//line aot_arbace_core_protocols.ae:1
package aot_arbace_core_protocols

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_New() *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_core_protocols_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_protocols_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_core_protocols_eval619000006_fn__619000007_A_New() *A_arbace_core_protocols_eval619000006_fn__619000007_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000006_fn__619000007_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_protocols_eval619000006_fn__619000007_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_protocols_eval619000006_fn__619000007_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_core_protocols_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_core_protocols_A_const_4), A_arbace_core_protocols_A_const_5.GetRawRoot__O(), A_arbace_core_protocols_A_const_6) }



func A_arbace_core_protocols_eval619000020_fn__619000021_A_New() *A_arbace_core_protocols_eval619000020_fn__619000021_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000020_fn__619000021_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_A) Ctor() {}
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__619000013__2_ any; var tmp1 any = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_New(); var tmp2 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_fn_class = fncls__17d; tmp2 = fncls__17d } else { tmp2 = fncls__17 }; G__619000013__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_New_O(G__619000013__2_); var tmp4 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_fn_class = fncls__32d; tmp4 = fncls__32d } else { tmp4 = fncls__32 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :13:1
func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_New_O(p0 any) *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A{}; t.Ctor_O(p0); return t }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) Ctor_O(c__G__619000013 any) { t.F_G__619000013 = c__G__619000013 }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) Invoke_O_O_O_O__O(self, gf__coll__619000031__1, gf__f__619000032__2, gf__val__619000033__3 any) any { var cache__231000236__auto____4 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____5 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____4)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__coll__619000031__1)); if jrt.J2g_Truth(f__231000237__auto____5) { return lang.IFn_Cast(f__231000237__auto____5).Invoke_O_O_O__O(gf__coll__619000031__1, gf__f__619000032__2, gf__val__619000033__3) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__coll__619000031__1, A_arbace_core_protocols_A_const_8, t.F_G__619000013)).Invoke_O_O_O__O(gf__coll__619000031__1, gf__f__619000032__2, gf__val__619000033__3) } }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) Invoke_O_O_O__O(self, gf__coll__619000029__1, gf__f__619000030__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__coll__619000029__1)); if jrt.J2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__coll__619000029__1, gf__f__619000030__2) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__coll__619000029__1, A_arbace_core_protocols_A_const_8, t.F_G__619000013)).Invoke_O_O__O(gf__coll__619000029__1, gf__f__619000030__2) } }
//line :13:1
func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_New() *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) Ctor() {}
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) Invoke_O_O_O_O__O(self, gf__coll__619000024__1, gf__f__619000025__2, gf__val__619000026__3 any) any { var target_15 any = gf__coll__619000024__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_15 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_15) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_15, Lit_3, jrt.RefArrayOf(jrt.Object_class, gf__f__619000025__2, gf__val__619000026__3)) } else { return A_arbace_core_protocols_CollReduce_A_Cast(target_15).Coll_reduce_O_O__O(gf__f__619000025__2, gf__val__619000026__3) } }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) Invoke_O_O_O__O(self, gf__coll__619000022__1, gf__f__619000023__2 any) any { var target_16 any = gf__coll__619000022__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_16 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_16) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_16, Lit_3, jrt.RefArrayOf(jrt.Object_class, gf__f__619000023__2)) } else { return A_arbace_core_protocols_CollReduce_A_Cast(target_16).Coll_reduce_O__O(gf__f__619000023__2) } }





func A_arbace_core_protocols_eval619000050_fn__619000051_A_New() *A_arbace_core_protocols_eval619000050_fn__619000051_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000050_fn__619000051_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_A) Ctor() {}
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__619000043__2_ any; var tmp1 any = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_New(); var tmp2 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_fn_class = fncls__34d; tmp2 = fncls__34d } else { tmp2 = fncls__34 }; G__619000043__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_New_O(G__619000043__2_); var tmp4 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_fn_class = fncls__42d; tmp4 = fncls__42d } else { tmp4 = fncls__42 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :19:1
func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_New_O(p0 any) *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A{}; t.Ctor_O(p0); return t }
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A) Ctor_O(c__G__619000043 any) { t.F_G__619000043 = c__G__619000043 }
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A) Invoke_O_O_O_O__O(self, gf__seq__619000057__1, gf__f__619000058__2, gf__start__619000059__3 any) any { var cache__231000236__auto____4 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____5 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____4)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__seq__619000057__1)); if jrt.J2g_Truth(f__231000237__auto____5) { return lang.IFn_Cast(f__231000237__auto____5).Invoke_O_O_O__O(gf__seq__619000057__1, gf__f__619000058__2, gf__start__619000059__3) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__seq__619000057__1, A_arbace_core_protocols_A_const_9, t.F_G__619000043)).Invoke_O_O_O__O(gf__seq__619000057__1, gf__f__619000058__2, gf__start__619000059__3) } }
//line :19:1
func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_New() *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A) Ctor() {}
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A) Invoke_O_O_O_O__O(self, gf__seq__619000052__1, gf__f__619000053__2, gf__start__619000054__3 any) any { var target_33 any = gf__seq__619000052__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_33 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_33) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_33, Lit_6, jrt.RefArrayOf(jrt.Object_class, gf__f__619000053__2, gf__start__619000054__3)) } else { return A_arbace_core_protocols_InternalReduce_A_Cast(target_33).Internal_reduce_O_O__O(gf__f__619000053__2, gf__start__619000054__3) } }




func A_arbace_core_protocols_seq_reduce_A_New() *A_arbace_core_protocols_seq_reduce_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_seq_reduce_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_core_protocols_seq_reduce_A) Ctor() {}
//line :24:1
func (t *A_arbace_core_protocols_seq_reduce_A) Invoke_O_O_O_O__O(self, coll__0, f__1, val__2 any) any { var s__4 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_10.GetRawRoot__O()).Invoke_O__O(coll__0); var target_47 any = s__4; var tmp1 bool; var tmp2 bool; tmp2 =






	A_arbace_core_protocols_InternalReduce_A_InstanceOf(target_47); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_47) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_protocols_InternalReduce_A_Cast(target_47).Internal_reduce_O_O__O(f__1, val__2) } else { return lang.IFn_Cast(A_arbace_core_protocols_A_const_11.GetRawRoot__O()).Invoke_O_O_O__O(target_47, f__1, val__2) } }
//line :24:1
func (t *A_arbace_core_protocols_seq_reduce_A) Invoke_O_O_O__O(self, coll__0, f__1 any) any { var temp__1927000408__auto____3 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_10.GetRawRoot__O()).Invoke_O__O(coll__0); if

	jrt.J2g_Truth(temp__1927000408__auto____3) { var s__4 any = temp__1927000408__auto____3; var target_52 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_12.GetRawRoot__O()).Invoke_O__O(s__4); var tmp1 bool; var tmp2 bool
		tmp2 = A_arbace_core_protocols_InternalReduce_A_InstanceOf(target_52); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_52) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_protocols_InternalReduce_A_Cast(target_52).Internal_reduce_O_O__O(f__1, lang.IFn_Cast(A_arbace_core_protocols_A_const_13.GetRawRoot__O()).Invoke_O__O(s__4)) } else { return lang.IFn_Cast(A_arbace_core_protocols_A_const_11.GetRawRoot__O()).Invoke_O_O_O__O(target_52, f__1, lang.IFn_Cast(A_arbace_core_protocols_A_const_13.GetRawRoot__O()).Invoke_O__O(s__4)) } } else {
			return lang.IFn_Cast(f__1).Invoke__O() } }





func A_arbace_core_protocols_iterator_reduce_BANG__A_New() *A_arbace_core_protocols_iterator_reduce_BANG__A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_iterator_reduce_BANG__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) Ctor() {}
//line :34:1
func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) Invoke_O_O_O_O__O(self, iter__0, f__1, val__2 any) any { { var ret__4 any = val__2; L1: for {






	if jrt.Iterator_Cast(iter__0).HasNext__Z() { var ret__5 any = lang.IFn_Cast(f__1).Invoke_O_O__O(ret__4, jrt.Iterator_Cast(iter__0).Next__O())

		if lang.RT_IsReduced_O__Z_NoInit(ret__5) { return lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(ret__5) } else {

			ret__4 = ret__5; continue L1 } } else {
//line :41:1
				return ret__4 } } }; /*line :34:1*/panic("j2g: unreachable") }
//line :34:1
func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) Invoke_O_O_O__O(self, iter__0, f__1 any) any {

	if jrt.Iterator_Cast(iter__0).HasNext__Z() {
		var root_69 any = A_arbace_core_protocols_A_const_14.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, A_arbace_core_protocols_iterator_reduce_BANG__A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = iter__0; var arg_73 any = f__1; var arg_74 any = jrt.Iterator_Cast(iter__0).Next__O(); if linked_70 == nil { return ifn_71.Invoke_O_O_O__O(arg_72, arg_73, arg_74) } else { return linked_70.(*A_arbace_core_protocols_iterator_reduce_BANG__A).Invoke_O_O_O_O__O(root_69, arg_72, arg_73, arg_74) } } else {
			return lang.IFn_Cast(f__1).Invoke__O()
		}
}







func A_arbace_core_protocols_iter_reduce_A_New() *A_arbace_core_protocols_iter_reduce_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_iter_reduce_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_core_protocols_iter_reduce_A) Ctor() {}
//line :48:1
func (t *A_arbace_core_protocols_iter_reduce_A) Invoke_O_O_O_O__O(self, coll__0, f__1, val__2 any) any {



	var root_75 any = A_arbace_core_protocols_A_const_14.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, A_arbace_core_protocols_iterator_reduce_BANG__A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = jrt.Iterable_Cast(coll__0).Iterator__Iterator(); var arg_79 any = f__1; var arg_80 any = val__2; if linked_76 == nil { return ifn_77.Invoke_O_O_O__O(arg_78, arg_79, arg_80) } else { return linked_76.(*A_arbace_core_protocols_iterator_reduce_BANG__A).Invoke_O_O_O_O__O(root_75, arg_78, arg_79, arg_80) } }
//line :48:1
func (t *A_arbace_core_protocols_iter_reduce_A) Invoke_O_O_O__O(self, coll__0, f__1 any) any {

	var root_81 any = A_arbace_core_protocols_A_const_14.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, A_arbace_core_protocols_iterator_reduce_BANG__A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = jrt.Iterable_Cast(coll__0).Iterator__Iterator(); var arg_85 any = f__1; if linked_82 == nil { return ifn_83.Invoke_O_O__O(arg_84, arg_85) } else { return linked_82.(*A_arbace_core_protocols_iterator_reduce_BANG__A).Invoke_O_O_O__O(root_81, arg_84, arg_85)
	}
}

func A_arbace_core_protocols_naive_seq_reduce_A_New() *A_arbace_core_protocols_naive_seq_reduce_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_naive_seq_reduce_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_core_protocols_naive_seq_reduce_A) Ctor() {}
//line :54:1
func (t *A_arbace_core_protocols_naive_seq_reduce_A) Invoke_O_O_O_O__O(self, s__0, f__1, val__2 any) any { { var s__4 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_10.GetRawRoot__O()).Invoke_O__O(s__0); var val__5 any = val__2; L1: for {





	if jrt.J2g_Truth(s__4) { var ret__6 any = lang.IFn_Cast(f__1).Invoke_O_O__O(val__5, lang.IFn_Cast(A_arbace_core_protocols_A_const_13.GetRawRoot__O()).Invoke_O__O(s__4))

		if lang.RT_IsReduced_O__Z_NoInit(ret__6) { return lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(ret__6) } else {

			s__4, val__5 = lang.IFn_Cast(A_arbace_core_protocols_A_const_12.GetRawRoot__O()).Invoke_O__O(s__4), ret__6; continue L1 } } else {
//line :60:1
				return val__5 } } }; /*line :54:1*/panic("j2g: unreachable") }












func A_arbace_core_protocols_interface_or_naive_reduce_A_New() *A_arbace_core_protocols_interface_or_naive_reduce_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_interface_or_naive_reduce_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_core_protocols_interface_or_naive_reduce_A) Ctor() {}
//line :67:1
func (t *A_arbace_core_protocols_interface_or_naive_reduce_A) Invoke_O_O_O_O__O(self, coll__0, f__1, val__2 any) any {


	if lang.IReduceInit_InstanceOf(coll__0) {
		return lang.IReduceInit_Cast(coll__0).Reduce_IFn_O__O(lang.IFn_Cast(f__1), val__2) } else {
			var root_102 any = A_arbace_core_protocols_A_const_15.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, A_arbace_core_protocols_naive_seq_reduce_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = coll__0; var arg_106 any = f__1; var arg_107 any = val__2; if linked_103 == nil { return ifn_104.Invoke_O_O_O__O(arg_105, arg_106, arg_107) } else { return linked_103.(*A_arbace_core_protocols_naive_seq_reduce_A).Invoke_O_O_O_O__O(root_102, arg_105, arg_106, arg_107)
			} } }
func A_arbace_core_protocols_eval619000073_fn__619000074_A_New() *A_arbace_core_protocols_eval619000073_fn__619000074_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000073_fn__619000074_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any { return val__3 }
//line :74:1
func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {


	return lang.IFn_Cast(f__2).Invoke__O() }
//line :74:1
func A_arbace_core_protocols_eval619000077_fn__619000078_A_New() *A_arbace_core_protocols_eval619000077_fn__619000078_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000077_fn__619000078_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {








	var root_108 any = A_arbace_core_protocols_A_const_16.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, A_arbace_core_protocols_seq_reduce_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = coll__1; var arg_112 any = f__2; var arg_113 any = val__3; if linked_109 == nil { return ifn_110.Invoke_O_O_O__O(arg_111, arg_112, arg_113) } else { return linked_109.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O_O__O(root_108, arg_111, arg_112, arg_113) } }
//line :74:1
func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {







	var root_114 any = A_arbace_core_protocols_A_const_16.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, A_arbace_core_protocols_seq_reduce_A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = coll__1; var arg_118 any = f__2; if linked_115 == nil { return ifn_116.Invoke_O_O__O(arg_117, arg_118) } else { return linked_115.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O__O(root_114, arg_117, arg_118) } }
//line :74:1
func A_arbace_core_protocols_eval619000081_fn__619000082_A_New() *A_arbace_core_protocols_eval619000081_fn__619000082_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000081_fn__619000082_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {








































	var root_119 any = A_arbace_core_protocols_A_const_16.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, A_arbace_core_protocols_seq_reduce_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = coll__1; var arg_123 any = f__2; var arg_124 any = val__3; if linked_120 == nil { return ifn_121.Invoke_O_O_O__O(arg_122, arg_123, arg_124) } else { return linked_120.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O_O__O(root_119, arg_122, arg_123, arg_124) } }
//line :74:1
func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {







































	var root_125 any = A_arbace_core_protocols_A_const_16.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, A_arbace_core_protocols_seq_reduce_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = coll__1; var arg_129 any = f__2; if linked_126 == nil { return ifn_127.Invoke_O_O__O(arg_128, arg_129) } else { return linked_126.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O__O(root_125, arg_128, arg_129) } }
//line :74:1
func A_arbace_core_protocols_eval619000085_fn__619000086_A_New() *A_arbace_core_protocols_eval619000085_fn__619000086_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000085_fn__619000086_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {













































	var root_130 any = A_arbace_core_protocols_A_const_17.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_core_protocols_iter_reduce_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = coll__1; var arg_134 any = f__2; var arg_135 any = val__3; if linked_131 == nil { return ifn_132.Invoke_O_O_O__O(arg_133, arg_134, arg_135) } else { return linked_131.(*A_arbace_core_protocols_iter_reduce_A).Invoke_O_O_O_O__O(root_130, arg_133, arg_134, arg_135) } }
//line :74:1
func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {












































	var root_136 any = A_arbace_core_protocols_A_const_17.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, A_arbace_core_protocols_iter_reduce_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = coll__1; var arg_140 any = f__2; if linked_137 == nil { return ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { return linked_137.(*A_arbace_core_protocols_iter_reduce_A).Invoke_O_O_O__O(root_136, arg_139, arg_140) } }
//line :74:1
func A_arbace_core_protocols_eval619000089_fn__619000090_A_New() *A_arbace_core_protocols_eval619000089_fn__619000090_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000089_fn__619000090_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {




























	var root_141 any = A_arbace_core_protocols_A_const_16.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, A_arbace_core_protocols_seq_reduce_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = coll__1; var arg_145 any = f__2; var arg_146 any = val__3; if linked_142 == nil { return ifn_143.Invoke_O_O_O__O(arg_144, arg_145, arg_146) } else { return linked_142.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O_O__O(root_141, arg_144, arg_145, arg_146) } }
//line :74:1
func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {



























	var root_147 any = A_arbace_core_protocols_A_const_16.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, A_arbace_core_protocols_seq_reduce_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = coll__1; var arg_151 any = f__2; if linked_148 == nil { return ifn_149.Invoke_O_O__O(arg_150, arg_151) } else { return linked_148.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O__O(root_147, arg_150, arg_151) } }
//line :74:1
func A_arbace_core_protocols_eval619000093_fn__619000094_A_New() *A_arbace_core_protocols_eval619000093_fn__619000094_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000093_fn__619000094_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {






















	return lang.IReduceInit_Cast(coll__1).Reduce_IFn_O__O(lang.IFn_Cast(f__2), val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {













	if lang.IReduce_InstanceOf(coll__1) {
		return lang.IReduce_Cast(coll__1).Reduce_IFn__O(lang.IFn_Cast(f__2)) } else {
//line :88:1
			var none__3 any = jrt.Object_New(); var ret__4 any; var tmp1 lang.IReduceInit = lang.IReduceInit_Cast(coll__1); var tmp2 any = A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_New_O_O(f__2, none__3); var tmp3 *jrt.Class
			var fncls__152 /*line :88:1*/*jrt.Class = A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_fn_class





			if fncls__152 == nil { var fncls__152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_fn_class = fncls__152d; tmp3 = fncls__152d } else { tmp3 = fncls__152 }
//line :93:1
			ret__4 = tmp1.Reduce_IFn_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), none__3)


			if lang.Util_Identical_O_O__Z_NoInit(ret__4, none__3) { return lang.IFn_Cast(f__2).Invoke__O() } else { return ret__4 } } }
//line :74:1
func A_arbace_core_protocols_eval619000099_fn__619000100_A_New() *A_arbace_core_protocols_eval619000099_fn__619000100_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000099_fn__619000100_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {


































	var root_153 any = A_arbace_core_protocols_A_const_16.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, A_arbace_core_protocols_seq_reduce_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = coll__1; var arg_157 any = f__2; var arg_158 any = val__3; if linked_154 == nil { return ifn_155.Invoke_O_O_O__O(arg_156, arg_157, arg_158) } else { return linked_154.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O_O__O(root_153, arg_156, arg_157, arg_158) } }
//line :74:1
func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {

































	var root_159 any = A_arbace_core_protocols_A_const_16.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, A_arbace_core_protocols_seq_reduce_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = coll__1; var arg_163 any = f__2; if linked_160 == nil { return ifn_161.Invoke_O_O__O(arg_162, arg_163) } else { return linked_160.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O__O(root_159, arg_162, arg_163) } }
//line :74:1
func A_arbace_core_protocols_eval619000103_fn__619000104_A_New() *A_arbace_core_protocols_eval619000103_fn__619000104_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000103_fn__619000104_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {


















































	var root_164 any = A_arbace_core_protocols_A_const_17.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, A_arbace_core_protocols_iter_reduce_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = coll__1; var arg_168 any = f__2; var arg_169 any = val__3; if linked_165 == nil { return ifn_166.Invoke_O_O_O__O(arg_167, arg_168, arg_169) } else { return linked_165.(*A_arbace_core_protocols_iter_reduce_A).Invoke_O_O_O_O__O(root_164, arg_167, arg_168, arg_169) } }
//line :74:1
func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {

















































	var root_170 any = A_arbace_core_protocols_A_const_17.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, A_arbace_core_protocols_iter_reduce_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = coll__1; var arg_174 any = f__2; if linked_171 == nil { return ifn_172.Invoke_O_O__O(arg_173, arg_174) } else { return linked_171.(*A_arbace_core_protocols_iter_reduce_A).Invoke_O_O_O__O(root_170, arg_173, arg_174) } }
//line :74:1
func A_arbace_core_protocols_eval619000107_fn__619000108_A_New() *A_arbace_core_protocols_eval619000107_fn__619000108_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000107_fn__619000108_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {























































	var root_175 any = A_arbace_core_protocols_A_const_17.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, A_arbace_core_protocols_iter_reduce_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = coll__1; var arg_179 any = f__2; var arg_180 any = val__3; if linked_176 == nil { return ifn_177.Invoke_O_O_O__O(arg_178, arg_179, arg_180) } else { return linked_176.(*A_arbace_core_protocols_iter_reduce_A).Invoke_O_O_O_O__O(root_175, arg_178, arg_179, arg_180) } }
//line :74:1
func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {






















































	var root_181 any = A_arbace_core_protocols_A_const_17.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, A_arbace_core_protocols_iter_reduce_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = coll__1; var arg_185 any = f__2; if linked_182 == nil { return ifn_183.Invoke_O_O__O(arg_184, arg_185) } else { return linked_182.(*A_arbace_core_protocols_iter_reduce_A).Invoke_O_O_O__O(root_181, arg_184, arg_185) } }
//line :94:1
func A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_New_O_O(p0, p1 any) *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A{}; t.Ctor_O_O(p0, p1); return t }
//line :94:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A) Ctor_O_O(c__f, c__none any) { t.F_f = c__f; t.F_none = c__none }
//line :94:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A) Invoke_O_O_O__O(self, acc__1, x__2 any) any { if lang.Util_Identical_O_O__Z_NoInit(acc__1, t.F_none) { return x__2 } else { return lang.IFn_Cast(t.F_f).Invoke_O_O__O(acc__1, x__2) } }





































func A_arbace_core_protocols_eval619000111_fn__619000112_A_New() *A_arbace_core_protocols_eval619000111_fn__619000112_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000111_fn__619000112_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_core_protocols_eval619000111_fn__619000112_A) Ctor() {}
//line :132:1
func (t *A_arbace_core_protocols_eval619000111_fn__619000112_A) Invoke_O_O_O_O__O(self, s__1, f__2, val__3 any) any { return val__3 }
//line :132:1
func A_arbace_core_protocols_eval619000115_fn__619000116_A_New() *A_arbace_core_protocols_eval619000115_fn__619000116_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000115_fn__619000116_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_core_protocols_eval619000115_fn__619000116_A) Ctor() {}
//line :132:1
func (t *A_arbace_core_protocols_eval619000115_fn__619000116_A) Invoke_O_O_O_O__O(self, s__1, f__2, val__3 any) any { { var s__1_2 any = s__1; var f__2_2 any = f__2; var val__3_2 any = val__3; L1: for { var temp__1927000408__auto____4 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_10.GetRawRoot__O()).Invoke_O__O(s__1_2)









	if jrt.J2g_Truth(temp__1927000408__auto____4) { var s__5 any = temp__1927000408__auto____4
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_protocols_A_const_18.GetRawRoot__O()).Invoke_O__O(s__5)) { var ret__6 any = lang.IChunk_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_19.GetRawRoot__O()).Invoke_O__O(s__5)).Reduce_IFn_O__O(lang.IFn_Cast(f__2_2), val__3_2)

			if lang.RT_IsReduced_O__Z_NoInit(ret__6) { return lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(ret__6) } else {

				s__1_2, f__2_2, val__3_2 = lang.IFn_Cast(A_arbace_core_protocols_A_const_21.GetRawRoot__O()).Invoke_O__O(s__5), f__2_2, ret__6; continue L1 } } else {


					var root_202 any = A_arbace_core_protocols_A_const_20.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, A_arbace_core_protocols_interface_or_naive_reduce_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = s__5; var arg_206 any = f__2_2; var arg_207 any = val__3_2; if linked_203 == nil { return ifn_204.Invoke_O_O_O__O(arg_205, arg_206, arg_207) } else { return linked_203.(*A_arbace_core_protocols_interface_or_naive_reduce_A).Invoke_O_O_O_O__O(root_202, arg_205, arg_206, arg_207) } } } else {
//line :142:1
						return val__3_2 } } }; /*line :132:1*/panic("j2g: unreachable") }
//line :132:1
func A_arbace_core_protocols_eval619000119_fn__619000120_A_New() *A_arbace_core_protocols_eval619000119_fn__619000120_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000119_fn__619000120_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_core_protocols_eval619000119_fn__619000120_A) Ctor() {}
//line :132:1
func (t *A_arbace_core_protocols_eval619000119_fn__619000120_A) Invoke_O_O_O_O__O(self, str_seq__1, f__2, val__3 any) any { { var s__4 any = lang.StringSeq_Cast(str_seq__1).F_s; var len__5 int32 = jrt.CharSequence_Cast(s__4).Length__I(); var i__6 int64 = lang.RT_LongCast_I__J_NoInit(lang.StringSeq_Cast(str_seq__1).F_i); var val__7 any = val__3; L1: for {



























	if lang.Numbers_Lt_J_J__Z_NoInit(i__6, int64(len__5)) { var ret__8 any = lang.IFn_Cast(f__2).Invoke_O_O__O(val__7, jrt.Character_ValueOf_C__Character_NoInit(jrt.CharSequence_Cast(s__4).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__6))).Ref())

		if lang.RT_IsReduced_O__Z_NoInit(ret__8) { return lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(ret__8) } else {

			i__6, val__7 = lang.Numbers_Inc_J__J_NoInit(i__6), ret__8; continue L1 } } else {
//line :160:1
				return val__7 } } }; /*line :132:1*/panic("j2g: unreachable") }
//line :132:1
func A_arbace_core_protocols_eval619000123_fn__619000124_A_New() *A_arbace_core_protocols_eval619000123_fn__619000124_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000123_fn__619000124_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_core_protocols_eval619000123_fn__619000124_A) Ctor() {}
//line :132:1
func (t *A_arbace_core_protocols_eval619000123_fn__619000124_A) Invoke_O_O_O_O__O(self, s__1, f__2, val__3 any) any { { var cls__4 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_22.GetRawRoot__O()).Invoke_O__O(s__1); var s__5 any = s__1; var f__6 any = f__2; var val__7 any = val__3; L1: for { var temp__1927000408__auto____8 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_10.GetRawRoot__O()).Invoke_O__O(s__5)









































	if jrt.J2g_Truth(temp__1927000408__auto____8) { var s__9 any = temp__1927000408__auto____8
		if lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_core_protocols_A_const_22.GetRawRoot__O()).Invoke_O__O(s__9), cls__4) { var ret__10 any = lang.IFn_Cast(f__6).Invoke_O_O__O(val__7, lang.IFn_Cast(A_arbace_core_protocols_A_const_13.GetRawRoot__O()).Invoke_O__O(s__9))

			if lang.RT_IsReduced_O__Z_NoInit(ret__10) { return lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(ret__10) } else {

				cls__4, s__5, f__6, val__7 = cls__4, lang.IFn_Cast(A_arbace_core_protocols_A_const_12.GetRawRoot__O()).Invoke_O__O(s__9), f__6, ret__10; continue L1 } } else {
					var root_232 any = A_arbace_core_protocols_A_const_20.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, A_arbace_core_protocols_interface_or_naive_reduce_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = s__9; var arg_236 any = f__6; var arg_237 any = val__7; if linked_233 == nil { return ifn_234.Invoke_O_O_O__O(arg_235, arg_236, arg_237) } else { return linked_233.(*A_arbace_core_protocols_interface_or_naive_reduce_A).Invoke_O_O_O_O__O(root_232, arg_235, arg_236, arg_237) } } } else {
//line :174:1
						return val__7 } } }; /*line :132:1*/panic("j2g: unreachable") }


















































func A_arbace_core_protocols_eval619000135_fn__619000136_A_New() *A_arbace_core_protocols_eval619000135_fn__619000136_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000135_fn__619000136_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_A) Ctor() {}
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__619000128__2_ any; var tmp1 any = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_New(); var tmp2 *jrt.Class; var fncls__247 *jrt.Class = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_fn_class; if fncls__247 == nil { var fncls__247d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_fn_class = fncls__247d; tmp2 = fncls__247d } else { tmp2 = fncls__247 }; G__619000128__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_New_O(G__619000128__2_); var tmp4 *jrt.Class; var fncls__255 *jrt.Class = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_fn_class; if fncls__255 == nil { var fncls__255d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_fn_class = fncls__255d; tmp4 = fncls__255d } else { tmp4 = fncls__255 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :183:1
func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_New_O(p0 any) *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A{}; t.Ctor_O(p0); return t }
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A) Ctor_O(c__G__619000128 any) { t.F_G__619000128 = c__G__619000128 }
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A) Invoke_O_O_O_O__O(self, gf__amap__619000142__1, gf__f__619000143__2, gf__init__619000144__3 any) any { var cache__231000236__auto____4 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____5 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____4)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__amap__619000142__1)); if jrt.J2g_Truth(f__231000237__auto____5) { return lang.IFn_Cast(f__231000237__auto____5).Invoke_O_O_O__O(gf__amap__619000142__1, gf__f__619000143__2, gf__init__619000144__3) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__amap__619000142__1, A_arbace_core_protocols_A_const_23, t.F_G__619000128)).Invoke_O_O_O__O(gf__amap__619000142__1, gf__f__619000143__2, gf__init__619000144__3) } }
//line :183:1
func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_New() *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A) Ctor() {}
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A) Invoke_O_O_O_O__O(self, gf__amap__619000137__1, gf__f__619000138__2, gf__init__619000139__3 any) any { var target_246 any = gf__amap__619000137__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_246 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_246) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_246, Lit_10, jrt.RefArrayOf(jrt.Object_class, gf__f__619000138__2, gf__init__619000139__3)) } else { return A_arbace_core_protocols_IKVReduce_A_Cast(target_246).Kv_reduce_O_O__O(gf__f__619000138__2, gf__init__619000139__3) } }






func A_arbace_core_protocols_eval619000161_fn__619000162_A_New() *A_arbace_core_protocols_eval619000161_fn__619000162_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000161_fn__619000162_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_A) Ctor() {}
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__619000154__2_ any; var tmp1 any = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_New(); var tmp2 *jrt.Class; var fncls__257 *jrt.Class = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_fn_class; if fncls__257 == nil { var fncls__257d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_fn_class = fncls__257d; tmp2 = fncls__257d } else { tmp2 = fncls__257 }; G__619000154__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_New_O(G__619000154__2_); var tmp4 *jrt.Class; var fncls__265 *jrt.Class = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_fn_class; if fncls__265 == nil { var fncls__265d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_fn_class = fncls__265d; tmp4 = fncls__265d } else { tmp4 = fncls__265 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :190:1
func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_New_O(p0 any) *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A{}; t.Ctor_O(p0); return t }
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A) Ctor_O(c__G__619000154 any) { t.F_G__619000154 = c__G__619000154 }
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A) Invoke_O_O__O(self, gf__o__619000166__1 any) any { var cache__231000232__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000233__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000232__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__o__619000166__1)); if lang.Util_Identical_O_O__Z_NoInit(f__231000233__auto____3, t.F_G__619000154) { return lang.IFn_Cast(f__231000233__auto____3).Invoke_O__O(gf__o__619000166__1) } else { var temp__1927000408__auto____4 any; var temp__1927000414__auto____4 any = lang.RT_Meta_O__IPersistentMap_NoInit(gf__o__619000166__1); if jrt.J2g_Truth(temp__1927000414__auto____4) { var m__231000235__auto____5 any = temp__1927000414__auto____4; temp__1927000408__auto____4 = Up_Symbol_IFn(lang.MethodImplCache_Cast(cache__231000232__auto____2).F_sym).Invoke_O__O(m__231000235__auto____5) } else { temp__1927000408__auto____4 = nil }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var meta__231000234__auto____5 any = temp__1927000408__auto____4; return lang.IFn_Cast(meta__231000234__auto____5).Invoke_O__O(gf__o__619000166__1) } else { if jrt.J2g_Truth(f__231000233__auto____3) { return lang.IFn_Cast(f__231000233__auto____3).Invoke_O__O(gf__o__619000166__1) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__o__619000166__1, A_arbace_core_protocols_A_const_24, t.F_G__619000154)).Invoke_O__O(gf__o__619000166__1) } } } }
//line :190:1
func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_New() *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A) Ctor() {}
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A) Invoke_O_O__O(self, gf__o__619000163__1 any) any { var target_256 any = gf__o__619000163__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_256 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_256) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_256, Lit_13, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_core_protocols_Datafiable_A_Cast(target_256).Datafy__O() } }




func A_arbace_core_protocols_eval619000175_fn__619000176_A_New() *A_arbace_core_protocols_eval619000175_fn__619000176_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000175_fn__619000176_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_core_protocols_eval619000175_fn__619000176_A) Ctor() {}
//line :195:1
func (t *A_arbace_core_protocols_eval619000175_fn__619000176_A) Invoke_O_O__O(self, ___1 any) any { return nil }
//line :195:1
func A_arbace_core_protocols_eval619000179_fn__619000180_A_New() *A_arbace_core_protocols_eval619000179_fn__619000180_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000179_fn__619000180_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_core_protocols_eval619000179_fn__619000180_A) Ctor() {}
//line :195:1
func (t *A_arbace_core_protocols_eval619000179_fn__619000180_A) Invoke_O_O__O(self, x__1 any) any { return x__1 }






func A_arbace_core_protocols_eval619000191_fn__619000192_A_New() *A_arbace_core_protocols_eval619000191_fn__619000192_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000191_fn__619000192_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_A) Ctor() {}
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__619000184__2_ any; var tmp1 any = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_New(); var tmp2 *jrt.Class; var fncls__267 *jrt.Class = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_fn_class; if fncls__267 == nil { var fncls__267d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_fn_class = fncls__267d; tmp2 = fncls__267d } else { tmp2 = fncls__267 }; G__619000184__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_New_O(G__619000184__2_); var tmp4 *jrt.Class; var fncls__275 *jrt.Class = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_fn_class; if fncls__275 == nil { var fncls__275d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_fn_class = fncls__275d; tmp4 = fncls__275d } else { tmp4 = fncls__275 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :202:1
func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_New_O(p0 any) *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A) Ctor_O(c__G__619000184 any) { t.F_G__619000184 = c__G__619000184 }
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A) Invoke_O_O_O_O__O(self, gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3 any) any { var cache__231000232__auto____4 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000233__auto____5 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000232__auto____4)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__coll__619000198__1)); if lang.Util_Identical_O_O__Z_NoInit(f__231000233__auto____5, t.F_G__619000184) { return lang.IFn_Cast(f__231000233__auto____5).Invoke_O_O_O__O(gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3) } else { var temp__1927000408__auto____6 any; var temp__1927000414__auto____6 any = lang.RT_Meta_O__IPersistentMap_NoInit(gf__coll__619000198__1); if jrt.J2g_Truth(temp__1927000414__auto____6) { var m__231000235__auto____7 any = temp__1927000414__auto____6; temp__1927000408__auto____6 = Up_Symbol_IFn(lang.MethodImplCache_Cast(cache__231000232__auto____4).F_sym).Invoke_O__O(m__231000235__auto____7) } else { temp__1927000408__auto____6 = nil }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var meta__231000234__auto____7 any = temp__1927000408__auto____6; return lang.IFn_Cast(meta__231000234__auto____7).Invoke_O_O_O__O(gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3) } else { if jrt.J2g_Truth(f__231000233__auto____5) { return lang.IFn_Cast(f__231000233__auto____5).Invoke_O_O_O__O(gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__coll__619000198__1, A_arbace_core_protocols_A_const_25, t.F_G__619000184)).Invoke_O_O_O__O(gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3) } } } }
//line :202:1
func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_New() *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A) Ctor() {}
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A) Invoke_O_O_O_O__O(self, gf__coll__619000193__1, gf__k__619000194__2, gf__v__619000195__3 any) any { var target_266 any = gf__coll__619000193__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_266 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_266) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_266, Lit_16, jrt.RefArrayOf(jrt.Object_class, gf__k__619000194__2, gf__v__619000195__3)) } else { return A_arbace_core_protocols_Navigable_A_Cast(target_266).Nav_O_O__O(gf__k__619000194__2, gf__v__619000195__3) } }





func A_arbace_core_protocols_eval619000209_fn__619000210_A_New() *A_arbace_core_protocols_eval619000209_fn__619000210_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000209_fn__619000210_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_core_protocols_eval619000209_fn__619000210_A) Ctor() {}
//line :208:1
func (t *A_arbace_core_protocols_eval619000209_fn__619000210_A) Invoke_O_O_O_O__O(self, ___1, ___2, x__3 any) any { return x__3 }
































































type A_arbace_core_protocols_A struct{ jrt.Object }

var A_arbace_core_protocols_A_const_pool *jrt.RefArray

var A_arbace_core_protocols_A_const_0 *lang.Var

var A_arbace_core_protocols_A_const_1 any

var A_arbace_core_protocols_A_const_2 *lang.Var

var A_arbace_core_protocols_A_const_3 *lang.Var

var A_arbace_core_protocols_A_const_4 *lang.Var

var A_arbace_core_protocols_A_const_5 *lang.Var

var A_arbace_core_protocols_A_const_6 any

var A_arbace_core_protocols_A_const_7 *lang.Var

var A_arbace_core_protocols_A_const_8 *jrt.Class

var A_arbace_core_protocols_A_const_9 *jrt.Class

var A_arbace_core_protocols_A_const_10 *lang.Var

var A_arbace_core_protocols_A_const_11 *lang.Var

var A_arbace_core_protocols_A_const_12 *lang.Var

var A_arbace_core_protocols_A_const_13 *lang.Var

var A_arbace_core_protocols_A_const_14 *lang.Var

var A_arbace_core_protocols_A_const_15 *lang.Var

var A_arbace_core_protocols_A_const_16 *lang.Var

var A_arbace_core_protocols_A_const_17 *lang.Var

var A_arbace_core_protocols_A_const_18 *lang.Var

var A_arbace_core_protocols_A_const_19 *lang.Var

var A_arbace_core_protocols_A_const_20 *lang.Var

var A_arbace_core_protocols_A_const_21 *lang.Var

var A_arbace_core_protocols_A_const_22 *lang.Var

var A_arbace_core_protocols_A_const_23 *jrt.Class

var A_arbace_core_protocols_A_const_24 *jrt.Class

var A_arbace_core_protocols_A_const_25 *jrt.Class

var A_arbace_core_protocols_A_init jrt.ClassInit

func A_arbace_core_protocols_A_Init() { if !A_arbace_core_protocols_A_init.Done() { A_arbace_core_protocols_A_init.Run(A_arbace_core_protocols_A_clinit) } }

func A_arbace_core_protocols_A_clinit() { A_arbace_core_protocols_A_clinit_p0(); A_arbace_core_protocols_A_clinit_p1(); A_arbace_core_protocols_A_clinit_p2() }

func A_arbace_core_protocols_A_clinit_p0() { jrt.StartCheck(); A_arbace_core_protocols_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 28); A_arbace_core_protocols_A_const_0 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[2]); A_arbace_core_protocols_A_const_1 = A_arbace_core_protocols_A_const_pool.A[3]; A_arbace_core_protocols_A_const_2 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[4]); A_arbace_core_protocols_A_const_3 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[5]); A_arbace_core_protocols_A_const_4 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[6]); A_arbace_core_protocols_A_const_5 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[7]); A_arbace_core_protocols_A_const_6 = A_arbace_core_protocols_A_const_pool.A[8]; A_arbace_core_protocols_A_const_7 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[9]); A_arbace_core_protocols_A_const_8 = jrt.Class_Cast(A_arbace_core_protocols_A_const_pool.A[10]); A_arbace_core_protocols_A_const_9 = jrt.Class_Cast(A_arbace_core_protocols_A_const_pool.A[11]); A_arbace_core_protocols_A_const_10 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[12]) }

func A_arbace_core_protocols_A_clinit_p1() { A_arbace_core_protocols_A_const_11 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[13]); A_arbace_core_protocols_A_const_12 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[14]); A_arbace_core_protocols_A_const_13 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[15]); A_arbace_core_protocols_A_const_14 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[16]); A_arbace_core_protocols_A_const_15 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[17]); A_arbace_core_protocols_A_const_16 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[18]); A_arbace_core_protocols_A_const_17 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[19]); A_arbace_core_protocols_A_const_18 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[20]); A_arbace_core_protocols_A_const_19 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[21]); A_arbace_core_protocols_A_const_20 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[22]); A_arbace_core_protocols_A_const_21 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[23]); A_arbace_core_protocols_A_const_22 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[24]) }

func A_arbace_core_protocols_A_clinit_p2() { A_arbace_core_protocols_A_const_23 = jrt.Class_Cast(A_arbace_core_protocols_A_const_pool.A[25]); A_arbace_core_protocols_A_const_24 = jrt.Class_Cast(A_arbace_core_protocols_A_const_pool.A[26]); A_arbace_core_protocols_A_const_25 = jrt.Class_Cast(A_arbace_core_protocols_A_const_pool.A[27]) }

func A_arbace_core_protocols_A_New() *A_arbace_core_protocols_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_A) Ctor() {}

func (t *A_arbace_core_protocols_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_A_class }

func (t *A_arbace_core_protocols_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_A); return ok }

func A_arbace_core_protocols_A_Cast(x any) *A_arbace_core_protocols_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_A_class)) }; return v }



type A_arbace_core_protocols_eval619000002_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000002_A_New() *A_arbace_core_protocols_eval619000002_A { t := &A_arbace_core_protocols_eval619000002_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000002_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000002_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000002_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000002_A_class }

func (t *A_arbace_core_protocols_eval619000002_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000002_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000002_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000002_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000002_A); return ok }

func A_arbace_core_protocols_eval619000002_A_Cast(x any) *A_arbace_core_protocols_eval619000002_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000002_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000002_A_class)) }; return v }



type A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000006_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000006_A_New() *A_arbace_core_protocols_eval619000006_A { t := &A_arbace_core_protocols_eval619000006_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000006_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000006_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000006_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000006_A_class }

func (t *A_arbace_core_protocols_eval619000006_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000006_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000006_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000006_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000006_A); return ok }

func A_arbace_core_protocols_eval619000006_A_Cast(x any) *A_arbace_core_protocols_eval619000006_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000006_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000006_A_class)) }; return v }



type A_arbace_core_protocols_eval619000006_fn__619000007_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000006_fn__619000007_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000020_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000020_A_New() *A_arbace_core_protocols_eval619000020_A { t := &A_arbace_core_protocols_eval619000020_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000020_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000020_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000020_A_class }

func (t *A_arbace_core_protocols_eval619000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000020_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000020_A); return ok }

func A_arbace_core_protocols_eval619000020_A_Cast(x any) *A_arbace_core_protocols_eval619000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000020_A_class)) }; return v }



type A_arbace_core_protocols_eval619000020_fn__619000021_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000020_fn__619000021_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A struct{ j2g_header uint64; F_G__619000013 any }

var A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000050_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000050_A_New() *A_arbace_core_protocols_eval619000050_A { t := &A_arbace_core_protocols_eval619000050_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000050_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000050_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000050_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000050_A_class }

func (t *A_arbace_core_protocols_eval619000050_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000050_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000050_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000050_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000050_A); return ok }

func A_arbace_core_protocols_eval619000050_A_Cast(x any) *A_arbace_core_protocols_eval619000050_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000050_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000050_A_class)) }; return v }



type A_arbace_core_protocols_eval619000050_fn__619000051_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000050_fn__619000051_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A struct{ j2g_header uint64; F_G__619000043 any }

var A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000073_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000073_A_New() *A_arbace_core_protocols_eval619000073_A { t := &A_arbace_core_protocols_eval619000073_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000073_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000073_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000073_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000073_A_class }

func (t *A_arbace_core_protocols_eval619000073_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000073_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000073_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000073_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000073_A); return ok }

func A_arbace_core_protocols_eval619000073_A_Cast(x any) *A_arbace_core_protocols_eval619000073_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000073_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000073_A_class)) }; return v }



type A_arbace_core_protocols_eval619000073_fn__619000074_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000073_fn__619000074_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000077_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000077_A_New() *A_arbace_core_protocols_eval619000077_A { t := &A_arbace_core_protocols_eval619000077_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000077_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000077_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000077_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000077_A_class }

func (t *A_arbace_core_protocols_eval619000077_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000077_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000077_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000077_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000077_A); return ok }

func A_arbace_core_protocols_eval619000077_A_Cast(x any) *A_arbace_core_protocols_eval619000077_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000077_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000077_A_class)) }; return v }



type A_arbace_core_protocols_eval619000077_fn__619000078_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000077_fn__619000078_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000081_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000081_A_New() *A_arbace_core_protocols_eval619000081_A { t := &A_arbace_core_protocols_eval619000081_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000081_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000081_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000081_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000081_A_class }

func (t *A_arbace_core_protocols_eval619000081_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000081_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000081_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000081_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000081_A); return ok }

func A_arbace_core_protocols_eval619000081_A_Cast(x any) *A_arbace_core_protocols_eval619000081_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000081_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000081_A_class)) }; return v }



type A_arbace_core_protocols_eval619000081_fn__619000082_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000081_fn__619000082_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000085_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000085_A_New() *A_arbace_core_protocols_eval619000085_A { t := &A_arbace_core_protocols_eval619000085_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000085_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000085_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000085_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000085_A_class }

func (t *A_arbace_core_protocols_eval619000085_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000085_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000085_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000085_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000085_A); return ok }

func A_arbace_core_protocols_eval619000085_A_Cast(x any) *A_arbace_core_protocols_eval619000085_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000085_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000085_A_class)) }; return v }



type A_arbace_core_protocols_eval619000085_fn__619000086_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000085_fn__619000086_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000089_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000089_A_New() *A_arbace_core_protocols_eval619000089_A { t := &A_arbace_core_protocols_eval619000089_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000089_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000089_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000089_A_class }

func (t *A_arbace_core_protocols_eval619000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000089_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000089_A); return ok }

func A_arbace_core_protocols_eval619000089_A_Cast(x any) *A_arbace_core_protocols_eval619000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000089_A_class)) }; return v }



type A_arbace_core_protocols_eval619000089_fn__619000090_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000089_fn__619000090_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000093_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000093_A_New() *A_arbace_core_protocols_eval619000093_A { t := &A_arbace_core_protocols_eval619000093_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000093_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000093_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000093_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000093_A_class }

func (t *A_arbace_core_protocols_eval619000093_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000093_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000093_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000093_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000093_A); return ok }

func A_arbace_core_protocols_eval619000093_A_Cast(x any) *A_arbace_core_protocols_eval619000093_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000093_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000093_A_class)) }; return v }



type A_arbace_core_protocols_eval619000093_fn__619000094_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000093_fn__619000094_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A struct{ j2g_header uint64; F_f, F_none any }

var A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000099_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000099_A_New() *A_arbace_core_protocols_eval619000099_A { t := &A_arbace_core_protocols_eval619000099_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000099_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000099_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000099_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000099_A_class }

func (t *A_arbace_core_protocols_eval619000099_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000099_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000099_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000099_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000099_A); return ok }

func A_arbace_core_protocols_eval619000099_A_Cast(x any) *A_arbace_core_protocols_eval619000099_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000099_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000099_A_class)) }; return v }



type A_arbace_core_protocols_eval619000099_fn__619000100_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000099_fn__619000100_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000103_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000103_A_New() *A_arbace_core_protocols_eval619000103_A { t := &A_arbace_core_protocols_eval619000103_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000103_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000103_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000103_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000103_A_class }

func (t *A_arbace_core_protocols_eval619000103_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000103_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000103_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000103_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000103_A); return ok }

func A_arbace_core_protocols_eval619000103_A_Cast(x any) *A_arbace_core_protocols_eval619000103_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000103_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000103_A_class)) }; return v }



type A_arbace_core_protocols_eval619000103_fn__619000104_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000103_fn__619000104_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000107_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000107_A_New() *A_arbace_core_protocols_eval619000107_A { t := &A_arbace_core_protocols_eval619000107_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000107_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000107_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000107_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000107_A_class }

func (t *A_arbace_core_protocols_eval619000107_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000107_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000107_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000107_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000107_A); return ok }

func A_arbace_core_protocols_eval619000107_A_Cast(x any) *A_arbace_core_protocols_eval619000107_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000107_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000107_A_class)) }; return v }



type A_arbace_core_protocols_eval619000107_fn__619000108_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000107_fn__619000108_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000111_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000111_A_New() *A_arbace_core_protocols_eval619000111_A { t := &A_arbace_core_protocols_eval619000111_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000111_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000111_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000111_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000111_A_class }

func (t *A_arbace_core_protocols_eval619000111_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000111_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000111_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000111_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000111_A); return ok }

func A_arbace_core_protocols_eval619000111_A_Cast(x any) *A_arbace_core_protocols_eval619000111_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000111_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000111_A_class)) }; return v }



type A_arbace_core_protocols_eval619000111_fn__619000112_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000111_fn__619000112_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000115_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000115_A_New() *A_arbace_core_protocols_eval619000115_A { t := &A_arbace_core_protocols_eval619000115_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000115_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000115_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000115_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000115_A_class }

func (t *A_arbace_core_protocols_eval619000115_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000115_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000115_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000115_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000115_A); return ok }

func A_arbace_core_protocols_eval619000115_A_Cast(x any) *A_arbace_core_protocols_eval619000115_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000115_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000115_A_class)) }; return v }



type A_arbace_core_protocols_eval619000115_fn__619000116_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000115_fn__619000116_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000119_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000119_A_New() *A_arbace_core_protocols_eval619000119_A { t := &A_arbace_core_protocols_eval619000119_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000119_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000119_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000119_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000119_A_class }

func (t *A_arbace_core_protocols_eval619000119_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000119_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000119_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000119_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000119_A); return ok }

func A_arbace_core_protocols_eval619000119_A_Cast(x any) *A_arbace_core_protocols_eval619000119_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000119_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000119_A_class)) }; return v }



type A_arbace_core_protocols_eval619000119_fn__619000120_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000119_fn__619000120_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000123_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000123_A_New() *A_arbace_core_protocols_eval619000123_A { t := &A_arbace_core_protocols_eval619000123_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000123_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000123_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000123_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000123_A_class }

func (t *A_arbace_core_protocols_eval619000123_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000123_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000123_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000123_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000123_A); return ok }

func A_arbace_core_protocols_eval619000123_A_Cast(x any) *A_arbace_core_protocols_eval619000123_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000123_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000123_A_class)) }; return v }



type A_arbace_core_protocols_eval619000123_fn__619000124_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000123_fn__619000124_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000135_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000135_A_New() *A_arbace_core_protocols_eval619000135_A { t := &A_arbace_core_protocols_eval619000135_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000135_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000135_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000135_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000135_A_class }

func (t *A_arbace_core_protocols_eval619000135_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000135_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000135_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000135_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000135_A); return ok }

func A_arbace_core_protocols_eval619000135_A_Cast(x any) *A_arbace_core_protocols_eval619000135_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000135_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000135_A_class)) }; return v }



type A_arbace_core_protocols_eval619000135_fn__619000136_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000135_fn__619000136_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A struct{ j2g_header uint64; F_G__619000128 any }

var A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000161_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000161_A_New() *A_arbace_core_protocols_eval619000161_A { t := &A_arbace_core_protocols_eval619000161_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000161_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000161_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000161_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000161_A_class }

func (t *A_arbace_core_protocols_eval619000161_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000161_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000161_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000161_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000161_A); return ok }

func A_arbace_core_protocols_eval619000161_A_Cast(x any) *A_arbace_core_protocols_eval619000161_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000161_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000161_A_class)) }; return v }



type A_arbace_core_protocols_eval619000161_fn__619000162_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000161_fn__619000162_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A struct{ j2g_header uint64; F_G__619000154 any }

var A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000175_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000175_A_New() *A_arbace_core_protocols_eval619000175_A { t := &A_arbace_core_protocols_eval619000175_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000175_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000175_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000175_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000175_A_class }

func (t *A_arbace_core_protocols_eval619000175_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000175_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000175_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000175_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000175_A); return ok }

func A_arbace_core_protocols_eval619000175_A_Cast(x any) *A_arbace_core_protocols_eval619000175_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000175_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000175_A_class)) }; return v }



type A_arbace_core_protocols_eval619000175_fn__619000176_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000175_fn__619000176_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000179_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000179_A_New() *A_arbace_core_protocols_eval619000179_A { t := &A_arbace_core_protocols_eval619000179_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000179_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000179_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000179_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000179_A_class }

func (t *A_arbace_core_protocols_eval619000179_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000179_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000179_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000179_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000179_A); return ok }

func A_arbace_core_protocols_eval619000179_A_Cast(x any) *A_arbace_core_protocols_eval619000179_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000179_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000179_A_class)) }; return v }



type A_arbace_core_protocols_eval619000179_fn__619000180_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000179_fn__619000180_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000191_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000191_A_New() *A_arbace_core_protocols_eval619000191_A { t := &A_arbace_core_protocols_eval619000191_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000191_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000191_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000191_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000191_A_class }

func (t *A_arbace_core_protocols_eval619000191_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000191_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000191_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000191_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000191_A); return ok }

func A_arbace_core_protocols_eval619000191_A_Cast(x any) *A_arbace_core_protocols_eval619000191_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000191_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000191_A_class)) }; return v }



type A_arbace_core_protocols_eval619000191_fn__619000192_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000191_fn__619000192_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A struct{ j2g_header uint64; F_G__619000184 any }

var A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000209_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000209_A_New() *A_arbace_core_protocols_eval619000209_A { t := &A_arbace_core_protocols_eval619000209_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000209_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000209_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000209_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000209_A_class }

func (t *A_arbace_core_protocols_eval619000209_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000209_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000209_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000209_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000209_A); return ok }

func A_arbace_core_protocols_eval619000209_A_Cast(x any) *A_arbace_core_protocols_eval619000209_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000209_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000209_A_class)) }; return v }



type A_arbace_core_protocols_eval619000209_fn__619000210_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000209_fn__619000210_A_fn_class *jrt.Class



type A_arbace_core_protocols_interface_or_naive_reduce_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_interface_or_naive_reduce_A_fn_class *jrt.Class



type A_arbace_core_protocols_iter_reduce_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_iter_reduce_A_fn_class *jrt.Class



type A_arbace_core_protocols_iterator_reduce_BANG__A struct{ j2g_header uint64 }

var A_arbace_core_protocols_iterator_reduce_BANG__A_fn_class *jrt.Class



type A_arbace_core_protocols_naive_seq_reduce_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_naive_seq_reduce_A_fn_class *jrt.Class



type A_arbace_core_protocols_seq_reduce_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_seq_reduce_A_fn_class *jrt.Class
