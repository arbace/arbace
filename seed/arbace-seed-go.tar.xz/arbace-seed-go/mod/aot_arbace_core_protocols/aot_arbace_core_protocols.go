//line aot_arbace_core_protocols.ae:1
package aot_arbace_core_protocols

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_New() *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A { A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_Init(); t := &A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_core_protocols_A_Init(); tmp4 = A_arbace_core_protocols_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_core_protocols_A_Init(); tmp6 = A_arbace_core_protocols_A_const_1; tmp3 = tmp5.Invoke_O__O(tmp6) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp7 != nil { panic(tmp7) }; return tmp3 }
//line :9:1
func A_arbace_core_protocols_eval619000006_fn__619000007_A_New() *A_arbace_core_protocols_eval619000006_fn__619000007_A { A_arbace_core_protocols_eval619000006_fn__619000007_A_Init(); t := &A_arbace_core_protocols_eval619000006_fn__619000007_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_protocols_eval619000006_fn__619000007_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_protocols_eval619000006_fn__619000007_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_2; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_protocols_A_Init(); tmp3 = A_arbace_core_protocols_A_const_3; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_core_protocols_A_Init(); tmp5 = A_arbace_core_protocols_A_const_6; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_core_protocols_A_Init(); tmp7 = A_arbace_core_protocols_A_const_4; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_core_protocols_A_Init(); tmp9 = A_arbace_core_protocols_A_const_5; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }



func A_arbace_core_protocols_eval619000020_fn__619000021_A_New() *A_arbace_core_protocols_eval619000020_fn__619000021_A { A_arbace_core_protocols_eval619000020_fn__619000021_A_Init(); t := &A_arbace_core_protocols_eval619000020_fn__619000021_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_A) Ctor() {}
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__619000013__2_ any; var tmp1 any = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_New(); var tmp2 *jrt.Class; A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_Init(); tmp2 = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_fn_class; G__619000013__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_New_O(G__619000013__2_); var tmp4 *jrt.Class; A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_Init(); tmp4 = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_fn_class; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :13:1
func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_New_O(p0 any) *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A { A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_Init(); t := &A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A{}; t.Ctor_O(p0); return t }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) Ctor_O(c__G__619000013 any) { t.F_G__619000013 = c__G__619000013 }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) Invoke_O_O_O_O__O(self, gf__coll__619000031__1, gf__f__619000032__2, gf__val__619000033__3 any) any { var cache__231000236__auto____4 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____5 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____4)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__coll__619000031__1)); if jrt.A2g_Truth(f__231000237__auto____5) { return lang.IFn_Cast(f__231000237__auto____5).Invoke_O_O_O__O(gf__coll__619000031__1, gf__f__619000032__2, gf__val__619000033__3) } else { var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_core_protocols_A_Init(); tmp3 = A_arbace_core_protocols_A_const_8; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__coll__619000031__1, tmp3.Ref(), t.F_G__619000013)).Invoke_O_O_O__O(gf__coll__619000031__1, gf__f__619000032__2, gf__val__619000033__3) } }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) Invoke_O_O_O__O(self, gf__coll__619000029__1, gf__f__619000030__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__coll__619000029__1)); if jrt.A2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__coll__619000029__1, gf__f__619000030__2) } else { var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_core_protocols_A_Init(); tmp3 = A_arbace_core_protocols_A_const_8; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__coll__619000029__1, tmp3.Ref(), t.F_G__619000013)).Invoke_O_O__O(gf__coll__619000029__1, gf__f__619000030__2) } }
//line :13:1
func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_New() *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A { A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_Init(); t := &A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) Ctor() {}
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) Invoke_O_O_O_O__O(self, gf__coll__619000024__1, gf__f__619000025__2, gf__val__619000026__3 any) any { var target_1 any = gf__coll__619000024__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_1 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_1) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_1, Lit_31, jrt.RefArrayOf(jrt.Object_class, gf__f__619000025__2, gf__val__619000026__3)) } else { return A_arbace_core_protocols_CollReduce_A_Cast(target_1).Coll_reduce_O_O__O(gf__f__619000025__2, gf__val__619000026__3) } }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) Invoke_O_O_O__O(self, gf__coll__619000022__1, gf__f__619000023__2 any) any { var target_2 any = gf__coll__619000022__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_2 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_2) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_2, Lit_31, jrt.RefArrayOf(jrt.Object_class, gf__f__619000023__2)) } else { return A_arbace_core_protocols_CollReduce_A_Cast(target_2).Coll_reduce_O__O(gf__f__619000023__2) } }





func A_arbace_core_protocols_eval619000050_fn__619000051_A_New() *A_arbace_core_protocols_eval619000050_fn__619000051_A { A_arbace_core_protocols_eval619000050_fn__619000051_A_Init(); t := &A_arbace_core_protocols_eval619000050_fn__619000051_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_A) Ctor() {}
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__619000043__2_ any; var tmp1 any = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_New(); var tmp2 *jrt.Class; A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_Init(); tmp2 = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_fn_class; G__619000043__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_New_O(G__619000043__2_); var tmp4 *jrt.Class; A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_Init(); tmp4 = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_fn_class; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :19:1
func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_New_O(p0 any) *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A { A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_Init(); t := &A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A{}; t.Ctor_O(p0); return t }
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A) Ctor_O(c__G__619000043 any) { t.F_G__619000043 = c__G__619000043 }
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A) Invoke_O_O_O_O__O(self, gf__seq__619000057__1, gf__f__619000058__2, gf__start__619000059__3 any) any { var cache__231000236__auto____4 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____5 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____4)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__seq__619000057__1)); if jrt.A2g_Truth(f__231000237__auto____5) { return lang.IFn_Cast(f__231000237__auto____5).Invoke_O_O_O__O(gf__seq__619000057__1, gf__f__619000058__2, gf__start__619000059__3) } else { var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_core_protocols_A_Init(); tmp3 = A_arbace_core_protocols_A_const_9; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__seq__619000057__1, tmp3.Ref(), t.F_G__619000043)).Invoke_O_O_O__O(gf__seq__619000057__1, gf__f__619000058__2, gf__start__619000059__3) } }
//line :19:1
func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_New() *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A { A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_Init(); t := &A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A) Ctor() {}
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A) Invoke_O_O_O_O__O(self, gf__seq__619000052__1, gf__f__619000053__2, gf__start__619000054__3 any) any { var target_3 any = gf__seq__619000052__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_3 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_3) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_3, Lit_35, jrt.RefArrayOf(jrt.Object_class, gf__f__619000053__2, gf__start__619000054__3)) } else { return A_arbace_core_protocols_InternalReduce_A_Cast(target_3).Internal_reduce_O_O__O(gf__f__619000053__2, gf__start__619000054__3) } }




func A_arbace_core_protocols_seq_reduce_A_New() *A_arbace_core_protocols_seq_reduce_A { A_arbace_core_protocols_seq_reduce_A_Init(); t := &A_arbace_core_protocols_seq_reduce_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_core_protocols_seq_reduce_A) Ctor() {}
//line :24:1
func (t *A_arbace_core_protocols_seq_reduce_A) Invoke_O_O_O_O__O(self, coll__0, f__1, val__2 any) any { var s__4 any; var tmp1 *lang.Var;





	A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_10; s__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(coll__0); var target_4 any = s__4; var tmp2 bool; var tmp3 bool; tmp3 =
	A_arbace_core_protocols_InternalReduce_A_InstanceOf(target_4); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z(target_4) }; tmp2 = tmp3; if tmp2 { return A_arbace_core_protocols_InternalReduce_A_Cast(target_4).Internal_reduce_O_O__O(f__1, val__2) } else { var tmp4 *lang.Var; A_arbace_core_protocols_A_Init(); tmp4 = A_arbace_core_protocols_A_const_11; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O_O__O(target_4, f__1, val__2) } }
//line :24:1
func (t *A_arbace_core_protocols_seq_reduce_A) Invoke_O_O_O__O(self, coll__0, f__1 any) any { var temp__1927000408__auto____3 any; var tmp1 *lang.Var;

	A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_10; temp__1927000408__auto____3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(coll__0); if jrt.A2g_Truth(temp__1927000408__auto____3) { var s__4 any = temp__1927000408__auto____3; var target_5 any; var tmp2 *lang.Var
		A_arbace_core_protocols_A_Init(); tmp2 = A_arbace_core_protocols_A_const_12; target_5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__4); var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_core_protocols_InternalReduce_A_InstanceOf(target_5); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z(target_5) }; tmp3 = tmp4; if tmp3 { var tmp5 A_arbace_core_protocols_InternalReduce_A = A_arbace_core_protocols_InternalReduce_A_Cast(target_5); var tmp6 *lang.Var; A_arbace_core_protocols_A_Init(); tmp6 = A_arbace_core_protocols_A_const_13; return tmp5.Internal_reduce_O_O__O(f__1, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(s__4)) } else { var tmp7 *lang.Var; A_arbace_core_protocols_A_Init(); tmp7 = A_arbace_core_protocols_A_const_11; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_core_protocols_A_Init(); tmp9 = A_arbace_core_protocols_A_const_13; return tmp8.Invoke_O_O_O__O(target_5, f__1, lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(s__4)) } } else {
			return lang.IFn_Cast(f__1).Invoke__O() } }





func A_arbace_core_protocols_iterator_reduce_BANG__A_New() *A_arbace_core_protocols_iterator_reduce_BANG__A { A_arbace_core_protocols_iterator_reduce_BANG__A_Init(); t := &A_arbace_core_protocols_iterator_reduce_BANG__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) Ctor() {}
//line :34:1
func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) Invoke_O_O_O_O__O(self, iter__0, f__1, val__2 any) any { { var ret__4 any = val__2; L1: for {






	if jrt.Iterator_Cast(iter__0).HasNext__Z() { var ret__5 any = lang.IFn_Cast(f__1).Invoke_O_O__O(ret__4, jrt.Iterator_Cast(iter__0).Next__O())

		if lang.RT_IsReduced_O__Z(ret__5) { var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_3; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(ret__5) } else {

			ret__4 = ret__5; continue L1 } } else {
//line :41:1
				return ret__4 } } }; /*line :34:1*/panic("a2g: unreachable") }
//line :34:1
func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) Invoke_O_O_O__O(self, iter__0, f__1 any) any {

	if jrt.Iterator_Cast(iter__0).HasNext__Z() {
		var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_14; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(iter__0, f__1, jrt.Iterator_Cast(iter__0).Next__O()) } else {
			return lang.IFn_Cast(f__1).Invoke__O()
		}
}







func A_arbace_core_protocols_iter_reduce_A_New() *A_arbace_core_protocols_iter_reduce_A { A_arbace_core_protocols_iter_reduce_A_Init(); t := &A_arbace_core_protocols_iter_reduce_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_core_protocols_iter_reduce_A) Ctor() {}
//line :48:1
func (t *A_arbace_core_protocols_iter_reduce_A) Invoke_O_O_O_O__O(self, coll__0, f__1, val__2 any) any {



	var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_14; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(jrt.Iterable_Cast(coll__0).Iterator__Iterator(), f__1, val__2) }
//line :48:1
func (t *A_arbace_core_protocols_iter_reduce_A) Invoke_O_O_O__O(self, coll__0, f__1 any) any {

	var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_14; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(jrt.Iterable_Cast(coll__0).Iterator__Iterator(), f__1)
}


func A_arbace_core_protocols_naive_seq_reduce_A_New() *A_arbace_core_protocols_naive_seq_reduce_A { A_arbace_core_protocols_naive_seq_reduce_A_Init(); t := &A_arbace_core_protocols_naive_seq_reduce_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_core_protocols_naive_seq_reduce_A) Ctor() {}
//line :54:1
func (t *A_arbace_core_protocols_naive_seq_reduce_A) Invoke_O_O_O_O__O(self, s__0, f__1, val__2 any) any { { var s__4 any; var tmp1 *lang.Var



	A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_10; s__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__0)
//line :54:1
	var val__5 any = val__2; L1: for {





		if jrt.A2g_Truth(s__4) { var ret__6 any; var tmp2 lang.IFn = lang.IFn_Cast(f__1); var tmp3 *lang.Var
			A_arbace_core_protocols_A_Init(); tmp3 = A_arbace_core_protocols_A_const_13; ret__6 = tmp2.Invoke_O_O__O(val__5, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__4))
			if lang.RT_IsReduced_O__Z(ret__6) { var tmp4 *lang.Var; A_arbace_core_protocols_A_Init(); tmp4 = A_arbace_core_protocols_A_const_3; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(ret__6) } else {

				var tmp5 *lang.Var; A_arbace_core_protocols_A_Init(); tmp5 = A_arbace_core_protocols_A_const_12; s__4, val__5 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(s__4), ret__6; continue L1 } } else {
//line :60:1
					return val__5 } } }; /*line :54:1*/panic("a2g: unreachable") }












func A_arbace_core_protocols_interface_or_naive_reduce_A_New() *A_arbace_core_protocols_interface_or_naive_reduce_A { A_arbace_core_protocols_interface_or_naive_reduce_A_Init(); t := &A_arbace_core_protocols_interface_or_naive_reduce_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_core_protocols_interface_or_naive_reduce_A) Ctor() {}
//line :67:1
func (t *A_arbace_core_protocols_interface_or_naive_reduce_A) Invoke_O_O_O_O__O(self, coll__0, f__1, val__2 any) any {


	if lang.IReduceInit_InstanceOf(coll__0) {
		return lang.IReduceInit_Cast(coll__0).Reduce_IFn_O__O(lang.IFn_Cast(f__1), val__2) } else {
			var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_15; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(coll__0, f__1, val__2)
		} }
func A_arbace_core_protocols_eval619000073_fn__619000074_A_New() *A_arbace_core_protocols_eval619000073_fn__619000074_A { A_arbace_core_protocols_eval619000073_fn__619000074_A_Init(); t := &A_arbace_core_protocols_eval619000073_fn__619000074_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any { return val__3 }
//line :74:1
func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {


	return lang.IFn_Cast(f__2).Invoke__O() }
//line :74:1
func A_arbace_core_protocols_eval619000077_fn__619000078_A_New() *A_arbace_core_protocols_eval619000077_fn__619000078_A { A_arbace_core_protocols_eval619000077_fn__619000078_A_Init(); t := &A_arbace_core_protocols_eval619000077_fn__619000078_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {








	var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_16; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(coll__1, f__2, val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {







	var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_16; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(coll__1, f__2) }
//line :74:1
func A_arbace_core_protocols_eval619000081_fn__619000082_A_New() *A_arbace_core_protocols_eval619000081_fn__619000082_A { A_arbace_core_protocols_eval619000081_fn__619000082_A_Init(); t := &A_arbace_core_protocols_eval619000081_fn__619000082_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {








































	var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_16; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(coll__1, f__2, val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {







































	var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_16; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(coll__1, f__2) }
//line :74:1
func A_arbace_core_protocols_eval619000085_fn__619000086_A_New() *A_arbace_core_protocols_eval619000085_fn__619000086_A { A_arbace_core_protocols_eval619000085_fn__619000086_A_Init(); t := &A_arbace_core_protocols_eval619000085_fn__619000086_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {













































	var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_17; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(coll__1, f__2, val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {












































	var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_17; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(coll__1, f__2) }
//line :74:1
func A_arbace_core_protocols_eval619000089_fn__619000090_A_New() *A_arbace_core_protocols_eval619000089_fn__619000090_A { A_arbace_core_protocols_eval619000089_fn__619000090_A_Init(); t := &A_arbace_core_protocols_eval619000089_fn__619000090_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {




























	var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_16; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(coll__1, f__2, val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {



























	var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_16; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(coll__1, f__2) }
//line :74:1
func A_arbace_core_protocols_eval619000093_fn__619000094_A_New() *A_arbace_core_protocols_eval619000093_fn__619000094_A { A_arbace_core_protocols_eval619000093_fn__619000094_A_Init(); t := &A_arbace_core_protocols_eval619000093_fn__619000094_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {






















	return lang.IReduceInit_Cast(coll__1).Reduce_IFn_O__O(lang.IFn_Cast(f__2), val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {













	if lang.IReduce_InstanceOf(coll__1) {
		return lang.IReduce_Cast(coll__1).Reduce_IFn__O(lang.IFn_Cast(f__2)) } else {
//line :88:1
			var none__3 any = jrt.Object_New(); var ret__4 any; var tmp1 lang.IReduceInit = lang.IReduceInit_Cast(coll__1); var tmp2 any = A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_New_O_O(f__2, none__3); var tmp3 *jrt.Class




			A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_Init(); tmp3 = A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_fn_class; ret__4 = tmp1.Reduce_IFn_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), none__3)


			if lang.Util_Identical_O_O__Z(ret__4, none__3) { return lang.IFn_Cast(f__2).Invoke__O() } else { return ret__4 } } }
//line :74:1
func A_arbace_core_protocols_eval619000099_fn__619000100_A_New() *A_arbace_core_protocols_eval619000099_fn__619000100_A { A_arbace_core_protocols_eval619000099_fn__619000100_A_Init(); t := &A_arbace_core_protocols_eval619000099_fn__619000100_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {


































	var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_16; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(coll__1, f__2, val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {

































	var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_16; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(coll__1, f__2) }
//line :74:1
func A_arbace_core_protocols_eval619000103_fn__619000104_A_New() *A_arbace_core_protocols_eval619000103_fn__619000104_A { A_arbace_core_protocols_eval619000103_fn__619000104_A_Init(); t := &A_arbace_core_protocols_eval619000103_fn__619000104_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {


















































	var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_17; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(coll__1, f__2, val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {

















































	var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_17; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(coll__1, f__2) }
//line :74:1
func A_arbace_core_protocols_eval619000107_fn__619000108_A_New() *A_arbace_core_protocols_eval619000107_fn__619000108_A { A_arbace_core_protocols_eval619000107_fn__619000108_A_Init(); t := &A_arbace_core_protocols_eval619000107_fn__619000108_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {























































	var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_17; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(coll__1, f__2, val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {






















































	var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_17; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(coll__1, f__2) }
//line :94:1
func A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_New_O_O(p0, p1 any) *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A { A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_Init(); t := &A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A{}; t.Ctor_O_O(p0, p1); return t }
//line :94:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A) Ctor_O_O(c__f, c__none any) { t.F_f = c__f; t.F_none = c__none }
//line :94:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A) Invoke_O_O_O__O(self, acc__1, x__2 any) any { if lang.Util_Identical_O_O__Z(acc__1, t.F_none) { return x__2 } else { return lang.IFn_Cast(t.F_f).Invoke_O_O__O(acc__1, x__2) } }





































func A_arbace_core_protocols_eval619000111_fn__619000112_A_New() *A_arbace_core_protocols_eval619000111_fn__619000112_A { A_arbace_core_protocols_eval619000111_fn__619000112_A_Init(); t := &A_arbace_core_protocols_eval619000111_fn__619000112_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_core_protocols_eval619000111_fn__619000112_A) Ctor() {}
//line :132:1
func (t *A_arbace_core_protocols_eval619000111_fn__619000112_A) Invoke_O_O_O_O__O(self, s__1, f__2, val__3 any) any { return val__3 }
//line :132:1
func A_arbace_core_protocols_eval619000115_fn__619000116_A_New() *A_arbace_core_protocols_eval619000115_fn__619000116_A { A_arbace_core_protocols_eval619000115_fn__619000116_A_Init(); t := &A_arbace_core_protocols_eval619000115_fn__619000116_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_core_protocols_eval619000115_fn__619000116_A) Ctor() {}
//line :132:1
func (t *A_arbace_core_protocols_eval619000115_fn__619000116_A) Invoke_O_O_O_O__O(self, s__1, f__2, val__3 any) any { { var s__1_2 any = s__1; var f__2_2 any = f__2; var val__3_2 any = val__3; L1: for { var temp__1927000408__auto____4 any; var tmp1 *lang.Var









	A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_10; temp__1927000408__auto____4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1_2); if jrt.A2g_Truth(temp__1927000408__auto____4) { var s__5 any = temp__1927000408__auto____4; var tmp2 *lang.Var
		A_arbace_core_protocols_A_Init(); tmp2 = A_arbace_core_protocols_A_const_18; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__5)) { var ret__6 any; var tmp3 *lang.Var
			A_arbace_core_protocols_A_Init(); tmp3 = A_arbace_core_protocols_A_const_19; ret__6 = lang.IChunk_Cast(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__5)).Reduce_IFn_O__O(lang.IFn_Cast(f__2_2), val__3_2)
			if lang.RT_IsReduced_O__Z(ret__6) { var tmp4 *lang.Var; A_arbace_core_protocols_A_Init(); tmp4 = A_arbace_core_protocols_A_const_3; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(ret__6) } else {

				var tmp5 *lang.Var; A_arbace_core_protocols_A_Init(); tmp5 = A_arbace_core_protocols_A_const_21; s__1_2, f__2_2, val__3_2 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(s__5), f__2_2, ret__6; continue L1 } } else {


					var tmp6 *lang.Var; A_arbace_core_protocols_A_Init(); tmp6 = A_arbace_core_protocols_A_const_20; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O_O__O(s__5, f__2_2, val__3_2) } } else {
//line :142:1
						return val__3_2 } } }; /*line :132:1*/panic("a2g: unreachable") }
//line :132:1
func A_arbace_core_protocols_eval619000119_fn__619000120_A_New() *A_arbace_core_protocols_eval619000119_fn__619000120_A { A_arbace_core_protocols_eval619000119_fn__619000120_A_Init(); t := &A_arbace_core_protocols_eval619000119_fn__619000120_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_core_protocols_eval619000119_fn__619000120_A) Ctor() {}
//line :132:1
func (t *A_arbace_core_protocols_eval619000119_fn__619000120_A) Invoke_O_O_O_O__O(self, str_seq__1, f__2, val__3 any) any { { var s__4 any = lang.StringSeq_Cast(str_seq__1).F_s; var len__5 int32 = jrt.CharSequence_Cast(s__4).Length__I(); var i__6 int64 = lang.RT_LongCast_I__J(lang.StringSeq_Cast(str_seq__1).F_i); var val__7 any = val__3; L1: for {



























	if lang.Numbers_Lt_J_J__Z(i__6, int64(len__5)) { var ret__8 any = lang.IFn_Cast(f__2).Invoke_O_O__O(val__7, jrt.Character_ValueOf_C__Character(jrt.CharSequence_Cast(s__4).CharAt_I__C(lang.RT_IntCast_J__I(i__6))).Ref())

		if lang.RT_IsReduced_O__Z(ret__8) { var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_3; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(ret__8) } else {

			i__6, val__7 = lang.Numbers_Inc_J__J(i__6), ret__8; continue L1 } } else {
//line :160:1
				return val__7 } } }; /*line :132:1*/panic("a2g: unreachable") }
//line :132:1
func A_arbace_core_protocols_eval619000123_fn__619000124_A_New() *A_arbace_core_protocols_eval619000123_fn__619000124_A { A_arbace_core_protocols_eval619000123_fn__619000124_A_Init(); t := &A_arbace_core_protocols_eval619000123_fn__619000124_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_core_protocols_eval619000123_fn__619000124_A) Ctor() {}
//line :132:1
func (t *A_arbace_core_protocols_eval619000123_fn__619000124_A) Invoke_O_O_O_O__O(self, s__1, f__2, val__3 any) any { { var cls__4 any; var tmp1 *lang.Var





































	A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_22; cls__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1)
//line :132:1
	var s__5 any = s__1; var f__6 any = f__2; var val__7 any = val__3; L1: for { var temp__1927000408__auto____8 any; var tmp2 *lang.Var









































		A_arbace_core_protocols_A_Init(); tmp2 = A_arbace_core_protocols_A_const_10; temp__1927000408__auto____8 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__5); if jrt.A2g_Truth(temp__1927000408__auto____8) { var s__9 any = temp__1927000408__auto____8; var tmp3 *lang.Var
			A_arbace_core_protocols_A_Init(); tmp3 = A_arbace_core_protocols_A_const_22; if lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__9), cls__4) { var ret__10 any; var tmp4 lang.IFn = lang.IFn_Cast(f__6); var tmp5 *lang.Var
				A_arbace_core_protocols_A_Init(); tmp5 = A_arbace_core_protocols_A_const_13; ret__10 = tmp4.Invoke_O_O__O(val__7, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(s__9))
				if lang.RT_IsReduced_O__Z(ret__10) { var tmp6 *lang.Var; A_arbace_core_protocols_A_Init(); tmp6 = A_arbace_core_protocols_A_const_3; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(ret__10) } else {

					var tmp7 *lang.Var; A_arbace_core_protocols_A_Init(); tmp7 = A_arbace_core_protocols_A_const_12; cls__4, s__5, f__6, val__7 = cls__4, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(s__9), f__6, ret__10; continue L1 } } else {
						var tmp8 *lang.Var; A_arbace_core_protocols_A_Init(); tmp8 = A_arbace_core_protocols_A_const_20; return lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O_O__O(s__9, f__6, val__7) } } else {
//line :174:1
							return val__7 } } }; /*line :132:1*/panic("a2g: unreachable") }


















































func A_arbace_core_protocols_eval619000135_fn__619000136_A_New() *A_arbace_core_protocols_eval619000135_fn__619000136_A { A_arbace_core_protocols_eval619000135_fn__619000136_A_Init(); t := &A_arbace_core_protocols_eval619000135_fn__619000136_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_A) Ctor() {}
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__619000128__2_ any; var tmp1 any = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_New(); var tmp2 *jrt.Class; A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_Init(); tmp2 = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_fn_class; G__619000128__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_New_O(G__619000128__2_); var tmp4 *jrt.Class; A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_Init(); tmp4 = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_fn_class; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :183:1
func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_New_O(p0 any) *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A { A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_Init(); t := &A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A{}; t.Ctor_O(p0); return t }
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A) Ctor_O(c__G__619000128 any) { t.F_G__619000128 = c__G__619000128 }
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A) Invoke_O_O_O_O__O(self, gf__amap__619000142__1, gf__f__619000143__2, gf__init__619000144__3 any) any { var cache__231000236__auto____4 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____5 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____4)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__amap__619000142__1)); if jrt.A2g_Truth(f__231000237__auto____5) { return lang.IFn_Cast(f__231000237__auto____5).Invoke_O_O_O__O(gf__amap__619000142__1, gf__f__619000143__2, gf__init__619000144__3) } else { var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_core_protocols_A_Init(); tmp3 = A_arbace_core_protocols_A_const_23; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__amap__619000142__1, tmp3.Ref(), t.F_G__619000128)).Invoke_O_O_O__O(gf__amap__619000142__1, gf__f__619000143__2, gf__init__619000144__3) } }
//line :183:1
func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_New() *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A { A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_Init(); t := &A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A) Ctor() {}
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A) Invoke_O_O_O_O__O(self, gf__amap__619000137__1, gf__f__619000138__2, gf__init__619000139__3 any) any { var target_6 any = gf__amap__619000137__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_6 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_6) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_6, Lit_53, jrt.RefArrayOf(jrt.Object_class, gf__f__619000138__2, gf__init__619000139__3)) } else { return A_arbace_core_protocols_IKVReduce_A_Cast(target_6).Kv_reduce_O_O__O(gf__f__619000138__2, gf__init__619000139__3) } }






func A_arbace_core_protocols_eval619000161_fn__619000162_A_New() *A_arbace_core_protocols_eval619000161_fn__619000162_A { A_arbace_core_protocols_eval619000161_fn__619000162_A_Init(); t := &A_arbace_core_protocols_eval619000161_fn__619000162_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_A) Ctor() {}
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__619000154__2_ any; var tmp1 any = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_New(); var tmp2 *jrt.Class; A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_Init(); tmp2 = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_fn_class; G__619000154__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_New_O(G__619000154__2_); var tmp4 *jrt.Class; A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_Init(); tmp4 = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_fn_class; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :190:1
func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_New_O(p0 any) *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A { A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_Init(); t := &A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A{}; t.Ctor_O(p0); return t }
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A) Ctor_O(c__G__619000154 any) { t.F_G__619000154 = c__G__619000154 }
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A) Invoke_O_O__O(self, gf__o__619000166__1 any) any { var cache__231000232__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000233__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000232__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__o__619000166__1)); if lang.Util_Identical_O_O__Z(f__231000233__auto____3, t.F_G__619000154) { return lang.IFn_Cast(f__231000233__auto____3).Invoke_O__O(gf__o__619000166__1) } else { var temp__1927000408__auto____4 any; var temp__1927000414__auto____4 any = lang.RT_Meta_O__IPersistentMap(gf__o__619000166__1); if jrt.A2g_Truth(temp__1927000414__auto____4) { var m__231000235__auto____5 any = temp__1927000414__auto____4; temp__1927000408__auto____4 = Up_Symbol_IFn(lang.MethodImplCache_Cast(cache__231000232__auto____2).F_sym).Invoke_O__O(m__231000235__auto____5) } else { temp__1927000408__auto____4 = nil }; if jrt.A2g_Truth(temp__1927000408__auto____4) { var meta__231000234__auto____5 any = temp__1927000408__auto____4; return lang.IFn_Cast(meta__231000234__auto____5).Invoke_O__O(gf__o__619000166__1) } else { if jrt.A2g_Truth(f__231000233__auto____3) { return lang.IFn_Cast(f__231000233__auto____3).Invoke_O__O(gf__o__619000166__1) } else { var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_core_protocols_A_Init(); tmp3 = A_arbace_core_protocols_A_const_24; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__o__619000166__1, tmp3.Ref(), t.F_G__619000154)).Invoke_O__O(gf__o__619000166__1) } } } }
//line :190:1
func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_New() *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A { A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_Init(); t := &A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A) Ctor() {}
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A) Invoke_O_O__O(self, gf__o__619000163__1 any) any { var target_7 any = gf__o__619000163__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_7 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_7) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_7, Lit_57, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_core_protocols_Datafiable_A_Cast(target_7).Datafy__O() } }




func A_arbace_core_protocols_eval619000175_fn__619000176_A_New() *A_arbace_core_protocols_eval619000175_fn__619000176_A { A_arbace_core_protocols_eval619000175_fn__619000176_A_Init(); t := &A_arbace_core_protocols_eval619000175_fn__619000176_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_core_protocols_eval619000175_fn__619000176_A) Ctor() {}
//line :195:1
func (t *A_arbace_core_protocols_eval619000175_fn__619000176_A) Invoke_O_O__O(self, ___1 any) any { return nil }
//line :195:1
func A_arbace_core_protocols_eval619000179_fn__619000180_A_New() *A_arbace_core_protocols_eval619000179_fn__619000180_A { A_arbace_core_protocols_eval619000179_fn__619000180_A_Init(); t := &A_arbace_core_protocols_eval619000179_fn__619000180_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_core_protocols_eval619000179_fn__619000180_A) Ctor() {}
//line :195:1
func (t *A_arbace_core_protocols_eval619000179_fn__619000180_A) Invoke_O_O__O(self, x__1 any) any { return x__1 }






func A_arbace_core_protocols_eval619000191_fn__619000192_A_New() *A_arbace_core_protocols_eval619000191_fn__619000192_A { A_arbace_core_protocols_eval619000191_fn__619000192_A_Init(); t := &A_arbace_core_protocols_eval619000191_fn__619000192_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_A) Ctor() {}
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__619000184__2_ any; var tmp1 any = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_New(); var tmp2 *jrt.Class; A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_Init(); tmp2 = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_fn_class; G__619000184__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_New_O(G__619000184__2_); var tmp4 *jrt.Class; A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_Init(); tmp4 = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_fn_class; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :202:1
func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_New_O(p0 any) *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A { A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_Init(); t := &A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A) Ctor_O(c__G__619000184 any) { t.F_G__619000184 = c__G__619000184 }
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A) Invoke_O_O_O_O__O(self, gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3 any) any { var cache__231000232__auto____4 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000233__auto____5 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000232__auto____4)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__coll__619000198__1)); if lang.Util_Identical_O_O__Z(f__231000233__auto____5, t.F_G__619000184) { return lang.IFn_Cast(f__231000233__auto____5).Invoke_O_O_O__O(gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3) } else { var temp__1927000408__auto____6 any; var temp__1927000414__auto____6 any = lang.RT_Meta_O__IPersistentMap(gf__coll__619000198__1); if jrt.A2g_Truth(temp__1927000414__auto____6) { var m__231000235__auto____7 any = temp__1927000414__auto____6; temp__1927000408__auto____6 = Up_Symbol_IFn(lang.MethodImplCache_Cast(cache__231000232__auto____4).F_sym).Invoke_O__O(m__231000235__auto____7) } else { temp__1927000408__auto____6 = nil }; if jrt.A2g_Truth(temp__1927000408__auto____6) { var meta__231000234__auto____7 any = temp__1927000408__auto____6; return lang.IFn_Cast(meta__231000234__auto____7).Invoke_O_O_O__O(gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3) } else { if jrt.A2g_Truth(f__231000233__auto____5) { return lang.IFn_Cast(f__231000233__auto____5).Invoke_O_O_O__O(gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3) } else { var tmp1 *lang.Var; A_arbace_core_protocols_A_Init(); tmp1 = A_arbace_core_protocols_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_core_protocols_A_Init(); tmp3 = A_arbace_core_protocols_A_const_25; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__coll__619000198__1, tmp3.Ref(), t.F_G__619000184)).Invoke_O_O_O__O(gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3) } } } }
//line :202:1
func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_New() *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A { A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_Init(); t := &A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A) Ctor() {}
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A) Invoke_O_O_O_O__O(self, gf__coll__619000193__1, gf__k__619000194__2, gf__v__619000195__3 any) any { var target_8 any = gf__coll__619000193__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_8 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_8) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_8, Lit_63, jrt.RefArrayOf(jrt.Object_class, gf__k__619000194__2, gf__v__619000195__3)) } else { return A_arbace_core_protocols_Navigable_A_Cast(target_8).Nav_O_O__O(gf__k__619000194__2, gf__v__619000195__3) } }





func A_arbace_core_protocols_eval619000209_fn__619000210_A_New() *A_arbace_core_protocols_eval619000209_fn__619000210_A { A_arbace_core_protocols_eval619000209_fn__619000210_A_Init(); t := &A_arbace_core_protocols_eval619000209_fn__619000210_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_core_protocols_eval619000209_fn__619000210_A) Ctor() {}
//line :208:1
func (t *A_arbace_core_protocols_eval619000209_fn__619000210_A) Invoke_O_O_O_O__O(self, ___1, ___2, x__3 any) any { return x__3 }
































































type A_arbace_core_protocols_A struct{ jrt.Object }

var A_arbace_core_protocols_A_const_0 *lang.Var

var A_arbace_core_protocols_A_const_1 any

var A_arbace_core_protocols_A_const_2 *lang.Var

var A_arbace_core_protocols_A_const_3 *lang.Var

var A_arbace_core_protocols_A_const_4 *lang.Var

var A_arbace_core_protocols_A_const_5 any

var A_arbace_core_protocols_A_const_6 *lang.Var

var A_arbace_core_protocols_A_const_7 *lang.Var

var A_arbace_core_protocols_A_const_8 *jrt.Class

var A_arbace_core_protocols_A_const_9 *jrt.Class

var A_arbace_core_protocols_A_const_10 *lang.Var

var A_arbace_core_protocols_A_const_11 *lang.Var

var A_arbace_core_protocols_A_const_12 *lang.Var

var A_arbace_core_protocols_A_const_13 *lang.Var

var A_arbace_core_protocols_A_const_14 *lang.Var

var A_arbace_core_protocols_A_const_15 *lang.Var

var A_arbace_core_protocols_A_const_16 *lang.Var

var A_arbace_core_protocols_A_const_17 *lang.Var

var A_arbace_core_protocols_A_const_18 *lang.Var

var A_arbace_core_protocols_A_const_19 *lang.Var

var A_arbace_core_protocols_A_const_20 *lang.Var

var A_arbace_core_protocols_A_const_21 *lang.Var

var A_arbace_core_protocols_A_const_22 *lang.Var

var A_arbace_core_protocols_A_const_23 *jrt.Class

var A_arbace_core_protocols_A_const_24 *jrt.Class

var A_arbace_core_protocols_A_const_25 *jrt.Class

var A_arbace_core_protocols_A_init jrt.ClassInit

func A_arbace_core_protocols_A_Init() { if !A_arbace_core_protocols_A_init.Done() { A_arbace_core_protocols_A_init.Run(A_arbace_core_protocols_A_clinit) } }

func A_arbace_core_protocols_A_clinit() { A_arbace_core_protocols_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_core_protocols_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_core_protocols_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_core_protocols_A_const_3 = lang.RT_Var_String_String__Var(Lit_0, Lit_3); A_arbace_core_protocols_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_4); A_arbace_core_protocols_A_const_5 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref(); A_arbace_core_protocols_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_6); A_arbace_core_protocols_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_core_protocols_A_const_8 = lang.RT_ClassForNameNonLoading_String__Class(Lit_8); A_arbace_core_protocols_A_const_9 = lang.RT_ClassForNameNonLoading_String__Class(Lit_9); A_arbace_core_protocols_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_core_protocols_A_const_11 = lang.RT_Var_String_String__Var(Lit_5, Lit_11); A_arbace_core_protocols_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_core_protocols_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_core_protocols_A_const_14 = lang.RT_Var_String_String__Var(Lit_5, Lit_14); A_arbace_core_protocols_A_const_15 = lang.RT_Var_String_String__Var(Lit_5, Lit_15); A_arbace_core_protocols_A_const_16 = lang.RT_Var_String_String__Var(Lit_5, Lit_16); A_arbace_core_protocols_A_const_17 = lang.RT_Var_String_String__Var(Lit_5, Lit_17); A_arbace_core_protocols_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_core_protocols_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_core_protocols_A_const_20 = lang.RT_Var_String_String__Var(Lit_5, Lit_20); A_arbace_core_protocols_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_core_protocols_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_core_protocols_A_const_23 = lang.RT_ClassForNameNonLoading_String__Class(Lit_23); A_arbace_core_protocols_A_const_24 = lang.RT_ClassForNameNonLoading_String__Class(Lit_24); A_arbace_core_protocols_A_const_25 = lang.RT_ClassForNameNonLoading_String__Class(Lit_25) }

func A_arbace_core_protocols_A_New() *A_arbace_core_protocols_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_A) Ctor() {}

func (t *A_arbace_core_protocols_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_A_class }

func (t *A_arbace_core_protocols_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_A); return ok }

func A_arbace_core_protocols_A_Cast(x any) *A_arbace_core_protocols_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_A_class)) }; return v }



type A_arbace_core_protocols_eval619000002_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000002_A_New() *A_arbace_core_protocols_eval619000002_A { t := &A_arbace_core_protocols_eval619000002_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000002_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000002_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000002_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000002_A_class }

func (t *A_arbace_core_protocols_eval619000002_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000002_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000002_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000002_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000002_A); return ok }

func A_arbace_core_protocols_eval619000002_A_Cast(x any) *A_arbace_core_protocols_eval619000002_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000002_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000002_A_class)) }; return v }



type A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A) Is_Compiler_AOTF0() {}

var A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_Init() { if !A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_init.Done() { A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_init.Run(A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_clinit) } }

func A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_clinit() { A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_26, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_class }

func (t *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A); return ok }

func A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_Cast(x any) *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_class)) }; return v }



type A_arbace_core_protocols_eval619000006_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000006_A_New() *A_arbace_core_protocols_eval619000006_A { t := &A_arbace_core_protocols_eval619000006_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000006_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000006_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000006_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000006_A_class }

func (t *A_arbace_core_protocols_eval619000006_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000006_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000006_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000006_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000006_A); return ok }

func A_arbace_core_protocols_eval619000006_A_Cast(x any) *A_arbace_core_protocols_eval619000006_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000006_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000006_A_class)) }; return v }



type A_arbace_core_protocols_eval619000006_fn__619000007_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000006_fn__619000007_A) Is_Compiler_AOTF0() {}

var A_arbace_core_protocols_eval619000006_fn__619000007_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000006_fn__619000007_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000006_fn__619000007_A_Init() { if !A_arbace_core_protocols_eval619000006_fn__619000007_A_init.Done() { A_arbace_core_protocols_eval619000006_fn__619000007_A_init.Run(A_arbace_core_protocols_eval619000006_fn__619000007_A_clinit) } }

func A_arbace_core_protocols_eval619000006_fn__619000007_A_clinit() { A_arbace_core_protocols_eval619000006_fn__619000007_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_27, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000006_fn__619000007_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000006_fn__619000007_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000006_fn__619000007_A_class }

func (t *A_arbace_core_protocols_eval619000006_fn__619000007_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000006_fn__619000007_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000006_fn__619000007_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000006_fn__619000007_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000006_fn__619000007_A); return ok }

func A_arbace_core_protocols_eval619000006_fn__619000007_A_Cast(x any) *A_arbace_core_protocols_eval619000006_fn__619000007_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000006_fn__619000007_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000006_fn__619000007_A_class)) }; return v }



type A_arbace_core_protocols_eval619000020_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000020_A_New() *A_arbace_core_protocols_eval619000020_A { t := &A_arbace_core_protocols_eval619000020_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000020_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000020_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000020_A_class }

func (t *A_arbace_core_protocols_eval619000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000020_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000020_A); return ok }

func A_arbace_core_protocols_eval619000020_A_Cast(x any) *A_arbace_core_protocols_eval619000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000020_A_class)) }; return v }



type A_arbace_core_protocols_eval619000020_fn__619000021_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_A) Is_Compiler_AOTF1() {}

var A_arbace_core_protocols_eval619000020_fn__619000021_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000020_fn__619000021_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000020_fn__619000021_A_Init() { if !A_arbace_core_protocols_eval619000020_fn__619000021_A_init.Done() { A_arbace_core_protocols_eval619000020_fn__619000021_A_init.Run(A_arbace_core_protocols_eval619000020_fn__619000021_A_clinit) } }

func A_arbace_core_protocols_eval619000020_fn__619000021_A_clinit() { A_arbace_core_protocols_eval619000020_fn__619000021_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_28, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000020_fn__619000021_A_class }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000020_fn__619000021_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000020_fn__619000021_A); return ok }

func A_arbace_core_protocols_eval619000020_fn__619000021_A_Cast(x any) *A_arbace_core_protocols_eval619000020_fn__619000021_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000020_fn__619000021_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000020_fn__619000021_A_class)) }; return v }



type A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A struct{ jrt.Object; F_G__619000013 any }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) Is_Compiler_AOTF2() {}

var A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_Init() { if !A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_init.Done() { A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_init.Run(A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_clinit) } }

func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_clinit() { A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_29, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_class }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A); return ok }

func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_Cast(x any) *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_class)) }; return v }



type A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) Is_Compiler_AOTF2() {}

var A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_Init() { if !A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_init.Done() { A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_init.Run(A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_clinit) } }

func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_clinit() { A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_30, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_class }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A); return ok }

func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_Cast(x any) *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_class)) }; return v }



type A_arbace_core_protocols_eval619000050_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000050_A_New() *A_arbace_core_protocols_eval619000050_A { t := &A_arbace_core_protocols_eval619000050_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000050_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000050_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000050_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000050_A_class }

func (t *A_arbace_core_protocols_eval619000050_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000050_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000050_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000050_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000050_A); return ok }

func A_arbace_core_protocols_eval619000050_A_Cast(x any) *A_arbace_core_protocols_eval619000050_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000050_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000050_A_class)) }; return v }



type A_arbace_core_protocols_eval619000050_fn__619000051_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_A) Is_Compiler_AOTF1() {}

var A_arbace_core_protocols_eval619000050_fn__619000051_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000050_fn__619000051_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000050_fn__619000051_A_Init() { if !A_arbace_core_protocols_eval619000050_fn__619000051_A_init.Done() { A_arbace_core_protocols_eval619000050_fn__619000051_A_init.Run(A_arbace_core_protocols_eval619000050_fn__619000051_A_clinit) } }

func A_arbace_core_protocols_eval619000050_fn__619000051_A_clinit() { A_arbace_core_protocols_eval619000050_fn__619000051_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_32, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000050_fn__619000051_A_class }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000050_fn__619000051_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000050_fn__619000051_A); return ok }

func A_arbace_core_protocols_eval619000050_fn__619000051_A_Cast(x any) *A_arbace_core_protocols_eval619000050_fn__619000051_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000050_fn__619000051_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000050_fn__619000051_A_class)) }; return v }



type A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A struct{ jrt.Object; F_G__619000043 any }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A) Is_Compiler_AOTF3() {}

var A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_Init() { if !A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_init.Done() { A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_init.Run(A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_clinit) } }

func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_clinit() { A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_33, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_class }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A); return ok }

func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_Cast(x any) *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_class)) }; return v }



type A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A) Is_Compiler_AOTF3() {}

var A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_Init() { if !A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_init.Done() { A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_init.Run(A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_clinit) } }

func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_clinit() { A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_34, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_class }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A); return ok }

func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_Cast(x any) *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_class)) }; return v }



type A_arbace_core_protocols_eval619000073_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000073_A_New() *A_arbace_core_protocols_eval619000073_A { t := &A_arbace_core_protocols_eval619000073_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000073_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000073_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000073_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000073_A_class }

func (t *A_arbace_core_protocols_eval619000073_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000073_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000073_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000073_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000073_A); return ok }

func A_arbace_core_protocols_eval619000073_A_Cast(x any) *A_arbace_core_protocols_eval619000073_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000073_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000073_A_class)) }; return v }



type A_arbace_core_protocols_eval619000073_fn__619000074_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) Is_Compiler_AOTF2() {}

var A_arbace_core_protocols_eval619000073_fn__619000074_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000073_fn__619000074_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000073_fn__619000074_A_Init() { if !A_arbace_core_protocols_eval619000073_fn__619000074_A_init.Done() { A_arbace_core_protocols_eval619000073_fn__619000074_A_init.Run(A_arbace_core_protocols_eval619000073_fn__619000074_A_clinit) } }

func A_arbace_core_protocols_eval619000073_fn__619000074_A_clinit() { A_arbace_core_protocols_eval619000073_fn__619000074_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_36, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000073_fn__619000074_A_class }

func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000073_fn__619000074_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000073_fn__619000074_A); return ok }

func A_arbace_core_protocols_eval619000073_fn__619000074_A_Cast(x any) *A_arbace_core_protocols_eval619000073_fn__619000074_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000073_fn__619000074_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000073_fn__619000074_A_class)) }; return v }



type A_arbace_core_protocols_eval619000077_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000077_A_New() *A_arbace_core_protocols_eval619000077_A { t := &A_arbace_core_protocols_eval619000077_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000077_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000077_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000077_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000077_A_class }

func (t *A_arbace_core_protocols_eval619000077_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000077_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000077_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000077_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000077_A); return ok }

func A_arbace_core_protocols_eval619000077_A_Cast(x any) *A_arbace_core_protocols_eval619000077_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000077_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000077_A_class)) }; return v }



type A_arbace_core_protocols_eval619000077_fn__619000078_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) Is_Compiler_AOTF2() {}

var A_arbace_core_protocols_eval619000077_fn__619000078_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000077_fn__619000078_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000077_fn__619000078_A_Init() { if !A_arbace_core_protocols_eval619000077_fn__619000078_A_init.Done() { A_arbace_core_protocols_eval619000077_fn__619000078_A_init.Run(A_arbace_core_protocols_eval619000077_fn__619000078_A_clinit) } }

func A_arbace_core_protocols_eval619000077_fn__619000078_A_clinit() { A_arbace_core_protocols_eval619000077_fn__619000078_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_37, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000077_fn__619000078_A_class }

func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000077_fn__619000078_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000077_fn__619000078_A); return ok }

func A_arbace_core_protocols_eval619000077_fn__619000078_A_Cast(x any) *A_arbace_core_protocols_eval619000077_fn__619000078_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000077_fn__619000078_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000077_fn__619000078_A_class)) }; return v }



type A_arbace_core_protocols_eval619000081_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000081_A_New() *A_arbace_core_protocols_eval619000081_A { t := &A_arbace_core_protocols_eval619000081_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000081_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000081_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000081_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000081_A_class }

func (t *A_arbace_core_protocols_eval619000081_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000081_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000081_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000081_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000081_A); return ok }

func A_arbace_core_protocols_eval619000081_A_Cast(x any) *A_arbace_core_protocols_eval619000081_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000081_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000081_A_class)) }; return v }



type A_arbace_core_protocols_eval619000081_fn__619000082_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) Is_Compiler_AOTF2() {}

var A_arbace_core_protocols_eval619000081_fn__619000082_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000081_fn__619000082_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000081_fn__619000082_A_Init() { if !A_arbace_core_protocols_eval619000081_fn__619000082_A_init.Done() { A_arbace_core_protocols_eval619000081_fn__619000082_A_init.Run(A_arbace_core_protocols_eval619000081_fn__619000082_A_clinit) } }

func A_arbace_core_protocols_eval619000081_fn__619000082_A_clinit() { A_arbace_core_protocols_eval619000081_fn__619000082_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_38, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000081_fn__619000082_A_class }

func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000081_fn__619000082_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000081_fn__619000082_A); return ok }

func A_arbace_core_protocols_eval619000081_fn__619000082_A_Cast(x any) *A_arbace_core_protocols_eval619000081_fn__619000082_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000081_fn__619000082_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000081_fn__619000082_A_class)) }; return v }



type A_arbace_core_protocols_eval619000085_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000085_A_New() *A_arbace_core_protocols_eval619000085_A { t := &A_arbace_core_protocols_eval619000085_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000085_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000085_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000085_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000085_A_class }

func (t *A_arbace_core_protocols_eval619000085_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000085_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000085_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000085_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000085_A); return ok }

func A_arbace_core_protocols_eval619000085_A_Cast(x any) *A_arbace_core_protocols_eval619000085_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000085_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000085_A_class)) }; return v }



type A_arbace_core_protocols_eval619000085_fn__619000086_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) Is_Compiler_AOTF2() {}

var A_arbace_core_protocols_eval619000085_fn__619000086_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000085_fn__619000086_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000085_fn__619000086_A_Init() { if !A_arbace_core_protocols_eval619000085_fn__619000086_A_init.Done() { A_arbace_core_protocols_eval619000085_fn__619000086_A_init.Run(A_arbace_core_protocols_eval619000085_fn__619000086_A_clinit) } }

func A_arbace_core_protocols_eval619000085_fn__619000086_A_clinit() { A_arbace_core_protocols_eval619000085_fn__619000086_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_39, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000085_fn__619000086_A_class }

func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000085_fn__619000086_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000085_fn__619000086_A); return ok }

func A_arbace_core_protocols_eval619000085_fn__619000086_A_Cast(x any) *A_arbace_core_protocols_eval619000085_fn__619000086_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000085_fn__619000086_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000085_fn__619000086_A_class)) }; return v }



type A_arbace_core_protocols_eval619000089_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000089_A_New() *A_arbace_core_protocols_eval619000089_A { t := &A_arbace_core_protocols_eval619000089_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000089_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000089_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000089_A_class }

func (t *A_arbace_core_protocols_eval619000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000089_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000089_A); return ok }

func A_arbace_core_protocols_eval619000089_A_Cast(x any) *A_arbace_core_protocols_eval619000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000089_A_class)) }; return v }



type A_arbace_core_protocols_eval619000089_fn__619000090_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) Is_Compiler_AOTF2() {}

var A_arbace_core_protocols_eval619000089_fn__619000090_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000089_fn__619000090_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000089_fn__619000090_A_Init() { if !A_arbace_core_protocols_eval619000089_fn__619000090_A_init.Done() { A_arbace_core_protocols_eval619000089_fn__619000090_A_init.Run(A_arbace_core_protocols_eval619000089_fn__619000090_A_clinit) } }

func A_arbace_core_protocols_eval619000089_fn__619000090_A_clinit() { A_arbace_core_protocols_eval619000089_fn__619000090_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_40, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000089_fn__619000090_A_class }

func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000089_fn__619000090_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000089_fn__619000090_A); return ok }

func A_arbace_core_protocols_eval619000089_fn__619000090_A_Cast(x any) *A_arbace_core_protocols_eval619000089_fn__619000090_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000089_fn__619000090_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000089_fn__619000090_A_class)) }; return v }



type A_arbace_core_protocols_eval619000093_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000093_A_New() *A_arbace_core_protocols_eval619000093_A { t := &A_arbace_core_protocols_eval619000093_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000093_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000093_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000093_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000093_A_class }

func (t *A_arbace_core_protocols_eval619000093_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000093_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000093_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000093_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000093_A); return ok }

func A_arbace_core_protocols_eval619000093_A_Cast(x any) *A_arbace_core_protocols_eval619000093_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000093_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000093_A_class)) }; return v }



type A_arbace_core_protocols_eval619000093_fn__619000094_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) Is_Compiler_AOTF2() {}

var A_arbace_core_protocols_eval619000093_fn__619000094_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000093_fn__619000094_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000093_fn__619000094_A_Init() { if !A_arbace_core_protocols_eval619000093_fn__619000094_A_init.Done() { A_arbace_core_protocols_eval619000093_fn__619000094_A_init.Run(A_arbace_core_protocols_eval619000093_fn__619000094_A_clinit) } }

func A_arbace_core_protocols_eval619000093_fn__619000094_A_clinit() { A_arbace_core_protocols_eval619000093_fn__619000094_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_41, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000093_fn__619000094_A_class }

func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000093_fn__619000094_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000093_fn__619000094_A); return ok }

func A_arbace_core_protocols_eval619000093_fn__619000094_A_Cast(x any) *A_arbace_core_protocols_eval619000093_fn__619000094_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000093_fn__619000094_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000093_fn__619000094_A_class)) }; return v }



type A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A struct{ jrt.Object; F_f, F_none any }

func (t *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A) Is_Compiler_AOTF2() {}

var A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_Init() { if !A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_init.Done() { A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_init.Run(A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_clinit) } }

func A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_clinit() { A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_42, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_class }

func (t *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A); return ok }

func A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_Cast(x any) *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_class)) }; return v }



type A_arbace_core_protocols_eval619000099_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000099_A_New() *A_arbace_core_protocols_eval619000099_A { t := &A_arbace_core_protocols_eval619000099_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000099_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000099_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000099_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000099_A_class }

func (t *A_arbace_core_protocols_eval619000099_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000099_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000099_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000099_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000099_A); return ok }

func A_arbace_core_protocols_eval619000099_A_Cast(x any) *A_arbace_core_protocols_eval619000099_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000099_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000099_A_class)) }; return v }



type A_arbace_core_protocols_eval619000099_fn__619000100_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) Is_Compiler_AOTF2() {}

var A_arbace_core_protocols_eval619000099_fn__619000100_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000099_fn__619000100_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000099_fn__619000100_A_Init() { if !A_arbace_core_protocols_eval619000099_fn__619000100_A_init.Done() { A_arbace_core_protocols_eval619000099_fn__619000100_A_init.Run(A_arbace_core_protocols_eval619000099_fn__619000100_A_clinit) } }

func A_arbace_core_protocols_eval619000099_fn__619000100_A_clinit() { A_arbace_core_protocols_eval619000099_fn__619000100_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_43, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000099_fn__619000100_A_class }

func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000099_fn__619000100_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000099_fn__619000100_A); return ok }

func A_arbace_core_protocols_eval619000099_fn__619000100_A_Cast(x any) *A_arbace_core_protocols_eval619000099_fn__619000100_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000099_fn__619000100_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000099_fn__619000100_A_class)) }; return v }



type A_arbace_core_protocols_eval619000103_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000103_A_New() *A_arbace_core_protocols_eval619000103_A { t := &A_arbace_core_protocols_eval619000103_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000103_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000103_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000103_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000103_A_class }

func (t *A_arbace_core_protocols_eval619000103_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000103_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000103_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000103_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000103_A); return ok }

func A_arbace_core_protocols_eval619000103_A_Cast(x any) *A_arbace_core_protocols_eval619000103_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000103_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000103_A_class)) }; return v }



type A_arbace_core_protocols_eval619000103_fn__619000104_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) Is_Compiler_AOTF2() {}

var A_arbace_core_protocols_eval619000103_fn__619000104_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000103_fn__619000104_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000103_fn__619000104_A_Init() { if !A_arbace_core_protocols_eval619000103_fn__619000104_A_init.Done() { A_arbace_core_protocols_eval619000103_fn__619000104_A_init.Run(A_arbace_core_protocols_eval619000103_fn__619000104_A_clinit) } }

func A_arbace_core_protocols_eval619000103_fn__619000104_A_clinit() { A_arbace_core_protocols_eval619000103_fn__619000104_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_44, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000103_fn__619000104_A_class }

func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000103_fn__619000104_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000103_fn__619000104_A); return ok }

func A_arbace_core_protocols_eval619000103_fn__619000104_A_Cast(x any) *A_arbace_core_protocols_eval619000103_fn__619000104_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000103_fn__619000104_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000103_fn__619000104_A_class)) }; return v }



type A_arbace_core_protocols_eval619000107_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000107_A_New() *A_arbace_core_protocols_eval619000107_A { t := &A_arbace_core_protocols_eval619000107_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000107_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000107_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000107_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000107_A_class }

func (t *A_arbace_core_protocols_eval619000107_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000107_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000107_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000107_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000107_A); return ok }

func A_arbace_core_protocols_eval619000107_A_Cast(x any) *A_arbace_core_protocols_eval619000107_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000107_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000107_A_class)) }; return v }



type A_arbace_core_protocols_eval619000107_fn__619000108_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) Is_Compiler_AOTF2() {}

var A_arbace_core_protocols_eval619000107_fn__619000108_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000107_fn__619000108_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000107_fn__619000108_A_Init() { if !A_arbace_core_protocols_eval619000107_fn__619000108_A_init.Done() { A_arbace_core_protocols_eval619000107_fn__619000108_A_init.Run(A_arbace_core_protocols_eval619000107_fn__619000108_A_clinit) } }

func A_arbace_core_protocols_eval619000107_fn__619000108_A_clinit() { A_arbace_core_protocols_eval619000107_fn__619000108_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_45, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000107_fn__619000108_A_class }

func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000107_fn__619000108_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000107_fn__619000108_A); return ok }

func A_arbace_core_protocols_eval619000107_fn__619000108_A_Cast(x any) *A_arbace_core_protocols_eval619000107_fn__619000108_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000107_fn__619000108_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000107_fn__619000108_A_class)) }; return v }



type A_arbace_core_protocols_eval619000111_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000111_A_New() *A_arbace_core_protocols_eval619000111_A { t := &A_arbace_core_protocols_eval619000111_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000111_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000111_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000111_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000111_A_class }

func (t *A_arbace_core_protocols_eval619000111_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000111_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000111_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000111_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000111_A); return ok }

func A_arbace_core_protocols_eval619000111_A_Cast(x any) *A_arbace_core_protocols_eval619000111_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000111_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000111_A_class)) }; return v }



type A_arbace_core_protocols_eval619000111_fn__619000112_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000111_fn__619000112_A) Is_Compiler_AOTF3() {}

var A_arbace_core_protocols_eval619000111_fn__619000112_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000111_fn__619000112_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000111_fn__619000112_A_Init() { if !A_arbace_core_protocols_eval619000111_fn__619000112_A_init.Done() { A_arbace_core_protocols_eval619000111_fn__619000112_A_init.Run(A_arbace_core_protocols_eval619000111_fn__619000112_A_clinit) } }

func A_arbace_core_protocols_eval619000111_fn__619000112_A_clinit() { A_arbace_core_protocols_eval619000111_fn__619000112_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_46, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000111_fn__619000112_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000111_fn__619000112_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000111_fn__619000112_A_class }

func (t *A_arbace_core_protocols_eval619000111_fn__619000112_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000111_fn__619000112_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000111_fn__619000112_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000111_fn__619000112_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000111_fn__619000112_A); return ok }

func A_arbace_core_protocols_eval619000111_fn__619000112_A_Cast(x any) *A_arbace_core_protocols_eval619000111_fn__619000112_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000111_fn__619000112_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000111_fn__619000112_A_class)) }; return v }



type A_arbace_core_protocols_eval619000115_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000115_A_New() *A_arbace_core_protocols_eval619000115_A { t := &A_arbace_core_protocols_eval619000115_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000115_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000115_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000115_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000115_A_class }

func (t *A_arbace_core_protocols_eval619000115_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000115_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000115_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000115_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000115_A); return ok }

func A_arbace_core_protocols_eval619000115_A_Cast(x any) *A_arbace_core_protocols_eval619000115_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000115_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000115_A_class)) }; return v }



type A_arbace_core_protocols_eval619000115_fn__619000116_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000115_fn__619000116_A) Is_Compiler_AOTF3() {}

var A_arbace_core_protocols_eval619000115_fn__619000116_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000115_fn__619000116_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000115_fn__619000116_A_Init() { if !A_arbace_core_protocols_eval619000115_fn__619000116_A_init.Done() { A_arbace_core_protocols_eval619000115_fn__619000116_A_init.Run(A_arbace_core_protocols_eval619000115_fn__619000116_A_clinit) } }

func A_arbace_core_protocols_eval619000115_fn__619000116_A_clinit() { A_arbace_core_protocols_eval619000115_fn__619000116_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_47, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000115_fn__619000116_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000115_fn__619000116_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000115_fn__619000116_A_class }

func (t *A_arbace_core_protocols_eval619000115_fn__619000116_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000115_fn__619000116_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000115_fn__619000116_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000115_fn__619000116_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000115_fn__619000116_A); return ok }

func A_arbace_core_protocols_eval619000115_fn__619000116_A_Cast(x any) *A_arbace_core_protocols_eval619000115_fn__619000116_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000115_fn__619000116_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000115_fn__619000116_A_class)) }; return v }



type A_arbace_core_protocols_eval619000119_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000119_A_New() *A_arbace_core_protocols_eval619000119_A { t := &A_arbace_core_protocols_eval619000119_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000119_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000119_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000119_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000119_A_class }

func (t *A_arbace_core_protocols_eval619000119_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000119_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000119_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000119_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000119_A); return ok }

func A_arbace_core_protocols_eval619000119_A_Cast(x any) *A_arbace_core_protocols_eval619000119_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000119_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000119_A_class)) }; return v }



type A_arbace_core_protocols_eval619000119_fn__619000120_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000119_fn__619000120_A) Is_Compiler_AOTF3() {}

var A_arbace_core_protocols_eval619000119_fn__619000120_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000119_fn__619000120_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000119_fn__619000120_A_Init() { if !A_arbace_core_protocols_eval619000119_fn__619000120_A_init.Done() { A_arbace_core_protocols_eval619000119_fn__619000120_A_init.Run(A_arbace_core_protocols_eval619000119_fn__619000120_A_clinit) } }

func A_arbace_core_protocols_eval619000119_fn__619000120_A_clinit() { A_arbace_core_protocols_eval619000119_fn__619000120_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_48, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000119_fn__619000120_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000119_fn__619000120_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000119_fn__619000120_A_class }

func (t *A_arbace_core_protocols_eval619000119_fn__619000120_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000119_fn__619000120_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000119_fn__619000120_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000119_fn__619000120_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000119_fn__619000120_A); return ok }

func A_arbace_core_protocols_eval619000119_fn__619000120_A_Cast(x any) *A_arbace_core_protocols_eval619000119_fn__619000120_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000119_fn__619000120_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000119_fn__619000120_A_class)) }; return v }



type A_arbace_core_protocols_eval619000123_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000123_A_New() *A_arbace_core_protocols_eval619000123_A { t := &A_arbace_core_protocols_eval619000123_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000123_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000123_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000123_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000123_A_class }

func (t *A_arbace_core_protocols_eval619000123_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000123_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000123_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000123_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000123_A); return ok }

func A_arbace_core_protocols_eval619000123_A_Cast(x any) *A_arbace_core_protocols_eval619000123_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000123_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000123_A_class)) }; return v }



type A_arbace_core_protocols_eval619000123_fn__619000124_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000123_fn__619000124_A) Is_Compiler_AOTF3() {}

var A_arbace_core_protocols_eval619000123_fn__619000124_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000123_fn__619000124_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000123_fn__619000124_A_Init() { if !A_arbace_core_protocols_eval619000123_fn__619000124_A_init.Done() { A_arbace_core_protocols_eval619000123_fn__619000124_A_init.Run(A_arbace_core_protocols_eval619000123_fn__619000124_A_clinit) } }

func A_arbace_core_protocols_eval619000123_fn__619000124_A_clinit() { A_arbace_core_protocols_eval619000123_fn__619000124_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_49, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000123_fn__619000124_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000123_fn__619000124_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000123_fn__619000124_A_class }

func (t *A_arbace_core_protocols_eval619000123_fn__619000124_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000123_fn__619000124_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000123_fn__619000124_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000123_fn__619000124_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000123_fn__619000124_A); return ok }

func A_arbace_core_protocols_eval619000123_fn__619000124_A_Cast(x any) *A_arbace_core_protocols_eval619000123_fn__619000124_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000123_fn__619000124_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000123_fn__619000124_A_class)) }; return v }



type A_arbace_core_protocols_eval619000135_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000135_A_New() *A_arbace_core_protocols_eval619000135_A { t := &A_arbace_core_protocols_eval619000135_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000135_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000135_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000135_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000135_A_class }

func (t *A_arbace_core_protocols_eval619000135_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000135_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000135_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000135_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000135_A); return ok }

func A_arbace_core_protocols_eval619000135_A_Cast(x any) *A_arbace_core_protocols_eval619000135_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000135_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000135_A_class)) }; return v }



type A_arbace_core_protocols_eval619000135_fn__619000136_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_A) Is_Compiler_AOTF1() {}

var A_arbace_core_protocols_eval619000135_fn__619000136_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000135_fn__619000136_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000135_fn__619000136_A_Init() { if !A_arbace_core_protocols_eval619000135_fn__619000136_A_init.Done() { A_arbace_core_protocols_eval619000135_fn__619000136_A_init.Run(A_arbace_core_protocols_eval619000135_fn__619000136_A_clinit) } }

func A_arbace_core_protocols_eval619000135_fn__619000136_A_clinit() { A_arbace_core_protocols_eval619000135_fn__619000136_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_50, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000135_fn__619000136_A_class }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000135_fn__619000136_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000135_fn__619000136_A); return ok }

func A_arbace_core_protocols_eval619000135_fn__619000136_A_Cast(x any) *A_arbace_core_protocols_eval619000135_fn__619000136_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000135_fn__619000136_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000135_fn__619000136_A_class)) }; return v }



type A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A struct{ jrt.Object; F_G__619000128 any }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A) Is_Compiler_AOTF3() {}

var A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_Init() { if !A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_init.Done() { A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_init.Run(A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_clinit) } }

func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_clinit() { A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_51, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_class }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A); return ok }

func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_Cast(x any) *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_class)) }; return v }



type A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A) Is_Compiler_AOTF3() {}

var A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_Init() { if !A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_init.Done() { A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_init.Run(A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_clinit) } }

func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_clinit() { A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_52, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_class }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A); return ok }

func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_Cast(x any) *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_class)) }; return v }



type A_arbace_core_protocols_eval619000161_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000161_A_New() *A_arbace_core_protocols_eval619000161_A { t := &A_arbace_core_protocols_eval619000161_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000161_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000161_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000161_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000161_A_class }

func (t *A_arbace_core_protocols_eval619000161_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000161_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000161_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000161_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000161_A); return ok }

func A_arbace_core_protocols_eval619000161_A_Cast(x any) *A_arbace_core_protocols_eval619000161_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000161_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000161_A_class)) }; return v }



type A_arbace_core_protocols_eval619000161_fn__619000162_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_A) Is_Compiler_AOTF1() {}

var A_arbace_core_protocols_eval619000161_fn__619000162_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000161_fn__619000162_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000161_fn__619000162_A_Init() { if !A_arbace_core_protocols_eval619000161_fn__619000162_A_init.Done() { A_arbace_core_protocols_eval619000161_fn__619000162_A_init.Run(A_arbace_core_protocols_eval619000161_fn__619000162_A_clinit) } }

func A_arbace_core_protocols_eval619000161_fn__619000162_A_clinit() { A_arbace_core_protocols_eval619000161_fn__619000162_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_54, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000161_fn__619000162_A_class }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000161_fn__619000162_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000161_fn__619000162_A); return ok }

func A_arbace_core_protocols_eval619000161_fn__619000162_A_Cast(x any) *A_arbace_core_protocols_eval619000161_fn__619000162_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000161_fn__619000162_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000161_fn__619000162_A_class)) }; return v }



type A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A struct{ jrt.Object; F_G__619000154 any }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A) Is_Compiler_AOTF1() {}

var A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_Init() { if !A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_init.Done() { A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_init.Run(A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_clinit) } }

func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_clinit() { A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_55, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_class }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A); return ok }

func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_Cast(x any) *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_class)) }; return v }



type A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A) Is_Compiler_AOTF1() {}

var A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_Init() { if !A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_init.Done() { A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_init.Run(A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_clinit) } }

func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_clinit() { A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_56, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_class }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A); return ok }

func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_Cast(x any) *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_class)) }; return v }



type A_arbace_core_protocols_eval619000175_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000175_A_New() *A_arbace_core_protocols_eval619000175_A { t := &A_arbace_core_protocols_eval619000175_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000175_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000175_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000175_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000175_A_class }

func (t *A_arbace_core_protocols_eval619000175_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000175_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000175_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000175_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000175_A); return ok }

func A_arbace_core_protocols_eval619000175_A_Cast(x any) *A_arbace_core_protocols_eval619000175_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000175_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000175_A_class)) }; return v }



type A_arbace_core_protocols_eval619000175_fn__619000176_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000175_fn__619000176_A) Is_Compiler_AOTF1() {}

var A_arbace_core_protocols_eval619000175_fn__619000176_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000175_fn__619000176_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000175_fn__619000176_A_Init() { if !A_arbace_core_protocols_eval619000175_fn__619000176_A_init.Done() { A_arbace_core_protocols_eval619000175_fn__619000176_A_init.Run(A_arbace_core_protocols_eval619000175_fn__619000176_A_clinit) } }

func A_arbace_core_protocols_eval619000175_fn__619000176_A_clinit() { A_arbace_core_protocols_eval619000175_fn__619000176_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_58, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000175_fn__619000176_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000175_fn__619000176_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000175_fn__619000176_A_class }

func (t *A_arbace_core_protocols_eval619000175_fn__619000176_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000175_fn__619000176_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000175_fn__619000176_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000175_fn__619000176_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000175_fn__619000176_A); return ok }

func A_arbace_core_protocols_eval619000175_fn__619000176_A_Cast(x any) *A_arbace_core_protocols_eval619000175_fn__619000176_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000175_fn__619000176_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000175_fn__619000176_A_class)) }; return v }



type A_arbace_core_protocols_eval619000179_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000179_A_New() *A_arbace_core_protocols_eval619000179_A { t := &A_arbace_core_protocols_eval619000179_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000179_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000179_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000179_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000179_A_class }

func (t *A_arbace_core_protocols_eval619000179_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000179_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000179_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000179_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000179_A); return ok }

func A_arbace_core_protocols_eval619000179_A_Cast(x any) *A_arbace_core_protocols_eval619000179_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000179_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000179_A_class)) }; return v }



type A_arbace_core_protocols_eval619000179_fn__619000180_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000179_fn__619000180_A) Is_Compiler_AOTF1() {}

var A_arbace_core_protocols_eval619000179_fn__619000180_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000179_fn__619000180_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000179_fn__619000180_A_Init() { if !A_arbace_core_protocols_eval619000179_fn__619000180_A_init.Done() { A_arbace_core_protocols_eval619000179_fn__619000180_A_init.Run(A_arbace_core_protocols_eval619000179_fn__619000180_A_clinit) } }

func A_arbace_core_protocols_eval619000179_fn__619000180_A_clinit() { A_arbace_core_protocols_eval619000179_fn__619000180_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_59, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000179_fn__619000180_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000179_fn__619000180_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000179_fn__619000180_A_class }

func (t *A_arbace_core_protocols_eval619000179_fn__619000180_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000179_fn__619000180_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000179_fn__619000180_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000179_fn__619000180_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000179_fn__619000180_A); return ok }

func A_arbace_core_protocols_eval619000179_fn__619000180_A_Cast(x any) *A_arbace_core_protocols_eval619000179_fn__619000180_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000179_fn__619000180_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000179_fn__619000180_A_class)) }; return v }



type A_arbace_core_protocols_eval619000191_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000191_A_New() *A_arbace_core_protocols_eval619000191_A { t := &A_arbace_core_protocols_eval619000191_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000191_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000191_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000191_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000191_A_class }

func (t *A_arbace_core_protocols_eval619000191_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000191_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000191_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000191_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000191_A); return ok }

func A_arbace_core_protocols_eval619000191_A_Cast(x any) *A_arbace_core_protocols_eval619000191_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000191_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000191_A_class)) }; return v }



type A_arbace_core_protocols_eval619000191_fn__619000192_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_A) Is_Compiler_AOTF1() {}

var A_arbace_core_protocols_eval619000191_fn__619000192_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000191_fn__619000192_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000191_fn__619000192_A_Init() { if !A_arbace_core_protocols_eval619000191_fn__619000192_A_init.Done() { A_arbace_core_protocols_eval619000191_fn__619000192_A_init.Run(A_arbace_core_protocols_eval619000191_fn__619000192_A_clinit) } }

func A_arbace_core_protocols_eval619000191_fn__619000192_A_clinit() { A_arbace_core_protocols_eval619000191_fn__619000192_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_60, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000191_fn__619000192_A_class }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000191_fn__619000192_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000191_fn__619000192_A); return ok }

func A_arbace_core_protocols_eval619000191_fn__619000192_A_Cast(x any) *A_arbace_core_protocols_eval619000191_fn__619000192_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000191_fn__619000192_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000191_fn__619000192_A_class)) }; return v }



type A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A struct{ jrt.Object; F_G__619000184 any }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A) Is_Compiler_AOTF3() {}

var A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_Init() { if !A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_init.Done() { A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_init.Run(A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_clinit) } }

func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_clinit() { A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_61, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_class }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A); return ok }

func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_Cast(x any) *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_class)) }; return v }



type A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A) Is_Compiler_AOTF3() {}

var A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_Init() { if !A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_init.Done() { A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_init.Run(A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_clinit) } }

func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_clinit() { A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_62, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_class }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A); return ok }

func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_Cast(x any) *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_class)) }; return v }



type A_arbace_core_protocols_eval619000209_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000209_A_New() *A_arbace_core_protocols_eval619000209_A { t := &A_arbace_core_protocols_eval619000209_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000209_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000209_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000209_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000209_A_class }

func (t *A_arbace_core_protocols_eval619000209_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000209_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000209_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000209_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000209_A); return ok }

func A_arbace_core_protocols_eval619000209_A_Cast(x any) *A_arbace_core_protocols_eval619000209_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000209_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000209_A_class)) }; return v }



type A_arbace_core_protocols_eval619000209_fn__619000210_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_eval619000209_fn__619000210_A) Is_Compiler_AOTF3() {}

var A_arbace_core_protocols_eval619000209_fn__619000210_A_fn_class *jrt.Class

var A_arbace_core_protocols_eval619000209_fn__619000210_A_init jrt.ClassInit

func A_arbace_core_protocols_eval619000209_fn__619000210_A_Init() { if !A_arbace_core_protocols_eval619000209_fn__619000210_A_init.Done() { A_arbace_core_protocols_eval619000209_fn__619000210_A_init.Run(A_arbace_core_protocols_eval619000209_fn__619000210_A_clinit) } }

func A_arbace_core_protocols_eval619000209_fn__619000210_A_clinit() { A_arbace_core_protocols_eval619000209_fn__619000210_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_64, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_eval619000209_fn__619000210_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000209_fn__619000210_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000209_fn__619000210_A_class }

func (t *A_arbace_core_protocols_eval619000209_fn__619000210_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000209_fn__619000210_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000209_fn__619000210_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000209_fn__619000210_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000209_fn__619000210_A); return ok }

func A_arbace_core_protocols_eval619000209_fn__619000210_A_Cast(x any) *A_arbace_core_protocols_eval619000209_fn__619000210_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000209_fn__619000210_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000209_fn__619000210_A_class)) }; return v }



type A_arbace_core_protocols_interface_or_naive_reduce_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_interface_or_naive_reduce_A) Is_Compiler_AOTF3() {}

var A_arbace_core_protocols_interface_or_naive_reduce_A_fn_class *jrt.Class

var A_arbace_core_protocols_interface_or_naive_reduce_A_init jrt.ClassInit

func A_arbace_core_protocols_interface_or_naive_reduce_A_Init() { if !A_arbace_core_protocols_interface_or_naive_reduce_A_init.Done() { A_arbace_core_protocols_interface_or_naive_reduce_A_init.Run(A_arbace_core_protocols_interface_or_naive_reduce_A_clinit) } }

func A_arbace_core_protocols_interface_or_naive_reduce_A_clinit() { A_arbace_core_protocols_interface_or_naive_reduce_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_65, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_interface_or_naive_reduce_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_interface_or_naive_reduce_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_interface_or_naive_reduce_A_class }

func (t *A_arbace_core_protocols_interface_or_naive_reduce_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_interface_or_naive_reduce_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_interface_or_naive_reduce_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_interface_or_naive_reduce_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_interface_or_naive_reduce_A); return ok }

func A_arbace_core_protocols_interface_or_naive_reduce_A_Cast(x any) *A_arbace_core_protocols_interface_or_naive_reduce_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_interface_or_naive_reduce_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_interface_or_naive_reduce_A_class)) }; return v }



type A_arbace_core_protocols_iter_reduce_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_iter_reduce_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_protocols_iter_reduce_A) Is_Compiler_AOTF2() {}

var A_arbace_core_protocols_iter_reduce_A_fn_class *jrt.Class

var A_arbace_core_protocols_iter_reduce_A_init jrt.ClassInit

func A_arbace_core_protocols_iter_reduce_A_Init() { if !A_arbace_core_protocols_iter_reduce_A_init.Done() { A_arbace_core_protocols_iter_reduce_A_init.Run(A_arbace_core_protocols_iter_reduce_A_clinit) } }

func A_arbace_core_protocols_iter_reduce_A_clinit() { A_arbace_core_protocols_iter_reduce_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_66, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_iter_reduce_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_iter_reduce_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_iter_reduce_A_class }

func (t *A_arbace_core_protocols_iter_reduce_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_iter_reduce_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_iter_reduce_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_iter_reduce_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_iter_reduce_A); return ok }

func A_arbace_core_protocols_iter_reduce_A_Cast(x any) *A_arbace_core_protocols_iter_reduce_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_iter_reduce_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_iter_reduce_A_class)) }; return v }



type A_arbace_core_protocols_iterator_reduce_BANG__A struct{ jrt.Object }

func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) Is_Compiler_AOTF2() {}

var A_arbace_core_protocols_iterator_reduce_BANG__A_fn_class *jrt.Class

var A_arbace_core_protocols_iterator_reduce_BANG__A_init jrt.ClassInit

func A_arbace_core_protocols_iterator_reduce_BANG__A_Init() { if !A_arbace_core_protocols_iterator_reduce_BANG__A_init.Done() { A_arbace_core_protocols_iterator_reduce_BANG__A_init.Run(A_arbace_core_protocols_iterator_reduce_BANG__A_clinit) } }

func A_arbace_core_protocols_iterator_reduce_BANG__A_clinit() { A_arbace_core_protocols_iterator_reduce_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_67, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_iterator_reduce_BANG__A_class }

func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_iterator_reduce_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_iterator_reduce_BANG__A); return ok }

func A_arbace_core_protocols_iterator_reduce_BANG__A_Cast(x any) *A_arbace_core_protocols_iterator_reduce_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_iterator_reduce_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_iterator_reduce_BANG__A_class)) }; return v }



type A_arbace_core_protocols_naive_seq_reduce_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_naive_seq_reduce_A) Is_Compiler_AOTF3() {}

var A_arbace_core_protocols_naive_seq_reduce_A_fn_class *jrt.Class

var A_arbace_core_protocols_naive_seq_reduce_A_init jrt.ClassInit

func A_arbace_core_protocols_naive_seq_reduce_A_Init() { if !A_arbace_core_protocols_naive_seq_reduce_A_init.Done() { A_arbace_core_protocols_naive_seq_reduce_A_init.Run(A_arbace_core_protocols_naive_seq_reduce_A_clinit) } }

func A_arbace_core_protocols_naive_seq_reduce_A_clinit() { A_arbace_core_protocols_naive_seq_reduce_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_68, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_naive_seq_reduce_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_naive_seq_reduce_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_naive_seq_reduce_A_class }

func (t *A_arbace_core_protocols_naive_seq_reduce_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_naive_seq_reduce_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_naive_seq_reduce_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_naive_seq_reduce_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_naive_seq_reduce_A); return ok }

func A_arbace_core_protocols_naive_seq_reduce_A_Cast(x any) *A_arbace_core_protocols_naive_seq_reduce_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_naive_seq_reduce_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_naive_seq_reduce_A_class)) }; return v }



type A_arbace_core_protocols_seq_reduce_A struct{ jrt.Object }

func (t *A_arbace_core_protocols_seq_reduce_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_core_protocols_seq_reduce_A) Is_Compiler_AOTF2() {}

var A_arbace_core_protocols_seq_reduce_A_fn_class *jrt.Class

var A_arbace_core_protocols_seq_reduce_A_init jrt.ClassInit

func A_arbace_core_protocols_seq_reduce_A_Init() { if !A_arbace_core_protocols_seq_reduce_A_init.Done() { A_arbace_core_protocols_seq_reduce_A_init.Run(A_arbace_core_protocols_seq_reduce_A_clinit) } }

func A_arbace_core_protocols_seq_reduce_A_clinit() { A_arbace_core_protocols_seq_reduce_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_69, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_protocols_seq_reduce_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_seq_reduce_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_seq_reduce_A_class }

func (t *A_arbace_core_protocols_seq_reduce_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_seq_reduce_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_seq_reduce_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_seq_reduce_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_seq_reduce_A); return ok }

func A_arbace_core_protocols_seq_reduce_A_Cast(x any) *A_arbace_core_protocols_seq_reduce_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_seq_reduce_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_seq_reduce_A_class)) }; return v }
