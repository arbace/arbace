//line aot_arbace_core_protocols.ae:1
package aot_arbace_core_protocols

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_New() *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_core_protocols_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_protocols_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_core_protocols_eval619000006_fn__619000007_A_New() *A_arbace_core_protocols_eval619000006_fn__619000007_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000006_fn__619000007_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_protocols_eval619000006_fn__619000007_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_protocols_eval619000006_fn__619000007_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_core_protocols_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_core_protocols_A_const_6), A_arbace_core_protocols_A_const_4.GetRawRoot__O(), A_arbace_core_protocols_A_const_5) }



func A_arbace_core_protocols_eval619000020_fn__619000021_A_New() *A_arbace_core_protocols_eval619000020_fn__619000021_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000020_fn__619000021_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_A) Ctor() {}
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__619000013__2_ any; var tmp1 any = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; G__619000013__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_New_O(G__619000013__2_); var tmp4 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_fn_class = fncls__4d; tmp4 = fncls__4d } else { tmp4 = fncls__4 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :13:1
func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_New_O(p0 any) *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A{}; t.Ctor_O(p0); return t }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) Ctor_O(c__G__619000013 any) { t.F_G__619000013 = c__G__619000013 }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) Invoke_O_O_O_O__O(self, gf__coll__619000031__1, gf__f__619000032__2, gf__val__619000033__3 any) any { var cache__231000236__auto____4 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____5 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____4)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__coll__619000031__1)); if jrt.J2g_Truth(f__231000237__auto____5) { return lang.IFn_Cast(f__231000237__auto____5).Invoke_O_O_O__O(gf__coll__619000031__1, gf__f__619000032__2, gf__val__619000033__3) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__coll__619000031__1, A_arbace_core_protocols_A_const_8, t.F_G__619000013)).Invoke_O_O_O__O(gf__coll__619000031__1, gf__f__619000032__2, gf__val__619000033__3) } }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) Invoke_O_O_O__O(self, gf__coll__619000029__1, gf__f__619000030__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__coll__619000029__1)); if jrt.J2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__coll__619000029__1, gf__f__619000030__2) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__coll__619000029__1, A_arbace_core_protocols_A_const_8, t.F_G__619000013)).Invoke_O_O__O(gf__coll__619000029__1, gf__f__619000030__2) } }
//line :13:1
func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_New() *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) Ctor() {}
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) Invoke_O_O_O_O__O(self, gf__coll__619000024__1, gf__f__619000025__2, gf__val__619000026__3 any) any { var target_1 any = gf__coll__619000024__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_1 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_1) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_1, Lit_3, jrt.RefArrayOf(jrt.Object_class, gf__f__619000025__2, gf__val__619000026__3)) } else { return A_arbace_core_protocols_CollReduce_A_Cast(target_1).Coll_reduce_O_O__O(gf__f__619000025__2, gf__val__619000026__3) } }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) Invoke_O_O_O__O(self, gf__coll__619000022__1, gf__f__619000023__2 any) any { var target_2 any = gf__coll__619000022__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_2 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_2) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_2, Lit_3, jrt.RefArrayOf(jrt.Object_class, gf__f__619000023__2)) } else { return A_arbace_core_protocols_CollReduce_A_Cast(target_2).Coll_reduce_O__O(gf__f__619000023__2) } }





func A_arbace_core_protocols_eval619000050_fn__619000051_A_New() *A_arbace_core_protocols_eval619000050_fn__619000051_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000050_fn__619000051_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_A) Ctor() {}
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__619000043__2_ any; var tmp1 any = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_New(); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; G__619000043__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_New_O(G__619000043__2_); var tmp4 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_fn_class = fncls__7d; tmp4 = fncls__7d } else { tmp4 = fncls__7 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :19:1
func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_New_O(p0 any) *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A{}; t.Ctor_O(p0); return t }
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A) Ctor_O(c__G__619000043 any) { t.F_G__619000043 = c__G__619000043 }
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A) Invoke_O_O_O_O__O(self, gf__seq__619000057__1, gf__f__619000058__2, gf__start__619000059__3 any) any { var cache__231000236__auto____4 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____5 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____4)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__seq__619000057__1)); if jrt.J2g_Truth(f__231000237__auto____5) { return lang.IFn_Cast(f__231000237__auto____5).Invoke_O_O_O__O(gf__seq__619000057__1, gf__f__619000058__2, gf__start__619000059__3) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__seq__619000057__1, A_arbace_core_protocols_A_const_9, t.F_G__619000043)).Invoke_O_O_O__O(gf__seq__619000057__1, gf__f__619000058__2, gf__start__619000059__3) } }
//line :19:1
func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_New() *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A) Ctor() {}
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A) Invoke_O_O_O_O__O(self, gf__seq__619000052__1, gf__f__619000053__2, gf__start__619000054__3 any) any { var target_5 any = gf__seq__619000052__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_5 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_5) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_5, Lit_6, jrt.RefArrayOf(jrt.Object_class, gf__f__619000053__2, gf__start__619000054__3)) } else { return A_arbace_core_protocols_InternalReduce_A_Cast(target_5).Internal_reduce_O_O__O(gf__f__619000053__2, gf__start__619000054__3) } }




func A_arbace_core_protocols_seq_reduce_A_New() *A_arbace_core_protocols_seq_reduce_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_seq_reduce_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_core_protocols_seq_reduce_A) Ctor() {}
//line :24:1
func (t *A_arbace_core_protocols_seq_reduce_A) Invoke_O_O_O_O__O(self, coll__0, f__1, val__2 any) any { var s__4 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_10.GetRawRoot__O()).Invoke_O__O(coll__0); var target_8 any = s__4; var tmp1 bool; var tmp2 bool; tmp2 =






	A_arbace_core_protocols_InternalReduce_A_InstanceOf(target_8); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_8) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_protocols_InternalReduce_A_Cast(target_8).Internal_reduce_O_O__O(f__1, val__2) } else { return lang.IFn_Cast(A_arbace_core_protocols_A_const_11.GetRawRoot__O()).Invoke_O_O_O__O(target_8, f__1, val__2) } }
//line :24:1
func (t *A_arbace_core_protocols_seq_reduce_A) Invoke_O_O_O__O(self, coll__0, f__1 any) any { var temp__1927000408__auto____3 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_10.GetRawRoot__O()).Invoke_O__O(coll__0); if

	jrt.J2g_Truth(temp__1927000408__auto____3) { var s__4 any = temp__1927000408__auto____3; var target_9 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_12.GetRawRoot__O()).Invoke_O__O(s__4); var tmp1 bool; var tmp2 bool
		tmp2 = A_arbace_core_protocols_InternalReduce_A_InstanceOf(target_9); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_9) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_protocols_InternalReduce_A_Cast(target_9).Internal_reduce_O_O__O(f__1, lang.IFn_Cast(A_arbace_core_protocols_A_const_13.GetRawRoot__O()).Invoke_O__O(s__4)) } else { return lang.IFn_Cast(A_arbace_core_protocols_A_const_11.GetRawRoot__O()).Invoke_O_O_O__O(target_9, f__1, lang.IFn_Cast(A_arbace_core_protocols_A_const_13.GetRawRoot__O()).Invoke_O__O(s__4)) } } else {
			return lang.IFn_Cast(f__1).Invoke__O() } }





func A_arbace_core_protocols_iterator_reduce_BANG__A_New() *A_arbace_core_protocols_iterator_reduce_BANG__A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_iterator_reduce_BANG__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) Ctor() {}
//line :34:1
func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) Invoke_O_O_O_O__O(self, iter__0, f__1, val__2 any) any { { var ret__4 any = val__2; L1: for {






	if jrt.Iterator_Cast(iter__0).HasNext__Z() { var ret__5 any = lang.IFn_Cast(f__1).Invoke_O_O__O(ret__4, jrt.Iterator_Cast(iter__0).Next__O())

		if lang.RT_IsReduced_O__Z_NoInit(ret__5) { return lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(ret__5) } else {

			ret__4 = ret__5; continue L1 } } else {
//line :41:1
				return ret__4 } } }; /*line :34:1*/panic("j2g: unreachable") }
//line :34:1
func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) Invoke_O_O_O__O(self, iter__0, f__1 any) any {

	if jrt.Iterator_Cast(iter__0).HasNext__Z() {
		return lang.IFn_Cast(A_arbace_core_protocols_A_const_14.GetRawRoot__O()).Invoke_O_O_O__O(iter__0, f__1, jrt.Iterator_Cast(iter__0).Next__O()) } else {
			return lang.IFn_Cast(f__1).Invoke__O()
		}
}







func A_arbace_core_protocols_iter_reduce_A_New() *A_arbace_core_protocols_iter_reduce_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_iter_reduce_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_core_protocols_iter_reduce_A) Ctor() {}
//line :48:1
func (t *A_arbace_core_protocols_iter_reduce_A) Invoke_O_O_O_O__O(self, coll__0, f__1, val__2 any) any {



	return lang.IFn_Cast(A_arbace_core_protocols_A_const_14.GetRawRoot__O()).Invoke_O_O_O__O(jrt.Iterable_Cast(coll__0).Iterator__Iterator(), f__1, val__2) }
//line :48:1
func (t *A_arbace_core_protocols_iter_reduce_A) Invoke_O_O_O__O(self, coll__0, f__1 any) any {

	return lang.IFn_Cast(A_arbace_core_protocols_A_const_14.GetRawRoot__O()).Invoke_O_O__O(jrt.Iterable_Cast(coll__0).Iterator__Iterator(), f__1)
}


func A_arbace_core_protocols_naive_seq_reduce_A_New() *A_arbace_core_protocols_naive_seq_reduce_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_naive_seq_reduce_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_core_protocols_naive_seq_reduce_A) Ctor() {}
//line :54:1
func (t *A_arbace_core_protocols_naive_seq_reduce_A) Invoke_O_O_O_O__O(self, s__0, f__1, val__2 any) any { { var s__4 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_10.GetRawRoot__O()).Invoke_O__O(s__0); var val__5 any = val__2; L1: for {





	if jrt.J2g_Truth(s__4) { var ret__6 any = lang.IFn_Cast(f__1).Invoke_O_O__O(val__5, lang.IFn_Cast(A_arbace_core_protocols_A_const_13.GetRawRoot__O()).Invoke_O__O(s__4))

		if lang.RT_IsReduced_O__Z_NoInit(ret__6) { return lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(ret__6) } else {

			s__4, val__5 = lang.IFn_Cast(A_arbace_core_protocols_A_const_12.GetRawRoot__O()).Invoke_O__O(s__4), ret__6; continue L1 } } else {
//line :60:1
				return val__5 } } }; /*line :54:1*/panic("j2g: unreachable") }












func A_arbace_core_protocols_interface_or_naive_reduce_A_New() *A_arbace_core_protocols_interface_or_naive_reduce_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_interface_or_naive_reduce_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_core_protocols_interface_or_naive_reduce_A) Ctor() {}
//line :67:1
func (t *A_arbace_core_protocols_interface_or_naive_reduce_A) Invoke_O_O_O_O__O(self, coll__0, f__1, val__2 any) any {


	if lang.IReduceInit_InstanceOf(coll__0) {
		return lang.IReduceInit_Cast(coll__0).Reduce_IFn_O__O(lang.IFn_Cast(f__1), val__2) } else {
			return lang.IFn_Cast(A_arbace_core_protocols_A_const_15.GetRawRoot__O()).Invoke_O_O_O__O(coll__0, f__1, val__2)
		} }
func A_arbace_core_protocols_eval619000073_fn__619000074_A_New() *A_arbace_core_protocols_eval619000073_fn__619000074_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000073_fn__619000074_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any { return val__3 }
//line :74:1
func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {


	return lang.IFn_Cast(f__2).Invoke__O() }
//line :74:1
func A_arbace_core_protocols_eval619000077_fn__619000078_A_New() *A_arbace_core_protocols_eval619000077_fn__619000078_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000077_fn__619000078_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {








	return lang.IFn_Cast(A_arbace_core_protocols_A_const_16.GetRawRoot__O()).Invoke_O_O_O__O(coll__1, f__2, val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {







	return lang.IFn_Cast(A_arbace_core_protocols_A_const_16.GetRawRoot__O()).Invoke_O_O__O(coll__1, f__2) }
//line :74:1
func A_arbace_core_protocols_eval619000081_fn__619000082_A_New() *A_arbace_core_protocols_eval619000081_fn__619000082_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000081_fn__619000082_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {








































	return lang.IFn_Cast(A_arbace_core_protocols_A_const_16.GetRawRoot__O()).Invoke_O_O_O__O(coll__1, f__2, val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {







































	return lang.IFn_Cast(A_arbace_core_protocols_A_const_16.GetRawRoot__O()).Invoke_O_O__O(coll__1, f__2) }
//line :74:1
func A_arbace_core_protocols_eval619000085_fn__619000086_A_New() *A_arbace_core_protocols_eval619000085_fn__619000086_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000085_fn__619000086_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {













































	return lang.IFn_Cast(A_arbace_core_protocols_A_const_17.GetRawRoot__O()).Invoke_O_O_O__O(coll__1, f__2, val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {












































	return lang.IFn_Cast(A_arbace_core_protocols_A_const_17.GetRawRoot__O()).Invoke_O_O__O(coll__1, f__2) }
//line :74:1
func A_arbace_core_protocols_eval619000089_fn__619000090_A_New() *A_arbace_core_protocols_eval619000089_fn__619000090_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000089_fn__619000090_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {




























	return lang.IFn_Cast(A_arbace_core_protocols_A_const_16.GetRawRoot__O()).Invoke_O_O_O__O(coll__1, f__2, val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {



























	return lang.IFn_Cast(A_arbace_core_protocols_A_const_16.GetRawRoot__O()).Invoke_O_O__O(coll__1, f__2) }
//line :74:1
func A_arbace_core_protocols_eval619000093_fn__619000094_A_New() *A_arbace_core_protocols_eval619000093_fn__619000094_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000093_fn__619000094_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {






















	return lang.IReduceInit_Cast(coll__1).Reduce_IFn_O__O(lang.IFn_Cast(f__2), val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {













	if lang.IReduce_InstanceOf(coll__1) {
		return lang.IReduce_Cast(coll__1).Reduce_IFn__O(lang.IFn_Cast(f__2)) } else {
//line :88:1
			var none__3 any = jrt.Object_New(); var ret__4 any; var tmp1 lang.IReduceInit = lang.IReduceInit_Cast(coll__1); var tmp2 any = A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_New_O_O(f__2, none__3); var tmp3 *jrt.Class
			var fncls__10 /*line :88:1*/*jrt.Class = A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_fn_class





			if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }
//line :93:1
			ret__4 = tmp1.Reduce_IFn_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), none__3)


			if lang.Util_Identical_O_O__Z_NoInit(ret__4, none__3) { return lang.IFn_Cast(f__2).Invoke__O() } else { return ret__4 } } }
//line :74:1
func A_arbace_core_protocols_eval619000099_fn__619000100_A_New() *A_arbace_core_protocols_eval619000099_fn__619000100_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000099_fn__619000100_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {


































	return lang.IFn_Cast(A_arbace_core_protocols_A_const_16.GetRawRoot__O()).Invoke_O_O_O__O(coll__1, f__2, val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {

































	return lang.IFn_Cast(A_arbace_core_protocols_A_const_16.GetRawRoot__O()).Invoke_O_O__O(coll__1, f__2) }
//line :74:1
func A_arbace_core_protocols_eval619000103_fn__619000104_A_New() *A_arbace_core_protocols_eval619000103_fn__619000104_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000103_fn__619000104_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {


















































	return lang.IFn_Cast(A_arbace_core_protocols_A_const_17.GetRawRoot__O()).Invoke_O_O_O__O(coll__1, f__2, val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {

















































	return lang.IFn_Cast(A_arbace_core_protocols_A_const_17.GetRawRoot__O()).Invoke_O_O__O(coll__1, f__2) }
//line :74:1
func A_arbace_core_protocols_eval619000107_fn__619000108_A_New() *A_arbace_core_protocols_eval619000107_fn__619000108_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000107_fn__619000108_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {























































	return lang.IFn_Cast(A_arbace_core_protocols_A_const_17.GetRawRoot__O()).Invoke_O_O_O__O(coll__1, f__2, val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {






















































	return lang.IFn_Cast(A_arbace_core_protocols_A_const_17.GetRawRoot__O()).Invoke_O_O__O(coll__1, f__2) }
//line :94:1
func A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_New_O_O(p0, p1 any) *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A{}; t.Ctor_O_O(p0, p1); return t }
//line :94:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A) Ctor_O_O(c__f, c__none any) { t.F_f = c__f; t.F_none = c__none }
//line :94:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A) Invoke_O_O_O__O(self, acc__1, x__2 any) any { if lang.Util_Identical_O_O__Z_NoInit(acc__1, t.F_none) { return x__2 } else { return lang.IFn_Cast(t.F_f).Invoke_O_O__O(acc__1, x__2) } }





































func A_arbace_core_protocols_eval619000111_fn__619000112_A_New() *A_arbace_core_protocols_eval619000111_fn__619000112_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000111_fn__619000112_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_core_protocols_eval619000111_fn__619000112_A) Ctor() {}
//line :132:1
func (t *A_arbace_core_protocols_eval619000111_fn__619000112_A) Invoke_O_O_O_O__O(self, s__1, f__2, val__3 any) any { return val__3 }
//line :132:1
func A_arbace_core_protocols_eval619000115_fn__619000116_A_New() *A_arbace_core_protocols_eval619000115_fn__619000116_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000115_fn__619000116_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_core_protocols_eval619000115_fn__619000116_A) Ctor() {}
//line :132:1
func (t *A_arbace_core_protocols_eval619000115_fn__619000116_A) Invoke_O_O_O_O__O(self, s__1, f__2, val__3 any) any { { var s__1_2 any = s__1; var f__2_2 any = f__2; var val__3_2 any = val__3; L1: for { var temp__1927000408__auto____4 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_10.GetRawRoot__O()).Invoke_O__O(s__1_2)









	if jrt.J2g_Truth(temp__1927000408__auto____4) { var s__5 any = temp__1927000408__auto____4
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_protocols_A_const_18.GetRawRoot__O()).Invoke_O__O(s__5)) { var ret__6 any = lang.IChunk_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_19.GetRawRoot__O()).Invoke_O__O(s__5)).Reduce_IFn_O__O(lang.IFn_Cast(f__2_2), val__3_2)

			if lang.RT_IsReduced_O__Z_NoInit(ret__6) { return lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(ret__6) } else {

				s__1_2, f__2_2, val__3_2 = lang.IFn_Cast(A_arbace_core_protocols_A_const_21.GetRawRoot__O()).Invoke_O__O(s__5), f__2_2, ret__6; continue L1 } } else {


					return lang.IFn_Cast(A_arbace_core_protocols_A_const_20.GetRawRoot__O()).Invoke_O_O_O__O(s__5, f__2_2, val__3_2) } } else {
//line :142:1
						return val__3_2 } } }; /*line :132:1*/panic("j2g: unreachable") }
//line :132:1
func A_arbace_core_protocols_eval619000119_fn__619000120_A_New() *A_arbace_core_protocols_eval619000119_fn__619000120_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000119_fn__619000120_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_core_protocols_eval619000119_fn__619000120_A) Ctor() {}
//line :132:1
func (t *A_arbace_core_protocols_eval619000119_fn__619000120_A) Invoke_O_O_O_O__O(self, str_seq__1, f__2, val__3 any) any { { var s__4 any = lang.StringSeq_Cast(str_seq__1).F_s; var len__5 int32 = jrt.CharSequence_Cast(s__4).Length__I(); var i__6 int64 = lang.RT_LongCast_I__J_NoInit(lang.StringSeq_Cast(str_seq__1).F_i); var val__7 any = val__3; L1: for {



























	if lang.Numbers_Lt_J_J__Z_NoInit(i__6, int64(len__5)) { var ret__8 any = lang.IFn_Cast(f__2).Invoke_O_O__O(val__7, jrt.Character_ValueOf_C__Character_NoInit(jrt.CharSequence_Cast(s__4).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__6))).Ref())

		if lang.RT_IsReduced_O__Z_NoInit(ret__8) { return lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(ret__8) } else {

			i__6, val__7 = lang.Numbers_Inc_J__J_NoInit(i__6), ret__8; continue L1 } } else {
//line :160:1
				return val__7 } } }; /*line :132:1*/panic("j2g: unreachable") }
//line :132:1
func A_arbace_core_protocols_eval619000123_fn__619000124_A_New() *A_arbace_core_protocols_eval619000123_fn__619000124_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000123_fn__619000124_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_core_protocols_eval619000123_fn__619000124_A) Ctor() {}
//line :132:1
func (t *A_arbace_core_protocols_eval619000123_fn__619000124_A) Invoke_O_O_O_O__O(self, s__1, f__2, val__3 any) any { { var cls__4 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_22.GetRawRoot__O()).Invoke_O__O(s__1); var s__5 any = s__1; var f__6 any = f__2; var val__7 any = val__3; L1: for { var temp__1927000408__auto____8 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_10.GetRawRoot__O()).Invoke_O__O(s__5)









































	if jrt.J2g_Truth(temp__1927000408__auto____8) { var s__9 any = temp__1927000408__auto____8
		if lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_core_protocols_A_const_22.GetRawRoot__O()).Invoke_O__O(s__9), cls__4) { var ret__10 any = lang.IFn_Cast(f__6).Invoke_O_O__O(val__7, lang.IFn_Cast(A_arbace_core_protocols_A_const_13.GetRawRoot__O()).Invoke_O__O(s__9))

			if lang.RT_IsReduced_O__Z_NoInit(ret__10) { return lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(ret__10) } else {

				cls__4, s__5, f__6, val__7 = cls__4, lang.IFn_Cast(A_arbace_core_protocols_A_const_12.GetRawRoot__O()).Invoke_O__O(s__9), f__6, ret__10; continue L1 } } else {
					return lang.IFn_Cast(A_arbace_core_protocols_A_const_20.GetRawRoot__O()).Invoke_O_O_O__O(s__9, f__6, val__7) } } else {
//line :174:1
						return val__7 } } }; /*line :132:1*/panic("j2g: unreachable") }


















































func A_arbace_core_protocols_eval619000135_fn__619000136_A_New() *A_arbace_core_protocols_eval619000135_fn__619000136_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000135_fn__619000136_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_A) Ctor() {}
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__619000128__2_ any; var tmp1 any = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_New(); var tmp2 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_fn_class = fncls__12d; tmp2 = fncls__12d } else { tmp2 = fncls__12 }; G__619000128__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_New_O(G__619000128__2_); var tmp4 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_fn_class = fncls__13d; tmp4 = fncls__13d } else { tmp4 = fncls__13 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :183:1
func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_New_O(p0 any) *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A{}; t.Ctor_O(p0); return t }
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A) Ctor_O(c__G__619000128 any) { t.F_G__619000128 = c__G__619000128 }
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A) Invoke_O_O_O_O__O(self, gf__amap__619000142__1, gf__f__619000143__2, gf__init__619000144__3 any) any { var cache__231000236__auto____4 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____5 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____4)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__amap__619000142__1)); if jrt.J2g_Truth(f__231000237__auto____5) { return lang.IFn_Cast(f__231000237__auto____5).Invoke_O_O_O__O(gf__amap__619000142__1, gf__f__619000143__2, gf__init__619000144__3) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__amap__619000142__1, A_arbace_core_protocols_A_const_23, t.F_G__619000128)).Invoke_O_O_O__O(gf__amap__619000142__1, gf__f__619000143__2, gf__init__619000144__3) } }
//line :183:1
func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_New() *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A) Ctor() {}
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A) Invoke_O_O_O_O__O(self, gf__amap__619000137__1, gf__f__619000138__2, gf__init__619000139__3 any) any { var target_11 any = gf__amap__619000137__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_11 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_11) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_11, Lit_10, jrt.RefArrayOf(jrt.Object_class, gf__f__619000138__2, gf__init__619000139__3)) } else { return A_arbace_core_protocols_IKVReduce_A_Cast(target_11).Kv_reduce_O_O__O(gf__f__619000138__2, gf__init__619000139__3) } }






func A_arbace_core_protocols_eval619000161_fn__619000162_A_New() *A_arbace_core_protocols_eval619000161_fn__619000162_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000161_fn__619000162_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_A) Ctor() {}
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__619000154__2_ any; var tmp1 any = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_New(); var tmp2 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_fn_class = fncls__15d; tmp2 = fncls__15d } else { tmp2 = fncls__15 }; G__619000154__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_New_O(G__619000154__2_); var tmp4 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_fn_class = fncls__16d; tmp4 = fncls__16d } else { tmp4 = fncls__16 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :190:1
func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_New_O(p0 any) *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A{}; t.Ctor_O(p0); return t }
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A) Ctor_O(c__G__619000154 any) { t.F_G__619000154 = c__G__619000154 }
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A) Invoke_O_O__O(self, gf__o__619000166__1 any) any { var cache__231000232__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000233__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000232__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__o__619000166__1)); if lang.Util_Identical_O_O__Z_NoInit(f__231000233__auto____3, t.F_G__619000154) { return lang.IFn_Cast(f__231000233__auto____3).Invoke_O__O(gf__o__619000166__1) } else { var temp__1927000408__auto____4 any; var temp__1927000414__auto____4 any = lang.RT_Meta_O__IPersistentMap_NoInit(gf__o__619000166__1); if jrt.J2g_Truth(temp__1927000414__auto____4) { var m__231000235__auto____5 any = temp__1927000414__auto____4; temp__1927000408__auto____4 = Up_Symbol_IFn(lang.MethodImplCache_Cast(cache__231000232__auto____2).F_sym).Invoke_O__O(m__231000235__auto____5) } else { temp__1927000408__auto____4 = nil }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var meta__231000234__auto____5 any = temp__1927000408__auto____4; return lang.IFn_Cast(meta__231000234__auto____5).Invoke_O__O(gf__o__619000166__1) } else { if jrt.J2g_Truth(f__231000233__auto____3) { return lang.IFn_Cast(f__231000233__auto____3).Invoke_O__O(gf__o__619000166__1) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__o__619000166__1, A_arbace_core_protocols_A_const_24, t.F_G__619000154)).Invoke_O__O(gf__o__619000166__1) } } } }
//line :190:1
func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_New() *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A) Ctor() {}
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A) Invoke_O_O__O(self, gf__o__619000163__1 any) any { var target_14 any = gf__o__619000163__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_14 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_14) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_14, Lit_13, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_core_protocols_Datafiable_A_Cast(target_14).Datafy__O() } }




func A_arbace_core_protocols_eval619000175_fn__619000176_A_New() *A_arbace_core_protocols_eval619000175_fn__619000176_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000175_fn__619000176_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_core_protocols_eval619000175_fn__619000176_A) Ctor() {}
//line :195:1
func (t *A_arbace_core_protocols_eval619000175_fn__619000176_A) Invoke_O_O__O(self, ___1 any) any { return nil }
//line :195:1
func A_arbace_core_protocols_eval619000179_fn__619000180_A_New() *A_arbace_core_protocols_eval619000179_fn__619000180_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000179_fn__619000180_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_core_protocols_eval619000179_fn__619000180_A) Ctor() {}
//line :195:1
func (t *A_arbace_core_protocols_eval619000179_fn__619000180_A) Invoke_O_O__O(self, x__1 any) any { return x__1 }






func A_arbace_core_protocols_eval619000191_fn__619000192_A_New() *A_arbace_core_protocols_eval619000191_fn__619000192_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000191_fn__619000192_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_A) Ctor() {}
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__619000184__2_ any; var tmp1 any = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_New(); var tmp2 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_fn_class = fncls__18d; tmp2 = fncls__18d } else { tmp2 = fncls__18 }; G__619000184__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_New_O(G__619000184__2_); var tmp4 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_fn_class = fncls__19d; tmp4 = fncls__19d } else { tmp4 = fncls__19 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :202:1
func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_New_O(p0 any) *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A) Ctor_O(c__G__619000184 any) { t.F_G__619000184 = c__G__619000184 }
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A) Invoke_O_O_O_O__O(self, gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3 any) any { var cache__231000232__auto____4 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000233__auto____5 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000232__auto____4)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__coll__619000198__1)); if lang.Util_Identical_O_O__Z_NoInit(f__231000233__auto____5, t.F_G__619000184) { return lang.IFn_Cast(f__231000233__auto____5).Invoke_O_O_O__O(gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3) } else { var temp__1927000408__auto____6 any; var temp__1927000414__auto____6 any = lang.RT_Meta_O__IPersistentMap_NoInit(gf__coll__619000198__1); if jrt.J2g_Truth(temp__1927000414__auto____6) { var m__231000235__auto____7 any = temp__1927000414__auto____6; temp__1927000408__auto____6 = Up_Symbol_IFn(lang.MethodImplCache_Cast(cache__231000232__auto____4).F_sym).Invoke_O__O(m__231000235__auto____7) } else { temp__1927000408__auto____6 = nil }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var meta__231000234__auto____7 any = temp__1927000408__auto____6; return lang.IFn_Cast(meta__231000234__auto____7).Invoke_O_O_O__O(gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3) } else { if jrt.J2g_Truth(f__231000233__auto____5) { return lang.IFn_Cast(f__231000233__auto____5).Invoke_O_O_O__O(gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__coll__619000198__1, A_arbace_core_protocols_A_const_25, t.F_G__619000184)).Invoke_O_O_O__O(gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3) } } } }
//line :202:1
func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_New() *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A) Ctor() {}
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A) Invoke_O_O_O_O__O(self, gf__coll__619000193__1, gf__k__619000194__2, gf__v__619000195__3 any) any { var target_17 any = gf__coll__619000193__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_17 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_17) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_17, Lit_16, jrt.RefArrayOf(jrt.Object_class, gf__k__619000194__2, gf__v__619000195__3)) } else { return A_arbace_core_protocols_Navigable_A_Cast(target_17).Nav_O_O__O(gf__k__619000194__2, gf__v__619000195__3) } }





func A_arbace_core_protocols_eval619000209_fn__619000210_A_New() *A_arbace_core_protocols_eval619000209_fn__619000210_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000209_fn__619000210_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_core_protocols_eval619000209_fn__619000210_A) Ctor() {}
//line :208:1
func (t *A_arbace_core_protocols_eval619000209_fn__619000210_A) Invoke_O_O_O_O__O(self, ___1, ___2, x__3 any) any { return x__3 }
































































type A_arbace_core_protocols_A struct{ jrt.Object }

var A_arbace_core_protocols_A_const_pool *jrt.RefArray

var A_arbace_core_protocols_A_const_0 *lang.Var

var A_arbace_core_protocols_A_const_1 any

var A_arbace_core_protocols_A_const_2 *lang.Var

var A_arbace_core_protocols_A_const_3 *lang.Var

var A_arbace_core_protocols_A_const_4 *lang.Var

var A_arbace_core_protocols_A_const_5 any

var A_arbace_core_protocols_A_const_6 *lang.Var

var A_arbace_core_protocols_A_const_7 *lang.Var

var A_arbace_core_protocols_A_const_8 *jrt.Class

var A_arbace_core_protocols_A_const_9 *jrt.Class

var A_arbace_core_protocols_A_const_10 *lang.Var

var A_arbace_core_protocols_A_const_11 *lang.Var

var A_arbace_core_protocols_A_const_12 *lang.Var

var A_arbace_core_protocols_A_const_13 *lang.Var

var A_arbace_core_protocols_A_const_14 *lang.Var

var A_arbace_core_protocols_A_const_15 *lang.Var

var A_arbace_core_protocols_A_const_16 *lang.Var

var A_arbace_core_protocols_A_const_17 *lang.Var

var A_arbace_core_protocols_A_const_18 *lang.Var

var A_arbace_core_protocols_A_const_19 *lang.Var

var A_arbace_core_protocols_A_const_20 *lang.Var

var A_arbace_core_protocols_A_const_21 *lang.Var

var A_arbace_core_protocols_A_const_22 *lang.Var

var A_arbace_core_protocols_A_const_23 *jrt.Class

var A_arbace_core_protocols_A_const_24 *jrt.Class

var A_arbace_core_protocols_A_const_25 *jrt.Class

var A_arbace_core_protocols_A_init jrt.ClassInit

func A_arbace_core_protocols_A_Init() { if !A_arbace_core_protocols_A_init.Done() { A_arbace_core_protocols_A_init.Run(A_arbace_core_protocols_A_clinit) } }

func A_arbace_core_protocols_A_clinit() { A_arbace_core_protocols_A_clinit_p0(); A_arbace_core_protocols_A_clinit_p1(); A_arbace_core_protocols_A_clinit_p2() }

func A_arbace_core_protocols_A_clinit_p0() { jrt.StartCheck(); A_arbace_core_protocols_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 28); A_arbace_core_protocols_A_const_0 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[2]); A_arbace_core_protocols_A_const_1 = A_arbace_core_protocols_A_const_pool.A[3]; A_arbace_core_protocols_A_const_2 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[4]); A_arbace_core_protocols_A_const_3 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[5]); A_arbace_core_protocols_A_const_4 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[6]); A_arbace_core_protocols_A_const_5 = A_arbace_core_protocols_A_const_pool.A[7]; A_arbace_core_protocols_A_const_6 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[8]); A_arbace_core_protocols_A_const_7 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[9]); A_arbace_core_protocols_A_const_8 = jrt.Class_Cast(A_arbace_core_protocols_A_const_pool.A[10]); A_arbace_core_protocols_A_const_9 = jrt.Class_Cast(A_arbace_core_protocols_A_const_pool.A[11]); A_arbace_core_protocols_A_const_10 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[12]) }

func A_arbace_core_protocols_A_clinit_p1() { A_arbace_core_protocols_A_const_11 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[13]); A_arbace_core_protocols_A_const_12 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[14]); A_arbace_core_protocols_A_const_13 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[15]); A_arbace_core_protocols_A_const_14 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[16]); A_arbace_core_protocols_A_const_15 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[17]); A_arbace_core_protocols_A_const_16 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[18]); A_arbace_core_protocols_A_const_17 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[19]); A_arbace_core_protocols_A_const_18 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[20]); A_arbace_core_protocols_A_const_19 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[21]); A_arbace_core_protocols_A_const_20 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[22]); A_arbace_core_protocols_A_const_21 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[23]); A_arbace_core_protocols_A_const_22 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[24]) }

func A_arbace_core_protocols_A_clinit_p2() { A_arbace_core_protocols_A_const_23 = jrt.Class_Cast(A_arbace_core_protocols_A_const_pool.A[25]); A_arbace_core_protocols_A_const_24 = jrt.Class_Cast(A_arbace_core_protocols_A_const_pool.A[26]); A_arbace_core_protocols_A_const_25 = jrt.Class_Cast(A_arbace_core_protocols_A_const_pool.A[27]) }

func A_arbace_core_protocols_A_New() *A_arbace_core_protocols_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_A) Ctor() {}

func (t *A_arbace_core_protocols_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_A_class }

func (t *A_arbace_core_protocols_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_A); return ok }

func A_arbace_core_protocols_A_Cast(x any) *A_arbace_core_protocols_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_A_class)) }; return v }



type A_arbace_core_protocols_eval619000002_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000002_A_New() *A_arbace_core_protocols_eval619000002_A { t := &A_arbace_core_protocols_eval619000002_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000002_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000002_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000002_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000002_A_class }

func (t *A_arbace_core_protocols_eval619000002_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000002_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000002_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000002_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000002_A); return ok }

func A_arbace_core_protocols_eval619000002_A_Cast(x any) *A_arbace_core_protocols_eval619000002_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000002_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000002_A_class)) }; return v }



type A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000006_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000006_A_New() *A_arbace_core_protocols_eval619000006_A { t := &A_arbace_core_protocols_eval619000006_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000006_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000006_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000006_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000006_A_class }

func (t *A_arbace_core_protocols_eval619000006_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000006_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000006_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000006_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000006_A); return ok }

func A_arbace_core_protocols_eval619000006_A_Cast(x any) *A_arbace_core_protocols_eval619000006_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000006_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000006_A_class)) }; return v }



type A_arbace_core_protocols_eval619000006_fn__619000007_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000006_fn__619000007_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000020_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000020_A_New() *A_arbace_core_protocols_eval619000020_A { t := &A_arbace_core_protocols_eval619000020_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000020_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000020_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000020_A_class }

func (t *A_arbace_core_protocols_eval619000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000020_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000020_A); return ok }

func A_arbace_core_protocols_eval619000020_A_Cast(x any) *A_arbace_core_protocols_eval619000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000020_A_class)) }; return v }



type A_arbace_core_protocols_eval619000020_fn__619000021_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000020_fn__619000021_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A struct{ j2g_header uint64; F_G__619000013 any }

var A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000050_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000050_A_New() *A_arbace_core_protocols_eval619000050_A { t := &A_arbace_core_protocols_eval619000050_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000050_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000050_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000050_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000050_A_class }

func (t *A_arbace_core_protocols_eval619000050_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000050_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000050_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000050_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000050_A); return ok }

func A_arbace_core_protocols_eval619000050_A_Cast(x any) *A_arbace_core_protocols_eval619000050_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000050_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000050_A_class)) }; return v }



type A_arbace_core_protocols_eval619000050_fn__619000051_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000050_fn__619000051_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A struct{ j2g_header uint64; F_G__619000043 any }

var A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000073_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000073_A_New() *A_arbace_core_protocols_eval619000073_A { t := &A_arbace_core_protocols_eval619000073_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000073_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000073_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000073_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000073_A_class }

func (t *A_arbace_core_protocols_eval619000073_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000073_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000073_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000073_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000073_A); return ok }

func A_arbace_core_protocols_eval619000073_A_Cast(x any) *A_arbace_core_protocols_eval619000073_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000073_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000073_A_class)) }; return v }



type A_arbace_core_protocols_eval619000073_fn__619000074_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000073_fn__619000074_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000077_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000077_A_New() *A_arbace_core_protocols_eval619000077_A { t := &A_arbace_core_protocols_eval619000077_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000077_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000077_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000077_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000077_A_class }

func (t *A_arbace_core_protocols_eval619000077_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000077_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000077_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000077_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000077_A); return ok }

func A_arbace_core_protocols_eval619000077_A_Cast(x any) *A_arbace_core_protocols_eval619000077_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000077_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000077_A_class)) }; return v }



type A_arbace_core_protocols_eval619000077_fn__619000078_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000077_fn__619000078_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000081_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000081_A_New() *A_arbace_core_protocols_eval619000081_A { t := &A_arbace_core_protocols_eval619000081_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000081_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000081_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000081_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000081_A_class }

func (t *A_arbace_core_protocols_eval619000081_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000081_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000081_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000081_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000081_A); return ok }

func A_arbace_core_protocols_eval619000081_A_Cast(x any) *A_arbace_core_protocols_eval619000081_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000081_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000081_A_class)) }; return v }



type A_arbace_core_protocols_eval619000081_fn__619000082_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000081_fn__619000082_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000085_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000085_A_New() *A_arbace_core_protocols_eval619000085_A { t := &A_arbace_core_protocols_eval619000085_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000085_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000085_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000085_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000085_A_class }

func (t *A_arbace_core_protocols_eval619000085_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000085_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000085_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000085_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000085_A); return ok }

func A_arbace_core_protocols_eval619000085_A_Cast(x any) *A_arbace_core_protocols_eval619000085_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000085_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000085_A_class)) }; return v }



type A_arbace_core_protocols_eval619000085_fn__619000086_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000085_fn__619000086_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000089_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000089_A_New() *A_arbace_core_protocols_eval619000089_A { t := &A_arbace_core_protocols_eval619000089_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000089_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000089_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000089_A_class }

func (t *A_arbace_core_protocols_eval619000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000089_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000089_A); return ok }

func A_arbace_core_protocols_eval619000089_A_Cast(x any) *A_arbace_core_protocols_eval619000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000089_A_class)) }; return v }



type A_arbace_core_protocols_eval619000089_fn__619000090_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000089_fn__619000090_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000093_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000093_A_New() *A_arbace_core_protocols_eval619000093_A { t := &A_arbace_core_protocols_eval619000093_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000093_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000093_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000093_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000093_A_class }

func (t *A_arbace_core_protocols_eval619000093_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000093_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000093_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000093_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000093_A); return ok }

func A_arbace_core_protocols_eval619000093_A_Cast(x any) *A_arbace_core_protocols_eval619000093_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000093_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000093_A_class)) }; return v }



type A_arbace_core_protocols_eval619000093_fn__619000094_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000093_fn__619000094_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A struct{ j2g_header uint64; F_f, F_none any }

var A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000099_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000099_A_New() *A_arbace_core_protocols_eval619000099_A { t := &A_arbace_core_protocols_eval619000099_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000099_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000099_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000099_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000099_A_class }

func (t *A_arbace_core_protocols_eval619000099_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000099_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000099_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000099_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000099_A); return ok }

func A_arbace_core_protocols_eval619000099_A_Cast(x any) *A_arbace_core_protocols_eval619000099_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000099_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000099_A_class)) }; return v }



type A_arbace_core_protocols_eval619000099_fn__619000100_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000099_fn__619000100_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000103_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000103_A_New() *A_arbace_core_protocols_eval619000103_A { t := &A_arbace_core_protocols_eval619000103_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000103_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000103_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000103_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000103_A_class }

func (t *A_arbace_core_protocols_eval619000103_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000103_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000103_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000103_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000103_A); return ok }

func A_arbace_core_protocols_eval619000103_A_Cast(x any) *A_arbace_core_protocols_eval619000103_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000103_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000103_A_class)) }; return v }



type A_arbace_core_protocols_eval619000103_fn__619000104_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000103_fn__619000104_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000107_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000107_A_New() *A_arbace_core_protocols_eval619000107_A { t := &A_arbace_core_protocols_eval619000107_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000107_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000107_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000107_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000107_A_class }

func (t *A_arbace_core_protocols_eval619000107_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000107_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000107_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000107_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000107_A); return ok }

func A_arbace_core_protocols_eval619000107_A_Cast(x any) *A_arbace_core_protocols_eval619000107_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000107_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000107_A_class)) }; return v }



type A_arbace_core_protocols_eval619000107_fn__619000108_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000107_fn__619000108_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000111_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000111_A_New() *A_arbace_core_protocols_eval619000111_A { t := &A_arbace_core_protocols_eval619000111_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000111_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000111_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000111_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000111_A_class }

func (t *A_arbace_core_protocols_eval619000111_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000111_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000111_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000111_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000111_A); return ok }

func A_arbace_core_protocols_eval619000111_A_Cast(x any) *A_arbace_core_protocols_eval619000111_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000111_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000111_A_class)) }; return v }



type A_arbace_core_protocols_eval619000111_fn__619000112_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000111_fn__619000112_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000115_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000115_A_New() *A_arbace_core_protocols_eval619000115_A { t := &A_arbace_core_protocols_eval619000115_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000115_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000115_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000115_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000115_A_class }

func (t *A_arbace_core_protocols_eval619000115_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000115_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000115_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000115_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000115_A); return ok }

func A_arbace_core_protocols_eval619000115_A_Cast(x any) *A_arbace_core_protocols_eval619000115_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000115_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000115_A_class)) }; return v }



type A_arbace_core_protocols_eval619000115_fn__619000116_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000115_fn__619000116_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000119_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000119_A_New() *A_arbace_core_protocols_eval619000119_A { t := &A_arbace_core_protocols_eval619000119_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000119_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000119_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000119_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000119_A_class }

func (t *A_arbace_core_protocols_eval619000119_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000119_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000119_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000119_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000119_A); return ok }

func A_arbace_core_protocols_eval619000119_A_Cast(x any) *A_arbace_core_protocols_eval619000119_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000119_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000119_A_class)) }; return v }



type A_arbace_core_protocols_eval619000119_fn__619000120_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000119_fn__619000120_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000123_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000123_A_New() *A_arbace_core_protocols_eval619000123_A { t := &A_arbace_core_protocols_eval619000123_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000123_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000123_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000123_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000123_A_class }

func (t *A_arbace_core_protocols_eval619000123_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000123_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000123_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000123_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000123_A); return ok }

func A_arbace_core_protocols_eval619000123_A_Cast(x any) *A_arbace_core_protocols_eval619000123_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000123_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000123_A_class)) }; return v }



type A_arbace_core_protocols_eval619000123_fn__619000124_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000123_fn__619000124_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000135_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000135_A_New() *A_arbace_core_protocols_eval619000135_A { t := &A_arbace_core_protocols_eval619000135_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000135_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000135_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000135_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000135_A_class }

func (t *A_arbace_core_protocols_eval619000135_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000135_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000135_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000135_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000135_A); return ok }

func A_arbace_core_protocols_eval619000135_A_Cast(x any) *A_arbace_core_protocols_eval619000135_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000135_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000135_A_class)) }; return v }



type A_arbace_core_protocols_eval619000135_fn__619000136_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000135_fn__619000136_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A struct{ j2g_header uint64; F_G__619000128 any }

var A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000161_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000161_A_New() *A_arbace_core_protocols_eval619000161_A { t := &A_arbace_core_protocols_eval619000161_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000161_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000161_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000161_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000161_A_class }

func (t *A_arbace_core_protocols_eval619000161_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000161_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000161_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000161_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000161_A); return ok }

func A_arbace_core_protocols_eval619000161_A_Cast(x any) *A_arbace_core_protocols_eval619000161_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000161_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000161_A_class)) }; return v }



type A_arbace_core_protocols_eval619000161_fn__619000162_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000161_fn__619000162_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A struct{ j2g_header uint64; F_G__619000154 any }

var A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000175_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000175_A_New() *A_arbace_core_protocols_eval619000175_A { t := &A_arbace_core_protocols_eval619000175_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000175_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000175_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000175_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000175_A_class }

func (t *A_arbace_core_protocols_eval619000175_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000175_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000175_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000175_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000175_A); return ok }

func A_arbace_core_protocols_eval619000175_A_Cast(x any) *A_arbace_core_protocols_eval619000175_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000175_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000175_A_class)) }; return v }



type A_arbace_core_protocols_eval619000175_fn__619000176_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000175_fn__619000176_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000179_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000179_A_New() *A_arbace_core_protocols_eval619000179_A { t := &A_arbace_core_protocols_eval619000179_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000179_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000179_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000179_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000179_A_class }

func (t *A_arbace_core_protocols_eval619000179_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000179_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000179_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000179_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000179_A); return ok }

func A_arbace_core_protocols_eval619000179_A_Cast(x any) *A_arbace_core_protocols_eval619000179_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000179_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000179_A_class)) }; return v }



type A_arbace_core_protocols_eval619000179_fn__619000180_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000179_fn__619000180_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000191_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000191_A_New() *A_arbace_core_protocols_eval619000191_A { t := &A_arbace_core_protocols_eval619000191_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000191_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000191_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000191_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000191_A_class }

func (t *A_arbace_core_protocols_eval619000191_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000191_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000191_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000191_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000191_A); return ok }

func A_arbace_core_protocols_eval619000191_A_Cast(x any) *A_arbace_core_protocols_eval619000191_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000191_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000191_A_class)) }; return v }



type A_arbace_core_protocols_eval619000191_fn__619000192_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000191_fn__619000192_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A struct{ j2g_header uint64; F_G__619000184 any }

var A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000209_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000209_A_New() *A_arbace_core_protocols_eval619000209_A { t := &A_arbace_core_protocols_eval619000209_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000209_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000209_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000209_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000209_A_class }

func (t *A_arbace_core_protocols_eval619000209_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000209_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000209_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000209_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000209_A); return ok }

func A_arbace_core_protocols_eval619000209_A_Cast(x any) *A_arbace_core_protocols_eval619000209_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000209_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000209_A_class)) }; return v }



type A_arbace_core_protocols_eval619000209_fn__619000210_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000209_fn__619000210_A_fn_class *jrt.Class



type A_arbace_core_protocols_interface_or_naive_reduce_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_interface_or_naive_reduce_A_fn_class *jrt.Class



type A_arbace_core_protocols_iter_reduce_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_iter_reduce_A_fn_class *jrt.Class



type A_arbace_core_protocols_iterator_reduce_BANG__A struct{ j2g_header uint64 }

var A_arbace_core_protocols_iterator_reduce_BANG__A_fn_class *jrt.Class



type A_arbace_core_protocols_naive_seq_reduce_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_naive_seq_reduce_A_fn_class *jrt.Class



type A_arbace_core_protocols_seq_reduce_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_seq_reduce_A_fn_class *jrt.Class
