//line aot_arbace_core_protocols.ae:1
package aot_arbace_core_protocols

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_New() *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_core_protocols_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_protocols_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_core_protocols_eval619000006_fn__619000007_A_New() *A_arbace_core_protocols_eval619000006_fn__619000007_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000006_fn__619000007_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_protocols_eval619000006_fn__619000007_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_protocols_eval619000006_fn__619000007_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_core_protocols_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_core_protocols_A_const_4), A_arbace_core_protocols_A_const_5.GetRawRoot__O(), A_arbace_core_protocols_A_const_6) }



func A_arbace_core_protocols_eval619000020_fn__619000021_A_New() *A_arbace_core_protocols_eval619000020_fn__619000021_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000020_fn__619000021_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_A) Ctor() {}
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_A) Invoke_O_O__O(self, cache__231000282__auto____1 any) any { var G__619000013__2_ any; var fnbody__18 any = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_New(); var tmp1 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, nil); A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_fn_class = fncls__17d; tmp1 = fncls__17d } else { tmp1 = fncls__17 }; G__619000013__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp1, nil); var f__231000283__auto____3 any; var fnbody__34 any = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_New_O(G__619000013__2_); var tmp2 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__34); A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_fn_class = fncls__33d; tmp2 = fncls__33d } else { tmp2 = fncls__33 }; f__231000283__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp2, nil); lang.AFunction_Cast(f__231000283__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000282__auto____1)); return f__231000283__auto____3 }
//line :13:1
func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_New_O(p0 any) *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A{}; t.Ctor_O(p0); return t }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) Ctor_O(c__G__619000013 any) { t.F_G__619000013 = c__G__619000013 }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) Invoke_O_O_O_O__O(self, gf__coll__619000031__1, gf__f__619000032__2, gf__val__619000033__3 any) any { var cache__231000280__auto____4 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000281__auto____5 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000280__auto____4)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__coll__619000031__1)); if jrt.J2g_Truth(f__231000281__auto____5) { return lang.IFn_Cast(f__231000281__auto____5).Invoke_O_O_O__O(gf__coll__619000031__1, gf__f__619000032__2, gf__val__619000033__3) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__coll__619000031__1, A_arbace_core_protocols_A_const_8, t.F_G__619000013)).Invoke_O_O_O__O(gf__coll__619000031__1, gf__f__619000032__2, gf__val__619000033__3) } }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A) Invoke_O_O_O__O(self, gf__coll__619000029__1, gf__f__619000030__2 any) any { var cache__231000280__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000281__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000280__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__coll__619000029__1)); if jrt.J2g_Truth(f__231000281__auto____4) { return lang.IFn_Cast(f__231000281__auto____4).Invoke_O_O__O(gf__coll__619000029__1, gf__f__619000030__2) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__coll__619000029__1, A_arbace_core_protocols_A_const_8, t.F_G__619000013)).Invoke_O_O__O(gf__coll__619000029__1, gf__f__619000030__2) } }
//line :13:1
func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_New() *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) Ctor() {}
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) Invoke_O_O_O_O__O(self, gf__coll__619000024__1, gf__f__619000025__2, gf__val__619000026__3 any) any { var target_15 any = gf__coll__619000024__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_15 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_15) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_15, Lit_3, jrt.RefArrayOf(jrt.Object_class, gf__f__619000025__2, gf__val__619000026__3)) } else { return A_arbace_core_protocols_CollReduce_A_Cast(target_15).Coll_reduce_O_O__O(gf__f__619000025__2, gf__val__619000026__3) } }
//line :13:1
func (t *A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A) Invoke_O_O_O__O(self, gf__coll__619000022__1, gf__f__619000023__2 any) any { var target_16 any = gf__coll__619000022__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_16 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_16) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_16, Lit_3, jrt.RefArrayOf(jrt.Object_class, gf__f__619000023__2)) } else { return A_arbace_core_protocols_CollReduce_A_Cast(target_16).Coll_reduce_O__O(gf__f__619000023__2) } }





func A_arbace_core_protocols_eval619000050_fn__619000051_A_New() *A_arbace_core_protocols_eval619000050_fn__619000051_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000050_fn__619000051_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_A) Ctor() {}
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_A) Invoke_O_O__O(self, cache__231000282__auto____1 any) any { var G__619000043__2_ any; var fnbody__37 any = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_New(); var tmp1 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_fn_class = fncls__36d; tmp1 = fncls__36d } else { tmp1 = fncls__36 }; G__619000043__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__37, tmp1, nil); var f__231000283__auto____3 any; var fnbody__46 any = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_New_O(G__619000043__2_); var tmp2 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__46); A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_fn_class = fncls__45d; tmp2 = fncls__45d } else { tmp2 = fncls__45 }; f__231000283__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp2, nil); lang.AFunction_Cast(f__231000283__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000282__auto____1)); return f__231000283__auto____3 }
//line :19:1
func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_New_O(p0 any) *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A{}; t.Ctor_O(p0); return t }
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A) Ctor_O(c__G__619000043 any) { t.F_G__619000043 = c__G__619000043 }
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A) Invoke_O_O_O_O__O(self, gf__seq__619000057__1, gf__f__619000058__2, gf__start__619000059__3 any) any { var cache__231000280__auto____4 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000281__auto____5 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000280__auto____4)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__seq__619000057__1)); if jrt.J2g_Truth(f__231000281__auto____5) { return lang.IFn_Cast(f__231000281__auto____5).Invoke_O_O_O__O(gf__seq__619000057__1, gf__f__619000058__2, gf__start__619000059__3) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__seq__619000057__1, A_arbace_core_protocols_A_const_9, t.F_G__619000043)).Invoke_O_O_O__O(gf__seq__619000057__1, gf__f__619000058__2, gf__start__619000059__3) } }
//line :19:1
func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_New() *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A) Ctor() {}
//line :19:1
func (t *A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A) Invoke_O_O_O_O__O(self, gf__seq__619000052__1, gf__f__619000053__2, gf__start__619000054__3 any) any { var target_35 any = gf__seq__619000052__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_35 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_35) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_35, Lit_6, jrt.RefArrayOf(jrt.Object_class, gf__f__619000053__2, gf__start__619000054__3)) } else { return A_arbace_core_protocols_InternalReduce_A_Cast(target_35).Internal_reduce_O_O__O(gf__f__619000053__2, gf__start__619000054__3) } }




func A_arbace_core_protocols_seq_reduce_A_New() *A_arbace_core_protocols_seq_reduce_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_seq_reduce_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_core_protocols_seq_reduce_A) Ctor() {}
//line :24:1
func (t *A_arbace_core_protocols_seq_reduce_A) Invoke_O_O_O_O__O(self, coll__0, f__1, val__2 any) any { var s__4 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_10.GetRawRoot__O()).Invoke_O__O(coll__0); var target_51 any = s__4; var tmp1 bool; var tmp2 bool; tmp2 =






	A_arbace_core_protocols_InternalReduce_A_InstanceOf(target_51); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_51) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_protocols_InternalReduce_A_Cast(target_51).Internal_reduce_O_O__O(f__1, val__2) } else { return lang.IFn_Cast(A_arbace_core_protocols_A_const_11.GetRawRoot__O()).Invoke_O_O_O__O(target_51, f__1, val__2) } }
//line :24:1
func (t *A_arbace_core_protocols_seq_reduce_A) Invoke_O_O_O__O(self, coll__0, f__1 any) any { var temp__1927000408__auto____3 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_10.GetRawRoot__O()).Invoke_O__O(coll__0); if

	jrt.J2g_Truth(temp__1927000408__auto____3) { var s__4 any = temp__1927000408__auto____3; var target_56 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_12.GetRawRoot__O()).Invoke_O__O(s__4); var tmp1 bool; var tmp2 bool
		tmp2 = A_arbace_core_protocols_InternalReduce_A_InstanceOf(target_56); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_56) }; tmp1 = tmp2; if tmp1 { return A_arbace_core_protocols_InternalReduce_A_Cast(target_56).Internal_reduce_O_O__O(f__1, lang.IFn_Cast(A_arbace_core_protocols_A_const_13.GetRawRoot__O()).Invoke_O__O(s__4)) } else { return lang.IFn_Cast(A_arbace_core_protocols_A_const_11.GetRawRoot__O()).Invoke_O_O_O__O(target_56, f__1, lang.IFn_Cast(A_arbace_core_protocols_A_const_13.GetRawRoot__O()).Invoke_O__O(s__4)) } } else {
			return lang.IFn_Cast(f__1).Invoke__O() } }





func A_arbace_core_protocols_iterator_reduce_BANG__A_New() *A_arbace_core_protocols_iterator_reduce_BANG__A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_iterator_reduce_BANG__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) Ctor() {}
//line :34:1
func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) Invoke_O_O_O_O__O(self, iter__0, f__1, val__2 any) any { { var ret__4 any = val__2; L1: for {






	if jrt.Iterator_Cast(iter__0).HasNext__Z() { var ret__5 any = lang.IFn_Cast(f__1).Invoke_O_O__O(ret__4, jrt.Iterator_Cast(iter__0).Next__O())

		if lang.RT_IsReduced_O__Z_NoInit(ret__5) { return lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(ret__5) } else {

			ret__4 = ret__5; continue L1 } } else {
//line :41:1
				return ret__4 } } }; /*line :34:1*/panic("j2g: unreachable") }
//line :34:1
func (t *A_arbace_core_protocols_iterator_reduce_BANG__A) Invoke_O_O_O__O(self, iter__0, f__1 any) any {

	if jrt.Iterator_Cast(iter__0).HasNext__Z() {
		var root_73 any = A_arbace_core_protocols_A_const_14.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, A_arbace_core_protocols_iterator_reduce_BANG__A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = iter__0; var arg_77 any = f__1; var arg_78 any = jrt.Iterator_Cast(iter__0).Next__O(); if linked_74 == nil { return ifn_75.Invoke_O_O_O__O(arg_76, arg_77, arg_78) } else { return linked_74.(*A_arbace_core_protocols_iterator_reduce_BANG__A).Invoke_O_O_O_O__O(root_73, arg_76, arg_77, arg_78) } } else {
			return lang.IFn_Cast(f__1).Invoke__O()
		}
}







func A_arbace_core_protocols_iter_reduce_A_New() *A_arbace_core_protocols_iter_reduce_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_iter_reduce_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_core_protocols_iter_reduce_A) Ctor() {}
//line :48:1
func (t *A_arbace_core_protocols_iter_reduce_A) Invoke_O_O_O_O__O(self, coll__0, f__1, val__2 any) any {



	var root_79 any = A_arbace_core_protocols_A_const_14.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, A_arbace_core_protocols_iterator_reduce_BANG__A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = jrt.Iterable_Cast(coll__0).Iterator__Iterator(); var arg_83 any = f__1; var arg_84 any = val__2; if linked_80 == nil { return ifn_81.Invoke_O_O_O__O(arg_82, arg_83, arg_84) } else { return linked_80.(*A_arbace_core_protocols_iterator_reduce_BANG__A).Invoke_O_O_O_O__O(root_79, arg_82, arg_83, arg_84) } }
//line :48:1
func (t *A_arbace_core_protocols_iter_reduce_A) Invoke_O_O_O__O(self, coll__0, f__1 any) any {

	var root_85 any = A_arbace_core_protocols_A_const_14.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, A_arbace_core_protocols_iterator_reduce_BANG__A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = jrt.Iterable_Cast(coll__0).Iterator__Iterator(); var arg_89 any = f__1; if linked_86 == nil { return ifn_87.Invoke_O_O__O(arg_88, arg_89) } else { return linked_86.(*A_arbace_core_protocols_iterator_reduce_BANG__A).Invoke_O_O_O__O(root_85, arg_88, arg_89)
	}
}

func A_arbace_core_protocols_naive_seq_reduce_A_New() *A_arbace_core_protocols_naive_seq_reduce_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_naive_seq_reduce_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_core_protocols_naive_seq_reduce_A) Ctor() {}
//line :54:1
func (t *A_arbace_core_protocols_naive_seq_reduce_A) Invoke_O_O_O_O__O(self, s__0, f__1, val__2 any) any { { var s__4 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_10.GetRawRoot__O()).Invoke_O__O(s__0); var val__5 any = val__2; L1: for {





	if jrt.J2g_Truth(s__4) { var ret__6 any = lang.IFn_Cast(f__1).Invoke_O_O__O(val__5, lang.IFn_Cast(A_arbace_core_protocols_A_const_13.GetRawRoot__O()).Invoke_O__O(s__4))

		if lang.RT_IsReduced_O__Z_NoInit(ret__6) { return lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(ret__6) } else {

			s__4, val__5 = lang.IFn_Cast(A_arbace_core_protocols_A_const_12.GetRawRoot__O()).Invoke_O__O(s__4), ret__6; continue L1 } } else {
//line :60:1
				return val__5 } } }; /*line :54:1*/panic("j2g: unreachable") }












func A_arbace_core_protocols_interface_or_naive_reduce_A_New() *A_arbace_core_protocols_interface_or_naive_reduce_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_interface_or_naive_reduce_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_core_protocols_interface_or_naive_reduce_A) Ctor() {}
//line :67:1
func (t *A_arbace_core_protocols_interface_or_naive_reduce_A) Invoke_O_O_O_O__O(self, coll__0, f__1, val__2 any) any {


	if lang.IReduceInit_InstanceOf(coll__0) {
		return lang.IReduceInit_Cast(coll__0).Reduce_IFn_O__O(lang.IFn_Cast(f__1), val__2) } else {
			var root_106 any = A_arbace_core_protocols_A_const_15.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, A_arbace_core_protocols_naive_seq_reduce_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = coll__0; var arg_110 any = f__1; var arg_111 any = val__2; if linked_107 == nil { return ifn_108.Invoke_O_O_O__O(arg_109, arg_110, arg_111) } else { return linked_107.(*A_arbace_core_protocols_naive_seq_reduce_A).Invoke_O_O_O_O__O(root_106, arg_109, arg_110, arg_111)
			} } }
func A_arbace_core_protocols_eval619000073_fn__619000074_A_New() *A_arbace_core_protocols_eval619000073_fn__619000074_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000073_fn__619000074_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any { return val__3 }
//line :74:1
func (t *A_arbace_core_protocols_eval619000073_fn__619000074_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {


	return lang.IFn_Cast(f__2).Invoke__O() }
//line :74:1
func A_arbace_core_protocols_eval619000077_fn__619000078_A_New() *A_arbace_core_protocols_eval619000077_fn__619000078_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000077_fn__619000078_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {








	var root_112 any = A_arbace_core_protocols_A_const_16.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, A_arbace_core_protocols_seq_reduce_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = coll__1; var arg_116 any = f__2; var arg_117 any = val__3; if linked_113 == nil { return ifn_114.Invoke_O_O_O__O(arg_115, arg_116, arg_117) } else { return linked_113.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O_O__O(root_112, arg_115, arg_116, arg_117) } }
//line :74:1
func (t *A_arbace_core_protocols_eval619000077_fn__619000078_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {







	var root_118 any = A_arbace_core_protocols_A_const_16.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, A_arbace_core_protocols_seq_reduce_A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = coll__1; var arg_122 any = f__2; if linked_119 == nil { return ifn_120.Invoke_O_O__O(arg_121, arg_122) } else { return linked_119.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O__O(root_118, arg_121, arg_122) } }
//line :74:1
func A_arbace_core_protocols_eval619000081_fn__619000082_A_New() *A_arbace_core_protocols_eval619000081_fn__619000082_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000081_fn__619000082_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {








































	var root_123 any = A_arbace_core_protocols_A_const_16.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, A_arbace_core_protocols_seq_reduce_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = coll__1; var arg_127 any = f__2; var arg_128 any = val__3; if linked_124 == nil { return ifn_125.Invoke_O_O_O__O(arg_126, arg_127, arg_128) } else { return linked_124.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O_O__O(root_123, arg_126, arg_127, arg_128) } }
//line :74:1
func (t *A_arbace_core_protocols_eval619000081_fn__619000082_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {







































	var root_129 any = A_arbace_core_protocols_A_const_16.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, A_arbace_core_protocols_seq_reduce_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = coll__1; var arg_133 any = f__2; if linked_130 == nil { return ifn_131.Invoke_O_O__O(arg_132, arg_133) } else { return linked_130.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O__O(root_129, arg_132, arg_133) } }
//line :74:1
func A_arbace_core_protocols_eval619000085_fn__619000086_A_New() *A_arbace_core_protocols_eval619000085_fn__619000086_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000085_fn__619000086_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {













































	var root_134 any = A_arbace_core_protocols_A_const_17.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, A_arbace_core_protocols_iter_reduce_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = coll__1; var arg_138 any = f__2; var arg_139 any = val__3; if linked_135 == nil { return ifn_136.Invoke_O_O_O__O(arg_137, arg_138, arg_139) } else { return linked_135.(*A_arbace_core_protocols_iter_reduce_A).Invoke_O_O_O_O__O(root_134, arg_137, arg_138, arg_139) } }
//line :74:1
func (t *A_arbace_core_protocols_eval619000085_fn__619000086_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {












































	var root_140 any = A_arbace_core_protocols_A_const_17.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, A_arbace_core_protocols_iter_reduce_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = coll__1; var arg_144 any = f__2; if linked_141 == nil { return ifn_142.Invoke_O_O__O(arg_143, arg_144) } else { return linked_141.(*A_arbace_core_protocols_iter_reduce_A).Invoke_O_O_O__O(root_140, arg_143, arg_144) } }
//line :74:1
func A_arbace_core_protocols_eval619000089_fn__619000090_A_New() *A_arbace_core_protocols_eval619000089_fn__619000090_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000089_fn__619000090_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {




























	var root_145 any = A_arbace_core_protocols_A_const_16.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, A_arbace_core_protocols_seq_reduce_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = coll__1; var arg_149 any = f__2; var arg_150 any = val__3; if linked_146 == nil { return ifn_147.Invoke_O_O_O__O(arg_148, arg_149, arg_150) } else { return linked_146.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O_O__O(root_145, arg_148, arg_149, arg_150) } }
//line :74:1
func (t *A_arbace_core_protocols_eval619000089_fn__619000090_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {



























	var root_151 any = A_arbace_core_protocols_A_const_16.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, A_arbace_core_protocols_seq_reduce_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = coll__1; var arg_155 any = f__2; if linked_152 == nil { return ifn_153.Invoke_O_O__O(arg_154, arg_155) } else { return linked_152.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O__O(root_151, arg_154, arg_155) } }
//line :74:1
func A_arbace_core_protocols_eval619000093_fn__619000094_A_New() *A_arbace_core_protocols_eval619000093_fn__619000094_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000093_fn__619000094_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {






















	return lang.IReduceInit_Cast(coll__1).Reduce_IFn_O__O(lang.IFn_Cast(f__2), val__3) }
//line :74:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {













	if lang.IReduce_InstanceOf(coll__1) {
		return lang.IReduce_Cast(coll__1).Reduce_IFn__O(lang.IFn_Cast(f__2)) } else {
//line :88:1
			var none__3 any = jrt.Object_New(); var ret__4 any; var tmp1 lang.IReduceInit = lang.IReduceInit_Cast(coll__1); var tmp2 *lang.Compiler_AOTFn; var fnbody__157 any = A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_New_O_O(f__2, none__3); var tmp3 *jrt.Class
			var fncls__156 /*line :88:1*/*jrt.Class = A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_fn_class





			if fncls__156 == nil { var fncls__156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__157); A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_fn_class = fncls__156d; tmp3 = fncls__156d } else { tmp3 = fncls__156 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__157, tmp3, nil)
//line :93:1
			ret__4 = tmp1.Reduce_IFn_O__O(Up_Compiler_AOTFn_IFn(tmp2), none__3)


			if lang.Util_Identical_O_O__Z_NoInit(ret__4, none__3) { return lang.IFn_Cast(f__2).Invoke__O() } else { return ret__4 } } }
//line :74:1
func A_arbace_core_protocols_eval619000099_fn__619000100_A_New() *A_arbace_core_protocols_eval619000099_fn__619000100_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000099_fn__619000100_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {


































	var root_158 any = A_arbace_core_protocols_A_const_16.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, A_arbace_core_protocols_seq_reduce_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = coll__1; var arg_162 any = f__2; var arg_163 any = val__3; if linked_159 == nil { return ifn_160.Invoke_O_O_O__O(arg_161, arg_162, arg_163) } else { return linked_159.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O_O__O(root_158, arg_161, arg_162, arg_163) } }
//line :74:1
func (t *A_arbace_core_protocols_eval619000099_fn__619000100_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {

































	var root_164 any = A_arbace_core_protocols_A_const_16.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, A_arbace_core_protocols_seq_reduce_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = coll__1; var arg_168 any = f__2; if linked_165 == nil { return ifn_166.Invoke_O_O__O(arg_167, arg_168) } else { return linked_165.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O__O(root_164, arg_167, arg_168) } }
//line :74:1
func A_arbace_core_protocols_eval619000103_fn__619000104_A_New() *A_arbace_core_protocols_eval619000103_fn__619000104_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000103_fn__619000104_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {


















































	var root_169 any = A_arbace_core_protocols_A_const_17.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, A_arbace_core_protocols_iter_reduce_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = coll__1; var arg_173 any = f__2; var arg_174 any = val__3; if linked_170 == nil { return ifn_171.Invoke_O_O_O__O(arg_172, arg_173, arg_174) } else { return linked_170.(*A_arbace_core_protocols_iter_reduce_A).Invoke_O_O_O_O__O(root_169, arg_172, arg_173, arg_174) } }
//line :74:1
func (t *A_arbace_core_protocols_eval619000103_fn__619000104_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {

















































	var root_175 any = A_arbace_core_protocols_A_const_17.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, A_arbace_core_protocols_iter_reduce_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = coll__1; var arg_179 any = f__2; if linked_176 == nil { return ifn_177.Invoke_O_O__O(arg_178, arg_179) } else { return linked_176.(*A_arbace_core_protocols_iter_reduce_A).Invoke_O_O_O__O(root_175, arg_178, arg_179) } }
//line :74:1
func A_arbace_core_protocols_eval619000107_fn__619000108_A_New() *A_arbace_core_protocols_eval619000107_fn__619000108_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000107_fn__619000108_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) Ctor() {}
//line :74:1
func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) Invoke_O_O_O_O__O(self, coll__1, f__2, val__3 any) any {























































	var root_180 any = A_arbace_core_protocols_A_const_17.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, A_arbace_core_protocols_iter_reduce_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = coll__1; var arg_184 any = f__2; var arg_185 any = val__3; if linked_181 == nil { return ifn_182.Invoke_O_O_O__O(arg_183, arg_184, arg_185) } else { return linked_181.(*A_arbace_core_protocols_iter_reduce_A).Invoke_O_O_O_O__O(root_180, arg_183, arg_184, arg_185) } }
//line :74:1
func (t *A_arbace_core_protocols_eval619000107_fn__619000108_A) Invoke_O_O_O__O(self, coll__1, f__2 any) any {






















































	var root_186 any = A_arbace_core_protocols_A_const_17.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, A_arbace_core_protocols_iter_reduce_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = coll__1; var arg_190 any = f__2; if linked_187 == nil { return ifn_188.Invoke_O_O__O(arg_189, arg_190) } else { return linked_187.(*A_arbace_core_protocols_iter_reduce_A).Invoke_O_O_O__O(root_186, arg_189, arg_190) } }
//line :94:1
func A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_New_O_O(p0, p1 any) *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A{}; t.Ctor_O_O(p0, p1); return t }
//line :94:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A) Ctor_O_O(c__f, c__none any) { t.F_f = c__f; t.F_none = c__none }
//line :94:1
func (t *A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A) Invoke_O_O_O__O(self, acc__1, x__2 any) any { if lang.Util_Identical_O_O__Z_NoInit(acc__1, t.F_none) { return x__2 } else { return lang.IFn_Cast(t.F_f).Invoke_O_O__O(acc__1, x__2) } }





































func A_arbace_core_protocols_eval619000111_fn__619000112_A_New() *A_arbace_core_protocols_eval619000111_fn__619000112_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000111_fn__619000112_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_core_protocols_eval619000111_fn__619000112_A) Ctor() {}
//line :132:1
func (t *A_arbace_core_protocols_eval619000111_fn__619000112_A) Invoke_O_O_O_O__O(self, s__1, f__2, val__3 any) any { return val__3 }
//line :132:1
func A_arbace_core_protocols_eval619000115_fn__619000116_A_New() *A_arbace_core_protocols_eval619000115_fn__619000116_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000115_fn__619000116_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_core_protocols_eval619000115_fn__619000116_A) Ctor() {}
//line :132:1
func (t *A_arbace_core_protocols_eval619000115_fn__619000116_A) Invoke_O_O_O_O__O(self, s__1, f__2, val__3 any) any { { var s__1_2 any = s__1; var f__2_2 any = f__2; var val__3_2 any = val__3; L1: for { var temp__1927000408__auto____4 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_10.GetRawRoot__O()).Invoke_O__O(s__1_2)









	if jrt.J2g_Truth(temp__1927000408__auto____4) { var s__5 any = temp__1927000408__auto____4
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_protocols_A_const_18.GetRawRoot__O()).Invoke_O__O(s__5)) { var ret__6 any = lang.IChunk_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_19.GetRawRoot__O()).Invoke_O__O(s__5)).Reduce_IFn_O__O(lang.IFn_Cast(f__2_2), val__3_2)

			if lang.RT_IsReduced_O__Z_NoInit(ret__6) { return lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(ret__6) } else {

				s__1_2, f__2_2, val__3_2 = lang.IFn_Cast(A_arbace_core_protocols_A_const_21.GetRawRoot__O()).Invoke_O__O(s__5), f__2_2, ret__6; continue L1 } } else {


					var root_207 any = A_arbace_core_protocols_A_const_20.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, A_arbace_core_protocols_interface_or_naive_reduce_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = s__5; var arg_211 any = f__2_2; var arg_212 any = val__3_2; if linked_208 == nil { return ifn_209.Invoke_O_O_O__O(arg_210, arg_211, arg_212) } else { return linked_208.(*A_arbace_core_protocols_interface_or_naive_reduce_A).Invoke_O_O_O_O__O(root_207, arg_210, arg_211, arg_212) } } } else {
//line :142:1
						return val__3_2 } } }; /*line :132:1*/panic("j2g: unreachable") }
//line :132:1
func A_arbace_core_protocols_eval619000119_fn__619000120_A_New() *A_arbace_core_protocols_eval619000119_fn__619000120_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000119_fn__619000120_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_core_protocols_eval619000119_fn__619000120_A) Ctor() {}
//line :132:1
func (t *A_arbace_core_protocols_eval619000119_fn__619000120_A) Invoke_O_O_O_O__O(self, str_seq__1, f__2, val__3 any) any { { var s__4 any = lang.StringSeq_Cast(str_seq__1).F_s; var len__5 int32 = jrt.CharSequence_Cast(s__4).Length__I(); var i__6 int64 = lang.RT_LongCast_I__J_NoInit(lang.StringSeq_Cast(str_seq__1).F_i); var val__7 any = val__3; L1: for {



























	if lang.Numbers_Lt_J_J__Z_NoInit(i__6, int64(len__5)) { var ret__8 any = lang.IFn_Cast(f__2).Invoke_O_O__O(val__7, jrt.Character_ValueOf_C__Character_NoInit(jrt.CharSequence_Cast(s__4).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__6))).Ref())

		if lang.RT_IsReduced_O__Z_NoInit(ret__8) { return lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(ret__8) } else {

			i__6, val__7 = lang.Numbers_Inc_J__J_NoInit(i__6), ret__8; continue L1 } } else {
//line :160:1
				return val__7 } } }; /*line :132:1*/panic("j2g: unreachable") }
//line :132:1
func A_arbace_core_protocols_eval619000123_fn__619000124_A_New() *A_arbace_core_protocols_eval619000123_fn__619000124_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000123_fn__619000124_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_core_protocols_eval619000123_fn__619000124_A) Ctor() {}
//line :132:1
func (t *A_arbace_core_protocols_eval619000123_fn__619000124_A) Invoke_O_O_O_O__O(self, s__1, f__2, val__3 any) any { { var cls__4 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_22.GetRawRoot__O()).Invoke_O__O(s__1); var s__5 any = s__1; var f__6 any = f__2; var val__7 any = val__3; L1: for { var temp__1927000408__auto____8 any = lang.IFn_Cast(A_arbace_core_protocols_A_const_10.GetRawRoot__O()).Invoke_O__O(s__5)









































	if jrt.J2g_Truth(temp__1927000408__auto____8) { var s__9 any = temp__1927000408__auto____8
		if lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_core_protocols_A_const_22.GetRawRoot__O()).Invoke_O__O(s__9), cls__4) { var ret__10 any = lang.IFn_Cast(f__6).Invoke_O_O__O(val__7, lang.IFn_Cast(A_arbace_core_protocols_A_const_13.GetRawRoot__O()).Invoke_O__O(s__9))

			if lang.RT_IsReduced_O__Z_NoInit(ret__10) { return lang.IFn_Cast(A_arbace_core_protocols_A_const_3.GetRawRoot__O()).Invoke_O__O(ret__10) } else {

				cls__4, s__5, f__6, val__7 = cls__4, lang.IFn_Cast(A_arbace_core_protocols_A_const_12.GetRawRoot__O()).Invoke_O__O(s__9), f__6, ret__10; continue L1 } } else {
					var root_237 any = A_arbace_core_protocols_A_const_20.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, A_arbace_core_protocols_interface_or_naive_reduce_A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = s__9; var arg_241 any = f__6; var arg_242 any = val__7; if linked_238 == nil { return ifn_239.Invoke_O_O_O__O(arg_240, arg_241, arg_242) } else { return linked_238.(*A_arbace_core_protocols_interface_or_naive_reduce_A).Invoke_O_O_O_O__O(root_237, arg_240, arg_241, arg_242) } } } else {
//line :174:1
						return val__7 } } }; /*line :132:1*/panic("j2g: unreachable") }


















































func A_arbace_core_protocols_eval619000135_fn__619000136_A_New() *A_arbace_core_protocols_eval619000135_fn__619000136_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000135_fn__619000136_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_A) Ctor() {}
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_A) Invoke_O_O__O(self, cache__231000282__auto____1 any) any { var G__619000128__2_ any; var fnbody__253 any = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_New(); var tmp1 *jrt.Class; var fncls__252 *jrt.Class = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_fn_class; if fncls__252 == nil { var fncls__252d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, nil); A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_fn_class = fncls__252d; tmp1 = fncls__252d } else { tmp1 = fncls__252 }; G__619000128__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__253, tmp1, nil); var f__231000283__auto____3 any; var fnbody__262 any = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_New_O(G__619000128__2_); var tmp2 *jrt.Class; var fncls__261 *jrt.Class = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_fn_class; if fncls__261 == nil { var fncls__261d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__262); A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_fn_class = fncls__261d; tmp2 = fncls__261d } else { tmp2 = fncls__261 }; f__231000283__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__262, tmp2, nil); lang.AFunction_Cast(f__231000283__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000282__auto____1)); return f__231000283__auto____3 }
//line :183:1
func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_New_O(p0 any) *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A{}; t.Ctor_O(p0); return t }
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A) Ctor_O(c__G__619000128 any) { t.F_G__619000128 = c__G__619000128 }
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A) Invoke_O_O_O_O__O(self, gf__amap__619000142__1, gf__f__619000143__2, gf__init__619000144__3 any) any { var cache__231000280__auto____4 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000281__auto____5 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000280__auto____4)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__amap__619000142__1)); if jrt.J2g_Truth(f__231000281__auto____5) { return lang.IFn_Cast(f__231000281__auto____5).Invoke_O_O_O__O(gf__amap__619000142__1, gf__f__619000143__2, gf__init__619000144__3) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__amap__619000142__1, A_arbace_core_protocols_A_const_23, t.F_G__619000128)).Invoke_O_O_O__O(gf__amap__619000142__1, gf__f__619000143__2, gf__init__619000144__3) } }
//line :183:1
func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_New() *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A) Ctor() {}
//line :183:1
func (t *A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A) Invoke_O_O_O_O__O(self, gf__amap__619000137__1, gf__f__619000138__2, gf__init__619000139__3 any) any { var target_251 any = gf__amap__619000137__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_251 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_251) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_251, Lit_10, jrt.RefArrayOf(jrt.Object_class, gf__f__619000138__2, gf__init__619000139__3)) } else { return A_arbace_core_protocols_IKVReduce_A_Cast(target_251).Kv_reduce_O_O__O(gf__f__619000138__2, gf__init__619000139__3) } }






func A_arbace_core_protocols_eval619000161_fn__619000162_A_New() *A_arbace_core_protocols_eval619000161_fn__619000162_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000161_fn__619000162_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_A) Ctor() {}
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_A) Invoke_O_O__O(self, cache__231000282__auto____1 any) any { var G__619000154__2_ any; var fnbody__265 any = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_New(); var tmp1 *jrt.Class; var fncls__264 *jrt.Class = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_fn_class; if fncls__264 == nil { var fncls__264d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, nil); A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_fn_class = fncls__264d; tmp1 = fncls__264d } else { tmp1 = fncls__264 }; G__619000154__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__265, tmp1, nil); var f__231000283__auto____3 any; var fnbody__274 any = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_New_O(G__619000154__2_); var tmp2 *jrt.Class; var fncls__273 *jrt.Class = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_fn_class; if fncls__273 == nil { var fncls__273d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__274); A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_fn_class = fncls__273d; tmp2 = fncls__273d } else { tmp2 = fncls__273 }; f__231000283__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__274, tmp2, nil); lang.AFunction_Cast(f__231000283__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000282__auto____1)); return f__231000283__auto____3 }
//line :190:1
func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_New_O(p0 any) *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A{}; t.Ctor_O(p0); return t }
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A) Ctor_O(c__G__619000154 any) { t.F_G__619000154 = c__G__619000154 }
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A) Invoke_O_O__O(self, gf__o__619000166__1 any) any { var cache__231000276__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000277__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000276__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__o__619000166__1)); if lang.Util_Identical_O_O__Z_NoInit(f__231000277__auto____3, t.F_G__619000154) { return lang.IFn_Cast(f__231000277__auto____3).Invoke_O__O(gf__o__619000166__1) } else { var temp__1927000408__auto____4 any; var temp__1927000414__auto____4 any = lang.RT_Meta_O__IPersistentMap_NoInit(gf__o__619000166__1); if jrt.J2g_Truth(temp__1927000414__auto____4) { var m__231000279__auto____5 any = temp__1927000414__auto____4; temp__1927000408__auto____4 = Up_Symbol_IFn(lang.MethodImplCache_Cast(cache__231000276__auto____2).F_sym).Invoke_O__O(m__231000279__auto____5) } else { temp__1927000408__auto____4 = nil }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var meta__231000278__auto____5 any = temp__1927000408__auto____4; return lang.IFn_Cast(meta__231000278__auto____5).Invoke_O__O(gf__o__619000166__1) } else { if jrt.J2g_Truth(f__231000277__auto____3) { return lang.IFn_Cast(f__231000277__auto____3).Invoke_O__O(gf__o__619000166__1) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__o__619000166__1, A_arbace_core_protocols_A_const_24, t.F_G__619000154)).Invoke_O__O(gf__o__619000166__1) } } } }
//line :190:1
func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_New() *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A) Ctor() {}
//line :190:1
func (t *A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A) Invoke_O_O__O(self, gf__o__619000163__1 any) any { var target_263 any = gf__o__619000163__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_263 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_263) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_263, Lit_13, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_core_protocols_Datafiable_A_Cast(target_263).Datafy__O() } }




func A_arbace_core_protocols_eval619000175_fn__619000176_A_New() *A_arbace_core_protocols_eval619000175_fn__619000176_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000175_fn__619000176_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_core_protocols_eval619000175_fn__619000176_A) Ctor() {}
//line :195:1
func (t *A_arbace_core_protocols_eval619000175_fn__619000176_A) Invoke_O_O__O(self, ___1 any) any { return nil }
//line :195:1
func A_arbace_core_protocols_eval619000179_fn__619000180_A_New() *A_arbace_core_protocols_eval619000179_fn__619000180_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000179_fn__619000180_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_core_protocols_eval619000179_fn__619000180_A) Ctor() {}
//line :195:1
func (t *A_arbace_core_protocols_eval619000179_fn__619000180_A) Invoke_O_O__O(self, x__1 any) any { return x__1 }






func A_arbace_core_protocols_eval619000191_fn__619000192_A_New() *A_arbace_core_protocols_eval619000191_fn__619000192_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000191_fn__619000192_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_A) Ctor() {}
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_A) Invoke_O_O__O(self, cache__231000282__auto____1 any) any { var G__619000184__2_ any; var fnbody__277 any = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_New(); var tmp1 *jrt.Class; var fncls__276 *jrt.Class = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_fn_class; if fncls__276 == nil { var fncls__276d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, nil); A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_fn_class = fncls__276d; tmp1 = fncls__276d } else { tmp1 = fncls__276 }; G__619000184__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__277, tmp1, nil); var f__231000283__auto____3 any; var fnbody__286 any = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_New_O(G__619000184__2_); var tmp2 *jrt.Class; var fncls__285 *jrt.Class = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_fn_class; if fncls__285 == nil { var fncls__285d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, fnbody__286); A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_fn_class = fncls__285d; tmp2 = fncls__285d } else { tmp2 = fncls__285 }; f__231000283__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__286, tmp2, nil); lang.AFunction_Cast(f__231000283__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000282__auto____1)); return f__231000283__auto____3 }
//line :202:1
func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_New_O(p0 any) *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A) Ctor_O(c__G__619000184 any) { t.F_G__619000184 = c__G__619000184 }
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A) Invoke_O_O_O_O__O(self, gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3 any) any { var cache__231000276__auto____4 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000277__auto____5 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000276__auto____4)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__coll__619000198__1)); if lang.Util_Identical_O_O__Z_NoInit(f__231000277__auto____5, t.F_G__619000184) { return lang.IFn_Cast(f__231000277__auto____5).Invoke_O_O_O__O(gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3) } else { var temp__1927000408__auto____6 any; var temp__1927000414__auto____6 any = lang.RT_Meta_O__IPersistentMap_NoInit(gf__coll__619000198__1); if jrt.J2g_Truth(temp__1927000414__auto____6) { var m__231000279__auto____7 any = temp__1927000414__auto____6; temp__1927000408__auto____6 = Up_Symbol_IFn(lang.MethodImplCache_Cast(cache__231000276__auto____4).F_sym).Invoke_O__O(m__231000279__auto____7) } else { temp__1927000408__auto____6 = nil }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var meta__231000278__auto____7 any = temp__1927000408__auto____6; return lang.IFn_Cast(meta__231000278__auto____7).Invoke_O_O_O__O(gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3) } else { if jrt.J2g_Truth(f__231000277__auto____5) { return lang.IFn_Cast(f__231000277__auto____5).Invoke_O_O_O__O(gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_core_protocols_A_const_7.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__coll__619000198__1, A_arbace_core_protocols_A_const_25, t.F_G__619000184)).Invoke_O_O_O__O(gf__coll__619000198__1, gf__k__619000199__2, gf__v__619000200__3) } } } }
//line :202:1
func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_New() *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A) Ctor() {}
//line :202:1
func (t *A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A) Invoke_O_O_O_O__O(self, gf__coll__619000193__1, gf__k__619000194__2, gf__v__619000195__3 any) any { var target_275 any = gf__coll__619000193__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_275 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_275) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_275, Lit_16, jrt.RefArrayOf(jrt.Object_class, gf__k__619000194__2, gf__v__619000195__3)) } else { return A_arbace_core_protocols_Navigable_A_Cast(target_275).Nav_O_O__O(gf__k__619000194__2, gf__v__619000195__3) } }





func A_arbace_core_protocols_eval619000209_fn__619000210_A_New() *A_arbace_core_protocols_eval619000209_fn__619000210_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_eval619000209_fn__619000210_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_core_protocols_eval619000209_fn__619000210_A) Ctor() {}
//line :208:1
func (t *A_arbace_core_protocols_eval619000209_fn__619000210_A) Invoke_O_O_O_O__O(self, ___1, ___2, x__3 any) any { return x__3 }
































































type A_arbace_core_protocols_A struct{ jrt.Object }

var A_arbace_core_protocols_A_const_pool *jrt.RefArray

var A_arbace_core_protocols_A_const_0 *lang.Var

var A_arbace_core_protocols_A_const_1 any

var A_arbace_core_protocols_A_const_2 *lang.Var

var A_arbace_core_protocols_A_const_3 *lang.Var

var A_arbace_core_protocols_A_const_4 *lang.Var

var A_arbace_core_protocols_A_const_5 *lang.Var

var A_arbace_core_protocols_A_const_6 any

var A_arbace_core_protocols_A_const_7 *lang.Var

var A_arbace_core_protocols_A_const_8 *jrt.Class

var A_arbace_core_protocols_A_const_9 *jrt.Class

var A_arbace_core_protocols_A_const_10 *lang.Var

var A_arbace_core_protocols_A_const_11 *lang.Var

var A_arbace_core_protocols_A_const_12 *lang.Var

var A_arbace_core_protocols_A_const_13 *lang.Var

var A_arbace_core_protocols_A_const_14 *lang.Var

var A_arbace_core_protocols_A_const_15 *lang.Var

var A_arbace_core_protocols_A_const_16 *lang.Var

var A_arbace_core_protocols_A_const_17 *lang.Var

var A_arbace_core_protocols_A_const_18 *lang.Var

var A_arbace_core_protocols_A_const_19 *lang.Var

var A_arbace_core_protocols_A_const_20 *lang.Var

var A_arbace_core_protocols_A_const_21 *lang.Var

var A_arbace_core_protocols_A_const_22 *lang.Var

var A_arbace_core_protocols_A_const_23 *jrt.Class

var A_arbace_core_protocols_A_const_24 *jrt.Class

var A_arbace_core_protocols_A_const_25 *jrt.Class

var A_arbace_core_protocols_A_init jrt.ClassInit

func A_arbace_core_protocols_A_Init() { if !A_arbace_core_protocols_A_init.Done() { A_arbace_core_protocols_A_init.Run(A_arbace_core_protocols_A_clinit) } }

func A_arbace_core_protocols_A_clinit() { A_arbace_core_protocols_A_clinit_p0(); A_arbace_core_protocols_A_clinit_p1(); A_arbace_core_protocols_A_clinit_p2() }

func A_arbace_core_protocols_A_clinit_p0() { jrt.StartCheck(); A_arbace_core_protocols_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 28); A_arbace_core_protocols_A_const_0 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[2]); A_arbace_core_protocols_A_const_1 = A_arbace_core_protocols_A_const_pool.A[3]; A_arbace_core_protocols_A_const_2 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[4]); A_arbace_core_protocols_A_const_3 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[5]); A_arbace_core_protocols_A_const_4 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[6]); A_arbace_core_protocols_A_const_5 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[7]); A_arbace_core_protocols_A_const_6 = A_arbace_core_protocols_A_const_pool.A[8]; A_arbace_core_protocols_A_const_7 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[9]); A_arbace_core_protocols_A_const_8 = jrt.Class_Cast(A_arbace_core_protocols_A_const_pool.A[10]); A_arbace_core_protocols_A_const_9 = jrt.Class_Cast(A_arbace_core_protocols_A_const_pool.A[11]); A_arbace_core_protocols_A_const_10 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[12]) }

func A_arbace_core_protocols_A_clinit_p1() { A_arbace_core_protocols_A_const_11 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[13]); A_arbace_core_protocols_A_const_12 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[14]); A_arbace_core_protocols_A_const_13 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[15]); A_arbace_core_protocols_A_const_14 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[16]); A_arbace_core_protocols_A_const_15 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[17]); A_arbace_core_protocols_A_const_16 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[18]); A_arbace_core_protocols_A_const_17 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[19]); A_arbace_core_protocols_A_const_18 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[20]); A_arbace_core_protocols_A_const_19 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[21]); A_arbace_core_protocols_A_const_20 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[22]); A_arbace_core_protocols_A_const_21 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[23]); A_arbace_core_protocols_A_const_22 = lang.Var_Cast(A_arbace_core_protocols_A_const_pool.A[24]) }

func A_arbace_core_protocols_A_clinit_p2() { A_arbace_core_protocols_A_const_23 = jrt.Class_Cast(A_arbace_core_protocols_A_const_pool.A[25]); A_arbace_core_protocols_A_const_24 = jrt.Class_Cast(A_arbace_core_protocols_A_const_pool.A[26]); A_arbace_core_protocols_A_const_25 = jrt.Class_Cast(A_arbace_core_protocols_A_const_pool.A[27]) }

func A_arbace_core_protocols_A_New() *A_arbace_core_protocols_A { A_arbace_core_protocols_A_Init(); t := &A_arbace_core_protocols_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_A) Ctor() {}

func (t *A_arbace_core_protocols_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_A_class }

func (t *A_arbace_core_protocols_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_A); return ok }

func A_arbace_core_protocols_A_Cast(x any) *A_arbace_core_protocols_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_A_class)) }; return v }



type A_arbace_core_protocols_eval619000002_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000002_A_New() *A_arbace_core_protocols_eval619000002_A { t := &A_arbace_core_protocols_eval619000002_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000002_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000002_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000002_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000002_A_class }

func (t *A_arbace_core_protocols_eval619000002_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000002_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000002_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000002_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000002_A); return ok }

func A_arbace_core_protocols_eval619000002_A_Cast(x any) *A_arbace_core_protocols_eval619000002_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000002_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000002_A_class)) }; return v }



type A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000006_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000006_A_New() *A_arbace_core_protocols_eval619000006_A { t := &A_arbace_core_protocols_eval619000006_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000006_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000006_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000006_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000006_A_class }

func (t *A_arbace_core_protocols_eval619000006_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000006_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000006_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000006_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000006_A); return ok }

func A_arbace_core_protocols_eval619000006_A_Cast(x any) *A_arbace_core_protocols_eval619000006_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000006_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000006_A_class)) }; return v }



type A_arbace_core_protocols_eval619000006_fn__619000007_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000006_fn__619000007_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000020_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000020_A_New() *A_arbace_core_protocols_eval619000020_A { t := &A_arbace_core_protocols_eval619000020_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000020_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000020_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000020_A_class }

func (t *A_arbace_core_protocols_eval619000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000020_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000020_A); return ok }

func A_arbace_core_protocols_eval619000020_A_Cast(x any) *A_arbace_core_protocols_eval619000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000020_A_class)) }; return v }



type A_arbace_core_protocols_eval619000020_fn__619000021_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000020_fn__619000021_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A struct{ j2g_header uint64; F_G__619000013 any }

var A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000050_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000050_A_New() *A_arbace_core_protocols_eval619000050_A { t := &A_arbace_core_protocols_eval619000050_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000050_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000050_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000050_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000050_A_class }

func (t *A_arbace_core_protocols_eval619000050_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000050_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000050_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000050_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000050_A); return ok }

func A_arbace_core_protocols_eval619000050_A_Cast(x any) *A_arbace_core_protocols_eval619000050_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000050_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000050_A_class)) }; return v }



type A_arbace_core_protocols_eval619000050_fn__619000051_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000050_fn__619000051_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A struct{ j2g_header uint64; F_G__619000043 any }

var A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000073_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000073_A_New() *A_arbace_core_protocols_eval619000073_A { t := &A_arbace_core_protocols_eval619000073_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000073_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000073_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000073_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000073_A_class }

func (t *A_arbace_core_protocols_eval619000073_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000073_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000073_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000073_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000073_A); return ok }

func A_arbace_core_protocols_eval619000073_A_Cast(x any) *A_arbace_core_protocols_eval619000073_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000073_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000073_A_class)) }; return v }



type A_arbace_core_protocols_eval619000073_fn__619000074_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000073_fn__619000074_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000077_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000077_A_New() *A_arbace_core_protocols_eval619000077_A { t := &A_arbace_core_protocols_eval619000077_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000077_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000077_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000077_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000077_A_class }

func (t *A_arbace_core_protocols_eval619000077_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000077_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000077_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000077_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000077_A); return ok }

func A_arbace_core_protocols_eval619000077_A_Cast(x any) *A_arbace_core_protocols_eval619000077_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000077_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000077_A_class)) }; return v }



type A_arbace_core_protocols_eval619000077_fn__619000078_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000077_fn__619000078_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000081_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000081_A_New() *A_arbace_core_protocols_eval619000081_A { t := &A_arbace_core_protocols_eval619000081_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000081_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000081_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000081_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000081_A_class }

func (t *A_arbace_core_protocols_eval619000081_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000081_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000081_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000081_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000081_A); return ok }

func A_arbace_core_protocols_eval619000081_A_Cast(x any) *A_arbace_core_protocols_eval619000081_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000081_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000081_A_class)) }; return v }



type A_arbace_core_protocols_eval619000081_fn__619000082_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000081_fn__619000082_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000085_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000085_A_New() *A_arbace_core_protocols_eval619000085_A { t := &A_arbace_core_protocols_eval619000085_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000085_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000085_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000085_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000085_A_class }

func (t *A_arbace_core_protocols_eval619000085_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000085_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000085_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000085_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000085_A); return ok }

func A_arbace_core_protocols_eval619000085_A_Cast(x any) *A_arbace_core_protocols_eval619000085_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000085_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000085_A_class)) }; return v }



type A_arbace_core_protocols_eval619000085_fn__619000086_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000085_fn__619000086_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000089_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000089_A_New() *A_arbace_core_protocols_eval619000089_A { t := &A_arbace_core_protocols_eval619000089_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000089_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000089_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000089_A_class }

func (t *A_arbace_core_protocols_eval619000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000089_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000089_A); return ok }

func A_arbace_core_protocols_eval619000089_A_Cast(x any) *A_arbace_core_protocols_eval619000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000089_A_class)) }; return v }



type A_arbace_core_protocols_eval619000089_fn__619000090_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000089_fn__619000090_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000093_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000093_A_New() *A_arbace_core_protocols_eval619000093_A { t := &A_arbace_core_protocols_eval619000093_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000093_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000093_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000093_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000093_A_class }

func (t *A_arbace_core_protocols_eval619000093_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000093_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000093_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000093_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000093_A); return ok }

func A_arbace_core_protocols_eval619000093_A_Cast(x any) *A_arbace_core_protocols_eval619000093_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000093_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000093_A_class)) }; return v }



type A_arbace_core_protocols_eval619000093_fn__619000094_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000093_fn__619000094_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A struct{ j2g_header uint64; F_f, F_none any }

var A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000099_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000099_A_New() *A_arbace_core_protocols_eval619000099_A { t := &A_arbace_core_protocols_eval619000099_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000099_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000099_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000099_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000099_A_class }

func (t *A_arbace_core_protocols_eval619000099_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000099_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000099_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000099_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000099_A); return ok }

func A_arbace_core_protocols_eval619000099_A_Cast(x any) *A_arbace_core_protocols_eval619000099_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000099_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000099_A_class)) }; return v }



type A_arbace_core_protocols_eval619000099_fn__619000100_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000099_fn__619000100_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000103_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000103_A_New() *A_arbace_core_protocols_eval619000103_A { t := &A_arbace_core_protocols_eval619000103_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000103_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000103_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000103_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000103_A_class }

func (t *A_arbace_core_protocols_eval619000103_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000103_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000103_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000103_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000103_A); return ok }

func A_arbace_core_protocols_eval619000103_A_Cast(x any) *A_arbace_core_protocols_eval619000103_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000103_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000103_A_class)) }; return v }



type A_arbace_core_protocols_eval619000103_fn__619000104_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000103_fn__619000104_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000107_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000107_A_New() *A_arbace_core_protocols_eval619000107_A { t := &A_arbace_core_protocols_eval619000107_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000107_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000107_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000107_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000107_A_class }

func (t *A_arbace_core_protocols_eval619000107_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000107_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000107_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000107_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000107_A); return ok }

func A_arbace_core_protocols_eval619000107_A_Cast(x any) *A_arbace_core_protocols_eval619000107_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000107_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000107_A_class)) }; return v }



type A_arbace_core_protocols_eval619000107_fn__619000108_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000107_fn__619000108_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000111_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000111_A_New() *A_arbace_core_protocols_eval619000111_A { t := &A_arbace_core_protocols_eval619000111_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000111_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000111_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000111_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000111_A_class }

func (t *A_arbace_core_protocols_eval619000111_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000111_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000111_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000111_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000111_A); return ok }

func A_arbace_core_protocols_eval619000111_A_Cast(x any) *A_arbace_core_protocols_eval619000111_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000111_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000111_A_class)) }; return v }



type A_arbace_core_protocols_eval619000111_fn__619000112_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000111_fn__619000112_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000115_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000115_A_New() *A_arbace_core_protocols_eval619000115_A { t := &A_arbace_core_protocols_eval619000115_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000115_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000115_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000115_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000115_A_class }

func (t *A_arbace_core_protocols_eval619000115_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000115_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000115_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000115_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000115_A); return ok }

func A_arbace_core_protocols_eval619000115_A_Cast(x any) *A_arbace_core_protocols_eval619000115_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000115_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000115_A_class)) }; return v }



type A_arbace_core_protocols_eval619000115_fn__619000116_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000115_fn__619000116_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000119_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000119_A_New() *A_arbace_core_protocols_eval619000119_A { t := &A_arbace_core_protocols_eval619000119_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000119_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000119_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000119_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000119_A_class }

func (t *A_arbace_core_protocols_eval619000119_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000119_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000119_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000119_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000119_A); return ok }

func A_arbace_core_protocols_eval619000119_A_Cast(x any) *A_arbace_core_protocols_eval619000119_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000119_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000119_A_class)) }; return v }



type A_arbace_core_protocols_eval619000119_fn__619000120_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000119_fn__619000120_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000123_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000123_A_New() *A_arbace_core_protocols_eval619000123_A { t := &A_arbace_core_protocols_eval619000123_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000123_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000123_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000123_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000123_A_class }

func (t *A_arbace_core_protocols_eval619000123_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000123_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000123_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000123_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000123_A); return ok }

func A_arbace_core_protocols_eval619000123_A_Cast(x any) *A_arbace_core_protocols_eval619000123_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000123_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000123_A_class)) }; return v }



type A_arbace_core_protocols_eval619000123_fn__619000124_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000123_fn__619000124_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000135_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000135_A_New() *A_arbace_core_protocols_eval619000135_A { t := &A_arbace_core_protocols_eval619000135_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000135_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000135_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000135_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000135_A_class }

func (t *A_arbace_core_protocols_eval619000135_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000135_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000135_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000135_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000135_A); return ok }

func A_arbace_core_protocols_eval619000135_A_Cast(x any) *A_arbace_core_protocols_eval619000135_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000135_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000135_A_class)) }; return v }



type A_arbace_core_protocols_eval619000135_fn__619000136_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000135_fn__619000136_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A struct{ j2g_header uint64; F_G__619000128 any }

var A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000161_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000161_A_New() *A_arbace_core_protocols_eval619000161_A { t := &A_arbace_core_protocols_eval619000161_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000161_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000161_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000161_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000161_A_class }

func (t *A_arbace_core_protocols_eval619000161_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000161_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000161_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000161_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000161_A); return ok }

func A_arbace_core_protocols_eval619000161_A_Cast(x any) *A_arbace_core_protocols_eval619000161_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000161_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000161_A_class)) }; return v }



type A_arbace_core_protocols_eval619000161_fn__619000162_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000161_fn__619000162_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A struct{ j2g_header uint64; F_G__619000154 any }

var A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000175_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000175_A_New() *A_arbace_core_protocols_eval619000175_A { t := &A_arbace_core_protocols_eval619000175_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000175_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000175_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000175_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000175_A_class }

func (t *A_arbace_core_protocols_eval619000175_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000175_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000175_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000175_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000175_A); return ok }

func A_arbace_core_protocols_eval619000175_A_Cast(x any) *A_arbace_core_protocols_eval619000175_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000175_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000175_A_class)) }; return v }



type A_arbace_core_protocols_eval619000175_fn__619000176_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000175_fn__619000176_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000179_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000179_A_New() *A_arbace_core_protocols_eval619000179_A { t := &A_arbace_core_protocols_eval619000179_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000179_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000179_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000179_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000179_A_class }

func (t *A_arbace_core_protocols_eval619000179_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000179_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000179_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000179_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000179_A); return ok }

func A_arbace_core_protocols_eval619000179_A_Cast(x any) *A_arbace_core_protocols_eval619000179_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000179_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000179_A_class)) }; return v }



type A_arbace_core_protocols_eval619000179_fn__619000180_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000179_fn__619000180_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000191_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000191_A_New() *A_arbace_core_protocols_eval619000191_A { t := &A_arbace_core_protocols_eval619000191_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000191_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000191_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000191_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000191_A_class }

func (t *A_arbace_core_protocols_eval619000191_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000191_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000191_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000191_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000191_A); return ok }

func A_arbace_core_protocols_eval619000191_A_Cast(x any) *A_arbace_core_protocols_eval619000191_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000191_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000191_A_class)) }; return v }



type A_arbace_core_protocols_eval619000191_fn__619000192_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000191_fn__619000192_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A struct{ j2g_header uint64; F_G__619000184 any }

var A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_fn_class *jrt.Class



type A_arbace_core_protocols_eval619000209_A struct{ jrt.Object }

func A_arbace_core_protocols_eval619000209_A_New() *A_arbace_core_protocols_eval619000209_A { t := &A_arbace_core_protocols_eval619000209_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols_eval619000209_A) Ctor() {}

func (t *A_arbace_core_protocols_eval619000209_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols_eval619000209_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols_eval619000209_A_class }

func (t *A_arbace_core_protocols_eval619000209_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols_eval619000209_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols_eval619000209_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols_eval619000209_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols_eval619000209_A); return ok }

func A_arbace_core_protocols_eval619000209_A_Cast(x any) *A_arbace_core_protocols_eval619000209_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols_eval619000209_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols_eval619000209_A_class)) }; return v }



type A_arbace_core_protocols_eval619000209_fn__619000210_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_eval619000209_fn__619000210_A_fn_class *jrt.Class



type A_arbace_core_protocols_interface_or_naive_reduce_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_interface_or_naive_reduce_A_fn_class *jrt.Class



type A_arbace_core_protocols_iter_reduce_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_iter_reduce_A_fn_class *jrt.Class



type A_arbace_core_protocols_iterator_reduce_BANG__A struct{ j2g_header uint64 }

var A_arbace_core_protocols_iterator_reduce_BANG__A_fn_class *jrt.Class



type A_arbace_core_protocols_naive_seq_reduce_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_naive_seq_reduce_A_fn_class *jrt.Class



type A_arbace_core_protocols_seq_reduce_A struct{ j2g_header uint64 }

var A_arbace_core_protocols_seq_reduce_A_fn_class *jrt.Class
