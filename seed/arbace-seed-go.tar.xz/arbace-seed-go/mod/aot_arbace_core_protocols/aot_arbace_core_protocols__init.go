//line aot_arbace_core_protocols__init.ae:1
package aot_arbace_core_protocols

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_protocols__init_A_Load__O() any { A_arbace_core_protocols__init_A_Init(); jrt.StartCheck(); A_arbace_core_protocols__init_A_Unit0__O(); A_arbace_core_protocols__init_A_Unit1__O(); A_arbace_core_protocols__init_A_Unit2__O(); A_arbace_core_protocols__init_A_Unit3__O(); A_arbace_core_protocols__init_A_Unit4__O(); A_arbace_core_protocols__init_A_Unit5__O(); A_arbace_core_protocols__init_A_Unit6__O(); A_arbace_core_protocols__init_A_Unit7__O(); A_arbace_core_protocols__init_A_Unit8__O(); A_arbace_core_protocols__init_A_Unit9__O(); A_arbace_core_protocols__init_A_Unit10__O(); A_arbace_core_protocols__init_A_Unit11__O(); A_arbace_core_protocols__init_A_Unit12__O(); A_arbace_core_protocols__init_A_Unit13__O(); A_arbace_core_protocols__init_A_Unit14__O(); A_arbace_core_protocols__init_A_Unit15__O(); A_arbace_core_protocols__init_A_Unit16__O(); A_arbace_core_protocols__init_A_Unit17__O(); A_arbace_core_protocols__init_A_Unit18__O(); A_arbace_core_protocols__init_A_Unit19__O(); A_arbace_core_protocols__init_A_Unit20__O(); A_arbace_core_protocols__init_A_Unit21__O(); A_arbace_core_protocols__init_A_Unit22__O(); A_arbace_core_protocols__init_A_Unit23__O(); A_arbace_core_protocols__init_A_Unit24__O(); A_arbace_core_protocols__init_A_Unit25__O(); A_arbace_core_protocols__init_A_Unit26__O(); A_arbace_core_protocols__init_A_Unit27__O(); A_arbace_core_protocols__init_A_Unit28__O(); A_arbace_core_protocols__init_A_Unit29__O(); A_arbace_core_protocols__init_A_Unit30__O(); A_arbace_core_protocols__init_A_Unit31__O(); A_arbace_core_protocols__init_A_Unit32__O(); A_arbace_core_protocols__init_A_Unit33__O(); A_arbace_core_protocols__init_A_Unit34__O(); A_arbace_core_protocols__init_A_Unit35__O(); A_arbace_core_protocols__init_A_Unit36__O(); A_arbace_core_protocols__init_A_Unit37__O(); A_arbace_core_protocols__init_A_Unit38__O(); A_arbace_core_protocols__init_A_Unit39__O(); A_arbace_core_protocols__init_A_Unit40__O(); A_arbace_core_protocols__init_A_Unit41__O(); A_arbace_core_protocols__init_A_Unit42__O(); A_arbace_core_protocols__init_A_Unit43__O(); A_arbace_core_protocols__init_A_Unit44__O(); A_arbace_core_protocols__init_A_Unit45__O(); A_arbace_core_protocols__init_A_Unit46__O(); A_arbace_core_protocols__init_A_Unit47__O(); A_arbace_core_protocols__init_A_Unit48__O(); A_arbace_core_protocols__init_A_Unit49__O(); A_arbace_core_protocols__init_A_Unit50__O(); A_arbace_core_protocols__init_A_Unit51__O(); A_arbace_core_protocols__init_A_Unit52__O(); A_arbace_core_protocols__init_A_Unit53__O(); A_arbace_core_protocols__init_A_Unit54__O(); A_arbace_core_protocols__init_A_Unit55__O(); A_arbace_core_protocols__init_A_Unit56__O(); A_arbace_core_protocols__init_A_Unit57__O(); A_arbace_core_protocols__init_A_Unit58__O(); A_arbace_core_protocols__init_A_Unit59__O(); return nil }



func A_arbace_core_protocols__init_A_Unit0__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return lang.IFn_Cast(A_arbace_core_protocols__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_protocols__init_A_const_1) }
//line :9:1
func A_arbace_core_protocols__init_A_Unit1__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, nil); A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :9:1
func A_arbace_core_protocols__init_A_Unit2__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_core_protocols__init_A_const_1)).Equals_O__Z(A_arbace_core_protocols__init_A_const_2) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_core_protocols_eval619000006_fn__619000007_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_core_protocols_eval619000006_fn__619000007_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_core_protocols_eval619000006_fn__619000007_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }

func A_arbace_core_protocols__init_A_Unit3__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(11, 1); return A_arbace_core_protocols__init_A_const_3.Set_O__O(jrt.Boolean_TRUE.Ref()) }

func A_arbace_core_protocols__init_A_Unit4__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_5)); v__1927001498__auto____1 = A_arbace_core_protocols__init_A_const_4; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_protocols__init_A_const_4; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_6)); A_arbace_core_protocols__init_A_const_4.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_core_protocols__init_A_const_4 } }
//line :13:1
func A_arbace_core_protocols__init_A_Unit5__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); return A_arbace_core_protocols__init_A_const_7 }
//line :13:1
func A_arbace_core_protocols__init_A_Unit6__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_8.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_4; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_core_protocols__init_A_const_9.GetRawRoot__O(), A_arbace_core_protocols__init_A_const_10, Lit_20) }
//line :13:1
func A_arbace_core_protocols__init_A_Unit7__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); return A_arbace_core_protocols__init_A_const_11.Invoke_O_O__O(A_arbace_core_protocols__init_A_const_4, A_arbace_core_protocols__init_A_const_12) }
//line :13:1
func A_arbace_core_protocols__init_A_Unit8__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_13.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_4; var tmp3 any = A_arbace_core_protocols__init_A_const_14.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_9.GetRawRoot__O()); var tmp5 any = A_arbace_core_protocols__init_A_const_15; var tmp6 any = A_arbace_core_protocols__init_A_const_16; var tmp7 any = A_arbace_core_protocols__init_A_const_17; var tmp8 any = A_arbace_core_protocols__init_A_const_18; var tmp9 any = A_arbace_core_protocols__init_A_const_4; var tmp10 any = A_arbace_core_protocols__init_A_const_19; var tmp11 any = A_arbace_core_protocols__init_A_const_20; var tmp12 any = A_arbace_core_protocols__init_A_const_21; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_24.GetRawRoot__O()); var tmp14 any = A_arbace_core_protocols__init_A_const_25; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_14.GetRawRoot__O()); var tmp16 any = A_arbace_core_protocols__init_A_const_26; var tmp17 any = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core_protocols__init_A_const_23.Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_protocols__init_A_const_27, A_arbace_core_protocols__init_A_const_4))))); var tmp18 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_core_protocols_eval619000020_fn__619000021_A_New(); var tmp19 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_core_protocols_eval619000020_fn__619000021_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, nil); A_arbace_core_protocols_eval619000020_fn__619000021_A_fn_class = fncls__45d; tmp19 = fncls__45d } else { tmp19 = fncls__45 }; tmp18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp19, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18.Ref())))) }
//line :13:1
func A_arbace_core_protocols__init_A_Unit9__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); return lang.IFn_Cast(A_arbace_core_protocols__init_A_const_28.GetRawRoot__O()).Invoke_O__O(A_arbace_core_protocols__init_A_const_4.GetRawRoot__O()) }
//line :13:1
func A_arbace_core_protocols__init_A_Unit10__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); return A_arbace_core_protocols__init_A_const_29 }





func A_arbace_core_protocols__init_A_Unit11__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_31)); v__1927001498__auto____1 = A_arbace_core_protocols__init_A_const_30; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_protocols__init_A_const_30; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_32)); A_arbace_core_protocols__init_A_const_30.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_core_protocols__init_A_const_30 } }
//line :19:1
func A_arbace_core_protocols__init_A_Unit12__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); return A_arbace_core_protocols__init_A_const_33 }
//line :19:1
func A_arbace_core_protocols__init_A_Unit13__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_8.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_30; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_core_protocols__init_A_const_9.GetRawRoot__O(), A_arbace_core_protocols__init_A_const_10, Lit_22) }
//line :19:1
func A_arbace_core_protocols__init_A_Unit14__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); return A_arbace_core_protocols__init_A_const_11.Invoke_O_O__O(A_arbace_core_protocols__init_A_const_30, A_arbace_core_protocols__init_A_const_34) }
//line :19:1
func A_arbace_core_protocols__init_A_Unit15__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_13.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_30; var tmp3 any = A_arbace_core_protocols__init_A_const_14.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_9.GetRawRoot__O()); var tmp5 any = A_arbace_core_protocols__init_A_const_35; var tmp6 any = A_arbace_core_protocols__init_A_const_16; var tmp7 any = A_arbace_core_protocols__init_A_const_36; var tmp8 any = A_arbace_core_protocols__init_A_const_18; var tmp9 any = A_arbace_core_protocols__init_A_const_30; var tmp10 any = A_arbace_core_protocols__init_A_const_19; var tmp11 any = A_arbace_core_protocols__init_A_const_37; var tmp12 any = A_arbace_core_protocols__init_A_const_21; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_24.GetRawRoot__O()); var tmp14 any = A_arbace_core_protocols__init_A_const_38; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_14.GetRawRoot__O()); var tmp16 any = A_arbace_core_protocols__init_A_const_39; var tmp17 any = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core_protocols__init_A_const_23.Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_protocols__init_A_const_27, A_arbace_core_protocols__init_A_const_30))))); var tmp18 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_core_protocols_eval619000050_fn__619000051_A_New(); var tmp19 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_core_protocols_eval619000050_fn__619000051_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, nil); A_arbace_core_protocols_eval619000050_fn__619000051_A_fn_class = fncls__91d; tmp19 = fncls__91d } else { tmp19 = fncls__91 }; tmp18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp19, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18.Ref())))) }
//line :19:1
func A_arbace_core_protocols__init_A_Unit16__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); return lang.IFn_Cast(A_arbace_core_protocols__init_A_const_28.GetRawRoot__O()).Invoke_O__O(A_arbace_core_protocols__init_A_const_30.GetRawRoot__O()) }
//line :19:1
func A_arbace_core_protocols__init_A_Unit17__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); return A_arbace_core_protocols__init_A_const_40 }




func A_arbace_core_protocols__init_A_Unit18__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_41; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_core_protocols_seq_reduce_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_core_protocols_seq_reduce_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, nil); A_arbace_core_protocols_seq_reduce_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_protocols__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_42)); return A_arbace_core_protocols__init_A_const_41 }









func A_arbace_core_protocols__init_A_Unit19__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_core_protocols_iterator_reduce_BANG__A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_core_protocols_iterator_reduce_BANG__A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, nil); A_arbace_core_protocols_iterator_reduce_BANG__A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_protocols__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_44)); return A_arbace_core_protocols__init_A_const_43 }













func A_arbace_core_protocols__init_A_Unit20__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_core_protocols_iter_reduce_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_core_protocols_iter_reduce_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, nil); A_arbace_core_protocols_iter_reduce_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_protocols__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_46)); return A_arbace_core_protocols__init_A_const_45 }





func A_arbace_core_protocols__init_A_Unit21__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(54, 1); var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_core_protocols_naive_seq_reduce_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_core_protocols_naive_seq_reduce_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); A_arbace_core_protocols_naive_seq_reduce_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_protocols__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_48)); return A_arbace_core_protocols__init_A_const_47 }












func A_arbace_core_protocols__init_A_Unit22__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(67, 1); var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_core_protocols_interface_or_naive_reduce_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_core_protocols_interface_or_naive_reduce_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, nil); A_arbace_core_protocols_interface_or_naive_reduce_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_protocols__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_50)); return A_arbace_core_protocols__init_A_const_49 }






func A_arbace_core_protocols__init_A_Unit23__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_51.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_4.GetRawRoot__O(); var tmp3 any = A_arbace_core_protocols__init_A_const_52; var tmp4 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_core_protocols_eval619000073_fn__619000074_A_New(); var tmp5 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_core_protocols_eval619000073_fn__619000074_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); A_arbace_core_protocols_eval619000073_fn__619000074_A_fn_class = fncls__113d; tmp5 = fncls__113d } else { tmp5 = fncls__113 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp5, nil); return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4.Ref()))) }
//line :74:1
func A_arbace_core_protocols__init_A_Unit24__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_51.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_53; var tmp3 any = A_arbace_core_protocols__init_A_const_4.GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_52; var tmp5 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_core_protocols_eval619000077_fn__619000078_A_New(); var tmp6 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_core_protocols_eval619000077_fn__619000078_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); A_arbace_core_protocols_eval619000077_fn__619000078_A_fn_class = fncls__121d; tmp6 = fncls__121d } else { tmp6 = fncls__121 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }
//line :74:1
func A_arbace_core_protocols__init_A_Unit25__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_51.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_54; var tmp3 any = A_arbace_core_protocols__init_A_const_4.GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_52; var tmp5 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_core_protocols_eval619000081_fn__619000082_A_New(); var tmp6 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_core_protocols_eval619000081_fn__619000082_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, nil); A_arbace_core_protocols_eval619000081_fn__619000082_A_fn_class = fncls__129d; tmp6 = fncls__129d } else { tmp6 = fncls__129 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }
//line :74:1
func A_arbace_core_protocols__init_A_Unit26__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_51.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_55; var tmp3 any = A_arbace_core_protocols__init_A_const_4.GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_52; var tmp5 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_core_protocols_eval619000085_fn__619000086_A_New(); var tmp6 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_core_protocols_eval619000085_fn__619000086_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); A_arbace_core_protocols_eval619000085_fn__619000086_A_fn_class = fncls__137d; tmp6 = fncls__137d } else { tmp6 = fncls__137 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }
//line :74:1
func A_arbace_core_protocols__init_A_Unit27__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_51.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_56; var tmp3 any = A_arbace_core_protocols__init_A_const_4.GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_52; var tmp5 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_core_protocols_eval619000089_fn__619000090_A_New(); var tmp6 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_core_protocols_eval619000089_fn__619000090_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_core_protocols_eval619000089_fn__619000090_A_fn_class = fncls__145d; tmp6 = fncls__145d } else { tmp6 = fncls__145 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }
//line :74:1
func A_arbace_core_protocols__init_A_Unit28__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_51.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_57; var tmp3 any = A_arbace_core_protocols__init_A_const_4.GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_52; var tmp5 *lang.Compiler_AOTFn; var fnbody__154 any = A_arbace_core_protocols_eval619000093_fn__619000094_A_New(); var tmp6 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_core_protocols_eval619000093_fn__619000094_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, nil); A_arbace_core_protocols_eval619000093_fn__619000094_A_fn_class = fncls__153d; tmp6 = fncls__153d } else { tmp6 = fncls__153 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__154, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }
//line :74:1
func A_arbace_core_protocols__init_A_Unit29__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_51.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_58; var tmp3 any = A_arbace_core_protocols__init_A_const_4.GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_52; var tmp5 *lang.Compiler_AOTFn; var fnbody__162 any = A_arbace_core_protocols_eval619000099_fn__619000100_A_New(); var tmp6 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_core_protocols_eval619000099_fn__619000100_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); A_arbace_core_protocols_eval619000099_fn__619000100_A_fn_class = fncls__161d; tmp6 = fncls__161d } else { tmp6 = fncls__161 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__162, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }
//line :74:1
func A_arbace_core_protocols__init_A_Unit30__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_51.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_59; var tmp3 any = A_arbace_core_protocols__init_A_const_4.GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_52; var tmp5 *lang.Compiler_AOTFn; var fnbody__170 any = A_arbace_core_protocols_eval619000103_fn__619000104_A_New(); var tmp6 *jrt.Class; var fncls__169 *jrt.Class = A_arbace_core_protocols_eval619000103_fn__619000104_A_fn_class; if fncls__169 == nil { var fncls__169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, nil); A_arbace_core_protocols_eval619000103_fn__619000104_A_fn_class = fncls__169d; tmp6 = fncls__169d } else { tmp6 = fncls__169 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__170, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }
//line :74:1
func A_arbace_core_protocols__init_A_Unit31__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_51.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_60; var tmp3 any = A_arbace_core_protocols__init_A_const_4.GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_52; var tmp5 *lang.Compiler_AOTFn; var fnbody__178 any = A_arbace_core_protocols_eval619000107_fn__619000108_A_New(); var tmp6 *jrt.Class; var fncls__177 *jrt.Class = A_arbace_core_protocols_eval619000107_fn__619000108_A_fn_class; if fncls__177 == nil { var fncls__177d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, nil); A_arbace_core_protocols_eval619000107_fn__619000108_A_fn_class = fncls__177d; tmp6 = fncls__177d } else { tmp6 = fncls__177 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__178, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }

























































func A_arbace_core_protocols__init_A_Unit32__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_51.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_30.GetRawRoot__O(); var tmp3 any = A_arbace_core_protocols__init_A_const_61; var tmp4 *lang.Compiler_AOTFn; var fnbody__186 any = A_arbace_core_protocols_eval619000111_fn__619000112_A_New(); var tmp5 *jrt.Class; var fncls__185 *jrt.Class = A_arbace_core_protocols_eval619000111_fn__619000112_A_fn_class; if fncls__185 == nil { var fncls__185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, nil); A_arbace_core_protocols_eval619000111_fn__619000112_A_fn_class = fncls__185d; tmp5 = fncls__185d } else { tmp5 = fncls__185 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__186, tmp5, nil); return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4.Ref()))) }
//line :132:1
func A_arbace_core_protocols__init_A_Unit33__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_51.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_62; var tmp3 any = A_arbace_core_protocols__init_A_const_30.GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_61; var tmp5 *lang.Compiler_AOTFn; var fnbody__194 any = A_arbace_core_protocols_eval619000115_fn__619000116_A_New(); var tmp6 *jrt.Class; var fncls__193 *jrt.Class = A_arbace_core_protocols_eval619000115_fn__619000116_A_fn_class; if fncls__193 == nil { var fncls__193d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); A_arbace_core_protocols_eval619000115_fn__619000116_A_fn_class = fncls__193d; tmp6 = fncls__193d } else { tmp6 = fncls__193 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__194, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }
//line :132:1
func A_arbace_core_protocols__init_A_Unit34__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_51.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_63; var tmp3 any = A_arbace_core_protocols__init_A_const_30.GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_61; var tmp5 *lang.Compiler_AOTFn; var fnbody__202 any = A_arbace_core_protocols_eval619000119_fn__619000120_A_New(); var tmp6 *jrt.Class; var fncls__201 *jrt.Class = A_arbace_core_protocols_eval619000119_fn__619000120_A_fn_class; if fncls__201 == nil { var fncls__201d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); A_arbace_core_protocols_eval619000119_fn__619000120_A_fn_class = fncls__201d; tmp6 = fncls__201d } else { tmp6 = fncls__201 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__202, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }
//line :132:1
func A_arbace_core_protocols__init_A_Unit35__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_51.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_53; var tmp3 any = A_arbace_core_protocols__init_A_const_30.GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_61; var tmp5 *lang.Compiler_AOTFn; var fnbody__210 any = A_arbace_core_protocols_eval619000123_fn__619000124_A_New(); var tmp6 *jrt.Class; var fncls__209 *jrt.Class = A_arbace_core_protocols_eval619000123_fn__619000124_A_fn_class; if fncls__209 == nil { var fncls__209d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, nil); A_arbace_core_protocols_eval619000123_fn__619000124_A_fn_class = fncls__209d; tmp6 = fncls__209d } else { tmp6 = fncls__209 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__210, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }


















































func A_arbace_core_protocols__init_A_Unit36__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(183, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_65)); v__1927001498__auto____1 = A_arbace_core_protocols__init_A_const_64; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_protocols__init_A_const_64; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_66)); A_arbace_core_protocols__init_A_const_64.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_core_protocols__init_A_const_64 } }
//line :183:1
func A_arbace_core_protocols__init_A_Unit37__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(183, 1); return A_arbace_core_protocols__init_A_const_67 }
//line :183:1
func A_arbace_core_protocols__init_A_Unit38__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(183, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_8.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_64; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_core_protocols__init_A_const_9.GetRawRoot__O(), A_arbace_core_protocols__init_A_const_10, Lit_42) }
//line :183:1
func A_arbace_core_protocols__init_A_Unit39__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(183, 1); return A_arbace_core_protocols__init_A_const_11.Invoke_O_O__O(A_arbace_core_protocols__init_A_const_64, A_arbace_core_protocols__init_A_const_68) }
//line :183:1
func A_arbace_core_protocols__init_A_Unit40__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(183, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_13.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_64; var tmp3 any = A_arbace_core_protocols__init_A_const_14.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_9.GetRawRoot__O()); var tmp5 any = A_arbace_core_protocols__init_A_const_69; var tmp6 any = A_arbace_core_protocols__init_A_const_16; var tmp7 any = A_arbace_core_protocols__init_A_const_70; var tmp8 any = A_arbace_core_protocols__init_A_const_18; var tmp9 any = A_arbace_core_protocols__init_A_const_64; var tmp10 any = A_arbace_core_protocols__init_A_const_19; var tmp11 any = A_arbace_core_protocols__init_A_const_71; var tmp12 any = A_arbace_core_protocols__init_A_const_21; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_24.GetRawRoot__O()); var tmp14 any = A_arbace_core_protocols__init_A_const_72; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_14.GetRawRoot__O()); var tmp16 any = A_arbace_core_protocols__init_A_const_73; var tmp17 any = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core_protocols__init_A_const_23.Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_protocols__init_A_const_27, A_arbace_core_protocols__init_A_const_64))))); var tmp18 *lang.Compiler_AOTFn; var fnbody__252 any = A_arbace_core_protocols_eval619000135_fn__619000136_A_New(); var tmp19 *jrt.Class; var fncls__251 *jrt.Class = A_arbace_core_protocols_eval619000135_fn__619000136_A_fn_class; if fncls__251 == nil { var fncls__251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, nil); A_arbace_core_protocols_eval619000135_fn__619000136_A_fn_class = fncls__251d; tmp19 = fncls__251d } else { tmp19 = fncls__251 }; tmp18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__252, tmp19, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18.Ref())))) }
//line :183:1
func A_arbace_core_protocols__init_A_Unit41__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(183, 1); return lang.IFn_Cast(A_arbace_core_protocols__init_A_const_28.GetRawRoot__O()).Invoke_O__O(A_arbace_core_protocols__init_A_const_64.GetRawRoot__O()) }
//line :183:1
func A_arbace_core_protocols__init_A_Unit42__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(183, 1); return A_arbace_core_protocols__init_A_const_74 }






func A_arbace_core_protocols__init_A_Unit43__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(190, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_75; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_76)); v__1927001498__auto____1 = A_arbace_core_protocols__init_A_const_75; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_protocols__init_A_const_75; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_77)); A_arbace_core_protocols__init_A_const_75.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_core_protocols__init_A_const_75 } }
//line :190:1
func A_arbace_core_protocols__init_A_Unit44__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(190, 1); return A_arbace_core_protocols__init_A_const_78 }
//line :190:1
func A_arbace_core_protocols__init_A_Unit45__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(190, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_8.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_75; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_core_protocols__init_A_const_9.GetRawRoot__O(), A_arbace_core_protocols__init_A_const_10, nil) }
//line :190:1
func A_arbace_core_protocols__init_A_Unit46__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(190, 1); return A_arbace_core_protocols__init_A_const_11.Invoke_O_O__O(A_arbace_core_protocols__init_A_const_75, A_arbace_core_protocols__init_A_const_79) }
//line :190:1
func A_arbace_core_protocols__init_A_Unit47__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(190, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_13.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_75; var tmp3 any = A_arbace_core_protocols__init_A_const_14.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_9.GetRawRoot__O()); var tmp5 any = A_arbace_core_protocols__init_A_const_80; var tmp6 any = A_arbace_core_protocols__init_A_const_16; var tmp7 any = A_arbace_core_protocols__init_A_const_81; var tmp8 any = A_arbace_core_protocols__init_A_const_18; var tmp9 any = A_arbace_core_protocols__init_A_const_75; var tmp10 any = A_arbace_core_protocols__init_A_const_19; var tmp11 any = A_arbace_core_protocols__init_A_const_82; var tmp12 any = A_arbace_core_protocols__init_A_const_21; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_24.GetRawRoot__O()); var tmp14 any = A_arbace_core_protocols__init_A_const_83; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_14.GetRawRoot__O()); var tmp16 any = A_arbace_core_protocols__init_A_const_84; var tmp17 any = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core_protocols__init_A_const_23.Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_protocols__init_A_const_27, A_arbace_core_protocols__init_A_const_75))))); var tmp18 *lang.Compiler_AOTFn; var fnbody__298 any = A_arbace_core_protocols_eval619000161_fn__619000162_A_New(); var tmp19 *jrt.Class; var fncls__297 *jrt.Class = A_arbace_core_protocols_eval619000161_fn__619000162_A_fn_class; if fncls__297 == nil { var fncls__297d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); A_arbace_core_protocols_eval619000161_fn__619000162_A_fn_class = fncls__297d; tmp19 = fncls__297d } else { tmp19 = fncls__297 }; tmp18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__298, tmp19, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18.Ref())))) }
//line :190:1
func A_arbace_core_protocols__init_A_Unit48__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(190, 1); return lang.IFn_Cast(A_arbace_core_protocols__init_A_const_28.GetRawRoot__O()).Invoke_O__O(A_arbace_core_protocols__init_A_const_75.GetRawRoot__O()) }
//line :190:1
func A_arbace_core_protocols__init_A_Unit49__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(190, 1); return A_arbace_core_protocols__init_A_const_85 }




func A_arbace_core_protocols__init_A_Unit50__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(195, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_51.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_75.GetRawRoot__O(); var tmp3 any = A_arbace_core_protocols__init_A_const_86; var tmp4 *lang.Compiler_AOTFn; var fnbody__310 any = A_arbace_core_protocols_eval619000175_fn__619000176_A_New(); var tmp5 *jrt.Class; var fncls__309 *jrt.Class = A_arbace_core_protocols_eval619000175_fn__619000176_A_fn_class; if fncls__309 == nil { var fncls__309d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, nil); A_arbace_core_protocols_eval619000175_fn__619000176_A_fn_class = fncls__309d; tmp5 = fncls__309d } else { tmp5 = fncls__309 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__310, tmp5, nil); return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4.Ref()))) }
//line :195:1
func A_arbace_core_protocols__init_A_Unit51__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(195, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_51.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_53; var tmp3 any = A_arbace_core_protocols__init_A_const_75.GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_86; var tmp5 *lang.Compiler_AOTFn; var fnbody__318 any = A_arbace_core_protocols_eval619000179_fn__619000180_A_New(); var tmp6 *jrt.Class; var fncls__317 *jrt.Class = A_arbace_core_protocols_eval619000179_fn__619000180_A_fn_class; if fncls__317 == nil { var fncls__317d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, nil); A_arbace_core_protocols_eval619000179_fn__619000180_A_fn_class = fncls__317d; tmp6 = fncls__317d } else { tmp6 = fncls__317 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__318, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }






func A_arbace_core_protocols__init_A_Unit52__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_87; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_88)); v__1927001498__auto____1 = A_arbace_core_protocols__init_A_const_87; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_protocols__init_A_const_87; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_89)); A_arbace_core_protocols__init_A_const_87.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_core_protocols__init_A_const_87 } }
//line :202:1
func A_arbace_core_protocols__init_A_Unit53__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); return A_arbace_core_protocols__init_A_const_90 }
//line :202:1
func A_arbace_core_protocols__init_A_Unit54__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_8.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_87; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_core_protocols__init_A_const_9.GetRawRoot__O(), A_arbace_core_protocols__init_A_const_10, nil) }
//line :202:1
func A_arbace_core_protocols__init_A_Unit55__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); return A_arbace_core_protocols__init_A_const_11.Invoke_O_O__O(A_arbace_core_protocols__init_A_const_87, A_arbace_core_protocols__init_A_const_91) }
//line :202:1
func A_arbace_core_protocols__init_A_Unit56__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_13.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_87; var tmp3 any = A_arbace_core_protocols__init_A_const_14.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_9.GetRawRoot__O()); var tmp5 any = A_arbace_core_protocols__init_A_const_92; var tmp6 any = A_arbace_core_protocols__init_A_const_16; var tmp7 any = A_arbace_core_protocols__init_A_const_93; var tmp8 any = A_arbace_core_protocols__init_A_const_18; var tmp9 any = A_arbace_core_protocols__init_A_const_87; var tmp10 any = A_arbace_core_protocols__init_A_const_19; var tmp11 any = A_arbace_core_protocols__init_A_const_94; var tmp12 any = A_arbace_core_protocols__init_A_const_21; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_24.GetRawRoot__O()); var tmp14 any = A_arbace_core_protocols__init_A_const_95; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_14.GetRawRoot__O()); var tmp16 any = A_arbace_core_protocols__init_A_const_96; var tmp17 any = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core_protocols__init_A_const_23.Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_protocols__init_A_const_27, A_arbace_core_protocols__init_A_const_87))))); var tmp18 *lang.Compiler_AOTFn; var fnbody__360 any = A_arbace_core_protocols_eval619000191_fn__619000192_A_New(); var tmp19 *jrt.Class; var fncls__359 *jrt.Class = A_arbace_core_protocols_eval619000191_fn__619000192_A_fn_class; if fncls__359 == nil { var fncls__359d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, nil); A_arbace_core_protocols_eval619000191_fn__619000192_A_fn_class = fncls__359d; tmp19 = fncls__359d } else { tmp19 = fncls__359 }; tmp18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__360, tmp19, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18.Ref())))) }
//line :202:1
func A_arbace_core_protocols__init_A_Unit57__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); return lang.IFn_Cast(A_arbace_core_protocols__init_A_const_28.GetRawRoot__O()).Invoke_O__O(A_arbace_core_protocols__init_A_const_87.GetRawRoot__O()) }
//line :202:1
func A_arbace_core_protocols__init_A_Unit58__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); return A_arbace_core_protocols__init_A_const_97 }





func A_arbace_core_protocols__init_A_Unit59__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(208, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_protocols__init_A_const_51.GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_53; var tmp3 any = A_arbace_core_protocols__init_A_const_87.GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_98; var tmp5 *lang.Compiler_AOTFn; var fnbody__372 any = A_arbace_core_protocols_eval619000209_fn__619000210_A_New(); var tmp6 *jrt.Class; var fncls__371 *jrt.Class = A_arbace_core_protocols_eval619000209_fn__619000210_A_fn_class; if fncls__371 == nil { var fncls__371d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, nil); A_arbace_core_protocols_eval619000209_fn__619000210_A_fn_class = fncls__371d; tmp6 = fncls__371d } else { tmp6 = fncls__371 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__372, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }
























type A_arbace_core_protocols__init_A struct{ jrt.Object }

var A_arbace_core_protocols__init_A_const_pool *jrt.RefArray

var A_arbace_core_protocols__init_A_const_0 *lang.Var

var A_arbace_core_protocols__init_A_const_1 any

var A_arbace_core_protocols__init_A_const_2 any

var A_arbace_core_protocols__init_A_const_3 *lang.Var

var A_arbace_core_protocols__init_A_const_4 *lang.Var

var A_arbace_core_protocols__init_A_const_5 any

var A_arbace_core_protocols__init_A_const_6 any

var A_arbace_core_protocols__init_A_const_7 *jrt.Class

var A_arbace_core_protocols__init_A_const_8 *lang.Var

var A_arbace_core_protocols__init_A_const_9 *lang.Var

var A_arbace_core_protocols__init_A_const_10 *lang.Keyword

var A_arbace_core_protocols__init_A_const_11 *lang.Var

var A_arbace_core_protocols__init_A_const_12 any

var A_arbace_core_protocols__init_A_const_13 *lang.Var

var A_arbace_core_protocols__init_A_const_14 *lang.Var

var A_arbace_core_protocols__init_A_const_15 any

var A_arbace_core_protocols__init_A_const_16 *lang.Keyword

var A_arbace_core_protocols__init_A_const_17 any

var A_arbace_core_protocols__init_A_const_18 *lang.Keyword

var A_arbace_core_protocols__init_A_const_19 *lang.Keyword

var A_arbace_core_protocols__init_A_const_20 any

var A_arbace_core_protocols__init_A_const_21 *lang.Keyword

var A_arbace_core_protocols__init_A_const_22 *lang.Var

var A_arbace_core_protocols__init_A_const_23 *lang.Var

var A_arbace_core_protocols__init_A_const_24 *lang.Var

var A_arbace_core_protocols__init_A_const_25 any

var A_arbace_core_protocols__init_A_const_26 any

var A_arbace_core_protocols__init_A_const_27 *lang.Keyword

var A_arbace_core_protocols__init_A_const_28 *lang.Var

var A_arbace_core_protocols__init_A_const_29 any

var A_arbace_core_protocols__init_A_const_30 *lang.Var

var A_arbace_core_protocols__init_A_const_31 any

var A_arbace_core_protocols__init_A_const_32 any

var A_arbace_core_protocols__init_A_const_33 *jrt.Class

var A_arbace_core_protocols__init_A_const_34 any

var A_arbace_core_protocols__init_A_const_35 any

var A_arbace_core_protocols__init_A_const_36 any

var A_arbace_core_protocols__init_A_const_37 any

var A_arbace_core_protocols__init_A_const_38 any

var A_arbace_core_protocols__init_A_const_39 any

var A_arbace_core_protocols__init_A_const_40 any

var A_arbace_core_protocols__init_A_const_41 *lang.Var

var A_arbace_core_protocols__init_A_const_42 any

var A_arbace_core_protocols__init_A_const_43 *lang.Var

var A_arbace_core_protocols__init_A_const_44 any

var A_arbace_core_protocols__init_A_const_45 *lang.Var

var A_arbace_core_protocols__init_A_const_46 any

var A_arbace_core_protocols__init_A_const_47 *lang.Var

var A_arbace_core_protocols__init_A_const_48 any

var A_arbace_core_protocols__init_A_const_49 *lang.Var

var A_arbace_core_protocols__init_A_const_50 any

var A_arbace_core_protocols__init_A_const_51 *lang.Var

var A_arbace_core_protocols__init_A_const_52 *lang.Keyword

var A_arbace_core_protocols__init_A_const_53 *jrt.Class

var A_arbace_core_protocols__init_A_const_54 *jrt.Class

var A_arbace_core_protocols__init_A_const_55 *jrt.Class

var A_arbace_core_protocols__init_A_const_56 *jrt.Class

var A_arbace_core_protocols__init_A_const_57 *jrt.Class

var A_arbace_core_protocols__init_A_const_58 *jrt.Class

var A_arbace_core_protocols__init_A_const_59 *jrt.Class

var A_arbace_core_protocols__init_A_const_60 *jrt.Class

var A_arbace_core_protocols__init_A_const_61 *lang.Keyword

var A_arbace_core_protocols__init_A_const_62 *jrt.Class

var A_arbace_core_protocols__init_A_const_63 *jrt.Class

var A_arbace_core_protocols__init_A_const_64 *lang.Var

var A_arbace_core_protocols__init_A_const_65 any

var A_arbace_core_protocols__init_A_const_66 any

var A_arbace_core_protocols__init_A_const_67 *jrt.Class

var A_arbace_core_protocols__init_A_const_68 any

var A_arbace_core_protocols__init_A_const_69 any

var A_arbace_core_protocols__init_A_const_70 any

var A_arbace_core_protocols__init_A_const_71 any

var A_arbace_core_protocols__init_A_const_72 any

var A_arbace_core_protocols__init_A_const_73 any

var A_arbace_core_protocols__init_A_const_74 any

var A_arbace_core_protocols__init_A_const_75 *lang.Var

var A_arbace_core_protocols__init_A_const_76 any

var A_arbace_core_protocols__init_A_const_77 any

var A_arbace_core_protocols__init_A_const_78 *jrt.Class

var A_arbace_core_protocols__init_A_const_79 any

var A_arbace_core_protocols__init_A_const_80 any

var A_arbace_core_protocols__init_A_const_81 any

var A_arbace_core_protocols__init_A_const_82 any

var A_arbace_core_protocols__init_A_const_83 any

var A_arbace_core_protocols__init_A_const_84 any

var A_arbace_core_protocols__init_A_const_85 any

var A_arbace_core_protocols__init_A_const_86 *lang.Keyword

var A_arbace_core_protocols__init_A_const_87 *lang.Var

var A_arbace_core_protocols__init_A_const_88 any

var A_arbace_core_protocols__init_A_const_89 any

var A_arbace_core_protocols__init_A_const_90 *jrt.Class

var A_arbace_core_protocols__init_A_const_91 any

var A_arbace_core_protocols__init_A_const_92 any

var A_arbace_core_protocols__init_A_const_93 any

var A_arbace_core_protocols__init_A_const_94 any

var A_arbace_core_protocols__init_A_const_95 any

var A_arbace_core_protocols__init_A_const_96 any

var A_arbace_core_protocols__init_A_const_97 any

var A_arbace_core_protocols__init_A_const_98 *lang.Keyword

var A_arbace_core_protocols__init_A_init jrt.ClassInit

func A_arbace_core_protocols__init_A_Init() { if !A_arbace_core_protocols__init_A_init.Done() { A_arbace_core_protocols__init_A_init.Run(A_arbace_core_protocols__init_A_clinit) } }

func A_arbace_core_protocols__init_A_clinit() { A_arbace_core_protocols__init_A_clinit_p0(); A_arbace_core_protocols__init_A_clinit_p1(); A_arbace_core_protocols__init_A_clinit_p2(); A_arbace_core_protocols__init_A_clinit_p3(); A_arbace_core_protocols__init_A_clinit_p4(); A_arbace_core_protocols__init_A_clinit_p5(); A_arbace_core_protocols__init_A_clinit_p6(); A_arbace_core_protocols__init_A_clinit_p7() }

func A_arbace_core_protocols__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_core_protocols__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_17, 145); A_arbace_core_protocols__init_A_const_0 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[46]); A_arbace_core_protocols__init_A_const_1 = A_arbace_core_protocols__init_A_const_pool.A[47]; A_arbace_core_protocols__init_A_const_2 = A_arbace_core_protocols__init_A_const_pool.A[48]; A_arbace_core_protocols__init_A_const_3 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[49]); A_arbace_core_protocols__init_A_const_4 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[50]); A_arbace_core_protocols__init_A_const_5 = A_arbace_core_protocols__init_A_const_pool.A[51]; A_arbace_core_protocols__init_A_const_6 = A_arbace_core_protocols__init_A_const_pool.A[52]; A_arbace_core_protocols__init_A_const_7 = jrt.Class_Cast(A_arbace_core_protocols__init_A_const_pool.A[53]); A_arbace_core_protocols__init_A_const_8 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[54]); A_arbace_core_protocols__init_A_const_9 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[55]); A_arbace_core_protocols__init_A_const_10 = lang.Keyword_Cast(A_arbace_core_protocols__init_A_const_pool.A[56]); A_arbace_core_protocols__init_A_const_11 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[57]) }

func A_arbace_core_protocols__init_A_clinit_p1() { A_arbace_core_protocols__init_A_const_12 = A_arbace_core_protocols__init_A_const_pool.A[58]; A_arbace_core_protocols__init_A_const_13 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[59]); A_arbace_core_protocols__init_A_const_14 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[60]); A_arbace_core_protocols__init_A_const_15 = A_arbace_core_protocols__init_A_const_pool.A[61]; A_arbace_core_protocols__init_A_const_16 = lang.Keyword_Cast(A_arbace_core_protocols__init_A_const_pool.A[62]); A_arbace_core_protocols__init_A_const_17 = A_arbace_core_protocols__init_A_const_pool.A[63]; A_arbace_core_protocols__init_A_const_18 = lang.Keyword_Cast(A_arbace_core_protocols__init_A_const_pool.A[64]); A_arbace_core_protocols__init_A_const_19 = lang.Keyword_Cast(A_arbace_core_protocols__init_A_const_pool.A[65]); A_arbace_core_protocols__init_A_const_20 = A_arbace_core_protocols__init_A_const_pool.A[66]; A_arbace_core_protocols__init_A_const_21 = lang.Keyword_Cast(A_arbace_core_protocols__init_A_const_pool.A[67]); A_arbace_core_protocols__init_A_const_22 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[68]); A_arbace_core_protocols__init_A_const_23 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[69]); A_arbace_core_protocols__init_A_const_24 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[70]) }

func A_arbace_core_protocols__init_A_clinit_p2() { A_arbace_core_protocols__init_A_const_25 = A_arbace_core_protocols__init_A_const_pool.A[71]; A_arbace_core_protocols__init_A_const_26 = A_arbace_core_protocols__init_A_const_pool.A[72]; A_arbace_core_protocols__init_A_const_27 = lang.Keyword_Cast(A_arbace_core_protocols__init_A_const_pool.A[73]); A_arbace_core_protocols__init_A_const_28 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[74]); A_arbace_core_protocols__init_A_const_29 = A_arbace_core_protocols__init_A_const_pool.A[75]; A_arbace_core_protocols__init_A_const_30 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[76]); A_arbace_core_protocols__init_A_const_31 = A_arbace_core_protocols__init_A_const_pool.A[77]; A_arbace_core_protocols__init_A_const_32 = A_arbace_core_protocols__init_A_const_pool.A[78]; A_arbace_core_protocols__init_A_const_33 = jrt.Class_Cast(A_arbace_core_protocols__init_A_const_pool.A[79]); A_arbace_core_protocols__init_A_const_34 = A_arbace_core_protocols__init_A_const_pool.A[80]; A_arbace_core_protocols__init_A_const_35 = A_arbace_core_protocols__init_A_const_pool.A[81]; A_arbace_core_protocols__init_A_const_36 = A_arbace_core_protocols__init_A_const_pool.A[82]; A_arbace_core_protocols__init_A_const_37 = A_arbace_core_protocols__init_A_const_pool.A[83]; A_arbace_core_protocols__init_A_const_38 = A_arbace_core_protocols__init_A_const_pool.A[84] }

func A_arbace_core_protocols__init_A_clinit_p3() { A_arbace_core_protocols__init_A_const_39 = A_arbace_core_protocols__init_A_const_pool.A[85]; A_arbace_core_protocols__init_A_const_40 = A_arbace_core_protocols__init_A_const_pool.A[86]; A_arbace_core_protocols__init_A_const_41 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[87]); A_arbace_core_protocols__init_A_const_42 = A_arbace_core_protocols__init_A_const_pool.A[88]; A_arbace_core_protocols__init_A_const_43 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[89]); A_arbace_core_protocols__init_A_const_44 = A_arbace_core_protocols__init_A_const_pool.A[90]; A_arbace_core_protocols__init_A_const_45 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[91]); A_arbace_core_protocols__init_A_const_46 = A_arbace_core_protocols__init_A_const_pool.A[92]; A_arbace_core_protocols__init_A_const_47 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[93]); A_arbace_core_protocols__init_A_const_48 = A_arbace_core_protocols__init_A_const_pool.A[94]; A_arbace_core_protocols__init_A_const_49 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[95]); A_arbace_core_protocols__init_A_const_50 = A_arbace_core_protocols__init_A_const_pool.A[96]; A_arbace_core_protocols__init_A_const_51 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[97]) }

func A_arbace_core_protocols__init_A_clinit_p4() { A_arbace_core_protocols__init_A_const_52 = lang.Keyword_Cast(A_arbace_core_protocols__init_A_const_pool.A[98]); A_arbace_core_protocols__init_A_const_53 = jrt.Class_Cast(A_arbace_core_protocols__init_A_const_pool.A[99]); A_arbace_core_protocols__init_A_const_54 = jrt.Class_Cast(A_arbace_core_protocols__init_A_const_pool.A[100]); A_arbace_core_protocols__init_A_const_55 = jrt.Class_Cast(A_arbace_core_protocols__init_A_const_pool.A[101]); A_arbace_core_protocols__init_A_const_56 = jrt.Class_Cast(A_arbace_core_protocols__init_A_const_pool.A[102]); A_arbace_core_protocols__init_A_const_57 = jrt.Class_Cast(A_arbace_core_protocols__init_A_const_pool.A[103]); A_arbace_core_protocols__init_A_const_58 = jrt.Class_Cast(A_arbace_core_protocols__init_A_const_pool.A[104]); A_arbace_core_protocols__init_A_const_59 = jrt.Class_Cast(A_arbace_core_protocols__init_A_const_pool.A[105]); A_arbace_core_protocols__init_A_const_60 = jrt.Class_Cast(A_arbace_core_protocols__init_A_const_pool.A[106]); A_arbace_core_protocols__init_A_const_61 = lang.Keyword_Cast(A_arbace_core_protocols__init_A_const_pool.A[107]); A_arbace_core_protocols__init_A_const_62 = jrt.Class_Cast(A_arbace_core_protocols__init_A_const_pool.A[108]); A_arbace_core_protocols__init_A_const_63 = jrt.Class_Cast(A_arbace_core_protocols__init_A_const_pool.A[109]) }

func A_arbace_core_protocols__init_A_clinit_p5() { A_arbace_core_protocols__init_A_const_64 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[110]); A_arbace_core_protocols__init_A_const_65 = A_arbace_core_protocols__init_A_const_pool.A[111]; A_arbace_core_protocols__init_A_const_66 = A_arbace_core_protocols__init_A_const_pool.A[112]; A_arbace_core_protocols__init_A_const_67 = jrt.Class_Cast(A_arbace_core_protocols__init_A_const_pool.A[113]); A_arbace_core_protocols__init_A_const_68 = A_arbace_core_protocols__init_A_const_pool.A[114]; A_arbace_core_protocols__init_A_const_69 = A_arbace_core_protocols__init_A_const_pool.A[115]; A_arbace_core_protocols__init_A_const_70 = A_arbace_core_protocols__init_A_const_pool.A[116]; A_arbace_core_protocols__init_A_const_71 = A_arbace_core_protocols__init_A_const_pool.A[117]; A_arbace_core_protocols__init_A_const_72 = A_arbace_core_protocols__init_A_const_pool.A[118]; A_arbace_core_protocols__init_A_const_73 = A_arbace_core_protocols__init_A_const_pool.A[119]; A_arbace_core_protocols__init_A_const_74 = A_arbace_core_protocols__init_A_const_pool.A[120]; A_arbace_core_protocols__init_A_const_75 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[121]); A_arbace_core_protocols__init_A_const_76 = A_arbace_core_protocols__init_A_const_pool.A[122]; A_arbace_core_protocols__init_A_const_77 = A_arbace_core_protocols__init_A_const_pool.A[123] }

func A_arbace_core_protocols__init_A_clinit_p6() { A_arbace_core_protocols__init_A_const_78 = jrt.Class_Cast(A_arbace_core_protocols__init_A_const_pool.A[124]); A_arbace_core_protocols__init_A_const_79 = A_arbace_core_protocols__init_A_const_pool.A[125]; A_arbace_core_protocols__init_A_const_80 = A_arbace_core_protocols__init_A_const_pool.A[126]; A_arbace_core_protocols__init_A_const_81 = A_arbace_core_protocols__init_A_const_pool.A[127]; A_arbace_core_protocols__init_A_const_82 = A_arbace_core_protocols__init_A_const_pool.A[128]; A_arbace_core_protocols__init_A_const_83 = A_arbace_core_protocols__init_A_const_pool.A[129]; A_arbace_core_protocols__init_A_const_84 = A_arbace_core_protocols__init_A_const_pool.A[130]; A_arbace_core_protocols__init_A_const_85 = A_arbace_core_protocols__init_A_const_pool.A[131]; A_arbace_core_protocols__init_A_const_86 = lang.Keyword_Cast(A_arbace_core_protocols__init_A_const_pool.A[132]); A_arbace_core_protocols__init_A_const_87 = lang.Var_Cast(A_arbace_core_protocols__init_A_const_pool.A[133]); A_arbace_core_protocols__init_A_const_88 = A_arbace_core_protocols__init_A_const_pool.A[134]; A_arbace_core_protocols__init_A_const_89 = A_arbace_core_protocols__init_A_const_pool.A[135]; A_arbace_core_protocols__init_A_const_90 = jrt.Class_Cast(A_arbace_core_protocols__init_A_const_pool.A[136]); A_arbace_core_protocols__init_A_const_91 = A_arbace_core_protocols__init_A_const_pool.A[137] }

func A_arbace_core_protocols__init_A_clinit_p7() { A_arbace_core_protocols__init_A_const_92 = A_arbace_core_protocols__init_A_const_pool.A[138]; A_arbace_core_protocols__init_A_const_93 = A_arbace_core_protocols__init_A_const_pool.A[139]; A_arbace_core_protocols__init_A_const_94 = A_arbace_core_protocols__init_A_const_pool.A[140]; A_arbace_core_protocols__init_A_const_95 = A_arbace_core_protocols__init_A_const_pool.A[141]; A_arbace_core_protocols__init_A_const_96 = A_arbace_core_protocols__init_A_const_pool.A[142]; A_arbace_core_protocols__init_A_const_97 = A_arbace_core_protocols__init_A_const_pool.A[143]; A_arbace_core_protocols__init_A_const_98 = lang.Keyword_Cast(A_arbace_core_protocols__init_A_const_pool.A[144]) }

func A_arbace_core_protocols__init_A_New() *A_arbace_core_protocols__init_A { A_arbace_core_protocols__init_A_Init(); t := &A_arbace_core_protocols__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols__init_A) Ctor() {}

func (t *A_arbace_core_protocols__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols__init_A_class }

func (t *A_arbace_core_protocols__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_protocols__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols__init_A); return ok }

func A_arbace_core_protocols__init_A_Cast(x any) *A_arbace_core_protocols__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols__init_A_class)) }; return v }
