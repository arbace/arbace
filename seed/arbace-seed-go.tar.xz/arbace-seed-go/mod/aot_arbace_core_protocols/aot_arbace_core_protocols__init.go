//line aot_arbace_core_protocols__init.ae:1
package aot_arbace_core_protocols

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_protocols__init_A_Load__O() any { A_arbace_core_protocols__init_A_Init(); A_arbace_core_protocols__init_A_Unit0__O(); A_arbace_core_protocols__init_A_Unit1__O(); A_arbace_core_protocols__init_A_Unit2__O(); A_arbace_core_protocols__init_A_Unit3__O(); A_arbace_core_protocols__init_A_Unit4__O(); A_arbace_core_protocols__init_A_Unit5__O(); A_arbace_core_protocols__init_A_Unit6__O(); A_arbace_core_protocols__init_A_Unit7__O(); A_arbace_core_protocols__init_A_Unit8__O(); A_arbace_core_protocols__init_A_Unit9__O(); A_arbace_core_protocols__init_A_Unit10__O(); A_arbace_core_protocols__init_A_Unit11__O(); A_arbace_core_protocols__init_A_Unit12__O(); A_arbace_core_protocols__init_A_Unit13__O(); A_arbace_core_protocols__init_A_Unit14__O(); A_arbace_core_protocols__init_A_Unit15__O(); A_arbace_core_protocols__init_A_Unit16__O(); A_arbace_core_protocols__init_A_Unit17__O(); A_arbace_core_protocols__init_A_Unit18__O(); A_arbace_core_protocols__init_A_Unit19__O(); A_arbace_core_protocols__init_A_Unit20__O(); A_arbace_core_protocols__init_A_Unit21__O(); A_arbace_core_protocols__init_A_Unit22__O(); A_arbace_core_protocols__init_A_Unit23__O(); A_arbace_core_protocols__init_A_Unit24__O(); A_arbace_core_protocols__init_A_Unit25__O(); A_arbace_core_protocols__init_A_Unit26__O(); A_arbace_core_protocols__init_A_Unit27__O(); A_arbace_core_protocols__init_A_Unit28__O(); A_arbace_core_protocols__init_A_Unit29__O(); A_arbace_core_protocols__init_A_Unit30__O(); A_arbace_core_protocols__init_A_Unit31__O(); A_arbace_core_protocols__init_A_Unit32__O(); A_arbace_core_protocols__init_A_Unit33__O(); A_arbace_core_protocols__init_A_Unit34__O(); A_arbace_core_protocols__init_A_Unit35__O(); A_arbace_core_protocols__init_A_Unit36__O(); A_arbace_core_protocols__init_A_Unit37__O(); A_arbace_core_protocols__init_A_Unit38__O(); A_arbace_core_protocols__init_A_Unit39__O(); A_arbace_core_protocols__init_A_Unit40__O(); A_arbace_core_protocols__init_A_Unit41__O(); A_arbace_core_protocols__init_A_Unit42__O(); A_arbace_core_protocols__init_A_Unit43__O(); A_arbace_core_protocols__init_A_Unit44__O(); A_arbace_core_protocols__init_A_Unit45__O(); A_arbace_core_protocols__init_A_Unit46__O(); A_arbace_core_protocols__init_A_Unit47__O(); A_arbace_core_protocols__init_A_Unit48__O(); A_arbace_core_protocols__init_A_Unit49__O(); A_arbace_core_protocols__init_A_Unit50__O(); A_arbace_core_protocols__init_A_Unit51__O(); A_arbace_core_protocols__init_A_Unit52__O(); A_arbace_core_protocols__init_A_Unit53__O(); A_arbace_core_protocols__init_A_Unit54__O(); A_arbace_core_protocols__init_A_Unit55__O(); A_arbace_core_protocols__init_A_Unit56__O(); A_arbace_core_protocols__init_A_Unit57__O(); A_arbace_core_protocols__init_A_Unit58__O(); A_arbace_core_protocols__init_A_Unit59__O(); return nil }



func A_arbace_core_protocols__init_A_Unit0__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_core_protocols__init_A_const_1) }
//line :9:1
func A_arbace_core_protocols__init_A_Unit1__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); var tmp1 any = A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_New(); var tmp2 *jrt.Class; A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_Init(); tmp2 = A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_core_protocols__init_A_Unit2__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_core_protocols__init_A_const_1)).Equals_O__Z(A_arbace_core_protocols__init_A_const_2) { return nil } else { var tmp1 any = A_arbace_core_protocols_eval619000006_fn__619000007_A_New(); var tmp2 *jrt.Class; A_arbace_core_protocols_eval619000006_fn__619000007_A_Init(); tmp2 = A_arbace_core_protocols_eval619000006_fn__619000007_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }

func A_arbace_core_protocols__init_A_Unit3__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(11, 1); var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_3; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return jrt.NN(tmp1).Set_O__O(tmp2.Ref()) }

func A_arbace_core_protocols__init_A_Unit4__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_5)); v__1927001498__auto____1 = A_arbace_core_protocols__init_A_const_4.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_protocols__init_A_const_4; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_6)); var tmp3 *lang.Var = A_arbace_core_protocols__init_A_const_4; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp3).BindRoot_O__V(tmp4.Ref()); return A_arbace_core_protocols__init_A_const_4.Ref() } }
//line :13:1
func A_arbace_core_protocols__init_A_Unit5__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); return A_arbace_core_protocols__init_A_const_7.Ref() }
//line :13:1
func A_arbace_core_protocols__init_A_Unit6__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_8).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_4.Ref(); return tmp1.Invoke_O_O_O_O__O(tmp2, jrt.NN(A_arbace_core_protocols__init_A_const_9).GetRawRoot__O(), A_arbace_core_protocols__init_A_const_10.Ref(), Lit_90) }
//line :13:1
func A_arbace_core_protocols__init_A_Unit7__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); return Up_Var_IFn(A_arbace_core_protocols__init_A_const_11).Invoke_O_O__O(A_arbace_core_protocols__init_A_const_4.Ref(), A_arbace_core_protocols__init_A_const_12) }
//line :13:1
func A_arbace_core_protocols__init_A_Unit8__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_13).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_4.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_14).GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_9).GetRawRoot__O()); var tmp5 any = A_arbace_core_protocols__init_A_const_15; var tmp6 any = A_arbace_core_protocols__init_A_const_16.Ref(); var tmp7 any = A_arbace_core_protocols__init_A_const_17; var tmp8 any = A_arbace_core_protocols__init_A_const_18.Ref(); var tmp9 any = A_arbace_core_protocols__init_A_const_4.Ref(); var tmp10 any = A_arbace_core_protocols__init_A_const_19.Ref(); var tmp11 any = A_arbace_core_protocols__init_A_const_20; var tmp12 any = A_arbace_core_protocols__init_A_const_21.Ref(); var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_24).GetRawRoot__O()); var tmp14 any = A_arbace_core_protocols__init_A_const_25; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_14).GetRawRoot__O()); var tmp16 any = A_arbace_core_protocols__init_A_const_26; var tmp17 any = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_22).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(A_arbace_core_protocols__init_A_const_23).Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_protocols__init_A_const_27.Ref(), A_arbace_core_protocols__init_A_const_4.Ref()))))); var tmp18 any = A_arbace_core_protocols_eval619000020_fn__619000021_A_New(); var tmp19 *jrt.Class; A_arbace_core_protocols_eval619000020_fn__619000021_A_Init(); tmp19 = A_arbace_core_protocols_eval619000020_fn__619000021_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :13:1
func A_arbace_core_protocols__init_A_Unit9__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_28).GetRawRoot__O()).Invoke_O__O(jrt.NN(A_arbace_core_protocols__init_A_const_4).GetRawRoot__O()) }
//line :13:1
func A_arbace_core_protocols__init_A_Unit10__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); return A_arbace_core_protocols__init_A_const_29 }





func A_arbace_core_protocols__init_A_Unit11__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_30; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_31)); v__1927001498__auto____1 = A_arbace_core_protocols__init_A_const_30.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_protocols__init_A_const_30; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_32)); var tmp3 *lang.Var = A_arbace_core_protocols__init_A_const_30; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp3).BindRoot_O__V(tmp4.Ref()); return A_arbace_core_protocols__init_A_const_30.Ref() } }
//line :19:1
func A_arbace_core_protocols__init_A_Unit12__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); return A_arbace_core_protocols__init_A_const_33.Ref() }
//line :19:1
func A_arbace_core_protocols__init_A_Unit13__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_8).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_30.Ref(); return tmp1.Invoke_O_O_O_O__O(tmp2, jrt.NN(A_arbace_core_protocols__init_A_const_9).GetRawRoot__O(), A_arbace_core_protocols__init_A_const_10.Ref(), Lit_104) }
//line :19:1
func A_arbace_core_protocols__init_A_Unit14__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); return Up_Var_IFn(A_arbace_core_protocols__init_A_const_11).Invoke_O_O__O(A_arbace_core_protocols__init_A_const_30.Ref(), A_arbace_core_protocols__init_A_const_34) }
//line :19:1
func A_arbace_core_protocols__init_A_Unit15__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_13).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_30.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_14).GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_9).GetRawRoot__O()); var tmp5 any = A_arbace_core_protocols__init_A_const_35; var tmp6 any = A_arbace_core_protocols__init_A_const_16.Ref(); var tmp7 any = A_arbace_core_protocols__init_A_const_36; var tmp8 any = A_arbace_core_protocols__init_A_const_18.Ref(); var tmp9 any = A_arbace_core_protocols__init_A_const_30.Ref(); var tmp10 any = A_arbace_core_protocols__init_A_const_19.Ref(); var tmp11 any = A_arbace_core_protocols__init_A_const_37; var tmp12 any = A_arbace_core_protocols__init_A_const_21.Ref(); var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_24).GetRawRoot__O()); var tmp14 any = A_arbace_core_protocols__init_A_const_38; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_14).GetRawRoot__O()); var tmp16 any = A_arbace_core_protocols__init_A_const_39; var tmp17 any = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_22).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(A_arbace_core_protocols__init_A_const_23).Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_protocols__init_A_const_27.Ref(), A_arbace_core_protocols__init_A_const_30.Ref()))))); var tmp18 any = A_arbace_core_protocols_eval619000050_fn__619000051_A_New(); var tmp19 *jrt.Class; A_arbace_core_protocols_eval619000050_fn__619000051_A_Init(); tmp19 = A_arbace_core_protocols_eval619000050_fn__619000051_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :19:1
func A_arbace_core_protocols__init_A_Unit16__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_28).GetRawRoot__O()).Invoke_O__O(jrt.NN(A_arbace_core_protocols__init_A_const_30).GetRawRoot__O()) }
//line :19:1
func A_arbace_core_protocols__init_A_Unit17__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); return A_arbace_core_protocols__init_A_const_40 }




func A_arbace_core_protocols__init_A_Unit18__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_41; var tmp2 any = A_arbace_core_protocols_seq_reduce_A_New(); var tmp3 *jrt.Class; A_arbace_core_protocols_seq_reduce_A_Init(); tmp3 = A_arbace_core_protocols_seq_reduce_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_protocols__init_A_const_41; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_42)); return A_arbace_core_protocols__init_A_const_41.Ref() }









func A_arbace_core_protocols__init_A_Unit19__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_43; var tmp2 any = A_arbace_core_protocols_iterator_reduce_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_core_protocols_iterator_reduce_BANG__A_Init(); tmp3 = A_arbace_core_protocols_iterator_reduce_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_protocols__init_A_const_43; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_44)); return A_arbace_core_protocols__init_A_const_43.Ref() }













func A_arbace_core_protocols__init_A_Unit20__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_45; var tmp2 any = A_arbace_core_protocols_iter_reduce_A_New(); var tmp3 *jrt.Class; A_arbace_core_protocols_iter_reduce_A_Init(); tmp3 = A_arbace_core_protocols_iter_reduce_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_protocols__init_A_const_45; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_46)); return A_arbace_core_protocols__init_A_const_45.Ref() }





func A_arbace_core_protocols__init_A_Unit21__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(54, 1); var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_47; var tmp2 any = A_arbace_core_protocols_naive_seq_reduce_A_New(); var tmp3 *jrt.Class; A_arbace_core_protocols_naive_seq_reduce_A_Init(); tmp3 = A_arbace_core_protocols_naive_seq_reduce_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_protocols__init_A_const_47; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_48)); return A_arbace_core_protocols__init_A_const_47.Ref() }












func A_arbace_core_protocols__init_A_Unit22__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(67, 1); var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_49; var tmp2 any = A_arbace_core_protocols_interface_or_naive_reduce_A_New(); var tmp3 *jrt.Class; A_arbace_core_protocols_interface_or_naive_reduce_A_Init(); tmp3 = A_arbace_core_protocols_interface_or_naive_reduce_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_protocols__init_A_const_49; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_50)); return A_arbace_core_protocols__init_A_const_49.Ref() }






func A_arbace_core_protocols__init_A_Unit23__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_51).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_core_protocols__init_A_const_4).GetRawRoot__O(); var tmp3 any = A_arbace_core_protocols__init_A_const_52.Ref(); var tmp4 any = A_arbace_core_protocols_eval619000073_fn__619000074_A_New(); var tmp5 *jrt.Class; A_arbace_core_protocols_eval619000073_fn__619000074_A_Init(); tmp5 = A_arbace_core_protocols_eval619000073_fn__619000074_A_fn_class; return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)))) }
//line :74:1
func A_arbace_core_protocols__init_A_Unit24__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_51).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_53.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_4).GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_52.Ref(); var tmp5 any = A_arbace_core_protocols_eval619000077_fn__619000078_A_New(); var tmp6 *jrt.Class; A_arbace_core_protocols_eval619000077_fn__619000078_A_Init(); tmp6 = A_arbace_core_protocols_eval619000077_fn__619000078_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :74:1
func A_arbace_core_protocols__init_A_Unit25__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_51).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_54.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_4).GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_52.Ref(); var tmp5 any = A_arbace_core_protocols_eval619000081_fn__619000082_A_New(); var tmp6 *jrt.Class; A_arbace_core_protocols_eval619000081_fn__619000082_A_Init(); tmp6 = A_arbace_core_protocols_eval619000081_fn__619000082_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :74:1
func A_arbace_core_protocols__init_A_Unit26__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_51).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_55.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_4).GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_52.Ref(); var tmp5 any = A_arbace_core_protocols_eval619000085_fn__619000086_A_New(); var tmp6 *jrt.Class; A_arbace_core_protocols_eval619000085_fn__619000086_A_Init(); tmp6 = A_arbace_core_protocols_eval619000085_fn__619000086_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :74:1
func A_arbace_core_protocols__init_A_Unit27__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_51).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_56.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_4).GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_52.Ref(); var tmp5 any = A_arbace_core_protocols_eval619000089_fn__619000090_A_New(); var tmp6 *jrt.Class; A_arbace_core_protocols_eval619000089_fn__619000090_A_Init(); tmp6 = A_arbace_core_protocols_eval619000089_fn__619000090_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :74:1
func A_arbace_core_protocols__init_A_Unit28__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_51).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_57.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_4).GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_52.Ref(); var tmp5 any = A_arbace_core_protocols_eval619000093_fn__619000094_A_New(); var tmp6 *jrt.Class; A_arbace_core_protocols_eval619000093_fn__619000094_A_Init(); tmp6 = A_arbace_core_protocols_eval619000093_fn__619000094_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :74:1
func A_arbace_core_protocols__init_A_Unit29__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_51).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_58.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_4).GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_52.Ref(); var tmp5 any = A_arbace_core_protocols_eval619000099_fn__619000100_A_New(); var tmp6 *jrt.Class; A_arbace_core_protocols_eval619000099_fn__619000100_A_Init(); tmp6 = A_arbace_core_protocols_eval619000099_fn__619000100_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :74:1
func A_arbace_core_protocols__init_A_Unit30__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_51).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_59.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_4).GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_52.Ref(); var tmp5 any = A_arbace_core_protocols_eval619000103_fn__619000104_A_New(); var tmp6 *jrt.Class; A_arbace_core_protocols_eval619000103_fn__619000104_A_Init(); tmp6 = A_arbace_core_protocols_eval619000103_fn__619000104_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :74:1
func A_arbace_core_protocols__init_A_Unit31__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_51).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_60.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_4).GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_52.Ref(); var tmp5 any = A_arbace_core_protocols_eval619000107_fn__619000108_A_New(); var tmp6 *jrt.Class; A_arbace_core_protocols_eval619000107_fn__619000108_A_Init(); tmp6 = A_arbace_core_protocols_eval619000107_fn__619000108_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }

























































func A_arbace_core_protocols__init_A_Unit32__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(132, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_51).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_core_protocols__init_A_const_30).GetRawRoot__O(); var tmp3 any = A_arbace_core_protocols__init_A_const_61.Ref(); var tmp4 any = A_arbace_core_protocols_eval619000111_fn__619000112_A_New(); var tmp5 *jrt.Class; A_arbace_core_protocols_eval619000111_fn__619000112_A_Init(); tmp5 = A_arbace_core_protocols_eval619000111_fn__619000112_A_fn_class; return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)))) }
//line :132:1
func A_arbace_core_protocols__init_A_Unit33__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(132, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_51).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_62.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_30).GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_61.Ref(); var tmp5 any = A_arbace_core_protocols_eval619000115_fn__619000116_A_New(); var tmp6 *jrt.Class; A_arbace_core_protocols_eval619000115_fn__619000116_A_Init(); tmp6 = A_arbace_core_protocols_eval619000115_fn__619000116_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :132:1
func A_arbace_core_protocols__init_A_Unit34__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(132, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_51).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_63.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_30).GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_61.Ref(); var tmp5 any = A_arbace_core_protocols_eval619000119_fn__619000120_A_New(); var tmp6 *jrt.Class; A_arbace_core_protocols_eval619000119_fn__619000120_A_Init(); tmp6 = A_arbace_core_protocols_eval619000119_fn__619000120_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :132:1
func A_arbace_core_protocols__init_A_Unit35__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(132, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_51).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_53.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_30).GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_61.Ref(); var tmp5 any = A_arbace_core_protocols_eval619000123_fn__619000124_A_New(); var tmp6 *jrt.Class; A_arbace_core_protocols_eval619000123_fn__619000124_A_Init(); tmp6 = A_arbace_core_protocols_eval619000123_fn__619000124_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }


















































func A_arbace_core_protocols__init_A_Unit36__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(183, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_64; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_65)); v__1927001498__auto____1 = A_arbace_core_protocols__init_A_const_64.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_protocols__init_A_const_64; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_66)); var tmp3 *lang.Var = A_arbace_core_protocols__init_A_const_64; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp3).BindRoot_O__V(tmp4.Ref()); return A_arbace_core_protocols__init_A_const_64.Ref() } }
//line :183:1
func A_arbace_core_protocols__init_A_Unit37__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(183, 1); return A_arbace_core_protocols__init_A_const_67.Ref() }
//line :183:1
func A_arbace_core_protocols__init_A_Unit38__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(183, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_8).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_64.Ref(); return tmp1.Invoke_O_O_O_O__O(tmp2, jrt.NN(A_arbace_core_protocols__init_A_const_9).GetRawRoot__O(), A_arbace_core_protocols__init_A_const_10.Ref(), Lit_127) }
//line :183:1
func A_arbace_core_protocols__init_A_Unit39__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(183, 1); return Up_Var_IFn(A_arbace_core_protocols__init_A_const_11).Invoke_O_O__O(A_arbace_core_protocols__init_A_const_64.Ref(), A_arbace_core_protocols__init_A_const_68) }
//line :183:1
func A_arbace_core_protocols__init_A_Unit40__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(183, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_13).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_64.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_14).GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_9).GetRawRoot__O()); var tmp5 any = A_arbace_core_protocols__init_A_const_69; var tmp6 any = A_arbace_core_protocols__init_A_const_16.Ref(); var tmp7 any = A_arbace_core_protocols__init_A_const_70; var tmp8 any = A_arbace_core_protocols__init_A_const_18.Ref(); var tmp9 any = A_arbace_core_protocols__init_A_const_64.Ref(); var tmp10 any = A_arbace_core_protocols__init_A_const_19.Ref(); var tmp11 any = A_arbace_core_protocols__init_A_const_71; var tmp12 any = A_arbace_core_protocols__init_A_const_21.Ref(); var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_24).GetRawRoot__O()); var tmp14 any = A_arbace_core_protocols__init_A_const_72; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_14).GetRawRoot__O()); var tmp16 any = A_arbace_core_protocols__init_A_const_73; var tmp17 any = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_22).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(A_arbace_core_protocols__init_A_const_23).Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_protocols__init_A_const_27.Ref(), A_arbace_core_protocols__init_A_const_64.Ref()))))); var tmp18 any = A_arbace_core_protocols_eval619000135_fn__619000136_A_New(); var tmp19 *jrt.Class; A_arbace_core_protocols_eval619000135_fn__619000136_A_Init(); tmp19 = A_arbace_core_protocols_eval619000135_fn__619000136_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :183:1
func A_arbace_core_protocols__init_A_Unit41__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(183, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_28).GetRawRoot__O()).Invoke_O__O(jrt.NN(A_arbace_core_protocols__init_A_const_64).GetRawRoot__O()) }
//line :183:1
func A_arbace_core_protocols__init_A_Unit42__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(183, 1); return A_arbace_core_protocols__init_A_const_74 }






func A_arbace_core_protocols__init_A_Unit43__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(190, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_75; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_76)); v__1927001498__auto____1 = A_arbace_core_protocols__init_A_const_75.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_protocols__init_A_const_75; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_77)); var tmp3 *lang.Var = A_arbace_core_protocols__init_A_const_75; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp3).BindRoot_O__V(tmp4.Ref()); return A_arbace_core_protocols__init_A_const_75.Ref() } }
//line :190:1
func A_arbace_core_protocols__init_A_Unit44__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(190, 1); return A_arbace_core_protocols__init_A_const_78.Ref() }
//line :190:1
func A_arbace_core_protocols__init_A_Unit45__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(190, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_8).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_75.Ref(); return tmp1.Invoke_O_O_O_O__O(tmp2, jrt.NN(A_arbace_core_protocols__init_A_const_9).GetRawRoot__O(), A_arbace_core_protocols__init_A_const_10.Ref(), nil) }
//line :190:1
func A_arbace_core_protocols__init_A_Unit46__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(190, 1); return Up_Var_IFn(A_arbace_core_protocols__init_A_const_11).Invoke_O_O__O(A_arbace_core_protocols__init_A_const_75.Ref(), A_arbace_core_protocols__init_A_const_79) }
//line :190:1
func A_arbace_core_protocols__init_A_Unit47__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(190, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_13).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_75.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_14).GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_9).GetRawRoot__O()); var tmp5 any = A_arbace_core_protocols__init_A_const_80; var tmp6 any = A_arbace_core_protocols__init_A_const_16.Ref(); var tmp7 any = A_arbace_core_protocols__init_A_const_81; var tmp8 any = A_arbace_core_protocols__init_A_const_18.Ref(); var tmp9 any = A_arbace_core_protocols__init_A_const_75.Ref(); var tmp10 any = A_arbace_core_protocols__init_A_const_19.Ref(); var tmp11 any = A_arbace_core_protocols__init_A_const_82; var tmp12 any = A_arbace_core_protocols__init_A_const_21.Ref(); var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_24).GetRawRoot__O()); var tmp14 any = A_arbace_core_protocols__init_A_const_83; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_14).GetRawRoot__O()); var tmp16 any = A_arbace_core_protocols__init_A_const_84; var tmp17 any = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_22).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(A_arbace_core_protocols__init_A_const_23).Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_protocols__init_A_const_27.Ref(), A_arbace_core_protocols__init_A_const_75.Ref()))))); var tmp18 any = A_arbace_core_protocols_eval619000161_fn__619000162_A_New(); var tmp19 *jrt.Class; A_arbace_core_protocols_eval619000161_fn__619000162_A_Init(); tmp19 = A_arbace_core_protocols_eval619000161_fn__619000162_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :190:1
func A_arbace_core_protocols__init_A_Unit48__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(190, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_28).GetRawRoot__O()).Invoke_O__O(jrt.NN(A_arbace_core_protocols__init_A_const_75).GetRawRoot__O()) }
//line :190:1
func A_arbace_core_protocols__init_A_Unit49__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(190, 1); return A_arbace_core_protocols__init_A_const_85 }




func A_arbace_core_protocols__init_A_Unit50__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(195, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_51).GetRawRoot__O()); var tmp2 any = jrt.NN(A_arbace_core_protocols__init_A_const_75).GetRawRoot__O(); var tmp3 any = A_arbace_core_protocols__init_A_const_86.Ref(); var tmp4 any = A_arbace_core_protocols_eval619000175_fn__619000176_A_New(); var tmp5 *jrt.Class; A_arbace_core_protocols_eval619000175_fn__619000176_A_Init(); tmp5 = A_arbace_core_protocols_eval619000175_fn__619000176_A_fn_class; return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)))) }
//line :195:1
func A_arbace_core_protocols__init_A_Unit51__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(195, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_51).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_53.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_75).GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_86.Ref(); var tmp5 any = A_arbace_core_protocols_eval619000179_fn__619000180_A_New(); var tmp6 *jrt.Class; A_arbace_core_protocols_eval619000179_fn__619000180_A_Init(); tmp6 = A_arbace_core_protocols_eval619000179_fn__619000180_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }






func A_arbace_core_protocols__init_A_Unit52__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_protocols__init_A_const_87; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_88)); v__1927001498__auto____1 = A_arbace_core_protocols__init_A_const_87.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_protocols__init_A_const_87; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_protocols__init_A_const_89)); var tmp3 *lang.Var = A_arbace_core_protocols__init_A_const_87; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp3).BindRoot_O__V(tmp4.Ref()); return A_arbace_core_protocols__init_A_const_87.Ref() } }
//line :202:1
func A_arbace_core_protocols__init_A_Unit53__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); return A_arbace_core_protocols__init_A_const_90.Ref() }
//line :202:1
func A_arbace_core_protocols__init_A_Unit54__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_8).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_87.Ref(); return tmp1.Invoke_O_O_O_O__O(tmp2, jrt.NN(A_arbace_core_protocols__init_A_const_9).GetRawRoot__O(), A_arbace_core_protocols__init_A_const_10.Ref(), nil) }
//line :202:1
func A_arbace_core_protocols__init_A_Unit55__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); return Up_Var_IFn(A_arbace_core_protocols__init_A_const_11).Invoke_O_O__O(A_arbace_core_protocols__init_A_const_87.Ref(), A_arbace_core_protocols__init_A_const_91) }
//line :202:1
func A_arbace_core_protocols__init_A_Unit56__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_13).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_87.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_14).GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_9).GetRawRoot__O()); var tmp5 any = A_arbace_core_protocols__init_A_const_92; var tmp6 any = A_arbace_core_protocols__init_A_const_16.Ref(); var tmp7 any = A_arbace_core_protocols__init_A_const_93; var tmp8 any = A_arbace_core_protocols__init_A_const_18.Ref(); var tmp9 any = A_arbace_core_protocols__init_A_const_87.Ref(); var tmp10 any = A_arbace_core_protocols__init_A_const_19.Ref(); var tmp11 any = A_arbace_core_protocols__init_A_const_94; var tmp12 any = A_arbace_core_protocols__init_A_const_21.Ref(); var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_24).GetRawRoot__O()); var tmp14 any = A_arbace_core_protocols__init_A_const_95; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_14).GetRawRoot__O()); var tmp16 any = A_arbace_core_protocols__init_A_const_96; var tmp17 any = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_22).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(A_arbace_core_protocols__init_A_const_23).Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_protocols__init_A_const_27.Ref(), A_arbace_core_protocols__init_A_const_87.Ref()))))); var tmp18 any = A_arbace_core_protocols_eval619000191_fn__619000192_A_New(); var tmp19 *jrt.Class; A_arbace_core_protocols_eval619000191_fn__619000192_A_Init(); tmp19 = A_arbace_core_protocols_eval619000191_fn__619000192_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :202:1
func A_arbace_core_protocols__init_A_Unit57__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_28).GetRawRoot__O()).Invoke_O__O(jrt.NN(A_arbace_core_protocols__init_A_const_87).GetRawRoot__O()) }
//line :202:1
func A_arbace_core_protocols__init_A_Unit58__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); return A_arbace_core_protocols__init_A_const_97 }





func A_arbace_core_protocols__init_A_Unit59__O() any { A_arbace_core_protocols__init_A_Init(); lang.Compiler_AOT_At_I_I__V(208, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_core_protocols__init_A_const_51).GetRawRoot__O()); var tmp2 any = A_arbace_core_protocols__init_A_const_53.Ref(); var tmp3 any = jrt.NN(A_arbace_core_protocols__init_A_const_87).GetRawRoot__O(); var tmp4 any = A_arbace_core_protocols__init_A_const_98.Ref(); var tmp5 any = A_arbace_core_protocols_eval619000209_fn__619000210_A_New(); var tmp6 *jrt.Class; A_arbace_core_protocols_eval619000209_fn__619000210_A_Init(); tmp6 = A_arbace_core_protocols_eval619000209_fn__619000210_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
























type A_arbace_core_protocols__init_A struct{ jrt.Object }

var A_arbace_core_protocols__init_A_const_0 *lang.Var

var A_arbace_core_protocols__init_A_const_1 any

var A_arbace_core_protocols__init_A_const_2 any

var A_arbace_core_protocols__init_A_const_3 *lang.Var

var A_arbace_core_protocols__init_A_const_4 *lang.Var

var A_arbace_core_protocols__init_A_const_5 any

var A_arbace_core_protocols__init_A_const_6 any

var A_arbace_core_protocols__init_A_const_7 *jrt.Class

var A_arbace_core_protocols__init_A_const_8 *lang.Var

var A_arbace_core_protocols__init_A_const_9 *lang.Var

var A_arbace_core_protocols__init_A_const_10 *lang.Keyword

var A_arbace_core_protocols__init_A_const_11 *lang.Var

var A_arbace_core_protocols__init_A_const_12 any

var A_arbace_core_protocols__init_A_const_13 *lang.Var

var A_arbace_core_protocols__init_A_const_14 *lang.Var

var A_arbace_core_protocols__init_A_const_15 any

var A_arbace_core_protocols__init_A_const_16 *lang.Keyword

var A_arbace_core_protocols__init_A_const_17 any

var A_arbace_core_protocols__init_A_const_18 *lang.Keyword

var A_arbace_core_protocols__init_A_const_19 *lang.Keyword

var A_arbace_core_protocols__init_A_const_20 any

var A_arbace_core_protocols__init_A_const_21 *lang.Keyword

var A_arbace_core_protocols__init_A_const_22 *lang.Var

var A_arbace_core_protocols__init_A_const_23 *lang.Var

var A_arbace_core_protocols__init_A_const_24 *lang.Var

var A_arbace_core_protocols__init_A_const_25 any

var A_arbace_core_protocols__init_A_const_26 any

var A_arbace_core_protocols__init_A_const_27 *lang.Keyword

var A_arbace_core_protocols__init_A_const_28 *lang.Var

var A_arbace_core_protocols__init_A_const_29 any

var A_arbace_core_protocols__init_A_const_30 *lang.Var

var A_arbace_core_protocols__init_A_const_31 any

var A_arbace_core_protocols__init_A_const_32 any

var A_arbace_core_protocols__init_A_const_33 *jrt.Class

var A_arbace_core_protocols__init_A_const_34 any

var A_arbace_core_protocols__init_A_const_35 any

var A_arbace_core_protocols__init_A_const_36 any

var A_arbace_core_protocols__init_A_const_37 any

var A_arbace_core_protocols__init_A_const_38 any

var A_arbace_core_protocols__init_A_const_39 any

var A_arbace_core_protocols__init_A_const_40 any

var A_arbace_core_protocols__init_A_const_41 *lang.Var

var A_arbace_core_protocols__init_A_const_42 any

var A_arbace_core_protocols__init_A_const_43 *lang.Var

var A_arbace_core_protocols__init_A_const_44 any

var A_arbace_core_protocols__init_A_const_45 *lang.Var

var A_arbace_core_protocols__init_A_const_46 any

var A_arbace_core_protocols__init_A_const_47 *lang.Var

var A_arbace_core_protocols__init_A_const_48 any

var A_arbace_core_protocols__init_A_const_49 *lang.Var

var A_arbace_core_protocols__init_A_const_50 any

var A_arbace_core_protocols__init_A_const_51 *lang.Var

var A_arbace_core_protocols__init_A_const_52 *lang.Keyword

var A_arbace_core_protocols__init_A_const_53 *jrt.Class

var A_arbace_core_protocols__init_A_const_54 *jrt.Class

var A_arbace_core_protocols__init_A_const_55 *jrt.Class

var A_arbace_core_protocols__init_A_const_56 *jrt.Class

var A_arbace_core_protocols__init_A_const_57 *jrt.Class

var A_arbace_core_protocols__init_A_const_58 *jrt.Class

var A_arbace_core_protocols__init_A_const_59 *jrt.Class

var A_arbace_core_protocols__init_A_const_60 *jrt.Class

var A_arbace_core_protocols__init_A_const_61 *lang.Keyword

var A_arbace_core_protocols__init_A_const_62 *jrt.Class

var A_arbace_core_protocols__init_A_const_63 *jrt.Class

var A_arbace_core_protocols__init_A_const_64 *lang.Var

var A_arbace_core_protocols__init_A_const_65 any

var A_arbace_core_protocols__init_A_const_66 any

var A_arbace_core_protocols__init_A_const_67 *jrt.Class

var A_arbace_core_protocols__init_A_const_68 any

var A_arbace_core_protocols__init_A_const_69 any

var A_arbace_core_protocols__init_A_const_70 any

var A_arbace_core_protocols__init_A_const_71 any

var A_arbace_core_protocols__init_A_const_72 any

var A_arbace_core_protocols__init_A_const_73 any

var A_arbace_core_protocols__init_A_const_74 any

var A_arbace_core_protocols__init_A_const_75 *lang.Var

var A_arbace_core_protocols__init_A_const_76 any

var A_arbace_core_protocols__init_A_const_77 any

var A_arbace_core_protocols__init_A_const_78 *jrt.Class

var A_arbace_core_protocols__init_A_const_79 any

var A_arbace_core_protocols__init_A_const_80 any

var A_arbace_core_protocols__init_A_const_81 any

var A_arbace_core_protocols__init_A_const_82 any

var A_arbace_core_protocols__init_A_const_83 any

var A_arbace_core_protocols__init_A_const_84 any

var A_arbace_core_protocols__init_A_const_85 any

var A_arbace_core_protocols__init_A_const_86 *lang.Keyword

var A_arbace_core_protocols__init_A_const_87 *lang.Var

var A_arbace_core_protocols__init_A_const_88 any

var A_arbace_core_protocols__init_A_const_89 any

var A_arbace_core_protocols__init_A_const_90 *jrt.Class

var A_arbace_core_protocols__init_A_const_91 any

var A_arbace_core_protocols__init_A_const_92 any

var A_arbace_core_protocols__init_A_const_93 any

var A_arbace_core_protocols__init_A_const_94 any

var A_arbace_core_protocols__init_A_const_95 any

var A_arbace_core_protocols__init_A_const_96 any

var A_arbace_core_protocols__init_A_const_97 any

var A_arbace_core_protocols__init_A_const_98 *lang.Keyword

var A_arbace_core_protocols__init_A_init jrt.ClassInit

func A_arbace_core_protocols__init_A_Init() { if !A_arbace_core_protocols__init_A_init.Done() { A_arbace_core_protocols__init_A_init.Run(A_arbace_core_protocols__init_A_clinit) } }

func A_arbace_core_protocols__init_A_clinit() { A_arbace_core_protocols__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_70); A_arbace_core_protocols__init_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref(); A_arbace_core_protocols__init_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_core_protocols__init_A_const_3 = lang.RT_Var_String_String__Var(Lit_0, Lit_71); A_arbace_core_protocols__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_5, Lit_72); A_arbace_core_protocols__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(13).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), Lit_76)); A_arbace_core_protocols__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(13).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), Lit_76)); A_arbace_core_protocols__init_A_const_7 = lang.RT_ClassForNameNonLoading_String__Class(Lit_8); A_arbace_core_protocols__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_77); A_arbace_core_protocols__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_78); A_arbace_core_protocols__init_A_const_10 = lang.RT_Keyword_String_String__Keyword(nil, Lit_79); A_arbace_core_protocols__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_core_protocols__init_A_const_12 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_81)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref())))))))))); A_arbace_core_protocols__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_86); A_arbace_core_protocols__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_87); A_arbace_core_protocols__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), lang.RT_ClassForNameNonLoading_String__Class(Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), Lit_90)); A_arbace_core_protocols__init_A_const_16 = lang.RT_Keyword_String_String__Keyword(nil, Lit_91); A_arbace_core_protocols__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_81)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil)))); A_arbace_core_protocols__init_A_const_18 = lang.RT_Keyword_String_String__Keyword(nil, Lit_94); A_arbace_core_protocols__init_A_const_19 = lang.RT_Keyword_String_String__Keyword(nil, Lit_95); A_arbace_core_protocols__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref())); A_arbace_core_protocols__init_A_const_21 = lang.RT_Keyword_String_String__Keyword(nil, Lit_96); A_arbace_core_protocols__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_97); A_arbace_core_protocols__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_98); A_arbace_core_protocols__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_99); A_arbace_core_protocols__init_A_const_25 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_81)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref()))))))); A_arbace_core_protocols__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_81)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil)); A_arbace_core_protocols__init_A_const_27 = lang.RT_Keyword_String_String__Keyword(nil, Lit_100); A_arbace_core_protocols__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_101); A_arbace_core_protocols__init_A_const_29 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_72).Ref(); A_arbace_core_protocols__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_5, Lit_102); A_arbace_core_protocols__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), Lit_76)); A_arbace_core_protocols__init_A_const_32 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), Lit_76)); A_arbace_core_protocols__init_A_const_33 = lang.RT_ClassForNameNonLoading_String__Class(Lit_9); A_arbace_core_protocols__init_A_const_34 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref())))))))))); A_arbace_core_protocols__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), lang.RT_ClassForNameNonLoading_String__Class(Lit_9).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), Lit_104)); A_arbace_core_protocols__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil)))); A_arbace_core_protocols__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref())); A_arbace_core_protocols__init_A_const_38 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref()))))))); A_arbace_core_protocols__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil)); A_arbace_core_protocols__init_A_const_40 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_102).Ref(); A_arbace_core_protocols__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_5, Lit_16); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_105).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_core_protocols__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(24).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), Lit_76)); A_arbace_core_protocols__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_5, Lit_14); A_arbace_core_protocols__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_107).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_107).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(34).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), Lit_76)); A_arbace_core_protocols__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_5, Lit_17); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_105).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_core_protocols__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_108).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_108).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(48).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), Lit_76)); A_arbace_core_protocols__init_A_const_47 = lang.RT_Var_String_String__Var(Lit_5, Lit_15); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_105).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_core_protocols__init_A_const_48 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), Lit_110, lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(54).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), Lit_76)); A_arbace_core_protocols__init_A_const_49 = lang.RT_Var_String_String__Var(Lit_5, Lit_20); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_105).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_core_protocols__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), Lit_111, lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(67).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), Lit_76)); A_arbace_core_protocols__init_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_112); A_arbace_core_protocols__init_A_const_52 = lang.RT_Keyword_String_String__Keyword(nil, Lit_81); A_arbace_core_protocols__init_A_const_53 = lang.RT_ClassForNameNonLoading_String__Class(Lit_113); A_arbace_core_protocols__init_A_const_54 = lang.RT_ClassForNameNonLoading_String__Class(Lit_114); A_arbace_core_protocols__init_A_const_55 = lang.RT_ClassForNameNonLoading_String__Class(Lit_115); A_arbace_core_protocols__init_A_const_56 = lang.RT_ClassForNameNonLoading_String__Class(Lit_116); A_arbace_core_protocols__init_A_const_57 = lang.RT_ClassForNameNonLoading_String__Class(Lit_117); A_arbace_core_protocols__init_A_const_58 = lang.RT_ClassForNameNonLoading_String__Class(Lit_118); A_arbace_core_protocols__init_A_const_59 = lang.RT_ClassForNameNonLoading_String__Class(Lit_119); A_arbace_core_protocols__init_A_const_60 = lang.RT_ClassForNameNonLoading_String__Class(Lit_120); A_arbace_core_protocols__init_A_const_61 = lang.RT_Keyword_String_String__Keyword(nil, Lit_11); A_arbace_core_protocols__init_A_const_62 = lang.RT_ClassForNameNonLoading_String__Class(Lit_121); A_arbace_core_protocols__init_A_const_63 = lang.RT_ClassForNameNonLoading_String__Class(Lit_122); A_arbace_core_protocols__init_A_const_64 = lang.RT_Var_String_String__Var(Lit_5, Lit_123); A_arbace_core_protocols__init_A_const_65 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(183).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), Lit_76)); A_arbace_core_protocols__init_A_const_66 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(183).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), Lit_76)); A_arbace_core_protocols__init_A_const_67 = lang.RT_ClassForNameNonLoading_String__Class(Lit_23); A_arbace_core_protocols__init_A_const_68 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_124)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_125).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref())))))))))); A_arbace_core_protocols__init_A_const_69 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_23).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), lang.RT_ClassForNameNonLoading_String__Class(Lit_23).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), Lit_127)); A_arbace_core_protocols__init_A_const_70 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_124)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_125).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_125).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil)))); A_arbace_core_protocols__init_A_const_71 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref())); A_arbace_core_protocols__init_A_const_72 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_124)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_125).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref()))))))); A_arbace_core_protocols__init_A_const_73 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_124)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_125).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_125).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), nil)); A_arbace_core_protocols__init_A_const_74 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_123).Ref(); A_arbace_core_protocols__init_A_const_75 = lang.RT_Var_String_String__Var(Lit_5, Lit_128); A_arbace_core_protocols__init_A_const_76 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(190).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), Lit_76)); A_arbace_core_protocols__init_A_const_77 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(190).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), Lit_76)); A_arbace_core_protocols__init_A_const_78 = lang.RT_ClassForNameNonLoading_String__Class(Lit_24); A_arbace_core_protocols__init_A_const_79 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_57)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), Lit_129, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_130).Ref())))))))))); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(); var tmp14 any = lang.Symbol_Intern_String_String__Symbol(nil, Lit_24).Ref(); var tmp15 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(); var tmp16 any = lang.RT_ClassForNameNonLoading_String__Class(Lit_24).Ref(); var tmp17 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(); var tmp18 *jrt.Boolean; jrt.Boolean_Init(); tmp18 = jrt.Boolean_TRUE; A_arbace_core_protocols__init_A_const_80 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18.Ref())); A_arbace_core_protocols__init_A_const_81 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_57)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), Lit_129, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_130).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_130).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), Lit_129)))); A_arbace_core_protocols__init_A_const_82 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref())); A_arbace_core_protocols__init_A_const_83 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_57)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), Lit_129, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_130).Ref()))))))); A_arbace_core_protocols__init_A_const_84 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_57)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), Lit_129, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_130).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_130).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), Lit_129)); A_arbace_core_protocols__init_A_const_85 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_128).Ref(); A_arbace_core_protocols__init_A_const_86 = lang.RT_Keyword_String_String__Keyword(nil, Lit_57); A_arbace_core_protocols__init_A_const_87 = lang.RT_Var_String_String__Var(Lit_5, Lit_132); A_arbace_core_protocols__init_A_const_88 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(202).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), Lit_76)); A_arbace_core_protocols__init_A_const_89 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), jrt.Integer_ValueOf_I__Integer(202).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), Lit_76)); A_arbace_core_protocols__init_A_const_90 = lang.RT_ClassForNameNonLoading_String__Class(Lit_25); A_arbace_core_protocols__init_A_const_91 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_63)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), Lit_133, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_134).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_135).Ref())))))))))); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(); var tmp20 any = lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref(); var tmp21 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(); var tmp22 any = lang.RT_ClassForNameNonLoading_String__Class(Lit_25).Ref(); var tmp23 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_131).Ref(); var tmp24 *jrt.Boolean; jrt.Boolean_Init(); tmp24 = jrt.Boolean_TRUE; A_arbace_core_protocols__init_A_const_92 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24.Ref())); A_arbace_core_protocols__init_A_const_93 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_63).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_63)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), Lit_133, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_134).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_135).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_134).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_135).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), Lit_133)))); A_arbace_core_protocols__init_A_const_94 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_63).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_63).Ref())); A_arbace_core_protocols__init_A_const_95 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_63)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), Lit_133, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_134).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_135).Ref()))))))); A_arbace_core_protocols__init_A_const_96 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_63)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), Lit_133, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_134).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_135).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_134).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_135).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_79).Ref(), Lit_133)); A_arbace_core_protocols__init_A_const_97 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_132).Ref(); A_arbace_core_protocols__init_A_const_98 = lang.RT_Keyword_String_String__Keyword(nil, Lit_63) }

func A_arbace_core_protocols__init_A_New() *A_arbace_core_protocols__init_A { A_arbace_core_protocols__init_A_Init(); t := &A_arbace_core_protocols__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_protocols__init_A) Ctor() {}

func (t *A_arbace_core_protocols__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_protocols__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_protocols__init_A_class }

func (t *A_arbace_core_protocols__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_protocols__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_protocols__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_protocols__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_protocols__init_A); return ok }

func A_arbace_core_protocols__init_A_Cast(x any) *A_arbace_core_protocols__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_protocols__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_protocols__init_A_class)) }; return v }
