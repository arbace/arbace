//line j2g_classes.ae:1
package aot_arbace_core_protocols

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_class, Name: "arbace.core.protocols$eval619000002$loading__1927001464__auto____619000003", Modifiers: 25, Simple: "loading__1927001464__auto____619000003", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000002_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000006_fn__619000007_A_class, Name: "arbace.core.protocols$eval619000006$fn__619000007", Modifiers: 25, Simple: "fn__619000007", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000006_fn__619000007_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000006_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000020_fn__619000021_A_class, Name: "arbace.core.protocols$eval619000020$fn__619000021", Modifiers: 25, Simple: "fn__619000021", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000020_fn__619000021_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000020_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_class, Name: "arbace.core.protocols$eval619000020$fn__619000021$G__619000012__619000034", Modifiers: 25, Simple: "G__619000012__619000034", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000020_fn__619000021_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_class, Name: "arbace.core.protocols$eval619000020$fn__619000021$G__619000013__619000027", Modifiers: 25, Simple: "G__619000013__619000027", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000020_fn__619000021_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000050_fn__619000051_A_class, Name: "arbace.core.protocols$eval619000050$fn__619000051", Modifiers: 25, Simple: "fn__619000051", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000050_fn__619000051_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000050_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_class, Name: "arbace.core.protocols$eval619000050$fn__619000051$G__619000042__619000060", Modifiers: 25, Simple: "G__619000042__619000060", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000050_fn__619000051_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_class, Name: "arbace.core.protocols$eval619000050$fn__619000051$G__619000043__619000055", Modifiers: 25, Simple: "G__619000043__619000055", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000050_fn__619000051_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000073_fn__619000074_A_class, Name: "arbace.core.protocols$eval619000073$fn__619000074", Modifiers: 25, Simple: "fn__619000074", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000073_fn__619000074_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000073_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000077_fn__619000078_A_class, Name: "arbace.core.protocols$eval619000077$fn__619000078", Modifiers: 25, Simple: "fn__619000078", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000077_fn__619000078_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000077_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000081_fn__619000082_A_class, Name: "arbace.core.protocols$eval619000081$fn__619000082", Modifiers: 25, Simple: "fn__619000082", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000081_fn__619000082_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000081_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000085_fn__619000086_A_class, Name: "arbace.core.protocols$eval619000085$fn__619000086", Modifiers: 25, Simple: "fn__619000086", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000085_fn__619000086_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000085_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000089_fn__619000090_A_class, Name: "arbace.core.protocols$eval619000089$fn__619000090", Modifiers: 25, Simple: "fn__619000090", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000089_fn__619000090_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000089_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000093_fn__619000094_A_class, Name: "arbace.core.protocols$eval619000093$fn__619000094", Modifiers: 25, Simple: "fn__619000094", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000093_fn__619000094_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000093_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_class, Name: "arbace.core.protocols$eval619000093$fn__619000094$fn__619000095", Modifiers: 25, Simple: "fn__619000095", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000093_fn__619000094_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000099_fn__619000100_A_class, Name: "arbace.core.protocols$eval619000099$fn__619000100", Modifiers: 25, Simple: "fn__619000100", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000099_fn__619000100_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000099_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000103_fn__619000104_A_class, Name: "arbace.core.protocols$eval619000103$fn__619000104", Modifiers: 25, Simple: "fn__619000104", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000103_fn__619000104_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000103_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000107_fn__619000108_A_class, Name: "arbace.core.protocols$eval619000107$fn__619000108", Modifiers: 25, Simple: "fn__619000108", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000107_fn__619000108_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000107_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000111_fn__619000112_A_class, Name: "arbace.core.protocols$eval619000111$fn__619000112", Modifiers: 25, Simple: "fn__619000112", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000111_fn__619000112_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000111_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000115_fn__619000116_A_class, Name: "arbace.core.protocols$eval619000115$fn__619000116", Modifiers: 25, Simple: "fn__619000116", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000115_fn__619000116_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000115_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000119_fn__619000120_A_class, Name: "arbace.core.protocols$eval619000119$fn__619000120", Modifiers: 25, Simple: "fn__619000120", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000119_fn__619000120_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000119_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000123_fn__619000124_A_class, Name: "arbace.core.protocols$eval619000123$fn__619000124", Modifiers: 25, Simple: "fn__619000124", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000123_fn__619000124_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000123_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000135_fn__619000136_A_class, Name: "arbace.core.protocols$eval619000135$fn__619000136", Modifiers: 25, Simple: "fn__619000136", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000135_fn__619000136_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000135_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_class, Name: "arbace.core.protocols$eval619000135$fn__619000136$G__619000127__619000145", Modifiers: 25, Simple: "G__619000127__619000145", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000135_fn__619000136_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_class, Name: "arbace.core.protocols$eval619000135$fn__619000136$G__619000128__619000140", Modifiers: 25, Simple: "G__619000128__619000140", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000135_fn__619000136_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000161_fn__619000162_A_class, Name: "arbace.core.protocols$eval619000161$fn__619000162", Modifiers: 25, Simple: "fn__619000162", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000161_fn__619000162_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000161_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_class, Name: "arbace.core.protocols$eval619000161$fn__619000162$G__619000153__619000167", Modifiers: 25, Simple: "G__619000153__619000167", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000161_fn__619000162_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_class, Name: "arbace.core.protocols$eval619000161$fn__619000162$G__619000154__619000164", Modifiers: 25, Simple: "G__619000154__619000164", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000161_fn__619000162_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000175_fn__619000176_A_class, Name: "arbace.core.protocols$eval619000175$fn__619000176", Modifiers: 25, Simple: "fn__619000176", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000175_fn__619000176_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000175_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000179_fn__619000180_A_class, Name: "arbace.core.protocols$eval619000179$fn__619000180", Modifiers: 25, Simple: "fn__619000180", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000179_fn__619000180_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000179_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000191_fn__619000192_A_class, Name: "arbace.core.protocols$eval619000191$fn__619000192", Modifiers: 25, Simple: "fn__619000192", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000191_fn__619000192_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000191_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_class, Name: "arbace.core.protocols$eval619000191$fn__619000192$G__619000183__619000201", Modifiers: 25, Simple: "G__619000183__619000201", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000191_fn__619000192_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_class, Name: "arbace.core.protocols$eval619000191$fn__619000192$G__619000184__619000196", Modifiers: 25, Simple: "G__619000184__619000196", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000191_fn__619000192_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_eval619000209_fn__619000210_A_class, Name: "arbace.core.protocols$eval619000209$fn__619000210", Modifiers: 25, Simple: "fn__619000210", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000209_fn__619000210_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_eval619000209_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_interface_or_naive_reduce_A_class, Name: "arbace.core.protocols$interface_or_naive_reduce", Modifiers: 25, Simple: "interface_or_naive_reduce", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_interface_or_naive_reduce_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_iter_reduce_A_class, Name: "arbace.core.protocols$iter_reduce", Modifiers: 25, Simple: "iter_reduce", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_iter_reduce_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_iterator_reduce_BANG__A_class, Name: "arbace.core.protocols$iterator_reduce_BANG_", Modifiers: 25, Simple: "iterator_reduce_BANG_", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_iterator_reduce_BANG__A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_naive_seq_reduce_A_class, Name: "arbace.core.protocols$naive_seq_reduce", Modifiers: 25, Simple: "naive_seq_reduce", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_naive_seq_reduce_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_core_protocols_seq_reduce_A_class, Name: "arbace.core.protocols$seq_reduce", Modifiers: 25, Simple: "seq_reduce", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_seq_reduce_A", Source: "protocols.ae", Declaring: &A_arbace_core_protocols_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_core_protocols_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_A_New()}; return nil }

var A_arbace_core_protocols_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_A_new}

var A_arbace_core_protocols_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_A"})

func init() { i := A_arbace_core_protocols_A_class.Info(); i.IsInstance = A_arbace_core_protocols_A_InstanceOf; i.Init = A_arbace_core_protocols_A_Init; i.Table = A_arbace_core_protocols_A_members }

func A_arbace_core_protocols_eval619000002_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000002_A_New()}; return nil }

var A_arbace_core_protocols_eval619000002_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000002_A_new}

var A_arbace_core_protocols_eval619000002_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000002", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000002", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000002_A"})

func init() { i := A_arbace_core_protocols_eval619000002_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000002_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000002_A_members }

var A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_class *jrt.Class

func A_arbace_core_protocols_eval619000006_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000006_A_New()}; return nil }

var A_arbace_core_protocols_eval619000006_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000006_A_new}

var A_arbace_core_protocols_eval619000006_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000006", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000006", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000006_A"})

func init() { i := A_arbace_core_protocols_eval619000006_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000006_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000006_A_members }

var A_arbace_core_protocols_eval619000006_fn__619000007_A_class *jrt.Class

func A_arbace_core_protocols_eval619000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000020_A_New()}; return nil }

var A_arbace_core_protocols_eval619000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000020_A_new}

var A_arbace_core_protocols_eval619000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000020", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000020_A"})

func init() { i := A_arbace_core_protocols_eval619000020_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000020_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000020_A_members }

var A_arbace_core_protocols_eval619000020_fn__619000021_A_class *jrt.Class

var A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_class *jrt.Class

var A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_class *jrt.Class

func A_arbace_core_protocols_eval619000050_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000050_A_New()}; return nil }

var A_arbace_core_protocols_eval619000050_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000050_A_new}

var A_arbace_core_protocols_eval619000050_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000050", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000050", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000050_A"})

func init() { i := A_arbace_core_protocols_eval619000050_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000050_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000050_A_members }

var A_arbace_core_protocols_eval619000050_fn__619000051_A_class *jrt.Class

var A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_class *jrt.Class

var A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_class *jrt.Class

func A_arbace_core_protocols_eval619000073_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000073_A_New()}; return nil }

var A_arbace_core_protocols_eval619000073_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000073_A_new}

var A_arbace_core_protocols_eval619000073_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000073", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000073", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000073_A"})

func init() { i := A_arbace_core_protocols_eval619000073_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000073_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000073_A_members }

var A_arbace_core_protocols_eval619000073_fn__619000074_A_class *jrt.Class

func A_arbace_core_protocols_eval619000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000077_A_New()}; return nil }

var A_arbace_core_protocols_eval619000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000077_A_new}

var A_arbace_core_protocols_eval619000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000077", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000077_A"})

func init() { i := A_arbace_core_protocols_eval619000077_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000077_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000077_A_members }

var A_arbace_core_protocols_eval619000077_fn__619000078_A_class *jrt.Class

func A_arbace_core_protocols_eval619000081_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000081_A_New()}; return nil }

var A_arbace_core_protocols_eval619000081_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000081_A_new}

var A_arbace_core_protocols_eval619000081_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000081", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000081", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000081_A"})

func init() { i := A_arbace_core_protocols_eval619000081_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000081_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000081_A_members }

var A_arbace_core_protocols_eval619000081_fn__619000082_A_class *jrt.Class

func A_arbace_core_protocols_eval619000085_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000085_A_New()}; return nil }

var A_arbace_core_protocols_eval619000085_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000085_A_new}

var A_arbace_core_protocols_eval619000085_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000085", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000085", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000085_A"})

func init() { i := A_arbace_core_protocols_eval619000085_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000085_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000085_A_members }

var A_arbace_core_protocols_eval619000085_fn__619000086_A_class *jrt.Class

func A_arbace_core_protocols_eval619000089_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000089_A_New()}; return nil }

var A_arbace_core_protocols_eval619000089_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000089_A_new}

var A_arbace_core_protocols_eval619000089_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000089", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000089", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000089_A"})

func init() { i := A_arbace_core_protocols_eval619000089_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000089_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000089_A_members }

var A_arbace_core_protocols_eval619000089_fn__619000090_A_class *jrt.Class

func A_arbace_core_protocols_eval619000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000093_A_New()}; return nil }

var A_arbace_core_protocols_eval619000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000093_A_new}

var A_arbace_core_protocols_eval619000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000093", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000093_A"})

func init() { i := A_arbace_core_protocols_eval619000093_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000093_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000093_A_members }

var A_arbace_core_protocols_eval619000093_fn__619000094_A_class *jrt.Class

var A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_class *jrt.Class

func A_arbace_core_protocols_eval619000099_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000099_A_New()}; return nil }

var A_arbace_core_protocols_eval619000099_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000099_A_new}

var A_arbace_core_protocols_eval619000099_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000099", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000099", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000099_A"})

func init() { i := A_arbace_core_protocols_eval619000099_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000099_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000099_A_members }

var A_arbace_core_protocols_eval619000099_fn__619000100_A_class *jrt.Class

func A_arbace_core_protocols_eval619000103_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000103_A_New()}; return nil }

var A_arbace_core_protocols_eval619000103_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000103_A_new}

var A_arbace_core_protocols_eval619000103_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000103", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000103", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000103_A"})

func init() { i := A_arbace_core_protocols_eval619000103_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000103_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000103_A_members }

var A_arbace_core_protocols_eval619000103_fn__619000104_A_class *jrt.Class

func A_arbace_core_protocols_eval619000107_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000107_A_New()}; return nil }

var A_arbace_core_protocols_eval619000107_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000107_A_new}

var A_arbace_core_protocols_eval619000107_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000107", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000107", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000107_A"})

func init() { i := A_arbace_core_protocols_eval619000107_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000107_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000107_A_members }

var A_arbace_core_protocols_eval619000107_fn__619000108_A_class *jrt.Class

func A_arbace_core_protocols_eval619000111_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000111_A_New()}; return nil }

var A_arbace_core_protocols_eval619000111_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000111_A_new}

var A_arbace_core_protocols_eval619000111_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000111", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000111", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000111_A"})

func init() { i := A_arbace_core_protocols_eval619000111_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000111_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000111_A_members }

var A_arbace_core_protocols_eval619000111_fn__619000112_A_class *jrt.Class

func A_arbace_core_protocols_eval619000115_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000115_A_New()}; return nil }

var A_arbace_core_protocols_eval619000115_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000115_A_new}

var A_arbace_core_protocols_eval619000115_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000115", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000115", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000115_A"})

func init() { i := A_arbace_core_protocols_eval619000115_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000115_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000115_A_members }

var A_arbace_core_protocols_eval619000115_fn__619000116_A_class *jrt.Class

func A_arbace_core_protocols_eval619000119_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000119_A_New()}; return nil }

var A_arbace_core_protocols_eval619000119_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000119_A_new}

var A_arbace_core_protocols_eval619000119_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000119", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000119", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000119_A"})

func init() { i := A_arbace_core_protocols_eval619000119_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000119_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000119_A_members }

var A_arbace_core_protocols_eval619000119_fn__619000120_A_class *jrt.Class

func A_arbace_core_protocols_eval619000123_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000123_A_New()}; return nil }

var A_arbace_core_protocols_eval619000123_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000123_A_new}

var A_arbace_core_protocols_eval619000123_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000123", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000123", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000123_A"})

func init() { i := A_arbace_core_protocols_eval619000123_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000123_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000123_A_members }

var A_arbace_core_protocols_eval619000123_fn__619000124_A_class *jrt.Class

func A_arbace_core_protocols_eval619000135_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000135_A_New()}; return nil }

var A_arbace_core_protocols_eval619000135_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000135_A_new}

var A_arbace_core_protocols_eval619000135_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000135", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000135", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000135_A"})

func init() { i := A_arbace_core_protocols_eval619000135_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000135_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000135_A_members }

var A_arbace_core_protocols_eval619000135_fn__619000136_A_class *jrt.Class

var A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_class *jrt.Class

var A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_class *jrt.Class

func A_arbace_core_protocols_eval619000161_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000161_A_New()}; return nil }

var A_arbace_core_protocols_eval619000161_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000161_A_new}

var A_arbace_core_protocols_eval619000161_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000161", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000161", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000161_A"})

func init() { i := A_arbace_core_protocols_eval619000161_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000161_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000161_A_members }

var A_arbace_core_protocols_eval619000161_fn__619000162_A_class *jrt.Class

var A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_class *jrt.Class

var A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_class *jrt.Class

func A_arbace_core_protocols_eval619000175_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000175_A_New()}; return nil }

var A_arbace_core_protocols_eval619000175_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000175_A_new}

var A_arbace_core_protocols_eval619000175_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000175", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000175", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000175_A"})

func init() { i := A_arbace_core_protocols_eval619000175_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000175_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000175_A_members }

var A_arbace_core_protocols_eval619000175_fn__619000176_A_class *jrt.Class

func A_arbace_core_protocols_eval619000179_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000179_A_New()}; return nil }

var A_arbace_core_protocols_eval619000179_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000179_A_new}

var A_arbace_core_protocols_eval619000179_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000179", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000179", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000179_A"})

func init() { i := A_arbace_core_protocols_eval619000179_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000179_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000179_A_members }

var A_arbace_core_protocols_eval619000179_fn__619000180_A_class *jrt.Class

func A_arbace_core_protocols_eval619000191_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000191_A_New()}; return nil }

var A_arbace_core_protocols_eval619000191_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000191_A_new}

var A_arbace_core_protocols_eval619000191_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000191", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000191", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000191_A"})

func init() { i := A_arbace_core_protocols_eval619000191_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000191_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000191_A_members }

var A_arbace_core_protocols_eval619000191_fn__619000192_A_class *jrt.Class

var A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_class *jrt.Class

var A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_class *jrt.Class

func A_arbace_core_protocols_eval619000209_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000209_A_New()}; return nil }

var A_arbace_core_protocols_eval619000209_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000209_A_new}

var A_arbace_core_protocols_eval619000209_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000209", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000209", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000209_A"})

func init() { i := A_arbace_core_protocols_eval619000209_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000209_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000209_A_members }

var A_arbace_core_protocols_eval619000209_fn__619000210_A_class *jrt.Class

var A_arbace_core_protocols_interface_or_naive_reduce_A_class *jrt.Class

var A_arbace_core_protocols_iter_reduce_A_class *jrt.Class

var A_arbace_core_protocols_iterator_reduce_BANG__A_class *jrt.Class

var A_arbace_core_protocols_naive_seq_reduce_A_class *jrt.Class

var A_arbace_core_protocols_seq_reduce_A_class *jrt.Class

func A_arbace_core_protocols_CollReduce_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_core_protocols_CollReduce_A).Coll_reduce_O__O(args[0]); case 1: return this.(A_arbace_core_protocols_CollReduce_A).Coll_reduce_O_O__O(args[0], args[1])}; return nil }

var A_arbace_core_protocols_CollReduce_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 coll_reduce (Ljava.lang.Object;)Ljava.lang.Object;\nM1025 coll_reduce (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;", Invoke: A_arbace_core_protocols_CollReduce_A_invoke}

var A_arbace_core_protocols_CollReduce_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols.CollReduce", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A"})

func init() { i := A_arbace_core_protocols_CollReduce_A_class.Info(); i.IsInstance = A_arbace_core_protocols_CollReduce_A_InstanceOf; i.Table = A_arbace_core_protocols_CollReduce_A_members }

func A_arbace_core_protocols_Datafiable_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_core_protocols_Datafiable_A).Datafy__O()}; return nil }

var A_arbace_core_protocols_Datafiable_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 datafy ()Ljava.lang.Object;", Invoke: A_arbace_core_protocols_Datafiable_A_invoke}

var A_arbace_core_protocols_Datafiable_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols.Datafiable", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_Datafiable_A"})

func init() { i := A_arbace_core_protocols_Datafiable_A_class.Info(); i.IsInstance = A_arbace_core_protocols_Datafiable_A_InstanceOf; i.Table = A_arbace_core_protocols_Datafiable_A_members }

func A_arbace_core_protocols_IKVReduce_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_core_protocols_IKVReduce_A).Kv_reduce_O_O__O(args[0], args[1])}; return nil }

var A_arbace_core_protocols_IKVReduce_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 kv_reduce (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;", Invoke: A_arbace_core_protocols_IKVReduce_A_invoke}

var A_arbace_core_protocols_IKVReduce_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols.IKVReduce", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_IKVReduce_A"})

func init() { i := A_arbace_core_protocols_IKVReduce_A_class.Info(); i.IsInstance = A_arbace_core_protocols_IKVReduce_A_InstanceOf; i.Table = A_arbace_core_protocols_IKVReduce_A_members }

func A_arbace_core_protocols_InternalReduce_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_core_protocols_InternalReduce_A).Internal_reduce_O_O__O(args[0], args[1])}; return nil }

var A_arbace_core_protocols_InternalReduce_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 internal_reduce (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;", Invoke: A_arbace_core_protocols_InternalReduce_A_invoke}

var A_arbace_core_protocols_InternalReduce_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols.InternalReduce", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_InternalReduce_A"})

func init() { i := A_arbace_core_protocols_InternalReduce_A_class.Info(); i.IsInstance = A_arbace_core_protocols_InternalReduce_A_InstanceOf; i.Table = A_arbace_core_protocols_InternalReduce_A_members }

func A_arbace_core_protocols_Navigable_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_core_protocols_Navigable_A).Nav_O_O__O(args[0], args[1])}; return nil }

var A_arbace_core_protocols_Navigable_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 nav (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;", Invoke: A_arbace_core_protocols_Navigable_A_invoke}

var A_arbace_core_protocols_Navigable_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols.Navigable", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_Navigable_A"})

func init() { i := A_arbace_core_protocols_Navigable_A_class.Info(); i.IsInstance = A_arbace_core_protocols_Navigable_A_InstanceOf; i.Table = A_arbace_core_protocols_Navigable_A_members }

func A_arbace_core_protocols__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_core_protocols__init_A_Load__O()}; return nil }

func A_arbace_core_protocols__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols__init_A_New()}; return nil }

var A_arbace_core_protocols__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_core_protocols__init_A_invoke, New: A_arbace_core_protocols__init_A_new}

var A_arbace_core_protocols__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols__init_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols__init_A_class.Info(); i.IsInstance = A_arbace_core_protocols__init_A_InstanceOf; i.Init = A_arbace_core_protocols__init_A_Init; i.Table = A_arbace_core_protocols__init_A_members }
