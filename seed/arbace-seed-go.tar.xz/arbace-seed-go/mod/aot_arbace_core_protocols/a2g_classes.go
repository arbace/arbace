//line a2g_classes.ae:1
package aot_arbace_core_protocols

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_core_protocols_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_A_New()}; return nil }

var A_arbace_core_protocols_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_A_new}

var A_arbace_core_protocols_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_A"})

func init() { i := A_arbace_core_protocols_A_class.Info(); i.IsInstance = A_arbace_core_protocols_A_InstanceOf; i.Init = A_arbace_core_protocols_A_Init; i.Table = A_arbace_core_protocols_A_members; jrt.RegisterGoType(A_arbace_core_protocols_A_class, reflect.TypeFor[A_arbace_core_protocols_A]()) }

func A_arbace_core_protocols_eval619000002_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000002_A_New()}; return nil }

var A_arbace_core_protocols_eval619000002_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000002_A_new}

var A_arbace_core_protocols_eval619000002_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000002", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000002", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000002_A"})

func init() { i := A_arbace_core_protocols_eval619000002_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000002_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000002_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000002_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000002_A]()) }

func A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_New()}; return nil }

func A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_invoke, New: A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_new, Get: A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_get}

var A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000002$loading__1927001464__auto____619000003", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_protocols_eval619000002_A_class, Simple: "loading__1927001464__auto____619000003", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_Init; i.Table = A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000002_loading__1927001464__auto____619000003_A]()) }

func A_arbace_core_protocols_eval619000006_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000006_A_New()}; return nil }

var A_arbace_core_protocols_eval619000006_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000006_A_new}

var A_arbace_core_protocols_eval619000006_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000006", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000006", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000006_A"})

func init() { i := A_arbace_core_protocols_eval619000006_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000006_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000006_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000006_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000006_A]()) }

func A_arbace_core_protocols_eval619000006_fn__619000007_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000006_fn__619000007_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_protocols_eval619000006_fn__619000007_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000006_fn__619000007_A_New()}; return nil }

func A_arbace_core_protocols_eval619000006_fn__619000007_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000006_fn__619000007_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000006_fn__619000007_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000006_fn__619000007_A_invoke, New: A_arbace_core_protocols_eval619000006_fn__619000007_A_new, Get: A_arbace_core_protocols_eval619000006_fn__619000007_A_get}

var A_arbace_core_protocols_eval619000006_fn__619000007_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000006$fn__619000007", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_protocols_eval619000006_A_class, Simple: "fn__619000007", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000006_fn__619000007_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000006_fn__619000007_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000006_fn__619000007_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000006_fn__619000007_A_Init; i.Table = A_arbace_core_protocols_eval619000006_fn__619000007_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000006_fn__619000007_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000006_fn__619000007_A]()) }

func A_arbace_core_protocols_eval619000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000020_A_New()}; return nil }

var A_arbace_core_protocols_eval619000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000020_A_new}

var A_arbace_core_protocols_eval619000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000020", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000020_A"})

func init() { i := A_arbace_core_protocols_eval619000020_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000020_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000020_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000020_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000020_A]()) }

func A_arbace_core_protocols_eval619000020_fn__619000021_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000020_fn__619000021_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_protocols_eval619000020_fn__619000021_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000020_fn__619000021_A_New()}; return nil }

func A_arbace_core_protocols_eval619000020_fn__619000021_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000020_fn__619000021_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000020_fn__619000021_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000020_fn__619000021_A_invoke, New: A_arbace_core_protocols_eval619000020_fn__619000021_A_new, Get: A_arbace_core_protocols_eval619000020_fn__619000021_A_get}

var A_arbace_core_protocols_eval619000020_fn__619000021_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000020$fn__619000021", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_protocols_eval619000020_A_class, Simple: "fn__619000021", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000020_fn__619000021_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000020_fn__619000021_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000020_fn__619000021_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000020_fn__619000021_A_Init; i.Table = A_arbace_core_protocols_eval619000020_fn__619000021_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000020_fn__619000021_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000020_fn__619000021_A]()) }

func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_New_O(args[0])}; return nil }

func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_invoke, New: A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_new, Get: A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_get}

var A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000020$fn__619000021$G__619000012__619000034", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_protocols_eval619000020_fn__619000021_A_class, Simple: "G__619000012__619000034", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_Init; i.Table = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000020_fn__619000021_G__619000012__619000034_A]()) }

func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_New()}; return nil }

func A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_invoke, New: A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_new, Get: A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_get}

var A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000020$fn__619000021$G__619000013__619000027", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_protocols_eval619000020_fn__619000021_A_class, Simple: "G__619000013__619000027", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_Init; i.Table = A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000020_fn__619000021_G__619000013__619000027_A]()) }

func A_arbace_core_protocols_eval619000050_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000050_A_New()}; return nil }

var A_arbace_core_protocols_eval619000050_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000050_A_new}

var A_arbace_core_protocols_eval619000050_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000050", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000050", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000050_A"})

func init() { i := A_arbace_core_protocols_eval619000050_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000050_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000050_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000050_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000050_A]()) }

func A_arbace_core_protocols_eval619000050_fn__619000051_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000050_fn__619000051_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_protocols_eval619000050_fn__619000051_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000050_fn__619000051_A_New()}; return nil }

func A_arbace_core_protocols_eval619000050_fn__619000051_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000050_fn__619000051_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000050_fn__619000051_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000050_fn__619000051_A_invoke, New: A_arbace_core_protocols_eval619000050_fn__619000051_A_new, Get: A_arbace_core_protocols_eval619000050_fn__619000051_A_get}

var A_arbace_core_protocols_eval619000050_fn__619000051_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000050$fn__619000051", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_protocols_eval619000050_A_class, Simple: "fn__619000051", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000050_fn__619000051_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000050_fn__619000051_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000050_fn__619000051_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000050_fn__619000051_A_Init; i.Table = A_arbace_core_protocols_eval619000050_fn__619000051_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000050_fn__619000051_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000050_fn__619000051_A]()) }

func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_New_O(args[0])}; return nil }

func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_invoke, New: A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_new, Get: A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_get}

var A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000050$fn__619000051$G__619000042__619000060", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_core_protocols_eval619000050_fn__619000051_A_class, Simple: "G__619000042__619000060", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_Init; i.Table = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000050_fn__619000051_G__619000042__619000060_A]()) }

func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_New()}; return nil }

func A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_invoke, New: A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_new, Get: A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_get}

var A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000050$fn__619000051$G__619000043__619000055", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_core_protocols_eval619000050_fn__619000051_A_class, Simple: "G__619000043__619000055", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_Init; i.Table = A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000050_fn__619000051_G__619000043__619000055_A]()) }

func A_arbace_core_protocols_eval619000073_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000073_A_New()}; return nil }

var A_arbace_core_protocols_eval619000073_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000073_A_new}

var A_arbace_core_protocols_eval619000073_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000073", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000073", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000073_A"})

func init() { i := A_arbace_core_protocols_eval619000073_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000073_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000073_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000073_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000073_A]()) }

func A_arbace_core_protocols_eval619000073_fn__619000074_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000073_fn__619000074_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_protocols_eval619000073_fn__619000074_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000073_fn__619000074_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000073_fn__619000074_A_New()}; return nil }

func A_arbace_core_protocols_eval619000073_fn__619000074_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000073_fn__619000074_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000073_fn__619000074_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000073_fn__619000074_A_invoke, New: A_arbace_core_protocols_eval619000073_fn__619000074_A_new, Get: A_arbace_core_protocols_eval619000073_fn__619000074_A_get}

var A_arbace_core_protocols_eval619000073_fn__619000074_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000073$fn__619000074", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_protocols_eval619000073_A_class, Simple: "fn__619000074", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000073_fn__619000074_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000073_fn__619000074_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000073_fn__619000074_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000073_fn__619000074_A_Init; i.Table = A_arbace_core_protocols_eval619000073_fn__619000074_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000073_fn__619000074_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000073_fn__619000074_A]()) }

func A_arbace_core_protocols_eval619000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000077_A_New()}; return nil }

var A_arbace_core_protocols_eval619000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000077_A_new}

var A_arbace_core_protocols_eval619000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000077", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000077_A"})

func init() { i := A_arbace_core_protocols_eval619000077_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000077_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000077_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000077_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000077_A]()) }

func A_arbace_core_protocols_eval619000077_fn__619000078_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000077_fn__619000078_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_protocols_eval619000077_fn__619000078_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000077_fn__619000078_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000077_fn__619000078_A_New()}; return nil }

func A_arbace_core_protocols_eval619000077_fn__619000078_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000077_fn__619000078_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000077_fn__619000078_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000077_fn__619000078_A_invoke, New: A_arbace_core_protocols_eval619000077_fn__619000078_A_new, Get: A_arbace_core_protocols_eval619000077_fn__619000078_A_get}

var A_arbace_core_protocols_eval619000077_fn__619000078_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000077$fn__619000078", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_protocols_eval619000077_A_class, Simple: "fn__619000078", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000077_fn__619000078_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000077_fn__619000078_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000077_fn__619000078_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000077_fn__619000078_A_Init; i.Table = A_arbace_core_protocols_eval619000077_fn__619000078_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000077_fn__619000078_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000077_fn__619000078_A]()) }

func A_arbace_core_protocols_eval619000081_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000081_A_New()}; return nil }

var A_arbace_core_protocols_eval619000081_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000081_A_new}

var A_arbace_core_protocols_eval619000081_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000081", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000081", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000081_A"})

func init() { i := A_arbace_core_protocols_eval619000081_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000081_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000081_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000081_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000081_A]()) }

func A_arbace_core_protocols_eval619000081_fn__619000082_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000081_fn__619000082_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_protocols_eval619000081_fn__619000082_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000081_fn__619000082_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000081_fn__619000082_A_New()}; return nil }

func A_arbace_core_protocols_eval619000081_fn__619000082_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000081_fn__619000082_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000081_fn__619000082_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000081_fn__619000082_A_invoke, New: A_arbace_core_protocols_eval619000081_fn__619000082_A_new, Get: A_arbace_core_protocols_eval619000081_fn__619000082_A_get}

var A_arbace_core_protocols_eval619000081_fn__619000082_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000081$fn__619000082", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_protocols_eval619000081_A_class, Simple: "fn__619000082", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000081_fn__619000082_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000081_fn__619000082_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000081_fn__619000082_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000081_fn__619000082_A_Init; i.Table = A_arbace_core_protocols_eval619000081_fn__619000082_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000081_fn__619000082_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000081_fn__619000082_A]()) }

func A_arbace_core_protocols_eval619000085_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000085_A_New()}; return nil }

var A_arbace_core_protocols_eval619000085_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000085_A_new}

var A_arbace_core_protocols_eval619000085_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000085", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000085", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000085_A"})

func init() { i := A_arbace_core_protocols_eval619000085_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000085_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000085_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000085_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000085_A]()) }

func A_arbace_core_protocols_eval619000085_fn__619000086_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000085_fn__619000086_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_protocols_eval619000085_fn__619000086_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000085_fn__619000086_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000085_fn__619000086_A_New()}; return nil }

func A_arbace_core_protocols_eval619000085_fn__619000086_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000085_fn__619000086_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000085_fn__619000086_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000085_fn__619000086_A_invoke, New: A_arbace_core_protocols_eval619000085_fn__619000086_A_new, Get: A_arbace_core_protocols_eval619000085_fn__619000086_A_get}

var A_arbace_core_protocols_eval619000085_fn__619000086_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000085$fn__619000086", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_protocols_eval619000085_A_class, Simple: "fn__619000086", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000085_fn__619000086_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000085_fn__619000086_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000085_fn__619000086_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000085_fn__619000086_A_Init; i.Table = A_arbace_core_protocols_eval619000085_fn__619000086_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000085_fn__619000086_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000085_fn__619000086_A]()) }

func A_arbace_core_protocols_eval619000089_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000089_A_New()}; return nil }

var A_arbace_core_protocols_eval619000089_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000089_A_new}

var A_arbace_core_protocols_eval619000089_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000089", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000089", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000089_A"})

func init() { i := A_arbace_core_protocols_eval619000089_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000089_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000089_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000089_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000089_A]()) }

func A_arbace_core_protocols_eval619000089_fn__619000090_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000089_fn__619000090_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_protocols_eval619000089_fn__619000090_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000089_fn__619000090_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000089_fn__619000090_A_New()}; return nil }

func A_arbace_core_protocols_eval619000089_fn__619000090_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000089_fn__619000090_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000089_fn__619000090_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000089_fn__619000090_A_invoke, New: A_arbace_core_protocols_eval619000089_fn__619000090_A_new, Get: A_arbace_core_protocols_eval619000089_fn__619000090_A_get}

var A_arbace_core_protocols_eval619000089_fn__619000090_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000089$fn__619000090", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_protocols_eval619000089_A_class, Simple: "fn__619000090", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000089_fn__619000090_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000089_fn__619000090_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000089_fn__619000090_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000089_fn__619000090_A_Init; i.Table = A_arbace_core_protocols_eval619000089_fn__619000090_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000089_fn__619000090_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000089_fn__619000090_A]()) }

func A_arbace_core_protocols_eval619000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000093_A_New()}; return nil }

var A_arbace_core_protocols_eval619000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000093_A_new}

var A_arbace_core_protocols_eval619000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000093", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000093_A"})

func init() { i := A_arbace_core_protocols_eval619000093_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000093_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000093_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000093_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000093_A]()) }

func A_arbace_core_protocols_eval619000093_fn__619000094_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000093_fn__619000094_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_protocols_eval619000093_fn__619000094_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000093_fn__619000094_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000093_fn__619000094_A_New()}; return nil }

func A_arbace_core_protocols_eval619000093_fn__619000094_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000093_fn__619000094_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000093_fn__619000094_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000093_fn__619000094_A_invoke, New: A_arbace_core_protocols_eval619000093_fn__619000094_A_new, Get: A_arbace_core_protocols_eval619000093_fn__619000094_A_get}

var A_arbace_core_protocols_eval619000093_fn__619000094_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000093$fn__619000094", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_protocols_eval619000093_A_class, Simple: "fn__619000094", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000093_fn__619000094_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000093_fn__619000094_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000093_fn__619000094_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000093_fn__619000094_A_Init; i.Table = A_arbace_core_protocols_eval619000093_fn__619000094_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000093_fn__619000094_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000093_fn__619000094_A]()) }

func A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_invoke, New: A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_new, Get: A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_get}

var A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000093$fn__619000094$fn__619000095", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_protocols_eval619000093_fn__619000094_A_class, Simple: "fn__619000095", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_Init; i.Table = A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000093_fn__619000094_fn__619000095_A]()) }

func A_arbace_core_protocols_eval619000099_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000099_A_New()}; return nil }

var A_arbace_core_protocols_eval619000099_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000099_A_new}

var A_arbace_core_protocols_eval619000099_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000099", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000099", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000099_A"})

func init() { i := A_arbace_core_protocols_eval619000099_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000099_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000099_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000099_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000099_A]()) }

func A_arbace_core_protocols_eval619000099_fn__619000100_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000099_fn__619000100_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_protocols_eval619000099_fn__619000100_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000099_fn__619000100_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000099_fn__619000100_A_New()}; return nil }

func A_arbace_core_protocols_eval619000099_fn__619000100_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000099_fn__619000100_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000099_fn__619000100_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000099_fn__619000100_A_invoke, New: A_arbace_core_protocols_eval619000099_fn__619000100_A_new, Get: A_arbace_core_protocols_eval619000099_fn__619000100_A_get}

var A_arbace_core_protocols_eval619000099_fn__619000100_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000099$fn__619000100", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_protocols_eval619000099_A_class, Simple: "fn__619000100", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000099_fn__619000100_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000099_fn__619000100_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000099_fn__619000100_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000099_fn__619000100_A_Init; i.Table = A_arbace_core_protocols_eval619000099_fn__619000100_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000099_fn__619000100_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000099_fn__619000100_A]()) }

func A_arbace_core_protocols_eval619000103_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000103_A_New()}; return nil }

var A_arbace_core_protocols_eval619000103_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000103_A_new}

var A_arbace_core_protocols_eval619000103_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000103", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000103", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000103_A"})

func init() { i := A_arbace_core_protocols_eval619000103_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000103_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000103_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000103_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000103_A]()) }

func A_arbace_core_protocols_eval619000103_fn__619000104_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000103_fn__619000104_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_protocols_eval619000103_fn__619000104_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000103_fn__619000104_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000103_fn__619000104_A_New()}; return nil }

func A_arbace_core_protocols_eval619000103_fn__619000104_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000103_fn__619000104_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000103_fn__619000104_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000103_fn__619000104_A_invoke, New: A_arbace_core_protocols_eval619000103_fn__619000104_A_new, Get: A_arbace_core_protocols_eval619000103_fn__619000104_A_get}

var A_arbace_core_protocols_eval619000103_fn__619000104_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000103$fn__619000104", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_protocols_eval619000103_A_class, Simple: "fn__619000104", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000103_fn__619000104_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000103_fn__619000104_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000103_fn__619000104_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000103_fn__619000104_A_Init; i.Table = A_arbace_core_protocols_eval619000103_fn__619000104_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000103_fn__619000104_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000103_fn__619000104_A]()) }

func A_arbace_core_protocols_eval619000107_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000107_A_New()}; return nil }

var A_arbace_core_protocols_eval619000107_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000107_A_new}

var A_arbace_core_protocols_eval619000107_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000107", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000107", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000107_A"})

func init() { i := A_arbace_core_protocols_eval619000107_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000107_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000107_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000107_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000107_A]()) }

func A_arbace_core_protocols_eval619000107_fn__619000108_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000107_fn__619000108_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_protocols_eval619000107_fn__619000108_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000107_fn__619000108_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000107_fn__619000108_A_New()}; return nil }

func A_arbace_core_protocols_eval619000107_fn__619000108_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000107_fn__619000108_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000107_fn__619000108_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000107_fn__619000108_A_invoke, New: A_arbace_core_protocols_eval619000107_fn__619000108_A_new, Get: A_arbace_core_protocols_eval619000107_fn__619000108_A_get}

var A_arbace_core_protocols_eval619000107_fn__619000108_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000107$fn__619000108", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_protocols_eval619000107_A_class, Simple: "fn__619000108", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000107_fn__619000108_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000107_fn__619000108_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000107_fn__619000108_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000107_fn__619000108_A_Init; i.Table = A_arbace_core_protocols_eval619000107_fn__619000108_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000107_fn__619000108_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000107_fn__619000108_A]()) }

func A_arbace_core_protocols_eval619000111_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000111_A_New()}; return nil }

var A_arbace_core_protocols_eval619000111_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000111_A_new}

var A_arbace_core_protocols_eval619000111_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000111", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000111", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000111_A"})

func init() { i := A_arbace_core_protocols_eval619000111_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000111_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000111_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000111_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000111_A]()) }

func A_arbace_core_protocols_eval619000111_fn__619000112_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000111_fn__619000112_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000111_fn__619000112_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000111_fn__619000112_A_New()}; return nil }

func A_arbace_core_protocols_eval619000111_fn__619000112_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000111_fn__619000112_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000111_fn__619000112_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000111_fn__619000112_A_invoke, New: A_arbace_core_protocols_eval619000111_fn__619000112_A_new, Get: A_arbace_core_protocols_eval619000111_fn__619000112_A_get}

var A_arbace_core_protocols_eval619000111_fn__619000112_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000111$fn__619000112", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_core_protocols_eval619000111_A_class, Simple: "fn__619000112", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000111_fn__619000112_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000111_fn__619000112_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000111_fn__619000112_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000111_fn__619000112_A_Init; i.Table = A_arbace_core_protocols_eval619000111_fn__619000112_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000111_fn__619000112_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000111_fn__619000112_A]()) }

func A_arbace_core_protocols_eval619000115_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000115_A_New()}; return nil }

var A_arbace_core_protocols_eval619000115_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000115_A_new}

var A_arbace_core_protocols_eval619000115_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000115", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000115", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000115_A"})

func init() { i := A_arbace_core_protocols_eval619000115_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000115_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000115_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000115_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000115_A]()) }

func A_arbace_core_protocols_eval619000115_fn__619000116_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000115_fn__619000116_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000115_fn__619000116_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000115_fn__619000116_A_New()}; return nil }

func A_arbace_core_protocols_eval619000115_fn__619000116_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000115_fn__619000116_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000115_fn__619000116_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000115_fn__619000116_A_invoke, New: A_arbace_core_protocols_eval619000115_fn__619000116_A_new, Get: A_arbace_core_protocols_eval619000115_fn__619000116_A_get}

var A_arbace_core_protocols_eval619000115_fn__619000116_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000115$fn__619000116", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_core_protocols_eval619000115_A_class, Simple: "fn__619000116", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000115_fn__619000116_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000115_fn__619000116_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000115_fn__619000116_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000115_fn__619000116_A_Init; i.Table = A_arbace_core_protocols_eval619000115_fn__619000116_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000115_fn__619000116_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000115_fn__619000116_A]()) }

func A_arbace_core_protocols_eval619000119_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000119_A_New()}; return nil }

var A_arbace_core_protocols_eval619000119_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000119_A_new}

var A_arbace_core_protocols_eval619000119_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000119", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000119", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000119_A"})

func init() { i := A_arbace_core_protocols_eval619000119_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000119_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000119_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000119_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000119_A]()) }

func A_arbace_core_protocols_eval619000119_fn__619000120_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000119_fn__619000120_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000119_fn__619000120_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000119_fn__619000120_A_New()}; return nil }

func A_arbace_core_protocols_eval619000119_fn__619000120_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000119_fn__619000120_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000119_fn__619000120_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000119_fn__619000120_A_invoke, New: A_arbace_core_protocols_eval619000119_fn__619000120_A_new, Get: A_arbace_core_protocols_eval619000119_fn__619000120_A_get}

var A_arbace_core_protocols_eval619000119_fn__619000120_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000119$fn__619000120", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_core_protocols_eval619000119_A_class, Simple: "fn__619000120", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000119_fn__619000120_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000119_fn__619000120_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000119_fn__619000120_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000119_fn__619000120_A_Init; i.Table = A_arbace_core_protocols_eval619000119_fn__619000120_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000119_fn__619000120_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000119_fn__619000120_A]()) }

func A_arbace_core_protocols_eval619000123_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000123_A_New()}; return nil }

var A_arbace_core_protocols_eval619000123_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000123_A_new}

var A_arbace_core_protocols_eval619000123_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000123", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000123", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000123_A"})

func init() { i := A_arbace_core_protocols_eval619000123_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000123_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000123_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000123_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000123_A]()) }

func A_arbace_core_protocols_eval619000123_fn__619000124_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000123_fn__619000124_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000123_fn__619000124_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000123_fn__619000124_A_New()}; return nil }

func A_arbace_core_protocols_eval619000123_fn__619000124_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000123_fn__619000124_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000123_fn__619000124_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000123_fn__619000124_A_invoke, New: A_arbace_core_protocols_eval619000123_fn__619000124_A_new, Get: A_arbace_core_protocols_eval619000123_fn__619000124_A_get}

var A_arbace_core_protocols_eval619000123_fn__619000124_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000123$fn__619000124", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_core_protocols_eval619000123_A_class, Simple: "fn__619000124", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000123_fn__619000124_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000123_fn__619000124_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000123_fn__619000124_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000123_fn__619000124_A_Init; i.Table = A_arbace_core_protocols_eval619000123_fn__619000124_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000123_fn__619000124_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000123_fn__619000124_A]()) }

func A_arbace_core_protocols_eval619000135_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000135_A_New()}; return nil }

var A_arbace_core_protocols_eval619000135_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000135_A_new}

var A_arbace_core_protocols_eval619000135_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000135", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000135", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000135_A"})

func init() { i := A_arbace_core_protocols_eval619000135_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000135_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000135_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000135_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000135_A]()) }

func A_arbace_core_protocols_eval619000135_fn__619000136_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000135_fn__619000136_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_protocols_eval619000135_fn__619000136_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000135_fn__619000136_A_New()}; return nil }

func A_arbace_core_protocols_eval619000135_fn__619000136_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000135_fn__619000136_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000135_fn__619000136_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000135_fn__619000136_A_invoke, New: A_arbace_core_protocols_eval619000135_fn__619000136_A_new, Get: A_arbace_core_protocols_eval619000135_fn__619000136_A_get}

var A_arbace_core_protocols_eval619000135_fn__619000136_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000135$fn__619000136", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_protocols_eval619000135_A_class, Simple: "fn__619000136", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000135_fn__619000136_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000135_fn__619000136_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000135_fn__619000136_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000135_fn__619000136_A_Init; i.Table = A_arbace_core_protocols_eval619000135_fn__619000136_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000135_fn__619000136_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000135_fn__619000136_A]()) }

func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_New_O(args[0])}; return nil }

func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_invoke, New: A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_new, Get: A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_get}

var A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000135$fn__619000136$G__619000127__619000145", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_core_protocols_eval619000135_fn__619000136_A_class, Simple: "G__619000127__619000145", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_Init; i.Table = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000135_fn__619000136_G__619000127__619000145_A]()) }

func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_New()}; return nil }

func A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_invoke, New: A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_new, Get: A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_get}

var A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000135$fn__619000136$G__619000128__619000140", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_core_protocols_eval619000135_fn__619000136_A_class, Simple: "G__619000128__619000140", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_Init; i.Table = A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000135_fn__619000136_G__619000128__619000140_A]()) }

func A_arbace_core_protocols_eval619000161_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000161_A_New()}; return nil }

var A_arbace_core_protocols_eval619000161_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000161_A_new}

var A_arbace_core_protocols_eval619000161_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000161", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000161", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000161_A"})

func init() { i := A_arbace_core_protocols_eval619000161_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000161_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000161_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000161_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000161_A]()) }

func A_arbace_core_protocols_eval619000161_fn__619000162_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000161_fn__619000162_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_protocols_eval619000161_fn__619000162_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000161_fn__619000162_A_New()}; return nil }

func A_arbace_core_protocols_eval619000161_fn__619000162_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000161_fn__619000162_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000161_fn__619000162_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000161_fn__619000162_A_invoke, New: A_arbace_core_protocols_eval619000161_fn__619000162_A_new, Get: A_arbace_core_protocols_eval619000161_fn__619000162_A_get}

var A_arbace_core_protocols_eval619000161_fn__619000162_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000161$fn__619000162", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_protocols_eval619000161_A_class, Simple: "fn__619000162", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000161_fn__619000162_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000161_fn__619000162_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000161_fn__619000162_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000161_fn__619000162_A_Init; i.Table = A_arbace_core_protocols_eval619000161_fn__619000162_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000161_fn__619000162_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000161_fn__619000162_A]()) }

func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_New_O(args[0])}; return nil }

func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_invoke, New: A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_new, Get: A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_get}

var A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000161$fn__619000162$G__619000153__619000167", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_protocols_eval619000161_fn__619000162_A_class, Simple: "G__619000153__619000167", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_Init; i.Table = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000161_fn__619000162_G__619000153__619000167_A]()) }

func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_New()}; return nil }

func A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_invoke, New: A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_new, Get: A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_get}

var A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000161$fn__619000162$G__619000154__619000164", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_protocols_eval619000161_fn__619000162_A_class, Simple: "G__619000154__619000164", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_Init; i.Table = A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000161_fn__619000162_G__619000154__619000164_A]()) }

func A_arbace_core_protocols_eval619000175_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000175_A_New()}; return nil }

var A_arbace_core_protocols_eval619000175_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000175_A_new}

var A_arbace_core_protocols_eval619000175_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000175", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000175", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000175_A"})

func init() { i := A_arbace_core_protocols_eval619000175_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000175_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000175_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000175_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000175_A]()) }

func A_arbace_core_protocols_eval619000175_fn__619000176_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000175_fn__619000176_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_protocols_eval619000175_fn__619000176_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000175_fn__619000176_A_New()}; return nil }

func A_arbace_core_protocols_eval619000175_fn__619000176_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000175_fn__619000176_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000175_fn__619000176_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000175_fn__619000176_A_invoke, New: A_arbace_core_protocols_eval619000175_fn__619000176_A_new, Get: A_arbace_core_protocols_eval619000175_fn__619000176_A_get}

var A_arbace_core_protocols_eval619000175_fn__619000176_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000175$fn__619000176", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_protocols_eval619000175_A_class, Simple: "fn__619000176", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000175_fn__619000176_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000175_fn__619000176_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000175_fn__619000176_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000175_fn__619000176_A_Init; i.Table = A_arbace_core_protocols_eval619000175_fn__619000176_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000175_fn__619000176_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000175_fn__619000176_A]()) }

func A_arbace_core_protocols_eval619000179_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000179_A_New()}; return nil }

var A_arbace_core_protocols_eval619000179_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000179_A_new}

var A_arbace_core_protocols_eval619000179_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000179", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000179", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000179_A"})

func init() { i := A_arbace_core_protocols_eval619000179_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000179_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000179_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000179_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000179_A]()) }

func A_arbace_core_protocols_eval619000179_fn__619000180_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000179_fn__619000180_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_protocols_eval619000179_fn__619000180_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000179_fn__619000180_A_New()}; return nil }

func A_arbace_core_protocols_eval619000179_fn__619000180_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000179_fn__619000180_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000179_fn__619000180_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000179_fn__619000180_A_invoke, New: A_arbace_core_protocols_eval619000179_fn__619000180_A_new, Get: A_arbace_core_protocols_eval619000179_fn__619000180_A_get}

var A_arbace_core_protocols_eval619000179_fn__619000180_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000179$fn__619000180", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_protocols_eval619000179_A_class, Simple: "fn__619000180", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000179_fn__619000180_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000179_fn__619000180_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000179_fn__619000180_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000179_fn__619000180_A_Init; i.Table = A_arbace_core_protocols_eval619000179_fn__619000180_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000179_fn__619000180_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000179_fn__619000180_A]()) }

func A_arbace_core_protocols_eval619000191_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000191_A_New()}; return nil }

var A_arbace_core_protocols_eval619000191_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000191_A_new}

var A_arbace_core_protocols_eval619000191_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000191", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000191", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000191_A"})

func init() { i := A_arbace_core_protocols_eval619000191_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000191_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000191_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000191_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000191_A]()) }

func A_arbace_core_protocols_eval619000191_fn__619000192_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000191_fn__619000192_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_protocols_eval619000191_fn__619000192_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000191_fn__619000192_A_New()}; return nil }

func A_arbace_core_protocols_eval619000191_fn__619000192_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000191_fn__619000192_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000191_fn__619000192_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000191_fn__619000192_A_invoke, New: A_arbace_core_protocols_eval619000191_fn__619000192_A_new, Get: A_arbace_core_protocols_eval619000191_fn__619000192_A_get}

var A_arbace_core_protocols_eval619000191_fn__619000192_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000191$fn__619000192", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_protocols_eval619000191_A_class, Simple: "fn__619000192", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000191_fn__619000192_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000191_fn__619000192_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000191_fn__619000192_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000191_fn__619000192_A_Init; i.Table = A_arbace_core_protocols_eval619000191_fn__619000192_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000191_fn__619000192_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000191_fn__619000192_A]()) }

func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_New_O(args[0])}; return nil }

func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_invoke, New: A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_new, Get: A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_get}

var A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000191$fn__619000192$G__619000183__619000201", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_core_protocols_eval619000191_fn__619000192_A_class, Simple: "G__619000183__619000201", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_Init; i.Table = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000191_fn__619000192_G__619000183__619000201_A]()) }

func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_New()}; return nil }

func A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_invoke, New: A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_new, Get: A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_get}

var A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000191$fn__619000192$G__619000184__619000196", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_core_protocols_eval619000191_fn__619000192_A_class, Simple: "G__619000184__619000196", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_Init; i.Table = A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000191_fn__619000192_G__619000184__619000196_A]()) }

func A_arbace_core_protocols_eval619000209_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000209_A_New()}; return nil }

var A_arbace_core_protocols_eval619000209_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_protocols_eval619000209_A_new}

var A_arbace_core_protocols_eval619000209_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000209", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_protocols_A_class, Simple: "eval619000209", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000209_A"})

func init() { i := A_arbace_core_protocols_eval619000209_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000209_A_InstanceOf; i.Table = A_arbace_core_protocols_eval619000209_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000209_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000209_A]()) }

func A_arbace_core_protocols_eval619000209_fn__619000210_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_eval619000209_fn__619000210_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_eval619000209_fn__619000210_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_eval619000209_fn__619000210_A_New()}; return nil }

func A_arbace_core_protocols_eval619000209_fn__619000210_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_eval619000209_fn__619000210_A_fn_class)}; return nil }

var A_arbace_core_protocols_eval619000209_fn__619000210_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_eval619000209_fn__619000210_A_invoke, New: A_arbace_core_protocols_eval619000209_fn__619000210_A_new, Get: A_arbace_core_protocols_eval619000209_fn__619000210_A_get}

var A_arbace_core_protocols_eval619000209_fn__619000210_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$eval619000209$fn__619000210", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_core_protocols_eval619000209_A_class, Simple: "fn__619000210", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_eval619000209_fn__619000210_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_eval619000209_fn__619000210_A_class.Info(); i.IsInstance = A_arbace_core_protocols_eval619000209_fn__619000210_A_InstanceOf; i.Init = A_arbace_core_protocols_eval619000209_fn__619000210_A_Init; i.Table = A_arbace_core_protocols_eval619000209_fn__619000210_A_members; jrt.RegisterGoType(A_arbace_core_protocols_eval619000209_fn__619000210_A_class, reflect.TypeFor[A_arbace_core_protocols_eval619000209_fn__619000210_A]()) }

func A_arbace_core_protocols_interface_or_naive_reduce_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_interface_or_naive_reduce_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_interface_or_naive_reduce_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_interface_or_naive_reduce_A_New()}; return nil }

func A_arbace_core_protocols_interface_or_naive_reduce_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_interface_or_naive_reduce_A_fn_class)}; return nil }

var A_arbace_core_protocols_interface_or_naive_reduce_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_interface_or_naive_reduce_A_invoke, New: A_arbace_core_protocols_interface_or_naive_reduce_A_new, Get: A_arbace_core_protocols_interface_or_naive_reduce_A_get}

var A_arbace_core_protocols_interface_or_naive_reduce_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$interface_or_naive_reduce", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_core_protocols_A_class, Simple: "interface_or_naive_reduce", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_interface_or_naive_reduce_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_interface_or_naive_reduce_A_class.Info(); i.IsInstance = A_arbace_core_protocols_interface_or_naive_reduce_A_InstanceOf; i.Init = A_arbace_core_protocols_interface_or_naive_reduce_A_Init; i.Table = A_arbace_core_protocols_interface_or_naive_reduce_A_members; jrt.RegisterGoType(A_arbace_core_protocols_interface_or_naive_reduce_A_class, reflect.TypeFor[A_arbace_core_protocols_interface_or_naive_reduce_A]()) }

func A_arbace_core_protocols_iter_reduce_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_iter_reduce_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_protocols_iter_reduce_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_iter_reduce_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_iter_reduce_A_New()}; return nil }

func A_arbace_core_protocols_iter_reduce_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_iter_reduce_A_fn_class)}; return nil }

var A_arbace_core_protocols_iter_reduce_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_iter_reduce_A_invoke, New: A_arbace_core_protocols_iter_reduce_A_new, Get: A_arbace_core_protocols_iter_reduce_A_get}

var A_arbace_core_protocols_iter_reduce_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$iter_reduce", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_protocols_A_class, Simple: "iter_reduce", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_iter_reduce_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_iter_reduce_A_class.Info(); i.IsInstance = A_arbace_core_protocols_iter_reduce_A_InstanceOf; i.Init = A_arbace_core_protocols_iter_reduce_A_Init; i.Table = A_arbace_core_protocols_iter_reduce_A_members; jrt.RegisterGoType(A_arbace_core_protocols_iter_reduce_A_class, reflect.TypeFor[A_arbace_core_protocols_iter_reduce_A]()) }

func A_arbace_core_protocols_iterator_reduce_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_iterator_reduce_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_protocols_iterator_reduce_BANG__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_iterator_reduce_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_iterator_reduce_BANG__A_New()}; return nil }

func A_arbace_core_protocols_iterator_reduce_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_iterator_reduce_BANG__A_fn_class)}; return nil }

var A_arbace_core_protocols_iterator_reduce_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_iterator_reduce_BANG__A_invoke, New: A_arbace_core_protocols_iterator_reduce_BANG__A_new, Get: A_arbace_core_protocols_iterator_reduce_BANG__A_get}

var A_arbace_core_protocols_iterator_reduce_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$iterator_reduce_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_protocols_A_class, Simple: "iterator_reduce_BANG_", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_iterator_reduce_BANG__A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_iterator_reduce_BANG__A_class.Info(); i.IsInstance = A_arbace_core_protocols_iterator_reduce_BANG__A_InstanceOf; i.Init = A_arbace_core_protocols_iterator_reduce_BANG__A_Init; i.Table = A_arbace_core_protocols_iterator_reduce_BANG__A_members; jrt.RegisterGoType(A_arbace_core_protocols_iterator_reduce_BANG__A_class, reflect.TypeFor[A_arbace_core_protocols_iterator_reduce_BANG__A]()) }

func A_arbace_core_protocols_naive_seq_reduce_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_naive_seq_reduce_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_naive_seq_reduce_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_naive_seq_reduce_A_New()}; return nil }

func A_arbace_core_protocols_naive_seq_reduce_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_naive_seq_reduce_A_fn_class)}; return nil }

var A_arbace_core_protocols_naive_seq_reduce_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_naive_seq_reduce_A_invoke, New: A_arbace_core_protocols_naive_seq_reduce_A_new, Get: A_arbace_core_protocols_naive_seq_reduce_A_get}

var A_arbace_core_protocols_naive_seq_reduce_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$naive_seq_reduce", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_core_protocols_A_class, Simple: "naive_seq_reduce", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_naive_seq_reduce_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_naive_seq_reduce_A_class.Info(); i.IsInstance = A_arbace_core_protocols_naive_seq_reduce_A_InstanceOf; i.Init = A_arbace_core_protocols_naive_seq_reduce_A_Init; i.Table = A_arbace_core_protocols_naive_seq_reduce_A_members; jrt.RegisterGoType(A_arbace_core_protocols_naive_seq_reduce_A_class, reflect.TypeFor[A_arbace_core_protocols_naive_seq_reduce_A]()) }

func A_arbace_core_protocols_seq_reduce_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_core_protocols_seq_reduce_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_protocols_seq_reduce_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols_seq_reduce_A_New()}; return nil }

func A_arbace_core_protocols_seq_reduce_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_protocols_seq_reduce_A_fn_class)}; return nil }

var A_arbace_core_protocols_seq_reduce_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_protocols_seq_reduce_A_invoke, New: A_arbace_core_protocols_seq_reduce_A_new, Get: A_arbace_core_protocols_seq_reduce_A_get}

var A_arbace_core_protocols_seq_reduce_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols$seq_reduce", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_protocols_A_class, Simple: "seq_reduce", Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_seq_reduce_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols_seq_reduce_A_class.Info(); i.IsInstance = A_arbace_core_protocols_seq_reduce_A_InstanceOf; i.Init = A_arbace_core_protocols_seq_reduce_A_Init; i.Table = A_arbace_core_protocols_seq_reduce_A_members; jrt.RegisterGoType(A_arbace_core_protocols_seq_reduce_A_class, reflect.TypeFor[A_arbace_core_protocols_seq_reduce_A]()) }

func A_arbace_core_protocols_CollReduce_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_core_protocols_CollReduce_A).Coll_reduce_O__O(args[0]); case 1: return this.(A_arbace_core_protocols_CollReduce_A).Coll_reduce_O_O__O(args[0], args[1])}; return nil }

var A_arbace_core_protocols_CollReduce_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 coll_reduce (Ljava.lang.Object;)Ljava.lang.Object;\nM1025 coll_reduce (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;", Invoke: A_arbace_core_protocols_CollReduce_A_invoke}

var A_arbace_core_protocols_CollReduce_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols.CollReduce", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_CollReduce_A"})

func init() { i := A_arbace_core_protocols_CollReduce_A_class.Info(); i.IsInstance = A_arbace_core_protocols_CollReduce_A_InstanceOf; i.Table = A_arbace_core_protocols_CollReduce_A_members }

func A_arbace_core_protocols_Datafiable_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_core_protocols_Datafiable_A).Datafy__O()}; return nil }

var A_arbace_core_protocols_Datafiable_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 datafy ()Ljava.lang.Object;", Invoke: A_arbace_core_protocols_Datafiable_A_invoke}

var A_arbace_core_protocols_Datafiable_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols.Datafiable", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_Datafiable_A"})

func init() { i := A_arbace_core_protocols_Datafiable_A_class.Info(); i.IsInstance = A_arbace_core_protocols_Datafiable_A_InstanceOf; i.Table = A_arbace_core_protocols_Datafiable_A_members }

func A_arbace_core_protocols_IKVReduce_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_core_protocols_IKVReduce_A).Kv_reduce_O_O__O(args[0], args[1])}; return nil }

var A_arbace_core_protocols_IKVReduce_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 kv_reduce (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;", Invoke: A_arbace_core_protocols_IKVReduce_A_invoke}

var A_arbace_core_protocols_IKVReduce_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols.IKVReduce", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_IKVReduce_A"})

func init() { i := A_arbace_core_protocols_IKVReduce_A_class.Info(); i.IsInstance = A_arbace_core_protocols_IKVReduce_A_InstanceOf; i.Table = A_arbace_core_protocols_IKVReduce_A_members }

func A_arbace_core_protocols_InternalReduce_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_core_protocols_InternalReduce_A).Internal_reduce_O_O__O(args[0], args[1])}; return nil }

var A_arbace_core_protocols_InternalReduce_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 internal_reduce (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;", Invoke: A_arbace_core_protocols_InternalReduce_A_invoke}

var A_arbace_core_protocols_InternalReduce_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols.InternalReduce", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_InternalReduce_A"})

func init() { i := A_arbace_core_protocols_InternalReduce_A_class.Info(); i.IsInstance = A_arbace_core_protocols_InternalReduce_A_InstanceOf; i.Table = A_arbace_core_protocols_InternalReduce_A_members }

func A_arbace_core_protocols_Navigable_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_core_protocols_Navigable_A).Nav_O_O__O(args[0], args[1])}; return nil }

var A_arbace_core_protocols_Navigable_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 nav (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;", Invoke: A_arbace_core_protocols_Navigable_A_invoke}

var A_arbace_core_protocols_Navigable_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols.Navigable", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols_Navigable_A"})

func init() { i := A_arbace_core_protocols_Navigable_A_class.Info(); i.IsInstance = A_arbace_core_protocols_Navigable_A_InstanceOf; i.Table = A_arbace_core_protocols_Navigable_A_members }

func A_arbace_core_protocols__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_core_protocols__init_A_Load__O(); case 1: return A_arbace_core_protocols__init_A_Unit0__O(); case 2: return A_arbace_core_protocols__init_A_Unit1__O(); case 3: return A_arbace_core_protocols__init_A_Unit10__O(); case 4: return A_arbace_core_protocols__init_A_Unit11__O(); case 5: return A_arbace_core_protocols__init_A_Unit12__O(); case 6: return A_arbace_core_protocols__init_A_Unit13__O(); case 7: return A_arbace_core_protocols__init_A_Unit14__O(); case 8: return A_arbace_core_protocols__init_A_Unit15__O(); case 9: return A_arbace_core_protocols__init_A_Unit16__O(); case 10: return A_arbace_core_protocols__init_A_Unit17__O(); case 11: return A_arbace_core_protocols__init_A_Unit18__O(); case 12: return A_arbace_core_protocols__init_A_Unit19__O(); case 13: return A_arbace_core_protocols__init_A_Unit2__O(); case 14: return A_arbace_core_protocols__init_A_Unit20__O(); case 15: return A_arbace_core_protocols__init_A_Unit21__O(); case 16: return A_arbace_core_protocols__init_A_Unit22__O(); case 17: return A_arbace_core_protocols__init_A_Unit23__O(); case 18: return A_arbace_core_protocols__init_A_Unit24__O(); case 19: return A_arbace_core_protocols__init_A_Unit25__O(); case 20: return A_arbace_core_protocols__init_A_Unit26__O(); case 21: return A_arbace_core_protocols__init_A_Unit27__O(); case 22: return A_arbace_core_protocols__init_A_Unit28__O(); case 23: return A_arbace_core_protocols__init_A_Unit29__O(); case 24: return A_arbace_core_protocols__init_A_Unit3__O(); case 25: return A_arbace_core_protocols__init_A_Unit30__O(); case 26: return A_arbace_core_protocols__init_A_Unit31__O(); case 27: return A_arbace_core_protocols__init_A_Unit32__O(); case 28: return A_arbace_core_protocols__init_A_Unit33__O(); case 29: return A_arbace_core_protocols__init_A_Unit34__O(); case 30: return A_arbace_core_protocols__init_A_Unit35__O(); case 31: return A_arbace_core_protocols__init_A_Unit36__O(); case 32: return A_arbace_core_protocols__init_A_Unit37__O(); case 33: return A_arbace_core_protocols__init_A_Unit38__O(); case 34: return A_arbace_core_protocols__init_A_Unit39__O(); case 35: return A_arbace_core_protocols__init_A_Unit4__O(); case 36: return A_arbace_core_protocols__init_A_Unit40__O(); case 37: return A_arbace_core_protocols__init_A_Unit41__O(); case 38: return A_arbace_core_protocols__init_A_Unit42__O(); case 39: return A_arbace_core_protocols__init_A_Unit43__O(); case 40: return A_arbace_core_protocols__init_A_Unit44__O(); case 41: return A_arbace_core_protocols__init_A_Unit45__O(); case 42: return A_arbace_core_protocols__init_A_Unit46__O(); case 43: return A_arbace_core_protocols__init_A_Unit47__O(); case 44: return A_arbace_core_protocols__init_A_Unit48__O(); case 45: return A_arbace_core_protocols__init_A_Unit49__O(); case 46: return A_arbace_core_protocols__init_A_Unit5__O(); case 47: return A_arbace_core_protocols__init_A_Unit50__O(); case 48: return A_arbace_core_protocols__init_A_Unit51__O(); case 49: return A_arbace_core_protocols__init_A_Unit52__O(); case 50: return A_arbace_core_protocols__init_A_Unit53__O(); case 51: return A_arbace_core_protocols__init_A_Unit54__O(); case 52: return A_arbace_core_protocols__init_A_Unit55__O(); case 53: return A_arbace_core_protocols__init_A_Unit56__O(); case 54: return A_arbace_core_protocols__init_A_Unit57__O(); case 55: return A_arbace_core_protocols__init_A_Unit58__O(); case 56: return A_arbace_core_protocols__init_A_Unit59__O(); case 57: return A_arbace_core_protocols__init_A_Unit6__O(); case 58: return A_arbace_core_protocols__init_A_Unit7__O(); case 59: return A_arbace_core_protocols__init_A_Unit8__O(); case 60: return A_arbace_core_protocols__init_A_Unit9__O()}; return nil }

func A_arbace_core_protocols__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_protocols__init_A_New()}; return nil }

var A_arbace_core_protocols__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit41 ()Ljava.lang.Object;\nM9 unit42 ()Ljava.lang.Object;\nM9 unit43 ()Ljava.lang.Object;\nM9 unit44 ()Ljava.lang.Object;\nM9 unit45 ()Ljava.lang.Object;\nM9 unit46 ()Ljava.lang.Object;\nM9 unit47 ()Ljava.lang.Object;\nM9 unit48 ()Ljava.lang.Object;\nM9 unit49 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit50 ()Ljava.lang.Object;\nM9 unit51 ()Ljava.lang.Object;\nM9 unit52 ()Ljava.lang.Object;\nM9 unit53 ()Ljava.lang.Object;\nM9 unit54 ()Ljava.lang.Object;\nM9 unit55 ()Ljava.lang.Object;\nM9 unit56 ()Ljava.lang.Object;\nM9 unit57 ()Ljava.lang.Object;\nM9 unit58 ()Ljava.lang.Object;\nM9 unit59 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_core_protocols__init_A_invoke, New: A_arbace_core_protocols__init_A_new}

var A_arbace_core_protocols__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.protocols__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_core_protocols.A_arbace_core_protocols__init_A", Source: "protocols.ae"})

func init() { i := A_arbace_core_protocols__init_A_class.Info(); i.IsInstance = A_arbace_core_protocols__init_A_InstanceOf; i.Init = A_arbace_core_protocols__init_A_Init; i.Table = A_arbace_core_protocols__init_A_members; jrt.RegisterGoType(A_arbace_core_protocols__init_A_class, reflect.TypeFor[A_arbace_core_protocols__init_A]()) }
