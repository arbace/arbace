//line j2g_strings.ae:1
package aot_arbace_go_check_types

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn21,arbace.go.check.constyn1,cyn11,arbace.corekn3,dockn4,sizekn4,namekn4,boolkn5,bool?kn4,int8kn4,int?kn5,int16kn5,int32kn5,int64kn3,intkn5,uint8kn9,unsigned?kn6,uint16kn6,uint32kn6,uint64kn4,uintkn7,uintptrkn7,float32kn6,float?kn7,float64kn9,complex64kn8,complex?kn10,complex128kn6,stringkn7,string?kn14,unsafe-pointerkn12,untyped-boolkn8,untyped?kn11,untyped-intkn12,untyped-runekn13,untyped-floatkn15,untyped-complexkn14,untyped-stringkn11,untyped-nilkn4,bytekn4,runekn6,actualkn3,pkgkn3,objkn5,tuplekn9,interfacekn4,typekn7,pointerkn5,arraykn5,namedkn3,mapkn5,slicekn4,chankn6,tparamkn4,funckn6,structkn4,elsekn2,idkn7,methodskn10,underlyingkn7,invalidkn9,resolvingkn3,tagkn3,allkn5,termskn10,comparablekn5,unionkn5,orderkn5,ifacekn5,boundkn4,bothkn8,embeddedkn5,localkn8,pkg-namekn5,targskn4,recvkn4,sendkn6,originkn9,multipleskn9,ambiguouskn4,kindkn6,methodkn9,recv-typekn5,indexkn3,viakn8,indirectkn5,fieldkn12,iface-methodkn8,ptr-recvkn5,foundkn10,incompletekn5,causekn7,missingkn10,wrong-typekn4,havekn10,unexportedkn10,wrong-namekn7,tparamsv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,v11,arbace.core5,referR5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn21,arbace.go.check.typesm2,R6,s1099,goi's checker: Go types (doc/go/GOI-SPEC.md §3.3), their predicates, printing, sizes, and\n  the lookup of fields and methods, after go/types (predicates.go, typestring.go, gcsizes.go,\n  lookup.go, methodset.go).\n\n  Basic types are keywords (:int, :untyped-float ...). Composite types are vectors compared by\n  structure: [:pointer T], [:slice T], [:array n T], [:map K V], [:chan dir T] (dir :both,\n  :send, :recv), [:func params results variadic?], [:struct fields] (each field {:name :type\n  :tag :embedded :pkg}, :pkg the package path of an unexported name), [:interface methods\n  terms] (methods the whole method set, embedded interfaces flattened, sorted by name and\n  package: {:name :type :pkg}; terms nil but for constraints), [:tuple T...]. Named types and\n  type parameters are [:named v] and [:tparam v], v a volatile holding their data, so that =\n  is identity on them (a volatile is equal only to itself).\n\n  A named type's volatile holds {:obj the type name's object, :name, :pkg path, :pkg-name,\n  :underlying, :methods [method objects], :origin and :targs for an instance, :tparams}.v11,arbace.core4,intoR7,R8,v11,arbace.core3,mapR9,l1,R10,R11,R12,R13,l2,R14,l4,R15,l8,R16,R17,R18,R19,R20,R21,R22,R23,R24,R25,R26,R27,R28,R29,l16,R30,R31,R32,R33,l0,R34,R35,R36,R37,R38,R39,R40,R41,R42,v11,arbace.core7,keywordv21,arbace.go.check.types10,kw-aliasesR43,R44,R45,v11,arbace.core9,namespacev21,arbace.go.check.types13,kw-alias-infov21,arbace.go.check.types8,canon-kwR46,v11,arbace.core9,with-metaV1,R46,v21,arbace.go.check.types5,canonv11,arbace.core4,restR47,v11,arbace.core4,mapvv11,arbace.core6,updateR48,R49,R50,R51,R52,R53,R54,R55,R56,v11,arbace.core6,every?v11,arbace.core5,true?v11,arbace.core10,identical?R57,v11,arbace.core3,notv21,arbace.go.check.types9,*spelled*v11,arbace.core8,keyword?v11,arbace.core7,vector?v21,arbace.go.check.types9,canon-vecR58,v21,arbace.go.check.types3,idsv11,arbace.core7,vreset!v11,arbace.core5,applyv11,arbace.core9,volatile!v11,arbace.core5,assocR59,v21,arbace.go.check.types7,next-idR60,v21,arbace.go.check.types4,infoR61,v21,arbace.go.check.types6,named?v11,arbace.core9,contains?R62,v21,arbace.go.check.types15,*resolve-named*R63,v21,arbace.go.check.types11,named-underv21,arbace.go.check.types12,tparam-ifacev21,arbace.go.check.types5,underv21,arbace.go.check.types5,basicv21,arbace.go.check.types10,basic-infov21,arbace.go.check.types4,flagv21,arbace.go.check.types13,integer-type?v21,arbace.go.check.types11,float-type?v21,arbace.go.check.types13,complex-type?v21,arbace.go.check.types8,untyped?S3,R62,R40,R32,v21,arbace.go.check.types12,string-type?v11,arbace.core4,not=v21,arbace.go.check.types7,tparam?v21,arbace.go.check.types8,under-isv11,arbace.core5,some?v21,arbace.go.check.types8,has-nil?S6,R54,R47,R56,R49,R53,R52,v11,arbace.core6,empty?v21,arbace.go.check.types11,ignore-tagsV1,R46,R64,R65,R66,R67,v11,arbace.core3,seqv21,arbace.go.check.types20,strictly-comparable?v21,arbace.go.check.types16,tset-comparable?v21,arbace.go.check.types11,tparam-tsetv21,arbace.go.check.types16,comparable-type?v21,arbace.go.check.types10,iface-tsetv21,arbace.go.check.types8,type-strv11,arbace.core4,someR68,v21,arbace.go.check.types5,same?v21,arbace.go.check.types14,term-disjoint?v11,arbace.core5,firstv11,arbace.core3,vecv11,arbace.core3,setR69,v21,arbace.go.check.types10,term-unionv21,arbace.go.check.types10,terms-normv11,arbace.core6,concatv21,arbace.go.check.types7,orderedv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv21,arbace.go.check.types14,term-intersectv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv21,arbace.go.check.types14,term-includes?v21,arbace.go.check.types12,term-subset?v21,arbace.go.check.types18,terms-superset-of?v11,arbace.core4,map?v21,arbace.go.check.types6,union?v21,arbace.go.check.types9,make-tsetR70,v21,arbace.go.check.types11,bound-ifaceR71,v21,arbace.go.check.types12,update-info!v21,arbace.go.check.types10,has-terms?V1,V2,nnv21,arbace.go.check.types13,typeset-pairsv21,arbace.go.check.types11,typeset-allv21,arbace.go.check.types9,all-basicv21,arbace.go.check.types9,unsigned?v21,arbace.go.check.types8,numeric?v21,arbace.go.check.types13,boolean-type?v21,arbace.go.check.types8,ordered?V2,ns16,no specific typeR72,V2,ns30,conflicting channel directionsV2,ns26,different underlying typesv11,arbace.core6,pr-strv21,arbace.go.check.types12,common-underv11,arbace.core7,sort-byv13,arbace.string4,joinv11,arbace.core11,map-indexedv21,arbace.go.check.types10,params-strR73,v21,arbace.go.check.const10,value-textv21,arbace.go.check.types9,*qualify*R74,R75,R76,v21,arbace.go.check.types11,basic-namesv11,arbace.core4,namev21,arbace.go.check.types9,named-strV1,s10,comparablev21,arbace.go.check.types7,sig-strv21,arbace.go.check.types9,terms-strR77,R78,v21,arbace.go.check.types9,field-strS2,s23,internal/runtime/atomics11,sync/atomicv21,arbace.go.check.types7,alignofv21,arbace.go.check.types20,sync-atomic-align64?v11,arbace.core6,reduceS2,R47,R53,v21,arbace.go.check.types9,word-sizev21,arbace.go.check.types6,sizeofv21,arbace.go.check.types9,max-alignv21,arbace.go.check.types8,align-upl-1,v21,arbace.go.check.types9,offsetsofv11,arbace.core4,peekR79,v21,arbace.go.check.types11,*fold-case*v21,arbace.go.check.types10,methods-ofv11,arbace.core4,nextv11,arbace.core8,to-arrayv21,arbace.go.check.types8,same-id?v11,arbace.core8,assoc-inR80,v21,arbace.go.check.types10,deref-typev21,arbace.go.check.types10,interface?v21,arbace.go.check.types12,named-methodv21,arbace.go.check.types12,iface-methodm2,R81,TR82,R83,v11,arbace.core6,secondR84,R85,R86,R87,m2,R81,TR88,m2,R81,TR89,R81,R90,v21,arbace.go.check.types12,*method-obj*R91,v21,arbace.go.check.types11,consolidatev21,arbace.go.check.types8,pointer?v21,arbace.go.check.types11,lookup-implR92,R93,R94,R95,R96,v11,arbace.core19,pop-thread-bindingsv21,arbace.go.check.types11,method-dataR97,R98,v21,arbace.go.check.types14,*subst-method*R99,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv21,arbace.go.check.types14,missing-methodv21,arbace.go.check.types11,tset-empty?v21,arbace.go.check.types11,comparable?v21,arbace.go.check.types13,terms-subset?v21,arbace.go.check.types15,terms-includes?")

var Lit_1 *jrt.String = jrt.Intern("arbace.go.check.types$alignof$fn__219000252")

var Lit_2 *jrt.String = jrt.Intern("arbace.go.check.types$all_basic$fn__219000185")

var Lit_3 *jrt.String = jrt.Intern("arbace.go.check.types$all_numeric_or_string_QMARK_$fn__219000198")

var Lit_4 *jrt.String = jrt.Intern("arbace.go.check.types$canon_vec$fn__219000025")

var Lit_5 *jrt.String = jrt.Intern("arbace.go.check.types$canon_vec$fn__219000030")

var Lit_6 *jrt.String = jrt.Intern("channels ")

var Lit_7 *jrt.String = jrt.Intern(" and ")

var Lit_8 *jrt.String = jrt.Intern(" have different element types")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.check.types$comparable_type_QMARK_$fn__219000086")

var Lit_10 *jrt.String = jrt.Intern("")

var Lit_11 *jrt.String = jrt.Intern(" ")

var Lit_12 *jrt.String = jrt.Intern("arbace.go.check.types$fn__219000012$m__219000013")

var Lit_13 *jrt.String = jrt.Intern("arbace.go.check.types$fn__219000012$m__219000013$fn__219000014")

var Lit_14 *jrt.String = jrt.Intern("arbace.go.check.types$has_nil_QMARK_$fn__219000065")

var Lit_15 *jrt.String = jrt.Intern("arbace.go.check.types$ignore_tags$fn__219000073")

var Lit_16 *jrt.String = jrt.Intern("arbace.go.check.types$incomparable_cause$cause__219000090")

var Lit_17 *jrt.String = jrt.Intern(" cannot be compared")

var Lit_18 *jrt.String = jrt.Intern("arbace.go.check.types$incomparable_cause$cause__219000090$fn__219000092")

var Lit_19 *jrt.String = jrt.Intern("struct containing ")

var Lit_20 *jrt.String = jrt.Intern("arbace.go.check.types")

var Lit_21 *jrt.String = jrt.Intern("a")

var Lit_22 *jrt.String = jrt.Intern("-")

var Lit_23 *jrt.String = jrt.Intern("arbace.go.check.types$lookup_impl$fn__219000275")

var Lit_24 *jrt.String = jrt.Intern("arbace.go.check.types$missing_method$fn__219000289")

var Lit_25 *jrt.String = jrt.Intern("arbace.go.check.types$missing_method$fn__219000289$fn__219000290")

var Lit_26 *jrt.String = jrt.Intern(".")

var Lit_27 *jrt.String = jrt.Intern("[")

var Lit_28 *jrt.String = jrt.Intern("]")

var Lit_29 *jrt.String = jrt.Intern(",")

var Lit_30 *jrt.String = jrt.Intern("incrementAndGet")

var Lit_31 *jrt.String = jrt.Intern("(")

var Lit_32 *jrt.String = jrt.Intern(")")

var Lit_33 *jrt.String = jrt.Intern(", ")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.check.types$params_str$fn__219000225")

var Lit_35 *jrt.String = jrt.Intern("...")

var Lit_36 *jrt.String = jrt.Intern("cannot satisfy ")

var Lit_37 *jrt.String = jrt.Intern(" (empty type set)")

var Lit_38 *jrt.String = jrt.Intern(" does not satisfy ")

var Lit_39 *jrt.String = jrt.Intern(" (missing method ")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.check.types$satisfies_cause$comparability__219000294")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.check.types$satisfies_cause$comparability__219000294$fn__219000296")

var Lit_42 *jrt.String = jrt.Intern(" does not satisfy comparable")

var Lit_43 *jrt.String = jrt.Intern(" (")

var Lit_44 *jrt.String = jrt.Intern("arbace.go.check.types$sort_methods$fn__219000285")

var Lit_45 *jrt.String = jrt.Intern("align64")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.check.types$terms_includes_QMARK_$fn__219000138")

var Lit_47 *jrt.String = jrt.Intern("arbace.go.check.types$terms_intersect$iter__219000120__219000126")

var Lit_48 *jrt.String = jrt.Intern("arbace.go.check.types$terms_intersect$iter__219000120__219000126$fn__219000127")

var Lit_49 *jrt.String = jrt.Intern("arbace.go.check.types$terms_intersect$iter__219000120__219000126$fn__219000127$iter__219000122__219000128")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.check.types$terms_intersect$iter__219000120__219000126$fn__219000127$iter__219000122__219000128$fn__219000129")

var Lit_51 *jrt.String = jrt.Intern("arbace.go.check.types$terms_intersect$iter__219000120__219000126$fn__219000127$iter__219000122__219000128$fn__219000129$fn__219000130")

var Lit_52 *jrt.String = jrt.Intern("arbace.go.check.types$terms_norm$fn__219000115")

var Lit_53 *jrt.String = jrt.Intern("∅")

var Lit_54 *jrt.String = jrt.Intern(" | ")

var Lit_55 *jrt.String = jrt.Intern("arbace.go.check.types$terms_str$iter__219000208__219000212")

var Lit_56 *jrt.String = jrt.Intern("arbace.go.check.types$terms_str$iter__219000208__219000212$fn__219000213")

var Lit_57 *jrt.String = jrt.Intern("arbace.go.check.types$terms_str$iter__219000208__219000212$fn__219000213$fn__219000214")

var Lit_58 *jrt.String = jrt.Intern("~")

var Lit_59 *jrt.String = jrt.Intern("arbace.go.check.types$terms_subset_QMARK_$fn__219000146")

var Lit_60 *jrt.String = jrt.Intern("arbace.go.check.types$terms_superset_of_QMARK_$fn__219000142")

var Lit_61 *jrt.String = jrt.Intern("arbace.go.check.types$tset_comparable_QMARK_$fn__219000078")

var Lit_62 *jrt.String = jrt.Intern("interface {}")

var Lit_63 *jrt.String = jrt.Intern("interface {")

var Lit_64 *jrt.String = jrt.Intern("}")

var Lit_65 *jrt.String = jrt.Intern("; ")

var Lit_66 *jrt.String = jrt.Intern("arbace.go.check.types$type_str$iter__219000238__219000242")

var Lit_67 *jrt.String = jrt.Intern("*")

var Lit_68 *jrt.String = jrt.Intern("map[")

var Lit_69 *jrt.String = jrt.Intern("[]")

var Lit_70 *jrt.String = jrt.Intern("<-chan ")

var Lit_71 *jrt.String = jrt.Intern("chan ")

var Lit_72 *jrt.String = jrt.Intern("chan<- ")

var Lit_73 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_74 *jrt.String = jrt.Intern("func")

var Lit_75 *jrt.String = jrt.Intern("struct{")

var Lit_76 *jrt.String = jrt.Intern("arbace.go.check.types$type_str$iter__219000238__219000242$fn__219000243")

var Lit_77 *jrt.String = jrt.Intern("arbace.go.check.types$type_str$iter__219000238__219000242$fn__219000243$fn__219000244")

var Lit_78 *jrt.String = jrt.Intern("arbace.go.check.types$typeset_all$fn__219000175")

var Lit_79 *jrt.String = jrt.Intern("arbace.go.check.types$typeset_pairs$iter__219000157__219000161")

var Lit_80 *jrt.String = jrt.Intern("arbace.go.check.types$typeset_pairs$iter__219000157__219000161$fn__219000162")

var Lit_81 *jrt.String = jrt.Intern("arbace.go.check.types$typeset_pairs$iter__219000157__219000161$fn__219000162$fn__219000163")

var Lit_82 *jrt.String = jrt.Intern("arbace.go.check.types$under_is$fn__219000181")

var Lit_83 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn4,boolkn4,int8kn5,int16kn5,int32kn5,int64kn3,intkn5,uint8kn6,uint16kn6,uint32kn6,uint64kn4,uintkn7,uintptrkn7,float32kn7,float64kn9,complex64kn10,complex128kn6,stringkn14,unsafe-pointerkn12,untyped-boolkn11,untyped-intkn12,untyped-runekn13,untyped-floatkn15,untyped-complexkn14,untyped-stringkn11,untyped-nilkn7,invalidkn4,bytekn4,runekn7,dynamickn7,privatekn8,arglistsyn1,xyn4,nameyn3,pkgyn6,actualyn1,kyn1,tkn8,declaredyn1,ykn3,tagyn4,longyn1,fyn1,&yn4,argsyn4,datayn2,tsyn4,seenyn7,dynamicyn2,xtyn2,ytyn5,tildeyn2,tyyn2,xlyn2,ylyn5,termsyn10,comparableyn1,uyn1,byn2,tpyn4,predyn3,cndv11,arbace.core5,in-nsMyn21,arbace.go.check.typesm2,R0,s1099,goi's checker: Go types (doc/go/GOI-SPEC.md §3.3), their predicates, printing, sizes, and\n  the lookup of fields and methods, after go/types (predicates.go, typestring.go, gcsizes.go,\n  lookup.go, methodset.go).\n\n  Basic types are keywords (:int, :untyped-float ...). Composite types are vectors compared by\n  structure: [:pointer T], [:slice T], [:array n T], [:map K V], [:chan dir T] (dir :both,\n  :send, :recv), [:func params results variadic?], [:struct fields] (each field {:name :type\n  :tag :embedded :pkg}, :pkg the package path of an unexported name), [:interface methods\n  terms] (methods the whole method set, embedded interfaces flattened, sorted by name and\n  package: {:name :type :pkg}; terms nil but for constraints), [:tuple T...]. Named types and\n  type parameters are [:named v] and [:tparam v], v a volatile holding their data, so that =\n  is identity on them (a volatile is equal only to itself).\n\n  A named type's volatile holds {:obj the type name's object, :name, :pkg path, :pkg-name,\n  :underlying, :methods [method objects], :origin and :targs for an instance, :tparams}.m2,R0,s1099,goi's checker: Go types (doc/go/GOI-SPEC.md §3.3), their predicates, printing, sizes, and\n  the lookup of fields and methods, after go/types (predicates.go, typestring.go, gcsizes.go,\n  lookup.go, methodset.go).\n\n  Basic types are keywords (:int, :untyped-float ...). Composite types are vectors compared by\n  structure: [:pointer T], [:slice T], [:array n T], [:map K V], [:chan dir T] (dir :both,\n  :send, :recv), [:func params results variadic?], [:struct fields] (each field {:name :type\n  :tag :embedded :pkg}, :pkg the package path of an unexported name), [:interface methods\n  terms] (methods the whole method set, embedded interfaces flattened, sorted by name and\n  package: {:name :type :pkg}; terms nil but for constraints), [:tuple T...]. Named types and\n  type parameters are [:named v] and [:tparam v], v a volatile holding their data, so that =\n  is identity on them (a volatile is equal only to itself).\n\n  A named type's volatile holds {:obj the type name's object, :name, :pkg path, :pkg-name,\n  :underlying, :methods [method objects], :origin and :targs for an instance, :tparams}.R1,v21,arbace.go.check.types10,basic-infom8,R2,i22,R3,i1,R4,s24,arbace/go/check/types.aeR0,s81,{kind {:size :int? :unsigned? :float? :complex? :string? :bool? :untyped? :name}}v21,arbace.go.check.types11,basic-namesm56,R5,s4,boolR6,s4,int8R7,s5,int16R8,s5,int32R9,s5,int64R10,s3,intR11,s5,uint8R12,s6,uint16R13,s6,uint32R14,s6,uint64R15,s4,uintR16,s7,uintptrR17,s7,float32R18,s7,float64R19,s9,complex64R20,s10,complex128R21,s6,stringR22,s14,unsafe.PointerR23,s12,untyped boolR24,s11,untyped intR25,s12,untyped runeR26,s13,untyped floatR27,s15,untyped complexR28,s14,untyped stringR29,s11,untyped nilR30,s12,invalid typeR31,s4,byteR32,s4,runem6,R2,i41,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,*spelled*m10,R33,TR2,i59,R3,i1,R4,s24,arbace/go/check/types.aeR0,s75,Whether types keep go/types' spellings of byte and rune (the resolve mode).v21,arbace.go.check.types10,kw-aliasesm10,R34,TR2,i63,R3,i1,R4,s24,arbace/go/check/types.aeR0,s132,The resolve mode's aliases of basic types (type A = int): their keywords\n  (:arbace.go.check.types/aN) -> {:actual :name :pkg :obj}.v21,arbace.go.check.types8,kw-aliasm10,R35,L1,V4,R36,R37,R38,R39,R0,s111,The keyword spelling alias object x (named name, of package pkg) of basic type actual (made\n  once per object).R2,i68,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types13,kw-alias-infom8,R35,L1,V1,R40,R2,i76,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,canon-kwm10,R35,L1,V1,R41,R0,s89,The canonical basic type of a keyword: uint8 for byte, int32 for rune, an alias's actual.R2,i78,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types5,canonm8,R42,TR2,i86,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,canon-vecm10,R34,TR35,L1,V1,R41,R2,i88,R3,i1,R4,s24,arbace/go/check/types.aem10,R35,L1,V1,R41,R0,s117,t with its spellings (byte, rune) made canonical, deeply (named types and type parameters\n  are their own: identity).R2,i105,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types5,same?m10,R35,L1,V2,R36,R43,R0,s84,Whether types x and y are identical: equal, or (the resolve mode) canonically equal.R2,i115,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types3,idsm8,R34,TR2,i122,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types7,next-idm8,R35,L1,MV0,m2,R44,R45,R2,i123,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types6,named?m8,R35,L1,V1,R41,R2,i125,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types7,tparam?m8,R35,L1,V1,R41,R2,i126,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types4,infom8,R35,L1,V1,R41,R2,i127,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,update-info!m8,R35,L1,V4,R41,R46,R47,R48,R2,i128,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,new-namedm10,R35,L1,V1,R49,R0,s84,A new named type: data {:obj :name :pkg :pkg-name ...}; its underlying is set later.R2,i130,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,new-tparamm10,R35,L1,V1,R49,R0,s90,A new type parameter: data {:name :index :bound (its constraint, set when declared) :obj}.R2,i135,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types15,*resolve-named*m10,R33,TR2,i140,R3,i1,R4,s24,arbace/go/check/types.aeR0,s159,A function called with a named type whose underlying type is not known yet (its declaration\n  not checked), which checks its declaration; bound by the checker.v21,arbace.go.check.types5,underm8,R42,TR2,i145,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,tparam-ifacem8,R42,TR2,i145,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,named-underm10,R34,TR35,L1,V1,R41,R2,i147,R3,i1,R4,s24,arbace/go/check/types.aem10,R35,L1,V1,R41,R0,s68,The underlying type of t (a basic type's canonical: uint8 for byte).R2,i162,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types5,basicm8,R35,L1,V1,R41,R2,i173,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types4,flagm10,R34,TR35,L1,V2,R41,R46,R2,i174,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types13,integer-type?m8,R35,L1,V1,R41,R2,i175,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,unsigned?m8,R35,L1,V1,R41,R2,i176,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,float-type?m8,R35,L1,V1,R41,R2,i177,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types13,complex-type?m8,R35,L1,V1,R41,R2,i178,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,numeric?m8,R35,L1,V1,R41,R2,i179,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,string-type?m8,R35,L1,V1,R41,R2,i180,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types13,boolean-type?m8,R35,L1,V1,R41,R2,i181,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,untyped?m8,R35,L1,V1,R41,R2,i182,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types6,typed?m8,R35,L1,V1,R41,R2,i183,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,const-type?m10,R35,L1,V1,R41,R0,s68,Whether values of t can be constants: booleans, numbers and strings.R2,i184,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,ordered?m8,R35,L1,V1,R41,R2,i188,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,interface?m8,R35,L1,V1,R41,R2,i189,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,pointer?m8,R35,L1,V1,R41,R2,i190,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types15,unsafe-pointer?m8,R35,L1,V1,R41,R2,i191,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,uintptr?m8,R35,L1,V1,R41,R2,i192,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types6,valid?m8,R35,L1,V1,R41,R2,i193,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types7,kind-ofm8,R35,L1,V1,R41,R2,i194,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,has-name?m8,R35,L1,V1,R41,R2,i195,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types17,integer-or-float?m8,R35,L1,V1,R41,R2,i196,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,under-ism8,R42,TR2,i198,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,has-nil?m10,R35,L1,V1,R41,R0,s158,Whether t's values include nil: pointers, slices, maps, channels, funcs, interfaces,\n  unsafe.Pointer; a type parameter's when every type of its type set has.R2,i200,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types16,empty-interface?m8,R35,L1,V1,R41,R2,i210,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,default-typem10,R35,L1,V1,R41,R0,s84,The default type of an untyped type (Go's Default: untyped rune's is rune, spelled).R2,i213,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,ignore-tagsm10,R35,L1,V1,R41,R0,s78,t with the tags of its struct types dropped, deeply (for IdenticalIgnoreTags).R2,i221,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types22,identical-ignore-tags?m8,R35,L1,V2,R36,R43,R2,i237,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,comparable?m8,R42,TR2,i239,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,type-strm8,R42,TR2,i239,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,tparam-tsetm8,R42,TR2,i241,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types20,strictly-comparable?m8,R42,TR2,i241,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,iface-tsetm8,R42,TR2,i241,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types16,tset-comparable?m12,R34,TR35,L1,V2,R50,R51,R0,s80,go/types' _TypeSet.IsComparable: every type of a type set comparable (strictly).R2,i243,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types16,comparable-type?m10,R35,L1,V3,R41,R52,R51,R0,s209,go/types' comparableType: whether values of t can be compared with ==; dynamic: the\n  specification's comparability (ordinary interfaces are comparable), else strict (an\n  interface only when its type set is).R2,i250,R3,i1,R4,s24,arbace/go/check/types.aem8,R35,L2,V1,R41,V2,R41,R51,R2,i271,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types18,incomparable-causem10,R35,L1,V1,R41,R0,s110,Why values of t cannot be compared (go/types' comparableType's cause, dynamic): \"\" when\n  it has none to give.R2,i273,R3,i1,R4,s24,arbace/go/check/types.aem10,R35,L2,V1,R41,V2,R41,R51,R0,s119,Go's Comparable: whether values of t can be compared with == (interfaces are; a type\n  parameter when its type set is).R2,i296,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types6,union?m8,R35,L1,V1,R41,R2,i313,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types14,term-disjoint?m10,R34,TR35,L1,V2,V2,R53,R36,V2,R54,R43,R2,i315,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,term-unionm10,R34,TR35,L1,V2,R36,R43,R2,i318,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types14,term-intersectm10,R34,TR35,L1,V2,R36,R43,R2,i324,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types14,term-includes?m10,R34,TR35,L1,V2,V2,R55,R56,R41,R2,i330,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,term-subset?m10,R34,TR35,L1,V2,R36,R43,R2,i332,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,terms-normm10,R35,L1,V1,R50,R0,s78,go/types' termlist.norm: the terms with the overlapping ones merged, as a set.R2,i334,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types7,orderedm12,R34,TR35,L1,V1,R50,R0,s75,A term set's terms in their written order (terms-norm's :order), GC144 (b).R2,i354,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,terms-unionm8,R35,L1,V2,R36,R43,R2,i359,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types15,terms-intersectm8,R35,L1,V2,R36,R43,R2,i361,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types15,terms-includes?m8,R35,L1,V2,R57,R41,R2,i368,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types18,terms-superset-of?m10,R34,TR35,L1,V2,R57,R43,R2,i370,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types13,terms-subset?m10,R35,L1,V2,R57,R58,R0,s38,Whether term set xl is a subset of yl.R2,i372,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,make-tsetm10,R35,L1,V2,R59,R60,R0,s52,An interface's type set element: nil for every type.R2,i381,R3,i1,R4,s24,arbace/go/check/types.aem10,R35,L1,V1,R61,R0,s101,The type set of interface type u (an underlying [:interface ms ts]): {:methods :terms\n  :comparable}.R2,i386,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,has-terms?m10,R35,L1,V1,R50,R0,s68,Whether a type set has specific terms (neither every type nor none).R2,i395,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,tset-empty?m8,R35,L1,V1,R50,R2,i400,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types17,method-set-iface?m10,R35,L1,V1,R61,R0,s119,go/types' IsMethodSet: whether interface type u is described by its methods alone (it may be\n  used as a value's type).R2,i402,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,bound-ifacem10,R35,L1,V1,R62,R0,s177,The interface a constraint b denotes: its underlying interface, or the implicit interface of\n  a union or a non-interface type (go/types' implicit interfaces); nil when invalid.R2,i408,R3,i1,R4,s24,arbace/go/check/types.aem10,R35,L1,V1,R63,R0,s75,go/types' TypeParam.iface: the interface of type parameter tp's constraint.R2,i420,R3,i1,R4,s24,arbace/go/check/types.aem8,R35,L1,V1,R63,R2,i429,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types13,typeset-pairsm10,R35,L1,V1,R41,R0,s160,The (type, underlying type) pairs of t's type set (go/types' typeset): a type parameter's\n  specific terms ([[nil nil]] when it has none), else [[t (under t)]].R2,i431,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,typeset-allm10,R35,L1,V2,R41,R46,R0,s68,go/types' all: whether (f t u) holds for every type of t's type set.R2,i442,R3,i1,R4,s24,arbace/go/check/types.aem10,R35,L1,V2,R41,R46,R0,s146,go/types' underIs: whether (f u) holds for the underlying type u of every type of t's type\n  set (u nil: a type parameter without specific types).R2,i447,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,all-basicm10,R35,L1,V2,R41,R64,R0,s118,go/types' allBasic: whether every type of t's type set satisfies pred (a type parameter\n  without specific types: no).R2,i453,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,all-integer?m8,R35,L1,V1,R41,R2,i462,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types13,all-unsigned?m8,R35,L1,V1,R41,R2,i463,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,all-numeric?m8,R35,L1,V1,R41,R2,i464,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,all-string?m8,R35,L1,V1,R41,R2,i465,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,all-boolean?m8,R35,L1,V1,R41,R2,i466,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,all-ordered?m8,R35,L1,V1,R41,R2,i467,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types22,all-numeric-or-string?m8,R35,L1,V1,R41,R2,i468,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,all-float?m8,R35,L1,V1,R41,R2,i469,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,all-complex?m8,R35,L1,V1,R41,R2,i470,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,common-underm10,R35,L2,V1,R41,V2,R41,R65,R0,s220,go/types' commonUnder: [u nil], u the underlying type every type of t's type set shares\n  (channels: the most restricted direction), or [nil cause]; cnd, when given, a function of\n  (t, u) returning a cause to fail with.R2,i472,R3,i1,R4,s24,arbace/go/check/types.ae")

var Lit_84 *jrt.String = jrt.Intern("arbace.go.check.types$eval219000004$loading__1927001464__auto____219000005")

var Lit_85 *jrt.String = jrt.Intern("arbace.go.check.types$eval219000008$fn__219000009")

var Lit_86 *jrt.String = jrt.Intern("arbace.go.check.types$fn__219000012")

var Lit_87 *jrt.String = jrt.Intern("arbace.go.check.types$kw_alias")

var Lit_88 *jrt.String = jrt.Intern("arbace.go.check.types$kw_alias_info")

var Lit_89 *jrt.String = jrt.Intern("arbace.go.check.types$canon_kw")

var Lit_90 *jrt.String = jrt.Intern("arbace.go.check.types$canon_vec")

var Lit_91 *jrt.String = jrt.Intern("arbace.go.check.types$canon")

var Lit_92 *jrt.String = jrt.Intern("arbace.go.check.types$same_QMARK_")

var Lit_93 *jrt.String = jrt.Intern("arbace.go.check.types$next_id")

var Lit_94 *jrt.String = jrt.Intern("arbace.go.check.types$named_QMARK_")

var Lit_95 *jrt.String = jrt.Intern("arbace.go.check.types$tparam_QMARK_")

var Lit_96 *jrt.String = jrt.Intern("arbace.go.check.types$info")

var Lit_97 *jrt.String = jrt.Intern("arbace.go.check.types$update_info_BANG_")

var Lit_98 *jrt.String = jrt.Intern("arbace.go.check.types$new_named")

var Lit_99 *jrt.String = jrt.Intern("arbace.go.check.types$new_tparam")

var Lit_100 *jrt.String = jrt.Intern("arbace.go.check.types$named_under")

var Lit_101 *jrt.String = jrt.Intern("arbace.go.check.types$under")

var Lit_102 *jrt.String = jrt.Intern("arbace.go.check.types$basic")

var Lit_103 *jrt.String = jrt.Intern("arbace.go.check.types$flag")

var Lit_104 *jrt.String = jrt.Intern("arbace.go.check.types$integer_type_QMARK_")

var Lit_105 *jrt.String = jrt.Intern("arbace.go.check.types$unsigned_QMARK_")

var Lit_106 *jrt.String = jrt.Intern("arbace.go.check.types$float_type_QMARK_")

var Lit_107 *jrt.String = jrt.Intern("arbace.go.check.types$complex_type_QMARK_")

var Lit_108 *jrt.String = jrt.Intern("arbace.go.check.types$numeric_QMARK_")

var Lit_109 *jrt.String = jrt.Intern("arbace.go.check.types$string_type_QMARK_")

var Lit_110 *jrt.String = jrt.Intern("arbace.go.check.types$boolean_type_QMARK_")

var Lit_111 *jrt.String = jrt.Intern("arbace.go.check.types$untyped_QMARK_")

var Lit_112 *jrt.String = jrt.Intern("arbace.go.check.types$typed_QMARK_")

var Lit_113 *jrt.String = jrt.Intern("arbace.go.check.types$const_type_QMARK_")

var Lit_114 *jrt.String = jrt.Intern("arbace.go.check.types$ordered_QMARK_")

var Lit_115 *jrt.String = jrt.Intern("arbace.go.check.types$interface_QMARK_")

var Lit_116 *jrt.String = jrt.Intern("arbace.go.check.types$pointer_QMARK_")

var Lit_117 *jrt.String = jrt.Intern("arbace.go.check.types$unsafe_pointer_QMARK_")

var Lit_118 *jrt.String = jrt.Intern("arbace.go.check.types$uintptr_QMARK_")

var Lit_119 *jrt.String = jrt.Intern("arbace.go.check.types$valid_QMARK_")

var Lit_120 *jrt.String = jrt.Intern("arbace.go.check.types$kind_of")

var Lit_121 *jrt.String = jrt.Intern("arbace.go.check.types$has_name_QMARK_")

var Lit_122 *jrt.String = jrt.Intern("arbace.go.check.types$integer_or_float_QMARK_")

var Lit_123 *jrt.String = jrt.Intern("arbace.go.check.types$has_nil_QMARK_")

var Lit_124 *jrt.String = jrt.Intern("arbace.go.check.types$empty_interface_QMARK_")

var Lit_125 *jrt.String = jrt.Intern("arbace.go.check.types$default_type")

var Lit_126 *jrt.String = jrt.Intern("arbace.go.check.types$ignore_tags")

var Lit_127 *jrt.String = jrt.Intern("arbace.go.check.types$identical_ignore_tags_QMARK_")

var Lit_128 *jrt.String = jrt.Intern("arbace.go.check.types$tset_comparable_QMARK_")

var Lit_129 *jrt.String = jrt.Intern("arbace.go.check.types$comparable_type_QMARK_")

var Lit_130 *jrt.String = jrt.Intern("arbace.go.check.types$strictly_comparable_QMARK_")

var Lit_131 *jrt.String = jrt.Intern("arbace.go.check.types$incomparable_cause")

var Lit_132 *jrt.String = jrt.Intern("arbace.go.check.types$comparable_QMARK_")

var Lit_133 *jrt.String = jrt.Intern("arbace.go.check.types$union_QMARK_")

var Lit_134 *jrt.String = jrt.Intern("arbace.go.check.types$term_disjoint_QMARK_")

var Lit_135 *jrt.String = jrt.Intern("arbace.go.check.types$term_union")

var Lit_136 *jrt.String = jrt.Intern("arbace.go.check.types$term_intersect")

var Lit_137 *jrt.String = jrt.Intern("arbace.go.check.types$term_includes_QMARK_")

var Lit_138 *jrt.String = jrt.Intern("arbace.go.check.types$term_subset_QMARK_")

var Lit_139 *jrt.String = jrt.Intern("arbace.go.check.types$terms_norm")

var Lit_140 *jrt.String = jrt.Intern("arbace.go.check.types$ordered")

var Lit_141 *jrt.String = jrt.Intern("arbace.go.check.types$terms_union")

var Lit_142 *jrt.String = jrt.Intern("arbace.go.check.types$terms_intersect")

var Lit_143 *jrt.String = jrt.Intern("arbace.go.check.types$terms_includes_QMARK_")

var Lit_144 *jrt.String = jrt.Intern("arbace.go.check.types$terms_superset_of_QMARK_")

var Lit_145 *jrt.String = jrt.Intern("arbace.go.check.types$terms_subset_QMARK_")

var Lit_146 *jrt.String = jrt.Intern("arbace.go.check.types$make_tset")

var Lit_147 *jrt.String = jrt.Intern("arbace.go.check.types$iface_tset")

var Lit_148 *jrt.String = jrt.Intern("arbace.go.check.types$has_terms_QMARK_")

var Lit_149 *jrt.String = jrt.Intern("arbace.go.check.types$tset_empty_QMARK_")

var Lit_150 *jrt.String = jrt.Intern("arbace.go.check.types$method_set_iface_QMARK_")

var Lit_151 *jrt.String = jrt.Intern("arbace.go.check.types$bound_iface")

var Lit_152 *jrt.String = jrt.Intern("arbace.go.check.types$tparam_iface")

var Lit_153 *jrt.String = jrt.Intern("arbace.go.check.types$tparam_tset")

var Lit_154 *jrt.String = jrt.Intern("arbace.go.check.types$typeset_pairs")

var Lit_155 *jrt.String = jrt.Intern("arbace.go.check.types$typeset_all")

var Lit_156 *jrt.String = jrt.Intern("arbace.go.check.types$under_is")

var Lit_157 *jrt.String = jrt.Intern("arbace.go.check.types$all_basic")

var Lit_158 *jrt.String = jrt.Intern("arbace.go.check.types$all_integer_QMARK_")

var Lit_159 *jrt.String = jrt.Intern("arbace.go.check.types$all_unsigned_QMARK_")

var Lit_160 *jrt.String = jrt.Intern("arbace.go.check.types$all_numeric_QMARK_")

var Lit_161 *jrt.String = jrt.Intern("arbace.go.check.types$all_string_QMARK_")

var Lit_162 *jrt.String = jrt.Intern("arbace.go.check.types$all_boolean_QMARK_")

var Lit_163 *jrt.String = jrt.Intern("arbace.go.check.types$all_ordered_QMARK_")

var Lit_164 *jrt.String = jrt.Intern("arbace.go.check.types$all_numeric_or_string_QMARK_")

var Lit_165 *jrt.String = jrt.Intern("arbace.go.check.types$all_float_QMARK_")

var Lit_166 *jrt.String = jrt.Intern("arbace.go.check.types$all_complex_QMARK_")

var Lit_167 *jrt.String = jrt.Intern("arbace.go.check.types$common_under")

var Lit_168 *jrt.String = jrt.Intern("kn8,arglistsyn1,tkn3,dockn4,linekn6,columnkn4,filekn7,dynamickn8,declaredyn5,termskn7,privateyn2,psyn8,variadicyn1,_yn2,rsyn1,fkn3,tagyn4,longyn6,fieldsyn1,nyn1,pyn4,nameyn3,pkgyn6,Stringyn1,uyn7,entriesyn1,Tyn11,addressableyn2,msyn1,myn1,Vyn6,staticyn5,same?yn1,bv21,arbace.go.check.types9,core-typem10,R0,L1,V1,R1,R2,s51,The common underlying type of t's type set, or nil.R3,i497,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types9,*qualify*m10,R6,TR3,i504,R4,i1,R5,s24,arbace/go/check/types.aeR2,s100,The current package's path: its named types print unqualified, the others by their\n  package's name.m8,R7,TR3,i509,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types9,terms-strm8,R0,L1,V1,R8,R3,i511,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types10,params-strm10,R9,TR0,L1,V2,R10,R11,R3,i517,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types7,sig-strm10,R0,L1,V1,V4,R12,R10,R13,R11,R2,s62,A signature's text without the func keyword: (params) results.R3,i526,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types9,field-strm10,R9,TR0,L1,V1,R14,R3,i535,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types9,named-strm8,R0,L1,V1,R1,R3,i539,R4,i1,R5,s24,arbace/go/check/types.aem10,R0,L1,V1,R1,R2,s20,Go's text of a type.R3,i548,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types9,word-sizel8,m6,R3,i583,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types9,max-alignm6,R3,i584,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types6,sizeofm8,R7,TR3,i586,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types8,align-upm12,R9,TR0,L1,MV2,Myn1,xm2,R15,R16,Myn1,am2,R15,R16,m2,R15,R16,R2,s88,The smallest y >= x with y % a = 0 (a a power of 2): gcSizes' align, overflowing to < 0.R3,i588,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types20,sync-atomic-align64?m10,R0,L1,V1,R1,R2,s101,Whether t is sync/atomic's align64 (or internal/runtime/atomic's), the empty struct gc\n  aligns to 8.R3,i593,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types7,alignofm8,R0,L1,MV1,R1,m2,R15,R16,R3,i602,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types9,offsetsofm10,R0,L1,V1,R17,R2,s119,gcSizes' Offsetsof: the fields' offsets, -1 from a field on whose offset or size is too\n  large (int64 overflow, GR7c).R3,i618,R4,i1,R5,s24,arbace/go/check/types.aem10,R0,L1,MV1,R1,m2,R15,R16,R2,s79,gcSizes' Sizeof: the size of t, -1 when it is too large (int64 overflow, GR7c).R3,i634,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types10,deref-typem10,R0,L1,V1,R1,R2,s72,[base true] for an unnamed pointer type [:pointer base], else [t false].R3,i668,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types10,methods-ofm10,R0,L1,V1,R1,R2,s80,The methods declared on named type t (objects): its declaration completed first.R3,i673,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types11,*fold-case*m10,R6,TR3,i680,R4,i1,R5,s24,arbace/go/check/types.aeR2,s85,go/types' foldCase: names compared without case (and packages ignored), for messages.v21,arbace.go.check.types8,same-id?m10,R0,L1,V4,R18,R19,R20,R21,R2,s114,Whether a field or method named n (in package p when unexported) is the one named name\n  as seen from package pkg.R3,i684,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types9,exported?m8,R0,L1,V1,Myn1,nm2,R15,R22,R3,i696,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types12,*method-obj*m10,R6,TR3,i699,R4,i1,R5,s24,arbace/go/check/types.aeR2,s129,A function from a method object to its data {:name :pkg :type :ptr-recv}, which resolves its\n  declaration; bound by the checker.v21,arbace.go.check.types14,*subst-method*m10,R6,TR3,i704,R4,i1,R5,s24,arbace/go/check/types.aeR2,s135,A function [instance method-obj] -> method data of the instance (type arguments\n  substituted); bound by the checker for generic types.v21,arbace.go.check.types12,named-methodm10,R0,L1,V3,R1,R20,R21,R2,s74,[index method-data] of named type t's method name (seen from pkg), or nil.R3,i709,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types12,iface-methodm10,R0,L1,V3,R23,R20,R21,R2,s73,[index method] of interface type u's method name (seen from pkg), or nil.R3,i721,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types11,consolidatem12,R9,TR0,L1,V1,R24,R2,s76,go/types' consolidateMultiples: entries of one type merged, marked multiple.R3,i732,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types11,lookup-implm10,R0,L1,V4,R25,R26,R20,R21,R2,s352,go/types' lookupFieldOrMethodImpl: {:kind :field|:method|:iface-method, :obj (a field map,\n  a method object or an interface method map), :index [i ...] (the path: field indexes, the\n  last the field's or method's), :via [embedded field names], :indirect}, or {:ambiguous\n  true}, {:ptr-recv true} (a pointer method on a non-addressable value), or nil.R3,i744,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types6,lookupm10,R0,L1,V4,R25,R26,R20,R21,R2,s87,go/types' LookupFieldOrMethod: lookup-impl, but a defined pointer type has fields only.R3,i812,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types12,sort-methodsm10,R0,L1,V1,R27,R2,s83,Interface methods in go/types' order: by name, unexported after package (Id order).R3,i822,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types11,method-datam10,R0,L1,V1,R28,R2,s81,The data of a method object or an interface method: {:name :pkg :type :ptr-recv}.R3,i827,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types14,missing-methodm10,R0,L2,V3,R29,R25,R30,V4,R29,R25,R30,R31,R2,s256,go/types' missingMethod: nil when V implements interface type T (u its underlying), else\n  {:method m :cause kw}: :missing, :ptr-recv (found with a pointer receiver), :wrong-type\n  (with :have), :field (a field of that name), :unexported (other package's).R3,i832,R4,i1,R5,s24,arbace/go/check/types.aev21,arbace.go.check.types15,satisfies-causem10,R0,L1,V2,R29,R32,R2,s122,nil when type V satisfies constraint b (go/types' implements with constraint set), else the\n  cause, as go/types words it.R3,i872,R4,i1,R5,s24,arbace/go/check/types.ae")

var Lit_169 *jrt.String = jrt.Intern("arbace.go.check.types$core_type")

var Lit_170 *jrt.String = jrt.Intern("arbace.go.check.types$terms_str")

var Lit_171 *jrt.String = jrt.Intern("arbace.go.check.types$params_str")

var Lit_172 *jrt.String = jrt.Intern("arbace.go.check.types$sig_str")

var Lit_173 *jrt.String = jrt.Intern("arbace.go.check.types$field_str")

var Lit_174 *jrt.String = jrt.Intern("arbace.go.check.types$named_str")

var Lit_175 *jrt.String = jrt.Intern("arbace.go.check.types$type_str")

var Lit_176 *jrt.String = jrt.Intern("arbace.go.check.types$align_up")

var Lit_177 *jrt.String = jrt.Intern("arbace.go.check.types$sync_atomic_align64_QMARK_")

var Lit_178 *jrt.String = jrt.Intern("arbace.go.check.types$alignof")

var Lit_179 *jrt.String = jrt.Intern("arbace.go.check.types$offsetsof")

var Lit_180 *jrt.String = jrt.Intern("arbace.go.check.types$sizeof")

var Lit_181 *jrt.String = jrt.Intern("arbace.go.check.types$deref_type")

var Lit_182 *jrt.String = jrt.Intern("arbace.go.check.types$methods_of")

var Lit_183 *jrt.String = jrt.Intern("arbace.go.check.types$same_id_QMARK_")

var Lit_184 *jrt.String = jrt.Intern("arbace.go.check.types$exported_QMARK_")

var Lit_185 *jrt.String = jrt.Intern("arbace.go.check.types$named_method")

var Lit_186 *jrt.String = jrt.Intern("arbace.go.check.types$iface_method")

var Lit_187 *jrt.String = jrt.Intern("arbace.go.check.types$consolidate")

var Lit_188 *jrt.String = jrt.Intern("arbace.go.check.types$lookup_impl")

var Lit_189 *jrt.String = jrt.Intern("arbace.go.check.types$lookup")

var Lit_190 *jrt.String = jrt.Intern("arbace.go.check.types$sort_methods")

var Lit_191 *jrt.String = jrt.Intern("arbace.go.check.types$method_data")

var Lit_192 *jrt.String = jrt.Intern("arbace.go.check.types$missing_method")

var Lit_193 *jrt.String = jrt.Intern("arbace.go.check.types$satisfies_cause")
