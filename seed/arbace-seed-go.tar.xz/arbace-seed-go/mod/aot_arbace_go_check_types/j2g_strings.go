//line j2g_strings.ae:1
package aot_arbace_go_check_types

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn21,arbace.go.check.constyn1,cyn11,arbace.corekn3,dockn4,sizekn4,namekn4,boolkn5,bool?kn4,int8kn4,int?kn5,int16kn5,int32kn5,int64kn3,intkn5,uint8kn9,unsigned?kn6,uint16kn6,uint32kn6,uint64kn4,uintkn7,uintptrkn7,float32kn6,float?kn7,float64kn9,complex64kn8,complex?kn10,complex128kn6,stringkn7,string?kn14,unsafe-pointerkn12,untyped-boolkn8,untyped?kn11,untyped-intkn12,untyped-runekn13,untyped-floatkn15,untyped-complexkn14,untyped-stringkn11,untyped-nilkn5,namedkn6,tparamkn2,idkn7,methodskn10,underlyingkn7,invalidkn9,resolvingkn3,objkn4,corekn4,elsekn9,interfacekn7,pointerkn4,chankn4,funckn5,slicekn3,mapkn5,arraykn5,tuplekn6,structkn3,tagkn4,typekn8,embeddedkn3,pkgkn5,localkn8,pkg-namekn5,targskn4,bothkn4,recvkn4,sendkn6,originkn9,multipleskn9,ambiguouskn4,kindkn6,methodkn9,recv-typekn5,indexkn3,viakn8,indirectkn5,fieldkn12,iface-methodkn5,ifacekn8,ptr-recvkn5,foundkn5,causekn7,missingkn10,wrong-typekn4,havev11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,v11,arbace.core5,referR5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn21,arbace.go.check.typesm2,R6,s1099,goi's checker: Go types (doc/go/GOI-SPEC.md §3.3), their predicates, printing, sizes, and\n  the lookup of fields and methods, after go/types (predicates.go, typestring.go, gcsizes.go,\n  lookup.go, methodset.go).\n\n  Basic types are keywords (:int, :untyped-float ...). Composite types are vectors compared by\n  structure: [:pointer T], [:slice T], [:array n T], [:map K V], [:chan dir T] (dir :both,\n  :send, :recv), [:func params results variadic?], [:struct fields] (each field {:name :type\n  :tag :embedded :pkg}, :pkg the package path of an unexported name), [:interface methods\n  terms] (methods the whole method set, embedded interfaces flattened, sorted by name and\n  package: {:name :type :pkg}; terms nil but for constraints), [:tuple T...]. Named types and\n  type parameters are [:named v] and [:tparam v], v a volatile holding their data, so that =\n  is identity on them (a volatile is equal only to itself).\n\n  A named type's volatile holds {:obj the type name's object, :name, :pkg path, :pkg-name,\n  :underlying, :methods [method objects], :origin and :targs for an instance, :tparams}.v11,arbace.core4,intoR7,R8,v11,arbace.core3,mapR9,l1,R10,R11,R12,R13,l2,R14,l4,R15,l8,R16,R17,R18,R19,R20,R21,R22,R23,R24,R25,R26,R27,R28,R29,l16,R30,R31,R32,R33,l0,R34,R35,R36,R37,R38,R39,R40,v21,arbace.go.check.types3,idsv11,arbace.core7,vector?R41,R42,v11,arbace.core7,vreset!v11,arbace.core5,applyv11,arbace.core9,volatile!v11,arbace.core5,assocR43,v21,arbace.go.check.types7,next-idR44,v21,arbace.go.check.types4,infoR45,v21,arbace.go.check.types6,named?v11,arbace.core9,contains?R46,v21,arbace.go.check.types15,*resolve-named*v11,arbace.core3,notR47,R48,v11,arbace.core8,keyword?v21,arbace.go.check.types11,named-underR49,R50,R51,v21,arbace.go.check.types5,underv21,arbace.go.check.types5,basicv21,arbace.go.check.types10,basic-infov21,arbace.go.check.types4,flagv21,arbace.go.check.types13,integer-type?v21,arbace.go.check.types11,float-type?v21,arbace.go.check.types13,complex-type?v21,arbace.go.check.types8,untyped?S3,R46,R40,R32,v21,arbace.go.check.types12,string-type?R52,v11,arbace.core4,not=v21,arbace.go.check.types7,tparam?S6,R53,R51,R54,R52,R55,R56,v11,arbace.core6,empty?R56,R55,R57,R53,v21,arbace.go.check.types11,ignore-tagsR58,V1,R58,v11,arbace.core4,restR54,v11,arbace.core4,mapvR59,R60,R61,v21,arbace.go.check.types11,comparable?v11,arbace.core6,every?v13,arbace.string4,joinv11,arbace.core11,map-indexedv21,arbace.go.check.types8,type-strv21,arbace.go.check.types10,params-strv11,arbace.core5,firstR62,v11,arbace.core6,pr-strv21,arbace.go.check.const10,value-textR63,v21,arbace.go.check.types9,*qualify*R64,R65,v11,arbace.core3,seqR66,v21,arbace.go.check.types11,basic-namesv11,arbace.core4,namev21,arbace.go.check.types9,named-strR67,R68,R69,v21,arbace.go.check.types9,field-strv21,arbace.go.check.types7,sig-strv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consS2,s23,internal/runtime/atomics11,sync/atomicv21,arbace.go.check.types7,alignofv21,arbace.go.check.types20,sync-atomic-align64?v11,arbace.core6,reduceS2,R51,R55,v21,arbace.go.check.types9,word-sizev21,arbace.go.check.types6,sizeofv21,arbace.go.check.types9,max-alignv21,arbace.go.check.types8,align-upv21,arbace.go.check.types9,offsetsofv11,arbace.core4,peekR70,v21,arbace.go.check.types11,*fold-case*v21,arbace.go.check.types10,methods-ofv11,arbace.core4,nextv11,arbace.core8,to-arrayv21,arbace.go.check.types8,same-id?v11,arbace.core8,assoc-inR71,v21,arbace.go.check.types10,deref-typev21,arbace.go.check.types10,interface?v21,arbace.go.check.types12,named-methodv21,arbace.go.check.types12,iface-methodm2,R72,TR73,R74,v11,arbace.core6,secondR75,R76,R77,R78,m2,R72,TR79,m2,R72,TR80,R81,R72,R82,v21,arbace.go.check.types12,*method-obj*R83,v21,arbace.go.check.types11,consolidatev21,arbace.go.check.types8,pointer?v21,arbace.go.check.types11,lookup-implv11,arbace.core3,vecv11,arbace.core7,sort-byv11,arbace.core4,map?v11,arbace.core4,someR84,R85,R86,R87,v21,arbace.go.check.types11,method-datav21,arbace.go.check.types14,*subst-method*")

var Lit_1 *jrt.String = jrt.Intern("arbace.go.check.types$alignof$fn__219000089")

var Lit_2 *jrt.String = jrt.Intern("arbace.go.check.types$comparable_QMARK_$fn__219000060")

var Lit_3 *jrt.String = jrt.Intern("")

var Lit_4 *jrt.String = jrt.Intern(" ")

var Lit_5 *jrt.String = jrt.Intern("arbace.go.check.types$fn__219000012$m__219000013")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.check.types$fn__219000012$m__219000013$fn__219000014")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.check.types$ignore_tags$fn__219000054")

var Lit_8 *jrt.String = jrt.Intern("arbace.go.check.types$lookup_impl$fn__219000112")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.check.types$missing_method$fn__219000126")

var Lit_10 *jrt.String = jrt.Intern(".")

var Lit_11 *jrt.String = jrt.Intern("[")

var Lit_12 *jrt.String = jrt.Intern("]")

var Lit_13 *jrt.String = jrt.Intern(",")

var Lit_14 *jrt.String = jrt.Intern("incrementAndGet")

var Lit_15 *jrt.String = jrt.Intern("(")

var Lit_16 *jrt.String = jrt.Intern(")")

var Lit_17 *jrt.String = jrt.Intern(", ")

var Lit_18 *jrt.String = jrt.Intern("arbace.go.check.types$params_str$fn__219000063")

var Lit_19 *jrt.String = jrt.Intern("...")

var Lit_20 *jrt.String = jrt.Intern(" (")

var Lit_21 *jrt.String = jrt.Intern("arbace.go.check.types$sort_methods$fn__219000122")

var Lit_22 *jrt.String = jrt.Intern("align64")

var Lit_23 *jrt.String = jrt.Intern("map[")

var Lit_24 *jrt.String = jrt.Intern("<-chan ")

var Lit_25 *jrt.String = jrt.Intern("chan ")

var Lit_26 *jrt.String = jrt.Intern("chan<- ")

var Lit_27 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_28 *jrt.String = jrt.Intern("*")

var Lit_29 *jrt.String = jrt.Intern("struct{")

var Lit_30 *jrt.String = jrt.Intern("}")

var Lit_31 *jrt.String = jrt.Intern("; ")

var Lit_32 *jrt.String = jrt.Intern("func")

var Lit_33 *jrt.String = jrt.Intern("interface {}")

var Lit_34 *jrt.String = jrt.Intern("interface {")

var Lit_35 *jrt.String = jrt.Intern("arbace.go.check.types$type_str$iter__219000076__219000080")

var Lit_36 *jrt.String = jrt.Intern("[]")

var Lit_37 *jrt.String = jrt.Intern("arbace.go.check.types$type_str$iter__219000076__219000080$fn__219000081")

var Lit_38 *jrt.String = jrt.Intern("arbace.go.check.types$type_str$iter__219000076__219000080$fn__219000081$fn__219000082")

var Lit_39 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn4,boolkn4,int8kn5,int16kn5,int32kn5,int64kn3,intkn5,uint8kn6,uint16kn6,uint32kn6,uint64kn4,uintkn7,uintptrkn7,float32kn7,float64kn9,complex64kn10,complex128kn6,stringkn14,unsafe-pointerkn12,untyped-boolkn11,untyped-intkn12,untyped-runekn13,untyped-floatkn15,untyped-complexkn14,untyped-stringkn11,untyped-nilkn7,invalidkn7,privatekn8,arglistskn3,tagyn4,longyn1,tyn1,fyn1,&yn4,argsyn4,datakn7,dynamickn8,declaredyn1,xyn1,yyn4,seenyn2,psyn8,variadicyn1,_yn2,rsyn6,fieldsyn1,nyn1,pyn4,nameyn3,pkgyn6,Stringyn1,uyn7,entriesyn1,Tyn11,addressableyn2,msyn1,myn1,Vyn6,staticv11,arbace.core5,in-nsMyn21,arbace.go.check.typesm2,R0,s1099,goi's checker: Go types (doc/go/GOI-SPEC.md §3.3), their predicates, printing, sizes, and\n  the lookup of fields and methods, after go/types (predicates.go, typestring.go, gcsizes.go,\n  lookup.go, methodset.go).\n\n  Basic types are keywords (:int, :untyped-float ...). Composite types are vectors compared by\n  structure: [:pointer T], [:slice T], [:array n T], [:map K V], [:chan dir T] (dir :both,\n  :send, :recv), [:func params results variadic?], [:struct fields] (each field {:name :type\n  :tag :embedded :pkg}, :pkg the package path of an unexported name), [:interface methods\n  terms] (methods the whole method set, embedded interfaces flattened, sorted by name and\n  package: {:name :type :pkg}; terms nil but for constraints), [:tuple T...]. Named types and\n  type parameters are [:named v] and [:tparam v], v a volatile holding their data, so that =\n  is identity on them (a volatile is equal only to itself).\n\n  A named type's volatile holds {:obj the type name's object, :name, :pkg path, :pkg-name,\n  :underlying, :methods [method objects], :origin and :targs for an instance, :tparams}.m2,R0,s1099,goi's checker: Go types (doc/go/GOI-SPEC.md §3.3), their predicates, printing, sizes, and\n  the lookup of fields and methods, after go/types (predicates.go, typestring.go, gcsizes.go,\n  lookup.go, methodset.go).\n\n  Basic types are keywords (:int, :untyped-float ...). Composite types are vectors compared by\n  structure: [:pointer T], [:slice T], [:array n T], [:map K V], [:chan dir T] (dir :both,\n  :send, :recv), [:func params results variadic?], [:struct fields] (each field {:name :type\n  :tag :embedded :pkg}, :pkg the package path of an unexported name), [:interface methods\n  terms] (methods the whole method set, embedded interfaces flattened, sorted by name and\n  package: {:name :type :pkg}; terms nil but for constraints), [:tuple T...]. Named types and\n  type parameters are [:named v] and [:tparam v], v a volatile holding their data, so that =\n  is identity on them (a volatile is equal only to itself).\n\n  A named type's volatile holds {:obj the type name's object, :name, :pkg path, :pkg-name,\n  :underlying, :methods [method objects], :origin and :targs for an instance, :tparams}.R1,v21,arbace.go.check.types10,basic-infom8,R2,i22,R3,i1,R4,s24,arbace/go/check/types.aeR0,s81,{kind {:size :int? :unsigned? :float? :complex? :string? :bool? :untyped? :name}}v21,arbace.go.check.types11,basic-namesm52,R5,s4,boolR6,s4,int8R7,s5,int16R8,s5,int32R9,s5,int64R10,s3,intR11,s5,uint8R12,s6,uint16R13,s6,uint32R14,s6,uint64R15,s4,uintR16,s7,uintptrR17,s7,float32R18,s7,float64R19,s9,complex64R20,s10,complex128R21,s6,stringR22,s14,unsafe.PointerR23,s12,untyped boolR24,s11,untyped intR25,s12,untyped runeR26,s13,untyped floatR27,s15,untyped complexR28,s14,untyped stringR29,s11,untyped nilR30,s12,invalid typem6,R2,i39,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types3,idsm8,R31,TR2,i50,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types7,next-idm8,R32,L1,MV0,m2,R33,R34,R2,i51,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types6,named?m8,R32,L1,V1,R35,R2,i53,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types7,tparam?m8,R32,L1,V1,R35,R2,i54,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types4,infom8,R32,L1,V1,R35,R2,i55,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,update-info!m8,R32,L1,V4,R35,R36,R37,R38,R2,i56,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,new-namedm10,R32,L1,V1,R39,R0,s84,A new named type: data {:obj :name :pkg :pkg-name ...}; its underlying is set later.R2,i58,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,new-tparamm8,R32,L1,V1,R39,R2,i63,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types15,*resolve-named*m10,R40,TR2,i65,R3,i1,R4,s24,arbace/go/check/types.aeR0,s159,A function called with a named type whose underlying type is not known yet (its declaration\n  not checked), which checks its declaration; bound by the checker.v21,arbace.go.check.types5,underm8,R41,TR2,i70,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,named-underm10,R31,TR32,L1,V1,R35,R2,i72,R3,i1,R4,s24,arbace/go/check/types.aem10,R32,L1,V1,R35,R0,s25,The underlying type of t.R2,i87,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types5,basicm8,R32,L1,V1,R35,R2,i98,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types4,flagm10,R31,TR32,L1,V2,R35,R36,R2,i99,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types13,integer-type?m8,R32,L1,V1,R35,R2,i100,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,unsigned?m8,R32,L1,V1,R35,R2,i101,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,float-type?m8,R32,L1,V1,R35,R2,i102,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types13,complex-type?m8,R32,L1,V1,R35,R2,i103,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,numeric?m8,R32,L1,V1,R35,R2,i104,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,string-type?m8,R32,L1,V1,R35,R2,i105,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types13,boolean-type?m8,R32,L1,V1,R35,R2,i106,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,untyped?m8,R32,L1,V1,R35,R2,i107,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types6,typed?m8,R32,L1,V1,R35,R2,i108,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,const-type?m10,R32,L1,V1,R35,R0,s68,Whether values of t can be constants: booleans, numbers and strings.R2,i109,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,ordered?m8,R32,L1,V1,R35,R2,i113,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,interface?m8,R32,L1,V1,R35,R2,i114,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,pointer?m8,R32,L1,V1,R35,R2,i115,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types15,unsafe-pointer?m8,R32,L1,V1,R35,R2,i116,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,uintptr?m8,R32,L1,V1,R35,R2,i117,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types6,valid?m8,R32,L1,V1,R35,R2,i118,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types7,kind-ofm8,R32,L1,V1,R35,R2,i119,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,has-name?m8,R32,L1,V1,R35,R2,i120,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types17,integer-or-float?m8,R32,L1,V1,R35,R2,i121,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,has-nil?m10,R32,L1,V1,R35,R0,s102,Whether t's values include nil: pointers, slices, maps, channels, funcs, interfaces,\n  unsafe.Pointer.R2,i123,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types16,empty-interface?m8,R32,L1,V1,R35,R2,i131,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,default-typem10,R32,L1,V1,R35,R0,s51,The default type of an untyped type (Go's Default).R2,i134,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,ignore-tagsm10,R32,L1,V1,R35,R0,s78,t with the tags of its struct types dropped, deeply (for IdenticalIgnoreTags).R2,i142,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types22,identical-ignore-tags?m8,R32,L1,V2,R42,R43,R2,i158,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,comparable?m8,R41,TR2,i160,R3,i1,R4,s24,arbace/go/check/types.aem10,R32,L2,V1,R35,V2,R35,R44,R0,s78,Go's Comparable: whether values of t can be compared with == (interfaces are).R2,i162,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,*qualify*m10,R40,TR2,i180,R3,i1,R4,s24,arbace/go/check/types.aeR0,s100,The current package's path: its named types print unqualified, the others by their\n  package's name.v21,arbace.go.check.types8,type-strm8,R41,TR2,i185,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,params-strm10,R31,TR32,L1,V2,R45,R46,R2,i187,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types7,sig-strm10,R32,L1,V1,V4,R47,R45,R48,R46,R0,s62,A signature's text without the func keyword: (params) results.R2,i196,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,field-strm10,R31,TR32,L1,V1,R36,R2,i205,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,named-strm8,R32,L1,V1,R35,R2,i209,R3,i1,R4,s24,arbace/go/check/types.aem10,R32,L1,V1,R35,R0,s20,Go's text of a type.R2,i218,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,word-sizel8,m6,R2,i247,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,max-alignm6,R2,i248,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types6,sizeofm8,R41,TR2,i250,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,align-upm10,R31,TR32,L1,MV2,Myn1,xm2,R33,R34,Myn1,am2,R33,R34,m2,R33,R34,R2,i252,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types20,sync-atomic-align64?m10,R32,L1,V1,R35,R0,s101,Whether t is sync/atomic's align64 (or internal/runtime/atomic's), the empty struct gc\n  aligns to 8.R2,i254,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types7,alignofm8,R32,L1,MV1,R35,m2,R33,R34,R2,i263,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,offsetsofm8,R32,L1,V1,R49,R2,i279,R3,i1,R4,s24,arbace/go/check/types.aem8,R32,L1,MV1,R35,m2,R33,R34,R2,i287,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,deref-typem10,R32,L1,V1,R35,R0,s72,[base true] for an unnamed pointer type [:pointer base], else [t false].R2,i309,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,methods-ofm10,R32,L1,V1,R35,R0,s80,The methods declared on named type t (objects): its declaration completed first.R2,i314,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,*fold-case*m10,R40,TR2,i321,R3,i1,R4,s24,arbace/go/check/types.aeR0,s85,go/types' foldCase: names compared without case (and packages ignored), for messages.v21,arbace.go.check.types8,same-id?m10,R32,L1,V4,R50,R51,R52,R53,R0,s114,Whether a field or method named n (in package p when unexported) is the one named name\n  as seen from package pkg.R2,i325,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,exported?m8,R32,L1,V1,Myn1,nm2,R33,R54,R2,i337,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,*method-obj*m10,R40,TR2,i340,R3,i1,R4,s24,arbace/go/check/types.aeR0,s129,A function from a method object to its data {:name :pkg :type :ptr-recv}, which resolves its\n  declaration; bound by the checker.v21,arbace.go.check.types14,*subst-method*m10,R40,TR2,i345,R3,i1,R4,s24,arbace/go/check/types.aeR0,s135,A function [instance method-obj] -> method data of the instance (type arguments\n  substituted); bound by the checker for generic types.v21,arbace.go.check.types12,named-methodm10,R32,L1,V3,R35,R52,R53,R0,s74,[index method-data] of named type t's method name (seen from pkg), or nil.R2,i350,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,iface-methodm10,R32,L1,V3,R55,R52,R53,R0,s73,[index method] of interface type u's method name (seen from pkg), or nil.R2,i362,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,consolidatem12,R31,TR32,L1,V1,R56,R0,s76,go/types' consolidateMultiples: entries of one type merged, marked multiple.R2,i373,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,lookup-implm10,R32,L1,V4,R57,R58,R52,R53,R0,s352,go/types' lookupFieldOrMethodImpl: {:kind :field|:method|:iface-method, :obj (a field map,\n  a method object or an interface method map), :index [i ...] (the path: field indexes, the\n  last the field's or method's), :via [embedded field names], :indirect}, or {:ambiguous\n  true}, {:ptr-recv true} (a pointer method on a non-addressable value), or nil.R2,i385,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types6,lookupm10,R32,L1,V4,R57,R58,R52,R53,R0,s87,go/types' LookupFieldOrMethod: lookup-impl, but a defined pointer type has fields only.R2,i453,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,sort-methodsm10,R32,L1,V1,R59,R0,s83,Interface methods in go/types' order: by name, unexported after package (Id order).R2,i463,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,method-datam10,R32,L1,V1,R60,R0,s81,The data of a method object or an interface method: {:name :pkg :type :ptr-recv}.R2,i468,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types14,missing-methodm10,R32,L1,V3,R61,R57,R62,R0,s256,go/types' missingMethod: nil when V implements interface type T (u its underlying), else\n  {:method m :cause kw}: :missing, :ptr-recv (found with a pointer receiver), :wrong-type\n  (with :have), :field (a field of that name), :unexported (other package's).R2,i473,R3,i1,R4,s24,arbace/go/check/types.ae")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.check.types$eval219000004$loading__1927001464__auto____219000005")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.check.types$eval219000008$fn__219000009")

var Lit_42 *jrt.String = jrt.Intern("arbace.go.check.types$fn__219000012")

var Lit_43 *jrt.String = jrt.Intern("arbace.go.check.types$next_id")

var Lit_44 *jrt.String = jrt.Intern("arbace.go.check.types$named_QMARK_")

var Lit_45 *jrt.String = jrt.Intern("arbace.go.check.types$tparam_QMARK_")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.check.types$info")

var Lit_47 *jrt.String = jrt.Intern("arbace.go.check.types$update_info_BANG_")

var Lit_48 *jrt.String = jrt.Intern("arbace.go.check.types$new_named")

var Lit_49 *jrt.String = jrt.Intern("arbace.go.check.types$new_tparam")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.check.types$named_under")

var Lit_51 *jrt.String = jrt.Intern("arbace.go.check.types$under")

var Lit_52 *jrt.String = jrt.Intern("arbace.go.check.types$basic")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.check.types$flag")

var Lit_54 *jrt.String = jrt.Intern("arbace.go.check.types$integer_type_QMARK_")

var Lit_55 *jrt.String = jrt.Intern("arbace.go.check.types$unsigned_QMARK_")

var Lit_56 *jrt.String = jrt.Intern("arbace.go.check.types$float_type_QMARK_")

var Lit_57 *jrt.String = jrt.Intern("arbace.go.check.types$complex_type_QMARK_")

var Lit_58 *jrt.String = jrt.Intern("arbace.go.check.types$numeric_QMARK_")

var Lit_59 *jrt.String = jrt.Intern("arbace.go.check.types$string_type_QMARK_")

var Lit_60 *jrt.String = jrt.Intern("arbace.go.check.types$boolean_type_QMARK_")

var Lit_61 *jrt.String = jrt.Intern("arbace.go.check.types$untyped_QMARK_")

var Lit_62 *jrt.String = jrt.Intern("arbace.go.check.types$typed_QMARK_")

var Lit_63 *jrt.String = jrt.Intern("arbace.go.check.types$const_type_QMARK_")

var Lit_64 *jrt.String = jrt.Intern("arbace.go.check.types$ordered_QMARK_")

var Lit_65 *jrt.String = jrt.Intern("arbace.go.check.types$interface_QMARK_")

var Lit_66 *jrt.String = jrt.Intern("arbace.go.check.types$pointer_QMARK_")

var Lit_67 *jrt.String = jrt.Intern("arbace.go.check.types$unsafe_pointer_QMARK_")

var Lit_68 *jrt.String = jrt.Intern("arbace.go.check.types$uintptr_QMARK_")

var Lit_69 *jrt.String = jrt.Intern("arbace.go.check.types$valid_QMARK_")

var Lit_70 *jrt.String = jrt.Intern("arbace.go.check.types$kind_of")

var Lit_71 *jrt.String = jrt.Intern("arbace.go.check.types$has_name_QMARK_")

var Lit_72 *jrt.String = jrt.Intern("arbace.go.check.types$integer_or_float_QMARK_")

var Lit_73 *jrt.String = jrt.Intern("arbace.go.check.types$has_nil_QMARK_")

var Lit_74 *jrt.String = jrt.Intern("arbace.go.check.types$empty_interface_QMARK_")

var Lit_75 *jrt.String = jrt.Intern("arbace.go.check.types$default_type")

var Lit_76 *jrt.String = jrt.Intern("arbace.go.check.types$ignore_tags")

var Lit_77 *jrt.String = jrt.Intern("arbace.go.check.types$identical_ignore_tags_QMARK_")

var Lit_78 *jrt.String = jrt.Intern("arbace.go.check.types$comparable_QMARK_")

var Lit_79 *jrt.String = jrt.Intern("arbace.go.check.types$params_str")

var Lit_80 *jrt.String = jrt.Intern("arbace.go.check.types$sig_str")

var Lit_81 *jrt.String = jrt.Intern("arbace.go.check.types$field_str")

var Lit_82 *jrt.String = jrt.Intern("arbace.go.check.types$named_str")

var Lit_83 *jrt.String = jrt.Intern("arbace.go.check.types$type_str")

var Lit_84 *jrt.String = jrt.Intern("arbace.go.check.types$align_up")

var Lit_85 *jrt.String = jrt.Intern("arbace.go.check.types$sync_atomic_align64_QMARK_")

var Lit_86 *jrt.String = jrt.Intern("arbace.go.check.types$alignof")

var Lit_87 *jrt.String = jrt.Intern("arbace.go.check.types$offsetsof")

var Lit_88 *jrt.String = jrt.Intern("arbace.go.check.types$sizeof")

var Lit_89 *jrt.String = jrt.Intern("arbace.go.check.types$deref_type")

var Lit_90 *jrt.String = jrt.Intern("arbace.go.check.types$methods_of")

var Lit_91 *jrt.String = jrt.Intern("arbace.go.check.types$same_id_QMARK_")

var Lit_92 *jrt.String = jrt.Intern("arbace.go.check.types$exported_QMARK_")

var Lit_93 *jrt.String = jrt.Intern("arbace.go.check.types$named_method")

var Lit_94 *jrt.String = jrt.Intern("arbace.go.check.types$iface_method")

var Lit_95 *jrt.String = jrt.Intern("arbace.go.check.types$consolidate")

var Lit_96 *jrt.String = jrt.Intern("arbace.go.check.types$lookup_impl")

var Lit_97 *jrt.String = jrt.Intern("arbace.go.check.types$lookup")

var Lit_98 *jrt.String = jrt.Intern("arbace.go.check.types$sort_methods")

var Lit_99 *jrt.String = jrt.Intern("arbace.go.check.types$method_data")

var Lit_100 *jrt.String = jrt.Intern("arbace.go.check.types$missing_method")
