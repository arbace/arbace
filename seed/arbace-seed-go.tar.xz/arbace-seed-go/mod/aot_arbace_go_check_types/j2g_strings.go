//line j2g_strings.ae:1
package aot_arbace_go_check_types

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn21,arbace.go.check.constyn1,cyn11,arbace.corekn3,dockn4,sizekn4,namekn4,boolkn5,bool?kn4,int8kn4,int?kn5,int16kn5,int32kn5,int64kn3,intkn5,uint8kn9,unsigned?kn6,uint16kn6,uint32kn6,uint64kn4,uintkn7,uintptrkn7,float32kn6,float?kn7,float64kn9,complex64kn8,complex?kn10,complex128kn6,stringkn7,string?kn14,unsafe-pointerkn12,untyped-boolkn8,untyped?kn11,untyped-intkn12,untyped-runekn13,untyped-floatkn15,untyped-complexkn14,untyped-stringkn11,untyped-nilkn5,namedkn6,tparamkn2,idkn7,methodskn10,underlyingkn7,invalidkn9,resolvingkn3,objkn4,elsekn9,interfacekn7,pointerkn4,chankn4,funckn5,slicekn3,mapkn5,arraykn5,tuplekn6,structkn3,tagkn4,typekn3,allkn5,termskn10,comparablekn5,unionkn5,orderkn5,ifacekn5,boundkn4,bothkn8,embeddedkn3,pkgkn5,localkn8,pkg-namekn5,targskn4,recvkn4,sendkn6,originkn9,multipleskn9,ambiguouskn4,kindkn6,methodkn9,recv-typekn5,indexkn3,viakn8,indirectkn5,fieldkn12,iface-methodkn8,ptr-recvkn5,foundkn5,causekn7,missingkn10,wrong-typekn4,havekn7,tparamsv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,v11,arbace.core5,referR5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn21,arbace.go.check.typesm2,R6,s1099,goi's checker: Go types (doc/go/GOI-SPEC.md §3.3), their predicates, printing, sizes, and\n  the lookup of fields and methods, after go/types (predicates.go, typestring.go, gcsizes.go,\n  lookup.go, methodset.go).\n\n  Basic types are keywords (:int, :untyped-float ...). Composite types are vectors compared by\n  structure: [:pointer T], [:slice T], [:array n T], [:map K V], [:chan dir T] (dir :both,\n  :send, :recv), [:func params results variadic?], [:struct fields] (each field {:name :type\n  :tag :embedded :pkg}, :pkg the package path of an unexported name), [:interface methods\n  terms] (methods the whole method set, embedded interfaces flattened, sorted by name and\n  package: {:name :type :pkg}; terms nil but for constraints), [:tuple T...]. Named types and\n  type parameters are [:named v] and [:tparam v], v a volatile holding their data, so that =\n  is identity on them (a volatile is equal only to itself).\n\n  A named type's volatile holds {:obj the type name's object, :name, :pkg path, :pkg-name,\n  :underlying, :methods [method objects], :origin and :targs for an instance, :tparams}.v11,arbace.core4,intoR7,R8,v11,arbace.core3,mapR9,l1,R10,R11,R12,R13,l2,R14,l4,R15,l8,R16,R17,R18,R19,R20,R21,R22,R23,R24,R25,R26,R27,R28,R29,l16,R30,R31,R32,R33,l0,R34,R35,R36,R37,R38,R39,R40,v21,arbace.go.check.types3,idsv11,arbace.core7,vector?R41,R42,v11,arbace.core7,vreset!v11,arbace.core5,applyv11,arbace.core9,volatile!v11,arbace.core5,assocR43,v21,arbace.go.check.types7,next-idR44,v21,arbace.go.check.types4,infoR45,v21,arbace.go.check.types6,named?v11,arbace.core9,contains?R46,v21,arbace.go.check.types15,*resolve-named*v11,arbace.core3,notR47,R48,v11,arbace.core8,keyword?v21,arbace.go.check.types11,named-underv21,arbace.go.check.types12,tparam-ifaceR49,v21,arbace.go.check.types5,underv21,arbace.go.check.types5,basicv21,arbace.go.check.types10,basic-infov21,arbace.go.check.types4,flagv21,arbace.go.check.types13,integer-type?v21,arbace.go.check.types11,float-type?v21,arbace.go.check.types13,complex-type?v21,arbace.go.check.types8,untyped?S3,R46,R40,R32,v21,arbace.go.check.types12,string-type?R50,R51,v11,arbace.core4,not=v21,arbace.go.check.types7,tparam?v21,arbace.go.check.types8,under-isv11,arbace.core5,some?v21,arbace.go.check.types8,has-nil?S6,R52,R50,R53,R51,R54,R55,v11,arbace.core6,empty?R55,R54,R56,R52,v21,arbace.go.check.types11,ignore-tagsR57,V1,R57,v11,arbace.core4,restR53,v11,arbace.core4,mapvR58,R59,R60,R61,R62,R63,v11,arbace.core3,seqv11,arbace.core6,every?v21,arbace.go.check.types20,strictly-comparable?v21,arbace.go.check.types16,tset-comparable?v21,arbace.go.check.types11,tparam-tsetv21,arbace.go.check.types16,comparable-type?v21,arbace.go.check.types10,iface-tsetv21,arbace.go.check.types8,type-strv11,arbace.core4,someR64,v21,arbace.go.check.types14,term-disjoint?v11,arbace.core5,firstv11,arbace.core3,vecv11,arbace.core9,with-metav11,arbace.core3,setR65,v21,arbace.go.check.types10,term-unionv21,arbace.go.check.types10,terms-normv11,arbace.core6,concatv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv21,arbace.go.check.types14,term-intersectv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv21,arbace.go.check.types14,term-includes?v21,arbace.go.check.types12,term-subset?v21,arbace.go.check.types18,terms-superset-of?v11,arbace.core4,map?v21,arbace.go.check.types6,union?v21,arbace.go.check.types9,make-tsetR66,v21,arbace.go.check.types11,bound-ifaceR67,v21,arbace.go.check.types12,update-info!v21,arbace.go.check.types10,has-terms?V1,V2,nnv21,arbace.go.check.types13,typeset-pairsv21,arbace.go.check.types11,typeset-allv21,arbace.go.check.types9,all-basicv21,arbace.go.check.types9,unsigned?v21,arbace.go.check.types8,numeric?v21,arbace.go.check.types13,boolean-type?v21,arbace.go.check.types8,ordered?V2,ns16,no specific typeR68,V2,ns30,conflicting channel directionsV2,ns26,different underlying typesv11,arbace.core6,pr-strv21,arbace.go.check.types12,common-underv11,arbace.core7,sort-byv13,arbace.string4,joinv11,arbace.core11,map-indexedv21,arbace.go.check.types10,params-strR69,v21,arbace.go.check.const10,value-textR70,v21,arbace.go.check.types9,*qualify*R71,R72,R73,v21,arbace.go.check.types11,basic-namesv11,arbace.core4,namev21,arbace.go.check.types9,named-strV1,s10,comparablev21,arbace.go.check.types7,sig-strv21,arbace.go.check.types9,terms-strR74,R75,v21,arbace.go.check.types9,field-strS2,s23,internal/runtime/atomics11,sync/atomicv21,arbace.go.check.types7,alignofv21,arbace.go.check.types20,sync-atomic-align64?v11,arbace.core6,reduceS2,R50,R54,v21,arbace.go.check.types9,word-sizev21,arbace.go.check.types6,sizeofv21,arbace.go.check.types9,max-alignv21,arbace.go.check.types8,align-upv21,arbace.go.check.types9,offsetsofv11,arbace.core4,peekR76,v21,arbace.go.check.types11,*fold-case*v21,arbace.go.check.types10,methods-ofv11,arbace.core4,nextv11,arbace.core8,to-arrayv21,arbace.go.check.types8,same-id?v11,arbace.core8,assoc-inR77,v21,arbace.go.check.types10,deref-typev21,arbace.go.check.types10,interface?v21,arbace.go.check.types12,named-methodv21,arbace.go.check.types12,iface-methodm2,R78,TR79,R80,v11,arbace.core6,secondR81,R82,R83,R84,m2,R78,TR85,m2,R78,TR86,R78,R87,v21,arbace.go.check.types12,*method-obj*R88,v21,arbace.go.check.types11,consolidatev21,arbace.go.check.types8,pointer?v21,arbace.go.check.types11,lookup-implR89,R90,R91,R92,v21,arbace.go.check.types11,method-datav21,arbace.go.check.types14,*subst-method*R93,v21,arbace.go.check.types14,missing-methodv11,arbace.core1,=v21,arbace.go.check.types11,tset-empty?v21,arbace.go.check.types11,comparable?v21,arbace.go.check.types13,terms-subset?v21,arbace.go.check.types15,terms-includes?")

var Lit_1 *jrt.String = jrt.Intern("arbace.go.check.types$alignof$fn__219000233")

var Lit_2 *jrt.String = jrt.Intern("arbace.go.check.types$all_basic$fn__219000167")

var Lit_3 *jrt.String = jrt.Intern("arbace.go.check.types$all_numeric_or_string_QMARK_$fn__219000180")

var Lit_4 *jrt.String = jrt.Intern("channels ")

var Lit_5 *jrt.String = jrt.Intern(" and ")

var Lit_6 *jrt.String = jrt.Intern(" have different element types")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.check.types$comparable_type_QMARK_$fn__219000069")

var Lit_8 *jrt.String = jrt.Intern("")

var Lit_9 *jrt.String = jrt.Intern(" ")

var Lit_10 *jrt.String = jrt.Intern("arbace.go.check.types$fn__219000012$m__219000013")

var Lit_11 *jrt.String = jrt.Intern("arbace.go.check.types$fn__219000012$m__219000013$fn__219000014")

var Lit_12 *jrt.String = jrt.Intern("arbace.go.check.types$has_nil_QMARK_$fn__219000048")

var Lit_13 *jrt.String = jrt.Intern("arbace.go.check.types$ignore_tags$fn__219000056")

var Lit_14 *jrt.String = jrt.Intern("arbace.go.check.types$incomparable_cause$cause__219000073")

var Lit_15 *jrt.String = jrt.Intern(" cannot be compared")

var Lit_16 *jrt.String = jrt.Intern("arbace.go.check.types$incomparable_cause$cause__219000073$fn__219000075")

var Lit_17 *jrt.String = jrt.Intern("struct containing ")

var Lit_18 *jrt.String = jrt.Intern("arbace.go.check.types$lookup_impl$fn__219000256")

var Lit_19 *jrt.String = jrt.Intern("arbace.go.check.types$missing_method$fn__219000270")

var Lit_20 *jrt.String = jrt.Intern(".")

var Lit_21 *jrt.String = jrt.Intern("[")

var Lit_22 *jrt.String = jrt.Intern("]")

var Lit_23 *jrt.String = jrt.Intern(",")

var Lit_24 *jrt.String = jrt.Intern("incrementAndGet")

var Lit_25 *jrt.String = jrt.Intern("(")

var Lit_26 *jrt.String = jrt.Intern(")")

var Lit_27 *jrt.String = jrt.Intern(", ")

var Lit_28 *jrt.String = jrt.Intern("arbace.go.check.types$params_str$fn__219000207")

var Lit_29 *jrt.String = jrt.Intern("...")

var Lit_30 *jrt.String = jrt.Intern("cannot satisfy ")

var Lit_31 *jrt.String = jrt.Intern(" (empty type set)")

var Lit_32 *jrt.String = jrt.Intern(" does not satisfy ")

var Lit_33 *jrt.String = jrt.Intern(" (missing method ")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.check.types$satisfies_cause$comparability__219000273")

var Lit_35 *jrt.String = jrt.Intern("arbace.go.check.types$satisfies_cause$comparability__219000273$fn__219000275")

var Lit_36 *jrt.String = jrt.Intern(" does not satisfy comparable")

var Lit_37 *jrt.String = jrt.Intern(" (")

var Lit_38 *jrt.String = jrt.Intern("arbace.go.check.types$sort_methods$fn__219000266")

var Lit_39 *jrt.String = jrt.Intern("align64")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.check.types$terms_includes_QMARK_$fn__219000120")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.check.types$terms_intersect$iter__219000102__219000108")

var Lit_42 *jrt.String = jrt.Intern("arbace.go.check.types$terms_intersect$iter__219000102__219000108$fn__219000109")

var Lit_43 *jrt.String = jrt.Intern("arbace.go.check.types$terms_intersect$iter__219000102__219000108$fn__219000109$iter__219000104__219000110")

var Lit_44 *jrt.String = jrt.Intern("arbace.go.check.types$terms_intersect$iter__219000102__219000108$fn__219000109$iter__219000104__219000110$fn__219000111")

var Lit_45 *jrt.String = jrt.Intern("arbace.go.check.types$terms_intersect$iter__219000102__219000108$fn__219000109$iter__219000104__219000110$fn__219000111$fn__219000112")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.check.types$terms_norm$fn__219000098")

var Lit_47 *jrt.String = jrt.Intern("∅")

var Lit_48 *jrt.String = jrt.Intern(" | ")

var Lit_49 *jrt.String = jrt.Intern("arbace.go.check.types$terms_str$iter__219000190__219000194")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.check.types$terms_str$iter__219000190__219000194$fn__219000195")

var Lit_51 *jrt.String = jrt.Intern("arbace.go.check.types$terms_str$iter__219000190__219000194$fn__219000195$fn__219000196")

var Lit_52 *jrt.String = jrt.Intern("~")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.check.types$terms_subset_QMARK_$fn__219000128")

var Lit_54 *jrt.String = jrt.Intern("arbace.go.check.types$terms_superset_of_QMARK_$fn__219000124")

var Lit_55 *jrt.String = jrt.Intern("arbace.go.check.types$tset_comparable_QMARK_$fn__219000061")

var Lit_56 *jrt.String = jrt.Intern("interface {}")

var Lit_57 *jrt.String = jrt.Intern("interface {")

var Lit_58 *jrt.String = jrt.Intern("}")

var Lit_59 *jrt.String = jrt.Intern("; ")

var Lit_60 *jrt.String = jrt.Intern("arbace.go.check.types$type_str$iter__219000219__219000223")

var Lit_61 *jrt.String = jrt.Intern("*")

var Lit_62 *jrt.String = jrt.Intern("map[")

var Lit_63 *jrt.String = jrt.Intern("[]")

var Lit_64 *jrt.String = jrt.Intern("<-chan ")

var Lit_65 *jrt.String = jrt.Intern("chan ")

var Lit_66 *jrt.String = jrt.Intern("chan<- ")

var Lit_67 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_68 *jrt.String = jrt.Intern("func")

var Lit_69 *jrt.String = jrt.Intern("struct{")

var Lit_70 *jrt.String = jrt.Intern("arbace.go.check.types$type_str$iter__219000219__219000223$fn__219000224")

var Lit_71 *jrt.String = jrt.Intern("arbace.go.check.types$type_str$iter__219000219__219000223$fn__219000224$fn__219000225")

var Lit_72 *jrt.String = jrt.Intern("arbace.go.check.types$typeset_all$fn__219000157")

var Lit_73 *jrt.String = jrt.Intern("arbace.go.check.types$typeset_pairs$iter__219000139__219000143")

var Lit_74 *jrt.String = jrt.Intern("arbace.go.check.types$typeset_pairs$iter__219000139__219000143$fn__219000144")

var Lit_75 *jrt.String = jrt.Intern("arbace.go.check.types$typeset_pairs$iter__219000139__219000143$fn__219000144$fn__219000145")

var Lit_76 *jrt.String = jrt.Intern("arbace.go.check.types$under_is$fn__219000163")

var Lit_77 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn4,boolkn4,int8kn5,int16kn5,int32kn5,int64kn3,intkn5,uint8kn6,uint16kn6,uint32kn6,uint64kn4,uintkn7,uintptrkn7,float32kn7,float64kn9,complex64kn10,complex128kn6,stringkn14,unsafe-pointerkn12,untyped-boolkn11,untyped-intkn12,untyped-runekn13,untyped-floatkn15,untyped-complexkn14,untyped-stringkn11,untyped-nilkn7,invalidkn7,privatekn8,arglistskn3,tagyn4,longyn1,tyn1,fyn1,&yn4,argsyn4,datakn7,dynamickn8,declaredyn1,xyn1,yyn2,tsyn4,seenyn7,dynamicyn2,xtyn2,ytyn5,tildeyn2,tyyn2,xlyn2,ylyn5,termsyn10,comparableyn1,uyn1,byn2,tpyn4,predyn3,cndyn2,psyn8,variadicyn1,_yn2,rsv11,arbace.core5,in-nsMyn21,arbace.go.check.typesm2,R0,s1099,goi's checker: Go types (doc/go/GOI-SPEC.md §3.3), their predicates, printing, sizes, and\n  the lookup of fields and methods, after go/types (predicates.go, typestring.go, gcsizes.go,\n  lookup.go, methodset.go).\n\n  Basic types are keywords (:int, :untyped-float ...). Composite types are vectors compared by\n  structure: [:pointer T], [:slice T], [:array n T], [:map K V], [:chan dir T] (dir :both,\n  :send, :recv), [:func params results variadic?], [:struct fields] (each field {:name :type\n  :tag :embedded :pkg}, :pkg the package path of an unexported name), [:interface methods\n  terms] (methods the whole method set, embedded interfaces flattened, sorted by name and\n  package: {:name :type :pkg}; terms nil but for constraints), [:tuple T...]. Named types and\n  type parameters are [:named v] and [:tparam v], v a volatile holding their data, so that =\n  is identity on them (a volatile is equal only to itself).\n\n  A named type's volatile holds {:obj the type name's object, :name, :pkg path, :pkg-name,\n  :underlying, :methods [method objects], :origin and :targs for an instance, :tparams}.m2,R0,s1099,goi's checker: Go types (doc/go/GOI-SPEC.md §3.3), their predicates, printing, sizes, and\n  the lookup of fields and methods, after go/types (predicates.go, typestring.go, gcsizes.go,\n  lookup.go, methodset.go).\n\n  Basic types are keywords (:int, :untyped-float ...). Composite types are vectors compared by\n  structure: [:pointer T], [:slice T], [:array n T], [:map K V], [:chan dir T] (dir :both,\n  :send, :recv), [:func params results variadic?], [:struct fields] (each field {:name :type\n  :tag :embedded :pkg}, :pkg the package path of an unexported name), [:interface methods\n  terms] (methods the whole method set, embedded interfaces flattened, sorted by name and\n  package: {:name :type :pkg}; terms nil but for constraints), [:tuple T...]. Named types and\n  type parameters are [:named v] and [:tparam v], v a volatile holding their data, so that =\n  is identity on them (a volatile is equal only to itself).\n\n  A named type's volatile holds {:obj the type name's object, :name, :pkg path, :pkg-name,\n  :underlying, :methods [method objects], :origin and :targs for an instance, :tparams}.R1,v21,arbace.go.check.types10,basic-infom8,R2,i22,R3,i1,R4,s24,arbace/go/check/types.aeR0,s81,{kind {:size :int? :unsigned? :float? :complex? :string? :bool? :untyped? :name}}v21,arbace.go.check.types11,basic-namesm52,R5,s4,boolR6,s4,int8R7,s5,int16R8,s5,int32R9,s5,int64R10,s3,intR11,s5,uint8R12,s6,uint16R13,s6,uint32R14,s6,uint64R15,s4,uintR16,s7,uintptrR17,s7,float32R18,s7,float64R19,s9,complex64R20,s10,complex128R21,s6,stringR22,s14,unsafe.PointerR23,s12,untyped boolR24,s11,untyped intR25,s12,untyped runeR26,s13,untyped floatR27,s15,untyped complexR28,s14,untyped stringR29,s11,untyped nilR30,s12,invalid typem6,R2,i39,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types3,idsm8,R31,TR2,i50,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types7,next-idm8,R32,L1,MV0,m2,R33,R34,R2,i51,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types6,named?m8,R32,L1,V1,R35,R2,i53,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types7,tparam?m8,R32,L1,V1,R35,R2,i54,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types4,infom8,R32,L1,V1,R35,R2,i55,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,update-info!m8,R32,L1,V4,R35,R36,R37,R38,R2,i56,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,new-namedm10,R32,L1,V1,R39,R0,s84,A new named type: data {:obj :name :pkg :pkg-name ...}; its underlying is set later.R2,i58,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,new-tparamm10,R32,L1,V1,R39,R0,s90,A new type parameter: data {:name :index :bound (its constraint, set when declared) :obj}.R2,i63,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types15,*resolve-named*m10,R40,TR2,i68,R3,i1,R4,s24,arbace/go/check/types.aeR0,s159,A function called with a named type whose underlying type is not known yet (its declaration\n  not checked), which checks its declaration; bound by the checker.v21,arbace.go.check.types5,underm8,R41,TR2,i73,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,tparam-ifacem8,R41,TR2,i73,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,named-underm10,R31,TR32,L1,V1,R35,R2,i75,R3,i1,R4,s24,arbace/go/check/types.aem10,R32,L1,V1,R35,R0,s25,The underlying type of t.R2,i90,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types5,basicm8,R32,L1,V1,R35,R2,i101,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types4,flagm10,R31,TR32,L1,V2,R35,R36,R2,i102,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types13,integer-type?m8,R32,L1,V1,R35,R2,i103,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,unsigned?m8,R32,L1,V1,R35,R2,i104,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,float-type?m8,R32,L1,V1,R35,R2,i105,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types13,complex-type?m8,R32,L1,V1,R35,R2,i106,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,numeric?m8,R32,L1,V1,R35,R2,i107,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,string-type?m8,R32,L1,V1,R35,R2,i108,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types13,boolean-type?m8,R32,L1,V1,R35,R2,i109,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,untyped?m8,R32,L1,V1,R35,R2,i110,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types6,typed?m8,R32,L1,V1,R35,R2,i111,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,const-type?m10,R32,L1,V1,R35,R0,s68,Whether values of t can be constants: booleans, numbers and strings.R2,i112,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,ordered?m8,R32,L1,V1,R35,R2,i116,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,interface?m8,R32,L1,V1,R35,R2,i117,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,pointer?m8,R32,L1,V1,R35,R2,i118,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types15,unsafe-pointer?m8,R32,L1,V1,R35,R2,i119,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,uintptr?m8,R32,L1,V1,R35,R2,i120,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types6,valid?m8,R32,L1,V1,R35,R2,i121,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types7,kind-ofm8,R32,L1,V1,R35,R2,i122,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,has-name?m8,R32,L1,V1,R35,R2,i123,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types17,integer-or-float?m8,R32,L1,V1,R35,R2,i124,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,under-ism8,R41,TR2,i126,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,has-nil?m10,R32,L1,V1,R35,R0,s158,Whether t's values include nil: pointers, slices, maps, channels, funcs, interfaces,\n  unsafe.Pointer; a type parameter's when every type of its type set has.R2,i128,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types16,empty-interface?m8,R32,L1,V1,R35,R2,i138,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,default-typem10,R32,L1,V1,R35,R0,s51,The default type of an untyped type (Go's Default).R2,i141,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,ignore-tagsm10,R32,L1,V1,R35,R0,s78,t with the tags of its struct types dropped, deeply (for IdenticalIgnoreTags).R2,i149,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types22,identical-ignore-tags?m8,R32,L1,V2,R42,R43,R2,i165,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,comparable?m8,R41,TR2,i167,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types8,type-strm8,R41,TR2,i167,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,tparam-tsetm8,R41,TR2,i169,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types20,strictly-comparable?m8,R41,TR2,i169,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,iface-tsetm8,R41,TR2,i169,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types16,tset-comparable?m12,R31,TR32,L1,V2,R44,R45,R0,s80,go/types' _TypeSet.IsComparable: every type of a type set comparable (strictly).R2,i171,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types16,comparable-type?m10,R32,L1,V3,R35,R46,R45,R0,s209,go/types' comparableType: whether values of t can be compared with ==; dynamic: the\n  specification's comparability (ordinary interfaces are comparable), else strict (an\n  interface only when its type set is).R2,i178,R3,i1,R4,s24,arbace/go/check/types.aem8,R32,L2,V1,R35,V2,R35,R45,R2,i199,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types18,incomparable-causem10,R32,L1,V1,R35,R0,s110,Why values of t cannot be compared (go/types' comparableType's cause, dynamic): \"\" when\n  it has none to give.R2,i201,R3,i1,R4,s24,arbace/go/check/types.aem10,R32,L2,V1,R35,V2,R35,R45,R0,s119,Go's Comparable: whether values of t can be compared with == (interfaces are; a type\n  parameter when its type set is).R2,i224,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types6,union?m8,R32,L1,V1,R35,R2,i241,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types14,term-disjoint?m10,R31,TR32,L1,V2,V2,R47,R42,V2,R48,R43,R2,i243,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,term-unionm10,R31,TR32,L1,V2,R42,R43,R2,i246,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types14,term-intersectm10,R31,TR32,L1,V2,R42,R43,R2,i252,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types14,term-includes?m10,R31,TR32,L1,V2,V2,R49,R50,R35,R2,i258,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,term-subset?m10,R31,TR32,L1,V2,R42,R43,R2,i260,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,terms-normm10,R32,L1,V1,R44,R0,s78,go/types' termlist.norm: the terms with the overlapping ones merged, as a set.R2,i262,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,terms-unionm8,R32,L1,V2,R42,R43,R2,i282,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types15,terms-intersectm8,R32,L1,V2,R42,R43,R2,i284,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types15,terms-includes?m8,R32,L1,V2,R51,R35,R2,i291,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types18,terms-superset-of?m10,R31,TR32,L1,V2,R51,R43,R2,i293,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types13,terms-subset?m10,R32,L1,V2,R51,R52,R0,s38,Whether term set xl is a subset of yl.R2,i295,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,make-tsetm10,R32,L1,V2,R53,R54,R0,s52,An interface's type set element: nil for every type.R2,i304,R3,i1,R4,s24,arbace/go/check/types.aem10,R32,L1,V1,R55,R0,s101,The type set of interface type u (an underlying [:interface ms ts]): {:methods :terms\n  :comparable}.R2,i309,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,has-terms?m10,R32,L1,V1,R44,R0,s68,Whether a type set has specific terms (neither every type nor none).R2,i318,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,tset-empty?m8,R32,L1,V1,R44,R2,i323,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types17,method-set-iface?m10,R32,L1,V1,R55,R0,s119,go/types' IsMethodSet: whether interface type u is described by its methods alone (it may be\n  used as a value's type).R2,i325,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,bound-ifacem10,R32,L1,V1,R56,R0,s177,The interface a constraint b denotes: its underlying interface, or the implicit interface of\n  a union or a non-interface type (go/types' implicit interfaces); nil when invalid.R2,i331,R3,i1,R4,s24,arbace/go/check/types.aem10,R32,L1,V1,R57,R0,s75,go/types' TypeParam.iface: the interface of type parameter tp's constraint.R2,i343,R3,i1,R4,s24,arbace/go/check/types.aem8,R32,L1,V1,R57,R2,i352,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types13,typeset-pairsm10,R32,L1,V1,R35,R0,s160,The (type, underlying type) pairs of t's type set (go/types' typeset): a type parameter's\n  specific terms ([[nil nil]] when it has none), else [[t (under t)]].R2,i354,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,typeset-allm10,R32,L1,V2,R35,R36,R0,s68,go/types' all: whether (f t u) holds for every type of t's type set.R2,i365,R3,i1,R4,s24,arbace/go/check/types.aem10,R32,L1,V2,R35,R36,R0,s146,go/types' underIs: whether (f u) holds for the underlying type u of every type of t's type\n  set (u nil: a type parameter without specific types).R2,i370,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,all-basicm10,R32,L1,V2,R35,R58,R0,s118,go/types' allBasic: whether every type of t's type set satisfies pred (a type parameter\n  without specific types: no).R2,i376,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,all-integer?m8,R32,L1,V1,R35,R2,i385,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types13,all-unsigned?m8,R32,L1,V1,R35,R2,i386,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,all-numeric?m8,R32,L1,V1,R35,R2,i387,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types11,all-string?m8,R32,L1,V1,R35,R2,i388,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,all-boolean?m8,R32,L1,V1,R35,R2,i389,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,all-ordered?m8,R32,L1,V1,R35,R2,i390,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types22,all-numeric-or-string?m8,R32,L1,V1,R35,R2,i391,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,all-float?m8,R32,L1,V1,R35,R2,i392,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,all-complex?m8,R32,L1,V1,R35,R2,i393,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types12,common-underm10,R32,L2,V1,R35,V2,R35,R59,R0,s220,go/types' commonUnder: [u nil], u the underlying type every type of t's type set shares\n  (channels: the most restricted direction), or [nil cause]; cnd, when given, a function of\n  (t, u) returning a cause to fail with.R2,i395,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,core-typem10,R32,L1,V1,R35,R0,s51,The common underlying type of t's type set, or nil.R2,i420,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,*qualify*m10,R40,TR2,i427,R3,i1,R4,s24,arbace/go/check/types.aeR0,s100,The current package's path: its named types print unqualified, the others by their\n  package's name.m8,R41,TR2,i432,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,terms-strm8,R32,L1,V1,R53,R2,i434,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types10,params-strm10,R31,TR32,L1,V2,R60,R61,R2,i440,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types7,sig-strm10,R32,L1,V1,V4,R62,R60,R63,R61,R0,s62,A signature's text without the func keyword: (params) results.R2,i449,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,field-strm10,R31,TR32,L1,V1,R36,R2,i458,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,named-strm8,R32,L1,V1,R35,R2,i462,R3,i1,R4,s24,arbace/go/check/types.aem10,R32,L1,V1,R35,R0,s20,Go's text of a type.R2,i471,R3,i1,R4,s24,arbace/go/check/types.aev21,arbace.go.check.types9,word-sizel8,m6,R2,i506,R3,i1,R4,s24,arbace/go/check/types.ae")

var Lit_78 *jrt.String = jrt.Intern("arbace.go.check.types$eval219000004$loading__1927001464__auto____219000005")

var Lit_79 *jrt.String = jrt.Intern("arbace.go.check.types$eval219000008$fn__219000009")

var Lit_80 *jrt.String = jrt.Intern("arbace.go.check.types$fn__219000012")

var Lit_81 *jrt.String = jrt.Intern("arbace.go.check.types$next_id")

var Lit_82 *jrt.String = jrt.Intern("arbace.go.check.types$named_QMARK_")

var Lit_83 *jrt.String = jrt.Intern("arbace.go.check.types$tparam_QMARK_")

var Lit_84 *jrt.String = jrt.Intern("arbace.go.check.types$info")

var Lit_85 *jrt.String = jrt.Intern("arbace.go.check.types$update_info_BANG_")

var Lit_86 *jrt.String = jrt.Intern("arbace.go.check.types$new_named")

var Lit_87 *jrt.String = jrt.Intern("arbace.go.check.types$new_tparam")

var Lit_88 *jrt.String = jrt.Intern("arbace.go.check.types$named_under")

var Lit_89 *jrt.String = jrt.Intern("arbace.go.check.types$under")

var Lit_90 *jrt.String = jrt.Intern("arbace.go.check.types$basic")

var Lit_91 *jrt.String = jrt.Intern("arbace.go.check.types$flag")

var Lit_92 *jrt.String = jrt.Intern("arbace.go.check.types$integer_type_QMARK_")

var Lit_93 *jrt.String = jrt.Intern("arbace.go.check.types$unsigned_QMARK_")

var Lit_94 *jrt.String = jrt.Intern("arbace.go.check.types$float_type_QMARK_")

var Lit_95 *jrt.String = jrt.Intern("arbace.go.check.types$complex_type_QMARK_")

var Lit_96 *jrt.String = jrt.Intern("arbace.go.check.types$numeric_QMARK_")

var Lit_97 *jrt.String = jrt.Intern("arbace.go.check.types$string_type_QMARK_")

var Lit_98 *jrt.String = jrt.Intern("arbace.go.check.types$boolean_type_QMARK_")

var Lit_99 *jrt.String = jrt.Intern("arbace.go.check.types$untyped_QMARK_")

var Lit_100 *jrt.String = jrt.Intern("arbace.go.check.types$typed_QMARK_")

var Lit_101 *jrt.String = jrt.Intern("arbace.go.check.types$const_type_QMARK_")

var Lit_102 *jrt.String = jrt.Intern("arbace.go.check.types$ordered_QMARK_")

var Lit_103 *jrt.String = jrt.Intern("arbace.go.check.types$interface_QMARK_")

var Lit_104 *jrt.String = jrt.Intern("arbace.go.check.types$pointer_QMARK_")

var Lit_105 *jrt.String = jrt.Intern("arbace.go.check.types$unsafe_pointer_QMARK_")

var Lit_106 *jrt.String = jrt.Intern("arbace.go.check.types$uintptr_QMARK_")

var Lit_107 *jrt.String = jrt.Intern("arbace.go.check.types$valid_QMARK_")

var Lit_108 *jrt.String = jrt.Intern("arbace.go.check.types$kind_of")

var Lit_109 *jrt.String = jrt.Intern("arbace.go.check.types$has_name_QMARK_")

var Lit_110 *jrt.String = jrt.Intern("arbace.go.check.types$integer_or_float_QMARK_")

var Lit_111 *jrt.String = jrt.Intern("arbace.go.check.types$has_nil_QMARK_")

var Lit_112 *jrt.String = jrt.Intern("arbace.go.check.types$empty_interface_QMARK_")

var Lit_113 *jrt.String = jrt.Intern("arbace.go.check.types$default_type")

var Lit_114 *jrt.String = jrt.Intern("arbace.go.check.types$ignore_tags")

var Lit_115 *jrt.String = jrt.Intern("arbace.go.check.types$identical_ignore_tags_QMARK_")

var Lit_116 *jrt.String = jrt.Intern("arbace.go.check.types$tset_comparable_QMARK_")

var Lit_117 *jrt.String = jrt.Intern("arbace.go.check.types$comparable_type_QMARK_")

var Lit_118 *jrt.String = jrt.Intern("arbace.go.check.types$strictly_comparable_QMARK_")

var Lit_119 *jrt.String = jrt.Intern("arbace.go.check.types$incomparable_cause")

var Lit_120 *jrt.String = jrt.Intern("arbace.go.check.types$comparable_QMARK_")

var Lit_121 *jrt.String = jrt.Intern("arbace.go.check.types$union_QMARK_")

var Lit_122 *jrt.String = jrt.Intern("arbace.go.check.types$term_disjoint_QMARK_")

var Lit_123 *jrt.String = jrt.Intern("arbace.go.check.types$term_union")

var Lit_124 *jrt.String = jrt.Intern("arbace.go.check.types$term_intersect")

var Lit_125 *jrt.String = jrt.Intern("arbace.go.check.types$term_includes_QMARK_")

var Lit_126 *jrt.String = jrt.Intern("arbace.go.check.types$term_subset_QMARK_")

var Lit_127 *jrt.String = jrt.Intern("arbace.go.check.types$terms_norm")

var Lit_128 *jrt.String = jrt.Intern("arbace.go.check.types$terms_union")

var Lit_129 *jrt.String = jrt.Intern("arbace.go.check.types$terms_intersect")

var Lit_130 *jrt.String = jrt.Intern("arbace.go.check.types$terms_includes_QMARK_")

var Lit_131 *jrt.String = jrt.Intern("arbace.go.check.types$terms_superset_of_QMARK_")

var Lit_132 *jrt.String = jrt.Intern("arbace.go.check.types$terms_subset_QMARK_")

var Lit_133 *jrt.String = jrt.Intern("arbace.go.check.types$make_tset")

var Lit_134 *jrt.String = jrt.Intern("arbace.go.check.types$iface_tset")

var Lit_135 *jrt.String = jrt.Intern("arbace.go.check.types$has_terms_QMARK_")

var Lit_136 *jrt.String = jrt.Intern("arbace.go.check.types$tset_empty_QMARK_")

var Lit_137 *jrt.String = jrt.Intern("arbace.go.check.types$method_set_iface_QMARK_")

var Lit_138 *jrt.String = jrt.Intern("arbace.go.check.types$bound_iface")

var Lit_139 *jrt.String = jrt.Intern("arbace.go.check.types$tparam_iface")

var Lit_140 *jrt.String = jrt.Intern("arbace.go.check.types$tparam_tset")

var Lit_141 *jrt.String = jrt.Intern("arbace.go.check.types$typeset_pairs")

var Lit_142 *jrt.String = jrt.Intern("arbace.go.check.types$typeset_all")

var Lit_143 *jrt.String = jrt.Intern("arbace.go.check.types$under_is")

var Lit_144 *jrt.String = jrt.Intern("arbace.go.check.types$all_basic")

var Lit_145 *jrt.String = jrt.Intern("arbace.go.check.types$all_integer_QMARK_")

var Lit_146 *jrt.String = jrt.Intern("arbace.go.check.types$all_unsigned_QMARK_")

var Lit_147 *jrt.String = jrt.Intern("arbace.go.check.types$all_numeric_QMARK_")

var Lit_148 *jrt.String = jrt.Intern("arbace.go.check.types$all_string_QMARK_")

var Lit_149 *jrt.String = jrt.Intern("arbace.go.check.types$all_boolean_QMARK_")

var Lit_150 *jrt.String = jrt.Intern("arbace.go.check.types$all_ordered_QMARK_")

var Lit_151 *jrt.String = jrt.Intern("arbace.go.check.types$all_numeric_or_string_QMARK_")

var Lit_152 *jrt.String = jrt.Intern("arbace.go.check.types$all_float_QMARK_")

var Lit_153 *jrt.String = jrt.Intern("arbace.go.check.types$all_complex_QMARK_")

var Lit_154 *jrt.String = jrt.Intern("arbace.go.check.types$common_under")

var Lit_155 *jrt.String = jrt.Intern("arbace.go.check.types$core_type")

var Lit_156 *jrt.String = jrt.Intern("arbace.go.check.types$terms_str")

var Lit_157 *jrt.String = jrt.Intern("arbace.go.check.types$params_str")

var Lit_158 *jrt.String = jrt.Intern("arbace.go.check.types$sig_str")

var Lit_159 *jrt.String = jrt.Intern("arbace.go.check.types$field_str")

var Lit_160 *jrt.String = jrt.Intern("arbace.go.check.types$named_str")

var Lit_161 *jrt.String = jrt.Intern("arbace.go.check.types$type_str")

var Lit_162 *jrt.String = jrt.Intern("kn4,linekn6,columnkn4,filekn8,declaredkn7,privatekn8,arglistskn3,tagyn4,longyn1,tkn3,docyn6,fieldskn7,dynamicyn1,nyn1,pyn4,nameyn3,pkgyn6,Stringyn1,uyn7,entriesyn1,Tyn11,addressableyn2,msyn1,myn1,Vyn6,staticyn5,same?yn1,bv21,arbace.go.check.types9,max-alignm6,R0,i507,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types6,sizeofm8,R3,TR0,i509,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types8,align-upm10,R4,TR5,L1,MV2,Myn1,xm2,R6,R7,Myn1,am2,R6,R7,m2,R6,R7,R0,i511,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types20,sync-atomic-align64?m10,R5,L1,V1,R8,R9,s101,Whether t is sync/atomic's align64 (or internal/runtime/atomic's), the empty struct gc\n  aligns to 8.R0,i513,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types7,alignofm8,R5,L1,MV1,R8,m2,R6,R7,R0,i522,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types9,offsetsofm8,R5,L1,V1,R10,R0,i538,R1,i1,R2,s24,arbace/go/check/types.aem8,R5,L1,MV1,R8,m2,R6,R7,R0,i546,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types10,deref-typem10,R5,L1,V1,R8,R9,s72,[base true] for an unnamed pointer type [:pointer base], else [t false].R0,i568,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types10,methods-ofm10,R5,L1,V1,R8,R9,s80,The methods declared on named type t (objects): its declaration completed first.R0,i573,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types11,*fold-case*m10,R11,TR0,i580,R1,i1,R2,s24,arbace/go/check/types.aeR9,s85,go/types' foldCase: names compared without case (and packages ignored), for messages.v21,arbace.go.check.types8,same-id?m10,R5,L1,V4,R12,R13,R14,R15,R9,s114,Whether a field or method named n (in package p when unexported) is the one named name\n  as seen from package pkg.R0,i584,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types9,exported?m8,R5,L1,V1,Myn1,nm2,R6,R16,R0,i596,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types12,*method-obj*m10,R11,TR0,i599,R1,i1,R2,s24,arbace/go/check/types.aeR9,s129,A function from a method object to its data {:name :pkg :type :ptr-recv}, which resolves its\n  declaration; bound by the checker.v21,arbace.go.check.types14,*subst-method*m10,R11,TR0,i604,R1,i1,R2,s24,arbace/go/check/types.aeR9,s135,A function [instance method-obj] -> method data of the instance (type arguments\n  substituted); bound by the checker for generic types.v21,arbace.go.check.types12,named-methodm10,R5,L1,V3,R8,R14,R15,R9,s74,[index method-data] of named type t's method name (seen from pkg), or nil.R0,i609,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types12,iface-methodm10,R5,L1,V3,R17,R14,R15,R9,s73,[index method] of interface type u's method name (seen from pkg), or nil.R0,i621,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types11,consolidatem12,R4,TR5,L1,V1,R18,R9,s76,go/types' consolidateMultiples: entries of one type merged, marked multiple.R0,i632,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types11,lookup-implm10,R5,L1,V4,R19,R20,R14,R15,R9,s352,go/types' lookupFieldOrMethodImpl: {:kind :field|:method|:iface-method, :obj (a field map,\n  a method object or an interface method map), :index [i ...] (the path: field indexes, the\n  last the field's or method's), :via [embedded field names], :indirect}, or {:ambiguous\n  true}, {:ptr-recv true} (a pointer method on a non-addressable value), or nil.R0,i644,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types6,lookupm10,R5,L1,V4,R19,R20,R14,R15,R9,s87,go/types' LookupFieldOrMethod: lookup-impl, but a defined pointer type has fields only.R0,i712,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types12,sort-methodsm10,R5,L1,V1,R21,R9,s83,Interface methods in go/types' order: by name, unexported after package (Id order).R0,i722,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types11,method-datam10,R5,L1,V1,R22,R9,s81,The data of a method object or an interface method: {:name :pkg :type :ptr-recv}.R0,i727,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types14,missing-methodm10,R5,L2,V3,R23,R19,R24,V4,R23,R19,R24,R25,R9,s256,go/types' missingMethod: nil when V implements interface type T (u its underlying), else\n  {:method m :cause kw}: :missing, :ptr-recv (found with a pointer receiver), :wrong-type\n  (with :have), :field (a field of that name), :unexported (other package's).R0,i732,R1,i1,R2,s24,arbace/go/check/types.aev21,arbace.go.check.types15,satisfies-causem10,R5,L1,V2,R23,R26,R9,s122,nil when type V satisfies constraint b (go/types' implements with constraint set), else the\n  cause, as go/types words it.R0,i763,R1,i1,R2,s24,arbace/go/check/types.ae")

var Lit_163 *jrt.String = jrt.Intern("arbace.go.check.types$align_up")

var Lit_164 *jrt.String = jrt.Intern("arbace.go.check.types$sync_atomic_align64_QMARK_")

var Lit_165 *jrt.String = jrt.Intern("arbace.go.check.types$alignof")

var Lit_166 *jrt.String = jrt.Intern("arbace.go.check.types$offsetsof")

var Lit_167 *jrt.String = jrt.Intern("arbace.go.check.types$sizeof")

var Lit_168 *jrt.String = jrt.Intern("arbace.go.check.types$deref_type")

var Lit_169 *jrt.String = jrt.Intern("arbace.go.check.types$methods_of")

var Lit_170 *jrt.String = jrt.Intern("arbace.go.check.types$same_id_QMARK_")

var Lit_171 *jrt.String = jrt.Intern("arbace.go.check.types$exported_QMARK_")

var Lit_172 *jrt.String = jrt.Intern("arbace.go.check.types$named_method")

var Lit_173 *jrt.String = jrt.Intern("arbace.go.check.types$iface_method")

var Lit_174 *jrt.String = jrt.Intern("arbace.go.check.types$consolidate")

var Lit_175 *jrt.String = jrt.Intern("arbace.go.check.types$lookup_impl")

var Lit_176 *jrt.String = jrt.Intern("arbace.go.check.types$lookup")

var Lit_177 *jrt.String = jrt.Intern("arbace.go.check.types$sort_methods")

var Lit_178 *jrt.String = jrt.Intern("arbace.go.check.types$method_data")

var Lit_179 *jrt.String = jrt.Intern("arbace.go.check.types$missing_method")

var Lit_180 *jrt.String = jrt.Intern("arbace.go.check.types$satisfies_cause")
