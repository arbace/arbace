//line j2g_classes.ae:1
package aot_arbace_go_check_types

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_go_check_types_align_up_A_class, Name: "arbace.go.check.types$align_up", Modifiers: 25, Simple: "align_up", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_align_up_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_alignof_A_class, Name: "arbace.go.check.types$alignof", Modifiers: 25, Simple: "alignof", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_alignof_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_alignof_fn__219000089_A_class, Name: "arbace.go.check.types$alignof$fn__219000089", Modifiers: 25, Simple: "fn__219000089", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_alignof_fn__219000089_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_alignof_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_basic_A_class, Name: "arbace.go.check.types$basic", Modifiers: 25, Simple: "basic", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_basic_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_boolean_type_QMARK__A_class, Name: "arbace.go.check.types$boolean_type_QMARK_", Modifiers: 25, Simple: "boolean_type_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_boolean_type_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_comparable_QMARK__A_class, Name: "arbace.go.check.types$comparable_QMARK_", Modifiers: 25, Simple: "comparable_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_comparable_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_comparable_QMARK__fn__219000060_A_class, Name: "arbace.go.check.types$comparable_QMARK_$fn__219000060", Modifiers: 25, Simple: "fn__219000060", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_comparable_QMARK__fn__219000060_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_comparable_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_complex_type_QMARK__A_class, Name: "arbace.go.check.types$complex_type_QMARK_", Modifiers: 25, Simple: "complex_type_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_complex_type_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_consolidate_A_class, Name: "arbace.go.check.types$consolidate", Modifiers: 25, Simple: "consolidate", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_consolidate_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_const_type_QMARK__A_class, Name: "arbace.go.check.types$const_type_QMARK_", Modifiers: 25, Simple: "const_type_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_const_type_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_default_type_A_class, Name: "arbace.go.check.types$default_type", Modifiers: 25, Simple: "default_type", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_default_type_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_deref_type_A_class, Name: "arbace.go.check.types$deref_type", Modifiers: 25, Simple: "deref_type", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_deref_type_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_empty_interface_QMARK__A_class, Name: "arbace.go.check.types$empty_interface_QMARK_", Modifiers: 25, Simple: "empty_interface_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_empty_interface_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_class, Name: "arbace.go.check.types$eval219000004$loading__1927001464__auto____219000005", Modifiers: 25, Simple: "loading__1927001464__auto____219000005", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_eval219000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_eval219000008_fn__219000009_A_class, Name: "arbace.go.check.types$eval219000008$fn__219000009", Modifiers: 25, Simple: "fn__219000009", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_eval219000008_fn__219000009_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_eval219000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_exported_QMARK__A_class, Name: "arbace.go.check.types$exported_QMARK_", Modifiers: 25, Simple: "exported_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_exported_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_field_str_A_class, Name: "arbace.go.check.types$field_str", Modifiers: 25, Simple: "field_str", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_field_str_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_flag_A_class, Name: "arbace.go.check.types$flag", Modifiers: 25, Simple: "flag", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_flag_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_float_type_QMARK__A_class, Name: "arbace.go.check.types$float_type_QMARK_", Modifiers: 25, Simple: "float_type_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_float_type_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_fn__219000012_A_class, Name: "arbace.go.check.types$fn__219000012", Modifiers: 25, Simple: "fn__219000012", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_fn__219000012_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_fn__219000012_m__219000013_A_class, Name: "arbace.go.check.types$fn__219000012$m__219000013", Modifiers: 25, Simple: "m__219000013", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_fn__219000012_m__219000013_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_fn__219000012_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_class, Name: "arbace.go.check.types$fn__219000012$m__219000013$fn__219000014", Modifiers: 25, Simple: "fn__219000014", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_fn__219000012_m__219000013_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_has_name_QMARK__A_class, Name: "arbace.go.check.types$has_name_QMARK_", Modifiers: 25, Simple: "has_name_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_has_name_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_has_nil_QMARK__A_class, Name: "arbace.go.check.types$has_nil_QMARK_", Modifiers: 25, Simple: "has_nil_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_has_nil_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_identical_ignore_tags_QMARK__A_class, Name: "arbace.go.check.types$identical_ignore_tags_QMARK_", Modifiers: 25, Simple: "identical_ignore_tags_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_identical_ignore_tags_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_iface_method_A_class, Name: "arbace.go.check.types$iface_method", Modifiers: 25, Simple: "iface_method", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_iface_method_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_ignore_tags_A_class, Name: "arbace.go.check.types$ignore_tags", Modifiers: 25, Simple: "ignore_tags", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_ignore_tags_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_ignore_tags_fn__219000054_A_class, Name: "arbace.go.check.types$ignore_tags$fn__219000054", Modifiers: 25, Simple: "fn__219000054", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_ignore_tags_fn__219000054_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_ignore_tags_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_info_A_class, Name: "arbace.go.check.types$info", Modifiers: 25, Simple: "info", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_info_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_integer_or_float_QMARK__A_class, Name: "arbace.go.check.types$integer_or_float_QMARK_", Modifiers: 25, Simple: "integer_or_float_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_integer_or_float_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_integer_type_QMARK__A_class, Name: "arbace.go.check.types$integer_type_QMARK_", Modifiers: 25, Simple: "integer_type_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_integer_type_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_interface_QMARK__A_class, Name: "arbace.go.check.types$interface_QMARK_", Modifiers: 25, Simple: "interface_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_interface_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_kind_of_A_class, Name: "arbace.go.check.types$kind_of", Modifiers: 25, Simple: "kind_of", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_kind_of_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_lookup_A_class, Name: "arbace.go.check.types$lookup", Modifiers: 25, Simple: "lookup", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_lookup_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_lookup_impl_A_class, Name: "arbace.go.check.types$lookup_impl", Modifiers: 25, Simple: "lookup_impl", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_lookup_impl_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_lookup_impl_fn__219000112_A_class, Name: "arbace.go.check.types$lookup_impl$fn__219000112", Modifiers: 25, Simple: "fn__219000112", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_lookup_impl_fn__219000112_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_lookup_impl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_method_data_A_class, Name: "arbace.go.check.types$method_data", Modifiers: 25, Simple: "method_data", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_method_data_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_methods_of_A_class, Name: "arbace.go.check.types$methods_of", Modifiers: 25, Simple: "methods_of", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_methods_of_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_missing_method_A_class, Name: "arbace.go.check.types$missing_method", Modifiers: 25, Simple: "missing_method", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_missing_method_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_missing_method_fn__219000126_A_class, Name: "arbace.go.check.types$missing_method$fn__219000126", Modifiers: 25, Simple: "fn__219000126", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_missing_method_fn__219000126_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_missing_method_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_named_QMARK__A_class, Name: "arbace.go.check.types$named_QMARK_", Modifiers: 25, Simple: "named_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_named_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_named_method_A_class, Name: "arbace.go.check.types$named_method", Modifiers: 25, Simple: "named_method", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_named_method_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_named_str_A_class, Name: "arbace.go.check.types$named_str", Modifiers: 25, Simple: "named_str", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_named_str_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_named_under_A_class, Name: "arbace.go.check.types$named_under", Modifiers: 25, Simple: "named_under", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_named_under_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_new_named_A_class, Name: "arbace.go.check.types$new_named", Modifiers: 25, Simple: "new_named", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_new_named_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_new_tparam_A_class, Name: "arbace.go.check.types$new_tparam", Modifiers: 25, Simple: "new_tparam", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_new_tparam_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_next_id_A_class, Name: "arbace.go.check.types$next_id", Modifiers: 25, Simple: "next_id", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_next_id_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_numeric_QMARK__A_class, Name: "arbace.go.check.types$numeric_QMARK_", Modifiers: 25, Simple: "numeric_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_numeric_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_offsetsof_A_class, Name: "arbace.go.check.types$offsetsof", Modifiers: 25, Simple: "offsetsof", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_offsetsof_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_ordered_QMARK__A_class, Name: "arbace.go.check.types$ordered_QMARK_", Modifiers: 25, Simple: "ordered_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_ordered_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_params_str_A_class, Name: "arbace.go.check.types$params_str", Modifiers: 25, Simple: "params_str", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_params_str_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_params_str_fn__219000063_A_class, Name: "arbace.go.check.types$params_str$fn__219000063", Modifiers: 25, Simple: "fn__219000063", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_params_str_fn__219000063_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_params_str_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_pointer_QMARK__A_class, Name: "arbace.go.check.types$pointer_QMARK_", Modifiers: 25, Simple: "pointer_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_pointer_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_same_id_QMARK__A_class, Name: "arbace.go.check.types$same_id_QMARK_", Modifiers: 25, Simple: "same_id_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_same_id_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_sig_str_A_class, Name: "arbace.go.check.types$sig_str", Modifiers: 25, Simple: "sig_str", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_sig_str_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_sizeof_A_class, Name: "arbace.go.check.types$sizeof", Modifiers: 25, Simple: "sizeof", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_sizeof_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_sort_methods_A_class, Name: "arbace.go.check.types$sort_methods", Modifiers: 25, Simple: "sort_methods", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_sort_methods_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_sort_methods_fn__219000122_A_class, Name: "arbace.go.check.types$sort_methods$fn__219000122", Modifiers: 25, Simple: "fn__219000122", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_sort_methods_fn__219000122_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_sort_methods_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_string_type_QMARK__A_class, Name: "arbace.go.check.types$string_type_QMARK_", Modifiers: 25, Simple: "string_type_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_string_type_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_sync_atomic_align64_QMARK__A_class, Name: "arbace.go.check.types$sync_atomic_align64_QMARK_", Modifiers: 25, Simple: "sync_atomic_align64_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_sync_atomic_align64_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_tparam_QMARK__A_class, Name: "arbace.go.check.types$tparam_QMARK_", Modifiers: 25, Simple: "tparam_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_tparam_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_type_str_A_class, Name: "arbace.go.check.types$type_str", Modifiers: 25, Simple: "type_str", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_type_str_iter__219000076__219000080_A_class, Name: "arbace.go.check.types$type_str$iter__219000076__219000080", Modifiers: 25, Simple: "iter__219000076__219000080", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_type_str_iter__219000076__219000080_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_type_str_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_A_class, Name: "arbace.go.check.types$type_str$iter__219000076__219000080$fn__219000081", Modifiers: 25, Simple: "fn__219000081", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_type_str_iter__219000076__219000080_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_fn__219000082_A_class, Name: "arbace.go.check.types$type_str$iter__219000076__219000080$fn__219000081$fn__219000082", Modifiers: 25, Simple: "fn__219000082", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_fn__219000082_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_typed_QMARK__A_class, Name: "arbace.go.check.types$typed_QMARK_", Modifiers: 25, Simple: "typed_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_typed_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_uintptr_QMARK__A_class, Name: "arbace.go.check.types$uintptr_QMARK_", Modifiers: 25, Simple: "uintptr_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_uintptr_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_under_A_class, Name: "arbace.go.check.types$under", Modifiers: 25, Simple: "under", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_under_A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_unsafe_pointer_QMARK__A_class, Name: "arbace.go.check.types$unsafe_pointer_QMARK_", Modifiers: 25, Simple: "unsafe_pointer_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_unsafe_pointer_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_unsigned_QMARK__A_class, Name: "arbace.go.check.types$unsigned_QMARK_", Modifiers: 25, Simple: "unsigned_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_unsigned_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_untyped_QMARK__A_class, Name: "arbace.go.check.types$untyped_QMARK_", Modifiers: 25, Simple: "untyped_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_untyped_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_update_info_BANG__A_class, Name: "arbace.go.check.types$update_info_BANG_", Modifiers: 25, Simple: "update_info_BANG_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_update_info_BANG__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_types_valid_QMARK__A_class, Name: "arbace.go.check.types$valid_QMARK_", Modifiers: 25, Simple: "valid_QMARK_", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_valid_QMARK__A", Source: "types.ae", Declaring: &A_arbace_go_check_types_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_go_check_types_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_check_types_A_New()}; return nil }

var A_arbace_go_check_types_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_check_types_A_new}

var A_arbace_go_check_types_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.check.types", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_A"})

func init() { i := A_arbace_go_check_types_A_class.Info(); i.IsInstance = A_arbace_go_check_types_A_InstanceOf; i.Init = A_arbace_go_check_types_A_Init; i.Table = A_arbace_go_check_types_A_members }

var A_arbace_go_check_types_align_up_A_class *jrt.Class

var A_arbace_go_check_types_alignof_A_class *jrt.Class

var A_arbace_go_check_types_alignof_fn__219000089_A_class *jrt.Class

var A_arbace_go_check_types_basic_A_class *jrt.Class

var A_arbace_go_check_types_boolean_type_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_comparable_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_comparable_QMARK__fn__219000060_A_class *jrt.Class

var A_arbace_go_check_types_complex_type_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_consolidate_A_class *jrt.Class

var A_arbace_go_check_types_const_type_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_default_type_A_class *jrt.Class

var A_arbace_go_check_types_deref_type_A_class *jrt.Class

var A_arbace_go_check_types_empty_interface_QMARK__A_class *jrt.Class

func A_arbace_go_check_types_eval219000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_check_types_eval219000004_A_New()}; return nil }

var A_arbace_go_check_types_eval219000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_check_types_eval219000004_A_new}

var A_arbace_go_check_types_eval219000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.check.types$eval219000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_check_types_A_class, Simple: "eval219000004", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_eval219000004_A"})

func init() { i := A_arbace_go_check_types_eval219000004_A_class.Info(); i.IsInstance = A_arbace_go_check_types_eval219000004_A_InstanceOf; i.Table = A_arbace_go_check_types_eval219000004_A_members }

var A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_class *jrt.Class

func A_arbace_go_check_types_eval219000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_check_types_eval219000008_A_New()}; return nil }

var A_arbace_go_check_types_eval219000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_check_types_eval219000008_A_new}

var A_arbace_go_check_types_eval219000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.check.types$eval219000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_check_types_A_class, Simple: "eval219000008", Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types_eval219000008_A"})

func init() { i := A_arbace_go_check_types_eval219000008_A_class.Info(); i.IsInstance = A_arbace_go_check_types_eval219000008_A_InstanceOf; i.Table = A_arbace_go_check_types_eval219000008_A_members }

var A_arbace_go_check_types_eval219000008_fn__219000009_A_class *jrt.Class

var A_arbace_go_check_types_exported_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_field_str_A_class *jrt.Class

var A_arbace_go_check_types_flag_A_class *jrt.Class

var A_arbace_go_check_types_float_type_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_fn__219000012_A_class *jrt.Class

var A_arbace_go_check_types_fn__219000012_m__219000013_A_class *jrt.Class

var A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_class *jrt.Class

var A_arbace_go_check_types_has_name_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_has_nil_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_identical_ignore_tags_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_iface_method_A_class *jrt.Class

var A_arbace_go_check_types_ignore_tags_A_class *jrt.Class

var A_arbace_go_check_types_ignore_tags_fn__219000054_A_class *jrt.Class

var A_arbace_go_check_types_info_A_class *jrt.Class

var A_arbace_go_check_types_integer_or_float_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_integer_type_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_interface_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_kind_of_A_class *jrt.Class

var A_arbace_go_check_types_lookup_A_class *jrt.Class

var A_arbace_go_check_types_lookup_impl_A_class *jrt.Class

var A_arbace_go_check_types_lookup_impl_fn__219000112_A_class *jrt.Class

var A_arbace_go_check_types_method_data_A_class *jrt.Class

var A_arbace_go_check_types_methods_of_A_class *jrt.Class

var A_arbace_go_check_types_missing_method_A_class *jrt.Class

var A_arbace_go_check_types_missing_method_fn__219000126_A_class *jrt.Class

var A_arbace_go_check_types_named_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_named_method_A_class *jrt.Class

var A_arbace_go_check_types_named_str_A_class *jrt.Class

var A_arbace_go_check_types_named_under_A_class *jrt.Class

var A_arbace_go_check_types_new_named_A_class *jrt.Class

var A_arbace_go_check_types_new_tparam_A_class *jrt.Class

var A_arbace_go_check_types_next_id_A_class *jrt.Class

var A_arbace_go_check_types_numeric_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_offsetsof_A_class *jrt.Class

var A_arbace_go_check_types_ordered_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_params_str_A_class *jrt.Class

var A_arbace_go_check_types_params_str_fn__219000063_A_class *jrt.Class

var A_arbace_go_check_types_pointer_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_same_id_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_sig_str_A_class *jrt.Class

var A_arbace_go_check_types_sizeof_A_class *jrt.Class

var A_arbace_go_check_types_sort_methods_A_class *jrt.Class

var A_arbace_go_check_types_sort_methods_fn__219000122_A_class *jrt.Class

var A_arbace_go_check_types_string_type_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_sync_atomic_align64_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_tparam_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_type_str_A_class *jrt.Class

var A_arbace_go_check_types_type_str_iter__219000076__219000080_A_class *jrt.Class

var A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_A_class *jrt.Class

var A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_fn__219000082_A_class *jrt.Class

var A_arbace_go_check_types_typed_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_uintptr_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_under_A_class *jrt.Class

var A_arbace_go_check_types_unsafe_pointer_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_unsigned_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_untyped_QMARK__A_class *jrt.Class

var A_arbace_go_check_types_update_info_BANG__A_class *jrt.Class

var A_arbace_go_check_types_valid_QMARK__A_class *jrt.Class

func A_arbace_go_check_types__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_go_check_types__init_A_Load__O()}; return nil }

func A_arbace_go_check_types__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_check_types__init_A_New()}; return nil }

var A_arbace_go_check_types__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_go_check_types__init_A_invoke, New: A_arbace_go_check_types__init_A_new}

var A_arbace_go_check_types__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.check.types__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_check_types.A_arbace_go_check_types__init_A", Source: "types.ae"})

func init() { i := A_arbace_go_check_types__init_A_class.Info(); i.IsInstance = A_arbace_go_check_types__init_A_InstanceOf; i.Init = A_arbace_go_check_types__init_A_Init; i.Table = A_arbace_go_check_types__init_A_members }
