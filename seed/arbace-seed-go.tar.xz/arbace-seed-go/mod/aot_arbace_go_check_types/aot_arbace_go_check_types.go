//line aot_arbace_go_check_types.ae:1
package aot_arbace_go_check_types

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_const"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_New() *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_types_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_types_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_go_check_types_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_1, A_arbace_go_check_types_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_types_eval219000008_fn__219000009_A_New() *A_arbace_go_check_types_eval219000008_fn__219000009_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_eval219000008_fn__219000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_types_eval219000008_fn__219000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_types_eval219000008_fn__219000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_go_check_types_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_types_A_const_8.GetRawRoot__O(), A_arbace_go_check_types_A_const_9) }






















func A_arbace_go_check_types_fn__219000012_A_New() *A_arbace_go_check_types_fn__219000012_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_A) Invoke_O__O(self any) any { var m__1 any; var tmp1 any = A_arbace_go_check_types_fn__219000012_m__219000013_A_New(); var tmp2 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, true); A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class = fncls__31d; tmp2 = fncls__31d } else { tmp2 = fncls__31 }; m__1 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp1, tmp2, nil, 2); var root_32 any =
										A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_36 any = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_14, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_16), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_17, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_19, A_arbace_go_check_types_A_const_20, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_21, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_23, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_25, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_26, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_28, A_arbace_go_check_types_A_const_20, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_29, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_30, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_31, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_32, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_33, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_34), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_35, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_34), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_36, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_37), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_38, A_arbace_go_check_types_A_const_39, A_arbace_go_check_types_A_const_37), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_40, A_arbace_go_check_types_A_const_39, A_arbace_go_check_types_A_const_41), lang.IFn_Cast(m__1).Invoke_O_O__O(A_arbace_go_check_types_A_const_42, A_arbace_go_check_types_A_const_24), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_43, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_16, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_46, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_47, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_48, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_34, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_49, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_37, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_50, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_41, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_51, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_45))); if linked_33 == nil { return ifn_34.Invoke_O_O__O(arg_35, arg_36) } else { return linked_33.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_32, arg_35, arg_36) } }
//line :24:1
func A_arbace_go_check_types_fn__219000012_m__219000013_A_New() *A_arbace_go_check_types_fn__219000012_m__219000013_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_m__219000013_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_A) DoInvoke_O_O_O_O__O(self, n__1, size__2, flags__3 any) any { var tmp1 any; var root_20 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_11, size__2, A_arbace_go_check_types_A_const_12, n__1)); var arg_24 any; var root_25 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any; var tmp2 any = A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; arg_28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_29 any = flags__3; if linked_26 == nil { arg_24 = ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { arg_24 = linked_26.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) }; if linked_21 == nil { tmp1 = ifn_22.Invoke_O_O__O(arg_23, arg_24) } else { tmp1 = linked_21.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_20, arg_23, arg_24) }; return lang.Tuple_Create_O_O__IPersistentVector(n__1, tmp1) }
//line :24:1
func A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_New() *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A) Invoke_O_O__O(self, f__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(f__1, jrt.Boolean_TRUE.Ref()) }


























func A_arbace_go_check_types_next_id_A_New() *A_arbace_go_check_types_next_id_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_next_id_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_go_check_types_next_id_A) Ctor() {}
//line :51:1
func (t *A_arbace_go_check_types_next_id_A) InvokePrim_O__J(self any) int64 { return jrt.Number_Cast(lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(A_arbace_go_check_types_A_const_52.GetRawRoot__O(), Lit_25, false)).LongValue__J() }
//line :51:1
func (t *A_arbace_go_check_types_next_id_A) Invoke_O__O(self any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O__J(self)).Ref() }

func A_arbace_go_check_types_named_QMARK__A_New() *A_arbace_go_check_types_named_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_QMARK__A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_go_check_types_named_QMARK__A) Ctor() {}
//line :53:1
func (t *A_arbace_go_check_types_named_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_37 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = t__0; if linked_38 == nil { and__1927000168__auto____2 = ifn_39.Invoke_O__O(arg_40) } else { and__1927000168__auto____2 = linked_38.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_37, arg_40) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_54; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_tparam_QMARK__A_New() *A_arbace_go_check_types_tparam_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_QMARK__A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_go_check_types_tparam_QMARK__A) Ctor() {}
//line :54:1
func (t *A_arbace_go_check_types_tparam_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_41 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = t__0; if linked_42 == nil { and__1927000168__auto____2 = ifn_43.Invoke_O__O(arg_44) } else { and__1927000168__auto____2 = linked_42.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_41, arg_44) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_55; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_info_A_New() *A_arbace_go_check_types_info_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_info_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_go_check_types_info_A) Ctor() {}
//line :55:1
func (t *A_arbace_go_check_types_info_A) Invoke_O_O__O(self, t__0 any) any { var root_45 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_46 == nil { return ifn_47.Invoke_O__O(arg_48) } else { return linked_46.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_45, arg_48) } }
func A_arbace_go_check_types_update_info_BANG__A_New() *A_arbace_go_check_types_update_info_BANG__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_update_info_BANG__A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_go_check_types_update_info_BANG__A) Ctor() {}
//line :56:1
func (t *A_arbace_go_check_types_update_info_BANG__A) DoInvoke_O_O_O_O__O(self, t__0, f__1, args__2 any) any { var root_49 any = A_arbace_go_check_types_A_const_56.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var arg_53 any; var root_54 any = A_arbace_go_check_types_A_const_57.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = f__1; var arg_58 any; var root_60 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_61 == nil { arg_58 = ifn_62.Invoke_O__O(arg_63) } else { arg_58 = linked_61.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_60, arg_63) }; var arg_59 any = args__2; if linked_55 == nil { arg_53 = ifn_56.Invoke_O_O_O__O(arg_57, arg_58, arg_59) } else { arg_53 = linked_55.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_54, arg_57, arg_58, arg_59) }; if linked_50 == nil { ifn_51.Invoke_O_O__O(arg_52, arg_53) } else { linked_50.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_49, arg_52, arg_53) }; return t__0 }

func A_arbace_go_check_types_new_named_A_New() *A_arbace_go_check_types_new_named_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_new_named_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_go_check_types_new_named_A) Ctor() {}
//line :58:1
func (t *A_arbace_go_check_types_new_named_A) Invoke_O_O__O(self, data__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_54; var tmp2 any; var root_64 any = A_arbace_go_check_types_A_const_58.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_66 lang.IFn; if


	linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_59.GetRawRoot__O()); var tmp4 any = A_arbace_go_check_types_A_const_60; var tmp5 any; var root_76 any = A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_76, A_arbace_go_check_types_next_id_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; if linked_77 == nil { tmp5 = ifn_78.Invoke__O() } else { tmp5 = jrt.Long_ValueOf_J__Long_NoInit(linked_77.(*A_arbace_go_check_types_next_id_A).InvokePrim_O__J(root_76)).Ref() }; arg_67 = tmp3.Invoke_O_O_O_O_O__O(data__0, tmp4, tmp5, A_arbace_go_check_types_A_const_62, lang.PersistentVector_EMPTY.Ref()); if linked_65 == nil { tmp2 = ifn_66.Invoke_O__O(arg_67) } else { tmp2 = linked_65.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_64, arg_67) }; return /*line :58:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }




func A_arbace_go_check_types_new_tparam_A_New() *A_arbace_go_check_types_new_tparam_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_new_tparam_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_go_check_types_new_tparam_A) Ctor() {}
//line :63:1
func (t *A_arbace_go_check_types_new_tparam_A) Invoke_O_O__O(self, data__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_55; var tmp2 any; var root_79 any = A_arbace_go_check_types_A_const_58.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_81 lang.IFn; if


	linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any; var root_83 any = A_arbace_go_check_types_A_const_59.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = data__0; var arg_87 any = A_arbace_go_check_types_A_const_60; var arg_88 any; var root_89 any = A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_89, A_arbace_go_check_types_next_id_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; if linked_90 == nil { arg_88 = ifn_91.Invoke__O() } else { arg_88 = jrt.Long_ValueOf_J__Long_NoInit(linked_90.(*A_arbace_go_check_types_next_id_A).InvokePrim_O__J(root_89)).Ref() }; if linked_84 == nil { arg_82 = ifn_85.Invoke_O_O_O__O(arg_86, arg_87, arg_88) } else { arg_82 = linked_84.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_83, arg_86, arg_87, arg_88) }; if linked_80 == nil { tmp2 = ifn_81.Invoke_O__O(arg_82) } else { tmp2 = linked_80.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_79, arg_82) }; return /*line :63:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }











func A_arbace_go_check_types_named_under_A_New() *A_arbace_go_check_types_named_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_under_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_go_check_types_named_under_A) Ctor() {}
//line :75:1
func (t *A_arbace_go_check_types_named_under_A) Invoke_O_O__O(self, t__0 any) any { { var t__2 any = t__0; var seen__3 any = lang.PersistentHashSet_EMPTY.Ref(); L1: for { var i__4 any; var root_92 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, A_arbace_go_check_types_info_A_fn_class); var ifn_94 lang.IFn

	if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = t__2; if linked_93 == nil { i__4 = ifn_94.Invoke_O__O(arg_95) } else { i__4 = linked_93.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_92, arg_95) }
//line :75:1
	var temp__1927000408__auto____5 any = A_arbace_go_check_types_A_const_64.Invoke_O__O(i__4)


	if jrt.J2g_Truth(temp__1927000408__auto____5) { var u__6 any = temp__1927000408__auto____5; var tmp1 any; var root_96 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_98 lang.IFn
		if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = u__6; if linked_97 == nil { tmp1 = ifn_98.Invoke_O__O(arg_99) } else { tmp1 = linked_97.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_96, arg_99) }; if jrt.J2g_Truth(tmp1) {

			var tmp2 any; var root_100 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = seen__3; var arg_104 any = u__6; if linked_101 == nil { tmp2 = ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { tmp2 = linked_101.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_100, arg_103, arg_104) }; if jrt.J2g_Truth(tmp2) { return A_arbace_go_check_types_A_const_67 } else {

				var tmp3 any; var root_113 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = seen__3; var arg_117 any = t__2; if linked_114 == nil { tmp3 = ifn_115.Invoke_O_O__O(arg_116, arg_117) } else { tmp3 = linked_114.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_113, arg_116, arg_117) }; t__2, seen__3 = u__6, tmp3; continue L1 } } else {
//line :79:1
					return u__6 } } else {





						var tmp4 any; var and__1927000168__auto____6 any = A_arbace_go_check_types_A_const_68.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_105 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = A_arbace_go_check_types_A_const_70.Invoke_O__O(i__4); if linked_106 == nil { and__1927000168__auto____7 = ifn_107.Invoke_O__O(arg_108) } else { and__1927000168__auto____7 = linked_106.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_105, arg_108) }; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp4 = A_arbace_go_check_types_A_const_71.Invoke_O__O(i__4) } else { tmp4 = and__1927000168__auto____7 } } else { tmp4 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp4) {
							lang.IFn_Cast(A_arbace_go_check_types_A_const_68.Get__O()).Invoke_O__O(t__2)
							var tmp5 *lang.Keyword = A_arbace_go_check_types_A_const_64; var tmp6 any; var root_109 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, A_arbace_go_check_types_info_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = t__2; if linked_110 == nil { tmp6 = ifn_111.Invoke_O__O(arg_112) } else { tmp6 = linked_110.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_109, arg_112) }; if jrt.J2g_Truth(tmp5.Invoke_O__O(tmp6)) { t__2, seen__3 = t__2, seen__3; continue L1 } else { return A_arbace_go_check_types_A_const_67 } } else {
//line :85:1
								return A_arbace_go_check_types_A_const_67 } } } }; /*line :75:1*/panic("j2g: unreachable") }














func A_arbace_go_check_types_under_A_New() *A_arbace_go_check_types_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_go_check_types_under_A) Ctor() {}
//line :90:1
func (t *A_arbace_go_check_types_under_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_118 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_120 lang.IFn
	if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = t__0; if linked_119 == nil { tmp1 = ifn_120.Invoke_O__O(arg_121) } else { tmp1 = linked_119.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_118, arg_121) }
//line :93:1
	if jrt.J2g_Truth(tmp1) { return t__0 } else { var tmp2 any = A_arbace_go_check_types_A_const_54; if lang.Util_Identical_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))) {

		var root_122 any = A_arbace_go_check_types_A_const_73.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, A_arbace_go_check_types_named_under_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = t__0; if linked_123 == nil { return ifn_124.Invoke_O__O(arg_125) } else { return linked_123.(*A_arbace_go_check_types_named_under_A).Invoke_O_O__O(root_122, arg_125) } } else {
//line :93:1
			var tmp3 any = A_arbace_go_check_types_A_const_55; if lang.Util_Identical_O_O__Z_NoInit(tmp3, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))) {


				var root_126 any = A_arbace_go_check_types_A_const_74.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, A_arbace_go_check_types_tparam_iface_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = t__0; if linked_127 == nil { return ifn_128.Invoke_O__O(arg_129) } else { return linked_127.(*A_arbace_go_check_types_tparam_iface_A).Invoke_O_O__O(root_126, arg_129) } } else {
//line :93:1
					if A_arbace_go_check_types_A_const_75 != nil { return t__0 } else { return nil
					}
				}
		}
	}
}


func A_arbace_go_check_types_basic_A_New() *A_arbace_go_check_types_basic_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_basic_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_check_types_basic_A) Ctor() {}
//line :101:1
func (t *A_arbace_go_check_types_basic_A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_130 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_go_check_types_under_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = t__0; if linked_131 == nil { u__2 = ifn_132.Invoke_O__O(arg_133) } else { u__2 = linked_131.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_130, arg_133) }; var tmp1 any; var root_134 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = u__2; if linked_135 == nil { tmp1 = ifn_136.Invoke_O__O(arg_137) } else { tmp1 = linked_135.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_134, arg_137) }; if jrt.J2g_Truth(tmp1) { return u__2 } else { return nil } }
func A_arbace_go_check_types_flag_A_New() *A_arbace_go_check_types_flag_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_flag_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_go_check_types_flag_A) Ctor() {}
//line :102:1
func (t *A_arbace_go_check_types_flag_A) Invoke_O_O_O__O(self, t__0, f__1 any) any { var b__3 any; var root_138 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, A_arbace_go_check_types_basic_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = t__0; if linked_139 == nil { b__3 = ifn_140.Invoke_O__O(arg_141) } else { b__3 = linked_139.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_138, arg_141) }; var tmp1 any; var and__1927000168__auto____4 any = b__3; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_go_check_types_A_const_78.GetRawRoot__O()).Invoke_O__O(b__3), f__1) } else { tmp1 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }
func A_arbace_go_check_types_integer_type_QMARK__A_New() *A_arbace_go_check_types_integer_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_integer_type_QMARK__A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_go_check_types_integer_type_QMARK__A) Ctor() {}
//line :103:1
func (t *A_arbace_go_check_types_integer_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_142 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, A_arbace_go_check_types_flag_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = t__0; var arg_146 any = A_arbace_go_check_types_A_const_18; if linked_143 == nil { return ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { return linked_143.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_142, arg_145, arg_146) } }
func A_arbace_go_check_types_unsigned_QMARK__A_New() *A_arbace_go_check_types_unsigned_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_unsigned_QMARK__A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_go_check_types_unsigned_QMARK__A) Ctor() {}
//line :104:1
func (t *A_arbace_go_check_types_unsigned_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_147 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, A_arbace_go_check_types_flag_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = t__0; var arg_151 any = A_arbace_go_check_types_A_const_27; if linked_148 == nil { return ifn_149.Invoke_O_O__O(arg_150, arg_151) } else { return linked_148.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_147, arg_150, arg_151) } }
func A_arbace_go_check_types_float_type_QMARK__A_New() *A_arbace_go_check_types_float_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_float_type_QMARK__A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_go_check_types_float_type_QMARK__A) Ctor() {}
//line :105:1
func (t *A_arbace_go_check_types_float_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_152 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, A_arbace_go_check_types_flag_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = t__0; var arg_156 any = A_arbace_go_check_types_A_const_34; if linked_153 == nil { return ifn_154.Invoke_O_O__O(arg_155, arg_156) } else { return linked_153.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_152, arg_155, arg_156) } }
func A_arbace_go_check_types_complex_type_QMARK__A_New() *A_arbace_go_check_types_complex_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_complex_type_QMARK__A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_go_check_types_complex_type_QMARK__A) Ctor() {}
//line :106:1
func (t *A_arbace_go_check_types_complex_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_157 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, A_arbace_go_check_types_flag_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = t__0; var arg_161 any = A_arbace_go_check_types_A_const_37; if linked_158 == nil { return ifn_159.Invoke_O_O__O(arg_160, arg_161) } else { return linked_158.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_157, arg_160, arg_161) } }
func A_arbace_go_check_types_numeric_QMARK__A_New() *A_arbace_go_check_types_numeric_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_numeric_QMARK__A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_go_check_types_numeric_QMARK__A) Ctor() {}
//line :107:1
func (t *A_arbace_go_check_types_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_162 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = t__0; if linked_163 == nil { or__1927000174__auto____2 = ifn_164.Invoke_O__O(arg_165) } else { or__1927000174__auto____2 = linked_163.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_162, arg_165) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_166 any = A_arbace_go_check_types_A_const_81.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = t__0; if linked_167 == nil { or__1927000174__auto____3 = ifn_168.Invoke_O__O(arg_169) } else { or__1927000174__auto____3 = linked_167.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_166, arg_169) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_170 any = A_arbace_go_check_types_A_const_82.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, A_arbace_go_check_types_complex_type_QMARK__A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = t__0; if linked_171 == nil { return ifn_172.Invoke_O__O(arg_173) } else { return linked_171.(*A_arbace_go_check_types_complex_type_QMARK__A).Invoke_O_O__O(root_170, arg_173) } } } }
func A_arbace_go_check_types_string_type_QMARK__A_New() *A_arbace_go_check_types_string_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_string_type_QMARK__A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_go_check_types_string_type_QMARK__A) Ctor() {}
//line :108:1
func (t *A_arbace_go_check_types_string_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_174 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, A_arbace_go_check_types_flag_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = t__0; var arg_178 any = A_arbace_go_check_types_A_const_41; if linked_175 == nil { return ifn_176.Invoke_O_O__O(arg_177, arg_178) } else { return linked_175.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_174, arg_177, arg_178) } }
func A_arbace_go_check_types_boolean_type_QMARK__A_New() *A_arbace_go_check_types_boolean_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_boolean_type_QMARK__A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_go_check_types_boolean_type_QMARK__A) Ctor() {}
//line :109:1
func (t *A_arbace_go_check_types_boolean_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_179 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, A_arbace_go_check_types_flag_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = t__0; var arg_183 any = A_arbace_go_check_types_A_const_16; if linked_180 == nil { return ifn_181.Invoke_O_O__O(arg_182, arg_183) } else { return linked_180.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_179, arg_182, arg_183) } }
func A_arbace_go_check_types_untyped_QMARK__A_New() *A_arbace_go_check_types_untyped_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_untyped_QMARK__A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_go_check_types_untyped_QMARK__A) Ctor() {}
//line :110:1
func (t *A_arbace_go_check_types_untyped_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_184 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = t__0; if linked_185 == nil { and__1927000168__auto____2 = ifn_186.Invoke_O__O(arg_187) } else { and__1927000168__auto____2 = linked_185.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_184, arg_187) }; if jrt.J2g_Truth(and__1927000168__auto____2) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_go_check_types_A_const_78.GetRawRoot__O()).Invoke_O__O(t__0), A_arbace_go_check_types_A_const_45))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_typed_QMARK__A_New() *A_arbace_go_check_types_typed_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typed_QMARK__A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_go_check_types_typed_QMARK__A) Ctor() {}
//line :111:1
func (t *A_arbace_go_check_types_typed_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_188 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any; var root_192 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, A_arbace_go_check_types_untyped_QMARK__A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = t__0; if linked_193 == nil { arg_191 = ifn_194.Invoke_O__O(arg_195) } else { arg_191 = linked_193.(*A_arbace_go_check_types_untyped_QMARK__A).Invoke_O_O__O(root_192, arg_195) }; if linked_189 == nil { return ifn_190.Invoke_O__O(arg_191) } else { return linked_189.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_188, arg_191) } }
func A_arbace_go_check_types_const_type_QMARK__A_New() *A_arbace_go_check_types_const_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_const_type_QMARK__A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_go_check_types_const_type_QMARK__A) Ctor() {}
//line :112:1
func (t *A_arbace_go_check_types_const_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var b__2 any; var root_196 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, A_arbace_go_check_types_basic_A_fn_class); var ifn_198 lang.IFn; if


	linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = t__0; if linked_197 == nil { b__2 = ifn_198.Invoke_O__O(arg_199) } else { b__2 = linked_197.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_196, arg_199) }; var and__1927000168__auto____3 any = b__2; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_200 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = lang.IFn_Cast(A_arbace_go_check_types_A_const_84).Invoke_O__O(b__2); if linked_201 == nil { return ifn_202.Invoke_O__O(arg_203) } else { return linked_201.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_200, arg_203) } } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_ordered_QMARK__A_New() *A_arbace_go_check_types_ordered_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ordered_QMARK__A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_go_check_types_ordered_QMARK__A) Ctor() {}
//line :116:1
func (t *A_arbace_go_check_types_ordered_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_204 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = t__0; if linked_205 == nil { or__1927000174__auto____2 = ifn_206.Invoke_O__O(arg_207) } else { or__1927000174__auto____2 = linked_205.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_204, arg_207) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_208 any = A_arbace_go_check_types_A_const_81.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = t__0; if linked_209 == nil { or__1927000174__auto____3 = ifn_210.Invoke_O__O(arg_211) } else { or__1927000174__auto____3 = linked_209.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_208, arg_211) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_212 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, A_arbace_go_check_types_string_type_QMARK__A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = t__0; if linked_213 == nil { return ifn_214.Invoke_O__O(arg_215) } else { return linked_213.(*A_arbace_go_check_types_string_type_QMARK__A).Invoke_O_O__O(root_212, arg_215) } } } }
func A_arbace_go_check_types_interface_QMARK__A_New() *A_arbace_go_check_types_interface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_interface_QMARK__A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_go_check_types_interface_QMARK__A) Ctor() {}
//line :117:1
func (t *A_arbace_go_check_types_interface_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_216 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, A_arbace_go_check_types_under_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = t__0; if linked_217 == nil { u__2 = ifn_218.Invoke_O__O(arg_219) } else { u__2 = linked_217.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_216, arg_219) }; var and__1927000168__auto____3 any; var root_220 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = u__2; if linked_221 == nil { and__1927000168__auto____3 = ifn_222.Invoke_O__O(arg_223) } else { and__1927000168__auto____3 = linked_221.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_220, arg_223) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_86; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_pointer_QMARK__A_New() *A_arbace_go_check_types_pointer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_pointer_QMARK__A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_go_check_types_pointer_QMARK__A) Ctor() {}
//line :118:1
func (t *A_arbace_go_check_types_pointer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_224 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, A_arbace_go_check_types_under_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = t__0; if linked_225 == nil { u__2 = ifn_226.Invoke_O__O(arg_227) } else { u__2 = linked_225.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_224, arg_227) }; var and__1927000168__auto____3 any; var root_228 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = u__2; if linked_229 == nil { and__1927000168__auto____3 = ifn_230.Invoke_O__O(arg_231) } else { and__1927000168__auto____3 = linked_229.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_228, arg_231) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_87; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_unsafe_pointer_QMARK__A_New() *A_arbace_go_check_types_unsafe_pointer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_unsafe_pointer_QMARK__A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_go_check_types_unsafe_pointer_QMARK__A) Ctor() {}
//line :119:1
func (t *A_arbace_go_check_types_unsafe_pointer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_42; var tmp2 any; var root_232 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, A_arbace_go_check_types_basic_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = t__0; if linked_233 == nil { tmp2 = ifn_234.Invoke_O__O(arg_235) } else { tmp2 = linked_233.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_232, arg_235) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }
func A_arbace_go_check_types_uintptr_QMARK__A_New() *A_arbace_go_check_types_uintptr_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_uintptr_QMARK__A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_go_check_types_uintptr_QMARK__A) Ctor() {}
//line :120:1
func (t *A_arbace_go_check_types_uintptr_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_32; var tmp2 any; var root_236 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, A_arbace_go_check_types_basic_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = t__0; if linked_237 == nil { tmp2 = ifn_238.Invoke_O__O(arg_239) } else { tmp2 = linked_237.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_236, arg_239) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }
func A_arbace_go_check_types_valid_QMARK__A_New() *A_arbace_go_check_types_valid_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_valid_QMARK__A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_go_check_types_valid_QMARK__A) Ctor() {}
//line :121:1
func (t *A_arbace_go_check_types_valid_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_240 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = A_arbace_go_check_types_A_const_67; var arg_244 any = t__0; if linked_241 == nil { return ifn_242.Invoke_O_O__O(arg_243, arg_244) } else { return linked_241.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_240, arg_243, arg_244) } }
func A_arbace_go_check_types_kind_of_A_New() *A_arbace_go_check_types_kind_of_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_kind_of_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_go_check_types_kind_of_A) Ctor() {}
//line :122:1
func (t *A_arbace_go_check_types_kind_of_A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_245 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, A_arbace_go_check_types_under_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = t__0; if linked_246 == nil { u__2 = ifn_247.Invoke_O__O(arg_248) } else { u__2 = linked_246.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_245, arg_248) }; var tmp1 any; var root_249 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = u__2; if linked_250 == nil { tmp1 = ifn_251.Invoke_O__O(arg_252) } else { tmp1 = linked_250.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_249, arg_252) }; if jrt.J2g_Truth(tmp1) { return u__2 } else { return lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)) } }
func A_arbace_go_check_types_has_name_QMARK__A_New() *A_arbace_go_check_types_has_name_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_name_QMARK__A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_go_check_types_has_name_QMARK__A) Ctor() {}
//line :123:1
func (t *A_arbace_go_check_types_has_name_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_253 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = t__0; if linked_254 == nil { or__1927000174__auto____2 = ifn_255.Invoke_O__O(arg_256) } else { or__1927000174__auto____2 = linked_254.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_253, arg_256) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_257 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = t__0; if linked_258 == nil { or__1927000174__auto____3 = ifn_259.Invoke_O__O(arg_260) } else { or__1927000174__auto____3 = linked_258.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_257, arg_260) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_261 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = t__0; if linked_262 == nil { return ifn_263.Invoke_O__O(arg_264) } else { return linked_262.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_261, arg_264) } } } }
func A_arbace_go_check_types_integer_or_float_QMARK__A_New() *A_arbace_go_check_types_integer_or_float_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_integer_or_float_QMARK__A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_go_check_types_integer_or_float_QMARK__A) Ctor() {}
//line :124:1
func (t *A_arbace_go_check_types_integer_or_float_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_265 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = t__0; if linked_266 == nil { or__1927000174__auto____2 = ifn_267.Invoke_O__O(arg_268) } else { or__1927000174__auto____2 = linked_266.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_265, arg_268) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_269 any = A_arbace_go_check_types_A_const_81.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = t__0; if linked_270 == nil { return ifn_271.Invoke_O__O(arg_272) } else { return linked_270.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_269, arg_272) } } }



func A_arbace_go_check_types_has_nil_QMARK__A_New() *A_arbace_go_check_types_has_nil_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_nil_QMARK__A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_go_check_types_has_nil_QMARK__A) Ctor() {}
//line :128:1
func (t *A_arbace_go_check_types_has_nil_QMARK__A) Invoke_O_O__O(self, t__0 any) any {



	var tmp1 any; var root_273 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = t__0; if linked_274 == nil { tmp1 = ifn_275.Invoke_O__O(arg_276) } else { tmp1 = linked_274.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_273, arg_276) }; if jrt.J2g_Truth(tmp1) {
		var root_277 any = A_arbace_go_check_types_A_const_90.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, A_arbace_go_check_types_under_is_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = t__0; var arg_281 any; var tmp2 any = A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A_New(); var tmp3 *jrt.Class; var fncls__290 *jrt.Class = A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A_fn_class; if fncls__290 == nil { var fncls__290d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A_fn_class = fncls__290d; tmp3 = fncls__290d } else { tmp3 = fncls__290 }; arg_281 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_278 == nil { return ifn_279.Invoke_O_O__O(arg_280, arg_281) } else { return linked_278.(*A_arbace_go_check_types_under_is_A).Invoke_O_O_O__O(root_277, arg_280, arg_281) } } else {
//line :132:1
			var u__2 any; var root_291 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, A_arbace_go_check_types_under_A_fn_class); var ifn_293 lang.IFn

			if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = t__0; if linked_292 == nil { u__2 = ifn_293.Invoke_O__O(arg_294) } else { u__2 = linked_292.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_291, arg_294) }
//line :132:1
			var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_42, u__2)


			if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_51, u__2); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var and__1927000168__auto____5 any; var root_295 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_297 lang.IFn
				if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = u__2; if linked_296 == nil { and__1927000168__auto____5 = ifn_297.Invoke_O__O(arg_298) } else { and__1927000168__auto____5 = linked_296.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_295, arg_298) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_299 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = A_arbace_go_check_types_A_const_93; var arg_303 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)); if linked_300 == nil { return ifn_301.Invoke_O_O__O(arg_302, arg_303) } else { return linked_300.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_299, arg_302, arg_303) } } else { return and__1927000168__auto____5 } } } } }
//line :133:1
func A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A_New() *A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A) Ctor() {}
//line :133:1
func (t *A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A) Invoke_O_O__O(self, u__1 any) any { var and__1927000168__auto____2 any; var root_282 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = u__1; if linked_283 == nil { and__1927000168__auto____2 = ifn_284.Invoke_O__O(arg_285) } else { and__1927000168__auto____2 = linked_283.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_282, arg_285) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_286 any = A_arbace_go_check_types_A_const_92.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, A_arbace_go_check_types_has_nil_QMARK__A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = u__1; if linked_287 == nil { return ifn_288.Invoke_O__O(arg_289) } else { return linked_287.(*A_arbace_go_check_types_has_nil_QMARK__A).Invoke_O_O__O(root_286, arg_289) } } else { return and__1927000168__auto____2 } }




func A_arbace_go_check_types_empty_interface_QMARK__A_New() *A_arbace_go_check_types_empty_interface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_empty_interface_QMARK__A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_go_check_types_empty_interface_QMARK__A) Ctor() {}
//line :138:1
func (t *A_arbace_go_check_types_empty_interface_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_304 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, A_arbace_go_check_types_under_A_fn_class); var ifn_306 lang.IFn; if
												linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = t__0; if linked_305 == nil { u__2 = ifn_306.Invoke_O__O(arg_307) } else { u__2 = linked_305.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_304, arg_307) }; var and__1927000168__auto____3 any; var root_308 any = /*line :138:1*/A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_310 lang.IFn; if
												linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = u__2; if linked_309 == nil { and__1927000168__auto____3 = ifn_310.Invoke_O__O(arg_311) } else { and__1927000168__auto____3 = linked_309.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_308, arg_311) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_86; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____4 { var and__1927000168__auto____5 any; var root_312 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_313 == nil { and__1927000168__auto____5 = ifn_314.Invoke_O__O(arg_315) } else { and__1927000168__auto____5 = linked_313.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_312, arg_315) }; if jrt.J2g_Truth(and__1927000168__auto____5) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref() } else { return and__1927000168__auto____5 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_default_type_A_New() *A_arbace_go_check_types_default_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_default_type_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_go_check_types_default_type_A) Ctor() {}
//line :141:1
func (t *A_arbace_go_check_types_default_type_A) Invoke_O_O__O(self, t__0 any) any { var G__219000052__2_ any = t__0; switch


	lang.Util_Hash_O__I_NoInit(G__219000052__2_) >> 19 & 7 { case 0: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_49) { return A_arbace_go_check_types_A_const_38 }; case 1: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_43) { return A_arbace_go_check_types_A_const_14 }; case 3: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_48) { return A_arbace_go_check_types_A_const_35 }; case 5: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_46) { return A_arbace_go_check_types_A_const_25 }; case 6: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_50) { return A_arbace_go_check_types_A_const_40 }; case 7: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_47) { return A_arbace_go_check_types_A_const_21 }; default:}; return t__0 }




func A_arbace_go_check_types_ignore_tags_A_New() *A_arbace_go_check_types_ignore_tags_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ignore_tags_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_go_check_types_ignore_tags_A) Ctor() {}
//line :149:1
func (t *A_arbace_go_check_types_ignore_tags_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_317 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = t__0; if linked_318 == nil { and__1927000168__auto____2 = ifn_319.Invoke_O__O(arg_320) } else { and__1927000168__auto____2 = linked_318.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_317, arg_320) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_321 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any; var root_325 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = t__0; if linked_326 == nil { arg_324 = ifn_327.Invoke_O__O(arg_328) } else { arg_324 = linked_326.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_325, arg_328) }; if linked_322 == nil { and__1927000168__auto____3 = ifn_323.Invoke_O__O(arg_324) } else { and__1927000168__auto____3 = linked_322.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_321, arg_324) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_329 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any; var root_333 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = t__0; if linked_334 == nil { arg_332 = ifn_335.Invoke_O__O(arg_336) } else { arg_332 = linked_334.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_333, arg_336) }; if linked_330 == nil { tmp1 = ifn_331.Invoke_O__O(arg_332) } else { tmp1 = linked_330.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_329, arg_332) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var G__219000055__2_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))
		switch lang.Util_Hash_O__I_NoInit(G__219000055__2_) >> 2 & 15 { case 1: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_95) { var tmp2 any = A_arbace_go_check_types_A_const_95; var tmp3 any; var root_338 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_340 lang.IFn




			if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_339 == nil { tmp3 = ifn_340.Invoke_O__O(arg_341) } else { tmp3 = linked_339.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_338, arg_341) }
//line :153:1
			var tmp4 any = tmp3; var tmp5 any; var root_342 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_344 lang.IFn




			if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_343 == nil { tmp5 = ifn_344.Invoke_O__O(arg_345) } else { tmp5 = linked_343.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_342, arg_345) }
//line :153:1
			return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp4, tmp5) }; case 2: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_96) { var tmp6 any = A_arbace_go_check_types_A_const_96; var tmp7 any; var root_346 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_348 lang.IFn


				if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_347 == nil { tmp7 = ifn_348.Invoke_O__O(arg_349) } else { tmp7 = linked_347.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_346, arg_349) }
//line :153:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7) }; case 3: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_97) { var tmp8 any = A_arbace_go_check_types_A_const_97; var tmp9 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp10 any; var root_350 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_352 lang.IFn



					if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_351 == nil { tmp10 = ifn_352.Invoke_O__O(arg_353) } else { tmp10 = linked_351.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_350, arg_353) }
//line :153:1
					return lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp9, tmp10) }; case 6: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_98) { var tmp11 any = A_arbace_go_check_types_A_const_98; var tmp12 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp13 any; var root_368 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_370 lang.IFn





						if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_369 == nil { tmp13 = ifn_370.Invoke_O__O(arg_371) } else { tmp13 = linked_369.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_368, arg_371) }
//line :153:1
						return lang.Tuple_Create_O_O_O__IPersistentVector(tmp11, tmp12, tmp13) }; case 7: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_100) {







							var root_354 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = A_arbace_go_check_types_A_const_101; var arg_358 any; var root_359 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var arg_363 any; var root_364 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = t__0; if linked_365 == nil { arg_363 = ifn_366.Invoke_O__O(arg_367) } else { arg_363 = linked_365.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_364, arg_367) }; if linked_360 == nil { arg_358 = ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { arg_358 = linked_360.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_359, arg_362, arg_363) }; if linked_355 == nil { return ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { return linked_355.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) } }
//line :153:1
		case 9: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_103) { var tmp14 any = A_arbace_go_check_types_A_const_103; var tmp15 any; var root_372 any = A_arbace_go_check_types_A_const_104.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_374 lang.IFn






			if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var arg_376 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_373 == nil { tmp15 = ifn_374.Invoke_O_O__O(arg_375, arg_376) } else { tmp15 = linked_373.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_372, arg_375, arg_376) }
//line :153:1
			var tmp16 any = tmp15; var tmp17 any; var root_377 any = A_arbace_go_check_types_A_const_104.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_377, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_379 lang.IFn






			if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; var arg_380 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var arg_381 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_378 == nil { tmp17 = ifn_379.Invoke_O_O__O(arg_380, arg_381) } else { tmp17 = linked_378.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_377, arg_380, arg_381) }
//line :153:1
			return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp14, tmp16, tmp17, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(3))) }; case 11: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_87) { var tmp18 any = A_arbace_go_check_types_A_const_87; var tmp19 any; var root_382 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_384 lang.IFn

				if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_383 == nil { tmp19 = ifn_384.Invoke_O__O(arg_385) } else { tmp19 = linked_383.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_382, arg_385) }
//line :153:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp18, tmp19) }; case 13: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_105) { var tmp20 any = A_arbace_go_check_types_A_const_105; var tmp21 any; var root_386 any = A_arbace_go_check_types_A_const_104.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_388 lang.IFn
					if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any; var tmp22 any = A_arbace_go_check_types_ignore_tags_fn__219000056_A_New(); var tmp23 *jrt.Class; var fncls__403 *jrt.Class = A_arbace_go_check_types_ignore_tags_fn__219000056_A_fn_class; if fncls__403 == nil { var fncls__403d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_check_types_ignore_tags_fn__219000056_A_fn_class = fncls__403d; tmp23 = fncls__403d } else { tmp23 = fncls__403 }; arg_389 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_390 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_387 == nil { tmp21 = ifn_388.Invoke_O_O__O(arg_389, arg_390) } else { tmp21 = linked_387.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_386, arg_389, arg_390) }
//line :153:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp20, tmp21) }; default:}; return t__0 } else {
//line :152:1
						return t__0
					} }
func A_arbace_go_check_types_ignore_tags_fn__219000056_A_New() *A_arbace_go_check_types_ignore_tags_fn__219000056_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ignore_tags_fn__219000056_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_go_check_types_ignore_tags_fn__219000056_A) Ctor() {}
//line :154:1
func (t *A_arbace_go_check_types_ignore_tags_fn__219000056_A) Invoke_O_O__O(self, p1__219000054_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_59.GetRawRoot__O()); var tmp2 any = A_arbace_go_check_types_A_const_106; var tmp3 any = A_arbace_go_check_types_A_const_107; var tmp4 any; var root_399 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(p1__219000054_SHARP___1); if linked_400 == nil { tmp4 = ifn_401.Invoke_O__O(arg_402) } else { tmp4 = linked_400.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_399, arg_402) }; return tmp1.Invoke_O_O_O_O_O__O(p1__219000054_SHARP___1, tmp2, nil, tmp3, tmp4) }










func A_arbace_go_check_types_identical_ignore_tags_QMARK__A_New() *A_arbace_go_check_types_identical_ignore_tags_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_identical_ignore_tags_QMARK__A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_go_check_types_identical_ignore_tags_QMARK__A) Ctor() {}
//line :165:1
func (t *A_arbace_go_check_types_identical_ignore_tags_QMARK__A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 any; var root_404 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = x__0; if linked_405 == nil { tmp1 = ifn_406.Invoke_O__O(arg_407) } else { tmp1 = linked_405.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_404, arg_407) }; var tmp2 any = tmp1; var tmp3 any; var root_408 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = y__1; if linked_409 == nil { tmp3 = ifn_410.Invoke_O__O(arg_411) } else { tmp3 = linked_409.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_408, arg_411) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() }





func A_arbace_go_check_types_tset_comparable_QMARK__A_New() *A_arbace_go_check_types_tset_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_comparable_QMARK__A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__A) Ctor() {}
//line :171:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__A) Invoke_O_O_O__O(self, ts__0, seen__1 any) any {


	var tmp1 any = A_arbace_go_check_types_A_const_108; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0)) {
		return A_arbace_go_check_types_A_const_110.Invoke_O__O(ts__0) } else {
//line :174:1
			var and__1927000168__auto____3 any; var root_412 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_414 lang.IFn

			if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0); if linked_413 == nil { and__1927000168__auto____3 = ifn_414.Invoke_O__O(arg_415) } else { and__1927000168__auto____3 = linked_413.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_412, arg_415) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_416 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any; var tmp2 any = A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A_New_O(seen__1); var tmp3 *jrt.Class; var fncls__426 *jrt.Class = A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A_fn_class; if fncls__426 == nil { var fncls__426d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A_fn_class = fncls__426d; tmp3 = fncls__426d } else { tmp3 = fncls__426 }; arg_419 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_420 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0); if linked_417 == nil { return ifn_418.Invoke_O_O__O(arg_419, arg_420) } else { return linked_417.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_416, arg_419, arg_420) } } else { return and__1927000168__auto____3 } } }
//line :176:1
func A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A_New_O(p0 any) *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A{}; t.Ctor_O(p0); return t }
//line :176:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A) Ctor_O(c__seen any) { t.F_seen = c__seen }
//line :176:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A) Invoke_O_O__O(self, p__219000060__1 any) any { var vec__219000062__2 any = p__219000060__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000062__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000062__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_421 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_423 lang.IFn; _ = ___3; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = ty__4; var arg_425 any = t.F_seen; if linked_422 == nil { return ifn_423.Invoke_O_O__O(arg_424, arg_425) } else { return linked_422.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O_O__O(root_421, arg_424, arg_425) } }

func A_arbace_go_check_types_comparable_type_QMARK__A_New() *A_arbace_go_check_types_comparable_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_type_QMARK__A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__A) Ctor() {}
//line :178:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__A) Invoke_O_O_O_O__O(self, t__0, dynamic__1, seen__2 any) any {




	var tmp1 any; var root_427 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = seen__2; var arg_431 any = t__0; if linked_428 == nil { tmp1 = ifn_429.Invoke_O_O__O(arg_430, arg_431) } else { tmp1 = linked_428.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_427, arg_430, arg_431) }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var seen__4 any; var root_432 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_434 lang.IFn

		if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = seen__2; var arg_436 any = t__0; if linked_433 == nil { seen__4 = ifn_434.Invoke_O_O__O(arg_435, arg_436) } else { seen__4 = linked_433.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_432, arg_435, arg_436) }
		var tmp2 any; var root_437 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = t__0; if linked_438 == nil { tmp2 = ifn_439.Invoke_O__O(arg_440) } else { tmp2 = linked_438.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_437, arg_440) }; if jrt.J2g_Truth(tmp2) {
			var tmp3 any; var root_441 any = A_arbace_go_check_types_A_const_114.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any; var root_446 any = A_arbace_go_check_types_A_const_115.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = t__0; if linked_447 == nil { arg_444 = ifn_448.Invoke_O__O(arg_449) } else { arg_444 = linked_447.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_446, arg_449) }; var arg_445 any = seen__4; if linked_442 == nil { tmp3 = ifn_443.Invoke_O_O__O(arg_444, arg_445) } else { tmp3 = linked_442.(*A_arbace_go_check_types_tset_comparable_QMARK__A).Invoke_O_O_O__O(root_441, arg_444, arg_445) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp3)).Ref() } else {
//line :186:1
				var u__5 any; var root_450 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, A_arbace_go_check_types_under_A_fn_class); var ifn_452 lang.IFn

				if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = t__0; if linked_451 == nil { u__5 = ifn_452.Invoke_O__O(arg_453) } else { u__5 = linked_451.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_450, arg_453) }
				var tmp4 any; var root_454 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_456 lang.IFn
				if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = u__5; if linked_455 == nil { tmp4 = ifn_456.Invoke_O__O(arg_457) } else { tmp4 = linked_455.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_454, arg_457) }
//line :189:1
				if jrt.J2g_Truth(tmp4) {
					var root_458 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = u__5; var arg_462 any = A_arbace_go_check_types_A_const_51; if linked_459 == nil { return ifn_460.Invoke_O_O__O(arg_461, arg_462) } else { return linked_459.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_458, arg_461, arg_462) } } else {
//line :189:1
						if A_arbace_go_check_types_A_const_75 != nil { var G__219000068__6_ any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(0))


							switch lang.Util_Hash_O__I_NoInit(G__219000068__6_) >> 4 & 7 { case 0: if any(G__219000068__6_) == any(A_arbace_go_check_types_A_const_97) {



								var root_464 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(2)); var arg_468 any = dynamic__1; var arg_469 any = seen__4; if linked_465 == nil { return ifn_466.Invoke_O_O_O__O(arg_467, arg_468, arg_469) } else { return linked_465.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_464, arg_467, arg_468, arg_469) } }
//line :192:1
							case 1: if any(G__219000068__6_) == any(A_arbace_go_check_types_A_const_98) { return jrt.Boolean_TRUE.Ref() }; case 3: if any(G__219000068__6_) == any(A_arbace_go_check_types_A_const_86) { var or__1927000174__auto____7 any = dynamic__1

								if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var tmp5 any; var root_470 any = A_arbace_go_check_types_A_const_114.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any; var root_475 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = u__5; if linked_476 == nil { arg_473 = ifn_477.Invoke_O__O(arg_478) } else { arg_473 = linked_476.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_475, arg_478) }; var arg_474 any = seen__4; if linked_471 == nil { tmp5 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { tmp5 = linked_471.(*A_arbace_go_check_types_tset_comparable_QMARK__A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp5)).Ref() } }
//line :192:1
							case 6: if any(G__219000068__6_) == any(A_arbace_go_check_types_A_const_87) { return jrt.Boolean_TRUE.Ref() }; case 7: if any(G__219000068__6_) == any(A_arbace_go_check_types_A_const_105) {


								var root_479 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any; var tmp6 any = A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A_New_O_O(seen__4, dynamic__1); var tmp7 *jrt.Class; var fncls__490 *jrt.Class = A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A_fn_class; if fncls__490 == nil { var fncls__490d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A_fn_class = fncls__490d; tmp7 = fncls__490d } else { tmp7 = fncls__490 }; arg_482 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_483 any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(1)); if linked_480 == nil { return ifn_481.Invoke_O_O__O(arg_482, arg_483) } else { return linked_480.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_479, arg_482, arg_483) } }
//line :192:1
							default:}; return jrt.Boolean_FALSE.Ref() } else {
//line :189:1
								return nil
							}
					}
			}
	}
}
func A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A{}; t.Ctor_O_O(p0, p1); return t }
//line :195:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A) Ctor_O_O(c__seen, c__dynamic any) { t.F_seen = c__seen; t.F_dynamic = c__dynamic }
//line :195:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A) Invoke_O_O__O(self, p1__219000067_SHARP___1 any) any { var root_484 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(p1__219000067_SHARP___1); var arg_488 any = t.F_dynamic; var arg_489 any = t.F_seen; if linked_485 == nil { return ifn_486.Invoke_O_O_O__O(arg_487, arg_488, arg_489) } else { return linked_485.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_484, arg_487, arg_488, arg_489) } }



func A_arbace_go_check_types_strictly_comparable_QMARK__A_New() *A_arbace_go_check_types_strictly_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_strictly_comparable_QMARK__A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Ctor() {}
//line :199:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Invoke_O_O_O__O(self, t__0, seen__1 any) any { var root_491 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = t__0; var arg_495 any = jrt.Boolean_FALSE.Ref(); var arg_496 any = seen__1; if linked_492 == nil { return ifn_493.Invoke_O_O_O__O(arg_494, arg_495, arg_496) } else { return linked_492.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_491, arg_494, arg_495, arg_496) } }
//line :199:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_497 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = t__0; var arg_501 any = jrt.Boolean_FALSE.Ref(); var arg_502 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_498 == nil { return ifn_499.Invoke_O_O_O__O(arg_500, arg_501, arg_502) } else { return linked_498.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_497, arg_500, arg_501, arg_502) } }

func A_arbace_go_check_types_incomparable_cause_A_New() *A_arbace_go_check_types_incomparable_cause_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_incomparable_cause_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_go_check_types_incomparable_cause_A) Ctor() {}
//line :201:1
func (t *A_arbace_go_check_types_incomparable_cause_A) Invoke_O_O__O(self, t__0 any) any { var body_cause__2 *A_arbace_go_check_types_incomparable_cause_cause__219000073_A = A_arbace_go_check_types_incomparable_cause_cause__219000073_A_New(); var cause__2 any; var tmp1 *jrt.Class; var fncls__549 *jrt.Class = A_arbace_go_check_types_incomparable_cause_cause__219000073_A_fn_class; if fncls__549 == nil { var fncls__549d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_go_check_types_incomparable_cause_cause__219000073_A_fn_class = fncls__549d; tmp1 = fncls__549d } else { tmp1 = fncls__549 }; cause__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_cause__2), tmp1, nil); var or__1927000174__auto____3 any = lang.IFn_Cast(cause__2).Invoke_O_O__O(t__0, lang.PersistentHashSet_EMPTY.Ref()); if




















	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { return Lit_8 } }
//line :205:1
func A_arbace_go_check_types_incomparable_cause_cause__219000073_A_New() *A_arbace_go_check_types_incomparable_cause_cause__219000073_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_incomparable_cause_cause__219000073_A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000073_A) Ctor() {}
//line :205:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000073_A) Invoke_O_O_O__O(self, t__1, seen__2 any) any {
	var tmp1 any; var root_503 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = seen__2; var arg_507 any = t__1; if linked_504 == nil { tmp1 = ifn_505.Invoke_O_O__O(arg_506, arg_507) } else { tmp1 = linked_504.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_503, arg_506, arg_507) }; if jrt.J2g_Truth(tmp1) { return nil } else { var seen__3 any; var root_508 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_510 lang.IFn

		if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = seen__2; var arg_512 any = t__1; if linked_509 == nil { seen__3 = ifn_510.Invoke_O_O__O(arg_511, arg_512) } else { seen__3 = linked_509.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_508, arg_511, arg_512) }
		var tmp2 any; var root_513 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_515 lang.IFn; if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any = t__1; if linked_514 == nil { tmp2 = ifn_515.Invoke_O__O(arg_516) } else { tmp2 = linked_514.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_513, arg_516) }; if jrt.J2g_Truth(tmp2) {
			var tmp3 any; var root_517 any = A_arbace_go_check_types_A_const_114.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any; var root_522 any = A_arbace_go_check_types_A_const_115.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = t__1; if linked_523 == nil { arg_520 = ifn_524.Invoke_O__O(arg_525) } else { arg_520 = linked_523.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_522, arg_525) }; var arg_521 any = seen__3; if linked_518 == nil { tmp3 = ifn_519.Invoke_O_O__O(arg_520, arg_521) } else { tmp3 = linked_518.(*A_arbace_go_check_types_tset_comparable_QMARK__A).Invoke_O_O_O__O(root_517, arg_520, arg_521) }; if jrt.J2g_Truth(tmp3) { return nil } else { return Lit_8 } } else {
//line :209:1
				var u__4 any; var root_526 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_526, A_arbace_go_check_types_under_A_fn_class); var ifn_528 lang.IFn

				if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any = t__1; if linked_527 == nil { u__4 = ifn_528.Invoke_O__O(arg_529) } else { u__4 = linked_527.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_526, arg_529) }
				var tmp4 any; var root_530 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_532 lang.IFn
				if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = u__4; if linked_531 == nil { tmp4 = ifn_532.Invoke_O__O(arg_533) } else { tmp4 = linked_531.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_530, arg_533) }
//line :212:1
				if jrt.J2g_Truth(tmp4) {
					if lang.Util_Equiv_O_O__Z_NoInit(u__4, A_arbace_go_check_types_A_const_51) { return Lit_8 } else { return nil } } else {
//line :212:1
						if A_arbace_go_check_types_A_const_75 != nil { var G__219000074__5_ any = lang.RT_Nth_O_I__O_NoInit(u__4, lang.RT_IntCast_J__I_NoInit(0))


							switch lang.Util_Hash_O__I_NoInit(G__219000074__5_) >> 4 & 7 { case 0: if any(G__219000074__5_) == any(A_arbace_go_check_types_A_const_97) {




								if jrt.J2g_Truth(lang.IFn_Cast(self).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(u__4, lang.RT_IntCast_J__I_NoInit(2)), seen__3)) { var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_15); var tmp6 any; var root_535 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, A_arbace_go_check_types_type_str_A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = t__1; if linked_536 == nil { tmp6 = ifn_537.Invoke_O__O(arg_538) } else { tmp6 = linked_536.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_535, arg_538) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil)).Ref() } else { return nil } }
//line :215:1
							case 1: if any(G__219000074__5_) == any(A_arbace_go_check_types_A_const_98) { return nil }; case 3: if any(G__219000074__5_) == any(A_arbace_go_check_types_A_const_86) { return nil }; case 6: if any(G__219000074__5_) == any(A_arbace_go_check_types_A_const_87) { return nil }; case 7: if any(G__219000074__5_) == any(A_arbace_go_check_types_A_const_105) {

								var root_539 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any; var tmp7 any = A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A_New_O_O(self, seen__3); var tmp8 *jrt.Class; var fncls__548 *jrt.Class = A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A_fn_class; if fncls__548 == nil { var fncls__548d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A_fn_class = fncls__548d; tmp8 = fncls__548d } else { tmp8 = fncls__548 }; arg_542 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_543 any = lang.RT_Nth_O_I__O_NoInit(u__4, lang.RT_IntCast_J__I_NoInit(1)); if linked_540 == nil { return ifn_541.Invoke_O_O__O(arg_542, arg_543) } else { return linked_540.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_539, arg_542, arg_543) } }
//line :215:1
							default:}; return Lit_8 } else {
//line :212:1
								return nil
							}
					}
			}
	} }
func A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A{}; t.Ctor_O_O(p0, p1); return t }
//line :217:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A) Ctor_O_O(c__cause, c__seen any) { t.F_cause = c__cause; t.F_seen = c__seen }
//line :217:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A) Invoke_O_O__O(self, fd__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_cause); if jrt.J2g_Truth(tmp1.Invoke_O_O__O(A_arbace_go_check_types_A_const_107.Invoke_O__O(fd__1), t.F_seen)) {
																var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_17, nil, Lit_15); var tmp3 any; var root_544 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, A_arbace_go_check_types_type_str_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(fd__1); if linked_545 == nil { tmp3 = ifn_546.Invoke_O__O(arg_547) } else { tmp3 = linked_545.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_544, arg_547) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref() } else {
//line :217:1
		return nil } }






func A_arbace_go_check_types_comparable_QMARK__A_New() *A_arbace_go_check_types_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_QMARK__A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Ctor() {}
//line :224:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Invoke_O_O_O__O(self, t__0, seen__1 any) any {



	var root_550 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = t__0; var arg_554 any = jrt.Boolean_TRUE.Ref(); var arg_555 any = seen__1; if linked_551 == nil { return ifn_552.Invoke_O_O_O__O(arg_553, arg_554, arg_555) } else { return linked_551.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_550, arg_553, arg_554, arg_555) } }
//line :224:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Invoke_O_O__O(self, t__0 any) any {


	var root_556 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = t__0; var arg_560 any = jrt.Boolean_TRUE.Ref(); var arg_561 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_557 == nil { return ifn_558.Invoke_O_O_O__O(arg_559, arg_560, arg_561) } else { return linked_557.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_556, arg_559, arg_560, arg_561)
	}
}











func A_arbace_go_check_types_union_QMARK__A_New() *A_arbace_go_check_types_union_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_union_QMARK__A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_go_check_types_union_QMARK__A) Ctor() {}
//line :241:1
func (t *A_arbace_go_check_types_union_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_562 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = t__0; if linked_563 == nil { and__1927000168__auto____2 = ifn_564.Invoke_O__O(arg_565) } else { and__1927000168__auto____2 = linked_563.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_562, arg_565) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_120; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_go_check_types_term_disjoint_QMARK__A_New() *A_arbace_go_check_types_term_disjoint_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_disjoint_QMARK__A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_go_check_types_term_disjoint_QMARK__A) Ctor() {}
//line :243:1
func (t *A_arbace_go_check_types_term_disjoint_QMARK__A) Invoke_O_O_O__O(self, p__219000081__0, p__219000082__1 any) any { var vec__219000083__3 any = p__219000081__0; var xt__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000083__3, lang.RT_IntCast_J__I_NoInit(0), nil); var x__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000083__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__219000086__6 any = p__219000082__1; var yt__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000086__6, lang.RT_IntCast_J__I_NoInit(0), nil); var y__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000086__6, lang.RT_IntCast_J__I_NoInit(1), nil); var root_566 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_568 lang.IFn; if
																linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any; if jrt.J2g_Truth(yt__7) { var root_571 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, A_arbace_go_check_types_under_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = x__5; if linked_572 == nil { arg_569 = ifn_573.Invoke_O__O(arg_574) } else { arg_569 = linked_572.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_571, arg_574) } } else { arg_569 = x__5 }; var arg_570 any; if jrt.J2g_Truth(xt__4) { var root_575 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, A_arbace_go_check_types_under_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = y__8; if linked_576 == nil { arg_570 = ifn_577.Invoke_O__O(arg_578) } else { arg_570 = linked_576.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_575, arg_578) } } else { arg_570 = y__8 }; if linked_567 == nil { return ifn_568.Invoke_O_O__O(arg_569, arg_570) } else { return linked_567.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_566, arg_569, arg_570) } }

func A_arbace_go_check_types_term_union_A_New() *A_arbace_go_check_types_term_union_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_union_A{}; t.Ctor(); return t }
//line :246:1
func (t *A_arbace_go_check_types_term_union_A) Ctor() {}
//line :246:1
func (t *A_arbace_go_check_types_term_union_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	var tmp1 any; var root_579 any = A_arbace_go_check_types_A_const_121.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_581 lang.IFn
	if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = x__0; var arg_583 any = y__1; if linked_580 == nil { tmp1 = ifn_581.Invoke_O_O__O(arg_582, arg_583) } else { tmp1 = linked_580.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_579, arg_582, arg_583) }
//line :247:1
	if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(x__0, y__1) } else { var tmp2 any; var or__1927000174__auto____3 any; var root_584 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_586 lang.IFn

		if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = x__0; if linked_585 == nil { or__1927000174__auto____3 = ifn_586.Invoke_O__O(arg_587) } else { or__1927000174__auto____3 = linked_585.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_584, arg_587) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_588 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any; var root_592 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = y__1; if linked_593 == nil { arg_591 = ifn_594.Invoke_O__O(arg_595) } else { arg_591 = linked_593.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_592, arg_595) }; if linked_589 == nil { tmp2 = ifn_590.Invoke_O__O(arg_591) } else { tmp2 = linked_589.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_588, arg_591) } }
//line :247:1
		if jrt.J2g_Truth(tmp2) { return lang.Tuple_Create_O__IPersistentVector(x__0) } else { if A_arbace_go_check_types_A_const_75 != nil { return lang.Tuple_Create_O__IPersistentVector(y__1) } else { return nil
		}
		}
	}
}
func A_arbace_go_check_types_term_intersect_A_New() *A_arbace_go_check_types_term_intersect_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_intersect_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_go_check_types_term_intersect_A) Ctor() {}
//line :252:1
func (t *A_arbace_go_check_types_term_intersect_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	var tmp1 any; var root_596 any = A_arbace_go_check_types_A_const_121.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_598 lang.IFn
	if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = x__0; var arg_600 any = y__1; if linked_597 == nil { tmp1 = ifn_598.Invoke_O_O__O(arg_599, arg_600) } else { tmp1 = linked_597.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_596, arg_599, arg_600) }
//line :253:1
	if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; var or__1927000174__auto____3 any; var root_601 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_603 lang.IFn

		if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any; var root_605 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = x__0; if linked_606 == nil { arg_604 = ifn_607.Invoke_O__O(arg_608) } else { arg_604 = linked_606.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_605, arg_608) }; if linked_602 == nil { or__1927000174__auto____3 = ifn_603.Invoke_O__O(arg_604) } else { or__1927000174__auto____3 = linked_602.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_601, arg_604) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_609 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = y__1; if linked_610 == nil { tmp2 = ifn_611.Invoke_O__O(arg_612) } else { tmp2 = linked_610.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_609, arg_612) } }
//line :253:1
		if jrt.J2g_Truth(tmp2) { return x__0 } else { if A_arbace_go_check_types_A_const_75 != nil { return y__1 } else { return nil
		}
		}
	}
}
func A_arbace_go_check_types_term_includes_QMARK__A_New() *A_arbace_go_check_types_term_includes_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_includes_QMARK__A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_go_check_types_term_includes_QMARK__A) Ctor() {}
//line :258:1
func (t *A_arbace_go_check_types_term_includes_QMARK__A) Invoke_O_O_O__O(self, p__219000092__0, t__1 any) any { var vec__219000093__3 any = p__219000092__0; var tilde__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000093__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000093__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; if jrt.J2g_Truth(tilde__4) { var root_613 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_613, A_arbace_go_check_types_under_A_fn_class); var ifn_615 lang.IFn; if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any = t__1; if linked_614 == nil { tmp1 = ifn_615.Invoke_O__O(arg_616) } else { tmp1 = linked_614.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_613, arg_616) } } else { tmp1 = t__1 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(ty__5, tmp1)).Ref() }

func A_arbace_go_check_types_term_subset_QMARK__A_New() *A_arbace_go_check_types_term_subset_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_subset_QMARK__A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_go_check_types_term_subset_QMARK__A) Ctor() {}
//line :260:1
func (t *A_arbace_go_check_types_term_subset_QMARK__A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var and__1927000168__auto____3 any; var root_617 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any; var root_621 any = A_arbace_go_check_types_A_const_121.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = x__0; var arg_625 any = y__1; if linked_622 == nil { arg_620 = ifn_623.Invoke_O_O__O(arg_624, arg_625) } else { arg_620 = linked_622.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_621, arg_624, arg_625) }; if linked_618 == nil { and__1927000168__auto____3 = ifn_619.Invoke_O__O(arg_620) } else { and__1927000168__auto____3 = linked_618.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_617, arg_620) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var root_626 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any; var root_630 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = x__0; if linked_631 == nil { arg_629 = ifn_632.Invoke_O__O(arg_633) } else { arg_629 = linked_631.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_630, arg_633) }; if linked_627 == nil { or__1927000174__auto____4 = ifn_628.Invoke_O__O(arg_629) } else { or__1927000174__auto____4 = linked_627.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_626, arg_629) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var root_634 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = y__1; if linked_635 == nil { return ifn_636.Invoke_O__O(arg_637) } else { return linked_635.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_634, arg_637) } } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_terms_norm_A_New() *A_arbace_go_check_types_terms_norm_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_norm_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_go_check_types_terms_norm_A) Ctor() {}
//line :262:1
func (t *A_arbace_go_check_types_terms_norm_A) Invoke_O_O__O(self, ts__0 any) any { { var ts__2 any; var root_638 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_640 lang.IFn


	if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = ts__0; if linked_639 == nil { ts__2 = ifn_640.Invoke_O__O(arg_641) } else { ts__2 = linked_639.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_638, arg_641) }
//line :262:1
	var n__3 int32 = lang.RT_Count_O__I_NoInit(ts__2); var used__4 any = lang.Numbers_Boolean_array_O__Z1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref()).Ref(); var i__5 int64 = 0; var rl__6 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




		if lang.Util_Equiv_J_J__Z_NoInit(i__5, int64(n__3)) {

			var root_642 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any; var root_647 any = A_arbace_go_check_types_A_const_125.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = rl__6; if linked_648 == nil { arg_645 = ifn_649.Invoke_O__O(arg_650) } else { arg_645 = linked_648.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_647, arg_650) }; var arg_646 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_126, rl__6)); if linked_643 == nil { return ifn_644.Invoke_O_O__O(arg_645, arg_646) } else { return linked_643.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_642, arg_645, arg_646) } } else {
				if lang.RT_Aget_Z1_I__Z_NoInit(jrt.J2g_CastArray[*jrt.BooleanArray](used__4, jrt.Prim_boolean.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__5)) {
					i__5, rl__6 = lang.Numbers_Inc_J__J_NoInit(i__5), rl__6; continue L1 } else {
//line :270:1
						var xi__7 any; var tmp1 any = A_arbace_go_check_types_terms_norm_fn__219000098_A_New_J_I_O_O(i__5, n__3, used__4, ts__2); var tmp2 *jrt.Class
						var fncls__660 /*line :270:1*/*jrt.Class = A_arbace_go_check_types_terms_norm_fn__219000098_A_fn_class

						if fncls__660 == nil { var fncls__660d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_go_check_types_terms_norm_fn__219000098_A_fn_class = fncls__660d; tmp2 = fncls__660d } else { tmp2 = fncls__660 }; xi__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()







						var tmp3 int64 = lang.Numbers_Inc_J__J_NoInit(i__5); var tmp4 any; var root_661 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = rl__6; var arg_665 any = xi__7; if linked_662 == nil { tmp4 = ifn_663.Invoke_O_O__O(arg_664, arg_665) } else { tmp4 = linked_662.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_661, arg_664, arg_665) }; i__5, rl__6 = tmp3, tmp4; continue L1 } } } }; /*line :262:1*/panic("j2g: unreachable") }









func A_arbace_go_check_types_terms_norm_fn__219000098_A_New_J_I_O_O(p0 int64, p1 int32, p2, p3 any) *A_arbace_go_check_types_terms_norm_fn__219000098_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_norm_fn__219000098_A{}; t.Ctor_J_I_O_O(p0, p1, p2, p3); return t }
//line :272:1
func (t *A_arbace_go_check_types_terms_norm_fn__219000098_A) Ctor_J_I_O_O(c__i int64, c__n int32, c__used, c__ts any) { t.F_i = c__i; t.F_n = c__n; t.F_used = c__used; t.F_ts = c__ts }
//line :272:1
func (t *A_arbace_go_check_types_terms_norm_fn__219000098_A) Invoke_O__O(self any) any { { var j__1 int64 = lang.Numbers_Inc_J__J_NoInit(t.F_i); var tmp1 any = t.F_ts; var xi__2 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(t.F_i)); L1: for {
											if lang.Util_Equiv_J_J__Z_NoInit(j__1, int64(t.F_n)) { return xi__2 } else { var tmp2 *jrt.BooleanArray = jrt.J2g_CastArray[*jrt.BooleanArray](t.F_used, jrt.Prim_boolean.ArrayClass()); if lang.RT_Aget_Z1_I__Z_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(j__1)) {

		j__1, xi__2 = lang.Numbers_Inc_J__J_NoInit(j__1), xi__2; continue L1 } else {
//line :273:1
			if A_arbace_go_check_types_A_const_75 != nil { var u__3 any; var root_651 any = A_arbace_go_check_types_A_const_127.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, A_arbace_go_check_types_term_union_A_fn_class); var ifn_653 lang.IFn


				if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = xi__2; var tmp3 any = t.F_ts; var arg_655 any = lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(j__1)); if linked_652 == nil { u__3 = ifn_653.Invoke_O_O__O(arg_654, arg_655) } else { u__3 = linked_652.(*A_arbace_go_check_types_term_union_A).Invoke_O_O_O__O(root_651, arg_654, arg_655) }
				if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(u__3))) {
					var tmp4 *jrt.BooleanArray = jrt.J2g_CastArray[*jrt.BooleanArray](t.F_used, jrt.Prim_boolean.ArrayClass()); jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_Aset_Z1_I_Z__Z_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(j__1), jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z())); var tmp5 int64 = lang.Numbers_Inc_J__J_NoInit(j__1); var tmp6 any; var root_656 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = u__3; if linked_657 == nil { tmp6 = ifn_658.Invoke_O__O(arg_659) } else { tmp6 = linked_657.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_656, arg_659) }; j__1, xi__2 = tmp5, tmp6; continue L1 } else {
						j__1, xi__2 = lang.Numbers_Inc_J__J_NoInit(j__1), xi__2; continue L1 } } else {
//line :273:1
							return nil } } } } }; /*line :272:1*/panic("j2g: unreachable") }









func A_arbace_go_check_types_ordered_A_New() *A_arbace_go_check_types_ordered_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ordered_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_go_check_types_ordered_A) Ctor() {}
//line :282:1
func (t *A_arbace_go_check_types_ordered_A) Invoke_O_O__O(self, ts__0 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_types_A_const_126; var or__1927000174__auto____2 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(ts__0)); if


	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_666 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any = ts__0; if linked_667 == nil { return ifn_668.Invoke_O__O(arg_669) } else { return linked_667.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_666, arg_669) } } }

func A_arbace_go_check_types_terms_union_A_New() *A_arbace_go_check_types_terms_union_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_union_A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_go_check_types_terms_union_A) Ctor() {}
//line :287:1
func (t *A_arbace_go_check_types_terms_union_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, x__0); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, y__1) }; if tmp1 { return A_arbace_go_check_types_A_const_108 } else { var root_670 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, A_arbace_go_check_types_terms_norm_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any; var root_674 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any; var root_679 any = A_arbace_go_check_types_A_const_130.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, A_arbace_go_check_types_ordered_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = x__0; if linked_680 == nil { arg_677 = ifn_681.Invoke_O__O(arg_682) } else { arg_677 = linked_680.(*A_arbace_go_check_types_ordered_A).Invoke_O_O__O(root_679, arg_682) }; var arg_678 any; var root_683 any = A_arbace_go_check_types_A_const_130.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, A_arbace_go_check_types_ordered_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = y__1; if linked_684 == nil { arg_678 = ifn_685.Invoke_O__O(arg_686) } else { arg_678 = linked_684.(*A_arbace_go_check_types_ordered_A).Invoke_O_O__O(root_683, arg_686) }; if linked_675 == nil { arg_673 = ifn_676.Invoke_O_O__O(arg_677, arg_678) } else { arg_673 = linked_675.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_674, arg_677, arg_678) }; if linked_671 == nil { return ifn_672.Invoke_O__O(arg_673) } else { return linked_671.(*A_arbace_go_check_types_terms_norm_A).Invoke_O_O__O(root_670, arg_673) } } }

func A_arbace_go_check_types_terms_intersect_A_New() *A_arbace_go_check_types_terms_intersect_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_A{}; t.Ctor(); return t }
//line :289:1
func (t *A_arbace_go_check_types_terms_intersect_A) Ctor() {}
//line :289:1
func (t *A_arbace_go_check_types_terms_intersect_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, x__0) { return y__1 } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, y__1) { return x__0 } else { var tmp1 any; var or__1927000174__auto____3 any; var root_687 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_689 lang.IFn


		if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = x__0; if linked_688 == nil { or__1927000174__auto____3 = ifn_689.Invoke_O__O(arg_690) } else { or__1927000174__auto____3 = linked_688.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_687, arg_690) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_691 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = y__1; if linked_692 == nil { tmp1 = ifn_693.Invoke_O__O(arg_694) } else { tmp1 = linked_692.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_691, arg_694) } }
//line :290:1
		if jrt.J2g_Truth(tmp1) { return lang.PersistentHashSet_EMPTY.Ref() } else { if A_arbace_go_check_types_A_const_75 != nil {



			var root_695 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, A_arbace_go_check_types_terms_norm_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any; var iter__1927001039__auto____3 any; var tmp2 any = A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_A_New_O(y__1); var tmp3 *jrt.Class; var fncls__802 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_A_fn_class; if fncls__802 == nil { var fncls__802d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_A_fn_class = fncls__802d; tmp3 = fncls__802d } else { tmp3 = fncls__802 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp5 any; var root_803 any = A_arbace_go_check_types_A_const_130.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, A_arbace_go_check_types_ordered_A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = x__0; if linked_804 == nil { tmp5 = ifn_805.Invoke_O__O(arg_806) } else { tmp5 = linked_804.(*A_arbace_go_check_types_ordered_A).Invoke_O_O__O(root_803, arg_806) }; arg_698 = tmp4.Invoke_O__O(tmp5); if linked_696 == nil { return ifn_697.Invoke_O__O(arg_698) } else { return linked_696.(*A_arbace_go_check_types_terms_norm_A).Invoke_O_O__O(root_695, arg_698) } } else {
//line :290:1
				return nil
			}
		}
	} } }
func A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_A_New_O(p0 any) *A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_A{}; t.Ctor_O(p0); return t }
//line :294:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_A) Ctor_O(c__y any) { t.F_y = c__y }
//line :294:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_A) Invoke_O_O__O(self, s__219000104__1 any) any { var tmp1 any = A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_A_New_O_O_O(self, s__219000104__1, t.F_y); var tmp2 *jrt.Class; var fncls__801 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_A_fn_class; if fncls__801 == nil { var fncls__801d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_A_fn_class = fncls__801d; tmp2 = fncls__801d } else { tmp2 = fncls__801 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :294:1
func A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :294:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_A) Ctor_O_O_O(c__iter__219000103, c__s__219000104, c__y any) { t.F_iter__219000103 = c__iter__219000103; t.F_s__219000104 = c__s__219000104; t.F_y = c__y }
//line :294:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_A) Invoke_O__O(self any) any { { var s__219000104__1 any; var t_ any = t.F_s__219000104; t.F_s__219000104 = nil; s__219000104__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_699 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any = s__219000104__1; if linked_700 == nil { temp__1927000414__auto____2 = ifn_701.Invoke_O__O(arg_702) } else { temp__1927000414__auto____2 = linked_700.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_699, arg_702) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var a__4 any; var root_703 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = xs__1927001018__auto____3; if linked_704 == nil { a__4 = ifn_705.Invoke_O__O(arg_706) } else { a__4 = linked_704.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_703, arg_706) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_A_New_O(a__4); var tmp2 *jrt.Class; var fncls__779 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_A_fn_class; if fncls__779 == nil { var fncls__779d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_A_fn_class = fncls__779d; tmp2 = fncls__779d } else { tmp2 = fncls__779 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_780 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_784 any = A_arbace_go_check_types_A_const_130.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_784, A_arbace_go_check_types_ordered_A_fn_class); var ifn_786 lang.IFn; if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any = t.F_y; if linked_785 == nil { tmp4 = ifn_786.Invoke_O__O(arg_787) } else { tmp4 = linked_785.(*A_arbace_go_check_types_ordered_A).Invoke_O_O__O(root_784, arg_787) }; arg_783 = tmp3.Invoke_O__O(tmp4); if linked_781 == nil { fs__1927001036__auto____6 = ifn_782.Invoke_O__O(arg_783) } else { fs__1927001036__auto____6 = linked_781.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_780, arg_783) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_788 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_789 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_788, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_790 lang.IFn; if linked_789 == nil { ifn_790 = lang.IFn_Cast(root_788) } else { ifn_790 = nil }; var arg_791 any = fs__1927001036__auto____6; var arg_792 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__219000103); var tmp6 any; var root_793 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_795 lang.IFn; if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = s__219000104__1; if linked_794 == nil { tmp6 = ifn_795.Invoke_O__O(arg_796) } else { tmp6 = linked_794.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_793, arg_796) }; arg_792 = tmp5.Invoke_O__O(tmp6); if linked_789 == nil { return ifn_790.Invoke_O_O__O(arg_791, arg_792) } else { return linked_789.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_788, arg_791, arg_792) } } else { var tmp7 any; var root_797 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_799 lang.IFn; if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = s__219000104__1; if linked_798 == nil { tmp7 = ifn_799.Invoke_O__O(arg_800) } else { tmp7 = linked_798.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_797, arg_800) }; s__219000104__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :294:1
func A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_A_New_O(p0 any) *A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_A{}; t.Ctor_O(p0); return t }
//line :294:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_A) Ctor_O(c__a any) { t.F_a = c__a }
//line :294:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_A) Invoke_O_O__O(self, s__219000106__1 any) any { var tmp1 any = A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_A_New_O_O_O(self, s__219000106__1, t.F_a); var tmp2 *jrt.Class; var fncls__778 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_A_fn_class; if fncls__778 == nil { var fncls__778d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_A_fn_class = fncls__778d; tmp2 = fncls__778d } else { tmp2 = fncls__778 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :294:1
func A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :294:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_A) Ctor_O_O_O(c__iter__219000105, c__s__219000106, c__a any) { t.F_iter__219000105 = c__iter__219000105; t.F_s__219000106 = c__s__219000106; t.F_a = c__a }
//line :294:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_A) Invoke_O__O(self any) any { { var s__219000106__1 any; var t_ any = t.F_s__219000106; t.F_s__219000106 = nil; s__219000106__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_707 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = s__219000106__1; if linked_708 == nil { temp__1927000414__auto____2 = ifn_709.Invoke_O__O(arg_710) } else { temp__1927000414__auto____2 = linked_708.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_707, arg_710) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000106__3 any = temp__1927000414__auto____2; var tmp1 any; var root_711 any = A_arbace_go_check_types_A_const_131.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = s__219000106__3; if linked_712 == nil { tmp1 = ifn_713.Invoke_O__O(arg_714) } else { tmp1 = linked_712.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_711, arg_714) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_715 any = A_arbace_go_check_types_A_const_132.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = s__219000106__3; if linked_716 == nil { c__1927001037__auto____4 = ifn_717.Invoke_O__O(arg_718) } else { c__1927001037__auto____4 = linked_716.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_715, arg_718) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000108__6 any; var root_719 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_720 == nil { b__219000108__6 = ifn_721.Invoke_O__O(arg_722) } else { b__219000108__6 = linked_720.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_719, arg_722) }; var tmp2 any = A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_fn__219000113_A_New_O_I_O_O(b__219000108__6, size__1927001038__auto____5, t.F_a, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__733 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_fn__219000113_A_fn_class; if fncls__733 == nil { var fncls__733d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_fn__219000113_A_fn_class = fncls__733d; tmp3 = fncls__733d } else { tmp3 = fncls__733 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_734 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any; var root_739 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_741 lang.IFn; if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any = b__219000108__6; if linked_740 == nil { arg_737 = ifn_741.Invoke_O__O(arg_742) } else { arg_737 = linked_740.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_739, arg_742) }; var arg_738 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000105); var tmp5 any; var root_743 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = s__219000106__3; if linked_744 == nil { tmp5 = ifn_745.Invoke_O__O(arg_746) } else { tmp5 = linked_744.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_743, arg_746) }; arg_738 = tmp4.Invoke_O__O(tmp5); if linked_735 == nil { return ifn_736.Invoke_O_O__O(arg_737, arg_738) } else { return linked_735.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_734, arg_737, arg_738) } } else { var root_747 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any; var root_752 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = b__219000108__6; if linked_753 == nil { arg_750 = ifn_754.Invoke_O__O(arg_755) } else { arg_750 = linked_753.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_752, arg_755) }; var arg_751 any; if linked_748 == nil { return ifn_749.Invoke_O_O__O(arg_750, arg_751) } else { return linked_748.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_747, arg_750, arg_751) } } } else { var b__4 any; var root_756 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = s__219000106__3; if linked_757 == nil { b__4 = ifn_758.Invoke_O__O(arg_759) } else { b__4 = linked_757.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_756, arg_759) }; var r__5 any; var root_760 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, A_arbace_go_check_types_term_intersect_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = t.F_a; var arg_764 any = b__4; if linked_761 == nil { r__5 = ifn_762.Invoke_O_O__O(arg_763, arg_764) } else { r__5 = linked_761.(*A_arbace_go_check_types_term_intersect_A).Invoke_O_O_O__O(root_760, arg_763, arg_764) }; if jrt.J2g_Truth(r__5) { var root_765 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any = r__5; var arg_769 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__219000105); var tmp7 any; var root_770 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = s__219000106__3; if linked_771 == nil { tmp7 = ifn_772.Invoke_O__O(arg_773) } else { tmp7 = linked_771.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_770, arg_773) }; arg_769 = tmp6.Invoke_O__O(tmp7); if linked_766 == nil { return ifn_767.Invoke_O_O__O(arg_768, arg_769) } else { return linked_766.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_765, arg_768, arg_769) } } else { var tmp8 any; var root_774 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = s__219000106__3; if linked_775 == nil { tmp8 = ifn_776.Invoke_O__O(arg_777) } else { tmp8 = linked_775.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_774, arg_777) }; s__219000106__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :294:1
func A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_fn__219000113_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_fn__219000113_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_fn__219000113_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :294:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_fn__219000113_A) Ctor_O_I_O_O(c__b__219000108 any, c__size__1927001038__auto__ int32, c__a, c__c__1927001037__auto__ any) { t.F_b__219000108 = c__b__219000108; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_a = c__a; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :294:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_fn__219000113_A) Invoke_O__O(self any) any { { var i__219000107__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000107__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000107__1)); var r__3 any; var root_723 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, A_arbace_go_check_types_term_intersect_A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = t.F_a; var arg_727 any = b__2; if linked_724 == nil { r__3 = ifn_725.Invoke_O_O__O(arg_726, arg_727) } else { r__3 = linked_724.(*A_arbace_go_check_types_term_intersect_A).Invoke_O_O_O__O(root_723, arg_726, arg_727) }; if jrt.J2g_Truth(r__3) { var root_728 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = t.F_b__219000108; var arg_732 any = r__3; if linked_729 == nil { ifn_730.Invoke_O_O__O(arg_731, arg_732) } else { linked_729.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_728, arg_731, arg_732) }; i__219000107__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000107__1); continue L1 } else { i__219000107__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000107__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_types_terms_includes_QMARK__A_New() *A_arbace_go_check_types_terms_includes_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_includes_QMARK__A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__A) Ctor() {}
//line :296:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__A) Invoke_O_O_O__O(self, xl__0, t__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, xl__0); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp1 any; var root_807 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any; var tmp2 any = A_arbace_go_check_types_terms_includes_QMARK__fn__219000121_A_New_O(t__1); var tmp3 *jrt.Class; var fncls__817 *jrt.Class = A_arbace_go_check_types_terms_includes_QMARK__fn__219000121_A_fn_class; if fncls__817 == nil { var fncls__817d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_check_types_terms_includes_QMARK__fn__219000121_A_fn_class = fncls__817d; tmp3 = fncls__817d } else { tmp3 = fncls__817 }; arg_810 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_811 any = xl__0; if linked_808 == nil { tmp1 = ifn_809.Invoke_O_O__O(arg_810, arg_811) } else { tmp1 = linked_808.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_807, arg_810, arg_811) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } }
//line :296:1
func A_arbace_go_check_types_terms_includes_QMARK__fn__219000121_A_New_O(p0 any) *A_arbace_go_check_types_terms_includes_QMARK__fn__219000121_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_includes_QMARK__fn__219000121_A{}; t.Ctor_O(p0); return t }
//line :296:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__fn__219000121_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :296:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__fn__219000121_A) Invoke_O_O__O(self, p1__219000120_SHARP___1 any) any { var root_812 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, A_arbace_go_check_types_term_includes_QMARK__A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = p1__219000120_SHARP___1; var arg_816 any = t.F_t; if linked_813 == nil { return ifn_814.Invoke_O_O__O(arg_815, arg_816) } else { return linked_813.(*A_arbace_go_check_types_term_includes_QMARK__A).Invoke_O_O_O__O(root_812, arg_815, arg_816) } }

func A_arbace_go_check_types_terms_superset_of_QMARK__A_New() *A_arbace_go_check_types_terms_superset_of_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_superset_of_QMARK__A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__A) Ctor() {}
//line :298:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__A) Invoke_O_O_O__O(self, xl__0, y__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, xl__0); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp1 any; var root_818 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_820 lang.IFn; if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any; var tmp2 any = A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000125_A_New_O(y__1); var tmp3 *jrt.Class; var fncls__828 *jrt.Class = A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000125_A_fn_class; if fncls__828 == nil { var fncls__828d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000125_A_fn_class = fncls__828d; tmp3 = fncls__828d } else { tmp3 = fncls__828 }; arg_821 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_822 any = xl__0; if linked_819 == nil { tmp1 = ifn_820.Invoke_O_O__O(arg_821, arg_822) } else { tmp1 = linked_819.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_818, arg_821, arg_822) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } }
//line :298:1
func A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000125_A_New_O(p0 any) *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000125_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000125_A{}; t.Ctor_O(p0); return t }
//line :298:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000125_A) Ctor_O(c__y any) { t.F_y = c__y }
//line :298:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000125_A) Invoke_O_O__O(self, p1__219000124_SHARP___1 any) any { var root_823 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, A_arbace_go_check_types_term_subset_QMARK__A_fn_class); var ifn_825 lang.IFn; if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any = t.F_y; var arg_827 any = p1__219000124_SHARP___1; if linked_824 == nil { return ifn_825.Invoke_O_O__O(arg_826, arg_827) } else { return linked_824.(*A_arbace_go_check_types_term_subset_QMARK__A).Invoke_O_O_O__O(root_823, arg_826, arg_827) } }

func A_arbace_go_check_types_terms_subset_QMARK__A_New() *A_arbace_go_check_types_terms_subset_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_subset_QMARK__A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__A) Ctor() {}
//line :300:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__A) Invoke_O_O_O__O(self, xl__0, yl__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, yl__1) { return jrt.Boolean_TRUE.Ref() } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, xl__0) { return jrt.Boolean_FALSE.Ref() } else { var tmp1 any; var root_829 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_831 lang.IFn


		if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = yl__1; if linked_830 == nil { tmp1 = ifn_831.Invoke_O__O(arg_832) } else { tmp1 = linked_830.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_829, arg_832) }
//line :303:1
		if jrt.J2g_Truth(tmp1) {


			var root_833 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_835 lang.IFn; if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = xl__0; if linked_834 == nil { return ifn_835.Invoke_O__O(arg_836) } else { return linked_834.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_833, arg_836) } } else {
//line :303:1
				if A_arbace_go_check_types_A_const_75 != nil {



					var root_837 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any; var tmp2 any = A_arbace_go_check_types_terms_subset_QMARK__fn__219000129_A_New_O(yl__1); var tmp3 *jrt.Class; var fncls__847 *jrt.Class = A_arbace_go_check_types_terms_subset_QMARK__fn__219000129_A_fn_class; if fncls__847 == nil { var fncls__847d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_go_check_types_terms_subset_QMARK__fn__219000129_A_fn_class = fncls__847d; tmp3 = fncls__847d } else { tmp3 = fncls__847 }; arg_840 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_841 any = xl__0; if linked_838 == nil { return ifn_839.Invoke_O_O__O(arg_840, arg_841) } else { return linked_838.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_837, arg_840, arg_841) } } else {
//line :303:1
						return nil
					}
			}
	} } }
func A_arbace_go_check_types_terms_subset_QMARK__fn__219000129_A_New_O(p0 any) *A_arbace_go_check_types_terms_subset_QMARK__fn__219000129_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_subset_QMARK__fn__219000129_A{}; t.Ctor_O(p0); return t }
//line :307:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__fn__219000129_A) Ctor_O(c__yl any) { t.F_yl = c__yl }
//line :307:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__fn__219000129_A) Invoke_O_O__O(self, p1__219000128_SHARP___1 any) any { var root_842 any = A_arbace_go_check_types_A_const_142.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, A_arbace_go_check_types_terms_superset_of_QMARK__A_fn_class); var ifn_844 lang.IFn; if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any = t.F_yl; var arg_846 any = p1__219000128_SHARP___1; if linked_843 == nil { return ifn_844.Invoke_O_O__O(arg_845, arg_846) } else { return linked_843.(*A_arbace_go_check_types_terms_superset_of_QMARK__A).Invoke_O_O_O__O(root_842, arg_845, arg_846) } }

func A_arbace_go_check_types_make_tset_A_New() *A_arbace_go_check_types_make_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_make_tset_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_go_check_types_make_tset_A) Ctor() {}
//line :309:1
func (t *A_arbace_go_check_types_make_tset_A) Invoke_O_O_O__O(self, terms__0, comparable__1 any) any {


	var tmp1 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, terms__0); if and__1927000168__auto____3 { var root_848 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = comparable__1; if linked_849 == nil { tmp1 = ifn_850.Invoke_O__O(arg_851) } else { tmp1 = linked_849.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_848, arg_851) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any = A_arbace_go_check_types_A_const_109; var tmp3 any = A_arbace_go_check_types_A_const_110; var tmp4 any; var and__1927000168__auto____3_2 any = comparable__1; if jrt.J2g_Truth(and__1927000168__auto____3_2) { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, terms__0)).Ref() } else { tmp4 = and__1927000168__auto____3_2 }; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, terms__0, tmp3, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp4)).Ref()))
	} }
func A_arbace_go_check_types_iface_tset_A_New() *A_arbace_go_check_types_iface_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_iface_tset_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_go_check_types_iface_tset_A) Ctor() {}
//line :314:1
func (t *A_arbace_go_check_types_iface_tset_A) Invoke_O_O__O(self, u__0 any) any { var ts__2 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(2)); var tmp1 any = A_arbace_go_check_types_A_const_62; var tmp2 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp3 any = A_arbace_go_check_types_A_const_109; var tmp4 any; var tmp5 any; var root_852 any = A_arbace_go_check_types_A_const_143.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_854 lang.IFn; if





	linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = ts__2; if linked_853 == nil { tmp5 = ifn_854.Invoke_O__O(arg_855) } else { tmp5 = linked_853.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_852, arg_855) }; if jrt.J2g_Truth(tmp5) { tmp4 = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__2) } else { tmp4 = A_arbace_go_check_types_A_const_108 }; var tmp6 any = tmp4; var tmp7 any = A_arbace_go_check_types_A_const_110; var tmp8 any; var and__1927000168__auto____3 any; var root_856 any = /*line :314:1*/A_arbace_go_check_types_A_const_143.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_858 lang.IFn; if






	linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = ts__2; if linked_857 == nil { and__1927000168__auto____3 = ifn_858.Invoke_O__O(arg_859) } else { and__1927000168__auto____3 = linked_857.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_856, arg_859) }; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp8 = A_arbace_go_check_types_A_const_110.Invoke_O__O(ts__2) } else { tmp8 = and__1927000168__auto____3 }; return /*line :314:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp6, tmp7, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp8)).Ref())) }








func A_arbace_go_check_types_has_terms_QMARK__A_New() *A_arbace_go_check_types_has_terms_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_terms_QMARK__A{}; t.Ctor(); return t }
//line :323:1
func (t *A_arbace_go_check_types_has_terms_QMARK__A) Ctor() {}
//line :323:1
func (t *A_arbace_go_check_types_has_terms_QMARK__A) Invoke_O_O__O(self, ts__0 any) any { var terms__2 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0); var and__1927000168__auto____3 any; var root_860 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_862 lang.IFn; if


	linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = A_arbace_go_check_types_A_const_108; var arg_864 any = terms__2; if linked_861 == nil { and__1927000168__auto____3 = ifn_862.Invoke_O_O__O(arg_863, arg_864) } else { and__1927000168__auto____3 = linked_861.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_860, arg_863, arg_864) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_865 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = terms__2; if linked_866 == nil { return ifn_867.Invoke_O__O(arg_868) } else { return linked_866.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_865, arg_868) } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_tset_empty_QMARK__A_New() *A_arbace_go_check_types_tset_empty_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_empty_QMARK__A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_go_check_types_tset_empty_QMARK__A) Ctor() {}
//line :328:1
func (t *A_arbace_go_check_types_tset_empty_QMARK__A) Invoke_O_O__O(self, ts__0 any) any { var and__1927000168__auto____2 any; var root_869 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = A_arbace_go_check_types_A_const_108; var arg_873 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0); if linked_870 == nil { and__1927000168__auto____2 = ifn_871.Invoke_O_O__O(arg_872, arg_873) } else { and__1927000168__auto____2 = linked_870.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_869, arg_872, arg_873) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_874 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_874, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_876 lang.IFn; if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; var arg_877 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0); if linked_875 == nil { return ifn_876.Invoke_O__O(arg_877) } else { return linked_875.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_874, arg_877) } } else { return and__1927000168__auto____2 } }

func A_arbace_go_check_types_method_set_iface_QMARK__A_New() *A_arbace_go_check_types_method_set_iface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_method_set_iface_QMARK__A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_go_check_types_method_set_iface_QMARK__A) Ctor() {}
//line :330:1
func (t *A_arbace_go_check_types_method_set_iface_QMARK__A) Invoke_O_O__O(self, u__0 any) any {



	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref()
}
func A_arbace_go_check_types_bound_iface_A_New() *A_arbace_go_check_types_bound_iface_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_bound_iface_A{}; t.Ctor(); return t }
//line :336:1
func (t *A_arbace_go_check_types_bound_iface_A) Ctor() {}
//line :336:1
func (t *A_arbace_go_check_types_bound_iface_A) Invoke_O_O__O(self, b__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any = b__0; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_878 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_878, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = A_arbace_go_check_types_A_const_67; var arg_882 any = b__0; if linked_879 == nil { tmp1 = ifn_880.Invoke_O_O__O(arg_881, arg_882) } else { tmp1 = linked_879.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_878, arg_881, arg_882) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var u__2 any; var root_883 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_883, A_arbace_go_check_types_under_A_fn_class); var ifn_885 lang.IFn
		if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any = b__0; if linked_884 == nil { u__2 = ifn_885.Invoke_O__O(arg_886) } else { u__2 = linked_884.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_883, arg_886) }
		if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_67, u__2) { return nil } else { var tmp2 any; var and__1927000168__auto____3 any; var root_887 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_887, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_889 lang.IFn

			if linked_888 == nil { ifn_889 = lang.IFn_Cast(root_887) } else { ifn_889 = nil }; var arg_890 any = u__2; if linked_888 == nil { and__1927000168__auto____3 = ifn_889.Invoke_O__O(arg_890) } else { and__1927000168__auto____3 = linked_888.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_887, arg_890) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_go_check_types_A_const_86; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :342:1
			if jrt.J2g_Truth(tmp2) { return u__2 } else { var tmp4 any; var root_891 any = A_arbace_go_check_types_A_const_144.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, A_arbace_go_check_types_union_QMARK__A_fn_class); var ifn_893 lang.IFn


				if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = u__2; if linked_892 == nil { tmp4 = ifn_893.Invoke_O__O(arg_894) } else { tmp4 = linked_892.(*A_arbace_go_check_types_union_QMARK__A).Invoke_O_O__O(root_891, arg_894) }
//line :342:1
				if jrt.J2g_Truth(tmp4) { var tmp5 any = A_arbace_go_check_types_A_const_86; var tmp6 any = lang.PersistentVector_EMPTY.Ref(); var tmp7 any; var root_895 any = A_arbace_go_check_types_A_const_145.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, A_arbace_go_check_types_make_tset_A_fn_class); var ifn_897 lang.IFn


					if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); var arg_899 any = jrt.Boolean_FALSE.Ref(); if linked_896 == nil { tmp7 = ifn_897.Invoke_O_O__O(arg_898, arg_899) } else { tmp7 = linked_896.(*A_arbace_go_check_types_make_tset_A).Invoke_O_O_O__O(root_895, arg_898, arg_899) }
//line :342:1
					return lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, tmp7) } else { if A_arbace_go_check_types_A_const_75 != nil { var tmp8 any = A_arbace_go_check_types_A_const_86; var tmp9 any = lang.PersistentVector_EMPTY.Ref(); var tmp10 any; var root_900 any = A_arbace_go_check_types_A_const_145.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, A_arbace_go_check_types_make_tset_A_fn_class); var ifn_902 lang.IFn



						if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(jrt.Boolean_FALSE.Ref(), b__0))); var arg_904 any = jrt.Boolean_FALSE.Ref(); if linked_901 == nil { tmp10 = ifn_902.Invoke_O_O__O(arg_903, arg_904) } else { tmp10 = linked_901.(*A_arbace_go_check_types_make_tset_A).Invoke_O_O_O__O(root_900, arg_903, arg_904) }
//line :342:1
						return lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp9, tmp10) } else { return nil } } } } } else {
//line :340:1
							return nil
						}
}





func A_arbace_go_check_types_tparam_iface_A_New() *A_arbace_go_check_types_tparam_iface_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_iface_A{}; t.Ctor(); return t }
//line :348:1
func (t *A_arbace_go_check_types_tparam_iface_A) Ctor() {}
//line :348:1
func (t *A_arbace_go_check_types_tparam_iface_A) Invoke_O_O__O(self, tp__0 any) any { var i__2 any; var root_905 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, A_arbace_go_check_types_info_A_fn_class); var ifn_907 lang.IFn; if


	linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = tp__0; if linked_906 == nil { i__2 = ifn_907.Invoke_O__O(arg_908) } else { i__2 = linked_906.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_905, arg_908) }; var or__1927000174__auto____3 any = /*line :348:1*/A_arbace_go_check_types_A_const_146.Invoke_O__O(i__2); if



	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000408__auto____4 any; var root_909 any = A_arbace_go_check_types_A_const_147.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, A_arbace_go_check_types_bound_iface_A_fn_class); var ifn_911 lang.IFn
		if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = A_arbace_go_check_types_A_const_148.Invoke_O__O(i__2); if linked_910 == nil { temp__1927000408__auto____4 = ifn_911.Invoke_O__O(arg_912) } else { temp__1927000408__auto____4 = linked_910.(*A_arbace_go_check_types_bound_iface_A).Invoke_O_O__O(root_909, arg_912) }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var r__5 any = temp__1927000408__auto____4
			lang.IFn_Cast(A_arbace_go_check_types_A_const_149.GetRawRoot__O()).Invoke_O_O_O_O__O(tp__0, A_arbace_go_check_types_A_const_59.GetRawRoot__O(), A_arbace_go_check_types_A_const_146, r__5)
//line :353:1
			return r__5 } else { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_86, lang.PersistentVector_EMPTY.Ref(), nil) } } }



func A_arbace_go_check_types_tparam_tset_A_New() *A_arbace_go_check_types_tparam_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_tset_A{}; t.Ctor(); return t }
//line :357:1
func (t *A_arbace_go_check_types_tparam_tset_A) Ctor() {}
//line :357:1
func (t *A_arbace_go_check_types_tparam_tset_A) Invoke_O_O__O(self, tp__0 any) any { var root_920 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any; var root_924 any = A_arbace_go_check_types_A_const_74.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, A_arbace_go_check_types_tparam_iface_A_fn_class); var ifn_926 lang.IFn; if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = tp__0; if linked_925 == nil { arg_923 = ifn_926.Invoke_O__O(arg_927) } else { arg_923 = linked_925.(*A_arbace_go_check_types_tparam_iface_A).Invoke_O_O__O(root_924, arg_927) }; if linked_921 == nil { return ifn_922.Invoke_O__O(arg_923) } else { return linked_921.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_920, arg_923) } }

func A_arbace_go_check_types_typeset_pairs_A_New() *A_arbace_go_check_types_typeset_pairs_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_go_check_types_typeset_pairs_A) Ctor() {}
//line :359:1
func (t *A_arbace_go_check_types_typeset_pairs_A) Invoke_O_O__O(self, t__0 any) any {



	var tmp1 any; var root_928 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_930 lang.IFn; if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = t__0; if linked_929 == nil { tmp1 = ifn_930.Invoke_O__O(arg_931) } else { tmp1 = linked_929.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_928, arg_931) }; if jrt.J2g_Truth(tmp1) { var ts__2 any; var root_932 any = A_arbace_go_check_types_A_const_115.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_934 lang.IFn
		if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = t__0; if linked_933 == nil { ts__2 = ifn_934.Invoke_O__O(arg_935) } else { ts__2 = linked_933.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_932, arg_935) }
		var tmp2 any; var root_936 any = A_arbace_go_check_types_A_const_150.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = ts__2; if linked_937 == nil { tmp2 = ifn_938.Invoke_O__O(arg_939) } else { tmp2 = linked_937.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_936, arg_939) }; if jrt.J2g_Truth(tmp2) { var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_A_New(); var tmp4 *jrt.Class; var fncls__1006 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_A_fn_class
			if fncls__1006 == nil { var fncls__1006d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_A_fn_class = fncls__1006d; tmp4 = fncls__1006d } else { tmp4 = fncls__1006 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); return lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__2)) } else {
//line :365:1
				return A_arbace_go_check_types_A_const_151 } } else {
//line :363:1
					var tmp5 any; var root_1007 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, A_arbace_go_check_types_under_A_fn_class); var ifn_1009 lang.IFn




					if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any = t__0; if linked_1008 == nil { tmp5 = ifn_1009.Invoke_O__O(arg_1010) } else { tmp5 = linked_1008.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1007, arg_1010) }
//line :363:1
					return lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(t__0, tmp5))
				}
}
func A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_A_New() *A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_A) Ctor() {}
//line :366:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_A) Invoke_O_O__O(self, s__219000141__1 any) any { var tmp1 any = A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_A_New_O_O(s__219000141__1, self); var tmp2 *jrt.Class; var fncls__1005 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_A_fn_class; if fncls__1005 == nil { var fncls__1005d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_A_fn_class = fncls__1005d; tmp2 = fncls__1005d } else { tmp2 = fncls__1005 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :366:1
func A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_A{}; t.Ctor_O_O(p0, p1); return t }
//line :366:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_A) Ctor_O_O(c__s__219000141, c__iter__219000140 any) { t.F_s__219000141 = c__s__219000141; t.F_iter__219000140 = c__iter__219000140 }
//line :366:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_A) Invoke_O__O(self any) any { { var s__219000141__1 any; var t_ any = t.F_s__219000141; t.F_s__219000141 = nil; s__219000141__1 = t_; for { var temp__1927000414__auto____2 any; var root_940 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_942 lang.IFn; if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = s__219000141__1; if linked_941 == nil { temp__1927000414__auto____2 = ifn_942.Invoke_O__O(arg_943) } else { temp__1927000414__auto____2 = linked_941.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_940, arg_943) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000141__3 any = temp__1927000414__auto____2; var tmp1 any; var root_944 any = A_arbace_go_check_types_A_const_131.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_946 lang.IFn; if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = s__219000141__3; if linked_945 == nil { tmp1 = ifn_946.Invoke_O__O(arg_947) } else { tmp1 = linked_945.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_944, arg_947) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_948 any = A_arbace_go_check_types_A_const_132.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = s__219000141__3; if linked_949 == nil { c__1927001037__auto____4 = ifn_950.Invoke_O__O(arg_951) } else { c__1927001037__auto____4 = linked_949.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_948, arg_951) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000143__6 any; var root_952 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_953 == nil { b__219000143__6 = ifn_954.Invoke_O__O(arg_955) } else { b__219000143__6 = linked_953.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_952, arg_955) }; var tmp2 any = A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_fn__219000146_A_New_O_I_O(b__219000143__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__965 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_fn__219000146_A_fn_class; if fncls__965 == nil { var fncls__965d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_fn__219000146_A_fn_class = fncls__965d; tmp3 = fncls__965d } else { tmp3 = fncls__965 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_966 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_968 lang.IFn; if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any; var root_971 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = b__219000143__6; if linked_972 == nil { arg_969 = ifn_973.Invoke_O__O(arg_974) } else { arg_969 = linked_972.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_971, arg_974) }; var arg_970 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000140); var tmp5 any; var root_975 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = s__219000141__3; if linked_976 == nil { tmp5 = ifn_977.Invoke_O__O(arg_978) } else { tmp5 = linked_976.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_975, arg_978) }; arg_970 = tmp4.Invoke_O__O(tmp5); if linked_967 == nil { return ifn_968.Invoke_O_O__O(arg_969, arg_970) } else { return linked_967.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_966, arg_969, arg_970) } } else { var root_979 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any; var root_984 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = b__219000143__6; if linked_985 == nil { arg_982 = ifn_986.Invoke_O__O(arg_987) } else { arg_982 = linked_985.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_984, arg_987) }; var arg_983 any; if linked_980 == nil { return ifn_981.Invoke_O_O__O(arg_982, arg_983) } else { return linked_980.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_979, arg_982, arg_983) } } } else { var vec__219000151__4 any; var root_988 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = s__219000141__3; if linked_989 == nil { vec__219000151__4 = ifn_990.Invoke_O__O(arg_991) } else { vec__219000151__4 = linked_989.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_988, arg_991) }; var tilde__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000151__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000151__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_992 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any; var tmp6 any; if jrt.J2g_Truth(tilde__5) { tmp6 = ty__6 } else { var root_997 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, A_arbace_go_check_types_under_A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any = ty__6; if linked_998 == nil { tmp6 = ifn_999.Invoke_O__O(arg_1000) } else { tmp6 = linked_998.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_997, arg_1000) } }; arg_995 = lang.Tuple_Create_O_O__IPersistentVector(ty__6, tmp6); var arg_996 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__219000140); var tmp8 any; var root_1001 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1001, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1003 lang.IFn; if linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any = s__219000141__3; if linked_1002 == nil { tmp8 = ifn_1003.Invoke_O__O(arg_1004) } else { tmp8 = linked_1002.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1001, arg_1004) }; arg_996 = tmp7.Invoke_O__O(tmp8); if linked_993 == nil { return ifn_994.Invoke_O_O__O(arg_995, arg_996) } else { return linked_993.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_992, arg_995, arg_996) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :366:1
func A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_fn__219000146_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_fn__219000146_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_fn__219000146_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :366:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_fn__219000146_A) Ctor_O_I_O(c__b__219000143 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000143 = c__b__219000143; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :366:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_fn__219000146_A) Invoke_O__O(self any) any { { var i__219000142__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000142__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__219000147__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000142__1)); var tilde__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000147__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000147__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_956 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = t.F_b__219000143; var arg_960 any; var tmp2 any; if jrt.J2g_Truth(tilde__3) { tmp2 = ty__4 } else { var root_961 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, A_arbace_go_check_types_under_A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any = ty__4; if linked_962 == nil { tmp2 = ifn_963.Invoke_O__O(arg_964) } else { tmp2 = linked_962.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_961, arg_964) } }; arg_960 = lang.Tuple_Create_O_O__IPersistentVector(ty__4, tmp2); if linked_957 == nil { ifn_958.Invoke_O_O__O(arg_959, arg_960) } else { linked_957.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_956, arg_959, arg_960) }; i__219000142__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000142__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_go_check_types_typeset_all_A_New() *A_arbace_go_check_types_typeset_all_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_all_A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_go_check_types_typeset_all_A) Ctor() {}
//line :370:1
func (t *A_arbace_go_check_types_typeset_all_A) Invoke_O_O_O__O(self, t__0, f__1 any) any {


	var root_1011 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any; var tmp1 any = A_arbace_go_check_types_typeset_all_fn__219000158_A_New_O(f__1); var tmp2 *jrt.Class; var fncls__1016 *jrt.Class = A_arbace_go_check_types_typeset_all_fn__219000158_A_fn_class; if fncls__1016 == nil { var fncls__1016d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_go_check_types_typeset_all_fn__219000158_A_fn_class = fncls__1016d; tmp2 = fncls__1016d } else { tmp2 = fncls__1016 }; arg_1014 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1015 any; var root_1017 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1017, A_arbace_go_check_types_typeset_pairs_A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any = t__0; if linked_1018 == nil { arg_1015 = ifn_1019.Invoke_O__O(arg_1020) } else { arg_1015 = linked_1018.(*A_arbace_go_check_types_typeset_pairs_A).Invoke_O_O__O(root_1017, arg_1020) }; if linked_1012 == nil { return ifn_1013.Invoke_O_O__O(arg_1014, arg_1015) } else { return linked_1012.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1011, arg_1014, arg_1015) } }
//line :373:1
func A_arbace_go_check_types_typeset_all_fn__219000158_A_New_O(p0 any) *A_arbace_go_check_types_typeset_all_fn__219000158_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_all_fn__219000158_A{}; t.Ctor_O(p0); return t }
//line :373:1
func (t *A_arbace_go_check_types_typeset_all_fn__219000158_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :373:1
func (t *A_arbace_go_check_types_typeset_all_fn__219000158_A) Invoke_O_O__O(self, p__219000157__1 any) any { var vec__219000159__2 any = p__219000157__1; var ty__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000159__2, lang.RT_IntCast_J__I_NoInit(0), nil); var u__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000159__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.IFn_Cast(t.F_f).Invoke_O_O__O(ty__3, u__4) }

func A_arbace_go_check_types_under_is_A_New() *A_arbace_go_check_types_under_is_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_is_A{}; t.Ctor(); return t }
//line :375:1
func (t *A_arbace_go_check_types_under_is_A) Ctor() {}
//line :375:1
func (t *A_arbace_go_check_types_under_is_A) Invoke_O_O_O__O(self, t__0, f__1 any) any {



	var root_1021 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1021, A_arbace_go_check_types_typeset_all_A_fn_class); var ifn_1023 lang.IFn; if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any = t__0; var arg_1025 any; var tmp1 any = A_arbace_go_check_types_under_is_fn__219000164_A_New_O(f__1); var tmp2 *jrt.Class; var fncls__1026 *jrt.Class = A_arbace_go_check_types_under_is_fn__219000164_A_fn_class; if fncls__1026 == nil { var fncls__1026d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_go_check_types_under_is_fn__219000164_A_fn_class = fncls__1026d; tmp2 = fncls__1026d } else { tmp2 = fncls__1026 }; arg_1025 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1022 == nil { return ifn_1023.Invoke_O_O__O(arg_1024, arg_1025) } else { return linked_1022.(*A_arbace_go_check_types_typeset_all_A).Invoke_O_O_O__O(root_1021, arg_1024, arg_1025) } }
//line :379:1
func A_arbace_go_check_types_under_is_fn__219000164_A_New_O(p0 any) *A_arbace_go_check_types_under_is_fn__219000164_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_is_fn__219000164_A{}; t.Ctor_O(p0); return t }
//line :379:1
func (t *A_arbace_go_check_types_under_is_fn__219000164_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :379:1
func (t *A_arbace_go_check_types_under_is_fn__219000164_A) Invoke_O_O_O__O(self, ___1, u__2 any) any { return lang.IFn_Cast(t.F_f).Invoke_O__O(u__2) }

func A_arbace_go_check_types_all_basic_A_New() *A_arbace_go_check_types_all_basic_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_basic_A{}; t.Ctor(); return t }
//line :381:1
func (t *A_arbace_go_check_types_all_basic_A) Ctor() {}
//line :381:1
func (t *A_arbace_go_check_types_all_basic_A) Invoke_O_O_O__O(self, t__0, pred__1 any) any {



	var tmp1 any; var root_1027 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = t__0; if linked_1028 == nil { tmp1 = ifn_1029.Invoke_O__O(arg_1030) } else { tmp1 = linked_1028.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_1027, arg_1030) }; if jrt.J2g_Truth(tmp1) { var ts__3 any; var root_1031 any = A_arbace_go_check_types_A_const_115.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_1033 lang.IFn
		if linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any = t__0; if linked_1032 == nil { ts__3 = ifn_1033.Invoke_O__O(arg_1034) } else { ts__3 = linked_1032.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_1031, arg_1034) }
		var tmp2 any; var and__1927000168__auto____4 any; var root_1035 any = A_arbace_go_check_types_A_const_150.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any = ts__3; if linked_1036 == nil { and__1927000168__auto____4 = ifn_1037.Invoke_O__O(arg_1038) } else { and__1927000168__auto____4 = linked_1036.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_1035, arg_1038) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1039 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1041 lang.IFn; if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any; var tmp3 any = A_arbace_go_check_types_all_basic_fn__219000168_A_New_O(pred__1); var tmp4 *jrt.Class; var fncls__1044 *jrt.Class = A_arbace_go_check_types_all_basic_fn__219000168_A_fn_class; if fncls__1044 == nil { var fncls__1044d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_check_types_all_basic_fn__219000168_A_fn_class = fncls__1044d; tmp4 = fncls__1044d } else { tmp4 = fncls__1044 }; arg_1042 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1043 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__3); if linked_1040 == nil { tmp2 = ifn_1041.Invoke_O_O__O(arg_1042, arg_1043) } else { tmp2 = linked_1040.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1039, arg_1042, arg_1043) } } else { tmp2 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp2)).Ref() } else {
			return lang.IFn_Cast(pred__1).Invoke_O__O(t__0) } }
//line :387:1
func A_arbace_go_check_types_all_basic_fn__219000168_A_New_O(p0 any) *A_arbace_go_check_types_all_basic_fn__219000168_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_basic_fn__219000168_A{}; t.Ctor_O(p0); return t }
//line :387:1
func (t *A_arbace_go_check_types_all_basic_fn__219000168_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :387:1
func (t *A_arbace_go_check_types_all_basic_fn__219000168_A) Invoke_O_O__O(self, p__219000167__1 any) any { var vec__219000169__2 any = p__219000167__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000169__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000169__2, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___3; return lang.IFn_Cast(t.F_pred).Invoke_O__O(ty__4) }


func A_arbace_go_check_types_all_integer_QMARK__A_New() *A_arbace_go_check_types_all_integer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_integer_QMARK__A{}; t.Ctor(); return t }
//line :390:1
func (t *A_arbace_go_check_types_all_integer_QMARK__A) Ctor() {}
//line :390:1
func (t *A_arbace_go_check_types_all_integer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1045 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1047 lang.IFn; if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any = t__0; var arg_1049 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); if linked_1046 == nil { return ifn_1047.Invoke_O_O__O(arg_1048, arg_1049) } else { return linked_1046.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1045, arg_1048, arg_1049) } }
func A_arbace_go_check_types_all_unsigned_QMARK__A_New() *A_arbace_go_check_types_all_unsigned_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_unsigned_QMARK__A{}; t.Ctor(); return t }
//line :391:1
func (t *A_arbace_go_check_types_all_unsigned_QMARK__A) Ctor() {}
//line :391:1
func (t *A_arbace_go_check_types_all_unsigned_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1050 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1050, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = t__0; var arg_1054 any = A_arbace_go_check_types_A_const_155.GetRawRoot__O(); if linked_1051 == nil { return ifn_1052.Invoke_O_O__O(arg_1053, arg_1054) } else { return linked_1051.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1050, arg_1053, arg_1054) } }
func A_arbace_go_check_types_all_numeric_QMARK__A_New() *A_arbace_go_check_types_all_numeric_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_QMARK__A{}; t.Ctor(); return t }
//line :392:1
func (t *A_arbace_go_check_types_all_numeric_QMARK__A) Ctor() {}
//line :392:1
func (t *A_arbace_go_check_types_all_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1055 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1055, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1057 lang.IFn; if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = t__0; var arg_1059 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); if linked_1056 == nil { return ifn_1057.Invoke_O_O__O(arg_1058, arg_1059) } else { return linked_1056.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1055, arg_1058, arg_1059) } }
func A_arbace_go_check_types_all_string_QMARK__A_New() *A_arbace_go_check_types_all_string_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_string_QMARK__A{}; t.Ctor(); return t }
//line :393:1
func (t *A_arbace_go_check_types_all_string_QMARK__A) Ctor() {}
//line :393:1
func (t *A_arbace_go_check_types_all_string_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1060 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1060, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1062 lang.IFn; if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 any = t__0; var arg_1064 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); if linked_1061 == nil { return ifn_1062.Invoke_O_O__O(arg_1063, arg_1064) } else { return linked_1061.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1060, arg_1063, arg_1064) } }
func A_arbace_go_check_types_all_boolean_QMARK__A_New() *A_arbace_go_check_types_all_boolean_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_boolean_QMARK__A{}; t.Ctor(); return t }
//line :394:1
func (t *A_arbace_go_check_types_all_boolean_QMARK__A) Ctor() {}
//line :394:1
func (t *A_arbace_go_check_types_all_boolean_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1065 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = t__0; var arg_1069 any = A_arbace_go_check_types_A_const_157.GetRawRoot__O(); if linked_1066 == nil { return ifn_1067.Invoke_O_O__O(arg_1068, arg_1069) } else { return linked_1066.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1065, arg_1068, arg_1069) } }
func A_arbace_go_check_types_all_ordered_QMARK__A_New() *A_arbace_go_check_types_all_ordered_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_ordered_QMARK__A{}; t.Ctor(); return t }
//line :395:1
func (t *A_arbace_go_check_types_all_ordered_QMARK__A) Ctor() {}
//line :395:1
func (t *A_arbace_go_check_types_all_ordered_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1070 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = t__0; var arg_1074 any = A_arbace_go_check_types_A_const_158.GetRawRoot__O(); if linked_1071 == nil { return ifn_1072.Invoke_O_O__O(arg_1073, arg_1074) } else { return linked_1071.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1070, arg_1073, arg_1074) } }
func A_arbace_go_check_types_all_numeric_or_string_QMARK__A_New() *A_arbace_go_check_types_all_numeric_or_string_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_or_string_QMARK__A{}; t.Ctor(); return t }
//line :396:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__A) Ctor() {}
//line :396:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1075 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1077 lang.IFn; if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = t__0; var arg_1079 any; var tmp1 any = A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000181_A_New(); var tmp2 *jrt.Class; var fncls__1088 *jrt.Class = A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000181_A_fn_class; if fncls__1088 == nil { var fncls__1088d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000181_A_fn_class = fncls__1088d; tmp2 = fncls__1088d } else { tmp2 = fncls__1088 }; arg_1079 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1076 == nil { return ifn_1077.Invoke_O_O__O(arg_1078, arg_1079) } else { return linked_1076.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1075, arg_1078, arg_1079) } }
//line :396:1
func A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000181_A_New() *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000181_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000181_A{}; t.Ctor(); return t }
//line :396:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000181_A) Ctor() {}
//line :396:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000181_A) Invoke_O_O__O(self, p1__219000180_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_1080 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); var linked_1081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1080, A_arbace_go_check_types_numeric_QMARK__A_fn_class); var ifn_1082 lang.IFn; if linked_1081 == nil { ifn_1082 = lang.IFn_Cast(root_1080) } else { ifn_1082 = nil }; var arg_1083 any = p1__219000180_SHARP___1; if linked_1081 == nil { or__1927000174__auto____2 = ifn_1082.Invoke_O__O(arg_1083) } else { or__1927000174__auto____2 = linked_1081.(*A_arbace_go_check_types_numeric_QMARK__A).Invoke_O_O__O(root_1080, arg_1083) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_1084 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1084, A_arbace_go_check_types_string_type_QMARK__A_fn_class); var ifn_1086 lang.IFn; if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any = p1__219000180_SHARP___1; if linked_1085 == nil { return ifn_1086.Invoke_O__O(arg_1087) } else { return linked_1085.(*A_arbace_go_check_types_string_type_QMARK__A).Invoke_O_O__O(root_1084, arg_1087) } } }
func A_arbace_go_check_types_all_float_QMARK__A_New() *A_arbace_go_check_types_all_float_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_float_QMARK__A{}; t.Ctor(); return t }
//line :397:1
func (t *A_arbace_go_check_types_all_float_QMARK__A) Ctor() {}
//line :397:1
func (t *A_arbace_go_check_types_all_float_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1089 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1091 lang.IFn; if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = t__0; var arg_1093 any = A_arbace_go_check_types_A_const_81.GetRawRoot__O(); if linked_1090 == nil { return ifn_1091.Invoke_O_O__O(arg_1092, arg_1093) } else { return linked_1090.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1089, arg_1092, arg_1093) } }
func A_arbace_go_check_types_all_complex_QMARK__A_New() *A_arbace_go_check_types_all_complex_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_complex_QMARK__A{}; t.Ctor(); return t }
//line :398:1
func (t *A_arbace_go_check_types_all_complex_QMARK__A) Ctor() {}
//line :398:1
func (t *A_arbace_go_check_types_all_complex_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1094 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1094, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1096 lang.IFn; if linked_1095 == nil { ifn_1096 = lang.IFn_Cast(root_1094) } else { ifn_1096 = nil }; var arg_1097 any = t__0; var arg_1098 any = A_arbace_go_check_types_A_const_82.GetRawRoot__O(); if linked_1095 == nil { return ifn_1096.Invoke_O_O__O(arg_1097, arg_1098) } else { return linked_1095.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1094, arg_1097, arg_1098) } }

func A_arbace_go_check_types_common_under_A_New() *A_arbace_go_check_types_common_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_common_under_A{}; t.Ctor(); return t }
//line :400:1
func (t *A_arbace_go_check_types_common_under_A) Ctor() {}
//line :400:1
func (t *A_arbace_go_check_types_common_under_A) Invoke_O_O_O__O(self, t__0, cnd__1 any) any { { var ps__3 any; var root_1099 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, A_arbace_go_check_types_typeset_pairs_A_fn_class); var ifn_1101 lang.IFn





	if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = t__0; if linked_1100 == nil { ps__3 = ifn_1101.Invoke_O__O(arg_1102) } else { ps__3 = linked_1100.(*A_arbace_go_check_types_typeset_pairs_A).Invoke_O_O__O(root_1099, arg_1102) }
//line :400:1
	var ct__4 any; var cu__5 any; L1: for {






		var tmp1 any; var root_1103 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = ps__3; if linked_1104 == nil { tmp1 = ifn_1105.Invoke_O__O(arg_1106) } else { tmp1 = linked_1104.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1103, arg_1106) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(cu__5, nil) } else { var vec__219000186__6 any; var root_1107 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1109 lang.IFn

			if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = ps__3; if linked_1108 == nil { vec__219000186__6 = ifn_1109.Invoke_O__O(arg_1110) } else { vec__219000186__6 = linked_1108.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1107, arg_1110) }
//line :407:1
			var ty__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000186__6, lang.RT_IntCast_J__I_NoInit(0), nil); var u__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000186__6, lang.RT_IntCast_J__I_NoInit(1), nil); var e__9 any


			if jrt.J2g_Truth(cnd__1) { e__9 = lang.IFn_Cast(cnd__1).Invoke_O_O__O(ty__7, u__8) } else { e__9 = nil }
			if jrt.J2g_Truth(e__9) { return lang.Tuple_Create_O_O__IPersistentVector(nil, e__9) } else { if lang.Util_Identical_O_O__Z_NoInit(u__8, nil) { return A_arbace_go_check_types_A_const_159 } else { if lang.Util_Identical_O_O__Z_NoInit(cu__5, nil) {


				var tmp2 any; var root_1134 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = ps__3; if linked_1135 == nil { tmp2 = ifn_1136.Invoke_O__O(arg_1137) } else { tmp2 = linked_1135.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1134, arg_1137) }; ps__3, ct__4, cu__5 = tmp2, ty__7, u__8; continue L1 } else {
//line :411:1
					var tmp3 any; var and__1927000168__auto____10 any; var root_1111 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1113 lang.IFn



					if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = cu__5; if linked_1112 == nil { and__1927000168__auto____10 = ifn_1113.Invoke_O__O(arg_1114) } else { and__1927000168__auto____10 = linked_1112.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1111, arg_1114) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp4 any = A_arbace_go_check_types_A_const_98; var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____11 { var and__1927000168__auto____12 any; var root_1115 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1117 lang.IFn; if linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any = u__8; if linked_1116 == nil { and__1927000168__auto____12 = ifn_1117.Invoke_O__O(arg_1118) } else { and__1927000168__auto____12 = linked_1116.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1115, arg_1118) }; if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp5 any = A_arbace_go_check_types_A_const_98; tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp5, lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp3 = and__1927000168__auto____12 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else { tmp3 = and__1927000168__auto____10 }
//line :411:1
					if jrt.J2g_Truth(tmp3) {




						var tmp6 any; var root_1119 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1119, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1121 lang.IFn
						if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(2)); var arg_1123 any = lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(2)); if linked_1120 == nil { tmp6 = ifn_1121.Invoke_O_O__O(arg_1122, arg_1123) } else { tmp6 = linked_1120.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1119, arg_1122, arg_1123) }
//line :416:1
						if jrt.J2g_Truth(tmp6) { return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_4, nil, Lit_5, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_go_check_types_A_const_163.GetRawRoot__O()).Invoke_O__O(ct__4), nil, lang.IFn_Cast(A_arbace_go_check_types_A_const_163.GetRawRoot__O()).Invoke_O__O(ty__7), nil)).Ref()) } else { if lang.Util_Equiv_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(1)), lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(1))) {

							var tmp7 any; var root_1146 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1148 lang.IFn; if linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any = ps__3; if linked_1147 == nil { tmp7 = ifn_1148.Invoke_O__O(arg_1149) } else { tmp7 = linked_1147.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1146, arg_1149) }; ps__3, ct__4, cu__5 = tmp7, ct__4, cu__5; continue L1 } else {
//line :416:1
								var tmp8 any = A_arbace_go_check_types_A_const_160; if lang.Util_Equiv_O_O__Z_NoInit(tmp8, lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(1))) {


									var tmp9 any; var root_1150 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any = ps__3; if linked_1151 == nil { tmp9 = ifn_1152.Invoke_O__O(arg_1153) } else { tmp9 = linked_1151.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1150, arg_1153) }; ps__3, ct__4, cu__5 = tmp9, ty__7, u__8; continue L1 } else {
//line :416:1
										var tmp10 any; var root_1124 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1124, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1126 lang.IFn



										if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any = A_arbace_go_check_types_A_const_160; var arg_1128 any = lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(1)); if linked_1125 == nil { tmp10 = ifn_1126.Invoke_O_O__O(arg_1127, arg_1128) } else { tmp10 = linked_1125.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1124, arg_1127, arg_1128) }
//line :416:1
										if jrt.J2g_Truth(tmp10) { return A_arbace_go_check_types_A_const_161 } else { if A_arbace_go_check_types_A_const_75 != nil {




											var tmp11 any; var root_1154 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = ps__3; if linked_1155 == nil { tmp11 = ifn_1156.Invoke_O__O(arg_1157) } else { tmp11 = linked_1155.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1154, arg_1157) }; ps__3, ct__4, cu__5 = tmp11, ct__4, cu__5; continue L1 } else {
//line :416:1
												return nil } } } } } } else {
//line :411:1
													var tmp12 any; var root_1129 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1129, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1131 lang.IFn










													if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = cu__5; var arg_1133 any = u__8; if linked_1130 == nil { tmp12 = ifn_1131.Invoke_O_O__O(arg_1132, arg_1133) } else { tmp12 = linked_1130.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1129, arg_1132, arg_1133) }
//line :411:1
													if jrt.J2g_Truth(tmp12) { return A_arbace_go_check_types_A_const_162 } else { if A_arbace_go_check_types_A_const_75 != nil {











														var tmp13 any; var root_1158 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1160 lang.IFn; if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any = ps__3; if linked_1159 == nil { tmp13 = ifn_1160.Invoke_O__O(arg_1161) } else { tmp13 = linked_1159.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1158, arg_1161) }; ps__3, ct__4, cu__5 = tmp13, ct__4, cu__5; continue L1 } else {
//line :411:1
															return nil } } } } } } } } }; /*line :400:1*/panic("j2g: unreachable") }
//line :400:1
func (t *A_arbace_go_check_types_common_under_A) Invoke_O_O__O(self, t__0 any) any {



	var root_1162 any = A_arbace_go_check_types_A_const_164.GetRawRoot__O(); var linked_1163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1162, A_arbace_go_check_types_common_under_A_fn_class); var ifn_1164 lang.IFn; if linked_1163 == nil { ifn_1164 = lang.IFn_Cast(root_1162) } else { ifn_1164 = nil }; var arg_1165 any = t__0; var arg_1166 any; if linked_1163 == nil { return ifn_1164.Invoke_O_O__O(arg_1165, arg_1166) } else { return linked_1163.(*A_arbace_go_check_types_common_under_A).Invoke_O_O_O__O(root_1162, arg_1165, arg_1166)
	}
}


















func A_arbace_go_check_types_core_type_A_New() *A_arbace_go_check_types_core_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_core_type_A{}; t.Ctor(); return t }
//line :425:1
func (t *A_arbace_go_check_types_core_type_A) Ctor() {}
//line :425:1
func (t *A_arbace_go_check_types_core_type_A) Invoke_O_O__O(self, t__0 any) any {


	var root_1167 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any; var root_1171 any = A_arbace_go_check_types_A_const_164.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, A_arbace_go_check_types_common_under_A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = t__0; if linked_1172 == nil { arg_1170 = ifn_1173.Invoke_O__O(arg_1174) } else { arg_1170 = linked_1172.(*A_arbace_go_check_types_common_under_A).Invoke_O_O__O(root_1171, arg_1174) }; if linked_1168 == nil { return ifn_1169.Invoke_O__O(arg_1170) } else { return linked_1168.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1167, arg_1170)
	}
}








func A_arbace_go_check_types_terms_str_A_New() *A_arbace_go_check_types_terms_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_A{}; t.Ctor(); return t }
//line :439:1
func (t *A_arbace_go_check_types_terms_str_A) Ctor() {}
//line :439:1
func (t *A_arbace_go_check_types_terms_str_A) Invoke_O_O__O(self, terms__0 any) any {
	var tmp1 any; var root_1175 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1177 lang.IFn; if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any = terms__0; if linked_1176 == nil { tmp1 = ifn_1177.Invoke_O__O(arg_1178) } else { tmp1 = linked_1176.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1175, arg_1178) }; if jrt.J2g_Truth(tmp1) { return Lit_48 } else { var ts__2 any; var tmp2 *lang.Keyword = A_arbace_go_check_types_A_const_126; var or__1927000174__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(terms__0))

		if jrt.J2g_Truth(or__1927000174__auto____2) { ts__2 = or__1927000174__auto____2 } else { var root_1179 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any = A_arbace_go_check_types_A_const_163.GetRawRoot__O(); var arg_1183 any = terms__0; if linked_1180 == nil { ts__2 = ifn_1181.Invoke_O_O__O(arg_1182, arg_1183) } else { ts__2 = linked_1180.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1179, arg_1182, arg_1183) } }
		var root_1184 any = A_arbace_go_check_types_A_const_166.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1184, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1186 lang.IFn; if linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var arg_1187 any = Lit_49; var arg_1188 any; var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_go_check_types_terms_str_iter__219000191__219000195_A_New(); var tmp4 *jrt.Class; var fncls__1255 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000191__219000195_A_fn_class; if fncls__1255 == nil { var fncls__1255d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_go_check_types_terms_str_iter__219000191__219000195_A_fn_class = fncls__1255d; tmp4 = fncls__1255d } else { tmp4 = fncls__1255 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); arg_1188 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(ts__2); if linked_1185 == nil { return ifn_1186.Invoke_O_O__O(arg_1187, arg_1188) } else { return linked_1185.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1184, arg_1187, arg_1188) } } }
//line :443:1
func A_arbace_go_check_types_terms_str_iter__219000191__219000195_A_New() *A_arbace_go_check_types_terms_str_iter__219000191__219000195_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000191__219000195_A{}; t.Ctor(); return t }
//line :443:1
func (t *A_arbace_go_check_types_terms_str_iter__219000191__219000195_A) Ctor() {}
//line :443:1
func (t *A_arbace_go_check_types_terms_str_iter__219000191__219000195_A) Invoke_O_O__O(self, s__219000192__1 any) any { var tmp1 any = A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_A_New_O_O(s__219000192__1, self); var tmp2 *jrt.Class; var fncls__1254 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_A_fn_class; if fncls__1254 == nil { var fncls__1254d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_A_fn_class = fncls__1254d; tmp2 = fncls__1254d } else { tmp2 = fncls__1254 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :443:1
func A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_A{}; t.Ctor_O_O(p0, p1); return t }
//line :443:1
func (t *A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_A) Ctor_O_O(c__s__219000192, c__iter__219000191 any) { t.F_s__219000192 = c__s__219000192; t.F_iter__219000191 = c__iter__219000191 }
//line :443:1
func (t *A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_A) Invoke_O__O(self any) any { { var s__219000192__1 any; var t_ any = t.F_s__219000192; t.F_s__219000192 = nil; s__219000192__1 = t_; for { var temp__1927000414__auto____2 any; var root_1189 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1189, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1191 lang.IFn; if linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var arg_1192 any = s__219000192__1; if linked_1190 == nil { temp__1927000414__auto____2 = ifn_1191.Invoke_O__O(arg_1192) } else { temp__1927000414__auto____2 = linked_1190.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1189, arg_1192) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000192__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1193 any = A_arbace_go_check_types_A_const_131.GetRawRoot__O(); var linked_1194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1193, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1195 lang.IFn; if linked_1194 == nil { ifn_1195 = lang.IFn_Cast(root_1193) } else { ifn_1195 = nil }; var arg_1196 any = s__219000192__3; if linked_1194 == nil { tmp1 = ifn_1195.Invoke_O__O(arg_1196) } else { tmp1 = linked_1194.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1193, arg_1196) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1197 any = A_arbace_go_check_types_A_const_132.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1199 lang.IFn; if linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any = s__219000192__3; if linked_1198 == nil { c__1927001037__auto____4 = ifn_1199.Invoke_O__O(arg_1200) } else { c__1927001037__auto____4 = linked_1198.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1197, arg_1200) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000194__6 any; var root_1201 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1201, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1203 lang.IFn; if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1202 == nil { b__219000194__6 = ifn_1203.Invoke_O__O(arg_1204) } else { b__219000194__6 = linked_1202.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1201, arg_1204) }; var tmp2 any = A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_fn__219000197_A_New_O_I_O(b__219000194__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1214 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_fn__219000197_A_fn_class; if fncls__1214 == nil { var fncls__1214d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_fn__219000197_A_fn_class = fncls__1214d; tmp3 = fncls__1214d } else { tmp3 = fncls__1214 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1215 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any; var root_1220 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1220, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any = b__219000194__6; if linked_1221 == nil { arg_1218 = ifn_1222.Invoke_O__O(arg_1223) } else { arg_1218 = linked_1221.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1220, arg_1223) }; var arg_1219 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000191); var tmp5 any; var root_1224 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = s__219000192__3; if linked_1225 == nil { tmp5 = ifn_1226.Invoke_O__O(arg_1227) } else { tmp5 = linked_1225.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1224, arg_1227) }; arg_1219 = tmp4.Invoke_O__O(tmp5); if linked_1216 == nil { return ifn_1217.Invoke_O_O__O(arg_1218, arg_1219) } else { return linked_1216.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1215, arg_1218, arg_1219) } } else { var root_1228 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_1229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1228, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1230 lang.IFn; if linked_1229 == nil { ifn_1230 = lang.IFn_Cast(root_1228) } else { ifn_1230 = nil }; var arg_1231 any; var root_1233 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_1234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1233, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1235 lang.IFn; if linked_1234 == nil { ifn_1235 = lang.IFn_Cast(root_1233) } else { ifn_1235 = nil }; var arg_1236 any = b__219000194__6; if linked_1234 == nil { arg_1231 = ifn_1235.Invoke_O__O(arg_1236) } else { arg_1231 = linked_1234.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1233, arg_1236) }; var arg_1232 any; if linked_1229 == nil { return ifn_1230.Invoke_O_O__O(arg_1231, arg_1232) } else { return linked_1229.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1228, arg_1231, arg_1232) } } } else { var vec__219000202__4 any; var root_1237 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1237, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1239 lang.IFn; if linked_1238 == nil { ifn_1239 = lang.IFn_Cast(root_1237) } else { ifn_1239 = nil }; var arg_1240 any = s__219000192__3; if linked_1238 == nil { vec__219000202__4 = ifn_1239.Invoke_O__O(arg_1240) } else { vec__219000202__4 = linked_1238.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1237, arg_1240) }; var tilde__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000202__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000202__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1241 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_1242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1241, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1243 lang.IFn; if linked_1242 == nil { ifn_1243 = lang.IFn_Cast(root_1241) } else { ifn_1243 = nil }; var arg_1244 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 *jrt.String; if jrt.J2g_Truth(tilde__5) { tmp7 = Lit_53 } else { tmp7 = nil }; var tmp8 any = tmp7.Ref(); var tmp9 any; var root_1246 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1246, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var arg_1249 any = ty__6; if linked_1247 == nil { tmp9 = ifn_1248.Invoke_O__O(arg_1249) } else { tmp9 = linked_1247.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1246, arg_1249) }; arg_1244 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9)).Ref(); var arg_1245 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__219000191); var tmp11 any; var root_1250 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1250, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1252 lang.IFn; if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = s__219000192__3; if linked_1251 == nil { tmp11 = ifn_1252.Invoke_O__O(arg_1253) } else { tmp11 = linked_1251.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1250, arg_1253) }; arg_1245 = tmp10.Invoke_O__O(tmp11); if linked_1242 == nil { return ifn_1243.Invoke_O_O__O(arg_1244, arg_1245) } else { return linked_1242.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1241, arg_1244, arg_1245) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :443:1
func A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_fn__219000197_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_fn__219000197_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_fn__219000197_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :443:1
func (t *A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_fn__219000197_A) Ctor_O_I_O(c__b__219000194 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000194 = c__b__219000194; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :443:1
func (t *A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_fn__219000197_A) Invoke_O__O(self any) any { { var i__219000193__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000193__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__219000198__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000193__1)); var tilde__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000198__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000198__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1205 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1205, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1207 lang.IFn; if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = t.F_b__219000194; var arg_1209 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 *jrt.String; if jrt.J2g_Truth(tilde__3) { tmp3 = Lit_53 } else { tmp3 = nil }; var tmp4 any = tmp3.Ref(); var tmp5 any; var root_1210 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any = ty__4; if linked_1211 == nil { tmp5 = ifn_1212.Invoke_O__O(arg_1213) } else { tmp5 = linked_1211.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1210, arg_1213) }; arg_1209 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5)).Ref(); if linked_1206 == nil { ifn_1207.Invoke_O_O__O(arg_1208, arg_1209) } else { linked_1206.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1205, arg_1208, arg_1209) }; i__219000193__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000193__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_types_params_str_A_New() *A_arbace_go_check_types_params_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_params_str_A{}; t.Ctor(); return t }
//line :445:1
func (t *A_arbace_go_check_types_params_str_A) Ctor() {}
//line :445:1
func (t *A_arbace_go_check_types_params_str_A) Invoke_O_O_O__O(self, ps__0, variadic__1 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_27); var tmp2 any; var root_1256 any = A_arbace_go_check_types_A_const_166.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1258 lang.IFn
	if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = Lit_28; var arg_1260 any; var root_1261 any = A_arbace_go_check_types_A_const_167.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1263 lang.IFn; if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any; var tmp3 any = A_arbace_go_check_types_params_str_fn__219000208_A_New_O_O(ps__0, variadic__1); var tmp4 *jrt.Class; var fncls__1274 *jrt.Class = A_arbace_go_check_types_params_str_fn__219000208_A_fn_class; if fncls__1274 == nil { var fncls__1274d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_go_check_types_params_str_fn__219000208_A_fn_class = fncls__1274d; tmp4 = fncls__1274d } else { tmp4 = fncls__1274 }; arg_1264 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1265 any = ps__0; if linked_1262 == nil { arg_1260 = ifn_1263.Invoke_O_O__O(arg_1264, arg_1265) } else { arg_1260 = linked_1262.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1261, arg_1264, arg_1265) }; if linked_1257 == nil { tmp2 = ifn_1258.Invoke_O_O__O(arg_1259, arg_1260) } else { tmp2 = linked_1257.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1256, arg_1259, arg_1260) }
//line :446:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil)).Ref() }
func A_arbace_go_check_types_params_str_fn__219000208_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_params_str_fn__219000208_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_params_str_fn__219000208_A{}; t.Ctor_O_O(p0, p1); return t }
//line :447:1
func (t *A_arbace_go_check_types_params_str_fn__219000208_A) Ctor_O_O(c__ps, c__variadic any) { t.F_ps = c__ps; t.F_variadic = c__variadic }
//line :447:1
func (t *A_arbace_go_check_types_params_str_fn__219000208_A) Invoke_O_O_O__O(self, i__1, p__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = t.F_variadic; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_J__Z_NoInit(i__1, lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_ps))))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_30, nil); var tmp3 any; var root_1266 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1266, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1268 lang.IFn; if linked_1267 == nil { ifn_1268 = lang.IFn_Cast(root_1266) } else { ifn_1268 = nil }; var arg_1269 any = lang.RT_Nth_O_I__O_NoInit(p__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1267 == nil { tmp3 = ifn_1268.Invoke_O__O(arg_1269) } else { tmp3 = linked_1267.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1266, arg_1269) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else {
			var root_1270 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1270, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1272 lang.IFn; if linked_1271 == nil { ifn_1272 = lang.IFn_Cast(root_1270) } else { ifn_1272 = nil }; var arg_1273 any = p__2; if linked_1271 == nil { return ifn_1272.Invoke_O__O(arg_1273) } else { return linked_1271.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1270, arg_1273)
			}
		}
}
func A_arbace_go_check_types_sig_str_A_New() *A_arbace_go_check_types_sig_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sig_str_A{}; t.Ctor(); return t }
//line :454:1
func (t *A_arbace_go_check_types_sig_str_A) Ctor() {}
//line :454:1
func (t *A_arbace_go_check_types_sig_str_A) Invoke_O_O__O(self, p__219000211__0 any) any { var vec__219000212__2 any = p__219000211__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000212__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000212__2, lang.RT_IntCast_J__I_NoInit(1), nil); var rs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000212__2, lang.RT_IntCast_J__I_NoInit(2), nil); var variadic__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000212__2, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_1275 any = A_arbace_go_check_types_A_const_168.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1275, A_arbace_go_check_types_params_str_A_fn_class); var ifn_1277 lang.IFn; _ = ___3; if


	linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = ps__4; var arg_1279 any = variadic__6; if linked_1276 == nil { tmp2 = ifn_1277.Invoke_O_O__O(arg_1278, arg_1279) } else { tmp2 = linked_1276.(*A_arbace_go_check_types_params_str_A).Invoke_O_O_O__O(root_1275, arg_1278, arg_1279) }; var tmp3 any = tmp2; var tmp4 *jrt.String; var G__219000215__9_ int32 = lang.RT_Count_O__I_NoInit(rs__5); L1:
	switch { default: switch G__219000215__9_ { case 0: tmp4 = Lit_8; break L1; case 1: var r__10 any; var root_1281 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1281, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1283 lang.IFn

		if linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = rs__5; if linked_1282 == nil { r__10 = ifn_1283.Invoke_O__O(arg_1284) } else { r__10 = linked_1282.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1281, arg_1284) }; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_9, nil); var tmp6 any; var root_1285 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1287 lang.IFn; if linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any = r__10; if linked_1286 == nil { tmp6 = ifn_1287.Invoke_O__O(arg_1288) } else { tmp6 = linked_1286.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1285, arg_1288) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6))
//line :458:1
		break L1; default:
	}

		var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_38, nil, Lit_27); var tmp8 any; var root_1289 any = A_arbace_go_check_types_A_const_166.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = Lit_28; var arg_1293 any; var root_1294 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1294, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1296 lang.IFn; if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var arg_1298 any = rs__5; if linked_1295 == nil { arg_1293 = ifn_1296.Invoke_O_O__O(arg_1297, arg_1298) } else { arg_1293 = linked_1295.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1294, arg_1297, arg_1298) }; if linked_1290 == nil { tmp8 = ifn_1291.Invoke_O_O__O(arg_1292, arg_1293) } else { tmp8 = linked_1290.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1289, arg_1292, arg_1293) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil))}; return /*line :457:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4.Ref())).Ref() }





func A_arbace_go_check_types_field_str_A_New() *A_arbace_go_check_types_field_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_field_str_A{}; t.Ctor(); return t }
//line :463:1
func (t *A_arbace_go_check_types_field_str_A) Ctor() {}
//line :463:1
func (t *A_arbace_go_check_types_field_str_A) Invoke_O_O__O(self, f__0 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 *jrt.String; if jrt.J2g_Truth(A_arbace_go_check_types_A_const_169.Invoke_O__O(f__0)) { tmp2 = Lit_8 } else { tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_12.Invoke_O__O(f__0), nil)) }; var tmp3 any = tmp2.Ref(); var tmp4 any; var root_1299 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(f__0); if linked_1300 == nil { tmp4 = ifn_1301.Invoke_O__O(arg_1302) } else { tmp4 = linked_1300.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1299, arg_1302) }; var tmp5 any = tmp4; var tmp6 *jrt.String
	if jrt.J2g_Truth(A_arbace_go_check_types_A_const_106.Invoke_O__O(f__0)) { var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_9, nil); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_163.GetRawRoot__O()); var tmp9 any; var root_1307 any = A_arbace_go_check_types_A_const_170.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = A_arbace_go_check_types_A_const_106.Invoke_O__O(f__0); if linked_1308 == nil { tmp9 = ifn_1309.Invoke_O__O(arg_1310) } else { tmp9 = linked_1308.(*aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A).Invoke_O_O__O(root_1307, arg_1310) }; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8.Invoke_O__O(tmp9))) } else { tmp6 = nil }
//line :464:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp5, tmp6.Ref())).Ref()
}

func A_arbace_go_check_types_named_str_A_New() *A_arbace_go_check_types_named_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_str_A{}; t.Ctor(); return t }
//line :467:1
func (t *A_arbace_go_check_types_named_str_A) Ctor() {}
//line :467:1
func (t *A_arbace_go_check_types_named_str_A) Invoke_O_O__O(self, t__0 any) any { var i__2 any; var root_1311 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1311, A_arbace_go_check_types_info_A_fn_class); var ifn_1313 lang.IFn; if
										linked_1312 == nil { ifn_1313 = lang.IFn_Cast(root_1311) } else { ifn_1313 = nil }; var arg_1314 any = t__0; if linked_1312 == nil { i__2 = ifn_1313.Invoke_O__O(arg_1314) } else { i__2 = linked_1312.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1311, arg_1314) }; var base__3 any; var tmp1 any; var and__1927000168__auto____3 any = /*line :467:1*/A_arbace_go_check_types_A_const_171.Invoke_O__O(i__2); if

	jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1315 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1315, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1317 lang.IFn; if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any = A_arbace_go_check_types_A_const_171.Invoke_O__O(i__2); var arg_1319 any = A_arbace_go_check_types_A_const_172.Get__O(); if linked_1316 == nil { and__1927000168__auto____4 = ifn_1317.Invoke_O_O__O(arg_1318, arg_1319) } else { and__1927000168__auto____4 = linked_1316.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1315, arg_1318, arg_1319) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1320 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1322 lang.IFn; if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = A_arbace_go_check_types_A_const_173.Invoke_O__O(i__2); if linked_1321 == nil { tmp1 = ifn_1322.Invoke_O__O(arg_1323) } else { tmp1 = linked_1321.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1320, arg_1323) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		base__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_21, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_174.Invoke_O__O(i__2), nil, A_arbace_go_check_types_A_const_12.Invoke_O__O(i__2))).Ref() } else {
			base__3 = A_arbace_go_check_types_A_const_12.Invoke_O__O(i__2) }; var tmp2 any; var root_1324 any =
	A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1324, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1326 lang.IFn; if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any = A_arbace_go_check_types_A_const_175.Invoke_O__O(i__2); if linked_1325 == nil { tmp2 = ifn_1326.Invoke_O__O(arg_1327) } else { tmp2 = linked_1325.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1324, arg_1327) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_22, nil, Lit_23); var tmp4 any; var root_1328 any = A_arbace_go_check_types_A_const_166.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1330 lang.IFn; if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any = Lit_24; var arg_1332 any; var root_1333 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1334 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1333, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1335 lang.IFn; if linked_1334 == nil { ifn_1335 = lang.IFn_Cast(root_1333) } else { ifn_1335 = nil }; var arg_1336 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var arg_1337 any = A_arbace_go_check_types_A_const_175.Invoke_O__O(i__2); if linked_1334 == nil { arg_1332 = ifn_1335.Invoke_O_O__O(arg_1336, arg_1337) } else { arg_1332 = linked_1334.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1333, arg_1336, arg_1337) }; if linked_1329 == nil { tmp4 = ifn_1330.Invoke_O_O__O(arg_1331, arg_1332) } else { tmp4 = linked_1329.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1328, arg_1331, arg_1332) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, base__3, nil, tmp4, nil)).Ref() } else {
//line :472:1
			return base__3 } }



func A_arbace_go_check_types_type_str_A_New() *A_arbace_go_check_types_type_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_A{}; t.Ctor(); return t }
//line :476:1
func (t *A_arbace_go_check_types_type_str_A) Ctor() {}
//line :476:1
func (t *A_arbace_go_check_types_type_str_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_1338 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_1340 lang.IFn
	if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = t__0; if linked_1339 == nil { tmp1 = ifn_1340.Invoke_O__O(arg_1341) } else { tmp1 = linked_1339.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_1338, arg_1341) }
//line :479:1
	if jrt.J2g_Truth(tmp1) {
		var tmp2 any = A_arbace_go_check_types_A_const_176.GetRawRoot__O(); var tmp3 any; var root_1342 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1344 lang.IFn; if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = t__0; if linked_1343 == nil { tmp3 = ifn_1344.Invoke_O__O(arg_1345) } else { tmp3 = linked_1343.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1342, arg_1345) }; return lang.RT_Get_O_O_O__O_NoInit(tmp2, t__0, tmp3) } else {
//line :479:1
			var tmp4 any; var root_1346 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1348 lang.IFn

			if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = t__0; if linked_1347 == nil { tmp4 = ifn_1348.Invoke_O__O(arg_1349) } else { tmp4 = linked_1347.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1346, arg_1349) }
//line :479:1
			if jrt.J2g_Truth(tmp4) {

				var root_1350 any = A_arbace_go_check_types_A_const_178.GetRawRoot__O(); var linked_1351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1350, A_arbace_go_check_types_named_str_A_fn_class); var ifn_1352 lang.IFn; if linked_1351 == nil { ifn_1352 = lang.IFn_Cast(root_1350) } else { ifn_1352 = nil }; var arg_1353 any = t__0; if linked_1351 == nil { return ifn_1352.Invoke_O__O(arg_1353) } else { return linked_1351.(*A_arbace_go_check_types_named_str_A).Invoke_O_O__O(root_1350, arg_1353) } } else {
//line :479:1
					var tmp5 any; var root_1354 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_1355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1354, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_1356 lang.IFn


					if linked_1355 == nil { ifn_1356 = lang.IFn_Cast(root_1354) } else { ifn_1356 = nil }; var arg_1357 any = t__0; if linked_1355 == nil { tmp5 = ifn_1356.Invoke_O__O(arg_1357) } else { tmp5 = linked_1355.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_1354, arg_1357) }
//line :479:1
					if jrt.J2g_Truth(tmp5) {


						var tmp6 *lang.Keyword = A_arbace_go_check_types_A_const_12; var tmp7 any; var root_1358 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, A_arbace_go_check_types_info_A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any = t__0; if linked_1359 == nil { tmp7 = ifn_1360.Invoke_O__O(arg_1361) } else { tmp7 = linked_1359.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1358, arg_1361) }; return tmp6.Invoke_O__O(tmp7) } else {
//line :479:1
							if A_arbace_go_check_types_A_const_75 != nil { var G__219000219__2_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))




								switch lang.Util_Hash_O__I_NoInit(G__219000219__2_) >> 5 & 31 { case 0: if any(G__219000219__2_) == any(A_arbace_go_check_types_A_const_100) {





















									var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_27); var tmp9 any; var root_1363 any = A_arbace_go_check_types_A_const_166.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1363, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1365 lang.IFn; if linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any = Lit_28; var arg_1367 any; var root_1368 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1368, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1370 lang.IFn; if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var arg_1372 any; var root_1373 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any = t__0; if linked_1374 == nil { arg_1372 = ifn_1375.Invoke_O__O(arg_1376) } else { arg_1372 = linked_1374.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1373, arg_1376) }; if linked_1369 == nil { arg_1367 = ifn_1370.Invoke_O_O__O(arg_1371, arg_1372) } else { arg_1367 = linked_1369.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1368, arg_1371, arg_1372) }; if linked_1364 == nil { tmp9 = ifn_1365.Invoke_O_O__O(arg_1366, arg_1367) } else { tmp9 = linked_1364.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1363, arg_1366, arg_1367) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil)).Ref() }
//line :484:1
								case 1: if any(G__219000219__2_) == any(A_arbace_go_check_types_A_const_86) { var ms__3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var ts__4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var tmp10 any; var and__1927000168__auto____5 any; var root_1377 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1379 lang.IFn












									if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any = ms__3; if linked_1378 == nil { and__1927000168__auto____5 = ifn_1379.Invoke_O__O(arg_1380) } else { and__1927000168__auto____5 = linked_1378.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1377, arg_1380) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(ts__4, nil)).Ref() } else { tmp10 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp10) { return Lit_57 } else {

										var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_58, nil, Lit_59); var tmp12 any; var root_1381 any = A_arbace_go_check_types_A_const_166.GetRawRoot__O(); var linked_1382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1381, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1383 lang.IFn
										if linked_1382 == nil { ifn_1383 = lang.IFn_Cast(root_1381) } else { ifn_1383 = nil }; var arg_1384 any = Lit_60; var arg_1385 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_129.GetRawRoot__O()); var tmp14 any; if jrt.J2g_Truth(A_arbace_go_check_types_A_const_110.Invoke_O__O(ts__4)) { tmp14 = A_arbace_go_check_types_A_const_179 } else { tmp14 = nil }; var tmp15 any = tmp14; var tmp16 any; var iter__1927001039__auto____8 any; var tmp17 any = A_arbace_go_check_types_type_str_iter__219000220__219000224_A_New(); var tmp18 *jrt.Class; var fncls__1458 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000220__219000224_A_fn_class
										if fncls__1458 == nil { var fncls__1458d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_go_check_types_type_str_iter__219000220__219000224_A_fn_class = fncls__1458d; tmp18 = fncls__1458d } else { tmp18 = fncls__1458 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); tmp16 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(ms__3)
//line :500:1
										var tmp19 any = tmp16; var tmp20 lang.IPersistentVector; var tmp21 any; var and__1927000168__auto____8 any; var root_1459 any = A_arbace_go_check_types_A_const_143.GetRawRoot__O(); var linked_1460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1459, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1461 lang.IFn

										if linked_1460 == nil { ifn_1461 = lang.IFn_Cast(root_1459) } else { ifn_1461 = nil }; var arg_1462 any = ts__4; if linked_1460 == nil { and__1927000168__auto____8 = ifn_1461.Invoke_O__O(arg_1462) } else { and__1927000168__auto____8 = linked_1460.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1459, arg_1462) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1463 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1463, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1465 lang.IFn; if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = A_arbace_go_check_types_A_const_108; var arg_1467 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__4); if linked_1464 == nil { tmp21 = ifn_1465.Invoke_O_O__O(arg_1466, arg_1467) } else { tmp21 = linked_1464.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1463, arg_1466, arg_1467) } } else { tmp21 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp21) { var tmp22 any; var root_1468 any = A_arbace_go_check_types_A_const_181.GetRawRoot__O(); var linked_1469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1468, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_1470 lang.IFn
											if linked_1469 == nil { ifn_1470 = lang.IFn_Cast(root_1468) } else { ifn_1470 = nil }; var arg_1471 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__4); if linked_1469 == nil { tmp22 = ifn_1470.Invoke_O__O(arg_1471) } else { tmp22 = linked_1469.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_1468, arg_1471) }
//line :502:1
											tmp20 = lang.Tuple_Create_O__IPersistentVector(tmp22) } else { tmp20 = nil }
//line :500:1
										arg_1385 = tmp13.Invoke_O_O_O__O(tmp15, tmp19, tmp20); if linked_1382 == nil { tmp12 = ifn_1383.Invoke_O_O__O(arg_1384, arg_1385) } else { tmp12 = linked_1382.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1381, arg_1384, arg_1385) }
//line :499:1
										return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, nil)).Ref() } }
//line :484:1
								case 3: if any(G__219000219__2_) == any(A_arbace_go_check_types_A_const_87) {
									var tmp23 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil); var tmp24 any; var root_1472 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1472, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1474 lang.IFn; if linked_1473 == nil { ifn_1474 = lang.IFn_Cast(root_1472) } else { ifn_1474 = nil }; var arg_1475 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1473 == nil { tmp24 = ifn_1474.Invoke_O__O(arg_1475) } else { tmp24 = linked_1473.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1472, arg_1475) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp23, jrt.RefArrayOf(jrt.Object_class, nil, tmp24)).Ref() }
//line :484:1
								case 4: if any(G__219000219__2_) == any(A_arbace_go_check_types_A_const_97) {


									var tmp25 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_22, nil, Lit_23, nil); var tmp26 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp27 any; var root_1476 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1476, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1478 lang.IFn; if linked_1477 == nil { ifn_1478 = lang.IFn_Cast(root_1476) } else { ifn_1478 = nil }; var arg_1479 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_1477 == nil { tmp27 = ifn_1478.Invoke_O__O(arg_1479) } else { tmp27 = linked_1477.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1476, arg_1479) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp25, jrt.RefArrayOf(jrt.Object_class, nil, tmp26, nil, tmp27)).Ref() }
//line :484:1
								case 8: if any(G__219000219__2_) == any(A_arbace_go_check_types_A_const_95) {



									var tmp28 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_23, nil); var tmp29 any; var root_1484 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1485 == nil { tmp29 = ifn_1486.Invoke_O__O(arg_1487) } else { tmp29 = linked_1485.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1484, arg_1487) }; var tmp30 any = tmp29; var tmp31 any; var root_1488 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_1489 == nil { tmp31 = ifn_1490.Invoke_O__O(arg_1491) } else { tmp31 = linked_1489.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1488, arg_1491) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp28, jrt.RefArrayOf(jrt.Object_class, nil, tmp30, nil, tmp31)).Ref() }
//line :484:1
								case 14: if any(G__219000219__2_) == any(A_arbace_go_check_types_A_const_96) {

									var tmp32 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_64, nil); var tmp33 any; var root_1492 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1493 == nil { tmp33 = ifn_1494.Invoke_O__O(arg_1495) } else { tmp33 = linked_1493.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1492, arg_1495) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp32, jrt.RefArrayOf(jrt.Object_class, nil, tmp33)).Ref() }
//line :484:1
								case 16: if any(G__219000219__2_) == any(A_arbace_go_check_types_A_const_98) { var e__3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var es__4 any; var root_1496 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1498 lang.IFn





									if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = e__3; if linked_1497 == nil { es__4 = ifn_1498.Invoke_O__O(arg_1499) } else { es__4 = linked_1497.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1496, arg_1499) }
//line :484:1
									var es__5 any; var tmp34 any; var tmp35 any = A_arbace_go_check_types_A_const_160; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp35, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)))






									if and__1927000168__auto____5_2 { var and__1927000168__auto____6 any; var root_1500 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1500, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1502 lang.IFn; if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any = e__3; if linked_1501 == nil { and__1927000168__auto____6 = ifn_1502.Invoke_O__O(arg_1503) } else { and__1927000168__auto____6 = linked_1501.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1500, arg_1503) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp36 any = A_arbace_go_check_types_A_const_98; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp36, lang.RT_Nth_O_I__O_NoInit(e__3, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____7 { var tmp37 any = A_arbace_go_check_types_A_const_182; tmp34 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp37, lang.RT_Nth_O_I__O_NoInit(e__3, lang.RT_IntCast_J__I_NoInit(1)))).Ref() } else { tmp34 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp34 = and__1927000168__auto____6 } } else { tmp34 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref() }; if jrt.J2g_Truth(tmp34) {
										es__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_27), jrt.RefArrayOf(jrt.Object_class, nil, es__4, nil)).Ref() } else {
//line :491:1
											es__5 = es__4 }
//line :484:1
									var G__219000230__6_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1))








									switch lang.Util_Hash_O__I_NoInit(G__219000230__6_) >> 7 & 3 { case 0: if any(G__219000230__6_) == any(A_arbace_go_check_types_A_const_182) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_65, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; case 2: if any(G__219000230__6_) == any(A_arbace_go_check_types_A_const_160) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_66, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; case 3: if any(G__219000230__6_) == any(A_arbace_go_check_types_A_const_183) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_68, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__219000230__6_))))) }
//line :484:1
								case 27: if any(G__219000219__2_) == any(A_arbace_go_check_types_A_const_103) {









									var tmp38 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_69, nil); var tmp39 any; var root_1505 any = A_arbace_go_check_types_A_const_180.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = t__0; if linked_1506 == nil { tmp39 = ifn_1507.Invoke_O__O(arg_1508) } else { tmp39 = linked_1506.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1505, arg_1508) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp38, jrt.RefArrayOf(jrt.Object_class, nil, tmp39)).Ref() }
//line :484:1
								case 28: if any(G__219000219__2_) == any(A_arbace_go_check_types_A_const_120) {




















									var root_1509 any = A_arbace_go_check_types_A_const_181.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_1511 lang.IFn; if linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1510 == nil { return ifn_1511.Invoke_O__O(arg_1512) } else { return linked_1510.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_1509, arg_1512) } }
//line :484:1
								case 31: if any(G__219000219__2_) == any(A_arbace_go_check_types_A_const_105) {










									var tmp40 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_70, nil, Lit_59); var tmp41 any; var root_1513 any = A_arbace_go_check_types_A_const_166.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1515 lang.IFn; if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = Lit_60; var arg_1517 any; var root_1518 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1518, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = A_arbace_go_check_types_A_const_184.GetRawRoot__O(); var arg_1522 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1519 == nil { arg_1517 = ifn_1520.Invoke_O_O__O(arg_1521, arg_1522) } else { arg_1517 = linked_1519.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1518, arg_1521, arg_1522) }; if linked_1514 == nil { tmp41 = ifn_1515.Invoke_O_O__O(arg_1516, arg_1517) } else { tmp41 = linked_1514.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1513, arg_1516, arg_1517) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp40, jrt.RefArrayOf(jrt.Object_class, nil, tmp41, nil)).Ref() }
//line :484:1
								default:
								}





















								return lang.IFn_Cast(A_arbace_go_check_types_A_const_163.GetRawRoot__O()).Invoke_O__O(t__0) } else {
//line :479:1
									return nil
								}
						}
				}
		}
}
















func A_arbace_go_check_types_type_str_iter__219000220__219000224_A_New() *A_arbace_go_check_types_type_str_iter__219000220__219000224_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000220__219000224_A{}; t.Ctor(); return t }
//line :501:1
func (t *A_arbace_go_check_types_type_str_iter__219000220__219000224_A) Ctor() {}
//line :501:1
func (t *A_arbace_go_check_types_type_str_iter__219000220__219000224_A) Invoke_O_O__O(self, s__219000221__1 any) any { var tmp1 any = A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_A_New_O_O(self, s__219000221__1); var tmp2 *jrt.Class; var fncls__1457 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_A_fn_class; if fncls__1457 == nil { var fncls__1457d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_A_fn_class = fncls__1457d; tmp2 = fncls__1457d } else { tmp2 = fncls__1457 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :501:1
func A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_A{}; t.Ctor_O_O(p0, p1); return t }
//line :501:1
func (t *A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_A) Ctor_O_O(c__iter__219000220, c__s__219000221 any) { t.F_iter__219000220 = c__iter__219000220; t.F_s__219000221 = c__s__219000221 }
//line :501:1
func (t *A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_A) Invoke_O__O(self any) any { { var s__219000221__1 any; var t_ any = t.F_s__219000221; t.F_s__219000221 = nil; s__219000221__1 = t_; for { var temp__1927000414__auto____2 any; var root_1392 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_1393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1392, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1394 lang.IFn; if linked_1393 == nil { ifn_1394 = lang.IFn_Cast(root_1392) } else { ifn_1394 = nil }; var arg_1395 any = s__219000221__1; if linked_1393 == nil { temp__1927000414__auto____2 = ifn_1394.Invoke_O__O(arg_1395) } else { temp__1927000414__auto____2 = linked_1393.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1392, arg_1395) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000221__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1396 any = A_arbace_go_check_types_A_const_131.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = s__219000221__3; if linked_1397 == nil { tmp1 = ifn_1398.Invoke_O__O(arg_1399) } else { tmp1 = linked_1397.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1396, arg_1399) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1400 any = A_arbace_go_check_types_A_const_132.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any = s__219000221__3; if linked_1401 == nil { c__1927001037__auto____4 = ifn_1402.Invoke_O__O(arg_1403) } else { c__1927001037__auto____4 = linked_1401.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1400, arg_1403) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000223__6 any; var root_1404 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1404, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1406 lang.IFn; if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1405 == nil { b__219000223__6 = ifn_1406.Invoke_O__O(arg_1407) } else { b__219000223__6 = linked_1405.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1404, arg_1407) }; var tmp2 any = A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_fn__219000226_A_New_O_I_O(b__219000223__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1417 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_fn__219000226_A_fn_class; if fncls__1417 == nil { var fncls__1417d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_fn__219000226_A_fn_class = fncls__1417d; tmp3 = fncls__1417d } else { tmp3 = fncls__1417 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1418 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1420 lang.IFn; if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any; var root_1423 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1423, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1425 lang.IFn; if linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; var arg_1426 any = b__219000223__6; if linked_1424 == nil { arg_1421 = ifn_1425.Invoke_O__O(arg_1426) } else { arg_1421 = linked_1424.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1423, arg_1426) }; var arg_1422 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000220); var tmp5 any; var root_1427 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1429 lang.IFn; if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = s__219000221__3; if linked_1428 == nil { tmp5 = ifn_1429.Invoke_O__O(arg_1430) } else { tmp5 = linked_1428.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1427, arg_1430) }; arg_1422 = tmp4.Invoke_O__O(tmp5); if linked_1419 == nil { return ifn_1420.Invoke_O_O__O(arg_1421, arg_1422) } else { return linked_1419.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1418, arg_1421, arg_1422) } } else { var root_1431 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any; var root_1436 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1438 lang.IFn; if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = b__219000223__6; if linked_1437 == nil { arg_1434 = ifn_1438.Invoke_O__O(arg_1439) } else { arg_1434 = linked_1437.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1436, arg_1439) }; var arg_1435 any; if linked_1432 == nil { return ifn_1433.Invoke_O_O__O(arg_1434, arg_1435) } else { return linked_1432.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1431, arg_1434, arg_1435) } } } else { var m__4 any; var root_1440 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1440, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1442 lang.IFn; if linked_1441 == nil { ifn_1442 = lang.IFn_Cast(root_1440) } else { ifn_1442 = nil }; var arg_1443 any = s__219000221__3; if linked_1441 == nil { m__4 = ifn_1442.Invoke_O__O(arg_1443) } else { m__4 = linked_1441.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1440, arg_1443) }; var root_1444 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1444, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__4); var tmp8 any; var root_1449 any = A_arbace_go_check_types_A_const_180.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1449, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1451 lang.IFn; if linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(m__4); if linked_1450 == nil { tmp8 = ifn_1451.Invoke_O__O(arg_1452) } else { tmp8 = linked_1450.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1449, arg_1452) }; arg_1447 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8)).Ref(); var arg_1448 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__219000220); var tmp10 any; var root_1453 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1455 lang.IFn; if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = s__219000221__3; if linked_1454 == nil { tmp10 = ifn_1455.Invoke_O__O(arg_1456) } else { tmp10 = linked_1454.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1453, arg_1456) }; arg_1448 = tmp9.Invoke_O__O(tmp10); if linked_1445 == nil { return ifn_1446.Invoke_O_O__O(arg_1447, arg_1448) } else { return linked_1445.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1444, arg_1447, arg_1448) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :501:1
func A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_fn__219000226_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_fn__219000226_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_fn__219000226_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :501:1
func (t *A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_fn__219000226_A) Ctor_O_I_O(c__b__219000223 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000223 = c__b__219000223; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :501:1
func (t *A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_fn__219000226_A) Invoke_O__O(self any) any { { var i__219000222__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000222__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000222__1)); var root_1408 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = t.F_b__219000223; var arg_1412 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__2); var tmp4 any; var root_1413 any = A_arbace_go_check_types_A_const_180.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1415 lang.IFn; if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(m__2); if linked_1414 == nil { tmp4 = ifn_1415.Invoke_O__O(arg_1416) } else { tmp4 = linked_1414.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1413, arg_1416) }; arg_1412 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref(); if linked_1409 == nil { ifn_1410.Invoke_O_O__O(arg_1411, arg_1412) } else { linked_1409.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1408, arg_1411, arg_1412) }; i__219000222__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000222__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }














func A_arbace_go_check_types_align_up_A_New() *A_arbace_go_check_types_align_up_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_align_up_A{}; t.Ctor(); return t }
//line :516:1
func (t *A_arbace_go_check_types_align_up_A) Ctor() {}
//line :516:1
func (t *A_arbace_go_check_types_align_up_A) InvokePrim_O_J_J__J(self any, x__0, a__1 int64) int64 {


	return lang.Numbers_AndNot_J_J__J_NoInit(lang.Numbers_Unchecked_add_J_J__J_NoInit(x__0, lang.Numbers_Dec_J__J_NoInit(a__1)), lang.Numbers_Dec_J__J_NoInit(a__1)) }
//line :516:1
func (t *A_arbace_go_check_types_align_up_A) Invoke_O_O_O__O(self, p_x__0, p_a__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_J__J(self, lang.RT_LongCast_O__J_NoInit(p_x__0), lang.RT_LongCast_O__J_NoInit(p_a__1))).Ref() }




func A_arbace_go_check_types_sync_atomic_align64_QMARK__A_New() *A_arbace_go_check_types_sync_atomic_align64_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sync_atomic_align64_QMARK__A{}; t.Ctor(); return t }
//line :521:1
func (t *A_arbace_go_check_types_sync_atomic_align64_QMARK__A) Ctor() {}
//line :521:1
func (t *A_arbace_go_check_types_sync_atomic_align64_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_1523 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1523, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1525 lang.IFn; if



	linked_1524 == nil { ifn_1525 = lang.IFn_Cast(root_1523) } else { ifn_1525 = nil }; var arg_1526 any = t__0; if linked_1524 == nil { and__1927000168__auto____2 = ifn_1525.Invoke_O__O(arg_1526) } else { and__1927000168__auto____2 = linked_1524.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1523, arg_1526) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var i__3 any; var root_1527 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1527, A_arbace_go_check_types_info_A_fn_class); var ifn_1529 lang.IFn
		if linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any = t__0; if linked_1528 == nil { i__3 = ifn_1529.Invoke_O__O(arg_1530) } else { i__3 = linked_1528.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1527, arg_1530) }
//line :525:1
		var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_40, A_arbace_go_check_types_A_const_12.Invoke_O__O(i__3))

		if and__1927000168__auto____4 {
			var root_1531 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1531, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1533 lang.IFn; if linked_1532 == nil { ifn_1533 = lang.IFn_Cast(root_1531) } else { ifn_1533 = nil }; var arg_1534 any = A_arbace_go_check_types_A_const_185; var arg_1535 any = A_arbace_go_check_types_A_const_171.Invoke_O__O(i__3); if linked_1532 == nil { return ifn_1533.Invoke_O_O__O(arg_1534, arg_1535) } else { return linked_1532.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1531, arg_1534, arg_1535) } } else {
//line :527:1
				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else {
//line :525:1
					return and__1927000168__auto____2 } }




func A_arbace_go_check_types_alignof_A_New() *A_arbace_go_check_types_alignof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alignof_A{}; t.Ctor(); return t }
//line :530:1
func (t *A_arbace_go_check_types_alignof_A) Ctor() {}
//line :530:1
func (t *A_arbace_go_check_types_alignof_A) InvokePrim_O_O__J(self, t__0 any) int64 { var tmp1 any; var u__2 any; var root_1536 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1536, A_arbace_go_check_types_under_A_fn_class); var ifn_1538 lang.IFn; if
											linked_1537 == nil { ifn_1538 = lang.IFn_Cast(root_1536) } else { ifn_1538 = nil }; var arg_1539 any = t__0; if linked_1537 == nil { u__2 = ifn_1538.Invoke_O__O(arg_1539) } else { u__2 = linked_1537.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1536, arg_1539) }; var tmp2 any; var and__1927000168__auto____3 any; var root_1540 any =
											A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1540, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1542 lang.IFn; if
											linked_1541 == nil { ifn_1542 = lang.IFn_Cast(root_1540) } else { ifn_1542 = nil }; var arg_1543 any = u__2; if linked_1541 == nil { and__1927000168__auto____3 = ifn_1542.Invoke_O__O(arg_1543) } else { and__1927000168__auto____3 = linked_1541.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1540, arg_1543) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_go_check_types_A_const_97; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp2 = and__1927000168__auto____3 }; if /*line :532:1*/ jrt.J2g_Truth(tmp2) {
												var root_1544 any = A_arbace_go_check_types_A_const_186.GetRawRoot__O(); var linked_1545 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1544, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1546 lang.IFn; if linked_1545 == nil { ifn_1546 = lang.IFn_Cast(root_1544) } else { ifn_1546 = nil }; var arg_1547 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)); if linked_1545 == nil { tmp1 = ifn_1546.Invoke_O__O(arg_1547) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_1545.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1544, arg_1547)).Ref() } } else {
//line :532:1
			var tmp4 any; var and__1927000168__auto____3_2 any; var root_1548 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1550 lang.IFn

			if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any = u__2; if linked_1549 == nil { and__1927000168__auto____3_2 = ifn_1550.Invoke_O__O(arg_1551) } else { and__1927000168__auto____3_2 = linked_1549.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1548, arg_1551) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) { var tmp5 any = A_arbace_go_check_types_A_const_105; tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp5, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp4 = and__1927000168__auto____3_2 }
//line :532:1
			if jrt.J2g_Truth(tmp4) {


				var tmp6 any; var and__1927000168__auto____3_3 any; var root_1552 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1552, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1554 lang.IFn; if linked_1553 == nil { ifn_1554 = lang.IFn_Cast(root_1552) } else { ifn_1554 = nil }; var arg_1555 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1553 == nil { and__1927000168__auto____3_3 = ifn_1554.Invoke_O__O(arg_1555) } else { and__1927000168__auto____3_3 = linked_1553.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1552, arg_1555) }; if jrt.J2g_Truth(and__1927000168__auto____3_3) { var root_1556 any = A_arbace_go_check_types_A_const_187.GetRawRoot__O(); var linked_1557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1556, A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class); var ifn_1558 lang.IFn; if linked_1557 == nil { ifn_1558 = lang.IFn_Cast(root_1556) } else { ifn_1558 = nil }; var arg_1559 any = t__0; if linked_1557 == nil { tmp6 = ifn_1558.Invoke_O__O(arg_1559) } else { tmp6 = linked_1557.(*A_arbace_go_check_types_sync_atomic_align64_QMARK__A).Invoke_O_O__O(root_1556, arg_1559) } } else { tmp6 = and__1927000168__auto____3_3 }; if jrt.J2g_Truth(tmp6) { tmp1 = A_arbace_go_check_types_A_const_24 } else {

					var root_1560 any = A_arbace_go_check_types_A_const_188.GetRawRoot__O(); var linked_1561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1560, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1562 lang.IFn; if linked_1561 == nil { ifn_1562 = lang.IFn_Cast(root_1560) } else { ifn_1562 = nil }; var arg_1563 any; var tmp7 any = A_arbace_go_check_types_alignof_fn__219000234_A_New(); var tmp8 *jrt.Class; var fncls__1570 *jrt.Class = A_arbace_go_check_types_alignof_fn__219000234_A_fn_class; if fncls__1570 == nil { var fncls__1570d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_go_check_types_alignof_fn__219000234_A_fn_class = fncls__1570d; tmp8 = fncls__1570d } else { tmp8 = fncls__1570 }; arg_1563 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_1564 any = A_arbace_go_check_types_A_const_15; var arg_1565 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1561 == nil { tmp1 = ifn_1562.Invoke_O_O_O__O(arg_1563, arg_1564, arg_1565) } else { tmp1 = linked_1561.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1560, arg_1563, arg_1564, arg_1565) } } } else {
//line :532:1
						var tmp9 any; var and__1927000168__auto____3_4 any; var root_1571 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1571, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1573 lang.IFn





						if linked_1572 == nil { ifn_1573 = lang.IFn_Cast(root_1571) } else { ifn_1573 = nil }; var arg_1574 any = u__2; if linked_1572 == nil { and__1927000168__auto____3_4 = ifn_1573.Invoke_O__O(arg_1574) } else { and__1927000168__auto____3_4 = linked_1572.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1571, arg_1574) }; if jrt.J2g_Truth(and__1927000168__auto____3_4) { var root_1575 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1575, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1577 lang.IFn; if linked_1576 == nil { ifn_1577 = lang.IFn_Cast(root_1575) } else { ifn_1577 = nil }; var arg_1578 any = A_arbace_go_check_types_A_const_189; var arg_1579 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)); if linked_1576 == nil { tmp9 = ifn_1577.Invoke_O_O__O(arg_1578, arg_1579) } else { tmp9 = linked_1576.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1575, arg_1578, arg_1579) } } else { tmp9 = and__1927000168__auto____3_4 }
//line :532:1
						if jrt.J2g_Truth(tmp9) { tmp1 = A_arbace_go_check_types_A_const_190.GetRawRoot__O() } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_40, u__2) { tmp1 = A_arbace_go_check_types_A_const_190.GetRawRoot__O() } else { if A_arbace_go_check_types_A_const_75 != nil { var a__3 any; var root_1580 any = A_arbace_go_check_types_A_const_191.GetRawRoot__O(); var linked_1581 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1580, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1582 lang.IFn








							if linked_1581 == nil { ifn_1582 = lang.IFn_Cast(root_1580) } else { ifn_1582 = nil }; var arg_1583 any = t__0; if linked_1581 == nil { a__3 = ifn_1582.Invoke_O__O(arg_1583) } else { a__3 = jrt.Long_ValueOf_J__Long_NoInit(linked_1581.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1580, arg_1583)).Ref() }
//line :532:1
							var a__4 any; var tmp10 bool
							var na_1584 any = a__3
							var na_1585 int64 = 1







							if jrt.Long_InstanceOf(na_1584) { var n0_1586 int64 = jrt.NN(jrt.Long_Cast(na_1584)).LongValue__J(); var n1_1587 int64 = na_1585; tmp10 = n0_1586 < n1_1587 } else { tmp10 = lang.Numbers_Lt_O_J__Z_NoInit(na_1584, na_1585) }; if tmp10 { a__4 = A_arbace_go_check_types_A_const_15 } else { a__4 = a__3 }
//line :532:1
							var a__5 any; var tmp11 any; var root_1589 any = A_arbace_go_check_types_A_const_82.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1589, A_arbace_go_check_types_complex_type_QMARK__A_fn_class); var ifn_1591 lang.IFn










							if linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any = t__0; if linked_1590 == nil { tmp11 = ifn_1591.Invoke_O__O(arg_1592) } else { tmp11 = linked_1590.(*A_arbace_go_check_types_complex_type_QMARK__A).Invoke_O_O__O(root_1589, arg_1592) }; if jrt.J2g_Truth(tmp11) { var na_1593 any = a__4; var na_1594 int64 = 2; if jrt.Long_InstanceOf(na_1593) { var n0_1595 int64 = jrt.NN(jrt.Long_Cast(na_1593)).LongValue__J(); var n1_1596 int64 = na_1594; if n1_1596 == 0 { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1593, na_1594) } else { a__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_1595 / n1_1596).Ref() } } else { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1593, na_1594) } } else { a__5 = a__4 }
							tmp1 = lang.Numbers_Min_O_O__O_NoInit(a__5, A_arbace_go_check_types_A_const_192.GetRawRoot__O()) } else {
//line :532:1
								tmp1 = nil } } } } }; return /*line :530:1*/ jrt.Number_Cast(tmp1).LongValue__J() }
//line :530:1
func (t *A_arbace_go_check_types_alignof_A) Invoke_O_O__O(self, t__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, t__0)).Ref() }






func A_arbace_go_check_types_alignof_fn__219000234_A_New() *A_arbace_go_check_types_alignof_fn__219000234_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alignof_fn__219000234_A{}; t.Ctor(); return t }
//line :537:1
func (t *A_arbace_go_check_types_alignof_fn__219000234_A) Ctor() {}
//line :537:1
func (t *A_arbace_go_check_types_alignof_fn__219000234_A) Invoke_O_O_O__O(self, m__1, f__2 any) any { var tmp1 int64; var root_1566 any = A_arbace_go_check_types_A_const_186.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1566, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1568 lang.IFn; if linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(f__2); if linked_1567 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_1568.Invoke_O__O(arg_1569)) } else { tmp1 = linked_1567.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1566, arg_1569) }; return lang.Numbers_Max_O_J__O_NoInit(m__1, tmp1) }








func A_arbace_go_check_types_offsetsof_A_New() *A_arbace_go_check_types_offsetsof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_offsetsof_A{}; t.Ctor(); return t }
//line :546:1
func (t *A_arbace_go_check_types_offsetsof_A) Ctor() {}
//line :546:1
func (t *A_arbace_go_check_types_offsetsof_A) Invoke_O_O__O(self, fields__0 any) any { { var fs__2 any = fields__0; var offs__3 any = lang.RT_Box_J__Number_NoInit(0); var acc__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




	var tmp1 any; var root_1598 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1598, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1600 lang.IFn; if linked_1599 == nil { ifn_1600 = lang.IFn_Cast(root_1598) } else { ifn_1600 = nil }; var arg_1601 any = fs__2; if linked_1599 == nil { tmp1 = ifn_1600.Invoke_O__O(arg_1601) } else { tmp1 = linked_1599.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1598, arg_1601) }; if jrt.J2g_Truth(tmp1) { return acc__4 } else { var f__5 any; var root_1602 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1604 lang.IFn

		if linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any = fs__2; if linked_1603 == nil { f__5 = ifn_1604.Invoke_O__O(arg_1605) } else { f__5 = linked_1603.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1602, arg_1605) }
		var tmp2 bool; var na_1606 any = offs__3; if jrt.Long_InstanceOf(na_1606) { var n0_1607 int64 = jrt.NN(jrt.Long_Cast(na_1606)).LongValue__J(); tmp2 = n0_1607 < 0 } else { if jrt.Double_InstanceOf(na_1606) { var n0_1607_2 float64 = jrt.NN(jrt.Double_Cast(na_1606)).DoubleValue__D(); tmp2 = n0_1607_2 < 0.0 } else { tmp2 = lang.Numbers_IsNeg_O__Z_NoInit(na_1606) } }; if tmp2 {
			var tmp3 any; var root_1621 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1621, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1623 lang.IFn; if linked_1622 == nil { ifn_1623 = lang.IFn_Cast(root_1621) } else { ifn_1623 = nil }; var arg_1624 any = fs__2; if linked_1622 == nil { tmp3 = ifn_1623.Invoke_O__O(arg_1624) } else { tmp3 = linked_1622.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1621, arg_1624) }; var tmp4 any = tmp3; var tmp5 any; var root_1625 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1626 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1625, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1627 lang.IFn; if linked_1626 == nil { ifn_1627 = lang.IFn_Cast(root_1625) } else { ifn_1627 = nil }; var arg_1628 any = acc__4; var arg_1629 any = A_arbace_go_check_types_A_const_194; if linked_1626 == nil { tmp5 = ifn_1627.Invoke_O_O__O(arg_1628, arg_1629) } else { tmp5 = linked_1626.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1625, arg_1628, arg_1629) }; fs__2, offs__3, acc__4 = tmp4, offs__3, tmp5; continue L1 } else {
//line :554:1
				var o__6 any; var root_1608 any = A_arbace_go_check_types_A_const_193.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1608, A_arbace_go_check_types_align_up_A_fn_class); var ifn_1610 lang.IFn

				if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = offs__3; var arg_1612 any; var root_1613 any = A_arbace_go_check_types_A_const_186.GetRawRoot__O(); var linked_1614 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1613, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1615 lang.IFn; if linked_1614 == nil { ifn_1615 = lang.IFn_Cast(root_1613) } else { ifn_1615 = nil }; var arg_1616 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(f__5); if linked_1614 == nil { arg_1612 = ifn_1615.Invoke_O__O(arg_1616) } else { arg_1612 = jrt.Long_ValueOf_J__Long_NoInit(linked_1614.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1613, arg_1616)).Ref() }; if linked_1609 == nil { o__6 = ifn_1610.Invoke_O_O__O(arg_1611, arg_1612) } else { o__6 = jrt.Long_ValueOf_J__Long_NoInit(linked_1609.(*A_arbace_go_check_types_align_up_A).InvokePrim_O_J_J__J(root_1608, lang.RT_LongCast_O__J_NoInit(arg_1611), lang.RT_LongCast_O__J_NoInit(arg_1612))).Ref() }
//line :554:1
				var d__7 any; var root_1617 any = A_arbace_go_check_types_A_const_191.GetRawRoot__O(); var linked_1618 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1617, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1619 lang.IFn


				if linked_1618 == nil { ifn_1619 = lang.IFn_Cast(root_1617) } else { ifn_1619 = nil }; var arg_1620 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(f__5); if linked_1618 == nil { d__7 = ifn_1619.Invoke_O__O(arg_1620) } else { d__7 = jrt.Long_ValueOf_J__Long_NoInit(linked_1618.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1617, arg_1620)).Ref() }
				var tmp6 any; var root_1630 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1630, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1632 lang.IFn; if linked_1631 == nil { ifn_1632 = lang.IFn_Cast(root_1630) } else { ifn_1632 = nil }; var arg_1633 any = fs__2; if linked_1631 == nil { tmp6 = ifn_1632.Invoke_O__O(arg_1633) } else { tmp6 = linked_1631.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1630, arg_1633) }; var tmp7 any = tmp6; var tmp8 any; var tmp9 bool; var and__1927000168__auto____8 bool; var na_1634 any = d__7; var na_1635 int64 = 0
				if jrt.Long_InstanceOf(na_1634) { var n0_1636 int64 = jrt.NN(jrt.Long_Cast(na_1634)).LongValue__J(); var n1_1637 int64 = na_1635; and__1927000168__auto____8 = n0_1636 >= n1_1637 } else { and__1927000168__auto____8 = lang.Numbers_Gte_O_J__Z_NoInit(na_1634, na_1635) }; if and__1927000168__auto____8 { var na_1639 any = o__6; var na_1640 int64 = 0; if jrt.Long_InstanceOf(na_1639) { var n0_1641 int64 = jrt.NN(jrt.Long_Cast(na_1639)).LongValue__J(); var n1_1642 int64 = na_1640; tmp9 = n0_1641 >= n1_1642 } else { tmp9 = lang.Numbers_Gte_O_J__Z_NoInit(na_1639, na_1640) } } else { tmp9 = and__1927000168__auto____8 }; if tmp9 { var na_1644 any = o__6; var na_1645 any = d__7; var tmp10 bool; var tmp11 bool; tmp11 = jrt.Long_InstanceOf(na_1644); if tmp11 { tmp11 = jrt.Long_InstanceOf(na_1645) }; tmp10 = tmp11; if tmp10 { var n0_1646 int64 = jrt.NN(jrt.Long_Cast(na_1644)).LongValue__J(); var n1_1647 int64 = jrt.NN(jrt.Long_Cast(na_1645)).LongValue__J(); tmp8 = jrt.Long_ValueOf_J__Long_NoInit(n0_1646 + n1_1647).Ref() } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_1644); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_1645) }; tmp12 = tmp13; if tmp12 { var n0_1646_2 float64 = jrt.NN(jrt.Double_Cast(na_1644)).DoubleValue__D(); var n1_1647_2 float64 = jrt.NN(jrt.Double_Cast(na_1645)).DoubleValue__D(); tmp8 = jrt.Double_ValueOf_D__Double_NoInit(n0_1646_2 + n1_1647_2).Ref() } else { tmp8 = lang.Numbers_Unchecked_add_O_O__Number_NoInit(na_1644, na_1645) } } } else { tmp8 = A_arbace_go_check_types_A_const_194 }
//line :558:1
				var tmp14 any = tmp8; var tmp15 any; var root_1649 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1649, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1651 lang.IFn

				if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any = acc__4; var arg_1653 any = o__6; if linked_1650 == nil { tmp15 = ifn_1651.Invoke_O_O__O(arg_1652, arg_1653) } else { tmp15 = linked_1650.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1649, arg_1652, arg_1653) }
//line :558:1
				fs__2, offs__3, acc__4 = tmp7, tmp14, tmp15; continue L1 } } } }; /*line :546:1*/panic("j2g: unreachable") }















func A_arbace_go_check_types_sizeof_A_New() *A_arbace_go_check_types_sizeof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sizeof_A{}; t.Ctor(); return t }
//line :562:1
func (t *A_arbace_go_check_types_sizeof_A) Ctor() {}
//line :562:1
func (t *A_arbace_go_check_types_sizeof_A) InvokePrim_O_O__J(self, t__0 any) int64 { var tmp1 any; var u__2 any; var root_1654 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1654, A_arbace_go_check_types_under_A_fn_class); var ifn_1656 lang.IFn; if


	linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any = t__0; if linked_1655 == nil { u__2 = ifn_1656.Invoke_O__O(arg_1657) } else { u__2 = linked_1655.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1654, arg_1657) }; var tmp2 any; var root_1658 any =
	A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_1660 lang.IFn; if
	linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any = u__2; if linked_1659 == nil { tmp2 = ifn_1660.Invoke_O__O(arg_1661) } else { tmp2 = linked_1659.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_1658, arg_1661) }; if /*line :566:1*/ jrt.J2g_Truth(tmp2) { var G__219000238__3_ any = u__2
	L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__219000238__3_) { case 717828005: if any(G__219000238__3_) == any(A_arbace_go_check_types_A_const_40) { var na_1663 int64 = 2; var na_1664 any = A_arbace_go_check_types_A_const_190.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1664) { var n0_1665 int64 = na_1663; var n1_1666 int64 = jrt.NN(jrt.Long_Cast(na_1664)).LongValue__J(); var nr_1667 int64 = n0_1665 * n1_1666; var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; tmp6 = n0_1665 == -9223372036854775808; if tmp6 { tmp6 = n1_1666 < 0 }; tmp5 = tmp6; tmp4 = !tmp5; if tmp4 { var tmp7 bool; tmp7 = n1_1666 == 0; if !tmp7 { tmp7 = nr_1667/n1_1666 == n0_1665 }; tmp4 = tmp7 }; tmp3 = tmp4; if tmp3 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1667).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1663, na_1664) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1663, na_1664) }; break L1 }; default:}; var tmp8 lang.IFn = A_arbace_go_check_types_A_const_11; tmp1 = tmp8.Invoke_O_O__O(lang.IFn_Cast(A_arbace_go_check_types_A_const_78.GetRawRoot__O()).Invoke_O__O(u__2), A_arbace_go_check_types_A_const_190.GetRawRoot__O())} } else {
//line :566:1
		if A_arbace_go_check_types_A_const_75 != nil { var G__219000239__3_ any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0))


		L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__219000239__3_) >> 5 & 3 { case 0: if any(G__219000239__3_) == any(A_arbace_go_check_types_A_const_97) { var n__4 int64 = lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)))

			if lang.Numbers_Lte_J_J__Z_NoInit(n__4, 0) { tmp1 = A_arbace_go_check_types_A_const_44 } else { var es__5 any; var root_1669 any = A_arbace_go_check_types_A_const_191.GetRawRoot__O(); var linked_1670 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1669, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1671 lang.IFn

				if linked_1670 == nil { ifn_1671 = lang.IFn_Cast(root_1669) } else { ifn_1671 = nil }; var arg_1672 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)); if linked_1670 == nil { es__5 = ifn_1671.Invoke_O__O(arg_1672) } else { es__5 = jrt.Long_ValueOf_J__Long_NoInit(linked_1670.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1669, arg_1672)).Ref() }
				var tmp9 bool; var na_1673 any = es__5
				if jrt.Long_InstanceOf(na_1673) { var n0_1674 int64 = jrt.NN(jrt.Long_Cast(na_1673)).LongValue__J(); tmp9 = n0_1674 < 0 } else { if jrt.Double_InstanceOf(na_1673) { var n0_1674_2 float64 = jrt.NN(jrt.Double_Cast(na_1673)).DoubleValue__D(); tmp9 = n0_1674_2 < 0.0 } else { tmp9 = lang.Numbers_IsNeg_O__Z_NoInit(na_1673) } }
//line :574:1
				if tmp9 { tmp1 = A_arbace_go_check_types_A_const_194 } else { var tmp10 bool
					var na_1675 any = es__5
					if jrt.Long_InstanceOf(na_1675) { var n0_1676 int64 = jrt.NN(jrt.Long_Cast(na_1675)).LongValue__J(); tmp10 = n0_1676 == 0 } else { if jrt.Double_InstanceOf(na_1675) { var n0_1676_2 float64 = jrt.NN(jrt.Double_Cast(na_1675)).DoubleValue__D(); tmp10 = n0_1676_2 == 0.0 } else { tmp10 = lang.Numbers_IsZero_O__Z_NoInit(na_1675) } }
//line :574:1
					if tmp10 { tmp1 = A_arbace_go_check_types_A_const_44 } else { var tmp11 bool; var na_1677 any = es__5; var na_1678 int64 = lang.Numbers_Quotient_J_J__J_NoInit(9223372036854775807, n__4)


						if jrt.Long_InstanceOf(na_1677) { var n0_1679 int64 = jrt.NN(jrt.Long_Cast(na_1677)).LongValue__J(); var n1_1680 int64 = na_1678; tmp11 = n0_1679 > n1_1680 } else { tmp11 = lang.Numbers_Gt_O_J__Z_NoInit(na_1677, na_1678) }
//line :574:1
						if tmp11 { tmp1 = A_arbace_go_check_types_A_const_194 } else { if A_arbace_go_check_types_A_const_75 != nil {



							var na_1682 any = es__5; var na_1683 int64 = n__4; if jrt.Long_InstanceOf(na_1682) { var n0_1684 int64 = jrt.NN(jrt.Long_Cast(na_1682)).LongValue__J(); var n1_1685 int64 = na_1683; var nr_1686 int64 = n0_1684 * n1_1685; var tmp12 bool; var tmp13 bool; var tmp14 bool; var tmp15 bool; tmp15 = n0_1684 == -9223372036854775808; if tmp15 { tmp15 = n1_1685 < 0 }; tmp14 = tmp15; tmp13 = !tmp14; if tmp13 { var tmp16 bool; tmp16 = n1_1685 == 0; if !tmp16 { tmp16 = nr_1686/n1_1685 == n0_1684 }; tmp13 = tmp16 }; tmp12 = tmp13; if tmp12 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1686).Ref() } else { tmp1 = lang.Numbers_Multiply_O_J__Number_NoInit(na_1682, na_1683) } } else { tmp1 = lang.Numbers_Multiply_O_J__Number_NoInit(na_1682, na_1683) } } else {
//line :574:1
								tmp1 = nil } } } } }
//line :569:1
			break L2 }; case 1: if any(G__219000239__3_) == any(A_arbace_go_check_types_A_const_86) {





















				var na_1687 int64 = 2; var na_1688 any = A_arbace_go_check_types_A_const_190.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1688) { var n0_1689 int64 = na_1687; var n1_1690 int64 = jrt.NN(jrt.Long_Cast(na_1688)).LongValue__J(); var nr_1691 int64 = n0_1689 * n1_1690; var tmp17 bool; var tmp18 bool; var tmp19 bool; var tmp20 bool; tmp20 = n0_1689 == -9223372036854775808; if tmp20 { tmp20 = n1_1690 < 0 }; tmp19 = tmp20; tmp18 = !tmp19; if tmp18 { var tmp21 bool; tmp21 = n1_1690 == 0; if !tmp21 { tmp21 = nr_1691/n1_1690 == n0_1689 }; tmp18 = tmp21 }; tmp17 = tmp18; if tmp17 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1691).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1687, na_1688) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1687, na_1688) }
//line :569:1
				break L2 }; case 2: if any(G__219000239__3_) == any(A_arbace_go_check_types_A_const_96) {









					var na_1692 int64 = 3; var na_1693 any = A_arbace_go_check_types_A_const_190.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1693) { var n0_1694 int64 = na_1692; var n1_1695 int64 = jrt.NN(jrt.Long_Cast(na_1693)).LongValue__J(); var nr_1696 int64 = n0_1694 * n1_1695; var tmp22 bool; var tmp23 bool; var tmp24 bool; var tmp25 bool; tmp25 = n0_1694 == -9223372036854775808; if tmp25 { tmp25 = n1_1695 < 0 }; tmp24 = tmp25; tmp23 = !tmp24; if tmp23 { var tmp26 bool; tmp26 = n1_1695 == 0; if !tmp26 { tmp26 = nr_1696/n1_1695 == n0_1694 }; tmp23 = tmp26 }; tmp22 = tmp23; if tmp22 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1696).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1692, na_1693) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1692, na_1693) }
//line :569:1
					break L2 }; case 3: if any(G__219000239__3_) == any(A_arbace_go_check_types_A_const_105) { var fs__4 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); var tmp27 any; var root_1697 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1697, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1699 lang.IFn











						if linked_1698 == nil { ifn_1699 = lang.IFn_Cast(root_1697) } else { ifn_1699 = nil }; var arg_1700 any = fs__4; if linked_1698 == nil { tmp27 = ifn_1699.Invoke_O__O(arg_1700) } else { tmp27 = linked_1698.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1697, arg_1700) }; if jrt.J2g_Truth(tmp27) { tmp1 = A_arbace_go_check_types_A_const_44 } else { var offs__5 any; var root_1701 any = A_arbace_go_check_types_A_const_195.GetRawRoot__O(); var linked_1702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1701, A_arbace_go_check_types_offsetsof_A_fn_class); var ifn_1703 lang.IFn

							if linked_1702 == nil { ifn_1703 = lang.IFn_Cast(root_1701) } else { ifn_1703 = nil }; var arg_1704 any = fs__4; if linked_1702 == nil { offs__5 = ifn_1703.Invoke_O__O(arg_1704) } else { offs__5 = linked_1702.(*A_arbace_go_check_types_offsetsof_A).Invoke_O_O__O(root_1701, arg_1704) }
//line :581:1
							var o__6 int64; var tmp28 any; var root_1705 any = A_arbace_go_check_types_A_const_196.GetRawRoot__O(); var linked_1706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1705, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_1707 lang.IFn


							if linked_1706 == nil { ifn_1707 = lang.IFn_Cast(root_1705) } else { ifn_1707 = nil }; var arg_1708 any = offs__5; if linked_1706 == nil { tmp28 = ifn_1707.Invoke_O__O(arg_1708) } else { tmp28 = linked_1706.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_1705, arg_1708) }; o__6 = lang.RT_LongCast_O__J_NoInit(tmp28)
//line :581:1
							var s__7 any; var root_1709 any = A_arbace_go_check_types_A_const_191.GetRawRoot__O(); var linked_1710 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1709, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1711 lang.IFn



							if linked_1710 == nil { ifn_1711 = lang.IFn_Cast(root_1709) } else { ifn_1711 = nil }; var arg_1712 any; var tmp29 *lang.Keyword = A_arbace_go_check_types_A_const_107; var tmp30 any; var root_1713 any = A_arbace_go_check_types_A_const_196.GetRawRoot__O(); var linked_1714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1713, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_1715 lang.IFn; if linked_1714 == nil { ifn_1715 = lang.IFn_Cast(root_1713) } else { ifn_1715 = nil }; var arg_1716 any = fs__4; if linked_1714 == nil { tmp30 = ifn_1715.Invoke_O__O(arg_1716) } else { tmp30 = linked_1714.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_1713, arg_1716) }; arg_1712 = tmp29.Invoke_O__O(tmp30); if linked_1710 == nil { s__7 = ifn_1711.Invoke_O__O(arg_1712) } else { s__7 = jrt.Long_ValueOf_J__Long_NoInit(linked_1710.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1709, arg_1712)).Ref() }
							var tmp31 bool; var or__1927000174__auto____8 bool = lang.Numbers_IsNeg_J__Z_NoInit(o__6); if or__1927000174__auto____8 { tmp31 = or__1927000174__auto____8 } else { var na_1717 any = s__7; if jrt.Long_InstanceOf(na_1717) { var n0_1718 int64 = jrt.NN(jrt.Long_Cast(na_1717)).LongValue__J(); tmp31 = n0_1718 < 0 } else { if jrt.Double_InstanceOf(na_1717) { var n0_1718_2 float64 = jrt.NN(jrt.Double_Cast(na_1717)).DoubleValue__D(); tmp31 = n0_1718_2 < 0.0 } else { tmp31 = lang.Numbers_IsNeg_O__Z_NoInit(na_1717) } } }; if tmp31 { tmp1 = A_arbace_go_check_types_A_const_194 } else { var s__8 any; var tmp32 bool; var and__1927000168__auto____8 bool = lang.Numbers_IsPos_J__Z_NoInit(o__6)

								if and__1927000168__auto____8 { var na_1719 any = s__7; if jrt.Long_InstanceOf(na_1719) { var n0_1720 int64 = jrt.NN(jrt.Long_Cast(na_1719)).LongValue__J(); tmp32 = n0_1720 == 0 } else { if jrt.Double_InstanceOf(na_1719) { var n0_1720_2 float64 = jrt.NN(jrt.Double_Cast(na_1719)).DoubleValue__D(); tmp32 = n0_1720_2 == 0.0 } else { tmp32 = lang.Numbers_IsZero_O__Z_NoInit(na_1719) } } } else { tmp32 = and__1927000168__auto____8 }; if tmp32 { s__8 = A_arbace_go_check_types_A_const_15 } else { s__8 = s__7
								}
								var root_1721 any = A_arbace_go_check_types_A_const_193.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1721, A_arbace_go_check_types_align_up_A_fn_class); var ifn_1723 lang.IFn; if linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any; var na_1726 int64 = o__6; var na_1727 any = s__8; if jrt.Long_InstanceOf(na_1727) { var n0_1728 int64 = na_1726; var n1_1729 int64 = jrt.NN(jrt.Long_Cast(na_1727)).LongValue__J(); arg_1724 = jrt.Long_ValueOf_J__Long_NoInit(n0_1728 + n1_1729).Ref() } else { arg_1724 = lang.Numbers_Unchecked_add_J_O__Number_NoInit(na_1726, na_1727) }; var arg_1725 any; var root_1731 any = A_arbace_go_check_types_A_const_186.GetRawRoot__O(); var linked_1732 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1731, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1733 lang.IFn; if linked_1732 == nil { ifn_1733 = lang.IFn_Cast(root_1731) } else { ifn_1733 = nil }; var arg_1734 any = t__0; if linked_1732 == nil { arg_1725 = ifn_1733.Invoke_O__O(arg_1734) } else { arg_1725 = jrt.Long_ValueOf_J__Long_NoInit(linked_1732.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1731, arg_1734)).Ref() }; if linked_1722 == nil { tmp1 = ifn_1723.Invoke_O_O__O(arg_1724, arg_1725) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_1722.(*A_arbace_go_check_types_align_up_A).InvokePrim_O_J_J__J(root_1721, lang.RT_LongCast_O__J_NoInit(arg_1724), lang.RT_LongCast_O__J_NoInit(arg_1725))).Ref() } } }
//line :569:1
						break L2 }; default:}; tmp1 = A_arbace_go_check_types_A_const_190.GetRawRoot__O()} } else {
//line :566:1
							tmp1 = nil } }; return /*line :562:1*/ jrt.Number_Cast(tmp1).LongValue__J() }
//line :562:1
func (t *A_arbace_go_check_types_sizeof_A) Invoke_O_O__O(self, t__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, t__0)).Ref() }

































func A_arbace_go_check_types_deref_type_A_New() *A_arbace_go_check_types_deref_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_deref_type_A{}; t.Ctor(); return t }
//line :596:1
func (t *A_arbace_go_check_types_deref_type_A) Ctor() {}
//line :596:1
func (t *A_arbace_go_check_types_deref_type_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_1735 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1735, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1737 lang.IFn; if linked_1736 == nil { ifn_1737 = lang.IFn_Cast(root_1735) } else { ifn_1737 = nil }; var arg_1738 any = t__0; if linked_1736 == nil { and__1927000168__auto____2 = ifn_1737.Invoke_O__O(arg_1738) } else { and__1927000168__auto____2 = linked_1736.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1735, arg_1738) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_types_A_const_87; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)), jrt.Boolean_TRUE.Ref()) } else { return lang.Tuple_Create_O_O__IPersistentVector(t__0, jrt.Boolean_FALSE.Ref())
	} }
func A_arbace_go_check_types_methods_of_A_New() *A_arbace_go_check_types_methods_of_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_methods_of_A{}; t.Ctor(); return t }
//line :601:1
func (t *A_arbace_go_check_types_methods_of_A) Ctor() {}
//line :601:1
func (t *A_arbace_go_check_types_methods_of_A) Invoke_O_O__O(self, t__0 any) any { var t__2 any; var tmp1 *lang.Keyword = A_arbace_go_check_types_A_const_197; var tmp2 any; var root_1739 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1739, A_arbace_go_check_types_info_A_fn_class); var ifn_1741 lang.IFn; if


	linked_1740 == nil { ifn_1741 = lang.IFn_Cast(root_1739) } else { ifn_1741 = nil }; var arg_1742 any = t__0; if linked_1740 == nil { tmp2 = ifn_1741.Invoke_O__O(arg_1742) } else { tmp2 = linked_1740.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1739, arg_1742) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 *lang.Keyword = A_arbace_go_check_types_A_const_197; var tmp4 any; var root_1743 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1743, A_arbace_go_check_types_info_A_fn_class); var ifn_1745 lang.IFn; if linked_1744 == nil { ifn_1745 = lang.IFn_Cast(root_1743) } else { ifn_1745 = nil }; var arg_1746 any = t__0; if linked_1744 == nil { tmp4 = ifn_1745.Invoke_O__O(arg_1746) } else { tmp4 = linked_1744.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1743, arg_1746) }; t__2 = tmp3.Invoke_O__O(tmp4) } else { t__2 = t__0 }; var root_1751 any =
	A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1751, A_arbace_go_check_types_under_A_fn_class); var ifn_1753 lang.IFn; if linked_1752 == nil { ifn_1753 = lang.IFn_Cast(root_1751) } else { ifn_1753 = nil }; var arg_1754 any = t__2; if linked_1752 == nil { ifn_1753.Invoke_O__O(arg_1754) } else { linked_1752.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1751, arg_1754) }; var tmp5 /*line :606:1*/*lang.Keyword = A_arbace_go_check_types_A_const_62; var tmp6 any; var root_1747 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1747, A_arbace_go_check_types_info_A_fn_class); var ifn_1749 lang.IFn; if linked_1748 == nil { ifn_1749 = lang.IFn_Cast(root_1747) } else { ifn_1749 = nil }; var arg_1750 any = t__2; if linked_1748 == nil { tmp6 = ifn_1749.Invoke_O__O(arg_1750) } else { tmp6 = linked_1748.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1747, arg_1750) }; return tmp5.Invoke_O__O(tmp6) }





func A_arbace_go_check_types_same_id_QMARK__A_New() *A_arbace_go_check_types_same_id_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_same_id_QMARK__A{}; t.Ctor(); return t }
//line :612:1
func (t *A_arbace_go_check_types_same_id_QMARK__A) Ctor() {}
//line :612:1
func (t *A_arbace_go_check_types_same_id_QMARK__A) Invoke_O_O_O_O_O__O(self, n__0, p__1, name__2, pkg__3 any) any {



	var tmp1 any; var and__1927000168__auto____5 any = A_arbace_go_check_types_A_const_198.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.String_Cast(n__0)).EqualsIgnoreCase_String__Z(jrt.String_Cast(name__2))).Ref() } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, name__2)

		if and__1927000168__auto____5_2 { var or__1927000174__auto____6 bool = jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(name__2)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))
			if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(p__1, pkg__3); if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { return jrt.Boolean_FALSE.Ref() } } } else {
//line :618:1
				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref()
			}
	}
}


func A_arbace_go_check_types_exported_QMARK__A_New() *A_arbace_go_check_types_exported_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_exported_QMARK__A{}; t.Ctor(); return t }
//line :624:1
func (t *A_arbace_go_check_types_exported_QMARK__A) Ctor() {}
//line :624:1
func (t *A_arbace_go_check_types_exported_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var cp__2 int32 = jrt.NN(jrt.String_Cast(n__0)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(0)); return /*line :625:1*/ jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_I__Z_NoInit(cp__2)).Ref() }











func A_arbace_go_check_types_named_method_A_New() *A_arbace_go_check_types_named_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_method_A{}; t.Ctor(); return t }
//line :637:1
func (t *A_arbace_go_check_types_named_method_A) Ctor() {}
//line :637:1
func (t *A_arbace_go_check_types_named_method_A) Invoke_O_O_O_O__O(self, t__0, name__1, pkg__2 any) any { { var ms__4 any; var root_1755 any = A_arbace_go_check_types_A_const_199.GetRawRoot__O(); var linked_1756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1755, A_arbace_go_check_types_methods_of_A_fn_class); var ifn_1757 lang.IFn


	if linked_1756 == nil { ifn_1757 = lang.IFn_Cast(root_1755) } else { ifn_1757 = nil }; var arg_1758 any = t__0; if linked_1756 == nil { ms__4 = ifn_1757.Invoke_O__O(arg_1758) } else { ms__4 = linked_1756.(*A_arbace_go_check_types_methods_of_A).Invoke_O_O__O(root_1755, arg_1758) }
//line :637:1
	var i__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i__5, int64(lang.RT_Count_O__I_NoInit(ms__4))) { var m__6 any = lang.RT_Nth_O_I__O_NoInit(ms__4, lang.RT_IntCast_J__I_NoInit(i__5)); var map__219000245__7 any; var root_1759 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_1760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1759, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1761 lang.IFn
			if linked_1760 == nil { ifn_1761 = lang.IFn_Cast(root_1759) } else { ifn_1761 = nil }; var arg_1762 any = m__6; if linked_1760 == nil { map__219000245__7 = ifn_1761.Invoke_O__O(arg_1762) } else { map__219000245__7 = linked_1760.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1759, arg_1762) }
//line :642:1
			var map__219000245__8 any
			if lang.ISeq_InstanceOf(map__219000245__7) { var tmp1 any; var root_1763 any = A_arbace_go_check_types_A_const_200.GetRawRoot__O(); var linked_1764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1763, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1765 lang.IFn; if linked_1764 == nil { ifn_1765 = lang.IFn_Cast(root_1763) } else { ifn_1765 = nil }; var arg_1766 any = map__219000245__7; if linked_1764 == nil { tmp1 = ifn_1765.Invoke_O__O(arg_1766) } else { tmp1 = linked_1764.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1763, arg_1766) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1767 any = A_arbace_go_check_types_A_const_201.GetRawRoot__O(); var linked_1768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1767, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1769 lang.IFn; if linked_1768 == nil { ifn_1769 = lang.IFn_Cast(root_1767) } else { ifn_1769 = nil }; var arg_1770 any = map__219000245__7; if linked_1768 == nil { tmp2 = ifn_1769.Invoke_O__O(arg_1770) } else { tmp2 = linked_1768.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1767, arg_1770) }; map__219000245__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1771 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_1772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1771, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1773 lang.IFn; if linked_1772 == nil { ifn_1773 = lang.IFn_Cast(root_1771) } else { ifn_1773 = nil }; var arg_1774 any = map__219000245__7; if linked_1772 == nil { tmp3 = ifn_1773.Invoke_O__O(arg_1774) } else { tmp3 = linked_1772.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1771, arg_1774) }; if jrt.J2g_Truth(tmp3) { var root_1775 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1775, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1777 lang.IFn; if linked_1776 == nil { ifn_1777 = lang.IFn_Cast(root_1775) } else { ifn_1777 = nil }; var arg_1778 any = map__219000245__7; if linked_1776 == nil { map__219000245__8 = ifn_1777.Invoke_O__O(arg_1778) } else { map__219000245__8 = linked_1776.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1775, arg_1778) } } else { map__219000245__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__219000245__8 = map__219000245__7 }
//line :642:1
			var mn__9 any = lang.RT_Get_O_O__O_NoInit(map__219000245__8, A_arbace_go_check_types_A_const_12); var mp__10 any = lang.RT_Get_O_O__O_NoInit(map__219000245__8, A_arbace_go_check_types_A_const_171); var tmp4 any; var root_1779 any = A_arbace_go_check_types_A_const_202.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1779, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_1781 lang.IFn


			if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any = mn__9; var arg_1783 any = mp__10; var arg_1784 any = name__1; var arg_1785 any = pkg__2; if linked_1780 == nil { tmp4 = ifn_1781.Invoke_O_O_O_O__O(arg_1782, arg_1783, arg_1784, arg_1785) } else { tmp4 = linked_1780.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_1779, arg_1782, arg_1783, arg_1784, arg_1785) }; if jrt.J2g_Truth(tmp4) { return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__5).Ref(), m__6) } else {

				i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } } else {
//line :642:1
					return nil } } }; /*line :637:1*/panic("j2g: unreachable") }











func A_arbace_go_check_types_iface_method_A_New() *A_arbace_go_check_types_iface_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_iface_method_A{}; t.Ctor(); return t }
//line :649:1
func (t *A_arbace_go_check_types_iface_method_A) Ctor() {}
//line :649:1
func (t *A_arbace_go_check_types_iface_method_A) Invoke_O_O_O_O__O(self, u__0, name__1, pkg__2 any) any { { var ms__4 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(1)); var i__5 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i__5, int64(lang.RT_Count_O__I_NoInit(ms__4))) { var m__6 any = lang.RT_Nth_O_I__O_NoInit(ms__4, lang.RT_IntCast_J__I_NoInit(i__5)); var tmp1 any; var root_1786 any = A_arbace_go_check_types_A_const_202.GetRawRoot__O(); var linked_1787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1786, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_1788 lang.IFn

		if linked_1787 == nil { ifn_1788 = lang.IFn_Cast(root_1786) } else { ifn_1788 = nil }; var arg_1789 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__6); var arg_1790 any = A_arbace_go_check_types_A_const_171.Invoke_O__O(m__6); var arg_1791 any = name__1; var arg_1792 any = pkg__2; if linked_1787 == nil { tmp1 = ifn_1788.Invoke_O_O_O_O__O(arg_1789, arg_1790, arg_1791, arg_1792) } else { tmp1 = linked_1787.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_1786, arg_1789, arg_1790, arg_1791, arg_1792) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__5).Ref(), m__6) } else {

			i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } } else {
//line :654:1
				return nil } } }; /*line :649:1*/panic("j2g: unreachable") }










func A_arbace_go_check_types_consolidate_A_New() *A_arbace_go_check_types_consolidate_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_consolidate_A{}; t.Ctor(); return t }
//line :660:1
func (t *A_arbace_go_check_types_consolidate_A) Ctor() {}
//line :660:1
func (t *A_arbace_go_check_types_consolidate_A) Invoke_O_O__O(self, entries__0 any) any { { var es__2 any = entries__0; var acc__3 any = lang.PersistentVector_EMPTY.Ref(); var idx__4 any = lang.PersistentArrayMap_EMPTY.Ref(); L1: for {



	var tmp1 any; var root_1793 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1793, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1795 lang.IFn; if linked_1794 == nil { ifn_1795 = lang.IFn_Cast(root_1793) } else { ifn_1795 = nil }; var arg_1796 any = es__2; if linked_1794 == nil { tmp1 = ifn_1795.Invoke_O__O(arg_1796) } else { tmp1 = linked_1794.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1793, arg_1796) }; if jrt.J2g_Truth(tmp1) { return acc__3 } else { var e__5 any; var root_1797 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1797, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1799 lang.IFn

		if linked_1798 == nil { ifn_1799 = lang.IFn_Cast(root_1797) } else { ifn_1799 = nil }; var arg_1800 any = es__2; if linked_1798 == nil { e__5 = ifn_1799.Invoke_O__O(arg_1800) } else { e__5 = linked_1798.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1797, arg_1800) }
//line :664:1
		var k__6 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(e__5); var temp__1927000408__auto____7 any = lang.RT_Get_O_O__O_NoInit(idx__4, k__6)



		if jrt.J2g_Truth(temp__1927000408__auto____7) { var j__8 any = temp__1927000408__auto____7; var tmp2 any; var root_1801 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1803 lang.IFn
			if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any = es__2; if linked_1802 == nil { tmp2 = ifn_1803.Invoke_O__O(arg_1804) } else { tmp2 = linked_1802.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1801, arg_1804) }; var tmp3 any = tmp2; var tmp4 any; var root_1805 any = A_arbace_go_check_types_A_const_203.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1807 lang.IFn; if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any = acc__3; var arg_1809 any = lang.Tuple_Create_O_O__IPersistentVector(j__8, A_arbace_go_check_types_A_const_204); var arg_1810 any = jrt.Boolean_TRUE.Ref(); if linked_1806 == nil { tmp4 = ifn_1807.Invoke_O_O_O__O(arg_1808, arg_1809, arg_1810) } else { tmp4 = linked_1806.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1805, arg_1808, arg_1809, arg_1810) }; es__2, acc__3, idx__4 = tmp3, tmp4, idx__4; continue L1 } else {
				var tmp5 any; var root_1811 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1811, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1813 lang.IFn; if linked_1812 == nil { ifn_1813 = lang.IFn_Cast(root_1811) } else { ifn_1813 = nil }; var arg_1814 any = es__2; if linked_1812 == nil { tmp5 = ifn_1813.Invoke_O__O(arg_1814) } else { tmp5 = linked_1812.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1811, arg_1814) }; var tmp6 any = tmp5; var tmp7 any; var root_1815 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1816 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1815, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1817 lang.IFn; if linked_1816 == nil { ifn_1817 = lang.IFn_Cast(root_1815) } else { ifn_1817 = nil }; var arg_1818 any = acc__3; var arg_1819 any = e__5; if linked_1816 == nil { tmp7 = ifn_1817.Invoke_O_O__O(arg_1818, arg_1819) } else { tmp7 = linked_1816.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1815, arg_1818, arg_1819) }; var tmp8 any = tmp7; var tmp9 any; var root_1820 any = A_arbace_go_check_types_A_const_59.GetRawRoot__O(); var linked_1821 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1820, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1822 lang.IFn; if linked_1821 == nil { ifn_1822 = lang.IFn_Cast(root_1820) } else { ifn_1822 = nil }; var arg_1823 any = idx__4; var arg_1824 any = k__6; var arg_1825 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(acc__3)).Ref(); if linked_1821 == nil { tmp9 = ifn_1822.Invoke_O_O_O__O(arg_1823, arg_1824, arg_1825) } else { tmp9 = linked_1821.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1820, arg_1823, arg_1824, arg_1825) }; es__2, acc__3, idx__4 = tmp6, tmp8, tmp9; continue L1 } } } }; /*line :660:1*/panic("j2g: unreachable") }











func A_arbace_go_check_types_lookup_impl_A_New() *A_arbace_go_check_types_lookup_impl_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_impl_A{}; t.Ctor(); return t }
//line :672:1
func (t *A_arbace_go_check_types_lookup_impl_A) Ctor() {}
//line :672:1
func (t *A_arbace_go_check_types_lookup_impl_A) Invoke_O_O_O_O_O__O(self, T__0_, addressable__1, name__2, pkg__3 any) any { { var vec__219000250__5 any; var root_1826 any = A_arbace_go_check_types_A_const_205.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1826, A_arbace_go_check_types_deref_type_A_fn_class); var ifn_1828 lang.IFn





	if linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; var arg_1829 any = T__0_; if linked_1827 == nil { vec__219000250__5 = ifn_1828.Invoke_O__O(arg_1829) } else { vec__219000250__5 = linked_1827.(*A_arbace_go_check_types_deref_type_A).Invoke_O_O__O(root_1826, arg_1829) }
//line :672:1
	var typ__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000250__5, lang.RT_IntCast_J__I_NoInit(0), nil); var is_ptr__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000250__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any
	var and__1927000168__auto____8 any = is_ptr__7





	if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1830 any = A_arbace_go_check_types_A_const_206.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1830, A_arbace_go_check_types_interface_QMARK__A_fn_class); var ifn_1832 lang.IFn; if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any = typ__6; if linked_1831 == nil { tmp1 = ifn_1832.Invoke_O__O(arg_1833) } else { tmp1 = linked_1831.(*A_arbace_go_check_types_interface_QMARK__A).Invoke_O_O__O(root_1830, arg_1833) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return nil } else { var current__8 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_107, typ__6, A_arbace_go_check_types_A_const_214, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_types_A_const_215, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_types_A_const_216, is_ptr__7, A_arbace_go_check_types_A_const_204, jrt.Boolean_FALSE.Ref()))); var seen__9 any = lang.PersistentHashSet_EMPTY.Ref(); L1: for {



		var tmp2 any; var root_1834 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1834, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1836 lang.IFn; if linked_1835 == nil { ifn_1836 = lang.IFn_Cast(root_1834) } else { ifn_1836 = nil }; var arg_1837 any = current__8; if linked_1835 == nil { tmp2 = ifn_1836.Invoke_O__O(arg_1837) } else { tmp2 = linked_1835.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1834, arg_1837) }; if jrt.J2g_Truth(tmp2) { return nil } else { var vec__219000253__10 any; var root_1838 any = A_arbace_go_check_types_A_const_188.GetRawRoot__O(); var linked_1839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1838, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1840 lang.IFn


			if linked_1839 == nil { ifn_1840 = lang.IFn_Cast(root_1838) } else { ifn_1840 = nil }; var arg_1841 any; var tmp3 any = A_arbace_go_check_types_lookup_impl_fn__219000257_A_New_O_O(pkg__3, name__2); var tmp4 *jrt.Class; var fncls__1947 *jrt.Class = A_arbace_go_check_types_lookup_impl_fn__219000257_A_fn_class
			if fncls__1947 == nil { var fncls__1947d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_go_check_types_lookup_impl_fn__219000257_A_fn_class = fncls__1947d; tmp4 = fncls__1947d } else { tmp4 = fncls__1947 }; arg_1841 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)
//line :686:1
			var arg_1842 any = lang.Tuple_Create_O_O_O__IPersistentVector(nil, lang.PersistentVector_EMPTY.Ref(), seen__9); var arg_1843 any = current__8; if linked_1839 == nil { vec__219000253__10 = ifn_1840.Invoke_O_O_O__O(arg_1841, arg_1842, arg_1843) } else { vec__219000253__10 = linked_1839.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1838, arg_1841, arg_1842, arg_1843) }
//line :683:1
			var found__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000253__10, lang.RT_IntCast_J__I_NoInit(0), nil); var next__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000253__10, lang.RT_IntCast_J__I_NoInit(1), nil); var seen__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000253__10, lang.RT_IntCast_J__I_NoInit(2), nil)















































			if jrt.J2g_Truth(A_arbace_go_check_types_A_const_221.Invoke_O__O(found__11)) { return found__11 } else { if jrt.J2g_Truth(found__11) {


				var tmp5 any; var tmp6 any = A_arbace_go_check_types_A_const_211; var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_go_check_types_A_const_210.Invoke_O__O(found__11)); if and__1927000168__auto____14 { var tmp7 *lang.Keyword = A_arbace_go_check_types_A_const_222; var and__1927000168__auto____15 any = tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_go_check_types_A_const_223.Get__O()).Invoke_O__O(A_arbace_go_check_types_A_const_71.Invoke_O__O(found__11))); if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any; var root_1948 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_1949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1948, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1950 lang.IFn
					if linked_1949 == nil { ifn_1950 = lang.IFn_Cast(root_1948) } else { ifn_1950 = nil }; var arg_1951 any = A_arbace_go_check_types_A_const_216.Invoke_O__O(found__11); if linked_1949 == nil { and__1927000168__auto____16 = ifn_1950.Invoke_O__O(arg_1951) } else { and__1927000168__auto____16 = linked_1949.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1948, arg_1951) }
//line :734:1
					if jrt.J2g_Truth(and__1927000168__auto____16) {
						var root_1952 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_1953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1952, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1954 lang.IFn; if linked_1953 == nil { ifn_1954 = lang.IFn_Cast(root_1952) } else { ifn_1954 = nil }; var arg_1955 any = addressable__1; if linked_1953 == nil { tmp5 = ifn_1954.Invoke_O__O(arg_1955) } else { tmp5 = linked_1953.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1952, arg_1955) } } else {
//line :734:1
							tmp5 = and__1927000168__auto____16 } } else { tmp5 = and__1927000168__auto____15 } } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }; if jrt.J2g_Truth(tmp5) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_222, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_types_A_const_224, found__11)) } else { return found__11 } } else {
//line :731:1
								if A_arbace_go_check_types_A_const_75 != nil {






									var tmp8 any; var root_1956 any = A_arbace_go_check_types_A_const_225.GetRawRoot__O(); var linked_1957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1956, A_arbace_go_check_types_consolidate_A_fn_class); var ifn_1958 lang.IFn; if linked_1957 == nil { ifn_1958 = lang.IFn_Cast(root_1956) } else { ifn_1958 = nil }; var arg_1959 any = next__12; if linked_1957 == nil { tmp8 = ifn_1958.Invoke_O__O(arg_1959) } else { tmp8 = linked_1957.(*A_arbace_go_check_types_consolidate_A).Invoke_O_O__O(root_1956, arg_1959) }; current__8, seen__9 = tmp8, seen__13; continue L1 } else {
//line :731:1
										return nil } } } } } } }; /*line :672:1*/panic("j2g: unreachable") }














func A_arbace_go_check_types_lookup_impl_fn__219000257_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_lookup_impl_fn__219000257_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_impl_fn__219000257_A{}; t.Ctor_O_O(p0, p1); return t }
//line :687:1
func (t *A_arbace_go_check_types_lookup_impl_fn__219000257_A) Ctor_O_O(c__pkg, c__name any) { t.F_pkg = c__pkg; t.F_name = c__name }
//line :687:1
func (t *A_arbace_go_check_types_lookup_impl_fn__219000257_A) Invoke_O_O_O__O(self, p__219000256__1, e__2 any) any { { var vec__219000258__3 any = p__219000256__1; var found__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000258__3, lang.RT_IntCast_J__I_NoInit(0), nil); var next__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000258__3, lang.RT_IntCast_J__I_NoInit(1), nil); var seen__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000258__3, lang.RT_IntCast_J__I_NoInit(2), nil); var typ__7 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(e__2); var tmp1 any; var and__1927000168__auto____8 any; var root_1844 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1844, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1846 lang.IFn

	if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any = typ__7; if linked_1845 == nil { and__1927000168__auto____8 = ifn_1846.Invoke_O__O(arg_1847) } else { and__1927000168__auto____8 = linked_1845.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1844, arg_1847) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1848 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1848, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1850 lang.IFn; if linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = seen__6; var arg_1852 any = typ__7; if linked_1849 == nil { tmp1 = ifn_1850.Invoke_O_O__O(arg_1851, arg_1852) } else { tmp1 = linked_1849.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1848, arg_1851, arg_1852) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__6) } else { var seen__8 any; var tmp2 any; var root_1853 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1853, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1855 lang.IFn

		if linked_1854 == nil { ifn_1855 = lang.IFn_Cast(root_1853) } else { ifn_1855 = nil }; var arg_1856 any = typ__7; if linked_1854 == nil { tmp2 = ifn_1855.Invoke_O__O(arg_1856) } else { tmp2 = linked_1854.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1853, arg_1856) }; if jrt.J2g_Truth(tmp2) { var root_1857 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1857, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1859 lang.IFn; if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any = seen__6; var arg_1861 any = typ__7; if linked_1858 == nil { seen__8 = ifn_1859.Invoke_O_O__O(arg_1860, arg_1861) } else { seen__8 = linked_1858.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1857, arg_1860, arg_1861) } } else { seen__8 = seen__6 }
//line :689:1
		var m__9 any; var tmp3 any; var root_1862 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1862, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1864 lang.IFn


		if linked_1863 == nil { ifn_1864 = lang.IFn_Cast(root_1862) } else { ifn_1864 = nil }; var arg_1865 any = typ__7; if linked_1863 == nil { tmp3 = ifn_1864.Invoke_O__O(arg_1865) } else { tmp3 = linked_1863.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1862, arg_1865) }; if jrt.J2g_Truth(tmp3) { var root_1866 any = A_arbace_go_check_types_A_const_207.GetRawRoot__O(); var linked_1867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1866, A_arbace_go_check_types_named_method_A_fn_class); var ifn_1868 lang.IFn; if linked_1867 == nil { ifn_1868 = lang.IFn_Cast(root_1866) } else { ifn_1868 = nil }; var arg_1869 any = typ__7; var arg_1870 any = t.F_name; var arg_1871 any = t.F_pkg; if linked_1867 == nil { m__9 = ifn_1868.Invoke_O_O_O__O(arg_1869, arg_1870, arg_1871) } else { m__9 = linked_1867.(*A_arbace_go_check_types_named_method_A).Invoke_O_O_O_O__O(root_1866, arg_1869, arg_1870, arg_1871) } } else { m__9 = nil }
		if jrt.J2g_Truth(m__9) {
			var tmp4 any; var or__1927000174__auto____10 any = found__4; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp4 = or__1927000174__auto____10 } else { tmp4 = A_arbace_go_check_types_A_const_204.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp4) { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_209, next__5, seen__8) } else { var tmp5 any = A_arbace_go_check_types_A_const_210; var tmp6 any = A_arbace_go_check_types_A_const_211; var tmp7 any = A_arbace_go_check_types_A_const_71; var tmp8 any; var root_1901 any = A_arbace_go_check_types_A_const_212.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1901, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1903 lang.IFn

				if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any = m__9; if linked_1902 == nil { tmp8 = ifn_1903.Invoke_O__O(arg_1904) } else { tmp8 = linked_1902.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1901, arg_1904) }
//line :694:1
				var tmp9 any = tmp8; var tmp10 any = A_arbace_go_check_types_A_const_213; var tmp11 any = A_arbace_go_check_types_A_const_214; var tmp12 any; var root_1905 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1906 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1905, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1907 lang.IFn

				if linked_1906 == nil { ifn_1907 = lang.IFn_Cast(root_1905) } else { ifn_1907 = nil }; var arg_1908 any = A_arbace_go_check_types_A_const_214.Invoke_O__O(e__2); var arg_1909 any; var root_1910 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1910, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1912 lang.IFn; if linked_1911 == nil { ifn_1912 = lang.IFn_Cast(root_1910) } else { ifn_1912 = nil }; var arg_1913 any = m__9; if linked_1911 == nil { arg_1909 = ifn_1912.Invoke_O__O(arg_1913) } else { arg_1909 = linked_1911.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1910, arg_1913) }; if linked_1906 == nil { tmp12 = ifn_1907.Invoke_O_O__O(arg_1908, arg_1909) } else { tmp12 = linked_1906.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1905, arg_1908, arg_1909) }
//line :694:1
				var tmp13 any = tmp12; var tmp14 any = A_arbace_go_check_types_A_const_215; var tmp15 any = A_arbace_go_check_types_A_const_215.Invoke_O__O(e__2); var tmp16 any = A_arbace_go_check_types_A_const_216; return lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, tmp9, tmp10, typ__7, tmp11, tmp13, tmp14, tmp15, tmp16, A_arbace_go_check_types_A_const_216.Invoke_O__O(e__2))), next__5, seen__8) } } else {
//line :693:1
					var u__10 any; var root_1872 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1872, A_arbace_go_check_types_under_A_fn_class); var ifn_1874 lang.IFn




					if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any = typ__7; if linked_1873 == nil { u__10 = ifn_1874.Invoke_O__O(arg_1875) } else { u__10 = linked_1873.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1872, arg_1875) }
					var tmp17 any; var and__1927000168__auto____11 any; var root_1876 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1876, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1878 lang.IFn
					if linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any = u__10; if linked_1877 == nil { and__1927000168__auto____11 = ifn_1878.Invoke_O__O(arg_1879) } else { and__1927000168__auto____11 = linked_1877.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1876, arg_1879) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var tmp18 any = A_arbace_go_check_types_A_const_105; tmp17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp18, lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp17 = and__1927000168__auto____11 }
//line :699:1
					if jrt.J2g_Truth(tmp17) { var fs__11 any = lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(1)); var i__12 int64 = 0; var found__13 any = found__4; var next__14 any = next__5; L1: for {



						if lang.Numbers_Gte_J_J__Z_NoInit(i__12, int64(lang.RT_Count_O__I_NoInit(fs__11))) { return lang.Tuple_Create_O_O_O__IPersistentVector(found__13, next__14, seen__8) } else { var f__15 any = lang.RT_Nth_O_I__O_NoInit(fs__11, lang.RT_IntCast_J__I_NoInit(i__12)); var tmp19 any; var root_1880 any = A_arbace_go_check_types_A_const_202.GetRawRoot__O(); var linked_1881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1880, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_1882 lang.IFn



							if linked_1881 == nil { ifn_1882 = lang.IFn_Cast(root_1880) } else { ifn_1882 = nil }; var arg_1883 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(f__15); var arg_1884 any = A_arbace_go_check_types_A_const_171.Invoke_O__O(f__15); var arg_1885 any = t.F_name; var arg_1886 any = t.F_pkg; if linked_1881 == nil { tmp19 = ifn_1882.Invoke_O_O_O_O__O(arg_1883, arg_1884, arg_1885, arg_1886) } else { tmp19 = linked_1881.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_1880, arg_1883, arg_1884, arg_1885, arg_1886) }
//line :706:1
							if jrt.J2g_Truth(tmp19) {

								var tmp20 any; var or__1927000174__auto____16 any = found__13; if jrt.J2g_Truth(or__1927000174__auto____16) { tmp20 = or__1927000174__auto____16 } else { tmp20 = A_arbace_go_check_types_A_const_204.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp20) {
									i__12, found__13, next__14 = lang.Numbers_Inc_J__J_NoInit(i__12), A_arbace_go_check_types_A_const_217, next__14; continue L1 } else {
										var tmp21 int64 = lang.Numbers_Inc_J__J_NoInit(i__12); var tmp22 any = A_arbace_go_check_types_A_const_210; var tmp23 any = A_arbace_go_check_types_A_const_218; var tmp24 any = A_arbace_go_check_types_A_const_71; var tmp25 any = A_arbace_go_check_types_A_const_214; var tmp26 any; var root_1914 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1915 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1914, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1916 lang.IFn; if linked_1915 == nil { ifn_1916 = lang.IFn_Cast(root_1914) } else { ifn_1916 = nil }; var arg_1917 any = A_arbace_go_check_types_A_const_214.Invoke_O__O(e__2); var arg_1918 any = jrt.Long_ValueOf_J__Long_NoInit(i__12).Ref(); if linked_1915 == nil { tmp26 = ifn_1916.Invoke_O_O__O(arg_1917, arg_1918) } else { tmp26 = linked_1915.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1914, arg_1917, arg_1918) }; var tmp27 any = tmp26; var tmp28 any = A_arbace_go_check_types_A_const_215; var tmp29 any = A_arbace_go_check_types_A_const_215.Invoke_O__O(e__2); var tmp30 any = A_arbace_go_check_types_A_const_216; i__12, found__13, next__14 = tmp21, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp23, tmp24, f__15, tmp25, tmp27, tmp28, tmp29, tmp30, A_arbace_go_check_types_A_const_216.Invoke_O__O(e__2))), next__14; continue L1 } } else {
//line :706:1
											var tmp31 any; var and__1927000168__auto____16 bool = lang.Util_Identical_O_O__Z_NoInit(found__13, nil)






											if and__1927000168__auto____16 { tmp31 = A_arbace_go_check_types_A_const_169.Invoke_O__O(f__15) } else { tmp31 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____16).Ref() }
//line :706:1
											if jrt.J2g_Truth(tmp31) { var vec__219000261__16 any; var root_1887 any = A_arbace_go_check_types_A_const_205.GetRawRoot__O(); var linked_1888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1887, A_arbace_go_check_types_deref_type_A_fn_class); var ifn_1889 lang.IFn







												if linked_1888 == nil { ifn_1889 = lang.IFn_Cast(root_1887) } else { ifn_1889 = nil }; var arg_1890 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(f__15); if linked_1888 == nil { vec__219000261__16 = ifn_1889.Invoke_O__O(arg_1890) } else { vec__219000261__16 = linked_1888.(*A_arbace_go_check_types_deref_type_A).Invoke_O_O__O(root_1887, arg_1890) }
//line :706:1
												var ft__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000261__16, lang.RT_IntCast_J__I_NoInit(0), nil); var fp__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000261__16, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp32 int64 = lang.Numbers_Inc_J__J_NoInit(i__12); var tmp33 any; var root_1919 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1920 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1919, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1921 lang.IFn









												if linked_1920 == nil { ifn_1921 = lang.IFn_Cast(root_1919) } else { ifn_1921 = nil }; var arg_1922 any = next__14; var arg_1923 any; var tmp34 any = A_arbace_go_check_types_A_const_107; var tmp35 any = A_arbace_go_check_types_A_const_214; var tmp36 any; var root_1924 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1925 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1924, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1926 lang.IFn; if linked_1925 == nil { ifn_1926 = lang.IFn_Cast(root_1924) } else { ifn_1926 = nil }; var arg_1927 any = A_arbace_go_check_types_A_const_214.Invoke_O__O(e__2); var arg_1928 any = jrt.Long_ValueOf_J__Long_NoInit(i__12).Ref(); if linked_1925 == nil { tmp36 = ifn_1926.Invoke_O_O__O(arg_1927, arg_1928) } else { tmp36 = linked_1925.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1924, arg_1927, arg_1928) }; var tmp37 any = tmp36; var tmp38 any = A_arbace_go_check_types_A_const_215; var tmp39 any; var root_1929 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1930 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1929, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1931 lang.IFn
												if linked_1930 == nil { ifn_1931 = lang.IFn_Cast(root_1929) } else { ifn_1931 = nil }; var arg_1932 any = A_arbace_go_check_types_A_const_215.Invoke_O__O(e__2); var arg_1933 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(f__15); if linked_1930 == nil { tmp39 = ifn_1931.Invoke_O_O__O(arg_1932, arg_1933) } else { tmp39 = linked_1930.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1929, arg_1932, arg_1933) }
//line :716:1
												var tmp40 any = tmp39; var tmp41 any = A_arbace_go_check_types_A_const_216; var tmp42 any; var or__1927000174__auto____19 any = A_arbace_go_check_types_A_const_216.Invoke_O__O(e__2)

												if jrt.J2g_Truth(or__1927000174__auto____19) { tmp42 = or__1927000174__auto____19 } else { tmp42 = fp__18 }
//line :716:1
												var tmp43 any = tmp42; var tmp44 any = A_arbace_go_check_types_A_const_204; arg_1923 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp34, ft__17, tmp35, tmp37, tmp38, tmp40, tmp41, tmp43, tmp44, A_arbace_go_check_types_A_const_204.Invoke_O__O(e__2))); if linked_1920 == nil { tmp33 = ifn_1921.Invoke_O_O__O(arg_1922, arg_1923) } else { tmp33 = linked_1920.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1919, arg_1922, arg_1923) }
//line :715:1
												i__12, found__13, next__14 = tmp32, found__13, tmp33; continue L1 } else {
//line :706:1
													if A_arbace_go_check_types_A_const_75 != nil {













														i__12, found__13, next__14 = lang.Numbers_Inc_J__J_NoInit(i__12), found__13, next__14; continue L1 } else {
//line :706:1
															return nil } } } } } } else {
//line :699:1
																var tmp45 any; var and__1927000168__auto____11_2 any; var root_1891 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1891, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1893 lang.IFn





















																if linked_1892 == nil { ifn_1893 = lang.IFn_Cast(root_1891) } else { ifn_1893 = nil }; var arg_1894 any = u__10; if linked_1892 == nil { and__1927000168__auto____11_2 = ifn_1893.Invoke_O__O(arg_1894) } else { and__1927000168__auto____11_2 = linked_1892.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1891, arg_1894) }; if jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp46 any = A_arbace_go_check_types_A_const_86; tmp45 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp46, lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp45 = and__1927000168__auto____11_2 }
//line :699:1
																if jrt.J2g_Truth(tmp45) { var temp__1927000408__auto____11 any; var root_1895 any = A_arbace_go_check_types_A_const_208.GetRawRoot__O(); var linked_1896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1895, A_arbace_go_check_types_iface_method_A_fn_class); var ifn_1897 lang.IFn






















																	if linked_1896 == nil { ifn_1897 = lang.IFn_Cast(root_1895) } else { ifn_1897 = nil }; var arg_1898 any = u__10; var arg_1899 any = t.F_name; var arg_1900 any = t.F_pkg; if linked_1896 == nil { temp__1927000408__auto____11 = ifn_1897.Invoke_O_O_O__O(arg_1898, arg_1899, arg_1900) } else { temp__1927000408__auto____11 = linked_1896.(*A_arbace_go_check_types_iface_method_A).Invoke_O_O_O_O__O(root_1895, arg_1898, arg_1899, arg_1900) }; if jrt.J2g_Truth(temp__1927000408__auto____11) { var m__12 any = temp__1927000408__auto____11; var tmp47 any; var or__1927000174__auto____13 any = found__4
																		if jrt.J2g_Truth(or__1927000174__auto____13) { tmp47 = or__1927000174__auto____13 } else { tmp47 = A_arbace_go_check_types_A_const_204.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp47) { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_219, next__5, seen__8) } else { var tmp48 any = A_arbace_go_check_types_A_const_210; var tmp49 any = A_arbace_go_check_types_A_const_220; var tmp50 any = A_arbace_go_check_types_A_const_71; var tmp51 any; var root_1934 any = A_arbace_go_check_types_A_const_212.GetRawRoot__O(); var linked_1935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1934, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1936 lang.IFn

																			if linked_1935 == nil { ifn_1936 = lang.IFn_Cast(root_1934) } else { ifn_1936 = nil }; var arg_1937 any = m__12; if linked_1935 == nil { tmp51 = ifn_1936.Invoke_O__O(arg_1937) } else { tmp51 = linked_1935.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1934, arg_1937) }
//line :723:1
																			var tmp52 any = tmp51; var tmp53 any = A_arbace_go_check_types_A_const_146; var tmp54 any = A_arbace_go_check_types_A_const_214; var tmp55 any; var root_1938 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1939 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1938, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1940 lang.IFn

																			if linked_1939 == nil { ifn_1940 = lang.IFn_Cast(root_1938) } else { ifn_1940 = nil }; var arg_1941 any = A_arbace_go_check_types_A_const_214.Invoke_O__O(e__2); var arg_1942 any; var root_1943 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1943, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1945 lang.IFn; if linked_1944 == nil { ifn_1945 = lang.IFn_Cast(root_1943) } else { ifn_1945 = nil }; var arg_1946 any = m__12; if linked_1944 == nil { arg_1942 = ifn_1945.Invoke_O__O(arg_1946) } else { arg_1942 = linked_1944.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1943, arg_1946) }; if linked_1939 == nil { tmp55 = ifn_1940.Invoke_O_O__O(arg_1941, arg_1942) } else { tmp55 = linked_1939.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1938, arg_1941, arg_1942) }
//line :723:1
																			var tmp56 any = tmp55; var tmp57 any = A_arbace_go_check_types_A_const_215; var tmp58 any = A_arbace_go_check_types_A_const_215.Invoke_O__O(e__2); var tmp59 any = A_arbace_go_check_types_A_const_216; return lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp48, tmp49, tmp50, tmp52, tmp53, typ__7, tmp54, tmp56, tmp57, tmp58, tmp59, A_arbace_go_check_types_A_const_216.Invoke_O__O(e__2))), next__5, seen__8) } } else {
//line :722:1
																				return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__8) } } else {
//line :699:1
																					if A_arbace_go_check_types_A_const_75 != nil { return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__8) } else { return nil } } } } } }; /*line :687:1*/panic("j2g: unreachable") }




















































func A_arbace_go_check_types_lookup_A_New() *A_arbace_go_check_types_lookup_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_A{}; t.Ctor(); return t }
//line :740:1
func (t *A_arbace_go_check_types_lookup_A) Ctor() {}
//line :740:1
func (t *A_arbace_go_check_types_lookup_A) Invoke_O_O_O_O_O__O(self, T__0_, addressable__1, name__2, pkg__3 any) any {


	var tmp1 any; var and__1927000168__auto____5 any; var root_1960 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1960, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1962 lang.IFn; if linked_1961 == nil { ifn_1962 = lang.IFn_Cast(root_1960) } else { ifn_1962 = nil }; var arg_1963 any = T__0_; if linked_1961 == nil { and__1927000168__auto____5 = ifn_1962.Invoke_O__O(arg_1963) } else { and__1927000168__auto____5 = linked_1961.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1960, arg_1963) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1964 any = A_arbace_go_check_types_A_const_226.GetRawRoot__O(); var linked_1965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1964, A_arbace_go_check_types_pointer_QMARK__A_fn_class); var ifn_1966 lang.IFn; if linked_1965 == nil { ifn_1966 = lang.IFn_Cast(root_1964) } else { ifn_1966 = nil }; var arg_1967 any = T__0_; if linked_1965 == nil { tmp1 = ifn_1966.Invoke_O__O(arg_1967) } else { tmp1 = linked_1965.(*A_arbace_go_check_types_pointer_QMARK__A).Invoke_O_O__O(root_1964, arg_1967) } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var r__5 any; var root_1968 any = A_arbace_go_check_types_A_const_227.GetRawRoot__O(); var linked_1969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1968, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_1970 lang.IFn
		if linked_1969 == nil { ifn_1970 = lang.IFn_Cast(root_1968) } else { ifn_1970 = nil }; var arg_1971 any; var root_1975 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1975, A_arbace_go_check_types_under_A_fn_class); var ifn_1977 lang.IFn; if linked_1976 == nil { ifn_1977 = lang.IFn_Cast(root_1975) } else { ifn_1977 = nil }; var arg_1978 any = T__0_; if linked_1976 == nil { arg_1971 = ifn_1977.Invoke_O__O(arg_1978) } else { arg_1971 = linked_1976.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1975, arg_1978) }; var arg_1972 any = jrt.Boolean_FALSE.Ref(); var arg_1973 any = name__2; var arg_1974 any = pkg__3; if linked_1969 == nil { r__5 = ifn_1970.Invoke_O_O_O_O__O(arg_1971, arg_1972, arg_1973, arg_1974) } else { r__5 = linked_1969.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_1968, arg_1971, arg_1972, arg_1973, arg_1974) }
		var tmp2 any = A_arbace_go_check_types_A_const_211; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_go_check_types_A_const_210.Invoke_O__O(r__5)) { return nil } else { return r__5 } } else {
			var root_1979 any = A_arbace_go_check_types_A_const_227.GetRawRoot__O(); var linked_1980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1979, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_1981 lang.IFn; if linked_1980 == nil { ifn_1981 = lang.IFn_Cast(root_1979) } else { ifn_1981 = nil }; var arg_1982 any = T__0_; var arg_1983 any = addressable__1; var arg_1984 any = name__2; var arg_1985 any = pkg__3; if linked_1980 == nil { return ifn_1981.Invoke_O_O_O_O__O(arg_1982, arg_1983, arg_1984, arg_1985) } else { return linked_1980.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_1979, arg_1982, arg_1983, arg_1984, arg_1985)
			}
		}
}
func A_arbace_go_check_types_sort_methods_A_New() *A_arbace_go_check_types_sort_methods_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sort_methods_A{}; t.Ctor(); return t }
//line :750:1
func (t *A_arbace_go_check_types_sort_methods_A) Ctor() {}
//line :750:1
func (t *A_arbace_go_check_types_sort_methods_A) Invoke_O_O__O(self, ms__0 any) any {


	var root_1986 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var linked_1987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1986, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1988 lang.IFn; if linked_1987 == nil { ifn_1988 = lang.IFn_Cast(root_1986) } else { ifn_1988 = nil }; var arg_1989 any; var root_1990 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1990, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1992 lang.IFn; if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; var arg_1993 any; var tmp1 any = A_arbace_go_check_types_sort_methods_fn__219000267_A_New(); var tmp2 *jrt.Class; var fncls__1995 *jrt.Class = A_arbace_go_check_types_sort_methods_fn__219000267_A_fn_class; if fncls__1995 == nil { var fncls__1995d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_go_check_types_sort_methods_fn__219000267_A_fn_class = fncls__1995d; tmp2 = fncls__1995d } else { tmp2 = fncls__1995 }; arg_1993 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1994 any = ms__0; if linked_1991 == nil { arg_1989 = ifn_1992.Invoke_O_O__O(arg_1993, arg_1994) } else { arg_1989 = linked_1991.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1990, arg_1993, arg_1994) }; if linked_1987 == nil { return ifn_1988.Invoke_O__O(arg_1989) } else { return linked_1987.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1986, arg_1989) } }
//line :753:1
func A_arbace_go_check_types_sort_methods_fn__219000267_A_New() *A_arbace_go_check_types_sort_methods_fn__219000267_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sort_methods_fn__219000267_A{}; t.Ctor(); return t }
//line :753:1
func (t *A_arbace_go_check_types_sort_methods_fn__219000267_A) Ctor() {}
//line :753:1
func (t *A_arbace_go_check_types_sort_methods_fn__219000267_A) Invoke_O_O__O(self, m__1 any) any { var tmp1 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var tmp2 any; var or__1927000174__auto____2 any = A_arbace_go_check_types_A_const_171.Invoke_O__O(m__1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = Lit_8 }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }

func A_arbace_go_check_types_method_data_A_New() *A_arbace_go_check_types_method_data_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_method_data_A{}; t.Ctor(); return t }
//line :755:1
func (t *A_arbace_go_check_types_method_data_A) Ctor() {}
//line :755:1
func (t *A_arbace_go_check_types_method_data_A) Invoke_O_O__O(self, m__0 any) any {


	var tmp1 any; var root_1996 any = A_arbace_go_check_types_A_const_143.GetRawRoot__O(); var linked_1997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1996, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1998 lang.IFn; if linked_1997 == nil { ifn_1998 = lang.IFn_Cast(root_1996) } else { ifn_1998 = nil }; var arg_1999 any = m__0; if linked_1997 == nil { tmp1 = ifn_1998.Invoke_O__O(arg_1999) } else { tmp1 = linked_1997.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1996, arg_1999) }; if jrt.J2g_Truth(tmp1) { return m__0 } else { return lang.IFn_Cast(A_arbace_go_check_types_A_const_223.Get__O()).Invoke_O__O(m__0)
	} }
func A_arbace_go_check_types_missing_method_A_New() *A_arbace_go_check_types_missing_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_A{}; t.Ctor(); return t }
//line :760:1
func (t *A_arbace_go_check_types_missing_method_A) Ctor() {}
//line :760:1
func (t *A_arbace_go_check_types_missing_method_A) Invoke_O_O_O_O_O__O(self, V__0_, T__1_, static__2, same_QMARK___3 any) any { var tu__5 any; var root_2000 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_2001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2000, A_arbace_go_check_types_under_A_fn_class); var ifn_2002 lang.IFn; if





	linked_2001 == nil { ifn_2002 = lang.IFn_Cast(root_2000) } else { ifn_2002 = nil }; var arg_2003 any = T__1_; if linked_2001 == nil { tu__5 = ifn_2002.Invoke_O__O(arg_2003) } else { tu__5 = linked_2001.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2000, arg_2003) }; var vu__6 any; var root_2004 any = /*line :760:1*/A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_2005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2004, A_arbace_go_check_types_under_A_fn_class); var ifn_2006 lang.IFn; if






	linked_2005 == nil { ifn_2006 = lang.IFn_Cast(root_2004) } else { ifn_2006 = nil }; var arg_2007 any = V__0_; if linked_2005 == nil { vu__6 = ifn_2006.Invoke_O__O(arg_2007) } else { vu__6 = linked_2005.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2004, arg_2007) }; var tmp1 any; var tmp2 /*line :770:1*/*lang.Keyword = A_arbace_go_check_types_A_const_228; var or__1927000174__auto____7 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tu__5)); if jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { var tmp3 *lang.Keyword = A_arbace_go_check_types_A_const_228; tmp1 = tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(vu__6)) }; if jrt.J2g_Truth(tmp1) { return nil } else {
		var root_2008 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_2009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2008, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2010 lang.IFn; if linked_2009 == nil { ifn_2010 = lang.IFn_Cast(root_2008) } else { ifn_2010 = nil }; var arg_2011 any; var tmp4 any = A_arbace_go_check_types_missing_method_fn__219000271_A_New_O_O_O_O(static__2, V__0_, same_QMARK___3, vu__6); var tmp5 *jrt.Class; var fncls__2082 *jrt.Class = A_arbace_go_check_types_missing_method_fn__219000271_A_fn_class
		if fncls__2082 == nil { var fncls__2082d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_go_check_types_missing_method_fn__219000271_A_fn_class = fncls__2082d; tmp5 = fncls__2082d } else { tmp5 = fncls__2082 }; arg_2011 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)
//line :771:1
		var arg_2012 any = lang.RT_Nth_O_I__O_NoInit(tu__5, lang.RT_IntCast_J__I_NoInit(1)); if linked_2009 == nil { return ifn_2010.Invoke_O_O__O(arg_2011, arg_2012) } else { return linked_2009.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2008, arg_2011, arg_2012) } } }
//line :760:1
func (t *A_arbace_go_check_types_missing_method_A) Invoke_O_O_O_O__O(self, V__0_, T__1_, static__2 any) any {



	var root_2083 any = A_arbace_go_check_types_A_const_241.GetRawRoot__O(); var linked_2084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2083, A_arbace_go_check_types_missing_method_A_fn_class); var ifn_2085 lang.IFn; if linked_2084 == nil { ifn_2085 = lang.IFn_Cast(root_2083) } else { ifn_2085 = nil }; var arg_2086 any = V__0_; var arg_2087 any = T__1_; var arg_2088 any = static__2; var arg_2089 any = A_arbace_go_check_types_A_const_242.GetRawRoot__O(); if linked_2084 == nil { return ifn_2085.Invoke_O_O_O_O__O(arg_2086, arg_2087, arg_2088, arg_2089) } else { return linked_2084.(*A_arbace_go_check_types_missing_method_A).Invoke_O_O_O_O_O__O(root_2083, arg_2086, arg_2087, arg_2088, arg_2089)
	}
}





func A_arbace_go_check_types_missing_method_fn__219000271_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_types_missing_method_fn__219000271_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_fn__219000271_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :772:1
func (t *A_arbace_go_check_types_missing_method_fn__219000271_A) Ctor_O_O_O_O(c__static, c__V, c__same_QMARK_, c__vu any) { t.F_static = c__static; t.F_V = c__V; t.F_same_QMARK_ = c__same_QMARK_; t.F_vu = c__vu }
//line :772:1
func (t *A_arbace_go_check_types_missing_method_fn__219000271_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_2013 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_2014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2013, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2015 lang.IFn; if linked_2014 == nil { ifn_2015 = lang.IFn_Cast(root_2013) } else { ifn_2015 = nil }; var arg_2016 any = t.F_vu; if linked_2014 == nil { and__1927000168__auto____2 = ifn_2015.Invoke_O__O(arg_2016) } else { and__1927000168__auto____2 = linked_2014.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2013, arg_2016) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_types_A_const_86; var tmp3 any = t.F_vu; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var f__2 any; var root_2017 any = A_arbace_go_check_types_A_const_208.GetRawRoot__O(); var linked_2018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2017, A_arbace_go_check_types_iface_method_A_fn_class); var ifn_2019 lang.IFn
		if linked_2018 == nil { ifn_2019 = lang.IFn_Cast(root_2017) } else { ifn_2019 = nil }; var arg_2020 any = t.F_vu; var arg_2021 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var arg_2022 any = A_arbace_go_check_types_A_const_171.Invoke_O__O(m__1); if linked_2018 == nil { f__2 = ifn_2019.Invoke_O_O_O__O(arg_2020, arg_2021, arg_2022) } else { f__2 = linked_2018.(*A_arbace_go_check_types_iface_method_A).Invoke_O_O_O_O__O(root_2017, arg_2020, arg_2021, arg_2022) }
		if lang.Util_Identical_O_O__Z_NoInit(f__2, nil) {
			if jrt.J2g_Truth(t.F_static) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_211, m__1, A_arbace_go_check_types_A_const_229, A_arbace_go_check_types_A_const_230)) } else { return nil } } else {
//line :775:1
				var tmp4 any; var root_2023 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_2024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2023, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2025 lang.IFn

				if linked_2024 == nil { ifn_2025 = lang.IFn_Cast(root_2023) } else { ifn_2025 = nil }; var arg_2026 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_same_QMARK_); var tmp6 *lang.Keyword = A_arbace_go_check_types_A_const_107; var tmp7 any; var root_2027 any = A_arbace_go_check_types_A_const_212.GetRawRoot__O(); var linked_2028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2027, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2029 lang.IFn; if linked_2028 == nil { ifn_2029 = lang.IFn_Cast(root_2027) } else { ifn_2029 = nil }; var arg_2030 any = f__2; if linked_2028 == nil { tmp7 = ifn_2029.Invoke_O__O(arg_2030) } else { tmp7 = linked_2028.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2027, arg_2030) }; arg_2026 = tmp5.Invoke_O_O__O(tmp6.Invoke_O__O(tmp7), A_arbace_go_check_types_A_const_107.Invoke_O__O(m__1)); if linked_2024 == nil { tmp4 = ifn_2025.Invoke_O__O(arg_2026) } else { tmp4 = linked_2024.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2023, arg_2026) }
//line :775:1
				if jrt.J2g_Truth(tmp4) { var tmp8 any = A_arbace_go_check_types_A_const_211; var tmp9 any = A_arbace_go_check_types_A_const_229; var tmp10 any = A_arbace_go_check_types_A_const_231; var tmp11 any = A_arbace_go_check_types_A_const_232; var tmp12 any; var root_2031 any = A_arbace_go_check_types_A_const_212.GetRawRoot__O(); var linked_2032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2031, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2033 lang.IFn

					if linked_2032 == nil { ifn_2033 = lang.IFn_Cast(root_2031) } else { ifn_2033 = nil }; var arg_2034 any = f__2; if linked_2032 == nil { tmp12 = ifn_2033.Invoke_O__O(arg_2034) } else { tmp12 = linked_2032.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2031, arg_2034) }
//line :775:1
					return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, m__1, tmp9, tmp10, tmp11, tmp12)) } else { return nil } } } else {
//line :773:1
						var r__2 any; var root_2035 any = A_arbace_go_check_types_A_const_227.GetRawRoot__O(); var linked_2036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2035, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_2037 lang.IFn




						if linked_2036 == nil { ifn_2037 = lang.IFn_Cast(root_2035) } else { ifn_2037 = nil }; var arg_2038 any = t.F_V; var arg_2039 any = jrt.Boolean_FALSE.Ref(); var arg_2040 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var arg_2041 any = A_arbace_go_check_types_A_const_171.Invoke_O__O(m__1); if linked_2036 == nil { r__2 = ifn_2037.Invoke_O_O_O_O__O(arg_2038, arg_2039, arg_2040, arg_2041) } else { r__2 = linked_2036.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_2035, arg_2038, arg_2039, arg_2040, arg_2041) }
						if jrt.J2g_Truth(A_arbace_go_check_types_A_const_222.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_211, m__1, A_arbace_go_check_types_A_const_229, A_arbace_go_check_types_A_const_222)) } else { if lang.Util_Identical_O_O__Z_NoInit(r__2, nil) { var fr__3 any; var root_2073 any = A_arbace_go_check_types_A_const_239.GetRawRoot__O(); var linked_2074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2073, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2075 lang.IFn



							if linked_2074 == nil { ifn_2075 = lang.IFn_Cast(root_2073) } else { ifn_2075 = nil }; var arg_2076 any = lang.IFn_Cast(A_arbace_go_check_types_A_const_240.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_198, jrt.Boolean_TRUE.Ref()); if linked_2074 == nil { ifn_2075.Invoke_O__O(arg_2076) } else { linked_2074.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2073, arg_2076) }; var tmp13 any = A_arbace_go_check_types_missing_method_fn__219000271_fn__219000272_A_New_O_O(m__1, t.F_V); var tmp14 *jrt.Class; var fncls__2052 *jrt.Class = A_arbace_go_check_types_missing_method_fn__219000271_fn__219000272_A_fn_class; if fncls__2052 == nil { var fncls__2052d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_go_check_types_missing_method_fn__219000271_fn__219000272_A_fn_class = fncls__2052d; tmp14 = fncls__2052d } else { tmp14 = fncls__2052 }; fr__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil).Invoke__O()
							var tmp15 any; var tmp16 any = A_arbace_go_check_types_A_const_211; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp16, A_arbace_go_check_types_A_const_210.Invoke_O__O(fr__3)); if and__1927000168__auto____4 { var root_2053 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_2054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2053, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2055 lang.IFn; if linked_2054 == nil { ifn_2055 = lang.IFn_Cast(root_2053) } else { ifn_2055 = nil }; var arg_2056 any = A_arbace_go_check_types_A_const_221.Invoke_O__O(fr__3); if linked_2054 == nil { tmp15 = ifn_2055.Invoke_O__O(arg_2056) } else { tmp15 = linked_2054.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2053, arg_2056) } } else { tmp15 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if jrt.J2g_Truth(tmp15) { var d__4 any; var root_2057 any = A_arbace_go_check_types_A_const_234.GetRawRoot__O(); var linked_2058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2057, A_arbace_go_check_types_method_data_A_fn_class); var ifn_2059 lang.IFn
								if linked_2058 == nil { ifn_2059 = lang.IFn_Cast(root_2057) } else { ifn_2059 = nil }; var arg_2060 any = A_arbace_go_check_types_A_const_71.Invoke_O__O(fr__3); if linked_2058 == nil { d__4 = ifn_2059.Invoke_O__O(arg_2060) } else { d__4 = linked_2058.(*A_arbace_go_check_types_method_data_A).Invoke_O_O__O(root_2057, arg_2060) }
//line :784:1
								var tmp17 any = A_arbace_go_check_types_A_const_211; var tmp18 any = A_arbace_go_check_types_A_const_229; var tmp19 *lang.Keyword

								if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_12.Invoke_O__O(d__4), A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1)) { tmp19 = A_arbace_go_check_types_A_const_235 } else { tmp19 = A_arbace_go_check_types_A_const_236 }
//line :784:1
								return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, m__1, tmp18, tmp19.Ref(), A_arbace_go_check_types_A_const_232, d__4)) } else { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_211, m__1, A_arbace_go_check_types_A_const_229, A_arbace_go_check_types_A_const_230)) } } else {
//line :779:1
									if jrt.J2g_Truth(A_arbace_go_check_types_A_const_221.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_211, m__1, A_arbace_go_check_types_A_const_229, A_arbace_go_check_types_A_const_230)) } else { var tmp20 any = A_arbace_go_check_types_A_const_218; if lang.Util_Equiv_O_O__Z_NoInit(tmp20, A_arbace_go_check_types_A_const_210.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_211, m__1, A_arbace_go_check_types_A_const_229, A_arbace_go_check_types_A_const_218)) } else { if A_arbace_go_check_types_A_const_75 != nil { var d__3 any; var root_2061 any = A_arbace_go_check_types_A_const_234.GetRawRoot__O(); var linked_2062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2061, A_arbace_go_check_types_method_data_A_fn_class); var ifn_2063 lang.IFn











										if linked_2062 == nil { ifn_2063 = lang.IFn_Cast(root_2061) } else { ifn_2063 = nil }; var arg_2064 any = A_arbace_go_check_types_A_const_71.Invoke_O__O(r__2); if linked_2062 == nil { d__3 = ifn_2063.Invoke_O__O(arg_2064) } else { d__3 = linked_2062.(*A_arbace_go_check_types_method_data_A).Invoke_O_O__O(root_2061, arg_2064) }
//line :779:1
										var d__4_2 any; var tmp21 any; var and__1927000168__auto____4_2 any = A_arbace_go_check_types_A_const_237.Get__O()












										if jrt.J2g_Truth(and__1927000168__auto____4_2) { var tmp22 any = A_arbace_go_check_types_A_const_211; tmp21 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp22, A_arbace_go_check_types_A_const_210.Invoke_O__O(r__2))).Ref() } else { tmp21 = and__1927000168__auto____4_2 }; if jrt.J2g_Truth(tmp21) { d__4_2 = lang.IFn_Cast(A_arbace_go_check_types_A_const_237.Get__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_213.Invoke_O__O(r__2), d__3) } else { d__4_2 = d__3
										}
										var tmp23 any; var or__1927000174__auto____5 any; var root_2065 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_2066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2065, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2067 lang.IFn; if linked_2066 == nil { ifn_2067 = lang.IFn_Cast(root_2065) } else { ifn_2067 = nil }; var arg_2068 any = A_arbace_go_check_types_A_const_238.Invoke_O__O(d__4_2); if linked_2066 == nil { or__1927000174__auto____5 = ifn_2067.Invoke_O__O(arg_2068) } else { or__1927000174__auto____5 = linked_2066.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2065, arg_2068) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp23 = or__1927000174__auto____5 } else { var root_2069 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_2070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2069, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2071 lang.IFn; if linked_2070 == nil { ifn_2071 = lang.IFn_Cast(root_2069) } else { ifn_2071 = nil }; var tmp24 lang.IFn = lang.IFn_Cast(t.F_same_QMARK_); var arg_2072 any = tmp24.Invoke_O_O__O(A_arbace_go_check_types_A_const_107.Invoke_O__O(d__4_2), A_arbace_go_check_types_A_const_107.Invoke_O__O(m__1)); if linked_2070 == nil { tmp23 = ifn_2071.Invoke_O__O(arg_2072) } else { tmp23 = linked_2070.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2069, arg_2072) } }; if jrt.J2g_Truth(tmp23) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_211, m__1, A_arbace_go_check_types_A_const_229, A_arbace_go_check_types_A_const_231, A_arbace_go_check_types_A_const_232, d__4_2)) } else { return nil } } else {
//line :779:1
											return nil
										}
									}
									} } } } }
func A_arbace_go_check_types_missing_method_fn__219000271_fn__219000272_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_missing_method_fn__219000271_fn__219000272_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_fn__219000271_fn__219000272_A{}; t.Ctor_O_O(p0, p1); return t }
//line :783:1
func (t *A_arbace_go_check_types_missing_method_fn__219000271_fn__219000272_A) Ctor_O_O(c__m, c__V any) { t.F_m = c__m; t.F_V = c__V }
//line :783:1
func (t *A_arbace_go_check_types_missing_method_fn__219000271_fn__219000272_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2042 any = A_arbace_go_check_types_A_const_227.GetRawRoot__O(); var linked_2043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2042, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_2044 lang.IFn; if linked_2043 == nil { ifn_2044 = lang.IFn_Cast(root_2042) } else { ifn_2044 = nil }; var arg_2045 any; var t_ any = t.F_V; t.F_V = nil; arg_2045 = t_; var arg_2046 any = jrt.Boolean_FALSE.Ref(); var arg_2047 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(t.F_m); var arg_2048 any; var tmp2 *lang.Keyword = A_arbace_go_check_types_A_const_171; var tmp3 any; var t__2 any = t.F_m; t.F_m = nil; tmp3 = t__2; arg_2048 = tmp2.Invoke_O__O(tmp3); if linked_2043 == nil { tmp1 = ifn_2044.Invoke_O_O_O_O__O(arg_2045, arg_2046, arg_2047, arg_2048) } else { tmp1 = linked_2043.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_2042, arg_2045, arg_2046, arg_2047, arg_2048) } }; return nil }(); var root_2049 any = A_arbace_go_check_types_A_const_233.GetRawRoot__O(); var linked_2050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2049, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2051 lang.IFn; if linked_2050 == nil { ifn_2051 = lang.IFn_Cast(root_2049) } else { ifn_2051 = nil }; if linked_2050 == nil { ifn_2051.Invoke__O() } else { linked_2050.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2049) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }
















func A_arbace_go_check_types_satisfies_cause_A_New() *A_arbace_go_check_types_satisfies_cause_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_A{}; t.Ctor(); return t }
//line :800:1
func (t *A_arbace_go_check_types_satisfies_cause_A) Ctor() {}
//line :800:1
func (t *A_arbace_go_check_types_satisfies_cause_A) Invoke_O_O_O__O(self, V__0_, b__1 any) any { var Ti__3_ any; var root_2090 any = A_arbace_go_check_types_A_const_147.GetRawRoot__O(); var linked_2091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2090, A_arbace_go_check_types_bound_iface_A_fn_class); var ifn_2092 lang.IFn; if



	linked_2091 == nil { ifn_2092 = lang.IFn_Cast(root_2090) } else { ifn_2092 = nil }; var arg_2093 any = b__1; if linked_2091 == nil { Ti__3_ = ifn_2092.Invoke_O__O(arg_2093) } else { Ti__3_ = linked_2091.(*A_arbace_go_check_types_bound_iface_A).Invoke_O_O__O(root_2090, arg_2093) }; var Vu__4_ any; var root_2094 any = /*line :800:1*/A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_2095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2094, A_arbace_go_check_types_under_A_fn_class); var ifn_2096 lang.IFn; if




	linked_2095 == nil { ifn_2096 = lang.IFn_Cast(root_2094) } else { ifn_2096 = nil }; var arg_2097 any = V__0_; if linked_2095 == nil { Vu__4_ = ifn_2096.Invoke_O__O(arg_2097) } else { Vu__4_ = linked_2095.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2094, arg_2097) }; var tmp1 any; var or__1927000174__auto____5 bool =
	lang.Util_Identical_O_O__Z_NoInit(Ti__3_, nil); if or__1927000174__auto____5 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_67, Vu__4_); if or__1927000174__auto____6 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var and__1927000168__auto____7 any; var root_2098 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_2099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2098, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2100 lang.IFn
		if linked_2099 == nil { ifn_2100 = lang.IFn_Cast(root_2098) } else { ifn_2100 = nil }; var arg_2101 any = Vu__4_; if linked_2099 == nil { and__1927000168__auto____7 = ifn_2100.Invoke_O__O(arg_2101) } else { and__1927000168__auto____7 = linked_2099.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2098, arg_2101) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp2 any = A_arbace_go_check_types_A_const_87; var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____8 { var tmp3 any = A_arbace_go_check_types_A_const_67; var tmp4 any; var root_2102 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_2103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2102, A_arbace_go_check_types_under_A_fn_class); var ifn_2104 lang.IFn; if linked_2103 == nil { ifn_2104 = lang.IFn_Cast(root_2102) } else { ifn_2104 = nil }; var arg_2105 any = lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(1)); if linked_2103 == nil { tmp4 = ifn_2104.Invoke_O__O(arg_2105) } else { tmp4 = linked_2103.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2102, arg_2105) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp1 = and__1927000168__auto____7 } } }; if /*line :806:1*/ jrt.J2g_Truth(tmp1) { return nil } else { var Tts__5_ any; var root_2106 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_2107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2106, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_2108 lang.IFn


			if linked_2107 == nil { ifn_2108 = lang.IFn_Cast(root_2106) } else { ifn_2108 = nil }; var arg_2109 any = Ti__3_; if linked_2107 == nil { Tts__5_ = ifn_2108.Invoke_O__O(arg_2109) } else { Tts__5_ = linked_2107.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_2106, arg_2109) }
//line :806:1
			var Vi__6_ any; var tmp5 any; var and__1927000168__auto____6 any; var root_2110 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_2111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2110, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2112 lang.IFn



			if linked_2111 == nil { ifn_2112 = lang.IFn_Cast(root_2110) } else { ifn_2112 = nil }; var arg_2113 any = Vu__4_; if linked_2111 == nil { and__1927000168__auto____6 = ifn_2112.Invoke_O__O(arg_2113) } else { and__1927000168__auto____6 = linked_2111.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2110, arg_2113) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp6 any = A_arbace_go_check_types_A_const_86; tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp6, lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp5 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp5) { Vi__6_ = Vu__4_ } else { Vi__6_ = nil }
//line :806:1
			var Vts__7_ any




			if jrt.J2g_Truth(Vi__6_) { var root_2114 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_2115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2114, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_2116 lang.IFn; if linked_2115 == nil { ifn_2116 = lang.IFn_Cast(root_2114) } else { ifn_2116 = nil }; var arg_2117 any = Vi__6_; if linked_2115 == nil { Vts__7_ = ifn_2116.Invoke_O__O(arg_2117) } else { Vts__7_ = linked_2115.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_2114, arg_2117) } } else { Vts__7_ = nil }
//line :806:1
			var T_str__8_ any; var root_2118 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_2119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2118, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2120 lang.IFn





			if linked_2119 == nil { ifn_2120 = lang.IFn_Cast(root_2118) } else { ifn_2120 = nil }; var arg_2121 any = b__1; if linked_2119 == nil { T_str__8_ = ifn_2120.Invoke_O__O(arg_2121) } else { T_str__8_ = linked_2119.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2118, arg_2121) }
			var tmp7 any; var and__1927000168__auto____9 any; var root_2122 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_2123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2122, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2124 lang.IFn
			if linked_2123 == nil { ifn_2124 = lang.IFn_Cast(root_2122) } else { ifn_2124 = nil }; var arg_2125 any = lang.RT_Nth_O_I__O_NoInit(Ti__3_, lang.RT_IntCast_J__I_NoInit(1)); if linked_2123 == nil { and__1927000168__auto____9 = ifn_2124.Invoke_O__O(arg_2125) } else { and__1927000168__auto____9 = linked_2123.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2122, arg_2125) }; if jrt.J2g_Truth(and__1927000168__auto____9) { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(Ti__3_, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref() } else { tmp7 = and__1927000168__auto____9 }
//line :813:1
			if jrt.J2g_Truth(tmp7) { return nil } else { var tmp8 any
				var and__1927000168__auto____9_2 any = Vts__7_
				if jrt.J2g_Truth(and__1927000168__auto____9_2) { var root_2126 any = A_arbace_go_check_types_A_const_243.GetRawRoot__O(); var linked_2127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2126, A_arbace_go_check_types_tset_empty_QMARK__A_fn_class); var ifn_2128 lang.IFn; if linked_2127 == nil { ifn_2128 = lang.IFn_Cast(root_2126) } else { ifn_2128 = nil }; var arg_2129 any = Vts__7_; if linked_2127 == nil { tmp8 = ifn_2128.Invoke_O__O(arg_2129) } else { tmp8 = linked_2127.(*A_arbace_go_check_types_tset_empty_QMARK__A).Invoke_O_O__O(root_2126, arg_2129) } } else { tmp8 = and__1927000168__auto____9_2 }
//line :813:1
				if jrt.J2g_Truth(tmp8) { return nil } else { var tmp9 any; var root_2130 any = A_arbace_go_check_types_A_const_243.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, A_arbace_go_check_types_tset_empty_QMARK__A_fn_class); var ifn_2132 lang.IFn


					if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any = Tts__5_; if linked_2131 == nil { tmp9 = ifn_2132.Invoke_O__O(arg_2133) } else { tmp9 = linked_2131.(*A_arbace_go_check_types_tset_empty_QMARK__A).Invoke_O_O__O(root_2130, arg_2133) }
//line :813:1
					if jrt.J2g_Truth(tmp9) {


						return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil, Lit_32), jrt.RefArrayOf(jrt.Object_class, nil, T_str__8_, nil)).Ref() } else {
//line :813:1
							if A_arbace_go_check_types_A_const_75 != nil { var temp__1927000408__auto____9 any; var root_2134 any = A_arbace_go_check_types_A_const_241.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2134, A_arbace_go_check_types_missing_method_A_fn_class); var ifn_2136 lang.IFn




								if linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any = V__0_; var arg_2138 any = Ti__3_; var arg_2139 any = jrt.Boolean_TRUE.Ref(); if linked_2135 == nil { temp__1927000408__auto____9 = ifn_2136.Invoke_O_O_O__O(arg_2137, arg_2138, arg_2139) } else { temp__1927000408__auto____9 = linked_2135.(*A_arbace_go_check_types_missing_method_A).Invoke_O_O_O_O__O(root_2134, arg_2137, arg_2138, arg_2139) }; if jrt.J2g_Truth(temp__1927000408__auto____9) { var mm__10 any = temp__1927000408__auto____9; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_33, nil, Lit_34, nil, Lit_27); var tmp11 any; var root_2140 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_2141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2140, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2142 lang.IFn
									if linked_2141 == nil { ifn_2142 = lang.IFn_Cast(root_2140) } else { ifn_2142 = nil }; var arg_2143 any = V__0_; if linked_2141 == nil { tmp11 = ifn_2142.Invoke_O__O(arg_2143) } else { tmp11 = linked_2141.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2140, arg_2143) }; var tmp12 *lang.Keyword = A_arbace_go_check_types_A_const_12; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp11, nil, T_str__8_, nil, tmp12.Invoke_O__O(A_arbace_go_check_types_A_const_211.Invoke_O__O(mm__10)), nil)).Ref() } else {
//line :818:1
										var comparability__10 any; var tmp13 any = A_arbace_go_check_types_satisfies_cause_comparability__219000276_A_New_O_O(Tts__5_, V__0_); var tmp14 *jrt.Class
										var fncls__2170 /*line :818:1*/*jrt.Class = A_arbace_go_check_types_satisfies_cause_comparability__219000276_A_fn_class


										if fncls__2170 == nil { var fncls__2170d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_check_types_satisfies_cause_comparability__219000276_A_fn_class = fncls__2170d; tmp14 = fncls__2170d } else { tmp14 = fncls__2170 }; comparability__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)








										var tmp15 any; var root_2171 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_2172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2171, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2173 lang.IFn
										if linked_2172 == nil { ifn_2173 = lang.IFn_Cast(root_2171) } else { ifn_2173 = nil }; var arg_2174 any; var root_2175 any = A_arbace_go_check_types_A_const_150.GetRawRoot__O(); var linked_2176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2175, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_2177 lang.IFn; if linked_2176 == nil { ifn_2177 = lang.IFn_Cast(root_2175) } else { ifn_2177 = nil }; var arg_2178 any = Tts__5_; if linked_2176 == nil { arg_2174 = ifn_2177.Invoke_O__O(arg_2178) } else { arg_2174 = linked_2176.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_2175, arg_2178) }; if linked_2172 == nil { tmp15 = ifn_2173.Invoke_O__O(arg_2174) } else { tmp15 = linked_2172.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2171, arg_2174) }
//line :830:1
										if jrt.J2g_Truth(tmp15) {
											return lang.IFn_Cast(comparability__10).Invoke__O() } else {
//line :830:1
												if jrt.J2g_Truth(Vts__7_) {

													var tmp16 any; var root_2179 any = A_arbace_go_check_types_A_const_245.GetRawRoot__O(); var linked_2180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2179, A_arbace_go_check_types_terms_subset_QMARK__A_fn_class); var ifn_2181 lang.IFn; if linked_2180 == nil { ifn_2181 = lang.IFn_Cast(root_2179) } else { ifn_2181 = nil }; var arg_2182 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(Vts__7_); var arg_2183 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(Tts__5_); if linked_2180 == nil { tmp16 = ifn_2181.Invoke_O_O__O(arg_2182, arg_2183) } else { tmp16 = linked_2180.(*A_arbace_go_check_types_terms_subset_QMARK__A).Invoke_O_O_O__O(root_2179, arg_2182, arg_2183) }; if jrt.J2g_Truth(tmp16) {
														return lang.IFn_Cast(comparability__10).Invoke__O() } else {
															var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_33, nil); var tmp18 any; var root_2184 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_2185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2184, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2186 lang.IFn; if linked_2185 == nil { ifn_2186 = lang.IFn_Cast(root_2184) } else { ifn_2186 = nil }; var arg_2187 any = V__0_; if linked_2185 == nil { tmp18 = ifn_2186.Invoke_O__O(arg_2187) } else { tmp18 = linked_2185.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2184, arg_2187) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, tmp18, nil, T_str__8_)).Ref() } } else {
//line :830:1
																var tmp19 any; var root_2188 any = A_arbace_go_check_types_A_const_246.GetRawRoot__O(); var linked_2189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2188, A_arbace_go_check_types_terms_includes_QMARK__A_fn_class); var ifn_2190 lang.IFn




																if linked_2189 == nil { ifn_2190 = lang.IFn_Cast(root_2188) } else { ifn_2190 = nil }; var arg_2191 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(Tts__5_); var arg_2192 any = V__0_; if linked_2189 == nil { tmp19 = ifn_2190.Invoke_O_O__O(arg_2191, arg_2192) } else { tmp19 = linked_2189.(*A_arbace_go_check_types_terms_includes_QMARK__A).Invoke_O_O_O__O(root_2188, arg_2191, arg_2192) }
//line :830:1
																if jrt.J2g_Truth(tmp19) {




																	return lang.IFn_Cast(comparability__10).Invoke__O() } else {
//line :830:1
																		if A_arbace_go_check_types_A_const_75 != nil {





																			var tmp20 *jrt.RefArray = jrt.ConstRefArray("[0,8,ns18: does not satisfy ns2: (ns12: missing in ns1:)", []*jrt.Class{jrt.String_class}); var tmp21 any; var root_2193 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_2194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2193, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2195 lang.IFn; if linked_2194 == nil { ifn_2195 = lang.IFn_Cast(root_2193) } else { ifn_2195 = nil }; var arg_2196 any = V__0_; if linked_2194 == nil { tmp21 = ifn_2195.Invoke_O__O(arg_2196) } else { tmp21 = linked_2194.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2193, arg_2196) }; var tmp22 any = tmp21; var tmp23 any; var root_2197 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_2198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2197, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2199 lang.IFn; if linked_2198 == nil { ifn_2199 = lang.IFn_Cast(root_2197) } else { ifn_2199 = nil }; var arg_2200 any = V__0_; if linked_2198 == nil { tmp23 = ifn_2199.Invoke_O__O(arg_2200) } else { tmp23 = linked_2198.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2197, arg_2200) }; var tmp24 any = tmp23; var tmp25 any; var root_2201 any = A_arbace_go_check_types_A_const_181.GetRawRoot__O(); var linked_2202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2201, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_2203 lang.IFn
																			if linked_2202 == nil { ifn_2203 = lang.IFn_Cast(root_2201) } else { ifn_2203 = nil }; var arg_2204 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(Tts__5_); if linked_2202 == nil { tmp25 = ifn_2203.Invoke_O__O(arg_2204) } else { tmp25 = linked_2202.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_2201, arg_2204) }
//line :836:1
																			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, tmp22, nil, T_str__8_, nil, tmp24, nil, tmp25, nil)).Ref() } else {
//line :830:1
																				return nil } } } } } } else {
//line :813:1
																					return nil } } } } } }







func A_arbace_go_check_types_satisfies_cause_comparability__219000276_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_satisfies_cause_comparability__219000276_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_comparability__219000276_A{}; t.Ctor_O_O(p0, p1); return t }
//line :821:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000276_A) Ctor_O_O(c__Tts, c__V any) { t.F_Tts = c__Tts; t.F_V = c__V }
//line :821:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000276_A) Invoke_O__O(self any) any {
	var tmp1 any; var root_2144 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_2145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2144, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2146 lang.IFn
	if linked_2145 == nil { ifn_2146 = lang.IFn_Cast(root_2144) } else { ifn_2146 = nil }; var arg_2147 any; var tmp2 any = A_arbace_go_check_types_A_const_108; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_go_check_types_A_const_109.Invoke_O__O(t.F_Tts)) {
		arg_2147 = A_arbace_go_check_types_A_const_110.Invoke_O__O(t.F_Tts) } else {
			var root_2148 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_2149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2148, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2150 lang.IFn; if linked_2149 == nil { ifn_2150 = lang.IFn_Cast(root_2148) } else { ifn_2150 = nil }; var arg_2151 any; var tmp3 any = A_arbace_go_check_types_satisfies_cause_comparability__219000276_fn__219000278_A_New(); var tmp4 *jrt.Class; var fncls__2157 *jrt.Class = A_arbace_go_check_types_satisfies_cause_comparability__219000276_fn__219000278_A_fn_class; if fncls__2157 == nil { var fncls__2157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_go_check_types_satisfies_cause_comparability__219000276_fn__219000278_A_fn_class = fncls__2157d; tmp4 = fncls__2157d } else { tmp4 = fncls__2157 }; arg_2151 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_2152 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(t.F_Tts); if linked_2149 == nil { arg_2147 = ifn_2150.Invoke_O_O__O(arg_2151, arg_2152) } else { arg_2147 = linked_2149.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2148, arg_2151, arg_2152) } }
//line :823:1
	if linked_2145 == nil { tmp1 = ifn_2146.Invoke_O__O(arg_2147) } else { tmp1 = linked_2145.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2144, arg_2147) }
//line :822:1
	if jrt.J2g_Truth(tmp1) { return nil } else { var tmp5 any; var root_2158 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); var linked_2159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2158, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_2160 lang.IFn




		if linked_2159 == nil { ifn_2160 = lang.IFn_Cast(root_2158) } else { ifn_2160 = nil }; var arg_2161 any = t.F_V; if linked_2159 == nil { tmp5 = ifn_2160.Invoke_O__O(arg_2161) } else { tmp5 = linked_2159.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O__O(root_2158, arg_2161) }
//line :822:1
		if jrt.J2g_Truth(tmp5) { return nil } else { var tmp6 any; var root_2162 any = A_arbace_go_check_types_A_const_244.GetRawRoot__O(); var linked_2163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2162, A_arbace_go_check_types_comparable_QMARK__A_fn_class); var ifn_2164 lang.IFn





			if linked_2163 == nil { ifn_2164 = lang.IFn_Cast(root_2162) } else { ifn_2164 = nil }; var arg_2165 any = t.F_V; if linked_2163 == nil { tmp6 = ifn_2164.Invoke_O__O(arg_2165) } else { tmp6 = linked_2163.(*A_arbace_go_check_types_comparable_QMARK__A).Invoke_O_O__O(root_2162, arg_2165) }
//line :822:1
			if jrt.J2g_Truth(tmp6) { return nil } else { if A_arbace_go_check_types_A_const_75 != nil {






				var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_37); var tmp8 any; var root_2166 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_2167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2166, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2168 lang.IFn; if linked_2167 == nil { ifn_2168 = lang.IFn_Cast(root_2166) } else { ifn_2168 = nil }; var arg_2169 any = t.F_V; if linked_2167 == nil { tmp8 = ifn_2168.Invoke_O__O(arg_2169) } else { tmp8 = linked_2167.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2166, arg_2169) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8, nil)).Ref() } else {
//line :822:1
					return nil
				}
			} } } }
func A_arbace_go_check_types_satisfies_cause_comparability__219000276_fn__219000278_A_New() *A_arbace_go_check_types_satisfies_cause_comparability__219000276_fn__219000278_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_comparability__219000276_fn__219000278_A{}; t.Ctor(); return t }
//line :825:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000276_fn__219000278_A) Ctor() {}
//line :825:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000276_fn__219000278_A) Invoke_O_O__O(self, p__219000277__1 any) any { var vec__219000279__2 any = p__219000277__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000279__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000279__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2153 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); var linked_2154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2153, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_2155 lang.IFn; _ = ___3; if linked_2154 == nil { ifn_2155 = lang.IFn_Cast(root_2153) } else { ifn_2155 = nil }; var arg_2156 any = ty__4; if linked_2154 == nil { return ifn_2155.Invoke_O__O(arg_2156) } else { return linked_2154.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O__O(root_2153, arg_2156) } }



























































type A_arbace_go_check_types_A struct{ jrt.Object }

var A_arbace_go_check_types_A_const_pool *jrt.RefArray

var A_arbace_go_check_types_A_const_0 *lang.Var

var A_arbace_go_check_types_A_const_1 any

var A_arbace_go_check_types_A_const_2 any

var A_arbace_go_check_types_A_const_3 *lang.Var

var A_arbace_go_check_types_A_const_4 any

var A_arbace_go_check_types_A_const_5 *lang.Var

var A_arbace_go_check_types_A_const_6 *lang.Var

var A_arbace_go_check_types_A_const_7 *lang.Var

var A_arbace_go_check_types_A_const_8 *lang.Var

var A_arbace_go_check_types_A_const_9 any

var A_arbace_go_check_types_A_const_10 *lang.Var

var A_arbace_go_check_types_A_const_11 *lang.Keyword

var A_arbace_go_check_types_A_const_12 *lang.Keyword

var A_arbace_go_check_types_A_const_13 *lang.Var

var A_arbace_go_check_types_A_const_14 *lang.Keyword

var A_arbace_go_check_types_A_const_15 any

var A_arbace_go_check_types_A_const_16 *lang.Keyword

var A_arbace_go_check_types_A_const_17 *lang.Keyword

var A_arbace_go_check_types_A_const_18 *lang.Keyword

var A_arbace_go_check_types_A_const_19 *lang.Keyword

var A_arbace_go_check_types_A_const_20 any

var A_arbace_go_check_types_A_const_21 *lang.Keyword

var A_arbace_go_check_types_A_const_22 any

var A_arbace_go_check_types_A_const_23 *lang.Keyword

var A_arbace_go_check_types_A_const_24 any

var A_arbace_go_check_types_A_const_25 *lang.Keyword

var A_arbace_go_check_types_A_const_26 *lang.Keyword

var A_arbace_go_check_types_A_const_27 *lang.Keyword

var A_arbace_go_check_types_A_const_28 *lang.Keyword

var A_arbace_go_check_types_A_const_29 *lang.Keyword

var A_arbace_go_check_types_A_const_30 *lang.Keyword

var A_arbace_go_check_types_A_const_31 *lang.Keyword

var A_arbace_go_check_types_A_const_32 *lang.Keyword

var A_arbace_go_check_types_A_const_33 *lang.Keyword

var A_arbace_go_check_types_A_const_34 *lang.Keyword

var A_arbace_go_check_types_A_const_35 *lang.Keyword

var A_arbace_go_check_types_A_const_36 *lang.Keyword

var A_arbace_go_check_types_A_const_37 *lang.Keyword

var A_arbace_go_check_types_A_const_38 *lang.Keyword

var A_arbace_go_check_types_A_const_39 any

var A_arbace_go_check_types_A_const_40 *lang.Keyword

var A_arbace_go_check_types_A_const_41 *lang.Keyword

var A_arbace_go_check_types_A_const_42 *lang.Keyword

var A_arbace_go_check_types_A_const_43 *lang.Keyword

var A_arbace_go_check_types_A_const_44 any

var A_arbace_go_check_types_A_const_45 *lang.Keyword

var A_arbace_go_check_types_A_const_46 *lang.Keyword

var A_arbace_go_check_types_A_const_47 *lang.Keyword

var A_arbace_go_check_types_A_const_48 *lang.Keyword

var A_arbace_go_check_types_A_const_49 *lang.Keyword

var A_arbace_go_check_types_A_const_50 *lang.Keyword

var A_arbace_go_check_types_A_const_51 *lang.Keyword

var A_arbace_go_check_types_A_const_52 *lang.Var

var A_arbace_go_check_types_A_const_53 *lang.Var

var A_arbace_go_check_types_A_const_54 *lang.Keyword

var A_arbace_go_check_types_A_const_55 *lang.Keyword

var A_arbace_go_check_types_A_const_56 *lang.Var

var A_arbace_go_check_types_A_const_57 *lang.Var

var A_arbace_go_check_types_A_const_58 *lang.Var

var A_arbace_go_check_types_A_const_59 *lang.Var

var A_arbace_go_check_types_A_const_60 *lang.Keyword

var A_arbace_go_check_types_A_const_61 *lang.Var

var A_arbace_go_check_types_A_const_62 *lang.Keyword

var A_arbace_go_check_types_A_const_63 *lang.Var

var A_arbace_go_check_types_A_const_64 *lang.Keyword

var A_arbace_go_check_types_A_const_65 *lang.Var

var A_arbace_go_check_types_A_const_66 *lang.Var

var A_arbace_go_check_types_A_const_67 *lang.Keyword

var A_arbace_go_check_types_A_const_68 *lang.Var

var A_arbace_go_check_types_A_const_69 *lang.Var

var A_arbace_go_check_types_A_const_70 *lang.Keyword

var A_arbace_go_check_types_A_const_71 *lang.Keyword

var A_arbace_go_check_types_A_const_72 *lang.Var

var A_arbace_go_check_types_A_const_73 *lang.Var

var A_arbace_go_check_types_A_const_74 *lang.Var

var A_arbace_go_check_types_A_const_75 *lang.Keyword

var A_arbace_go_check_types_A_const_76 *lang.Var

var A_arbace_go_check_types_A_const_77 *lang.Var

var A_arbace_go_check_types_A_const_78 *lang.Var

var A_arbace_go_check_types_A_const_79 *lang.Var

var A_arbace_go_check_types_A_const_80 *lang.Var

var A_arbace_go_check_types_A_const_81 *lang.Var

var A_arbace_go_check_types_A_const_82 *lang.Var

var A_arbace_go_check_types_A_const_83 *lang.Var

var A_arbace_go_check_types_A_const_84 any

var A_arbace_go_check_types_A_const_85 *lang.Var

var A_arbace_go_check_types_A_const_86 *lang.Keyword

var A_arbace_go_check_types_A_const_87 *lang.Keyword

var A_arbace_go_check_types_A_const_88 *lang.Var

var A_arbace_go_check_types_A_const_89 *lang.Var

var A_arbace_go_check_types_A_const_90 *lang.Var

var A_arbace_go_check_types_A_const_91 *lang.Var

var A_arbace_go_check_types_A_const_92 *lang.Var

var A_arbace_go_check_types_A_const_93 any

var A_arbace_go_check_types_A_const_94 *lang.Var

var A_arbace_go_check_types_A_const_95 *lang.Keyword

var A_arbace_go_check_types_A_const_96 *lang.Keyword

var A_arbace_go_check_types_A_const_97 *lang.Keyword

var A_arbace_go_check_types_A_const_98 *lang.Keyword

var A_arbace_go_check_types_A_const_99 *lang.Var

var A_arbace_go_check_types_A_const_100 *lang.Keyword

var A_arbace_go_check_types_A_const_101 any

var A_arbace_go_check_types_A_const_102 *lang.Var

var A_arbace_go_check_types_A_const_103 *lang.Keyword

var A_arbace_go_check_types_A_const_104 *lang.Var

var A_arbace_go_check_types_A_const_105 *lang.Keyword

var A_arbace_go_check_types_A_const_106 *lang.Keyword

var A_arbace_go_check_types_A_const_107 *lang.Keyword

var A_arbace_go_check_types_A_const_108 *lang.Keyword

var A_arbace_go_check_types_A_const_109 *lang.Keyword

var A_arbace_go_check_types_A_const_110 *lang.Keyword

var A_arbace_go_check_types_A_const_111 *lang.Var

var A_arbace_go_check_types_A_const_112 *lang.Var

var A_arbace_go_check_types_A_const_113 *lang.Var

var A_arbace_go_check_types_A_const_114 *lang.Var

var A_arbace_go_check_types_A_const_115 *lang.Var

var A_arbace_go_check_types_A_const_116 *lang.Var

var A_arbace_go_check_types_A_const_117 *lang.Var

var A_arbace_go_check_types_A_const_118 *lang.Var

var A_arbace_go_check_types_A_const_119 *lang.Var

var A_arbace_go_check_types_A_const_120 *lang.Keyword

var A_arbace_go_check_types_A_const_121 *lang.Var

var A_arbace_go_check_types_A_const_122 *lang.Var

var A_arbace_go_check_types_A_const_123 *lang.Var

var A_arbace_go_check_types_A_const_124 *lang.Var

var A_arbace_go_check_types_A_const_125 *lang.Var

var A_arbace_go_check_types_A_const_126 *lang.Keyword

var A_arbace_go_check_types_A_const_127 *lang.Var

var A_arbace_go_check_types_A_const_128 *lang.Var

var A_arbace_go_check_types_A_const_129 *lang.Var

var A_arbace_go_check_types_A_const_130 *lang.Var

var A_arbace_go_check_types_A_const_131 *lang.Var

var A_arbace_go_check_types_A_const_132 *lang.Var

var A_arbace_go_check_types_A_const_133 *lang.Var

var A_arbace_go_check_types_A_const_134 *lang.Var

var A_arbace_go_check_types_A_const_135 *lang.Var

var A_arbace_go_check_types_A_const_136 *lang.Var

var A_arbace_go_check_types_A_const_137 *lang.Var

var A_arbace_go_check_types_A_const_138 *lang.Var

var A_arbace_go_check_types_A_const_139 *lang.Var

var A_arbace_go_check_types_A_const_140 *lang.Var

var A_arbace_go_check_types_A_const_141 *lang.Var

var A_arbace_go_check_types_A_const_142 *lang.Var

var A_arbace_go_check_types_A_const_143 *lang.Var

var A_arbace_go_check_types_A_const_144 *lang.Var

var A_arbace_go_check_types_A_const_145 *lang.Var

var A_arbace_go_check_types_A_const_146 *lang.Keyword

var A_arbace_go_check_types_A_const_147 *lang.Var

var A_arbace_go_check_types_A_const_148 *lang.Keyword

var A_arbace_go_check_types_A_const_149 *lang.Var

var A_arbace_go_check_types_A_const_150 *lang.Var

var A_arbace_go_check_types_A_const_151 any

var A_arbace_go_check_types_A_const_152 *lang.Var

var A_arbace_go_check_types_A_const_153 *lang.Var

var A_arbace_go_check_types_A_const_154 *lang.Var

var A_arbace_go_check_types_A_const_155 *lang.Var

var A_arbace_go_check_types_A_const_156 *lang.Var

var A_arbace_go_check_types_A_const_157 *lang.Var

var A_arbace_go_check_types_A_const_158 *lang.Var

var A_arbace_go_check_types_A_const_159 any

var A_arbace_go_check_types_A_const_160 *lang.Keyword

var A_arbace_go_check_types_A_const_161 any

var A_arbace_go_check_types_A_const_162 any

var A_arbace_go_check_types_A_const_163 *lang.Var

var A_arbace_go_check_types_A_const_164 *lang.Var

var A_arbace_go_check_types_A_const_165 *lang.Var

var A_arbace_go_check_types_A_const_166 *lang.Var

var A_arbace_go_check_types_A_const_167 *lang.Var

var A_arbace_go_check_types_A_const_168 *lang.Var

var A_arbace_go_check_types_A_const_169 *lang.Keyword

var A_arbace_go_check_types_A_const_170 *lang.Var

var A_arbace_go_check_types_A_const_171 *lang.Keyword

var A_arbace_go_check_types_A_const_172 *lang.Var

var A_arbace_go_check_types_A_const_173 *lang.Keyword

var A_arbace_go_check_types_A_const_174 *lang.Keyword

var A_arbace_go_check_types_A_const_175 *lang.Keyword

var A_arbace_go_check_types_A_const_176 *lang.Var

var A_arbace_go_check_types_A_const_177 *lang.Var

var A_arbace_go_check_types_A_const_178 *lang.Var

var A_arbace_go_check_types_A_const_179 any

var A_arbace_go_check_types_A_const_180 *lang.Var

var A_arbace_go_check_types_A_const_181 *lang.Var

var A_arbace_go_check_types_A_const_182 *lang.Keyword

var A_arbace_go_check_types_A_const_183 *lang.Keyword

var A_arbace_go_check_types_A_const_184 *lang.Var

var A_arbace_go_check_types_A_const_185 any

var A_arbace_go_check_types_A_const_186 *lang.Var

var A_arbace_go_check_types_A_const_187 *lang.Var

var A_arbace_go_check_types_A_const_188 *lang.Var

var A_arbace_go_check_types_A_const_189 any

var A_arbace_go_check_types_A_const_190 *lang.Var

var A_arbace_go_check_types_A_const_191 *lang.Var

var A_arbace_go_check_types_A_const_192 *lang.Var

var A_arbace_go_check_types_A_const_193 *lang.Var

var A_arbace_go_check_types_A_const_194 any

var A_arbace_go_check_types_A_const_195 *lang.Var

var A_arbace_go_check_types_A_const_196 *lang.Var

var A_arbace_go_check_types_A_const_197 *lang.Keyword

var A_arbace_go_check_types_A_const_198 *lang.Var

var A_arbace_go_check_types_A_const_199 *lang.Var

var A_arbace_go_check_types_A_const_200 *lang.Var

var A_arbace_go_check_types_A_const_201 *lang.Var

var A_arbace_go_check_types_A_const_202 *lang.Var

var A_arbace_go_check_types_A_const_203 *lang.Var

var A_arbace_go_check_types_A_const_204 *lang.Keyword

var A_arbace_go_check_types_A_const_205 *lang.Var

var A_arbace_go_check_types_A_const_206 *lang.Var

var A_arbace_go_check_types_A_const_207 *lang.Var

var A_arbace_go_check_types_A_const_208 *lang.Var

var A_arbace_go_check_types_A_const_209 any

var A_arbace_go_check_types_A_const_210 *lang.Keyword

var A_arbace_go_check_types_A_const_211 *lang.Keyword

var A_arbace_go_check_types_A_const_212 *lang.Var

var A_arbace_go_check_types_A_const_213 *lang.Keyword

var A_arbace_go_check_types_A_const_214 *lang.Keyword

var A_arbace_go_check_types_A_const_215 *lang.Keyword

var A_arbace_go_check_types_A_const_216 *lang.Keyword

var A_arbace_go_check_types_A_const_217 any

var A_arbace_go_check_types_A_const_218 *lang.Keyword

var A_arbace_go_check_types_A_const_219 any

var A_arbace_go_check_types_A_const_220 *lang.Keyword

var A_arbace_go_check_types_A_const_221 *lang.Keyword

var A_arbace_go_check_types_A_const_222 *lang.Keyword

var A_arbace_go_check_types_A_const_223 *lang.Var

var A_arbace_go_check_types_A_const_224 *lang.Keyword

var A_arbace_go_check_types_A_const_225 *lang.Var

var A_arbace_go_check_types_A_const_226 *lang.Var

var A_arbace_go_check_types_A_const_227 *lang.Var

var A_arbace_go_check_types_A_const_228 *lang.Keyword

var A_arbace_go_check_types_A_const_229 *lang.Keyword

var A_arbace_go_check_types_A_const_230 *lang.Keyword

var A_arbace_go_check_types_A_const_231 *lang.Keyword

var A_arbace_go_check_types_A_const_232 *lang.Keyword

var A_arbace_go_check_types_A_const_233 *lang.Var

var A_arbace_go_check_types_A_const_234 *lang.Var

var A_arbace_go_check_types_A_const_235 *lang.Keyword

var A_arbace_go_check_types_A_const_236 *lang.Keyword

var A_arbace_go_check_types_A_const_237 *lang.Var

var A_arbace_go_check_types_A_const_238 *lang.Keyword

var A_arbace_go_check_types_A_const_239 *lang.Var

var A_arbace_go_check_types_A_const_240 *lang.Var

var A_arbace_go_check_types_A_const_241 *lang.Var

var A_arbace_go_check_types_A_const_242 *lang.Var

var A_arbace_go_check_types_A_const_243 *lang.Var

var A_arbace_go_check_types_A_const_244 *lang.Var

var A_arbace_go_check_types_A_const_245 *lang.Var

var A_arbace_go_check_types_A_const_246 *lang.Var

var A_arbace_go_check_types_A_init jrt.ClassInit

func A_arbace_go_check_types_A_Init() { if !A_arbace_go_check_types_A_init.Done() { A_arbace_go_check_types_A_init.Run(A_arbace_go_check_types_A_clinit) } }

func A_arbace_go_check_types_A_clinit() { A_arbace_go_check_types_A_clinit_p0(); A_arbace_go_check_types_A_clinit_p1(); A_arbace_go_check_types_A_clinit_p2(); A_arbace_go_check_types_A_clinit_p3(); A_arbace_go_check_types_A_clinit_p4(); A_arbace_go_check_types_A_clinit_p5(); A_arbace_go_check_types_A_clinit_p6(); A_arbace_go_check_types_A_clinit_p7(); A_arbace_go_check_types_A_clinit_p8(); A_arbace_go_check_types_A_clinit_p9(); A_arbace_go_check_types_A_clinit_p10(); A_arbace_go_check_types_A_clinit_p11(); A_arbace_go_check_types_A_clinit_p12(); A_arbace_go_check_types_A_clinit_p13(); A_arbace_go_check_types_A_clinit_p14(); A_arbace_go_check_types_A_clinit_p15(); A_arbace_go_check_types_A_clinit_p16(); A_arbace_go_check_types_A_clinit_p17(); A_arbace_go_check_types_A_clinit_p18(); A_arbace_go_check_types_A_clinit_p19(); A_arbace_go_check_types_A_clinit_p20() }

func A_arbace_go_check_types_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_types_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 344); A_arbace_go_check_types_A_const_0 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[97]); A_arbace_go_check_types_A_const_1 = A_arbace_go_check_types_A_const_pool.A[98]; A_arbace_go_check_types_A_const_2 = A_arbace_go_check_types_A_const_pool.A[99]; A_arbace_go_check_types_A_const_3 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[100]); A_arbace_go_check_types_A_const_4 = A_arbace_go_check_types_A_const_pool.A[101]; A_arbace_go_check_types_A_const_5 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[102]); A_arbace_go_check_types_A_const_6 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[103]); A_arbace_go_check_types_A_const_7 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[104]); A_arbace_go_check_types_A_const_8 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[105]); A_arbace_go_check_types_A_const_9 = A_arbace_go_check_types_A_const_pool.A[106]; A_arbace_go_check_types_A_const_10 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[107]); A_arbace_go_check_types_A_const_11 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[108]) }

func A_arbace_go_check_types_A_clinit_p1() { A_arbace_go_check_types_A_const_12 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[109]); A_arbace_go_check_types_A_const_13 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[110]); A_arbace_go_check_types_A_const_14 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[111]); A_arbace_go_check_types_A_const_15 = A_arbace_go_check_types_A_const_pool.A[112]; A_arbace_go_check_types_A_const_16 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[113]); A_arbace_go_check_types_A_const_17 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[114]); A_arbace_go_check_types_A_const_18 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[115]); A_arbace_go_check_types_A_const_19 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[116]); A_arbace_go_check_types_A_const_20 = A_arbace_go_check_types_A_const_pool.A[117]; A_arbace_go_check_types_A_const_21 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[118]); A_arbace_go_check_types_A_const_22 = A_arbace_go_check_types_A_const_pool.A[119]; A_arbace_go_check_types_A_const_23 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[120]); A_arbace_go_check_types_A_const_24 = A_arbace_go_check_types_A_const_pool.A[121] }

func A_arbace_go_check_types_A_clinit_p2() { A_arbace_go_check_types_A_const_25 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[122]); A_arbace_go_check_types_A_const_26 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[123]); A_arbace_go_check_types_A_const_27 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[124]); A_arbace_go_check_types_A_const_28 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[125]); A_arbace_go_check_types_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[126]); A_arbace_go_check_types_A_const_30 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[127]); A_arbace_go_check_types_A_const_31 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[128]); A_arbace_go_check_types_A_const_32 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[129]); A_arbace_go_check_types_A_const_33 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[130]); A_arbace_go_check_types_A_const_34 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[131]); A_arbace_go_check_types_A_const_35 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[132]); A_arbace_go_check_types_A_const_36 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[133]) }

func A_arbace_go_check_types_A_clinit_p3() { A_arbace_go_check_types_A_const_37 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[134]); A_arbace_go_check_types_A_const_38 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[135]); A_arbace_go_check_types_A_const_39 = A_arbace_go_check_types_A_const_pool.A[136]; A_arbace_go_check_types_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[137]); A_arbace_go_check_types_A_const_41 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[138]); A_arbace_go_check_types_A_const_42 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[139]); A_arbace_go_check_types_A_const_43 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[140]); A_arbace_go_check_types_A_const_44 = A_arbace_go_check_types_A_const_pool.A[141]; A_arbace_go_check_types_A_const_45 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[142]); A_arbace_go_check_types_A_const_46 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[143]); A_arbace_go_check_types_A_const_47 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[144]); A_arbace_go_check_types_A_const_48 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[145]) }

func A_arbace_go_check_types_A_clinit_p4() { A_arbace_go_check_types_A_const_49 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[146]); A_arbace_go_check_types_A_const_50 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[147]); A_arbace_go_check_types_A_const_51 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[148]); A_arbace_go_check_types_A_const_52 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[149]); A_arbace_go_check_types_A_const_53 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[150]); A_arbace_go_check_types_A_const_54 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[151]); A_arbace_go_check_types_A_const_55 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[152]); A_arbace_go_check_types_A_const_56 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[153]); A_arbace_go_check_types_A_const_57 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[154]); A_arbace_go_check_types_A_const_58 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[155]); A_arbace_go_check_types_A_const_59 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[156]); A_arbace_go_check_types_A_const_60 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[157]) }

func A_arbace_go_check_types_A_clinit_p5() { A_arbace_go_check_types_A_const_61 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[158]); A_arbace_go_check_types_A_const_62 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[159]); A_arbace_go_check_types_A_const_63 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[160]); A_arbace_go_check_types_A_const_64 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[161]); A_arbace_go_check_types_A_const_65 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[162]); A_arbace_go_check_types_A_const_66 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[163]); A_arbace_go_check_types_A_const_67 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[164]); A_arbace_go_check_types_A_const_68 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[165]); A_arbace_go_check_types_A_const_69 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[166]); A_arbace_go_check_types_A_const_70 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[167]); A_arbace_go_check_types_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[168]); A_arbace_go_check_types_A_const_72 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[169]) }

func A_arbace_go_check_types_A_clinit_p6() { A_arbace_go_check_types_A_const_73 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[170]); A_arbace_go_check_types_A_const_74 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[171]); A_arbace_go_check_types_A_const_75 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[172]); A_arbace_go_check_types_A_const_76 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[173]); A_arbace_go_check_types_A_const_77 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[174]); A_arbace_go_check_types_A_const_78 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[175]); A_arbace_go_check_types_A_const_79 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[176]); A_arbace_go_check_types_A_const_80 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[177]); A_arbace_go_check_types_A_const_81 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[178]); A_arbace_go_check_types_A_const_82 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[179]); A_arbace_go_check_types_A_const_83 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[180]); A_arbace_go_check_types_A_const_84 = A_arbace_go_check_types_A_const_pool.A[181] }

func A_arbace_go_check_types_A_clinit_p7() { A_arbace_go_check_types_A_const_85 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[182]); A_arbace_go_check_types_A_const_86 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[183]); A_arbace_go_check_types_A_const_87 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[184]); A_arbace_go_check_types_A_const_88 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[185]); A_arbace_go_check_types_A_const_89 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[186]); A_arbace_go_check_types_A_const_90 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[187]); A_arbace_go_check_types_A_const_91 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[188]); A_arbace_go_check_types_A_const_92 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[189]); A_arbace_go_check_types_A_const_93 = A_arbace_go_check_types_A_const_pool.A[190]; A_arbace_go_check_types_A_const_94 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[191]); A_arbace_go_check_types_A_const_95 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[192]); A_arbace_go_check_types_A_const_96 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[193]) }

func A_arbace_go_check_types_A_clinit_p8() { A_arbace_go_check_types_A_const_97 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[194]); A_arbace_go_check_types_A_const_98 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[195]); A_arbace_go_check_types_A_const_99 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[196]); A_arbace_go_check_types_A_const_100 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[197]); A_arbace_go_check_types_A_const_101 = A_arbace_go_check_types_A_const_pool.A[198]; A_arbace_go_check_types_A_const_102 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[199]); A_arbace_go_check_types_A_const_103 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[200]); A_arbace_go_check_types_A_const_104 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[201]); A_arbace_go_check_types_A_const_105 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[202]); A_arbace_go_check_types_A_const_106 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[203]); A_arbace_go_check_types_A_const_107 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[204]); A_arbace_go_check_types_A_const_108 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[205]) }

func A_arbace_go_check_types_A_clinit_p9() { A_arbace_go_check_types_A_const_109 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[206]); A_arbace_go_check_types_A_const_110 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[207]); A_arbace_go_check_types_A_const_111 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[208]); A_arbace_go_check_types_A_const_112 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[209]); A_arbace_go_check_types_A_const_113 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[210]); A_arbace_go_check_types_A_const_114 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[211]); A_arbace_go_check_types_A_const_115 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[212]); A_arbace_go_check_types_A_const_116 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[213]); A_arbace_go_check_types_A_const_117 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[214]); A_arbace_go_check_types_A_const_118 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[215]); A_arbace_go_check_types_A_const_119 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[216]); A_arbace_go_check_types_A_const_120 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[217]) }

func A_arbace_go_check_types_A_clinit_p10() { A_arbace_go_check_types_A_const_121 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[218]); A_arbace_go_check_types_A_const_122 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[219]); A_arbace_go_check_types_A_const_123 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[220]); A_arbace_go_check_types_A_const_124 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[221]); A_arbace_go_check_types_A_const_125 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[222]); A_arbace_go_check_types_A_const_126 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[223]); A_arbace_go_check_types_A_const_127 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[224]); A_arbace_go_check_types_A_const_128 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[225]); A_arbace_go_check_types_A_const_129 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[226]); A_arbace_go_check_types_A_const_130 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[227]); A_arbace_go_check_types_A_const_131 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[228]); A_arbace_go_check_types_A_const_132 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[229]) }

func A_arbace_go_check_types_A_clinit_p11() { A_arbace_go_check_types_A_const_133 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[230]); A_arbace_go_check_types_A_const_134 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[231]); A_arbace_go_check_types_A_const_135 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[232]); A_arbace_go_check_types_A_const_136 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[233]); A_arbace_go_check_types_A_const_137 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[234]); A_arbace_go_check_types_A_const_138 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[235]); A_arbace_go_check_types_A_const_139 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[236]); A_arbace_go_check_types_A_const_140 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[237]); A_arbace_go_check_types_A_const_141 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[238]); A_arbace_go_check_types_A_const_142 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[239]); A_arbace_go_check_types_A_const_143 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[240]); A_arbace_go_check_types_A_const_144 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[241]) }

func A_arbace_go_check_types_A_clinit_p12() { A_arbace_go_check_types_A_const_145 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[242]); A_arbace_go_check_types_A_const_146 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[243]); A_arbace_go_check_types_A_const_147 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[244]); A_arbace_go_check_types_A_const_148 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[245]); A_arbace_go_check_types_A_const_149 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[246]); A_arbace_go_check_types_A_const_150 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[247]); A_arbace_go_check_types_A_const_151 = A_arbace_go_check_types_A_const_pool.A[248]; A_arbace_go_check_types_A_const_152 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[249]); A_arbace_go_check_types_A_const_153 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[250]); A_arbace_go_check_types_A_const_154 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[251]); A_arbace_go_check_types_A_const_155 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[252]); A_arbace_go_check_types_A_const_156 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[253]) }

func A_arbace_go_check_types_A_clinit_p13() { A_arbace_go_check_types_A_const_157 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[254]); A_arbace_go_check_types_A_const_158 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[255]); A_arbace_go_check_types_A_const_159 = A_arbace_go_check_types_A_const_pool.A[256]; A_arbace_go_check_types_A_const_160 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[257]); A_arbace_go_check_types_A_const_161 = A_arbace_go_check_types_A_const_pool.A[258]; A_arbace_go_check_types_A_const_162 = A_arbace_go_check_types_A_const_pool.A[259]; A_arbace_go_check_types_A_const_163 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[260]); A_arbace_go_check_types_A_const_164 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[261]); A_arbace_go_check_types_A_const_165 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[262]); A_arbace_go_check_types_A_const_166 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[263]); A_arbace_go_check_types_A_const_167 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[264]); A_arbace_go_check_types_A_const_168 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[265]) }

func A_arbace_go_check_types_A_clinit_p14() { A_arbace_go_check_types_A_const_169 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[266]); A_arbace_go_check_types_A_const_170 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[267]); A_arbace_go_check_types_A_const_171 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[268]); A_arbace_go_check_types_A_const_172 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[269]); A_arbace_go_check_types_A_const_173 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[270]); A_arbace_go_check_types_A_const_174 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[271]); A_arbace_go_check_types_A_const_175 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[272]); A_arbace_go_check_types_A_const_176 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[273]); A_arbace_go_check_types_A_const_177 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[274]); A_arbace_go_check_types_A_const_178 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[275]); A_arbace_go_check_types_A_const_179 = A_arbace_go_check_types_A_const_pool.A[276]; A_arbace_go_check_types_A_const_180 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[277]) }

func A_arbace_go_check_types_A_clinit_p15() { A_arbace_go_check_types_A_const_181 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[278]); A_arbace_go_check_types_A_const_182 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[279]); A_arbace_go_check_types_A_const_183 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[280]); A_arbace_go_check_types_A_const_184 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[281]); A_arbace_go_check_types_A_const_185 = A_arbace_go_check_types_A_const_pool.A[282]; A_arbace_go_check_types_A_const_186 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[283]); A_arbace_go_check_types_A_const_187 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[284]); A_arbace_go_check_types_A_const_188 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[285]); A_arbace_go_check_types_A_const_189 = A_arbace_go_check_types_A_const_pool.A[286]; A_arbace_go_check_types_A_const_190 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[287]); A_arbace_go_check_types_A_const_191 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[288]); A_arbace_go_check_types_A_const_192 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[289]) }

func A_arbace_go_check_types_A_clinit_p16() { A_arbace_go_check_types_A_const_193 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[290]); A_arbace_go_check_types_A_const_194 = A_arbace_go_check_types_A_const_pool.A[291]; A_arbace_go_check_types_A_const_195 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[292]); A_arbace_go_check_types_A_const_196 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[293]); A_arbace_go_check_types_A_const_197 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[294]); A_arbace_go_check_types_A_const_198 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[295]); A_arbace_go_check_types_A_const_199 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[296]); A_arbace_go_check_types_A_const_200 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[297]); A_arbace_go_check_types_A_const_201 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[298]); A_arbace_go_check_types_A_const_202 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[299]); A_arbace_go_check_types_A_const_203 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[300]); A_arbace_go_check_types_A_const_204 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[301]) }

func A_arbace_go_check_types_A_clinit_p17() { A_arbace_go_check_types_A_const_205 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[302]); A_arbace_go_check_types_A_const_206 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[303]); A_arbace_go_check_types_A_const_207 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[304]); A_arbace_go_check_types_A_const_208 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[305]); A_arbace_go_check_types_A_const_209 = A_arbace_go_check_types_A_const_pool.A[306]; A_arbace_go_check_types_A_const_210 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[307]); A_arbace_go_check_types_A_const_211 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[308]); A_arbace_go_check_types_A_const_212 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[309]); A_arbace_go_check_types_A_const_213 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[310]); A_arbace_go_check_types_A_const_214 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[311]); A_arbace_go_check_types_A_const_215 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[312]); A_arbace_go_check_types_A_const_216 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[313]) }

func A_arbace_go_check_types_A_clinit_p18() { A_arbace_go_check_types_A_const_217 = A_arbace_go_check_types_A_const_pool.A[314]; A_arbace_go_check_types_A_const_218 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[315]); A_arbace_go_check_types_A_const_219 = A_arbace_go_check_types_A_const_pool.A[316]; A_arbace_go_check_types_A_const_220 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[317]); A_arbace_go_check_types_A_const_221 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[318]); A_arbace_go_check_types_A_const_222 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[319]); A_arbace_go_check_types_A_const_223 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[320]); A_arbace_go_check_types_A_const_224 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[321]); A_arbace_go_check_types_A_const_225 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[322]); A_arbace_go_check_types_A_const_226 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[323]); A_arbace_go_check_types_A_const_227 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[324]); A_arbace_go_check_types_A_const_228 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[325]) }

func A_arbace_go_check_types_A_clinit_p19() { A_arbace_go_check_types_A_const_229 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[326]); A_arbace_go_check_types_A_const_230 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[327]); A_arbace_go_check_types_A_const_231 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[328]); A_arbace_go_check_types_A_const_232 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[329]); A_arbace_go_check_types_A_const_233 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[330]); A_arbace_go_check_types_A_const_234 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[331]); A_arbace_go_check_types_A_const_235 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[332]); A_arbace_go_check_types_A_const_236 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[333]); A_arbace_go_check_types_A_const_237 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[334]); A_arbace_go_check_types_A_const_238 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[335]); A_arbace_go_check_types_A_const_239 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[336]); A_arbace_go_check_types_A_const_240 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[337]) }

func A_arbace_go_check_types_A_clinit_p20() { A_arbace_go_check_types_A_const_241 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[338]); A_arbace_go_check_types_A_const_242 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[339]); A_arbace_go_check_types_A_const_243 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[340]); A_arbace_go_check_types_A_const_244 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[341]); A_arbace_go_check_types_A_const_245 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[342]); A_arbace_go_check_types_A_const_246 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[343]) }

func A_arbace_go_check_types_A_New() *A_arbace_go_check_types_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_A) Ctor() {}

func (t *A_arbace_go_check_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_A_class }

func (t *A_arbace_go_check_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_A); return ok }

func A_arbace_go_check_types_A_Cast(x any) *A_arbace_go_check_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_A_class)) }; return v }



type A_arbace_go_check_types_align_up_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_align_up_A_fn_class *jrt.Class



type A_arbace_go_check_types_alignof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alignof_A_fn_class *jrt.Class



type A_arbace_go_check_types_alignof_fn__219000234_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alignof_fn__219000234_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_basic_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_basic_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_basic_fn__219000168_A struct{ j2g_header uint64; F_pred any }

var A_arbace_go_check_types_all_basic_fn__219000168_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_boolean_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_boolean_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_complex_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_complex_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_float_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_float_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_integer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_integer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_or_string_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_or_string_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000181_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000181_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_ordered_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_ordered_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_string_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_string_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_unsigned_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_unsigned_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_basic_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_basic_A_fn_class *jrt.Class



type A_arbace_go_check_types_boolean_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_boolean_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_bound_iface_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_bound_iface_A_fn_class *jrt.Class



type A_arbace_go_check_types_common_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_common_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_comparable_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A struct{ j2g_header uint64; F_seen, F_dynamic any }

var A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A_fn_class *jrt.Class



type A_arbace_go_check_types_complex_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_complex_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_consolidate_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_consolidate_A_fn_class *jrt.Class



type A_arbace_go_check_types_const_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_const_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_core_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_core_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_default_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_default_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_deref_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_deref_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_empty_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_empty_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_eval219000004_A struct{ jrt.Object }

func A_arbace_go_check_types_eval219000004_A_New() *A_arbace_go_check_types_eval219000004_A { t := &A_arbace_go_check_types_eval219000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_eval219000004_A) Ctor() {}

func (t *A_arbace_go_check_types_eval219000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_eval219000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_eval219000004_A_class }

func (t *A_arbace_go_check_types_eval219000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_eval219000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_eval219000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_eval219000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_eval219000004_A); return ok }

func A_arbace_go_check_types_eval219000004_A_Cast(x any) *A_arbace_go_check_types_eval219000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_eval219000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_eval219000004_A_class)) }; return v }



type A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_fn_class *jrt.Class



type A_arbace_go_check_types_eval219000008_A struct{ jrt.Object }

func A_arbace_go_check_types_eval219000008_A_New() *A_arbace_go_check_types_eval219000008_A { t := &A_arbace_go_check_types_eval219000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_eval219000008_A) Ctor() {}

func (t *A_arbace_go_check_types_eval219000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_eval219000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_eval219000008_A_class }

func (t *A_arbace_go_check_types_eval219000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_eval219000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_eval219000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_eval219000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_eval219000008_A); return ok }

func A_arbace_go_check_types_eval219000008_A_Cast(x any) *A_arbace_go_check_types_eval219000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_eval219000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_eval219000008_A_class)) }; return v }



type A_arbace_go_check_types_eval219000008_fn__219000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_eval219000008_fn__219000009_A_fn_class *jrt.Class



type A_arbace_go_check_types_exported_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_exported_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_field_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_field_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_flag_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_flag_A_fn_class *jrt.Class



type A_arbace_go_check_types_float_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_float_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_m__219000013_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class *jrt.Class



type A_arbace_go_check_types_has_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_name_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_has_nil_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_nil_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A_fn_class *jrt.Class



type A_arbace_go_check_types_has_terms_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_terms_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_identical_ignore_tags_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_identical_ignore_tags_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_iface_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_iface_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_iface_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_iface_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_ignore_tags_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ignore_tags_A_fn_class *jrt.Class



type A_arbace_go_check_types_ignore_tags_fn__219000056_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ignore_tags_fn__219000056_A_fn_class *jrt.Class



type A_arbace_go_check_types_incomparable_cause_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_incomparable_cause_A_fn_class *jrt.Class



type A_arbace_go_check_types_incomparable_cause_cause__219000073_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_incomparable_cause_cause__219000073_A_fn_class *jrt.Class



type A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A struct{ j2g_header uint64; F_cause, F_seen any }

var A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A_fn_class *jrt.Class



type A_arbace_go_check_types_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_info_A_fn_class *jrt.Class



type A_arbace_go_check_types_integer_or_float_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_integer_or_float_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_integer_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_integer_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_kind_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_kind_of_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_lookup_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_impl_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_lookup_impl_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_impl_fn__219000257_A struct{ j2g_header uint64; F_pkg, F_name any }

var A_arbace_go_check_types_lookup_impl_fn__219000257_A_fn_class *jrt.Class



type A_arbace_go_check_types_make_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_make_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_method_data_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_method_data_A_fn_class *jrt.Class



type A_arbace_go_check_types_method_set_iface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_method_set_iface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_methods_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_methods_of_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_missing_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_fn__219000271_A struct{ j2g_header uint64; F_static, F_V, F_same_QMARK_, F_vu any }

var A_arbace_go_check_types_missing_method_fn__219000271_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_fn__219000271_fn__219000272_A struct{ j2g_header uint64; F_m, F_V any }

var A_arbace_go_check_types_missing_method_fn__219000271_fn__219000272_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_named_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_new_named_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_new_named_A_fn_class *jrt.Class



type A_arbace_go_check_types_new_tparam_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_new_tparam_A_fn_class *jrt.Class



type A_arbace_go_check_types_next_id_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_next_id_A_fn_class *jrt.Class



type A_arbace_go_check_types_numeric_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_offsetsof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_offsetsof_A_fn_class *jrt.Class



type A_arbace_go_check_types_ordered_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ordered_A_fn_class *jrt.Class



type A_arbace_go_check_types_ordered_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ordered_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_params_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_params_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_params_str_fn__219000208_A struct{ j2g_header uint64; F_ps, F_variadic any }

var A_arbace_go_check_types_params_str_fn__219000208_A_fn_class *jrt.Class



type A_arbace_go_check_types_pointer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_pointer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_same_id_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_same_id_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_satisfies_cause_A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_comparability__219000276_A struct{ j2g_header uint64; F_Tts, F_V any }

var A_arbace_go_check_types_satisfies_cause_comparability__219000276_A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_comparability__219000276_fn__219000278_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_satisfies_cause_comparability__219000276_fn__219000278_A_fn_class *jrt.Class



type A_arbace_go_check_types_sig_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sig_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_sizeof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sizeof_A_fn_class *jrt.Class



type A_arbace_go_check_types_sort_methods_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sort_methods_A_fn_class *jrt.Class



type A_arbace_go_check_types_sort_methods_fn__219000267_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sort_methods_fn__219000267_A_fn_class *jrt.Class



type A_arbace_go_check_types_strictly_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_string_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_string_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_sync_atomic_align64_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_disjoint_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_includes_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_includes_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_intersect_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_intersect_A_fn_class *jrt.Class



type A_arbace_go_check_types_term_subset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_subset_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_union_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_union_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_includes_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_includes_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_includes_QMARK__fn__219000121_A struct{ j2g_header uint64; F_t any }

var A_arbace_go_check_types_terms_includes_QMARK__fn__219000121_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_intersect_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_A struct{ j2g_header uint64; F_y any }

var A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_A struct{ j2g_header uint64; F_iter__219000103, F_s__219000104, F_y any }

var A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_A struct{ j2g_header uint64; F_a any }

var A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_A struct{ j2g_header uint64; F_iter__219000105, F_s__219000106, F_a any }

var A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_fn__219000113_A struct{ j2g_header uint64; F_b__219000108 any; F_size__1927001038__auto__ int32; F_a, F_c__1927001037__auto__ any }

var A_arbace_go_check_types_terms_intersect_iter__219000103__219000109_fn__219000110_iter__219000105__219000111_fn__219000112_fn__219000113_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_norm_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_norm_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_norm_fn__219000098_A struct{ j2g_header uint64; F_i int64; F_n int32; F_used, F_ts any }

var A_arbace_go_check_types_terms_norm_fn__219000098_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000191__219000195_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_str_iter__219000191__219000195_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_A struct{ j2g_header uint64; F_s__219000192, F_iter__219000191 any }

var A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_fn__219000197_A struct{ j2g_header uint64; F_b__219000194 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_terms_str_iter__219000191__219000195_fn__219000196_fn__219000197_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_subset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_subset_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_subset_QMARK__fn__219000129_A struct{ j2g_header uint64; F_yl any }

var A_arbace_go_check_types_terms_subset_QMARK__fn__219000129_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_superset_of_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_superset_of_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000125_A struct{ j2g_header uint64; F_y any }

var A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000125_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_union_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_union_A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_iface_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_iface_A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A struct{ j2g_header uint64; F_seen any }

var A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_empty_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tset_empty_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_type_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000220__219000224_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_type_str_iter__219000220__219000224_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_A struct{ j2g_header uint64; F_iter__219000220, F_s__219000221 any }

var A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_fn__219000226_A struct{ j2g_header uint64; F_b__219000223 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_type_str_iter__219000220__219000224_fn__219000225_fn__219000226_A_fn_class *jrt.Class



type A_arbace_go_check_types_typed_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typed_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_all_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_all_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_all_fn__219000158_A struct{ j2g_header uint64; F_f any }

var A_arbace_go_check_types_typeset_all_fn__219000158_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_pairs_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_A struct{ j2g_header uint64; F_s__219000141, F_iter__219000140 any }

var A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_fn__219000146_A struct{ j2g_header uint64; F_b__219000143 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_typeset_pairs_iter__219000140__219000144_fn__219000145_fn__219000146_A_fn_class *jrt.Class



type A_arbace_go_check_types_uintptr_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_uintptr_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_under_is_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_under_is_A_fn_class *jrt.Class



type A_arbace_go_check_types_under_is_fn__219000164_A struct{ j2g_header uint64; F_f any }

var A_arbace_go_check_types_under_is_fn__219000164_A_fn_class *jrt.Class



type A_arbace_go_check_types_union_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_union_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_unsafe_pointer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_unsafe_pointer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_unsigned_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_unsigned_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_untyped_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_untyped_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_update_info_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_update_info_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_types_valid_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_valid_QMARK__A_fn_class *jrt.Class
