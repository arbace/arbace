//line aot_arbace_go_check_types.ae:1
package aot_arbace_go_check_types

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_const"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_New() *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_types_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_types_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_go_check_types_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_1, A_arbace_go_check_types_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_types_eval219000008_fn__219000009_A_New() *A_arbace_go_check_types_eval219000008_fn__219000009_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_eval219000008_fn__219000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_types_eval219000008_fn__219000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_types_eval219000008_fn__219000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_go_check_types_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_types_A_const_8.GetRawRoot__O(), A_arbace_go_check_types_A_const_9) }






















func A_arbace_go_check_types_fn__219000012_A_New() *A_arbace_go_check_types_fn__219000012_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_A) Invoke_O__O(self any) any { var m__1 any; var tmp1 any = A_arbace_go_check_types_fn__219000012_m__219000013_A_New(); var tmp2 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, true); A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class = fncls__31d; tmp2 = fncls__31d } else { tmp2 = fncls__31 }; m__1 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp1, tmp2, nil, 2); var root_32 any =
										A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_36 any = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_14, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_16), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_17, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_19, A_arbace_go_check_types_A_const_20, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_21, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_23, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_25, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_26, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_28, A_arbace_go_check_types_A_const_20, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_29, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_30, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_31, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_32, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_33, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_34), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_35, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_34), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_36, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_37), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_38, A_arbace_go_check_types_A_const_39, A_arbace_go_check_types_A_const_37), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_40, A_arbace_go_check_types_A_const_39, A_arbace_go_check_types_A_const_41), lang.IFn_Cast(m__1).Invoke_O_O__O(A_arbace_go_check_types_A_const_42, A_arbace_go_check_types_A_const_24), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_43, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_16, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_46, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_47, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_48, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_34, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_49, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_37, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_50, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_41, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_51, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_45))); if linked_33 == nil { return ifn_34.Invoke_O_O__O(arg_35, arg_36) } else { return linked_33.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_32, arg_35, arg_36) } }
//line :24:1
func A_arbace_go_check_types_fn__219000012_m__219000013_A_New() *A_arbace_go_check_types_fn__219000012_m__219000013_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_m__219000013_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_A) DoInvoke_O_O_O_O__O(self, n__1, size__2, flags__3 any) any { var tmp1 any; var root_20 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_11, size__2, A_arbace_go_check_types_A_const_12, n__1)); var arg_24 any; var root_25 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any; var tmp2 any = A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; arg_28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_29 any = flags__3; if linked_26 == nil { arg_24 = ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { arg_24 = linked_26.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) }; if linked_21 == nil { tmp1 = ifn_22.Invoke_O_O__O(arg_23, arg_24) } else { tmp1 = linked_21.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_20, arg_23, arg_24) }; return lang.Tuple_Create_O_O__IPersistentVector(n__1, tmp1) }
//line :24:1
func A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_New() *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A) Invoke_O_O__O(self, f__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(f__1, jrt.Boolean_TRUE.Ref()) }


























func A_arbace_go_check_types_next_id_A_New() *A_arbace_go_check_types_next_id_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_next_id_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_go_check_types_next_id_A) Ctor() {}
//line :51:1
func (t *A_arbace_go_check_types_next_id_A) InvokePrim_O__J(self any) int64 { return jrt.Number_Cast(lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(A_arbace_go_check_types_A_const_52.GetRawRoot__O(), Lit_14, false)).LongValue__J() }
//line :51:1
func (t *A_arbace_go_check_types_next_id_A) Invoke_O__O(self any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O__J(self)).Ref() }

func A_arbace_go_check_types_named_QMARK__A_New() *A_arbace_go_check_types_named_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_QMARK__A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_go_check_types_named_QMARK__A) Ctor() {}
//line :53:1
func (t *A_arbace_go_check_types_named_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_37 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = t__0; if linked_38 == nil { and__1927000168__auto____2 = ifn_39.Invoke_O__O(arg_40) } else { and__1927000168__auto____2 = linked_38.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_37, arg_40) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_54; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_tparam_QMARK__A_New() *A_arbace_go_check_types_tparam_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_QMARK__A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_go_check_types_tparam_QMARK__A) Ctor() {}
//line :54:1
func (t *A_arbace_go_check_types_tparam_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_41 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = t__0; if linked_42 == nil { and__1927000168__auto____2 = ifn_43.Invoke_O__O(arg_44) } else { and__1927000168__auto____2 = linked_42.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_41, arg_44) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_55; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_info_A_New() *A_arbace_go_check_types_info_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_info_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_go_check_types_info_A) Ctor() {}
//line :55:1
func (t *A_arbace_go_check_types_info_A) Invoke_O_O__O(self, t__0 any) any { var root_45 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_46 == nil { return ifn_47.Invoke_O__O(arg_48) } else { return linked_46.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_45, arg_48) } }
func A_arbace_go_check_types_update_info_BANG__A_New() *A_arbace_go_check_types_update_info_BANG__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_update_info_BANG__A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_go_check_types_update_info_BANG__A) Ctor() {}
//line :56:1
func (t *A_arbace_go_check_types_update_info_BANG__A) DoInvoke_O_O_O_O__O(self, t__0, f__1, args__2 any) any { var root_49 any = A_arbace_go_check_types_A_const_56.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var arg_53 any; var root_54 any = A_arbace_go_check_types_A_const_57.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = f__1; var arg_58 any; var root_60 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_61 == nil { arg_58 = ifn_62.Invoke_O__O(arg_63) } else { arg_58 = linked_61.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_60, arg_63) }; var arg_59 any = args__2; if linked_55 == nil { arg_53 = ifn_56.Invoke_O_O_O__O(arg_57, arg_58, arg_59) } else { arg_53 = linked_55.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_54, arg_57, arg_58, arg_59) }; if linked_50 == nil { ifn_51.Invoke_O_O__O(arg_52, arg_53) } else { linked_50.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_49, arg_52, arg_53) }; return t__0 }

func A_arbace_go_check_types_new_named_A_New() *A_arbace_go_check_types_new_named_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_new_named_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_go_check_types_new_named_A) Ctor() {}
//line :58:1
func (t *A_arbace_go_check_types_new_named_A) Invoke_O_O__O(self, data__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_54; var tmp2 any; var root_64 any = A_arbace_go_check_types_A_const_58.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_66 lang.IFn; if


	linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_59.GetRawRoot__O()); var tmp4 any = A_arbace_go_check_types_A_const_60; var tmp5 any; var root_76 any = A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_76, A_arbace_go_check_types_next_id_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; if linked_77 == nil { tmp5 = ifn_78.Invoke__O() } else { tmp5 = jrt.Long_ValueOf_J__Long_NoInit(linked_77.(*A_arbace_go_check_types_next_id_A).InvokePrim_O__J(root_76)).Ref() }; arg_67 = tmp3.Invoke_O_O_O_O_O__O(data__0, tmp4, tmp5, A_arbace_go_check_types_A_const_62, lang.PersistentVector_EMPTY.Ref()); if linked_65 == nil { tmp2 = ifn_66.Invoke_O__O(arg_67) } else { tmp2 = linked_65.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_64, arg_67) }; return /*line :58:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }




func A_arbace_go_check_types_new_tparam_A_New() *A_arbace_go_check_types_new_tparam_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_new_tparam_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_go_check_types_new_tparam_A) Ctor() {}
//line :63:1
func (t *A_arbace_go_check_types_new_tparam_A) Invoke_O_O__O(self, data__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_55; var tmp2 any; var root_79 any = A_arbace_go_check_types_A_const_58.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any; var root_83 any = A_arbace_go_check_types_A_const_59.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = data__0; var arg_87 any = A_arbace_go_check_types_A_const_60; var arg_88 any; var root_89 any = A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_89, A_arbace_go_check_types_next_id_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; if linked_90 == nil { arg_88 = ifn_91.Invoke__O() } else { arg_88 = jrt.Long_ValueOf_J__Long_NoInit(linked_90.(*A_arbace_go_check_types_next_id_A).InvokePrim_O__J(root_89)).Ref() }; if linked_84 == nil { arg_82 = ifn_85.Invoke_O_O_O__O(arg_86, arg_87, arg_88) } else { arg_82 = linked_84.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_83, arg_86, arg_87, arg_88) }; if linked_80 == nil { tmp2 = ifn_81.Invoke_O__O(arg_82) } else { tmp2 = linked_80.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_79, arg_82) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }








func A_arbace_go_check_types_named_under_A_New() *A_arbace_go_check_types_named_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_under_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_go_check_types_named_under_A) Ctor() {}
//line :72:1
func (t *A_arbace_go_check_types_named_under_A) Invoke_O_O__O(self, t__0 any) any { { var t__2 any = t__0; var seen__3 any = lang.PersistentHashSet_EMPTY.Ref(); L1: for { var i__4 any; var root_92 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, A_arbace_go_check_types_info_A_fn_class); var ifn_94 lang.IFn

	if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = t__2; if linked_93 == nil { i__4 = ifn_94.Invoke_O__O(arg_95) } else { i__4 = linked_93.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_92, arg_95) }
//line :72:1
	var temp__1927000408__auto____5 any = A_arbace_go_check_types_A_const_64.Invoke_O__O(i__4)


	if jrt.J2g_Truth(temp__1927000408__auto____5) { var u__6 any = temp__1927000408__auto____5; var tmp1 any; var root_96 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_98 lang.IFn
		if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = u__6; if linked_97 == nil { tmp1 = ifn_98.Invoke_O__O(arg_99) } else { tmp1 = linked_97.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_96, arg_99) }; if jrt.J2g_Truth(tmp1) {

			var tmp2 any; var root_100 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = seen__3; var arg_104 any = u__6; if linked_101 == nil { tmp2 = ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { tmp2 = linked_101.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_100, arg_103, arg_104) }; if jrt.J2g_Truth(tmp2) { return A_arbace_go_check_types_A_const_67 } else {

				var tmp3 any; var root_113 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = seen__3; var arg_117 any = t__2; if linked_114 == nil { tmp3 = ifn_115.Invoke_O_O__O(arg_116, arg_117) } else { tmp3 = linked_114.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_113, arg_116, arg_117) }; t__2, seen__3 = u__6, tmp3; continue L1 } } else {
//line :76:1
					return u__6 } } else {





						var tmp4 any; var and__1927000168__auto____6 any = A_arbace_go_check_types_A_const_68.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_105 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = A_arbace_go_check_types_A_const_70.Invoke_O__O(i__4); if linked_106 == nil { and__1927000168__auto____7 = ifn_107.Invoke_O__O(arg_108) } else { and__1927000168__auto____7 = linked_106.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_105, arg_108) }; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp4 = A_arbace_go_check_types_A_const_71.Invoke_O__O(i__4) } else { tmp4 = and__1927000168__auto____7 } } else { tmp4 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp4) {
							lang.IFn_Cast(A_arbace_go_check_types_A_const_68.Get__O()).Invoke_O__O(t__2)
							var tmp5 *lang.Keyword = A_arbace_go_check_types_A_const_64; var tmp6 any; var root_109 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, A_arbace_go_check_types_info_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = t__2; if linked_110 == nil { tmp6 = ifn_111.Invoke_O__O(arg_112) } else { tmp6 = linked_110.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_109, arg_112) }; if jrt.J2g_Truth(tmp5.Invoke_O__O(tmp6)) { t__2, seen__3 = t__2, seen__3; continue L1 } else { return A_arbace_go_check_types_A_const_67 } } else {
//line :82:1
								return A_arbace_go_check_types_A_const_67 } } } }; /*line :72:1*/panic("j2g: unreachable") }














func A_arbace_go_check_types_under_A_New() *A_arbace_go_check_types_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_go_check_types_under_A) Ctor() {}
//line :87:1
func (t *A_arbace_go_check_types_under_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_118 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_120 lang.IFn
	if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = t__0; if linked_119 == nil { tmp1 = ifn_120.Invoke_O__O(arg_121) } else { tmp1 = linked_119.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_118, arg_121) }
//line :90:1
	if jrt.J2g_Truth(tmp1) { return t__0 } else { var tmp2 any = A_arbace_go_check_types_A_const_54; if lang.Util_Identical_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))) {

		var root_122 any = A_arbace_go_check_types_A_const_73.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, A_arbace_go_check_types_named_under_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = t__0; if linked_123 == nil { return ifn_124.Invoke_O__O(arg_125) } else { return linked_123.(*A_arbace_go_check_types_named_under_A).Invoke_O_O__O(root_122, arg_125) } } else {
//line :90:1
			var tmp3 any = A_arbace_go_check_types_A_const_55; if lang.Util_Identical_O_O__Z_NoInit(tmp3, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))) { var or__1927000174__auto____2 any; var tmp4 *lang.Keyword = A_arbace_go_check_types_A_const_74; var tmp5 any; var root_126 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, A_arbace_go_check_types_info_A_fn_class); var ifn_128 lang.IFn


				if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = t__0; if linked_127 == nil { tmp5 = ifn_128.Invoke_O__O(arg_129) } else { tmp5 = linked_127.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_126, arg_129) }; or__1927000174__auto____2 = tmp4.Invoke_O__O(tmp5); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_76, lang.PersistentVector_EMPTY.Ref(), nil) } } else {
//line :90:1
					if A_arbace_go_check_types_A_const_75 != nil { return t__0 } else { return nil
					}
				}
		}
	}
}


func A_arbace_go_check_types_basic_A_New() *A_arbace_go_check_types_basic_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_basic_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_go_check_types_basic_A) Ctor() {}
//line :98:1
func (t *A_arbace_go_check_types_basic_A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_130 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_go_check_types_under_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = t__0; if linked_131 == nil { u__2 = ifn_132.Invoke_O__O(arg_133) } else { u__2 = linked_131.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_130, arg_133) }; var tmp1 any; var root_134 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = u__2; if linked_135 == nil { tmp1 = ifn_136.Invoke_O__O(arg_137) } else { tmp1 = linked_135.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_134, arg_137) }; if jrt.J2g_Truth(tmp1) { return u__2 } else { return nil } }
func A_arbace_go_check_types_flag_A_New() *A_arbace_go_check_types_flag_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_flag_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_go_check_types_flag_A) Ctor() {}
//line :99:1
func (t *A_arbace_go_check_types_flag_A) Invoke_O_O_O__O(self, t__0, f__1 any) any { var b__3 any; var root_138 any = A_arbace_go_check_types_A_const_78.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, A_arbace_go_check_types_basic_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = t__0; if linked_139 == nil { b__3 = ifn_140.Invoke_O__O(arg_141) } else { b__3 = linked_139.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_138, arg_141) }; var tmp1 any; var and__1927000168__auto____4 any = b__3; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_go_check_types_A_const_79.GetRawRoot__O()).Invoke_O__O(b__3), f__1) } else { tmp1 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }
func A_arbace_go_check_types_integer_type_QMARK__A_New() *A_arbace_go_check_types_integer_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_integer_type_QMARK__A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_go_check_types_integer_type_QMARK__A) Ctor() {}
//line :100:1
func (t *A_arbace_go_check_types_integer_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_142 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, A_arbace_go_check_types_flag_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = t__0; var arg_146 any = A_arbace_go_check_types_A_const_18; if linked_143 == nil { return ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { return linked_143.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_142, arg_145, arg_146) } }
func A_arbace_go_check_types_unsigned_QMARK__A_New() *A_arbace_go_check_types_unsigned_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_unsigned_QMARK__A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_check_types_unsigned_QMARK__A) Ctor() {}
//line :101:1
func (t *A_arbace_go_check_types_unsigned_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_147 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, A_arbace_go_check_types_flag_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = t__0; var arg_151 any = A_arbace_go_check_types_A_const_27; if linked_148 == nil { return ifn_149.Invoke_O_O__O(arg_150, arg_151) } else { return linked_148.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_147, arg_150, arg_151) } }
func A_arbace_go_check_types_float_type_QMARK__A_New() *A_arbace_go_check_types_float_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_float_type_QMARK__A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_go_check_types_float_type_QMARK__A) Ctor() {}
//line :102:1
func (t *A_arbace_go_check_types_float_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_152 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, A_arbace_go_check_types_flag_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = t__0; var arg_156 any = A_arbace_go_check_types_A_const_34; if linked_153 == nil { return ifn_154.Invoke_O_O__O(arg_155, arg_156) } else { return linked_153.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_152, arg_155, arg_156) } }
func A_arbace_go_check_types_complex_type_QMARK__A_New() *A_arbace_go_check_types_complex_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_complex_type_QMARK__A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_go_check_types_complex_type_QMARK__A) Ctor() {}
//line :103:1
func (t *A_arbace_go_check_types_complex_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_157 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, A_arbace_go_check_types_flag_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = t__0; var arg_161 any = A_arbace_go_check_types_A_const_37; if linked_158 == nil { return ifn_159.Invoke_O_O__O(arg_160, arg_161) } else { return linked_158.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_157, arg_160, arg_161) } }
func A_arbace_go_check_types_numeric_QMARK__A_New() *A_arbace_go_check_types_numeric_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_numeric_QMARK__A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_go_check_types_numeric_QMARK__A) Ctor() {}
//line :104:1
func (t *A_arbace_go_check_types_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_162 any = A_arbace_go_check_types_A_const_81.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = t__0; if linked_163 == nil { or__1927000174__auto____2 = ifn_164.Invoke_O__O(arg_165) } else { or__1927000174__auto____2 = linked_163.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_162, arg_165) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_166 any = A_arbace_go_check_types_A_const_82.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = t__0; if linked_167 == nil { or__1927000174__auto____3 = ifn_168.Invoke_O__O(arg_169) } else { or__1927000174__auto____3 = linked_167.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_166, arg_169) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_170 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, A_arbace_go_check_types_complex_type_QMARK__A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = t__0; if linked_171 == nil { return ifn_172.Invoke_O__O(arg_173) } else { return linked_171.(*A_arbace_go_check_types_complex_type_QMARK__A).Invoke_O_O__O(root_170, arg_173) } } } }
func A_arbace_go_check_types_string_type_QMARK__A_New() *A_arbace_go_check_types_string_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_string_type_QMARK__A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_go_check_types_string_type_QMARK__A) Ctor() {}
//line :105:1
func (t *A_arbace_go_check_types_string_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_174 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, A_arbace_go_check_types_flag_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = t__0; var arg_178 any = A_arbace_go_check_types_A_const_41; if linked_175 == nil { return ifn_176.Invoke_O_O__O(arg_177, arg_178) } else { return linked_175.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_174, arg_177, arg_178) } }
func A_arbace_go_check_types_boolean_type_QMARK__A_New() *A_arbace_go_check_types_boolean_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_boolean_type_QMARK__A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_go_check_types_boolean_type_QMARK__A) Ctor() {}
//line :106:1
func (t *A_arbace_go_check_types_boolean_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_179 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, A_arbace_go_check_types_flag_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = t__0; var arg_183 any = A_arbace_go_check_types_A_const_16; if linked_180 == nil { return ifn_181.Invoke_O_O__O(arg_182, arg_183) } else { return linked_180.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_179, arg_182, arg_183) } }
func A_arbace_go_check_types_untyped_QMARK__A_New() *A_arbace_go_check_types_untyped_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_untyped_QMARK__A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_go_check_types_untyped_QMARK__A) Ctor() {}
//line :107:1
func (t *A_arbace_go_check_types_untyped_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_184 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = t__0; if linked_185 == nil { and__1927000168__auto____2 = ifn_186.Invoke_O__O(arg_187) } else { and__1927000168__auto____2 = linked_185.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_184, arg_187) }; if jrt.J2g_Truth(and__1927000168__auto____2) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_go_check_types_A_const_79.GetRawRoot__O()).Invoke_O__O(t__0), A_arbace_go_check_types_A_const_45))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_typed_QMARK__A_New() *A_arbace_go_check_types_typed_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typed_QMARK__A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_go_check_types_typed_QMARK__A) Ctor() {}
//line :108:1
func (t *A_arbace_go_check_types_typed_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_188 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any; var root_192 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, A_arbace_go_check_types_untyped_QMARK__A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = t__0; if linked_193 == nil { arg_191 = ifn_194.Invoke_O__O(arg_195) } else { arg_191 = linked_193.(*A_arbace_go_check_types_untyped_QMARK__A).Invoke_O_O__O(root_192, arg_195) }; if linked_189 == nil { return ifn_190.Invoke_O__O(arg_191) } else { return linked_189.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_188, arg_191) } }
func A_arbace_go_check_types_const_type_QMARK__A_New() *A_arbace_go_check_types_const_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_const_type_QMARK__A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_go_check_types_const_type_QMARK__A) Ctor() {}
//line :109:1
func (t *A_arbace_go_check_types_const_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var b__2 any; var root_196 any = A_arbace_go_check_types_A_const_78.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, A_arbace_go_check_types_basic_A_fn_class); var ifn_198 lang.IFn; if


	linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = t__0; if linked_197 == nil { b__2 = ifn_198.Invoke_O__O(arg_199) } else { b__2 = linked_197.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_196, arg_199) }; var and__1927000168__auto____3 any = b__2; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_200 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = lang.IFn_Cast(A_arbace_go_check_types_A_const_85).Invoke_O__O(b__2); if linked_201 == nil { return ifn_202.Invoke_O__O(arg_203) } else { return linked_201.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_200, arg_203) } } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_ordered_QMARK__A_New() *A_arbace_go_check_types_ordered_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ordered_QMARK__A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_go_check_types_ordered_QMARK__A) Ctor() {}
//line :113:1
func (t *A_arbace_go_check_types_ordered_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_204 any = A_arbace_go_check_types_A_const_81.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = t__0; if linked_205 == nil { or__1927000174__auto____2 = ifn_206.Invoke_O__O(arg_207) } else { or__1927000174__auto____2 = linked_205.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_204, arg_207) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_208 any = A_arbace_go_check_types_A_const_82.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = t__0; if linked_209 == nil { or__1927000174__auto____3 = ifn_210.Invoke_O__O(arg_211) } else { or__1927000174__auto____3 = linked_209.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_208, arg_211) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_212 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, A_arbace_go_check_types_string_type_QMARK__A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = t__0; if linked_213 == nil { return ifn_214.Invoke_O__O(arg_215) } else { return linked_213.(*A_arbace_go_check_types_string_type_QMARK__A).Invoke_O_O__O(root_212, arg_215) } } } }
func A_arbace_go_check_types_interface_QMARK__A_New() *A_arbace_go_check_types_interface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_interface_QMARK__A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_go_check_types_interface_QMARK__A) Ctor() {}
//line :114:1
func (t *A_arbace_go_check_types_interface_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_216 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, A_arbace_go_check_types_under_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = t__0; if linked_217 == nil { u__2 = ifn_218.Invoke_O__O(arg_219) } else { u__2 = linked_217.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_216, arg_219) }; var and__1927000168__auto____3 any; var root_220 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = u__2; if linked_221 == nil { and__1927000168__auto____3 = ifn_222.Invoke_O__O(arg_223) } else { and__1927000168__auto____3 = linked_221.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_220, arg_223) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_76; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_pointer_QMARK__A_New() *A_arbace_go_check_types_pointer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_pointer_QMARK__A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_go_check_types_pointer_QMARK__A) Ctor() {}
//line :115:1
func (t *A_arbace_go_check_types_pointer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_224 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, A_arbace_go_check_types_under_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = t__0; if linked_225 == nil { u__2 = ifn_226.Invoke_O__O(arg_227) } else { u__2 = linked_225.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_224, arg_227) }; var and__1927000168__auto____3 any; var root_228 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = u__2; if linked_229 == nil { and__1927000168__auto____3 = ifn_230.Invoke_O__O(arg_231) } else { and__1927000168__auto____3 = linked_229.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_228, arg_231) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_87; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_unsafe_pointer_QMARK__A_New() *A_arbace_go_check_types_unsafe_pointer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_unsafe_pointer_QMARK__A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_go_check_types_unsafe_pointer_QMARK__A) Ctor() {}
//line :116:1
func (t *A_arbace_go_check_types_unsafe_pointer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_42; var tmp2 any; var root_232 any = A_arbace_go_check_types_A_const_78.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, A_arbace_go_check_types_basic_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = t__0; if linked_233 == nil { tmp2 = ifn_234.Invoke_O__O(arg_235) } else { tmp2 = linked_233.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_232, arg_235) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }
func A_arbace_go_check_types_uintptr_QMARK__A_New() *A_arbace_go_check_types_uintptr_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_uintptr_QMARK__A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_go_check_types_uintptr_QMARK__A) Ctor() {}
//line :117:1
func (t *A_arbace_go_check_types_uintptr_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_32; var tmp2 any; var root_236 any = A_arbace_go_check_types_A_const_78.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, A_arbace_go_check_types_basic_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = t__0; if linked_237 == nil { tmp2 = ifn_238.Invoke_O__O(arg_239) } else { tmp2 = linked_237.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_236, arg_239) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }
func A_arbace_go_check_types_valid_QMARK__A_New() *A_arbace_go_check_types_valid_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_valid_QMARK__A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_go_check_types_valid_QMARK__A) Ctor() {}
//line :118:1
func (t *A_arbace_go_check_types_valid_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_240 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = A_arbace_go_check_types_A_const_67; var arg_244 any = t__0; if linked_241 == nil { return ifn_242.Invoke_O_O__O(arg_243, arg_244) } else { return linked_241.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_240, arg_243, arg_244) } }
func A_arbace_go_check_types_kind_of_A_New() *A_arbace_go_check_types_kind_of_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_kind_of_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_go_check_types_kind_of_A) Ctor() {}
//line :119:1
func (t *A_arbace_go_check_types_kind_of_A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_245 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, A_arbace_go_check_types_under_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = t__0; if linked_246 == nil { u__2 = ifn_247.Invoke_O__O(arg_248) } else { u__2 = linked_246.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_245, arg_248) }; var tmp1 any; var root_249 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = u__2; if linked_250 == nil { tmp1 = ifn_251.Invoke_O__O(arg_252) } else { tmp1 = linked_250.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_249, arg_252) }; if jrt.J2g_Truth(tmp1) { return u__2 } else { return lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)) } }
func A_arbace_go_check_types_has_name_QMARK__A_New() *A_arbace_go_check_types_has_name_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_name_QMARK__A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_go_check_types_has_name_QMARK__A) Ctor() {}
//line :120:1
func (t *A_arbace_go_check_types_has_name_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_253 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = t__0; if linked_254 == nil { or__1927000174__auto____2 = ifn_255.Invoke_O__O(arg_256) } else { or__1927000174__auto____2 = linked_254.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_253, arg_256) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_257 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = t__0; if linked_258 == nil { or__1927000174__auto____3 = ifn_259.Invoke_O__O(arg_260) } else { or__1927000174__auto____3 = linked_258.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_257, arg_260) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_261 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = t__0; if linked_262 == nil { return ifn_263.Invoke_O__O(arg_264) } else { return linked_262.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_261, arg_264) } } } }
func A_arbace_go_check_types_integer_or_float_QMARK__A_New() *A_arbace_go_check_types_integer_or_float_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_integer_or_float_QMARK__A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_go_check_types_integer_or_float_QMARK__A) Ctor() {}
//line :121:1
func (t *A_arbace_go_check_types_integer_or_float_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_265 any = A_arbace_go_check_types_A_const_81.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = t__0; if linked_266 == nil { or__1927000174__auto____2 = ifn_267.Invoke_O__O(arg_268) } else { or__1927000174__auto____2 = linked_266.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_265, arg_268) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_269 any = A_arbace_go_check_types_A_const_82.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = t__0; if linked_270 == nil { return ifn_271.Invoke_O__O(arg_272) } else { return linked_270.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_269, arg_272) } } }

func A_arbace_go_check_types_has_nil_QMARK__A_New() *A_arbace_go_check_types_has_nil_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_nil_QMARK__A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_go_check_types_has_nil_QMARK__A) Ctor() {}
//line :123:1
func (t *A_arbace_go_check_types_has_nil_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_273 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, A_arbace_go_check_types_under_A_fn_class); var ifn_275 lang.IFn; if



	linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = t__0; if linked_274 == nil { u__2 = ifn_275.Invoke_O__O(arg_276) } else { u__2 = linked_274.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_273, arg_276) }; var or__1927000174__auto____3 bool = /*line :123:1*/lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_42, u__2); if or__1927000174__auto____3 {




		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_51, u__2); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var and__1927000168__auto____5 any; var root_277 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_279 lang.IFn
			if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = u__2; if linked_278 == nil { and__1927000168__auto____5 = ifn_279.Invoke_O__O(arg_280) } else { and__1927000168__auto____5 = linked_278.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_277, arg_280) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_281 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = A_arbace_go_check_types_A_const_90; var arg_285 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)); if linked_282 == nil { return ifn_283.Invoke_O_O__O(arg_284, arg_285) } else { return linked_282.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_281, arg_284, arg_285) } } else { return and__1927000168__auto____5 } } } }

func A_arbace_go_check_types_empty_interface_QMARK__A_New() *A_arbace_go_check_types_empty_interface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_empty_interface_QMARK__A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_go_check_types_empty_interface_QMARK__A) Ctor() {}
//line :131:1
func (t *A_arbace_go_check_types_empty_interface_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_286 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, A_arbace_go_check_types_under_A_fn_class); var ifn_288 lang.IFn; if
												linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = t__0; if linked_287 == nil { u__2 = ifn_288.Invoke_O__O(arg_289) } else { u__2 = linked_287.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_286, arg_289) }; var and__1927000168__auto____3 any; var root_290 any = /*line :131:1*/A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_292 lang.IFn; if
												linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = u__2; if linked_291 == nil { and__1927000168__auto____3 = ifn_292.Invoke_O__O(arg_293) } else { and__1927000168__auto____3 = linked_291.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_290, arg_293) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_76; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____4 { var and__1927000168__auto____5 any; var root_294 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_295 == nil { and__1927000168__auto____5 = ifn_296.Invoke_O__O(arg_297) } else { and__1927000168__auto____5 = linked_295.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_294, arg_297) }; if jrt.J2g_Truth(and__1927000168__auto____5) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref() } else { return and__1927000168__auto____5 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_default_type_A_New() *A_arbace_go_check_types_default_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_default_type_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_go_check_types_default_type_A) Ctor() {}
//line :134:1
func (t *A_arbace_go_check_types_default_type_A) Invoke_O_O__O(self, t__0 any) any { var G__219000050__2_ any = t__0; switch


	lang.Util_Hash_O__I_NoInit(G__219000050__2_) >> 19 & 7 { case 0: if any(G__219000050__2_) == any(A_arbace_go_check_types_A_const_49) { return A_arbace_go_check_types_A_const_38 }; case 1: if any(G__219000050__2_) == any(A_arbace_go_check_types_A_const_43) { return A_arbace_go_check_types_A_const_14 }; case 3: if any(G__219000050__2_) == any(A_arbace_go_check_types_A_const_48) { return A_arbace_go_check_types_A_const_35 }; case 5: if any(G__219000050__2_) == any(A_arbace_go_check_types_A_const_46) { return A_arbace_go_check_types_A_const_25 }; case 6: if any(G__219000050__2_) == any(A_arbace_go_check_types_A_const_50) { return A_arbace_go_check_types_A_const_40 }; case 7: if any(G__219000050__2_) == any(A_arbace_go_check_types_A_const_47) { return A_arbace_go_check_types_A_const_21 }; default:}; return t__0 }




func A_arbace_go_check_types_ignore_tags_A_New() *A_arbace_go_check_types_ignore_tags_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ignore_tags_A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_go_check_types_ignore_tags_A) Ctor() {}
//line :142:1
func (t *A_arbace_go_check_types_ignore_tags_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_299 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = t__0; if linked_300 == nil { and__1927000168__auto____2 = ifn_301.Invoke_O__O(arg_302) } else { and__1927000168__auto____2 = linked_300.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_299, arg_302) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_303 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any; var root_307 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any = t__0; if linked_308 == nil { arg_306 = ifn_309.Invoke_O__O(arg_310) } else { arg_306 = linked_308.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_307, arg_310) }; if linked_304 == nil { and__1927000168__auto____3 = ifn_305.Invoke_O__O(arg_306) } else { and__1927000168__auto____3 = linked_304.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_303, arg_306) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_311 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any; var root_315 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = t__0; if linked_316 == nil { arg_314 = ifn_317.Invoke_O__O(arg_318) } else { arg_314 = linked_316.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_315, arg_318) }; if linked_312 == nil { tmp1 = ifn_313.Invoke_O__O(arg_314) } else { tmp1 = linked_312.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_311, arg_314) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var G__219000053__2_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))
		switch lang.Util_Hash_O__I_NoInit(G__219000053__2_) >> 2 & 15 { case 1: if any(G__219000053__2_) == any(A_arbace_go_check_types_A_const_92) { var tmp2 any = A_arbace_go_check_types_A_const_92; var tmp3 any; var root_320 any = A_arbace_go_check_types_A_const_96.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_322 lang.IFn




			if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_321 == nil { tmp3 = ifn_322.Invoke_O__O(arg_323) } else { tmp3 = linked_321.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_320, arg_323) }
//line :146:1
			var tmp4 any = tmp3; var tmp5 any; var root_324 any = A_arbace_go_check_types_A_const_96.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_326 lang.IFn




			if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_325 == nil { tmp5 = ifn_326.Invoke_O__O(arg_327) } else { tmp5 = linked_325.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_324, arg_327) }
//line :146:1
			return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp4, tmp5) }; case 2: if any(G__219000053__2_) == any(A_arbace_go_check_types_A_const_93) { var tmp6 any = A_arbace_go_check_types_A_const_93; var tmp7 any; var root_328 any = A_arbace_go_check_types_A_const_96.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_330 lang.IFn


				if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_329 == nil { tmp7 = ifn_330.Invoke_O__O(arg_331) } else { tmp7 = linked_329.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_328, arg_331) }
//line :146:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7) }; case 3: if any(G__219000053__2_) == any(A_arbace_go_check_types_A_const_94) { var tmp8 any = A_arbace_go_check_types_A_const_94; var tmp9 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp10 any; var root_332 any = A_arbace_go_check_types_A_const_96.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_334 lang.IFn



					if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_333 == nil { tmp10 = ifn_334.Invoke_O__O(arg_335) } else { tmp10 = linked_333.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_332, arg_335) }
//line :146:1
					return lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp9, tmp10) }; case 6: if any(G__219000053__2_) == any(A_arbace_go_check_types_A_const_95) { var tmp11 any = A_arbace_go_check_types_A_const_95; var tmp12 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp13 any; var root_350 any = A_arbace_go_check_types_A_const_96.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_352 lang.IFn





						if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_351 == nil { tmp13 = ifn_352.Invoke_O__O(arg_353) } else { tmp13 = linked_351.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_350, arg_353) }
//line :146:1
						return lang.Tuple_Create_O_O_O__IPersistentVector(tmp11, tmp12, tmp13) }; case 7: if any(G__219000053__2_) == any(A_arbace_go_check_types_A_const_97) {







							var root_336 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = A_arbace_go_check_types_A_const_98; var arg_340 any; var root_341 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = A_arbace_go_check_types_A_const_96.GetRawRoot__O(); var arg_345 any; var root_346 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = t__0; if linked_347 == nil { arg_345 = ifn_348.Invoke_O__O(arg_349) } else { arg_345 = linked_347.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_346, arg_349) }; if linked_342 == nil { arg_340 = ifn_343.Invoke_O_O__O(arg_344, arg_345) } else { arg_340 = linked_342.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_341, arg_344, arg_345) }; if linked_337 == nil { return ifn_338.Invoke_O_O__O(arg_339, arg_340) } else { return linked_337.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_336, arg_339, arg_340) } }
//line :146:1
		case 9: if any(G__219000053__2_) == any(A_arbace_go_check_types_A_const_100) { var tmp14 any = A_arbace_go_check_types_A_const_100; var tmp15 any; var root_354 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_356 lang.IFn






			if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = A_arbace_go_check_types_A_const_96.GetRawRoot__O(); var arg_358 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_355 == nil { tmp15 = ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { tmp15 = linked_355.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) }
//line :146:1
			var tmp16 any = tmp15; var tmp17 any; var root_359 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_361 lang.IFn






			if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = A_arbace_go_check_types_A_const_96.GetRawRoot__O(); var arg_363 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_360 == nil { tmp17 = ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { tmp17 = linked_360.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_359, arg_362, arg_363) }
//line :146:1
			return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp14, tmp16, tmp17, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(3))) }; case 11: if any(G__219000053__2_) == any(A_arbace_go_check_types_A_const_87) { var tmp18 any = A_arbace_go_check_types_A_const_87; var tmp19 any; var root_364 any = A_arbace_go_check_types_A_const_96.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_366 lang.IFn

				if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_365 == nil { tmp19 = ifn_366.Invoke_O__O(arg_367) } else { tmp19 = linked_365.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_364, arg_367) }
//line :146:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp18, tmp19) }; case 13: if any(G__219000053__2_) == any(A_arbace_go_check_types_A_const_102) { var tmp20 any = A_arbace_go_check_types_A_const_102; var tmp21 any; var root_368 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_370 lang.IFn
					if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any; var tmp22 any = A_arbace_go_check_types_ignore_tags_fn__219000054_A_New(); var tmp23 *jrt.Class; var fncls__385 *jrt.Class = A_arbace_go_check_types_ignore_tags_fn__219000054_A_fn_class; if fncls__385 == nil { var fncls__385d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_go_check_types_ignore_tags_fn__219000054_A_fn_class = fncls__385d; tmp23 = fncls__385d } else { tmp23 = fncls__385 }; arg_371 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_372 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_369 == nil { tmp21 = ifn_370.Invoke_O_O__O(arg_371, arg_372) } else { tmp21 = linked_369.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_368, arg_371, arg_372) }
//line :146:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp20, tmp21) }; default:}; return t__0 } else {
//line :145:1
						return t__0
					} }
func A_arbace_go_check_types_ignore_tags_fn__219000054_A_New() *A_arbace_go_check_types_ignore_tags_fn__219000054_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ignore_tags_fn__219000054_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_go_check_types_ignore_tags_fn__219000054_A) Ctor() {}
//line :147:1
func (t *A_arbace_go_check_types_ignore_tags_fn__219000054_A) Invoke_O_O__O(self, p1__219000052_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_59.GetRawRoot__O()); var tmp2 any = A_arbace_go_check_types_A_const_103; var tmp3 any = A_arbace_go_check_types_A_const_104; var tmp4 any; var root_381 any = A_arbace_go_check_types_A_const_96.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = A_arbace_go_check_types_A_const_104.Invoke_O__O(p1__219000052_SHARP___1); if linked_382 == nil { tmp4 = ifn_383.Invoke_O__O(arg_384) } else { tmp4 = linked_382.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_381, arg_384) }; return tmp1.Invoke_O_O_O_O_O__O(p1__219000052_SHARP___1, tmp2, nil, tmp3, tmp4) }










func A_arbace_go_check_types_identical_ignore_tags_QMARK__A_New() *A_arbace_go_check_types_identical_ignore_tags_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_identical_ignore_tags_QMARK__A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_go_check_types_identical_ignore_tags_QMARK__A) Ctor() {}
//line :158:1
func (t *A_arbace_go_check_types_identical_ignore_tags_QMARK__A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 any; var root_386 any = A_arbace_go_check_types_A_const_96.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = x__0; if linked_387 == nil { tmp1 = ifn_388.Invoke_O__O(arg_389) } else { tmp1 = linked_387.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_386, arg_389) }; var tmp2 any = tmp1; var tmp3 any; var root_390 any = A_arbace_go_check_types_A_const_96.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = y__1; if linked_391 == nil { tmp3 = ifn_392.Invoke_O__O(arg_393) } else { tmp3 = linked_391.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_390, arg_393) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() }



func A_arbace_go_check_types_comparable_QMARK__A_New() *A_arbace_go_check_types_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_QMARK__A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Ctor() {}
//line :162:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Invoke_O_O_O__O(self, t__0, seen__1 any) any {



	var tmp1 any; var root_394 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = seen__1; var arg_398 any = t__0; if linked_395 == nil { tmp1 = ifn_396.Invoke_O_O__O(arg_397, arg_398) } else { tmp1 = linked_395.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_394, arg_397, arg_398) }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var u__3 any; var root_399 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, A_arbace_go_check_types_under_A_fn_class); var ifn_401 lang.IFn

		if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = t__0; if linked_400 == nil { u__3 = ifn_401.Invoke_O__O(arg_402) } else { u__3 = linked_400.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_399, arg_402) }
//line :166:1
		var seen__4 any; var root_403 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_405 lang.IFn

		if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = seen__1; var arg_407 any = t__0; if linked_404 == nil { seen__4 = ifn_405.Invoke_O_O__O(arg_406, arg_407) } else { seen__4 = linked_404.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_403, arg_406, arg_407) }
		var tmp2 any; var root_408 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_410 lang.IFn
		if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = u__3; if linked_409 == nil { tmp2 = ifn_410.Invoke_O__O(arg_411) } else { tmp2 = linked_409.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_408, arg_411) }
//line :169:1
		if jrt.J2g_Truth(tmp2) {
			var root_412 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = u__3; var arg_416 any = A_arbace_go_check_types_A_const_51; if linked_413 == nil { return ifn_414.Invoke_O_O__O(arg_415, arg_416) } else { return linked_413.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_412, arg_415, arg_416) } } else {
//line :169:1
				if A_arbace_go_check_types_A_const_75 != nil { var G__219000059__5_ any = lang.RT_Nth_O_I__O_NoInit(u__3, lang.RT_IntCast_J__I_NoInit(0))


					switch lang.Util_Hash_O__I_NoInit(G__219000059__5_) >> 4 & 7 { case 0: if any(G__219000059__5_) == any(A_arbace_go_check_types_A_const_94) {


						var root_418 any = A_arbace_go_check_types_A_const_105.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, A_arbace_go_check_types_comparable_QMARK__A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = lang.RT_Nth_O_I__O_NoInit(u__3, lang.RT_IntCast_J__I_NoInit(2)); var arg_422 any = seen__4; if linked_419 == nil { return ifn_420.Invoke_O_O__O(arg_421, arg_422) } else { return linked_419.(*A_arbace_go_check_types_comparable_QMARK__A).Invoke_O_O_O__O(root_418, arg_421, arg_422) } }
//line :172:1
					case 1: if any(G__219000059__5_) == any(A_arbace_go_check_types_A_const_95) { return jrt.Boolean_TRUE.Ref() }; case 3: if any(G__219000059__5_) == any(A_arbace_go_check_types_A_const_76) { return jrt.Boolean_TRUE.Ref() }; case 6: if any(G__219000059__5_) == any(A_arbace_go_check_types_A_const_87) { return jrt.Boolean_TRUE.Ref() }; case 7: if any(G__219000059__5_) == any(A_arbace_go_check_types_A_const_102) {

						var root_423 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any; var tmp3 any = A_arbace_go_check_types_comparable_QMARK__fn__219000060_A_New_O(seen__4); var tmp4 *jrt.Class; var fncls__433 *jrt.Class = A_arbace_go_check_types_comparable_QMARK__fn__219000060_A_fn_class; if fncls__433 == nil { var fncls__433d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_check_types_comparable_QMARK__fn__219000060_A_fn_class = fncls__433d; tmp4 = fncls__433d } else { tmp4 = fncls__433 }; arg_426 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_427 any = lang.RT_Nth_O_I__O_NoInit(u__3, lang.RT_IntCast_J__I_NoInit(1)); if linked_424 == nil { return ifn_425.Invoke_O_O__O(arg_426, arg_427) } else { return linked_424.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_423, arg_426, arg_427) } }
//line :172:1
					default:}; return jrt.Boolean_FALSE.Ref() } else {
//line :169:1
						return nil } } } }
//line :162:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Invoke_O_O__O(self, t__0 any) any {

	var root_434 any = A_arbace_go_check_types_A_const_105.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, A_arbace_go_check_types_comparable_QMARK__A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = t__0; var arg_438 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_435 == nil { return ifn_436.Invoke_O_O__O(arg_437, arg_438) } else { return linked_435.(*A_arbace_go_check_types_comparable_QMARK__A).Invoke_O_O_O__O(root_434, arg_437, arg_438)
	}
}







func A_arbace_go_check_types_comparable_QMARK__fn__219000060_A_New_O(p0 any) *A_arbace_go_check_types_comparable_QMARK__fn__219000060_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_QMARK__fn__219000060_A{}; t.Ctor_O(p0); return t }
//line :174:1
func (t *A_arbace_go_check_types_comparable_QMARK__fn__219000060_A) Ctor_O(c__seen any) { t.F_seen = c__seen }
//line :174:1
func (t *A_arbace_go_check_types_comparable_QMARK__fn__219000060_A) Invoke_O_O__O(self, p1__219000058_SHARP___1 any) any { var root_428 any = A_arbace_go_check_types_A_const_105.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, A_arbace_go_check_types_comparable_QMARK__A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = A_arbace_go_check_types_A_const_104.Invoke_O__O(p1__219000058_SHARP___1); var arg_432 any = t.F_seen; if linked_429 == nil { return ifn_430.Invoke_O_O__O(arg_431, arg_432) } else { return linked_429.(*A_arbace_go_check_types_comparable_QMARK__A).Invoke_O_O_O__O(root_428, arg_431, arg_432) } }












func A_arbace_go_check_types_params_str_A_New() *A_arbace_go_check_types_params_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_params_str_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_go_check_types_params_str_A) Ctor() {}
//line :187:1
func (t *A_arbace_go_check_types_params_str_A) Invoke_O_O_O__O(self, ps__0, variadic__1 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16); var tmp2 any; var root_439 any = A_arbace_go_check_types_A_const_107.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_441 lang.IFn
	if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = Lit_17; var arg_443 any; var root_444 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any; var tmp3 any = A_arbace_go_check_types_params_str_fn__219000063_A_New_O_O(ps__0, variadic__1); var tmp4 *jrt.Class; var fncls__457 *jrt.Class = A_arbace_go_check_types_params_str_fn__219000063_A_fn_class; if fncls__457 == nil { var fncls__457d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_go_check_types_params_str_fn__219000063_A_fn_class = fncls__457d; tmp4 = fncls__457d } else { tmp4 = fncls__457 }; arg_447 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_448 any = ps__0; if linked_445 == nil { arg_443 = ifn_446.Invoke_O_O__O(arg_447, arg_448) } else { arg_443 = linked_445.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_444, arg_447, arg_448) }; if linked_440 == nil { tmp2 = ifn_441.Invoke_O_O__O(arg_442, arg_443) } else { tmp2 = linked_440.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_439, arg_442, arg_443) }
//line :188:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil)).Ref() }
func A_arbace_go_check_types_params_str_fn__219000063_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_params_str_fn__219000063_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_params_str_fn__219000063_A{}; t.Ctor_O_O(p0, p1); return t }
//line :189:1
func (t *A_arbace_go_check_types_params_str_fn__219000063_A) Ctor_O_O(c__ps, c__variadic any) { t.F_ps = c__ps; t.F_variadic = c__variadic }
//line :189:1
func (t *A_arbace_go_check_types_params_str_fn__219000063_A) Invoke_O_O_O__O(self, i__1, p__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = t.F_variadic; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_J__Z_NoInit(i__1, lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_ps))))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_19, nil); var tmp3 any; var root_449 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, A_arbace_go_check_types_type_str_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = lang.RT_Nth_O_I__O_NoInit(p__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_450 == nil { tmp3 = ifn_451.Invoke_O__O(arg_452) } else { tmp3 = linked_450.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_449, arg_452) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else {
			var root_453 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, A_arbace_go_check_types_type_str_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = p__2; if linked_454 == nil { return ifn_455.Invoke_O__O(arg_456) } else { return linked_454.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_453, arg_456)
			}
		}
}
func A_arbace_go_check_types_sig_str_A_New() *A_arbace_go_check_types_sig_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sig_str_A{}; t.Ctor(); return t }
//line :196:1
func (t *A_arbace_go_check_types_sig_str_A) Ctor() {}
//line :196:1
func (t *A_arbace_go_check_types_sig_str_A) Invoke_O_O__O(self, p__219000066__0 any) any { var vec__219000067__2 any = p__219000066__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000067__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000067__2, lang.RT_IntCast_J__I_NoInit(1), nil); var rs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000067__2, lang.RT_IntCast_J__I_NoInit(2), nil); var variadic__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000067__2, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_458 any = A_arbace_go_check_types_A_const_110.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, A_arbace_go_check_types_params_str_A_fn_class); var ifn_460 lang.IFn; _ = ___3; if


	linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = ps__4; var arg_462 any = variadic__6; if linked_459 == nil { tmp2 = ifn_460.Invoke_O_O__O(arg_461, arg_462) } else { tmp2 = linked_459.(*A_arbace_go_check_types_params_str_A).Invoke_O_O_O__O(root_458, arg_461, arg_462) }; var tmp3 any = tmp2; var tmp4 *jrt.String; var G__219000070__9_ int32 = lang.RT_Count_O__I_NoInit(rs__5); L1:
	switch { default: switch G__219000070__9_ { case 0: tmp4 = Lit_3; break L1; case 1: var r__10 any; var root_464 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_466 lang.IFn

		if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = rs__5; if linked_465 == nil { r__10 = ifn_466.Invoke_O__O(arg_467) } else { r__10 = linked_465.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_464, arg_467) }; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_4, nil); var tmp6 any; var root_468 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, A_arbace_go_check_types_type_str_A_fn_class); var ifn_470 lang.IFn; if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = r__10; if linked_469 == nil { tmp6 = ifn_470.Invoke_O__O(arg_471) } else { tmp6 = linked_469.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_468, arg_471) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6))
//line :200:1
		break L1; default:
	}

		var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_20, nil, Lit_16); var tmp8 any; var root_472 any = A_arbace_go_check_types_A_const_107.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = Lit_17; var arg_476 any; var root_477 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_477, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_479 lang.IFn; if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var arg_481 any = rs__5; if linked_478 == nil { arg_476 = ifn_479.Invoke_O_O__O(arg_480, arg_481) } else { arg_476 = linked_478.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_477, arg_480, arg_481) }; if linked_473 == nil { tmp8 = ifn_474.Invoke_O_O__O(arg_475, arg_476) } else { tmp8 = linked_473.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_472, arg_475, arg_476) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil))}; return /*line :199:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4.Ref())).Ref() }





func A_arbace_go_check_types_field_str_A_New() *A_arbace_go_check_types_field_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_field_str_A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_go_check_types_field_str_A) Ctor() {}
//line :205:1
func (t *A_arbace_go_check_types_field_str_A) Invoke_O_O__O(self, f__0 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 *jrt.String; if jrt.J2g_Truth(A_arbace_go_check_types_A_const_112.Invoke_O__O(f__0)) { tmp2 = Lit_3 } else { tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_4), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_12.Invoke_O__O(f__0), nil)) }; var tmp3 any = tmp2.Ref(); var tmp4 any; var root_482 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, A_arbace_go_check_types_type_str_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = A_arbace_go_check_types_A_const_104.Invoke_O__O(f__0); if linked_483 == nil { tmp4 = ifn_484.Invoke_O__O(arg_485) } else { tmp4 = linked_483.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_482, arg_485) }; var tmp5 any = tmp4; var tmp6 *jrt.String
	if jrt.J2g_Truth(A_arbace_go_check_types_A_const_103.Invoke_O__O(f__0)) { var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_4, nil); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_113.GetRawRoot__O()); var tmp9 any; var root_490 any = A_arbace_go_check_types_A_const_114.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = A_arbace_go_check_types_A_const_103.Invoke_O__O(f__0); if linked_491 == nil { tmp9 = ifn_492.Invoke_O__O(arg_493) } else { tmp9 = linked_491.(*aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A).Invoke_O_O__O(root_490, arg_493) }; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8.Invoke_O__O(tmp9))) } else { tmp6 = nil }
//line :206:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp5, tmp6.Ref())).Ref()
}

func A_arbace_go_check_types_named_str_A_New() *A_arbace_go_check_types_named_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_str_A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_go_check_types_named_str_A) Ctor() {}
//line :209:1
func (t *A_arbace_go_check_types_named_str_A) Invoke_O_O__O(self, t__0 any) any { var i__2 any; var root_494 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, A_arbace_go_check_types_info_A_fn_class); var ifn_496 lang.IFn; if
										linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = t__0; if linked_495 == nil { i__2 = ifn_496.Invoke_O__O(arg_497) } else { i__2 = linked_495.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_494, arg_497) }; var base__3 any; var tmp1 any; var and__1927000168__auto____3 any = /*line :209:1*/A_arbace_go_check_types_A_const_115.Invoke_O__O(i__2); if

	jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_498 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = A_arbace_go_check_types_A_const_115.Invoke_O__O(i__2); var arg_502 any = A_arbace_go_check_types_A_const_116.Get__O(); if linked_499 == nil { and__1927000168__auto____4 = ifn_500.Invoke_O_O__O(arg_501, arg_502) } else { and__1927000168__auto____4 = linked_499.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_498, arg_501, arg_502) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_503 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = A_arbace_go_check_types_A_const_117.Invoke_O__O(i__2); if linked_504 == nil { tmp1 = ifn_505.Invoke_O__O(arg_506) } else { tmp1 = linked_504.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_503, arg_506) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		base__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_118.Invoke_O__O(i__2), nil, A_arbace_go_check_types_A_const_12.Invoke_O__O(i__2))).Ref() } else {
			base__3 = A_arbace_go_check_types_A_const_12.Invoke_O__O(i__2) }; var tmp2 any; var root_507 any =
	A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = A_arbace_go_check_types_A_const_120.Invoke_O__O(i__2); if linked_508 == nil { tmp2 = ifn_509.Invoke_O__O(arg_510) } else { tmp2 = linked_508.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_507, arg_510) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_11, nil, Lit_12); var tmp4 any; var root_511 any = A_arbace_go_check_types_A_const_107.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = Lit_13; var arg_515 any; var root_516 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var arg_520 any = A_arbace_go_check_types_A_const_120.Invoke_O__O(i__2); if linked_517 == nil { arg_515 = ifn_518.Invoke_O_O__O(arg_519, arg_520) } else { arg_515 = linked_517.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_516, arg_519, arg_520) }; if linked_512 == nil { tmp4 = ifn_513.Invoke_O_O__O(arg_514, arg_515) } else { tmp4 = linked_512.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_511, arg_514, arg_515) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, base__3, nil, tmp4, nil)).Ref() } else {
//line :214:1
			return base__3 } }



func A_arbace_go_check_types_type_str_A_New() *A_arbace_go_check_types_type_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_go_check_types_type_str_A) Ctor() {}
//line :218:1
func (t *A_arbace_go_check_types_type_str_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_521 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_523 lang.IFn
	if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = t__0; if linked_522 == nil { tmp1 = ifn_523.Invoke_O__O(arg_524) } else { tmp1 = linked_522.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_521, arg_524) }
//line :221:1
	if jrt.J2g_Truth(tmp1) {
		var tmp2 any = A_arbace_go_check_types_A_const_121.GetRawRoot__O(); var tmp3 any; var root_525 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = t__0; if linked_526 == nil { tmp3 = ifn_527.Invoke_O__O(arg_528) } else { tmp3 = linked_526.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_525, arg_528) }; return lang.RT_Get_O_O_O__O_NoInit(tmp2, t__0, tmp3) } else {
//line :221:1
			var tmp4 any; var root_529 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_531 lang.IFn

			if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = t__0; if linked_530 == nil { tmp4 = ifn_531.Invoke_O__O(arg_532) } else { tmp4 = linked_530.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_529, arg_532) }
//line :221:1
			if jrt.J2g_Truth(tmp4) {

				var root_533 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, A_arbace_go_check_types_named_str_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = t__0; if linked_534 == nil { return ifn_535.Invoke_O__O(arg_536) } else { return linked_534.(*A_arbace_go_check_types_named_str_A).Invoke_O_O__O(root_533, arg_536) } } else {
//line :221:1
					var tmp5 any; var root_537 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_539 lang.IFn


					if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = t__0; if linked_538 == nil { tmp5 = ifn_539.Invoke_O__O(arg_540) } else { tmp5 = linked_538.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_537, arg_540) }
//line :221:1
					if jrt.J2g_Truth(tmp5) {


						var tmp6 *lang.Keyword = A_arbace_go_check_types_A_const_12; var tmp7 any; var root_541 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, A_arbace_go_check_types_info_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = t__0; if linked_542 == nil { tmp7 = ifn_543.Invoke_O__O(arg_544) } else { tmp7 = linked_542.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_541, arg_544) }; return tmp6.Invoke_O__O(tmp7) } else {
//line :221:1
							if A_arbace_go_check_types_A_const_75 != nil { var G__219000074__2_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))




								switch lang.Util_Hash_O__I_NoInit(G__219000074__2_) >> 15 & 15 { case 0: if any(G__219000074__2_) == any(A_arbace_go_check_types_A_const_92) {



									var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_23, nil, Lit_12, nil); var tmp9 any; var root_546 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, A_arbace_go_check_types_type_str_A_fn_class); var ifn_548 lang.IFn; if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_547 == nil { tmp9 = ifn_548.Invoke_O__O(arg_549) } else { tmp9 = linked_547.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_546, arg_549) }; var tmp10 any = tmp9; var tmp11 any; var root_550 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, A_arbace_go_check_types_type_str_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_551 == nil { tmp11 = ifn_552.Invoke_O__O(arg_553) } else { tmp11 = linked_551.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_550, arg_553) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, nil, tmp11)).Ref() }
//line :226:1
								case 1: if any(G__219000074__2_) == any(A_arbace_go_check_types_A_const_95) { var e__3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var es__4 any; var root_554 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, A_arbace_go_check_types_type_str_A_fn_class); var ifn_556 lang.IFn





									if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any = e__3; if linked_555 == nil { es__4 = ifn_556.Invoke_O__O(arg_557) } else { es__4 = linked_555.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_554, arg_557) }
//line :226:1
									var es__5 any; var tmp12 any; var tmp13 any = A_arbace_go_check_types_A_const_124; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp13, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)))






									if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_558 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_560 lang.IFn; if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = e__3; if linked_559 == nil { and__1927000168__auto____6 = ifn_560.Invoke_O__O(arg_561) } else { and__1927000168__auto____6 = linked_559.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_558, arg_561) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp14 any = A_arbace_go_check_types_A_const_95; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp14, lang.RT_Nth_O_I__O_NoInit(e__3, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____7 { var tmp15 any = A_arbace_go_check_types_A_const_125; tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp15, lang.RT_Nth_O_I__O_NoInit(e__3, lang.RT_IntCast_J__I_NoInit(1)))).Ref() } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp12 = and__1927000168__auto____6 } } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }; if jrt.J2g_Truth(tmp12) {
										es__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16), jrt.RefArrayOf(jrt.Object_class, nil, es__4, nil)).Ref() } else {
//line :233:1
											es__5 = es__4 }
//line :226:1
									var G__219000075__6_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1))








									switch lang.Util_Hash_O__I_NoInit(G__219000075__6_) >> 7 & 3 { case 0: if any(G__219000075__6_) == any(A_arbace_go_check_types_A_const_125) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; case 2: if any(G__219000075__6_) == any(A_arbace_go_check_types_A_const_124) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; case 3: if any(G__219000075__6_) == any(A_arbace_go_check_types_A_const_126) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_27, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__219000075__6_))))) }
//line :226:1
								case 2: if any(G__219000074__2_) == any(A_arbace_go_check_types_A_const_87) {
									var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_28, nil); var tmp17 any; var root_563 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, A_arbace_go_check_types_type_str_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_564 == nil { tmp17 = ifn_565.Invoke_O__O(arg_566) } else { tmp17 = linked_564.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_563, arg_566) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, nil, tmp17)).Ref() }
//line :226:1
								case 3: if any(G__219000074__2_) == any(A_arbace_go_check_types_A_const_102) {










									var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_29, nil, Lit_30); var tmp19 any; var root_567 any = A_arbace_go_check_types_A_const_107.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = Lit_31; var arg_571 any; var root_572 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = A_arbace_go_check_types_A_const_127.GetRawRoot__O(); var arg_576 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_573 == nil { arg_571 = ifn_574.Invoke_O_O__O(arg_575, arg_576) } else { arg_571 = linked_573.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_572, arg_575, arg_576) }; if linked_568 == nil { tmp19 = ifn_569.Invoke_O_O__O(arg_570, arg_571) } else { tmp19 = linked_568.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_567, arg_570, arg_571) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, tmp19, nil)).Ref() }
//line :226:1
								case 5: if any(G__219000074__2_) == any(A_arbace_go_check_types_A_const_94) {


									var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_12, nil); var tmp21 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp22 any; var root_581 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, A_arbace_go_check_types_type_str_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_582 == nil { tmp22 = ifn_583.Invoke_O__O(arg_584) } else { tmp22 = linked_582.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_581, arg_584) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, tmp21, nil, tmp22)).Ref() }
//line :226:1
								case 7: if any(G__219000074__2_) == any(A_arbace_go_check_types_A_const_100) {









									var tmp23 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_32, nil); var tmp24 any; var root_585 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = t__0; if linked_586 == nil { tmp24 = ifn_587.Invoke_O__O(arg_588) } else { tmp24 = linked_586.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_585, arg_588) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp23, jrt.RefArrayOf(jrt.Object_class, nil, tmp24)).Ref() }
//line :226:1
								case 9: if any(G__219000074__2_) == any(A_arbace_go_check_types_A_const_76) { var ms__3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp25 any; var and__1927000168__auto____4 any; var root_589 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_591 lang.IFn












									if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = ms__3; if linked_590 == nil { and__1927000168__auto____4 = ifn_591.Invoke_O__O(arg_592) } else { and__1927000168__auto____4 = linked_590.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_589, arg_592) }; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp25 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref() } else { tmp25 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp25) { return Lit_33 } else {

										var tmp26 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_34, nil, Lit_30); var tmp27 any; var root_593 any = A_arbace_go_check_types_A_const_107.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = Lit_31; var arg_597 any; var iter__1927001039__auto____7 any; var tmp28 any = A_arbace_go_check_types_type_str_iter__219000076__219000080_A_New(); var tmp29 *jrt.Class; var fncls__664 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000076__219000080_A_fn_class; if fncls__664 == nil { var fncls__664d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_check_types_type_str_iter__219000076__219000080_A_fn_class = fncls__664d; tmp29 = fncls__664d } else { tmp29 = fncls__664 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); arg_597 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(ms__3); if linked_594 == nil { tmp27 = ifn_595.Invoke_O_O__O(arg_596, arg_597) } else { tmp27 = linked_594.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_593, arg_596, arg_597) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp26, jrt.RefArrayOf(jrt.Object_class, nil, tmp27, nil)).Ref() } }
//line :226:1
								case 11: if any(G__219000074__2_) == any(A_arbace_go_check_types_A_const_97) {















									var tmp30 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16); var tmp31 any; var root_665 any = A_arbace_go_check_types_A_const_107.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = Lit_17; var arg_669 any; var root_670 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var arg_674 any; var root_675 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = t__0; if linked_676 == nil { arg_674 = ifn_677.Invoke_O__O(arg_678) } else { arg_674 = linked_676.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_675, arg_678) }; if linked_671 == nil { arg_669 = ifn_672.Invoke_O_O__O(arg_673, arg_674) } else { arg_669 = linked_671.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_670, arg_673, arg_674) }; if linked_666 == nil { tmp31 = ifn_667.Invoke_O_O__O(arg_668, arg_669) } else { tmp31 = linked_666.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_665, arg_668, arg_669) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp30, jrt.RefArrayOf(jrt.Object_class, nil, tmp31, nil)).Ref() }
//line :226:1
								case 14: if any(G__219000074__2_) == any(A_arbace_go_check_types_A_const_93) {

									var tmp32 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil); var tmp33 any; var root_679 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, A_arbace_go_check_types_type_str_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_680 == nil { tmp33 = ifn_681.Invoke_O__O(arg_682) } else { tmp33 = linked_680.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_679, arg_682) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp32, jrt.RefArrayOf(jrt.Object_class, nil, tmp33)).Ref() }
//line :226:1
								default:
								}















								return lang.IFn_Cast(A_arbace_go_check_types_A_const_113.GetRawRoot__O()).Invoke_O__O(t__0) } else {
//line :221:1
									return nil
								}
						}
				}
		}
}














func A_arbace_go_check_types_type_str_iter__219000076__219000080_A_New() *A_arbace_go_check_types_type_str_iter__219000076__219000080_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000076__219000080_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_go_check_types_type_str_iter__219000076__219000080_A) Ctor() {}
//line :241:1
func (t *A_arbace_go_check_types_type_str_iter__219000076__219000080_A) Invoke_O_O__O(self, s__219000077__1 any) any { var tmp1 any = A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_A_New_O_O(self, s__219000077__1); var tmp2 *jrt.Class; var fncls__663 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_A_fn_class; if fncls__663 == nil { var fncls__663d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_A_fn_class = fncls__663d; tmp2 = fncls__663d } else { tmp2 = fncls__663 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :241:1
func A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :241:1
func (t *A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_A) Ctor_O_O(c__iter__219000076, c__s__219000077 any) { t.F_iter__219000076 = c__iter__219000076; t.F_s__219000077 = c__s__219000077 }
//line :241:1
func (t *A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_A) Invoke_O__O(self any) any { { var s__219000077__1 any; var t_ any = t.F_s__219000077; t.F_s__219000077 = nil; s__219000077__1 = t_; for { var temp__1927000414__auto____2 any; var root_598 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = s__219000077__1; if linked_599 == nil { temp__1927000414__auto____2 = ifn_600.Invoke_O__O(arg_601) } else { temp__1927000414__auto____2 = linked_599.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_598, arg_601) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000077__3 any = temp__1927000414__auto____2; var tmp1 any; var root_602 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = s__219000077__3; if linked_603 == nil { tmp1 = ifn_604.Invoke_O__O(arg_605) } else { tmp1 = linked_603.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_602, arg_605) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_606 any = A_arbace_go_check_types_A_const_130.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = s__219000077__3; if linked_607 == nil { c__1927001037__auto____4 = ifn_608.Invoke_O__O(arg_609) } else { c__1927001037__auto____4 = linked_607.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_606, arg_609) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000079__6 any; var root_610 any = A_arbace_go_check_types_A_const_131.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_611 == nil { b__219000079__6 = ifn_612.Invoke_O__O(arg_613) } else { b__219000079__6 = linked_611.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_610, arg_613) }; var tmp2 any = A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_fn__219000082_A_New_O_I_O(b__219000079__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__623 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_fn__219000082_A_fn_class; if fncls__623 == nil { var fncls__623d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_fn__219000082_A_fn_class = fncls__623d; tmp3 = fncls__623d } else { tmp3 = fncls__623 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_624 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any; var root_629 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = b__219000079__6; if linked_630 == nil { arg_627 = ifn_631.Invoke_O__O(arg_632) } else { arg_627 = linked_630.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_629, arg_632) }; var arg_628 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000076); var tmp5 any; var root_633 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = s__219000077__3; if linked_634 == nil { tmp5 = ifn_635.Invoke_O__O(arg_636) } else { tmp5 = linked_634.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_633, arg_636) }; arg_628 = tmp4.Invoke_O__O(tmp5); if linked_625 == nil { return ifn_626.Invoke_O_O__O(arg_627, arg_628) } else { return linked_625.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_624, arg_627, arg_628) } } else { var root_637 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any; var root_642 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = b__219000079__6; if linked_643 == nil { arg_640 = ifn_644.Invoke_O__O(arg_645) } else { arg_640 = linked_643.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_642, arg_645) }; var arg_641 any; if linked_638 == nil { return ifn_639.Invoke_O_O__O(arg_640, arg_641) } else { return linked_638.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_637, arg_640, arg_641) } } } else { var m__4 any; var root_646 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = s__219000077__3; if linked_647 == nil { m__4 = ifn_648.Invoke_O__O(arg_649) } else { m__4 = linked_647.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_646, arg_649) }; var root_650 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__4); var tmp8 any; var root_655 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = A_arbace_go_check_types_A_const_104.Invoke_O__O(m__4); if linked_656 == nil { tmp8 = ifn_657.Invoke_O__O(arg_658) } else { tmp8 = linked_656.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_655, arg_658) }; arg_653 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8)).Ref(); var arg_654 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__219000076); var tmp10 any; var root_659 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = s__219000077__3; if linked_660 == nil { tmp10 = ifn_661.Invoke_O__O(arg_662) } else { tmp10 = linked_660.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_659, arg_662) }; arg_654 = tmp9.Invoke_O__O(tmp10); if linked_651 == nil { return ifn_652.Invoke_O_O__O(arg_653, arg_654) } else { return linked_651.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_650, arg_653, arg_654) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :241:1
func A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_fn__219000082_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_fn__219000082_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_fn__219000082_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :241:1
func (t *A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_fn__219000082_A) Ctor_O_I_O(c__b__219000079 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000079 = c__b__219000079; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :241:1
func (t *A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_fn__219000082_A) Invoke_O__O(self any) any { { var i__219000078__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000078__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000078__1)); var root_614 any = A_arbace_go_check_types_A_const_132.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = t.F_b__219000079; var arg_618 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__2); var tmp4 any; var root_619 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = A_arbace_go_check_types_A_const_104.Invoke_O__O(m__2); if linked_620 == nil { tmp4 = ifn_621.Invoke_O__O(arg_622) } else { tmp4 = linked_620.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_619, arg_622) }; arg_618 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref(); if linked_615 == nil { ifn_616.Invoke_O_O__O(arg_617, arg_618) } else { linked_615.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_614, arg_617, arg_618) }; i__219000078__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000078__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_go_check_types_align_up_A_New() *A_arbace_go_check_types_align_up_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_align_up_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_go_check_types_align_up_A) Ctor() {}
//line :252:1
func (t *A_arbace_go_check_types_align_up_A) InvokePrim_O_J_J__J(self any, x__0, a__1 int64) int64 { return lang.Numbers_Multiply_J_J__J_NoInit(a__1, lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(x__0, lang.Numbers_Dec_J__J_NoInit(a__1)), a__1)) }
//line :252:1
func (t *A_arbace_go_check_types_align_up_A) Invoke_O_O_O__O(self, p_x__0, p_a__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_J__J(self, lang.RT_LongCast_O__J_NoInit(p_x__0), lang.RT_LongCast_O__J_NoInit(p_a__1))).Ref() }

func A_arbace_go_check_types_sync_atomic_align64_QMARK__A_New() *A_arbace_go_check_types_sync_atomic_align64_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sync_atomic_align64_QMARK__A{}; t.Ctor(); return t }
//line :254:1
func (t *A_arbace_go_check_types_sync_atomic_align64_QMARK__A) Ctor() {}
//line :254:1
func (t *A_arbace_go_check_types_sync_atomic_align64_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_683 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_685 lang.IFn; if



	linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = t__0; if linked_684 == nil { and__1927000168__auto____2 = ifn_685.Invoke_O__O(arg_686) } else { and__1927000168__auto____2 = linked_684.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_683, arg_686) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var i__3 any; var root_687 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, A_arbace_go_check_types_info_A_fn_class); var ifn_689 lang.IFn
		if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = t__0; if linked_688 == nil { i__3 = ifn_689.Invoke_O__O(arg_690) } else { i__3 = linked_688.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_687, arg_690) }
//line :258:1
		var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_22, A_arbace_go_check_types_A_const_12.Invoke_O__O(i__3))

		if and__1927000168__auto____4 {
			var root_691 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = A_arbace_go_check_types_A_const_137; var arg_695 any = A_arbace_go_check_types_A_const_115.Invoke_O__O(i__3); if linked_692 == nil { return ifn_693.Invoke_O_O__O(arg_694, arg_695) } else { return linked_692.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_691, arg_694, arg_695) } } else {
//line :260:1
				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else {
//line :258:1
					return and__1927000168__auto____2 } }




func A_arbace_go_check_types_alignof_A_New() *A_arbace_go_check_types_alignof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alignof_A{}; t.Ctor(); return t }
//line :263:1
func (t *A_arbace_go_check_types_alignof_A) Ctor() {}
//line :263:1
func (t *A_arbace_go_check_types_alignof_A) InvokePrim_O_O__J(self, t__0 any) int64 { var tmp1 any; var u__2 any; var root_696 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, A_arbace_go_check_types_under_A_fn_class); var ifn_698 lang.IFn; if
											linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = t__0; if linked_697 == nil { u__2 = ifn_698.Invoke_O__O(arg_699) } else { u__2 = linked_697.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_696, arg_699) }; var tmp2 any; var and__1927000168__auto____3 any; var root_700 any =
											A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_702 lang.IFn; if
											linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = u__2; if linked_701 == nil { and__1927000168__auto____3 = ifn_702.Invoke_O__O(arg_703) } else { and__1927000168__auto____3 = linked_701.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_700, arg_703) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_go_check_types_A_const_94; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp2 = and__1927000168__auto____3 }; if /*line :265:1*/ jrt.J2g_Truth(tmp2) {
												var root_704 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_704, A_arbace_go_check_types_alignof_A_fn_class); var ifn_706 lang.IFn; if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)); if linked_705 == nil { tmp1 = ifn_706.Invoke_O__O(arg_707) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_705.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_704, arg_707)).Ref() } } else {
//line :265:1
			var tmp4 any; var and__1927000168__auto____3_2 any; var root_708 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_708, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_710 lang.IFn

			if linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any = u__2; if linked_709 == nil { and__1927000168__auto____3_2 = ifn_710.Invoke_O__O(arg_711) } else { and__1927000168__auto____3_2 = linked_709.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_708, arg_711) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) { var tmp5 any = A_arbace_go_check_types_A_const_102; tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp5, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp4 = and__1927000168__auto____3_2 }
//line :265:1
			if jrt.J2g_Truth(tmp4) {


				var tmp6 any; var and__1927000168__auto____3_3 any; var root_712 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_713 == nil { and__1927000168__auto____3_3 = ifn_714.Invoke_O__O(arg_715) } else { and__1927000168__auto____3_3 = linked_713.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_712, arg_715) }; if jrt.J2g_Truth(and__1927000168__auto____3_3) { var root_716 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = t__0; if linked_717 == nil { tmp6 = ifn_718.Invoke_O__O(arg_719) } else { tmp6 = linked_717.(*A_arbace_go_check_types_sync_atomic_align64_QMARK__A).Invoke_O_O__O(root_716, arg_719) } } else { tmp6 = and__1927000168__auto____3_3 }; if jrt.J2g_Truth(tmp6) { tmp1 = A_arbace_go_check_types_A_const_24 } else {

					var root_720 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any; var tmp7 any = A_arbace_go_check_types_alignof_fn__219000089_A_New(); var tmp8 *jrt.Class; var fncls__730 *jrt.Class = A_arbace_go_check_types_alignof_fn__219000089_A_fn_class; if fncls__730 == nil { var fncls__730d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_go_check_types_alignof_fn__219000089_A_fn_class = fncls__730d; tmp8 = fncls__730d } else { tmp8 = fncls__730 }; arg_723 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_724 any = A_arbace_go_check_types_A_const_15; var arg_725 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_721 == nil { tmp1 = ifn_722.Invoke_O_O_O__O(arg_723, arg_724, arg_725) } else { tmp1 = linked_721.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_720, arg_723, arg_724, arg_725) } } } else {
//line :265:1
						var tmp9 any; var and__1927000168__auto____3_4 any; var root_731 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_731, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_733 lang.IFn





						if linked_732 == nil { ifn_733 = lang.IFn_Cast(root_731) } else { ifn_733 = nil }; var arg_734 any = u__2; if linked_732 == nil { and__1927000168__auto____3_4 = ifn_733.Invoke_O__O(arg_734) } else { and__1927000168__auto____3_4 = linked_732.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_731, arg_734) }; if jrt.J2g_Truth(and__1927000168__auto____3_4) { var root_735 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_737 lang.IFn; if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = A_arbace_go_check_types_A_const_141; var arg_739 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)); if linked_736 == nil { tmp9 = ifn_737.Invoke_O_O__O(arg_738, arg_739) } else { tmp9 = linked_736.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_735, arg_738, arg_739) } } else { tmp9 = and__1927000168__auto____3_4 }
//line :265:1
						if jrt.J2g_Truth(tmp9) { tmp1 = A_arbace_go_check_types_A_const_142.GetRawRoot__O() } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_40, u__2) { tmp1 = A_arbace_go_check_types_A_const_142.GetRawRoot__O() } else { if A_arbace_go_check_types_A_const_75 != nil { var a__3 any; var root_740 any = A_arbace_go_check_types_A_const_143.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_740, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_742 lang.IFn








							if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any = t__0; if linked_741 == nil { a__3 = ifn_742.Invoke_O__O(arg_743) } else { a__3 = jrt.Long_ValueOf_J__Long_NoInit(linked_741.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_740, arg_743)).Ref() }
//line :265:1
							var a__4 any; var tmp10 bool
							var na_744 any = a__3
							var na_745 int64 = 1







							if jrt.Long_InstanceOf(na_744) { var n0_746 int64 = jrt.NN(jrt.Long_Cast(na_744)).LongValue__J(); var n1_747 int64 = na_745; tmp10 = n0_746 < n1_747 } else { tmp10 = lang.Numbers_Lt_O_J__Z_NoInit(na_744, na_745) }; if tmp10 { a__4 = A_arbace_go_check_types_A_const_15 } else { a__4 = a__3 }
//line :265:1
							var a__5 any; var tmp11 any; var root_749 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, A_arbace_go_check_types_complex_type_QMARK__A_fn_class); var ifn_751 lang.IFn










							if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = t__0; if linked_750 == nil { tmp11 = ifn_751.Invoke_O__O(arg_752) } else { tmp11 = linked_750.(*A_arbace_go_check_types_complex_type_QMARK__A).Invoke_O_O__O(root_749, arg_752) }; if jrt.J2g_Truth(tmp11) { var na_753 any = a__4; var na_754 int64 = 2; if jrt.Long_InstanceOf(na_753) { var n0_755 int64 = jrt.NN(jrt.Long_Cast(na_753)).LongValue__J(); var n1_756 int64 = na_754; if n1_756 == 0 { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_753, na_754) } else { a__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_755 / n1_756).Ref() } } else { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_753, na_754) } } else { a__5 = a__4 }
							tmp1 = lang.Numbers_Min_O_O__O_NoInit(a__5, A_arbace_go_check_types_A_const_144.GetRawRoot__O()) } else {
//line :265:1
								tmp1 = nil } } } } }; return /*line :263:1*/ jrt.Number_Cast(tmp1).LongValue__J() }
//line :263:1
func (t *A_arbace_go_check_types_alignof_A) Invoke_O_O__O(self, t__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, t__0)).Ref() }






func A_arbace_go_check_types_alignof_fn__219000089_A_New() *A_arbace_go_check_types_alignof_fn__219000089_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alignof_fn__219000089_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_go_check_types_alignof_fn__219000089_A) Ctor() {}
//line :270:1
func (t *A_arbace_go_check_types_alignof_fn__219000089_A) Invoke_O_O_O__O(self, m__1, f__2 any) any { var tmp1 int64; var root_726 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_726, A_arbace_go_check_types_alignof_A_fn_class); var ifn_728 lang.IFn; if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = A_arbace_go_check_types_A_const_104.Invoke_O__O(f__2); if linked_727 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_728.Invoke_O__O(arg_729)) } else { tmp1 = linked_727.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_726, arg_729) }; return lang.Numbers_Max_O_J__O_NoInit(m__1, tmp1) }








func A_arbace_go_check_types_offsetsof_A_New() *A_arbace_go_check_types_offsetsof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_offsetsof_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_go_check_types_offsetsof_A) Ctor() {}
//line :279:1
func (t *A_arbace_go_check_types_offsetsof_A) Invoke_O_O__O(self, fields__0 any) any { { var fs__2 any = fields__0; var offs__3 any = lang.RT_Box_J__Number_NoInit(0); var acc__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for {

	var tmp1 any; var root_758 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_758, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_760 lang.IFn; if linked_759 == nil { ifn_760 = lang.IFn_Cast(root_758) } else { ifn_760 = nil }; var arg_761 any = fs__2; if linked_759 == nil { tmp1 = ifn_760.Invoke_O__O(arg_761) } else { tmp1 = linked_759.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_758, arg_761) }; if jrt.J2g_Truth(tmp1) { return acc__4 } else { var f__5 any; var root_762 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_764 lang.IFn

		if linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = fs__2; if linked_763 == nil { f__5 = ifn_764.Invoke_O__O(arg_765) } else { f__5 = linked_763.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_762, arg_765) }
//line :281:1
		var o__6 any; var root_766 any = A_arbace_go_check_types_A_const_145.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_766, A_arbace_go_check_types_align_up_A_fn_class); var ifn_768 lang.IFn


		if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = offs__3; var arg_770 any; var root_771 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_771, A_arbace_go_check_types_alignof_A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = A_arbace_go_check_types_A_const_104.Invoke_O__O(f__5); if linked_772 == nil { arg_770 = ifn_773.Invoke_O__O(arg_774) } else { arg_770 = jrt.Long_ValueOf_J__Long_NoInit(linked_772.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_771, arg_774)).Ref() }; if linked_767 == nil { o__6 = ifn_768.Invoke_O_O__O(arg_769, arg_770) } else { o__6 = jrt.Long_ValueOf_J__Long_NoInit(linked_767.(*A_arbace_go_check_types_align_up_A).InvokePrim_O_J_J__J(root_766, lang.RT_LongCast_O__J_NoInit(arg_769), lang.RT_LongCast_O__J_NoInit(arg_770))).Ref() }
		var tmp2 any; var root_775 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any = fs__2; if linked_776 == nil { tmp2 = ifn_777.Invoke_O__O(arg_778) } else { tmp2 = linked_776.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_775, arg_778) }; var tmp3 any = tmp2; var tmp4 jrt.Number_I; var na_779 any = o__6; var na_780 any; var root_781 any = A_arbace_go_check_types_A_const_143.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_781, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = A_arbace_go_check_types_A_const_104.Invoke_O__O(f__5); if linked_782 == nil { na_780 = ifn_783.Invoke_O__O(arg_784) } else { na_780 = jrt.Long_ValueOf_J__Long_NoInit(linked_782.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_781, arg_784)).Ref() }; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_779); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_780) }; tmp5 = tmp6; if tmp5 { var n0_785 int64 = jrt.NN(jrt.Long_Cast(na_779)).LongValue__J(); var n1_786 int64 = jrt.NN(jrt.Long_Cast(na_780)).LongValue__J(); var nr_787 int64 = n0_785 + n1_786; if (n0_785^nr_787)&(n1_786^nr_787) >= 0 { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_787)) } else { tmp4 = lang.Numbers_Add_O_O__Number_NoInit(na_779, na_780) } } else { var tmp7 bool; var tmp8 bool; tmp8 = jrt.Double_InstanceOf(na_779); if tmp8 { tmp8 = jrt.Double_InstanceOf(na_780) }; tmp7 = tmp8; if tmp7 { var n0_785_2 float64 = jrt.NN(jrt.Double_Cast(na_779)).DoubleValue__D(); var n1_786_2 float64 = jrt.NN(jrt.Double_Cast(na_780)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_785_2 + n1_786_2)) } else { tmp4 = lang.Numbers_Add_O_O__Number_NoInit(na_779, na_780) } }; var tmp9 any = tmp4; var tmp10 any; var root_788 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_789 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_788, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_790 lang.IFn; if linked_789 == nil { ifn_790 = lang.IFn_Cast(root_788) } else { ifn_790 = nil }; var arg_791 any = acc__4; var arg_792 any = o__6; if linked_789 == nil { tmp10 = ifn_790.Invoke_O_O__O(arg_791, arg_792) } else { tmp10 = linked_789.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_788, arg_791, arg_792) }; fs__2, offs__3, acc__4 = tmp3, tmp9, tmp10; continue L1 } } }; /*line :279:1*/panic("j2g: unreachable") }







func A_arbace_go_check_types_sizeof_A_New() *A_arbace_go_check_types_sizeof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sizeof_A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_go_check_types_sizeof_A) Ctor() {}
//line :287:1
func (t *A_arbace_go_check_types_sizeof_A) InvokePrim_O_O__J(self, t__0 any) int64 { var tmp1 any; var u__2 any; var root_793 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, A_arbace_go_check_types_under_A_fn_class); var ifn_795 lang.IFn; if
											linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = t__0; if linked_794 == nil { u__2 = ifn_795.Invoke_O__O(arg_796) } else { u__2 = linked_794.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_793, arg_796) }; var tmp2 any; var root_797 any =
											A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_799 lang.IFn; if
											linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = u__2; if linked_798 == nil { tmp2 = ifn_799.Invoke_O__O(arg_800) } else { tmp2 = linked_798.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_797, arg_800) }; if /*line :289:1*/ jrt.J2g_Truth(tmp2) { var G__219000093__3_ any = u__2
											L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__219000093__3_) { case 717828005: if any(G__219000093__3_) == any(A_arbace_go_check_types_A_const_40) { var na_802 int64 = 2; var na_803 any = A_arbace_go_check_types_A_const_142.GetRawRoot__O(); if jrt.Long_InstanceOf(na_803) { var n0_804 int64 = na_802; var n1_805 int64 = jrt.NN(jrt.Long_Cast(na_803)).LongValue__J(); var nr_806 int64 = n0_804 * n1_805; var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; tmp6 = n0_804 == -9223372036854775808; if tmp6 { tmp6 = n1_805 < 0 }; tmp5 = tmp6; tmp4 = !tmp5; if tmp4 { var tmp7 bool; tmp7 = n1_805 == 0; if !tmp7 { tmp7 = nr_806/n1_805 == n0_804 }; tmp4 = tmp7 }; tmp3 = tmp4; if tmp3 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_806).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_802, na_803) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_802, na_803) }; break L1 }; default:}; var tmp8 lang.IFn = A_arbace_go_check_types_A_const_11; tmp1 = tmp8.Invoke_O_O__O(lang.IFn_Cast(A_arbace_go_check_types_A_const_79.GetRawRoot__O()).Invoke_O__O(u__2), A_arbace_go_check_types_A_const_142.GetRawRoot__O())} } else {
//line :289:1
		if A_arbace_go_check_types_A_const_75 != nil { var G__219000094__3_ any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0))


		L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__219000094__3_) >> 5 & 3 { case 0: if any(G__219000094__3_) == any(A_arbace_go_check_types_A_const_94) { var n__4 int64 = lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)))

			if lang.Numbers_Lte_J_J__Z_NoInit(n__4, 0) { tmp1 = A_arbace_go_check_types_A_const_44 } else { var tmp9 int64; var root_808 any = A_arbace_go_check_types_A_const_143.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_808, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)); if linked_809 == nil { tmp9 = lang.RT_LongCast_O__J_NoInit(ifn_810.Invoke_O__O(arg_811)) } else { tmp9 = linked_809.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_808, arg_811) }; tmp1 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(n__4, tmp9)).Ref() }
//line :292:1
			break L2 }; case 1: if any(G__219000094__3_) == any(A_arbace_go_check_types_A_const_76) {











				var na_812 int64 = 2; var na_813 any = A_arbace_go_check_types_A_const_142.GetRawRoot__O(); if jrt.Long_InstanceOf(na_813) { var n0_814 int64 = na_812; var n1_815 int64 = jrt.NN(jrt.Long_Cast(na_813)).LongValue__J(); var nr_816 int64 = n0_814 * n1_815; var tmp10 bool; var tmp11 bool; var tmp12 bool; var tmp13 bool; tmp13 = n0_814 == -9223372036854775808; if tmp13 { tmp13 = n1_815 < 0 }; tmp12 = tmp13; tmp11 = !tmp12; if tmp11 { var tmp14 bool; tmp14 = n1_815 == 0; if !tmp14 { tmp14 = nr_816/n1_815 == n0_814 }; tmp11 = tmp14 }; tmp10 = tmp11; if tmp10 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_816).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_812, na_813) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_812, na_813) }
//line :292:1
				break L2 }; case 2: if any(G__219000094__3_) == any(A_arbace_go_check_types_A_const_93) {


					var na_817 int64 = 3; var na_818 any = A_arbace_go_check_types_A_const_142.GetRawRoot__O(); if jrt.Long_InstanceOf(na_818) { var n0_819 int64 = na_817; var n1_820 int64 = jrt.NN(jrt.Long_Cast(na_818)).LongValue__J(); var nr_821 int64 = n0_819 * n1_820; var tmp15 bool; var tmp16 bool; var tmp17 bool; var tmp18 bool; tmp18 = n0_819 == -9223372036854775808; if tmp18 { tmp18 = n1_820 < 0 }; tmp17 = tmp18; tmp16 = !tmp17; if tmp16 { var tmp19 bool; tmp19 = n1_820 == 0; if !tmp19 { tmp19 = nr_821/n1_820 == n0_819 }; tmp16 = tmp19 }; tmp15 = tmp16; if tmp15 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_821).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_817, na_818) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_817, na_818) }
//line :292:1
					break L2 }; case 3: if any(G__219000094__3_) == any(A_arbace_go_check_types_A_const_102) { var fs__4 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); var tmp20 any; var root_822 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_824 lang.IFn




						if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = fs__4; if linked_823 == nil { tmp20 = ifn_824.Invoke_O__O(arg_825) } else { tmp20 = linked_823.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_822, arg_825) }; if jrt.J2g_Truth(tmp20) { tmp1 = A_arbace_go_check_types_A_const_44 } else { var offs__5 any; var root_826 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, A_arbace_go_check_types_offsetsof_A_fn_class); var ifn_828 lang.IFn

							if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any = fs__4; if linked_827 == nil { offs__5 = ifn_828.Invoke_O__O(arg_829) } else { offs__5 = linked_827.(*A_arbace_go_check_types_offsetsof_A).Invoke_O_O__O(root_826, arg_829) }
//line :297:1
							var o__6 int64; var tmp21 any; var root_830 any = A_arbace_go_check_types_A_const_147.GetRawRoot__O(); var linked_831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_830, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_832 lang.IFn


							if linked_831 == nil { ifn_832 = lang.IFn_Cast(root_830) } else { ifn_832 = nil }; var arg_833 any = offs__5; if linked_831 == nil { tmp21 = ifn_832.Invoke_O__O(arg_833) } else { tmp21 = linked_831.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_830, arg_833) }; o__6 = lang.RT_LongCast_O__J_NoInit(tmp21)
//line :297:1
							var s__7 any; var root_834 any = A_arbace_go_check_types_A_const_143.GetRawRoot__O(); var linked_835 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_834, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_836 lang.IFn



							if linked_835 == nil { ifn_836 = lang.IFn_Cast(root_834) } else { ifn_836 = nil }; var arg_837 any; var tmp22 *lang.Keyword = A_arbace_go_check_types_A_const_104; var tmp23 any; var root_838 any = A_arbace_go_check_types_A_const_147.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_840 lang.IFn; if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any = fs__4; if linked_839 == nil { tmp23 = ifn_840.Invoke_O__O(arg_841) } else { tmp23 = linked_839.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_838, arg_841) }; arg_837 = tmp22.Invoke_O__O(tmp23); if linked_835 == nil { s__7 = ifn_836.Invoke_O__O(arg_837) } else { s__7 = jrt.Long_ValueOf_J__Long_NoInit(linked_835.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_834, arg_837)).Ref() }
//line :297:1
							var s__8 any; var tmp24 bool; var and__1927000168__auto____8 bool = lang.Numbers_IsPos_J__Z_NoInit(o__6)




							if and__1927000168__auto____8 { var na_842 any = s__7; if jrt.Long_InstanceOf(na_842) { var n0_843 int64 = jrt.NN(jrt.Long_Cast(na_842)).LongValue__J(); tmp24 = n0_843 == 0 } else { if jrt.Double_InstanceOf(na_842) { var n0_843_2 float64 = jrt.NN(jrt.Double_Cast(na_842)).DoubleValue__D(); tmp24 = n0_843_2 == 0.0 } else { tmp24 = lang.Numbers_IsZero_O__Z_NoInit(na_842) } } } else { tmp24 = and__1927000168__auto____8 }; if tmp24 { s__8 = A_arbace_go_check_types_A_const_15 } else { s__8 = s__7 }
							var root_844 any = A_arbace_go_check_types_A_const_145.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_844, A_arbace_go_check_types_align_up_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any; var na_849 int64 = o__6; var na_850 any = s__8; if jrt.Long_InstanceOf(na_850) { var n0_851 int64 = na_849; var n1_852 int64 = jrt.NN(jrt.Long_Cast(na_850)).LongValue__J(); var nr_853 int64 = n0_851 + n1_852; if (n0_851^nr_853)&(n1_852^nr_853) >= 0 { arg_847 = jrt.Long_ValueOf_J__Long_NoInit(nr_853).Ref() } else { arg_847 = lang.Numbers_Add_J_O__Number_NoInit(na_849, na_850) } } else { arg_847 = lang.Numbers_Add_J_O__Number_NoInit(na_849, na_850) }; var arg_848 any; var root_854 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_854, A_arbace_go_check_types_alignof_A_fn_class); var ifn_856 lang.IFn; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any = t__0; if linked_855 == nil { arg_848 = ifn_856.Invoke_O__O(arg_857) } else { arg_848 = jrt.Long_ValueOf_J__Long_NoInit(linked_855.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_854, arg_857)).Ref() }; if linked_845 == nil { tmp1 = ifn_846.Invoke_O_O__O(arg_847, arg_848) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_845.(*A_arbace_go_check_types_align_up_A).InvokePrim_O_J_J__J(root_844, lang.RT_LongCast_O__J_NoInit(arg_847), lang.RT_LongCast_O__J_NoInit(arg_848))).Ref() } }
//line :292:1
						break L2 }; default:}; tmp1 = A_arbace_go_check_types_A_const_142.GetRawRoot__O()} } else {
//line :289:1
							tmp1 = nil } }; return /*line :287:1*/ jrt.Number_Cast(tmp1).LongValue__J() }
//line :287:1
func (t *A_arbace_go_check_types_sizeof_A) Invoke_O_O__O(self, t__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, t__0)).Ref() }





















func A_arbace_go_check_types_deref_type_A_New() *A_arbace_go_check_types_deref_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_deref_type_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_go_check_types_deref_type_A) Ctor() {}
//line :309:1
func (t *A_arbace_go_check_types_deref_type_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_858 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_858, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_860 lang.IFn; if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any = t__0; if linked_859 == nil { and__1927000168__auto____2 = ifn_860.Invoke_O__O(arg_861) } else { and__1927000168__auto____2 = linked_859.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_858, arg_861) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_types_A_const_87; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)), jrt.Boolean_TRUE.Ref()) } else { return lang.Tuple_Create_O_O__IPersistentVector(t__0, jrt.Boolean_FALSE.Ref())
	} }
func A_arbace_go_check_types_methods_of_A_New() *A_arbace_go_check_types_methods_of_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_methods_of_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_go_check_types_methods_of_A) Ctor() {}
//line :314:1
func (t *A_arbace_go_check_types_methods_of_A) Invoke_O_O__O(self, t__0 any) any { var t__2 any; var tmp1 *lang.Keyword = A_arbace_go_check_types_A_const_148; var tmp2 any; var root_862 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_862, A_arbace_go_check_types_info_A_fn_class); var ifn_864 lang.IFn; if


	linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any = t__0; if linked_863 == nil { tmp2 = ifn_864.Invoke_O__O(arg_865) } else { tmp2 = linked_863.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_862, arg_865) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 *lang.Keyword = A_arbace_go_check_types_A_const_148; var tmp4 any; var root_866 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, A_arbace_go_check_types_info_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = t__0; if linked_867 == nil { tmp4 = ifn_868.Invoke_O__O(arg_869) } else { tmp4 = linked_867.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_866, arg_869) }; t__2 = tmp3.Invoke_O__O(tmp4) } else { t__2 = t__0 }; var root_874 any =
	A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_874, A_arbace_go_check_types_under_A_fn_class); var ifn_876 lang.IFn; if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; var arg_877 any = t__2; if linked_875 == nil { ifn_876.Invoke_O__O(arg_877) } else { linked_875.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_874, arg_877) }; var tmp5 /*line :319:1*/*lang.Keyword = A_arbace_go_check_types_A_const_62; var tmp6 any; var root_870 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, A_arbace_go_check_types_info_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = t__2; if linked_871 == nil { tmp6 = ifn_872.Invoke_O__O(arg_873) } else { tmp6 = linked_871.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_870, arg_873) }; return tmp5.Invoke_O__O(tmp6) }





func A_arbace_go_check_types_same_id_QMARK__A_New() *A_arbace_go_check_types_same_id_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_same_id_QMARK__A{}; t.Ctor(); return t }
//line :325:1
func (t *A_arbace_go_check_types_same_id_QMARK__A) Ctor() {}
//line :325:1
func (t *A_arbace_go_check_types_same_id_QMARK__A) Invoke_O_O_O_O_O__O(self, n__0, p__1, name__2, pkg__3 any) any {



	var tmp1 any; var and__1927000168__auto____5 any = A_arbace_go_check_types_A_const_149.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.String_Cast(n__0)).EqualsIgnoreCase_String__Z(jrt.String_Cast(name__2))).Ref() } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, name__2)

		if and__1927000168__auto____5_2 { var or__1927000174__auto____6 bool = jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(name__2)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))
			if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(p__1, pkg__3); if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { return jrt.Boolean_FALSE.Ref() } } } else {
//line :331:1
				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref()
			}
	}
}


func A_arbace_go_check_types_exported_QMARK__A_New() *A_arbace_go_check_types_exported_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_exported_QMARK__A{}; t.Ctor(); return t }
//line :337:1
func (t *A_arbace_go_check_types_exported_QMARK__A) Ctor() {}
//line :337:1
func (t *A_arbace_go_check_types_exported_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var cp__2 int32 = jrt.NN(jrt.String_Cast(n__0)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(0)); return /*line :338:1*/ jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_I__Z_NoInit(cp__2)).Ref() }











func A_arbace_go_check_types_named_method_A_New() *A_arbace_go_check_types_named_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_method_A{}; t.Ctor(); return t }
//line :350:1
func (t *A_arbace_go_check_types_named_method_A) Ctor() {}
//line :350:1
func (t *A_arbace_go_check_types_named_method_A) Invoke_O_O_O_O__O(self, t__0, name__1, pkg__2 any) any { { var ms__4 any; var root_878 any = A_arbace_go_check_types_A_const_150.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, A_arbace_go_check_types_methods_of_A_fn_class); var ifn_880 lang.IFn


	if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = t__0; if linked_879 == nil { ms__4 = ifn_880.Invoke_O__O(arg_881) } else { ms__4 = linked_879.(*A_arbace_go_check_types_methods_of_A).Invoke_O_O__O(root_878, arg_881) }
//line :350:1
	var i__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i__5, int64(lang.RT_Count_O__I_NoInit(ms__4))) { var m__6 any = lang.RT_Nth_O_I__O_NoInit(ms__4, lang.RT_IntCast_J__I_NoInit(i__5)); var map__219000100__7 any; var root_882 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_884 lang.IFn
			if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any = m__6; if linked_883 == nil { map__219000100__7 = ifn_884.Invoke_O__O(arg_885) } else { map__219000100__7 = linked_883.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_882, arg_885) }
//line :355:1
			var map__219000100__8 any
			if lang.ISeq_InstanceOf(map__219000100__7) { var tmp1 any; var root_886 any = A_arbace_go_check_types_A_const_151.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = map__219000100__7; if linked_887 == nil { tmp1 = ifn_888.Invoke_O__O(arg_889) } else { tmp1 = linked_887.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_886, arg_889) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_890 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = map__219000100__7; if linked_891 == nil { tmp2 = ifn_892.Invoke_O__O(arg_893) } else { tmp2 = linked_891.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_890, arg_893) }; map__219000100__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_894 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = map__219000100__7; if linked_895 == nil { tmp3 = ifn_896.Invoke_O__O(arg_897) } else { tmp3 = linked_895.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_894, arg_897) }; if jrt.J2g_Truth(tmp3) { var root_898 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = map__219000100__7; if linked_899 == nil { map__219000100__8 = ifn_900.Invoke_O__O(arg_901) } else { map__219000100__8 = linked_899.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_898, arg_901) } } else { map__219000100__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__219000100__8 = map__219000100__7 }
//line :355:1
			var mn__9 any = lang.RT_Get_O_O__O_NoInit(map__219000100__8, A_arbace_go_check_types_A_const_12); var mp__10 any = lang.RT_Get_O_O__O_NoInit(map__219000100__8, A_arbace_go_check_types_A_const_115); var tmp4 any; var root_902 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_904 lang.IFn


			if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any = mn__9; var arg_906 any = mp__10; var arg_907 any = name__1; var arg_908 any = pkg__2; if linked_903 == nil { tmp4 = ifn_904.Invoke_O_O_O_O__O(arg_905, arg_906, arg_907, arg_908) } else { tmp4 = linked_903.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_902, arg_905, arg_906, arg_907, arg_908) }; if jrt.J2g_Truth(tmp4) { return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__5).Ref(), m__6) } else {

				i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } } else {
//line :355:1
					return nil } } }; /*line :350:1*/panic("j2g: unreachable") }











func A_arbace_go_check_types_iface_method_A_New() *A_arbace_go_check_types_iface_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_iface_method_A{}; t.Ctor(); return t }
//line :362:1
func (t *A_arbace_go_check_types_iface_method_A) Ctor() {}
//line :362:1
func (t *A_arbace_go_check_types_iface_method_A) Invoke_O_O_O_O__O(self, u__0, name__1, pkg__2 any) any { { var ms__4 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(1)); var i__5 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i__5, int64(lang.RT_Count_O__I_NoInit(ms__4))) { var m__6 any = lang.RT_Nth_O_I__O_NoInit(ms__4, lang.RT_IntCast_J__I_NoInit(i__5)); var tmp1 any; var root_909 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_911 lang.IFn

		if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__6); var arg_913 any = A_arbace_go_check_types_A_const_115.Invoke_O__O(m__6); var arg_914 any = name__1; var arg_915 any = pkg__2; if linked_910 == nil { tmp1 = ifn_911.Invoke_O_O_O_O__O(arg_912, arg_913, arg_914, arg_915) } else { tmp1 = linked_910.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_909, arg_912, arg_913, arg_914, arg_915) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__5).Ref(), m__6) } else {

			i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } } else {
//line :367:1
				return nil } } }; /*line :362:1*/panic("j2g: unreachable") }










func A_arbace_go_check_types_consolidate_A_New() *A_arbace_go_check_types_consolidate_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_consolidate_A{}; t.Ctor(); return t }
//line :373:1
func (t *A_arbace_go_check_types_consolidate_A) Ctor() {}
//line :373:1
func (t *A_arbace_go_check_types_consolidate_A) Invoke_O_O__O(self, entries__0 any) any { { var es__2 any = entries__0; var acc__3 any = lang.PersistentVector_EMPTY.Ref(); var idx__4 any = lang.PersistentArrayMap_EMPTY.Ref(); L1: for {



	var tmp1 any; var root_916 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any = es__2; if linked_917 == nil { tmp1 = ifn_918.Invoke_O__O(arg_919) } else { tmp1 = linked_917.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_916, arg_919) }; if jrt.J2g_Truth(tmp1) { return acc__3 } else { var e__5 any; var root_920 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_922 lang.IFn

		if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = es__2; if linked_921 == nil { e__5 = ifn_922.Invoke_O__O(arg_923) } else { e__5 = linked_921.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_920, arg_923) }
//line :377:1
		var k__6 any = A_arbace_go_check_types_A_const_104.Invoke_O__O(e__5); var temp__1927000408__auto____7 any = lang.RT_Get_O_O__O_NoInit(idx__4, k__6)



		if jrt.J2g_Truth(temp__1927000408__auto____7) { var j__8 any = temp__1927000408__auto____7; var tmp2 any; var root_924 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_926 lang.IFn
			if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = es__2; if linked_925 == nil { tmp2 = ifn_926.Invoke_O__O(arg_927) } else { tmp2 = linked_925.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_924, arg_927) }; var tmp3 any = tmp2; var tmp4 any; var root_928 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_930 lang.IFn; if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = acc__3; var arg_932 any = lang.Tuple_Create_O_O__IPersistentVector(j__8, A_arbace_go_check_types_A_const_155); var arg_933 any = jrt.Boolean_TRUE.Ref(); if linked_929 == nil { tmp4 = ifn_930.Invoke_O_O_O__O(arg_931, arg_932, arg_933) } else { tmp4 = linked_929.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_928, arg_931, arg_932, arg_933) }; es__2, acc__3, idx__4 = tmp3, tmp4, idx__4; continue L1 } else {
				var tmp5 any; var root_934 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = es__2; if linked_935 == nil { tmp5 = ifn_936.Invoke_O__O(arg_937) } else { tmp5 = linked_935.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_934, arg_937) }; var tmp6 any = tmp5; var tmp7 any; var root_938 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = acc__3; var arg_942 any = e__5; if linked_939 == nil { tmp7 = ifn_940.Invoke_O_O__O(arg_941, arg_942) } else { tmp7 = linked_939.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_938, arg_941, arg_942) }; var tmp8 any = tmp7; var tmp9 any; var root_943 any = A_arbace_go_check_types_A_const_59.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = idx__4; var arg_947 any = k__6; var arg_948 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(acc__3)).Ref(); if linked_944 == nil { tmp9 = ifn_945.Invoke_O_O_O__O(arg_946, arg_947, arg_948) } else { tmp9 = linked_944.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_943, arg_946, arg_947, arg_948) }; es__2, acc__3, idx__4 = tmp6, tmp8, tmp9; continue L1 } } } }; /*line :373:1*/panic("j2g: unreachable") }











func A_arbace_go_check_types_lookup_impl_A_New() *A_arbace_go_check_types_lookup_impl_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_impl_A{}; t.Ctor(); return t }
//line :385:1
func (t *A_arbace_go_check_types_lookup_impl_A) Ctor() {}
//line :385:1
func (t *A_arbace_go_check_types_lookup_impl_A) Invoke_O_O_O_O_O__O(self, T__0_, addressable__1, name__2, pkg__3 any) any { { var vec__219000105__5 any; var root_949 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_949, A_arbace_go_check_types_deref_type_A_fn_class); var ifn_951 lang.IFn





	if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_952 any = T__0_; if linked_950 == nil { vec__219000105__5 = ifn_951.Invoke_O__O(arg_952) } else { vec__219000105__5 = linked_950.(*A_arbace_go_check_types_deref_type_A).Invoke_O_O__O(root_949, arg_952) }
//line :385:1
	var typ__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000105__5, lang.RT_IntCast_J__I_NoInit(0), nil); var is_ptr__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000105__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any
	var and__1927000168__auto____8 any = is_ptr__7





	if jrt.J2g_Truth(and__1927000168__auto____8) { var root_953 any = A_arbace_go_check_types_A_const_157.GetRawRoot__O(); var linked_954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_953, A_arbace_go_check_types_interface_QMARK__A_fn_class); var ifn_955 lang.IFn; if linked_954 == nil { ifn_955 = lang.IFn_Cast(root_953) } else { ifn_955 = nil }; var arg_956 any = typ__6; if linked_954 == nil { tmp1 = ifn_955.Invoke_O__O(arg_956) } else { tmp1 = linked_954.(*A_arbace_go_check_types_interface_QMARK__A).Invoke_O_O__O(root_953, arg_956) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return nil } else { var current__8 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_104, typ__6, A_arbace_go_check_types_A_const_165, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_types_A_const_166, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_types_A_const_167, is_ptr__7, A_arbace_go_check_types_A_const_155, jrt.Boolean_FALSE.Ref()))); var seen__9 any = lang.PersistentHashSet_EMPTY.Ref(); L1: for {



		var tmp2 any; var root_957 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_957, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_959 lang.IFn; if linked_958 == nil { ifn_959 = lang.IFn_Cast(root_957) } else { ifn_959 = nil }; var arg_960 any = current__8; if linked_958 == nil { tmp2 = ifn_959.Invoke_O__O(arg_960) } else { tmp2 = linked_958.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_957, arg_960) }; if jrt.J2g_Truth(tmp2) { return nil } else { var vec__219000108__10 any; var root_961 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_963 lang.IFn


			if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any; var tmp3 any = A_arbace_go_check_types_lookup_impl_fn__219000112_A_New_O_O(pkg__3, name__2); var tmp4 *jrt.Class; var fncls__1070 *jrt.Class = A_arbace_go_check_types_lookup_impl_fn__219000112_A_fn_class
			if fncls__1070 == nil { var fncls__1070d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_go_check_types_lookup_impl_fn__219000112_A_fn_class = fncls__1070d; tmp4 = fncls__1070d } else { tmp4 = fncls__1070 }; arg_964 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)
//line :399:1
			var arg_965 any = lang.Tuple_Create_O_O_O__IPersistentVector(nil, lang.PersistentVector_EMPTY.Ref(), seen__9); var arg_966 any = current__8; if linked_962 == nil { vec__219000108__10 = ifn_963.Invoke_O_O_O__O(arg_964, arg_965, arg_966) } else { vec__219000108__10 = linked_962.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_961, arg_964, arg_965, arg_966) }
//line :396:1
			var found__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000108__10, lang.RT_IntCast_J__I_NoInit(0), nil); var next__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000108__10, lang.RT_IntCast_J__I_NoInit(1), nil); var seen__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000108__10, lang.RT_IntCast_J__I_NoInit(2), nil)















































			if jrt.J2g_Truth(A_arbace_go_check_types_A_const_173.Invoke_O__O(found__11)) { return found__11 } else { if jrt.J2g_Truth(found__11) {


				var tmp5 any; var tmp6 any = A_arbace_go_check_types_A_const_162; var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_go_check_types_A_const_161.Invoke_O__O(found__11)); if and__1927000168__auto____14 { var tmp7 *lang.Keyword = A_arbace_go_check_types_A_const_174; var and__1927000168__auto____15 any = tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_go_check_types_A_const_175.Get__O()).Invoke_O__O(A_arbace_go_check_types_A_const_71.Invoke_O__O(found__11))); if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any; var root_1071 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1073 lang.IFn
					if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = A_arbace_go_check_types_A_const_167.Invoke_O__O(found__11); if linked_1072 == nil { and__1927000168__auto____16 = ifn_1073.Invoke_O__O(arg_1074) } else { and__1927000168__auto____16 = linked_1072.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1071, arg_1074) }
//line :447:1
					if jrt.J2g_Truth(and__1927000168__auto____16) {
						var root_1075 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1077 lang.IFn; if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = addressable__1; if linked_1076 == nil { tmp5 = ifn_1077.Invoke_O__O(arg_1078) } else { tmp5 = linked_1076.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1075, arg_1078) } } else {
//line :447:1
							tmp5 = and__1927000168__auto____16 } } else { tmp5 = and__1927000168__auto____15 } } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }; if jrt.J2g_Truth(tmp5) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_174, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_types_A_const_176, found__11)) } else { return found__11 } } else {
//line :444:1
								if A_arbace_go_check_types_A_const_75 != nil {






									var tmp8 any; var root_1079 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, A_arbace_go_check_types_consolidate_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any = next__12; if linked_1080 == nil { tmp8 = ifn_1081.Invoke_O__O(arg_1082) } else { tmp8 = linked_1080.(*A_arbace_go_check_types_consolidate_A).Invoke_O_O__O(root_1079, arg_1082) }; current__8, seen__9 = tmp8, seen__13; continue L1 } else {
//line :444:1
										return nil } } } } } } }; /*line :385:1*/panic("j2g: unreachable") }














func A_arbace_go_check_types_lookup_impl_fn__219000112_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_lookup_impl_fn__219000112_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_impl_fn__219000112_A{}; t.Ctor_O_O(p0, p1); return t }
//line :400:1
func (t *A_arbace_go_check_types_lookup_impl_fn__219000112_A) Ctor_O_O(c__pkg, c__name any) { t.F_pkg = c__pkg; t.F_name = c__name }
//line :400:1
func (t *A_arbace_go_check_types_lookup_impl_fn__219000112_A) Invoke_O_O_O__O(self, p__219000111__1, e__2 any) any { { var vec__219000113__3 any = p__219000111__1; var found__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000113__3, lang.RT_IntCast_J__I_NoInit(0), nil); var next__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000113__3, lang.RT_IntCast_J__I_NoInit(1), nil); var seen__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000113__3, lang.RT_IntCast_J__I_NoInit(2), nil); var typ__7 any = A_arbace_go_check_types_A_const_104.Invoke_O__O(e__2); var tmp1 any; var and__1927000168__auto____8 any; var root_967 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_969 lang.IFn

	if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = typ__7; if linked_968 == nil { and__1927000168__auto____8 = ifn_969.Invoke_O__O(arg_970) } else { and__1927000168__auto____8 = linked_968.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_967, arg_970) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_971 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = seen__6; var arg_975 any = typ__7; if linked_972 == nil { tmp1 = ifn_973.Invoke_O_O__O(arg_974, arg_975) } else { tmp1 = linked_972.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_971, arg_974, arg_975) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__6) } else { var seen__8 any; var tmp2 any; var root_976 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_978 lang.IFn

		if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = typ__7; if linked_977 == nil { tmp2 = ifn_978.Invoke_O__O(arg_979) } else { tmp2 = linked_977.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_976, arg_979) }; if jrt.J2g_Truth(tmp2) { var root_980 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = seen__6; var arg_984 any = typ__7; if linked_981 == nil { seen__8 = ifn_982.Invoke_O_O__O(arg_983, arg_984) } else { seen__8 = linked_981.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_980, arg_983, arg_984) } } else { seen__8 = seen__6 }
//line :402:1
		var m__9 any; var tmp3 any; var root_985 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_987 lang.IFn


		if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = typ__7; if linked_986 == nil { tmp3 = ifn_987.Invoke_O__O(arg_988) } else { tmp3 = linked_986.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_985, arg_988) }; if jrt.J2g_Truth(tmp3) { var root_989 any = A_arbace_go_check_types_A_const_158.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, A_arbace_go_check_types_named_method_A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = typ__7; var arg_993 any = t.F_name; var arg_994 any = t.F_pkg; if linked_990 == nil { m__9 = ifn_991.Invoke_O_O_O__O(arg_992, arg_993, arg_994) } else { m__9 = linked_990.(*A_arbace_go_check_types_named_method_A).Invoke_O_O_O_O__O(root_989, arg_992, arg_993, arg_994) } } else { m__9 = nil }
		if jrt.J2g_Truth(m__9) {
			var tmp4 any; var or__1927000174__auto____10 any = found__4; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp4 = or__1927000174__auto____10 } else { tmp4 = A_arbace_go_check_types_A_const_155.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp4) { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_160, next__5, seen__8) } else { var tmp5 any = A_arbace_go_check_types_A_const_161; var tmp6 any = A_arbace_go_check_types_A_const_162; var tmp7 any = A_arbace_go_check_types_A_const_71; var tmp8 any; var root_1024 any = A_arbace_go_check_types_A_const_163.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1026 lang.IFn

				if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = m__9; if linked_1025 == nil { tmp8 = ifn_1026.Invoke_O__O(arg_1027) } else { tmp8 = linked_1025.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1024, arg_1027) }
//line :407:1
				var tmp9 any = tmp8; var tmp10 any = A_arbace_go_check_types_A_const_164; var tmp11 any = A_arbace_go_check_types_A_const_165; var tmp12 any; var root_1028 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1030 lang.IFn

				if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = A_arbace_go_check_types_A_const_165.Invoke_O__O(e__2); var arg_1032 any; var root_1033 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any = m__9; if linked_1034 == nil { arg_1032 = ifn_1035.Invoke_O__O(arg_1036) } else { arg_1032 = linked_1034.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1033, arg_1036) }; if linked_1029 == nil { tmp12 = ifn_1030.Invoke_O_O__O(arg_1031, arg_1032) } else { tmp12 = linked_1029.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1028, arg_1031, arg_1032) }
//line :407:1
				var tmp13 any = tmp12; var tmp14 any = A_arbace_go_check_types_A_const_166; var tmp15 any = A_arbace_go_check_types_A_const_166.Invoke_O__O(e__2); var tmp16 any = A_arbace_go_check_types_A_const_167; return lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, tmp9, tmp10, typ__7, tmp11, tmp13, tmp14, tmp15, tmp16, A_arbace_go_check_types_A_const_167.Invoke_O__O(e__2))), next__5, seen__8) } } else {
//line :406:1
					var u__10 any; var root_995 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_995, A_arbace_go_check_types_under_A_fn_class); var ifn_997 lang.IFn




					if linked_996 == nil { ifn_997 = lang.IFn_Cast(root_995) } else { ifn_997 = nil }; var arg_998 any = typ__7; if linked_996 == nil { u__10 = ifn_997.Invoke_O__O(arg_998) } else { u__10 = linked_996.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_995, arg_998) }
					var tmp17 any; var and__1927000168__auto____11 any; var root_999 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_999, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1001 lang.IFn
					if linked_1000 == nil { ifn_1001 = lang.IFn_Cast(root_999) } else { ifn_1001 = nil }; var arg_1002 any = u__10; if linked_1000 == nil { and__1927000168__auto____11 = ifn_1001.Invoke_O__O(arg_1002) } else { and__1927000168__auto____11 = linked_1000.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_999, arg_1002) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var tmp18 any = A_arbace_go_check_types_A_const_102; tmp17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp18, lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp17 = and__1927000168__auto____11 }
//line :412:1
					if jrt.J2g_Truth(tmp17) { var fs__11 any = lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(1)); var i__12 int64 = 0; var found__13 any = found__4; var next__14 any = next__5; L1: for {



						if lang.Numbers_Gte_J_J__Z_NoInit(i__12, int64(lang.RT_Count_O__I_NoInit(fs__11))) { return lang.Tuple_Create_O_O_O__IPersistentVector(found__13, next__14, seen__8) } else { var f__15 any = lang.RT_Nth_O_I__O_NoInit(fs__11, lang.RT_IntCast_J__I_NoInit(i__12)); var tmp19 any; var root_1003 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1003, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_1005 lang.IFn



							if linked_1004 == nil { ifn_1005 = lang.IFn_Cast(root_1003) } else { ifn_1005 = nil }; var arg_1006 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(f__15); var arg_1007 any = A_arbace_go_check_types_A_const_115.Invoke_O__O(f__15); var arg_1008 any = t.F_name; var arg_1009 any = t.F_pkg; if linked_1004 == nil { tmp19 = ifn_1005.Invoke_O_O_O_O__O(arg_1006, arg_1007, arg_1008, arg_1009) } else { tmp19 = linked_1004.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_1003, arg_1006, arg_1007, arg_1008, arg_1009) }
//line :419:1
							if jrt.J2g_Truth(tmp19) {

								var tmp20 any; var or__1927000174__auto____16 any = found__13; if jrt.J2g_Truth(or__1927000174__auto____16) { tmp20 = or__1927000174__auto____16 } else { tmp20 = A_arbace_go_check_types_A_const_155.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp20) {
									i__12, found__13, next__14 = lang.Numbers_Inc_J__J_NoInit(i__12), A_arbace_go_check_types_A_const_168, next__14; continue L1 } else {
										var tmp21 int64 = lang.Numbers_Inc_J__J_NoInit(i__12); var tmp22 any = A_arbace_go_check_types_A_const_161; var tmp23 any = A_arbace_go_check_types_A_const_169; var tmp24 any = A_arbace_go_check_types_A_const_71; var tmp25 any = A_arbace_go_check_types_A_const_165; var tmp26 any; var root_1037 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = A_arbace_go_check_types_A_const_165.Invoke_O__O(e__2); var arg_1041 any = jrt.Long_ValueOf_J__Long_NoInit(i__12).Ref(); if linked_1038 == nil { tmp26 = ifn_1039.Invoke_O_O__O(arg_1040, arg_1041) } else { tmp26 = linked_1038.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1037, arg_1040, arg_1041) }; var tmp27 any = tmp26; var tmp28 any = A_arbace_go_check_types_A_const_166; var tmp29 any = A_arbace_go_check_types_A_const_166.Invoke_O__O(e__2); var tmp30 any = A_arbace_go_check_types_A_const_167; i__12, found__13, next__14 = tmp21, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp23, tmp24, f__15, tmp25, tmp27, tmp28, tmp29, tmp30, A_arbace_go_check_types_A_const_167.Invoke_O__O(e__2))), next__14; continue L1 } } else {
//line :419:1
											var tmp31 any; var and__1927000168__auto____16 bool = lang.Util_Identical_O_O__Z_NoInit(found__13, nil)






											if and__1927000168__auto____16 { tmp31 = A_arbace_go_check_types_A_const_112.Invoke_O__O(f__15) } else { tmp31 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____16).Ref() }
//line :419:1
											if jrt.J2g_Truth(tmp31) { var vec__219000116__16 any; var root_1010 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, A_arbace_go_check_types_deref_type_A_fn_class); var ifn_1012 lang.IFn







												if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; var arg_1013 any = A_arbace_go_check_types_A_const_104.Invoke_O__O(f__15); if linked_1011 == nil { vec__219000116__16 = ifn_1012.Invoke_O__O(arg_1013) } else { vec__219000116__16 = linked_1011.(*A_arbace_go_check_types_deref_type_A).Invoke_O_O__O(root_1010, arg_1013) }
//line :419:1
												var ft__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000116__16, lang.RT_IntCast_J__I_NoInit(0), nil); var fp__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000116__16, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp32 int64 = lang.Numbers_Inc_J__J_NoInit(i__12); var tmp33 any; var root_1042 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1044 lang.IFn









												if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = next__14; var arg_1046 any; var tmp34 any = A_arbace_go_check_types_A_const_104; var tmp35 any = A_arbace_go_check_types_A_const_165; var tmp36 any; var root_1047 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = A_arbace_go_check_types_A_const_165.Invoke_O__O(e__2); var arg_1051 any = jrt.Long_ValueOf_J__Long_NoInit(i__12).Ref(); if linked_1048 == nil { tmp36 = ifn_1049.Invoke_O_O__O(arg_1050, arg_1051) } else { tmp36 = linked_1048.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1047, arg_1050, arg_1051) }; var tmp37 any = tmp36; var tmp38 any = A_arbace_go_check_types_A_const_166; var tmp39 any; var root_1052 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1052, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1054 lang.IFn
												if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any = A_arbace_go_check_types_A_const_166.Invoke_O__O(e__2); var arg_1056 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(f__15); if linked_1053 == nil { tmp39 = ifn_1054.Invoke_O_O__O(arg_1055, arg_1056) } else { tmp39 = linked_1053.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1052, arg_1055, arg_1056) }
//line :429:1
												var tmp40 any = tmp39; var tmp41 any = A_arbace_go_check_types_A_const_167; var tmp42 any; var or__1927000174__auto____19 any = A_arbace_go_check_types_A_const_167.Invoke_O__O(e__2)

												if jrt.J2g_Truth(or__1927000174__auto____19) { tmp42 = or__1927000174__auto____19 } else { tmp42 = fp__18 }
//line :429:1
												var tmp43 any = tmp42; var tmp44 any = A_arbace_go_check_types_A_const_155; arg_1046 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp34, ft__17, tmp35, tmp37, tmp38, tmp40, tmp41, tmp43, tmp44, A_arbace_go_check_types_A_const_155.Invoke_O__O(e__2))); if linked_1043 == nil { tmp33 = ifn_1044.Invoke_O_O__O(arg_1045, arg_1046) } else { tmp33 = linked_1043.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1042, arg_1045, arg_1046) }
//line :428:1
												i__12, found__13, next__14 = tmp32, found__13, tmp33; continue L1 } else {
//line :419:1
													if A_arbace_go_check_types_A_const_75 != nil {













														i__12, found__13, next__14 = lang.Numbers_Inc_J__J_NoInit(i__12), found__13, next__14; continue L1 } else {
//line :419:1
															return nil } } } } } } else {
//line :412:1
																var tmp45 any; var and__1927000168__auto____11_2 any; var root_1014 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1016 lang.IFn





















																if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = u__10; if linked_1015 == nil { and__1927000168__auto____11_2 = ifn_1016.Invoke_O__O(arg_1017) } else { and__1927000168__auto____11_2 = linked_1015.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1014, arg_1017) }; if jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp46 any = A_arbace_go_check_types_A_const_76; tmp45 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp46, lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp45 = and__1927000168__auto____11_2 }
//line :412:1
																if jrt.J2g_Truth(tmp45) { var temp__1927000408__auto____11 any; var root_1018 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, A_arbace_go_check_types_iface_method_A_fn_class); var ifn_1020 lang.IFn






















																	if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = u__10; var arg_1022 any = t.F_name; var arg_1023 any = t.F_pkg; if linked_1019 == nil { temp__1927000408__auto____11 = ifn_1020.Invoke_O_O_O__O(arg_1021, arg_1022, arg_1023) } else { temp__1927000408__auto____11 = linked_1019.(*A_arbace_go_check_types_iface_method_A).Invoke_O_O_O_O__O(root_1018, arg_1021, arg_1022, arg_1023) }; if jrt.J2g_Truth(temp__1927000408__auto____11) { var m__12 any = temp__1927000408__auto____11; var tmp47 any; var or__1927000174__auto____13 any = found__4
																		if jrt.J2g_Truth(or__1927000174__auto____13) { tmp47 = or__1927000174__auto____13 } else { tmp47 = A_arbace_go_check_types_A_const_155.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp47) { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_170, next__5, seen__8) } else { var tmp48 any = A_arbace_go_check_types_A_const_161; var tmp49 any = A_arbace_go_check_types_A_const_171; var tmp50 any = A_arbace_go_check_types_A_const_71; var tmp51 any; var root_1057 any = A_arbace_go_check_types_A_const_163.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1059 lang.IFn

																			if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = m__12; if linked_1058 == nil { tmp51 = ifn_1059.Invoke_O__O(arg_1060) } else { tmp51 = linked_1058.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1057, arg_1060) }
//line :436:1
																			var tmp52 any = tmp51; var tmp53 any = A_arbace_go_check_types_A_const_172; var tmp54 any = A_arbace_go_check_types_A_const_165; var tmp55 any; var root_1061 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1063 lang.IFn

																			if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = A_arbace_go_check_types_A_const_165.Invoke_O__O(e__2); var arg_1065 any; var root_1066 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = m__12; if linked_1067 == nil { arg_1065 = ifn_1068.Invoke_O__O(arg_1069) } else { arg_1065 = linked_1067.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1066, arg_1069) }; if linked_1062 == nil { tmp55 = ifn_1063.Invoke_O_O__O(arg_1064, arg_1065) } else { tmp55 = linked_1062.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1061, arg_1064, arg_1065) }
//line :436:1
																			var tmp56 any = tmp55; var tmp57 any = A_arbace_go_check_types_A_const_166; var tmp58 any = A_arbace_go_check_types_A_const_166.Invoke_O__O(e__2); var tmp59 any = A_arbace_go_check_types_A_const_167; return lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp48, tmp49, tmp50, tmp52, tmp53, typ__7, tmp54, tmp56, tmp57, tmp58, tmp59, A_arbace_go_check_types_A_const_167.Invoke_O__O(e__2))), next__5, seen__8) } } else {
//line :435:1
																				return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__8) } } else {
//line :412:1
																					if A_arbace_go_check_types_A_const_75 != nil { return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__8) } else { return nil } } } } } }; /*line :400:1*/panic("j2g: unreachable") }




















































func A_arbace_go_check_types_lookup_A_New() *A_arbace_go_check_types_lookup_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_A{}; t.Ctor(); return t }
//line :453:1
func (t *A_arbace_go_check_types_lookup_A) Ctor() {}
//line :453:1
func (t *A_arbace_go_check_types_lookup_A) Invoke_O_O_O_O_O__O(self, T__0_, addressable__1, name__2, pkg__3 any) any {


	var tmp1 any; var and__1927000168__auto____5 any; var root_1083 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = T__0_; if linked_1084 == nil { and__1927000168__auto____5 = ifn_1085.Invoke_O__O(arg_1086) } else { and__1927000168__auto____5 = linked_1084.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1083, arg_1086) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1087 any = A_arbace_go_check_types_A_const_178.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, A_arbace_go_check_types_pointer_QMARK__A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = T__0_; if linked_1088 == nil { tmp1 = ifn_1089.Invoke_O__O(arg_1090) } else { tmp1 = linked_1088.(*A_arbace_go_check_types_pointer_QMARK__A).Invoke_O_O__O(root_1087, arg_1090) } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var r__5 any; var root_1091 any = A_arbace_go_check_types_A_const_179.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_1093 lang.IFn
		if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any; var root_1098 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_1099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1098, A_arbace_go_check_types_under_A_fn_class); var ifn_1100 lang.IFn; if linked_1099 == nil { ifn_1100 = lang.IFn_Cast(root_1098) } else { ifn_1100 = nil }; var arg_1101 any = T__0_; if linked_1099 == nil { arg_1094 = ifn_1100.Invoke_O__O(arg_1101) } else { arg_1094 = linked_1099.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1098, arg_1101) }; var arg_1095 any = jrt.Boolean_FALSE.Ref(); var arg_1096 any = name__2; var arg_1097 any = pkg__3; if linked_1092 == nil { r__5 = ifn_1093.Invoke_O_O_O_O__O(arg_1094, arg_1095, arg_1096, arg_1097) } else { r__5 = linked_1092.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_1091, arg_1094, arg_1095, arg_1096, arg_1097) }
		var tmp2 any = A_arbace_go_check_types_A_const_162; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_go_check_types_A_const_161.Invoke_O__O(r__5)) { return nil } else { return r__5 } } else {
			var root_1102 any = A_arbace_go_check_types_A_const_179.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1102, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_1104 lang.IFn; if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any = T__0_; var arg_1106 any = addressable__1; var arg_1107 any = name__2; var arg_1108 any = pkg__3; if linked_1103 == nil { return ifn_1104.Invoke_O_O_O_O__O(arg_1105, arg_1106, arg_1107, arg_1108) } else { return linked_1103.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_1102, arg_1105, arg_1106, arg_1107, arg_1108)
			}
		}
}
func A_arbace_go_check_types_sort_methods_A_New() *A_arbace_go_check_types_sort_methods_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sort_methods_A{}; t.Ctor(); return t }
//line :463:1
func (t *A_arbace_go_check_types_sort_methods_A) Ctor() {}
//line :463:1
func (t *A_arbace_go_check_types_sort_methods_A) Invoke_O_O__O(self, ms__0 any) any {


	var root_1109 any = A_arbace_go_check_types_A_const_180.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1111 lang.IFn; if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any; var root_1113 any = A_arbace_go_check_types_A_const_181.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any; var tmp1 any = A_arbace_go_check_types_sort_methods_fn__219000122_A_New(); var tmp2 *jrt.Class; var fncls__1118 *jrt.Class = A_arbace_go_check_types_sort_methods_fn__219000122_A_fn_class; if fncls__1118 == nil { var fncls__1118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_go_check_types_sort_methods_fn__219000122_A_fn_class = fncls__1118d; tmp2 = fncls__1118d } else { tmp2 = fncls__1118 }; arg_1116 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1117 any = ms__0; if linked_1114 == nil { arg_1112 = ifn_1115.Invoke_O_O__O(arg_1116, arg_1117) } else { arg_1112 = linked_1114.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1113, arg_1116, arg_1117) }; if linked_1110 == nil { return ifn_1111.Invoke_O__O(arg_1112) } else { return linked_1110.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1109, arg_1112) } }
//line :466:1
func A_arbace_go_check_types_sort_methods_fn__219000122_A_New() *A_arbace_go_check_types_sort_methods_fn__219000122_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sort_methods_fn__219000122_A{}; t.Ctor(); return t }
//line :466:1
func (t *A_arbace_go_check_types_sort_methods_fn__219000122_A) Ctor() {}
//line :466:1
func (t *A_arbace_go_check_types_sort_methods_fn__219000122_A) Invoke_O_O__O(self, m__1 any) any { var tmp1 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var tmp2 any; var or__1927000174__auto____2 any = A_arbace_go_check_types_A_const_115.Invoke_O__O(m__1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = Lit_3 }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }

func A_arbace_go_check_types_method_data_A_New() *A_arbace_go_check_types_method_data_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_method_data_A{}; t.Ctor(); return t }
//line :468:1
func (t *A_arbace_go_check_types_method_data_A) Ctor() {}
//line :468:1
func (t *A_arbace_go_check_types_method_data_A) Invoke_O_O__O(self, m__0 any) any {


	var tmp1 any; var root_1119 any = A_arbace_go_check_types_A_const_182.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1121 lang.IFn; if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = m__0; if linked_1120 == nil { tmp1 = ifn_1121.Invoke_O__O(arg_1122) } else { tmp1 = linked_1120.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1119, arg_1122) }; if jrt.J2g_Truth(tmp1) { return m__0 } else { return lang.IFn_Cast(A_arbace_go_check_types_A_const_175.Get__O()).Invoke_O__O(m__0)
	} }
func A_arbace_go_check_types_missing_method_A_New() *A_arbace_go_check_types_missing_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_A{}; t.Ctor(); return t }
//line :473:1
func (t *A_arbace_go_check_types_missing_method_A) Ctor() {}
//line :473:1
func (t *A_arbace_go_check_types_missing_method_A) Invoke_O_O_O_O__O(self, V__0_, T__1_, static__2 any) any { var tu__4 any; var root_1123 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, A_arbace_go_check_types_under_A_fn_class); var ifn_1125 lang.IFn; if




	linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any = T__1_; if linked_1124 == nil { tu__4 = ifn_1125.Invoke_O__O(arg_1126) } else { tu__4 = linked_1124.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1123, arg_1126) }; var vu__5 any; var root_1127 any = /*line :473:1*/A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, A_arbace_go_check_types_under_A_fn_class); var ifn_1129 lang.IFn; if





	linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = V__0_; if linked_1128 == nil { vu__5 = ifn_1129.Invoke_O__O(arg_1130) } else { vu__5 = linked_1128.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1127, arg_1130) }; var root_1131 any =
	A_arbace_go_check_types_A_const_183.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1133 lang.IFn; if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any; var tmp1 any = A_arbace_go_check_types_missing_method_fn__219000126_A_New_O_O_O(static__2, V__0_, vu__5); var tmp2 *jrt.Class; var fncls__1175 *jrt.Class = A_arbace_go_check_types_missing_method_fn__219000126_A_fn_class; if
	fncls__1175 == nil { var fncls__1175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_go_check_types_missing_method_fn__219000126_A_fn_class = fncls__1175d; tmp2 = fncls__1175d } else { tmp2 = fncls__1175 }; arg_1134 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1135 any = /*line :480:1*/lang.RT_Nth_O_I__O_NoInit(tu__4, lang.RT_IntCast_J__I_NoInit(1)); if linked_1132 == nil { return ifn_1133.Invoke_O_O__O(arg_1134, arg_1135) } else { return linked_1132.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1131, arg_1134, arg_1135) } }
func A_arbace_go_check_types_missing_method_fn__219000126_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_types_missing_method_fn__219000126_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_fn__219000126_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :481:1
func (t *A_arbace_go_check_types_missing_method_fn__219000126_A) Ctor_O_O_O(c__static, c__V, c__vu any) { t.F_static = c__static; t.F_V = c__V; t.F_vu = c__vu }
//line :481:1
func (t *A_arbace_go_check_types_missing_method_fn__219000126_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_1136 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1136, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1138 lang.IFn; if linked_1137 == nil { ifn_1138 = lang.IFn_Cast(root_1136) } else { ifn_1138 = nil }; var arg_1139 any = t.F_vu; if linked_1137 == nil { and__1927000168__auto____2 = ifn_1138.Invoke_O__O(arg_1139) } else { and__1927000168__auto____2 = linked_1137.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1136, arg_1139) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_types_A_const_76; var tmp3 any = t.F_vu; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var f__2 any; var root_1140 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1140, A_arbace_go_check_types_iface_method_A_fn_class); var ifn_1142 lang.IFn
		if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var arg_1143 any = t.F_vu; var arg_1144 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var arg_1145 any = A_arbace_go_check_types_A_const_115.Invoke_O__O(m__1); if linked_1141 == nil { f__2 = ifn_1142.Invoke_O_O_O__O(arg_1143, arg_1144, arg_1145) } else { f__2 = linked_1141.(*A_arbace_go_check_types_iface_method_A).Invoke_O_O_O_O__O(root_1140, arg_1143, arg_1144, arg_1145) }
		if lang.Util_Identical_O_O__Z_NoInit(f__2, nil) {
			if jrt.J2g_Truth(t.F_static) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_162, m__1, A_arbace_go_check_types_A_const_184, A_arbace_go_check_types_A_const_185)) } else { return nil } } else {
//line :484:1
				var tmp4 any; var root_1146 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1146, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1148 lang.IFn

				if linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any; var tmp5 *lang.Keyword = A_arbace_go_check_types_A_const_104; var tmp6 any; var root_1151 any = A_arbace_go_check_types_A_const_163.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1153 lang.IFn; if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any = f__2; if linked_1152 == nil { tmp6 = ifn_1153.Invoke_O__O(arg_1154) } else { tmp6 = linked_1152.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1151, arg_1154) }; arg_1149 = tmp5.Invoke_O__O(tmp6); var arg_1150 any = A_arbace_go_check_types_A_const_104.Invoke_O__O(m__1); if linked_1147 == nil { tmp4 = ifn_1148.Invoke_O_O__O(arg_1149, arg_1150) } else { tmp4 = linked_1147.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1146, arg_1149, arg_1150) }
//line :484:1
				if jrt.J2g_Truth(tmp4) { var tmp7 any = A_arbace_go_check_types_A_const_162; var tmp8 any = A_arbace_go_check_types_A_const_184; var tmp9 any = A_arbace_go_check_types_A_const_186; var tmp10 any = A_arbace_go_check_types_A_const_187; var tmp11 any; var root_1155 any = A_arbace_go_check_types_A_const_163.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1157 lang.IFn

					if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any = f__2; if linked_1156 == nil { tmp11 = ifn_1157.Invoke_O__O(arg_1158) } else { tmp11 = linked_1156.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1155, arg_1158) }
//line :484:1
					return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, m__1, tmp8, tmp9, tmp10, tmp11)) } else { return nil } } } else {
//line :482:1
						var r__2 any; var root_1159 any = A_arbace_go_check_types_A_const_179.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1159, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_1161 lang.IFn




						if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = t.F_V; var arg_1163 any = jrt.Boolean_FALSE.Ref(); var arg_1164 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var arg_1165 any = A_arbace_go_check_types_A_const_115.Invoke_O__O(m__1); if linked_1160 == nil { r__2 = ifn_1161.Invoke_O_O_O_O__O(arg_1162, arg_1163, arg_1164, arg_1165) } else { r__2 = linked_1160.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_1159, arg_1162, arg_1163, arg_1164, arg_1165) }
						if jrt.J2g_Truth(A_arbace_go_check_types_A_const_174.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_162, m__1, A_arbace_go_check_types_A_const_184, A_arbace_go_check_types_A_const_174)) } else { if lang.Util_Identical_O_O__Z_NoInit(r__2, nil) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_162, m__1, A_arbace_go_check_types_A_const_184, A_arbace_go_check_types_A_const_185)) } else { if jrt.J2g_Truth(A_arbace_go_check_types_A_const_173.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_162, m__1, A_arbace_go_check_types_A_const_184, A_arbace_go_check_types_A_const_185)) } else { var tmp12 any = A_arbace_go_check_types_A_const_169; if lang.Util_Equiv_O_O__Z_NoInit(tmp12, A_arbace_go_check_types_A_const_161.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_162, m__1, A_arbace_go_check_types_A_const_184, A_arbace_go_check_types_A_const_169)) } else { if A_arbace_go_check_types_A_const_75 != nil { var d__3 any; var root_1166 any = A_arbace_go_check_types_A_const_188.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, A_arbace_go_check_types_method_data_A_fn_class); var ifn_1168 lang.IFn





							if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = A_arbace_go_check_types_A_const_71.Invoke_O__O(r__2); if linked_1167 == nil { d__3 = ifn_1168.Invoke_O__O(arg_1169) } else { d__3 = linked_1167.(*A_arbace_go_check_types_method_data_A).Invoke_O_O__O(root_1166, arg_1169) }
//line :488:1
							var d__4 any; var tmp13 any; var and__1927000168__auto____4 any = A_arbace_go_check_types_A_const_189.Get__O()






							if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp14 any = A_arbace_go_check_types_A_const_162; tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp14, A_arbace_go_check_types_A_const_161.Invoke_O__O(r__2))).Ref() } else { tmp13 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp13) { d__4 = lang.IFn_Cast(A_arbace_go_check_types_A_const_189.Get__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_164.Invoke_O__O(r__2), d__3) } else { d__4 = d__3 }
							var tmp15 any; var root_1170 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1170, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1172 lang.IFn; if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any = A_arbace_go_check_types_A_const_104.Invoke_O__O(d__4); var arg_1174 any = A_arbace_go_check_types_A_const_104.Invoke_O__O(m__1); if linked_1171 == nil { tmp15 = ifn_1172.Invoke_O_O__O(arg_1173, arg_1174) } else { tmp15 = linked_1171.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1170, arg_1173, arg_1174) }; if jrt.J2g_Truth(tmp15) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_162, m__1, A_arbace_go_check_types_A_const_184, A_arbace_go_check_types_A_const_186, A_arbace_go_check_types_A_const_187, d__4)) } else { return nil } } else {
//line :488:1
								return nil
							}
						}
						}
						}
						}
					} }
type A_arbace_go_check_types_A struct{ jrt.Object }

var A_arbace_go_check_types_A_const_pool *jrt.RefArray

var A_arbace_go_check_types_A_const_0 *lang.Var

var A_arbace_go_check_types_A_const_1 any

var A_arbace_go_check_types_A_const_2 any

var A_arbace_go_check_types_A_const_3 *lang.Var

var A_arbace_go_check_types_A_const_4 any

var A_arbace_go_check_types_A_const_5 *lang.Var

var A_arbace_go_check_types_A_const_6 *lang.Var

var A_arbace_go_check_types_A_const_7 *lang.Var

var A_arbace_go_check_types_A_const_8 *lang.Var

var A_arbace_go_check_types_A_const_9 any

var A_arbace_go_check_types_A_const_10 *lang.Var

var A_arbace_go_check_types_A_const_11 *lang.Keyword

var A_arbace_go_check_types_A_const_12 *lang.Keyword

var A_arbace_go_check_types_A_const_13 *lang.Var

var A_arbace_go_check_types_A_const_14 *lang.Keyword

var A_arbace_go_check_types_A_const_15 any

var A_arbace_go_check_types_A_const_16 *lang.Keyword

var A_arbace_go_check_types_A_const_17 *lang.Keyword

var A_arbace_go_check_types_A_const_18 *lang.Keyword

var A_arbace_go_check_types_A_const_19 *lang.Keyword

var A_arbace_go_check_types_A_const_20 any

var A_arbace_go_check_types_A_const_21 *lang.Keyword

var A_arbace_go_check_types_A_const_22 any

var A_arbace_go_check_types_A_const_23 *lang.Keyword

var A_arbace_go_check_types_A_const_24 any

var A_arbace_go_check_types_A_const_25 *lang.Keyword

var A_arbace_go_check_types_A_const_26 *lang.Keyword

var A_arbace_go_check_types_A_const_27 *lang.Keyword

var A_arbace_go_check_types_A_const_28 *lang.Keyword

var A_arbace_go_check_types_A_const_29 *lang.Keyword

var A_arbace_go_check_types_A_const_30 *lang.Keyword

var A_arbace_go_check_types_A_const_31 *lang.Keyword

var A_arbace_go_check_types_A_const_32 *lang.Keyword

var A_arbace_go_check_types_A_const_33 *lang.Keyword

var A_arbace_go_check_types_A_const_34 *lang.Keyword

var A_arbace_go_check_types_A_const_35 *lang.Keyword

var A_arbace_go_check_types_A_const_36 *lang.Keyword

var A_arbace_go_check_types_A_const_37 *lang.Keyword

var A_arbace_go_check_types_A_const_38 *lang.Keyword

var A_arbace_go_check_types_A_const_39 any

var A_arbace_go_check_types_A_const_40 *lang.Keyword

var A_arbace_go_check_types_A_const_41 *lang.Keyword

var A_arbace_go_check_types_A_const_42 *lang.Keyword

var A_arbace_go_check_types_A_const_43 *lang.Keyword

var A_arbace_go_check_types_A_const_44 any

var A_arbace_go_check_types_A_const_45 *lang.Keyword

var A_arbace_go_check_types_A_const_46 *lang.Keyword

var A_arbace_go_check_types_A_const_47 *lang.Keyword

var A_arbace_go_check_types_A_const_48 *lang.Keyword

var A_arbace_go_check_types_A_const_49 *lang.Keyword

var A_arbace_go_check_types_A_const_50 *lang.Keyword

var A_arbace_go_check_types_A_const_51 *lang.Keyword

var A_arbace_go_check_types_A_const_52 *lang.Var

var A_arbace_go_check_types_A_const_53 *lang.Var

var A_arbace_go_check_types_A_const_54 *lang.Keyword

var A_arbace_go_check_types_A_const_55 *lang.Keyword

var A_arbace_go_check_types_A_const_56 *lang.Var

var A_arbace_go_check_types_A_const_57 *lang.Var

var A_arbace_go_check_types_A_const_58 *lang.Var

var A_arbace_go_check_types_A_const_59 *lang.Var

var A_arbace_go_check_types_A_const_60 *lang.Keyword

var A_arbace_go_check_types_A_const_61 *lang.Var

var A_arbace_go_check_types_A_const_62 *lang.Keyword

var A_arbace_go_check_types_A_const_63 *lang.Var

var A_arbace_go_check_types_A_const_64 *lang.Keyword

var A_arbace_go_check_types_A_const_65 *lang.Var

var A_arbace_go_check_types_A_const_66 *lang.Var

var A_arbace_go_check_types_A_const_67 *lang.Keyword

var A_arbace_go_check_types_A_const_68 *lang.Var

var A_arbace_go_check_types_A_const_69 *lang.Var

var A_arbace_go_check_types_A_const_70 *lang.Keyword

var A_arbace_go_check_types_A_const_71 *lang.Keyword

var A_arbace_go_check_types_A_const_72 *lang.Var

var A_arbace_go_check_types_A_const_73 *lang.Var

var A_arbace_go_check_types_A_const_74 *lang.Keyword

var A_arbace_go_check_types_A_const_75 *lang.Keyword

var A_arbace_go_check_types_A_const_76 *lang.Keyword

var A_arbace_go_check_types_A_const_77 *lang.Var

var A_arbace_go_check_types_A_const_78 *lang.Var

var A_arbace_go_check_types_A_const_79 *lang.Var

var A_arbace_go_check_types_A_const_80 *lang.Var

var A_arbace_go_check_types_A_const_81 *lang.Var

var A_arbace_go_check_types_A_const_82 *lang.Var

var A_arbace_go_check_types_A_const_83 *lang.Var

var A_arbace_go_check_types_A_const_84 *lang.Var

var A_arbace_go_check_types_A_const_85 any

var A_arbace_go_check_types_A_const_86 *lang.Var

var A_arbace_go_check_types_A_const_87 *lang.Keyword

var A_arbace_go_check_types_A_const_88 *lang.Var

var A_arbace_go_check_types_A_const_89 *lang.Var

var A_arbace_go_check_types_A_const_90 any

var A_arbace_go_check_types_A_const_91 *lang.Var

var A_arbace_go_check_types_A_const_92 *lang.Keyword

var A_arbace_go_check_types_A_const_93 *lang.Keyword

var A_arbace_go_check_types_A_const_94 *lang.Keyword

var A_arbace_go_check_types_A_const_95 *lang.Keyword

var A_arbace_go_check_types_A_const_96 *lang.Var

var A_arbace_go_check_types_A_const_97 *lang.Keyword

var A_arbace_go_check_types_A_const_98 any

var A_arbace_go_check_types_A_const_99 *lang.Var

var A_arbace_go_check_types_A_const_100 *lang.Keyword

var A_arbace_go_check_types_A_const_101 *lang.Var

var A_arbace_go_check_types_A_const_102 *lang.Keyword

var A_arbace_go_check_types_A_const_103 *lang.Keyword

var A_arbace_go_check_types_A_const_104 *lang.Keyword

var A_arbace_go_check_types_A_const_105 *lang.Var

var A_arbace_go_check_types_A_const_106 *lang.Var

var A_arbace_go_check_types_A_const_107 *lang.Var

var A_arbace_go_check_types_A_const_108 *lang.Var

var A_arbace_go_check_types_A_const_109 *lang.Var

var A_arbace_go_check_types_A_const_110 *lang.Var

var A_arbace_go_check_types_A_const_111 *lang.Var

var A_arbace_go_check_types_A_const_112 *lang.Keyword

var A_arbace_go_check_types_A_const_113 *lang.Var

var A_arbace_go_check_types_A_const_114 *lang.Var

var A_arbace_go_check_types_A_const_115 *lang.Keyword

var A_arbace_go_check_types_A_const_116 *lang.Var

var A_arbace_go_check_types_A_const_117 *lang.Keyword

var A_arbace_go_check_types_A_const_118 *lang.Keyword

var A_arbace_go_check_types_A_const_119 *lang.Var

var A_arbace_go_check_types_A_const_120 *lang.Keyword

var A_arbace_go_check_types_A_const_121 *lang.Var

var A_arbace_go_check_types_A_const_122 *lang.Var

var A_arbace_go_check_types_A_const_123 *lang.Var

var A_arbace_go_check_types_A_const_124 *lang.Keyword

var A_arbace_go_check_types_A_const_125 *lang.Keyword

var A_arbace_go_check_types_A_const_126 *lang.Keyword

var A_arbace_go_check_types_A_const_127 *lang.Var

var A_arbace_go_check_types_A_const_128 *lang.Var

var A_arbace_go_check_types_A_const_129 *lang.Var

var A_arbace_go_check_types_A_const_130 *lang.Var

var A_arbace_go_check_types_A_const_131 *lang.Var

var A_arbace_go_check_types_A_const_132 *lang.Var

var A_arbace_go_check_types_A_const_133 *lang.Var

var A_arbace_go_check_types_A_const_134 *lang.Var

var A_arbace_go_check_types_A_const_135 *lang.Var

var A_arbace_go_check_types_A_const_136 *lang.Var

var A_arbace_go_check_types_A_const_137 any

var A_arbace_go_check_types_A_const_138 *lang.Var

var A_arbace_go_check_types_A_const_139 *lang.Var

var A_arbace_go_check_types_A_const_140 *lang.Var

var A_arbace_go_check_types_A_const_141 any

var A_arbace_go_check_types_A_const_142 *lang.Var

var A_arbace_go_check_types_A_const_143 *lang.Var

var A_arbace_go_check_types_A_const_144 *lang.Var

var A_arbace_go_check_types_A_const_145 *lang.Var

var A_arbace_go_check_types_A_const_146 *lang.Var

var A_arbace_go_check_types_A_const_147 *lang.Var

var A_arbace_go_check_types_A_const_148 *lang.Keyword

var A_arbace_go_check_types_A_const_149 *lang.Var

var A_arbace_go_check_types_A_const_150 *lang.Var

var A_arbace_go_check_types_A_const_151 *lang.Var

var A_arbace_go_check_types_A_const_152 *lang.Var

var A_arbace_go_check_types_A_const_153 *lang.Var

var A_arbace_go_check_types_A_const_154 *lang.Var

var A_arbace_go_check_types_A_const_155 *lang.Keyword

var A_arbace_go_check_types_A_const_156 *lang.Var

var A_arbace_go_check_types_A_const_157 *lang.Var

var A_arbace_go_check_types_A_const_158 *lang.Var

var A_arbace_go_check_types_A_const_159 *lang.Var

var A_arbace_go_check_types_A_const_160 any

var A_arbace_go_check_types_A_const_161 *lang.Keyword

var A_arbace_go_check_types_A_const_162 *lang.Keyword

var A_arbace_go_check_types_A_const_163 *lang.Var

var A_arbace_go_check_types_A_const_164 *lang.Keyword

var A_arbace_go_check_types_A_const_165 *lang.Keyword

var A_arbace_go_check_types_A_const_166 *lang.Keyword

var A_arbace_go_check_types_A_const_167 *lang.Keyword

var A_arbace_go_check_types_A_const_168 any

var A_arbace_go_check_types_A_const_169 *lang.Keyword

var A_arbace_go_check_types_A_const_170 any

var A_arbace_go_check_types_A_const_171 *lang.Keyword

var A_arbace_go_check_types_A_const_172 *lang.Keyword

var A_arbace_go_check_types_A_const_173 *lang.Keyword

var A_arbace_go_check_types_A_const_174 *lang.Keyword

var A_arbace_go_check_types_A_const_175 *lang.Var

var A_arbace_go_check_types_A_const_176 *lang.Keyword

var A_arbace_go_check_types_A_const_177 *lang.Var

var A_arbace_go_check_types_A_const_178 *lang.Var

var A_arbace_go_check_types_A_const_179 *lang.Var

var A_arbace_go_check_types_A_const_180 *lang.Var

var A_arbace_go_check_types_A_const_181 *lang.Var

var A_arbace_go_check_types_A_const_182 *lang.Var

var A_arbace_go_check_types_A_const_183 *lang.Var

var A_arbace_go_check_types_A_const_184 *lang.Keyword

var A_arbace_go_check_types_A_const_185 *lang.Keyword

var A_arbace_go_check_types_A_const_186 *lang.Keyword

var A_arbace_go_check_types_A_const_187 *lang.Keyword

var A_arbace_go_check_types_A_const_188 *lang.Var

var A_arbace_go_check_types_A_const_189 *lang.Var

var A_arbace_go_check_types_A_init jrt.ClassInit

func A_arbace_go_check_types_A_Init() { if !A_arbace_go_check_types_A_init.Done() { A_arbace_go_check_types_A_init.Run(A_arbace_go_check_types_A_clinit) } }

func A_arbace_go_check_types_A_clinit() { A_arbace_go_check_types_A_clinit_p0(); A_arbace_go_check_types_A_clinit_p1(); A_arbace_go_check_types_A_clinit_p2(); A_arbace_go_check_types_A_clinit_p3(); A_arbace_go_check_types_A_clinit_p4(); A_arbace_go_check_types_A_clinit_p5(); A_arbace_go_check_types_A_clinit_p6(); A_arbace_go_check_types_A_clinit_p7(); A_arbace_go_check_types_A_clinit_p8(); A_arbace_go_check_types_A_clinit_p9(); A_arbace_go_check_types_A_clinit_p10(); A_arbace_go_check_types_A_clinit_p11(); A_arbace_go_check_types_A_clinit_p12(); A_arbace_go_check_types_A_clinit_p13(); A_arbace_go_check_types_A_clinit_p14(); A_arbace_go_check_types_A_clinit_p15() }

func A_arbace_go_check_types_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_types_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 278); A_arbace_go_check_types_A_const_0 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[88]); A_arbace_go_check_types_A_const_1 = A_arbace_go_check_types_A_const_pool.A[89]; A_arbace_go_check_types_A_const_2 = A_arbace_go_check_types_A_const_pool.A[90]; A_arbace_go_check_types_A_const_3 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[91]); A_arbace_go_check_types_A_const_4 = A_arbace_go_check_types_A_const_pool.A[92]; A_arbace_go_check_types_A_const_5 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[93]); A_arbace_go_check_types_A_const_6 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[94]); A_arbace_go_check_types_A_const_7 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[95]); A_arbace_go_check_types_A_const_8 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[96]); A_arbace_go_check_types_A_const_9 = A_arbace_go_check_types_A_const_pool.A[97]; A_arbace_go_check_types_A_const_10 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[98]); A_arbace_go_check_types_A_const_11 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[99]) }

func A_arbace_go_check_types_A_clinit_p1() { A_arbace_go_check_types_A_const_12 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[100]); A_arbace_go_check_types_A_const_13 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[101]); A_arbace_go_check_types_A_const_14 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[102]); A_arbace_go_check_types_A_const_15 = A_arbace_go_check_types_A_const_pool.A[103]; A_arbace_go_check_types_A_const_16 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[104]); A_arbace_go_check_types_A_const_17 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[105]); A_arbace_go_check_types_A_const_18 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[106]); A_arbace_go_check_types_A_const_19 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[107]); A_arbace_go_check_types_A_const_20 = A_arbace_go_check_types_A_const_pool.A[108]; A_arbace_go_check_types_A_const_21 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[109]); A_arbace_go_check_types_A_const_22 = A_arbace_go_check_types_A_const_pool.A[110]; A_arbace_go_check_types_A_const_23 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[111]); A_arbace_go_check_types_A_const_24 = A_arbace_go_check_types_A_const_pool.A[112] }

func A_arbace_go_check_types_A_clinit_p2() { A_arbace_go_check_types_A_const_25 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[113]); A_arbace_go_check_types_A_const_26 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[114]); A_arbace_go_check_types_A_const_27 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[115]); A_arbace_go_check_types_A_const_28 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[116]); A_arbace_go_check_types_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[117]); A_arbace_go_check_types_A_const_30 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[118]); A_arbace_go_check_types_A_const_31 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[119]); A_arbace_go_check_types_A_const_32 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[120]); A_arbace_go_check_types_A_const_33 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[121]); A_arbace_go_check_types_A_const_34 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[122]); A_arbace_go_check_types_A_const_35 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[123]); A_arbace_go_check_types_A_const_36 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[124]) }

func A_arbace_go_check_types_A_clinit_p3() { A_arbace_go_check_types_A_const_37 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[125]); A_arbace_go_check_types_A_const_38 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[126]); A_arbace_go_check_types_A_const_39 = A_arbace_go_check_types_A_const_pool.A[127]; A_arbace_go_check_types_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[128]); A_arbace_go_check_types_A_const_41 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[129]); A_arbace_go_check_types_A_const_42 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[130]); A_arbace_go_check_types_A_const_43 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[131]); A_arbace_go_check_types_A_const_44 = A_arbace_go_check_types_A_const_pool.A[132]; A_arbace_go_check_types_A_const_45 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[133]); A_arbace_go_check_types_A_const_46 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[134]); A_arbace_go_check_types_A_const_47 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[135]); A_arbace_go_check_types_A_const_48 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[136]) }

func A_arbace_go_check_types_A_clinit_p4() { A_arbace_go_check_types_A_const_49 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[137]); A_arbace_go_check_types_A_const_50 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[138]); A_arbace_go_check_types_A_const_51 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[139]); A_arbace_go_check_types_A_const_52 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[140]); A_arbace_go_check_types_A_const_53 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[141]); A_arbace_go_check_types_A_const_54 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[142]); A_arbace_go_check_types_A_const_55 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[143]); A_arbace_go_check_types_A_const_56 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[144]); A_arbace_go_check_types_A_const_57 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[145]); A_arbace_go_check_types_A_const_58 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[146]); A_arbace_go_check_types_A_const_59 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[147]); A_arbace_go_check_types_A_const_60 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[148]) }

func A_arbace_go_check_types_A_clinit_p5() { A_arbace_go_check_types_A_const_61 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[149]); A_arbace_go_check_types_A_const_62 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[150]); A_arbace_go_check_types_A_const_63 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[151]); A_arbace_go_check_types_A_const_64 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[152]); A_arbace_go_check_types_A_const_65 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[153]); A_arbace_go_check_types_A_const_66 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[154]); A_arbace_go_check_types_A_const_67 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[155]); A_arbace_go_check_types_A_const_68 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[156]); A_arbace_go_check_types_A_const_69 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[157]); A_arbace_go_check_types_A_const_70 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[158]); A_arbace_go_check_types_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[159]); A_arbace_go_check_types_A_const_72 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[160]) }

func A_arbace_go_check_types_A_clinit_p6() { A_arbace_go_check_types_A_const_73 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[161]); A_arbace_go_check_types_A_const_74 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[162]); A_arbace_go_check_types_A_const_75 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[163]); A_arbace_go_check_types_A_const_76 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[164]); A_arbace_go_check_types_A_const_77 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[165]); A_arbace_go_check_types_A_const_78 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[166]); A_arbace_go_check_types_A_const_79 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[167]); A_arbace_go_check_types_A_const_80 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[168]); A_arbace_go_check_types_A_const_81 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[169]); A_arbace_go_check_types_A_const_82 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[170]); A_arbace_go_check_types_A_const_83 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[171]); A_arbace_go_check_types_A_const_84 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[172]) }

func A_arbace_go_check_types_A_clinit_p7() { A_arbace_go_check_types_A_const_85 = A_arbace_go_check_types_A_const_pool.A[173]; A_arbace_go_check_types_A_const_86 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[174]); A_arbace_go_check_types_A_const_87 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[175]); A_arbace_go_check_types_A_const_88 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[176]); A_arbace_go_check_types_A_const_89 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[177]); A_arbace_go_check_types_A_const_90 = A_arbace_go_check_types_A_const_pool.A[178]; A_arbace_go_check_types_A_const_91 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[179]); A_arbace_go_check_types_A_const_92 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[180]); A_arbace_go_check_types_A_const_93 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[181]); A_arbace_go_check_types_A_const_94 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[182]); A_arbace_go_check_types_A_const_95 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[183]); A_arbace_go_check_types_A_const_96 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[184]) }

func A_arbace_go_check_types_A_clinit_p8() { A_arbace_go_check_types_A_const_97 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[185]); A_arbace_go_check_types_A_const_98 = A_arbace_go_check_types_A_const_pool.A[186]; A_arbace_go_check_types_A_const_99 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[187]); A_arbace_go_check_types_A_const_100 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[188]); A_arbace_go_check_types_A_const_101 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[189]); A_arbace_go_check_types_A_const_102 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[190]); A_arbace_go_check_types_A_const_103 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[191]); A_arbace_go_check_types_A_const_104 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[192]); A_arbace_go_check_types_A_const_105 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[193]); A_arbace_go_check_types_A_const_106 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[194]); A_arbace_go_check_types_A_const_107 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[195]); A_arbace_go_check_types_A_const_108 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[196]) }

func A_arbace_go_check_types_A_clinit_p9() { A_arbace_go_check_types_A_const_109 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[197]); A_arbace_go_check_types_A_const_110 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[198]); A_arbace_go_check_types_A_const_111 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[199]); A_arbace_go_check_types_A_const_112 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[200]); A_arbace_go_check_types_A_const_113 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[201]); A_arbace_go_check_types_A_const_114 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[202]); A_arbace_go_check_types_A_const_115 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[203]); A_arbace_go_check_types_A_const_116 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[204]); A_arbace_go_check_types_A_const_117 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[205]); A_arbace_go_check_types_A_const_118 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[206]); A_arbace_go_check_types_A_const_119 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[207]); A_arbace_go_check_types_A_const_120 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[208]) }

func A_arbace_go_check_types_A_clinit_p10() { A_arbace_go_check_types_A_const_121 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[209]); A_arbace_go_check_types_A_const_122 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[210]); A_arbace_go_check_types_A_const_123 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[211]); A_arbace_go_check_types_A_const_124 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[212]); A_arbace_go_check_types_A_const_125 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[213]); A_arbace_go_check_types_A_const_126 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[214]); A_arbace_go_check_types_A_const_127 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[215]); A_arbace_go_check_types_A_const_128 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[216]); A_arbace_go_check_types_A_const_129 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[217]); A_arbace_go_check_types_A_const_130 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[218]); A_arbace_go_check_types_A_const_131 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[219]); A_arbace_go_check_types_A_const_132 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[220]) }

func A_arbace_go_check_types_A_clinit_p11() { A_arbace_go_check_types_A_const_133 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[221]); A_arbace_go_check_types_A_const_134 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[222]); A_arbace_go_check_types_A_const_135 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[223]); A_arbace_go_check_types_A_const_136 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[224]); A_arbace_go_check_types_A_const_137 = A_arbace_go_check_types_A_const_pool.A[225]; A_arbace_go_check_types_A_const_138 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[226]); A_arbace_go_check_types_A_const_139 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[227]); A_arbace_go_check_types_A_const_140 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[228]); A_arbace_go_check_types_A_const_141 = A_arbace_go_check_types_A_const_pool.A[229]; A_arbace_go_check_types_A_const_142 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[230]); A_arbace_go_check_types_A_const_143 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[231]); A_arbace_go_check_types_A_const_144 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[232]) }

func A_arbace_go_check_types_A_clinit_p12() { A_arbace_go_check_types_A_const_145 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[233]); A_arbace_go_check_types_A_const_146 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[234]); A_arbace_go_check_types_A_const_147 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[235]); A_arbace_go_check_types_A_const_148 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[236]); A_arbace_go_check_types_A_const_149 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[237]); A_arbace_go_check_types_A_const_150 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[238]); A_arbace_go_check_types_A_const_151 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[239]); A_arbace_go_check_types_A_const_152 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[240]); A_arbace_go_check_types_A_const_153 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[241]); A_arbace_go_check_types_A_const_154 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[242]); A_arbace_go_check_types_A_const_155 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[243]); A_arbace_go_check_types_A_const_156 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[244]) }

func A_arbace_go_check_types_A_clinit_p13() { A_arbace_go_check_types_A_const_157 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[245]); A_arbace_go_check_types_A_const_158 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[246]); A_arbace_go_check_types_A_const_159 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[247]); A_arbace_go_check_types_A_const_160 = A_arbace_go_check_types_A_const_pool.A[248]; A_arbace_go_check_types_A_const_161 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[249]); A_arbace_go_check_types_A_const_162 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[250]); A_arbace_go_check_types_A_const_163 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[251]); A_arbace_go_check_types_A_const_164 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[252]); A_arbace_go_check_types_A_const_165 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[253]); A_arbace_go_check_types_A_const_166 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[254]); A_arbace_go_check_types_A_const_167 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[255]); A_arbace_go_check_types_A_const_168 = A_arbace_go_check_types_A_const_pool.A[256] }

func A_arbace_go_check_types_A_clinit_p14() { A_arbace_go_check_types_A_const_169 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[257]); A_arbace_go_check_types_A_const_170 = A_arbace_go_check_types_A_const_pool.A[258]; A_arbace_go_check_types_A_const_171 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[259]); A_arbace_go_check_types_A_const_172 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[260]); A_arbace_go_check_types_A_const_173 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[261]); A_arbace_go_check_types_A_const_174 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[262]); A_arbace_go_check_types_A_const_175 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[263]); A_arbace_go_check_types_A_const_176 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[264]); A_arbace_go_check_types_A_const_177 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[265]); A_arbace_go_check_types_A_const_178 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[266]); A_arbace_go_check_types_A_const_179 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[267]); A_arbace_go_check_types_A_const_180 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[268]) }

func A_arbace_go_check_types_A_clinit_p15() { A_arbace_go_check_types_A_const_181 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[269]); A_arbace_go_check_types_A_const_182 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[270]); A_arbace_go_check_types_A_const_183 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[271]); A_arbace_go_check_types_A_const_184 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[272]); A_arbace_go_check_types_A_const_185 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[273]); A_arbace_go_check_types_A_const_186 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[274]); A_arbace_go_check_types_A_const_187 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[275]); A_arbace_go_check_types_A_const_188 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[276]); A_arbace_go_check_types_A_const_189 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[277]) }

func A_arbace_go_check_types_A_New() *A_arbace_go_check_types_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_A) Ctor() {}

func (t *A_arbace_go_check_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_A_class }

func (t *A_arbace_go_check_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_A); return ok }

func A_arbace_go_check_types_A_Cast(x any) *A_arbace_go_check_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_A_class)) }; return v }



type A_arbace_go_check_types_align_up_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_align_up_A_fn_class *jrt.Class



type A_arbace_go_check_types_alignof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alignof_A_fn_class *jrt.Class



type A_arbace_go_check_types_alignof_fn__219000089_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alignof_fn__219000089_A_fn_class *jrt.Class



type A_arbace_go_check_types_basic_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_basic_A_fn_class *jrt.Class



type A_arbace_go_check_types_boolean_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_boolean_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_QMARK__fn__219000060_A struct{ j2g_header uint64; F_seen any }

var A_arbace_go_check_types_comparable_QMARK__fn__219000060_A_fn_class *jrt.Class



type A_arbace_go_check_types_complex_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_complex_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_consolidate_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_consolidate_A_fn_class *jrt.Class



type A_arbace_go_check_types_const_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_const_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_default_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_default_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_deref_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_deref_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_empty_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_empty_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_eval219000004_A struct{ jrt.Object }

func A_arbace_go_check_types_eval219000004_A_New() *A_arbace_go_check_types_eval219000004_A { t := &A_arbace_go_check_types_eval219000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_eval219000004_A) Ctor() {}

func (t *A_arbace_go_check_types_eval219000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_eval219000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_eval219000004_A_class }

func (t *A_arbace_go_check_types_eval219000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_eval219000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_eval219000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_eval219000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_eval219000004_A); return ok }

func A_arbace_go_check_types_eval219000004_A_Cast(x any) *A_arbace_go_check_types_eval219000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_eval219000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_eval219000004_A_class)) }; return v }



type A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_fn_class *jrt.Class



type A_arbace_go_check_types_eval219000008_A struct{ jrt.Object }

func A_arbace_go_check_types_eval219000008_A_New() *A_arbace_go_check_types_eval219000008_A { t := &A_arbace_go_check_types_eval219000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_eval219000008_A) Ctor() {}

func (t *A_arbace_go_check_types_eval219000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_eval219000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_eval219000008_A_class }

func (t *A_arbace_go_check_types_eval219000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_eval219000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_eval219000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_eval219000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_eval219000008_A); return ok }

func A_arbace_go_check_types_eval219000008_A_Cast(x any) *A_arbace_go_check_types_eval219000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_eval219000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_eval219000008_A_class)) }; return v }



type A_arbace_go_check_types_eval219000008_fn__219000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_eval219000008_fn__219000009_A_fn_class *jrt.Class



type A_arbace_go_check_types_exported_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_exported_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_field_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_field_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_flag_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_flag_A_fn_class *jrt.Class



type A_arbace_go_check_types_float_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_float_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_m__219000013_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class *jrt.Class



type A_arbace_go_check_types_has_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_name_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_has_nil_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_nil_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_identical_ignore_tags_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_identical_ignore_tags_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_iface_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_iface_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_ignore_tags_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ignore_tags_A_fn_class *jrt.Class



type A_arbace_go_check_types_ignore_tags_fn__219000054_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ignore_tags_fn__219000054_A_fn_class *jrt.Class



type A_arbace_go_check_types_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_info_A_fn_class *jrt.Class



type A_arbace_go_check_types_integer_or_float_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_integer_or_float_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_integer_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_integer_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_kind_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_kind_of_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_lookup_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_impl_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_lookup_impl_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_impl_fn__219000112_A struct{ j2g_header uint64; F_pkg, F_name any }

var A_arbace_go_check_types_lookup_impl_fn__219000112_A_fn_class *jrt.Class



type A_arbace_go_check_types_method_data_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_method_data_A_fn_class *jrt.Class



type A_arbace_go_check_types_methods_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_methods_of_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_missing_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_fn__219000126_A struct{ j2g_header uint64; F_static, F_V, F_vu any }

var A_arbace_go_check_types_missing_method_fn__219000126_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_named_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_new_named_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_new_named_A_fn_class *jrt.Class



type A_arbace_go_check_types_new_tparam_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_new_tparam_A_fn_class *jrt.Class



type A_arbace_go_check_types_next_id_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_next_id_A_fn_class *jrt.Class



type A_arbace_go_check_types_numeric_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_offsetsof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_offsetsof_A_fn_class *jrt.Class



type A_arbace_go_check_types_ordered_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ordered_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_params_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_params_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_params_str_fn__219000063_A struct{ j2g_header uint64; F_ps, F_variadic any }

var A_arbace_go_check_types_params_str_fn__219000063_A_fn_class *jrt.Class



type A_arbace_go_check_types_pointer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_pointer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_same_id_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_same_id_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_sig_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sig_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_sizeof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sizeof_A_fn_class *jrt.Class



type A_arbace_go_check_types_sort_methods_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sort_methods_A_fn_class *jrt.Class



type A_arbace_go_check_types_sort_methods_fn__219000122_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sort_methods_fn__219000122_A_fn_class *jrt.Class



type A_arbace_go_check_types_string_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_string_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_sync_atomic_align64_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_type_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000076__219000080_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_type_str_iter__219000076__219000080_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_A struct{ j2g_header uint64; F_iter__219000076, F_s__219000077 any }

var A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_fn__219000082_A struct{ j2g_header uint64; F_b__219000079 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_type_str_iter__219000076__219000080_fn__219000081_fn__219000082_A_fn_class *jrt.Class



type A_arbace_go_check_types_typed_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typed_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_uintptr_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_uintptr_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_unsafe_pointer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_unsafe_pointer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_unsigned_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_unsigned_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_untyped_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_untyped_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_update_info_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_update_info_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_types_valid_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_valid_QMARK__A_fn_class *jrt.Class
