//line aot_arbace_go_check_types.ae:1
package aot_arbace_go_check_types

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_const"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_New() *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_types_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_types_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_go_check_types_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_1, A_arbace_go_check_types_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_types_eval219000008_fn__219000009_A_New() *A_arbace_go_check_types_eval219000008_fn__219000009_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_eval219000008_fn__219000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_types_eval219000008_fn__219000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_types_eval219000008_fn__219000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_go_check_types_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_types_A_const_8.GetRawRoot__O(), A_arbace_go_check_types_A_const_9) }






















func A_arbace_go_check_types_fn__219000012_A_New() *A_arbace_go_check_types_fn__219000012_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_A) Invoke_O__O(self any) any { var m__1 any; var tmp1 any = A_arbace_go_check_types_fn__219000012_m__219000013_A_New(); var tmp2 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, true); A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class = fncls__31d; tmp2 = fncls__31d } else { tmp2 = fncls__31 }; m__1 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp1, tmp2, nil, 2); var root_32 any =
										A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_36 any = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_14, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_16), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_17, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_19, A_arbace_go_check_types_A_const_20, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_21, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_23, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_25, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_26, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_28, A_arbace_go_check_types_A_const_20, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_29, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_30, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_31, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_32, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_33, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_34), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_35, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_34), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_36, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_37), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_38, A_arbace_go_check_types_A_const_39, A_arbace_go_check_types_A_const_37), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_40, A_arbace_go_check_types_A_const_39, A_arbace_go_check_types_A_const_41), lang.IFn_Cast(m__1).Invoke_O_O__O(A_arbace_go_check_types_A_const_42, A_arbace_go_check_types_A_const_24), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_43, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_16, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_46, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_47, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_48, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_34, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_49, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_37, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_50, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_41, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_51, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_52, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_53, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_18))); if linked_33 == nil { return ifn_34.Invoke_O_O__O(arg_35, arg_36) } else { return linked_33.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_32, arg_35, arg_36) } }
//line :24:1
func A_arbace_go_check_types_fn__219000012_m__219000013_A_New() *A_arbace_go_check_types_fn__219000012_m__219000013_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_m__219000013_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_A) DoInvoke_O_O_O_O__O(self, n__1, size__2, flags__3 any) any { var tmp1 any; var root_20 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_11, size__2, A_arbace_go_check_types_A_const_12, n__1)); var arg_24 any; var root_25 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any; var tmp2 any = A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; arg_28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_29 any = flags__3; if linked_26 == nil { arg_24 = ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { arg_24 = linked_26.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) }; if linked_21 == nil { tmp1 = ifn_22.Invoke_O_O__O(arg_23, arg_24) } else { tmp1 = linked_21.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_20, arg_23, arg_24) }; return lang.Tuple_Create_O_O__IPersistentVector(n__1, tmp1) }
//line :24:1
func A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_New() *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A) Invoke_O_O__O(self, f__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(f__1, jrt.Boolean_TRUE.Ref()) }













































func A_arbace_go_check_types_kw_alias_A_New() *A_arbace_go_check_types_kw_alias_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_kw_alias_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_go_check_types_kw_alias_A) Ctor() {}
//line :70:1
func (t *A_arbace_go_check_types_kw_alias_A) Invoke_O_O_O_O_O_O_O__O(self, x__0, name__1, pkg__2, pkg_name__3, local__4, actual__5 any) any { var k__7 any; var root_37 any = A_arbace_go_check_types_A_const_54.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_39 lang.IFn; if



	linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = Lit_20; var arg_41 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_21, nil, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.System_IdentityHashCode_O__I(x__0)).Ref(), nil, name__1)).Ref(); if linked_38 == nil { k__7 = ifn_39.Invoke_O_O__O(arg_40, arg_41) } else { k__7 = linked_38.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O_O__O(root_37, arg_40, arg_41) };
	jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_go_check_types_A_const_55.GetRawRoot__O())).PutIfAbsent_O_O__O(k__7, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_56, actual__5, A_arbace_go_check_types_A_const_12, name__1, A_arbace_go_check_types_A_const_57, pkg__2, A_arbace_go_check_types_A_const_58, pkg_name__3, A_arbace_go_check_types_A_const_59, local__4, A_arbace_go_check_types_A_const_60, x__0))); return k__7 }



func A_arbace_go_check_types_kw_alias_info_A_New() *A_arbace_go_check_types_kw_alias_info_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_kw_alias_info_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_go_check_types_kw_alias_info_A) Ctor() {}
//line :79:1
func (t *A_arbace_go_check_types_kw_alias_info_A) Invoke_O_O__O(self, k__0 any) any { var tmp1 any; var root_42 any = A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = k__0; if linked_43 == nil { tmp1 = ifn_44.Invoke_O__O(arg_45) } else { tmp1 = linked_43.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_42, arg_45) }; if jrt.J2g_Truth(tmp1) { return jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_go_check_types_A_const_55.GetRawRoot__O())).Get_O__O(k__0) } else { return nil } }

func A_arbace_go_check_types_canon_kw_A_New() *A_arbace_go_check_types_canon_kw_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_canon_kw_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_go_check_types_canon_kw_A) Ctor() {}
//line :81:1
func (t *A_arbace_go_check_types_canon_kw_A) Invoke_O_O__O(self, t__0 any) any { var G__219000020__2_ any = t__0; switch


	lang.Util_Hash_O__I_NoInit(G__219000020__2_) >> 1 & 1 { case 0: if any(G__219000020__2_) == any(A_arbace_go_check_types_A_const_52) { return A_arbace_go_check_types_A_const_26 }; case 1: if any(G__219000020__2_) == any(A_arbace_go_check_types_A_const_53) { return A_arbace_go_check_types_A_const_21 }; default:}; var tmp1 any; var root_47 any =


	A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = t__0; if linked_48 == nil { tmp1 = ifn_49.Invoke_O__O(arg_50) } else { tmp1 = linked_48.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_47, arg_50) }; if jrt.J2g_Truth(tmp1) { var temp__1927000408__auto____3 any; var root_51 any = A_arbace_go_check_types_A_const_62.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, A_arbace_go_check_types_kw_alias_info_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = t__0; if linked_52 == nil { temp__1927000408__auto____3 = ifn_53.Invoke_O__O(arg_54) } else { temp__1927000408__auto____3 = linked_52.(*A_arbace_go_check_types_kw_alias_info_A).Invoke_O_O__O(root_51, arg_54) }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var a__4 any = temp__1927000408__auto____3; var root_55 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, A_arbace_go_check_types_canon_kw_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = A_arbace_go_check_types_A_const_56.Invoke_O__O(a__4); if linked_56 == nil { return ifn_57.Invoke_O__O(arg_58) } else { return linked_56.(*A_arbace_go_check_types_canon_kw_A).Invoke_O_O__O(root_55, arg_58) } } else { return t__0 } } else { return t__0 } }



func A_arbace_go_check_types_map_same_A_New() *A_arbace_go_check_types_map_same_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_map_same_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_go_check_types_map_same_A) Ctor() {}
//line :91:1
func (t *A_arbace_go_check_types_map_same_A) Invoke_O_O_O__O(self, f__0, v__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(v__1); var i__4 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, int64(n__3)) { var x__5 any = lang.RT_Nth_O_I__O_NoInit(v__1, lang.RT_IntCast_J__I_NoInit(i__4)); var c__6 any = lang.IFn_Cast(f__0).Invoke_O__O(x__5)

		if lang.Util_Identical_O_O__Z_NoInit(x__5, c__6) {
			i__4 = lang.Numbers_Inc_J__J_NoInit(i__4); continue L1 } else {
				var root_59 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any; var root_65 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any; var root_70 any = A_arbace_go_check_types_A_const_64.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = v__1; var arg_74 any = A_arbace_go_check_types_A_const_44; var arg_75 any = jrt.Long_ValueOf_J__Long_NoInit(i__4).Ref(); if linked_71 == nil { arg_68 = ifn_72.Invoke_O_O_O__O(arg_73, arg_74, arg_75) } else { arg_68 = linked_71.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_70, arg_73, arg_74, arg_75) }; var arg_69 any = c__6; if linked_66 == nil { arg_62 = ifn_67.Invoke_O_O__O(arg_68, arg_69) } else { arg_62 = linked_66.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_65, arg_68, arg_69) }; var arg_63 any; var root_76 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = f__0; if linked_77 == nil { arg_63 = ifn_78.Invoke_O__O(arg_79) } else { arg_63 = linked_77.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_76, arg_79) }; var arg_64 any; var root_80 any = A_arbace_go_check_types_A_const_64.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = v__1; var arg_84 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(i__4)).Ref(); if linked_81 == nil { arg_64 = ifn_82.Invoke_O_O__O(arg_83, arg_84) } else { arg_64 = linked_81.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O__O(root_80, arg_83, arg_84) }; if linked_60 == nil { return ifn_61.Invoke_O_O_O__O(arg_62, arg_63, arg_64) } else { return linked_60.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_59, arg_62, arg_63, arg_64) } } } else {
//line :96:1
					return v__1 } } }; /*line :91:1*/panic("j2g: unreachable") }











func A_arbace_go_check_types_canon_member_A_New() *A_arbace_go_check_types_canon_member_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_canon_member_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_go_check_types_canon_member_A) Ctor() {}
//line :103:1
func (t *A_arbace_go_check_types_canon_member_A) Invoke_O_O__O(self, m__0 any) any { var ty__2 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(m__0); var c__3 any; var root_85 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, A_arbace_go_check_types_canon_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = ty__2; if linked_86 == nil { c__3 = ifn_87.Invoke_O__O(arg_88) } else { c__3 = linked_86.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_85, arg_88) }; if lang.Util_Identical_O_O__Z_NoInit(ty__2, c__3) { return m__0 } else { var root_89 any = A_arbace_go_check_types_A_const_67.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = m__0; var arg_93 any = A_arbace_go_check_types_A_const_65; var arg_94 any = c__3; if linked_90 == nil { return ifn_91.Invoke_O_O_O__O(arg_92, arg_93, arg_94) } else { return linked_90.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_89, arg_92, arg_93, arg_94) } } }

func A_arbace_go_check_types_canon_vec_A_New() *A_arbace_go_check_types_canon_vec_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_canon_vec_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_go_check_types_canon_vec_A) Ctor() {}
//line :105:1
func (t *A_arbace_go_check_types_canon_vec_A) Invoke_O_O__O(self, t__0 any) any { var re__2 any; var tmp1 any = A_arbace_go_check_types_canon_vec_re__219000024_A_New_O(t__0); var tmp2 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_go_check_types_canon_vec_re__219000024_A_fn_class; if
										fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_go_check_types_canon_vec_re__219000024_A_fn_class = fncls__100d; tmp2 = fncls__100d } else { tmp2 = fncls__100 }; re__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var G__219000026__3_ any = /*line :105:1*/lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)); switch

	lang.Util_Hash_O__I_NoInit(G__219000026__3_) >> 5 & 31 { case 0: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_69) { var xs__4 any; var root_102 any = A_arbace_go_check_types_A_const_64.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_104 lang.IFn











		if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = t__0; var arg_106 any = A_arbace_go_check_types_A_const_15; if linked_103 == nil { xs__4 = ifn_104.Invoke_O_O__O(arg_105, arg_106) } else { xs__4 = linked_103.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O__O(root_102, arg_105, arg_106) }
//line :107:1
		var c__5 any; var root_107 any = A_arbace_go_check_types_A_const_70.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, A_arbace_go_check_types_map_same_A_fn_class); var ifn_109 lang.IFn











		if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var arg_111 any = xs__4; if linked_108 == nil { c__5 = ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { c__5 = linked_108.(*A_arbace_go_check_types_map_same_A).Invoke_O_O_O__O(root_107, arg_110, arg_111) }; if lang.Util_Identical_O_O__Z_NoInit(xs__4, c__5) { return t__0 } else { var tmp3 lang.IFn = lang.IFn_Cast(re__2); var tmp4 any; var root_125 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = A_arbace_go_check_types_A_const_75; var arg_129 any = c__5; if linked_126 == nil { tmp4 = ifn_127.Invoke_O_O__O(arg_128, arg_129) } else { tmp4 = linked_126.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_125, arg_128, arg_129) }; return tmp3.Invoke_O__O(tmp4) } }
//line :107:1
	case 1: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_71) { var ms__4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var c__5_2 any; var root_112 any = A_arbace_go_check_types_A_const_70.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, A_arbace_go_check_types_map_same_A_fn_class); var ifn_114 lang.IFn









		if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var arg_116 any = ms__4; if linked_113 == nil { c__5_2 = ifn_114.Invoke_O_O__O(arg_115, arg_116) } else { c__5_2 = linked_113.(*A_arbace_go_check_types_map_same_A).Invoke_O_O_O__O(root_112, arg_115, arg_116) }
		if lang.Util_Identical_O_O__Z_NoInit(ms__4, c__5_2) { return t__0 } else { var tmp5 any = A_arbace_go_check_types_A_const_71; return lang.IFn_Cast(re__2).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, c__5_2, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)))) } }
//line :107:1
	case 3: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_73) { var e__4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var c__5_3 any; var root_117 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, A_arbace_go_check_types_canon_A_fn_class); var ifn_119 lang.IFn

		if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = e__4; if linked_118 == nil { c__5_3 = ifn_119.Invoke_O__O(arg_120) } else { c__5_3 = linked_118.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_117, arg_120) }; if lang.Util_Identical_O_O__Z_NoInit(e__4, c__5_3) { return t__0 } else { return lang.IFn_Cast(re__2).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)), c__5_3)) } }
//line :107:1
	case 4: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_74) { var e__4_2 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var c__5_4 any; var root_121 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_go_check_types_canon_A_fn_class); var ifn_123 lang.IFn


		if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = e__4_2; if linked_122 == nil { c__5_4 = ifn_123.Invoke_O__O(arg_124) } else { c__5_4 = linked_122.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_121, arg_124) }; if lang.Util_Identical_O_O__Z_NoInit(e__4_2, c__5_4) { return t__0 } else { var tmp6 any = A_arbace_go_check_types_A_const_74; return lang.IFn_Cast(re__2).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp6, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)), c__5_4)) } }
//line :107:1
	case 5: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_76) { return t__0 }; case 8: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_77) { var k__4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var v__5 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var ck__6 any; var root_130 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_go_check_types_canon_A_fn_class); var ifn_132 lang.IFn




		if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = k__4; if linked_131 == nil { ck__6 = ifn_132.Invoke_O__O(arg_133) } else { ck__6 = linked_131.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_130, arg_133) }
//line :107:1
		var cv__7 any; var root_134 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, A_arbace_go_check_types_canon_A_fn_class); var ifn_136 lang.IFn




		if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = v__5; if linked_135 == nil { cv__7 = ifn_136.Invoke_O__O(arg_137) } else { cv__7 = linked_135.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_134, arg_137) }
		var tmp7 bool; var and__1927000168__auto____8 bool = lang.Util_Identical_O_O__Z_NoInit(k__4, ck__6); if and__1927000168__auto____8 { tmp7 = lang.Util_Identical_O_O__Z_NoInit(v__5, cv__7) } else { tmp7 = and__1927000168__auto____8 }; if tmp7 { return t__0 } else { return lang.IFn_Cast(re__2).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_77, ck__6, cv__7)) } }
//line :107:1
	case 14: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_78) { var e__4_3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var c__5_5 any; var root_138 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, A_arbace_go_check_types_canon_A_fn_class); var ifn_140 lang.IFn

		if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = e__4_3; if linked_139 == nil { c__5_5 = ifn_140.Invoke_O__O(arg_141) } else { c__5_5 = linked_139.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_138, arg_141) }; if lang.Util_Identical_O_O__Z_NoInit(e__4_3, c__5_5) { return t__0 } else { return lang.IFn_Cast(re__2).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)), c__5_5)) } }
//line :107:1
	case 16: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_79) { var e__4_4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var c__5_6 any; var root_142 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, A_arbace_go_check_types_canon_A_fn_class); var ifn_144 lang.IFn



		if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = e__4_4; if linked_143 == nil { c__5_6 = ifn_144.Invoke_O__O(arg_145) } else { c__5_6 = linked_143.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_142, arg_145) }; if lang.Util_Identical_O_O__Z_NoInit(e__4_4, c__5_6) { return t__0 } else { var tmp8 any = A_arbace_go_check_types_A_const_79; return lang.IFn_Cast(re__2).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)), c__5_6)) } }
//line :107:1
	case 17: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_80) { return t__0 }; case 27: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_81) { var vec__219000027__4 any = t__0; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000027__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000027__4, lang.RT_IntCast_J__I_NoInit(1), nil); var rs__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000027__4, lang.RT_IntCast_J__I_NoInit(2), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000027__4, lang.RT_IntCast_J__I_NoInit(3), nil); var cps__9 any; var root_146 any = A_arbace_go_check_types_A_const_70.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, A_arbace_go_check_types_map_same_A_fn_class); var ifn_148 lang.IFn; _ = ___5






		if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var arg_150 any = ps__6; if linked_147 == nil { cps__9 = ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { cps__9 = linked_147.(*A_arbace_go_check_types_map_same_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) }
//line :107:1
		var crs__10 any; var root_151 any = A_arbace_go_check_types_A_const_70.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, A_arbace_go_check_types_map_same_A_fn_class); var ifn_153 lang.IFn






		if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var arg_155 any = rs__7; if linked_152 == nil { crs__10 = ifn_153.Invoke_O_O__O(arg_154, arg_155) } else { crs__10 = linked_152.(*A_arbace_go_check_types_map_same_A).Invoke_O_O_O__O(root_151, arg_154, arg_155) }
		var tmp9 bool; var and__1927000168__auto____11 bool = lang.Util_Identical_O_O__Z_NoInit(ps__6, cps__9); if and__1927000168__auto____11 { tmp9 = lang.Util_Identical_O_O__Z_NoInit(rs__7, crs__10) } else { tmp9 = and__1927000168__auto____11 }; if tmp9 { return t__0 } else { return lang.IFn_Cast(re__2).Invoke_O__O(lang.Tuple_Create_O_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_81, cps__9, crs__10, v__8)) } }
//line :107:1
	case 31: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_82) { var fs__4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var c__5_7 any; var root_156 any = A_arbace_go_check_types_A_const_70.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, A_arbace_go_check_types_map_same_A_fn_class); var ifn_158 lang.IFn








		if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var arg_160 any = fs__4; if linked_157 == nil { c__5_7 = ifn_158.Invoke_O_O__O(arg_159, arg_160) } else { c__5_7 = linked_157.(*A_arbace_go_check_types_map_same_A).Invoke_O_O_O__O(root_156, arg_159, arg_160) }; if lang.Util_Identical_O_O__Z_NoInit(fs__4, c__5_7) { return t__0 } else { return lang.IFn_Cast(re__2).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_types_A_const_82, c__5_7)) } }
//line :107:1
	default:}; return t__0 }
//line :106:1
func A_arbace_go_check_types_canon_vec_re__219000024_A_New_O(p0 any) *A_arbace_go_check_types_canon_vec_re__219000024_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_canon_vec_re__219000024_A{}; t.Ctor_O(p0); return t }
//line :106:1
func (t *A_arbace_go_check_types_canon_vec_re__219000024_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :106:1
func (t *A_arbace_go_check_types_canon_vec_re__219000024_A) Invoke_O_O__O(self, c__1 any) any { var root_95 any = A_arbace_go_check_types_A_const_68.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = c__1; var arg_99 any = lang.RT_Meta_O__IPersistentMap_NoInit(t.F_t); if linked_96 == nil { return ifn_97.Invoke_O_O__O(arg_98, arg_99) } else { return linked_96.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_95, arg_98, arg_99) } }















func A_arbace_go_check_types_alias_of_A_New() *A_arbace_go_check_types_alias_of_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alias_of_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_go_check_types_alias_of_A) Ctor() {}
//line :122:1
func (t *A_arbace_go_check_types_alias_of_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_161 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_163 lang.IFn
	if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = t__0; if linked_162 == nil { tmp1 = ifn_163.Invoke_O__O(arg_164) } else { tmp1 = linked_162.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_161, arg_164) }
//line :125:1
	if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_165 any = A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = t__0; if linked_166 == nil { tmp2 = ifn_167.Invoke_O__O(arg_168) } else { tmp2 = linked_166.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_165, arg_168) }; if jrt.J2g_Truth(tmp2) { var root_169 any = A_arbace_go_check_types_A_const_62.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, A_arbace_go_check_types_kw_alias_info_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = t__0; if linked_170 == nil { return ifn_171.Invoke_O__O(arg_172) } else { return linked_170.(*A_arbace_go_check_types_kw_alias_info_A).Invoke_O_O__O(root_169, arg_172) } } else { return nil } } else {
//line :125:1
			var tmp3 any; var root_173 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_175 lang.IFn

			if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = t__0; if linked_174 == nil { tmp3 = ifn_175.Invoke_O__O(arg_176) } else { tmp3 = linked_174.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_173, arg_176) }
//line :125:1
			if jrt.J2g_Truth(tmp3) {

				var tmp4 *lang.Keyword = A_arbace_go_check_types_A_const_85; return tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(t__0)) } else {
//line :125:1
					if A_arbace_go_check_types_A_const_86 != nil { return nil } else { return nil
					}
				}
		}
}
func A_arbace_go_check_types_unalias_A_New() *A_arbace_go_check_types_unalias_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_unalias_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_go_check_types_unalias_A) Ctor() {}
//line :130:1
func (t *A_arbace_go_check_types_unalias_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_177 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = t__0; if linked_178 == nil { and__1927000168__auto____2 = ifn_179.Invoke_O__O(arg_180) } else { and__1927000168__auto____2 = linked_178.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_177, arg_180) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Keyword = A_arbace_go_check_types_A_const_85; tmp1 = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(t__0)) } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_go_check_types_A_const_87.GetRawRoot__O()).Invoke_O_O_O__O(t__0, A_arbace_go_check_types_A_const_88.GetRawRoot__O(), A_arbace_go_check_types_A_const_85) } else {
//line :133:1
			return t__0
		}
}

func A_arbace_go_check_types_canon_A_New() *A_arbace_go_check_types_canon_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_canon_A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_go_check_types_canon_A) Ctor() {}
//line :137:1
func (t *A_arbace_go_check_types_canon_A) Invoke_O_O__O(self, t__0 any) any {




	var tmp1 any; var root_187 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_189 lang.IFn
	if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = t__0; if linked_188 == nil { tmp1 = ifn_189.Invoke_O__O(arg_190) } else { tmp1 = linked_188.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_187, arg_190) }
//line :142:1
	if jrt.J2g_Truth(tmp1) {
		var root_191 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, A_arbace_go_check_types_canon_kw_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = t__0; if linked_192 == nil { return ifn_193.Invoke_O__O(arg_194) } else { return linked_192.(*A_arbace_go_check_types_canon_kw_A).Invoke_O_O__O(root_191, arg_194) } } else {
//line :142:1
			var tmp2 any; var root_195 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_197 lang.IFn

			if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = t__0; if linked_196 == nil { tmp2 = ifn_197.Invoke_O__O(arg_198) } else { tmp2 = linked_196.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_195, arg_198) }
//line :142:1
			if jrt.J2g_Truth(tmp2) {

				var root_199 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, A_arbace_go_check_types_canon_vec_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any; var root_203 any = A_arbace_go_check_types_A_const_90.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, A_arbace_go_check_types_unalias_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = t__0; if linked_204 == nil { arg_202 = ifn_205.Invoke_O__O(arg_206) } else { arg_202 = linked_204.(*A_arbace_go_check_types_unalias_A).Invoke_O_O__O(root_203, arg_206) }; if linked_200 == nil { return ifn_201.Invoke_O__O(arg_202) } else { return linked_200.(*A_arbace_go_check_types_canon_vec_A).Invoke_O_O__O(root_199, arg_202) } } else {
//line :142:1
					if A_arbace_go_check_types_A_const_86 != nil { return t__0 } else { return nil
					}
				}
		}
}
func A_arbace_go_check_types_same_QMARK__A_New() *A_arbace_go_check_types_same_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_same_QMARK__A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_go_check_types_same_QMARK__A) Ctor() {}
//line :147:1
func (t *A_arbace_go_check_types_same_QMARK__A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(x__0, y__1); if or__1927000174__auto____3 {


	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var cx__4 any; var root_207 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, A_arbace_go_check_types_canon_A_fn_class); var ifn_209 lang.IFn
		if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = x__0; if linked_208 == nil { cx__4 = ifn_209.Invoke_O__O(arg_210) } else { cx__4 = linked_208.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_207, arg_210) }
//line :150:1
		var cy__5 any; var root_211 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, A_arbace_go_check_types_canon_A_fn_class); var ifn_213 lang.IFn
		if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = y__1; if linked_212 == nil { cy__5 = ifn_213.Invoke_O__O(arg_214) } else { cy__5 = linked_212.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_211, arg_214) }
//line :150:1
		var and__1927000168__auto____6 any; var root_215 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_217 lang.IFn

		if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any; var and__1927000168__auto____6_2 bool = lang.Util_Identical_O_O__Z_NoInit(cx__4, x__0); if and__1927000168__auto____6_2 { arg_218 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(cy__5, y__1)).Ref() } else { arg_218 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6_2).Ref() }; if linked_216 == nil { and__1927000168__auto____6 = ifn_217.Invoke_O__O(arg_218) } else { and__1927000168__auto____6 = linked_216.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_215, arg_218) }; if jrt.J2g_Truth(and__1927000168__auto____6) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(cx__4, cy__5)).Ref() } else { return and__1927000168__auto____6 } } }




func A_arbace_go_check_types_next_id_A_New() *A_arbace_go_check_types_next_id_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_next_id_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_types_next_id_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_types_next_id_A) InvokePrim_O__J(self any) int64 { return jrt.Number_Cast(lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(A_arbace_go_check_types_A_const_92.GetRawRoot__O(), Lit_29, false)).LongValue__J() }
//line :157:1
func (t *A_arbace_go_check_types_next_id_A) Invoke_O__O(self any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O__J(self)).Ref() }

func A_arbace_go_check_types_named_QMARK__A_New() *A_arbace_go_check_types_named_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_QMARK__A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_go_check_types_named_QMARK__A) Ctor() {}
//line :159:1
func (t *A_arbace_go_check_types_named_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_219 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = t__0; if linked_220 == nil { and__1927000168__auto____2 = ifn_221.Invoke_O__O(arg_222) } else { and__1927000168__auto____2 = linked_220.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_219, arg_222) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_76; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_tparam_QMARK__A_New() *A_arbace_go_check_types_tparam_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_QMARK__A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_go_check_types_tparam_QMARK__A) Ctor() {}
//line :160:1
func (t *A_arbace_go_check_types_tparam_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_223 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_225 lang.IFn; if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = t__0; if linked_224 == nil { and__1927000168__auto____2 = ifn_225.Invoke_O__O(arg_226) } else { and__1927000168__auto____2 = linked_224.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_223, arg_226) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_80; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_info_A_New() *A_arbace_go_check_types_info_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_info_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_go_check_types_info_A) Ctor() {}
//line :161:1
func (t *A_arbace_go_check_types_info_A) Invoke_O_O__O(self, t__0 any) any { var root_227 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_228 == nil { return ifn_229.Invoke_O__O(arg_230) } else { return linked_228.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_227, arg_230) } }
func A_arbace_go_check_types_update_info_BANG__A_New() *A_arbace_go_check_types_update_info_BANG__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_update_info_BANG__A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_go_check_types_update_info_BANG__A) Ctor() {}
//line :162:1
func (t *A_arbace_go_check_types_update_info_BANG__A) DoInvoke_O_O_O_O__O(self, t__0, f__1, args__2 any) any { var root_231 any = A_arbace_go_check_types_A_const_93.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var arg_235 any; var root_236 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = f__1; var arg_240 any; var root_242 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_243 == nil { arg_240 = ifn_244.Invoke_O__O(arg_245) } else { arg_240 = linked_243.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_242, arg_245) }; var arg_241 any = args__2; if linked_237 == nil { arg_235 = ifn_238.Invoke_O_O_O__O(arg_239, arg_240, arg_241) } else { arg_235 = linked_237.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_236, arg_239, arg_240, arg_241) }; if linked_232 == nil { ifn_233.Invoke_O_O__O(arg_234, arg_235) } else { linked_232.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_231, arg_234, arg_235) }; return t__0 }

func A_arbace_go_check_types_new_named_A_New() *A_arbace_go_check_types_new_named_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_new_named_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_go_check_types_new_named_A) Ctor() {}
//line :164:1
func (t *A_arbace_go_check_types_new_named_A) Invoke_O_O__O(self, data__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_76; var tmp2 any; var root_246 any = A_arbace_go_check_types_A_const_95.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_248 lang.IFn; if


	linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_67.GetRawRoot__O()); var tmp4 any = A_arbace_go_check_types_A_const_96; var tmp5 any; var root_258 any = A_arbace_go_check_types_A_const_97.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_258, A_arbace_go_check_types_next_id_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; if linked_259 == nil { tmp5 = ifn_260.Invoke__O() } else { tmp5 = jrt.Long_ValueOf_J__Long_NoInit(linked_259.(*A_arbace_go_check_types_next_id_A).InvokePrim_O__J(root_258)).Ref() }; arg_249 = tmp3.Invoke_O_O_O_O_O__O(data__0, tmp4, tmp5, A_arbace_go_check_types_A_const_98, lang.PersistentVector_EMPTY.Ref()); if linked_247 == nil { tmp2 = ifn_248.Invoke_O__O(arg_249) } else { tmp2 = linked_247.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_246, arg_249) }; return /*line :164:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }




func A_arbace_go_check_types_new_tparam_A_New() *A_arbace_go_check_types_new_tparam_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_new_tparam_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_go_check_types_new_tparam_A) Ctor() {}
//line :169:1
func (t *A_arbace_go_check_types_new_tparam_A) Invoke_O_O__O(self, data__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_80; var tmp2 any; var root_261 any = A_arbace_go_check_types_A_const_95.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_263 lang.IFn; if


	linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any; var root_265 any = A_arbace_go_check_types_A_const_67.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = data__0; var arg_269 any = A_arbace_go_check_types_A_const_96; var arg_270 any; var root_271 any = A_arbace_go_check_types_A_const_97.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_271, A_arbace_go_check_types_next_id_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; if linked_272 == nil { arg_270 = ifn_273.Invoke__O() } else { arg_270 = jrt.Long_ValueOf_J__Long_NoInit(linked_272.(*A_arbace_go_check_types_next_id_A).InvokePrim_O__J(root_271)).Ref() }; if linked_266 == nil { arg_264 = ifn_267.Invoke_O_O_O__O(arg_268, arg_269, arg_270) } else { arg_264 = linked_266.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_265, arg_268, arg_269, arg_270) }; if linked_262 == nil { tmp2 = ifn_263.Invoke_O__O(arg_264) } else { tmp2 = linked_262.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_261, arg_264) }; return /*line :169:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }











func A_arbace_go_check_types_named_under_A_New() *A_arbace_go_check_types_named_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_under_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_go_check_types_named_under_A) Ctor() {}
//line :181:1
func (t *A_arbace_go_check_types_named_under_A) Invoke_O_O__O(self, t__0 any) any { { var t__2 any = t__0; var seen__3 any = lang.PersistentHashSet_EMPTY.Ref(); L1: for { var i__4 any; var root_274 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, A_arbace_go_check_types_info_A_fn_class); var ifn_276 lang.IFn

	if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = t__2; if linked_275 == nil { i__4 = ifn_276.Invoke_O__O(arg_277) } else { i__4 = linked_275.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_274, arg_277) }
//line :181:1
	var temp__1927000408__auto____5 any = A_arbace_go_check_types_A_const_100.Invoke_O__O(i__4)


	if jrt.J2g_Truth(temp__1927000408__auto____5) { var u__6 any = temp__1927000408__auto____5; var tmp1 any; var root_278 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_280 lang.IFn
		if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any = u__6; if linked_279 == nil { tmp1 = ifn_280.Invoke_O__O(arg_281) } else { tmp1 = linked_279.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_278, arg_281) }; if jrt.J2g_Truth(tmp1) {

			var tmp2 any; var root_282 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = seen__3; var arg_286 any = u__6; if linked_283 == nil { tmp2 = ifn_284.Invoke_O_O__O(arg_285, arg_286) } else { tmp2 = linked_283.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_282, arg_285, arg_286) }; if jrt.J2g_Truth(tmp2) { return A_arbace_go_check_types_A_const_103 } else {

				var tmp3 any; var root_295 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = seen__3; var arg_299 any = t__2; if linked_296 == nil { tmp3 = ifn_297.Invoke_O_O__O(arg_298, arg_299) } else { tmp3 = linked_296.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_295, arg_298, arg_299) }; t__2, seen__3 = u__6, tmp3; continue L1 } } else {
//line :185:1
					return u__6 } } else {





						var tmp4 any; var and__1927000168__auto____6 any = A_arbace_go_check_types_A_const_104.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_287 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = A_arbace_go_check_types_A_const_105.Invoke_O__O(i__4); if linked_288 == nil { and__1927000168__auto____7 = ifn_289.Invoke_O__O(arg_290) } else { and__1927000168__auto____7 = linked_288.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_287, arg_290) }; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp4 = A_arbace_go_check_types_A_const_60.Invoke_O__O(i__4) } else { tmp4 = and__1927000168__auto____7 } } else { tmp4 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp4) {
							lang.IFn_Cast(A_arbace_go_check_types_A_const_104.Get__O()).Invoke_O__O(t__2)
							var tmp5 *lang.Keyword = A_arbace_go_check_types_A_const_100; var tmp6 any; var root_291 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, A_arbace_go_check_types_info_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = t__2; if linked_292 == nil { tmp6 = ifn_293.Invoke_O__O(arg_294) } else { tmp6 = linked_292.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_291, arg_294) }; if jrt.J2g_Truth(tmp5.Invoke_O__O(tmp6)) { t__2, seen__3 = t__2, seen__3; continue L1 } else { return A_arbace_go_check_types_A_const_103 } } else {
//line :191:1
								return A_arbace_go_check_types_A_const_103 } } } }; /*line :181:1*/panic("j2g: unreachable") }














func A_arbace_go_check_types_under_A_New() *A_arbace_go_check_types_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_A{}; t.Ctor(); return t }
//line :196:1
func (t *A_arbace_go_check_types_under_A) Ctor() {}
//line :196:1
func (t *A_arbace_go_check_types_under_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_300 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_302 lang.IFn
	if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = t__0; if linked_301 == nil { tmp1 = ifn_302.Invoke_O__O(arg_303) } else { tmp1 = linked_301.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_300, arg_303) }
//line :199:1
	if jrt.J2g_Truth(tmp1) {
		var root_304 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, A_arbace_go_check_types_canon_kw_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = t__0; if linked_305 == nil { return ifn_306.Invoke_O__O(arg_307) } else { return linked_305.(*A_arbace_go_check_types_canon_kw_A).Invoke_O_O__O(root_304, arg_307) } } else {
//line :199:1
			var tmp2 any = A_arbace_go_check_types_A_const_76; if lang.Util_Identical_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))) { var u__2 any; var root_308 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, A_arbace_go_check_types_named_under_A_fn_class); var ifn_310 lang.IFn

				if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = t__0; if linked_309 == nil { u__2 = ifn_310.Invoke_O__O(arg_311) } else { u__2 = linked_309.(*A_arbace_go_check_types_named_under_A).Invoke_O_O__O(root_308, arg_311) }; var tmp3 any; var root_312 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = u__2; if linked_313 == nil { tmp3 = ifn_314.Invoke_O__O(arg_315) } else { tmp3 = linked_313.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_312, arg_315) }; if jrt.J2g_Truth(tmp3) { var root_316 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, A_arbace_go_check_types_canon_kw_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = u__2; if linked_317 == nil { return ifn_318.Invoke_O__O(arg_319) } else { return linked_317.(*A_arbace_go_check_types_canon_kw_A).Invoke_O_O__O(root_316, arg_319) } } else { return u__2 } } else {
//line :199:1
					var tmp4 any = A_arbace_go_check_types_A_const_80; if lang.Util_Identical_O_O__Z_NoInit(tmp4, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))) {


						var root_320 any = A_arbace_go_check_types_A_const_107.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, A_arbace_go_check_types_tparam_iface_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = t__0; if linked_321 == nil { return ifn_322.Invoke_O__O(arg_323) } else { return linked_321.(*A_arbace_go_check_types_tparam_iface_A).Invoke_O_O__O(root_320, arg_323) } } else {
//line :199:1
							if A_arbace_go_check_types_A_const_86 != nil {



								var root_324 any = A_arbace_go_check_types_A_const_90.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, A_arbace_go_check_types_unalias_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = t__0; if linked_325 == nil { return ifn_326.Invoke_O__O(arg_327) } else { return linked_325.(*A_arbace_go_check_types_unalias_A).Invoke_O_O__O(root_324, arg_327) } } else {
//line :199:1
									return nil
								}
						}
				}
		}
}


func A_arbace_go_check_types_basic_A_New() *A_arbace_go_check_types_basic_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_basic_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_go_check_types_basic_A) Ctor() {}
//line :207:1
func (t *A_arbace_go_check_types_basic_A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_328 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, A_arbace_go_check_types_under_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = t__0; if linked_329 == nil { u__2 = ifn_330.Invoke_O__O(arg_331) } else { u__2 = linked_329.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_328, arg_331) }; var tmp1 any; var root_332 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = u__2; if linked_333 == nil { tmp1 = ifn_334.Invoke_O__O(arg_335) } else { tmp1 = linked_333.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_332, arg_335) }; if jrt.J2g_Truth(tmp1) { return u__2 } else { return nil } }
func A_arbace_go_check_types_flag_A_New() *A_arbace_go_check_types_flag_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_flag_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_go_check_types_flag_A) Ctor() {}
//line :208:1
func (t *A_arbace_go_check_types_flag_A) Invoke_O_O_O__O(self, t__0, f__1 any) any { var b__3 any; var root_336 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, A_arbace_go_check_types_basic_A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = t__0; if linked_337 == nil { b__3 = ifn_338.Invoke_O__O(arg_339) } else { b__3 = linked_337.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_336, arg_339) }; var tmp1 any; var and__1927000168__auto____4 any = b__3; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_go_check_types_A_const_110.GetRawRoot__O()).Invoke_O__O(b__3), f__1) } else { tmp1 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }
func A_arbace_go_check_types_integer_type_QMARK__A_New() *A_arbace_go_check_types_integer_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_integer_type_QMARK__A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_go_check_types_integer_type_QMARK__A) Ctor() {}
//line :209:1
func (t *A_arbace_go_check_types_integer_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_340 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, A_arbace_go_check_types_flag_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = t__0; var arg_344 any = A_arbace_go_check_types_A_const_18; if linked_341 == nil { return ifn_342.Invoke_O_O__O(arg_343, arg_344) } else { return linked_341.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_340, arg_343, arg_344) } }
func A_arbace_go_check_types_unsigned_QMARK__A_New() *A_arbace_go_check_types_unsigned_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_unsigned_QMARK__A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_go_check_types_unsigned_QMARK__A) Ctor() {}
//line :210:1
func (t *A_arbace_go_check_types_unsigned_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_345 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, A_arbace_go_check_types_flag_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = t__0; var arg_349 any = A_arbace_go_check_types_A_const_27; if linked_346 == nil { return ifn_347.Invoke_O_O__O(arg_348, arg_349) } else { return linked_346.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_345, arg_348, arg_349) } }
func A_arbace_go_check_types_float_type_QMARK__A_New() *A_arbace_go_check_types_float_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_float_type_QMARK__A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_go_check_types_float_type_QMARK__A) Ctor() {}
//line :211:1
func (t *A_arbace_go_check_types_float_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_350 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, A_arbace_go_check_types_flag_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = t__0; var arg_354 any = A_arbace_go_check_types_A_const_34; if linked_351 == nil { return ifn_352.Invoke_O_O__O(arg_353, arg_354) } else { return linked_351.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_350, arg_353, arg_354) } }
func A_arbace_go_check_types_complex_type_QMARK__A_New() *A_arbace_go_check_types_complex_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_complex_type_QMARK__A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_go_check_types_complex_type_QMARK__A) Ctor() {}
//line :212:1
func (t *A_arbace_go_check_types_complex_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_355 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, A_arbace_go_check_types_flag_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = t__0; var arg_359 any = A_arbace_go_check_types_A_const_37; if linked_356 == nil { return ifn_357.Invoke_O_O__O(arg_358, arg_359) } else { return linked_356.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_355, arg_358, arg_359) } }
func A_arbace_go_check_types_numeric_QMARK__A_New() *A_arbace_go_check_types_numeric_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_numeric_QMARK__A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_go_check_types_numeric_QMARK__A) Ctor() {}
//line :213:1
func (t *A_arbace_go_check_types_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_360 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = t__0; if linked_361 == nil { or__1927000174__auto____2 = ifn_362.Invoke_O__O(arg_363) } else { or__1927000174__auto____2 = linked_361.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_360, arg_363) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_364 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = t__0; if linked_365 == nil { or__1927000174__auto____3 = ifn_366.Invoke_O__O(arg_367) } else { or__1927000174__auto____3 = linked_365.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_364, arg_367) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_368 any = A_arbace_go_check_types_A_const_114.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, A_arbace_go_check_types_complex_type_QMARK__A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = t__0; if linked_369 == nil { return ifn_370.Invoke_O__O(arg_371) } else { return linked_369.(*A_arbace_go_check_types_complex_type_QMARK__A).Invoke_O_O__O(root_368, arg_371) } } } }
func A_arbace_go_check_types_string_type_QMARK__A_New() *A_arbace_go_check_types_string_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_string_type_QMARK__A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_go_check_types_string_type_QMARK__A) Ctor() {}
//line :214:1
func (t *A_arbace_go_check_types_string_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_372 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, A_arbace_go_check_types_flag_A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = t__0; var arg_376 any = A_arbace_go_check_types_A_const_41; if linked_373 == nil { return ifn_374.Invoke_O_O__O(arg_375, arg_376) } else { return linked_373.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_372, arg_375, arg_376) } }
func A_arbace_go_check_types_boolean_type_QMARK__A_New() *A_arbace_go_check_types_boolean_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_boolean_type_QMARK__A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_go_check_types_boolean_type_QMARK__A) Ctor() {}
//line :215:1
func (t *A_arbace_go_check_types_boolean_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_377 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_377, A_arbace_go_check_types_flag_A_fn_class); var ifn_379 lang.IFn; if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; var arg_380 any = t__0; var arg_381 any = A_arbace_go_check_types_A_const_16; if linked_378 == nil { return ifn_379.Invoke_O_O__O(arg_380, arg_381) } else { return linked_378.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_377, arg_380, arg_381) } }
func A_arbace_go_check_types_untyped_QMARK__A_New() *A_arbace_go_check_types_untyped_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_untyped_QMARK__A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_go_check_types_untyped_QMARK__A) Ctor() {}
//line :216:1
func (t *A_arbace_go_check_types_untyped_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_382 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = t__0; if linked_383 == nil { and__1927000168__auto____2 = ifn_384.Invoke_O__O(arg_385) } else { and__1927000168__auto____2 = linked_383.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_382, arg_385) }; if jrt.J2g_Truth(and__1927000168__auto____2) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_go_check_types_A_const_110.GetRawRoot__O()).Invoke_O__O(t__0), A_arbace_go_check_types_A_const_45))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_typed_QMARK__A_New() *A_arbace_go_check_types_typed_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typed_QMARK__A{}; t.Ctor(); return t }
//line :217:1
func (t *A_arbace_go_check_types_typed_QMARK__A) Ctor() {}
//line :217:1
func (t *A_arbace_go_check_types_typed_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_386 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any; var root_390 any = A_arbace_go_check_types_A_const_115.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, A_arbace_go_check_types_untyped_QMARK__A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = t__0; if linked_391 == nil { arg_389 = ifn_392.Invoke_O__O(arg_393) } else { arg_389 = linked_391.(*A_arbace_go_check_types_untyped_QMARK__A).Invoke_O_O__O(root_390, arg_393) }; if linked_387 == nil { return ifn_388.Invoke_O__O(arg_389) } else { return linked_387.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_386, arg_389) } }
func A_arbace_go_check_types_const_type_QMARK__A_New() *A_arbace_go_check_types_const_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_const_type_QMARK__A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_go_check_types_const_type_QMARK__A) Ctor() {}
//line :218:1
func (t *A_arbace_go_check_types_const_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var b__2 any; var root_394 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, A_arbace_go_check_types_basic_A_fn_class); var ifn_396 lang.IFn; if


	linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = t__0; if linked_395 == nil { b__2 = ifn_396.Invoke_O__O(arg_397) } else { b__2 = linked_395.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_394, arg_397) }; var and__1927000168__auto____3 any = b__2; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_398 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = lang.IFn_Cast(A_arbace_go_check_types_A_const_116).Invoke_O__O(b__2); if linked_399 == nil { return ifn_400.Invoke_O__O(arg_401) } else { return linked_399.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_398, arg_401) } } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_ordered_QMARK__A_New() *A_arbace_go_check_types_ordered_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ordered_QMARK__A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_go_check_types_ordered_QMARK__A) Ctor() {}
//line :222:1
func (t *A_arbace_go_check_types_ordered_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_402 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = t__0; if linked_403 == nil { or__1927000174__auto____2 = ifn_404.Invoke_O__O(arg_405) } else { or__1927000174__auto____2 = linked_403.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_402, arg_405) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_406 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = t__0; if linked_407 == nil { or__1927000174__auto____3 = ifn_408.Invoke_O__O(arg_409) } else { or__1927000174__auto____3 = linked_407.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_406, arg_409) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_410 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, A_arbace_go_check_types_string_type_QMARK__A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = t__0; if linked_411 == nil { return ifn_412.Invoke_O__O(arg_413) } else { return linked_411.(*A_arbace_go_check_types_string_type_QMARK__A).Invoke_O_O__O(root_410, arg_413) } } } }
func A_arbace_go_check_types_interface_QMARK__A_New() *A_arbace_go_check_types_interface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_interface_QMARK__A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_go_check_types_interface_QMARK__A) Ctor() {}
//line :223:1
func (t *A_arbace_go_check_types_interface_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_414 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, A_arbace_go_check_types_under_A_fn_class); var ifn_416 lang.IFn; if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = t__0; if linked_415 == nil { u__2 = ifn_416.Invoke_O__O(arg_417) } else { u__2 = linked_415.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_414, arg_417) }; var and__1927000168__auto____3 any; var root_418 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = u__2; if linked_419 == nil { and__1927000168__auto____3 = ifn_420.Invoke_O__O(arg_421) } else { and__1927000168__auto____3 = linked_419.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_418, arg_421) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_71; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_pointer_QMARK__A_New() *A_arbace_go_check_types_pointer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_pointer_QMARK__A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_go_check_types_pointer_QMARK__A) Ctor() {}
//line :224:1
func (t *A_arbace_go_check_types_pointer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_422 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, A_arbace_go_check_types_under_A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = t__0; if linked_423 == nil { u__2 = ifn_424.Invoke_O__O(arg_425) } else { u__2 = linked_423.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_422, arg_425) }; var and__1927000168__auto____3 any; var root_426 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = u__2; if linked_427 == nil { and__1927000168__auto____3 = ifn_428.Invoke_O__O(arg_429) } else { and__1927000168__auto____3 = linked_427.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_426, arg_429) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_73; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_unsafe_pointer_QMARK__A_New() *A_arbace_go_check_types_unsafe_pointer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_unsafe_pointer_QMARK__A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_go_check_types_unsafe_pointer_QMARK__A) Ctor() {}
//line :225:1
func (t *A_arbace_go_check_types_unsafe_pointer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_42; var tmp2 any; var root_430 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, A_arbace_go_check_types_basic_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = t__0; if linked_431 == nil { tmp2 = ifn_432.Invoke_O__O(arg_433) } else { tmp2 = linked_431.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_430, arg_433) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }
func A_arbace_go_check_types_uintptr_QMARK__A_New() *A_arbace_go_check_types_uintptr_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_uintptr_QMARK__A{}; t.Ctor(); return t }
//line :226:1
func (t *A_arbace_go_check_types_uintptr_QMARK__A) Ctor() {}
//line :226:1
func (t *A_arbace_go_check_types_uintptr_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_32; var tmp2 any; var root_434 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, A_arbace_go_check_types_basic_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = t__0; if linked_435 == nil { tmp2 = ifn_436.Invoke_O__O(arg_437) } else { tmp2 = linked_435.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_434, arg_437) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }
func A_arbace_go_check_types_valid_QMARK__A_New() *A_arbace_go_check_types_valid_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_valid_QMARK__A{}; t.Ctor(); return t }
//line :227:1
func (t *A_arbace_go_check_types_valid_QMARK__A) Ctor() {}
//line :227:1
func (t *A_arbace_go_check_types_valid_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_438 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = A_arbace_go_check_types_A_const_103; var arg_442 any = t__0; if linked_439 == nil { return ifn_440.Invoke_O_O__O(arg_441, arg_442) } else { return linked_439.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_438, arg_441, arg_442) } }
func A_arbace_go_check_types_kind_of_A_New() *A_arbace_go_check_types_kind_of_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_kind_of_A{}; t.Ctor(); return t }
//line :228:1
func (t *A_arbace_go_check_types_kind_of_A) Ctor() {}
//line :228:1
func (t *A_arbace_go_check_types_kind_of_A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_443 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, A_arbace_go_check_types_under_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = t__0; if linked_444 == nil { u__2 = ifn_445.Invoke_O__O(arg_446) } else { u__2 = linked_444.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_443, arg_446) }; var tmp1 any; var root_447 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = u__2; if linked_448 == nil { tmp1 = ifn_449.Invoke_O__O(arg_450) } else { tmp1 = linked_448.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_447, arg_450) }; if jrt.J2g_Truth(tmp1) { return u__2 } else { return lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)) } }
func A_arbace_go_check_types_has_name_QMARK__A_New() *A_arbace_go_check_types_has_name_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_name_QMARK__A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_go_check_types_has_name_QMARK__A) Ctor() {}
//line :229:1
func (t *A_arbace_go_check_types_has_name_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_451 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = t__0; if linked_452 == nil { or__1927000174__auto____2 = ifn_453.Invoke_O__O(arg_454) } else { or__1927000174__auto____2 = linked_452.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_451, arg_454) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_455 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = t__0; if linked_456 == nil { or__1927000174__auto____3 = ifn_457.Invoke_O__O(arg_458) } else { or__1927000174__auto____3 = linked_456.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_455, arg_458) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_459 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_461 lang.IFn; if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = t__0; if linked_460 == nil { return ifn_461.Invoke_O__O(arg_462) } else { return linked_460.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_459, arg_462) } } } }
func A_arbace_go_check_types_integer_or_float_QMARK__A_New() *A_arbace_go_check_types_integer_or_float_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_integer_or_float_QMARK__A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_go_check_types_integer_or_float_QMARK__A) Ctor() {}
//line :230:1
func (t *A_arbace_go_check_types_integer_or_float_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_463 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = t__0; if linked_464 == nil { or__1927000174__auto____2 = ifn_465.Invoke_O__O(arg_466) } else { or__1927000174__auto____2 = linked_464.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_463, arg_466) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_467 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = t__0; if linked_468 == nil { return ifn_469.Invoke_O__O(arg_470) } else { return linked_468.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_467, arg_470) } } }



func A_arbace_go_check_types_has_nil_QMARK__A_New() *A_arbace_go_check_types_has_nil_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_nil_QMARK__A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_go_check_types_has_nil_QMARK__A) Ctor() {}
//line :234:1
func (t *A_arbace_go_check_types_has_nil_QMARK__A) Invoke_O_O__O(self, t__0 any) any {



	var tmp1 any; var root_471 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = t__0; if linked_472 == nil { tmp1 = ifn_473.Invoke_O__O(arg_474) } else { tmp1 = linked_472.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_471, arg_474) }; if jrt.J2g_Truth(tmp1) {
		var root_475 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, A_arbace_go_check_types_under_is_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = t__0; var arg_479 any; var tmp2 any = A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A_New(); var tmp3 *jrt.Class; var fncls__488 *jrt.Class = A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A_fn_class; if fncls__488 == nil { var fncls__488d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A_fn_class = fncls__488d; tmp3 = fncls__488d } else { tmp3 = fncls__488 }; arg_479 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_476 == nil { return ifn_477.Invoke_O_O__O(arg_478, arg_479) } else { return linked_476.(*A_arbace_go_check_types_under_is_A).Invoke_O_O_O__O(root_475, arg_478, arg_479) } } else {
//line :238:1
			var u__2 any; var root_489 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, A_arbace_go_check_types_under_A_fn_class); var ifn_491 lang.IFn

			if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = t__0; if linked_490 == nil { u__2 = ifn_491.Invoke_O__O(arg_492) } else { u__2 = linked_490.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_489, arg_492) }
//line :238:1
			var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_42, u__2)


			if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_51, u__2); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var and__1927000168__auto____5 any; var root_493 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_495 lang.IFn
				if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = u__2; if linked_494 == nil { and__1927000168__auto____5 = ifn_495.Invoke_O__O(arg_496) } else { and__1927000168__auto____5 = linked_494.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_493, arg_496) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_497 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = A_arbace_go_check_types_A_const_123; var arg_501 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)); if linked_498 == nil { return ifn_499.Invoke_O_O__O(arg_500, arg_501) } else { return linked_498.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_497, arg_500, arg_501) } } else { return and__1927000168__auto____5 } } } } }
//line :239:1
func A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A_New() *A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A) Ctor() {}
//line :239:1
func (t *A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A) Invoke_O_O__O(self, u__1 any) any { var and__1927000168__auto____2 any; var root_480 any = A_arbace_go_check_types_A_const_121.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = u__1; if linked_481 == nil { and__1927000168__auto____2 = ifn_482.Invoke_O__O(arg_483) } else { and__1927000168__auto____2 = linked_481.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_480, arg_483) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_484 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, A_arbace_go_check_types_has_nil_QMARK__A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = u__1; if linked_485 == nil { return ifn_486.Invoke_O__O(arg_487) } else { return linked_485.(*A_arbace_go_check_types_has_nil_QMARK__A).Invoke_O_O__O(root_484, arg_487) } } else { return and__1927000168__auto____2 } }




func A_arbace_go_check_types_empty_interface_QMARK__A_New() *A_arbace_go_check_types_empty_interface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_empty_interface_QMARK__A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_go_check_types_empty_interface_QMARK__A) Ctor() {}
//line :244:1
func (t *A_arbace_go_check_types_empty_interface_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_502 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, A_arbace_go_check_types_under_A_fn_class); var ifn_504 lang.IFn; if
												linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = t__0; if linked_503 == nil { u__2 = ifn_504.Invoke_O__O(arg_505) } else { u__2 = linked_503.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_502, arg_505) }; var and__1927000168__auto____3 any; var root_506 any = /*line :244:1*/A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_508 lang.IFn; if
												linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = u__2; if linked_507 == nil { and__1927000168__auto____3 = ifn_508.Invoke_O__O(arg_509) } else { and__1927000168__auto____3 = linked_507.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_506, arg_509) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_71; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____4 { var and__1927000168__auto____5 any; var root_510 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_511 == nil { and__1927000168__auto____5 = ifn_512.Invoke_O__O(arg_513) } else { and__1927000168__auto____5 = linked_511.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_510, arg_513) }; if jrt.J2g_Truth(and__1927000168__auto____5) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref() } else { return and__1927000168__auto____5 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_default_type_A_New() *A_arbace_go_check_types_default_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_default_type_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_go_check_types_default_type_A) Ctor() {}
//line :247:1
func (t *A_arbace_go_check_types_default_type_A) Invoke_O_O__O(self, t__0 any) any { var G__219000069__2_ any = t__0; switch


	lang.Util_Hash_O__I_NoInit(G__219000069__2_) >> 19 & 7 { case 0: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_49) { return A_arbace_go_check_types_A_const_38 }; case 1: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_43) { return A_arbace_go_check_types_A_const_14 }; case 3: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_48) { return A_arbace_go_check_types_A_const_35 }; case 5: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_46) { return A_arbace_go_check_types_A_const_25 }; case 6: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_50) { return A_arbace_go_check_types_A_const_40 }; case 7: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_47) {
		if jrt.J2g_Truth(A_arbace_go_check_types_A_const_125.Get__O()) { return A_arbace_go_check_types_A_const_53 } else { return A_arbace_go_check_types_A_const_21 } }
//line :250:1
	default:}; return t__0 }




func A_arbace_go_check_types_ignore_tags_A_New() *A_arbace_go_check_types_ignore_tags_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ignore_tags_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_go_check_types_ignore_tags_A) Ctor() {}
//line :255:1
func (t *A_arbace_go_check_types_ignore_tags_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_515 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = t__0; if linked_516 == nil { and__1927000168__auto____2 = ifn_517.Invoke_O__O(arg_518) } else { and__1927000168__auto____2 = linked_516.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_515, arg_518) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_519 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any; var root_523 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = t__0; if linked_524 == nil { arg_522 = ifn_525.Invoke_O__O(arg_526) } else { arg_522 = linked_524.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_523, arg_526) }; if linked_520 == nil { and__1927000168__auto____3 = ifn_521.Invoke_O__O(arg_522) } else { and__1927000168__auto____3 = linked_520.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_519, arg_522) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_527 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any; var root_531 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = t__0; if linked_532 == nil { arg_530 = ifn_533.Invoke_O__O(arg_534) } else { arg_530 = linked_532.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_531, arg_534) }; if linked_528 == nil { tmp1 = ifn_529.Invoke_O__O(arg_530) } else { tmp1 = linked_528.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_527, arg_530) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var G__219000072__2_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))
		switch lang.Util_Hash_O__I_NoInit(G__219000072__2_) >> 2 & 15 { case 1: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_77) { var tmp2 any = A_arbace_go_check_types_A_const_77; var tmp3 any; var root_536 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_538 lang.IFn




			if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_537 == nil { tmp3 = ifn_538.Invoke_O__O(arg_539) } else { tmp3 = linked_537.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_536, arg_539) }
//line :259:1
			var tmp4 any = tmp3; var tmp5 any; var root_540 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_542 lang.IFn




			if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_541 == nil { tmp5 = ifn_542.Invoke_O__O(arg_543) } else { tmp5 = linked_541.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_540, arg_543) }
//line :259:1
			return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp4, tmp5) }; case 2: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_78) { var tmp6 any = A_arbace_go_check_types_A_const_78; var tmp7 any; var root_544 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_546 lang.IFn


				if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_545 == nil { tmp7 = ifn_546.Invoke_O__O(arg_547) } else { tmp7 = linked_545.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_544, arg_547) }
//line :259:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7) }; case 3: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_74) { var tmp8 any = A_arbace_go_check_types_A_const_74; var tmp9 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp10 any; var root_548 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_550 lang.IFn



					if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_549 == nil { tmp10 = ifn_550.Invoke_O__O(arg_551) } else { tmp10 = linked_549.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_548, arg_551) }
//line :259:1
					return lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp9, tmp10) }; case 6: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_79) { var tmp11 any = A_arbace_go_check_types_A_const_79; var tmp12 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp13 any; var root_566 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_568 lang.IFn





						if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_567 == nil { tmp13 = ifn_568.Invoke_O__O(arg_569) } else { tmp13 = linked_567.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_566, arg_569) }
//line :259:1
						return lang.Tuple_Create_O_O_O__IPersistentVector(tmp11, tmp12, tmp13) }; case 7: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_69) {







							var root_552 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = A_arbace_go_check_types_A_const_127; var arg_556 any; var root_557 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var arg_561 any; var root_562 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = t__0; if linked_563 == nil { arg_561 = ifn_564.Invoke_O__O(arg_565) } else { arg_561 = linked_563.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_562, arg_565) }; if linked_558 == nil { arg_556 = ifn_559.Invoke_O_O__O(arg_560, arg_561) } else { arg_556 = linked_558.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_557, arg_560, arg_561) }; if linked_553 == nil { return ifn_554.Invoke_O_O__O(arg_555, arg_556) } else { return linked_553.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_552, arg_555, arg_556) } }
//line :259:1
		case 9: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_81) { var tmp14 any = A_arbace_go_check_types_A_const_81; var tmp15 any; var root_570 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_572 lang.IFn






			if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var arg_574 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_571 == nil { tmp15 = ifn_572.Invoke_O_O__O(arg_573, arg_574) } else { tmp15 = linked_571.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_570, arg_573, arg_574) }
//line :259:1
			var tmp16 any = tmp15; var tmp17 any; var root_575 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_577 lang.IFn






			if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var arg_579 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_576 == nil { tmp17 = ifn_577.Invoke_O_O__O(arg_578, arg_579) } else { tmp17 = linked_576.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_575, arg_578, arg_579) }
//line :259:1
			return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp14, tmp16, tmp17, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(3))) }; case 11: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_73) { var tmp18 any = A_arbace_go_check_types_A_const_73; var tmp19 any; var root_580 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_582 lang.IFn

				if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_581 == nil { tmp19 = ifn_582.Invoke_O__O(arg_583) } else { tmp19 = linked_581.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_580, arg_583) }
//line :259:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp18, tmp19) }; case 13: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_82) { var tmp20 any = A_arbace_go_check_types_A_const_82; var tmp21 any; var root_584 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_586 lang.IFn
					if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any; var tmp22 any = A_arbace_go_check_types_ignore_tags_fn__219000073_A_New(); var tmp23 *jrt.Class; var fncls__601 *jrt.Class = A_arbace_go_check_types_ignore_tags_fn__219000073_A_fn_class; if fncls__601 == nil { var fncls__601d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_go_check_types_ignore_tags_fn__219000073_A_fn_class = fncls__601d; tmp23 = fncls__601d } else { tmp23 = fncls__601 }; arg_587 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_588 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_585 == nil { tmp21 = ifn_586.Invoke_O_O__O(arg_587, arg_588) } else { tmp21 = linked_585.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_584, arg_587, arg_588) }
//line :259:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp20, tmp21) }; default:}; return t__0 } else {
//line :258:1
						return t__0
					} }
func A_arbace_go_check_types_ignore_tags_fn__219000073_A_New() *A_arbace_go_check_types_ignore_tags_fn__219000073_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ignore_tags_fn__219000073_A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_go_check_types_ignore_tags_fn__219000073_A) Ctor() {}
//line :260:1
func (t *A_arbace_go_check_types_ignore_tags_fn__219000073_A) Invoke_O_O__O(self, p1__219000071_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_67.GetRawRoot__O()); var tmp2 any = A_arbace_go_check_types_A_const_130; var tmp3 any = A_arbace_go_check_types_A_const_65; var tmp4 any; var root_597 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(p1__219000071_SHARP___1); if linked_598 == nil { tmp4 = ifn_599.Invoke_O__O(arg_600) } else { tmp4 = linked_598.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_597, arg_600) }; return tmp1.Invoke_O_O_O_O_O__O(p1__219000071_SHARP___1, tmp2, nil, tmp3, tmp4) }










func A_arbace_go_check_types_identical_ignore_tags_QMARK__A_New() *A_arbace_go_check_types_identical_ignore_tags_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_identical_ignore_tags_QMARK__A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_go_check_types_identical_ignore_tags_QMARK__A) Ctor() {}
//line :271:1
func (t *A_arbace_go_check_types_identical_ignore_tags_QMARK__A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 any; var root_602 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, A_arbace_go_check_types_canon_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any; var root_606 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = x__0; if linked_607 == nil { arg_605 = ifn_608.Invoke_O__O(arg_609) } else { arg_605 = linked_607.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_606, arg_609) }; if linked_603 == nil { tmp1 = ifn_604.Invoke_O__O(arg_605) } else { tmp1 = linked_603.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_602, arg_605) }; var tmp2 any = tmp1; var tmp3 any; var root_610 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, A_arbace_go_check_types_canon_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any; var root_614 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = y__1; if linked_615 == nil { arg_613 = ifn_616.Invoke_O__O(arg_617) } else { arg_613 = linked_615.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_614, arg_617) }; if linked_611 == nil { tmp3 = ifn_612.Invoke_O__O(arg_613) } else { tmp3 = linked_611.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_610, arg_613) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() }





func A_arbace_go_check_types_tset_comparable_QMARK__A_New() *A_arbace_go_check_types_tset_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_comparable_QMARK__A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__A) Ctor() {}
//line :277:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__A) Invoke_O_O_O__O(self, ts__0, seen__1 any) any {


	var tmp1 any = A_arbace_go_check_types_A_const_131; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__0)) {
		return A_arbace_go_check_types_A_const_133.Invoke_O__O(ts__0) } else {
//line :280:1
			var and__1927000168__auto____3 any; var root_618 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_620 lang.IFn

			if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__0); if linked_619 == nil { and__1927000168__auto____3 = ifn_620.Invoke_O__O(arg_621) } else { and__1927000168__auto____3 = linked_619.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_618, arg_621) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_622 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any; var tmp2 any = A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A_New_O(seen__1); var tmp3 *jrt.Class; var fncls__632 *jrt.Class = A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A_fn_class; if fncls__632 == nil { var fncls__632d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A_fn_class = fncls__632d; tmp3 = fncls__632d } else { tmp3 = fncls__632 }; arg_625 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_626 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__0); if linked_623 == nil { return ifn_624.Invoke_O_O__O(arg_625, arg_626) } else { return linked_623.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_622, arg_625, arg_626) } } else { return and__1927000168__auto____3 } } }
//line :282:1
func A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A_New_O(p0 any) *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A{}; t.Ctor_O(p0); return t }
//line :282:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A) Ctor_O(c__seen any) { t.F_seen = c__seen }
//line :282:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A) Invoke_O_O__O(self, p__219000077__1 any) any { var vec__219000079__2 any = p__219000077__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000079__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000079__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_627 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_629 lang.IFn; _ = ___3; if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = ty__4; var arg_631 any = t.F_seen; if linked_628 == nil { return ifn_629.Invoke_O_O__O(arg_630, arg_631) } else { return linked_628.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O_O__O(root_627, arg_630, arg_631) } }

func A_arbace_go_check_types_comparable_type_QMARK__A_New() *A_arbace_go_check_types_comparable_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_type_QMARK__A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__A) Ctor() {}
//line :284:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__A) Invoke_O_O_O_O__O(self, t__0, dynamic__1, seen__2 any) any {




	var tmp1 any; var root_633 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = seen__2; var arg_637 any = t__0; if linked_634 == nil { tmp1 = ifn_635.Invoke_O_O__O(arg_636, arg_637) } else { tmp1 = linked_634.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_633, arg_636, arg_637) }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var seen__4 any; var root_638 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_640 lang.IFn

		if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = seen__2; var arg_642 any = t__0; if linked_639 == nil { seen__4 = ifn_640.Invoke_O_O__O(arg_641, arg_642) } else { seen__4 = linked_639.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_638, arg_641, arg_642) }
		var tmp2 any; var root_643 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = t__0; if linked_644 == nil { tmp2 = ifn_645.Invoke_O__O(arg_646) } else { tmp2 = linked_644.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_643, arg_646) }; if jrt.J2g_Truth(tmp2) {
			var tmp3 any; var root_647 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any; var root_652 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = t__0; if linked_653 == nil { arg_650 = ifn_654.Invoke_O__O(arg_655) } else { arg_650 = linked_653.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_652, arg_655) }; var arg_651 any = seen__4; if linked_648 == nil { tmp3 = ifn_649.Invoke_O_O__O(arg_650, arg_651) } else { tmp3 = linked_648.(*A_arbace_go_check_types_tset_comparable_QMARK__A).Invoke_O_O_O__O(root_647, arg_650, arg_651) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp3)).Ref() } else {
//line :292:1
				var u__5 any; var root_656 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, A_arbace_go_check_types_under_A_fn_class); var ifn_658 lang.IFn

				if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = t__0; if linked_657 == nil { u__5 = ifn_658.Invoke_O__O(arg_659) } else { u__5 = linked_657.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_656, arg_659) }
				var tmp4 any; var root_660 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_662 lang.IFn
				if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = u__5; if linked_661 == nil { tmp4 = ifn_662.Invoke_O__O(arg_663) } else { tmp4 = linked_661.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_660, arg_663) }
//line :295:1
				if jrt.J2g_Truth(tmp4) {
					var root_664 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = u__5; var arg_668 any = A_arbace_go_check_types_A_const_51; if linked_665 == nil { return ifn_666.Invoke_O_O__O(arg_667, arg_668) } else { return linked_665.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_664, arg_667, arg_668) } } else {
//line :295:1
						if A_arbace_go_check_types_A_const_86 != nil { var G__219000085__6_ any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(0))


							switch lang.Util_Hash_O__I_NoInit(G__219000085__6_) >> 4 & 7 { case 0: if any(G__219000085__6_) == any(A_arbace_go_check_types_A_const_74) {



								var root_670 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(2)); var arg_674 any = dynamic__1; var arg_675 any = seen__4; if linked_671 == nil { return ifn_672.Invoke_O_O_O__O(arg_673, arg_674, arg_675) } else { return linked_671.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_670, arg_673, arg_674, arg_675) } }
//line :298:1
							case 1: if any(G__219000085__6_) == any(A_arbace_go_check_types_A_const_79) { return jrt.Boolean_TRUE.Ref() }; case 3: if any(G__219000085__6_) == any(A_arbace_go_check_types_A_const_71) { var or__1927000174__auto____7 any = dynamic__1

								if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var tmp5 any; var root_676 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any; var root_681 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_681, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_683 lang.IFn; if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = u__5; if linked_682 == nil { arg_679 = ifn_683.Invoke_O__O(arg_684) } else { arg_679 = linked_682.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_681, arg_684) }; var arg_680 any = seen__4; if linked_677 == nil { tmp5 = ifn_678.Invoke_O_O__O(arg_679, arg_680) } else { tmp5 = linked_677.(*A_arbace_go_check_types_tset_comparable_QMARK__A).Invoke_O_O_O__O(root_676, arg_679, arg_680) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp5)).Ref() } }
//line :298:1
							case 6: if any(G__219000085__6_) == any(A_arbace_go_check_types_A_const_73) { return jrt.Boolean_TRUE.Ref() }; case 7: if any(G__219000085__6_) == any(A_arbace_go_check_types_A_const_82) {


								var root_685 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any; var tmp6 any = A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A_New_O_O(seen__4, dynamic__1); var tmp7 *jrt.Class; var fncls__696 *jrt.Class = A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A_fn_class; if fncls__696 == nil { var fncls__696d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A_fn_class = fncls__696d; tmp7 = fncls__696d } else { tmp7 = fncls__696 }; arg_688 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_689 any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(1)); if linked_686 == nil { return ifn_687.Invoke_O_O__O(arg_688, arg_689) } else { return linked_686.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_685, arg_688, arg_689) } }
//line :298:1
							default:}; return jrt.Boolean_FALSE.Ref() } else {
//line :295:1
								return nil
							}
					}
			}
	}
}
func A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A{}; t.Ctor_O_O(p0, p1); return t }
//line :301:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A) Ctor_O_O(c__seen, c__dynamic any) { t.F_seen = c__seen; t.F_dynamic = c__dynamic }
//line :301:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A) Invoke_O_O__O(self, p1__219000084_SHARP___1 any) any { var root_690 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(p1__219000084_SHARP___1); var arg_694 any = t.F_dynamic; var arg_695 any = t.F_seen; if linked_691 == nil { return ifn_692.Invoke_O_O_O__O(arg_693, arg_694, arg_695) } else { return linked_691.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_690, arg_693, arg_694, arg_695) } }



func A_arbace_go_check_types_strictly_comparable_QMARK__A_New() *A_arbace_go_check_types_strictly_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_strictly_comparable_QMARK__A{}; t.Ctor(); return t }
//line :305:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Ctor() {}
//line :305:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Invoke_O_O_O__O(self, t__0, seen__1 any) any { var root_697 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = t__0; var arg_701 any = jrt.Boolean_FALSE.Ref(); var arg_702 any = seen__1; if linked_698 == nil { return ifn_699.Invoke_O_O_O__O(arg_700, arg_701, arg_702) } else { return linked_698.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_697, arg_700, arg_701, arg_702) } }
//line :305:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_703 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = t__0; var arg_707 any = jrt.Boolean_FALSE.Ref(); var arg_708 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_704 == nil { return ifn_705.Invoke_O_O_O__O(arg_706, arg_707, arg_708) } else { return linked_704.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_703, arg_706, arg_707, arg_708) } }

func A_arbace_go_check_types_incomparable_cause_A_New() *A_arbace_go_check_types_incomparable_cause_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_incomparable_cause_A{}; t.Ctor(); return t }
//line :307:1
func (t *A_arbace_go_check_types_incomparable_cause_A) Ctor() {}
//line :307:1
func (t *A_arbace_go_check_types_incomparable_cause_A) Invoke_O_O__O(self, t__0 any) any { var body_cause__2 *A_arbace_go_check_types_incomparable_cause_cause__219000090_A = A_arbace_go_check_types_incomparable_cause_cause__219000090_A_New(); var cause__2 any; var tmp1 *jrt.Class; var fncls__755 *jrt.Class = A_arbace_go_check_types_incomparable_cause_cause__219000090_A_fn_class; if fncls__755 == nil { var fncls__755d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_go_check_types_incomparable_cause_cause__219000090_A_fn_class = fncls__755d; tmp1 = fncls__755d } else { tmp1 = fncls__755 }; cause__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_cause__2), tmp1, nil); var or__1927000174__auto____3 any = lang.IFn_Cast(cause__2).Invoke_O_O__O(t__0, lang.PersistentHashSet_EMPTY.Ref()); if




















	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { return Lit_10 } }
//line :311:1
func A_arbace_go_check_types_incomparable_cause_cause__219000090_A_New() *A_arbace_go_check_types_incomparable_cause_cause__219000090_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_incomparable_cause_cause__219000090_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000090_A) Ctor() {}
//line :311:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000090_A) Invoke_O_O_O__O(self, t__1, seen__2 any) any {
	var tmp1 any; var root_709 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = seen__2; var arg_713 any = t__1; if linked_710 == nil { tmp1 = ifn_711.Invoke_O_O__O(arg_712, arg_713) } else { tmp1 = linked_710.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_709, arg_712, arg_713) }; if jrt.J2g_Truth(tmp1) { return nil } else { var seen__3 any; var root_714 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_716 lang.IFn

		if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = seen__2; var arg_718 any = t__1; if linked_715 == nil { seen__3 = ifn_716.Invoke_O_O__O(arg_717, arg_718) } else { seen__3 = linked_715.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_714, arg_717, arg_718) }
		var tmp2 any; var root_719 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = t__1; if linked_720 == nil { tmp2 = ifn_721.Invoke_O__O(arg_722) } else { tmp2 = linked_720.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_719, arg_722) }; if jrt.J2g_Truth(tmp2) {
			var tmp3 any; var root_723 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any; var root_728 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = t__1; if linked_729 == nil { arg_726 = ifn_730.Invoke_O__O(arg_731) } else { arg_726 = linked_729.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_728, arg_731) }; var arg_727 any = seen__3; if linked_724 == nil { tmp3 = ifn_725.Invoke_O_O__O(arg_726, arg_727) } else { tmp3 = linked_724.(*A_arbace_go_check_types_tset_comparable_QMARK__A).Invoke_O_O_O__O(root_723, arg_726, arg_727) }; if jrt.J2g_Truth(tmp3) { return nil } else { return Lit_10 } } else {
//line :315:1
				var u__4 any; var root_732 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, A_arbace_go_check_types_under_A_fn_class); var ifn_734 lang.IFn

				if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = t__1; if linked_733 == nil { u__4 = ifn_734.Invoke_O__O(arg_735) } else { u__4 = linked_733.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_732, arg_735) }
				var tmp4 any; var root_736 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_738 lang.IFn
				if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = u__4; if linked_737 == nil { tmp4 = ifn_738.Invoke_O__O(arg_739) } else { tmp4 = linked_737.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_736, arg_739) }
//line :318:1
				if jrt.J2g_Truth(tmp4) {
					if lang.Util_Equiv_O_O__Z_NoInit(u__4, A_arbace_go_check_types_A_const_51) { return Lit_10 } else { return nil } } else {
//line :318:1
						if A_arbace_go_check_types_A_const_86 != nil { var G__219000091__5_ any = lang.RT_Nth_O_I__O_NoInit(u__4, lang.RT_IntCast_J__I_NoInit(0))


							switch lang.Util_Hash_O__I_NoInit(G__219000091__5_) >> 4 & 7 { case 0: if any(G__219000091__5_) == any(A_arbace_go_check_types_A_const_74) {




								if jrt.J2g_Truth(lang.IFn_Cast(self).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(u__4, lang.RT_IntCast_J__I_NoInit(2)), seen__3)) { var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_17); var tmp6 any; var root_741 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, A_arbace_go_check_types_type_str_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = t__1; if linked_742 == nil { tmp6 = ifn_743.Invoke_O__O(arg_744) } else { tmp6 = linked_742.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_741, arg_744) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil)).Ref() } else { return nil } }
//line :321:1
							case 1: if any(G__219000091__5_) == any(A_arbace_go_check_types_A_const_79) { return nil }; case 3: if any(G__219000091__5_) == any(A_arbace_go_check_types_A_const_71) { return nil }; case 6: if any(G__219000091__5_) == any(A_arbace_go_check_types_A_const_73) { return nil }; case 7: if any(G__219000091__5_) == any(A_arbace_go_check_types_A_const_82) {

								var root_745 any = A_arbace_go_check_types_A_const_142.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any; var tmp7 any = A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A_New_O_O(self, seen__3); var tmp8 *jrt.Class; var fncls__754 *jrt.Class = A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A_fn_class; if fncls__754 == nil { var fncls__754d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A_fn_class = fncls__754d; tmp8 = fncls__754d } else { tmp8 = fncls__754 }; arg_748 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_749 any = lang.RT_Nth_O_I__O_NoInit(u__4, lang.RT_IntCast_J__I_NoInit(1)); if linked_746 == nil { return ifn_747.Invoke_O_O__O(arg_748, arg_749) } else { return linked_746.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_745, arg_748, arg_749) } }
//line :321:1
							default:}; return Lit_10 } else {
//line :318:1
								return nil
							}
					}
			}
	} }
func A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A{}; t.Ctor_O_O(p0, p1); return t }
//line :323:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A) Ctor_O_O(c__cause, c__seen any) { t.F_cause = c__cause; t.F_seen = c__seen }
//line :323:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A) Invoke_O_O__O(self, fd__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_cause); if jrt.J2g_Truth(tmp1.Invoke_O_O__O(A_arbace_go_check_types_A_const_65.Invoke_O__O(fd__1), t.F_seen)) {
																var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_19, nil, Lit_17); var tmp3 any; var root_750 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, A_arbace_go_check_types_type_str_A_fn_class); var ifn_752 lang.IFn; if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(fd__1); if linked_751 == nil { tmp3 = ifn_752.Invoke_O__O(arg_753) } else { tmp3 = linked_751.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_750, arg_753) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref() } else {
//line :323:1
		return nil } }






func A_arbace_go_check_types_comparable_QMARK__A_New() *A_arbace_go_check_types_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_QMARK__A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Ctor() {}
//line :330:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Invoke_O_O_O__O(self, t__0, seen__1 any) any {



	var root_756 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = t__0; var arg_760 any = jrt.Boolean_TRUE.Ref(); var arg_761 any = seen__1; if linked_757 == nil { return ifn_758.Invoke_O_O_O__O(arg_759, arg_760, arg_761) } else { return linked_757.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_756, arg_759, arg_760, arg_761) } }
//line :330:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Invoke_O_O__O(self, t__0 any) any {


	var root_762 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_764 lang.IFn; if linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = t__0; var arg_766 any = jrt.Boolean_TRUE.Ref(); var arg_767 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_763 == nil { return ifn_764.Invoke_O_O_O__O(arg_765, arg_766, arg_767) } else { return linked_763.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_762, arg_765, arg_766, arg_767)
	}
}











func A_arbace_go_check_types_union_QMARK__A_New() *A_arbace_go_check_types_union_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_union_QMARK__A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_go_check_types_union_QMARK__A) Ctor() {}
//line :347:1
func (t *A_arbace_go_check_types_union_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_768 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = t__0; if linked_769 == nil { and__1927000168__auto____2 = ifn_770.Invoke_O__O(arg_771) } else { and__1927000168__auto____2 = linked_769.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_768, arg_771) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_143; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_go_check_types_term_disjoint_QMARK__A_New() *A_arbace_go_check_types_term_disjoint_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_disjoint_QMARK__A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_go_check_types_term_disjoint_QMARK__A) Ctor() {}
//line :349:1
func (t *A_arbace_go_check_types_term_disjoint_QMARK__A) Invoke_O_O_O__O(self, p__219000098__0, p__219000099__1 any) any { var vec__219000100__3 any = p__219000098__0; var xt__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000100__3, lang.RT_IntCast_J__I_NoInit(0), nil); var x__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000100__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__219000103__6 any = p__219000099__1; var yt__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000103__6, lang.RT_IntCast_J__I_NoInit(0), nil); var y__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000103__6, lang.RT_IntCast_J__I_NoInit(1), nil); var root_772 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_774 lang.IFn; if
																linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any; var root_776 any = A_arbace_go_check_types_A_const_144.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any; if jrt.J2g_Truth(yt__7) { var root_781 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, A_arbace_go_check_types_under_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = x__5; if linked_782 == nil { arg_779 = ifn_783.Invoke_O__O(arg_784) } else { arg_779 = linked_782.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_781, arg_784) } } else { arg_779 = x__5 }; var arg_780 any; if jrt.J2g_Truth(xt__4) { var root_785 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, A_arbace_go_check_types_under_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = y__8; if linked_786 == nil { arg_780 = ifn_787.Invoke_O__O(arg_788) } else { arg_780 = linked_786.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_785, arg_788) } } else { arg_780 = y__8 }; if linked_777 == nil { arg_775 = ifn_778.Invoke_O_O__O(arg_779, arg_780) } else { arg_775 = linked_777.(*A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_776, arg_779, arg_780) }; if linked_773 == nil { return ifn_774.Invoke_O__O(arg_775) } else { return linked_773.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_772, arg_775) } }

func A_arbace_go_check_types_term_union_A_New() *A_arbace_go_check_types_term_union_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_union_A{}; t.Ctor(); return t }
//line :352:1
func (t *A_arbace_go_check_types_term_union_A) Ctor() {}
//line :352:1
func (t *A_arbace_go_check_types_term_union_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	var tmp1 any; var root_789 any = A_arbace_go_check_types_A_const_145.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_791 lang.IFn
	if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = x__0; var arg_793 any = y__1; if linked_790 == nil { tmp1 = ifn_791.Invoke_O_O__O(arg_792, arg_793) } else { tmp1 = linked_790.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_789, arg_792, arg_793) }
//line :353:1
	if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(x__0, y__1) } else { var tmp2 any; var or__1927000174__auto____3 any; var root_794 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_796 lang.IFn

		if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any = x__0; if linked_795 == nil { or__1927000174__auto____3 = ifn_796.Invoke_O__O(arg_797) } else { or__1927000174__auto____3 = linked_795.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_794, arg_797) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_798 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any; var root_802 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = y__1; if linked_803 == nil { arg_801 = ifn_804.Invoke_O__O(arg_805) } else { arg_801 = linked_803.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_802, arg_805) }; if linked_799 == nil { tmp2 = ifn_800.Invoke_O__O(arg_801) } else { tmp2 = linked_799.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_798, arg_801) } }
//line :353:1
		if jrt.J2g_Truth(tmp2) { return lang.Tuple_Create_O__IPersistentVector(x__0) } else { if A_arbace_go_check_types_A_const_86 != nil { return lang.Tuple_Create_O__IPersistentVector(y__1) } else { return nil
		}
		}
	}
}
func A_arbace_go_check_types_term_intersect_A_New() *A_arbace_go_check_types_term_intersect_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_intersect_A{}; t.Ctor(); return t }
//line :358:1
func (t *A_arbace_go_check_types_term_intersect_A) Ctor() {}
//line :358:1
func (t *A_arbace_go_check_types_term_intersect_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	var tmp1 any; var root_806 any = A_arbace_go_check_types_A_const_145.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_808 lang.IFn
	if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = x__0; var arg_810 any = y__1; if linked_807 == nil { tmp1 = ifn_808.Invoke_O_O__O(arg_809, arg_810) } else { tmp1 = linked_807.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_806, arg_809, arg_810) }
//line :359:1
	if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; var or__1927000174__auto____3 any; var root_811 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_811, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_813 lang.IFn

		if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any; var root_815 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_817 lang.IFn; if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any = x__0; if linked_816 == nil { arg_814 = ifn_817.Invoke_O__O(arg_818) } else { arg_814 = linked_816.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_815, arg_818) }; if linked_812 == nil { or__1927000174__auto____3 = ifn_813.Invoke_O__O(arg_814) } else { or__1927000174__auto____3 = linked_812.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_811, arg_814) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_819 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_819, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_821 lang.IFn; if linked_820 == nil { ifn_821 = lang.IFn_Cast(root_819) } else { ifn_821 = nil }; var arg_822 any = y__1; if linked_820 == nil { tmp2 = ifn_821.Invoke_O__O(arg_822) } else { tmp2 = linked_820.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_819, arg_822) } }
//line :359:1
		if jrt.J2g_Truth(tmp2) { return x__0 } else { if A_arbace_go_check_types_A_const_86 != nil { return y__1 } else { return nil
		}
		}
	}
}
func A_arbace_go_check_types_term_includes_QMARK__A_New() *A_arbace_go_check_types_term_includes_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_includes_QMARK__A{}; t.Ctor(); return t }
//line :364:1
func (t *A_arbace_go_check_types_term_includes_QMARK__A) Ctor() {}
//line :364:1
func (t *A_arbace_go_check_types_term_includes_QMARK__A) Invoke_O_O_O__O(self, p__219000109__0, t__1 any) any { var vec__219000110__3 any = p__219000109__0; var tilde__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000110__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000110__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_823 any = A_arbace_go_check_types_A_const_144.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_825 lang.IFn; if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any = ty__5; var arg_827 any; if jrt.J2g_Truth(tilde__4) { var root_828 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, A_arbace_go_check_types_under_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = t__1; if linked_829 == nil { arg_827 = ifn_830.Invoke_O__O(arg_831) } else { arg_827 = linked_829.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_828, arg_831) } } else { arg_827 = t__1 }; if linked_824 == nil { return ifn_825.Invoke_O_O__O(arg_826, arg_827) } else { return linked_824.(*A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_823, arg_826, arg_827) } }

func A_arbace_go_check_types_term_subset_QMARK__A_New() *A_arbace_go_check_types_term_subset_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_subset_QMARK__A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_go_check_types_term_subset_QMARK__A) Ctor() {}
//line :366:1
func (t *A_arbace_go_check_types_term_subset_QMARK__A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var and__1927000168__auto____3 any; var root_832 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_834 lang.IFn; if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any; var root_836 any = A_arbace_go_check_types_A_const_145.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = x__0; var arg_840 any = y__1; if linked_837 == nil { arg_835 = ifn_838.Invoke_O_O__O(arg_839, arg_840) } else { arg_835 = linked_837.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_836, arg_839, arg_840) }; if linked_833 == nil { and__1927000168__auto____3 = ifn_834.Invoke_O__O(arg_835) } else { and__1927000168__auto____3 = linked_833.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_832, arg_835) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var root_841 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any; var root_845 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_845, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any = x__0; if linked_846 == nil { arg_844 = ifn_847.Invoke_O__O(arg_848) } else { arg_844 = linked_846.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_845, arg_848) }; if linked_842 == nil { or__1927000174__auto____4 = ifn_843.Invoke_O__O(arg_844) } else { or__1927000174__auto____4 = linked_842.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_841, arg_844) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var root_849 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_849, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_851 lang.IFn; if linked_850 == nil { ifn_851 = lang.IFn_Cast(root_849) } else { ifn_851 = nil }; var arg_852 any = y__1; if linked_850 == nil { return ifn_851.Invoke_O__O(arg_852) } else { return linked_850.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_849, arg_852) } } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_terms_norm_A_New() *A_arbace_go_check_types_terms_norm_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_norm_A{}; t.Ctor(); return t }
//line :368:1
func (t *A_arbace_go_check_types_terms_norm_A) Ctor() {}
//line :368:1
func (t *A_arbace_go_check_types_terms_norm_A) Invoke_O_O__O(self, ts__0 any) any { { var ts__2 any; var root_853 any = A_arbace_go_check_types_A_const_147.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_855 lang.IFn


	if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = ts__0; if linked_854 == nil { ts__2 = ifn_855.Invoke_O__O(arg_856) } else { ts__2 = linked_854.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_853, arg_856) }
//line :368:1
	var n__3 int32 = lang.RT_Count_O__I_NoInit(ts__2); var used__4 any = lang.Numbers_Boolean_array_O__Z1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref()).Ref(); var i__5 int64 = 0; var rl__6 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




		if lang.Util_Equiv_J_J__Z_NoInit(i__5, int64(n__3)) {

			var root_857 any = A_arbace_go_check_types_A_const_68.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any; var root_862 any = A_arbace_go_check_types_A_const_148.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_862, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_864 lang.IFn; if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any = rl__6; if linked_863 == nil { arg_860 = ifn_864.Invoke_O__O(arg_865) } else { arg_860 = linked_863.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_862, arg_865) }; var arg_861 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_149, rl__6)); if linked_858 == nil { return ifn_859.Invoke_O_O__O(arg_860, arg_861) } else { return linked_858.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_857, arg_860, arg_861) } } else {
				if lang.RT_Aget_Z1_I__Z_NoInit(jrt.BooleanArray_Cast(used__4), lang.RT_IntCast_J__I_NoInit(i__5)) {
					i__5, rl__6 = lang.Numbers_Inc_J__J_NoInit(i__5), rl__6; continue L1 } else {
//line :376:1
						var xi__7 any; var tmp1 any = A_arbace_go_check_types_terms_norm_fn__219000115_A_New_J_I_O_O(i__5, n__3, used__4, ts__2); var tmp2 *jrt.Class
						var fncls__875 /*line :376:1*/*jrt.Class = A_arbace_go_check_types_terms_norm_fn__219000115_A_fn_class

						if fncls__875 == nil { var fncls__875d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_go_check_types_terms_norm_fn__219000115_A_fn_class = fncls__875d; tmp2 = fncls__875d } else { tmp2 = fncls__875 }; xi__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()







						var tmp3 int64 = lang.Numbers_Inc_J__J_NoInit(i__5); var tmp4 any; var root_876 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = rl__6; var arg_880 any = xi__7; if linked_877 == nil { tmp4 = ifn_878.Invoke_O_O__O(arg_879, arg_880) } else { tmp4 = linked_877.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_876, arg_879, arg_880) }; i__5, rl__6 = tmp3, tmp4; continue L1 } } } }; /*line :368:1*/panic("j2g: unreachable") }









func A_arbace_go_check_types_terms_norm_fn__219000115_A_New_J_I_O_O(p0 int64, p1 int32, p2, p3 any) *A_arbace_go_check_types_terms_norm_fn__219000115_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_norm_fn__219000115_A{}; t.Ctor_J_I_O_O(p0, p1, p2, p3); return t }
//line :378:1
func (t *A_arbace_go_check_types_terms_norm_fn__219000115_A) Ctor_J_I_O_O(c__i int64, c__n int32, c__used, c__ts any) { t.F_i = c__i; t.F_n = c__n; t.F_used = c__used; t.F_ts = c__ts }
//line :378:1
func (t *A_arbace_go_check_types_terms_norm_fn__219000115_A) Invoke_O__O(self any) any { { var j__1 int64 = lang.Numbers_Inc_J__J_NoInit(t.F_i); var tmp1 any = t.F_ts; var xi__2 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(t.F_i)); L1: for {
											if lang.Util_Equiv_J_J__Z_NoInit(j__1, int64(t.F_n)) { return xi__2 } else { var tmp2 *jrt.BooleanArray = jrt.BooleanArray_Cast(t.F_used); if lang.RT_Aget_Z1_I__Z_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(j__1)) {

		j__1, xi__2 = lang.Numbers_Inc_J__J_NoInit(j__1), xi__2; continue L1 } else {
//line :379:1
			if A_arbace_go_check_types_A_const_86 != nil { var u__3 any; var root_866 any = A_arbace_go_check_types_A_const_150.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, A_arbace_go_check_types_term_union_A_fn_class); var ifn_868 lang.IFn


				if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = xi__2; var tmp3 any = t.F_ts; var arg_870 any = lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(j__1)); if linked_867 == nil { u__3 = ifn_868.Invoke_O_O__O(arg_869, arg_870) } else { u__3 = linked_867.(*A_arbace_go_check_types_term_union_A).Invoke_O_O_O__O(root_866, arg_869, arg_870) }
				if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(u__3))) {
					var tmp4 *jrt.BooleanArray = jrt.BooleanArray_Cast(t.F_used); jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_Aset_Z1_I_Z__Z_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(j__1), jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z())); var tmp5 int64 = lang.Numbers_Inc_J__J_NoInit(j__1); var tmp6 any; var root_871 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_871, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_873 lang.IFn; if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any = u__3; if linked_872 == nil { tmp6 = ifn_873.Invoke_O__O(arg_874) } else { tmp6 = linked_872.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_871, arg_874) }; j__1, xi__2 = tmp5, tmp6; continue L1 } else {
						j__1, xi__2 = lang.Numbers_Inc_J__J_NoInit(j__1), xi__2; continue L1 } } else {
//line :379:1
							return nil } } } } }; /*line :378:1*/panic("j2g: unreachable") }









func A_arbace_go_check_types_ordered_A_New() *A_arbace_go_check_types_ordered_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ordered_A{}; t.Ctor(); return t }
//line :388:1
func (t *A_arbace_go_check_types_ordered_A) Ctor() {}
//line :388:1
func (t *A_arbace_go_check_types_ordered_A) Invoke_O_O__O(self, ts__0 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_types_A_const_149; var or__1927000174__auto____2 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(ts__0)); if


	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_881 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = ts__0; if linked_882 == nil { return ifn_883.Invoke_O__O(arg_884) } else { return linked_882.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_881, arg_884) } } }

func A_arbace_go_check_types_terms_union_A_New() *A_arbace_go_check_types_terms_union_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_union_A{}; t.Ctor(); return t }
//line :393:1
func (t *A_arbace_go_check_types_terms_union_A) Ctor() {}
//line :393:1
func (t *A_arbace_go_check_types_terms_union_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, x__0); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, y__1) }; if tmp1 { return A_arbace_go_check_types_A_const_131 } else { var root_885 any = A_arbace_go_check_types_A_const_151.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, A_arbace_go_check_types_terms_norm_A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any; var root_889 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_889, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any; var root_894 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, A_arbace_go_check_types_ordered_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = x__0; if linked_895 == nil { arg_892 = ifn_896.Invoke_O__O(arg_897) } else { arg_892 = linked_895.(*A_arbace_go_check_types_ordered_A).Invoke_O_O__O(root_894, arg_897) }; var arg_893 any; var root_898 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, A_arbace_go_check_types_ordered_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = y__1; if linked_899 == nil { arg_893 = ifn_900.Invoke_O__O(arg_901) } else { arg_893 = linked_899.(*A_arbace_go_check_types_ordered_A).Invoke_O_O__O(root_898, arg_901) }; if linked_890 == nil { arg_888 = ifn_891.Invoke_O_O__O(arg_892, arg_893) } else { arg_888 = linked_890.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_889, arg_892, arg_893) }; if linked_886 == nil { return ifn_887.Invoke_O__O(arg_888) } else { return linked_886.(*A_arbace_go_check_types_terms_norm_A).Invoke_O_O__O(root_885, arg_888) } } }

func A_arbace_go_check_types_terms_intersect_A_New() *A_arbace_go_check_types_terms_intersect_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_A{}; t.Ctor(); return t }
//line :395:1
func (t *A_arbace_go_check_types_terms_intersect_A) Ctor() {}
//line :395:1
func (t *A_arbace_go_check_types_terms_intersect_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, x__0) { return y__1 } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, y__1) { return x__0 } else { var tmp1 any; var or__1927000174__auto____3 any; var root_902 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_904 lang.IFn


		if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any = x__0; if linked_903 == nil { or__1927000174__auto____3 = ifn_904.Invoke_O__O(arg_905) } else { or__1927000174__auto____3 = linked_903.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_902, arg_905) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_906 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_908 lang.IFn; if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any = y__1; if linked_907 == nil { tmp1 = ifn_908.Invoke_O__O(arg_909) } else { tmp1 = linked_907.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_906, arg_909) } }
//line :396:1
		if jrt.J2g_Truth(tmp1) { return lang.PersistentHashSet_EMPTY.Ref() } else { if A_arbace_go_check_types_A_const_86 != nil {



			var root_910 any = A_arbace_go_check_types_A_const_151.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_910, A_arbace_go_check_types_terms_norm_A_fn_class); var ifn_912 lang.IFn; if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any; var iter__1927001039__auto____3 any; var tmp2 any = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A_New_O(y__1); var tmp3 *jrt.Class; var fncls__1017 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A_fn_class; if fncls__1017 == nil { var fncls__1017d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A_fn_class = fncls__1017d; tmp3 = fncls__1017d } else { tmp3 = fncls__1017 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp5 any; var root_1018 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, A_arbace_go_check_types_ordered_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = x__0; if linked_1019 == nil { tmp5 = ifn_1020.Invoke_O__O(arg_1021) } else { tmp5 = linked_1019.(*A_arbace_go_check_types_ordered_A).Invoke_O_O__O(root_1018, arg_1021) }; arg_913 = tmp4.Invoke_O__O(tmp5); if linked_911 == nil { return ifn_912.Invoke_O__O(arg_913) } else { return linked_911.(*A_arbace_go_check_types_terms_norm_A).Invoke_O_O__O(root_910, arg_913) } } else {
//line :396:1
				return nil
			}
		}
	} } }
func A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A_New_O(p0 any) *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A{}; t.Ctor_O(p0); return t }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A) Ctor_O(c__y any) { t.F_y = c__y }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A) Invoke_O_O__O(self, s__219000121__1 any) any { var tmp1 any = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A_New_O_O_O(self, s__219000121__1, t.F_y); var tmp2 *jrt.Class; var fncls__1016 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A_fn_class; if fncls__1016 == nil { var fncls__1016d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A_fn_class = fncls__1016d; tmp2 = fncls__1016d } else { tmp2 = fncls__1016 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :400:1
func A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A) Ctor_O_O_O(c__iter__219000120, c__s__219000121, c__y any) { t.F_iter__219000120 = c__iter__219000120; t.F_s__219000121 = c__s__219000121; t.F_y = c__y }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A) Invoke_O__O(self any) any { { var s__219000121__1 any; var t_ any = t.F_s__219000121; t.F_s__219000121 = nil; s__219000121__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_914 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = s__219000121__1; if linked_915 == nil { temp__1927000414__auto____2 = ifn_916.Invoke_O__O(arg_917) } else { temp__1927000414__auto____2 = linked_915.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_914, arg_917) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var a__4 any; var root_918 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = xs__1927001018__auto____3; if linked_919 == nil { a__4 = ifn_920.Invoke_O__O(arg_921) } else { a__4 = linked_919.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_918, arg_921) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A_New_O(a__4); var tmp2 *jrt.Class; var fncls__994 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A_fn_class; if fncls__994 == nil { var fncls__994d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A_fn_class = fncls__994d; tmp2 = fncls__994d } else { tmp2 = fncls__994 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_995 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_995, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_997 lang.IFn; if linked_996 == nil { ifn_997 = lang.IFn_Cast(root_995) } else { ifn_997 = nil }; var arg_998 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_999 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_999, A_arbace_go_check_types_ordered_A_fn_class); var ifn_1001 lang.IFn; if linked_1000 == nil { ifn_1001 = lang.IFn_Cast(root_999) } else { ifn_1001 = nil }; var arg_1002 any = t.F_y; if linked_1000 == nil { tmp4 = ifn_1001.Invoke_O__O(arg_1002) } else { tmp4 = linked_1000.(*A_arbace_go_check_types_ordered_A).Invoke_O_O__O(root_999, arg_1002) }; arg_998 = tmp3.Invoke_O__O(tmp4); if linked_996 == nil { fs__1927001036__auto____6 = ifn_997.Invoke_O__O(arg_998) } else { fs__1927001036__auto____6 = linked_996.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_995, arg_998) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1003 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_1004 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1003, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1005 lang.IFn; if linked_1004 == nil { ifn_1005 = lang.IFn_Cast(root_1003) } else { ifn_1005 = nil }; var arg_1006 any = fs__1927001036__auto____6; var arg_1007 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__219000120); var tmp6 any; var root_1008 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1008, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1010 lang.IFn; if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any = s__219000121__1; if linked_1009 == nil { tmp6 = ifn_1010.Invoke_O__O(arg_1011) } else { tmp6 = linked_1009.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1008, arg_1011) }; arg_1007 = tmp5.Invoke_O__O(tmp6); if linked_1004 == nil { return ifn_1005.Invoke_O_O__O(arg_1006, arg_1007) } else { return linked_1004.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1003, arg_1006, arg_1007) } } else { var tmp7 any; var root_1012 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1014 lang.IFn; if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = s__219000121__1; if linked_1013 == nil { tmp7 = ifn_1014.Invoke_O__O(arg_1015) } else { tmp7 = linked_1013.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1012, arg_1015) }; s__219000121__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :400:1
func A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A_New_O(p0 any) *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A{}; t.Ctor_O(p0); return t }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A) Ctor_O(c__a any) { t.F_a = c__a }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A) Invoke_O_O__O(self, s__219000123__1 any) any { var tmp1 any = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A_New_O_O_O(self, s__219000123__1, t.F_a); var tmp2 *jrt.Class; var fncls__993 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A_fn_class; if fncls__993 == nil { var fncls__993d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A_fn_class = fncls__993d; tmp2 = fncls__993d } else { tmp2 = fncls__993 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :400:1
func A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A) Ctor_O_O_O(c__iter__219000122, c__s__219000123, c__a any) { t.F_iter__219000122 = c__iter__219000122; t.F_s__219000123 = c__s__219000123; t.F_a = c__a }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A) Invoke_O__O(self any) any { { var s__219000123__1 any; var t_ any = t.F_s__219000123; t.F_s__219000123 = nil; s__219000123__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_922 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = s__219000123__1; if linked_923 == nil { temp__1927000414__auto____2 = ifn_924.Invoke_O__O(arg_925) } else { temp__1927000414__auto____2 = linked_923.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_922, arg_925) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000123__3 any = temp__1927000414__auto____2; var tmp1 any; var root_926 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = s__219000123__3; if linked_927 == nil { tmp1 = ifn_928.Invoke_O__O(arg_929) } else { tmp1 = linked_927.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_926, arg_929) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_930 any = A_arbace_go_check_types_A_const_155.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = s__219000123__3; if linked_931 == nil { c__1927001037__auto____4 = ifn_932.Invoke_O__O(arg_933) } else { c__1927001037__auto____4 = linked_931.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_930, arg_933) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000125__6 any; var root_934 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_935 == nil { b__219000125__6 = ifn_936.Invoke_O__O(arg_937) } else { b__219000125__6 = linked_935.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_934, arg_937) }; var tmp2 any = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A_New_O_I_O_O(b__219000125__6, size__1927001038__auto____5, t.F_a, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__948 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A_fn_class; if fncls__948 == nil { var fncls__948d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A_fn_class = fncls__948d; tmp3 = fncls__948d } else { tmp3 = fncls__948 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_949 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_949, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_951 lang.IFn; if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_952 any; var root_954 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = b__219000125__6; if linked_955 == nil { arg_952 = ifn_956.Invoke_O__O(arg_957) } else { arg_952 = linked_955.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_954, arg_957) }; var arg_953 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000122); var tmp5 any; var root_958 any = A_arbace_go_check_types_A_const_161.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = s__219000123__3; if linked_959 == nil { tmp5 = ifn_960.Invoke_O__O(arg_961) } else { tmp5 = linked_959.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_958, arg_961) }; arg_953 = tmp4.Invoke_O__O(tmp5); if linked_950 == nil { return ifn_951.Invoke_O_O__O(arg_952, arg_953) } else { return linked_950.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_949, arg_952, arg_953) } } else { var root_962 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any; var root_967 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = b__219000125__6; if linked_968 == nil { arg_965 = ifn_969.Invoke_O__O(arg_970) } else { arg_965 = linked_968.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_967, arg_970) }; var arg_966 any; if linked_963 == nil { return ifn_964.Invoke_O_O__O(arg_965, arg_966) } else { return linked_963.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_962, arg_965, arg_966) } } } else { var b__4 any; var root_971 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = s__219000123__3; if linked_972 == nil { b__4 = ifn_973.Invoke_O__O(arg_974) } else { b__4 = linked_972.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_971, arg_974) }; var r__5 any; var root_975 any = A_arbace_go_check_types_A_const_157.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, A_arbace_go_check_types_term_intersect_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = t.F_a; var arg_979 any = b__4; if linked_976 == nil { r__5 = ifn_977.Invoke_O_O__O(arg_978, arg_979) } else { r__5 = linked_976.(*A_arbace_go_check_types_term_intersect_A).Invoke_O_O_O__O(root_975, arg_978, arg_979) }; if jrt.J2g_Truth(r__5) { var root_980 any = A_arbace_go_check_types_A_const_162.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = r__5; var arg_984 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__219000122); var tmp7 any; var root_985 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = s__219000123__3; if linked_986 == nil { tmp7 = ifn_987.Invoke_O__O(arg_988) } else { tmp7 = linked_986.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_985, arg_988) }; arg_984 = tmp6.Invoke_O__O(tmp7); if linked_981 == nil { return ifn_982.Invoke_O_O__O(arg_983, arg_984) } else { return linked_981.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_980, arg_983, arg_984) } } else { var tmp8 any; var root_989 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = s__219000123__3; if linked_990 == nil { tmp8 = ifn_991.Invoke_O__O(arg_992) } else { tmp8 = linked_990.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_989, arg_992) }; s__219000123__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :400:1
func A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A) Ctor_O_I_O_O(c__b__219000125 any, c__size__1927001038__auto__ int32, c__a, c__c__1927001037__auto__ any) { t.F_b__219000125 = c__b__219000125; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_a = c__a; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A) Invoke_O__O(self any) any { { var i__219000124__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000124__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000124__1)); var r__3 any; var root_938 any = A_arbace_go_check_types_A_const_157.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, A_arbace_go_check_types_term_intersect_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = t.F_a; var arg_942 any = b__2; if linked_939 == nil { r__3 = ifn_940.Invoke_O_O__O(arg_941, arg_942) } else { r__3 = linked_939.(*A_arbace_go_check_types_term_intersect_A).Invoke_O_O_O__O(root_938, arg_941, arg_942) }; if jrt.J2g_Truth(r__3) { var root_943 any = A_arbace_go_check_types_A_const_158.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = t.F_b__219000125; var arg_947 any = r__3; if linked_944 == nil { ifn_945.Invoke_O_O__O(arg_946, arg_947) } else { linked_944.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_943, arg_946, arg_947) }; i__219000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000124__1); continue L1 } else { i__219000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000124__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_types_terms_includes_QMARK__A_New() *A_arbace_go_check_types_terms_includes_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_includes_QMARK__A{}; t.Ctor(); return t }
//line :402:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__A) Ctor() {}
//line :402:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__A) Invoke_O_O_O__O(self, xl__0, t__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, xl__0); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp1 any; var root_1022 any = A_arbace_go_check_types_A_const_142.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any; var tmp2 any = A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A_New_O(t__1); var tmp3 *jrt.Class; var fncls__1032 *jrt.Class = A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A_fn_class; if fncls__1032 == nil { var fncls__1032d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A_fn_class = fncls__1032d; tmp3 = fncls__1032d } else { tmp3 = fncls__1032 }; arg_1025 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_1026 any = xl__0; if linked_1023 == nil { tmp1 = ifn_1024.Invoke_O_O__O(arg_1025, arg_1026) } else { tmp1 = linked_1023.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1022, arg_1025, arg_1026) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } }
//line :402:1
func A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A_New_O(p0 any) *A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A{}; t.Ctor_O(p0); return t }
//line :402:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :402:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A) Invoke_O_O__O(self, p1__219000137_SHARP___1 any) any { var root_1027 any = A_arbace_go_check_types_A_const_163.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, A_arbace_go_check_types_term_includes_QMARK__A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = p1__219000137_SHARP___1; var arg_1031 any = t.F_t; if linked_1028 == nil { return ifn_1029.Invoke_O_O__O(arg_1030, arg_1031) } else { return linked_1028.(*A_arbace_go_check_types_term_includes_QMARK__A).Invoke_O_O_O__O(root_1027, arg_1030, arg_1031) } }

func A_arbace_go_check_types_terms_superset_of_QMARK__A_New() *A_arbace_go_check_types_terms_superset_of_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_superset_of_QMARK__A{}; t.Ctor(); return t }
//line :404:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__A) Ctor() {}
//line :404:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__A) Invoke_O_O_O__O(self, xl__0, y__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, xl__0); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp1 any; var root_1033 any = A_arbace_go_check_types_A_const_142.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any; var tmp2 any = A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A_New_O(y__1); var tmp3 *jrt.Class; var fncls__1043 *jrt.Class = A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A_fn_class; if fncls__1043 == nil { var fncls__1043d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A_fn_class = fncls__1043d; tmp3 = fncls__1043d } else { tmp3 = fncls__1043 }; arg_1036 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_1037 any = xl__0; if linked_1034 == nil { tmp1 = ifn_1035.Invoke_O_O__O(arg_1036, arg_1037) } else { tmp1 = linked_1034.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1033, arg_1036, arg_1037) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } }
//line :404:1
func A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A_New_O(p0 any) *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A{}; t.Ctor_O(p0); return t }
//line :404:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A) Ctor_O(c__y any) { t.F_y = c__y }
//line :404:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A) Invoke_O_O__O(self, p1__219000141_SHARP___1 any) any { var root_1038 any = A_arbace_go_check_types_A_const_164.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, A_arbace_go_check_types_term_subset_QMARK__A_fn_class); var ifn_1040 lang.IFn; if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any = t.F_y; var arg_1042 any = p1__219000141_SHARP___1; if linked_1039 == nil { return ifn_1040.Invoke_O_O__O(arg_1041, arg_1042) } else { return linked_1039.(*A_arbace_go_check_types_term_subset_QMARK__A).Invoke_O_O_O__O(root_1038, arg_1041, arg_1042) } }

func A_arbace_go_check_types_terms_subset_QMARK__A_New() *A_arbace_go_check_types_terms_subset_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_subset_QMARK__A{}; t.Ctor(); return t }
//line :406:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__A) Ctor() {}
//line :406:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__A) Invoke_O_O_O__O(self, xl__0, yl__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, yl__1) { return jrt.Boolean_TRUE.Ref() } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, xl__0) { return jrt.Boolean_FALSE.Ref() } else { var tmp1 any; var root_1044 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1046 lang.IFn


		if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = yl__1; if linked_1045 == nil { tmp1 = ifn_1046.Invoke_O__O(arg_1047) } else { tmp1 = linked_1045.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1044, arg_1047) }
//line :409:1
		if jrt.J2g_Truth(tmp1) {


			var root_1048 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any = xl__0; if linked_1049 == nil { return ifn_1050.Invoke_O__O(arg_1051) } else { return linked_1049.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1048, arg_1051) } } else {
//line :409:1
				if A_arbace_go_check_types_A_const_86 != nil {



					var root_1052 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1052, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1054 lang.IFn; if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any; var tmp2 any = A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A_New_O(yl__1); var tmp3 *jrt.Class; var fncls__1062 *jrt.Class = A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A_fn_class; if fncls__1062 == nil { var fncls__1062d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A_fn_class = fncls__1062d; tmp3 = fncls__1062d } else { tmp3 = fncls__1062 }; arg_1055 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_1056 any = xl__0; if linked_1053 == nil { return ifn_1054.Invoke_O_O__O(arg_1055, arg_1056) } else { return linked_1053.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1052, arg_1055, arg_1056) } } else {
//line :409:1
						return nil
					}
			}
	} } }
func A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A_New_O(p0 any) *A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A{}; t.Ctor_O(p0); return t }
//line :413:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A) Ctor_O(c__yl any) { t.F_yl = c__yl }
//line :413:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A) Invoke_O_O__O(self, p1__219000145_SHARP___1 any) any { var root_1057 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, A_arbace_go_check_types_terms_superset_of_QMARK__A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = t.F_yl; var arg_1061 any = p1__219000145_SHARP___1; if linked_1058 == nil { return ifn_1059.Invoke_O_O__O(arg_1060, arg_1061) } else { return linked_1058.(*A_arbace_go_check_types_terms_superset_of_QMARK__A).Invoke_O_O_O__O(root_1057, arg_1060, arg_1061) } }

func A_arbace_go_check_types_make_tset_A_New() *A_arbace_go_check_types_make_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_make_tset_A{}; t.Ctor(); return t }
//line :415:1
func (t *A_arbace_go_check_types_make_tset_A) Ctor() {}
//line :415:1
func (t *A_arbace_go_check_types_make_tset_A) Invoke_O_O_O__O(self, terms__0, comparable__1 any) any {


	var tmp1 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, terms__0); if and__1927000168__auto____3 { var root_1063 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1065 lang.IFn; if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any = comparable__1; if linked_1064 == nil { tmp1 = ifn_1065.Invoke_O__O(arg_1066) } else { tmp1 = linked_1064.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1063, arg_1066) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any = A_arbace_go_check_types_A_const_132; var tmp3 any = A_arbace_go_check_types_A_const_133; var tmp4 any; var and__1927000168__auto____3_2 any = comparable__1; if jrt.J2g_Truth(and__1927000168__auto____3_2) { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, terms__0)).Ref() } else { tmp4 = and__1927000168__auto____3_2 }; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, terms__0, tmp3, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp4)).Ref()))
	} }
func A_arbace_go_check_types_iface_tset_A_New() *A_arbace_go_check_types_iface_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_iface_tset_A{}; t.Ctor(); return t }
//line :420:1
func (t *A_arbace_go_check_types_iface_tset_A) Ctor() {}
//line :420:1
func (t *A_arbace_go_check_types_iface_tset_A) Invoke_O_O__O(self, u__0 any) any { var ts__2 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(2)); var tmp1 any = A_arbace_go_check_types_A_const_98; var tmp2 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp3 any = A_arbace_go_check_types_A_const_132; var tmp4 any; var tmp5 any; var root_1067 any = A_arbace_go_check_types_A_const_166.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1069 lang.IFn; if





	linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any = ts__2; if linked_1068 == nil { tmp5 = ifn_1069.Invoke_O__O(arg_1070) } else { tmp5 = linked_1068.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1067, arg_1070) }; if jrt.J2g_Truth(tmp5) { tmp4 = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__2) } else { tmp4 = A_arbace_go_check_types_A_const_131 }; var tmp6 any = tmp4; var tmp7 any = A_arbace_go_check_types_A_const_133; var tmp8 any; var and__1927000168__auto____3 any; var root_1071 any = /*line :420:1*/A_arbace_go_check_types_A_const_166.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1073 lang.IFn; if






	linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = ts__2; if linked_1072 == nil { and__1927000168__auto____3 = ifn_1073.Invoke_O__O(arg_1074) } else { and__1927000168__auto____3 = linked_1072.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1071, arg_1074) }; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp8 = A_arbace_go_check_types_A_const_133.Invoke_O__O(ts__2) } else { tmp8 = and__1927000168__auto____3 }; return /*line :420:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp6, tmp7, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp8)).Ref())) }








func A_arbace_go_check_types_has_terms_QMARK__A_New() *A_arbace_go_check_types_has_terms_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_terms_QMARK__A{}; t.Ctor(); return t }
//line :429:1
func (t *A_arbace_go_check_types_has_terms_QMARK__A) Ctor() {}
//line :429:1
func (t *A_arbace_go_check_types_has_terms_QMARK__A) Invoke_O_O__O(self, ts__0 any) any { var terms__2 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__0); var and__1927000168__auto____3 any; var root_1075 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1077 lang.IFn; if


	linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = A_arbace_go_check_types_A_const_131; var arg_1079 any = terms__2; if linked_1076 == nil { and__1927000168__auto____3 = ifn_1077.Invoke_O_O__O(arg_1078, arg_1079) } else { and__1927000168__auto____3 = linked_1076.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1075, arg_1078, arg_1079) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1080 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1080, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1082 lang.IFn; if linked_1081 == nil { ifn_1082 = lang.IFn_Cast(root_1080) } else { ifn_1082 = nil }; var arg_1083 any = terms__2; if linked_1081 == nil { return ifn_1082.Invoke_O__O(arg_1083) } else { return linked_1081.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1080, arg_1083) } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_tset_empty_QMARK__A_New() *A_arbace_go_check_types_tset_empty_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_empty_QMARK__A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_go_check_types_tset_empty_QMARK__A) Ctor() {}
//line :434:1
func (t *A_arbace_go_check_types_tset_empty_QMARK__A) Invoke_O_O__O(self, ts__0 any) any { var and__1927000168__auto____2 any; var root_1084 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1084, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1086 lang.IFn; if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any = A_arbace_go_check_types_A_const_131; var arg_1088 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__0); if linked_1085 == nil { and__1927000168__auto____2 = ifn_1086.Invoke_O_O__O(arg_1087, arg_1088) } else { and__1927000168__auto____2 = linked_1085.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1084, arg_1087, arg_1088) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1089 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1091 lang.IFn; if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__0); if linked_1090 == nil { return ifn_1091.Invoke_O__O(arg_1092) } else { return linked_1090.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1089, arg_1092) } } else { return and__1927000168__auto____2 } }

func A_arbace_go_check_types_method_set_iface_QMARK__A_New() *A_arbace_go_check_types_method_set_iface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_method_set_iface_QMARK__A{}; t.Ctor(); return t }
//line :436:1
func (t *A_arbace_go_check_types_method_set_iface_QMARK__A) Ctor() {}
//line :436:1
func (t *A_arbace_go_check_types_method_set_iface_QMARK__A) Invoke_O_O__O(self, u__0 any) any {



	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref()
}
func A_arbace_go_check_types_bound_iface_A_New() *A_arbace_go_check_types_bound_iface_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_bound_iface_A{}; t.Ctor(); return t }
//line :442:1
func (t *A_arbace_go_check_types_bound_iface_A) Ctor() {}
//line :442:1
func (t *A_arbace_go_check_types_bound_iface_A) Invoke_O_O__O(self, b__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any = b__0; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1093 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = A_arbace_go_check_types_A_const_103; var arg_1097 any = b__0; if linked_1094 == nil { tmp1 = ifn_1095.Invoke_O_O__O(arg_1096, arg_1097) } else { tmp1 = linked_1094.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1093, arg_1096, arg_1097) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var u__2 any; var root_1098 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_1099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1098, A_arbace_go_check_types_under_A_fn_class); var ifn_1100 lang.IFn
		if linked_1099 == nil { ifn_1100 = lang.IFn_Cast(root_1098) } else { ifn_1100 = nil }; var arg_1101 any = b__0; if linked_1099 == nil { u__2 = ifn_1100.Invoke_O__O(arg_1101) } else { u__2 = linked_1099.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1098, arg_1101) }
		if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_103, u__2) { return nil } else { var tmp2 any; var and__1927000168__auto____3 any; var root_1102 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1102, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1104 lang.IFn

			if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any = u__2; if linked_1103 == nil { and__1927000168__auto____3 = ifn_1104.Invoke_O__O(arg_1105) } else { and__1927000168__auto____3 = linked_1103.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1102, arg_1105) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_go_check_types_A_const_71; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :448:1
			if jrt.J2g_Truth(tmp2) { return u__2 } else { var tmp4 any; var root_1106 any = A_arbace_go_check_types_A_const_167.GetRawRoot__O(); var linked_1107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1106, A_arbace_go_check_types_union_QMARK__A_fn_class); var ifn_1108 lang.IFn


				if linked_1107 == nil { ifn_1108 = lang.IFn_Cast(root_1106) } else { ifn_1108 = nil }; var arg_1109 any = u__2; if linked_1107 == nil { tmp4 = ifn_1108.Invoke_O__O(arg_1109) } else { tmp4 = linked_1107.(*A_arbace_go_check_types_union_QMARK__A).Invoke_O_O__O(root_1106, arg_1109) }
//line :448:1
				if jrt.J2g_Truth(tmp4) { var tmp5 any = A_arbace_go_check_types_A_const_71; var tmp6 any = lang.PersistentVector_EMPTY.Ref(); var tmp7 any; var root_1110 any = A_arbace_go_check_types_A_const_168.GetRawRoot__O(); var linked_1111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1110, A_arbace_go_check_types_make_tset_A_fn_class); var ifn_1112 lang.IFn


					if linked_1111 == nil { ifn_1112 = lang.IFn_Cast(root_1110) } else { ifn_1112 = nil }; var arg_1113 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); var arg_1114 any = jrt.Boolean_FALSE.Ref(); if linked_1111 == nil { tmp7 = ifn_1112.Invoke_O_O__O(arg_1113, arg_1114) } else { tmp7 = linked_1111.(*A_arbace_go_check_types_make_tset_A).Invoke_O_O_O__O(root_1110, arg_1113, arg_1114) }
//line :448:1
					return lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, tmp7) } else { if A_arbace_go_check_types_A_const_86 != nil { var tmp8 any = A_arbace_go_check_types_A_const_71; var tmp9 any = lang.PersistentVector_EMPTY.Ref(); var tmp10 any; var root_1115 any = A_arbace_go_check_types_A_const_168.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, A_arbace_go_check_types_make_tset_A_fn_class); var ifn_1117 lang.IFn



						if linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(jrt.Boolean_FALSE.Ref(), b__0))); var arg_1119 any = jrt.Boolean_FALSE.Ref(); if linked_1116 == nil { tmp10 = ifn_1117.Invoke_O_O__O(arg_1118, arg_1119) } else { tmp10 = linked_1116.(*A_arbace_go_check_types_make_tset_A).Invoke_O_O_O__O(root_1115, arg_1118, arg_1119) }
//line :448:1
						return lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp9, tmp10) } else { return nil } } } } } else {
//line :446:1
							return nil
						}
}





func A_arbace_go_check_types_tparam_iface_A_New() *A_arbace_go_check_types_tparam_iface_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_iface_A{}; t.Ctor(); return t }
//line :454:1
func (t *A_arbace_go_check_types_tparam_iface_A) Ctor() {}
//line :454:1
func (t *A_arbace_go_check_types_tparam_iface_A) Invoke_O_O__O(self, tp__0 any) any { var i__2 any; var root_1120 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_1121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1120, A_arbace_go_check_types_info_A_fn_class); var ifn_1122 lang.IFn; if


	linked_1121 == nil { ifn_1122 = lang.IFn_Cast(root_1120) } else { ifn_1122 = nil }; var arg_1123 any = tp__0; if linked_1121 == nil { i__2 = ifn_1122.Invoke_O__O(arg_1123) } else { i__2 = linked_1121.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1120, arg_1123) }; var or__1927000174__auto____3 any = /*line :454:1*/A_arbace_go_check_types_A_const_169.Invoke_O__O(i__2); if



	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000408__auto____4 any; var root_1124 any = A_arbace_go_check_types_A_const_170.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1124, A_arbace_go_check_types_bound_iface_A_fn_class); var ifn_1126 lang.IFn
		if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any = A_arbace_go_check_types_A_const_171.Invoke_O__O(i__2); if linked_1125 == nil { temp__1927000408__auto____4 = ifn_1126.Invoke_O__O(arg_1127) } else { temp__1927000408__auto____4 = linked_1125.(*A_arbace_go_check_types_bound_iface_A).Invoke_O_O__O(root_1124, arg_1127) }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var r__5 any = temp__1927000408__auto____4
			lang.IFn_Cast(A_arbace_go_check_types_A_const_172.GetRawRoot__O()).Invoke_O_O_O_O__O(tp__0, A_arbace_go_check_types_A_const_67.GetRawRoot__O(), A_arbace_go_check_types_A_const_169, r__5)
//line :459:1
			return r__5 } else { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_71, lang.PersistentVector_EMPTY.Ref(), nil) } } }



func A_arbace_go_check_types_tparam_tset_A_New() *A_arbace_go_check_types_tparam_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_tset_A{}; t.Ctor(); return t }
//line :463:1
func (t *A_arbace_go_check_types_tparam_tset_A) Ctor() {}
//line :463:1
func (t *A_arbace_go_check_types_tparam_tset_A) Invoke_O_O__O(self, tp__0 any) any { var root_1135 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_1137 lang.IFn; if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any; var root_1139 any = A_arbace_go_check_types_A_const_107.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, A_arbace_go_check_types_tparam_iface_A_fn_class); var ifn_1141 lang.IFn; if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any = tp__0; if linked_1140 == nil { arg_1138 = ifn_1141.Invoke_O__O(arg_1142) } else { arg_1138 = linked_1140.(*A_arbace_go_check_types_tparam_iface_A).Invoke_O_O__O(root_1139, arg_1142) }; if linked_1136 == nil { return ifn_1137.Invoke_O__O(arg_1138) } else { return linked_1136.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_1135, arg_1138) } }

func A_arbace_go_check_types_typeset_pairs_A_New() *A_arbace_go_check_types_typeset_pairs_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_A{}; t.Ctor(); return t }
//line :465:1
func (t *A_arbace_go_check_types_typeset_pairs_A) Ctor() {}
//line :465:1
func (t *A_arbace_go_check_types_typeset_pairs_A) Invoke_O_O__O(self, t__0 any) any {



	var tmp1 any; var root_1143 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1143, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_1145 lang.IFn; if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = t__0; if linked_1144 == nil { tmp1 = ifn_1145.Invoke_O__O(arg_1146) } else { tmp1 = linked_1144.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_1143, arg_1146) }; if jrt.J2g_Truth(tmp1) { var ts__2 any; var root_1147 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_1149 lang.IFn
		if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any = t__0; if linked_1148 == nil { ts__2 = ifn_1149.Invoke_O__O(arg_1150) } else { ts__2 = linked_1148.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_1147, arg_1150) }
		var tmp2 any; var root_1151 any = A_arbace_go_check_types_A_const_173.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_1153 lang.IFn; if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any = ts__2; if linked_1152 == nil { tmp2 = ifn_1153.Invoke_O__O(arg_1154) } else { tmp2 = linked_1152.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_1151, arg_1154) }; if jrt.J2g_Truth(tmp2) { var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A_New(); var tmp4 *jrt.Class; var fncls__1221 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A_fn_class
			if fncls__1221 == nil { var fncls__1221d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A_fn_class = fncls__1221d; tmp4 = fncls__1221d } else { tmp4 = fncls__1221 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); return lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__2)) } else {
//line :471:1
				return A_arbace_go_check_types_A_const_174 } } else {
//line :469:1
					var tmp5 any; var root_1222 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_1223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1222, A_arbace_go_check_types_under_A_fn_class); var ifn_1224 lang.IFn




					if linked_1223 == nil { ifn_1224 = lang.IFn_Cast(root_1222) } else { ifn_1224 = nil }; var arg_1225 any = t__0; if linked_1223 == nil { tmp5 = ifn_1224.Invoke_O__O(arg_1225) } else { tmp5 = linked_1223.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1222, arg_1225) }
//line :469:1
					return lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(t__0, tmp5))
				}
}
func A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A_New() *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A{}; t.Ctor(); return t }
//line :472:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A) Ctor() {}
//line :472:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A) Invoke_O_O__O(self, s__219000158__1 any) any { var tmp1 any = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A_New_O_O(self, s__219000158__1); var tmp2 *jrt.Class; var fncls__1220 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A_fn_class; if fncls__1220 == nil { var fncls__1220d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A_fn_class = fncls__1220d; tmp2 = fncls__1220d } else { tmp2 = fncls__1220 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :472:1
func A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A{}; t.Ctor_O_O(p0, p1); return t }
//line :472:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A) Ctor_O_O(c__iter__219000157, c__s__219000158 any) { t.F_iter__219000157 = c__iter__219000157; t.F_s__219000158 = c__s__219000158 }
//line :472:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A) Invoke_O__O(self any) any { { var s__219000158__1 any; var t_ any = t.F_s__219000158; t.F_s__219000158 = nil; s__219000158__1 = t_; for { var temp__1927000414__auto____2 any; var root_1155 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1157 lang.IFn; if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any = s__219000158__1; if linked_1156 == nil { temp__1927000414__auto____2 = ifn_1157.Invoke_O__O(arg_1158) } else { temp__1927000414__auto____2 = linked_1156.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1155, arg_1158) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000158__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1159 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1159, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1161 lang.IFn; if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = s__219000158__3; if linked_1160 == nil { tmp1 = ifn_1161.Invoke_O__O(arg_1162) } else { tmp1 = linked_1160.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1159, arg_1162) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1163 any = A_arbace_go_check_types_A_const_155.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any = s__219000158__3; if linked_1164 == nil { c__1927001037__auto____4 = ifn_1165.Invoke_O__O(arg_1166) } else { c__1927001037__auto____4 = linked_1164.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1163, arg_1166) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000160__6 any; var root_1167 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1168 == nil { b__219000160__6 = ifn_1169.Invoke_O__O(arg_1170) } else { b__219000160__6 = linked_1168.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1167, arg_1170) }; var tmp2 any = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A_New_O_I_O(b__219000160__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1180 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A_fn_class; if fncls__1180 == nil { var fncls__1180d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A_fn_class = fncls__1180d; tmp3 = fncls__1180d } else { tmp3 = fncls__1180 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1181 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any; var root_1186 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1188 lang.IFn; if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any = b__219000160__6; if linked_1187 == nil { arg_1184 = ifn_1188.Invoke_O__O(arg_1189) } else { arg_1184 = linked_1187.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1186, arg_1189) }; var arg_1185 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000157); var tmp5 any; var root_1190 any = A_arbace_go_check_types_A_const_161.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = s__219000158__3; if linked_1191 == nil { tmp5 = ifn_1192.Invoke_O__O(arg_1193) } else { tmp5 = linked_1191.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1190, arg_1193) }; arg_1185 = tmp4.Invoke_O__O(tmp5); if linked_1182 == nil { return ifn_1183.Invoke_O_O__O(arg_1184, arg_1185) } else { return linked_1182.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1181, arg_1184, arg_1185) } } else { var root_1194 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1194, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1196 lang.IFn; if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any; var root_1199 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1201 lang.IFn; if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any = b__219000160__6; if linked_1200 == nil { arg_1197 = ifn_1201.Invoke_O__O(arg_1202) } else { arg_1197 = linked_1200.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1199, arg_1202) }; var arg_1198 any; if linked_1195 == nil { return ifn_1196.Invoke_O_O__O(arg_1197, arg_1198) } else { return linked_1195.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1194, arg_1197, arg_1198) } } } else { var vec__219000168__4 any; var root_1203 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1203, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1205 lang.IFn; if linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any = s__219000158__3; if linked_1204 == nil { vec__219000168__4 = ifn_1205.Invoke_O__O(arg_1206) } else { vec__219000168__4 = linked_1204.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1203, arg_1206) }; var tilde__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000168__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000168__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1207 any = A_arbace_go_check_types_A_const_162.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any; var tmp6 any; if jrt.J2g_Truth(tilde__5) { tmp6 = ty__6 } else { var root_1212 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1212, A_arbace_go_check_types_under_A_fn_class); var ifn_1214 lang.IFn; if linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; var arg_1215 any = ty__6; if linked_1213 == nil { tmp6 = ifn_1214.Invoke_O__O(arg_1215) } else { tmp6 = linked_1213.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1212, arg_1215) } }; arg_1210 = lang.Tuple_Create_O_O__IPersistentVector(ty__6, tmp6); var arg_1211 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__219000157); var tmp8 any; var root_1216 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1216, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1218 lang.IFn; if linked_1217 == nil { ifn_1218 = lang.IFn_Cast(root_1216) } else { ifn_1218 = nil }; var arg_1219 any = s__219000158__3; if linked_1217 == nil { tmp8 = ifn_1218.Invoke_O__O(arg_1219) } else { tmp8 = linked_1217.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1216, arg_1219) }; arg_1211 = tmp7.Invoke_O__O(tmp8); if linked_1208 == nil { return ifn_1209.Invoke_O_O__O(arg_1210, arg_1211) } else { return linked_1208.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1207, arg_1210, arg_1211) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :472:1
func A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :472:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A) Ctor_O_I_O(c__b__219000160 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000160 = c__b__219000160; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :472:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A) Invoke_O__O(self any) any { { var i__219000159__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000159__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__219000164__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000159__1)); var tilde__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000164__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000164__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1171 any = A_arbace_go_check_types_A_const_158.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = t.F_b__219000160; var arg_1175 any; var tmp2 any; if jrt.J2g_Truth(tilde__3) { tmp2 = ty__4 } else { var root_1176 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, A_arbace_go_check_types_under_A_fn_class); var ifn_1178 lang.IFn; if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any = ty__4; if linked_1177 == nil { tmp2 = ifn_1178.Invoke_O__O(arg_1179) } else { tmp2 = linked_1177.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1176, arg_1179) } }; arg_1175 = lang.Tuple_Create_O_O__IPersistentVector(ty__4, tmp2); if linked_1172 == nil { ifn_1173.Invoke_O_O__O(arg_1174, arg_1175) } else { linked_1172.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1171, arg_1174, arg_1175) }; i__219000159__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000159__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_go_check_types_typeset_all_A_New() *A_arbace_go_check_types_typeset_all_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_all_A{}; t.Ctor(); return t }
//line :476:1
func (t *A_arbace_go_check_types_typeset_all_A) Ctor() {}
//line :476:1
func (t *A_arbace_go_check_types_typeset_all_A) Invoke_O_O_O__O(self, t__0, f__1 any) any {


	var root_1226 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any; var tmp1 any = A_arbace_go_check_types_typeset_all_fn__219000175_A_New_O(f__1); var tmp2 *jrt.Class; var fncls__1231 *jrt.Class = A_arbace_go_check_types_typeset_all_fn__219000175_A_fn_class; if fncls__1231 == nil { var fncls__1231d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_go_check_types_typeset_all_fn__219000175_A_fn_class = fncls__1231d; tmp2 = fncls__1231d } else { tmp2 = fncls__1231 }; arg_1229 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1230 any; var root_1232 any = A_arbace_go_check_types_A_const_175.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, A_arbace_go_check_types_typeset_pairs_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = t__0; if linked_1233 == nil { arg_1230 = ifn_1234.Invoke_O__O(arg_1235) } else { arg_1230 = linked_1233.(*A_arbace_go_check_types_typeset_pairs_A).Invoke_O_O__O(root_1232, arg_1235) }; if linked_1227 == nil { return ifn_1228.Invoke_O_O__O(arg_1229, arg_1230) } else { return linked_1227.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1226, arg_1229, arg_1230) } }
//line :479:1
func A_arbace_go_check_types_typeset_all_fn__219000175_A_New_O(p0 any) *A_arbace_go_check_types_typeset_all_fn__219000175_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_all_fn__219000175_A{}; t.Ctor_O(p0); return t }
//line :479:1
func (t *A_arbace_go_check_types_typeset_all_fn__219000175_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :479:1
func (t *A_arbace_go_check_types_typeset_all_fn__219000175_A) Invoke_O_O__O(self, p__219000174__1 any) any { var vec__219000176__2 any = p__219000174__1; var ty__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000176__2, lang.RT_IntCast_J__I_NoInit(0), nil); var u__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000176__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.IFn_Cast(t.F_f).Invoke_O_O__O(ty__3, u__4) }

func A_arbace_go_check_types_under_is_A_New() *A_arbace_go_check_types_under_is_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_is_A{}; t.Ctor(); return t }
//line :481:1
func (t *A_arbace_go_check_types_under_is_A) Ctor() {}
//line :481:1
func (t *A_arbace_go_check_types_under_is_A) Invoke_O_O_O__O(self, t__0, f__1 any) any {



	var root_1236 any = A_arbace_go_check_types_A_const_176.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, A_arbace_go_check_types_typeset_all_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = t__0; var arg_1240 any; var tmp1 any = A_arbace_go_check_types_under_is_fn__219000181_A_New_O(f__1); var tmp2 *jrt.Class; var fncls__1241 *jrt.Class = A_arbace_go_check_types_under_is_fn__219000181_A_fn_class; if fncls__1241 == nil { var fncls__1241d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_go_check_types_under_is_fn__219000181_A_fn_class = fncls__1241d; tmp2 = fncls__1241d } else { tmp2 = fncls__1241 }; arg_1240 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1237 == nil { return ifn_1238.Invoke_O_O__O(arg_1239, arg_1240) } else { return linked_1237.(*A_arbace_go_check_types_typeset_all_A).Invoke_O_O_O__O(root_1236, arg_1239, arg_1240) } }
//line :485:1
func A_arbace_go_check_types_under_is_fn__219000181_A_New_O(p0 any) *A_arbace_go_check_types_under_is_fn__219000181_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_is_fn__219000181_A{}; t.Ctor_O(p0); return t }
//line :485:1
func (t *A_arbace_go_check_types_under_is_fn__219000181_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :485:1
func (t *A_arbace_go_check_types_under_is_fn__219000181_A) Invoke_O_O_O__O(self, ___1, u__2 any) any { return lang.IFn_Cast(t.F_f).Invoke_O__O(u__2) }

func A_arbace_go_check_types_all_basic_A_New() *A_arbace_go_check_types_all_basic_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_basic_A{}; t.Ctor(); return t }
//line :487:1
func (t *A_arbace_go_check_types_all_basic_A) Ctor() {}
//line :487:1
func (t *A_arbace_go_check_types_all_basic_A) Invoke_O_O_O__O(self, t__0, pred__1 any) any {



	var tmp1 any; var root_1242 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_1243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1242, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_1244 lang.IFn; if linked_1243 == nil { ifn_1244 = lang.IFn_Cast(root_1242) } else { ifn_1244 = nil }; var arg_1245 any = t__0; if linked_1243 == nil { tmp1 = ifn_1244.Invoke_O__O(arg_1245) } else { tmp1 = linked_1243.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_1242, arg_1245) }; if jrt.J2g_Truth(tmp1) { var ts__3 any; var root_1246 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1246, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_1248 lang.IFn
		if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var arg_1249 any = t__0; if linked_1247 == nil { ts__3 = ifn_1248.Invoke_O__O(arg_1249) } else { ts__3 = linked_1247.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_1246, arg_1249) }
		var tmp2 any; var and__1927000168__auto____4 any; var root_1250 any = A_arbace_go_check_types_A_const_173.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1250, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_1252 lang.IFn; if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = ts__3; if linked_1251 == nil { and__1927000168__auto____4 = ifn_1252.Invoke_O__O(arg_1253) } else { and__1927000168__auto____4 = linked_1251.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_1250, arg_1253) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1254 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1254, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1256 lang.IFn; if linked_1255 == nil { ifn_1256 = lang.IFn_Cast(root_1254) } else { ifn_1256 = nil }; var arg_1257 any; var tmp3 any = A_arbace_go_check_types_all_basic_fn__219000185_A_New_O(pred__1); var tmp4 *jrt.Class; var fncls__1259 *jrt.Class = A_arbace_go_check_types_all_basic_fn__219000185_A_fn_class; if fncls__1259 == nil { var fncls__1259d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_check_types_all_basic_fn__219000185_A_fn_class = fncls__1259d; tmp4 = fncls__1259d } else { tmp4 = fncls__1259 }; arg_1257 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1258 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__3); if linked_1255 == nil { tmp2 = ifn_1256.Invoke_O_O__O(arg_1257, arg_1258) } else { tmp2 = linked_1255.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1254, arg_1257, arg_1258) } } else { tmp2 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp2)).Ref() } else {
			return lang.IFn_Cast(pred__1).Invoke_O__O(t__0) } }
//line :493:1
func A_arbace_go_check_types_all_basic_fn__219000185_A_New_O(p0 any) *A_arbace_go_check_types_all_basic_fn__219000185_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_basic_fn__219000185_A{}; t.Ctor_O(p0); return t }
//line :493:1
func (t *A_arbace_go_check_types_all_basic_fn__219000185_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :493:1
func (t *A_arbace_go_check_types_all_basic_fn__219000185_A) Invoke_O_O__O(self, p__219000184__1 any) any { var vec__219000186__2 any = p__219000184__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000186__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000186__2, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___3; return lang.IFn_Cast(t.F_pred).Invoke_O__O(ty__4) }


func A_arbace_go_check_types_all_integer_QMARK__A_New() *A_arbace_go_check_types_all_integer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_integer_QMARK__A{}; t.Ctor(); return t }
//line :496:1
func (t *A_arbace_go_check_types_all_integer_QMARK__A) Ctor() {}
//line :496:1
func (t *A_arbace_go_check_types_all_integer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1260 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = t__0; var arg_1264 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); if linked_1261 == nil { return ifn_1262.Invoke_O_O__O(arg_1263, arg_1264) } else { return linked_1261.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1260, arg_1263, arg_1264) } }
func A_arbace_go_check_types_all_unsigned_QMARK__A_New() *A_arbace_go_check_types_all_unsigned_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_unsigned_QMARK__A{}; t.Ctor(); return t }
//line :497:1
func (t *A_arbace_go_check_types_all_unsigned_QMARK__A) Ctor() {}
//line :497:1
func (t *A_arbace_go_check_types_all_unsigned_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1265 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = t__0; var arg_1269 any = A_arbace_go_check_types_A_const_178.GetRawRoot__O(); if linked_1266 == nil { return ifn_1267.Invoke_O_O__O(arg_1268, arg_1269) } else { return linked_1266.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1265, arg_1268, arg_1269) } }
func A_arbace_go_check_types_all_numeric_QMARK__A_New() *A_arbace_go_check_types_all_numeric_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_QMARK__A{}; t.Ctor(); return t }
//line :498:1
func (t *A_arbace_go_check_types_all_numeric_QMARK__A) Ctor() {}
//line :498:1
func (t *A_arbace_go_check_types_all_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1270 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1270, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1272 lang.IFn; if linked_1271 == nil { ifn_1272 = lang.IFn_Cast(root_1270) } else { ifn_1272 = nil }; var arg_1273 any = t__0; var arg_1274 any = A_arbace_go_check_types_A_const_179.GetRawRoot__O(); if linked_1271 == nil { return ifn_1272.Invoke_O_O__O(arg_1273, arg_1274) } else { return linked_1271.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1270, arg_1273, arg_1274) } }
func A_arbace_go_check_types_all_string_QMARK__A_New() *A_arbace_go_check_types_all_string_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_string_QMARK__A{}; t.Ctor(); return t }
//line :499:1
func (t *A_arbace_go_check_types_all_string_QMARK__A) Ctor() {}
//line :499:1
func (t *A_arbace_go_check_types_all_string_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1275 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1275, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1277 lang.IFn; if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = t__0; var arg_1279 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); if linked_1276 == nil { return ifn_1277.Invoke_O_O__O(arg_1278, arg_1279) } else { return linked_1276.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1275, arg_1278, arg_1279) } }
func A_arbace_go_check_types_all_boolean_QMARK__A_New() *A_arbace_go_check_types_all_boolean_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_boolean_QMARK__A{}; t.Ctor(); return t }
//line :500:1
func (t *A_arbace_go_check_types_all_boolean_QMARK__A) Ctor() {}
//line :500:1
func (t *A_arbace_go_check_types_all_boolean_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1280 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any = t__0; var arg_1284 any = A_arbace_go_check_types_A_const_180.GetRawRoot__O(); if linked_1281 == nil { return ifn_1282.Invoke_O_O__O(arg_1283, arg_1284) } else { return linked_1281.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1280, arg_1283, arg_1284) } }
func A_arbace_go_check_types_all_ordered_QMARK__A_New() *A_arbace_go_check_types_all_ordered_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_ordered_QMARK__A{}; t.Ctor(); return t }
//line :501:1
func (t *A_arbace_go_check_types_all_ordered_QMARK__A) Ctor() {}
//line :501:1
func (t *A_arbace_go_check_types_all_ordered_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1285 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1287 lang.IFn; if linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any = t__0; var arg_1289 any = A_arbace_go_check_types_A_const_181.GetRawRoot__O(); if linked_1286 == nil { return ifn_1287.Invoke_O_O__O(arg_1288, arg_1289) } else { return linked_1286.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1285, arg_1288, arg_1289) } }
func A_arbace_go_check_types_all_numeric_or_string_QMARK__A_New() *A_arbace_go_check_types_all_numeric_or_string_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_or_string_QMARK__A{}; t.Ctor(); return t }
//line :502:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__A) Ctor() {}
//line :502:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1290 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1290, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1292 lang.IFn; if linked_1291 == nil { ifn_1292 = lang.IFn_Cast(root_1290) } else { ifn_1292 = nil }; var arg_1293 any = t__0; var arg_1294 any; var tmp1 any = A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A_New(); var tmp2 *jrt.Class; var fncls__1303 *jrt.Class = A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A_fn_class; if fncls__1303 == nil { var fncls__1303d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A_fn_class = fncls__1303d; tmp2 = fncls__1303d } else { tmp2 = fncls__1303 }; arg_1294 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1291 == nil { return ifn_1292.Invoke_O_O__O(arg_1293, arg_1294) } else { return linked_1291.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1290, arg_1293, arg_1294) } }
//line :502:1
func A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A_New() *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A{}; t.Ctor(); return t }
//line :502:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A) Ctor() {}
//line :502:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A) Invoke_O_O__O(self, p1__219000197_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_1295 any = A_arbace_go_check_types_A_const_179.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, A_arbace_go_check_types_numeric_QMARK__A_fn_class); var ifn_1297 lang.IFn; if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any = p1__219000197_SHARP___1; if linked_1296 == nil { or__1927000174__auto____2 = ifn_1297.Invoke_O__O(arg_1298) } else { or__1927000174__auto____2 = linked_1296.(*A_arbace_go_check_types_numeric_QMARK__A).Invoke_O_O__O(root_1295, arg_1298) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_1299 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, A_arbace_go_check_types_string_type_QMARK__A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = p1__219000197_SHARP___1; if linked_1300 == nil { return ifn_1301.Invoke_O__O(arg_1302) } else { return linked_1300.(*A_arbace_go_check_types_string_type_QMARK__A).Invoke_O_O__O(root_1299, arg_1302) } } }
func A_arbace_go_check_types_all_float_QMARK__A_New() *A_arbace_go_check_types_all_float_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_float_QMARK__A{}; t.Ctor(); return t }
//line :503:1
func (t *A_arbace_go_check_types_all_float_QMARK__A) Ctor() {}
//line :503:1
func (t *A_arbace_go_check_types_all_float_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1304 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1304, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1306 lang.IFn; if linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any = t__0; var arg_1308 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); if linked_1305 == nil { return ifn_1306.Invoke_O_O__O(arg_1307, arg_1308) } else { return linked_1305.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1304, arg_1307, arg_1308) } }
func A_arbace_go_check_types_all_complex_QMARK__A_New() *A_arbace_go_check_types_all_complex_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_complex_QMARK__A{}; t.Ctor(); return t }
//line :504:1
func (t *A_arbace_go_check_types_all_complex_QMARK__A) Ctor() {}
//line :504:1
func (t *A_arbace_go_check_types_all_complex_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1309 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1309, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1311 lang.IFn; if linked_1310 == nil { ifn_1311 = lang.IFn_Cast(root_1309) } else { ifn_1311 = nil }; var arg_1312 any = t__0; var arg_1313 any = A_arbace_go_check_types_A_const_114.GetRawRoot__O(); if linked_1310 == nil { return ifn_1311.Invoke_O_O__O(arg_1312, arg_1313) } else { return linked_1310.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1309, arg_1312, arg_1313) } }

func A_arbace_go_check_types_common_under_A_New() *A_arbace_go_check_types_common_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_common_under_A{}; t.Ctor(); return t }
//line :506:1
func (t *A_arbace_go_check_types_common_under_A) Ctor() {}
//line :506:1
func (t *A_arbace_go_check_types_common_under_A) Invoke_O_O_O__O(self, t__0, cnd__1 any) any { { var ps__3 any; var root_1314 any = A_arbace_go_check_types_A_const_175.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1314, A_arbace_go_check_types_typeset_pairs_A_fn_class); var ifn_1316 lang.IFn





	if linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any = t__0; if linked_1315 == nil { ps__3 = ifn_1316.Invoke_O__O(arg_1317) } else { ps__3 = linked_1315.(*A_arbace_go_check_types_typeset_pairs_A).Invoke_O_O__O(root_1314, arg_1317) }
//line :506:1
	var ct__4 any; var cu__5 any; L1: for {






		var tmp1 any; var root_1318 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1318, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1320 lang.IFn; if linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any = ps__3; if linked_1319 == nil { tmp1 = ifn_1320.Invoke_O__O(arg_1321) } else { tmp1 = linked_1319.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1318, arg_1321) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(cu__5, nil) } else { var vec__219000203__6 any; var root_1322 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1322, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1324 lang.IFn

			if linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any = ps__3; if linked_1323 == nil { vec__219000203__6 = ifn_1324.Invoke_O__O(arg_1325) } else { vec__219000203__6 = linked_1323.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1322, arg_1325) }
//line :513:1
			var ty__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000203__6, lang.RT_IntCast_J__I_NoInit(0), nil); var u__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000203__6, lang.RT_IntCast_J__I_NoInit(1), nil); var e__9 any


			if jrt.J2g_Truth(cnd__1) { e__9 = lang.IFn_Cast(cnd__1).Invoke_O_O__O(ty__7, u__8) } else { e__9 = nil }
			if jrt.J2g_Truth(e__9) { return lang.Tuple_Create_O_O__IPersistentVector(nil, e__9) } else { if lang.Util_Identical_O_O__Z_NoInit(u__8, nil) { return A_arbace_go_check_types_A_const_182 } else { if lang.Util_Identical_O_O__Z_NoInit(cu__5, nil) {


				var tmp2 any; var root_1357 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1357, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1359 lang.IFn; if linked_1358 == nil { ifn_1359 = lang.IFn_Cast(root_1357) } else { ifn_1359 = nil }; var arg_1360 any = ps__3; if linked_1358 == nil { tmp2 = ifn_1359.Invoke_O__O(arg_1360) } else { tmp2 = linked_1358.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1357, arg_1360) }; ps__3, ct__4, cu__5 = tmp2, ty__7, u__8; continue L1 } else {
//line :517:1
					var tmp3 any; var and__1927000168__auto____10 any; var root_1326 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_1327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1326, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1328 lang.IFn



					if linked_1327 == nil { ifn_1328 = lang.IFn_Cast(root_1326) } else { ifn_1328 = nil }; var arg_1329 any = cu__5; if linked_1327 == nil { and__1927000168__auto____10 = ifn_1328.Invoke_O__O(arg_1329) } else { and__1927000168__auto____10 = linked_1327.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1326, arg_1329) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp4 any = A_arbace_go_check_types_A_const_79; var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____11 { var and__1927000168__auto____12 any; var root_1330 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1332 lang.IFn; if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = u__8; if linked_1331 == nil { and__1927000168__auto____12 = ifn_1332.Invoke_O__O(arg_1333) } else { and__1927000168__auto____12 = linked_1331.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1330, arg_1333) }; if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp5 any = A_arbace_go_check_types_A_const_79; tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp5, lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp3 = and__1927000168__auto____12 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else { tmp3 = and__1927000168__auto____10 }
//line :517:1
					if jrt.J2g_Truth(tmp3) {




						var tmp6 any; var root_1334 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1336 lang.IFn
						if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any; var root_1338 any = A_arbace_go_check_types_A_const_144.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_1340 lang.IFn; if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(2)); var arg_1342 any = lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(2)); if linked_1339 == nil { arg_1337 = ifn_1340.Invoke_O_O__O(arg_1341, arg_1342) } else { arg_1337 = linked_1339.(*A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_1338, arg_1341, arg_1342) }; if linked_1335 == nil { tmp6 = ifn_1336.Invoke_O__O(arg_1337) } else { tmp6 = linked_1335.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1334, arg_1337) }
//line :522:1
						if jrt.J2g_Truth(tmp6) { return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7, nil, Lit_8), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_go_check_types_A_const_186.GetRawRoot__O()).Invoke_O__O(ct__4), nil, lang.IFn_Cast(A_arbace_go_check_types_A_const_186.GetRawRoot__O()).Invoke_O__O(ty__7), nil)).Ref()) } else { if lang.Util_Equiv_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(1)), lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(1))) {

							var tmp7 any; var root_1369 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1371 lang.IFn; if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var arg_1372 any = ps__3; if linked_1370 == nil { tmp7 = ifn_1371.Invoke_O__O(arg_1372) } else { tmp7 = linked_1370.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1369, arg_1372) }; ps__3, ct__4, cu__5 = tmp7, ct__4, cu__5; continue L1 } else {
//line :522:1
								var tmp8 any = A_arbace_go_check_types_A_const_183; if lang.Util_Equiv_O_O__Z_NoInit(tmp8, lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(1))) {


									var tmp9 any; var root_1373 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any = ps__3; if linked_1374 == nil { tmp9 = ifn_1375.Invoke_O__O(arg_1376) } else { tmp9 = linked_1374.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1373, arg_1376) }; ps__3, ct__4, cu__5 = tmp9, ty__7, u__8; continue L1 } else {
//line :522:1
										var tmp10 any; var root_1343 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1343, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1345 lang.IFn



										if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = A_arbace_go_check_types_A_const_183; var arg_1347 any = lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(1)); if linked_1344 == nil { tmp10 = ifn_1345.Invoke_O_O__O(arg_1346, arg_1347) } else { tmp10 = linked_1344.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1343, arg_1346, arg_1347) }
//line :522:1
										if jrt.J2g_Truth(tmp10) { return A_arbace_go_check_types_A_const_184 } else { if A_arbace_go_check_types_A_const_86 != nil {




											var tmp11 any; var root_1377 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any = ps__3; if linked_1378 == nil { tmp11 = ifn_1379.Invoke_O__O(arg_1380) } else { tmp11 = linked_1378.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1377, arg_1380) }; ps__3, ct__4, cu__5 = tmp11, ct__4, cu__5; continue L1 } else {
//line :522:1
												return nil } } } } } } else {
//line :517:1
													var tmp12 any; var root_1348 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1350 lang.IFn










													if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any; var root_1352 any = A_arbace_go_check_types_A_const_144.GetRawRoot__O(); var linked_1353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1352, A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_1354 lang.IFn; if linked_1353 == nil { ifn_1354 = lang.IFn_Cast(root_1352) } else { ifn_1354 = nil }; var arg_1355 any = cu__5; var arg_1356 any = u__8; if linked_1353 == nil { arg_1351 = ifn_1354.Invoke_O_O__O(arg_1355, arg_1356) } else { arg_1351 = linked_1353.(*A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_1352, arg_1355, arg_1356) }; if linked_1349 == nil { tmp12 = ifn_1350.Invoke_O__O(arg_1351) } else { tmp12 = linked_1349.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1348, arg_1351) }
//line :517:1
													if jrt.J2g_Truth(tmp12) { return A_arbace_go_check_types_A_const_185 } else { if A_arbace_go_check_types_A_const_86 != nil {











														var tmp13 any; var root_1381 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1381, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1383 lang.IFn; if linked_1382 == nil { ifn_1383 = lang.IFn_Cast(root_1381) } else { ifn_1383 = nil }; var arg_1384 any = ps__3; if linked_1382 == nil { tmp13 = ifn_1383.Invoke_O__O(arg_1384) } else { tmp13 = linked_1382.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1381, arg_1384) }; ps__3, ct__4, cu__5 = tmp13, ct__4, cu__5; continue L1 } else {
//line :517:1
															return nil } } } } } } } } }; /*line :506:1*/panic("j2g: unreachable") }
//line :506:1
func (t *A_arbace_go_check_types_common_under_A) Invoke_O_O__O(self, t__0 any) any {



	var root_1385 any = A_arbace_go_check_types_A_const_187.GetRawRoot__O(); var linked_1386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1385, A_arbace_go_check_types_common_under_A_fn_class); var ifn_1387 lang.IFn; if linked_1386 == nil { ifn_1387 = lang.IFn_Cast(root_1385) } else { ifn_1387 = nil }; var arg_1388 any = t__0; var arg_1389 any; if linked_1386 == nil { return ifn_1387.Invoke_O_O__O(arg_1388, arg_1389) } else { return linked_1386.(*A_arbace_go_check_types_common_under_A).Invoke_O_O_O__O(root_1385, arg_1388, arg_1389)
	}
}


















func A_arbace_go_check_types_core_type_A_New() *A_arbace_go_check_types_core_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_core_type_A{}; t.Ctor(); return t }
//line :531:1
func (t *A_arbace_go_check_types_core_type_A) Ctor() {}
//line :531:1
func (t *A_arbace_go_check_types_core_type_A) Invoke_O_O__O(self, t__0 any) any {


	var root_1390 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_1391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1390, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1392 lang.IFn; if linked_1391 == nil { ifn_1392 = lang.IFn_Cast(root_1390) } else { ifn_1392 = nil }; var arg_1393 any; var root_1394 any = A_arbace_go_check_types_A_const_187.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1394, A_arbace_go_check_types_common_under_A_fn_class); var ifn_1396 lang.IFn; if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any = t__0; if linked_1395 == nil { arg_1393 = ifn_1396.Invoke_O__O(arg_1397) } else { arg_1393 = linked_1395.(*A_arbace_go_check_types_common_under_A).Invoke_O_O__O(root_1394, arg_1397) }; if linked_1391 == nil { return ifn_1392.Invoke_O__O(arg_1393) } else { return linked_1391.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1390, arg_1393)
	}
}








func A_arbace_go_check_types_terms_str_A_New() *A_arbace_go_check_types_terms_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_A{}; t.Ctor(); return t }
//line :545:1
func (t *A_arbace_go_check_types_terms_str_A) Ctor() {}
//line :545:1
func (t *A_arbace_go_check_types_terms_str_A) Invoke_O_O__O(self, terms__0 any) any {
	var tmp1 any; var root_1398 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any = terms__0; if linked_1399 == nil { tmp1 = ifn_1400.Invoke_O__O(arg_1401) } else { tmp1 = linked_1399.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1398, arg_1401) }; if jrt.J2g_Truth(tmp1) { return Lit_52 } else { var ts__2 any; var tmp2 *lang.Keyword = A_arbace_go_check_types_A_const_149; var or__1927000174__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(terms__0))

		if jrt.J2g_Truth(or__1927000174__auto____2) { ts__2 = or__1927000174__auto____2 } else { var root_1402 any = A_arbace_go_check_types_A_const_188.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1404 lang.IFn; if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any = A_arbace_go_check_types_A_const_186.GetRawRoot__O(); var arg_1406 any = terms__0; if linked_1403 == nil { ts__2 = ifn_1404.Invoke_O_O__O(arg_1405, arg_1406) } else { ts__2 = linked_1403.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1402, arg_1405, arg_1406) } }
		var root_1407 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); var linked_1408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1407, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1409 lang.IFn; if linked_1408 == nil { ifn_1409 = lang.IFn_Cast(root_1407) } else { ifn_1409 = nil }; var arg_1410 any = Lit_53; var arg_1411 any; var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_go_check_types_terms_str_iter__219000208__219000212_A_New(); var tmp4 *jrt.Class; var fncls__1478 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000208__219000212_A_fn_class; if fncls__1478 == nil { var fncls__1478d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_go_check_types_terms_str_iter__219000208__219000212_A_fn_class = fncls__1478d; tmp4 = fncls__1478d } else { tmp4 = fncls__1478 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); arg_1411 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(ts__2); if linked_1408 == nil { return ifn_1409.Invoke_O_O__O(arg_1410, arg_1411) } else { return linked_1408.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1407, arg_1410, arg_1411) } } }
//line :549:1
func A_arbace_go_check_types_terms_str_iter__219000208__219000212_A_New() *A_arbace_go_check_types_terms_str_iter__219000208__219000212_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000208__219000212_A{}; t.Ctor(); return t }
//line :549:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_A) Ctor() {}
//line :549:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_A) Invoke_O_O__O(self, s__219000209__1 any) any { var tmp1 any = A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A_New_O_O(self, s__219000209__1); var tmp2 *jrt.Class; var fncls__1477 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A_fn_class; if fncls__1477 == nil { var fncls__1477d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A_fn_class = fncls__1477d; tmp2 = fncls__1477d } else { tmp2 = fncls__1477 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :549:1
func A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A{}; t.Ctor_O_O(p0, p1); return t }
//line :549:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A) Ctor_O_O(c__iter__219000208, c__s__219000209 any) { t.F_iter__219000208 = c__iter__219000208; t.F_s__219000209 = c__s__219000209 }
//line :549:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A) Invoke_O__O(self any) any { { var s__219000209__1 any; var t_ any = t.F_s__219000209; t.F_s__219000209 = nil; s__219000209__1 = t_; for { var temp__1927000414__auto____2 any; var root_1412 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1414 lang.IFn; if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = s__219000209__1; if linked_1413 == nil { temp__1927000414__auto____2 = ifn_1414.Invoke_O__O(arg_1415) } else { temp__1927000414__auto____2 = linked_1413.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1412, arg_1415) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000209__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1416 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = s__219000209__3; if linked_1417 == nil { tmp1 = ifn_1418.Invoke_O__O(arg_1419) } else { tmp1 = linked_1417.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1416, arg_1419) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1420 any = A_arbace_go_check_types_A_const_155.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1420, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any = s__219000209__3; if linked_1421 == nil { c__1927001037__auto____4 = ifn_1422.Invoke_O__O(arg_1423) } else { c__1927001037__auto____4 = linked_1421.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1420, arg_1423) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000211__6 any; var root_1424 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); var linked_1425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1424, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1426 lang.IFn; if linked_1425 == nil { ifn_1426 = lang.IFn_Cast(root_1424) } else { ifn_1426 = nil }; var arg_1427 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1425 == nil { b__219000211__6 = ifn_1426.Invoke_O__O(arg_1427) } else { b__219000211__6 = linked_1425.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1424, arg_1427) }; var tmp2 any = A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A_New_O_I_O(b__219000211__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1437 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A_fn_class; if fncls__1437 == nil { var fncls__1437d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A_fn_class = fncls__1437d; tmp3 = fncls__1437d } else { tmp3 = fncls__1437 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1438 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_1439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1438, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1440 lang.IFn; if linked_1439 == nil { ifn_1440 = lang.IFn_Cast(root_1438) } else { ifn_1440 = nil }; var arg_1441 any; var root_1443 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1445 lang.IFn; if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any = b__219000211__6; if linked_1444 == nil { arg_1441 = ifn_1445.Invoke_O__O(arg_1446) } else { arg_1441 = linked_1444.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1443, arg_1446) }; var arg_1442 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000208); var tmp5 any; var root_1447 any = A_arbace_go_check_types_A_const_161.GetRawRoot__O(); var linked_1448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1447, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1449 lang.IFn; if linked_1448 == nil { ifn_1449 = lang.IFn_Cast(root_1447) } else { ifn_1449 = nil }; var arg_1450 any = s__219000209__3; if linked_1448 == nil { tmp5 = ifn_1449.Invoke_O__O(arg_1450) } else { tmp5 = linked_1448.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1447, arg_1450) }; arg_1442 = tmp4.Invoke_O__O(tmp5); if linked_1439 == nil { return ifn_1440.Invoke_O_O__O(arg_1441, arg_1442) } else { return linked_1439.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1438, arg_1441, arg_1442) } } else { var root_1451 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1451, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1453 lang.IFn; if linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any; var root_1456 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_1457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1456, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1458 lang.IFn; if linked_1457 == nil { ifn_1458 = lang.IFn_Cast(root_1456) } else { ifn_1458 = nil }; var arg_1459 any = b__219000211__6; if linked_1457 == nil { arg_1454 = ifn_1458.Invoke_O__O(arg_1459) } else { arg_1454 = linked_1457.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1456, arg_1459) }; var arg_1455 any; if linked_1452 == nil { return ifn_1453.Invoke_O_O__O(arg_1454, arg_1455) } else { return linked_1452.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1451, arg_1454, arg_1455) } } } else { var vec__219000219__4 any; var root_1460 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_1461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1460, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1462 lang.IFn; if linked_1461 == nil { ifn_1462 = lang.IFn_Cast(root_1460) } else { ifn_1462 = nil }; var arg_1463 any = s__219000209__3; if linked_1461 == nil { vec__219000219__4 = ifn_1462.Invoke_O__O(arg_1463) } else { vec__219000219__4 = linked_1461.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1460, arg_1463) }; var tilde__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000219__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000219__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1464 any = A_arbace_go_check_types_A_const_162.GetRawRoot__O(); var linked_1465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1464, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1466 lang.IFn; if linked_1465 == nil { ifn_1466 = lang.IFn_Cast(root_1464) } else { ifn_1466 = nil }; var arg_1467 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 *jrt.String; if jrt.J2g_Truth(tilde__5) { tmp7 = Lit_57 } else { tmp7 = nil }; var tmp8 any = tmp7.Ref(); var tmp9 any; var root_1469 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = ty__6; if linked_1470 == nil { tmp9 = ifn_1471.Invoke_O__O(arg_1472) } else { tmp9 = linked_1470.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1469, arg_1472) }; arg_1467 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9)).Ref(); var arg_1468 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__219000208); var tmp11 any; var root_1473 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = s__219000209__3; if linked_1474 == nil { tmp11 = ifn_1475.Invoke_O__O(arg_1476) } else { tmp11 = linked_1474.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1473, arg_1476) }; arg_1468 = tmp10.Invoke_O__O(tmp11); if linked_1465 == nil { return ifn_1466.Invoke_O_O__O(arg_1467, arg_1468) } else { return linked_1465.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1464, arg_1467, arg_1468) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :549:1
func A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :549:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A) Ctor_O_I_O(c__b__219000211 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000211 = c__b__219000211; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :549:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A) Invoke_O__O(self any) any { { var i__219000210__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000210__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__219000215__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000210__1)); var tilde__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000215__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000215__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1428 any = A_arbace_go_check_types_A_const_158.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1430 lang.IFn; if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = t.F_b__219000211; var arg_1432 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 *jrt.String; if jrt.J2g_Truth(tilde__3) { tmp3 = Lit_57 } else { tmp3 = nil }; var tmp4 any = tmp3.Ref(); var tmp5 any; var root_1433 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = ty__4; if linked_1434 == nil { tmp5 = ifn_1435.Invoke_O__O(arg_1436) } else { tmp5 = linked_1434.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1433, arg_1436) }; arg_1432 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5)).Ref(); if linked_1429 == nil { ifn_1430.Invoke_O_O__O(arg_1431, arg_1432) } else { linked_1429.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1428, arg_1431, arg_1432) }; i__219000210__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000210__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_types_params_str_A_New() *A_arbace_go_check_types_params_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_params_str_A{}; t.Ctor(); return t }
//line :551:1
func (t *A_arbace_go_check_types_params_str_A) Ctor() {}
//line :551:1
func (t *A_arbace_go_check_types_params_str_A) Invoke_O_O_O__O(self, ps__0, variadic__1 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_30, nil, Lit_31); var tmp2 any; var root_1479 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1481 lang.IFn
	if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any = Lit_32; var arg_1483 any; var root_1484 any = A_arbace_go_check_types_A_const_190.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any; var tmp3 any = A_arbace_go_check_types_params_str_fn__219000225_A_New_O_O(ps__0, variadic__1); var tmp4 *jrt.Class; var fncls__1497 *jrt.Class = A_arbace_go_check_types_params_str_fn__219000225_A_fn_class; if fncls__1497 == nil { var fncls__1497d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_check_types_params_str_fn__219000225_A_fn_class = fncls__1497d; tmp4 = fncls__1497d } else { tmp4 = fncls__1497 }; arg_1487 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1488 any = ps__0; if linked_1485 == nil { arg_1483 = ifn_1486.Invoke_O_O__O(arg_1487, arg_1488) } else { arg_1483 = linked_1485.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1484, arg_1487, arg_1488) }; if linked_1480 == nil { tmp2 = ifn_1481.Invoke_O_O__O(arg_1482, arg_1483) } else { tmp2 = linked_1480.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1479, arg_1482, arg_1483) }
//line :552:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil)).Ref() }
func A_arbace_go_check_types_params_str_fn__219000225_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_params_str_fn__219000225_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_params_str_fn__219000225_A{}; t.Ctor_O_O(p0, p1); return t }
//line :553:1
func (t *A_arbace_go_check_types_params_str_fn__219000225_A) Ctor_O_O(c__ps, c__variadic any) { t.F_ps = c__ps; t.F_variadic = c__variadic }
//line :553:1
func (t *A_arbace_go_check_types_params_str_fn__219000225_A) Invoke_O_O_O__O(self, i__1, p__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = t.F_variadic; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_J__Z_NoInit(i__1, lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_ps))))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_34, nil); var tmp3 any; var root_1489 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1489, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1491 lang.IFn; if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any = lang.RT_Nth_O_I__O_NoInit(p__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1490 == nil { tmp3 = ifn_1491.Invoke_O__O(arg_1492) } else { tmp3 = linked_1490.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1489, arg_1492) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else {
			var root_1493 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1493, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1495 lang.IFn; if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any = p__2; if linked_1494 == nil { return ifn_1495.Invoke_O__O(arg_1496) } else { return linked_1494.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1493, arg_1496)
			}
		}
}
func A_arbace_go_check_types_sig_str_A_New() *A_arbace_go_check_types_sig_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sig_str_A{}; t.Ctor(); return t }
//line :560:1
func (t *A_arbace_go_check_types_sig_str_A) Ctor() {}
//line :560:1
func (t *A_arbace_go_check_types_sig_str_A) Invoke_O_O__O(self, p__219000228__0 any) any { var vec__219000229__2 any = p__219000228__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000229__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000229__2, lang.RT_IntCast_J__I_NoInit(1), nil); var rs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000229__2, lang.RT_IntCast_J__I_NoInit(2), nil); var variadic__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000229__2, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_1498 any = A_arbace_go_check_types_A_const_191.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1498, A_arbace_go_check_types_params_str_A_fn_class); var ifn_1500 lang.IFn; _ = ___3; if


	linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any = ps__4; var arg_1502 any = variadic__6; if linked_1499 == nil { tmp2 = ifn_1500.Invoke_O_O__O(arg_1501, arg_1502) } else { tmp2 = linked_1499.(*A_arbace_go_check_types_params_str_A).Invoke_O_O_O__O(root_1498, arg_1501, arg_1502) }; var tmp3 any = tmp2; var tmp4 *jrt.String; var G__219000232__9_ int32 = lang.RT_Count_O__I_NoInit(rs__5); L1:
	switch { default: switch G__219000232__9_ { case 0: tmp4 = Lit_10; break L1; case 1: var r__10 any; var root_1504 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_1505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1504, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1506 lang.IFn

		if linked_1505 == nil { ifn_1506 = lang.IFn_Cast(root_1504) } else { ifn_1506 = nil }; var arg_1507 any = rs__5; if linked_1505 == nil { r__10 = ifn_1506.Invoke_O__O(arg_1507) } else { r__10 = linked_1505.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1504, arg_1507) }; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_11, nil); var tmp6 any; var root_1508 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1508, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1510 lang.IFn; if linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any = r__10; if linked_1509 == nil { tmp6 = ifn_1510.Invoke_O__O(arg_1511) } else { tmp6 = linked_1509.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1508, arg_1511) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6))
//line :564:1
		break L1; default:
	}

		var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_42, nil, Lit_31); var tmp8 any; var root_1512 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1512, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1514 lang.IFn; if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; var arg_1515 any = Lit_32; var arg_1516 any; var root_1517 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1519 lang.IFn; if linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var arg_1521 any = rs__5; if linked_1518 == nil { arg_1516 = ifn_1519.Invoke_O_O__O(arg_1520, arg_1521) } else { arg_1516 = linked_1518.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1517, arg_1520, arg_1521) }; if linked_1513 == nil { tmp8 = ifn_1514.Invoke_O_O__O(arg_1515, arg_1516) } else { tmp8 = linked_1513.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1512, arg_1515, arg_1516) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil))}; return /*line :563:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4.Ref())).Ref() }





func A_arbace_go_check_types_field_str_A_New() *A_arbace_go_check_types_field_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_field_str_A{}; t.Ctor(); return t }
//line :569:1
func (t *A_arbace_go_check_types_field_str_A) Ctor() {}
//line :569:1
func (t *A_arbace_go_check_types_field_str_A) Invoke_O_O__O(self, f__0 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 *jrt.String; if jrt.J2g_Truth(A_arbace_go_check_types_A_const_192.Invoke_O__O(f__0)) { tmp2 = Lit_10 } else { tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_12.Invoke_O__O(f__0), nil)) }; var tmp3 any = tmp2.Ref(); var tmp4 any; var root_1522 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1522, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1524 lang.IFn; if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(f__0); if linked_1523 == nil { tmp4 = ifn_1524.Invoke_O__O(arg_1525) } else { tmp4 = linked_1523.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1522, arg_1525) }; var tmp5 any = tmp4; var tmp6 *jrt.String
	if jrt.J2g_Truth(A_arbace_go_check_types_A_const_130.Invoke_O__O(f__0)) { var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_11, nil); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_186.GetRawRoot__O()); var tmp9 any; var root_1530 any = A_arbace_go_check_types_A_const_193.GetRawRoot__O(); var linked_1531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1530, aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A_fn_class); var ifn_1532 lang.IFn; if linked_1531 == nil { ifn_1532 = lang.IFn_Cast(root_1530) } else { ifn_1532 = nil }; var arg_1533 any = A_arbace_go_check_types_A_const_130.Invoke_O__O(f__0); if linked_1531 == nil { tmp9 = ifn_1532.Invoke_O__O(arg_1533) } else { tmp9 = linked_1531.(*aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A).Invoke_O_O__O(root_1530, arg_1533) }; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8.Invoke_O__O(tmp9))) } else { tmp6 = nil }
//line :570:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp5, tmp6.Ref())).Ref()
}

func A_arbace_go_check_types_named_str_A_New() *A_arbace_go_check_types_named_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_str_A{}; t.Ctor(); return t }
//line :573:1
func (t *A_arbace_go_check_types_named_str_A) Ctor() {}
//line :573:1
func (t *A_arbace_go_check_types_named_str_A) Invoke_O_O__O(self, t__0 any) any { var i__2 any; var root_1534 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_1535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1534, A_arbace_go_check_types_info_A_fn_class); var ifn_1536 lang.IFn; if
										linked_1535 == nil { ifn_1536 = lang.IFn_Cast(root_1534) } else { ifn_1536 = nil }; var arg_1537 any = t__0; if linked_1535 == nil { i__2 = ifn_1536.Invoke_O__O(arg_1537) } else { i__2 = linked_1535.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1534, arg_1537) }; var base__3 any; var tmp1 any; var and__1927000168__auto____3 any = /*line :573:1*/A_arbace_go_check_types_A_const_57.Invoke_O__O(i__2); if

	jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1538 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1538, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1540 lang.IFn; if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(i__2); var arg_1542 any = A_arbace_go_check_types_A_const_194.Get__O(); if linked_1539 == nil { and__1927000168__auto____4 = ifn_1540.Invoke_O_O__O(arg_1541, arg_1542) } else { and__1927000168__auto____4 = linked_1539.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1538, arg_1541, arg_1542) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1543 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1543, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1545 lang.IFn; if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = A_arbace_go_check_types_A_const_59.Invoke_O__O(i__2); if linked_1544 == nil { tmp1 = ifn_1545.Invoke_O__O(arg_1546) } else { tmp1 = linked_1544.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1543, arg_1546) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		base__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_58.Invoke_O__O(i__2), nil, A_arbace_go_check_types_A_const_12.Invoke_O__O(i__2))).Ref() } else {
			base__3 = A_arbace_go_check_types_A_const_12.Invoke_O__O(i__2) }; var tmp2 any; var root_1547 any =
	A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1547, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1549 lang.IFn; if linked_1548 == nil { ifn_1549 = lang.IFn_Cast(root_1547) } else { ifn_1549 = nil }; var arg_1550 any = A_arbace_go_check_types_A_const_195.Invoke_O__O(i__2); if linked_1548 == nil { tmp2 = ifn_1549.Invoke_O__O(arg_1550) } else { tmp2 = linked_1548.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1547, arg_1550) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil, Lit_27); var tmp4 any; var root_1551 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1551, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1553 lang.IFn; if linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any = Lit_28; var arg_1555 any; var root_1556 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1557 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1556, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1558 lang.IFn; if linked_1557 == nil { ifn_1558 = lang.IFn_Cast(root_1556) } else { ifn_1558 = nil }; var arg_1559 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var arg_1560 any = A_arbace_go_check_types_A_const_195.Invoke_O__O(i__2); if linked_1557 == nil { arg_1555 = ifn_1558.Invoke_O_O__O(arg_1559, arg_1560) } else { arg_1555 = linked_1557.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1556, arg_1559, arg_1560) }; if linked_1552 == nil { tmp4 = ifn_1553.Invoke_O_O__O(arg_1554, arg_1555) } else { tmp4 = linked_1552.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1551, arg_1554, arg_1555) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, base__3, nil, tmp4, nil)).Ref() } else {
//line :578:1
			return base__3 } }



func A_arbace_go_check_types_alias_str_A_New() *A_arbace_go_check_types_alias_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alias_str_A{}; t.Ctor(); return t }
//line :582:1
func (t *A_arbace_go_check_types_alias_str_A) Ctor() {}
//line :582:1
func (t *A_arbace_go_check_types_alias_str_A) Invoke_O_O__O(self, a__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(a__0); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1561 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1563 lang.IFn; if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(a__0); var arg_1565 any = A_arbace_go_check_types_A_const_194.Get__O(); if linked_1562 == nil { and__1927000168__auto____3 = ifn_1563.Invoke_O_O__O(arg_1564, arg_1565) } else { and__1927000168__auto____3 = linked_1562.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1561, arg_1564, arg_1565) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1566 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1566, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1568 lang.IFn; if linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any = A_arbace_go_check_types_A_const_59.Invoke_O__O(a__0); if linked_1567 == nil { tmp1 = ifn_1568.Invoke_O__O(arg_1569) } else { tmp1 = linked_1567.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1566, arg_1569) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_58.Invoke_O__O(a__0), nil, A_arbace_go_check_types_A_const_12.Invoke_O__O(a__0))).Ref() } else {
			return A_arbace_go_check_types_A_const_12.Invoke_O__O(a__0)
		} }
func A_arbace_go_check_types_type_str_A_New() *A_arbace_go_check_types_type_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_A{}; t.Ctor(); return t }
//line :589:1
func (t *A_arbace_go_check_types_type_str_A) Ctor() {}
//line :589:1
func (t *A_arbace_go_check_types_type_str_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_1570 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1570, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_1572 lang.IFn
	if linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = t__0; if linked_1571 == nil { tmp1 = ifn_1572.Invoke_O__O(arg_1573) } else { tmp1 = linked_1571.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_1570, arg_1573) }
//line :592:1
	if jrt.J2g_Truth(tmp1) { var or__1927000174__auto____2 any = lang.RT_Get_O_O__O_NoInit(A_arbace_go_check_types_A_const_196.GetRawRoot__O(), t__0)
		if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var G__219000237__3_ any; var root_1574 any = A_arbace_go_check_types_A_const_62.GetRawRoot__O(); var linked_1575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1574, A_arbace_go_check_types_kw_alias_info_A_fn_class); var ifn_1576 lang.IFn; if linked_1575 == nil { ifn_1576 = lang.IFn_Cast(root_1574) } else { ifn_1576 = nil }; var arg_1577 any = t__0; if linked_1575 == nil { G__219000237__3_ = ifn_1576.Invoke_O__O(arg_1577) } else { G__219000237__3_ = linked_1575.(*A_arbace_go_check_types_kw_alias_info_A).Invoke_O_O__O(root_1574, arg_1577) }; if lang.Util_Identical_O_O__Z_NoInit(G__219000237__3_, nil) { or__1927000174__auto____3 = nil } else { var root_1578 any = A_arbace_go_check_types_A_const_197.GetRawRoot__O(); var linked_1579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1578, A_arbace_go_check_types_alias_str_A_fn_class); var ifn_1580 lang.IFn; if linked_1579 == nil { ifn_1580 = lang.IFn_Cast(root_1578) } else { ifn_1580 = nil }; var arg_1581 any = G__219000237__3_; if linked_1579 == nil { or__1927000174__auto____3 = ifn_1580.Invoke_O__O(arg_1581) } else { or__1927000174__auto____3 = linked_1579.(*A_arbace_go_check_types_alias_str_A).Invoke_O_O__O(root_1578, arg_1581) } }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_1582 any = A_arbace_go_check_types_A_const_198.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1584 lang.IFn; if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = t__0; if linked_1583 == nil { return ifn_1584.Invoke_O__O(arg_1585) } else { return linked_1583.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1582, arg_1585) } } } } else {
//line :592:1
			var tmp2 *lang.Keyword = A_arbace_go_check_types_A_const_85; if jrt.J2g_Truth(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(t__0))) {

				var root_1586 any = A_arbace_go_check_types_A_const_197.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1586, A_arbace_go_check_types_alias_str_A_fn_class); var ifn_1588 lang.IFn; if linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; var tmp3 *lang.Keyword = A_arbace_go_check_types_A_const_85; var arg_1589 any = tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(t__0)); if linked_1587 == nil { return ifn_1588.Invoke_O__O(arg_1589) } else { return linked_1587.(*A_arbace_go_check_types_alias_str_A).Invoke_O_O__O(root_1586, arg_1589) } } else {
//line :592:1
					var tmp4 any; var root_1590 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_1591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1590, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1592 lang.IFn


					if linked_1591 == nil { ifn_1592 = lang.IFn_Cast(root_1590) } else { ifn_1592 = nil }; var arg_1593 any = t__0; if linked_1591 == nil { tmp4 = ifn_1592.Invoke_O__O(arg_1593) } else { tmp4 = linked_1591.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1590, arg_1593) }
//line :592:1
					if jrt.J2g_Truth(tmp4) {


						var root_1594 any = A_arbace_go_check_types_A_const_199.GetRawRoot__O(); var linked_1595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1594, A_arbace_go_check_types_named_str_A_fn_class); var ifn_1596 lang.IFn; if linked_1595 == nil { ifn_1596 = lang.IFn_Cast(root_1594) } else { ifn_1596 = nil }; var arg_1597 any = t__0; if linked_1595 == nil { return ifn_1596.Invoke_O__O(arg_1597) } else { return linked_1595.(*A_arbace_go_check_types_named_str_A).Invoke_O_O__O(root_1594, arg_1597) } } else {
//line :592:1
							var tmp5 any; var root_1598 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_1599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1598, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_1600 lang.IFn



							if linked_1599 == nil { ifn_1600 = lang.IFn_Cast(root_1598) } else { ifn_1600 = nil }; var arg_1601 any = t__0; if linked_1599 == nil { tmp5 = ifn_1600.Invoke_O__O(arg_1601) } else { tmp5 = linked_1599.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_1598, arg_1601) }
//line :592:1
							if jrt.J2g_Truth(tmp5) {



								var tmp6 *lang.Keyword = A_arbace_go_check_types_A_const_12; var tmp7 any; var root_1602 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, A_arbace_go_check_types_info_A_fn_class); var ifn_1604 lang.IFn; if linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any = t__0; if linked_1603 == nil { tmp7 = ifn_1604.Invoke_O__O(arg_1605) } else { tmp7 = linked_1603.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1602, arg_1605) }; return tmp6.Invoke_O__O(tmp7) } else {
//line :592:1
									if A_arbace_go_check_types_A_const_86 != nil { var G__219000238__2_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))





										switch lang.Util_Hash_O__I_NoInit(G__219000238__2_) >> 5 & 31 { case 0: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_69) {





















											var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_30, nil, Lit_31); var tmp9 any; var root_1607 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); var linked_1608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1607, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1609 lang.IFn; if linked_1608 == nil { ifn_1609 = lang.IFn_Cast(root_1607) } else { ifn_1609 = nil }; var arg_1610 any = Lit_32; var arg_1611 any; var root_1612 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1612, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1614 lang.IFn; if linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var arg_1616 any; var root_1617 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1617, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1619 lang.IFn; if linked_1618 == nil { ifn_1619 = lang.IFn_Cast(root_1617) } else { ifn_1619 = nil }; var arg_1620 any = t__0; if linked_1618 == nil { arg_1616 = ifn_1619.Invoke_O__O(arg_1620) } else { arg_1616 = linked_1618.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1617, arg_1620) }; if linked_1613 == nil { arg_1611 = ifn_1614.Invoke_O_O__O(arg_1615, arg_1616) } else { arg_1611 = linked_1613.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1612, arg_1615, arg_1616) }; if linked_1608 == nil { tmp9 = ifn_1609.Invoke_O_O__O(arg_1610, arg_1611) } else { tmp9 = linked_1608.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1607, arg_1610, arg_1611) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil)).Ref() }
//line :598:1
										case 1: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_71) { var ms__3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var ts__4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var tmp10 any; var and__1927000168__auto____5 any; var root_1621 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1621, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1623 lang.IFn












											if linked_1622 == nil { ifn_1623 = lang.IFn_Cast(root_1621) } else { ifn_1623 = nil }; var arg_1624 any = ms__3; if linked_1622 == nil { and__1927000168__auto____5 = ifn_1623.Invoke_O__O(arg_1624) } else { and__1927000168__auto____5 = linked_1622.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1621, arg_1624) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(ts__4, nil)).Ref() } else { tmp10 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp10) { return Lit_61 } else {

												var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil, Lit_63); var tmp12 any; var root_1625 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); var linked_1626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1625, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1627 lang.IFn
												if linked_1626 == nil { ifn_1627 = lang.IFn_Cast(root_1625) } else { ifn_1627 = nil }; var arg_1628 any = Lit_64; var arg_1629 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_152.GetRawRoot__O()); var tmp14 any; if jrt.J2g_Truth(A_arbace_go_check_types_A_const_133.Invoke_O__O(ts__4)) { tmp14 = A_arbace_go_check_types_A_const_200 } else { tmp14 = nil }; var tmp15 any = tmp14; var tmp16 any; var iter__1927001039__auto____8 any; var tmp17 any = A_arbace_go_check_types_type_str_iter__219000239__219000243_A_New(); var tmp18 *jrt.Class; var fncls__1702 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000239__219000243_A_fn_class
												if fncls__1702 == nil { var fncls__1702d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_go_check_types_type_str_iter__219000239__219000243_A_fn_class = fncls__1702d; tmp18 = fncls__1702d } else { tmp18 = fncls__1702 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); tmp16 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(ms__3)
//line :614:1
												var tmp19 any = tmp16; var tmp20 lang.IPersistentVector; var tmp21 any; var and__1927000168__auto____8 any; var root_1703 any = A_arbace_go_check_types_A_const_166.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1705 lang.IFn

												if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any = ts__4; if linked_1704 == nil { and__1927000168__auto____8 = ifn_1705.Invoke_O__O(arg_1706) } else { and__1927000168__auto____8 = linked_1704.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1703, arg_1706) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1707 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1707, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1709 lang.IFn; if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var arg_1710 any = A_arbace_go_check_types_A_const_131; var arg_1711 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__4); if linked_1708 == nil { tmp21 = ifn_1709.Invoke_O_O__O(arg_1710, arg_1711) } else { tmp21 = linked_1708.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1707, arg_1710, arg_1711) } } else { tmp21 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp21) { var tmp22 any; var root_1712 any = A_arbace_go_check_types_A_const_202.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_1714 lang.IFn
													if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__4); if linked_1713 == nil { tmp22 = ifn_1714.Invoke_O__O(arg_1715) } else { tmp22 = linked_1713.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_1712, arg_1715) }
//line :616:1
													tmp20 = lang.Tuple_Create_O__IPersistentVector(tmp22) } else { tmp20 = nil }
//line :614:1
												arg_1629 = tmp13.Invoke_O_O_O__O(tmp15, tmp19, tmp20); if linked_1626 == nil { tmp12 = ifn_1627.Invoke_O_O__O(arg_1628, arg_1629) } else { tmp12 = linked_1626.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1625, arg_1628, arg_1629) }
//line :613:1
												return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, nil)).Ref() } }
//line :598:1
										case 3: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_73) {
											var tmp23 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_66, nil); var tmp24 any; var root_1716 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1716, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1718 lang.IFn; if linked_1717 == nil { ifn_1718 = lang.IFn_Cast(root_1716) } else { ifn_1718 = nil }; var arg_1719 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1717 == nil { tmp24 = ifn_1718.Invoke_O__O(arg_1719) } else { tmp24 = linked_1717.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1716, arg_1719) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp23, jrt.RefArrayOf(jrt.Object_class, nil, tmp24)).Ref() }
//line :598:1
										case 4: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_74) {


											var tmp25 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_27, nil); var tmp26 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp27 any; var root_1720 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1720, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1722 lang.IFn; if linked_1721 == nil { ifn_1722 = lang.IFn_Cast(root_1720) } else { ifn_1722 = nil }; var arg_1723 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_1721 == nil { tmp27 = ifn_1722.Invoke_O__O(arg_1723) } else { tmp27 = linked_1721.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1720, arg_1723) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp25, jrt.RefArrayOf(jrt.Object_class, nil, tmp26, nil, tmp27)).Ref() }
//line :598:1
										case 8: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_77) {



											var tmp28 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_67, nil, Lit_27, nil); var tmp29 any; var root_1728 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1728, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1730 lang.IFn; if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var arg_1731 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1729 == nil { tmp29 = ifn_1730.Invoke_O__O(arg_1731) } else { tmp29 = linked_1729.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1728, arg_1731) }; var tmp30 any = tmp29; var tmp31 any; var root_1732 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1732, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1734 lang.IFn; if linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_1733 == nil { tmp31 = ifn_1734.Invoke_O__O(arg_1735) } else { tmp31 = linked_1733.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1732, arg_1735) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp28, jrt.RefArrayOf(jrt.Object_class, nil, tmp30, nil, tmp31)).Ref() }
//line :598:1
										case 14: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_78) {

											var tmp32 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil); var tmp33 any; var root_1736 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1736, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1738 lang.IFn; if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var arg_1739 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1737 == nil { tmp33 = ifn_1738.Invoke_O__O(arg_1739) } else { tmp33 = linked_1737.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1736, arg_1739) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp32, jrt.RefArrayOf(jrt.Object_class, nil, tmp33)).Ref() }
//line :598:1
										case 16: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_79) { var e__3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var es__4 any; var root_1740 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1740, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1742 lang.IFn





											if linked_1741 == nil { ifn_1742 = lang.IFn_Cast(root_1740) } else { ifn_1742 = nil }; var arg_1743 any = e__3; if linked_1741 == nil { es__4 = ifn_1742.Invoke_O__O(arg_1743) } else { es__4 = linked_1741.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1740, arg_1743) }
//line :598:1
											var es__5 any; var tmp34 any; var tmp35 any = A_arbace_go_check_types_A_const_183; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp35, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)))






											if and__1927000168__auto____5_2 { var and__1927000168__auto____6 any; var root_1744 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = e__3; if linked_1745 == nil { and__1927000168__auto____6 = ifn_1746.Invoke_O__O(arg_1747) } else { and__1927000168__auto____6 = linked_1745.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1744, arg_1747) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp36 any = A_arbace_go_check_types_A_const_79; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp36, lang.RT_Nth_O_I__O_NoInit(e__3, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____7 { var tmp37 any = A_arbace_go_check_types_A_const_203; tmp34 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp37, lang.RT_Nth_O_I__O_NoInit(e__3, lang.RT_IntCast_J__I_NoInit(1)))).Ref() } else { tmp34 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp34 = and__1927000168__auto____6 } } else { tmp34 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref() }; if jrt.J2g_Truth(tmp34) {
												es__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_30, nil, Lit_31), jrt.RefArrayOf(jrt.Object_class, nil, es__4, nil)).Ref() } else {
//line :605:1
													es__5 = es__4 }
//line :598:1
											var G__219000249__6_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1))








											switch lang.Util_Hash_O__I_NoInit(G__219000249__6_) >> 7 & 3 { case 0: if any(G__219000249__6_) == any(A_arbace_go_check_types_A_const_203) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_69, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; case 2: if any(G__219000249__6_) == any(A_arbace_go_check_types_A_const_183) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_70, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; case 3: if any(G__219000249__6_) == any(A_arbace_go_check_types_A_const_204) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_71, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__219000249__6_))))) }
//line :598:1
										case 27: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_81) {









											var tmp38 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_73, nil); var tmp39 any; var root_1749 any = A_arbace_go_check_types_A_const_201.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1749, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1751 lang.IFn; if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any = t__0; if linked_1750 == nil { tmp39 = ifn_1751.Invoke_O__O(arg_1752) } else { tmp39 = linked_1750.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1749, arg_1752) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp38, jrt.RefArrayOf(jrt.Object_class, nil, tmp39)).Ref() }
//line :598:1
										case 28: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_143) {




















											var root_1753 any = A_arbace_go_check_types_A_const_202.GetRawRoot__O(); var linked_1754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1753, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_1755 lang.IFn; if linked_1754 == nil { ifn_1755 = lang.IFn_Cast(root_1753) } else { ifn_1755 = nil }; var arg_1756 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1754 == nil { return ifn_1755.Invoke_O__O(arg_1756) } else { return linked_1754.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_1753, arg_1756) } }
//line :598:1
										case 31: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_82) {










											var tmp40 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_74, nil, Lit_63); var tmp41 any; var root_1757 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); var linked_1758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1757, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1759 lang.IFn; if linked_1758 == nil { ifn_1759 = lang.IFn_Cast(root_1757) } else { ifn_1759 = nil }; var arg_1760 any = Lit_64; var arg_1761 any; var root_1762 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1762, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1764 lang.IFn; if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var arg_1765 any = A_arbace_go_check_types_A_const_205.GetRawRoot__O(); var arg_1766 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1763 == nil { arg_1761 = ifn_1764.Invoke_O_O__O(arg_1765, arg_1766) } else { arg_1761 = linked_1763.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1762, arg_1765, arg_1766) }; if linked_1758 == nil { tmp41 = ifn_1759.Invoke_O_O__O(arg_1760, arg_1761) } else { tmp41 = linked_1758.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1757, arg_1760, arg_1761) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp40, jrt.RefArrayOf(jrt.Object_class, nil, tmp41, nil)).Ref() }
//line :598:1
										default:
										}





















										return lang.IFn_Cast(A_arbace_go_check_types_A_const_186.GetRawRoot__O()).Invoke_O__O(t__0) } else {
//line :592:1
											return nil
										}
								}
						}
				}
		}
}
















func A_arbace_go_check_types_type_str_iter__219000239__219000243_A_New() *A_arbace_go_check_types_type_str_iter__219000239__219000243_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000239__219000243_A{}; t.Ctor(); return t }
//line :615:1
func (t *A_arbace_go_check_types_type_str_iter__219000239__219000243_A) Ctor() {}
//line :615:1
func (t *A_arbace_go_check_types_type_str_iter__219000239__219000243_A) Invoke_O_O__O(self, s__219000240__1 any) any { var tmp1 any = A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A_New_O_O(s__219000240__1, self); var tmp2 *jrt.Class; var fncls__1701 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A_fn_class; if fncls__1701 == nil { var fncls__1701d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A_fn_class = fncls__1701d; tmp2 = fncls__1701d } else { tmp2 = fncls__1701 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :615:1
func A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A{}; t.Ctor_O_O(p0, p1); return t }
//line :615:1
func (t *A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A) Ctor_O_O(c__s__219000240, c__iter__219000239 any) { t.F_s__219000240 = c__s__219000240; t.F_iter__219000239 = c__iter__219000239 }
//line :615:1
func (t *A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A) Invoke_O__O(self any) any { { var s__219000240__1 any; var t_ any = t.F_s__219000240; t.F_s__219000240 = nil; s__219000240__1 = t_; for { var temp__1927000414__auto____2 any; var root_1636 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any = s__219000240__1; if linked_1637 == nil { temp__1927000414__auto____2 = ifn_1638.Invoke_O__O(arg_1639) } else { temp__1927000414__auto____2 = linked_1637.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1636, arg_1639) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000240__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1640 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1640, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1642 lang.IFn; if linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any = s__219000240__3; if linked_1641 == nil { tmp1 = ifn_1642.Invoke_O__O(arg_1643) } else { tmp1 = linked_1641.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1640, arg_1643) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1644 any = A_arbace_go_check_types_A_const_155.GetRawRoot__O(); var linked_1645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1644, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1646 lang.IFn; if linked_1645 == nil { ifn_1646 = lang.IFn_Cast(root_1644) } else { ifn_1646 = nil }; var arg_1647 any = s__219000240__3; if linked_1645 == nil { c__1927001037__auto____4 = ifn_1646.Invoke_O__O(arg_1647) } else { c__1927001037__auto____4 = linked_1645.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1644, arg_1647) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000242__6 any; var root_1648 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); var linked_1649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1648, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1650 lang.IFn; if linked_1649 == nil { ifn_1650 = lang.IFn_Cast(root_1648) } else { ifn_1650 = nil }; var arg_1651 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1649 == nil { b__219000242__6 = ifn_1650.Invoke_O__O(arg_1651) } else { b__219000242__6 = linked_1649.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1648, arg_1651) }; var tmp2 any = A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A_New_O_I_O(b__219000242__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1661 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A_fn_class; if fncls__1661 == nil { var fncls__1661d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A_fn_class = fncls__1661d; tmp3 = fncls__1661d } else { tmp3 = fncls__1661 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1662 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_1663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1662, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1664 lang.IFn; if linked_1663 == nil { ifn_1664 = lang.IFn_Cast(root_1662) } else { ifn_1664 = nil }; var arg_1665 any; var root_1667 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_1668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1667, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1669 lang.IFn; if linked_1668 == nil { ifn_1669 = lang.IFn_Cast(root_1667) } else { ifn_1669 = nil }; var arg_1670 any = b__219000242__6; if linked_1668 == nil { arg_1665 = ifn_1669.Invoke_O__O(arg_1670) } else { arg_1665 = linked_1668.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1667, arg_1670) }; var arg_1666 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000239); var tmp5 any; var root_1671 any = A_arbace_go_check_types_A_const_161.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1671, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any = s__219000240__3; if linked_1672 == nil { tmp5 = ifn_1673.Invoke_O__O(arg_1674) } else { tmp5 = linked_1672.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1671, arg_1674) }; arg_1666 = tmp4.Invoke_O__O(tmp5); if linked_1663 == nil { return ifn_1664.Invoke_O_O__O(arg_1665, arg_1666) } else { return linked_1663.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1662, arg_1665, arg_1666) } } else { var root_1675 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_1676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1675, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1677 lang.IFn; if linked_1676 == nil { ifn_1677 = lang.IFn_Cast(root_1675) } else { ifn_1677 = nil }; var arg_1678 any; var root_1680 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = b__219000242__6; if linked_1681 == nil { arg_1678 = ifn_1682.Invoke_O__O(arg_1683) } else { arg_1678 = linked_1681.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1680, arg_1683) }; var arg_1679 any; if linked_1676 == nil { return ifn_1677.Invoke_O_O__O(arg_1678, arg_1679) } else { return linked_1676.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1675, arg_1678, arg_1679) } } } else { var m__4 any; var root_1684 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1686 lang.IFn; if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = s__219000240__3; if linked_1685 == nil { m__4 = ifn_1686.Invoke_O__O(arg_1687) } else { m__4 = linked_1685.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1684, arg_1687) }; var root_1688 any = A_arbace_go_check_types_A_const_162.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1688, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1690 lang.IFn; if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__4); var tmp8 any; var root_1693 any = A_arbace_go_check_types_A_const_201.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1693, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1695 lang.IFn; if linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var arg_1696 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(m__4); if linked_1694 == nil { tmp8 = ifn_1695.Invoke_O__O(arg_1696) } else { tmp8 = linked_1694.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1693, arg_1696) }; arg_1691 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8)).Ref(); var arg_1692 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__219000239); var tmp10 any; var root_1697 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1697, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1699 lang.IFn; if linked_1698 == nil { ifn_1699 = lang.IFn_Cast(root_1697) } else { ifn_1699 = nil }; var arg_1700 any = s__219000240__3; if linked_1698 == nil { tmp10 = ifn_1699.Invoke_O__O(arg_1700) } else { tmp10 = linked_1698.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1697, arg_1700) }; arg_1692 = tmp9.Invoke_O__O(tmp10); if linked_1689 == nil { return ifn_1690.Invoke_O_O__O(arg_1691, arg_1692) } else { return linked_1689.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1688, arg_1691, arg_1692) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :615:1
func A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :615:1
func (t *A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A) Ctor_O_I_O(c__b__219000242 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000242 = c__b__219000242; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :615:1
func (t *A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A) Invoke_O__O(self any) any { { var i__219000241__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000241__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000241__1)); var root_1652 any = A_arbace_go_check_types_A_const_158.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1654 lang.IFn; if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = t.F_b__219000242; var arg_1656 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__2); var tmp4 any; var root_1657 any = A_arbace_go_check_types_A_const_201.GetRawRoot__O(); var linked_1658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1657, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1659 lang.IFn; if linked_1658 == nil { ifn_1659 = lang.IFn_Cast(root_1657) } else { ifn_1659 = nil }; var arg_1660 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(m__2); if linked_1658 == nil { tmp4 = ifn_1659.Invoke_O__O(arg_1660) } else { tmp4 = linked_1658.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1657, arg_1660) }; arg_1656 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref(); if linked_1653 == nil { ifn_1654.Invoke_O_O__O(arg_1655, arg_1656) } else { linked_1653.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1652, arg_1655, arg_1656) }; i__219000241__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000241__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }














func A_arbace_go_check_types_align_up_A_New() *A_arbace_go_check_types_align_up_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_align_up_A{}; t.Ctor(); return t }
//line :630:1
func (t *A_arbace_go_check_types_align_up_A) Ctor() {}
//line :630:1
func (t *A_arbace_go_check_types_align_up_A) InvokePrim_O_J_J__J(self any, x__0, a__1 int64) int64 {


	return lang.Numbers_AndNot_J_J__J_NoInit(lang.Numbers_Unchecked_add_J_J__J_NoInit(x__0, lang.Numbers_Dec_J__J_NoInit(a__1)), lang.Numbers_Dec_J__J_NoInit(a__1)) }
//line :630:1
func (t *A_arbace_go_check_types_align_up_A) Invoke_O_O_O__O(self, p_x__0, p_a__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_J__J(self, lang.RT_LongCast_O__J_NoInit(p_x__0), lang.RT_LongCast_O__J_NoInit(p_a__1))).Ref() }




func A_arbace_go_check_types_sync_atomic_align64_QMARK__A_New() *A_arbace_go_check_types_sync_atomic_align64_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sync_atomic_align64_QMARK__A{}; t.Ctor(); return t }
//line :635:1
func (t *A_arbace_go_check_types_sync_atomic_align64_QMARK__A) Ctor() {}
//line :635:1
func (t *A_arbace_go_check_types_sync_atomic_align64_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_1767 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_1768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1767, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1769 lang.IFn; if



	linked_1768 == nil { ifn_1769 = lang.IFn_Cast(root_1767) } else { ifn_1769 = nil }; var arg_1770 any = t__0; if linked_1768 == nil { and__1927000168__auto____2 = ifn_1769.Invoke_O__O(arg_1770) } else { and__1927000168__auto____2 = linked_1768.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1767, arg_1770) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var i__3 any; var root_1771 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_1772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1771, A_arbace_go_check_types_info_A_fn_class); var ifn_1773 lang.IFn
		if linked_1772 == nil { ifn_1773 = lang.IFn_Cast(root_1771) } else { ifn_1773 = nil }; var arg_1774 any = t__0; if linked_1772 == nil { i__3 = ifn_1773.Invoke_O__O(arg_1774) } else { i__3 = linked_1772.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1771, arg_1774) }
//line :639:1
		var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_44, A_arbace_go_check_types_A_const_12.Invoke_O__O(i__3))

		if and__1927000168__auto____4 {
			var root_1775 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1775, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1777 lang.IFn; if linked_1776 == nil { ifn_1777 = lang.IFn_Cast(root_1775) } else { ifn_1777 = nil }; var arg_1778 any = A_arbace_go_check_types_A_const_206; var arg_1779 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(i__3); if linked_1776 == nil { return ifn_1777.Invoke_O_O__O(arg_1778, arg_1779) } else { return linked_1776.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1775, arg_1778, arg_1779) } } else {
//line :641:1
				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else {
//line :639:1
					return and__1927000168__auto____2 } }




func A_arbace_go_check_types_alignof_A_New() *A_arbace_go_check_types_alignof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alignof_A{}; t.Ctor(); return t }
//line :644:1
func (t *A_arbace_go_check_types_alignof_A) Ctor() {}
//line :644:1
func (t *A_arbace_go_check_types_alignof_A) InvokePrim_O_O__J(self, t__0 any) int64 { var tmp1 any; var u__2 any; var root_1780 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_1781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1780, A_arbace_go_check_types_under_A_fn_class); var ifn_1782 lang.IFn; if
											linked_1781 == nil { ifn_1782 = lang.IFn_Cast(root_1780) } else { ifn_1782 = nil }; var arg_1783 any = t__0; if linked_1781 == nil { u__2 = ifn_1782.Invoke_O__O(arg_1783) } else { u__2 = linked_1781.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1780, arg_1783) }; var tmp2 any; var and__1927000168__auto____3 any; var root_1784 any =
											A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_1785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1784, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1786 lang.IFn; if
											linked_1785 == nil { ifn_1786 = lang.IFn_Cast(root_1784) } else { ifn_1786 = nil }; var arg_1787 any = u__2; if linked_1785 == nil { and__1927000168__auto____3 = ifn_1786.Invoke_O__O(arg_1787) } else { and__1927000168__auto____3 = linked_1785.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1784, arg_1787) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_go_check_types_A_const_74; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp2 = and__1927000168__auto____3 }; if /*line :646:1*/ jrt.J2g_Truth(tmp2) {
												var root_1788 any = A_arbace_go_check_types_A_const_207.GetRawRoot__O(); var linked_1789 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1788, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1790 lang.IFn; if linked_1789 == nil { ifn_1790 = lang.IFn_Cast(root_1788) } else { ifn_1790 = nil }; var arg_1791 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)); if linked_1789 == nil { tmp1 = ifn_1790.Invoke_O__O(arg_1791) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_1789.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1788, arg_1791)).Ref() } } else {
//line :646:1
			var tmp4 any; var and__1927000168__auto____3_2 any; var root_1792 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_1793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1792, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1794 lang.IFn

			if linked_1793 == nil { ifn_1794 = lang.IFn_Cast(root_1792) } else { ifn_1794 = nil }; var arg_1795 any = u__2; if linked_1793 == nil { and__1927000168__auto____3_2 = ifn_1794.Invoke_O__O(arg_1795) } else { and__1927000168__auto____3_2 = linked_1793.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1792, arg_1795) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) { var tmp5 any = A_arbace_go_check_types_A_const_82; tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp5, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp4 = and__1927000168__auto____3_2 }
//line :646:1
			if jrt.J2g_Truth(tmp4) {


				var tmp6 any; var and__1927000168__auto____3_3 any; var root_1796 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1798 lang.IFn; if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1797 == nil { and__1927000168__auto____3_3 = ifn_1798.Invoke_O__O(arg_1799) } else { and__1927000168__auto____3_3 = linked_1797.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1796, arg_1799) }; if jrt.J2g_Truth(and__1927000168__auto____3_3) { var root_1800 any = A_arbace_go_check_types_A_const_208.GetRawRoot__O(); var linked_1801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1800, A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class); var ifn_1802 lang.IFn; if linked_1801 == nil { ifn_1802 = lang.IFn_Cast(root_1800) } else { ifn_1802 = nil }; var arg_1803 any = t__0; if linked_1801 == nil { tmp6 = ifn_1802.Invoke_O__O(arg_1803) } else { tmp6 = linked_1801.(*A_arbace_go_check_types_sync_atomic_align64_QMARK__A).Invoke_O_O__O(root_1800, arg_1803) } } else { tmp6 = and__1927000168__auto____3_3 }; if jrt.J2g_Truth(tmp6) { tmp1 = A_arbace_go_check_types_A_const_24 } else {

					var root_1804 any = A_arbace_go_check_types_A_const_209.GetRawRoot__O(); var linked_1805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1804, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1806 lang.IFn; if linked_1805 == nil { ifn_1806 = lang.IFn_Cast(root_1804) } else { ifn_1806 = nil }; var arg_1807 any; var tmp7 any = A_arbace_go_check_types_alignof_fn__219000253_A_New(); var tmp8 *jrt.Class; var fncls__1814 *jrt.Class = A_arbace_go_check_types_alignof_fn__219000253_A_fn_class; if fncls__1814 == nil { var fncls__1814d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_check_types_alignof_fn__219000253_A_fn_class = fncls__1814d; tmp8 = fncls__1814d } else { tmp8 = fncls__1814 }; arg_1807 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_1808 any = A_arbace_go_check_types_A_const_15; var arg_1809 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1805 == nil { tmp1 = ifn_1806.Invoke_O_O_O__O(arg_1807, arg_1808, arg_1809) } else { tmp1 = linked_1805.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1804, arg_1807, arg_1808, arg_1809) } } } else {
//line :646:1
						var tmp9 any; var and__1927000168__auto____3_4 any; var root_1815 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_1816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1815, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1817 lang.IFn





						if linked_1816 == nil { ifn_1817 = lang.IFn_Cast(root_1815) } else { ifn_1817 = nil }; var arg_1818 any = u__2; if linked_1816 == nil { and__1927000168__auto____3_4 = ifn_1817.Invoke_O__O(arg_1818) } else { and__1927000168__auto____3_4 = linked_1816.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1815, arg_1818) }; if jrt.J2g_Truth(and__1927000168__auto____3_4) { var root_1819 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1819, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1821 lang.IFn; if linked_1820 == nil { ifn_1821 = lang.IFn_Cast(root_1819) } else { ifn_1821 = nil }; var arg_1822 any = A_arbace_go_check_types_A_const_210; var arg_1823 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)); if linked_1820 == nil { tmp9 = ifn_1821.Invoke_O_O__O(arg_1822, arg_1823) } else { tmp9 = linked_1820.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1819, arg_1822, arg_1823) } } else { tmp9 = and__1927000168__auto____3_4 }
//line :646:1
						if jrt.J2g_Truth(tmp9) { tmp1 = A_arbace_go_check_types_A_const_211.GetRawRoot__O() } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_40, u__2) { tmp1 = A_arbace_go_check_types_A_const_211.GetRawRoot__O() } else { if A_arbace_go_check_types_A_const_86 != nil { var a__3 any; var root_1824 any = A_arbace_go_check_types_A_const_212.GetRawRoot__O(); var linked_1825 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1824, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1826 lang.IFn








							if linked_1825 == nil { ifn_1826 = lang.IFn_Cast(root_1824) } else { ifn_1826 = nil }; var arg_1827 any = t__0; if linked_1825 == nil { a__3 = ifn_1826.Invoke_O__O(arg_1827) } else { a__3 = jrt.Long_ValueOf_J__Long_NoInit(linked_1825.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1824, arg_1827)).Ref() }
//line :646:1
							var a__4 any; var tmp10 bool
							var na_1828 any = a__3
							var na_1829 int64 = 1







							if jrt.Long_InstanceOf(na_1828) { var n0_1830 int64 = jrt.NN(jrt.Long_Cast(na_1828)).LongValue__J(); var n1_1831 int64 = na_1829; tmp10 = n0_1830 < n1_1831 } else { tmp10 = lang.Numbers_Lt_O_J__Z_NoInit(na_1828, na_1829) }; if tmp10 { a__4 = A_arbace_go_check_types_A_const_15 } else { a__4 = a__3 }
//line :646:1
							var a__5 any; var tmp11 any; var root_1833 any = A_arbace_go_check_types_A_const_114.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, A_arbace_go_check_types_complex_type_QMARK__A_fn_class); var ifn_1835 lang.IFn










							if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any = t__0; if linked_1834 == nil { tmp11 = ifn_1835.Invoke_O__O(arg_1836) } else { tmp11 = linked_1834.(*A_arbace_go_check_types_complex_type_QMARK__A).Invoke_O_O__O(root_1833, arg_1836) }; if jrt.J2g_Truth(tmp11) { var na_1837 any = a__4; var na_1838 int64 = 2; if jrt.Long_InstanceOf(na_1837) { var n0_1839 int64 = jrt.NN(jrt.Long_Cast(na_1837)).LongValue__J(); var n1_1840 int64 = na_1838; if n1_1840 == 0 { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1837, na_1838) } else { a__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_1839 / n1_1840).Ref() } } else { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1837, na_1838) } } else { a__5 = a__4 }
							tmp1 = lang.Numbers_Min_O_O__O_NoInit(a__5, A_arbace_go_check_types_A_const_213.GetRawRoot__O()) } else {
//line :646:1
								tmp1 = nil } } } } }; return /*line :644:1*/ jrt.Number_Cast(tmp1).LongValue__J() }
//line :644:1
func (t *A_arbace_go_check_types_alignof_A) Invoke_O_O__O(self, t__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, t__0)).Ref() }






func A_arbace_go_check_types_alignof_fn__219000253_A_New() *A_arbace_go_check_types_alignof_fn__219000253_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alignof_fn__219000253_A{}; t.Ctor(); return t }
//line :651:1
func (t *A_arbace_go_check_types_alignof_fn__219000253_A) Ctor() {}
//line :651:1
func (t *A_arbace_go_check_types_alignof_fn__219000253_A) Invoke_O_O_O__O(self, m__1, f__2 any) any { var tmp1 int64; var root_1810 any = A_arbace_go_check_types_A_const_207.GetRawRoot__O(); var linked_1811 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1810, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1812 lang.IFn; if linked_1811 == nil { ifn_1812 = lang.IFn_Cast(root_1810) } else { ifn_1812 = nil }; var arg_1813 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(f__2); if linked_1811 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_1812.Invoke_O__O(arg_1813)) } else { tmp1 = linked_1811.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1810, arg_1813) }; return lang.Numbers_Max_O_J__O_NoInit(m__1, tmp1) }








func A_arbace_go_check_types_offsetsof_A_New() *A_arbace_go_check_types_offsetsof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_offsetsof_A{}; t.Ctor(); return t }
//line :660:1
func (t *A_arbace_go_check_types_offsetsof_A) Ctor() {}
//line :660:1
func (t *A_arbace_go_check_types_offsetsof_A) Invoke_O_O__O(self, fields__0 any) any { { var fs__2 any = fields__0; var offs__3 any = lang.RT_Box_J__Number_NoInit(0); var acc__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




	var tmp1 any; var root_1842 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1842, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1844 lang.IFn; if linked_1843 == nil { ifn_1844 = lang.IFn_Cast(root_1842) } else { ifn_1844 = nil }; var arg_1845 any = fs__2; if linked_1843 == nil { tmp1 = ifn_1844.Invoke_O__O(arg_1845) } else { tmp1 = linked_1843.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1842, arg_1845) }; if jrt.J2g_Truth(tmp1) { return acc__4 } else { var f__5 any; var root_1846 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_1847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1846, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1848 lang.IFn

		if linked_1847 == nil { ifn_1848 = lang.IFn_Cast(root_1846) } else { ifn_1848 = nil }; var arg_1849 any = fs__2; if linked_1847 == nil { f__5 = ifn_1848.Invoke_O__O(arg_1849) } else { f__5 = linked_1847.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1846, arg_1849) }
		var tmp2 bool; var na_1850 any = offs__3; if jrt.Long_InstanceOf(na_1850) { var n0_1851 int64 = jrt.NN(jrt.Long_Cast(na_1850)).LongValue__J(); tmp2 = n0_1851 < 0 } else { if jrt.Double_InstanceOf(na_1850) { var n0_1851_2 float64 = jrt.NN(jrt.Double_Cast(na_1850)).DoubleValue__D(); tmp2 = n0_1851_2 < 0.0 } else { tmp2 = lang.Numbers_IsNeg_O__Z_NoInit(na_1850) } }; if tmp2 {
			var tmp3 any; var root_1865 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1865, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1867 lang.IFn; if linked_1866 == nil { ifn_1867 = lang.IFn_Cast(root_1865) } else { ifn_1867 = nil }; var arg_1868 any = fs__2; if linked_1866 == nil { tmp3 = ifn_1867.Invoke_O__O(arg_1868) } else { tmp3 = linked_1866.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1865, arg_1868) }; var tmp4 any = tmp3; var tmp5 any; var root_1869 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1870 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1869, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1871 lang.IFn; if linked_1870 == nil { ifn_1871 = lang.IFn_Cast(root_1869) } else { ifn_1871 = nil }; var arg_1872 any = acc__4; var arg_1873 any = A_arbace_go_check_types_A_const_215; if linked_1870 == nil { tmp5 = ifn_1871.Invoke_O_O__O(arg_1872, arg_1873) } else { tmp5 = linked_1870.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1869, arg_1872, arg_1873) }; fs__2, offs__3, acc__4 = tmp4, offs__3, tmp5; continue L1 } else {
//line :668:1
				var o__6 any; var root_1852 any = A_arbace_go_check_types_A_const_214.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1852, A_arbace_go_check_types_align_up_A_fn_class); var ifn_1854 lang.IFn

				if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = offs__3; var arg_1856 any; var root_1857 any = A_arbace_go_check_types_A_const_207.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1857, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1859 lang.IFn; if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(f__5); if linked_1858 == nil { arg_1856 = ifn_1859.Invoke_O__O(arg_1860) } else { arg_1856 = jrt.Long_ValueOf_J__Long_NoInit(linked_1858.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1857, arg_1860)).Ref() }; if linked_1853 == nil { o__6 = ifn_1854.Invoke_O_O__O(arg_1855, arg_1856) } else { o__6 = jrt.Long_ValueOf_J__Long_NoInit(linked_1853.(*A_arbace_go_check_types_align_up_A).InvokePrim_O_J_J__J(root_1852, lang.RT_LongCast_O__J_NoInit(arg_1855), lang.RT_LongCast_O__J_NoInit(arg_1856))).Ref() }
//line :668:1
				var d__7 any; var root_1861 any = A_arbace_go_check_types_A_const_212.GetRawRoot__O(); var linked_1862 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1861, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1863 lang.IFn


				if linked_1862 == nil { ifn_1863 = lang.IFn_Cast(root_1861) } else { ifn_1863 = nil }; var arg_1864 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(f__5); if linked_1862 == nil { d__7 = ifn_1863.Invoke_O__O(arg_1864) } else { d__7 = jrt.Long_ValueOf_J__Long_NoInit(linked_1862.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1861, arg_1864)).Ref() }
				var tmp6 any; var root_1874 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1874, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1876 lang.IFn; if linked_1875 == nil { ifn_1876 = lang.IFn_Cast(root_1874) } else { ifn_1876 = nil }; var arg_1877 any = fs__2; if linked_1875 == nil { tmp6 = ifn_1876.Invoke_O__O(arg_1877) } else { tmp6 = linked_1875.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1874, arg_1877) }; var tmp7 any = tmp6; var tmp8 any; var tmp9 bool; var and__1927000168__auto____8 bool; var na_1878 any = d__7; var na_1879 int64 = 0
				if jrt.Long_InstanceOf(na_1878) { var n0_1880 int64 = jrt.NN(jrt.Long_Cast(na_1878)).LongValue__J(); var n1_1881 int64 = na_1879; and__1927000168__auto____8 = n0_1880 >= n1_1881 } else { and__1927000168__auto____8 = lang.Numbers_Gte_O_J__Z_NoInit(na_1878, na_1879) }; if and__1927000168__auto____8 { var na_1883 any = o__6; var na_1884 int64 = 0; if jrt.Long_InstanceOf(na_1883) { var n0_1885 int64 = jrt.NN(jrt.Long_Cast(na_1883)).LongValue__J(); var n1_1886 int64 = na_1884; tmp9 = n0_1885 >= n1_1886 } else { tmp9 = lang.Numbers_Gte_O_J__Z_NoInit(na_1883, na_1884) } } else { tmp9 = and__1927000168__auto____8 }; if tmp9 { var na_1888 any = o__6; var na_1889 any = d__7; var tmp10 bool; var tmp11 bool; tmp11 = jrt.Long_InstanceOf(na_1888); if tmp11 { tmp11 = jrt.Long_InstanceOf(na_1889) }; tmp10 = tmp11; if tmp10 { var n0_1890 int64 = jrt.NN(jrt.Long_Cast(na_1888)).LongValue__J(); var n1_1891 int64 = jrt.NN(jrt.Long_Cast(na_1889)).LongValue__J(); tmp8 = jrt.Long_ValueOf_J__Long_NoInit(n0_1890 + n1_1891).Ref() } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_1888); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_1889) }; tmp12 = tmp13; if tmp12 { var n0_1890_2 float64 = jrt.NN(jrt.Double_Cast(na_1888)).DoubleValue__D(); var n1_1891_2 float64 = jrt.NN(jrt.Double_Cast(na_1889)).DoubleValue__D(); tmp8 = jrt.Double_ValueOf_D__Double_NoInit(n0_1890_2 + n1_1891_2).Ref() } else { tmp8 = lang.Numbers_Unchecked_add_O_O__Number_NoInit(na_1888, na_1889) } } } else { tmp8 = A_arbace_go_check_types_A_const_215 }
//line :672:1
				var tmp14 any = tmp8; var tmp15 any; var root_1893 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1894 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1893, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1895 lang.IFn

				if linked_1894 == nil { ifn_1895 = lang.IFn_Cast(root_1893) } else { ifn_1895 = nil }; var arg_1896 any = acc__4; var arg_1897 any = o__6; if linked_1894 == nil { tmp15 = ifn_1895.Invoke_O_O__O(arg_1896, arg_1897) } else { tmp15 = linked_1894.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1893, arg_1896, arg_1897) }
//line :672:1
				fs__2, offs__3, acc__4 = tmp7, tmp14, tmp15; continue L1 } } } }; /*line :660:1*/panic("j2g: unreachable") }















func A_arbace_go_check_types_sizeof_A_New() *A_arbace_go_check_types_sizeof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sizeof_A{}; t.Ctor(); return t }
//line :676:1
func (t *A_arbace_go_check_types_sizeof_A) Ctor() {}
//line :676:1
func (t *A_arbace_go_check_types_sizeof_A) InvokePrim_O_O__J(self, t__0 any) int64 { var tmp1 any; var u__2 any; var root_1898 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_1899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1898, A_arbace_go_check_types_under_A_fn_class); var ifn_1900 lang.IFn; if


	linked_1899 == nil { ifn_1900 = lang.IFn_Cast(root_1898) } else { ifn_1900 = nil }; var arg_1901 any = t__0; if linked_1899 == nil { u__2 = ifn_1900.Invoke_O__O(arg_1901) } else { u__2 = linked_1899.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1898, arg_1901) }; var tmp2 any; var root_1902 any =
	A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_1903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1902, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_1904 lang.IFn; if
	linked_1903 == nil { ifn_1904 = lang.IFn_Cast(root_1902) } else { ifn_1904 = nil }; var arg_1905 any = u__2; if linked_1903 == nil { tmp2 = ifn_1904.Invoke_O__O(arg_1905) } else { tmp2 = linked_1903.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_1902, arg_1905) }; if /*line :680:1*/ jrt.J2g_Truth(tmp2) { var G__219000257__3_ any = u__2
	L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__219000257__3_) { case 717828005: if any(G__219000257__3_) == any(A_arbace_go_check_types_A_const_40) { var na_1907 int64 = 2; var na_1908 any = A_arbace_go_check_types_A_const_211.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1908) { var n0_1909 int64 = na_1907; var n1_1910 int64 = jrt.NN(jrt.Long_Cast(na_1908)).LongValue__J(); var nr_1911 int64 = n0_1909 * n1_1910; var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; tmp6 = n0_1909 == -9223372036854775808; if tmp6 { tmp6 = n1_1910 < 0 }; tmp5 = tmp6; tmp4 = !tmp5; if tmp4 { var tmp7 bool; tmp7 = n1_1910 == 0; if !tmp7 { tmp7 = nr_1911/n1_1910 == n0_1909 }; tmp4 = tmp7 }; tmp3 = tmp4; if tmp3 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1911).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1907, na_1908) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1907, na_1908) }; break L1 }; default:}; var tmp8 lang.IFn = A_arbace_go_check_types_A_const_11; tmp1 = tmp8.Invoke_O_O__O(lang.IFn_Cast(A_arbace_go_check_types_A_const_110.GetRawRoot__O()).Invoke_O__O(u__2), A_arbace_go_check_types_A_const_211.GetRawRoot__O())} } else {
//line :680:1
		if A_arbace_go_check_types_A_const_86 != nil { var G__219000258__3_ any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0))


		L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__219000258__3_) >> 5 & 3 { case 0: if any(G__219000258__3_) == any(A_arbace_go_check_types_A_const_74) { var n__4 int64 = lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)))

			if lang.Numbers_Lte_J_J__Z_NoInit(n__4, 0) { tmp1 = A_arbace_go_check_types_A_const_44 } else { var es__5 any; var root_1913 any = A_arbace_go_check_types_A_const_212.GetRawRoot__O(); var linked_1914 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1913, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1915 lang.IFn

				if linked_1914 == nil { ifn_1915 = lang.IFn_Cast(root_1913) } else { ifn_1915 = nil }; var arg_1916 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)); if linked_1914 == nil { es__5 = ifn_1915.Invoke_O__O(arg_1916) } else { es__5 = jrt.Long_ValueOf_J__Long_NoInit(linked_1914.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1913, arg_1916)).Ref() }
				var tmp9 bool; var na_1917 any = es__5
				if jrt.Long_InstanceOf(na_1917) { var n0_1918 int64 = jrt.NN(jrt.Long_Cast(na_1917)).LongValue__J(); tmp9 = n0_1918 < 0 } else { if jrt.Double_InstanceOf(na_1917) { var n0_1918_2 float64 = jrt.NN(jrt.Double_Cast(na_1917)).DoubleValue__D(); tmp9 = n0_1918_2 < 0.0 } else { tmp9 = lang.Numbers_IsNeg_O__Z_NoInit(na_1917) } }
//line :688:1
				if tmp9 { tmp1 = A_arbace_go_check_types_A_const_215 } else { var tmp10 bool
					var na_1919 any = es__5
					if jrt.Long_InstanceOf(na_1919) { var n0_1920 int64 = jrt.NN(jrt.Long_Cast(na_1919)).LongValue__J(); tmp10 = n0_1920 == 0 } else { if jrt.Double_InstanceOf(na_1919) { var n0_1920_2 float64 = jrt.NN(jrt.Double_Cast(na_1919)).DoubleValue__D(); tmp10 = n0_1920_2 == 0.0 } else { tmp10 = lang.Numbers_IsZero_O__Z_NoInit(na_1919) } }
//line :688:1
					if tmp10 { tmp1 = A_arbace_go_check_types_A_const_44 } else { var tmp11 bool; var na_1921 any = es__5; var na_1922 int64 = lang.Numbers_Quotient_J_J__J_NoInit(9223372036854775807, n__4)


						if jrt.Long_InstanceOf(na_1921) { var n0_1923 int64 = jrt.NN(jrt.Long_Cast(na_1921)).LongValue__J(); var n1_1924 int64 = na_1922; tmp11 = n0_1923 > n1_1924 } else { tmp11 = lang.Numbers_Gt_O_J__Z_NoInit(na_1921, na_1922) }
//line :688:1
						if tmp11 { tmp1 = A_arbace_go_check_types_A_const_215 } else { if A_arbace_go_check_types_A_const_86 != nil {



							var na_1926 any = es__5; var na_1927 int64 = n__4; if jrt.Long_InstanceOf(na_1926) { var n0_1928 int64 = jrt.NN(jrt.Long_Cast(na_1926)).LongValue__J(); var n1_1929 int64 = na_1927; var nr_1930 int64 = n0_1928 * n1_1929; var tmp12 bool; var tmp13 bool; var tmp14 bool; var tmp15 bool; tmp15 = n0_1928 == -9223372036854775808; if tmp15 { tmp15 = n1_1929 < 0 }; tmp14 = tmp15; tmp13 = !tmp14; if tmp13 { var tmp16 bool; tmp16 = n1_1929 == 0; if !tmp16 { tmp16 = nr_1930/n1_1929 == n0_1928 }; tmp13 = tmp16 }; tmp12 = tmp13; if tmp12 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1930).Ref() } else { tmp1 = lang.Numbers_Multiply_O_J__Number_NoInit(na_1926, na_1927) } } else { tmp1 = lang.Numbers_Multiply_O_J__Number_NoInit(na_1926, na_1927) } } else {
//line :688:1
								tmp1 = nil } } } } }
//line :683:1
			break L2 }; case 1: if any(G__219000258__3_) == any(A_arbace_go_check_types_A_const_71) {





















				var na_1931 int64 = 2; var na_1932 any = A_arbace_go_check_types_A_const_211.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1932) { var n0_1933 int64 = na_1931; var n1_1934 int64 = jrt.NN(jrt.Long_Cast(na_1932)).LongValue__J(); var nr_1935 int64 = n0_1933 * n1_1934; var tmp17 bool; var tmp18 bool; var tmp19 bool; var tmp20 bool; tmp20 = n0_1933 == -9223372036854775808; if tmp20 { tmp20 = n1_1934 < 0 }; tmp19 = tmp20; tmp18 = !tmp19; if tmp18 { var tmp21 bool; tmp21 = n1_1934 == 0; if !tmp21 { tmp21 = nr_1935/n1_1934 == n0_1933 }; tmp18 = tmp21 }; tmp17 = tmp18; if tmp17 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1935).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1931, na_1932) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1931, na_1932) }
//line :683:1
				break L2 }; case 2: if any(G__219000258__3_) == any(A_arbace_go_check_types_A_const_78) {









					var na_1936 int64 = 3; var na_1937 any = A_arbace_go_check_types_A_const_211.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1937) { var n0_1938 int64 = na_1936; var n1_1939 int64 = jrt.NN(jrt.Long_Cast(na_1937)).LongValue__J(); var nr_1940 int64 = n0_1938 * n1_1939; var tmp22 bool; var tmp23 bool; var tmp24 bool; var tmp25 bool; tmp25 = n0_1938 == -9223372036854775808; if tmp25 { tmp25 = n1_1939 < 0 }; tmp24 = tmp25; tmp23 = !tmp24; if tmp23 { var tmp26 bool; tmp26 = n1_1939 == 0; if !tmp26 { tmp26 = nr_1940/n1_1939 == n0_1938 }; tmp23 = tmp26 }; tmp22 = tmp23; if tmp22 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1940).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1936, na_1937) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1936, na_1937) }
//line :683:1
					break L2 }; case 3: if any(G__219000258__3_) == any(A_arbace_go_check_types_A_const_82) { var fs__4 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); var tmp27 any; var root_1941 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1941, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1943 lang.IFn











						if linked_1942 == nil { ifn_1943 = lang.IFn_Cast(root_1941) } else { ifn_1943 = nil }; var arg_1944 any = fs__4; if linked_1942 == nil { tmp27 = ifn_1943.Invoke_O__O(arg_1944) } else { tmp27 = linked_1942.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1941, arg_1944) }; if jrt.J2g_Truth(tmp27) { tmp1 = A_arbace_go_check_types_A_const_44 } else { var offs__5 any; var root_1945 any = A_arbace_go_check_types_A_const_216.GetRawRoot__O(); var linked_1946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1945, A_arbace_go_check_types_offsetsof_A_fn_class); var ifn_1947 lang.IFn

							if linked_1946 == nil { ifn_1947 = lang.IFn_Cast(root_1945) } else { ifn_1947 = nil }; var arg_1948 any = fs__4; if linked_1946 == nil { offs__5 = ifn_1947.Invoke_O__O(arg_1948) } else { offs__5 = linked_1946.(*A_arbace_go_check_types_offsetsof_A).Invoke_O_O__O(root_1945, arg_1948) }
//line :695:1
							var o__6 int64; var tmp28 any; var root_1949 any = A_arbace_go_check_types_A_const_217.GetRawRoot__O(); var linked_1950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1949, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_1951 lang.IFn


							if linked_1950 == nil { ifn_1951 = lang.IFn_Cast(root_1949) } else { ifn_1951 = nil }; var arg_1952 any = offs__5; if linked_1950 == nil { tmp28 = ifn_1951.Invoke_O__O(arg_1952) } else { tmp28 = linked_1950.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_1949, arg_1952) }; o__6 = lang.RT_LongCast_O__J_NoInit(tmp28)
//line :695:1
							var s__7 any; var root_1953 any = A_arbace_go_check_types_A_const_212.GetRawRoot__O(); var linked_1954 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1953, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1955 lang.IFn



							if linked_1954 == nil { ifn_1955 = lang.IFn_Cast(root_1953) } else { ifn_1955 = nil }; var arg_1956 any; var tmp29 *lang.Keyword = A_arbace_go_check_types_A_const_65; var tmp30 any; var root_1957 any = A_arbace_go_check_types_A_const_217.GetRawRoot__O(); var linked_1958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1957, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_1959 lang.IFn; if linked_1958 == nil { ifn_1959 = lang.IFn_Cast(root_1957) } else { ifn_1959 = nil }; var arg_1960 any = fs__4; if linked_1958 == nil { tmp30 = ifn_1959.Invoke_O__O(arg_1960) } else { tmp30 = linked_1958.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_1957, arg_1960) }; arg_1956 = tmp29.Invoke_O__O(tmp30); if linked_1954 == nil { s__7 = ifn_1955.Invoke_O__O(arg_1956) } else { s__7 = jrt.Long_ValueOf_J__Long_NoInit(linked_1954.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1953, arg_1956)).Ref() }
							var tmp31 bool; var or__1927000174__auto____8 bool = lang.Numbers_IsNeg_J__Z_NoInit(o__6); if or__1927000174__auto____8 { tmp31 = or__1927000174__auto____8 } else { var na_1961 any = s__7; if jrt.Long_InstanceOf(na_1961) { var n0_1962 int64 = jrt.NN(jrt.Long_Cast(na_1961)).LongValue__J(); tmp31 = n0_1962 < 0 } else { if jrt.Double_InstanceOf(na_1961) { var n0_1962_2 float64 = jrt.NN(jrt.Double_Cast(na_1961)).DoubleValue__D(); tmp31 = n0_1962_2 < 0.0 } else { tmp31 = lang.Numbers_IsNeg_O__Z_NoInit(na_1961) } } }; if tmp31 { tmp1 = A_arbace_go_check_types_A_const_215 } else { var s__8 any; var tmp32 bool; var and__1927000168__auto____8 bool = lang.Numbers_IsPos_J__Z_NoInit(o__6)

								if and__1927000168__auto____8 { var na_1963 any = s__7; if jrt.Long_InstanceOf(na_1963) { var n0_1964 int64 = jrt.NN(jrt.Long_Cast(na_1963)).LongValue__J(); tmp32 = n0_1964 == 0 } else { if jrt.Double_InstanceOf(na_1963) { var n0_1964_2 float64 = jrt.NN(jrt.Double_Cast(na_1963)).DoubleValue__D(); tmp32 = n0_1964_2 == 0.0 } else { tmp32 = lang.Numbers_IsZero_O__Z_NoInit(na_1963) } } } else { tmp32 = and__1927000168__auto____8 }; if tmp32 { s__8 = A_arbace_go_check_types_A_const_15 } else { s__8 = s__7
								}
								var root_1965 any = A_arbace_go_check_types_A_const_214.GetRawRoot__O(); var linked_1966 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1965, A_arbace_go_check_types_align_up_A_fn_class); var ifn_1967 lang.IFn; if linked_1966 == nil { ifn_1967 = lang.IFn_Cast(root_1965) } else { ifn_1967 = nil }; var arg_1968 any; var na_1970 int64 = o__6; var na_1971 any = s__8; if jrt.Long_InstanceOf(na_1971) { var n0_1972 int64 = na_1970; var n1_1973 int64 = jrt.NN(jrt.Long_Cast(na_1971)).LongValue__J(); arg_1968 = jrt.Long_ValueOf_J__Long_NoInit(n0_1972 + n1_1973).Ref() } else { arg_1968 = lang.Numbers_Unchecked_add_J_O__Number_NoInit(na_1970, na_1971) }; var arg_1969 any; var root_1975 any = A_arbace_go_check_types_A_const_207.GetRawRoot__O(); var linked_1976 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1975, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1977 lang.IFn; if linked_1976 == nil { ifn_1977 = lang.IFn_Cast(root_1975) } else { ifn_1977 = nil }; var arg_1978 any = t__0; if linked_1976 == nil { arg_1969 = ifn_1977.Invoke_O__O(arg_1978) } else { arg_1969 = jrt.Long_ValueOf_J__Long_NoInit(linked_1976.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1975, arg_1978)).Ref() }; if linked_1966 == nil { tmp1 = ifn_1967.Invoke_O_O__O(arg_1968, arg_1969) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_1966.(*A_arbace_go_check_types_align_up_A).InvokePrim_O_J_J__J(root_1965, lang.RT_LongCast_O__J_NoInit(arg_1968), lang.RT_LongCast_O__J_NoInit(arg_1969))).Ref() } } }
//line :683:1
						break L2 }; default:}; tmp1 = A_arbace_go_check_types_A_const_211.GetRawRoot__O()} } else {
//line :680:1
							tmp1 = nil } }; return /*line :676:1*/ jrt.Number_Cast(tmp1).LongValue__J() }
//line :676:1
func (t *A_arbace_go_check_types_sizeof_A) Invoke_O_O__O(self, t__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, t__0)).Ref() }

































func A_arbace_go_check_types_deref_type_A_New() *A_arbace_go_check_types_deref_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_deref_type_A{}; t.Ctor(); return t }
//line :710:1
func (t *A_arbace_go_check_types_deref_type_A) Ctor() {}
//line :710:1
func (t *A_arbace_go_check_types_deref_type_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_1979 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_1980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1979, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1981 lang.IFn; if linked_1980 == nil { ifn_1981 = lang.IFn_Cast(root_1979) } else { ifn_1981 = nil }; var arg_1982 any = t__0; if linked_1980 == nil { and__1927000168__auto____2 = ifn_1981.Invoke_O__O(arg_1982) } else { and__1927000168__auto____2 = linked_1980.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1979, arg_1982) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_types_A_const_73; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)), jrt.Boolean_TRUE.Ref()) } else { return lang.Tuple_Create_O_O__IPersistentVector(t__0, jrt.Boolean_FALSE.Ref())
	} }
func A_arbace_go_check_types_methods_of_A_New() *A_arbace_go_check_types_methods_of_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_methods_of_A{}; t.Ctor(); return t }
//line :715:1
func (t *A_arbace_go_check_types_methods_of_A) Ctor() {}
//line :715:1
func (t *A_arbace_go_check_types_methods_of_A) Invoke_O_O__O(self, t__0 any) any { var t__2 any; var tmp1 *lang.Keyword = A_arbace_go_check_types_A_const_218; var tmp2 any; var root_1983 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_1984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1983, A_arbace_go_check_types_info_A_fn_class); var ifn_1985 lang.IFn; if


	linked_1984 == nil { ifn_1985 = lang.IFn_Cast(root_1983) } else { ifn_1985 = nil }; var arg_1986 any = t__0; if linked_1984 == nil { tmp2 = ifn_1985.Invoke_O__O(arg_1986) } else { tmp2 = linked_1984.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1983, arg_1986) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 *lang.Keyword = A_arbace_go_check_types_A_const_218; var tmp4 any; var root_1987 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_1988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1987, A_arbace_go_check_types_info_A_fn_class); var ifn_1989 lang.IFn; if linked_1988 == nil { ifn_1989 = lang.IFn_Cast(root_1987) } else { ifn_1989 = nil }; var arg_1990 any = t__0; if linked_1988 == nil { tmp4 = ifn_1989.Invoke_O__O(arg_1990) } else { tmp4 = linked_1988.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1987, arg_1990) }; t__2 = tmp3.Invoke_O__O(tmp4) } else { t__2 = t__0 }; var root_1995 any =
	A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_1996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1995, A_arbace_go_check_types_under_A_fn_class); var ifn_1997 lang.IFn; if linked_1996 == nil { ifn_1997 = lang.IFn_Cast(root_1995) } else { ifn_1997 = nil }; var arg_1998 any = t__2; if linked_1996 == nil { ifn_1997.Invoke_O__O(arg_1998) } else { linked_1996.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1995, arg_1998) }; var tmp5 /*line :720:1*/*lang.Keyword = A_arbace_go_check_types_A_const_98; var tmp6 any; var root_1991 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_1992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1991, A_arbace_go_check_types_info_A_fn_class); var ifn_1993 lang.IFn; if linked_1992 == nil { ifn_1993 = lang.IFn_Cast(root_1991) } else { ifn_1993 = nil }; var arg_1994 any = t__2; if linked_1992 == nil { tmp6 = ifn_1993.Invoke_O__O(arg_1994) } else { tmp6 = linked_1992.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1991, arg_1994) }; return tmp5.Invoke_O__O(tmp6) }





func A_arbace_go_check_types_same_id_QMARK__A_New() *A_arbace_go_check_types_same_id_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_same_id_QMARK__A{}; t.Ctor(); return t }
//line :726:1
func (t *A_arbace_go_check_types_same_id_QMARK__A) Ctor() {}
//line :726:1
func (t *A_arbace_go_check_types_same_id_QMARK__A) Invoke_O_O_O_O_O__O(self, n__0, p__1, name__2, pkg__3 any) any {



	var tmp1 any; var and__1927000168__auto____5 any = A_arbace_go_check_types_A_const_219.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.String_Cast(n__0)).EqualsIgnoreCase_String__Z(jrt.String_Cast(name__2))).Ref() } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, name__2)

		if and__1927000168__auto____5_2 { var or__1927000174__auto____6 bool = jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(name__2)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))
			if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(p__1, pkg__3); if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { return jrt.Boolean_FALSE.Ref() } } } else {
//line :732:1
				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref()
			}
	}
}


func A_arbace_go_check_types_exported_QMARK__A_New() *A_arbace_go_check_types_exported_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_exported_QMARK__A{}; t.Ctor(); return t }
//line :738:1
func (t *A_arbace_go_check_types_exported_QMARK__A) Ctor() {}
//line :738:1
func (t *A_arbace_go_check_types_exported_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var cp__2 int32 = jrt.NN(jrt.String_Cast(n__0)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(0)); return /*line :739:1*/ jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_I__Z_NoInit(cp__2)).Ref() }











func A_arbace_go_check_types_named_method_A_New() *A_arbace_go_check_types_named_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_method_A{}; t.Ctor(); return t }
//line :751:1
func (t *A_arbace_go_check_types_named_method_A) Ctor() {}
//line :751:1
func (t *A_arbace_go_check_types_named_method_A) Invoke_O_O_O_O__O(self, t__0, name__1, pkg__2 any) any { { var ms__4 any; var root_1999 any = A_arbace_go_check_types_A_const_220.GetRawRoot__O(); var linked_2000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1999, A_arbace_go_check_types_methods_of_A_fn_class); var ifn_2001 lang.IFn


	if linked_2000 == nil { ifn_2001 = lang.IFn_Cast(root_1999) } else { ifn_2001 = nil }; var arg_2002 any = t__0; if linked_2000 == nil { ms__4 = ifn_2001.Invoke_O__O(arg_2002) } else { ms__4 = linked_2000.(*A_arbace_go_check_types_methods_of_A).Invoke_O_O__O(root_1999, arg_2002) }
//line :751:1
	var i__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i__5, int64(lang.RT_Count_O__I_NoInit(ms__4))) { var m__6 any = lang.RT_Nth_O_I__O_NoInit(ms__4, lang.RT_IntCast_J__I_NoInit(i__5)); var map__219000264__7 any; var root_2003 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_2004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2003, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2005 lang.IFn
			if linked_2004 == nil { ifn_2005 = lang.IFn_Cast(root_2003) } else { ifn_2005 = nil }; var arg_2006 any = m__6; if linked_2004 == nil { map__219000264__7 = ifn_2005.Invoke_O__O(arg_2006) } else { map__219000264__7 = linked_2004.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2003, arg_2006) }
//line :756:1
			var map__219000264__8 any
			if lang.ISeq_InstanceOf(map__219000264__7) { var tmp1 any; var root_2007 any = A_arbace_go_check_types_A_const_221.GetRawRoot__O(); var linked_2008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2007, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2009 lang.IFn; if linked_2008 == nil { ifn_2009 = lang.IFn_Cast(root_2007) } else { ifn_2009 = nil }; var arg_2010 any = map__219000264__7; if linked_2008 == nil { tmp1 = ifn_2009.Invoke_O__O(arg_2010) } else { tmp1 = linked_2008.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2007, arg_2010) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2011 any = A_arbace_go_check_types_A_const_222.GetRawRoot__O(); var linked_2012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2011, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2013 lang.IFn; if linked_2012 == nil { ifn_2013 = lang.IFn_Cast(root_2011) } else { ifn_2013 = nil }; var arg_2014 any = map__219000264__7; if linked_2012 == nil { tmp2 = ifn_2013.Invoke_O__O(arg_2014) } else { tmp2 = linked_2012.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2011, arg_2014) }; map__219000264__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_2015 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_2016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2015, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2017 lang.IFn; if linked_2016 == nil { ifn_2017 = lang.IFn_Cast(root_2015) } else { ifn_2017 = nil }; var arg_2018 any = map__219000264__7; if linked_2016 == nil { tmp3 = ifn_2017.Invoke_O__O(arg_2018) } else { tmp3 = linked_2016.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2015, arg_2018) }; if jrt.J2g_Truth(tmp3) { var root_2019 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_2020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2019, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2021 lang.IFn; if linked_2020 == nil { ifn_2021 = lang.IFn_Cast(root_2019) } else { ifn_2021 = nil }; var arg_2022 any = map__219000264__7; if linked_2020 == nil { map__219000264__8 = ifn_2021.Invoke_O__O(arg_2022) } else { map__219000264__8 = linked_2020.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2019, arg_2022) } } else { map__219000264__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__219000264__8 = map__219000264__7 }
//line :756:1
			var mn__9 any = lang.RT_Get_O_O__O_NoInit(map__219000264__8, A_arbace_go_check_types_A_const_12); var mp__10 any = lang.RT_Get_O_O__O_NoInit(map__219000264__8, A_arbace_go_check_types_A_const_57); var tmp4 any; var root_2023 any = A_arbace_go_check_types_A_const_223.GetRawRoot__O(); var linked_2024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2023, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_2025 lang.IFn


			if linked_2024 == nil { ifn_2025 = lang.IFn_Cast(root_2023) } else { ifn_2025 = nil }; var arg_2026 any = mn__9; var arg_2027 any = mp__10; var arg_2028 any = name__1; var arg_2029 any = pkg__2; if linked_2024 == nil { tmp4 = ifn_2025.Invoke_O_O_O_O__O(arg_2026, arg_2027, arg_2028, arg_2029) } else { tmp4 = linked_2024.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_2023, arg_2026, arg_2027, arg_2028, arg_2029) }; if jrt.J2g_Truth(tmp4) { return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__5).Ref(), m__6) } else {

				i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } } else {
//line :756:1
					return nil } } }; /*line :751:1*/panic("j2g: unreachable") }











func A_arbace_go_check_types_iface_method_A_New() *A_arbace_go_check_types_iface_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_iface_method_A{}; t.Ctor(); return t }
//line :763:1
func (t *A_arbace_go_check_types_iface_method_A) Ctor() {}
//line :763:1
func (t *A_arbace_go_check_types_iface_method_A) Invoke_O_O_O_O__O(self, u__0, name__1, pkg__2 any) any { { var ms__4 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(1)); var i__5 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i__5, int64(lang.RT_Count_O__I_NoInit(ms__4))) { var m__6 any = lang.RT_Nth_O_I__O_NoInit(ms__4, lang.RT_IntCast_J__I_NoInit(i__5)); var tmp1 any; var root_2030 any = A_arbace_go_check_types_A_const_223.GetRawRoot__O(); var linked_2031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2030, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_2032 lang.IFn

		if linked_2031 == nil { ifn_2032 = lang.IFn_Cast(root_2030) } else { ifn_2032 = nil }; var arg_2033 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__6); var arg_2034 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(m__6); var arg_2035 any = name__1; var arg_2036 any = pkg__2; if linked_2031 == nil { tmp1 = ifn_2032.Invoke_O_O_O_O__O(arg_2033, arg_2034, arg_2035, arg_2036) } else { tmp1 = linked_2031.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_2030, arg_2033, arg_2034, arg_2035, arg_2036) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__5).Ref(), m__6) } else {

			i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } } else {
//line :768:1
				return nil } } }; /*line :763:1*/panic("j2g: unreachable") }










func A_arbace_go_check_types_consolidate_A_New() *A_arbace_go_check_types_consolidate_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_consolidate_A{}; t.Ctor(); return t }
//line :774:1
func (t *A_arbace_go_check_types_consolidate_A) Ctor() {}
//line :774:1
func (t *A_arbace_go_check_types_consolidate_A) Invoke_O_O__O(self, entries__0 any) any { { var es__2 any = entries__0; var acc__3 any = lang.PersistentVector_EMPTY.Ref(); var idx__4 any = lang.PersistentArrayMap_EMPTY.Ref(); L1: for {



	var tmp1 any; var root_2037 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_2038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2037, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2039 lang.IFn; if linked_2038 == nil { ifn_2039 = lang.IFn_Cast(root_2037) } else { ifn_2039 = nil }; var arg_2040 any = es__2; if linked_2038 == nil { tmp1 = ifn_2039.Invoke_O__O(arg_2040) } else { tmp1 = linked_2038.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2037, arg_2040) }; if jrt.J2g_Truth(tmp1) { return acc__3 } else { var e__5 any; var root_2041 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_2042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2041, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2043 lang.IFn

		if linked_2042 == nil { ifn_2043 = lang.IFn_Cast(root_2041) } else { ifn_2043 = nil }; var arg_2044 any = es__2; if linked_2042 == nil { e__5 = ifn_2043.Invoke_O__O(arg_2044) } else { e__5 = linked_2042.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2041, arg_2044) }
//line :778:1
		var k__6 any; var root_2045 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_2046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2045, A_arbace_go_check_types_canon_A_fn_class); var ifn_2047 lang.IFn


		if linked_2046 == nil { ifn_2047 = lang.IFn_Cast(root_2045) } else { ifn_2047 = nil }; var arg_2048 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(e__5); if linked_2046 == nil { k__6 = ifn_2047.Invoke_O__O(arg_2048) } else { k__6 = linked_2046.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_2045, arg_2048) }
//line :778:1
		var temp__1927000408__auto____7 any = lang.RT_Get_O_O__O_NoInit(idx__4, k__6)



		if jrt.J2g_Truth(temp__1927000408__auto____7) { var j__8 any = temp__1927000408__auto____7; var tmp2 any; var root_2049 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_2050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2049, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2051 lang.IFn
			if linked_2050 == nil { ifn_2051 = lang.IFn_Cast(root_2049) } else { ifn_2051 = nil }; var arg_2052 any = es__2; if linked_2050 == nil { tmp2 = ifn_2051.Invoke_O__O(arg_2052) } else { tmp2 = linked_2050.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2049, arg_2052) }; var tmp3 any = tmp2; var tmp4 any; var root_2053 any = A_arbace_go_check_types_A_const_224.GetRawRoot__O(); var linked_2054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2053, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_2055 lang.IFn; if linked_2054 == nil { ifn_2055 = lang.IFn_Cast(root_2053) } else { ifn_2055 = nil }; var arg_2056 any = acc__3; var arg_2057 any = lang.Tuple_Create_O_O__IPersistentVector(j__8, A_arbace_go_check_types_A_const_225); var arg_2058 any = jrt.Boolean_TRUE.Ref(); if linked_2054 == nil { tmp4 = ifn_2055.Invoke_O_O_O__O(arg_2056, arg_2057, arg_2058) } else { tmp4 = linked_2054.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_2053, arg_2056, arg_2057, arg_2058) }; es__2, acc__3, idx__4 = tmp3, tmp4, idx__4; continue L1 } else {
				var tmp5 any; var root_2059 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_2060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2059, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2061 lang.IFn; if linked_2060 == nil { ifn_2061 = lang.IFn_Cast(root_2059) } else { ifn_2061 = nil }; var arg_2062 any = es__2; if linked_2060 == nil { tmp5 = ifn_2061.Invoke_O__O(arg_2062) } else { tmp5 = linked_2060.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2059, arg_2062) }; var tmp6 any = tmp5; var tmp7 any; var root_2063 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2064 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2063, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2065 lang.IFn; if linked_2064 == nil { ifn_2065 = lang.IFn_Cast(root_2063) } else { ifn_2065 = nil }; var arg_2066 any = acc__3; var arg_2067 any = e__5; if linked_2064 == nil { tmp7 = ifn_2065.Invoke_O_O__O(arg_2066, arg_2067) } else { tmp7 = linked_2064.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2063, arg_2066, arg_2067) }; var tmp8 any = tmp7; var tmp9 any; var root_2068 any = A_arbace_go_check_types_A_const_67.GetRawRoot__O(); var linked_2069 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2068, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2070 lang.IFn; if linked_2069 == nil { ifn_2070 = lang.IFn_Cast(root_2068) } else { ifn_2070 = nil }; var arg_2071 any = idx__4; var arg_2072 any = k__6; var arg_2073 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(acc__3)).Ref(); if linked_2069 == nil { tmp9 = ifn_2070.Invoke_O_O_O__O(arg_2071, arg_2072, arg_2073) } else { tmp9 = linked_2069.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2068, arg_2071, arg_2072, arg_2073) }; es__2, acc__3, idx__4 = tmp6, tmp8, tmp9; continue L1 } } } }; /*line :774:1*/panic("j2g: unreachable") }











func A_arbace_go_check_types_lookup_impl_A_New() *A_arbace_go_check_types_lookup_impl_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_impl_A{}; t.Ctor(); return t }
//line :786:1
func (t *A_arbace_go_check_types_lookup_impl_A) Ctor() {}
//line :786:1
func (t *A_arbace_go_check_types_lookup_impl_A) Invoke_O_O_O_O_O__O(self, T__0_, addressable__1, name__2, pkg__3 any) any { { var vec__219000269__5 any; var root_2074 any = A_arbace_go_check_types_A_const_226.GetRawRoot__O(); var linked_2075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2074, A_arbace_go_check_types_deref_type_A_fn_class); var ifn_2076 lang.IFn





	if linked_2075 == nil { ifn_2076 = lang.IFn_Cast(root_2074) } else { ifn_2076 = nil }; var arg_2077 any = T__0_; if linked_2075 == nil { vec__219000269__5 = ifn_2076.Invoke_O__O(arg_2077) } else { vec__219000269__5 = linked_2075.(*A_arbace_go_check_types_deref_type_A).Invoke_O_O__O(root_2074, arg_2077) }
//line :786:1
	var typ__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000269__5, lang.RT_IntCast_J__I_NoInit(0), nil); var is_ptr__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000269__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any
	var and__1927000168__auto____8 any = is_ptr__7





	if jrt.J2g_Truth(and__1927000168__auto____8) { var root_2078 any = A_arbace_go_check_types_A_const_227.GetRawRoot__O(); var linked_2079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2078, A_arbace_go_check_types_interface_QMARK__A_fn_class); var ifn_2080 lang.IFn; if linked_2079 == nil { ifn_2080 = lang.IFn_Cast(root_2078) } else { ifn_2080 = nil }; var arg_2081 any = typ__6; if linked_2079 == nil { tmp1 = ifn_2080.Invoke_O__O(arg_2081) } else { tmp1 = linked_2079.(*A_arbace_go_check_types_interface_QMARK__A).Invoke_O_O__O(root_2078, arg_2081) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return nil } else { var current__8 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_65, typ__6, A_arbace_go_check_types_A_const_235, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_types_A_const_236, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_types_A_const_237, is_ptr__7, A_arbace_go_check_types_A_const_225, jrt.Boolean_FALSE.Ref()))); var seen__9 any = lang.PersistentHashSet_EMPTY.Ref(); L1: for {



		var tmp2 any; var root_2082 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_2083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2082, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2084 lang.IFn; if linked_2083 == nil { ifn_2084 = lang.IFn_Cast(root_2082) } else { ifn_2084 = nil }; var arg_2085 any = current__8; if linked_2083 == nil { tmp2 = ifn_2084.Invoke_O__O(arg_2085) } else { tmp2 = linked_2083.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2082, arg_2085) }; if jrt.J2g_Truth(tmp2) { return nil } else { var vec__219000272__10 any; var root_2086 any = A_arbace_go_check_types_A_const_209.GetRawRoot__O(); var linked_2087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2086, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_2088 lang.IFn


			if linked_2087 == nil { ifn_2088 = lang.IFn_Cast(root_2086) } else { ifn_2088 = nil }; var arg_2089 any; var tmp3 any = A_arbace_go_check_types_lookup_impl_fn__219000276_A_New_O_O(pkg__3, name__2); var tmp4 *jrt.Class; var fncls__2195 *jrt.Class = A_arbace_go_check_types_lookup_impl_fn__219000276_A_fn_class
			if fncls__2195 == nil { var fncls__2195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_go_check_types_lookup_impl_fn__219000276_A_fn_class = fncls__2195d; tmp4 = fncls__2195d } else { tmp4 = fncls__2195 }; arg_2089 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)
//line :800:1
			var arg_2090 any = lang.Tuple_Create_O_O_O__IPersistentVector(nil, lang.PersistentVector_EMPTY.Ref(), seen__9); var arg_2091 any = current__8; if linked_2087 == nil { vec__219000272__10 = ifn_2088.Invoke_O_O_O__O(arg_2089, arg_2090, arg_2091) } else { vec__219000272__10 = linked_2087.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_2086, arg_2089, arg_2090, arg_2091) }
//line :797:1
			var found__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000272__10, lang.RT_IntCast_J__I_NoInit(0), nil); var next__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000272__10, lang.RT_IntCast_J__I_NoInit(1), nil); var seen__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000272__10, lang.RT_IntCast_J__I_NoInit(2), nil)















































			if jrt.J2g_Truth(A_arbace_go_check_types_A_const_242.Invoke_O__O(found__11)) { return found__11 } else { if jrt.J2g_Truth(found__11) {


				var tmp5 any; var tmp6 any = A_arbace_go_check_types_A_const_232; var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_go_check_types_A_const_231.Invoke_O__O(found__11)); if and__1927000168__auto____14 { var tmp7 *lang.Keyword = A_arbace_go_check_types_A_const_243; var and__1927000168__auto____15 any = tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_go_check_types_A_const_244.Get__O()).Invoke_O__O(A_arbace_go_check_types_A_const_60.Invoke_O__O(found__11))); if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any; var root_2196 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_2197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2196, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2198 lang.IFn
					if linked_2197 == nil { ifn_2198 = lang.IFn_Cast(root_2196) } else { ifn_2198 = nil }; var arg_2199 any = A_arbace_go_check_types_A_const_237.Invoke_O__O(found__11); if linked_2197 == nil { and__1927000168__auto____16 = ifn_2198.Invoke_O__O(arg_2199) } else { and__1927000168__auto____16 = linked_2197.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2196, arg_2199) }
//line :848:1
					if jrt.J2g_Truth(and__1927000168__auto____16) {
						var root_2200 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_2201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2200, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2202 lang.IFn; if linked_2201 == nil { ifn_2202 = lang.IFn_Cast(root_2200) } else { ifn_2202 = nil }; var arg_2203 any = addressable__1; if linked_2201 == nil { tmp5 = ifn_2202.Invoke_O__O(arg_2203) } else { tmp5 = linked_2201.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2200, arg_2203) } } else {
//line :848:1
							tmp5 = and__1927000168__auto____16 } } else { tmp5 = and__1927000168__auto____15 } } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }; if jrt.J2g_Truth(tmp5) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_243, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_types_A_const_245, found__11)) } else { return found__11 } } else {
//line :845:1
								if A_arbace_go_check_types_A_const_86 != nil {






									var tmp8 any; var root_2204 any = A_arbace_go_check_types_A_const_246.GetRawRoot__O(); var linked_2205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2204, A_arbace_go_check_types_consolidate_A_fn_class); var ifn_2206 lang.IFn; if linked_2205 == nil { ifn_2206 = lang.IFn_Cast(root_2204) } else { ifn_2206 = nil }; var arg_2207 any = next__12; if linked_2205 == nil { tmp8 = ifn_2206.Invoke_O__O(arg_2207) } else { tmp8 = linked_2205.(*A_arbace_go_check_types_consolidate_A).Invoke_O_O__O(root_2204, arg_2207) }; current__8, seen__9 = tmp8, seen__13; continue L1 } else {
//line :845:1
										return nil } } } } } } }; /*line :786:1*/panic("j2g: unreachable") }














func A_arbace_go_check_types_lookup_impl_fn__219000276_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_lookup_impl_fn__219000276_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_impl_fn__219000276_A{}; t.Ctor_O_O(p0, p1); return t }
//line :801:1
func (t *A_arbace_go_check_types_lookup_impl_fn__219000276_A) Ctor_O_O(c__pkg, c__name any) { t.F_pkg = c__pkg; t.F_name = c__name }
//line :801:1
func (t *A_arbace_go_check_types_lookup_impl_fn__219000276_A) Invoke_O_O_O__O(self, p__219000275__1, e__2 any) any { { var vec__219000277__3 any = p__219000275__1; var found__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000277__3, lang.RT_IntCast_J__I_NoInit(0), nil); var next__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000277__3, lang.RT_IntCast_J__I_NoInit(1), nil); var seen__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000277__3, lang.RT_IntCast_J__I_NoInit(2), nil); var typ__7 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(e__2); var tmp1 any; var and__1927000168__auto____8 any; var root_2092 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_2093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2092, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_2094 lang.IFn

	if linked_2093 == nil { ifn_2094 = lang.IFn_Cast(root_2092) } else { ifn_2094 = nil }; var arg_2095 any = typ__7; if linked_2093 == nil { and__1927000168__auto____8 = ifn_2094.Invoke_O__O(arg_2095) } else { and__1927000168__auto____8 = linked_2093.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_2092, arg_2095) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_2096 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_2097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2096, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2098 lang.IFn; if linked_2097 == nil { ifn_2098 = lang.IFn_Cast(root_2096) } else { ifn_2098 = nil }; var arg_2099 any = seen__6; var arg_2100 any = typ__7; if linked_2097 == nil { tmp1 = ifn_2098.Invoke_O_O__O(arg_2099, arg_2100) } else { tmp1 = linked_2097.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2096, arg_2099, arg_2100) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__6) } else { var seen__8 any; var tmp2 any; var root_2101 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_2102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2101, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_2103 lang.IFn

		if linked_2102 == nil { ifn_2103 = lang.IFn_Cast(root_2101) } else { ifn_2103 = nil }; var arg_2104 any = typ__7; if linked_2102 == nil { tmp2 = ifn_2103.Invoke_O__O(arg_2104) } else { tmp2 = linked_2102.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_2101, arg_2104) }; if jrt.J2g_Truth(tmp2) { var root_2105 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2106 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2105, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2107 lang.IFn; if linked_2106 == nil { ifn_2107 = lang.IFn_Cast(root_2105) } else { ifn_2107 = nil }; var arg_2108 any = seen__6; var arg_2109 any = typ__7; if linked_2106 == nil { seen__8 = ifn_2107.Invoke_O_O__O(arg_2108, arg_2109) } else { seen__8 = linked_2106.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2105, arg_2108, arg_2109) } } else { seen__8 = seen__6 }
//line :803:1
		var m__9 any; var tmp3 any; var root_2110 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_2111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2110, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_2112 lang.IFn


		if linked_2111 == nil { ifn_2112 = lang.IFn_Cast(root_2110) } else { ifn_2112 = nil }; var arg_2113 any = typ__7; if linked_2111 == nil { tmp3 = ifn_2112.Invoke_O__O(arg_2113) } else { tmp3 = linked_2111.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_2110, arg_2113) }; if jrt.J2g_Truth(tmp3) { var root_2114 any = A_arbace_go_check_types_A_const_228.GetRawRoot__O(); var linked_2115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2114, A_arbace_go_check_types_named_method_A_fn_class); var ifn_2116 lang.IFn; if linked_2115 == nil { ifn_2116 = lang.IFn_Cast(root_2114) } else { ifn_2116 = nil }; var arg_2117 any = typ__7; var arg_2118 any = t.F_name; var arg_2119 any = t.F_pkg; if linked_2115 == nil { m__9 = ifn_2116.Invoke_O_O_O__O(arg_2117, arg_2118, arg_2119) } else { m__9 = linked_2115.(*A_arbace_go_check_types_named_method_A).Invoke_O_O_O_O__O(root_2114, arg_2117, arg_2118, arg_2119) } } else { m__9 = nil }
		if jrt.J2g_Truth(m__9) {
			var tmp4 any; var or__1927000174__auto____10 any = found__4; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp4 = or__1927000174__auto____10 } else { tmp4 = A_arbace_go_check_types_A_const_225.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp4) { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_230, next__5, seen__8) } else { var tmp5 any = A_arbace_go_check_types_A_const_231; var tmp6 any = A_arbace_go_check_types_A_const_232; var tmp7 any = A_arbace_go_check_types_A_const_60; var tmp8 any; var root_2149 any = A_arbace_go_check_types_A_const_233.GetRawRoot__O(); var linked_2150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2149, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2151 lang.IFn

				if linked_2150 == nil { ifn_2151 = lang.IFn_Cast(root_2149) } else { ifn_2151 = nil }; var arg_2152 any = m__9; if linked_2150 == nil { tmp8 = ifn_2151.Invoke_O__O(arg_2152) } else { tmp8 = linked_2150.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2149, arg_2152) }
//line :808:1
				var tmp9 any = tmp8; var tmp10 any = A_arbace_go_check_types_A_const_234; var tmp11 any = A_arbace_go_check_types_A_const_235; var tmp12 any; var root_2153 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2154 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2153, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2155 lang.IFn

				if linked_2154 == nil { ifn_2155 = lang.IFn_Cast(root_2153) } else { ifn_2155 = nil }; var arg_2156 any = A_arbace_go_check_types_A_const_235.Invoke_O__O(e__2); var arg_2157 any; var root_2158 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_2159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2158, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2160 lang.IFn; if linked_2159 == nil { ifn_2160 = lang.IFn_Cast(root_2158) } else { ifn_2160 = nil }; var arg_2161 any = m__9; if linked_2159 == nil { arg_2157 = ifn_2160.Invoke_O__O(arg_2161) } else { arg_2157 = linked_2159.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2158, arg_2161) }; if linked_2154 == nil { tmp12 = ifn_2155.Invoke_O_O__O(arg_2156, arg_2157) } else { tmp12 = linked_2154.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2153, arg_2156, arg_2157) }
//line :808:1
				var tmp13 any = tmp12; var tmp14 any = A_arbace_go_check_types_A_const_236; var tmp15 any = A_arbace_go_check_types_A_const_236.Invoke_O__O(e__2); var tmp16 any = A_arbace_go_check_types_A_const_237; return lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, tmp9, tmp10, typ__7, tmp11, tmp13, tmp14, tmp15, tmp16, A_arbace_go_check_types_A_const_237.Invoke_O__O(e__2))), next__5, seen__8) } } else {
//line :807:1
					var u__10 any; var root_2120 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_2121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2120, A_arbace_go_check_types_under_A_fn_class); var ifn_2122 lang.IFn




					if linked_2121 == nil { ifn_2122 = lang.IFn_Cast(root_2120) } else { ifn_2122 = nil }; var arg_2123 any = typ__7; if linked_2121 == nil { u__10 = ifn_2122.Invoke_O__O(arg_2123) } else { u__10 = linked_2121.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2120, arg_2123) }
					var tmp17 any; var and__1927000168__auto____11 any; var root_2124 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_2125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2124, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2126 lang.IFn
					if linked_2125 == nil { ifn_2126 = lang.IFn_Cast(root_2124) } else { ifn_2126 = nil }; var arg_2127 any = u__10; if linked_2125 == nil { and__1927000168__auto____11 = ifn_2126.Invoke_O__O(arg_2127) } else { and__1927000168__auto____11 = linked_2125.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2124, arg_2127) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var tmp18 any = A_arbace_go_check_types_A_const_82; tmp17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp18, lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp17 = and__1927000168__auto____11 }
//line :813:1
					if jrt.J2g_Truth(tmp17) { var fs__11 any = lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(1)); var i__12 int64 = 0; var found__13 any = found__4; var next__14 any = next__5; L1: for {



						if lang.Numbers_Gte_J_J__Z_NoInit(i__12, int64(lang.RT_Count_O__I_NoInit(fs__11))) { return lang.Tuple_Create_O_O_O__IPersistentVector(found__13, next__14, seen__8) } else { var f__15 any = lang.RT_Nth_O_I__O_NoInit(fs__11, lang.RT_IntCast_J__I_NoInit(i__12)); var tmp19 any; var root_2128 any = A_arbace_go_check_types_A_const_223.GetRawRoot__O(); var linked_2129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2128, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_2130 lang.IFn



							if linked_2129 == nil { ifn_2130 = lang.IFn_Cast(root_2128) } else { ifn_2130 = nil }; var arg_2131 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(f__15); var arg_2132 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(f__15); var arg_2133 any = t.F_name; var arg_2134 any = t.F_pkg; if linked_2129 == nil { tmp19 = ifn_2130.Invoke_O_O_O_O__O(arg_2131, arg_2132, arg_2133, arg_2134) } else { tmp19 = linked_2129.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_2128, arg_2131, arg_2132, arg_2133, arg_2134) }
//line :820:1
							if jrt.J2g_Truth(tmp19) {

								var tmp20 any; var or__1927000174__auto____16 any = found__13; if jrt.J2g_Truth(or__1927000174__auto____16) { tmp20 = or__1927000174__auto____16 } else { tmp20 = A_arbace_go_check_types_A_const_225.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp20) {
									i__12, found__13, next__14 = lang.Numbers_Inc_J__J_NoInit(i__12), A_arbace_go_check_types_A_const_238, next__14; continue L1 } else {
										var tmp21 int64 = lang.Numbers_Inc_J__J_NoInit(i__12); var tmp22 any = A_arbace_go_check_types_A_const_231; var tmp23 any = A_arbace_go_check_types_A_const_239; var tmp24 any = A_arbace_go_check_types_A_const_60; var tmp25 any = A_arbace_go_check_types_A_const_235; var tmp26 any; var root_2162 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2163 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2162, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2164 lang.IFn; if linked_2163 == nil { ifn_2164 = lang.IFn_Cast(root_2162) } else { ifn_2164 = nil }; var arg_2165 any = A_arbace_go_check_types_A_const_235.Invoke_O__O(e__2); var arg_2166 any = jrt.Long_ValueOf_J__Long_NoInit(i__12).Ref(); if linked_2163 == nil { tmp26 = ifn_2164.Invoke_O_O__O(arg_2165, arg_2166) } else { tmp26 = linked_2163.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2162, arg_2165, arg_2166) }; var tmp27 any = tmp26; var tmp28 any = A_arbace_go_check_types_A_const_236; var tmp29 any = A_arbace_go_check_types_A_const_236.Invoke_O__O(e__2); var tmp30 any = A_arbace_go_check_types_A_const_237; i__12, found__13, next__14 = tmp21, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp23, tmp24, f__15, tmp25, tmp27, tmp28, tmp29, tmp30, A_arbace_go_check_types_A_const_237.Invoke_O__O(e__2))), next__14; continue L1 } } else {
//line :820:1
											var tmp31 any; var and__1927000168__auto____16 bool = lang.Util_Identical_O_O__Z_NoInit(found__13, nil)






											if and__1927000168__auto____16 { tmp31 = A_arbace_go_check_types_A_const_192.Invoke_O__O(f__15) } else { tmp31 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____16).Ref() }
//line :820:1
											if jrt.J2g_Truth(tmp31) { var vec__219000280__16 any; var root_2135 any = A_arbace_go_check_types_A_const_226.GetRawRoot__O(); var linked_2136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2135, A_arbace_go_check_types_deref_type_A_fn_class); var ifn_2137 lang.IFn







												if linked_2136 == nil { ifn_2137 = lang.IFn_Cast(root_2135) } else { ifn_2137 = nil }; var arg_2138 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(f__15); if linked_2136 == nil { vec__219000280__16 = ifn_2137.Invoke_O__O(arg_2138) } else { vec__219000280__16 = linked_2136.(*A_arbace_go_check_types_deref_type_A).Invoke_O_O__O(root_2135, arg_2138) }
//line :820:1
												var ft__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000280__16, lang.RT_IntCast_J__I_NoInit(0), nil); var fp__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000280__16, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp32 int64 = lang.Numbers_Inc_J__J_NoInit(i__12); var tmp33 any; var root_2167 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2168 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2167, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2169 lang.IFn









												if linked_2168 == nil { ifn_2169 = lang.IFn_Cast(root_2167) } else { ifn_2169 = nil }; var arg_2170 any = next__14; var arg_2171 any; var tmp34 any = A_arbace_go_check_types_A_const_65; var tmp35 any = A_arbace_go_check_types_A_const_235; var tmp36 any; var root_2172 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2173 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2172, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2174 lang.IFn; if linked_2173 == nil { ifn_2174 = lang.IFn_Cast(root_2172) } else { ifn_2174 = nil }; var arg_2175 any = A_arbace_go_check_types_A_const_235.Invoke_O__O(e__2); var arg_2176 any = jrt.Long_ValueOf_J__Long_NoInit(i__12).Ref(); if linked_2173 == nil { tmp36 = ifn_2174.Invoke_O_O__O(arg_2175, arg_2176) } else { tmp36 = linked_2173.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2172, arg_2175, arg_2176) }; var tmp37 any = tmp36; var tmp38 any = A_arbace_go_check_types_A_const_236; var tmp39 any; var root_2177 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2178 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2177, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2179 lang.IFn
												if linked_2178 == nil { ifn_2179 = lang.IFn_Cast(root_2177) } else { ifn_2179 = nil }; var arg_2180 any = A_arbace_go_check_types_A_const_236.Invoke_O__O(e__2); var arg_2181 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(f__15); if linked_2178 == nil { tmp39 = ifn_2179.Invoke_O_O__O(arg_2180, arg_2181) } else { tmp39 = linked_2178.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2177, arg_2180, arg_2181) }
//line :830:1
												var tmp40 any = tmp39; var tmp41 any = A_arbace_go_check_types_A_const_237; var tmp42 any; var or__1927000174__auto____19 any = A_arbace_go_check_types_A_const_237.Invoke_O__O(e__2)

												if jrt.J2g_Truth(or__1927000174__auto____19) { tmp42 = or__1927000174__auto____19 } else { tmp42 = fp__18 }
//line :830:1
												var tmp43 any = tmp42; var tmp44 any = A_arbace_go_check_types_A_const_225; arg_2171 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp34, ft__17, tmp35, tmp37, tmp38, tmp40, tmp41, tmp43, tmp44, A_arbace_go_check_types_A_const_225.Invoke_O__O(e__2))); if linked_2168 == nil { tmp33 = ifn_2169.Invoke_O_O__O(arg_2170, arg_2171) } else { tmp33 = linked_2168.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2167, arg_2170, arg_2171) }
//line :829:1
												i__12, found__13, next__14 = tmp32, found__13, tmp33; continue L1 } else {
//line :820:1
													if A_arbace_go_check_types_A_const_86 != nil {













														i__12, found__13, next__14 = lang.Numbers_Inc_J__J_NoInit(i__12), found__13, next__14; continue L1 } else {
//line :820:1
															return nil } } } } } } else {
//line :813:1
																var tmp45 any; var and__1927000168__auto____11_2 any; var root_2139 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_2140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2139, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2141 lang.IFn





















																if linked_2140 == nil { ifn_2141 = lang.IFn_Cast(root_2139) } else { ifn_2141 = nil }; var arg_2142 any = u__10; if linked_2140 == nil { and__1927000168__auto____11_2 = ifn_2141.Invoke_O__O(arg_2142) } else { and__1927000168__auto____11_2 = linked_2140.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2139, arg_2142) }; if jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp46 any = A_arbace_go_check_types_A_const_71; tmp45 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp46, lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp45 = and__1927000168__auto____11_2 }
//line :813:1
																if jrt.J2g_Truth(tmp45) { var temp__1927000408__auto____11 any; var root_2143 any = A_arbace_go_check_types_A_const_229.GetRawRoot__O(); var linked_2144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2143, A_arbace_go_check_types_iface_method_A_fn_class); var ifn_2145 lang.IFn






















																	if linked_2144 == nil { ifn_2145 = lang.IFn_Cast(root_2143) } else { ifn_2145 = nil }; var arg_2146 any = u__10; var arg_2147 any = t.F_name; var arg_2148 any = t.F_pkg; if linked_2144 == nil { temp__1927000408__auto____11 = ifn_2145.Invoke_O_O_O__O(arg_2146, arg_2147, arg_2148) } else { temp__1927000408__auto____11 = linked_2144.(*A_arbace_go_check_types_iface_method_A).Invoke_O_O_O_O__O(root_2143, arg_2146, arg_2147, arg_2148) }; if jrt.J2g_Truth(temp__1927000408__auto____11) { var m__12 any = temp__1927000408__auto____11; var tmp47 any; var or__1927000174__auto____13 any = found__4
																		if jrt.J2g_Truth(or__1927000174__auto____13) { tmp47 = or__1927000174__auto____13 } else { tmp47 = A_arbace_go_check_types_A_const_225.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp47) { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_240, next__5, seen__8) } else { var tmp48 any = A_arbace_go_check_types_A_const_231; var tmp49 any = A_arbace_go_check_types_A_const_241; var tmp50 any = A_arbace_go_check_types_A_const_60; var tmp51 any; var root_2182 any = A_arbace_go_check_types_A_const_233.GetRawRoot__O(); var linked_2183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2182, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2184 lang.IFn

																			if linked_2183 == nil { ifn_2184 = lang.IFn_Cast(root_2182) } else { ifn_2184 = nil }; var arg_2185 any = m__12; if linked_2183 == nil { tmp51 = ifn_2184.Invoke_O__O(arg_2185) } else { tmp51 = linked_2183.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2182, arg_2185) }
//line :837:1
																			var tmp52 any = tmp51; var tmp53 any = A_arbace_go_check_types_A_const_169; var tmp54 any = A_arbace_go_check_types_A_const_235; var tmp55 any; var root_2186 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2187 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2186, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2188 lang.IFn

																			if linked_2187 == nil { ifn_2188 = lang.IFn_Cast(root_2186) } else { ifn_2188 = nil }; var arg_2189 any = A_arbace_go_check_types_A_const_235.Invoke_O__O(e__2); var arg_2190 any; var root_2191 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_2192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2191, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2193 lang.IFn; if linked_2192 == nil { ifn_2193 = lang.IFn_Cast(root_2191) } else { ifn_2193 = nil }; var arg_2194 any = m__12; if linked_2192 == nil { arg_2190 = ifn_2193.Invoke_O__O(arg_2194) } else { arg_2190 = linked_2192.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2191, arg_2194) }; if linked_2187 == nil { tmp55 = ifn_2188.Invoke_O_O__O(arg_2189, arg_2190) } else { tmp55 = linked_2187.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2186, arg_2189, arg_2190) }
//line :837:1
																			var tmp56 any = tmp55; var tmp57 any = A_arbace_go_check_types_A_const_236; var tmp58 any = A_arbace_go_check_types_A_const_236.Invoke_O__O(e__2); var tmp59 any = A_arbace_go_check_types_A_const_237; return lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp48, tmp49, tmp50, tmp52, tmp53, typ__7, tmp54, tmp56, tmp57, tmp58, tmp59, A_arbace_go_check_types_A_const_237.Invoke_O__O(e__2))), next__5, seen__8) } } else {
//line :836:1
																				return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__8) } } else {
//line :813:1
																					if A_arbace_go_check_types_A_const_86 != nil { return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__8) } else { return nil } } } } } }; /*line :801:1*/panic("j2g: unreachable") }




















































func A_arbace_go_check_types_lookup_A_New() *A_arbace_go_check_types_lookup_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_A{}; t.Ctor(); return t }
//line :854:1
func (t *A_arbace_go_check_types_lookup_A) Ctor() {}
//line :854:1
func (t *A_arbace_go_check_types_lookup_A) Invoke_O_O_O_O_O__O(self, T__0_, addressable__1, name__2, pkg__3 any) any {


	var tmp1 any; var and__1927000168__auto____5 any; var root_2208 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_2209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2208, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_2210 lang.IFn; if linked_2209 == nil { ifn_2210 = lang.IFn_Cast(root_2208) } else { ifn_2210 = nil }; var arg_2211 any = T__0_; if linked_2209 == nil { and__1927000168__auto____5 = ifn_2210.Invoke_O__O(arg_2211) } else { and__1927000168__auto____5 = linked_2209.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_2208, arg_2211) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_2212 any = A_arbace_go_check_types_A_const_247.GetRawRoot__O(); var linked_2213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2212, A_arbace_go_check_types_pointer_QMARK__A_fn_class); var ifn_2214 lang.IFn; if linked_2213 == nil { ifn_2214 = lang.IFn_Cast(root_2212) } else { ifn_2214 = nil }; var arg_2215 any = T__0_; if linked_2213 == nil { tmp1 = ifn_2214.Invoke_O__O(arg_2215) } else { tmp1 = linked_2213.(*A_arbace_go_check_types_pointer_QMARK__A).Invoke_O_O__O(root_2212, arg_2215) } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var r__5 any; var root_2216 any = A_arbace_go_check_types_A_const_248.GetRawRoot__O(); var linked_2217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2216, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_2218 lang.IFn
		if linked_2217 == nil { ifn_2218 = lang.IFn_Cast(root_2216) } else { ifn_2218 = nil }; var arg_2219 any; var root_2223 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_2224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2223, A_arbace_go_check_types_under_A_fn_class); var ifn_2225 lang.IFn; if linked_2224 == nil { ifn_2225 = lang.IFn_Cast(root_2223) } else { ifn_2225 = nil }; var arg_2226 any = T__0_; if linked_2224 == nil { arg_2219 = ifn_2225.Invoke_O__O(arg_2226) } else { arg_2219 = linked_2224.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2223, arg_2226) }; var arg_2220 any = jrt.Boolean_FALSE.Ref(); var arg_2221 any = name__2; var arg_2222 any = pkg__3; if linked_2217 == nil { r__5 = ifn_2218.Invoke_O_O_O_O__O(arg_2219, arg_2220, arg_2221, arg_2222) } else { r__5 = linked_2217.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_2216, arg_2219, arg_2220, arg_2221, arg_2222) }
		var tmp2 any = A_arbace_go_check_types_A_const_232; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_go_check_types_A_const_231.Invoke_O__O(r__5)) { return nil } else { return r__5 } } else {
			var root_2227 any = A_arbace_go_check_types_A_const_248.GetRawRoot__O(); var linked_2228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2227, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_2229 lang.IFn; if linked_2228 == nil { ifn_2229 = lang.IFn_Cast(root_2227) } else { ifn_2229 = nil }; var arg_2230 any = T__0_; var arg_2231 any = addressable__1; var arg_2232 any = name__2; var arg_2233 any = pkg__3; if linked_2228 == nil { return ifn_2229.Invoke_O_O_O_O__O(arg_2230, arg_2231, arg_2232, arg_2233) } else { return linked_2228.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_2227, arg_2230, arg_2231, arg_2232, arg_2233)
			}
		}
}
func A_arbace_go_check_types_sort_methods_A_New() *A_arbace_go_check_types_sort_methods_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sort_methods_A{}; t.Ctor(); return t }
//line :864:1
func (t *A_arbace_go_check_types_sort_methods_A) Ctor() {}
//line :864:1
func (t *A_arbace_go_check_types_sort_methods_A) Invoke_O_O__O(self, ms__0 any) any {


	var root_2234 any = A_arbace_go_check_types_A_const_147.GetRawRoot__O(); var linked_2235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2234, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2236 lang.IFn; if linked_2235 == nil { ifn_2236 = lang.IFn_Cast(root_2234) } else { ifn_2236 = nil }; var arg_2237 any; var root_2238 any = A_arbace_go_check_types_A_const_188.GetRawRoot__O(); var linked_2239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2238, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2240 lang.IFn; if linked_2239 == nil { ifn_2240 = lang.IFn_Cast(root_2238) } else { ifn_2240 = nil }; var arg_2241 any; var tmp1 any = A_arbace_go_check_types_sort_methods_fn__219000286_A_New(); var tmp2 *jrt.Class; var fncls__2243 *jrt.Class = A_arbace_go_check_types_sort_methods_fn__219000286_A_fn_class; if fncls__2243 == nil { var fncls__2243d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_go_check_types_sort_methods_fn__219000286_A_fn_class = fncls__2243d; tmp2 = fncls__2243d } else { tmp2 = fncls__2243 }; arg_2241 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2242 any = ms__0; if linked_2239 == nil { arg_2237 = ifn_2240.Invoke_O_O__O(arg_2241, arg_2242) } else { arg_2237 = linked_2239.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2238, arg_2241, arg_2242) }; if linked_2235 == nil { return ifn_2236.Invoke_O__O(arg_2237) } else { return linked_2235.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2234, arg_2237) } }
//line :867:1
func A_arbace_go_check_types_sort_methods_fn__219000286_A_New() *A_arbace_go_check_types_sort_methods_fn__219000286_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sort_methods_fn__219000286_A{}; t.Ctor(); return t }
//line :867:1
func (t *A_arbace_go_check_types_sort_methods_fn__219000286_A) Ctor() {}
//line :867:1
func (t *A_arbace_go_check_types_sort_methods_fn__219000286_A) Invoke_O_O__O(self, m__1 any) any { var tmp1 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var tmp2 any; var or__1927000174__auto____2 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(m__1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = Lit_10 }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }

func A_arbace_go_check_types_method_data_A_New() *A_arbace_go_check_types_method_data_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_method_data_A{}; t.Ctor(); return t }
//line :869:1
func (t *A_arbace_go_check_types_method_data_A) Ctor() {}
//line :869:1
func (t *A_arbace_go_check_types_method_data_A) Invoke_O_O__O(self, m__0 any) any {


	var tmp1 any; var root_2244 any = A_arbace_go_check_types_A_const_166.GetRawRoot__O(); var linked_2245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2244, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_2246 lang.IFn; if linked_2245 == nil { ifn_2246 = lang.IFn_Cast(root_2244) } else { ifn_2246 = nil }; var arg_2247 any = m__0; if linked_2245 == nil { tmp1 = ifn_2246.Invoke_O__O(arg_2247) } else { tmp1 = linked_2245.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_2244, arg_2247) }; if jrt.J2g_Truth(tmp1) { return m__0 } else { return lang.IFn_Cast(A_arbace_go_check_types_A_const_244.Get__O()).Invoke_O__O(m__0)
	} }
func A_arbace_go_check_types_missing_method_A_New() *A_arbace_go_check_types_missing_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_A{}; t.Ctor(); return t }
//line :874:1
func (t *A_arbace_go_check_types_missing_method_A) Ctor() {}
//line :874:1
func (t *A_arbace_go_check_types_missing_method_A) Invoke_O_O_O_O_O__O(self, V__0_, T__1_, static__2, same_QMARK___3 any) any { var tu__5 any; var root_2248 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_2249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2248, A_arbace_go_check_types_under_A_fn_class); var ifn_2250 lang.IFn; if





	linked_2249 == nil { ifn_2250 = lang.IFn_Cast(root_2248) } else { ifn_2250 = nil }; var arg_2251 any = T__1_; if linked_2249 == nil { tu__5 = ifn_2250.Invoke_O__O(arg_2251) } else { tu__5 = linked_2249.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2248, arg_2251) }; var vu__6 any; var root_2252 any = /*line :874:1*/A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_2253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2252, A_arbace_go_check_types_under_A_fn_class); var ifn_2254 lang.IFn; if






	linked_2253 == nil { ifn_2254 = lang.IFn_Cast(root_2252) } else { ifn_2254 = nil }; var arg_2255 any = V__0_; if linked_2253 == nil { vu__6 = ifn_2254.Invoke_O__O(arg_2255) } else { vu__6 = linked_2253.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2252, arg_2255) }; var tmp1 any; var tmp2 /*line :884:1*/*lang.Keyword = A_arbace_go_check_types_A_const_249; var or__1927000174__auto____7 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tu__5)); if jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { var tmp3 *lang.Keyword = A_arbace_go_check_types_A_const_249; tmp1 = tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(vu__6)) }; if jrt.J2g_Truth(tmp1) { return nil } else {
		var root_2256 any = A_arbace_go_check_types_A_const_142.GetRawRoot__O(); var linked_2257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2256, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2258 lang.IFn; if linked_2257 == nil { ifn_2258 = lang.IFn_Cast(root_2256) } else { ifn_2258 = nil }; var arg_2259 any; var tmp4 any = A_arbace_go_check_types_missing_method_fn__219000290_A_New_O_O_O_O(static__2, V__0_, same_QMARK___3, vu__6); var tmp5 *jrt.Class; var fncls__2330 *jrt.Class = A_arbace_go_check_types_missing_method_fn__219000290_A_fn_class
		if fncls__2330 == nil { var fncls__2330d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_go_check_types_missing_method_fn__219000290_A_fn_class = fncls__2330d; tmp5 = fncls__2330d } else { tmp5 = fncls__2330 }; arg_2259 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)
//line :885:1
		var arg_2260 any = lang.RT_Nth_O_I__O_NoInit(tu__5, lang.RT_IntCast_J__I_NoInit(1)); if linked_2257 == nil { return ifn_2258.Invoke_O_O__O(arg_2259, arg_2260) } else { return linked_2257.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2256, arg_2259, arg_2260) } } }
//line :874:1
func (t *A_arbace_go_check_types_missing_method_A) Invoke_O_O_O_O__O(self, V__0_, T__1_, static__2 any) any {



	var root_2331 any = A_arbace_go_check_types_A_const_262.GetRawRoot__O(); var linked_2332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2331, A_arbace_go_check_types_missing_method_A_fn_class); var ifn_2333 lang.IFn; if linked_2332 == nil { ifn_2333 = lang.IFn_Cast(root_2331) } else { ifn_2333 = nil }; var arg_2334 any = V__0_; var arg_2335 any = T__1_; var arg_2336 any = static__2; var arg_2337 any = A_arbace_go_check_types_A_const_144.GetRawRoot__O(); if linked_2332 == nil { return ifn_2333.Invoke_O_O_O_O__O(arg_2334, arg_2335, arg_2336, arg_2337) } else { return linked_2332.(*A_arbace_go_check_types_missing_method_A).Invoke_O_O_O_O_O__O(root_2331, arg_2334, arg_2335, arg_2336, arg_2337)
	}
}





func A_arbace_go_check_types_missing_method_fn__219000290_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_types_missing_method_fn__219000290_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_fn__219000290_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :886:1
func (t *A_arbace_go_check_types_missing_method_fn__219000290_A) Ctor_O_O_O_O(c__static, c__V, c__same_QMARK_, c__vu any) { t.F_static = c__static; t.F_V = c__V; t.F_same_QMARK_ = c__same_QMARK_; t.F_vu = c__vu }
//line :886:1
func (t *A_arbace_go_check_types_missing_method_fn__219000290_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_2261 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_2262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2261, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2263 lang.IFn; if linked_2262 == nil { ifn_2263 = lang.IFn_Cast(root_2261) } else { ifn_2263 = nil }; var arg_2264 any = t.F_vu; if linked_2262 == nil { and__1927000168__auto____2 = ifn_2263.Invoke_O__O(arg_2264) } else { and__1927000168__auto____2 = linked_2262.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2261, arg_2264) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_types_A_const_71; var tmp3 any = t.F_vu; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var f__2 any; var root_2265 any = A_arbace_go_check_types_A_const_229.GetRawRoot__O(); var linked_2266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2265, A_arbace_go_check_types_iface_method_A_fn_class); var ifn_2267 lang.IFn
		if linked_2266 == nil { ifn_2267 = lang.IFn_Cast(root_2265) } else { ifn_2267 = nil }; var arg_2268 any = t.F_vu; var arg_2269 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var arg_2270 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(m__1); if linked_2266 == nil { f__2 = ifn_2267.Invoke_O_O_O__O(arg_2268, arg_2269, arg_2270) } else { f__2 = linked_2266.(*A_arbace_go_check_types_iface_method_A).Invoke_O_O_O_O__O(root_2265, arg_2268, arg_2269, arg_2270) }
		if lang.Util_Identical_O_O__Z_NoInit(f__2, nil) {
			if jrt.J2g_Truth(t.F_static) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_232, m__1, A_arbace_go_check_types_A_const_250, A_arbace_go_check_types_A_const_251)) } else { return nil } } else {
//line :889:1
				var tmp4 any; var root_2271 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_2272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2271, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2273 lang.IFn

				if linked_2272 == nil { ifn_2273 = lang.IFn_Cast(root_2271) } else { ifn_2273 = nil }; var arg_2274 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_same_QMARK_); var tmp6 *lang.Keyword = A_arbace_go_check_types_A_const_65; var tmp7 any; var root_2275 any = A_arbace_go_check_types_A_const_233.GetRawRoot__O(); var linked_2276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2275, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2277 lang.IFn; if linked_2276 == nil { ifn_2277 = lang.IFn_Cast(root_2275) } else { ifn_2277 = nil }; var arg_2278 any = f__2; if linked_2276 == nil { tmp7 = ifn_2277.Invoke_O__O(arg_2278) } else { tmp7 = linked_2276.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2275, arg_2278) }; arg_2274 = tmp5.Invoke_O_O__O(tmp6.Invoke_O__O(tmp7), A_arbace_go_check_types_A_const_65.Invoke_O__O(m__1)); if linked_2272 == nil { tmp4 = ifn_2273.Invoke_O__O(arg_2274) } else { tmp4 = linked_2272.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2271, arg_2274) }
//line :889:1
				if jrt.J2g_Truth(tmp4) { var tmp8 any = A_arbace_go_check_types_A_const_232; var tmp9 any = A_arbace_go_check_types_A_const_250; var tmp10 any = A_arbace_go_check_types_A_const_252; var tmp11 any = A_arbace_go_check_types_A_const_253; var tmp12 any; var root_2279 any = A_arbace_go_check_types_A_const_233.GetRawRoot__O(); var linked_2280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2279, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2281 lang.IFn

					if linked_2280 == nil { ifn_2281 = lang.IFn_Cast(root_2279) } else { ifn_2281 = nil }; var arg_2282 any = f__2; if linked_2280 == nil { tmp12 = ifn_2281.Invoke_O__O(arg_2282) } else { tmp12 = linked_2280.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2279, arg_2282) }
//line :889:1
					return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, m__1, tmp9, tmp10, tmp11, tmp12)) } else { return nil } } } else {
//line :887:1
						var r__2 any; var root_2283 any = A_arbace_go_check_types_A_const_248.GetRawRoot__O(); var linked_2284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2283, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_2285 lang.IFn




						if linked_2284 == nil { ifn_2285 = lang.IFn_Cast(root_2283) } else { ifn_2285 = nil }; var arg_2286 any = t.F_V; var arg_2287 any = jrt.Boolean_FALSE.Ref(); var arg_2288 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var arg_2289 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(m__1); if linked_2284 == nil { r__2 = ifn_2285.Invoke_O_O_O_O__O(arg_2286, arg_2287, arg_2288, arg_2289) } else { r__2 = linked_2284.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_2283, arg_2286, arg_2287, arg_2288, arg_2289) }
						if jrt.J2g_Truth(A_arbace_go_check_types_A_const_243.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_232, m__1, A_arbace_go_check_types_A_const_250, A_arbace_go_check_types_A_const_243)) } else { if lang.Util_Identical_O_O__Z_NoInit(r__2, nil) { var fr__3 any; var root_2321 any = A_arbace_go_check_types_A_const_260.GetRawRoot__O(); var linked_2322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2321, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2323 lang.IFn



							if linked_2322 == nil { ifn_2323 = lang.IFn_Cast(root_2321) } else { ifn_2323 = nil }; var arg_2324 any = lang.IFn_Cast(A_arbace_go_check_types_A_const_261.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_219, jrt.Boolean_TRUE.Ref()); if linked_2322 == nil { ifn_2323.Invoke_O__O(arg_2324) } else { linked_2322.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2321, arg_2324) }; var tmp13 any = A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A_New_O_O(m__1, t.F_V); var tmp14 *jrt.Class; var fncls__2300 *jrt.Class = A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A_fn_class; if fncls__2300 == nil { var fncls__2300d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A_fn_class = fncls__2300d; tmp14 = fncls__2300d } else { tmp14 = fncls__2300 }; fr__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil).Invoke__O()
							var tmp15 any; var tmp16 any = A_arbace_go_check_types_A_const_232; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp16, A_arbace_go_check_types_A_const_231.Invoke_O__O(fr__3)); if and__1927000168__auto____4 { var root_2301 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_2302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2301, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2303 lang.IFn; if linked_2302 == nil { ifn_2303 = lang.IFn_Cast(root_2301) } else { ifn_2303 = nil }; var arg_2304 any = A_arbace_go_check_types_A_const_242.Invoke_O__O(fr__3); if linked_2302 == nil { tmp15 = ifn_2303.Invoke_O__O(arg_2304) } else { tmp15 = linked_2302.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2301, arg_2304) } } else { tmp15 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if jrt.J2g_Truth(tmp15) { var d__4 any; var root_2305 any = A_arbace_go_check_types_A_const_255.GetRawRoot__O(); var linked_2306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2305, A_arbace_go_check_types_method_data_A_fn_class); var ifn_2307 lang.IFn
								if linked_2306 == nil { ifn_2307 = lang.IFn_Cast(root_2305) } else { ifn_2307 = nil }; var arg_2308 any = A_arbace_go_check_types_A_const_60.Invoke_O__O(fr__3); if linked_2306 == nil { d__4 = ifn_2307.Invoke_O__O(arg_2308) } else { d__4 = linked_2306.(*A_arbace_go_check_types_method_data_A).Invoke_O_O__O(root_2305, arg_2308) }
//line :898:1
								var tmp17 any = A_arbace_go_check_types_A_const_232; var tmp18 any = A_arbace_go_check_types_A_const_250; var tmp19 *lang.Keyword

								if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_12.Invoke_O__O(d__4), A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1)) { tmp19 = A_arbace_go_check_types_A_const_256 } else { tmp19 = A_arbace_go_check_types_A_const_257 }
//line :898:1
								return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, m__1, tmp18, tmp19.Ref(), A_arbace_go_check_types_A_const_253, d__4)) } else { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_232, m__1, A_arbace_go_check_types_A_const_250, A_arbace_go_check_types_A_const_251)) } } else {
//line :893:1
									if jrt.J2g_Truth(A_arbace_go_check_types_A_const_242.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_232, m__1, A_arbace_go_check_types_A_const_250, A_arbace_go_check_types_A_const_251)) } else { var tmp20 any = A_arbace_go_check_types_A_const_239; if lang.Util_Equiv_O_O__Z_NoInit(tmp20, A_arbace_go_check_types_A_const_231.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_232, m__1, A_arbace_go_check_types_A_const_250, A_arbace_go_check_types_A_const_239)) } else { if A_arbace_go_check_types_A_const_86 != nil { var d__3 any; var root_2309 any = A_arbace_go_check_types_A_const_255.GetRawRoot__O(); var linked_2310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2309, A_arbace_go_check_types_method_data_A_fn_class); var ifn_2311 lang.IFn











										if linked_2310 == nil { ifn_2311 = lang.IFn_Cast(root_2309) } else { ifn_2311 = nil }; var arg_2312 any = A_arbace_go_check_types_A_const_60.Invoke_O__O(r__2); if linked_2310 == nil { d__3 = ifn_2311.Invoke_O__O(arg_2312) } else { d__3 = linked_2310.(*A_arbace_go_check_types_method_data_A).Invoke_O_O__O(root_2309, arg_2312) }
//line :893:1
										var d__4_2 any; var tmp21 any; var and__1927000168__auto____4_2 any = A_arbace_go_check_types_A_const_258.Get__O()












										if jrt.J2g_Truth(and__1927000168__auto____4_2) { var tmp22 any = A_arbace_go_check_types_A_const_232; tmp21 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp22, A_arbace_go_check_types_A_const_231.Invoke_O__O(r__2))).Ref() } else { tmp21 = and__1927000168__auto____4_2 }; if jrt.J2g_Truth(tmp21) { d__4_2 = lang.IFn_Cast(A_arbace_go_check_types_A_const_258.Get__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_234.Invoke_O__O(r__2), d__3) } else { d__4_2 = d__3
										}
										var tmp23 any; var or__1927000174__auto____5 any; var root_2313 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_2314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2313, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2315 lang.IFn; if linked_2314 == nil { ifn_2315 = lang.IFn_Cast(root_2313) } else { ifn_2315 = nil }; var arg_2316 any = A_arbace_go_check_types_A_const_259.Invoke_O__O(d__4_2); if linked_2314 == nil { or__1927000174__auto____5 = ifn_2315.Invoke_O__O(arg_2316) } else { or__1927000174__auto____5 = linked_2314.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2313, arg_2316) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp23 = or__1927000174__auto____5 } else { var root_2317 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_2318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2317, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2319 lang.IFn; if linked_2318 == nil { ifn_2319 = lang.IFn_Cast(root_2317) } else { ifn_2319 = nil }; var tmp24 lang.IFn = lang.IFn_Cast(t.F_same_QMARK_); var arg_2320 any = tmp24.Invoke_O_O__O(A_arbace_go_check_types_A_const_65.Invoke_O__O(d__4_2), A_arbace_go_check_types_A_const_65.Invoke_O__O(m__1)); if linked_2318 == nil { tmp23 = ifn_2319.Invoke_O__O(arg_2320) } else { tmp23 = linked_2318.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2317, arg_2320) } }; if jrt.J2g_Truth(tmp23) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_232, m__1, A_arbace_go_check_types_A_const_250, A_arbace_go_check_types_A_const_252, A_arbace_go_check_types_A_const_253, d__4_2)) } else { return nil } } else {
//line :893:1
											return nil
										}
									}
									} } } } }
func A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A{}; t.Ctor_O_O(p0, p1); return t }
//line :897:1
func (t *A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A) Ctor_O_O(c__m, c__V any) { t.F_m = c__m; t.F_V = c__V }
//line :897:1
func (t *A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2290 any = A_arbace_go_check_types_A_const_248.GetRawRoot__O(); var linked_2291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2290, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_2292 lang.IFn; if linked_2291 == nil { ifn_2292 = lang.IFn_Cast(root_2290) } else { ifn_2292 = nil }; var arg_2293 any; var t_ any = t.F_V; t.F_V = nil; arg_2293 = t_; var arg_2294 any = jrt.Boolean_FALSE.Ref(); var arg_2295 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(t.F_m); var arg_2296 any; var tmp2 *lang.Keyword = A_arbace_go_check_types_A_const_57; var tmp3 any; var t__2 any = t.F_m; t.F_m = nil; tmp3 = t__2; arg_2296 = tmp2.Invoke_O__O(tmp3); if linked_2291 == nil { tmp1 = ifn_2292.Invoke_O_O_O_O__O(arg_2293, arg_2294, arg_2295, arg_2296) } else { tmp1 = linked_2291.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_2290, arg_2293, arg_2294, arg_2295, arg_2296) } }; return nil }(); var root_2297 any = A_arbace_go_check_types_A_const_254.GetRawRoot__O(); var linked_2298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2297, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2299 lang.IFn; if linked_2298 == nil { ifn_2299 = lang.IFn_Cast(root_2297) } else { ifn_2299 = nil }; if linked_2298 == nil { ifn_2299.Invoke__O() } else { linked_2298.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2297) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }
















func A_arbace_go_check_types_satisfies_cause_A_New() *A_arbace_go_check_types_satisfies_cause_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_A{}; t.Ctor(); return t }
//line :914:1
func (t *A_arbace_go_check_types_satisfies_cause_A) Ctor() {}
//line :914:1
func (t *A_arbace_go_check_types_satisfies_cause_A) Invoke_O_O_O__O(self, V__0_, b__1 any) any { var Ti__3_ any; var root_2338 any = A_arbace_go_check_types_A_const_170.GetRawRoot__O(); var linked_2339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2338, A_arbace_go_check_types_bound_iface_A_fn_class); var ifn_2340 lang.IFn; if



	linked_2339 == nil { ifn_2340 = lang.IFn_Cast(root_2338) } else { ifn_2340 = nil }; var arg_2341 any = b__1; if linked_2339 == nil { Ti__3_ = ifn_2340.Invoke_O__O(arg_2341) } else { Ti__3_ = linked_2339.(*A_arbace_go_check_types_bound_iface_A).Invoke_O_O__O(root_2338, arg_2341) }; var Vu__4_ any; var root_2342 any = /*line :914:1*/A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_2343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2342, A_arbace_go_check_types_under_A_fn_class); var ifn_2344 lang.IFn; if




	linked_2343 == nil { ifn_2344 = lang.IFn_Cast(root_2342) } else { ifn_2344 = nil }; var arg_2345 any = V__0_; if linked_2343 == nil { Vu__4_ = ifn_2344.Invoke_O__O(arg_2345) } else { Vu__4_ = linked_2343.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2342, arg_2345) }; var tmp1 any; var or__1927000174__auto____5 bool =
	lang.Util_Identical_O_O__Z_NoInit(Ti__3_, nil); if or__1927000174__auto____5 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_103, Vu__4_); if or__1927000174__auto____6 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var and__1927000168__auto____7 any; var root_2346 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_2347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2346, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2348 lang.IFn
		if linked_2347 == nil { ifn_2348 = lang.IFn_Cast(root_2346) } else { ifn_2348 = nil }; var arg_2349 any = Vu__4_; if linked_2347 == nil { and__1927000168__auto____7 = ifn_2348.Invoke_O__O(arg_2349) } else { and__1927000168__auto____7 = linked_2347.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2346, arg_2349) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp2 any = A_arbace_go_check_types_A_const_73; var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____8 { var tmp3 any = A_arbace_go_check_types_A_const_103; var tmp4 any; var root_2350 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_2351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2350, A_arbace_go_check_types_under_A_fn_class); var ifn_2352 lang.IFn; if linked_2351 == nil { ifn_2352 = lang.IFn_Cast(root_2350) } else { ifn_2352 = nil }; var arg_2353 any = lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(1)); if linked_2351 == nil { tmp4 = ifn_2352.Invoke_O__O(arg_2353) } else { tmp4 = linked_2351.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2350, arg_2353) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp1 = and__1927000168__auto____7 } } }; if /*line :920:1*/ jrt.J2g_Truth(tmp1) { return nil } else { var Tts__5_ any; var root_2354 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_2355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2354, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_2356 lang.IFn


			if linked_2355 == nil { ifn_2356 = lang.IFn_Cast(root_2354) } else { ifn_2356 = nil }; var arg_2357 any = Ti__3_; if linked_2355 == nil { Tts__5_ = ifn_2356.Invoke_O__O(arg_2357) } else { Tts__5_ = linked_2355.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_2354, arg_2357) }
//line :920:1
			var Vi__6_ any; var tmp5 any; var and__1927000168__auto____6 any; var root_2358 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_2359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2358, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2360 lang.IFn



			if linked_2359 == nil { ifn_2360 = lang.IFn_Cast(root_2358) } else { ifn_2360 = nil }; var arg_2361 any = Vu__4_; if linked_2359 == nil { and__1927000168__auto____6 = ifn_2360.Invoke_O__O(arg_2361) } else { and__1927000168__auto____6 = linked_2359.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2358, arg_2361) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp6 any = A_arbace_go_check_types_A_const_71; tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp6, lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp5 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp5) { Vi__6_ = Vu__4_ } else { Vi__6_ = nil }
//line :920:1
			var Vts__7_ any




			if jrt.J2g_Truth(Vi__6_) { var root_2362 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_2363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2362, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_2364 lang.IFn; if linked_2363 == nil { ifn_2364 = lang.IFn_Cast(root_2362) } else { ifn_2364 = nil }; var arg_2365 any = Vi__6_; if linked_2363 == nil { Vts__7_ = ifn_2364.Invoke_O__O(arg_2365) } else { Vts__7_ = linked_2363.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_2362, arg_2365) } } else { Vts__7_ = nil }
//line :920:1
			var T_str__8_ any; var root_2366 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_2367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2366, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2368 lang.IFn





			if linked_2367 == nil { ifn_2368 = lang.IFn_Cast(root_2366) } else { ifn_2368 = nil }; var arg_2369 any = b__1; if linked_2367 == nil { T_str__8_ = ifn_2368.Invoke_O__O(arg_2369) } else { T_str__8_ = linked_2367.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2366, arg_2369) }
			var tmp7 any; var and__1927000168__auto____9 any; var root_2370 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_2371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2370, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2372 lang.IFn
			if linked_2371 == nil { ifn_2372 = lang.IFn_Cast(root_2370) } else { ifn_2372 = nil }; var arg_2373 any = lang.RT_Nth_O_I__O_NoInit(Ti__3_, lang.RT_IntCast_J__I_NoInit(1)); if linked_2371 == nil { and__1927000168__auto____9 = ifn_2372.Invoke_O__O(arg_2373) } else { and__1927000168__auto____9 = linked_2371.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2370, arg_2373) }; if jrt.J2g_Truth(and__1927000168__auto____9) { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(Ti__3_, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref() } else { tmp7 = and__1927000168__auto____9 }
//line :927:1
			if jrt.J2g_Truth(tmp7) { return nil } else { var tmp8 any
				var and__1927000168__auto____9_2 any = Vts__7_
				if jrt.J2g_Truth(and__1927000168__auto____9_2) { var root_2374 any = A_arbace_go_check_types_A_const_263.GetRawRoot__O(); var linked_2375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2374, A_arbace_go_check_types_tset_empty_QMARK__A_fn_class); var ifn_2376 lang.IFn; if linked_2375 == nil { ifn_2376 = lang.IFn_Cast(root_2374) } else { ifn_2376 = nil }; var arg_2377 any = Vts__7_; if linked_2375 == nil { tmp8 = ifn_2376.Invoke_O__O(arg_2377) } else { tmp8 = linked_2375.(*A_arbace_go_check_types_tset_empty_QMARK__A).Invoke_O_O__O(root_2374, arg_2377) } } else { tmp8 = and__1927000168__auto____9_2 }
//line :927:1
				if jrt.J2g_Truth(tmp8) { return nil } else { var tmp9 any; var root_2378 any = A_arbace_go_check_types_A_const_263.GetRawRoot__O(); var linked_2379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2378, A_arbace_go_check_types_tset_empty_QMARK__A_fn_class); var ifn_2380 lang.IFn


					if linked_2379 == nil { ifn_2380 = lang.IFn_Cast(root_2378) } else { ifn_2380 = nil }; var arg_2381 any = Tts__5_; if linked_2379 == nil { tmp9 = ifn_2380.Invoke_O__O(arg_2381) } else { tmp9 = linked_2379.(*A_arbace_go_check_types_tset_empty_QMARK__A).Invoke_O_O__O(root_2378, arg_2381) }
//line :927:1
					if jrt.J2g_Truth(tmp9) {


						return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_35, nil, Lit_36), jrt.RefArrayOf(jrt.Object_class, nil, T_str__8_, nil)).Ref() } else {
//line :927:1
							if A_arbace_go_check_types_A_const_86 != nil { var temp__1927000408__auto____9 any; var root_2382 any = A_arbace_go_check_types_A_const_262.GetRawRoot__O(); var linked_2383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2382, A_arbace_go_check_types_missing_method_A_fn_class); var ifn_2384 lang.IFn




								if linked_2383 == nil { ifn_2384 = lang.IFn_Cast(root_2382) } else { ifn_2384 = nil }; var arg_2385 any = V__0_; var arg_2386 any = Ti__3_; var arg_2387 any = jrt.Boolean_TRUE.Ref(); if linked_2383 == nil { temp__1927000408__auto____9 = ifn_2384.Invoke_O_O_O__O(arg_2385, arg_2386, arg_2387) } else { temp__1927000408__auto____9 = linked_2383.(*A_arbace_go_check_types_missing_method_A).Invoke_O_O_O_O__O(root_2382, arg_2385, arg_2386, arg_2387) }; if jrt.J2g_Truth(temp__1927000408__auto____9) { var mm__10 any = temp__1927000408__auto____9; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_37, nil, Lit_38, nil, Lit_31); var tmp11 any; var root_2388 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_2389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2388, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2390 lang.IFn
									if linked_2389 == nil { ifn_2390 = lang.IFn_Cast(root_2388) } else { ifn_2390 = nil }; var arg_2391 any = V__0_; if linked_2389 == nil { tmp11 = ifn_2390.Invoke_O__O(arg_2391) } else { tmp11 = linked_2389.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2388, arg_2391) }; var tmp12 *lang.Keyword = A_arbace_go_check_types_A_const_12; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp11, nil, T_str__8_, nil, tmp12.Invoke_O__O(A_arbace_go_check_types_A_const_232.Invoke_O__O(mm__10)), nil)).Ref() } else {
//line :932:1
										var comparability__10 any; var tmp13 any = A_arbace_go_check_types_satisfies_cause_comparability__219000295_A_New_O_O(Tts__5_, V__0_); var tmp14 *jrt.Class
										var fncls__2418 /*line :932:1*/*jrt.Class = A_arbace_go_check_types_satisfies_cause_comparability__219000295_A_fn_class


										if fncls__2418 == nil { var fncls__2418d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_go_check_types_satisfies_cause_comparability__219000295_A_fn_class = fncls__2418d; tmp14 = fncls__2418d } else { tmp14 = fncls__2418 }; comparability__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)








										var tmp15 any; var root_2419 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_2420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2419, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2421 lang.IFn
										if linked_2420 == nil { ifn_2421 = lang.IFn_Cast(root_2419) } else { ifn_2421 = nil }; var arg_2422 any; var root_2423 any = A_arbace_go_check_types_A_const_173.GetRawRoot__O(); var linked_2424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2423, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_2425 lang.IFn; if linked_2424 == nil { ifn_2425 = lang.IFn_Cast(root_2423) } else { ifn_2425 = nil }; var arg_2426 any = Tts__5_; if linked_2424 == nil { arg_2422 = ifn_2425.Invoke_O__O(arg_2426) } else { arg_2422 = linked_2424.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_2423, arg_2426) }; if linked_2420 == nil { tmp15 = ifn_2421.Invoke_O__O(arg_2422) } else { tmp15 = linked_2420.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2419, arg_2422) }
//line :944:1
										if jrt.J2g_Truth(tmp15) {
											return lang.IFn_Cast(comparability__10).Invoke__O() } else {
//line :944:1
												if jrt.J2g_Truth(Vts__7_) {

													var tmp16 any; var root_2427 any = A_arbace_go_check_types_A_const_265.GetRawRoot__O(); var linked_2428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2427, A_arbace_go_check_types_terms_subset_QMARK__A_fn_class); var ifn_2429 lang.IFn; if linked_2428 == nil { ifn_2429 = lang.IFn_Cast(root_2427) } else { ifn_2429 = nil }; var arg_2430 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(Vts__7_); var arg_2431 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(Tts__5_); if linked_2428 == nil { tmp16 = ifn_2429.Invoke_O_O__O(arg_2430, arg_2431) } else { tmp16 = linked_2428.(*A_arbace_go_check_types_terms_subset_QMARK__A).Invoke_O_O_O__O(root_2427, arg_2430, arg_2431) }; if jrt.J2g_Truth(tmp16) {
														return lang.IFn_Cast(comparability__10).Invoke__O() } else {
															var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_37, nil); var tmp18 any; var root_2432 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_2433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2432, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2434 lang.IFn; if linked_2433 == nil { ifn_2434 = lang.IFn_Cast(root_2432) } else { ifn_2434 = nil }; var arg_2435 any = V__0_; if linked_2433 == nil { tmp18 = ifn_2434.Invoke_O__O(arg_2435) } else { tmp18 = linked_2433.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2432, arg_2435) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, tmp18, nil, T_str__8_)).Ref() } } else {
//line :944:1
																var tmp19 any; var root_2436 any = A_arbace_go_check_types_A_const_266.GetRawRoot__O(); var linked_2437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2436, A_arbace_go_check_types_terms_includes_QMARK__A_fn_class); var ifn_2438 lang.IFn




																if linked_2437 == nil { ifn_2438 = lang.IFn_Cast(root_2436) } else { ifn_2438 = nil }; var arg_2439 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(Tts__5_); var arg_2440 any = V__0_; if linked_2437 == nil { tmp19 = ifn_2438.Invoke_O_O__O(arg_2439, arg_2440) } else { tmp19 = linked_2437.(*A_arbace_go_check_types_terms_includes_QMARK__A).Invoke_O_O_O__O(root_2436, arg_2439, arg_2440) }
//line :944:1
																if jrt.J2g_Truth(tmp19) {




																	return lang.IFn_Cast(comparability__10).Invoke__O() } else {
//line :944:1
																		if A_arbace_go_check_types_A_const_86 != nil {





																			var tmp20 *jrt.RefArray = jrt.ConstRefArray("[0,8,ns18: does not satisfy ns2: (ns12: missing in ns1:)", []*jrt.Class{jrt.String_class}); var tmp21 any; var root_2441 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_2442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2441, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2443 lang.IFn; if linked_2442 == nil { ifn_2443 = lang.IFn_Cast(root_2441) } else { ifn_2443 = nil }; var arg_2444 any = V__0_; if linked_2442 == nil { tmp21 = ifn_2443.Invoke_O__O(arg_2444) } else { tmp21 = linked_2442.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2441, arg_2444) }; var tmp22 any = tmp21; var tmp23 any; var root_2445 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_2446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2445, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2447 lang.IFn; if linked_2446 == nil { ifn_2447 = lang.IFn_Cast(root_2445) } else { ifn_2447 = nil }; var arg_2448 any = V__0_; if linked_2446 == nil { tmp23 = ifn_2447.Invoke_O__O(arg_2448) } else { tmp23 = linked_2446.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2445, arg_2448) }; var tmp24 any = tmp23; var tmp25 any; var root_2449 any = A_arbace_go_check_types_A_const_202.GetRawRoot__O(); var linked_2450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2449, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_2451 lang.IFn
																			if linked_2450 == nil { ifn_2451 = lang.IFn_Cast(root_2449) } else { ifn_2451 = nil }; var arg_2452 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(Tts__5_); if linked_2450 == nil { tmp25 = ifn_2451.Invoke_O__O(arg_2452) } else { tmp25 = linked_2450.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_2449, arg_2452) }
//line :950:1
																			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, tmp22, nil, T_str__8_, nil, tmp24, nil, tmp25, nil)).Ref() } else {
//line :944:1
																				return nil } } } } } } else {
//line :927:1
																					return nil } } } } } }







func A_arbace_go_check_types_satisfies_cause_comparability__219000295_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_satisfies_cause_comparability__219000295_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_comparability__219000295_A{}; t.Ctor_O_O(p0, p1); return t }
//line :935:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000295_A) Ctor_O_O(c__Tts, c__V any) { t.F_Tts = c__Tts; t.F_V = c__V }
//line :935:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000295_A) Invoke_O__O(self any) any {
	var tmp1 any; var root_2392 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_2393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2392, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2394 lang.IFn
	if linked_2393 == nil { ifn_2394 = lang.IFn_Cast(root_2392) } else { ifn_2394 = nil }; var arg_2395 any; var tmp2 any = A_arbace_go_check_types_A_const_131; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_go_check_types_A_const_132.Invoke_O__O(t.F_Tts)) {
		arg_2395 = A_arbace_go_check_types_A_const_133.Invoke_O__O(t.F_Tts) } else {
			var root_2396 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_2397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2396, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2398 lang.IFn; if linked_2397 == nil { ifn_2398 = lang.IFn_Cast(root_2396) } else { ifn_2398 = nil }; var arg_2399 any; var tmp3 any = A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A_New(); var tmp4 *jrt.Class; var fncls__2405 *jrt.Class = A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A_fn_class; if fncls__2405 == nil { var fncls__2405d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A_fn_class = fncls__2405d; tmp4 = fncls__2405d } else { tmp4 = fncls__2405 }; arg_2399 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_2400 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(t.F_Tts); if linked_2397 == nil { arg_2395 = ifn_2398.Invoke_O_O__O(arg_2399, arg_2400) } else { arg_2395 = linked_2397.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2396, arg_2399, arg_2400) } }
//line :937:1
	if linked_2393 == nil { tmp1 = ifn_2394.Invoke_O__O(arg_2395) } else { tmp1 = linked_2393.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2392, arg_2395) }
//line :936:1
	if jrt.J2g_Truth(tmp1) { return nil } else { var tmp5 any; var root_2406 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_2407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2406, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_2408 lang.IFn




		if linked_2407 == nil { ifn_2408 = lang.IFn_Cast(root_2406) } else { ifn_2408 = nil }; var arg_2409 any = t.F_V; if linked_2407 == nil { tmp5 = ifn_2408.Invoke_O__O(arg_2409) } else { tmp5 = linked_2407.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O__O(root_2406, arg_2409) }
//line :936:1
		if jrt.J2g_Truth(tmp5) { return nil } else { var tmp6 any; var root_2410 any = A_arbace_go_check_types_A_const_264.GetRawRoot__O(); var linked_2411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2410, A_arbace_go_check_types_comparable_QMARK__A_fn_class); var ifn_2412 lang.IFn





			if linked_2411 == nil { ifn_2412 = lang.IFn_Cast(root_2410) } else { ifn_2412 = nil }; var arg_2413 any = t.F_V; if linked_2411 == nil { tmp6 = ifn_2412.Invoke_O__O(arg_2413) } else { tmp6 = linked_2411.(*A_arbace_go_check_types_comparable_QMARK__A).Invoke_O_O__O(root_2410, arg_2413) }
//line :936:1
			if jrt.J2g_Truth(tmp6) { return nil } else { if A_arbace_go_check_types_A_const_86 != nil {






				var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_41); var tmp8 any; var root_2414 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_2415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2414, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2416 lang.IFn; if linked_2415 == nil { ifn_2416 = lang.IFn_Cast(root_2414) } else { ifn_2416 = nil }; var arg_2417 any = t.F_V; if linked_2415 == nil { tmp8 = ifn_2416.Invoke_O__O(arg_2417) } else { tmp8 = linked_2415.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2414, arg_2417) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8, nil)).Ref() } else {
//line :936:1
					return nil
				}
			} } } }
func A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A_New() *A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A{}; t.Ctor(); return t }
//line :939:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A) Ctor() {}
//line :939:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A) Invoke_O_O__O(self, p__219000296__1 any) any { var vec__219000298__2 any = p__219000296__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000298__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000298__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2401 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_2402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2401, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_2403 lang.IFn; _ = ___3; if linked_2402 == nil { ifn_2403 = lang.IFn_Cast(root_2401) } else { ifn_2403 = nil }; var arg_2404 any = ty__4; if linked_2402 == nil { return ifn_2403.Invoke_O__O(arg_2404) } else { return linked_2402.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O__O(root_2401, arg_2404) } }

























































type A_arbace_go_check_types_A struct{ jrt.Object }

var A_arbace_go_check_types_A_const_pool *jrt.RefArray

var A_arbace_go_check_types_A_const_0 *lang.Var

var A_arbace_go_check_types_A_const_1 any

var A_arbace_go_check_types_A_const_2 any

var A_arbace_go_check_types_A_const_3 *lang.Var

var A_arbace_go_check_types_A_const_4 any

var A_arbace_go_check_types_A_const_5 *lang.Var

var A_arbace_go_check_types_A_const_6 *lang.Var

var A_arbace_go_check_types_A_const_7 *lang.Var

var A_arbace_go_check_types_A_const_8 *lang.Var

var A_arbace_go_check_types_A_const_9 any

var A_arbace_go_check_types_A_const_10 *lang.Var

var A_arbace_go_check_types_A_const_11 *lang.Keyword

var A_arbace_go_check_types_A_const_12 *lang.Keyword

var A_arbace_go_check_types_A_const_13 *lang.Var

var A_arbace_go_check_types_A_const_14 *lang.Keyword

var A_arbace_go_check_types_A_const_15 any

var A_arbace_go_check_types_A_const_16 *lang.Keyword

var A_arbace_go_check_types_A_const_17 *lang.Keyword

var A_arbace_go_check_types_A_const_18 *lang.Keyword

var A_arbace_go_check_types_A_const_19 *lang.Keyword

var A_arbace_go_check_types_A_const_20 any

var A_arbace_go_check_types_A_const_21 *lang.Keyword

var A_arbace_go_check_types_A_const_22 any

var A_arbace_go_check_types_A_const_23 *lang.Keyword

var A_arbace_go_check_types_A_const_24 any

var A_arbace_go_check_types_A_const_25 *lang.Keyword

var A_arbace_go_check_types_A_const_26 *lang.Keyword

var A_arbace_go_check_types_A_const_27 *lang.Keyword

var A_arbace_go_check_types_A_const_28 *lang.Keyword

var A_arbace_go_check_types_A_const_29 *lang.Keyword

var A_arbace_go_check_types_A_const_30 *lang.Keyword

var A_arbace_go_check_types_A_const_31 *lang.Keyword

var A_arbace_go_check_types_A_const_32 *lang.Keyword

var A_arbace_go_check_types_A_const_33 *lang.Keyword

var A_arbace_go_check_types_A_const_34 *lang.Keyword

var A_arbace_go_check_types_A_const_35 *lang.Keyword

var A_arbace_go_check_types_A_const_36 *lang.Keyword

var A_arbace_go_check_types_A_const_37 *lang.Keyword

var A_arbace_go_check_types_A_const_38 *lang.Keyword

var A_arbace_go_check_types_A_const_39 any

var A_arbace_go_check_types_A_const_40 *lang.Keyword

var A_arbace_go_check_types_A_const_41 *lang.Keyword

var A_arbace_go_check_types_A_const_42 *lang.Keyword

var A_arbace_go_check_types_A_const_43 *lang.Keyword

var A_arbace_go_check_types_A_const_44 any

var A_arbace_go_check_types_A_const_45 *lang.Keyword

var A_arbace_go_check_types_A_const_46 *lang.Keyword

var A_arbace_go_check_types_A_const_47 *lang.Keyword

var A_arbace_go_check_types_A_const_48 *lang.Keyword

var A_arbace_go_check_types_A_const_49 *lang.Keyword

var A_arbace_go_check_types_A_const_50 *lang.Keyword

var A_arbace_go_check_types_A_const_51 *lang.Keyword

var A_arbace_go_check_types_A_const_52 *lang.Keyword

var A_arbace_go_check_types_A_const_53 *lang.Keyword

var A_arbace_go_check_types_A_const_54 *lang.Var

var A_arbace_go_check_types_A_const_55 *lang.Var

var A_arbace_go_check_types_A_const_56 *lang.Keyword

var A_arbace_go_check_types_A_const_57 *lang.Keyword

var A_arbace_go_check_types_A_const_58 *lang.Keyword

var A_arbace_go_check_types_A_const_59 *lang.Keyword

var A_arbace_go_check_types_A_const_60 *lang.Keyword

var A_arbace_go_check_types_A_const_61 *lang.Var

var A_arbace_go_check_types_A_const_62 *lang.Var

var A_arbace_go_check_types_A_const_63 *lang.Var

var A_arbace_go_check_types_A_const_64 *lang.Var

var A_arbace_go_check_types_A_const_65 *lang.Keyword

var A_arbace_go_check_types_A_const_66 *lang.Var

var A_arbace_go_check_types_A_const_67 *lang.Var

var A_arbace_go_check_types_A_const_68 *lang.Var

var A_arbace_go_check_types_A_const_69 *lang.Keyword

var A_arbace_go_check_types_A_const_70 *lang.Var

var A_arbace_go_check_types_A_const_71 *lang.Keyword

var A_arbace_go_check_types_A_const_72 *lang.Var

var A_arbace_go_check_types_A_const_73 *lang.Keyword

var A_arbace_go_check_types_A_const_74 *lang.Keyword

var A_arbace_go_check_types_A_const_75 any

var A_arbace_go_check_types_A_const_76 *lang.Keyword

var A_arbace_go_check_types_A_const_77 *lang.Keyword

var A_arbace_go_check_types_A_const_78 *lang.Keyword

var A_arbace_go_check_types_A_const_79 *lang.Keyword

var A_arbace_go_check_types_A_const_80 *lang.Keyword

var A_arbace_go_check_types_A_const_81 *lang.Keyword

var A_arbace_go_check_types_A_const_82 *lang.Keyword

var A_arbace_go_check_types_A_const_83 *lang.Var

var A_arbace_go_check_types_A_const_84 *lang.Var

var A_arbace_go_check_types_A_const_85 *lang.Keyword

var A_arbace_go_check_types_A_const_86 *lang.Keyword

var A_arbace_go_check_types_A_const_87 *lang.Var

var A_arbace_go_check_types_A_const_88 *lang.Var

var A_arbace_go_check_types_A_const_89 *lang.Var

var A_arbace_go_check_types_A_const_90 *lang.Var

var A_arbace_go_check_types_A_const_91 *lang.Var

var A_arbace_go_check_types_A_const_92 *lang.Var

var A_arbace_go_check_types_A_const_93 *lang.Var

var A_arbace_go_check_types_A_const_94 *lang.Var

var A_arbace_go_check_types_A_const_95 *lang.Var

var A_arbace_go_check_types_A_const_96 *lang.Keyword

var A_arbace_go_check_types_A_const_97 *lang.Var

var A_arbace_go_check_types_A_const_98 *lang.Keyword

var A_arbace_go_check_types_A_const_99 *lang.Var

var A_arbace_go_check_types_A_const_100 *lang.Keyword

var A_arbace_go_check_types_A_const_101 *lang.Var

var A_arbace_go_check_types_A_const_102 *lang.Var

var A_arbace_go_check_types_A_const_103 *lang.Keyword

var A_arbace_go_check_types_A_const_104 *lang.Var

var A_arbace_go_check_types_A_const_105 *lang.Keyword

var A_arbace_go_check_types_A_const_106 *lang.Var

var A_arbace_go_check_types_A_const_107 *lang.Var

var A_arbace_go_check_types_A_const_108 *lang.Var

var A_arbace_go_check_types_A_const_109 *lang.Var

var A_arbace_go_check_types_A_const_110 *lang.Var

var A_arbace_go_check_types_A_const_111 *lang.Var

var A_arbace_go_check_types_A_const_112 *lang.Var

var A_arbace_go_check_types_A_const_113 *lang.Var

var A_arbace_go_check_types_A_const_114 *lang.Var

var A_arbace_go_check_types_A_const_115 *lang.Var

var A_arbace_go_check_types_A_const_116 any

var A_arbace_go_check_types_A_const_117 *lang.Var

var A_arbace_go_check_types_A_const_118 *lang.Var

var A_arbace_go_check_types_A_const_119 *lang.Var

var A_arbace_go_check_types_A_const_120 *lang.Var

var A_arbace_go_check_types_A_const_121 *lang.Var

var A_arbace_go_check_types_A_const_122 *lang.Var

var A_arbace_go_check_types_A_const_123 any

var A_arbace_go_check_types_A_const_124 *lang.Var

var A_arbace_go_check_types_A_const_125 *lang.Var

var A_arbace_go_check_types_A_const_126 *lang.Var

var A_arbace_go_check_types_A_const_127 any

var A_arbace_go_check_types_A_const_128 *lang.Var

var A_arbace_go_check_types_A_const_129 *lang.Var

var A_arbace_go_check_types_A_const_130 *lang.Keyword

var A_arbace_go_check_types_A_const_131 *lang.Keyword

var A_arbace_go_check_types_A_const_132 *lang.Keyword

var A_arbace_go_check_types_A_const_133 *lang.Keyword

var A_arbace_go_check_types_A_const_134 *lang.Var

var A_arbace_go_check_types_A_const_135 *lang.Var

var A_arbace_go_check_types_A_const_136 *lang.Var

var A_arbace_go_check_types_A_const_137 *lang.Var

var A_arbace_go_check_types_A_const_138 *lang.Var

var A_arbace_go_check_types_A_const_139 *lang.Var

var A_arbace_go_check_types_A_const_140 *lang.Var

var A_arbace_go_check_types_A_const_141 *lang.Var

var A_arbace_go_check_types_A_const_142 *lang.Var

var A_arbace_go_check_types_A_const_143 *lang.Keyword

var A_arbace_go_check_types_A_const_144 *lang.Var

var A_arbace_go_check_types_A_const_145 *lang.Var

var A_arbace_go_check_types_A_const_146 *lang.Var

var A_arbace_go_check_types_A_const_147 *lang.Var

var A_arbace_go_check_types_A_const_148 *lang.Var

var A_arbace_go_check_types_A_const_149 *lang.Keyword

var A_arbace_go_check_types_A_const_150 *lang.Var

var A_arbace_go_check_types_A_const_151 *lang.Var

var A_arbace_go_check_types_A_const_152 *lang.Var

var A_arbace_go_check_types_A_const_153 *lang.Var

var A_arbace_go_check_types_A_const_154 *lang.Var

var A_arbace_go_check_types_A_const_155 *lang.Var

var A_arbace_go_check_types_A_const_156 *lang.Var

var A_arbace_go_check_types_A_const_157 *lang.Var

var A_arbace_go_check_types_A_const_158 *lang.Var

var A_arbace_go_check_types_A_const_159 *lang.Var

var A_arbace_go_check_types_A_const_160 *lang.Var

var A_arbace_go_check_types_A_const_161 *lang.Var

var A_arbace_go_check_types_A_const_162 *lang.Var

var A_arbace_go_check_types_A_const_163 *lang.Var

var A_arbace_go_check_types_A_const_164 *lang.Var

var A_arbace_go_check_types_A_const_165 *lang.Var

var A_arbace_go_check_types_A_const_166 *lang.Var

var A_arbace_go_check_types_A_const_167 *lang.Var

var A_arbace_go_check_types_A_const_168 *lang.Var

var A_arbace_go_check_types_A_const_169 *lang.Keyword

var A_arbace_go_check_types_A_const_170 *lang.Var

var A_arbace_go_check_types_A_const_171 *lang.Keyword

var A_arbace_go_check_types_A_const_172 *lang.Var

var A_arbace_go_check_types_A_const_173 *lang.Var

var A_arbace_go_check_types_A_const_174 any

var A_arbace_go_check_types_A_const_175 *lang.Var

var A_arbace_go_check_types_A_const_176 *lang.Var

var A_arbace_go_check_types_A_const_177 *lang.Var

var A_arbace_go_check_types_A_const_178 *lang.Var

var A_arbace_go_check_types_A_const_179 *lang.Var

var A_arbace_go_check_types_A_const_180 *lang.Var

var A_arbace_go_check_types_A_const_181 *lang.Var

var A_arbace_go_check_types_A_const_182 any

var A_arbace_go_check_types_A_const_183 *lang.Keyword

var A_arbace_go_check_types_A_const_184 any

var A_arbace_go_check_types_A_const_185 any

var A_arbace_go_check_types_A_const_186 *lang.Var

var A_arbace_go_check_types_A_const_187 *lang.Var

var A_arbace_go_check_types_A_const_188 *lang.Var

var A_arbace_go_check_types_A_const_189 *lang.Var

var A_arbace_go_check_types_A_const_190 *lang.Var

var A_arbace_go_check_types_A_const_191 *lang.Var

var A_arbace_go_check_types_A_const_192 *lang.Keyword

var A_arbace_go_check_types_A_const_193 *lang.Var

var A_arbace_go_check_types_A_const_194 *lang.Var

var A_arbace_go_check_types_A_const_195 *lang.Keyword

var A_arbace_go_check_types_A_const_196 *lang.Var

var A_arbace_go_check_types_A_const_197 *lang.Var

var A_arbace_go_check_types_A_const_198 *lang.Var

var A_arbace_go_check_types_A_const_199 *lang.Var

var A_arbace_go_check_types_A_const_200 any

var A_arbace_go_check_types_A_const_201 *lang.Var

var A_arbace_go_check_types_A_const_202 *lang.Var

var A_arbace_go_check_types_A_const_203 *lang.Keyword

var A_arbace_go_check_types_A_const_204 *lang.Keyword

var A_arbace_go_check_types_A_const_205 *lang.Var

var A_arbace_go_check_types_A_const_206 any

var A_arbace_go_check_types_A_const_207 *lang.Var

var A_arbace_go_check_types_A_const_208 *lang.Var

var A_arbace_go_check_types_A_const_209 *lang.Var

var A_arbace_go_check_types_A_const_210 any

var A_arbace_go_check_types_A_const_211 *lang.Var

var A_arbace_go_check_types_A_const_212 *lang.Var

var A_arbace_go_check_types_A_const_213 *lang.Var

var A_arbace_go_check_types_A_const_214 *lang.Var

var A_arbace_go_check_types_A_const_215 any

var A_arbace_go_check_types_A_const_216 *lang.Var

var A_arbace_go_check_types_A_const_217 *lang.Var

var A_arbace_go_check_types_A_const_218 *lang.Keyword

var A_arbace_go_check_types_A_const_219 *lang.Var

var A_arbace_go_check_types_A_const_220 *lang.Var

var A_arbace_go_check_types_A_const_221 *lang.Var

var A_arbace_go_check_types_A_const_222 *lang.Var

var A_arbace_go_check_types_A_const_223 *lang.Var

var A_arbace_go_check_types_A_const_224 *lang.Var

var A_arbace_go_check_types_A_const_225 *lang.Keyword

var A_arbace_go_check_types_A_const_226 *lang.Var

var A_arbace_go_check_types_A_const_227 *lang.Var

var A_arbace_go_check_types_A_const_228 *lang.Var

var A_arbace_go_check_types_A_const_229 *lang.Var

var A_arbace_go_check_types_A_const_230 any

var A_arbace_go_check_types_A_const_231 *lang.Keyword

var A_arbace_go_check_types_A_const_232 *lang.Keyword

var A_arbace_go_check_types_A_const_233 *lang.Var

var A_arbace_go_check_types_A_const_234 *lang.Keyword

var A_arbace_go_check_types_A_const_235 *lang.Keyword

var A_arbace_go_check_types_A_const_236 *lang.Keyword

var A_arbace_go_check_types_A_const_237 *lang.Keyword

var A_arbace_go_check_types_A_const_238 any

var A_arbace_go_check_types_A_const_239 *lang.Keyword

var A_arbace_go_check_types_A_const_240 any

var A_arbace_go_check_types_A_const_241 *lang.Keyword

var A_arbace_go_check_types_A_const_242 *lang.Keyword

var A_arbace_go_check_types_A_const_243 *lang.Keyword

var A_arbace_go_check_types_A_const_244 *lang.Var

var A_arbace_go_check_types_A_const_245 *lang.Keyword

var A_arbace_go_check_types_A_const_246 *lang.Var

var A_arbace_go_check_types_A_const_247 *lang.Var

var A_arbace_go_check_types_A_const_248 *lang.Var

var A_arbace_go_check_types_A_const_249 *lang.Keyword

var A_arbace_go_check_types_A_const_250 *lang.Keyword

var A_arbace_go_check_types_A_const_251 *lang.Keyword

var A_arbace_go_check_types_A_const_252 *lang.Keyword

var A_arbace_go_check_types_A_const_253 *lang.Keyword

var A_arbace_go_check_types_A_const_254 *lang.Var

var A_arbace_go_check_types_A_const_255 *lang.Var

var A_arbace_go_check_types_A_const_256 *lang.Keyword

var A_arbace_go_check_types_A_const_257 *lang.Keyword

var A_arbace_go_check_types_A_const_258 *lang.Var

var A_arbace_go_check_types_A_const_259 *lang.Keyword

var A_arbace_go_check_types_A_const_260 *lang.Var

var A_arbace_go_check_types_A_const_261 *lang.Var

var A_arbace_go_check_types_A_const_262 *lang.Var

var A_arbace_go_check_types_A_const_263 *lang.Var

var A_arbace_go_check_types_A_const_264 *lang.Var

var A_arbace_go_check_types_A_const_265 *lang.Var

var A_arbace_go_check_types_A_const_266 *lang.Var

var A_arbace_go_check_types_A_init jrt.ClassInit

func A_arbace_go_check_types_A_Init() { if !A_arbace_go_check_types_A_init.Done() { A_arbace_go_check_types_A_init.Run(A_arbace_go_check_types_A_clinit) } }

func A_arbace_go_check_types_A_clinit() { A_arbace_go_check_types_A_clinit_p0(); A_arbace_go_check_types_A_clinit_p1(); A_arbace_go_check_types_A_clinit_p2(); A_arbace_go_check_types_A_clinit_p3(); A_arbace_go_check_types_A_clinit_p4(); A_arbace_go_check_types_A_clinit_p5(); A_arbace_go_check_types_A_clinit_p6(); A_arbace_go_check_types_A_clinit_p7(); A_arbace_go_check_types_A_clinit_p8(); A_arbace_go_check_types_A_clinit_p9(); A_arbace_go_check_types_A_clinit_p10(); A_arbace_go_check_types_A_clinit_p11(); A_arbace_go_check_types_A_clinit_p12(); A_arbace_go_check_types_A_clinit_p13(); A_arbace_go_check_types_A_clinit_p14(); A_arbace_go_check_types_A_clinit_p15(); A_arbace_go_check_types_A_clinit_p16(); A_arbace_go_check_types_A_clinit_p17(); A_arbace_go_check_types_A_clinit_p18(); A_arbace_go_check_types_A_clinit_p19(); A_arbace_go_check_types_A_clinit_p20(); A_arbace_go_check_types_A_clinit_p21(); A_arbace_go_check_types_A_clinit_p22() }

func A_arbace_go_check_types_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_types_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 368); A_arbace_go_check_types_A_const_0 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[101]); A_arbace_go_check_types_A_const_1 = A_arbace_go_check_types_A_const_pool.A[102]; A_arbace_go_check_types_A_const_2 = A_arbace_go_check_types_A_const_pool.A[103]; A_arbace_go_check_types_A_const_3 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[104]); A_arbace_go_check_types_A_const_4 = A_arbace_go_check_types_A_const_pool.A[105]; A_arbace_go_check_types_A_const_5 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[106]); A_arbace_go_check_types_A_const_6 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[107]); A_arbace_go_check_types_A_const_7 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[108]); A_arbace_go_check_types_A_const_8 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[109]); A_arbace_go_check_types_A_const_9 = A_arbace_go_check_types_A_const_pool.A[110]; A_arbace_go_check_types_A_const_10 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[111]); A_arbace_go_check_types_A_const_11 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[112]) }

func A_arbace_go_check_types_A_clinit_p1() { A_arbace_go_check_types_A_const_12 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[113]); A_arbace_go_check_types_A_const_13 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[114]); A_arbace_go_check_types_A_const_14 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[115]); A_arbace_go_check_types_A_const_15 = A_arbace_go_check_types_A_const_pool.A[116]; A_arbace_go_check_types_A_const_16 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[117]); A_arbace_go_check_types_A_const_17 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[118]); A_arbace_go_check_types_A_const_18 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[119]); A_arbace_go_check_types_A_const_19 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[120]); A_arbace_go_check_types_A_const_20 = A_arbace_go_check_types_A_const_pool.A[121]; A_arbace_go_check_types_A_const_21 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[122]); A_arbace_go_check_types_A_const_22 = A_arbace_go_check_types_A_const_pool.A[123]; A_arbace_go_check_types_A_const_23 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[124]); A_arbace_go_check_types_A_const_24 = A_arbace_go_check_types_A_const_pool.A[125] }

func A_arbace_go_check_types_A_clinit_p2() { A_arbace_go_check_types_A_const_25 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[126]); A_arbace_go_check_types_A_const_26 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[127]); A_arbace_go_check_types_A_const_27 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[128]); A_arbace_go_check_types_A_const_28 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[129]); A_arbace_go_check_types_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[130]); A_arbace_go_check_types_A_const_30 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[131]); A_arbace_go_check_types_A_const_31 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[132]); A_arbace_go_check_types_A_const_32 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[133]); A_arbace_go_check_types_A_const_33 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[134]); A_arbace_go_check_types_A_const_34 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[135]); A_arbace_go_check_types_A_const_35 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[136]); A_arbace_go_check_types_A_const_36 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[137]) }

func A_arbace_go_check_types_A_clinit_p3() { A_arbace_go_check_types_A_const_37 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[138]); A_arbace_go_check_types_A_const_38 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[139]); A_arbace_go_check_types_A_const_39 = A_arbace_go_check_types_A_const_pool.A[140]; A_arbace_go_check_types_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[141]); A_arbace_go_check_types_A_const_41 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[142]); A_arbace_go_check_types_A_const_42 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[143]); A_arbace_go_check_types_A_const_43 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[144]); A_arbace_go_check_types_A_const_44 = A_arbace_go_check_types_A_const_pool.A[145]; A_arbace_go_check_types_A_const_45 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[146]); A_arbace_go_check_types_A_const_46 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[147]); A_arbace_go_check_types_A_const_47 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[148]); A_arbace_go_check_types_A_const_48 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[149]) }

func A_arbace_go_check_types_A_clinit_p4() { A_arbace_go_check_types_A_const_49 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[150]); A_arbace_go_check_types_A_const_50 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[151]); A_arbace_go_check_types_A_const_51 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[152]); A_arbace_go_check_types_A_const_52 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[153]); A_arbace_go_check_types_A_const_53 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[154]); A_arbace_go_check_types_A_const_54 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[155]); A_arbace_go_check_types_A_const_55 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[156]); A_arbace_go_check_types_A_const_56 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[157]); A_arbace_go_check_types_A_const_57 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[158]); A_arbace_go_check_types_A_const_58 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[159]); A_arbace_go_check_types_A_const_59 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[160]); A_arbace_go_check_types_A_const_60 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[161]) }

func A_arbace_go_check_types_A_clinit_p5() { A_arbace_go_check_types_A_const_61 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[162]); A_arbace_go_check_types_A_const_62 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[163]); A_arbace_go_check_types_A_const_63 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[164]); A_arbace_go_check_types_A_const_64 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[165]); A_arbace_go_check_types_A_const_65 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[166]); A_arbace_go_check_types_A_const_66 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[167]); A_arbace_go_check_types_A_const_67 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[168]); A_arbace_go_check_types_A_const_68 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[169]); A_arbace_go_check_types_A_const_69 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[170]); A_arbace_go_check_types_A_const_70 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[171]); A_arbace_go_check_types_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[172]); A_arbace_go_check_types_A_const_72 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[173]) }

func A_arbace_go_check_types_A_clinit_p6() { A_arbace_go_check_types_A_const_73 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[174]); A_arbace_go_check_types_A_const_74 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[175]); A_arbace_go_check_types_A_const_75 = A_arbace_go_check_types_A_const_pool.A[176]; A_arbace_go_check_types_A_const_76 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[177]); A_arbace_go_check_types_A_const_77 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[178]); A_arbace_go_check_types_A_const_78 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[179]); A_arbace_go_check_types_A_const_79 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[180]); A_arbace_go_check_types_A_const_80 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[181]); A_arbace_go_check_types_A_const_81 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[182]); A_arbace_go_check_types_A_const_82 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[183]); A_arbace_go_check_types_A_const_83 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[184]); A_arbace_go_check_types_A_const_84 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[185]) }

func A_arbace_go_check_types_A_clinit_p7() { A_arbace_go_check_types_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[186]); A_arbace_go_check_types_A_const_86 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[187]); A_arbace_go_check_types_A_const_87 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[188]); A_arbace_go_check_types_A_const_88 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[189]); A_arbace_go_check_types_A_const_89 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[190]); A_arbace_go_check_types_A_const_90 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[191]); A_arbace_go_check_types_A_const_91 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[192]); A_arbace_go_check_types_A_const_92 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[193]); A_arbace_go_check_types_A_const_93 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[194]); A_arbace_go_check_types_A_const_94 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[195]); A_arbace_go_check_types_A_const_95 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[196]); A_arbace_go_check_types_A_const_96 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[197]) }

func A_arbace_go_check_types_A_clinit_p8() { A_arbace_go_check_types_A_const_97 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[198]); A_arbace_go_check_types_A_const_98 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[199]); A_arbace_go_check_types_A_const_99 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[200]); A_arbace_go_check_types_A_const_100 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[201]); A_arbace_go_check_types_A_const_101 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[202]); A_arbace_go_check_types_A_const_102 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[203]); A_arbace_go_check_types_A_const_103 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[204]); A_arbace_go_check_types_A_const_104 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[205]); A_arbace_go_check_types_A_const_105 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[206]); A_arbace_go_check_types_A_const_106 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[207]); A_arbace_go_check_types_A_const_107 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[208]); A_arbace_go_check_types_A_const_108 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[209]) }

func A_arbace_go_check_types_A_clinit_p9() { A_arbace_go_check_types_A_const_109 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[210]); A_arbace_go_check_types_A_const_110 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[211]); A_arbace_go_check_types_A_const_111 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[212]); A_arbace_go_check_types_A_const_112 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[213]); A_arbace_go_check_types_A_const_113 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[214]); A_arbace_go_check_types_A_const_114 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[215]); A_arbace_go_check_types_A_const_115 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[216]); A_arbace_go_check_types_A_const_116 = A_arbace_go_check_types_A_const_pool.A[217]; A_arbace_go_check_types_A_const_117 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[218]); A_arbace_go_check_types_A_const_118 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[219]); A_arbace_go_check_types_A_const_119 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[220]); A_arbace_go_check_types_A_const_120 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[221]) }

func A_arbace_go_check_types_A_clinit_p10() { A_arbace_go_check_types_A_const_121 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[222]); A_arbace_go_check_types_A_const_122 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[223]); A_arbace_go_check_types_A_const_123 = A_arbace_go_check_types_A_const_pool.A[224]; A_arbace_go_check_types_A_const_124 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[225]); A_arbace_go_check_types_A_const_125 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[226]); A_arbace_go_check_types_A_const_126 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[227]); A_arbace_go_check_types_A_const_127 = A_arbace_go_check_types_A_const_pool.A[228]; A_arbace_go_check_types_A_const_128 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[229]); A_arbace_go_check_types_A_const_129 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[230]); A_arbace_go_check_types_A_const_130 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[231]); A_arbace_go_check_types_A_const_131 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[232]); A_arbace_go_check_types_A_const_132 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[233]) }

func A_arbace_go_check_types_A_clinit_p11() { A_arbace_go_check_types_A_const_133 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[234]); A_arbace_go_check_types_A_const_134 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[235]); A_arbace_go_check_types_A_const_135 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[236]); A_arbace_go_check_types_A_const_136 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[237]); A_arbace_go_check_types_A_const_137 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[238]); A_arbace_go_check_types_A_const_138 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[239]); A_arbace_go_check_types_A_const_139 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[240]); A_arbace_go_check_types_A_const_140 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[241]); A_arbace_go_check_types_A_const_141 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[242]); A_arbace_go_check_types_A_const_142 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[243]); A_arbace_go_check_types_A_const_143 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[244]); A_arbace_go_check_types_A_const_144 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[245]) }

func A_arbace_go_check_types_A_clinit_p12() { A_arbace_go_check_types_A_const_145 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[246]); A_arbace_go_check_types_A_const_146 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[247]); A_arbace_go_check_types_A_const_147 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[248]); A_arbace_go_check_types_A_const_148 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[249]); A_arbace_go_check_types_A_const_149 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[250]); A_arbace_go_check_types_A_const_150 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[251]); A_arbace_go_check_types_A_const_151 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[252]); A_arbace_go_check_types_A_const_152 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[253]); A_arbace_go_check_types_A_const_153 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[254]); A_arbace_go_check_types_A_const_154 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[255]); A_arbace_go_check_types_A_const_155 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[256]); A_arbace_go_check_types_A_const_156 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[257]) }

func A_arbace_go_check_types_A_clinit_p13() { A_arbace_go_check_types_A_const_157 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[258]); A_arbace_go_check_types_A_const_158 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[259]); A_arbace_go_check_types_A_const_159 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[260]); A_arbace_go_check_types_A_const_160 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[261]); A_arbace_go_check_types_A_const_161 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[262]); A_arbace_go_check_types_A_const_162 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[263]); A_arbace_go_check_types_A_const_163 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[264]); A_arbace_go_check_types_A_const_164 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[265]); A_arbace_go_check_types_A_const_165 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[266]); A_arbace_go_check_types_A_const_166 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[267]); A_arbace_go_check_types_A_const_167 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[268]); A_arbace_go_check_types_A_const_168 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[269]) }

func A_arbace_go_check_types_A_clinit_p14() { A_arbace_go_check_types_A_const_169 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[270]); A_arbace_go_check_types_A_const_170 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[271]); A_arbace_go_check_types_A_const_171 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[272]); A_arbace_go_check_types_A_const_172 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[273]); A_arbace_go_check_types_A_const_173 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[274]); A_arbace_go_check_types_A_const_174 = A_arbace_go_check_types_A_const_pool.A[275]; A_arbace_go_check_types_A_const_175 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[276]); A_arbace_go_check_types_A_const_176 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[277]); A_arbace_go_check_types_A_const_177 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[278]); A_arbace_go_check_types_A_const_178 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[279]); A_arbace_go_check_types_A_const_179 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[280]); A_arbace_go_check_types_A_const_180 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[281]) }

func A_arbace_go_check_types_A_clinit_p15() { A_arbace_go_check_types_A_const_181 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[282]); A_arbace_go_check_types_A_const_182 = A_arbace_go_check_types_A_const_pool.A[283]; A_arbace_go_check_types_A_const_183 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[284]); A_arbace_go_check_types_A_const_184 = A_arbace_go_check_types_A_const_pool.A[285]; A_arbace_go_check_types_A_const_185 = A_arbace_go_check_types_A_const_pool.A[286]; A_arbace_go_check_types_A_const_186 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[287]); A_arbace_go_check_types_A_const_187 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[288]); A_arbace_go_check_types_A_const_188 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[289]); A_arbace_go_check_types_A_const_189 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[290]); A_arbace_go_check_types_A_const_190 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[291]); A_arbace_go_check_types_A_const_191 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[292]); A_arbace_go_check_types_A_const_192 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[293]) }

func A_arbace_go_check_types_A_clinit_p16() { A_arbace_go_check_types_A_const_193 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[294]); A_arbace_go_check_types_A_const_194 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[295]); A_arbace_go_check_types_A_const_195 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[296]); A_arbace_go_check_types_A_const_196 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[297]); A_arbace_go_check_types_A_const_197 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[298]); A_arbace_go_check_types_A_const_198 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[299]); A_arbace_go_check_types_A_const_199 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[300]); A_arbace_go_check_types_A_const_200 = A_arbace_go_check_types_A_const_pool.A[301]; A_arbace_go_check_types_A_const_201 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[302]); A_arbace_go_check_types_A_const_202 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[303]); A_arbace_go_check_types_A_const_203 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[304]); A_arbace_go_check_types_A_const_204 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[305]) }

func A_arbace_go_check_types_A_clinit_p17() { A_arbace_go_check_types_A_const_205 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[306]); A_arbace_go_check_types_A_const_206 = A_arbace_go_check_types_A_const_pool.A[307]; A_arbace_go_check_types_A_const_207 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[308]); A_arbace_go_check_types_A_const_208 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[309]); A_arbace_go_check_types_A_const_209 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[310]); A_arbace_go_check_types_A_const_210 = A_arbace_go_check_types_A_const_pool.A[311]; A_arbace_go_check_types_A_const_211 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[312]); A_arbace_go_check_types_A_const_212 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[313]); A_arbace_go_check_types_A_const_213 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[314]); A_arbace_go_check_types_A_const_214 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[315]); A_arbace_go_check_types_A_const_215 = A_arbace_go_check_types_A_const_pool.A[316]; A_arbace_go_check_types_A_const_216 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[317]) }

func A_arbace_go_check_types_A_clinit_p18() { A_arbace_go_check_types_A_const_217 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[318]); A_arbace_go_check_types_A_const_218 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[319]); A_arbace_go_check_types_A_const_219 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[320]); A_arbace_go_check_types_A_const_220 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[321]); A_arbace_go_check_types_A_const_221 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[322]); A_arbace_go_check_types_A_const_222 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[323]); A_arbace_go_check_types_A_const_223 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[324]); A_arbace_go_check_types_A_const_224 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[325]); A_arbace_go_check_types_A_const_225 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[326]); A_arbace_go_check_types_A_const_226 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[327]); A_arbace_go_check_types_A_const_227 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[328]); A_arbace_go_check_types_A_const_228 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[329]) }

func A_arbace_go_check_types_A_clinit_p19() { A_arbace_go_check_types_A_const_229 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[330]); A_arbace_go_check_types_A_const_230 = A_arbace_go_check_types_A_const_pool.A[331]; A_arbace_go_check_types_A_const_231 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[332]); A_arbace_go_check_types_A_const_232 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[333]); A_arbace_go_check_types_A_const_233 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[334]); A_arbace_go_check_types_A_const_234 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[335]); A_arbace_go_check_types_A_const_235 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[336]); A_arbace_go_check_types_A_const_236 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[337]); A_arbace_go_check_types_A_const_237 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[338]); A_arbace_go_check_types_A_const_238 = A_arbace_go_check_types_A_const_pool.A[339]; A_arbace_go_check_types_A_const_239 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[340]); A_arbace_go_check_types_A_const_240 = A_arbace_go_check_types_A_const_pool.A[341] }

func A_arbace_go_check_types_A_clinit_p20() { A_arbace_go_check_types_A_const_241 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[342]); A_arbace_go_check_types_A_const_242 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[343]); A_arbace_go_check_types_A_const_243 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[344]); A_arbace_go_check_types_A_const_244 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[345]); A_arbace_go_check_types_A_const_245 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[346]); A_arbace_go_check_types_A_const_246 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[347]); A_arbace_go_check_types_A_const_247 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[348]); A_arbace_go_check_types_A_const_248 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[349]); A_arbace_go_check_types_A_const_249 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[350]); A_arbace_go_check_types_A_const_250 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[351]); A_arbace_go_check_types_A_const_251 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[352]); A_arbace_go_check_types_A_const_252 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[353]) }

func A_arbace_go_check_types_A_clinit_p21() { A_arbace_go_check_types_A_const_253 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[354]); A_arbace_go_check_types_A_const_254 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[355]); A_arbace_go_check_types_A_const_255 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[356]); A_arbace_go_check_types_A_const_256 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[357]); A_arbace_go_check_types_A_const_257 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[358]); A_arbace_go_check_types_A_const_258 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[359]); A_arbace_go_check_types_A_const_259 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[360]); A_arbace_go_check_types_A_const_260 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[361]); A_arbace_go_check_types_A_const_261 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[362]); A_arbace_go_check_types_A_const_262 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[363]); A_arbace_go_check_types_A_const_263 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[364]); A_arbace_go_check_types_A_const_264 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[365]) }

func A_arbace_go_check_types_A_clinit_p22() { A_arbace_go_check_types_A_const_265 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[366]); A_arbace_go_check_types_A_const_266 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[367]) }

func A_arbace_go_check_types_A_New() *A_arbace_go_check_types_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_A) Ctor() {}

func (t *A_arbace_go_check_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_A_class }

func (t *A_arbace_go_check_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_A); return ok }

func A_arbace_go_check_types_A_Cast(x any) *A_arbace_go_check_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_A_class)) }; return v }



type A_arbace_go_check_types_alias_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alias_of_A_fn_class *jrt.Class



type A_arbace_go_check_types_alias_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alias_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_align_up_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_align_up_A_fn_class *jrt.Class



type A_arbace_go_check_types_alignof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alignof_A_fn_class *jrt.Class



type A_arbace_go_check_types_alignof_fn__219000253_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alignof_fn__219000253_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_basic_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_basic_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_basic_fn__219000185_A struct{ j2g_header uint64; F_pred any }

var A_arbace_go_check_types_all_basic_fn__219000185_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_boolean_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_boolean_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_complex_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_complex_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_float_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_float_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_integer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_integer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_or_string_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_or_string_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_ordered_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_ordered_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_string_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_string_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_unsigned_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_unsigned_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_basic_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_basic_A_fn_class *jrt.Class



type A_arbace_go_check_types_boolean_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_boolean_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_bound_iface_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_bound_iface_A_fn_class *jrt.Class



type A_arbace_go_check_types_canon_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_canon_A_fn_class *jrt.Class



type A_arbace_go_check_types_canon_kw_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_canon_kw_A_fn_class *jrt.Class



type A_arbace_go_check_types_canon_member_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_canon_member_A_fn_class *jrt.Class



type A_arbace_go_check_types_canon_vec_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_canon_vec_A_fn_class *jrt.Class



type A_arbace_go_check_types_canon_vec_re__219000024_A struct{ j2g_header uint64; F_t any }

var A_arbace_go_check_types_canon_vec_re__219000024_A_fn_class *jrt.Class



type A_arbace_go_check_types_common_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_common_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_comparable_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A struct{ j2g_header uint64; F_seen, F_dynamic any }

var A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A_fn_class *jrt.Class



type A_arbace_go_check_types_complex_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_complex_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_consolidate_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_consolidate_A_fn_class *jrt.Class



type A_arbace_go_check_types_const_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_const_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_core_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_core_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_default_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_default_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_deref_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_deref_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_empty_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_empty_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_eval219000004_A struct{ jrt.Object }

func A_arbace_go_check_types_eval219000004_A_New() *A_arbace_go_check_types_eval219000004_A { t := &A_arbace_go_check_types_eval219000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_eval219000004_A) Ctor() {}

func (t *A_arbace_go_check_types_eval219000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_eval219000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_eval219000004_A_class }

func (t *A_arbace_go_check_types_eval219000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_eval219000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_eval219000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_eval219000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_eval219000004_A); return ok }

func A_arbace_go_check_types_eval219000004_A_Cast(x any) *A_arbace_go_check_types_eval219000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_eval219000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_eval219000004_A_class)) }; return v }



type A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_fn_class *jrt.Class



type A_arbace_go_check_types_eval219000008_A struct{ jrt.Object }

func A_arbace_go_check_types_eval219000008_A_New() *A_arbace_go_check_types_eval219000008_A { t := &A_arbace_go_check_types_eval219000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_eval219000008_A) Ctor() {}

func (t *A_arbace_go_check_types_eval219000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_eval219000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_eval219000008_A_class }

func (t *A_arbace_go_check_types_eval219000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_eval219000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_eval219000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_eval219000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_eval219000008_A); return ok }

func A_arbace_go_check_types_eval219000008_A_Cast(x any) *A_arbace_go_check_types_eval219000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_eval219000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_eval219000008_A_class)) }; return v }



type A_arbace_go_check_types_eval219000008_fn__219000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_eval219000008_fn__219000009_A_fn_class *jrt.Class



type A_arbace_go_check_types_exported_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_exported_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_field_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_field_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_flag_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_flag_A_fn_class *jrt.Class



type A_arbace_go_check_types_float_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_float_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_m__219000013_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class *jrt.Class



type A_arbace_go_check_types_has_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_name_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_has_nil_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_nil_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A_fn_class *jrt.Class



type A_arbace_go_check_types_has_terms_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_terms_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_identical_ignore_tags_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_identical_ignore_tags_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_iface_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_iface_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_iface_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_iface_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_ignore_tags_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ignore_tags_A_fn_class *jrt.Class



type A_arbace_go_check_types_ignore_tags_fn__219000073_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ignore_tags_fn__219000073_A_fn_class *jrt.Class



type A_arbace_go_check_types_incomparable_cause_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_incomparable_cause_A_fn_class *jrt.Class



type A_arbace_go_check_types_incomparable_cause_cause__219000090_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_incomparable_cause_cause__219000090_A_fn_class *jrt.Class



type A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A struct{ j2g_header uint64; F_cause, F_seen any }

var A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A_fn_class *jrt.Class



type A_arbace_go_check_types_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_info_A_fn_class *jrt.Class



type A_arbace_go_check_types_integer_or_float_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_integer_or_float_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_integer_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_integer_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_kind_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_kind_of_A_fn_class *jrt.Class



type A_arbace_go_check_types_kw_alias_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_kw_alias_A_fn_class *jrt.Class



type A_arbace_go_check_types_kw_alias_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_kw_alias_info_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_lookup_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_impl_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_lookup_impl_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_impl_fn__219000276_A struct{ j2g_header uint64; F_pkg, F_name any }

var A_arbace_go_check_types_lookup_impl_fn__219000276_A_fn_class *jrt.Class



type A_arbace_go_check_types_make_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_make_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_map_same_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_map_same_A_fn_class *jrt.Class



type A_arbace_go_check_types_method_data_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_method_data_A_fn_class *jrt.Class



type A_arbace_go_check_types_method_set_iface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_method_set_iface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_methods_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_methods_of_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_missing_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_fn__219000290_A struct{ j2g_header uint64; F_static, F_V, F_same_QMARK_, F_vu any }

var A_arbace_go_check_types_missing_method_fn__219000290_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A struct{ j2g_header uint64; F_m, F_V any }

var A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_named_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_new_named_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_new_named_A_fn_class *jrt.Class



type A_arbace_go_check_types_new_tparam_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_new_tparam_A_fn_class *jrt.Class



type A_arbace_go_check_types_next_id_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_next_id_A_fn_class *jrt.Class



type A_arbace_go_check_types_numeric_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_offsetsof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_offsetsof_A_fn_class *jrt.Class



type A_arbace_go_check_types_ordered_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ordered_A_fn_class *jrt.Class



type A_arbace_go_check_types_ordered_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ordered_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_params_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_params_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_params_str_fn__219000225_A struct{ j2g_header uint64; F_ps, F_variadic any }

var A_arbace_go_check_types_params_str_fn__219000225_A_fn_class *jrt.Class



type A_arbace_go_check_types_pointer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_pointer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_same_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_same_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_same_id_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_same_id_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_satisfies_cause_A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_comparability__219000295_A struct{ j2g_header uint64; F_Tts, F_V any }

var A_arbace_go_check_types_satisfies_cause_comparability__219000295_A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A_fn_class *jrt.Class



type A_arbace_go_check_types_sig_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sig_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_sizeof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sizeof_A_fn_class *jrt.Class



type A_arbace_go_check_types_sort_methods_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sort_methods_A_fn_class *jrt.Class



type A_arbace_go_check_types_sort_methods_fn__219000286_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sort_methods_fn__219000286_A_fn_class *jrt.Class



type A_arbace_go_check_types_strictly_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_string_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_string_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_sync_atomic_align64_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_disjoint_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_includes_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_includes_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_intersect_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_intersect_A_fn_class *jrt.Class



type A_arbace_go_check_types_term_subset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_subset_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_union_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_union_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_includes_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_includes_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A struct{ j2g_header uint64; F_t any }

var A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_intersect_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A struct{ j2g_header uint64; F_y any }

var A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A struct{ j2g_header uint64; F_iter__219000120, F_s__219000121, F_y any }

var A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A struct{ j2g_header uint64; F_a any }

var A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A struct{ j2g_header uint64; F_iter__219000122, F_s__219000123, F_a any }

var A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A struct{ j2g_header uint64; F_b__219000125 any; F_size__1927001038__auto__ int32; F_a, F_c__1927001037__auto__ any }

var A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_norm_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_norm_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_norm_fn__219000115_A struct{ j2g_header uint64; F_i int64; F_n int32; F_used, F_ts any }

var A_arbace_go_check_types_terms_norm_fn__219000115_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000208__219000212_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_str_iter__219000208__219000212_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A struct{ j2g_header uint64; F_iter__219000208, F_s__219000209 any }

var A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A struct{ j2g_header uint64; F_b__219000211 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_subset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_subset_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A struct{ j2g_header uint64; F_yl any }

var A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_superset_of_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_superset_of_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A struct{ j2g_header uint64; F_y any }

var A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_union_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_union_A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_iface_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_iface_A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A struct{ j2g_header uint64; F_seen any }

var A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_empty_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tset_empty_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_type_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000239__219000243_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_type_str_iter__219000239__219000243_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A struct{ j2g_header uint64; F_s__219000240, F_iter__219000239 any }

var A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A struct{ j2g_header uint64; F_b__219000242 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A_fn_class *jrt.Class



type A_arbace_go_check_types_typed_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typed_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_all_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_all_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_all_fn__219000175_A struct{ j2g_header uint64; F_f any }

var A_arbace_go_check_types_typeset_all_fn__219000175_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_pairs_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A struct{ j2g_header uint64; F_iter__219000157, F_s__219000158 any }

var A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A struct{ j2g_header uint64; F_b__219000160 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A_fn_class *jrt.Class



type A_arbace_go_check_types_uintptr_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_uintptr_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_unalias_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_unalias_A_fn_class *jrt.Class



type A_arbace_go_check_types_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_under_is_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_under_is_A_fn_class *jrt.Class



type A_arbace_go_check_types_under_is_fn__219000181_A struct{ j2g_header uint64; F_f any }

var A_arbace_go_check_types_under_is_fn__219000181_A_fn_class *jrt.Class



type A_arbace_go_check_types_union_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_union_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_unsafe_pointer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_unsafe_pointer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_unsigned_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_unsigned_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_untyped_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_untyped_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_update_info_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_update_info_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_types_valid_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_valid_QMARK__A_fn_class *jrt.Class
