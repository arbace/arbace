//line aot_arbace_go_check_types.ae:1
package aot_arbace_go_check_types

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_const"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_New() *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_types_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_types_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_go_check_types_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_1, A_arbace_go_check_types_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_types_eval219000008_fn__219000009_A_New() *A_arbace_go_check_types_eval219000008_fn__219000009_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_eval219000008_fn__219000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_types_eval219000008_fn__219000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_types_eval219000008_fn__219000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_go_check_types_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_types_A_const_8.GetRawRoot__O(), A_arbace_go_check_types_A_const_9) }






















func A_arbace_go_check_types_fn__219000012_A_New() *A_arbace_go_check_types_fn__219000012_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_A) Invoke_O__O(self any) any { var m__1 any; var tmp1 any = A_arbace_go_check_types_fn__219000012_m__219000013_A_New(); var tmp2 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, true); A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class = fncls__31d; tmp2 = fncls__31d } else { tmp2 = fncls__31 }; m__1 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp1, tmp2, nil, 2); var root_32 any =
										A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_36 any = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_14, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_16), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_17, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_19, A_arbace_go_check_types_A_const_20, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_21, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_23, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_25, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_26, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_28, A_arbace_go_check_types_A_const_20, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_29, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_30, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_31, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_32, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_33, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_34), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_35, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_34), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_36, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_37), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_38, A_arbace_go_check_types_A_const_39, A_arbace_go_check_types_A_const_37), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_40, A_arbace_go_check_types_A_const_39, A_arbace_go_check_types_A_const_41), lang.IFn_Cast(m__1).Invoke_O_O__O(A_arbace_go_check_types_A_const_42, A_arbace_go_check_types_A_const_24), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_43, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_16, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_46, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_47, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_48, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_34, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_49, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_37, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_50, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_41, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_51, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_52, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_53, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_18))); if linked_33 == nil { return ifn_34.Invoke_O_O__O(arg_35, arg_36) } else { return linked_33.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_32, arg_35, arg_36) } }
//line :24:1
func A_arbace_go_check_types_fn__219000012_m__219000013_A_New() *A_arbace_go_check_types_fn__219000012_m__219000013_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_m__219000013_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_A) DoInvoke_O_O_O_O__O(self, n__1, size__2, flags__3 any) any { var tmp1 any; var root_20 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_11, size__2, A_arbace_go_check_types_A_const_12, n__1)); var arg_24 any; var root_25 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any; var tmp2 any = A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; arg_28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_29 any = flags__3; if linked_26 == nil { arg_24 = ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { arg_24 = linked_26.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) }; if linked_21 == nil { tmp1 = ifn_22.Invoke_O_O__O(arg_23, arg_24) } else { tmp1 = linked_21.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_20, arg_23, arg_24) }; return lang.Tuple_Create_O_O__IPersistentVector(n__1, tmp1) }
//line :24:1
func A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_New() *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A) Invoke_O_O__O(self, f__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(f__1, jrt.Boolean_TRUE.Ref()) }











































func A_arbace_go_check_types_kw_alias_A_New() *A_arbace_go_check_types_kw_alias_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_kw_alias_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_go_check_types_kw_alias_A) Ctor() {}
//line :68:1
func (t *A_arbace_go_check_types_kw_alias_A) Invoke_O_O_O_O_O__O(self, x__0, name__1, pkg__2, actual__3 any) any { var k__5 any; var root_37 any = A_arbace_go_check_types_A_const_54.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_39 lang.IFn; if



	linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = Lit_20; var arg_41 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_21, nil, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.System_IdentityHashCode_O__I(x__0)).Ref(), nil, name__1)).Ref(); if linked_38 == nil { k__5 = ifn_39.Invoke_O_O__O(arg_40, arg_41) } else { k__5 = linked_38.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O_O__O(root_37, arg_40, arg_41) };
	jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_go_check_types_A_const_55.GetRawRoot__O())).PutIfAbsent_O_O__O(k__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_56, actual__3, A_arbace_go_check_types_A_const_12, name__1, A_arbace_go_check_types_A_const_57, pkg__2, A_arbace_go_check_types_A_const_58, x__0))); return k__5 }


func A_arbace_go_check_types_kw_alias_info_A_New() *A_arbace_go_check_types_kw_alias_info_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_kw_alias_info_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_go_check_types_kw_alias_info_A) Ctor() {}
//line :76:1
func (t *A_arbace_go_check_types_kw_alias_info_A) Invoke_O_O__O(self, k__0 any) any { var tmp1 any; var root_42 any = A_arbace_go_check_types_A_const_59.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = k__0; if linked_43 == nil { tmp1 = ifn_44.Invoke_O__O(arg_45) } else { tmp1 = linked_43.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_42, arg_45) }; if jrt.J2g_Truth(tmp1) { return jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_go_check_types_A_const_55.GetRawRoot__O())).Get_O__O(k__0) } else { return nil } }

func A_arbace_go_check_types_canon_kw_A_New() *A_arbace_go_check_types_canon_kw_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_canon_kw_A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_go_check_types_canon_kw_A) Ctor() {}
//line :78:1
func (t *A_arbace_go_check_types_canon_kw_A) Invoke_O_O__O(self, t__0 any) any { var G__219000020__2_ any = t__0; switch


	lang.Util_Hash_O__I_NoInit(G__219000020__2_) >> 1 & 1 { case 0: if any(G__219000020__2_) == any(A_arbace_go_check_types_A_const_52) { return A_arbace_go_check_types_A_const_26 }; case 1: if any(G__219000020__2_) == any(A_arbace_go_check_types_A_const_53) { return A_arbace_go_check_types_A_const_21 }; default:}; var tmp1 any; var root_47 any =


	A_arbace_go_check_types_A_const_59.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = t__0; if linked_48 == nil { tmp1 = ifn_49.Invoke_O__O(arg_50) } else { tmp1 = linked_48.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_47, arg_50) }; if jrt.J2g_Truth(tmp1) { var temp__1927000408__auto____3 any; var root_51 any = A_arbace_go_check_types_A_const_60.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, A_arbace_go_check_types_kw_alias_info_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = t__0; if linked_52 == nil { temp__1927000408__auto____3 = ifn_53.Invoke_O__O(arg_54) } else { temp__1927000408__auto____3 = linked_52.(*A_arbace_go_check_types_kw_alias_info_A).Invoke_O_O__O(root_51, arg_54) }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var a__4 any = temp__1927000408__auto____3; var root_55 any = A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, A_arbace_go_check_types_canon_kw_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = A_arbace_go_check_types_A_const_56.Invoke_O__O(a__4); if linked_56 == nil { return ifn_57.Invoke_O__O(arg_58) } else { return linked_56.(*A_arbace_go_check_types_canon_kw_A).Invoke_O_O__O(root_55, arg_58) } } else { return t__0 } } else { return t__0 } }



func A_arbace_go_check_types_canon_vec_A_New() *A_arbace_go_check_types_canon_vec_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_canon_vec_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_go_check_types_canon_vec_A) Ctor() {}
//line :88:1
func (t *A_arbace_go_check_types_canon_vec_A) Invoke_O_O__O(self, t__0 any) any { var G__219000024__2_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)); switch
										lang.Util_Hash_O__I_NoInit(G__219000024__2_) >> 5 & 31 { case 0: if any(G__219000024__2_) == any(A_arbace_go_check_types_A_const_62) {












		var root_60 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any; var root_65 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = A_arbace_go_check_types_A_const_64; var arg_69 any; var root_70 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var arg_74 any; var root_75 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = t__0; if linked_76 == nil { arg_74 = ifn_77.Invoke_O__O(arg_78) } else { arg_74 = linked_76.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_75, arg_78) }; if linked_71 == nil { arg_69 = ifn_72.Invoke_O_O__O(arg_73, arg_74) } else { arg_69 = linked_71.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_70, arg_73, arg_74) }; if linked_66 == nil { arg_63 = ifn_67.Invoke_O_O__O(arg_68, arg_69) } else { arg_63 = linked_66.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_65, arg_68, arg_69) }; var arg_64 any = lang.RT_Meta_O__IPersistentMap_NoInit(t__0); if linked_61 == nil { return ifn_62.Invoke_O_O__O(arg_63, arg_64) } else { return linked_61.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_60, arg_63, arg_64) } }
//line :89:1
	case 1: if any(G__219000024__2_) == any(A_arbace_go_check_types_A_const_67) {











		var root_79 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any; var tmp1 any = A_arbace_go_check_types_A_const_67; var tmp2 any; var root_84 any = A_arbace_go_check_types_A_const_68.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any; var tmp3 any = A_arbace_go_check_types_canon_vec_fn__219000025_A_New(); var tmp4 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_go_check_types_canon_vec_fn__219000025_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_go_check_types_canon_vec_fn__219000025_A_fn_class = fncls__95d; tmp4 = fncls__95d } else { tmp4 = fncls__95 }; arg_87 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_88 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_85 == nil { tmp2 = ifn_86.Invoke_O_O__O(arg_87, arg_88) } else { tmp2 = linked_85.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_84, arg_87, arg_88) }; arg_82 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp1, tmp2, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2))); var arg_83 any = lang.RT_Meta_O__IPersistentMap_NoInit(t__0); if linked_80 == nil { return ifn_81.Invoke_O_O__O(arg_82, arg_83) } else { return linked_80.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_79, arg_82, arg_83) } }
//line :89:1
	case 3: if any(G__219000024__2_) == any(A_arbace_go_check_types_A_const_71) { var e__3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var c__4 any; var root_96 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, A_arbace_go_check_types_canon_A_fn_class); var ifn_98 lang.IFn

		if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = e__3; if linked_97 == nil { c__4 = ifn_98.Invoke_O__O(arg_99) } else { c__4 = linked_97.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_96, arg_99) }; if lang.Util_Identical_O_O__Z_NoInit(e__3, c__4) { return t__0 } else { var root_100 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)), c__4); var arg_104 any = lang.RT_Meta_O__IPersistentMap_NoInit(t__0); if linked_101 == nil { return ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { return linked_101.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_100, arg_103, arg_104) } } }
//line :89:1
	case 4: if any(G__219000024__2_) == any(A_arbace_go_check_types_A_const_72) { var e__3_2 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var c__4_2 any; var root_105 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, A_arbace_go_check_types_canon_A_fn_class); var ifn_107 lang.IFn


		if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = e__3_2; if linked_106 == nil { c__4_2 = ifn_107.Invoke_O__O(arg_108) } else { c__4_2 = linked_106.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_105, arg_108) }; if lang.Util_Identical_O_O__Z_NoInit(e__3_2, c__4_2) { return t__0 } else { var root_109 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var tmp5 any = A_arbace_go_check_types_A_const_72; var arg_112 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)), c__4_2); var arg_113 any = lang.RT_Meta_O__IPersistentMap_NoInit(t__0); if linked_110 == nil { return ifn_111.Invoke_O_O__O(arg_112, arg_113) } else { return linked_110.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_109, arg_112, arg_113) } } }
//line :89:1
	case 5: if any(G__219000024__2_) == any(A_arbace_go_check_types_A_const_73) { return t__0 }; case 8: if any(G__219000024__2_) == any(A_arbace_go_check_types_A_const_74) { var k__3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var v__4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var ck__5 any; var root_114 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, A_arbace_go_check_types_canon_A_fn_class); var ifn_116 lang.IFn




		if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = k__3; if linked_115 == nil { ck__5 = ifn_116.Invoke_O__O(arg_117) } else { ck__5 = linked_115.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_114, arg_117) }
//line :89:1
		var cv__6 any; var root_118 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, A_arbace_go_check_types_canon_A_fn_class); var ifn_120 lang.IFn




		if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = v__4; if linked_119 == nil { cv__6 = ifn_120.Invoke_O__O(arg_121) } else { cv__6 = linked_119.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_118, arg_121) }
		var tmp6 bool; var and__1927000168__auto____7 bool = lang.Util_Identical_O_O__Z_NoInit(k__3, ck__5); if and__1927000168__auto____7 { tmp6 = lang.Util_Identical_O_O__Z_NoInit(v__4, cv__6) } else { tmp6 = and__1927000168__auto____7 }; if tmp6 { return t__0 } else { var root_122 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_74, ck__5, cv__6); var arg_126 any = lang.RT_Meta_O__IPersistentMap_NoInit(t__0); if linked_123 == nil { return ifn_124.Invoke_O_O__O(arg_125, arg_126) } else { return linked_123.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_122, arg_125, arg_126) } } }
//line :89:1
	case 14: if any(G__219000024__2_) == any(A_arbace_go_check_types_A_const_75) { var e__3_3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var c__4_3 any; var root_127 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, A_arbace_go_check_types_canon_A_fn_class); var ifn_129 lang.IFn

		if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = e__3_3; if linked_128 == nil { c__4_3 = ifn_129.Invoke_O__O(arg_130) } else { c__4_3 = linked_128.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_127, arg_130) }; if lang.Util_Identical_O_O__Z_NoInit(e__3_3, c__4_3) { return t__0 } else { var root_131 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)), c__4_3); var arg_135 any = lang.RT_Meta_O__IPersistentMap_NoInit(t__0); if linked_132 == nil { return ifn_133.Invoke_O_O__O(arg_134, arg_135) } else { return linked_132.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_131, arg_134, arg_135) } } }
//line :89:1
	case 16: if any(G__219000024__2_) == any(A_arbace_go_check_types_A_const_76) { var e__3_4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var c__4_4 any; var root_136 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, A_arbace_go_check_types_canon_A_fn_class); var ifn_138 lang.IFn



		if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = e__3_4; if linked_137 == nil { c__4_4 = ifn_138.Invoke_O__O(arg_139) } else { c__4_4 = linked_137.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_136, arg_139) }; if lang.Util_Identical_O_O__Z_NoInit(e__3_4, c__4_4) { return t__0 } else { var root_140 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var tmp7 any = A_arbace_go_check_types_A_const_76; var arg_143 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp7, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)), c__4_4); var arg_144 any = lang.RT_Meta_O__IPersistentMap_NoInit(t__0); if linked_141 == nil { return ifn_142.Invoke_O_O__O(arg_143, arg_144) } else { return linked_141.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_140, arg_143, arg_144) } } }
//line :89:1
	case 17: if any(G__219000024__2_) == any(A_arbace_go_check_types_A_const_77) { return t__0 }; case 27: if any(G__219000024__2_) == any(A_arbace_go_check_types_A_const_78) { var vec__219000027__3 any = t__0; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000027__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000027__3, lang.RT_IntCast_J__I_NoInit(1), nil); var rs__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000027__3, lang.RT_IntCast_J__I_NoInit(2), nil); var v__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000027__3, lang.RT_IntCast_J__I_NoInit(3), nil); var cps__8 any; var root_145 any = A_arbace_go_check_types_A_const_68.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_147 lang.IFn; _ = ___4






		if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var arg_149 any = ps__5; if linked_146 == nil { cps__8 = ifn_147.Invoke_O_O__O(arg_148, arg_149) } else { cps__8 = linked_146.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_145, arg_148, arg_149) }
//line :89:1
		var crs__9 any; var root_150 any = A_arbace_go_check_types_A_const_68.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_152 lang.IFn






		if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var arg_154 any = rs__6; if linked_151 == nil { crs__9 = ifn_152.Invoke_O_O__O(arg_153, arg_154) } else { crs__9 = linked_151.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_150, arg_153, arg_154) }
		var tmp8 any; var and__1927000168__auto____10 bool = lang.Util_Equiv_O_O__Z_NoInit(ps__5, cps__8); if and__1927000168__auto____10 { var and__1927000168__auto____11 any; var root_155 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); var arg_159 any; var root_160 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = A_arbace_go_check_types_A_const_81.GetRawRoot__O(); var arg_164 any = ps__5; var arg_165 any = cps__8; if linked_161 == nil { arg_159 = ifn_162.Invoke_O_O_O__O(arg_163, arg_164, arg_165) } else { arg_159 = linked_161.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_160, arg_163, arg_164, arg_165) }; if linked_156 == nil { and__1927000168__auto____11 = ifn_157.Invoke_O_O__O(arg_158, arg_159) } else { and__1927000168__auto____11 = linked_156.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_155, arg_158, arg_159) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_166 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); var arg_170 any; var root_171 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = A_arbace_go_check_types_A_const_81.GetRawRoot__O(); var arg_175 any = rs__6; var arg_176 any = crs__9; if linked_172 == nil { arg_170 = ifn_173.Invoke_O_O_O__O(arg_174, arg_175, arg_176) } else { arg_170 = linked_172.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_171, arg_174, arg_175, arg_176) }; if linked_167 == nil { tmp8 = ifn_168.Invoke_O_O__O(arg_169, arg_170) } else { tmp8 = linked_167.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_166, arg_169, arg_170) } } else { tmp8 = and__1927000168__auto____11 } } else { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }; if jrt.J2g_Truth(tmp8) { return t__0 } else {

			var root_177 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_78, cps__8, crs__9, v__7); var arg_181 any = lang.RT_Meta_O__IPersistentMap_NoInit(t__0); if linked_178 == nil { return ifn_179.Invoke_O_O__O(arg_180, arg_181) } else { return linked_178.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_177, arg_180, arg_181) } } }
//line :89:1
	case 31: if any(G__219000024__2_) == any(A_arbace_go_check_types_A_const_82) {










		var root_182 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any; var tmp9 any = A_arbace_go_check_types_A_const_82; var tmp10 any; var root_187 any = A_arbace_go_check_types_A_const_68.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any; var tmp11 any = A_arbace_go_check_types_canon_vec_fn__219000030_A_New(); var tmp12 *jrt.Class; var fncls__198 *jrt.Class = A_arbace_go_check_types_canon_vec_fn__219000030_A_fn_class; if fncls__198 == nil { var fncls__198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_go_check_types_canon_vec_fn__219000030_A_fn_class = fncls__198d; tmp12 = fncls__198d } else { tmp12 = fncls__198 }; arg_190 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_191 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_188 == nil { tmp10 = ifn_189.Invoke_O_O__O(arg_190, arg_191) } else { tmp10 = linked_188.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_187, arg_190, arg_191) }; arg_185 = lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10); var arg_186 any = lang.RT_Meta_O__IPersistentMap_NoInit(t__0); if linked_183 == nil { return ifn_184.Invoke_O_O__O(arg_185, arg_186) } else { return linked_183.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_182, arg_185, arg_186) } }
//line :89:1
	default:}; return t__0 }










func A_arbace_go_check_types_canon_vec_fn__219000030_A_New() *A_arbace_go_check_types_canon_vec_fn__219000030_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_canon_vec_fn__219000030_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_go_check_types_canon_vec_fn__219000030_A) Ctor() {}
//line :100:1
func (t *A_arbace_go_check_types_canon_vec_fn__219000030_A) Invoke_O_O__O(self, p1__219000022_SHARP___1 any) any { var root_192 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = p1__219000022_SHARP___1; var arg_196 any = A_arbace_go_check_types_A_const_70; var arg_197 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); if linked_193 == nil { return ifn_194.Invoke_O_O_O__O(arg_195, arg_196, arg_197) } else { return linked_193.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_192, arg_195, arg_196, arg_197) } }
func A_arbace_go_check_types_canon_vec_fn__219000025_A_New() *A_arbace_go_check_types_canon_vec_fn__219000025_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_canon_vec_fn__219000025_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_check_types_canon_vec_fn__219000025_A) Ctor() {}
//line :101:1
func (t *A_arbace_go_check_types_canon_vec_fn__219000025_A) Invoke_O_O__O(self, p1__219000023_SHARP___1 any) any { var root_89 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = p1__219000023_SHARP___1; var arg_93 any = A_arbace_go_check_types_A_const_70; var arg_94 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); if linked_90 == nil { return ifn_91.Invoke_O_O_O__O(arg_92, arg_93, arg_94) } else { return linked_90.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_89, arg_92, arg_93, arg_94) } }



func A_arbace_go_check_types_canon_A_New() *A_arbace_go_check_types_canon_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_canon_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_go_check_types_canon_A) Ctor() {}
//line :105:1
func (t *A_arbace_go_check_types_canon_A) Invoke_O_O__O(self, t__0 any) any {



	var tmp1 any; var root_199 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_201 lang.IFn
	if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = A_arbace_go_check_types_A_const_84.Get__O(); if linked_200 == nil { tmp1 = ifn_201.Invoke_O__O(arg_202) } else { tmp1 = linked_200.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_199, arg_202) }
//line :109:1
	if jrt.J2g_Truth(tmp1) { return t__0 } else { var tmp2 any; var root_203 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_205 lang.IFn

		if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = t__0; if linked_204 == nil { tmp2 = ifn_205.Invoke_O__O(arg_206) } else { tmp2 = linked_204.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_203, arg_206) }
//line :109:1
		if jrt.J2g_Truth(tmp2) {

			var root_207 any = A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, A_arbace_go_check_types_canon_kw_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = t__0; if linked_208 == nil { return ifn_209.Invoke_O__O(arg_210) } else { return linked_208.(*A_arbace_go_check_types_canon_kw_A).Invoke_O_O__O(root_207, arg_210) } } else {
//line :109:1
				var tmp3 any; var root_211 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_213 lang.IFn


				if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = t__0; if linked_212 == nil { tmp3 = ifn_213.Invoke_O__O(arg_214) } else { tmp3 = linked_212.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_211, arg_214) }
//line :109:1
				if jrt.J2g_Truth(tmp3) {


					var root_215 any = A_arbace_go_check_types_A_const_87.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, A_arbace_go_check_types_canon_vec_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = t__0; if linked_216 == nil { return ifn_217.Invoke_O__O(arg_218) } else { return linked_216.(*A_arbace_go_check_types_canon_vec_A).Invoke_O_O__O(root_215, arg_218) } } else {
//line :109:1
						if A_arbace_go_check_types_A_const_88 != nil { return t__0 } else { return nil
						}
					}
			}
	}
}
func A_arbace_go_check_types_same_QMARK__A_New() *A_arbace_go_check_types_same_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_same_QMARK__A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_go_check_types_same_QMARK__A) Ctor() {}
//line :115:1
func (t *A_arbace_go_check_types_same_QMARK__A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(x__0, y__1); if or__1927000174__auto____3 {


	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var and__1927000168__auto____4 any = A_arbace_go_check_types_A_const_84.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp1 any; var root_219 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, A_arbace_go_check_types_canon_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = x__0; if linked_220 == nil { tmp1 = ifn_221.Invoke_O__O(arg_222) } else { tmp1 = linked_220.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_219, arg_222) }; var tmp2 any = tmp1; var tmp3 any; var root_223 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, A_arbace_go_check_types_canon_A_fn_class); var ifn_225 lang.IFn; if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = y__1; if linked_224 == nil { tmp3 = ifn_225.Invoke_O__O(arg_226) } else { tmp3 = linked_224.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_223, arg_226) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { return and__1927000168__auto____4 } } }




func A_arbace_go_check_types_next_id_A_New() *A_arbace_go_check_types_next_id_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_next_id_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_go_check_types_next_id_A) Ctor() {}
//line :123:1
func (t *A_arbace_go_check_types_next_id_A) InvokePrim_O__J(self any) int64 { return jrt.Number_Cast(lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(A_arbace_go_check_types_A_const_89.GetRawRoot__O(), Lit_30, false)).LongValue__J() }
//line :123:1
func (t *A_arbace_go_check_types_next_id_A) Invoke_O__O(self any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O__J(self)).Ref() }

func A_arbace_go_check_types_named_QMARK__A_New() *A_arbace_go_check_types_named_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_QMARK__A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_go_check_types_named_QMARK__A) Ctor() {}
//line :125:1
func (t *A_arbace_go_check_types_named_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_227 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = t__0; if linked_228 == nil { and__1927000168__auto____2 = ifn_229.Invoke_O__O(arg_230) } else { and__1927000168__auto____2 = linked_228.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_227, arg_230) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_73; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_tparam_QMARK__A_New() *A_arbace_go_check_types_tparam_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_QMARK__A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_go_check_types_tparam_QMARK__A) Ctor() {}
//line :126:1
func (t *A_arbace_go_check_types_tparam_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_231 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = t__0; if linked_232 == nil { and__1927000168__auto____2 = ifn_233.Invoke_O__O(arg_234) } else { and__1927000168__auto____2 = linked_232.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_231, arg_234) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_77; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_info_A_New() *A_arbace_go_check_types_info_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_info_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_go_check_types_info_A) Ctor() {}
//line :127:1
func (t *A_arbace_go_check_types_info_A) Invoke_O_O__O(self, t__0 any) any { var root_235 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_236 == nil { return ifn_237.Invoke_O__O(arg_238) } else { return linked_236.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_235, arg_238) } }
func A_arbace_go_check_types_update_info_BANG__A_New() *A_arbace_go_check_types_update_info_BANG__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_update_info_BANG__A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_go_check_types_update_info_BANG__A) Ctor() {}
//line :128:1
func (t *A_arbace_go_check_types_update_info_BANG__A) DoInvoke_O_O_O_O__O(self, t__0, f__1, args__2 any) any { var root_239 any = A_arbace_go_check_types_A_const_90.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var arg_243 any; var root_244 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = f__1; var arg_248 any; var root_250 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_251 == nil { arg_248 = ifn_252.Invoke_O__O(arg_253) } else { arg_248 = linked_251.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_250, arg_253) }; var arg_249 any = args__2; if linked_245 == nil { arg_243 = ifn_246.Invoke_O_O_O__O(arg_247, arg_248, arg_249) } else { arg_243 = linked_245.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_244, arg_247, arg_248, arg_249) }; if linked_240 == nil { ifn_241.Invoke_O_O__O(arg_242, arg_243) } else { linked_240.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_239, arg_242, arg_243) }; return t__0 }

func A_arbace_go_check_types_new_named_A_New() *A_arbace_go_check_types_new_named_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_new_named_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_go_check_types_new_named_A) Ctor() {}
//line :130:1
func (t *A_arbace_go_check_types_new_named_A) Invoke_O_O__O(self, data__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_73; var tmp2 any; var root_254 any = A_arbace_go_check_types_A_const_92.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_256 lang.IFn; if


	linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_93.GetRawRoot__O()); var tmp4 any = A_arbace_go_check_types_A_const_94; var tmp5 any; var root_266 any = A_arbace_go_check_types_A_const_95.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_266, A_arbace_go_check_types_next_id_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; if linked_267 == nil { tmp5 = ifn_268.Invoke__O() } else { tmp5 = jrt.Long_ValueOf_J__Long_NoInit(linked_267.(*A_arbace_go_check_types_next_id_A).InvokePrim_O__J(root_266)).Ref() }; arg_257 = tmp3.Invoke_O_O_O_O_O__O(data__0, tmp4, tmp5, A_arbace_go_check_types_A_const_96, lang.PersistentVector_EMPTY.Ref()); if linked_255 == nil { tmp2 = ifn_256.Invoke_O__O(arg_257) } else { tmp2 = linked_255.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_254, arg_257) }; return /*line :130:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }




func A_arbace_go_check_types_new_tparam_A_New() *A_arbace_go_check_types_new_tparam_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_new_tparam_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_go_check_types_new_tparam_A) Ctor() {}
//line :135:1
func (t *A_arbace_go_check_types_new_tparam_A) Invoke_O_O__O(self, data__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_77; var tmp2 any; var root_269 any = A_arbace_go_check_types_A_const_92.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_271 lang.IFn; if


	linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any; var root_273 any = A_arbace_go_check_types_A_const_93.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = data__0; var arg_277 any = A_arbace_go_check_types_A_const_94; var arg_278 any; var root_279 any = A_arbace_go_check_types_A_const_95.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_279, A_arbace_go_check_types_next_id_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; if linked_280 == nil { arg_278 = ifn_281.Invoke__O() } else { arg_278 = jrt.Long_ValueOf_J__Long_NoInit(linked_280.(*A_arbace_go_check_types_next_id_A).InvokePrim_O__J(root_279)).Ref() }; if linked_274 == nil { arg_272 = ifn_275.Invoke_O_O_O__O(arg_276, arg_277, arg_278) } else { arg_272 = linked_274.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_273, arg_276, arg_277, arg_278) }; if linked_270 == nil { tmp2 = ifn_271.Invoke_O__O(arg_272) } else { tmp2 = linked_270.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_269, arg_272) }; return /*line :135:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }











func A_arbace_go_check_types_named_under_A_New() *A_arbace_go_check_types_named_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_under_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_go_check_types_named_under_A) Ctor() {}
//line :147:1
func (t *A_arbace_go_check_types_named_under_A) Invoke_O_O__O(self, t__0 any) any { { var t__2 any = t__0; var seen__3 any = lang.PersistentHashSet_EMPTY.Ref(); L1: for { var i__4 any; var root_282 any = A_arbace_go_check_types_A_const_97.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, A_arbace_go_check_types_info_A_fn_class); var ifn_284 lang.IFn

	if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = t__2; if linked_283 == nil { i__4 = ifn_284.Invoke_O__O(arg_285) } else { i__4 = linked_283.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_282, arg_285) }
//line :147:1
	var temp__1927000408__auto____5 any = A_arbace_go_check_types_A_const_98.Invoke_O__O(i__4)


	if jrt.J2g_Truth(temp__1927000408__auto____5) { var u__6 any = temp__1927000408__auto____5; var tmp1 any; var root_286 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_288 lang.IFn
		if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = u__6; if linked_287 == nil { tmp1 = ifn_288.Invoke_O__O(arg_289) } else { tmp1 = linked_287.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_286, arg_289) }; if jrt.J2g_Truth(tmp1) {

			var tmp2 any; var root_290 any = A_arbace_go_check_types_A_const_100.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = seen__3; var arg_294 any = u__6; if linked_291 == nil { tmp2 = ifn_292.Invoke_O_O__O(arg_293, arg_294) } else { tmp2 = linked_291.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_290, arg_293, arg_294) }; if jrt.J2g_Truth(tmp2) { return A_arbace_go_check_types_A_const_101 } else {

				var tmp3 any; var root_303 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = seen__3; var arg_307 any = t__2; if linked_304 == nil { tmp3 = ifn_305.Invoke_O_O__O(arg_306, arg_307) } else { tmp3 = linked_304.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_303, arg_306, arg_307) }; t__2, seen__3 = u__6, tmp3; continue L1 } } else {
//line :151:1
					return u__6 } } else {





						var tmp4 any; var and__1927000168__auto____6 any = A_arbace_go_check_types_A_const_102.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_295 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = A_arbace_go_check_types_A_const_103.Invoke_O__O(i__4); if linked_296 == nil { and__1927000168__auto____7 = ifn_297.Invoke_O__O(arg_298) } else { and__1927000168__auto____7 = linked_296.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_295, arg_298) }; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp4 = A_arbace_go_check_types_A_const_58.Invoke_O__O(i__4) } else { tmp4 = and__1927000168__auto____7 } } else { tmp4 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp4) {
							lang.IFn_Cast(A_arbace_go_check_types_A_const_102.Get__O()).Invoke_O__O(t__2)
							var tmp5 *lang.Keyword = A_arbace_go_check_types_A_const_98; var tmp6 any; var root_299 any = A_arbace_go_check_types_A_const_97.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, A_arbace_go_check_types_info_A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = t__2; if linked_300 == nil { tmp6 = ifn_301.Invoke_O__O(arg_302) } else { tmp6 = linked_300.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_299, arg_302) }; if jrt.J2g_Truth(tmp5.Invoke_O__O(tmp6)) { t__2, seen__3 = t__2, seen__3; continue L1 } else { return A_arbace_go_check_types_A_const_101 } } else {
//line :157:1
								return A_arbace_go_check_types_A_const_101 } } } }; /*line :147:1*/panic("j2g: unreachable") }














func A_arbace_go_check_types_under_A_New() *A_arbace_go_check_types_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_go_check_types_under_A) Ctor() {}
//line :162:1
func (t *A_arbace_go_check_types_under_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_308 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_310 lang.IFn
	if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = t__0; if linked_309 == nil { tmp1 = ifn_310.Invoke_O__O(arg_311) } else { tmp1 = linked_309.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_308, arg_311) }
//line :165:1
	if jrt.J2g_Truth(tmp1) {
		var root_312 any = A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, A_arbace_go_check_types_canon_kw_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = t__0; if linked_313 == nil { return ifn_314.Invoke_O__O(arg_315) } else { return linked_313.(*A_arbace_go_check_types_canon_kw_A).Invoke_O_O__O(root_312, arg_315) } } else {
//line :165:1
			var tmp2 any = A_arbace_go_check_types_A_const_73; if lang.Util_Identical_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))) { var u__2 any; var root_316 any = A_arbace_go_check_types_A_const_104.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, A_arbace_go_check_types_named_under_A_fn_class); var ifn_318 lang.IFn

				if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = t__0; if linked_317 == nil { u__2 = ifn_318.Invoke_O__O(arg_319) } else { u__2 = linked_317.(*A_arbace_go_check_types_named_under_A).Invoke_O_O__O(root_316, arg_319) }; var tmp3 any; var root_320 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = u__2; if linked_321 == nil { tmp3 = ifn_322.Invoke_O__O(arg_323) } else { tmp3 = linked_321.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_320, arg_323) }; if jrt.J2g_Truth(tmp3) { var root_324 any = A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, A_arbace_go_check_types_canon_kw_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = u__2; if linked_325 == nil { return ifn_326.Invoke_O__O(arg_327) } else { return linked_325.(*A_arbace_go_check_types_canon_kw_A).Invoke_O_O__O(root_324, arg_327) } } else { return u__2 } } else {
//line :165:1
					var tmp4 any = A_arbace_go_check_types_A_const_77; if lang.Util_Identical_O_O__Z_NoInit(tmp4, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))) {


						var root_328 any = A_arbace_go_check_types_A_const_105.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, A_arbace_go_check_types_tparam_iface_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = t__0; if linked_329 == nil { return ifn_330.Invoke_O__O(arg_331) } else { return linked_329.(*A_arbace_go_check_types_tparam_iface_A).Invoke_O_O__O(root_328, arg_331) } } else {
//line :165:1
							if A_arbace_go_check_types_A_const_88 != nil { return t__0 } else { return nil
							}
						}
				}
		}
}


func A_arbace_go_check_types_basic_A_New() *A_arbace_go_check_types_basic_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_basic_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_go_check_types_basic_A) Ctor() {}
//line :173:1
func (t *A_arbace_go_check_types_basic_A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_332 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, A_arbace_go_check_types_under_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = t__0; if linked_333 == nil { u__2 = ifn_334.Invoke_O__O(arg_335) } else { u__2 = linked_333.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_332, arg_335) }; var tmp1 any; var root_336 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = u__2; if linked_337 == nil { tmp1 = ifn_338.Invoke_O__O(arg_339) } else { tmp1 = linked_337.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_336, arg_339) }; if jrt.J2g_Truth(tmp1) { return u__2 } else { return nil } }
func A_arbace_go_check_types_flag_A_New() *A_arbace_go_check_types_flag_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_flag_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_go_check_types_flag_A) Ctor() {}
//line :174:1
func (t *A_arbace_go_check_types_flag_A) Invoke_O_O_O__O(self, t__0, f__1 any) any { var b__3 any; var root_340 any = A_arbace_go_check_types_A_const_107.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, A_arbace_go_check_types_basic_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = t__0; if linked_341 == nil { b__3 = ifn_342.Invoke_O__O(arg_343) } else { b__3 = linked_341.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_340, arg_343) }; var tmp1 any; var and__1927000168__auto____4 any = b__3; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_go_check_types_A_const_108.GetRawRoot__O()).Invoke_O__O(b__3), f__1) } else { tmp1 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }
func A_arbace_go_check_types_integer_type_QMARK__A_New() *A_arbace_go_check_types_integer_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_integer_type_QMARK__A{}; t.Ctor(); return t }
//line :175:1
func (t *A_arbace_go_check_types_integer_type_QMARK__A) Ctor() {}
//line :175:1
func (t *A_arbace_go_check_types_integer_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_344 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, A_arbace_go_check_types_flag_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = t__0; var arg_348 any = A_arbace_go_check_types_A_const_18; if linked_345 == nil { return ifn_346.Invoke_O_O__O(arg_347, arg_348) } else { return linked_345.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_344, arg_347, arg_348) } }
func A_arbace_go_check_types_unsigned_QMARK__A_New() *A_arbace_go_check_types_unsigned_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_unsigned_QMARK__A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_go_check_types_unsigned_QMARK__A) Ctor() {}
//line :176:1
func (t *A_arbace_go_check_types_unsigned_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_349 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, A_arbace_go_check_types_flag_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = t__0; var arg_353 any = A_arbace_go_check_types_A_const_27; if linked_350 == nil { return ifn_351.Invoke_O_O__O(arg_352, arg_353) } else { return linked_350.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_349, arg_352, arg_353) } }
func A_arbace_go_check_types_float_type_QMARK__A_New() *A_arbace_go_check_types_float_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_float_type_QMARK__A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_go_check_types_float_type_QMARK__A) Ctor() {}
//line :177:1
func (t *A_arbace_go_check_types_float_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_354 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, A_arbace_go_check_types_flag_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = t__0; var arg_358 any = A_arbace_go_check_types_A_const_34; if linked_355 == nil { return ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { return linked_355.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) } }
func A_arbace_go_check_types_complex_type_QMARK__A_New() *A_arbace_go_check_types_complex_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_complex_type_QMARK__A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_go_check_types_complex_type_QMARK__A) Ctor() {}
//line :178:1
func (t *A_arbace_go_check_types_complex_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_359 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, A_arbace_go_check_types_flag_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = t__0; var arg_363 any = A_arbace_go_check_types_A_const_37; if linked_360 == nil { return ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { return linked_360.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_359, arg_362, arg_363) } }
func A_arbace_go_check_types_numeric_QMARK__A_New() *A_arbace_go_check_types_numeric_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_numeric_QMARK__A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_go_check_types_numeric_QMARK__A) Ctor() {}
//line :179:1
func (t *A_arbace_go_check_types_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_364 any = A_arbace_go_check_types_A_const_110.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = t__0; if linked_365 == nil { or__1927000174__auto____2 = ifn_366.Invoke_O__O(arg_367) } else { or__1927000174__auto____2 = linked_365.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_364, arg_367) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_368 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = t__0; if linked_369 == nil { or__1927000174__auto____3 = ifn_370.Invoke_O__O(arg_371) } else { or__1927000174__auto____3 = linked_369.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_368, arg_371) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_372 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, A_arbace_go_check_types_complex_type_QMARK__A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = t__0; if linked_373 == nil { return ifn_374.Invoke_O__O(arg_375) } else { return linked_373.(*A_arbace_go_check_types_complex_type_QMARK__A).Invoke_O_O__O(root_372, arg_375) } } } }
func A_arbace_go_check_types_string_type_QMARK__A_New() *A_arbace_go_check_types_string_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_string_type_QMARK__A{}; t.Ctor(); return t }
//line :180:1
func (t *A_arbace_go_check_types_string_type_QMARK__A) Ctor() {}
//line :180:1
func (t *A_arbace_go_check_types_string_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_376 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, A_arbace_go_check_types_flag_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = t__0; var arg_380 any = A_arbace_go_check_types_A_const_41; if linked_377 == nil { return ifn_378.Invoke_O_O__O(arg_379, arg_380) } else { return linked_377.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_376, arg_379, arg_380) } }
func A_arbace_go_check_types_boolean_type_QMARK__A_New() *A_arbace_go_check_types_boolean_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_boolean_type_QMARK__A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_go_check_types_boolean_type_QMARK__A) Ctor() {}
//line :181:1
func (t *A_arbace_go_check_types_boolean_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_381 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, A_arbace_go_check_types_flag_A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = t__0; var arg_385 any = A_arbace_go_check_types_A_const_16; if linked_382 == nil { return ifn_383.Invoke_O_O__O(arg_384, arg_385) } else { return linked_382.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_381, arg_384, arg_385) } }
func A_arbace_go_check_types_untyped_QMARK__A_New() *A_arbace_go_check_types_untyped_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_untyped_QMARK__A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_go_check_types_untyped_QMARK__A) Ctor() {}
//line :182:1
func (t *A_arbace_go_check_types_untyped_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_386 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = t__0; if linked_387 == nil { and__1927000168__auto____2 = ifn_388.Invoke_O__O(arg_389) } else { and__1927000168__auto____2 = linked_387.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_386, arg_389) }; if jrt.J2g_Truth(and__1927000168__auto____2) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_go_check_types_A_const_108.GetRawRoot__O()).Invoke_O__O(t__0), A_arbace_go_check_types_A_const_45))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_typed_QMARK__A_New() *A_arbace_go_check_types_typed_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typed_QMARK__A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_go_check_types_typed_QMARK__A) Ctor() {}
//line :183:1
func (t *A_arbace_go_check_types_typed_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_390 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any; var root_394 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, A_arbace_go_check_types_untyped_QMARK__A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = t__0; if linked_395 == nil { arg_393 = ifn_396.Invoke_O__O(arg_397) } else { arg_393 = linked_395.(*A_arbace_go_check_types_untyped_QMARK__A).Invoke_O_O__O(root_394, arg_397) }; if linked_391 == nil { return ifn_392.Invoke_O__O(arg_393) } else { return linked_391.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_390, arg_393) } }
func A_arbace_go_check_types_const_type_QMARK__A_New() *A_arbace_go_check_types_const_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_const_type_QMARK__A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_go_check_types_const_type_QMARK__A) Ctor() {}
//line :184:1
func (t *A_arbace_go_check_types_const_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var b__2 any; var root_398 any = A_arbace_go_check_types_A_const_107.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, A_arbace_go_check_types_basic_A_fn_class); var ifn_400 lang.IFn; if


	linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = t__0; if linked_399 == nil { b__2 = ifn_400.Invoke_O__O(arg_401) } else { b__2 = linked_399.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_398, arg_401) }; var and__1927000168__auto____3 any = b__2; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_402 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = lang.IFn_Cast(A_arbace_go_check_types_A_const_114).Invoke_O__O(b__2); if linked_403 == nil { return ifn_404.Invoke_O__O(arg_405) } else { return linked_403.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_402, arg_405) } } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_ordered_QMARK__A_New() *A_arbace_go_check_types_ordered_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ordered_QMARK__A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_go_check_types_ordered_QMARK__A) Ctor() {}
//line :188:1
func (t *A_arbace_go_check_types_ordered_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_406 any = A_arbace_go_check_types_A_const_110.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = t__0; if linked_407 == nil { or__1927000174__auto____2 = ifn_408.Invoke_O__O(arg_409) } else { or__1927000174__auto____2 = linked_407.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_406, arg_409) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_410 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = t__0; if linked_411 == nil { or__1927000174__auto____3 = ifn_412.Invoke_O__O(arg_413) } else { or__1927000174__auto____3 = linked_411.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_410, arg_413) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_414 any = A_arbace_go_check_types_A_const_115.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, A_arbace_go_check_types_string_type_QMARK__A_fn_class); var ifn_416 lang.IFn; if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = t__0; if linked_415 == nil { return ifn_416.Invoke_O__O(arg_417) } else { return linked_415.(*A_arbace_go_check_types_string_type_QMARK__A).Invoke_O_O__O(root_414, arg_417) } } } }
func A_arbace_go_check_types_interface_QMARK__A_New() *A_arbace_go_check_types_interface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_interface_QMARK__A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_go_check_types_interface_QMARK__A) Ctor() {}
//line :189:1
func (t *A_arbace_go_check_types_interface_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_418 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, A_arbace_go_check_types_under_A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = t__0; if linked_419 == nil { u__2 = ifn_420.Invoke_O__O(arg_421) } else { u__2 = linked_419.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_418, arg_421) }; var and__1927000168__auto____3 any; var root_422 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = u__2; if linked_423 == nil { and__1927000168__auto____3 = ifn_424.Invoke_O__O(arg_425) } else { and__1927000168__auto____3 = linked_423.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_422, arg_425) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_67; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_pointer_QMARK__A_New() *A_arbace_go_check_types_pointer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_pointer_QMARK__A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_go_check_types_pointer_QMARK__A) Ctor() {}
//line :190:1
func (t *A_arbace_go_check_types_pointer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_426 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, A_arbace_go_check_types_under_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = t__0; if linked_427 == nil { u__2 = ifn_428.Invoke_O__O(arg_429) } else { u__2 = linked_427.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_426, arg_429) }; var and__1927000168__auto____3 any; var root_430 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = u__2; if linked_431 == nil { and__1927000168__auto____3 = ifn_432.Invoke_O__O(arg_433) } else { and__1927000168__auto____3 = linked_431.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_430, arg_433) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_71; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_unsafe_pointer_QMARK__A_New() *A_arbace_go_check_types_unsafe_pointer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_unsafe_pointer_QMARK__A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_go_check_types_unsafe_pointer_QMARK__A) Ctor() {}
//line :191:1
func (t *A_arbace_go_check_types_unsafe_pointer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_42; var tmp2 any; var root_434 any = A_arbace_go_check_types_A_const_107.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, A_arbace_go_check_types_basic_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = t__0; if linked_435 == nil { tmp2 = ifn_436.Invoke_O__O(arg_437) } else { tmp2 = linked_435.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_434, arg_437) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }
func A_arbace_go_check_types_uintptr_QMARK__A_New() *A_arbace_go_check_types_uintptr_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_uintptr_QMARK__A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_go_check_types_uintptr_QMARK__A) Ctor() {}
//line :192:1
func (t *A_arbace_go_check_types_uintptr_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_32; var tmp2 any; var root_438 any = A_arbace_go_check_types_A_const_107.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, A_arbace_go_check_types_basic_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = t__0; if linked_439 == nil { tmp2 = ifn_440.Invoke_O__O(arg_441) } else { tmp2 = linked_439.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_438, arg_441) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }
func A_arbace_go_check_types_valid_QMARK__A_New() *A_arbace_go_check_types_valid_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_valid_QMARK__A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_go_check_types_valid_QMARK__A) Ctor() {}
//line :193:1
func (t *A_arbace_go_check_types_valid_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_442 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = A_arbace_go_check_types_A_const_101; var arg_446 any = t__0; if linked_443 == nil { return ifn_444.Invoke_O_O__O(arg_445, arg_446) } else { return linked_443.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_442, arg_445, arg_446) } }
func A_arbace_go_check_types_kind_of_A_New() *A_arbace_go_check_types_kind_of_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_kind_of_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_go_check_types_kind_of_A) Ctor() {}
//line :194:1
func (t *A_arbace_go_check_types_kind_of_A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_447 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, A_arbace_go_check_types_under_A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = t__0; if linked_448 == nil { u__2 = ifn_449.Invoke_O__O(arg_450) } else { u__2 = linked_448.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_447, arg_450) }; var tmp1 any; var root_451 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = u__2; if linked_452 == nil { tmp1 = ifn_453.Invoke_O__O(arg_454) } else { tmp1 = linked_452.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_451, arg_454) }; if jrt.J2g_Truth(tmp1) { return u__2 } else { return lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)) } }
func A_arbace_go_check_types_has_name_QMARK__A_New() *A_arbace_go_check_types_has_name_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_name_QMARK__A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_go_check_types_has_name_QMARK__A) Ctor() {}
//line :195:1
func (t *A_arbace_go_check_types_has_name_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_455 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = t__0; if linked_456 == nil { or__1927000174__auto____2 = ifn_457.Invoke_O__O(arg_458) } else { or__1927000174__auto____2 = linked_456.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_455, arg_458) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_459 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_461 lang.IFn; if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = t__0; if linked_460 == nil { or__1927000174__auto____3 = ifn_461.Invoke_O__O(arg_462) } else { or__1927000174__auto____3 = linked_460.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_459, arg_462) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_463 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = t__0; if linked_464 == nil { return ifn_465.Invoke_O__O(arg_466) } else { return linked_464.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_463, arg_466) } } } }
func A_arbace_go_check_types_integer_or_float_QMARK__A_New() *A_arbace_go_check_types_integer_or_float_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_integer_or_float_QMARK__A{}; t.Ctor(); return t }
//line :196:1
func (t *A_arbace_go_check_types_integer_or_float_QMARK__A) Ctor() {}
//line :196:1
func (t *A_arbace_go_check_types_integer_or_float_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_467 any = A_arbace_go_check_types_A_const_110.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = t__0; if linked_468 == nil { or__1927000174__auto____2 = ifn_469.Invoke_O__O(arg_470) } else { or__1927000174__auto____2 = linked_468.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_467, arg_470) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_471 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = t__0; if linked_472 == nil { return ifn_473.Invoke_O__O(arg_474) } else { return linked_472.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_471, arg_474) } } }



func A_arbace_go_check_types_has_nil_QMARK__A_New() *A_arbace_go_check_types_has_nil_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_nil_QMARK__A{}; t.Ctor(); return t }
//line :200:1
func (t *A_arbace_go_check_types_has_nil_QMARK__A) Ctor() {}
//line :200:1
func (t *A_arbace_go_check_types_has_nil_QMARK__A) Invoke_O_O__O(self, t__0 any) any {



	var tmp1 any; var root_475 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = t__0; if linked_476 == nil { tmp1 = ifn_477.Invoke_O__O(arg_478) } else { tmp1 = linked_476.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_475, arg_478) }; if jrt.J2g_Truth(tmp1) {
		var root_479 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, A_arbace_go_check_types_under_is_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = t__0; var arg_483 any; var tmp2 any = A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A_New(); var tmp3 *jrt.Class; var fncls__492 *jrt.Class = A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A_fn_class; if fncls__492 == nil { var fncls__492d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A_fn_class = fncls__492d; tmp3 = fncls__492d } else { tmp3 = fncls__492 }; arg_483 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_480 == nil { return ifn_481.Invoke_O_O__O(arg_482, arg_483) } else { return linked_480.(*A_arbace_go_check_types_under_is_A).Invoke_O_O_O__O(root_479, arg_482, arg_483) } } else {
//line :204:1
			var u__2 any; var root_493 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, A_arbace_go_check_types_under_A_fn_class); var ifn_495 lang.IFn

			if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = t__0; if linked_494 == nil { u__2 = ifn_495.Invoke_O__O(arg_496) } else { u__2 = linked_494.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_493, arg_496) }
//line :204:1
			var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_42, u__2)


			if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_51, u__2); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var and__1927000168__auto____5 any; var root_497 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_499 lang.IFn
				if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = u__2; if linked_498 == nil { and__1927000168__auto____5 = ifn_499.Invoke_O__O(arg_500) } else { and__1927000168__auto____5 = linked_498.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_497, arg_500) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_501 any = A_arbace_go_check_types_A_const_100.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = A_arbace_go_check_types_A_const_121; var arg_505 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)); if linked_502 == nil { return ifn_503.Invoke_O_O__O(arg_504, arg_505) } else { return linked_502.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_501, arg_504, arg_505) } } else { return and__1927000168__auto____5 } } } } }
//line :205:1
func A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A_New() *A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A) Ctor() {}
//line :205:1
func (t *A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A) Invoke_O_O__O(self, u__1 any) any { var and__1927000168__auto____2 any; var root_484 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = u__1; if linked_485 == nil { and__1927000168__auto____2 = ifn_486.Invoke_O__O(arg_487) } else { and__1927000168__auto____2 = linked_485.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_484, arg_487) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_488 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, A_arbace_go_check_types_has_nil_QMARK__A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = u__1; if linked_489 == nil { return ifn_490.Invoke_O__O(arg_491) } else { return linked_489.(*A_arbace_go_check_types_has_nil_QMARK__A).Invoke_O_O__O(root_488, arg_491) } } else { return and__1927000168__auto____2 } }




func A_arbace_go_check_types_empty_interface_QMARK__A_New() *A_arbace_go_check_types_empty_interface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_empty_interface_QMARK__A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_go_check_types_empty_interface_QMARK__A) Ctor() {}
//line :210:1
func (t *A_arbace_go_check_types_empty_interface_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_506 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, A_arbace_go_check_types_under_A_fn_class); var ifn_508 lang.IFn; if
												linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = t__0; if linked_507 == nil { u__2 = ifn_508.Invoke_O__O(arg_509) } else { u__2 = linked_507.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_506, arg_509) }; var and__1927000168__auto____3 any; var root_510 any = /*line :210:1*/A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_512 lang.IFn; if
												linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = u__2; if linked_511 == nil { and__1927000168__auto____3 = ifn_512.Invoke_O__O(arg_513) } else { and__1927000168__auto____3 = linked_511.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_510, arg_513) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_67; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____4 { var and__1927000168__auto____5 any; var root_514 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_515 == nil { and__1927000168__auto____5 = ifn_516.Invoke_O__O(arg_517) } else { and__1927000168__auto____5 = linked_515.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_514, arg_517) }; if jrt.J2g_Truth(and__1927000168__auto____5) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref() } else { return and__1927000168__auto____5 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_default_type_A_New() *A_arbace_go_check_types_default_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_default_type_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_go_check_types_default_type_A) Ctor() {}
//line :213:1
func (t *A_arbace_go_check_types_default_type_A) Invoke_O_O__O(self, t__0 any) any { var G__219000069__2_ any = t__0; switch


	lang.Util_Hash_O__I_NoInit(G__219000069__2_) >> 19 & 7 { case 0: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_49) { return A_arbace_go_check_types_A_const_38 }; case 1: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_43) { return A_arbace_go_check_types_A_const_14 }; case 3: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_48) { return A_arbace_go_check_types_A_const_35 }; case 5: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_46) { return A_arbace_go_check_types_A_const_25 }; case 6: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_50) { return A_arbace_go_check_types_A_const_40 }; case 7: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_47) {
		if jrt.J2g_Truth(A_arbace_go_check_types_A_const_84.Get__O()) { return A_arbace_go_check_types_A_const_53 } else { return A_arbace_go_check_types_A_const_21 } }
//line :216:1
	default:}; return t__0 }




func A_arbace_go_check_types_ignore_tags_A_New() *A_arbace_go_check_types_ignore_tags_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ignore_tags_A{}; t.Ctor(); return t }
//line :221:1
func (t *A_arbace_go_check_types_ignore_tags_A) Ctor() {}
//line :221:1
func (t *A_arbace_go_check_types_ignore_tags_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_519 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = t__0; if linked_520 == nil { and__1927000168__auto____2 = ifn_521.Invoke_O__O(arg_522) } else { and__1927000168__auto____2 = linked_520.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_519, arg_522) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_523 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any; var root_527 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any = t__0; if linked_528 == nil { arg_526 = ifn_529.Invoke_O__O(arg_530) } else { arg_526 = linked_528.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_527, arg_530) }; if linked_524 == nil { and__1927000168__auto____3 = ifn_525.Invoke_O__O(arg_526) } else { and__1927000168__auto____3 = linked_524.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_523, arg_526) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_531 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any; var root_535 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = t__0; if linked_536 == nil { arg_534 = ifn_537.Invoke_O__O(arg_538) } else { arg_534 = linked_536.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_535, arg_538) }; if linked_532 == nil { tmp1 = ifn_533.Invoke_O__O(arg_534) } else { tmp1 = linked_532.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_531, arg_534) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var G__219000072__2_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))
		switch lang.Util_Hash_O__I_NoInit(G__219000072__2_) >> 2 & 15 { case 1: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_74) { var tmp2 any = A_arbace_go_check_types_A_const_74; var tmp3 any; var root_540 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_542 lang.IFn




			if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_541 == nil { tmp3 = ifn_542.Invoke_O__O(arg_543) } else { tmp3 = linked_541.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_540, arg_543) }
//line :225:1
			var tmp4 any = tmp3; var tmp5 any; var root_544 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_546 lang.IFn




			if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_545 == nil { tmp5 = ifn_546.Invoke_O__O(arg_547) } else { tmp5 = linked_545.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_544, arg_547) }
//line :225:1
			return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp4, tmp5) }; case 2: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_75) { var tmp6 any = A_arbace_go_check_types_A_const_75; var tmp7 any; var root_548 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_550 lang.IFn


				if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_549 == nil { tmp7 = ifn_550.Invoke_O__O(arg_551) } else { tmp7 = linked_549.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_548, arg_551) }
//line :225:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7) }; case 3: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_72) { var tmp8 any = A_arbace_go_check_types_A_const_72; var tmp9 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp10 any; var root_552 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_554 lang.IFn



					if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_553 == nil { tmp10 = ifn_554.Invoke_O__O(arg_555) } else { tmp10 = linked_553.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_552, arg_555) }
//line :225:1
					return lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp9, tmp10) }; case 6: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_76) { var tmp11 any = A_arbace_go_check_types_A_const_76; var tmp12 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp13 any; var root_570 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_572 lang.IFn





						if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_571 == nil { tmp13 = ifn_572.Invoke_O__O(arg_573) } else { tmp13 = linked_571.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_570, arg_573) }
//line :225:1
						return lang.Tuple_Create_O_O_O__IPersistentVector(tmp11, tmp12, tmp13) }; case 7: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_62) {







							var root_556 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = A_arbace_go_check_types_A_const_124; var arg_560 any; var root_561 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var arg_565 any; var root_566 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = t__0; if linked_567 == nil { arg_565 = ifn_568.Invoke_O__O(arg_569) } else { arg_565 = linked_567.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_566, arg_569) }; if linked_562 == nil { arg_560 = ifn_563.Invoke_O_O__O(arg_564, arg_565) } else { arg_560 = linked_562.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_561, arg_564, arg_565) }; if linked_557 == nil { return ifn_558.Invoke_O_O__O(arg_559, arg_560) } else { return linked_557.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_556, arg_559, arg_560) } }
//line :225:1
		case 9: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_78) { var tmp14 any = A_arbace_go_check_types_A_const_78; var tmp15 any; var root_574 any = A_arbace_go_check_types_A_const_68.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_576 lang.IFn






			if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var arg_578 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_575 == nil { tmp15 = ifn_576.Invoke_O_O__O(arg_577, arg_578) } else { tmp15 = linked_575.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_574, arg_577, arg_578) }
//line :225:1
			var tmp16 any = tmp15; var tmp17 any; var root_579 any = A_arbace_go_check_types_A_const_68.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_581 lang.IFn






			if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var arg_583 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_580 == nil { tmp17 = ifn_581.Invoke_O_O__O(arg_582, arg_583) } else { tmp17 = linked_580.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_579, arg_582, arg_583) }
//line :225:1
			return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp14, tmp16, tmp17, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(3))) }; case 11: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_71) { var tmp18 any = A_arbace_go_check_types_A_const_71; var tmp19 any; var root_584 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_586 lang.IFn

				if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_585 == nil { tmp19 = ifn_586.Invoke_O__O(arg_587) } else { tmp19 = linked_585.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_584, arg_587) }
//line :225:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp18, tmp19) }; case 13: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_82) { var tmp20 any = A_arbace_go_check_types_A_const_82; var tmp21 any; var root_588 any = A_arbace_go_check_types_A_const_68.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_590 lang.IFn
					if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any; var tmp22 any = A_arbace_go_check_types_ignore_tags_fn__219000073_A_New(); var tmp23 *jrt.Class; var fncls__605 *jrt.Class = A_arbace_go_check_types_ignore_tags_fn__219000073_A_fn_class; if fncls__605 == nil { var fncls__605d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_go_check_types_ignore_tags_fn__219000073_A_fn_class = fncls__605d; tmp23 = fncls__605d } else { tmp23 = fncls__605 }; arg_591 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_592 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_589 == nil { tmp21 = ifn_590.Invoke_O_O__O(arg_591, arg_592) } else { tmp21 = linked_589.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_588, arg_591, arg_592) }
//line :225:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp20, tmp21) }; default:}; return t__0 } else {
//line :224:1
						return t__0
					} }
func A_arbace_go_check_types_ignore_tags_fn__219000073_A_New() *A_arbace_go_check_types_ignore_tags_fn__219000073_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ignore_tags_fn__219000073_A{}; t.Ctor(); return t }
//line :226:1
func (t *A_arbace_go_check_types_ignore_tags_fn__219000073_A) Ctor() {}
//line :226:1
func (t *A_arbace_go_check_types_ignore_tags_fn__219000073_A) Invoke_O_O__O(self, p1__219000071_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_93.GetRawRoot__O()); var tmp2 any = A_arbace_go_check_types_A_const_125; var tmp3 any = A_arbace_go_check_types_A_const_70; var tmp4 any; var root_601 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_603 lang.IFn; if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = A_arbace_go_check_types_A_const_70.Invoke_O__O(p1__219000071_SHARP___1); if linked_602 == nil { tmp4 = ifn_603.Invoke_O__O(arg_604) } else { tmp4 = linked_602.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_601, arg_604) }; return tmp1.Invoke_O_O_O_O_O__O(p1__219000071_SHARP___1, tmp2, nil, tmp3, tmp4) }










func A_arbace_go_check_types_identical_ignore_tags_QMARK__A_New() *A_arbace_go_check_types_identical_ignore_tags_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_identical_ignore_tags_QMARK__A{}; t.Ctor(); return t }
//line :237:1
func (t *A_arbace_go_check_types_identical_ignore_tags_QMARK__A) Ctor() {}
//line :237:1
func (t *A_arbace_go_check_types_identical_ignore_tags_QMARK__A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 any; var root_606 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, A_arbace_go_check_types_canon_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any; var root_610 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = x__0; if linked_611 == nil { arg_609 = ifn_612.Invoke_O__O(arg_613) } else { arg_609 = linked_611.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_610, arg_613) }; if linked_607 == nil { tmp1 = ifn_608.Invoke_O__O(arg_609) } else { tmp1 = linked_607.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_606, arg_609) }; var tmp2 any = tmp1; var tmp3 any; var root_614 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, A_arbace_go_check_types_canon_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any; var root_618 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = y__1; if linked_619 == nil { arg_617 = ifn_620.Invoke_O__O(arg_621) } else { arg_617 = linked_619.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_618, arg_621) }; if linked_615 == nil { tmp3 = ifn_616.Invoke_O__O(arg_617) } else { tmp3 = linked_615.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_614, arg_617) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() }





func A_arbace_go_check_types_tset_comparable_QMARK__A_New() *A_arbace_go_check_types_tset_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_comparable_QMARK__A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__A) Ctor() {}
//line :243:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__A) Invoke_O_O_O__O(self, ts__0, seen__1 any) any {


	var tmp1 any = A_arbace_go_check_types_A_const_126; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_check_types_A_const_127.Invoke_O__O(ts__0)) {
		return A_arbace_go_check_types_A_const_128.Invoke_O__O(ts__0) } else {
//line :246:1
			var and__1927000168__auto____3 any; var root_622 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_624 lang.IFn

			if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = A_arbace_go_check_types_A_const_127.Invoke_O__O(ts__0); if linked_623 == nil { and__1927000168__auto____3 = ifn_624.Invoke_O__O(arg_625) } else { and__1927000168__auto____3 = linked_623.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_622, arg_625) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_626 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any; var tmp2 any = A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A_New_O(seen__1); var tmp3 *jrt.Class; var fncls__636 *jrt.Class = A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A_fn_class; if fncls__636 == nil { var fncls__636d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A_fn_class = fncls__636d; tmp3 = fncls__636d } else { tmp3 = fncls__636 }; arg_629 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_630 any = A_arbace_go_check_types_A_const_127.Invoke_O__O(ts__0); if linked_627 == nil { return ifn_628.Invoke_O_O__O(arg_629, arg_630) } else { return linked_627.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_626, arg_629, arg_630) } } else { return and__1927000168__auto____3 } } }
//line :248:1
func A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A_New_O(p0 any) *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A{}; t.Ctor_O(p0); return t }
//line :248:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A) Ctor_O(c__seen any) { t.F_seen = c__seen }
//line :248:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A) Invoke_O_O__O(self, p__219000077__1 any) any { var vec__219000079__2 any = p__219000077__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000079__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000079__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_631 any = A_arbace_go_check_types_A_const_130.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_633 lang.IFn; _ = ___3; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = ty__4; var arg_635 any = t.F_seen; if linked_632 == nil { return ifn_633.Invoke_O_O__O(arg_634, arg_635) } else { return linked_632.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O_O__O(root_631, arg_634, arg_635) } }

func A_arbace_go_check_types_comparable_type_QMARK__A_New() *A_arbace_go_check_types_comparable_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_type_QMARK__A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__A) Ctor() {}
//line :250:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__A) Invoke_O_O_O_O__O(self, t__0, dynamic__1, seen__2 any) any {




	var tmp1 any; var root_637 any = A_arbace_go_check_types_A_const_100.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = seen__2; var arg_641 any = t__0; if linked_638 == nil { tmp1 = ifn_639.Invoke_O_O__O(arg_640, arg_641) } else { tmp1 = linked_638.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_637, arg_640, arg_641) }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var seen__4 any; var root_642 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_644 lang.IFn

		if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = seen__2; var arg_646 any = t__0; if linked_643 == nil { seen__4 = ifn_644.Invoke_O_O__O(arg_645, arg_646) } else { seen__4 = linked_643.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_642, arg_645, arg_646) }
		var tmp2 any; var root_647 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = t__0; if linked_648 == nil { tmp2 = ifn_649.Invoke_O__O(arg_650) } else { tmp2 = linked_648.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_647, arg_650) }; if jrt.J2g_Truth(tmp2) {
			var tmp3 any; var root_651 any = A_arbace_go_check_types_A_const_131.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any; var root_656 any = A_arbace_go_check_types_A_const_132.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = t__0; if linked_657 == nil { arg_654 = ifn_658.Invoke_O__O(arg_659) } else { arg_654 = linked_657.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_656, arg_659) }; var arg_655 any = seen__4; if linked_652 == nil { tmp3 = ifn_653.Invoke_O_O__O(arg_654, arg_655) } else { tmp3 = linked_652.(*A_arbace_go_check_types_tset_comparable_QMARK__A).Invoke_O_O_O__O(root_651, arg_654, arg_655) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp3)).Ref() } else {
//line :258:1
				var u__5 any; var root_660 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, A_arbace_go_check_types_under_A_fn_class); var ifn_662 lang.IFn

				if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = t__0; if linked_661 == nil { u__5 = ifn_662.Invoke_O__O(arg_663) } else { u__5 = linked_661.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_660, arg_663) }
				var tmp4 any; var root_664 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_666 lang.IFn
				if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = u__5; if linked_665 == nil { tmp4 = ifn_666.Invoke_O__O(arg_667) } else { tmp4 = linked_665.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_664, arg_667) }
//line :261:1
				if jrt.J2g_Truth(tmp4) {
					var root_668 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_668, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_670 lang.IFn; if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = u__5; var arg_672 any = A_arbace_go_check_types_A_const_51; if linked_669 == nil { return ifn_670.Invoke_O_O__O(arg_671, arg_672) } else { return linked_669.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_668, arg_671, arg_672) } } else {
//line :261:1
						if A_arbace_go_check_types_A_const_88 != nil { var G__219000085__6_ any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(0))


							switch lang.Util_Hash_O__I_NoInit(G__219000085__6_) >> 4 & 7 { case 0: if any(G__219000085__6_) == any(A_arbace_go_check_types_A_const_72) {



								var root_674 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(2)); var arg_678 any = dynamic__1; var arg_679 any = seen__4; if linked_675 == nil { return ifn_676.Invoke_O_O_O__O(arg_677, arg_678, arg_679) } else { return linked_675.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_674, arg_677, arg_678, arg_679) } }
//line :264:1
							case 1: if any(G__219000085__6_) == any(A_arbace_go_check_types_A_const_76) { return jrt.Boolean_TRUE.Ref() }; case 3: if any(G__219000085__6_) == any(A_arbace_go_check_types_A_const_67) { var or__1927000174__auto____7 any = dynamic__1

								if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var tmp5 any; var root_680 any = A_arbace_go_check_types_A_const_131.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any; var root_685 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any = u__5; if linked_686 == nil { arg_683 = ifn_687.Invoke_O__O(arg_688) } else { arg_683 = linked_686.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_685, arg_688) }; var arg_684 any = seen__4; if linked_681 == nil { tmp5 = ifn_682.Invoke_O_O__O(arg_683, arg_684) } else { tmp5 = linked_681.(*A_arbace_go_check_types_tset_comparable_QMARK__A).Invoke_O_O_O__O(root_680, arg_683, arg_684) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp5)).Ref() } }
//line :264:1
							case 6: if any(G__219000085__6_) == any(A_arbace_go_check_types_A_const_71) { return jrt.Boolean_TRUE.Ref() }; case 7: if any(G__219000085__6_) == any(A_arbace_go_check_types_A_const_82) {


								var root_689 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any; var tmp6 any = A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A_New_O_O(seen__4, dynamic__1); var tmp7 *jrt.Class; var fncls__700 *jrt.Class = A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A_fn_class; if fncls__700 == nil { var fncls__700d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A_fn_class = fncls__700d; tmp7 = fncls__700d } else { tmp7 = fncls__700 }; arg_692 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_693 any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(1)); if linked_690 == nil { return ifn_691.Invoke_O_O__O(arg_692, arg_693) } else { return linked_690.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_689, arg_692, arg_693) } }
//line :264:1
							default:}; return jrt.Boolean_FALSE.Ref() } else {
//line :261:1
								return nil
							}
					}
			}
	}
}
func A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A{}; t.Ctor_O_O(p0, p1); return t }
//line :267:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A) Ctor_O_O(c__seen, c__dynamic any) { t.F_seen = c__seen; t.F_dynamic = c__dynamic }
//line :267:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A) Invoke_O_O__O(self, p1__219000084_SHARP___1 any) any { var root_694 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = A_arbace_go_check_types_A_const_70.Invoke_O__O(p1__219000084_SHARP___1); var arg_698 any = t.F_dynamic; var arg_699 any = t.F_seen; if linked_695 == nil { return ifn_696.Invoke_O_O_O__O(arg_697, arg_698, arg_699) } else { return linked_695.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_694, arg_697, arg_698, arg_699) } }



func A_arbace_go_check_types_strictly_comparable_QMARK__A_New() *A_arbace_go_check_types_strictly_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_strictly_comparable_QMARK__A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Ctor() {}
//line :271:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Invoke_O_O_O__O(self, t__0, seen__1 any) any { var root_701 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = t__0; var arg_705 any = jrt.Boolean_FALSE.Ref(); var arg_706 any = seen__1; if linked_702 == nil { return ifn_703.Invoke_O_O_O__O(arg_704, arg_705, arg_706) } else { return linked_702.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_701, arg_704, arg_705, arg_706) } }
//line :271:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_707 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = t__0; var arg_711 any = jrt.Boolean_FALSE.Ref(); var arg_712 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_708 == nil { return ifn_709.Invoke_O_O_O__O(arg_710, arg_711, arg_712) } else { return linked_708.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_707, arg_710, arg_711, arg_712) } }

func A_arbace_go_check_types_incomparable_cause_A_New() *A_arbace_go_check_types_incomparable_cause_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_incomparable_cause_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_go_check_types_incomparable_cause_A) Ctor() {}
//line :273:1
func (t *A_arbace_go_check_types_incomparable_cause_A) Invoke_O_O__O(self, t__0 any) any { var body_cause__2 *A_arbace_go_check_types_incomparable_cause_cause__219000090_A = A_arbace_go_check_types_incomparable_cause_cause__219000090_A_New(); var cause__2 any; var tmp1 *jrt.Class; var fncls__759 *jrt.Class = A_arbace_go_check_types_incomparable_cause_cause__219000090_A_fn_class; if fncls__759 == nil { var fncls__759d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_go_check_types_incomparable_cause_cause__219000090_A_fn_class = fncls__759d; tmp1 = fncls__759d } else { tmp1 = fncls__759 }; cause__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_cause__2), tmp1, nil); var or__1927000174__auto____3 any = lang.IFn_Cast(cause__2).Invoke_O_O__O(t__0, lang.PersistentHashSet_EMPTY.Ref()); if




















	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { return Lit_10 } }
//line :277:1
func A_arbace_go_check_types_incomparable_cause_cause__219000090_A_New() *A_arbace_go_check_types_incomparable_cause_cause__219000090_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_incomparable_cause_cause__219000090_A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000090_A) Ctor() {}
//line :277:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000090_A) Invoke_O_O_O__O(self, t__1, seen__2 any) any {
	var tmp1 any; var root_713 any = A_arbace_go_check_types_A_const_100.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_715 lang.IFn; if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = seen__2; var arg_717 any = t__1; if linked_714 == nil { tmp1 = ifn_715.Invoke_O_O__O(arg_716, arg_717) } else { tmp1 = linked_714.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_713, arg_716, arg_717) }; if jrt.J2g_Truth(tmp1) { return nil } else { var seen__3 any; var root_718 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_719 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_718, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_720 lang.IFn

		if linked_719 == nil { ifn_720 = lang.IFn_Cast(root_718) } else { ifn_720 = nil }; var arg_721 any = seen__2; var arg_722 any = t__1; if linked_719 == nil { seen__3 = ifn_720.Invoke_O_O__O(arg_721, arg_722) } else { seen__3 = linked_719.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_718, arg_721, arg_722) }
		var tmp2 any; var root_723 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = t__1; if linked_724 == nil { tmp2 = ifn_725.Invoke_O__O(arg_726) } else { tmp2 = linked_724.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_723, arg_726) }; if jrt.J2g_Truth(tmp2) {
			var tmp3 any; var root_727 any = A_arbace_go_check_types_A_const_131.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any; var root_732 any = A_arbace_go_check_types_A_const_132.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = t__1; if linked_733 == nil { arg_730 = ifn_734.Invoke_O__O(arg_735) } else { arg_730 = linked_733.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_732, arg_735) }; var arg_731 any = seen__3; if linked_728 == nil { tmp3 = ifn_729.Invoke_O_O__O(arg_730, arg_731) } else { tmp3 = linked_728.(*A_arbace_go_check_types_tset_comparable_QMARK__A).Invoke_O_O_O__O(root_727, arg_730, arg_731) }; if jrt.J2g_Truth(tmp3) { return nil } else { return Lit_10 } } else {
//line :281:1
				var u__4 any; var root_736 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, A_arbace_go_check_types_under_A_fn_class); var ifn_738 lang.IFn

				if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = t__1; if linked_737 == nil { u__4 = ifn_738.Invoke_O__O(arg_739) } else { u__4 = linked_737.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_736, arg_739) }
				var tmp4 any; var root_740 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_742 lang.IFn
				if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any = u__4; if linked_741 == nil { tmp4 = ifn_742.Invoke_O__O(arg_743) } else { tmp4 = linked_741.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_740, arg_743) }
//line :284:1
				if jrt.J2g_Truth(tmp4) {
					if lang.Util_Equiv_O_O__Z_NoInit(u__4, A_arbace_go_check_types_A_const_51) { return Lit_10 } else { return nil } } else {
//line :284:1
						if A_arbace_go_check_types_A_const_88 != nil { var G__219000091__5_ any = lang.RT_Nth_O_I__O_NoInit(u__4, lang.RT_IntCast_J__I_NoInit(0))


							switch lang.Util_Hash_O__I_NoInit(G__219000091__5_) >> 4 & 7 { case 0: if any(G__219000091__5_) == any(A_arbace_go_check_types_A_const_72) {




								if jrt.J2g_Truth(lang.IFn_Cast(self).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(u__4, lang.RT_IntCast_J__I_NoInit(2)), seen__3)) { var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_17); var tmp6 any; var root_745 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, A_arbace_go_check_types_type_str_A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any = t__1; if linked_746 == nil { tmp6 = ifn_747.Invoke_O__O(arg_748) } else { tmp6 = linked_746.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_745, arg_748) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil)).Ref() } else { return nil } }
//line :287:1
							case 1: if any(G__219000091__5_) == any(A_arbace_go_check_types_A_const_76) { return nil }; case 3: if any(G__219000091__5_) == any(A_arbace_go_check_types_A_const_67) { return nil }; case 6: if any(G__219000091__5_) == any(A_arbace_go_check_types_A_const_71) { return nil }; case 7: if any(G__219000091__5_) == any(A_arbace_go_check_types_A_const_82) {

								var root_749 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_751 lang.IFn; if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any; var tmp7 any = A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A_New_O_O(self, seen__3); var tmp8 *jrt.Class; var fncls__758 *jrt.Class = A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A_fn_class; if fncls__758 == nil { var fncls__758d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A_fn_class = fncls__758d; tmp8 = fncls__758d } else { tmp8 = fncls__758 }; arg_752 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_753 any = lang.RT_Nth_O_I__O_NoInit(u__4, lang.RT_IntCast_J__I_NoInit(1)); if linked_750 == nil { return ifn_751.Invoke_O_O__O(arg_752, arg_753) } else { return linked_750.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_749, arg_752, arg_753) } }
//line :287:1
							default:}; return Lit_10 } else {
//line :284:1
								return nil
							}
					}
			}
	} }
func A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A{}; t.Ctor_O_O(p0, p1); return t }
//line :289:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A) Ctor_O_O(c__cause, c__seen any) { t.F_cause = c__cause; t.F_seen = c__seen }
//line :289:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A) Invoke_O_O__O(self, fd__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_cause); if jrt.J2g_Truth(tmp1.Invoke_O_O__O(A_arbace_go_check_types_A_const_70.Invoke_O__O(fd__1), t.F_seen)) {
																var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_19, nil, Lit_17); var tmp3 any; var root_754 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, A_arbace_go_check_types_type_str_A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = A_arbace_go_check_types_A_const_70.Invoke_O__O(fd__1); if linked_755 == nil { tmp3 = ifn_756.Invoke_O__O(arg_757) } else { tmp3 = linked_755.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_754, arg_757) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref() } else {
//line :289:1
		return nil } }






func A_arbace_go_check_types_comparable_QMARK__A_New() *A_arbace_go_check_types_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_QMARK__A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Ctor() {}
//line :296:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Invoke_O_O_O__O(self, t__0, seen__1 any) any {



	var root_760 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = t__0; var arg_764 any = jrt.Boolean_TRUE.Ref(); var arg_765 any = seen__1; if linked_761 == nil { return ifn_762.Invoke_O_O_O__O(arg_763, arg_764, arg_765) } else { return linked_761.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_760, arg_763, arg_764, arg_765) } }
//line :296:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Invoke_O_O__O(self, t__0 any) any {


	var root_766 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_768 lang.IFn; if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = t__0; var arg_770 any = jrt.Boolean_TRUE.Ref(); var arg_771 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_767 == nil { return ifn_768.Invoke_O_O_O__O(arg_769, arg_770, arg_771) } else { return linked_767.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_766, arg_769, arg_770, arg_771)
	}
}











func A_arbace_go_check_types_union_QMARK__A_New() *A_arbace_go_check_types_union_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_union_QMARK__A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_go_check_types_union_QMARK__A) Ctor() {}
//line :313:1
func (t *A_arbace_go_check_types_union_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_772 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any = t__0; if linked_773 == nil { and__1927000168__auto____2 = ifn_774.Invoke_O__O(arg_775) } else { and__1927000168__auto____2 = linked_773.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_772, arg_775) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_137; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_go_check_types_term_disjoint_QMARK__A_New() *A_arbace_go_check_types_term_disjoint_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_disjoint_QMARK__A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_go_check_types_term_disjoint_QMARK__A) Ctor() {}
//line :315:1
func (t *A_arbace_go_check_types_term_disjoint_QMARK__A) Invoke_O_O_O__O(self, p__219000098__0, p__219000099__1 any) any { var vec__219000100__3 any = p__219000098__0; var xt__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000100__3, lang.RT_IntCast_J__I_NoInit(0), nil); var x__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000100__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__219000103__6 any = p__219000099__1; var yt__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000103__6, lang.RT_IntCast_J__I_NoInit(0), nil); var y__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000103__6, lang.RT_IntCast_J__I_NoInit(1), nil); var root_776 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_778 lang.IFn; if
																linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any; var root_780 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any; if jrt.J2g_Truth(yt__7) { var root_785 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, A_arbace_go_check_types_under_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = x__5; if linked_786 == nil { arg_783 = ifn_787.Invoke_O__O(arg_788) } else { arg_783 = linked_786.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_785, arg_788) } } else { arg_783 = x__5 }; var arg_784 any; if jrt.J2g_Truth(xt__4) { var root_789 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, A_arbace_go_check_types_under_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = y__8; if linked_790 == nil { arg_784 = ifn_791.Invoke_O__O(arg_792) } else { arg_784 = linked_790.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_789, arg_792) } } else { arg_784 = y__8 }; if linked_781 == nil { arg_779 = ifn_782.Invoke_O_O__O(arg_783, arg_784) } else { arg_779 = linked_781.(*A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_780, arg_783, arg_784) }; if linked_777 == nil { return ifn_778.Invoke_O__O(arg_779) } else { return linked_777.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_776, arg_779) } }

func A_arbace_go_check_types_term_union_A_New() *A_arbace_go_check_types_term_union_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_union_A{}; t.Ctor(); return t }
//line :318:1
func (t *A_arbace_go_check_types_term_union_A) Ctor() {}
//line :318:1
func (t *A_arbace_go_check_types_term_union_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	var tmp1 any; var root_793 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_795 lang.IFn
	if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = x__0; var arg_797 any = y__1; if linked_794 == nil { tmp1 = ifn_795.Invoke_O_O__O(arg_796, arg_797) } else { tmp1 = linked_794.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_793, arg_796, arg_797) }
//line :319:1
	if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(x__0, y__1) } else { var tmp2 any; var or__1927000174__auto____3 any; var root_798 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_800 lang.IFn

		if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = x__0; if linked_799 == nil { or__1927000174__auto____3 = ifn_800.Invoke_O__O(arg_801) } else { or__1927000174__auto____3 = linked_799.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_798, arg_801) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_802 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any; var root_806 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = y__1; if linked_807 == nil { arg_805 = ifn_808.Invoke_O__O(arg_809) } else { arg_805 = linked_807.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_806, arg_809) }; if linked_803 == nil { tmp2 = ifn_804.Invoke_O__O(arg_805) } else { tmp2 = linked_803.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_802, arg_805) } }
//line :319:1
		if jrt.J2g_Truth(tmp2) { return lang.Tuple_Create_O__IPersistentVector(x__0) } else { if A_arbace_go_check_types_A_const_88 != nil { return lang.Tuple_Create_O__IPersistentVector(y__1) } else { return nil
		}
		}
	}
}
func A_arbace_go_check_types_term_intersect_A_New() *A_arbace_go_check_types_term_intersect_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_intersect_A{}; t.Ctor(); return t }
//line :324:1
func (t *A_arbace_go_check_types_term_intersect_A) Ctor() {}
//line :324:1
func (t *A_arbace_go_check_types_term_intersect_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	var tmp1 any; var root_810 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_810, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_812 lang.IFn
	if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any = x__0; var arg_814 any = y__1; if linked_811 == nil { tmp1 = ifn_812.Invoke_O_O__O(arg_813, arg_814) } else { tmp1 = linked_811.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_810, arg_813, arg_814) }
//line :325:1
	if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; var or__1927000174__auto____3 any; var root_815 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_817 lang.IFn

		if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any; var root_819 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_819, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_821 lang.IFn; if linked_820 == nil { ifn_821 = lang.IFn_Cast(root_819) } else { ifn_821 = nil }; var arg_822 any = x__0; if linked_820 == nil { arg_818 = ifn_821.Invoke_O__O(arg_822) } else { arg_818 = linked_820.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_819, arg_822) }; if linked_816 == nil { or__1927000174__auto____3 = ifn_817.Invoke_O__O(arg_818) } else { or__1927000174__auto____3 = linked_816.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_815, arg_818) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_823 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_825 lang.IFn; if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any = y__1; if linked_824 == nil { tmp2 = ifn_825.Invoke_O__O(arg_826) } else { tmp2 = linked_824.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_823, arg_826) } }
//line :325:1
		if jrt.J2g_Truth(tmp2) { return x__0 } else { if A_arbace_go_check_types_A_const_88 != nil { return y__1 } else { return nil
		}
		}
	}
}
func A_arbace_go_check_types_term_includes_QMARK__A_New() *A_arbace_go_check_types_term_includes_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_includes_QMARK__A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_go_check_types_term_includes_QMARK__A) Ctor() {}
//line :330:1
func (t *A_arbace_go_check_types_term_includes_QMARK__A) Invoke_O_O_O__O(self, p__219000109__0, t__1 any) any { var vec__219000110__3 any = p__219000109__0; var tilde__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000110__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000110__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_827 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = ty__5; var arg_831 any; if jrt.J2g_Truth(tilde__4) { var root_832 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, A_arbace_go_check_types_under_A_fn_class); var ifn_834 lang.IFn; if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any = t__1; if linked_833 == nil { arg_831 = ifn_834.Invoke_O__O(arg_835) } else { arg_831 = linked_833.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_832, arg_835) } } else { arg_831 = t__1 }; if linked_828 == nil { return ifn_829.Invoke_O_O__O(arg_830, arg_831) } else { return linked_828.(*A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_827, arg_830, arg_831) } }

func A_arbace_go_check_types_term_subset_QMARK__A_New() *A_arbace_go_check_types_term_subset_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_subset_QMARK__A{}; t.Ctor(); return t }
//line :332:1
func (t *A_arbace_go_check_types_term_subset_QMARK__A) Ctor() {}
//line :332:1
func (t *A_arbace_go_check_types_term_subset_QMARK__A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var and__1927000168__auto____3 any; var root_836 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any; var root_840 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = x__0; var arg_844 any = y__1; if linked_841 == nil { arg_839 = ifn_842.Invoke_O_O__O(arg_843, arg_844) } else { arg_839 = linked_841.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_840, arg_843, arg_844) }; if linked_837 == nil { and__1927000168__auto____3 = ifn_838.Invoke_O__O(arg_839) } else { and__1927000168__auto____3 = linked_837.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_836, arg_839) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var root_845 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_845, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any; var root_849 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_849, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_851 lang.IFn; if linked_850 == nil { ifn_851 = lang.IFn_Cast(root_849) } else { ifn_851 = nil }; var arg_852 any = x__0; if linked_850 == nil { arg_848 = ifn_851.Invoke_O__O(arg_852) } else { arg_848 = linked_850.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_849, arg_852) }; if linked_846 == nil { or__1927000174__auto____4 = ifn_847.Invoke_O__O(arg_848) } else { or__1927000174__auto____4 = linked_846.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_845, arg_848) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var root_853 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = y__1; if linked_854 == nil { return ifn_855.Invoke_O__O(arg_856) } else { return linked_854.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_853, arg_856) } } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_terms_norm_A_New() *A_arbace_go_check_types_terms_norm_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_norm_A{}; t.Ctor(); return t }
//line :334:1
func (t *A_arbace_go_check_types_terms_norm_A) Ctor() {}
//line :334:1
func (t *A_arbace_go_check_types_terms_norm_A) Invoke_O_O__O(self, ts__0 any) any { { var ts__2 any; var root_857 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_859 lang.IFn


	if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = ts__0; if linked_858 == nil { ts__2 = ifn_859.Invoke_O__O(arg_860) } else { ts__2 = linked_858.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_857, arg_860) }
//line :334:1
	var n__3 int32 = lang.RT_Count_O__I_NoInit(ts__2); var used__4 any = lang.Numbers_Boolean_array_O__Z1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref()).Ref(); var i__5 int64 = 0; var rl__6 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




		if lang.Util_Equiv_J_J__Z_NoInit(i__5, int64(n__3)) {

			var root_861 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any; var root_866 any = A_arbace_go_check_types_A_const_142.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = rl__6; if linked_867 == nil { arg_864 = ifn_868.Invoke_O__O(arg_869) } else { arg_864 = linked_867.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_866, arg_869) }; var arg_865 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_143, rl__6)); if linked_862 == nil { return ifn_863.Invoke_O_O__O(arg_864, arg_865) } else { return linked_862.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_861, arg_864, arg_865) } } else {
				if lang.RT_Aget_Z1_I__Z_NoInit(jrt.J2g_CastArray[*jrt.BooleanArray](used__4, jrt.Prim_boolean.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__5)) {
					i__5, rl__6 = lang.Numbers_Inc_J__J_NoInit(i__5), rl__6; continue L1 } else {
//line :342:1
						var xi__7 any; var tmp1 any = A_arbace_go_check_types_terms_norm_fn__219000115_A_New_J_I_O_O(i__5, n__3, used__4, ts__2); var tmp2 *jrt.Class
						var fncls__879 /*line :342:1*/*jrt.Class = A_arbace_go_check_types_terms_norm_fn__219000115_A_fn_class

						if fncls__879 == nil { var fncls__879d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_go_check_types_terms_norm_fn__219000115_A_fn_class = fncls__879d; tmp2 = fncls__879d } else { tmp2 = fncls__879 }; xi__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()







						var tmp3 int64 = lang.Numbers_Inc_J__J_NoInit(i__5); var tmp4 any; var root_880 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = rl__6; var arg_884 any = xi__7; if linked_881 == nil { tmp4 = ifn_882.Invoke_O_O__O(arg_883, arg_884) } else { tmp4 = linked_881.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_880, arg_883, arg_884) }; i__5, rl__6 = tmp3, tmp4; continue L1 } } } }; /*line :334:1*/panic("j2g: unreachable") }









func A_arbace_go_check_types_terms_norm_fn__219000115_A_New_J_I_O_O(p0 int64, p1 int32, p2, p3 any) *A_arbace_go_check_types_terms_norm_fn__219000115_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_norm_fn__219000115_A{}; t.Ctor_J_I_O_O(p0, p1, p2, p3); return t }
//line :344:1
func (t *A_arbace_go_check_types_terms_norm_fn__219000115_A) Ctor_J_I_O_O(c__i int64, c__n int32, c__used, c__ts any) { t.F_i = c__i; t.F_n = c__n; t.F_used = c__used; t.F_ts = c__ts }
//line :344:1
func (t *A_arbace_go_check_types_terms_norm_fn__219000115_A) Invoke_O__O(self any) any { { var j__1 int64 = lang.Numbers_Inc_J__J_NoInit(t.F_i); var tmp1 any = t.F_ts; var xi__2 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(t.F_i)); L1: for {
											if lang.Util_Equiv_J_J__Z_NoInit(j__1, int64(t.F_n)) { return xi__2 } else { var tmp2 *jrt.BooleanArray = jrt.J2g_CastArray[*jrt.BooleanArray](t.F_used, jrt.Prim_boolean.ArrayClass()); if lang.RT_Aget_Z1_I__Z_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(j__1)) {

		j__1, xi__2 = lang.Numbers_Inc_J__J_NoInit(j__1), xi__2; continue L1 } else {
//line :345:1
			if A_arbace_go_check_types_A_const_88 != nil { var u__3 any; var root_870 any = A_arbace_go_check_types_A_const_144.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, A_arbace_go_check_types_term_union_A_fn_class); var ifn_872 lang.IFn


				if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = xi__2; var tmp3 any = t.F_ts; var arg_874 any = lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(j__1)); if linked_871 == nil { u__3 = ifn_872.Invoke_O_O__O(arg_873, arg_874) } else { u__3 = linked_871.(*A_arbace_go_check_types_term_union_A).Invoke_O_O_O__O(root_870, arg_873, arg_874) }
				if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(u__3))) {
					var tmp4 *jrt.BooleanArray = jrt.J2g_CastArray[*jrt.BooleanArray](t.F_used, jrt.Prim_boolean.ArrayClass()); jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_Aset_Z1_I_Z__Z_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(j__1), jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z())); var tmp5 int64 = lang.Numbers_Inc_J__J_NoInit(j__1); var tmp6 any; var root_875 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = u__3; if linked_876 == nil { tmp6 = ifn_877.Invoke_O__O(arg_878) } else { tmp6 = linked_876.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_875, arg_878) }; j__1, xi__2 = tmp5, tmp6; continue L1 } else {
						j__1, xi__2 = lang.Numbers_Inc_J__J_NoInit(j__1), xi__2; continue L1 } } else {
//line :345:1
							return nil } } } } }; /*line :344:1*/panic("j2g: unreachable") }









func A_arbace_go_check_types_ordered_A_New() *A_arbace_go_check_types_ordered_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ordered_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_go_check_types_ordered_A) Ctor() {}
//line :354:1
func (t *A_arbace_go_check_types_ordered_A) Invoke_O_O__O(self, ts__0 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_types_A_const_143; var or__1927000174__auto____2 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(ts__0)); if


	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_885 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = ts__0; if linked_886 == nil { return ifn_887.Invoke_O__O(arg_888) } else { return linked_886.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_885, arg_888) } } }

func A_arbace_go_check_types_terms_union_A_New() *A_arbace_go_check_types_terms_union_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_union_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_go_check_types_terms_union_A) Ctor() {}
//line :359:1
func (t *A_arbace_go_check_types_terms_union_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_126, x__0); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_126, y__1) }; if tmp1 { return A_arbace_go_check_types_A_const_126 } else { var root_889 any = A_arbace_go_check_types_A_const_145.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, A_arbace_go_check_types_terms_norm_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any; var root_893 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_893, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any; var root_898 any = A_arbace_go_check_types_A_const_147.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, A_arbace_go_check_types_ordered_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = x__0; if linked_899 == nil { arg_896 = ifn_900.Invoke_O__O(arg_901) } else { arg_896 = linked_899.(*A_arbace_go_check_types_ordered_A).Invoke_O_O__O(root_898, arg_901) }; var arg_897 any; var root_902 any = A_arbace_go_check_types_A_const_147.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, A_arbace_go_check_types_ordered_A_fn_class); var ifn_904 lang.IFn; if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any = y__1; if linked_903 == nil { arg_897 = ifn_904.Invoke_O__O(arg_905) } else { arg_897 = linked_903.(*A_arbace_go_check_types_ordered_A).Invoke_O_O__O(root_902, arg_905) }; if linked_894 == nil { arg_892 = ifn_895.Invoke_O_O__O(arg_896, arg_897) } else { arg_892 = linked_894.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_893, arg_896, arg_897) }; if linked_890 == nil { return ifn_891.Invoke_O__O(arg_892) } else { return linked_890.(*A_arbace_go_check_types_terms_norm_A).Invoke_O_O__O(root_889, arg_892) } } }

func A_arbace_go_check_types_terms_intersect_A_New() *A_arbace_go_check_types_terms_intersect_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_A{}; t.Ctor(); return t }
//line :361:1
func (t *A_arbace_go_check_types_terms_intersect_A) Ctor() {}
//line :361:1
func (t *A_arbace_go_check_types_terms_intersect_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_126, x__0) { return y__1 } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_126, y__1) { return x__0 } else { var tmp1 any; var or__1927000174__auto____3 any; var root_906 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_908 lang.IFn


		if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any = x__0; if linked_907 == nil { or__1927000174__auto____3 = ifn_908.Invoke_O__O(arg_909) } else { or__1927000174__auto____3 = linked_907.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_906, arg_909) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_910 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_910, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_912 lang.IFn; if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any = y__1; if linked_911 == nil { tmp1 = ifn_912.Invoke_O__O(arg_913) } else { tmp1 = linked_911.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_910, arg_913) } }
//line :362:1
		if jrt.J2g_Truth(tmp1) { return lang.PersistentHashSet_EMPTY.Ref() } else { if A_arbace_go_check_types_A_const_88 != nil {



			var root_914 any = A_arbace_go_check_types_A_const_145.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, A_arbace_go_check_types_terms_norm_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any; var iter__1927001039__auto____3 any; var tmp2 any = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A_New_O(y__1); var tmp3 *jrt.Class; var fncls__1021 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A_fn_class; if fncls__1021 == nil { var fncls__1021d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A_fn_class = fncls__1021d; tmp3 = fncls__1021d } else { tmp3 = fncls__1021 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp5 any; var root_1022 any = A_arbace_go_check_types_A_const_147.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, A_arbace_go_check_types_ordered_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = x__0; if linked_1023 == nil { tmp5 = ifn_1024.Invoke_O__O(arg_1025) } else { tmp5 = linked_1023.(*A_arbace_go_check_types_ordered_A).Invoke_O_O__O(root_1022, arg_1025) }; arg_917 = tmp4.Invoke_O__O(tmp5); if linked_915 == nil { return ifn_916.Invoke_O__O(arg_917) } else { return linked_915.(*A_arbace_go_check_types_terms_norm_A).Invoke_O_O__O(root_914, arg_917) } } else {
//line :362:1
				return nil
			}
		}
	} } }
func A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A_New_O(p0 any) *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A{}; t.Ctor_O(p0); return t }
//line :366:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A) Ctor_O(c__y any) { t.F_y = c__y }
//line :366:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A) Invoke_O_O__O(self, s__219000121__1 any) any { var tmp1 any = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A_New_O_O_O(self, s__219000121__1, t.F_y); var tmp2 *jrt.Class; var fncls__1020 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A_fn_class; if fncls__1020 == nil { var fncls__1020d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A_fn_class = fncls__1020d; tmp2 = fncls__1020d } else { tmp2 = fncls__1020 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :366:1
func A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :366:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A) Ctor_O_O_O(c__iter__219000120, c__s__219000121, c__y any) { t.F_iter__219000120 = c__iter__219000120; t.F_s__219000121 = c__s__219000121; t.F_y = c__y }
//line :366:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A) Invoke_O__O(self any) any { { var s__219000121__1 any; var t_ any = t.F_s__219000121; t.F_s__219000121 = nil; s__219000121__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_918 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = s__219000121__1; if linked_919 == nil { temp__1927000414__auto____2 = ifn_920.Invoke_O__O(arg_921) } else { temp__1927000414__auto____2 = linked_919.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_918, arg_921) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var a__4 any; var root_922 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = xs__1927001018__auto____3; if linked_923 == nil { a__4 = ifn_924.Invoke_O__O(arg_925) } else { a__4 = linked_923.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_922, arg_925) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A_New_O(a__4); var tmp2 *jrt.Class; var fncls__998 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A_fn_class; if fncls__998 == nil { var fncls__998d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A_fn_class = fncls__998d; tmp2 = fncls__998d } else { tmp2 = fncls__998 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_999 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_1000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_999, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1001 lang.IFn; if linked_1000 == nil { ifn_1001 = lang.IFn_Cast(root_999) } else { ifn_1001 = nil }; var arg_1002 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_1003 any = A_arbace_go_check_types_A_const_147.GetRawRoot__O(); var linked_1004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1003, A_arbace_go_check_types_ordered_A_fn_class); var ifn_1005 lang.IFn; if linked_1004 == nil { ifn_1005 = lang.IFn_Cast(root_1003) } else { ifn_1005 = nil }; var arg_1006 any = t.F_y; if linked_1004 == nil { tmp4 = ifn_1005.Invoke_O__O(arg_1006) } else { tmp4 = linked_1004.(*A_arbace_go_check_types_ordered_A).Invoke_O_O__O(root_1003, arg_1006) }; arg_1002 = tmp3.Invoke_O__O(tmp4); if linked_1000 == nil { fs__1927001036__auto____6 = ifn_1001.Invoke_O__O(arg_1002) } else { fs__1927001036__auto____6 = linked_1000.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_999, arg_1002) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1007 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1007, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any = fs__1927001036__auto____6; var arg_1011 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__219000120); var tmp6 any; var root_1012 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1014 lang.IFn; if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = s__219000121__1; if linked_1013 == nil { tmp6 = ifn_1014.Invoke_O__O(arg_1015) } else { tmp6 = linked_1013.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1012, arg_1015) }; arg_1011 = tmp5.Invoke_O__O(tmp6); if linked_1008 == nil { return ifn_1009.Invoke_O_O__O(arg_1010, arg_1011) } else { return linked_1008.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1007, arg_1010, arg_1011) } } else { var tmp7 any; var root_1016 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1018 lang.IFn; if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = s__219000121__1; if linked_1017 == nil { tmp7 = ifn_1018.Invoke_O__O(arg_1019) } else { tmp7 = linked_1017.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1016, arg_1019) }; s__219000121__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :366:1
func A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A_New_O(p0 any) *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A{}; t.Ctor_O(p0); return t }
//line :366:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A) Ctor_O(c__a any) { t.F_a = c__a }
//line :366:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A) Invoke_O_O__O(self, s__219000123__1 any) any { var tmp1 any = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A_New_O_O_O(self, s__219000123__1, t.F_a); var tmp2 *jrt.Class; var fncls__997 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A_fn_class; if fncls__997 == nil { var fncls__997d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A_fn_class = fncls__997d; tmp2 = fncls__997d } else { tmp2 = fncls__997 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :366:1
func A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :366:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A) Ctor_O_O_O(c__iter__219000122, c__s__219000123, c__a any) { t.F_iter__219000122 = c__iter__219000122; t.F_s__219000123 = c__s__219000123; t.F_a = c__a }
//line :366:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A) Invoke_O__O(self any) any { { var s__219000123__1 any; var t_ any = t.F_s__219000123; t.F_s__219000123 = nil; s__219000123__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_926 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = s__219000123__1; if linked_927 == nil { temp__1927000414__auto____2 = ifn_928.Invoke_O__O(arg_929) } else { temp__1927000414__auto____2 = linked_927.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_926, arg_929) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000123__3 any = temp__1927000414__auto____2; var tmp1 any; var root_930 any = A_arbace_go_check_types_A_const_148.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = s__219000123__3; if linked_931 == nil { tmp1 = ifn_932.Invoke_O__O(arg_933) } else { tmp1 = linked_931.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_930, arg_933) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_934 any = A_arbace_go_check_types_A_const_149.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = s__219000123__3; if linked_935 == nil { c__1927001037__auto____4 = ifn_936.Invoke_O__O(arg_937) } else { c__1927001037__auto____4 = linked_935.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_934, arg_937) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000125__6 any; var root_938 any = A_arbace_go_check_types_A_const_150.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_939 == nil { b__219000125__6 = ifn_940.Invoke_O__O(arg_941) } else { b__219000125__6 = linked_939.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_938, arg_941) }; var tmp2 any = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A_New_O_I_O_O(b__219000125__6, size__1927001038__auto____5, t.F_a, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__952 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A_fn_class; if fncls__952 == nil { var fncls__952d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A_fn_class = fncls__952d; tmp3 = fncls__952d } else { tmp3 = fncls__952 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_953 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_953, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_955 lang.IFn; if linked_954 == nil { ifn_955 = lang.IFn_Cast(root_953) } else { ifn_955 = nil }; var arg_956 any; var root_958 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = b__219000125__6; if linked_959 == nil { arg_956 = ifn_960.Invoke_O__O(arg_961) } else { arg_956 = linked_959.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_958, arg_961) }; var arg_957 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000122); var tmp5 any; var root_962 any = A_arbace_go_check_types_A_const_155.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = s__219000123__3; if linked_963 == nil { tmp5 = ifn_964.Invoke_O__O(arg_965) } else { tmp5 = linked_963.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_962, arg_965) }; arg_957 = tmp4.Invoke_O__O(tmp5); if linked_954 == nil { return ifn_955.Invoke_O_O__O(arg_956, arg_957) } else { return linked_954.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_953, arg_956, arg_957) } } else { var root_966 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_968 lang.IFn; if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any; var root_971 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = b__219000125__6; if linked_972 == nil { arg_969 = ifn_973.Invoke_O__O(arg_974) } else { arg_969 = linked_972.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_971, arg_974) }; var arg_970 any; if linked_967 == nil { return ifn_968.Invoke_O_O__O(arg_969, arg_970) } else { return linked_967.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_966, arg_969, arg_970) } } } else { var b__4 any; var root_975 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = s__219000123__3; if linked_976 == nil { b__4 = ifn_977.Invoke_O__O(arg_978) } else { b__4 = linked_976.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_975, arg_978) }; var r__5 any; var root_979 any = A_arbace_go_check_types_A_const_151.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, A_arbace_go_check_types_term_intersect_A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = t.F_a; var arg_983 any = b__4; if linked_980 == nil { r__5 = ifn_981.Invoke_O_O__O(arg_982, arg_983) } else { r__5 = linked_980.(*A_arbace_go_check_types_term_intersect_A).Invoke_O_O_O__O(root_979, arg_982, arg_983) }; if jrt.J2g_Truth(r__5) { var root_984 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = r__5; var arg_988 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__219000122); var tmp7 any; var root_989 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = s__219000123__3; if linked_990 == nil { tmp7 = ifn_991.Invoke_O__O(arg_992) } else { tmp7 = linked_990.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_989, arg_992) }; arg_988 = tmp6.Invoke_O__O(tmp7); if linked_985 == nil { return ifn_986.Invoke_O_O__O(arg_987, arg_988) } else { return linked_985.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_984, arg_987, arg_988) } } else { var tmp8 any; var root_993 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_993, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_995 lang.IFn; if linked_994 == nil { ifn_995 = lang.IFn_Cast(root_993) } else { ifn_995 = nil }; var arg_996 any = s__219000123__3; if linked_994 == nil { tmp8 = ifn_995.Invoke_O__O(arg_996) } else { tmp8 = linked_994.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_993, arg_996) }; s__219000123__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :366:1
func A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :366:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A) Ctor_O_I_O_O(c__b__219000125 any, c__size__1927001038__auto__ int32, c__a, c__c__1927001037__auto__ any) { t.F_b__219000125 = c__b__219000125; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_a = c__a; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :366:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A) Invoke_O__O(self any) any { { var i__219000124__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000124__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000124__1)); var r__3 any; var root_942 any = A_arbace_go_check_types_A_const_151.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, A_arbace_go_check_types_term_intersect_A_fn_class); var ifn_944 lang.IFn; if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = t.F_a; var arg_946 any = b__2; if linked_943 == nil { r__3 = ifn_944.Invoke_O_O__O(arg_945, arg_946) } else { r__3 = linked_943.(*A_arbace_go_check_types_term_intersect_A).Invoke_O_O_O__O(root_942, arg_945, arg_946) }; if jrt.J2g_Truth(r__3) { var root_947 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_947, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_949 lang.IFn; if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any = t.F_b__219000125; var arg_951 any = r__3; if linked_948 == nil { ifn_949.Invoke_O_O__O(arg_950, arg_951) } else { linked_948.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_947, arg_950, arg_951) }; i__219000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000124__1); continue L1 } else { i__219000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000124__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_types_terms_includes_QMARK__A_New() *A_arbace_go_check_types_terms_includes_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_includes_QMARK__A{}; t.Ctor(); return t }
//line :368:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__A) Ctor() {}
//line :368:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__A) Invoke_O_O_O__O(self, xl__0, t__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_126, xl__0); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp1 any; var root_1026 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1028 lang.IFn; if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any; var tmp2 any = A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A_New_O(t__1); var tmp3 *jrt.Class; var fncls__1036 *jrt.Class = A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A_fn_class; if fncls__1036 == nil { var fncls__1036d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A_fn_class = fncls__1036d; tmp3 = fncls__1036d } else { tmp3 = fncls__1036 }; arg_1029 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_1030 any = xl__0; if linked_1027 == nil { tmp1 = ifn_1028.Invoke_O_O__O(arg_1029, arg_1030) } else { tmp1 = linked_1027.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1026, arg_1029, arg_1030) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } }
//line :368:1
func A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A_New_O(p0 any) *A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A{}; t.Ctor_O(p0); return t }
//line :368:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :368:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A) Invoke_O_O__O(self, p1__219000137_SHARP___1 any) any { var root_1031 any = A_arbace_go_check_types_A_const_157.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, A_arbace_go_check_types_term_includes_QMARK__A_fn_class); var ifn_1033 lang.IFn; if linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any = p1__219000137_SHARP___1; var arg_1035 any = t.F_t; if linked_1032 == nil { return ifn_1033.Invoke_O_O__O(arg_1034, arg_1035) } else { return linked_1032.(*A_arbace_go_check_types_term_includes_QMARK__A).Invoke_O_O_O__O(root_1031, arg_1034, arg_1035) } }

func A_arbace_go_check_types_terms_superset_of_QMARK__A_New() *A_arbace_go_check_types_terms_superset_of_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_superset_of_QMARK__A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__A) Ctor() {}
//line :370:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__A) Invoke_O_O_O__O(self, xl__0, y__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_126, xl__0); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp1 any; var root_1037 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any; var tmp2 any = A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A_New_O(y__1); var tmp3 *jrt.Class; var fncls__1047 *jrt.Class = A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A_fn_class; if fncls__1047 == nil { var fncls__1047d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A_fn_class = fncls__1047d; tmp3 = fncls__1047d } else { tmp3 = fncls__1047 }; arg_1040 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_1041 any = xl__0; if linked_1038 == nil { tmp1 = ifn_1039.Invoke_O_O__O(arg_1040, arg_1041) } else { tmp1 = linked_1038.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1037, arg_1040, arg_1041) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } }
//line :370:1
func A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A_New_O(p0 any) *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A{}; t.Ctor_O(p0); return t }
//line :370:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A) Ctor_O(c__y any) { t.F_y = c__y }
//line :370:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A) Invoke_O_O__O(self, p1__219000141_SHARP___1 any) any { var root_1042 any = A_arbace_go_check_types_A_const_158.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, A_arbace_go_check_types_term_subset_QMARK__A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = t.F_y; var arg_1046 any = p1__219000141_SHARP___1; if linked_1043 == nil { return ifn_1044.Invoke_O_O__O(arg_1045, arg_1046) } else { return linked_1043.(*A_arbace_go_check_types_term_subset_QMARK__A).Invoke_O_O_O__O(root_1042, arg_1045, arg_1046) } }

func A_arbace_go_check_types_terms_subset_QMARK__A_New() *A_arbace_go_check_types_terms_subset_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_subset_QMARK__A{}; t.Ctor(); return t }
//line :372:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__A) Ctor() {}
//line :372:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__A) Invoke_O_O_O__O(self, xl__0, yl__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_126, yl__1) { return jrt.Boolean_TRUE.Ref() } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_126, xl__0) { return jrt.Boolean_FALSE.Ref() } else { var tmp1 any; var root_1048 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1050 lang.IFn


		if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any = yl__1; if linked_1049 == nil { tmp1 = ifn_1050.Invoke_O__O(arg_1051) } else { tmp1 = linked_1049.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1048, arg_1051) }
//line :375:1
		if jrt.J2g_Truth(tmp1) {


			var root_1052 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1052, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1054 lang.IFn; if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any = xl__0; if linked_1053 == nil { return ifn_1054.Invoke_O__O(arg_1055) } else { return linked_1053.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1052, arg_1055) } } else {
//line :375:1
				if A_arbace_go_check_types_A_const_88 != nil {



					var root_1056 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1058 lang.IFn; if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any; var tmp2 any = A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A_New_O(yl__1); var tmp3 *jrt.Class; var fncls__1066 *jrt.Class = A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A_fn_class; if fncls__1066 == nil { var fncls__1066d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A_fn_class = fncls__1066d; tmp3 = fncls__1066d } else { tmp3 = fncls__1066 }; arg_1059 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_1060 any = xl__0; if linked_1057 == nil { return ifn_1058.Invoke_O_O__O(arg_1059, arg_1060) } else { return linked_1057.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1056, arg_1059, arg_1060) } } else {
//line :375:1
						return nil
					}
			}
	} } }
func A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A_New_O(p0 any) *A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A{}; t.Ctor_O(p0); return t }
//line :379:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A) Ctor_O(c__yl any) { t.F_yl = c__yl }
//line :379:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A) Invoke_O_O__O(self, p1__219000145_SHARP___1 any) any { var root_1061 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, A_arbace_go_check_types_terms_superset_of_QMARK__A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = t.F_yl; var arg_1065 any = p1__219000145_SHARP___1; if linked_1062 == nil { return ifn_1063.Invoke_O_O__O(arg_1064, arg_1065) } else { return linked_1062.(*A_arbace_go_check_types_terms_superset_of_QMARK__A).Invoke_O_O_O__O(root_1061, arg_1064, arg_1065) } }

func A_arbace_go_check_types_make_tset_A_New() *A_arbace_go_check_types_make_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_make_tset_A{}; t.Ctor(); return t }
//line :381:1
func (t *A_arbace_go_check_types_make_tset_A) Ctor() {}
//line :381:1
func (t *A_arbace_go_check_types_make_tset_A) Invoke_O_O_O__O(self, terms__0, comparable__1 any) any {


	var tmp1 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_126, terms__0); if and__1927000168__auto____3 { var root_1067 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1069 lang.IFn; if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any = comparable__1; if linked_1068 == nil { tmp1 = ifn_1069.Invoke_O__O(arg_1070) } else { tmp1 = linked_1068.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1067, arg_1070) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any = A_arbace_go_check_types_A_const_127; var tmp3 any = A_arbace_go_check_types_A_const_128; var tmp4 any; var and__1927000168__auto____3_2 any = comparable__1; if jrt.J2g_Truth(and__1927000168__auto____3_2) { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_126, terms__0)).Ref() } else { tmp4 = and__1927000168__auto____3_2 }; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, terms__0, tmp3, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp4)).Ref()))
	} }
func A_arbace_go_check_types_iface_tset_A_New() *A_arbace_go_check_types_iface_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_iface_tset_A{}; t.Ctor(); return t }
//line :386:1
func (t *A_arbace_go_check_types_iface_tset_A) Ctor() {}
//line :386:1
func (t *A_arbace_go_check_types_iface_tset_A) Invoke_O_O__O(self, u__0 any) any { var ts__2 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(2)); var tmp1 any = A_arbace_go_check_types_A_const_96; var tmp2 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp3 any = A_arbace_go_check_types_A_const_127; var tmp4 any; var tmp5 any; var root_1071 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1073 lang.IFn; if





	linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = ts__2; if linked_1072 == nil { tmp5 = ifn_1073.Invoke_O__O(arg_1074) } else { tmp5 = linked_1072.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1071, arg_1074) }; if jrt.J2g_Truth(tmp5) { tmp4 = A_arbace_go_check_types_A_const_127.Invoke_O__O(ts__2) } else { tmp4 = A_arbace_go_check_types_A_const_126 }; var tmp6 any = tmp4; var tmp7 any = A_arbace_go_check_types_A_const_128; var tmp8 any; var and__1927000168__auto____3 any; var root_1075 any = /*line :386:1*/A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1077 lang.IFn; if






	linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = ts__2; if linked_1076 == nil { and__1927000168__auto____3 = ifn_1077.Invoke_O__O(arg_1078) } else { and__1927000168__auto____3 = linked_1076.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1075, arg_1078) }; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp8 = A_arbace_go_check_types_A_const_128.Invoke_O__O(ts__2) } else { tmp8 = and__1927000168__auto____3 }; return /*line :386:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp6, tmp7, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp8)).Ref())) }








func A_arbace_go_check_types_has_terms_QMARK__A_New() *A_arbace_go_check_types_has_terms_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_terms_QMARK__A{}; t.Ctor(); return t }
//line :395:1
func (t *A_arbace_go_check_types_has_terms_QMARK__A) Ctor() {}
//line :395:1
func (t *A_arbace_go_check_types_has_terms_QMARK__A) Invoke_O_O__O(self, ts__0 any) any { var terms__2 any = A_arbace_go_check_types_A_const_127.Invoke_O__O(ts__0); var and__1927000168__auto____3 any; var root_1079 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1081 lang.IFn; if


	linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any = A_arbace_go_check_types_A_const_126; var arg_1083 any = terms__2; if linked_1080 == nil { and__1927000168__auto____3 = ifn_1081.Invoke_O_O__O(arg_1082, arg_1083) } else { and__1927000168__auto____3 = linked_1080.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1079, arg_1082, arg_1083) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1084 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1084, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1086 lang.IFn; if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any = terms__2; if linked_1085 == nil { return ifn_1086.Invoke_O__O(arg_1087) } else { return linked_1085.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1084, arg_1087) } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_tset_empty_QMARK__A_New() *A_arbace_go_check_types_tset_empty_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_empty_QMARK__A{}; t.Ctor(); return t }
//line :400:1
func (t *A_arbace_go_check_types_tset_empty_QMARK__A) Ctor() {}
//line :400:1
func (t *A_arbace_go_check_types_tset_empty_QMARK__A) Invoke_O_O__O(self, ts__0 any) any { var and__1927000168__auto____2 any; var root_1088 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1088, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any = A_arbace_go_check_types_A_const_126; var arg_1092 any = A_arbace_go_check_types_A_const_127.Invoke_O__O(ts__0); if linked_1089 == nil { and__1927000168__auto____2 = ifn_1090.Invoke_O_O__O(arg_1091, arg_1092) } else { and__1927000168__auto____2 = linked_1089.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1088, arg_1091, arg_1092) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1093 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = A_arbace_go_check_types_A_const_127.Invoke_O__O(ts__0); if linked_1094 == nil { return ifn_1095.Invoke_O__O(arg_1096) } else { return linked_1094.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1093, arg_1096) } } else { return and__1927000168__auto____2 } }

func A_arbace_go_check_types_method_set_iface_QMARK__A_New() *A_arbace_go_check_types_method_set_iface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_method_set_iface_QMARK__A{}; t.Ctor(); return t }
//line :402:1
func (t *A_arbace_go_check_types_method_set_iface_QMARK__A) Ctor() {}
//line :402:1
func (t *A_arbace_go_check_types_method_set_iface_QMARK__A) Invoke_O_O__O(self, u__0 any) any {



	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref()
}
func A_arbace_go_check_types_bound_iface_A_New() *A_arbace_go_check_types_bound_iface_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_bound_iface_A{}; t.Ctor(); return t }
//line :408:1
func (t *A_arbace_go_check_types_bound_iface_A) Ctor() {}
//line :408:1
func (t *A_arbace_go_check_types_bound_iface_A) Invoke_O_O__O(self, b__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any = b__0; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1097 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_1098 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1097, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1099 lang.IFn; if linked_1098 == nil { ifn_1099 = lang.IFn_Cast(root_1097) } else { ifn_1099 = nil }; var arg_1100 any = A_arbace_go_check_types_A_const_101; var arg_1101 any = b__0; if linked_1098 == nil { tmp1 = ifn_1099.Invoke_O_O__O(arg_1100, arg_1101) } else { tmp1 = linked_1098.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1097, arg_1100, arg_1101) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var u__2 any; var root_1102 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1102, A_arbace_go_check_types_under_A_fn_class); var ifn_1104 lang.IFn
		if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any = b__0; if linked_1103 == nil { u__2 = ifn_1104.Invoke_O__O(arg_1105) } else { u__2 = linked_1103.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1102, arg_1105) }
		if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_101, u__2) { return nil } else { var tmp2 any; var and__1927000168__auto____3 any; var root_1106 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_1107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1106, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1108 lang.IFn

			if linked_1107 == nil { ifn_1108 = lang.IFn_Cast(root_1106) } else { ifn_1108 = nil }; var arg_1109 any = u__2; if linked_1107 == nil { and__1927000168__auto____3 = ifn_1108.Invoke_O__O(arg_1109) } else { and__1927000168__auto____3 = linked_1107.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1106, arg_1109) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_go_check_types_A_const_67; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :414:1
			if jrt.J2g_Truth(tmp2) { return u__2 } else { var tmp4 any; var root_1110 any = A_arbace_go_check_types_A_const_161.GetRawRoot__O(); var linked_1111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1110, A_arbace_go_check_types_union_QMARK__A_fn_class); var ifn_1112 lang.IFn


				if linked_1111 == nil { ifn_1112 = lang.IFn_Cast(root_1110) } else { ifn_1112 = nil }; var arg_1113 any = u__2; if linked_1111 == nil { tmp4 = ifn_1112.Invoke_O__O(arg_1113) } else { tmp4 = linked_1111.(*A_arbace_go_check_types_union_QMARK__A).Invoke_O_O__O(root_1110, arg_1113) }
//line :414:1
				if jrt.J2g_Truth(tmp4) { var tmp5 any = A_arbace_go_check_types_A_const_67; var tmp6 any = lang.PersistentVector_EMPTY.Ref(); var tmp7 any; var root_1114 any = A_arbace_go_check_types_A_const_162.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1114, A_arbace_go_check_types_make_tset_A_fn_class); var ifn_1116 lang.IFn


					if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); var arg_1118 any = jrt.Boolean_FALSE.Ref(); if linked_1115 == nil { tmp7 = ifn_1116.Invoke_O_O__O(arg_1117, arg_1118) } else { tmp7 = linked_1115.(*A_arbace_go_check_types_make_tset_A).Invoke_O_O_O__O(root_1114, arg_1117, arg_1118) }
//line :414:1
					return lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, tmp7) } else { if A_arbace_go_check_types_A_const_88 != nil { var tmp8 any = A_arbace_go_check_types_A_const_67; var tmp9 any = lang.PersistentVector_EMPTY.Ref(); var tmp10 any; var root_1119 any = A_arbace_go_check_types_A_const_162.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, A_arbace_go_check_types_make_tset_A_fn_class); var ifn_1121 lang.IFn



						if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(jrt.Boolean_FALSE.Ref(), b__0))); var arg_1123 any = jrt.Boolean_FALSE.Ref(); if linked_1120 == nil { tmp10 = ifn_1121.Invoke_O_O__O(arg_1122, arg_1123) } else { tmp10 = linked_1120.(*A_arbace_go_check_types_make_tset_A).Invoke_O_O_O__O(root_1119, arg_1122, arg_1123) }
//line :414:1
						return lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp9, tmp10) } else { return nil } } } } } else {
//line :412:1
							return nil
						}
}





func A_arbace_go_check_types_tparam_iface_A_New() *A_arbace_go_check_types_tparam_iface_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_iface_A{}; t.Ctor(); return t }
//line :420:1
func (t *A_arbace_go_check_types_tparam_iface_A) Ctor() {}
//line :420:1
func (t *A_arbace_go_check_types_tparam_iface_A) Invoke_O_O__O(self, tp__0 any) any { var i__2 any; var root_1124 any = A_arbace_go_check_types_A_const_97.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1124, A_arbace_go_check_types_info_A_fn_class); var ifn_1126 lang.IFn; if


	linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any = tp__0; if linked_1125 == nil { i__2 = ifn_1126.Invoke_O__O(arg_1127) } else { i__2 = linked_1125.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1124, arg_1127) }; var or__1927000174__auto____3 any = /*line :420:1*/A_arbace_go_check_types_A_const_163.Invoke_O__O(i__2); if



	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000408__auto____4 any; var root_1128 any = A_arbace_go_check_types_A_const_164.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1128, A_arbace_go_check_types_bound_iface_A_fn_class); var ifn_1130 lang.IFn
		if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any = A_arbace_go_check_types_A_const_165.Invoke_O__O(i__2); if linked_1129 == nil { temp__1927000408__auto____4 = ifn_1130.Invoke_O__O(arg_1131) } else { temp__1927000408__auto____4 = linked_1129.(*A_arbace_go_check_types_bound_iface_A).Invoke_O_O__O(root_1128, arg_1131) }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var r__5 any = temp__1927000408__auto____4
			lang.IFn_Cast(A_arbace_go_check_types_A_const_166.GetRawRoot__O()).Invoke_O_O_O_O__O(tp__0, A_arbace_go_check_types_A_const_93.GetRawRoot__O(), A_arbace_go_check_types_A_const_163, r__5)
//line :425:1
			return r__5 } else { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_67, lang.PersistentVector_EMPTY.Ref(), nil) } } }



func A_arbace_go_check_types_tparam_tset_A_New() *A_arbace_go_check_types_tparam_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_tset_A{}; t.Ctor(); return t }
//line :429:1
func (t *A_arbace_go_check_types_tparam_tset_A) Ctor() {}
//line :429:1
func (t *A_arbace_go_check_types_tparam_tset_A) Invoke_O_O__O(self, tp__0 any) any { var root_1139 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_1141 lang.IFn; if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any; var root_1143 any = A_arbace_go_check_types_A_const_105.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1143, A_arbace_go_check_types_tparam_iface_A_fn_class); var ifn_1145 lang.IFn; if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = tp__0; if linked_1144 == nil { arg_1142 = ifn_1145.Invoke_O__O(arg_1146) } else { arg_1142 = linked_1144.(*A_arbace_go_check_types_tparam_iface_A).Invoke_O_O__O(root_1143, arg_1146) }; if linked_1140 == nil { return ifn_1141.Invoke_O__O(arg_1142) } else { return linked_1140.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_1139, arg_1142) } }

func A_arbace_go_check_types_typeset_pairs_A_New() *A_arbace_go_check_types_typeset_pairs_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_A{}; t.Ctor(); return t }
//line :431:1
func (t *A_arbace_go_check_types_typeset_pairs_A) Ctor() {}
//line :431:1
func (t *A_arbace_go_check_types_typeset_pairs_A) Invoke_O_O__O(self, t__0 any) any {



	var tmp1 any; var root_1147 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any = t__0; if linked_1148 == nil { tmp1 = ifn_1149.Invoke_O__O(arg_1150) } else { tmp1 = linked_1148.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_1147, arg_1150) }; if jrt.J2g_Truth(tmp1) { var ts__2 any; var root_1151 any = A_arbace_go_check_types_A_const_132.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_1153 lang.IFn
		if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any = t__0; if linked_1152 == nil { ts__2 = ifn_1153.Invoke_O__O(arg_1154) } else { ts__2 = linked_1152.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_1151, arg_1154) }
		var tmp2 any; var root_1155 any = A_arbace_go_check_types_A_const_167.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_1157 lang.IFn; if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any = ts__2; if linked_1156 == nil { tmp2 = ifn_1157.Invoke_O__O(arg_1158) } else { tmp2 = linked_1156.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_1155, arg_1158) }; if jrt.J2g_Truth(tmp2) { var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A_New(); var tmp4 *jrt.Class; var fncls__1225 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A_fn_class
			if fncls__1225 == nil { var fncls__1225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A_fn_class = fncls__1225d; tmp4 = fncls__1225d } else { tmp4 = fncls__1225 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); return lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_go_check_types_A_const_127.Invoke_O__O(ts__2)) } else {
//line :437:1
				return A_arbace_go_check_types_A_const_168 } } else {
//line :435:1
					var tmp5 any; var root_1226 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, A_arbace_go_check_types_under_A_fn_class); var ifn_1228 lang.IFn




					if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any = t__0; if linked_1227 == nil { tmp5 = ifn_1228.Invoke_O__O(arg_1229) } else { tmp5 = linked_1227.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1226, arg_1229) }
//line :435:1
					return lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(t__0, tmp5))
				}
}
func A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A_New() *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A{}; t.Ctor(); return t }
//line :438:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A) Ctor() {}
//line :438:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A) Invoke_O_O__O(self, s__219000158__1 any) any { var tmp1 any = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A_New_O_O(self, s__219000158__1); var tmp2 *jrt.Class; var fncls__1224 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A_fn_class; if fncls__1224 == nil { var fncls__1224d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A_fn_class = fncls__1224d; tmp2 = fncls__1224d } else { tmp2 = fncls__1224 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :438:1
func A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A{}; t.Ctor_O_O(p0, p1); return t }
//line :438:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A) Ctor_O_O(c__iter__219000157, c__s__219000158 any) { t.F_iter__219000157 = c__iter__219000157; t.F_s__219000158 = c__s__219000158 }
//line :438:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A) Invoke_O__O(self any) any { { var s__219000158__1 any; var t_ any = t.F_s__219000158; t.F_s__219000158 = nil; s__219000158__1 = t_; for { var temp__1927000414__auto____2 any; var root_1159 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1159, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1161 lang.IFn; if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = s__219000158__1; if linked_1160 == nil { temp__1927000414__auto____2 = ifn_1161.Invoke_O__O(arg_1162) } else { temp__1927000414__auto____2 = linked_1160.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1159, arg_1162) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000158__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1163 any = A_arbace_go_check_types_A_const_148.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any = s__219000158__3; if linked_1164 == nil { tmp1 = ifn_1165.Invoke_O__O(arg_1166) } else { tmp1 = linked_1164.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1163, arg_1166) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1167 any = A_arbace_go_check_types_A_const_149.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = s__219000158__3; if linked_1168 == nil { c__1927001037__auto____4 = ifn_1169.Invoke_O__O(arg_1170) } else { c__1927001037__auto____4 = linked_1168.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1167, arg_1170) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000160__6 any; var root_1171 any = A_arbace_go_check_types_A_const_150.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1172 == nil { b__219000160__6 = ifn_1173.Invoke_O__O(arg_1174) } else { b__219000160__6 = linked_1172.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1171, arg_1174) }; var tmp2 any = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A_New_O_I_O(b__219000160__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1184 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A_fn_class; if fncls__1184 == nil { var fncls__1184d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A_fn_class = fncls__1184d; tmp3 = fncls__1184d } else { tmp3 = fncls__1184 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1185 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1187 lang.IFn; if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any; var root_1190 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = b__219000160__6; if linked_1191 == nil { arg_1188 = ifn_1192.Invoke_O__O(arg_1193) } else { arg_1188 = linked_1191.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1190, arg_1193) }; var arg_1189 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000157); var tmp5 any; var root_1194 any = A_arbace_go_check_types_A_const_155.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1194, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1196 lang.IFn; if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any = s__219000158__3; if linked_1195 == nil { tmp5 = ifn_1196.Invoke_O__O(arg_1197) } else { tmp5 = linked_1195.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1194, arg_1197) }; arg_1189 = tmp4.Invoke_O__O(tmp5); if linked_1186 == nil { return ifn_1187.Invoke_O_O__O(arg_1188, arg_1189) } else { return linked_1186.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1185, arg_1188, arg_1189) } } else { var root_1198 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1198, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1200 lang.IFn; if linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any; var root_1203 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1203, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1205 lang.IFn; if linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any = b__219000160__6; if linked_1204 == nil { arg_1201 = ifn_1205.Invoke_O__O(arg_1206) } else { arg_1201 = linked_1204.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1203, arg_1206) }; var arg_1202 any; if linked_1199 == nil { return ifn_1200.Invoke_O_O__O(arg_1201, arg_1202) } else { return linked_1199.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1198, arg_1201, arg_1202) } } } else { var vec__219000168__4 any; var root_1207 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any = s__219000158__3; if linked_1208 == nil { vec__219000168__4 = ifn_1209.Invoke_O__O(arg_1210) } else { vec__219000168__4 = linked_1208.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1207, arg_1210) }; var tilde__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000168__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000168__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1211 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); var linked_1212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1211, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1213 lang.IFn; if linked_1212 == nil { ifn_1213 = lang.IFn_Cast(root_1211) } else { ifn_1213 = nil }; var arg_1214 any; var tmp6 any; if jrt.J2g_Truth(tilde__5) { tmp6 = ty__6 } else { var root_1216 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_1217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1216, A_arbace_go_check_types_under_A_fn_class); var ifn_1218 lang.IFn; if linked_1217 == nil { ifn_1218 = lang.IFn_Cast(root_1216) } else { ifn_1218 = nil }; var arg_1219 any = ty__6; if linked_1217 == nil { tmp6 = ifn_1218.Invoke_O__O(arg_1219) } else { tmp6 = linked_1217.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1216, arg_1219) } }; arg_1214 = lang.Tuple_Create_O_O__IPersistentVector(ty__6, tmp6); var arg_1215 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__219000157); var tmp8 any; var root_1220 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1220, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any = s__219000158__3; if linked_1221 == nil { tmp8 = ifn_1222.Invoke_O__O(arg_1223) } else { tmp8 = linked_1221.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1220, arg_1223) }; arg_1215 = tmp7.Invoke_O__O(tmp8); if linked_1212 == nil { return ifn_1213.Invoke_O_O__O(arg_1214, arg_1215) } else { return linked_1212.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1211, arg_1214, arg_1215) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :438:1
func A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :438:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A) Ctor_O_I_O(c__b__219000160 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000160 = c__b__219000160; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :438:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A) Invoke_O__O(self any) any { { var i__219000159__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000159__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__219000164__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000159__1)); var tilde__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000164__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000164__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1175 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1177 lang.IFn; if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any = t.F_b__219000160; var arg_1179 any; var tmp2 any; if jrt.J2g_Truth(tilde__3) { tmp2 = ty__4 } else { var root_1180 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_1181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1180, A_arbace_go_check_types_under_A_fn_class); var ifn_1182 lang.IFn; if linked_1181 == nil { ifn_1182 = lang.IFn_Cast(root_1180) } else { ifn_1182 = nil }; var arg_1183 any = ty__4; if linked_1181 == nil { tmp2 = ifn_1182.Invoke_O__O(arg_1183) } else { tmp2 = linked_1181.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1180, arg_1183) } }; arg_1179 = lang.Tuple_Create_O_O__IPersistentVector(ty__4, tmp2); if linked_1176 == nil { ifn_1177.Invoke_O_O__O(arg_1178, arg_1179) } else { linked_1176.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1175, arg_1178, arg_1179) }; i__219000159__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000159__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_go_check_types_typeset_all_A_New() *A_arbace_go_check_types_typeset_all_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_all_A{}; t.Ctor(); return t }
//line :442:1
func (t *A_arbace_go_check_types_typeset_all_A) Ctor() {}
//line :442:1
func (t *A_arbace_go_check_types_typeset_all_A) Invoke_O_O_O__O(self, t__0, f__1 any) any {


	var root_1230 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_1231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1230, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1232 lang.IFn; if linked_1231 == nil { ifn_1232 = lang.IFn_Cast(root_1230) } else { ifn_1232 = nil }; var arg_1233 any; var tmp1 any = A_arbace_go_check_types_typeset_all_fn__219000175_A_New_O(f__1); var tmp2 *jrt.Class; var fncls__1235 *jrt.Class = A_arbace_go_check_types_typeset_all_fn__219000175_A_fn_class; if fncls__1235 == nil { var fncls__1235d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_go_check_types_typeset_all_fn__219000175_A_fn_class = fncls__1235d; tmp2 = fncls__1235d } else { tmp2 = fncls__1235 }; arg_1233 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1234 any; var root_1236 any = A_arbace_go_check_types_A_const_169.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, A_arbace_go_check_types_typeset_pairs_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = t__0; if linked_1237 == nil { arg_1234 = ifn_1238.Invoke_O__O(arg_1239) } else { arg_1234 = linked_1237.(*A_arbace_go_check_types_typeset_pairs_A).Invoke_O_O__O(root_1236, arg_1239) }; if linked_1231 == nil { return ifn_1232.Invoke_O_O__O(arg_1233, arg_1234) } else { return linked_1231.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1230, arg_1233, arg_1234) } }
//line :445:1
func A_arbace_go_check_types_typeset_all_fn__219000175_A_New_O(p0 any) *A_arbace_go_check_types_typeset_all_fn__219000175_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_all_fn__219000175_A{}; t.Ctor_O(p0); return t }
//line :445:1
func (t *A_arbace_go_check_types_typeset_all_fn__219000175_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :445:1
func (t *A_arbace_go_check_types_typeset_all_fn__219000175_A) Invoke_O_O__O(self, p__219000174__1 any) any { var vec__219000176__2 any = p__219000174__1; var ty__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000176__2, lang.RT_IntCast_J__I_NoInit(0), nil); var u__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000176__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.IFn_Cast(t.F_f).Invoke_O_O__O(ty__3, u__4) }

func A_arbace_go_check_types_under_is_A_New() *A_arbace_go_check_types_under_is_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_is_A{}; t.Ctor(); return t }
//line :447:1
func (t *A_arbace_go_check_types_under_is_A) Ctor() {}
//line :447:1
func (t *A_arbace_go_check_types_under_is_A) Invoke_O_O_O__O(self, t__0, f__1 any) any {



	var root_1240 any = A_arbace_go_check_types_A_const_170.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, A_arbace_go_check_types_typeset_all_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = t__0; var arg_1244 any; var tmp1 any = A_arbace_go_check_types_under_is_fn__219000181_A_New_O(f__1); var tmp2 *jrt.Class; var fncls__1245 *jrt.Class = A_arbace_go_check_types_under_is_fn__219000181_A_fn_class; if fncls__1245 == nil { var fncls__1245d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_go_check_types_under_is_fn__219000181_A_fn_class = fncls__1245d; tmp2 = fncls__1245d } else { tmp2 = fncls__1245 }; arg_1244 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1241 == nil { return ifn_1242.Invoke_O_O__O(arg_1243, arg_1244) } else { return linked_1241.(*A_arbace_go_check_types_typeset_all_A).Invoke_O_O_O__O(root_1240, arg_1243, arg_1244) } }
//line :451:1
func A_arbace_go_check_types_under_is_fn__219000181_A_New_O(p0 any) *A_arbace_go_check_types_under_is_fn__219000181_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_is_fn__219000181_A{}; t.Ctor_O(p0); return t }
//line :451:1
func (t *A_arbace_go_check_types_under_is_fn__219000181_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :451:1
func (t *A_arbace_go_check_types_under_is_fn__219000181_A) Invoke_O_O_O__O(self, ___1, u__2 any) any { return lang.IFn_Cast(t.F_f).Invoke_O__O(u__2) }

func A_arbace_go_check_types_all_basic_A_New() *A_arbace_go_check_types_all_basic_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_basic_A{}; t.Ctor(); return t }
//line :453:1
func (t *A_arbace_go_check_types_all_basic_A) Ctor() {}
//line :453:1
func (t *A_arbace_go_check_types_all_basic_A) Invoke_O_O_O__O(self, t__0, pred__1 any) any {



	var tmp1 any; var root_1246 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1246, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var arg_1249 any = t__0; if linked_1247 == nil { tmp1 = ifn_1248.Invoke_O__O(arg_1249) } else { tmp1 = linked_1247.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_1246, arg_1249) }; if jrt.J2g_Truth(tmp1) { var ts__3 any; var root_1250 any = A_arbace_go_check_types_A_const_132.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1250, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_1252 lang.IFn
		if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = t__0; if linked_1251 == nil { ts__3 = ifn_1252.Invoke_O__O(arg_1253) } else { ts__3 = linked_1251.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_1250, arg_1253) }
		var tmp2 any; var and__1927000168__auto____4 any; var root_1254 any = A_arbace_go_check_types_A_const_167.GetRawRoot__O(); var linked_1255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1254, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_1256 lang.IFn; if linked_1255 == nil { ifn_1256 = lang.IFn_Cast(root_1254) } else { ifn_1256 = nil }; var arg_1257 any = ts__3; if linked_1255 == nil { and__1927000168__auto____4 = ifn_1256.Invoke_O__O(arg_1257) } else { and__1927000168__auto____4 = linked_1255.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_1254, arg_1257) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1258 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1258, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1260 lang.IFn; if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var arg_1261 any; var tmp3 any = A_arbace_go_check_types_all_basic_fn__219000185_A_New_O(pred__1); var tmp4 *jrt.Class; var fncls__1263 *jrt.Class = A_arbace_go_check_types_all_basic_fn__219000185_A_fn_class; if fncls__1263 == nil { var fncls__1263d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_check_types_all_basic_fn__219000185_A_fn_class = fncls__1263d; tmp4 = fncls__1263d } else { tmp4 = fncls__1263 }; arg_1261 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1262 any = A_arbace_go_check_types_A_const_127.Invoke_O__O(ts__3); if linked_1259 == nil { tmp2 = ifn_1260.Invoke_O_O__O(arg_1261, arg_1262) } else { tmp2 = linked_1259.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1258, arg_1261, arg_1262) } } else { tmp2 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp2)).Ref() } else {
			return lang.IFn_Cast(pred__1).Invoke_O__O(t__0) } }
//line :459:1
func A_arbace_go_check_types_all_basic_fn__219000185_A_New_O(p0 any) *A_arbace_go_check_types_all_basic_fn__219000185_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_basic_fn__219000185_A{}; t.Ctor_O(p0); return t }
//line :459:1
func (t *A_arbace_go_check_types_all_basic_fn__219000185_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :459:1
func (t *A_arbace_go_check_types_all_basic_fn__219000185_A) Invoke_O_O__O(self, p__219000184__1 any) any { var vec__219000186__2 any = p__219000184__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000186__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000186__2, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___3; return lang.IFn_Cast(t.F_pred).Invoke_O__O(ty__4) }


func A_arbace_go_check_types_all_integer_QMARK__A_New() *A_arbace_go_check_types_all_integer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_integer_QMARK__A{}; t.Ctor(); return t }
//line :462:1
func (t *A_arbace_go_check_types_all_integer_QMARK__A) Ctor() {}
//line :462:1
func (t *A_arbace_go_check_types_all_integer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1264 any = A_arbace_go_check_types_A_const_171.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1266 lang.IFn; if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any = t__0; var arg_1268 any = A_arbace_go_check_types_A_const_110.GetRawRoot__O(); if linked_1265 == nil { return ifn_1266.Invoke_O_O__O(arg_1267, arg_1268) } else { return linked_1265.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1264, arg_1267, arg_1268) } }
func A_arbace_go_check_types_all_unsigned_QMARK__A_New() *A_arbace_go_check_types_all_unsigned_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_unsigned_QMARK__A{}; t.Ctor(); return t }
//line :463:1
func (t *A_arbace_go_check_types_all_unsigned_QMARK__A) Ctor() {}
//line :463:1
func (t *A_arbace_go_check_types_all_unsigned_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1269 any = A_arbace_go_check_types_A_const_171.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = t__0; var arg_1273 any = A_arbace_go_check_types_A_const_172.GetRawRoot__O(); if linked_1270 == nil { return ifn_1271.Invoke_O_O__O(arg_1272, arg_1273) } else { return linked_1270.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1269, arg_1272, arg_1273) } }
func A_arbace_go_check_types_all_numeric_QMARK__A_New() *A_arbace_go_check_types_all_numeric_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_QMARK__A{}; t.Ctor(); return t }
//line :464:1
func (t *A_arbace_go_check_types_all_numeric_QMARK__A) Ctor() {}
//line :464:1
func (t *A_arbace_go_check_types_all_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1274 any = A_arbace_go_check_types_A_const_171.GetRawRoot__O(); var linked_1275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1274, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1276 lang.IFn; if linked_1275 == nil { ifn_1276 = lang.IFn_Cast(root_1274) } else { ifn_1276 = nil }; var arg_1277 any = t__0; var arg_1278 any = A_arbace_go_check_types_A_const_173.GetRawRoot__O(); if linked_1275 == nil { return ifn_1276.Invoke_O_O__O(arg_1277, arg_1278) } else { return linked_1275.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1274, arg_1277, arg_1278) } }
func A_arbace_go_check_types_all_string_QMARK__A_New() *A_arbace_go_check_types_all_string_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_string_QMARK__A{}; t.Ctor(); return t }
//line :465:1
func (t *A_arbace_go_check_types_all_string_QMARK__A) Ctor() {}
//line :465:1
func (t *A_arbace_go_check_types_all_string_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1279 any = A_arbace_go_check_types_A_const_171.GetRawRoot__O(); var linked_1280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1279, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1281 lang.IFn; if linked_1280 == nil { ifn_1281 = lang.IFn_Cast(root_1279) } else { ifn_1281 = nil }; var arg_1282 any = t__0; var arg_1283 any = A_arbace_go_check_types_A_const_115.GetRawRoot__O(); if linked_1280 == nil { return ifn_1281.Invoke_O_O__O(arg_1282, arg_1283) } else { return linked_1280.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1279, arg_1282, arg_1283) } }
func A_arbace_go_check_types_all_boolean_QMARK__A_New() *A_arbace_go_check_types_all_boolean_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_boolean_QMARK__A{}; t.Ctor(); return t }
//line :466:1
func (t *A_arbace_go_check_types_all_boolean_QMARK__A) Ctor() {}
//line :466:1
func (t *A_arbace_go_check_types_all_boolean_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1284 any = A_arbace_go_check_types_A_const_171.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = t__0; var arg_1288 any = A_arbace_go_check_types_A_const_174.GetRawRoot__O(); if linked_1285 == nil { return ifn_1286.Invoke_O_O__O(arg_1287, arg_1288) } else { return linked_1285.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1284, arg_1287, arg_1288) } }
func A_arbace_go_check_types_all_ordered_QMARK__A_New() *A_arbace_go_check_types_all_ordered_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_ordered_QMARK__A{}; t.Ctor(); return t }
//line :467:1
func (t *A_arbace_go_check_types_all_ordered_QMARK__A) Ctor() {}
//line :467:1
func (t *A_arbace_go_check_types_all_ordered_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1289 any = A_arbace_go_check_types_A_const_171.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = t__0; var arg_1293 any = A_arbace_go_check_types_A_const_175.GetRawRoot__O(); if linked_1290 == nil { return ifn_1291.Invoke_O_O__O(arg_1292, arg_1293) } else { return linked_1290.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1289, arg_1292, arg_1293) } }
func A_arbace_go_check_types_all_numeric_or_string_QMARK__A_New() *A_arbace_go_check_types_all_numeric_or_string_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_or_string_QMARK__A{}; t.Ctor(); return t }
//line :468:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__A) Ctor() {}
//line :468:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1294 any = A_arbace_go_check_types_A_const_171.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1294, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1296 lang.IFn; if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any = t__0; var arg_1298 any; var tmp1 any = A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A_New(); var tmp2 *jrt.Class; var fncls__1307 *jrt.Class = A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A_fn_class; if fncls__1307 == nil { var fncls__1307d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A_fn_class = fncls__1307d; tmp2 = fncls__1307d } else { tmp2 = fncls__1307 }; arg_1298 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1295 == nil { return ifn_1296.Invoke_O_O__O(arg_1297, arg_1298) } else { return linked_1295.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1294, arg_1297, arg_1298) } }
//line :468:1
func A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A_New() *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A{}; t.Ctor(); return t }
//line :468:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A) Ctor() {}
//line :468:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A) Invoke_O_O__O(self, p1__219000197_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_1299 any = A_arbace_go_check_types_A_const_173.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, A_arbace_go_check_types_numeric_QMARK__A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = p1__219000197_SHARP___1; if linked_1300 == nil { or__1927000174__auto____2 = ifn_1301.Invoke_O__O(arg_1302) } else { or__1927000174__auto____2 = linked_1300.(*A_arbace_go_check_types_numeric_QMARK__A).Invoke_O_O__O(root_1299, arg_1302) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_1303 any = A_arbace_go_check_types_A_const_115.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, A_arbace_go_check_types_string_type_QMARK__A_fn_class); var ifn_1305 lang.IFn; if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any = p1__219000197_SHARP___1; if linked_1304 == nil { return ifn_1305.Invoke_O__O(arg_1306) } else { return linked_1304.(*A_arbace_go_check_types_string_type_QMARK__A).Invoke_O_O__O(root_1303, arg_1306) } } }
func A_arbace_go_check_types_all_float_QMARK__A_New() *A_arbace_go_check_types_all_float_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_float_QMARK__A{}; t.Ctor(); return t }
//line :469:1
func (t *A_arbace_go_check_types_all_float_QMARK__A) Ctor() {}
//line :469:1
func (t *A_arbace_go_check_types_all_float_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1308 any = A_arbace_go_check_types_A_const_171.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1308, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1310 lang.IFn; if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any = t__0; var arg_1312 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); if linked_1309 == nil { return ifn_1310.Invoke_O_O__O(arg_1311, arg_1312) } else { return linked_1309.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1308, arg_1311, arg_1312) } }
func A_arbace_go_check_types_all_complex_QMARK__A_New() *A_arbace_go_check_types_all_complex_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_complex_QMARK__A{}; t.Ctor(); return t }
//line :470:1
func (t *A_arbace_go_check_types_all_complex_QMARK__A) Ctor() {}
//line :470:1
func (t *A_arbace_go_check_types_all_complex_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1313 any = A_arbace_go_check_types_A_const_171.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1313, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1315 lang.IFn; if linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any = t__0; var arg_1317 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); if linked_1314 == nil { return ifn_1315.Invoke_O_O__O(arg_1316, arg_1317) } else { return linked_1314.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1313, arg_1316, arg_1317) } }

func A_arbace_go_check_types_common_under_A_New() *A_arbace_go_check_types_common_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_common_under_A{}; t.Ctor(); return t }
//line :472:1
func (t *A_arbace_go_check_types_common_under_A) Ctor() {}
//line :472:1
func (t *A_arbace_go_check_types_common_under_A) Invoke_O_O_O__O(self, t__0, cnd__1 any) any { { var ps__3 any; var root_1318 any = A_arbace_go_check_types_A_const_169.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1318, A_arbace_go_check_types_typeset_pairs_A_fn_class); var ifn_1320 lang.IFn





	if linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any = t__0; if linked_1319 == nil { ps__3 = ifn_1320.Invoke_O__O(arg_1321) } else { ps__3 = linked_1319.(*A_arbace_go_check_types_typeset_pairs_A).Invoke_O_O__O(root_1318, arg_1321) }
//line :472:1
	var ct__4 any; var cu__5 any; L1: for {






		var tmp1 any; var root_1322 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1322, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1324 lang.IFn; if linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any = ps__3; if linked_1323 == nil { tmp1 = ifn_1324.Invoke_O__O(arg_1325) } else { tmp1 = linked_1323.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1322, arg_1325) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(cu__5, nil) } else { var vec__219000203__6 any; var root_1326 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_1327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1326, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1328 lang.IFn

			if linked_1327 == nil { ifn_1328 = lang.IFn_Cast(root_1326) } else { ifn_1328 = nil }; var arg_1329 any = ps__3; if linked_1327 == nil { vec__219000203__6 = ifn_1328.Invoke_O__O(arg_1329) } else { vec__219000203__6 = linked_1327.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1326, arg_1329) }
//line :479:1
			var ty__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000203__6, lang.RT_IntCast_J__I_NoInit(0), nil); var u__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000203__6, lang.RT_IntCast_J__I_NoInit(1), nil); var e__9 any


			if jrt.J2g_Truth(cnd__1) { e__9 = lang.IFn_Cast(cnd__1).Invoke_O_O__O(ty__7, u__8) } else { e__9 = nil }
			if jrt.J2g_Truth(e__9) { return lang.Tuple_Create_O_O__IPersistentVector(nil, e__9) } else { if lang.Util_Identical_O_O__Z_NoInit(u__8, nil) { return A_arbace_go_check_types_A_const_176 } else { if lang.Util_Identical_O_O__Z_NoInit(cu__5, nil) {


				var tmp2 any; var root_1361 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1361, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1363 lang.IFn; if linked_1362 == nil { ifn_1363 = lang.IFn_Cast(root_1361) } else { ifn_1363 = nil }; var arg_1364 any = ps__3; if linked_1362 == nil { tmp2 = ifn_1363.Invoke_O__O(arg_1364) } else { tmp2 = linked_1362.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1361, arg_1364) }; ps__3, ct__4, cu__5 = tmp2, ty__7, u__8; continue L1 } else {
//line :483:1
					var tmp3 any; var and__1927000168__auto____10 any; var root_1330 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1332 lang.IFn



					if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = cu__5; if linked_1331 == nil { and__1927000168__auto____10 = ifn_1332.Invoke_O__O(arg_1333) } else { and__1927000168__auto____10 = linked_1331.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1330, arg_1333) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp4 any = A_arbace_go_check_types_A_const_76; var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____11 { var and__1927000168__auto____12 any; var root_1334 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = u__8; if linked_1335 == nil { and__1927000168__auto____12 = ifn_1336.Invoke_O__O(arg_1337) } else { and__1927000168__auto____12 = linked_1335.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1334, arg_1337) }; if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp5 any = A_arbace_go_check_types_A_const_76; tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp5, lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp3 = and__1927000168__auto____12 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else { tmp3 = and__1927000168__auto____10 }
//line :483:1
					if jrt.J2g_Truth(tmp3) {




						var tmp6 any; var root_1338 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1340 lang.IFn
						if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any; var root_1342 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_1344 lang.IFn; if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(2)); var arg_1346 any = lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(2)); if linked_1343 == nil { arg_1341 = ifn_1344.Invoke_O_O__O(arg_1345, arg_1346) } else { arg_1341 = linked_1343.(*A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_1342, arg_1345, arg_1346) }; if linked_1339 == nil { tmp6 = ifn_1340.Invoke_O__O(arg_1341) } else { tmp6 = linked_1339.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1338, arg_1341) }
//line :488:1
						if jrt.J2g_Truth(tmp6) { return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7, nil, Lit_8), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_go_check_types_A_const_180.GetRawRoot__O()).Invoke_O__O(ct__4), nil, lang.IFn_Cast(A_arbace_go_check_types_A_const_180.GetRawRoot__O()).Invoke_O__O(ty__7), nil)).Ref()) } else { if lang.Util_Equiv_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(1)), lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(1))) {

							var tmp7 any; var root_1373 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any = ps__3; if linked_1374 == nil { tmp7 = ifn_1375.Invoke_O__O(arg_1376) } else { tmp7 = linked_1374.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1373, arg_1376) }; ps__3, ct__4, cu__5 = tmp7, ct__4, cu__5; continue L1 } else {
//line :488:1
								var tmp8 any = A_arbace_go_check_types_A_const_177; if lang.Util_Equiv_O_O__Z_NoInit(tmp8, lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(1))) {


									var tmp9 any; var root_1377 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any = ps__3; if linked_1378 == nil { tmp9 = ifn_1379.Invoke_O__O(arg_1380) } else { tmp9 = linked_1378.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1377, arg_1380) }; ps__3, ct__4, cu__5 = tmp9, ty__7, u__8; continue L1 } else {
//line :488:1
										var tmp10 any; var root_1347 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_1348 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1347, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1349 lang.IFn



										if linked_1348 == nil { ifn_1349 = lang.IFn_Cast(root_1347) } else { ifn_1349 = nil }; var arg_1350 any = A_arbace_go_check_types_A_const_177; var arg_1351 any = lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(1)); if linked_1348 == nil { tmp10 = ifn_1349.Invoke_O_O__O(arg_1350, arg_1351) } else { tmp10 = linked_1348.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1347, arg_1350, arg_1351) }
//line :488:1
										if jrt.J2g_Truth(tmp10) { return A_arbace_go_check_types_A_const_178 } else { if A_arbace_go_check_types_A_const_88 != nil {




											var tmp11 any; var root_1381 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1381, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1383 lang.IFn; if linked_1382 == nil { ifn_1383 = lang.IFn_Cast(root_1381) } else { ifn_1383 = nil }; var arg_1384 any = ps__3; if linked_1382 == nil { tmp11 = ifn_1383.Invoke_O__O(arg_1384) } else { tmp11 = linked_1382.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1381, arg_1384) }; ps__3, ct__4, cu__5 = tmp11, ct__4, cu__5; continue L1 } else {
//line :488:1
												return nil } } } } } } else {
//line :483:1
													var tmp12 any; var root_1352 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_1353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1352, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1354 lang.IFn










													if linked_1353 == nil { ifn_1354 = lang.IFn_Cast(root_1352) } else { ifn_1354 = nil }; var arg_1355 any; var root_1356 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_1357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1356, A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_1358 lang.IFn; if linked_1357 == nil { ifn_1358 = lang.IFn_Cast(root_1356) } else { ifn_1358 = nil }; var arg_1359 any = cu__5; var arg_1360 any = u__8; if linked_1357 == nil { arg_1355 = ifn_1358.Invoke_O_O__O(arg_1359, arg_1360) } else { arg_1355 = linked_1357.(*A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_1356, arg_1359, arg_1360) }; if linked_1353 == nil { tmp12 = ifn_1354.Invoke_O__O(arg_1355) } else { tmp12 = linked_1353.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1352, arg_1355) }
//line :483:1
													if jrt.J2g_Truth(tmp12) { return A_arbace_go_check_types_A_const_179 } else { if A_arbace_go_check_types_A_const_88 != nil {











														var tmp13 any; var root_1385 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1385, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1387 lang.IFn; if linked_1386 == nil { ifn_1387 = lang.IFn_Cast(root_1385) } else { ifn_1387 = nil }; var arg_1388 any = ps__3; if linked_1386 == nil { tmp13 = ifn_1387.Invoke_O__O(arg_1388) } else { tmp13 = linked_1386.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1385, arg_1388) }; ps__3, ct__4, cu__5 = tmp13, ct__4, cu__5; continue L1 } else {
//line :483:1
															return nil } } } } } } } } }; /*line :472:1*/panic("j2g: unreachable") }
//line :472:1
func (t *A_arbace_go_check_types_common_under_A) Invoke_O_O__O(self, t__0 any) any {



	var root_1389 any = A_arbace_go_check_types_A_const_181.GetRawRoot__O(); var linked_1390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1389, A_arbace_go_check_types_common_under_A_fn_class); var ifn_1391 lang.IFn; if linked_1390 == nil { ifn_1391 = lang.IFn_Cast(root_1389) } else { ifn_1391 = nil }; var arg_1392 any = t__0; var arg_1393 any; if linked_1390 == nil { return ifn_1391.Invoke_O_O__O(arg_1392, arg_1393) } else { return linked_1390.(*A_arbace_go_check_types_common_under_A).Invoke_O_O_O__O(root_1389, arg_1392, arg_1393)
	}
}


















func A_arbace_go_check_types_core_type_A_New() *A_arbace_go_check_types_core_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_core_type_A{}; t.Ctor(); return t }
//line :497:1
func (t *A_arbace_go_check_types_core_type_A) Ctor() {}
//line :497:1
func (t *A_arbace_go_check_types_core_type_A) Invoke_O_O__O(self, t__0 any) any {


	var root_1394 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1394, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1396 lang.IFn; if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any; var root_1398 any = A_arbace_go_check_types_A_const_181.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, A_arbace_go_check_types_common_under_A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any = t__0; if linked_1399 == nil { arg_1397 = ifn_1400.Invoke_O__O(arg_1401) } else { arg_1397 = linked_1399.(*A_arbace_go_check_types_common_under_A).Invoke_O_O__O(root_1398, arg_1401) }; if linked_1395 == nil { return ifn_1396.Invoke_O__O(arg_1397) } else { return linked_1395.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1394, arg_1397)
	}
}








func A_arbace_go_check_types_terms_str_A_New() *A_arbace_go_check_types_terms_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_A{}; t.Ctor(); return t }
//line :511:1
func (t *A_arbace_go_check_types_terms_str_A) Ctor() {}
//line :511:1
func (t *A_arbace_go_check_types_terms_str_A) Invoke_O_O__O(self, terms__0 any) any {
	var tmp1 any; var root_1402 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1404 lang.IFn; if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any = terms__0; if linked_1403 == nil { tmp1 = ifn_1404.Invoke_O__O(arg_1405) } else { tmp1 = linked_1403.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1402, arg_1405) }; if jrt.J2g_Truth(tmp1) { return Lit_53 } else { var ts__2 any; var tmp2 *lang.Keyword = A_arbace_go_check_types_A_const_143; var or__1927000174__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(terms__0))

		if jrt.J2g_Truth(or__1927000174__auto____2) { ts__2 = or__1927000174__auto____2 } else { var root_1406 any = A_arbace_go_check_types_A_const_182.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1408 lang.IFn; if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any = A_arbace_go_check_types_A_const_180.GetRawRoot__O(); var arg_1410 any = terms__0; if linked_1407 == nil { ts__2 = ifn_1408.Invoke_O_O__O(arg_1409, arg_1410) } else { ts__2 = linked_1407.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1406, arg_1409, arg_1410) } }
		var root_1411 any = A_arbace_go_check_types_A_const_183.GetRawRoot__O(); var linked_1412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1411, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1413 lang.IFn; if linked_1412 == nil { ifn_1413 = lang.IFn_Cast(root_1411) } else { ifn_1413 = nil }; var arg_1414 any = Lit_54; var arg_1415 any; var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_go_check_types_terms_str_iter__219000208__219000212_A_New(); var tmp4 *jrt.Class; var fncls__1482 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000208__219000212_A_fn_class; if fncls__1482 == nil { var fncls__1482d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_check_types_terms_str_iter__219000208__219000212_A_fn_class = fncls__1482d; tmp4 = fncls__1482d } else { tmp4 = fncls__1482 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); arg_1415 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(ts__2); if linked_1412 == nil { return ifn_1413.Invoke_O_O__O(arg_1414, arg_1415) } else { return linked_1412.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1411, arg_1414, arg_1415) } } }
//line :515:1
func A_arbace_go_check_types_terms_str_iter__219000208__219000212_A_New() *A_arbace_go_check_types_terms_str_iter__219000208__219000212_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000208__219000212_A{}; t.Ctor(); return t }
//line :515:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_A) Ctor() {}
//line :515:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_A) Invoke_O_O__O(self, s__219000209__1 any) any { var tmp1 any = A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A_New_O_O(self, s__219000209__1); var tmp2 *jrt.Class; var fncls__1481 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A_fn_class; if fncls__1481 == nil { var fncls__1481d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A_fn_class = fncls__1481d; tmp2 = fncls__1481d } else { tmp2 = fncls__1481 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :515:1
func A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A{}; t.Ctor_O_O(p0, p1); return t }
//line :515:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A) Ctor_O_O(c__iter__219000208, c__s__219000209 any) { t.F_iter__219000208 = c__iter__219000208; t.F_s__219000209 = c__s__219000209 }
//line :515:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A) Invoke_O__O(self any) any { { var s__219000209__1 any; var t_ any = t.F_s__219000209; t.F_s__219000209 = nil; s__219000209__1 = t_; for { var temp__1927000414__auto____2 any; var root_1416 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = s__219000209__1; if linked_1417 == nil { temp__1927000414__auto____2 = ifn_1418.Invoke_O__O(arg_1419) } else { temp__1927000414__auto____2 = linked_1417.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1416, arg_1419) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000209__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1420 any = A_arbace_go_check_types_A_const_148.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1420, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any = s__219000209__3; if linked_1421 == nil { tmp1 = ifn_1422.Invoke_O__O(arg_1423) } else { tmp1 = linked_1421.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1420, arg_1423) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1424 any = A_arbace_go_check_types_A_const_149.GetRawRoot__O(); var linked_1425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1424, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1426 lang.IFn; if linked_1425 == nil { ifn_1426 = lang.IFn_Cast(root_1424) } else { ifn_1426 = nil }; var arg_1427 any = s__219000209__3; if linked_1425 == nil { c__1927001037__auto____4 = ifn_1426.Invoke_O__O(arg_1427) } else { c__1927001037__auto____4 = linked_1425.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1424, arg_1427) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000211__6 any; var root_1428 any = A_arbace_go_check_types_A_const_150.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1430 lang.IFn; if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1429 == nil { b__219000211__6 = ifn_1430.Invoke_O__O(arg_1431) } else { b__219000211__6 = linked_1429.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1428, arg_1431) }; var tmp2 any = A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A_New_O_I_O(b__219000211__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1441 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A_fn_class; if fncls__1441 == nil { var fncls__1441d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A_fn_class = fncls__1441d; tmp3 = fncls__1441d } else { tmp3 = fncls__1441 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1442 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1442, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1444 lang.IFn; if linked_1443 == nil { ifn_1444 = lang.IFn_Cast(root_1442) } else { ifn_1444 = nil }; var arg_1445 any; var root_1447 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1447, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1449 lang.IFn; if linked_1448 == nil { ifn_1449 = lang.IFn_Cast(root_1447) } else { ifn_1449 = nil }; var arg_1450 any = b__219000211__6; if linked_1448 == nil { arg_1445 = ifn_1449.Invoke_O__O(arg_1450) } else { arg_1445 = linked_1448.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1447, arg_1450) }; var arg_1446 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000208); var tmp5 any; var root_1451 any = A_arbace_go_check_types_A_const_155.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1451, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1453 lang.IFn; if linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any = s__219000209__3; if linked_1452 == nil { tmp5 = ifn_1453.Invoke_O__O(arg_1454) } else { tmp5 = linked_1452.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1451, arg_1454) }; arg_1446 = tmp4.Invoke_O__O(tmp5); if linked_1443 == nil { return ifn_1444.Invoke_O_O__O(arg_1445, arg_1446) } else { return linked_1443.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1442, arg_1445, arg_1446) } } else { var root_1455 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1455, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1457 lang.IFn; if linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any; var root_1460 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1460, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1462 lang.IFn; if linked_1461 == nil { ifn_1462 = lang.IFn_Cast(root_1460) } else { ifn_1462 = nil }; var arg_1463 any = b__219000211__6; if linked_1461 == nil { arg_1458 = ifn_1462.Invoke_O__O(arg_1463) } else { arg_1458 = linked_1461.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1460, arg_1463) }; var arg_1459 any; if linked_1456 == nil { return ifn_1457.Invoke_O_O__O(arg_1458, arg_1459) } else { return linked_1456.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1455, arg_1458, arg_1459) } } } else { var vec__219000219__4 any; var root_1464 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_1465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1464, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1466 lang.IFn; if linked_1465 == nil { ifn_1466 = lang.IFn_Cast(root_1464) } else { ifn_1466 = nil }; var arg_1467 any = s__219000209__3; if linked_1465 == nil { vec__219000219__4 = ifn_1466.Invoke_O__O(arg_1467) } else { vec__219000219__4 = linked_1465.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1464, arg_1467) }; var tilde__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000219__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000219__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1468 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); var linked_1469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1468, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1470 lang.IFn; if linked_1469 == nil { ifn_1470 = lang.IFn_Cast(root_1468) } else { ifn_1470 = nil }; var arg_1471 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 *jrt.String; if jrt.J2g_Truth(tilde__5) { tmp7 = Lit_58 } else { tmp7 = nil }; var tmp8 any = tmp7.Ref(); var tmp9 any; var root_1473 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = ty__6; if linked_1474 == nil { tmp9 = ifn_1475.Invoke_O__O(arg_1476) } else { tmp9 = linked_1474.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1473, arg_1476) }; arg_1471 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9)).Ref(); var arg_1472 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__219000208); var tmp11 any; var root_1477 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1477, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1479 lang.IFn; if linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any = s__219000209__3; if linked_1478 == nil { tmp11 = ifn_1479.Invoke_O__O(arg_1480) } else { tmp11 = linked_1478.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1477, arg_1480) }; arg_1472 = tmp10.Invoke_O__O(tmp11); if linked_1469 == nil { return ifn_1470.Invoke_O_O__O(arg_1471, arg_1472) } else { return linked_1469.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1468, arg_1471, arg_1472) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :515:1
func A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :515:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A) Ctor_O_I_O(c__b__219000211 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000211 = c__b__219000211; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :515:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A) Invoke_O__O(self any) any { { var i__219000210__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000210__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__219000215__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000210__1)); var tilde__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000215__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000215__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1432 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_1433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1432, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1434 lang.IFn; if linked_1433 == nil { ifn_1434 = lang.IFn_Cast(root_1432) } else { ifn_1434 = nil }; var arg_1435 any = t.F_b__219000211; var arg_1436 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 *jrt.String; if jrt.J2g_Truth(tilde__3) { tmp3 = Lit_58 } else { tmp3 = nil }; var tmp4 any = tmp3.Ref(); var tmp5 any; var root_1437 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1439 lang.IFn; if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any = ty__4; if linked_1438 == nil { tmp5 = ifn_1439.Invoke_O__O(arg_1440) } else { tmp5 = linked_1438.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1437, arg_1440) }; arg_1436 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5)).Ref(); if linked_1433 == nil { ifn_1434.Invoke_O_O__O(arg_1435, arg_1436) } else { linked_1433.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1432, arg_1435, arg_1436) }; i__219000210__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000210__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_types_params_str_A_New() *A_arbace_go_check_types_params_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_params_str_A{}; t.Ctor(); return t }
//line :517:1
func (t *A_arbace_go_check_types_params_str_A) Ctor() {}
//line :517:1
func (t *A_arbace_go_check_types_params_str_A) Invoke_O_O_O__O(self, ps__0, variadic__1 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_31, nil, Lit_32); var tmp2 any; var root_1483 any = A_arbace_go_check_types_A_const_183.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1485 lang.IFn
	if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any = Lit_33; var arg_1487 any; var root_1488 any = A_arbace_go_check_types_A_const_184.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any; var tmp3 any = A_arbace_go_check_types_params_str_fn__219000225_A_New_O_O(ps__0, variadic__1); var tmp4 *jrt.Class; var fncls__1501 *jrt.Class = A_arbace_go_check_types_params_str_fn__219000225_A_fn_class; if fncls__1501 == nil { var fncls__1501d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_check_types_params_str_fn__219000225_A_fn_class = fncls__1501d; tmp4 = fncls__1501d } else { tmp4 = fncls__1501 }; arg_1491 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1492 any = ps__0; if linked_1489 == nil { arg_1487 = ifn_1490.Invoke_O_O__O(arg_1491, arg_1492) } else { arg_1487 = linked_1489.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1488, arg_1491, arg_1492) }; if linked_1484 == nil { tmp2 = ifn_1485.Invoke_O_O__O(arg_1486, arg_1487) } else { tmp2 = linked_1484.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1483, arg_1486, arg_1487) }
//line :518:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil)).Ref() }
func A_arbace_go_check_types_params_str_fn__219000225_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_params_str_fn__219000225_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_params_str_fn__219000225_A{}; t.Ctor_O_O(p0, p1); return t }
//line :519:1
func (t *A_arbace_go_check_types_params_str_fn__219000225_A) Ctor_O_O(c__ps, c__variadic any) { t.F_ps = c__ps; t.F_variadic = c__variadic }
//line :519:1
func (t *A_arbace_go_check_types_params_str_fn__219000225_A) Invoke_O_O_O__O(self, i__1, p__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = t.F_variadic; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_J__Z_NoInit(i__1, lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_ps))))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_35, nil); var tmp3 any; var root_1493 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1493, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1495 lang.IFn; if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any = lang.RT_Nth_O_I__O_NoInit(p__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1494 == nil { tmp3 = ifn_1495.Invoke_O__O(arg_1496) } else { tmp3 = linked_1494.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1493, arg_1496) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else {
			var root_1497 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1497, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1499 lang.IFn; if linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; var arg_1500 any = p__2; if linked_1498 == nil { return ifn_1499.Invoke_O__O(arg_1500) } else { return linked_1498.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1497, arg_1500)
			}
		}
}
func A_arbace_go_check_types_sig_str_A_New() *A_arbace_go_check_types_sig_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sig_str_A{}; t.Ctor(); return t }
//line :526:1
func (t *A_arbace_go_check_types_sig_str_A) Ctor() {}
//line :526:1
func (t *A_arbace_go_check_types_sig_str_A) Invoke_O_O__O(self, p__219000228__0 any) any { var vec__219000229__2 any = p__219000228__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000229__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000229__2, lang.RT_IntCast_J__I_NoInit(1), nil); var rs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000229__2, lang.RT_IntCast_J__I_NoInit(2), nil); var variadic__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000229__2, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_1502 any = A_arbace_go_check_types_A_const_185.GetRawRoot__O(); var linked_1503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1502, A_arbace_go_check_types_params_str_A_fn_class); var ifn_1504 lang.IFn; _ = ___3; if


	linked_1503 == nil { ifn_1504 = lang.IFn_Cast(root_1502) } else { ifn_1504 = nil }; var arg_1505 any = ps__4; var arg_1506 any = variadic__6; if linked_1503 == nil { tmp2 = ifn_1504.Invoke_O_O__O(arg_1505, arg_1506) } else { tmp2 = linked_1503.(*A_arbace_go_check_types_params_str_A).Invoke_O_O_O__O(root_1502, arg_1505, arg_1506) }; var tmp3 any = tmp2; var tmp4 *jrt.String; var G__219000232__9_ int32 = lang.RT_Count_O__I_NoInit(rs__5); L1:
	switch { default: switch G__219000232__9_ { case 0: tmp4 = Lit_10; break L1; case 1: var r__10 any; var root_1508 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1508, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1510 lang.IFn

		if linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any = rs__5; if linked_1509 == nil { r__10 = ifn_1510.Invoke_O__O(arg_1511) } else { r__10 = linked_1509.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1508, arg_1511) }; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_11, nil); var tmp6 any; var root_1512 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1512, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1514 lang.IFn; if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; var arg_1515 any = r__10; if linked_1513 == nil { tmp6 = ifn_1514.Invoke_O__O(arg_1515) } else { tmp6 = linked_1513.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1512, arg_1515) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6))
//line :530:1
		break L1; default:
	}

		var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_32); var tmp8 any; var root_1516 any = A_arbace_go_check_types_A_const_183.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1516, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1518 lang.IFn; if linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any = Lit_33; var arg_1520 any; var root_1521 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1521, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1523 lang.IFn; if linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1524 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var arg_1525 any = rs__5; if linked_1522 == nil { arg_1520 = ifn_1523.Invoke_O_O__O(arg_1524, arg_1525) } else { arg_1520 = linked_1522.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1521, arg_1524, arg_1525) }; if linked_1517 == nil { tmp8 = ifn_1518.Invoke_O_O__O(arg_1519, arg_1520) } else { tmp8 = linked_1517.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1516, arg_1519, arg_1520) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil))}; return /*line :529:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4.Ref())).Ref() }





func A_arbace_go_check_types_field_str_A_New() *A_arbace_go_check_types_field_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_field_str_A{}; t.Ctor(); return t }
//line :535:1
func (t *A_arbace_go_check_types_field_str_A) Ctor() {}
//line :535:1
func (t *A_arbace_go_check_types_field_str_A) Invoke_O_O__O(self, f__0 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 *jrt.String; if jrt.J2g_Truth(A_arbace_go_check_types_A_const_186.Invoke_O__O(f__0)) { tmp2 = Lit_10 } else { tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_12.Invoke_O__O(f__0), nil)) }; var tmp3 any = tmp2.Ref(); var tmp4 any; var root_1526 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1526, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any = A_arbace_go_check_types_A_const_70.Invoke_O__O(f__0); if linked_1527 == nil { tmp4 = ifn_1528.Invoke_O__O(arg_1529) } else { tmp4 = linked_1527.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1526, arg_1529) }; var tmp5 any = tmp4; var tmp6 *jrt.String
	if jrt.J2g_Truth(A_arbace_go_check_types_A_const_125.Invoke_O__O(f__0)) { var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_11, nil); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_180.GetRawRoot__O()); var tmp9 any; var root_1534 any = A_arbace_go_check_types_A_const_187.GetRawRoot__O(); var linked_1535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1534, aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A_fn_class); var ifn_1536 lang.IFn; if linked_1535 == nil { ifn_1536 = lang.IFn_Cast(root_1534) } else { ifn_1536 = nil }; var arg_1537 any = A_arbace_go_check_types_A_const_125.Invoke_O__O(f__0); if linked_1535 == nil { tmp9 = ifn_1536.Invoke_O__O(arg_1537) } else { tmp9 = linked_1535.(*aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A).Invoke_O_O__O(root_1534, arg_1537) }; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8.Invoke_O__O(tmp9))) } else { tmp6 = nil }
//line :536:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp5, tmp6.Ref())).Ref()
}

func A_arbace_go_check_types_named_str_A_New() *A_arbace_go_check_types_named_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_str_A{}; t.Ctor(); return t }
//line :539:1
func (t *A_arbace_go_check_types_named_str_A) Ctor() {}
//line :539:1
func (t *A_arbace_go_check_types_named_str_A) Invoke_O_O__O(self, t__0 any) any { var i__2 any; var root_1538 any = A_arbace_go_check_types_A_const_97.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, A_arbace_go_check_types_info_A_fn_class); var ifn_1540 lang.IFn; if
										linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = t__0; if linked_1539 == nil { i__2 = ifn_1540.Invoke_O__O(arg_1541) } else { i__2 = linked_1539.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1538, arg_1541) }; var base__3 any; var tmp1 any; var and__1927000168__auto____3 any = /*line :539:1*/A_arbace_go_check_types_A_const_57.Invoke_O__O(i__2); if

	jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1542 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1542, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1544 lang.IFn; if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(i__2); var arg_1546 any = A_arbace_go_check_types_A_const_188.Get__O(); if linked_1543 == nil { and__1927000168__auto____4 = ifn_1544.Invoke_O_O__O(arg_1545, arg_1546) } else { and__1927000168__auto____4 = linked_1543.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1542, arg_1545, arg_1546) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1547 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_1548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1547, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1549 lang.IFn; if linked_1548 == nil { ifn_1549 = lang.IFn_Cast(root_1547) } else { ifn_1549 = nil }; var arg_1550 any = A_arbace_go_check_types_A_const_189.Invoke_O__O(i__2); if linked_1548 == nil { tmp1 = ifn_1549.Invoke_O__O(arg_1550) } else { tmp1 = linked_1548.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1547, arg_1550) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		base__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_190.Invoke_O__O(i__2), nil, A_arbace_go_check_types_A_const_12.Invoke_O__O(i__2))).Ref() } else {
			base__3 = A_arbace_go_check_types_A_const_12.Invoke_O__O(i__2) }; var tmp2 any; var root_1551 any =
	A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1551, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1553 lang.IFn; if linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any = A_arbace_go_check_types_A_const_191.Invoke_O__O(i__2); if linked_1552 == nil { tmp2 = ifn_1553.Invoke_O__O(arg_1554) } else { tmp2 = linked_1552.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1551, arg_1554) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_27, nil, Lit_28); var tmp4 any; var root_1555 any = A_arbace_go_check_types_A_const_183.GetRawRoot__O(); var linked_1556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1555, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1557 lang.IFn; if linked_1556 == nil { ifn_1557 = lang.IFn_Cast(root_1555) } else { ifn_1557 = nil }; var arg_1558 any = Lit_29; var arg_1559 any; var root_1560 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1561 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1560, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1562 lang.IFn; if linked_1561 == nil { ifn_1562 = lang.IFn_Cast(root_1560) } else { ifn_1562 = nil }; var arg_1563 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var arg_1564 any = A_arbace_go_check_types_A_const_191.Invoke_O__O(i__2); if linked_1561 == nil { arg_1559 = ifn_1562.Invoke_O_O__O(arg_1563, arg_1564) } else { arg_1559 = linked_1561.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1560, arg_1563, arg_1564) }; if linked_1556 == nil { tmp4 = ifn_1557.Invoke_O_O__O(arg_1558, arg_1559) } else { tmp4 = linked_1556.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1555, arg_1558, arg_1559) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, base__3, nil, tmp4, nil)).Ref() } else {
//line :544:1
			return base__3 } }



func A_arbace_go_check_types_type_str_A_New() *A_arbace_go_check_types_type_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_A{}; t.Ctor(); return t }
//line :548:1
func (t *A_arbace_go_check_types_type_str_A) Ctor() {}
//line :548:1
func (t *A_arbace_go_check_types_type_str_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_1565 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1565, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_1567 lang.IFn
	if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any = t__0; if linked_1566 == nil { tmp1 = ifn_1567.Invoke_O__O(arg_1568) } else { tmp1 = linked_1566.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_1565, arg_1568) }
//line :551:1
	if jrt.J2g_Truth(tmp1) { var or__1927000174__auto____2 any = lang.RT_Get_O_O__O_NoInit(A_arbace_go_check_types_A_const_192.GetRawRoot__O(), t__0)
		if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var G__219000236__3_ any; var root_1569 any = A_arbace_go_check_types_A_const_60.GetRawRoot__O(); var linked_1570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1569, A_arbace_go_check_types_kw_alias_info_A_fn_class); var ifn_1571 lang.IFn; if linked_1570 == nil { ifn_1571 = lang.IFn_Cast(root_1569) } else { ifn_1571 = nil }; var arg_1572 any = t__0; if linked_1570 == nil { G__219000236__3_ = ifn_1571.Invoke_O__O(arg_1572) } else { G__219000236__3_ = linked_1570.(*A_arbace_go_check_types_kw_alias_info_A).Invoke_O_O__O(root_1569, arg_1572) }; if lang.Util_Identical_O_O__Z_NoInit(G__219000236__3_, nil) { or__1927000174__auto____3 = nil } else { or__1927000174__auto____3 = A_arbace_go_check_types_A_const_12.Invoke_O__O(G__219000236__3_) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_1573 any = A_arbace_go_check_types_A_const_193.GetRawRoot__O(); var linked_1574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1573, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1575 lang.IFn; if linked_1574 == nil { ifn_1575 = lang.IFn_Cast(root_1573) } else { ifn_1575 = nil }; var arg_1576 any = t__0; if linked_1574 == nil { return ifn_1575.Invoke_O__O(arg_1576) } else { return linked_1574.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1573, arg_1576) } } } } else {
//line :551:1
			var tmp2 any; var root_1577 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1579 lang.IFn

			if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = t__0; if linked_1578 == nil { tmp2 = ifn_1579.Invoke_O__O(arg_1580) } else { tmp2 = linked_1578.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1577, arg_1580) }
//line :551:1
			if jrt.J2g_Truth(tmp2) {

				var root_1581 any = A_arbace_go_check_types_A_const_194.GetRawRoot__O(); var linked_1582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1581, A_arbace_go_check_types_named_str_A_fn_class); var ifn_1583 lang.IFn; if linked_1582 == nil { ifn_1583 = lang.IFn_Cast(root_1581) } else { ifn_1583 = nil }; var arg_1584 any = t__0; if linked_1582 == nil { return ifn_1583.Invoke_O__O(arg_1584) } else { return linked_1582.(*A_arbace_go_check_types_named_str_A).Invoke_O_O__O(root_1581, arg_1584) } } else {
//line :551:1
					var tmp3 any; var root_1585 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1585, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_1587 lang.IFn


					if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var arg_1588 any = t__0; if linked_1586 == nil { tmp3 = ifn_1587.Invoke_O__O(arg_1588) } else { tmp3 = linked_1586.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_1585, arg_1588) }
//line :551:1
					if jrt.J2g_Truth(tmp3) {


						var tmp4 *lang.Keyword = A_arbace_go_check_types_A_const_12; var tmp5 any; var root_1589 any = A_arbace_go_check_types_A_const_97.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1589, A_arbace_go_check_types_info_A_fn_class); var ifn_1591 lang.IFn; if linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any = t__0; if linked_1590 == nil { tmp5 = ifn_1591.Invoke_O__O(arg_1592) } else { tmp5 = linked_1590.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1589, arg_1592) }; return tmp4.Invoke_O__O(tmp5) } else {
//line :551:1
							if A_arbace_go_check_types_A_const_88 != nil { var G__219000237__2_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))




								switch lang.Util_Hash_O__I_NoInit(G__219000237__2_) >> 5 & 31 { case 0: if any(G__219000237__2_) == any(A_arbace_go_check_types_A_const_62) {





















									var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_31, nil, Lit_32); var tmp7 any; var root_1594 any = A_arbace_go_check_types_A_const_183.GetRawRoot__O(); var linked_1595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1594, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1596 lang.IFn; if linked_1595 == nil { ifn_1596 = lang.IFn_Cast(root_1594) } else { ifn_1596 = nil }; var arg_1597 any = Lit_33; var arg_1598 any; var root_1599 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1599, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1601 lang.IFn; if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var arg_1603 any; var root_1604 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1606 lang.IFn; if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = t__0; if linked_1605 == nil { arg_1603 = ifn_1606.Invoke_O__O(arg_1607) } else { arg_1603 = linked_1605.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1604, arg_1607) }; if linked_1600 == nil { arg_1598 = ifn_1601.Invoke_O_O__O(arg_1602, arg_1603) } else { arg_1598 = linked_1600.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1599, arg_1602, arg_1603) }; if linked_1595 == nil { tmp7 = ifn_1596.Invoke_O_O__O(arg_1597, arg_1598) } else { tmp7 = linked_1595.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1594, arg_1597, arg_1598) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil)).Ref() }
//line :556:1
								case 1: if any(G__219000237__2_) == any(A_arbace_go_check_types_A_const_67) { var ms__3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var ts__4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var tmp8 any; var and__1927000168__auto____5 any; var root_1608 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1610 lang.IFn












									if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = ms__3; if linked_1609 == nil { and__1927000168__auto____5 = ifn_1610.Invoke_O__O(arg_1611) } else { and__1927000168__auto____5 = linked_1609.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1608, arg_1611) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(ts__4, nil)).Ref() } else { tmp8 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp8) { return Lit_62 } else {

										var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_64); var tmp10 any; var root_1612 any = A_arbace_go_check_types_A_const_183.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1612, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1614 lang.IFn
										if linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any = Lit_65; var arg_1616 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_146.GetRawRoot__O()); var tmp12 any; if jrt.J2g_Truth(A_arbace_go_check_types_A_const_128.Invoke_O__O(ts__4)) { tmp12 = A_arbace_go_check_types_A_const_195 } else { tmp12 = nil }; var tmp13 any = tmp12; var tmp14 any; var iter__1927001039__auto____8 any; var tmp15 any = A_arbace_go_check_types_type_str_iter__219000238__219000242_A_New(); var tmp16 *jrt.Class; var fncls__1689 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000238__219000242_A_fn_class
										if fncls__1689 == nil { var fncls__1689d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_go_check_types_type_str_iter__219000238__219000242_A_fn_class = fncls__1689d; tmp16 = fncls__1689d } else { tmp16 = fncls__1689 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); tmp14 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(ms__3)
//line :572:1
										var tmp17 any = tmp14; var tmp18 lang.IPersistentVector; var tmp19 any; var and__1927000168__auto____8 any; var root_1690 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_1691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1690, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1692 lang.IFn

										if linked_1691 == nil { ifn_1692 = lang.IFn_Cast(root_1690) } else { ifn_1692 = nil }; var arg_1693 any = ts__4; if linked_1691 == nil { and__1927000168__auto____8 = ifn_1692.Invoke_O__O(arg_1693) } else { and__1927000168__auto____8 = linked_1691.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1690, arg_1693) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1694 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_1695 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1694, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1696 lang.IFn; if linked_1695 == nil { ifn_1696 = lang.IFn_Cast(root_1694) } else { ifn_1696 = nil }; var arg_1697 any = A_arbace_go_check_types_A_const_126; var arg_1698 any = A_arbace_go_check_types_A_const_127.Invoke_O__O(ts__4); if linked_1695 == nil { tmp19 = ifn_1696.Invoke_O_O__O(arg_1697, arg_1698) } else { tmp19 = linked_1695.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1694, arg_1697, arg_1698) } } else { tmp19 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp19) { var tmp20 any; var root_1699 any = A_arbace_go_check_types_A_const_197.GetRawRoot__O(); var linked_1700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1699, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_1701 lang.IFn
											if linked_1700 == nil { ifn_1701 = lang.IFn_Cast(root_1699) } else { ifn_1701 = nil }; var arg_1702 any = A_arbace_go_check_types_A_const_127.Invoke_O__O(ts__4); if linked_1700 == nil { tmp20 = ifn_1701.Invoke_O__O(arg_1702) } else { tmp20 = linked_1700.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_1699, arg_1702) }
//line :574:1
											tmp18 = lang.Tuple_Create_O__IPersistentVector(tmp20) } else { tmp18 = nil }
//line :572:1
										arg_1616 = tmp11.Invoke_O_O_O__O(tmp13, tmp17, tmp18); if linked_1613 == nil { tmp10 = ifn_1614.Invoke_O_O__O(arg_1615, arg_1616) } else { tmp10 = linked_1613.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1612, arg_1615, arg_1616) }
//line :571:1
										return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, nil)).Ref() } }
//line :556:1
								case 3: if any(G__219000237__2_) == any(A_arbace_go_check_types_A_const_71) {
									var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_67, nil); var tmp22 any; var root_1703 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1705 lang.IFn; if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1704 == nil { tmp22 = ifn_1705.Invoke_O__O(arg_1706) } else { tmp22 = linked_1704.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1703, arg_1706) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp22)).Ref() }
//line :556:1
								case 4: if any(G__219000237__2_) == any(A_arbace_go_check_types_A_const_72) {


									var tmp23 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_27, nil, Lit_28, nil); var tmp24 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp25 any; var root_1707 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1707, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1709 lang.IFn; if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var arg_1710 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_1708 == nil { tmp25 = ifn_1709.Invoke_O__O(arg_1710) } else { tmp25 = linked_1708.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1707, arg_1710) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp23, jrt.RefArrayOf(jrt.Object_class, nil, tmp24, nil, tmp25)).Ref() }
//line :556:1
								case 8: if any(G__219000237__2_) == any(A_arbace_go_check_types_A_const_74) {



									var tmp26 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil, Lit_28, nil); var tmp27 any; var root_1715 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1715, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1717 lang.IFn; if linked_1716 == nil { ifn_1717 = lang.IFn_Cast(root_1715) } else { ifn_1717 = nil }; var arg_1718 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1716 == nil { tmp27 = ifn_1717.Invoke_O__O(arg_1718) } else { tmp27 = linked_1716.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1715, arg_1718) }; var tmp28 any = tmp27; var tmp29 any; var root_1719 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1719, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1721 lang.IFn; if linked_1720 == nil { ifn_1721 = lang.IFn_Cast(root_1719) } else { ifn_1721 = nil }; var arg_1722 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_1720 == nil { tmp29 = ifn_1721.Invoke_O__O(arg_1722) } else { tmp29 = linked_1720.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1719, arg_1722) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp26, jrt.RefArrayOf(jrt.Object_class, nil, tmp28, nil, tmp29)).Ref() }
//line :556:1
								case 14: if any(G__219000237__2_) == any(A_arbace_go_check_types_A_const_75) {

									var tmp30 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_69, nil); var tmp31 any; var root_1723 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1723, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1725 lang.IFn; if linked_1724 == nil { ifn_1725 = lang.IFn_Cast(root_1723) } else { ifn_1725 = nil }; var arg_1726 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1724 == nil { tmp31 = ifn_1725.Invoke_O__O(arg_1726) } else { tmp31 = linked_1724.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1723, arg_1726) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp30, jrt.RefArrayOf(jrt.Object_class, nil, tmp31)).Ref() }
//line :556:1
								case 16: if any(G__219000237__2_) == any(A_arbace_go_check_types_A_const_76) { var e__3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var es__4 any; var root_1727 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1727, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1729 lang.IFn





									if linked_1728 == nil { ifn_1729 = lang.IFn_Cast(root_1727) } else { ifn_1729 = nil }; var arg_1730 any = e__3; if linked_1728 == nil { es__4 = ifn_1729.Invoke_O__O(arg_1730) } else { es__4 = linked_1728.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1727, arg_1730) }
//line :556:1
									var es__5 any; var tmp32 any; var tmp33 any = A_arbace_go_check_types_A_const_177; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp33, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)))






									if and__1927000168__auto____5_2 { var and__1927000168__auto____6 any; var root_1731 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_1732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1731, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1733 lang.IFn; if linked_1732 == nil { ifn_1733 = lang.IFn_Cast(root_1731) } else { ifn_1733 = nil }; var arg_1734 any = e__3; if linked_1732 == nil { and__1927000168__auto____6 = ifn_1733.Invoke_O__O(arg_1734) } else { and__1927000168__auto____6 = linked_1732.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1731, arg_1734) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp34 any = A_arbace_go_check_types_A_const_76; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp34, lang.RT_Nth_O_I__O_NoInit(e__3, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____7 { var tmp35 any = A_arbace_go_check_types_A_const_198; tmp32 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp35, lang.RT_Nth_O_I__O_NoInit(e__3, lang.RT_IntCast_J__I_NoInit(1)))).Ref() } else { tmp32 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp32 = and__1927000168__auto____6 } } else { tmp32 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref() }; if jrt.J2g_Truth(tmp32) {
										es__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil, Lit_32), jrt.RefArrayOf(jrt.Object_class, nil, es__4, nil)).Ref() } else {
//line :563:1
											es__5 = es__4 }
//line :556:1
									var G__219000248__6_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1))








									switch lang.Util_Hash_O__I_NoInit(G__219000248__6_) >> 7 & 3 { case 0: if any(G__219000248__6_) == any(A_arbace_go_check_types_A_const_198) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_70, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; case 2: if any(G__219000248__6_) == any(A_arbace_go_check_types_A_const_177) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_71, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; case 3: if any(G__219000248__6_) == any(A_arbace_go_check_types_A_const_199) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_73, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__219000248__6_))))) }
//line :556:1
								case 27: if any(G__219000237__2_) == any(A_arbace_go_check_types_A_const_78) {









									var tmp36 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_74, nil); var tmp37 any; var root_1736 any = A_arbace_go_check_types_A_const_196.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1736, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1738 lang.IFn; if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var arg_1739 any = t__0; if linked_1737 == nil { tmp37 = ifn_1738.Invoke_O__O(arg_1739) } else { tmp37 = linked_1737.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1736, arg_1739) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp36, jrt.RefArrayOf(jrt.Object_class, nil, tmp37)).Ref() }
//line :556:1
								case 28: if any(G__219000237__2_) == any(A_arbace_go_check_types_A_const_137) {




















									var root_1740 any = A_arbace_go_check_types_A_const_197.GetRawRoot__O(); var linked_1741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1740, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_1742 lang.IFn; if linked_1741 == nil { ifn_1742 = lang.IFn_Cast(root_1740) } else { ifn_1742 = nil }; var arg_1743 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1741 == nil { return ifn_1742.Invoke_O__O(arg_1743) } else { return linked_1741.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_1740, arg_1743) } }
//line :556:1
								case 31: if any(G__219000237__2_) == any(A_arbace_go_check_types_A_const_82) {










									var tmp38 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_75, nil, Lit_64); var tmp39 any; var root_1744 any = A_arbace_go_check_types_A_const_183.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = Lit_65; var arg_1748 any; var root_1749 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1749, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1751 lang.IFn; if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any = A_arbace_go_check_types_A_const_200.GetRawRoot__O(); var arg_1753 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1750 == nil { arg_1748 = ifn_1751.Invoke_O_O__O(arg_1752, arg_1753) } else { arg_1748 = linked_1750.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1749, arg_1752, arg_1753) }; if linked_1745 == nil { tmp39 = ifn_1746.Invoke_O_O__O(arg_1747, arg_1748) } else { tmp39 = linked_1745.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1744, arg_1747, arg_1748) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp38, jrt.RefArrayOf(jrt.Object_class, nil, tmp39, nil)).Ref() }
//line :556:1
								default:
								}





















								return lang.IFn_Cast(A_arbace_go_check_types_A_const_180.GetRawRoot__O()).Invoke_O__O(t__0) } else {
//line :551:1
									return nil
								}
						}
				}
		}
}
















func A_arbace_go_check_types_type_str_iter__219000238__219000242_A_New() *A_arbace_go_check_types_type_str_iter__219000238__219000242_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000238__219000242_A{}; t.Ctor(); return t }
//line :573:1
func (t *A_arbace_go_check_types_type_str_iter__219000238__219000242_A) Ctor() {}
//line :573:1
func (t *A_arbace_go_check_types_type_str_iter__219000238__219000242_A) Invoke_O_O__O(self, s__219000239__1 any) any { var tmp1 any = A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_A_New_O_O(self, s__219000239__1); var tmp2 *jrt.Class; var fncls__1688 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_A_fn_class; if fncls__1688 == nil { var fncls__1688d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_A_fn_class = fncls__1688d; tmp2 = fncls__1688d } else { tmp2 = fncls__1688 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :573:1
func A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_A{}; t.Ctor_O_O(p0, p1); return t }
//line :573:1
func (t *A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_A) Ctor_O_O(c__iter__219000238, c__s__219000239 any) { t.F_iter__219000238 = c__iter__219000238; t.F_s__219000239 = c__s__219000239 }
//line :573:1
func (t *A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_A) Invoke_O__O(self any) any { { var s__219000239__1 any; var t_ any = t.F_s__219000239; t.F_s__219000239 = nil; s__219000239__1 = t_; for { var temp__1927000414__auto____2 any; var root_1623 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_1624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1623, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1625 lang.IFn; if linked_1624 == nil { ifn_1625 = lang.IFn_Cast(root_1623) } else { ifn_1625 = nil }; var arg_1626 any = s__219000239__1; if linked_1624 == nil { temp__1927000414__auto____2 = ifn_1625.Invoke_O__O(arg_1626) } else { temp__1927000414__auto____2 = linked_1624.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1623, arg_1626) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000239__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1627 any = A_arbace_go_check_types_A_const_148.GetRawRoot__O(); var linked_1628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1627, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1629 lang.IFn; if linked_1628 == nil { ifn_1629 = lang.IFn_Cast(root_1627) } else { ifn_1629 = nil }; var arg_1630 any = s__219000239__3; if linked_1628 == nil { tmp1 = ifn_1629.Invoke_O__O(arg_1630) } else { tmp1 = linked_1628.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1627, arg_1630) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1631 any = A_arbace_go_check_types_A_const_149.GetRawRoot__O(); var linked_1632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1631, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1633 lang.IFn; if linked_1632 == nil { ifn_1633 = lang.IFn_Cast(root_1631) } else { ifn_1633 = nil }; var arg_1634 any = s__219000239__3; if linked_1632 == nil { c__1927001037__auto____4 = ifn_1633.Invoke_O__O(arg_1634) } else { c__1927001037__auto____4 = linked_1632.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1631, arg_1634) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000241__6 any; var root_1635 any = A_arbace_go_check_types_A_const_150.GetRawRoot__O(); var linked_1636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1635, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1637 lang.IFn; if linked_1636 == nil { ifn_1637 = lang.IFn_Cast(root_1635) } else { ifn_1637 = nil }; var arg_1638 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1636 == nil { b__219000241__6 = ifn_1637.Invoke_O__O(arg_1638) } else { b__219000241__6 = linked_1636.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1635, arg_1638) }; var tmp2 any = A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_fn__219000244_A_New_O_I_O(b__219000241__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1648 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_fn__219000244_A_fn_class; if fncls__1648 == nil { var fncls__1648d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_fn__219000244_A_fn_class = fncls__1648d; tmp3 = fncls__1648d } else { tmp3 = fncls__1648 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1649 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1649, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1651 lang.IFn; if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any; var root_1654 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1654, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1656 lang.IFn; if linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any = b__219000241__6; if linked_1655 == nil { arg_1652 = ifn_1656.Invoke_O__O(arg_1657) } else { arg_1652 = linked_1655.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1654, arg_1657) }; var arg_1653 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000238); var tmp5 any; var root_1658 any = A_arbace_go_check_types_A_const_155.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1660 lang.IFn; if linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any = s__219000239__3; if linked_1659 == nil { tmp5 = ifn_1660.Invoke_O__O(arg_1661) } else { tmp5 = linked_1659.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1658, arg_1661) }; arg_1653 = tmp4.Invoke_O__O(tmp5); if linked_1650 == nil { return ifn_1651.Invoke_O_O__O(arg_1652, arg_1653) } else { return linked_1650.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1649, arg_1652, arg_1653) } } else { var root_1662 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1662, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1664 lang.IFn; if linked_1663 == nil { ifn_1664 = lang.IFn_Cast(root_1662) } else { ifn_1664 = nil }; var arg_1665 any; var root_1667 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1667, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1669 lang.IFn; if linked_1668 == nil { ifn_1669 = lang.IFn_Cast(root_1667) } else { ifn_1669 = nil }; var arg_1670 any = b__219000241__6; if linked_1668 == nil { arg_1665 = ifn_1669.Invoke_O__O(arg_1670) } else { arg_1665 = linked_1668.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1667, arg_1670) }; var arg_1666 any; if linked_1663 == nil { return ifn_1664.Invoke_O_O__O(arg_1665, arg_1666) } else { return linked_1663.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1662, arg_1665, arg_1666) } } } else { var m__4 any; var root_1671 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1671, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any = s__219000239__3; if linked_1672 == nil { m__4 = ifn_1673.Invoke_O__O(arg_1674) } else { m__4 = linked_1672.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1671, arg_1674) }; var root_1675 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); var linked_1676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1675, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1677 lang.IFn; if linked_1676 == nil { ifn_1677 = lang.IFn_Cast(root_1675) } else { ifn_1677 = nil }; var arg_1678 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__4); var tmp8 any; var root_1680 any = A_arbace_go_check_types_A_const_196.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = A_arbace_go_check_types_A_const_70.Invoke_O__O(m__4); if linked_1681 == nil { tmp8 = ifn_1682.Invoke_O__O(arg_1683) } else { tmp8 = linked_1681.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1680, arg_1683) }; arg_1678 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8)).Ref(); var arg_1679 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__219000238); var tmp10 any; var root_1684 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1686 lang.IFn; if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = s__219000239__3; if linked_1685 == nil { tmp10 = ifn_1686.Invoke_O__O(arg_1687) } else { tmp10 = linked_1685.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1684, arg_1687) }; arg_1679 = tmp9.Invoke_O__O(tmp10); if linked_1676 == nil { return ifn_1677.Invoke_O_O__O(arg_1678, arg_1679) } else { return linked_1676.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1675, arg_1678, arg_1679) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :573:1
func A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_fn__219000244_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_fn__219000244_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_fn__219000244_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :573:1
func (t *A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_fn__219000244_A) Ctor_O_I_O(c__b__219000241 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000241 = c__b__219000241; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :573:1
func (t *A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_fn__219000244_A) Invoke_O__O(self any) any { { var i__219000240__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000240__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000240__1)); var root_1639 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_1640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1639, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1641 lang.IFn; if linked_1640 == nil { ifn_1641 = lang.IFn_Cast(root_1639) } else { ifn_1641 = nil }; var arg_1642 any = t.F_b__219000241; var arg_1643 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__2); var tmp4 any; var root_1644 any = A_arbace_go_check_types_A_const_196.GetRawRoot__O(); var linked_1645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1644, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1646 lang.IFn; if linked_1645 == nil { ifn_1646 = lang.IFn_Cast(root_1644) } else { ifn_1646 = nil }; var arg_1647 any = A_arbace_go_check_types_A_const_70.Invoke_O__O(m__2); if linked_1645 == nil { tmp4 = ifn_1646.Invoke_O__O(arg_1647) } else { tmp4 = linked_1645.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1644, arg_1647) }; arg_1643 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref(); if linked_1640 == nil { ifn_1641.Invoke_O_O__O(arg_1642, arg_1643) } else { linked_1640.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1639, arg_1642, arg_1643) }; i__219000240__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000240__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }














func A_arbace_go_check_types_align_up_A_New() *A_arbace_go_check_types_align_up_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_align_up_A{}; t.Ctor(); return t }
//line :588:1
func (t *A_arbace_go_check_types_align_up_A) Ctor() {}
//line :588:1
func (t *A_arbace_go_check_types_align_up_A) InvokePrim_O_J_J__J(self any, x__0, a__1 int64) int64 {


	return lang.Numbers_AndNot_J_J__J_NoInit(lang.Numbers_Unchecked_add_J_J__J_NoInit(x__0, lang.Numbers_Dec_J__J_NoInit(a__1)), lang.Numbers_Dec_J__J_NoInit(a__1)) }
//line :588:1
func (t *A_arbace_go_check_types_align_up_A) Invoke_O_O_O__O(self, p_x__0, p_a__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_J__J(self, lang.RT_LongCast_O__J_NoInit(p_x__0), lang.RT_LongCast_O__J_NoInit(p_a__1))).Ref() }




func A_arbace_go_check_types_sync_atomic_align64_QMARK__A_New() *A_arbace_go_check_types_sync_atomic_align64_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sync_atomic_align64_QMARK__A{}; t.Ctor(); return t }
//line :593:1
func (t *A_arbace_go_check_types_sync_atomic_align64_QMARK__A) Ctor() {}
//line :593:1
func (t *A_arbace_go_check_types_sync_atomic_align64_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_1754 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1756 lang.IFn; if



	linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = t__0; if linked_1755 == nil { and__1927000168__auto____2 = ifn_1756.Invoke_O__O(arg_1757) } else { and__1927000168__auto____2 = linked_1755.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1754, arg_1757) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var i__3 any; var root_1758 any = A_arbace_go_check_types_A_const_97.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, A_arbace_go_check_types_info_A_fn_class); var ifn_1760 lang.IFn
		if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = t__0; if linked_1759 == nil { i__3 = ifn_1760.Invoke_O__O(arg_1761) } else { i__3 = linked_1759.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1758, arg_1761) }
//line :597:1
		var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_45, A_arbace_go_check_types_A_const_12.Invoke_O__O(i__3))

		if and__1927000168__auto____4 {
			var root_1762 any = A_arbace_go_check_types_A_const_100.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1764 lang.IFn; if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var arg_1765 any = A_arbace_go_check_types_A_const_201; var arg_1766 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(i__3); if linked_1763 == nil { return ifn_1764.Invoke_O_O__O(arg_1765, arg_1766) } else { return linked_1763.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1762, arg_1765, arg_1766) } } else {
//line :599:1
				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else {
//line :597:1
					return and__1927000168__auto____2 } }




func A_arbace_go_check_types_alignof_A_New() *A_arbace_go_check_types_alignof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alignof_A{}; t.Ctor(); return t }
//line :602:1
func (t *A_arbace_go_check_types_alignof_A) Ctor() {}
//line :602:1
func (t *A_arbace_go_check_types_alignof_A) InvokePrim_O_O__J(self, t__0 any) int64 { var tmp1 any; var u__2 any; var root_1767 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_1768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1767, A_arbace_go_check_types_under_A_fn_class); var ifn_1769 lang.IFn; if
											linked_1768 == nil { ifn_1769 = lang.IFn_Cast(root_1767) } else { ifn_1769 = nil }; var arg_1770 any = t__0; if linked_1768 == nil { u__2 = ifn_1769.Invoke_O__O(arg_1770) } else { u__2 = linked_1768.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1767, arg_1770) }; var tmp2 any; var and__1927000168__auto____3 any; var root_1771 any =
											A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_1772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1771, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1773 lang.IFn; if
											linked_1772 == nil { ifn_1773 = lang.IFn_Cast(root_1771) } else { ifn_1773 = nil }; var arg_1774 any = u__2; if linked_1772 == nil { and__1927000168__auto____3 = ifn_1773.Invoke_O__O(arg_1774) } else { and__1927000168__auto____3 = linked_1772.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1771, arg_1774) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_go_check_types_A_const_72; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp2 = and__1927000168__auto____3 }; if /*line :604:1*/ jrt.J2g_Truth(tmp2) {
												var root_1775 any = A_arbace_go_check_types_A_const_202.GetRawRoot__O(); var linked_1776 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1775, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1777 lang.IFn; if linked_1776 == nil { ifn_1777 = lang.IFn_Cast(root_1775) } else { ifn_1777 = nil }; var arg_1778 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)); if linked_1776 == nil { tmp1 = ifn_1777.Invoke_O__O(arg_1778) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_1776.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1775, arg_1778)).Ref() } } else {
//line :604:1
			var tmp4 any; var and__1927000168__auto____3_2 any; var root_1779 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1779, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1781 lang.IFn

			if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any = u__2; if linked_1780 == nil { and__1927000168__auto____3_2 = ifn_1781.Invoke_O__O(arg_1782) } else { and__1927000168__auto____3_2 = linked_1780.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1779, arg_1782) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) { var tmp5 any = A_arbace_go_check_types_A_const_82; tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp5, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp4 = and__1927000168__auto____3_2 }
//line :604:1
			if jrt.J2g_Truth(tmp4) {


				var tmp6 any; var and__1927000168__auto____3_3 any; var root_1783 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1784 == nil { and__1927000168__auto____3_3 = ifn_1785.Invoke_O__O(arg_1786) } else { and__1927000168__auto____3_3 = linked_1784.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1783, arg_1786) }; if jrt.J2g_Truth(and__1927000168__auto____3_3) { var root_1787 any = A_arbace_go_check_types_A_const_203.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class); var ifn_1789 lang.IFn; if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = t__0; if linked_1788 == nil { tmp6 = ifn_1789.Invoke_O__O(arg_1790) } else { tmp6 = linked_1788.(*A_arbace_go_check_types_sync_atomic_align64_QMARK__A).Invoke_O_O__O(root_1787, arg_1790) } } else { tmp6 = and__1927000168__auto____3_3 }; if jrt.J2g_Truth(tmp6) { tmp1 = A_arbace_go_check_types_A_const_24 } else {

					var root_1791 any = A_arbace_go_check_types_A_const_204.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1793 lang.IFn; if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any; var tmp7 any = A_arbace_go_check_types_alignof_fn__219000252_A_New(); var tmp8 *jrt.Class; var fncls__1801 *jrt.Class = A_arbace_go_check_types_alignof_fn__219000252_A_fn_class; if fncls__1801 == nil { var fncls__1801d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_go_check_types_alignof_fn__219000252_A_fn_class = fncls__1801d; tmp8 = fncls__1801d } else { tmp8 = fncls__1801 }; arg_1794 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_1795 any = A_arbace_go_check_types_A_const_15; var arg_1796 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1792 == nil { tmp1 = ifn_1793.Invoke_O_O_O__O(arg_1794, arg_1795, arg_1796) } else { tmp1 = linked_1792.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1791, arg_1794, arg_1795, arg_1796) } } } else {
//line :604:1
						var tmp9 any; var and__1927000168__auto____3_4 any; var root_1802 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_1803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1802, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1804 lang.IFn





						if linked_1803 == nil { ifn_1804 = lang.IFn_Cast(root_1802) } else { ifn_1804 = nil }; var arg_1805 any = u__2; if linked_1803 == nil { and__1927000168__auto____3_4 = ifn_1804.Invoke_O__O(arg_1805) } else { and__1927000168__auto____3_4 = linked_1803.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1802, arg_1805) }; if jrt.J2g_Truth(and__1927000168__auto____3_4) { var root_1806 any = A_arbace_go_check_types_A_const_100.GetRawRoot__O(); var linked_1807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1806, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1808 lang.IFn; if linked_1807 == nil { ifn_1808 = lang.IFn_Cast(root_1806) } else { ifn_1808 = nil }; var arg_1809 any = A_arbace_go_check_types_A_const_205; var arg_1810 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)); if linked_1807 == nil { tmp9 = ifn_1808.Invoke_O_O__O(arg_1809, arg_1810) } else { tmp9 = linked_1807.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1806, arg_1809, arg_1810) } } else { tmp9 = and__1927000168__auto____3_4 }
//line :604:1
						if jrt.J2g_Truth(tmp9) { tmp1 = A_arbace_go_check_types_A_const_206.GetRawRoot__O() } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_40, u__2) { tmp1 = A_arbace_go_check_types_A_const_206.GetRawRoot__O() } else { if A_arbace_go_check_types_A_const_88 != nil { var a__3 any; var root_1811 any = A_arbace_go_check_types_A_const_207.GetRawRoot__O(); var linked_1812 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1811, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1813 lang.IFn








							if linked_1812 == nil { ifn_1813 = lang.IFn_Cast(root_1811) } else { ifn_1813 = nil }; var arg_1814 any = t__0; if linked_1812 == nil { a__3 = ifn_1813.Invoke_O__O(arg_1814) } else { a__3 = jrt.Long_ValueOf_J__Long_NoInit(linked_1812.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1811, arg_1814)).Ref() }
//line :604:1
							var a__4 any; var tmp10 bool
							var na_1815 any = a__3
							var na_1816 int64 = 1







							if jrt.Long_InstanceOf(na_1815) { var n0_1817 int64 = jrt.NN(jrt.Long_Cast(na_1815)).LongValue__J(); var n1_1818 int64 = na_1816; tmp10 = n0_1817 < n1_1818 } else { tmp10 = lang.Numbers_Lt_O_J__Z_NoInit(na_1815, na_1816) }; if tmp10 { a__4 = A_arbace_go_check_types_A_const_15 } else { a__4 = a__3 }
//line :604:1
							var a__5 any; var tmp11 any; var root_1820 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_1821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1820, A_arbace_go_check_types_complex_type_QMARK__A_fn_class); var ifn_1822 lang.IFn










							if linked_1821 == nil { ifn_1822 = lang.IFn_Cast(root_1820) } else { ifn_1822 = nil }; var arg_1823 any = t__0; if linked_1821 == nil { tmp11 = ifn_1822.Invoke_O__O(arg_1823) } else { tmp11 = linked_1821.(*A_arbace_go_check_types_complex_type_QMARK__A).Invoke_O_O__O(root_1820, arg_1823) }; if jrt.J2g_Truth(tmp11) { var na_1824 any = a__4; var na_1825 int64 = 2; if jrt.Long_InstanceOf(na_1824) { var n0_1826 int64 = jrt.NN(jrt.Long_Cast(na_1824)).LongValue__J(); var n1_1827 int64 = na_1825; if n1_1827 == 0 { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1824, na_1825) } else { a__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_1826 / n1_1827).Ref() } } else { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1824, na_1825) } } else { a__5 = a__4 }
							tmp1 = lang.Numbers_Min_O_O__O_NoInit(a__5, A_arbace_go_check_types_A_const_208.GetRawRoot__O()) } else {
//line :604:1
								tmp1 = nil } } } } }; return /*line :602:1*/ jrt.Number_Cast(tmp1).LongValue__J() }
//line :602:1
func (t *A_arbace_go_check_types_alignof_A) Invoke_O_O__O(self, t__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, t__0)).Ref() }






func A_arbace_go_check_types_alignof_fn__219000252_A_New() *A_arbace_go_check_types_alignof_fn__219000252_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alignof_fn__219000252_A{}; t.Ctor(); return t }
//line :609:1
func (t *A_arbace_go_check_types_alignof_fn__219000252_A) Ctor() {}
//line :609:1
func (t *A_arbace_go_check_types_alignof_fn__219000252_A) Invoke_O_O_O__O(self, m__1, f__2 any) any { var tmp1 int64; var root_1797 any = A_arbace_go_check_types_A_const_202.GetRawRoot__O(); var linked_1798 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1797, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1799 lang.IFn; if linked_1798 == nil { ifn_1799 = lang.IFn_Cast(root_1797) } else { ifn_1799 = nil }; var arg_1800 any = A_arbace_go_check_types_A_const_70.Invoke_O__O(f__2); if linked_1798 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_1799.Invoke_O__O(arg_1800)) } else { tmp1 = linked_1798.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1797, arg_1800) }; return lang.Numbers_Max_O_J__O_NoInit(m__1, tmp1) }








func A_arbace_go_check_types_offsetsof_A_New() *A_arbace_go_check_types_offsetsof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_offsetsof_A{}; t.Ctor(); return t }
//line :618:1
func (t *A_arbace_go_check_types_offsetsof_A) Ctor() {}
//line :618:1
func (t *A_arbace_go_check_types_offsetsof_A) Invoke_O_O__O(self, fields__0 any) any { { var fs__2 any = fields__0; var offs__3 any = lang.RT_Box_J__Number_NoInit(0); var acc__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




	var tmp1 any; var root_1829 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1829, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1831 lang.IFn; if linked_1830 == nil { ifn_1831 = lang.IFn_Cast(root_1829) } else { ifn_1831 = nil }; var arg_1832 any = fs__2; if linked_1830 == nil { tmp1 = ifn_1831.Invoke_O__O(arg_1832) } else { tmp1 = linked_1830.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1829, arg_1832) }; if jrt.J2g_Truth(tmp1) { return acc__4 } else { var f__5 any; var root_1833 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1835 lang.IFn

		if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any = fs__2; if linked_1834 == nil { f__5 = ifn_1835.Invoke_O__O(arg_1836) } else { f__5 = linked_1834.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1833, arg_1836) }
		var tmp2 bool; var na_1837 any = offs__3; if jrt.Long_InstanceOf(na_1837) { var n0_1838 int64 = jrt.NN(jrt.Long_Cast(na_1837)).LongValue__J(); tmp2 = n0_1838 < 0 } else { if jrt.Double_InstanceOf(na_1837) { var n0_1838_2 float64 = jrt.NN(jrt.Double_Cast(na_1837)).DoubleValue__D(); tmp2 = n0_1838_2 < 0.0 } else { tmp2 = lang.Numbers_IsNeg_O__Z_NoInit(na_1837) } }; if tmp2 {
			var tmp3 any; var root_1852 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = fs__2; if linked_1853 == nil { tmp3 = ifn_1854.Invoke_O__O(arg_1855) } else { tmp3 = linked_1853.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1852, arg_1855) }; var tmp4 any = tmp3; var tmp5 any; var root_1856 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1856, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1858 lang.IFn; if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any = acc__4; var arg_1860 any = A_arbace_go_check_types_A_const_210; if linked_1857 == nil { tmp5 = ifn_1858.Invoke_O_O__O(arg_1859, arg_1860) } else { tmp5 = linked_1857.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1856, arg_1859, arg_1860) }; fs__2, offs__3, acc__4 = tmp4, offs__3, tmp5; continue L1 } else {
//line :626:1
				var o__6 any; var root_1839 any = A_arbace_go_check_types_A_const_209.GetRawRoot__O(); var linked_1840 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1839, A_arbace_go_check_types_align_up_A_fn_class); var ifn_1841 lang.IFn

				if linked_1840 == nil { ifn_1841 = lang.IFn_Cast(root_1839) } else { ifn_1841 = nil }; var arg_1842 any = offs__3; var arg_1843 any; var root_1844 any = A_arbace_go_check_types_A_const_202.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1844, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1846 lang.IFn; if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any = A_arbace_go_check_types_A_const_70.Invoke_O__O(f__5); if linked_1845 == nil { arg_1843 = ifn_1846.Invoke_O__O(arg_1847) } else { arg_1843 = jrt.Long_ValueOf_J__Long_NoInit(linked_1845.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1844, arg_1847)).Ref() }; if linked_1840 == nil { o__6 = ifn_1841.Invoke_O_O__O(arg_1842, arg_1843) } else { o__6 = jrt.Long_ValueOf_J__Long_NoInit(linked_1840.(*A_arbace_go_check_types_align_up_A).InvokePrim_O_J_J__J(root_1839, lang.RT_LongCast_O__J_NoInit(arg_1842), lang.RT_LongCast_O__J_NoInit(arg_1843))).Ref() }
//line :626:1
				var d__7 any; var root_1848 any = A_arbace_go_check_types_A_const_207.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1848, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1850 lang.IFn


				if linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = A_arbace_go_check_types_A_const_70.Invoke_O__O(f__5); if linked_1849 == nil { d__7 = ifn_1850.Invoke_O__O(arg_1851) } else { d__7 = jrt.Long_ValueOf_J__Long_NoInit(linked_1849.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1848, arg_1851)).Ref() }
				var tmp6 any; var root_1861 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1861, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1863 lang.IFn; if linked_1862 == nil { ifn_1863 = lang.IFn_Cast(root_1861) } else { ifn_1863 = nil }; var arg_1864 any = fs__2; if linked_1862 == nil { tmp6 = ifn_1863.Invoke_O__O(arg_1864) } else { tmp6 = linked_1862.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1861, arg_1864) }; var tmp7 any = tmp6; var tmp8 any; var tmp9 bool; var and__1927000168__auto____8 bool; var na_1865 any = d__7; var na_1866 int64 = 0
				if jrt.Long_InstanceOf(na_1865) { var n0_1867 int64 = jrt.NN(jrt.Long_Cast(na_1865)).LongValue__J(); var n1_1868 int64 = na_1866; and__1927000168__auto____8 = n0_1867 >= n1_1868 } else { and__1927000168__auto____8 = lang.Numbers_Gte_O_J__Z_NoInit(na_1865, na_1866) }; if and__1927000168__auto____8 { var na_1870 any = o__6; var na_1871 int64 = 0; if jrt.Long_InstanceOf(na_1870) { var n0_1872 int64 = jrt.NN(jrt.Long_Cast(na_1870)).LongValue__J(); var n1_1873 int64 = na_1871; tmp9 = n0_1872 >= n1_1873 } else { tmp9 = lang.Numbers_Gte_O_J__Z_NoInit(na_1870, na_1871) } } else { tmp9 = and__1927000168__auto____8 }; if tmp9 { var na_1875 any = o__6; var na_1876 any = d__7; var tmp10 bool; var tmp11 bool; tmp11 = jrt.Long_InstanceOf(na_1875); if tmp11 { tmp11 = jrt.Long_InstanceOf(na_1876) }; tmp10 = tmp11; if tmp10 { var n0_1877 int64 = jrt.NN(jrt.Long_Cast(na_1875)).LongValue__J(); var n1_1878 int64 = jrt.NN(jrt.Long_Cast(na_1876)).LongValue__J(); tmp8 = jrt.Long_ValueOf_J__Long_NoInit(n0_1877 + n1_1878).Ref() } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_1875); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_1876) }; tmp12 = tmp13; if tmp12 { var n0_1877_2 float64 = jrt.NN(jrt.Double_Cast(na_1875)).DoubleValue__D(); var n1_1878_2 float64 = jrt.NN(jrt.Double_Cast(na_1876)).DoubleValue__D(); tmp8 = jrt.Double_ValueOf_D__Double_NoInit(n0_1877_2 + n1_1878_2).Ref() } else { tmp8 = lang.Numbers_Unchecked_add_O_O__Number_NoInit(na_1875, na_1876) } } } else { tmp8 = A_arbace_go_check_types_A_const_210 }
//line :630:1
				var tmp14 any = tmp8; var tmp15 any; var root_1880 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1881 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1880, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1882 lang.IFn

				if linked_1881 == nil { ifn_1882 = lang.IFn_Cast(root_1880) } else { ifn_1882 = nil }; var arg_1883 any = acc__4; var arg_1884 any = o__6; if linked_1881 == nil { tmp15 = ifn_1882.Invoke_O_O__O(arg_1883, arg_1884) } else { tmp15 = linked_1881.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1880, arg_1883, arg_1884) }
//line :630:1
				fs__2, offs__3, acc__4 = tmp7, tmp14, tmp15; continue L1 } } } }; /*line :618:1*/panic("j2g: unreachable") }















func A_arbace_go_check_types_sizeof_A_New() *A_arbace_go_check_types_sizeof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sizeof_A{}; t.Ctor(); return t }
//line :634:1
func (t *A_arbace_go_check_types_sizeof_A) Ctor() {}
//line :634:1
func (t *A_arbace_go_check_types_sizeof_A) InvokePrim_O_O__J(self, t__0 any) int64 { var tmp1 any; var u__2 any; var root_1885 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_1886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1885, A_arbace_go_check_types_under_A_fn_class); var ifn_1887 lang.IFn; if


	linked_1886 == nil { ifn_1887 = lang.IFn_Cast(root_1885) } else { ifn_1887 = nil }; var arg_1888 any = t__0; if linked_1886 == nil { u__2 = ifn_1887.Invoke_O__O(arg_1888) } else { u__2 = linked_1886.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1885, arg_1888) }; var tmp2 any; var root_1889 any =
	A_arbace_go_check_types_A_const_85.GetRawRoot__O(); var linked_1890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1889, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_1891 lang.IFn; if
	linked_1890 == nil { ifn_1891 = lang.IFn_Cast(root_1889) } else { ifn_1891 = nil }; var arg_1892 any = u__2; if linked_1890 == nil { tmp2 = ifn_1891.Invoke_O__O(arg_1892) } else { tmp2 = linked_1890.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_1889, arg_1892) }; if /*line :638:1*/ jrt.J2g_Truth(tmp2) { var G__219000256__3_ any = u__2
	L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__219000256__3_) { case 717828005: if any(G__219000256__3_) == any(A_arbace_go_check_types_A_const_40) { var na_1894 int64 = 2; var na_1895 any = A_arbace_go_check_types_A_const_206.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1895) { var n0_1896 int64 = na_1894; var n1_1897 int64 = jrt.NN(jrt.Long_Cast(na_1895)).LongValue__J(); var nr_1898 int64 = n0_1896 * n1_1897; var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; tmp6 = n0_1896 == -9223372036854775808; if tmp6 { tmp6 = n1_1897 < 0 }; tmp5 = tmp6; tmp4 = !tmp5; if tmp4 { var tmp7 bool; tmp7 = n1_1897 == 0; if !tmp7 { tmp7 = nr_1898/n1_1897 == n0_1896 }; tmp4 = tmp7 }; tmp3 = tmp4; if tmp3 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1898).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1894, na_1895) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1894, na_1895) }; break L1 }; default:}; var tmp8 lang.IFn = A_arbace_go_check_types_A_const_11; tmp1 = tmp8.Invoke_O_O__O(lang.IFn_Cast(A_arbace_go_check_types_A_const_108.GetRawRoot__O()).Invoke_O__O(u__2), A_arbace_go_check_types_A_const_206.GetRawRoot__O())} } else {
//line :638:1
		if A_arbace_go_check_types_A_const_88 != nil { var G__219000257__3_ any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0))


		L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__219000257__3_) >> 5 & 3 { case 0: if any(G__219000257__3_) == any(A_arbace_go_check_types_A_const_72) { var n__4 int64 = lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)))

			if lang.Numbers_Lte_J_J__Z_NoInit(n__4, 0) { tmp1 = A_arbace_go_check_types_A_const_44 } else { var es__5 any; var root_1900 any = A_arbace_go_check_types_A_const_207.GetRawRoot__O(); var linked_1901 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1900, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1902 lang.IFn

				if linked_1901 == nil { ifn_1902 = lang.IFn_Cast(root_1900) } else { ifn_1902 = nil }; var arg_1903 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)); if linked_1901 == nil { es__5 = ifn_1902.Invoke_O__O(arg_1903) } else { es__5 = jrt.Long_ValueOf_J__Long_NoInit(linked_1901.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1900, arg_1903)).Ref() }
				var tmp9 bool; var na_1904 any = es__5
				if jrt.Long_InstanceOf(na_1904) { var n0_1905 int64 = jrt.NN(jrt.Long_Cast(na_1904)).LongValue__J(); tmp9 = n0_1905 < 0 } else { if jrt.Double_InstanceOf(na_1904) { var n0_1905_2 float64 = jrt.NN(jrt.Double_Cast(na_1904)).DoubleValue__D(); tmp9 = n0_1905_2 < 0.0 } else { tmp9 = lang.Numbers_IsNeg_O__Z_NoInit(na_1904) } }
//line :646:1
				if tmp9 { tmp1 = A_arbace_go_check_types_A_const_210 } else { var tmp10 bool
					var na_1906 any = es__5
					if jrt.Long_InstanceOf(na_1906) { var n0_1907 int64 = jrt.NN(jrt.Long_Cast(na_1906)).LongValue__J(); tmp10 = n0_1907 == 0 } else { if jrt.Double_InstanceOf(na_1906) { var n0_1907_2 float64 = jrt.NN(jrt.Double_Cast(na_1906)).DoubleValue__D(); tmp10 = n0_1907_2 == 0.0 } else { tmp10 = lang.Numbers_IsZero_O__Z_NoInit(na_1906) } }
//line :646:1
					if tmp10 { tmp1 = A_arbace_go_check_types_A_const_44 } else { var tmp11 bool; var na_1908 any = es__5; var na_1909 int64 = lang.Numbers_Quotient_J_J__J_NoInit(9223372036854775807, n__4)


						if jrt.Long_InstanceOf(na_1908) { var n0_1910 int64 = jrt.NN(jrt.Long_Cast(na_1908)).LongValue__J(); var n1_1911 int64 = na_1909; tmp11 = n0_1910 > n1_1911 } else { tmp11 = lang.Numbers_Gt_O_J__Z_NoInit(na_1908, na_1909) }
//line :646:1
						if tmp11 { tmp1 = A_arbace_go_check_types_A_const_210 } else { if A_arbace_go_check_types_A_const_88 != nil {



							var na_1913 any = es__5; var na_1914 int64 = n__4; if jrt.Long_InstanceOf(na_1913) { var n0_1915 int64 = jrt.NN(jrt.Long_Cast(na_1913)).LongValue__J(); var n1_1916 int64 = na_1914; var nr_1917 int64 = n0_1915 * n1_1916; var tmp12 bool; var tmp13 bool; var tmp14 bool; var tmp15 bool; tmp15 = n0_1915 == -9223372036854775808; if tmp15 { tmp15 = n1_1916 < 0 }; tmp14 = tmp15; tmp13 = !tmp14; if tmp13 { var tmp16 bool; tmp16 = n1_1916 == 0; if !tmp16 { tmp16 = nr_1917/n1_1916 == n0_1915 }; tmp13 = tmp16 }; tmp12 = tmp13; if tmp12 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1917).Ref() } else { tmp1 = lang.Numbers_Multiply_O_J__Number_NoInit(na_1913, na_1914) } } else { tmp1 = lang.Numbers_Multiply_O_J__Number_NoInit(na_1913, na_1914) } } else {
//line :646:1
								tmp1 = nil } } } } }
//line :641:1
			break L2 }; case 1: if any(G__219000257__3_) == any(A_arbace_go_check_types_A_const_67) {





















				var na_1918 int64 = 2; var na_1919 any = A_arbace_go_check_types_A_const_206.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1919) { var n0_1920 int64 = na_1918; var n1_1921 int64 = jrt.NN(jrt.Long_Cast(na_1919)).LongValue__J(); var nr_1922 int64 = n0_1920 * n1_1921; var tmp17 bool; var tmp18 bool; var tmp19 bool; var tmp20 bool; tmp20 = n0_1920 == -9223372036854775808; if tmp20 { tmp20 = n1_1921 < 0 }; tmp19 = tmp20; tmp18 = !tmp19; if tmp18 { var tmp21 bool; tmp21 = n1_1921 == 0; if !tmp21 { tmp21 = nr_1922/n1_1921 == n0_1920 }; tmp18 = tmp21 }; tmp17 = tmp18; if tmp17 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1922).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1918, na_1919) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1918, na_1919) }
//line :641:1
				break L2 }; case 2: if any(G__219000257__3_) == any(A_arbace_go_check_types_A_const_75) {









					var na_1923 int64 = 3; var na_1924 any = A_arbace_go_check_types_A_const_206.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1924) { var n0_1925 int64 = na_1923; var n1_1926 int64 = jrt.NN(jrt.Long_Cast(na_1924)).LongValue__J(); var nr_1927 int64 = n0_1925 * n1_1926; var tmp22 bool; var tmp23 bool; var tmp24 bool; var tmp25 bool; tmp25 = n0_1925 == -9223372036854775808; if tmp25 { tmp25 = n1_1926 < 0 }; tmp24 = tmp25; tmp23 = !tmp24; if tmp23 { var tmp26 bool; tmp26 = n1_1926 == 0; if !tmp26 { tmp26 = nr_1927/n1_1926 == n0_1925 }; tmp23 = tmp26 }; tmp22 = tmp23; if tmp22 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1927).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1923, na_1924) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1923, na_1924) }
//line :641:1
					break L2 }; case 3: if any(G__219000257__3_) == any(A_arbace_go_check_types_A_const_82) { var fs__4 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); var tmp27 any; var root_1928 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1928, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1930 lang.IFn











						if linked_1929 == nil { ifn_1930 = lang.IFn_Cast(root_1928) } else { ifn_1930 = nil }; var arg_1931 any = fs__4; if linked_1929 == nil { tmp27 = ifn_1930.Invoke_O__O(arg_1931) } else { tmp27 = linked_1929.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1928, arg_1931) }; if jrt.J2g_Truth(tmp27) { tmp1 = A_arbace_go_check_types_A_const_44 } else { var offs__5 any; var root_1932 any = A_arbace_go_check_types_A_const_211.GetRawRoot__O(); var linked_1933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1932, A_arbace_go_check_types_offsetsof_A_fn_class); var ifn_1934 lang.IFn

							if linked_1933 == nil { ifn_1934 = lang.IFn_Cast(root_1932) } else { ifn_1934 = nil }; var arg_1935 any = fs__4; if linked_1933 == nil { offs__5 = ifn_1934.Invoke_O__O(arg_1935) } else { offs__5 = linked_1933.(*A_arbace_go_check_types_offsetsof_A).Invoke_O_O__O(root_1932, arg_1935) }
//line :653:1
							var o__6 int64; var tmp28 any; var root_1936 any = A_arbace_go_check_types_A_const_212.GetRawRoot__O(); var linked_1937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1936, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_1938 lang.IFn


							if linked_1937 == nil { ifn_1938 = lang.IFn_Cast(root_1936) } else { ifn_1938 = nil }; var arg_1939 any = offs__5; if linked_1937 == nil { tmp28 = ifn_1938.Invoke_O__O(arg_1939) } else { tmp28 = linked_1937.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_1936, arg_1939) }; o__6 = lang.RT_LongCast_O__J_NoInit(tmp28)
//line :653:1
							var s__7 any; var root_1940 any = A_arbace_go_check_types_A_const_207.GetRawRoot__O(); var linked_1941 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1940, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1942 lang.IFn



							if linked_1941 == nil { ifn_1942 = lang.IFn_Cast(root_1940) } else { ifn_1942 = nil }; var arg_1943 any; var tmp29 *lang.Keyword = A_arbace_go_check_types_A_const_70; var tmp30 any; var root_1944 any = A_arbace_go_check_types_A_const_212.GetRawRoot__O(); var linked_1945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1944, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_1946 lang.IFn; if linked_1945 == nil { ifn_1946 = lang.IFn_Cast(root_1944) } else { ifn_1946 = nil }; var arg_1947 any = fs__4; if linked_1945 == nil { tmp30 = ifn_1946.Invoke_O__O(arg_1947) } else { tmp30 = linked_1945.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_1944, arg_1947) }; arg_1943 = tmp29.Invoke_O__O(tmp30); if linked_1941 == nil { s__7 = ifn_1942.Invoke_O__O(arg_1943) } else { s__7 = jrt.Long_ValueOf_J__Long_NoInit(linked_1941.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1940, arg_1943)).Ref() }
							var tmp31 bool; var or__1927000174__auto____8 bool = lang.Numbers_IsNeg_J__Z_NoInit(o__6); if or__1927000174__auto____8 { tmp31 = or__1927000174__auto____8 } else { var na_1948 any = s__7; if jrt.Long_InstanceOf(na_1948) { var n0_1949 int64 = jrt.NN(jrt.Long_Cast(na_1948)).LongValue__J(); tmp31 = n0_1949 < 0 } else { if jrt.Double_InstanceOf(na_1948) { var n0_1949_2 float64 = jrt.NN(jrt.Double_Cast(na_1948)).DoubleValue__D(); tmp31 = n0_1949_2 < 0.0 } else { tmp31 = lang.Numbers_IsNeg_O__Z_NoInit(na_1948) } } }; if tmp31 { tmp1 = A_arbace_go_check_types_A_const_210 } else { var s__8 any; var tmp32 bool; var and__1927000168__auto____8 bool = lang.Numbers_IsPos_J__Z_NoInit(o__6)

								if and__1927000168__auto____8 { var na_1950 any = s__7; if jrt.Long_InstanceOf(na_1950) { var n0_1951 int64 = jrt.NN(jrt.Long_Cast(na_1950)).LongValue__J(); tmp32 = n0_1951 == 0 } else { if jrt.Double_InstanceOf(na_1950) { var n0_1951_2 float64 = jrt.NN(jrt.Double_Cast(na_1950)).DoubleValue__D(); tmp32 = n0_1951_2 == 0.0 } else { tmp32 = lang.Numbers_IsZero_O__Z_NoInit(na_1950) } } } else { tmp32 = and__1927000168__auto____8 }; if tmp32 { s__8 = A_arbace_go_check_types_A_const_15 } else { s__8 = s__7
								}
								var root_1952 any = A_arbace_go_check_types_A_const_209.GetRawRoot__O(); var linked_1953 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1952, A_arbace_go_check_types_align_up_A_fn_class); var ifn_1954 lang.IFn; if linked_1953 == nil { ifn_1954 = lang.IFn_Cast(root_1952) } else { ifn_1954 = nil }; var arg_1955 any; var na_1957 int64 = o__6; var na_1958 any = s__8; if jrt.Long_InstanceOf(na_1958) { var n0_1959 int64 = na_1957; var n1_1960 int64 = jrt.NN(jrt.Long_Cast(na_1958)).LongValue__J(); arg_1955 = jrt.Long_ValueOf_J__Long_NoInit(n0_1959 + n1_1960).Ref() } else { arg_1955 = lang.Numbers_Unchecked_add_J_O__Number_NoInit(na_1957, na_1958) }; var arg_1956 any; var root_1962 any = A_arbace_go_check_types_A_const_202.GetRawRoot__O(); var linked_1963 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1962, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1964 lang.IFn; if linked_1963 == nil { ifn_1964 = lang.IFn_Cast(root_1962) } else { ifn_1964 = nil }; var arg_1965 any = t__0; if linked_1963 == nil { arg_1956 = ifn_1964.Invoke_O__O(arg_1965) } else { arg_1956 = jrt.Long_ValueOf_J__Long_NoInit(linked_1963.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1962, arg_1965)).Ref() }; if linked_1953 == nil { tmp1 = ifn_1954.Invoke_O_O__O(arg_1955, arg_1956) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_1953.(*A_arbace_go_check_types_align_up_A).InvokePrim_O_J_J__J(root_1952, lang.RT_LongCast_O__J_NoInit(arg_1955), lang.RT_LongCast_O__J_NoInit(arg_1956))).Ref() } } }
//line :641:1
						break L2 }; default:}; tmp1 = A_arbace_go_check_types_A_const_206.GetRawRoot__O()} } else {
//line :638:1
							tmp1 = nil } }; return /*line :634:1*/ jrt.Number_Cast(tmp1).LongValue__J() }
//line :634:1
func (t *A_arbace_go_check_types_sizeof_A) Invoke_O_O__O(self, t__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, t__0)).Ref() }

































func A_arbace_go_check_types_deref_type_A_New() *A_arbace_go_check_types_deref_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_deref_type_A{}; t.Ctor(); return t }
//line :668:1
func (t *A_arbace_go_check_types_deref_type_A) Ctor() {}
//line :668:1
func (t *A_arbace_go_check_types_deref_type_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_1966 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_1967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1966, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1968 lang.IFn; if linked_1967 == nil { ifn_1968 = lang.IFn_Cast(root_1966) } else { ifn_1968 = nil }; var arg_1969 any = t__0; if linked_1967 == nil { and__1927000168__auto____2 = ifn_1968.Invoke_O__O(arg_1969) } else { and__1927000168__auto____2 = linked_1967.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1966, arg_1969) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_types_A_const_71; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)), jrt.Boolean_TRUE.Ref()) } else { return lang.Tuple_Create_O_O__IPersistentVector(t__0, jrt.Boolean_FALSE.Ref())
	} }
func A_arbace_go_check_types_methods_of_A_New() *A_arbace_go_check_types_methods_of_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_methods_of_A{}; t.Ctor(); return t }
//line :673:1
func (t *A_arbace_go_check_types_methods_of_A) Ctor() {}
//line :673:1
func (t *A_arbace_go_check_types_methods_of_A) Invoke_O_O__O(self, t__0 any) any { var t__2 any; var tmp1 *lang.Keyword = A_arbace_go_check_types_A_const_213; var tmp2 any; var root_1970 any = A_arbace_go_check_types_A_const_97.GetRawRoot__O(); var linked_1971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1970, A_arbace_go_check_types_info_A_fn_class); var ifn_1972 lang.IFn; if


	linked_1971 == nil { ifn_1972 = lang.IFn_Cast(root_1970) } else { ifn_1972 = nil }; var arg_1973 any = t__0; if linked_1971 == nil { tmp2 = ifn_1972.Invoke_O__O(arg_1973) } else { tmp2 = linked_1971.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1970, arg_1973) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 *lang.Keyword = A_arbace_go_check_types_A_const_213; var tmp4 any; var root_1974 any = A_arbace_go_check_types_A_const_97.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, A_arbace_go_check_types_info_A_fn_class); var ifn_1976 lang.IFn; if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = t__0; if linked_1975 == nil { tmp4 = ifn_1976.Invoke_O__O(arg_1977) } else { tmp4 = linked_1975.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1974, arg_1977) }; t__2 = tmp3.Invoke_O__O(tmp4) } else { t__2 = t__0 }; var root_1982 any =
	A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_1983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1982, A_arbace_go_check_types_under_A_fn_class); var ifn_1984 lang.IFn; if linked_1983 == nil { ifn_1984 = lang.IFn_Cast(root_1982) } else { ifn_1984 = nil }; var arg_1985 any = t__2; if linked_1983 == nil { ifn_1984.Invoke_O__O(arg_1985) } else { linked_1983.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1982, arg_1985) }; var tmp5 /*line :678:1*/*lang.Keyword = A_arbace_go_check_types_A_const_96; var tmp6 any; var root_1978 any = A_arbace_go_check_types_A_const_97.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, A_arbace_go_check_types_info_A_fn_class); var ifn_1980 lang.IFn; if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any = t__2; if linked_1979 == nil { tmp6 = ifn_1980.Invoke_O__O(arg_1981) } else { tmp6 = linked_1979.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1978, arg_1981) }; return tmp5.Invoke_O__O(tmp6) }





func A_arbace_go_check_types_same_id_QMARK__A_New() *A_arbace_go_check_types_same_id_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_same_id_QMARK__A{}; t.Ctor(); return t }
//line :684:1
func (t *A_arbace_go_check_types_same_id_QMARK__A) Ctor() {}
//line :684:1
func (t *A_arbace_go_check_types_same_id_QMARK__A) Invoke_O_O_O_O_O__O(self, n__0, p__1, name__2, pkg__3 any) any {



	var tmp1 any; var and__1927000168__auto____5 any = A_arbace_go_check_types_A_const_214.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.String_Cast(n__0)).EqualsIgnoreCase_String__Z(jrt.String_Cast(name__2))).Ref() } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, name__2)

		if and__1927000168__auto____5_2 { var or__1927000174__auto____6 bool = jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(name__2)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))
			if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(p__1, pkg__3); if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { return jrt.Boolean_FALSE.Ref() } } } else {
//line :690:1
				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref()
			}
	}
}


func A_arbace_go_check_types_exported_QMARK__A_New() *A_arbace_go_check_types_exported_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_exported_QMARK__A{}; t.Ctor(); return t }
//line :696:1
func (t *A_arbace_go_check_types_exported_QMARK__A) Ctor() {}
//line :696:1
func (t *A_arbace_go_check_types_exported_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var cp__2 int32 = jrt.NN(jrt.String_Cast(n__0)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(0)); return /*line :697:1*/ jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_I__Z_NoInit(cp__2)).Ref() }











func A_arbace_go_check_types_named_method_A_New() *A_arbace_go_check_types_named_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_method_A{}; t.Ctor(); return t }
//line :709:1
func (t *A_arbace_go_check_types_named_method_A) Ctor() {}
//line :709:1
func (t *A_arbace_go_check_types_named_method_A) Invoke_O_O_O_O__O(self, t__0, name__1, pkg__2 any) any { { var ms__4 any; var root_1986 any = A_arbace_go_check_types_A_const_215.GetRawRoot__O(); var linked_1987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1986, A_arbace_go_check_types_methods_of_A_fn_class); var ifn_1988 lang.IFn


	if linked_1987 == nil { ifn_1988 = lang.IFn_Cast(root_1986) } else { ifn_1988 = nil }; var arg_1989 any = t__0; if linked_1987 == nil { ms__4 = ifn_1988.Invoke_O__O(arg_1989) } else { ms__4 = linked_1987.(*A_arbace_go_check_types_methods_of_A).Invoke_O_O__O(root_1986, arg_1989) }
//line :709:1
	var i__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i__5, int64(lang.RT_Count_O__I_NoInit(ms__4))) { var m__6 any = lang.RT_Nth_O_I__O_NoInit(ms__4, lang.RT_IntCast_J__I_NoInit(i__5)); var map__219000263__7 any; var root_1990 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1990, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1992 lang.IFn
			if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; var arg_1993 any = m__6; if linked_1991 == nil { map__219000263__7 = ifn_1992.Invoke_O__O(arg_1993) } else { map__219000263__7 = linked_1991.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1990, arg_1993) }
//line :714:1
			var map__219000263__8 any
			if lang.ISeq_InstanceOf(map__219000263__7) { var tmp1 any; var root_1994 any = A_arbace_go_check_types_A_const_216.GetRawRoot__O(); var linked_1995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1994, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1996 lang.IFn; if linked_1995 == nil { ifn_1996 = lang.IFn_Cast(root_1994) } else { ifn_1996 = nil }; var arg_1997 any = map__219000263__7; if linked_1995 == nil { tmp1 = ifn_1996.Invoke_O__O(arg_1997) } else { tmp1 = linked_1995.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1994, arg_1997) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1998 any = A_arbace_go_check_types_A_const_217.GetRawRoot__O(); var linked_1999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1998, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2000 lang.IFn; if linked_1999 == nil { ifn_2000 = lang.IFn_Cast(root_1998) } else { ifn_2000 = nil }; var arg_2001 any = map__219000263__7; if linked_1999 == nil { tmp2 = ifn_2000.Invoke_O__O(arg_2001) } else { tmp2 = linked_1999.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1998, arg_2001) }; map__219000263__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_2002 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_2003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2002, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2004 lang.IFn; if linked_2003 == nil { ifn_2004 = lang.IFn_Cast(root_2002) } else { ifn_2004 = nil }; var arg_2005 any = map__219000263__7; if linked_2003 == nil { tmp3 = ifn_2004.Invoke_O__O(arg_2005) } else { tmp3 = linked_2003.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2002, arg_2005) }; if jrt.J2g_Truth(tmp3) { var root_2006 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_2007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2006, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2008 lang.IFn; if linked_2007 == nil { ifn_2008 = lang.IFn_Cast(root_2006) } else { ifn_2008 = nil }; var arg_2009 any = map__219000263__7; if linked_2007 == nil { map__219000263__8 = ifn_2008.Invoke_O__O(arg_2009) } else { map__219000263__8 = linked_2007.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2006, arg_2009) } } else { map__219000263__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__219000263__8 = map__219000263__7 }
//line :714:1
			var mn__9 any = lang.RT_Get_O_O__O_NoInit(map__219000263__8, A_arbace_go_check_types_A_const_12); var mp__10 any = lang.RT_Get_O_O__O_NoInit(map__219000263__8, A_arbace_go_check_types_A_const_57); var tmp4 any; var root_2010 any = A_arbace_go_check_types_A_const_218.GetRawRoot__O(); var linked_2011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2010, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_2012 lang.IFn


			if linked_2011 == nil { ifn_2012 = lang.IFn_Cast(root_2010) } else { ifn_2012 = nil }; var arg_2013 any = mn__9; var arg_2014 any = mp__10; var arg_2015 any = name__1; var arg_2016 any = pkg__2; if linked_2011 == nil { tmp4 = ifn_2012.Invoke_O_O_O_O__O(arg_2013, arg_2014, arg_2015, arg_2016) } else { tmp4 = linked_2011.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_2010, arg_2013, arg_2014, arg_2015, arg_2016) }; if jrt.J2g_Truth(tmp4) { return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__5).Ref(), m__6) } else {

				i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } } else {
//line :714:1
					return nil } } }; /*line :709:1*/panic("j2g: unreachable") }











func A_arbace_go_check_types_iface_method_A_New() *A_arbace_go_check_types_iface_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_iface_method_A{}; t.Ctor(); return t }
//line :721:1
func (t *A_arbace_go_check_types_iface_method_A) Ctor() {}
//line :721:1
func (t *A_arbace_go_check_types_iface_method_A) Invoke_O_O_O_O__O(self, u__0, name__1, pkg__2 any) any { { var ms__4 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(1)); var i__5 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i__5, int64(lang.RT_Count_O__I_NoInit(ms__4))) { var m__6 any = lang.RT_Nth_O_I__O_NoInit(ms__4, lang.RT_IntCast_J__I_NoInit(i__5)); var tmp1 any; var root_2017 any = A_arbace_go_check_types_A_const_218.GetRawRoot__O(); var linked_2018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2017, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_2019 lang.IFn

		if linked_2018 == nil { ifn_2019 = lang.IFn_Cast(root_2017) } else { ifn_2019 = nil }; var arg_2020 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__6); var arg_2021 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(m__6); var arg_2022 any = name__1; var arg_2023 any = pkg__2; if linked_2018 == nil { tmp1 = ifn_2019.Invoke_O_O_O_O__O(arg_2020, arg_2021, arg_2022, arg_2023) } else { tmp1 = linked_2018.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_2017, arg_2020, arg_2021, arg_2022, arg_2023) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__5).Ref(), m__6) } else {

			i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } } else {
//line :726:1
				return nil } } }; /*line :721:1*/panic("j2g: unreachable") }










func A_arbace_go_check_types_consolidate_A_New() *A_arbace_go_check_types_consolidate_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_consolidate_A{}; t.Ctor(); return t }
//line :732:1
func (t *A_arbace_go_check_types_consolidate_A) Ctor() {}
//line :732:1
func (t *A_arbace_go_check_types_consolidate_A) Invoke_O_O__O(self, entries__0 any) any { { var es__2 any = entries__0; var acc__3 any = lang.PersistentVector_EMPTY.Ref(); var idx__4 any = lang.PersistentArrayMap_EMPTY.Ref(); L1: for {



	var tmp1 any; var root_2024 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_2025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2024, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2026 lang.IFn; if linked_2025 == nil { ifn_2026 = lang.IFn_Cast(root_2024) } else { ifn_2026 = nil }; var arg_2027 any = es__2; if linked_2025 == nil { tmp1 = ifn_2026.Invoke_O__O(arg_2027) } else { tmp1 = linked_2025.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2024, arg_2027) }; if jrt.J2g_Truth(tmp1) { return acc__3 } else { var e__5 any; var root_2028 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_2029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2028, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2030 lang.IFn

		if linked_2029 == nil { ifn_2030 = lang.IFn_Cast(root_2028) } else { ifn_2030 = nil }; var arg_2031 any = es__2; if linked_2029 == nil { e__5 = ifn_2030.Invoke_O__O(arg_2031) } else { e__5 = linked_2029.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2028, arg_2031) }
//line :736:1
		var k__6 any; var root_2032 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_2033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2032, A_arbace_go_check_types_canon_A_fn_class); var ifn_2034 lang.IFn


		if linked_2033 == nil { ifn_2034 = lang.IFn_Cast(root_2032) } else { ifn_2034 = nil }; var arg_2035 any = A_arbace_go_check_types_A_const_70.Invoke_O__O(e__5); if linked_2033 == nil { k__6 = ifn_2034.Invoke_O__O(arg_2035) } else { k__6 = linked_2033.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_2032, arg_2035) }
//line :736:1
		var temp__1927000408__auto____7 any = lang.RT_Get_O_O__O_NoInit(idx__4, k__6)



		if jrt.J2g_Truth(temp__1927000408__auto____7) { var j__8 any = temp__1927000408__auto____7; var tmp2 any; var root_2036 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_2037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2036, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2038 lang.IFn
			if linked_2037 == nil { ifn_2038 = lang.IFn_Cast(root_2036) } else { ifn_2038 = nil }; var arg_2039 any = es__2; if linked_2037 == nil { tmp2 = ifn_2038.Invoke_O__O(arg_2039) } else { tmp2 = linked_2037.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2036, arg_2039) }; var tmp3 any = tmp2; var tmp4 any; var root_2040 any = A_arbace_go_check_types_A_const_219.GetRawRoot__O(); var linked_2041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2040, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_2042 lang.IFn; if linked_2041 == nil { ifn_2042 = lang.IFn_Cast(root_2040) } else { ifn_2042 = nil }; var arg_2043 any = acc__3; var arg_2044 any = lang.Tuple_Create_O_O__IPersistentVector(j__8, A_arbace_go_check_types_A_const_220); var arg_2045 any = jrt.Boolean_TRUE.Ref(); if linked_2041 == nil { tmp4 = ifn_2042.Invoke_O_O_O__O(arg_2043, arg_2044, arg_2045) } else { tmp4 = linked_2041.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_2040, arg_2043, arg_2044, arg_2045) }; es__2, acc__3, idx__4 = tmp3, tmp4, idx__4; continue L1 } else {
				var tmp5 any; var root_2046 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_2047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2046, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2048 lang.IFn; if linked_2047 == nil { ifn_2048 = lang.IFn_Cast(root_2046) } else { ifn_2048 = nil }; var arg_2049 any = es__2; if linked_2047 == nil { tmp5 = ifn_2048.Invoke_O__O(arg_2049) } else { tmp5 = linked_2047.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2046, arg_2049) }; var tmp6 any = tmp5; var tmp7 any; var root_2050 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2051 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2050, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2052 lang.IFn; if linked_2051 == nil { ifn_2052 = lang.IFn_Cast(root_2050) } else { ifn_2052 = nil }; var arg_2053 any = acc__3; var arg_2054 any = e__5; if linked_2051 == nil { tmp7 = ifn_2052.Invoke_O_O__O(arg_2053, arg_2054) } else { tmp7 = linked_2051.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2050, arg_2053, arg_2054) }; var tmp8 any = tmp7; var tmp9 any; var root_2055 any = A_arbace_go_check_types_A_const_93.GetRawRoot__O(); var linked_2056 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2055, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2057 lang.IFn; if linked_2056 == nil { ifn_2057 = lang.IFn_Cast(root_2055) } else { ifn_2057 = nil }; var arg_2058 any = idx__4; var arg_2059 any = k__6; var arg_2060 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(acc__3)).Ref(); if linked_2056 == nil { tmp9 = ifn_2057.Invoke_O_O_O__O(arg_2058, arg_2059, arg_2060) } else { tmp9 = linked_2056.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2055, arg_2058, arg_2059, arg_2060) }; es__2, acc__3, idx__4 = tmp6, tmp8, tmp9; continue L1 } } } }; /*line :732:1*/panic("j2g: unreachable") }











func A_arbace_go_check_types_lookup_impl_A_New() *A_arbace_go_check_types_lookup_impl_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_impl_A{}; t.Ctor(); return t }
//line :744:1
func (t *A_arbace_go_check_types_lookup_impl_A) Ctor() {}
//line :744:1
func (t *A_arbace_go_check_types_lookup_impl_A) Invoke_O_O_O_O_O__O(self, T__0_, addressable__1, name__2, pkg__3 any) any { { var vec__219000268__5 any; var root_2061 any = A_arbace_go_check_types_A_const_221.GetRawRoot__O(); var linked_2062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2061, A_arbace_go_check_types_deref_type_A_fn_class); var ifn_2063 lang.IFn





	if linked_2062 == nil { ifn_2063 = lang.IFn_Cast(root_2061) } else { ifn_2063 = nil }; var arg_2064 any = T__0_; if linked_2062 == nil { vec__219000268__5 = ifn_2063.Invoke_O__O(arg_2064) } else { vec__219000268__5 = linked_2062.(*A_arbace_go_check_types_deref_type_A).Invoke_O_O__O(root_2061, arg_2064) }
//line :744:1
	var typ__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000268__5, lang.RT_IntCast_J__I_NoInit(0), nil); var is_ptr__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000268__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any
	var and__1927000168__auto____8 any = is_ptr__7





	if jrt.J2g_Truth(and__1927000168__auto____8) { var root_2065 any = A_arbace_go_check_types_A_const_222.GetRawRoot__O(); var linked_2066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2065, A_arbace_go_check_types_interface_QMARK__A_fn_class); var ifn_2067 lang.IFn; if linked_2066 == nil { ifn_2067 = lang.IFn_Cast(root_2065) } else { ifn_2067 = nil }; var arg_2068 any = typ__6; if linked_2066 == nil { tmp1 = ifn_2067.Invoke_O__O(arg_2068) } else { tmp1 = linked_2066.(*A_arbace_go_check_types_interface_QMARK__A).Invoke_O_O__O(root_2065, arg_2068) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return nil } else { var current__8 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_70, typ__6, A_arbace_go_check_types_A_const_230, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_types_A_const_231, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_types_A_const_232, is_ptr__7, A_arbace_go_check_types_A_const_220, jrt.Boolean_FALSE.Ref()))); var seen__9 any = lang.PersistentHashSet_EMPTY.Ref(); L1: for {



		var tmp2 any; var root_2069 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_2070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2069, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2071 lang.IFn; if linked_2070 == nil { ifn_2071 = lang.IFn_Cast(root_2069) } else { ifn_2071 = nil }; var arg_2072 any = current__8; if linked_2070 == nil { tmp2 = ifn_2071.Invoke_O__O(arg_2072) } else { tmp2 = linked_2070.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2069, arg_2072) }; if jrt.J2g_Truth(tmp2) { return nil } else { var vec__219000271__10 any; var root_2073 any = A_arbace_go_check_types_A_const_204.GetRawRoot__O(); var linked_2074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2073, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_2075 lang.IFn


			if linked_2074 == nil { ifn_2075 = lang.IFn_Cast(root_2073) } else { ifn_2075 = nil }; var arg_2076 any; var tmp3 any = A_arbace_go_check_types_lookup_impl_fn__219000275_A_New_O_O(pkg__3, name__2); var tmp4 *jrt.Class; var fncls__2182 *jrt.Class = A_arbace_go_check_types_lookup_impl_fn__219000275_A_fn_class
			if fncls__2182 == nil { var fncls__2182d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_go_check_types_lookup_impl_fn__219000275_A_fn_class = fncls__2182d; tmp4 = fncls__2182d } else { tmp4 = fncls__2182 }; arg_2076 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)
//line :758:1
			var arg_2077 any = lang.Tuple_Create_O_O_O__IPersistentVector(nil, lang.PersistentVector_EMPTY.Ref(), seen__9); var arg_2078 any = current__8; if linked_2074 == nil { vec__219000271__10 = ifn_2075.Invoke_O_O_O__O(arg_2076, arg_2077, arg_2078) } else { vec__219000271__10 = linked_2074.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_2073, arg_2076, arg_2077, arg_2078) }
//line :755:1
			var found__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000271__10, lang.RT_IntCast_J__I_NoInit(0), nil); var next__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000271__10, lang.RT_IntCast_J__I_NoInit(1), nil); var seen__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000271__10, lang.RT_IntCast_J__I_NoInit(2), nil)















































			if jrt.J2g_Truth(A_arbace_go_check_types_A_const_237.Invoke_O__O(found__11)) { return found__11 } else { if jrt.J2g_Truth(found__11) {


				var tmp5 any; var tmp6 any = A_arbace_go_check_types_A_const_227; var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_go_check_types_A_const_226.Invoke_O__O(found__11)); if and__1927000168__auto____14 { var tmp7 *lang.Keyword = A_arbace_go_check_types_A_const_238; var and__1927000168__auto____15 any = tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_go_check_types_A_const_239.Get__O()).Invoke_O__O(A_arbace_go_check_types_A_const_58.Invoke_O__O(found__11))); if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any; var root_2183 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_2184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2183, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2185 lang.IFn
					if linked_2184 == nil { ifn_2185 = lang.IFn_Cast(root_2183) } else { ifn_2185 = nil }; var arg_2186 any = A_arbace_go_check_types_A_const_232.Invoke_O__O(found__11); if linked_2184 == nil { and__1927000168__auto____16 = ifn_2185.Invoke_O__O(arg_2186) } else { and__1927000168__auto____16 = linked_2184.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2183, arg_2186) }
//line :806:1
					if jrt.J2g_Truth(and__1927000168__auto____16) {
						var root_2187 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_2188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2187, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2189 lang.IFn; if linked_2188 == nil { ifn_2189 = lang.IFn_Cast(root_2187) } else { ifn_2189 = nil }; var arg_2190 any = addressable__1; if linked_2188 == nil { tmp5 = ifn_2189.Invoke_O__O(arg_2190) } else { tmp5 = linked_2188.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2187, arg_2190) } } else {
//line :806:1
							tmp5 = and__1927000168__auto____16 } } else { tmp5 = and__1927000168__auto____15 } } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }; if jrt.J2g_Truth(tmp5) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_238, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_types_A_const_240, found__11)) } else { return found__11 } } else {
//line :803:1
								if A_arbace_go_check_types_A_const_88 != nil {






									var tmp8 any; var root_2191 any = A_arbace_go_check_types_A_const_241.GetRawRoot__O(); var linked_2192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2191, A_arbace_go_check_types_consolidate_A_fn_class); var ifn_2193 lang.IFn; if linked_2192 == nil { ifn_2193 = lang.IFn_Cast(root_2191) } else { ifn_2193 = nil }; var arg_2194 any = next__12; if linked_2192 == nil { tmp8 = ifn_2193.Invoke_O__O(arg_2194) } else { tmp8 = linked_2192.(*A_arbace_go_check_types_consolidate_A).Invoke_O_O__O(root_2191, arg_2194) }; current__8, seen__9 = tmp8, seen__13; continue L1 } else {
//line :803:1
										return nil } } } } } } }; /*line :744:1*/panic("j2g: unreachable") }














func A_arbace_go_check_types_lookup_impl_fn__219000275_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_lookup_impl_fn__219000275_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_impl_fn__219000275_A{}; t.Ctor_O_O(p0, p1); return t }
//line :759:1
func (t *A_arbace_go_check_types_lookup_impl_fn__219000275_A) Ctor_O_O(c__pkg, c__name any) { t.F_pkg = c__pkg; t.F_name = c__name }
//line :759:1
func (t *A_arbace_go_check_types_lookup_impl_fn__219000275_A) Invoke_O_O_O__O(self, p__219000274__1, e__2 any) any { { var vec__219000276__3 any = p__219000274__1; var found__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000276__3, lang.RT_IntCast_J__I_NoInit(0), nil); var next__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000276__3, lang.RT_IntCast_J__I_NoInit(1), nil); var seen__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000276__3, lang.RT_IntCast_J__I_NoInit(2), nil); var typ__7 any = A_arbace_go_check_types_A_const_70.Invoke_O__O(e__2); var tmp1 any; var and__1927000168__auto____8 any; var root_2079 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_2080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2079, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_2081 lang.IFn

	if linked_2080 == nil { ifn_2081 = lang.IFn_Cast(root_2079) } else { ifn_2081 = nil }; var arg_2082 any = typ__7; if linked_2080 == nil { and__1927000168__auto____8 = ifn_2081.Invoke_O__O(arg_2082) } else { and__1927000168__auto____8 = linked_2080.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_2079, arg_2082) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_2083 any = A_arbace_go_check_types_A_const_100.GetRawRoot__O(); var linked_2084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2083, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2085 lang.IFn; if linked_2084 == nil { ifn_2085 = lang.IFn_Cast(root_2083) } else { ifn_2085 = nil }; var arg_2086 any = seen__6; var arg_2087 any = typ__7; if linked_2084 == nil { tmp1 = ifn_2085.Invoke_O_O__O(arg_2086, arg_2087) } else { tmp1 = linked_2084.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2083, arg_2086, arg_2087) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__6) } else { var seen__8 any; var tmp2 any; var root_2088 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_2089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2088, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_2090 lang.IFn

		if linked_2089 == nil { ifn_2090 = lang.IFn_Cast(root_2088) } else { ifn_2090 = nil }; var arg_2091 any = typ__7; if linked_2089 == nil { tmp2 = ifn_2090.Invoke_O__O(arg_2091) } else { tmp2 = linked_2089.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_2088, arg_2091) }; if jrt.J2g_Truth(tmp2) { var root_2092 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2093 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2092, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2094 lang.IFn; if linked_2093 == nil { ifn_2094 = lang.IFn_Cast(root_2092) } else { ifn_2094 = nil }; var arg_2095 any = seen__6; var arg_2096 any = typ__7; if linked_2093 == nil { seen__8 = ifn_2094.Invoke_O_O__O(arg_2095, arg_2096) } else { seen__8 = linked_2093.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2092, arg_2095, arg_2096) } } else { seen__8 = seen__6 }
//line :761:1
		var m__9 any; var tmp3 any; var root_2097 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_2098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2097, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_2099 lang.IFn


		if linked_2098 == nil { ifn_2099 = lang.IFn_Cast(root_2097) } else { ifn_2099 = nil }; var arg_2100 any = typ__7; if linked_2098 == nil { tmp3 = ifn_2099.Invoke_O__O(arg_2100) } else { tmp3 = linked_2098.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_2097, arg_2100) }; if jrt.J2g_Truth(tmp3) { var root_2101 any = A_arbace_go_check_types_A_const_223.GetRawRoot__O(); var linked_2102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2101, A_arbace_go_check_types_named_method_A_fn_class); var ifn_2103 lang.IFn; if linked_2102 == nil { ifn_2103 = lang.IFn_Cast(root_2101) } else { ifn_2103 = nil }; var arg_2104 any = typ__7; var arg_2105 any = t.F_name; var arg_2106 any = t.F_pkg; if linked_2102 == nil { m__9 = ifn_2103.Invoke_O_O_O__O(arg_2104, arg_2105, arg_2106) } else { m__9 = linked_2102.(*A_arbace_go_check_types_named_method_A).Invoke_O_O_O_O__O(root_2101, arg_2104, arg_2105, arg_2106) } } else { m__9 = nil }
		if jrt.J2g_Truth(m__9) {
			var tmp4 any; var or__1927000174__auto____10 any = found__4; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp4 = or__1927000174__auto____10 } else { tmp4 = A_arbace_go_check_types_A_const_220.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp4) { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_225, next__5, seen__8) } else { var tmp5 any = A_arbace_go_check_types_A_const_226; var tmp6 any = A_arbace_go_check_types_A_const_227; var tmp7 any = A_arbace_go_check_types_A_const_58; var tmp8 any; var root_2136 any = A_arbace_go_check_types_A_const_228.GetRawRoot__O(); var linked_2137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2136, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2138 lang.IFn

				if linked_2137 == nil { ifn_2138 = lang.IFn_Cast(root_2136) } else { ifn_2138 = nil }; var arg_2139 any = m__9; if linked_2137 == nil { tmp8 = ifn_2138.Invoke_O__O(arg_2139) } else { tmp8 = linked_2137.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2136, arg_2139) }
//line :766:1
				var tmp9 any = tmp8; var tmp10 any = A_arbace_go_check_types_A_const_229; var tmp11 any = A_arbace_go_check_types_A_const_230; var tmp12 any; var root_2140 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2141 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2140, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2142 lang.IFn

				if linked_2141 == nil { ifn_2142 = lang.IFn_Cast(root_2140) } else { ifn_2142 = nil }; var arg_2143 any = A_arbace_go_check_types_A_const_230.Invoke_O__O(e__2); var arg_2144 any; var root_2145 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_2146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2145, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2147 lang.IFn; if linked_2146 == nil { ifn_2147 = lang.IFn_Cast(root_2145) } else { ifn_2147 = nil }; var arg_2148 any = m__9; if linked_2146 == nil { arg_2144 = ifn_2147.Invoke_O__O(arg_2148) } else { arg_2144 = linked_2146.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2145, arg_2148) }; if linked_2141 == nil { tmp12 = ifn_2142.Invoke_O_O__O(arg_2143, arg_2144) } else { tmp12 = linked_2141.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2140, arg_2143, arg_2144) }
//line :766:1
				var tmp13 any = tmp12; var tmp14 any = A_arbace_go_check_types_A_const_231; var tmp15 any = A_arbace_go_check_types_A_const_231.Invoke_O__O(e__2); var tmp16 any = A_arbace_go_check_types_A_const_232; return lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, tmp9, tmp10, typ__7, tmp11, tmp13, tmp14, tmp15, tmp16, A_arbace_go_check_types_A_const_232.Invoke_O__O(e__2))), next__5, seen__8) } } else {
//line :765:1
					var u__10 any; var root_2107 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_2108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2107, A_arbace_go_check_types_under_A_fn_class); var ifn_2109 lang.IFn




					if linked_2108 == nil { ifn_2109 = lang.IFn_Cast(root_2107) } else { ifn_2109 = nil }; var arg_2110 any = typ__7; if linked_2108 == nil { u__10 = ifn_2109.Invoke_O__O(arg_2110) } else { u__10 = linked_2108.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2107, arg_2110) }
					var tmp17 any; var and__1927000168__auto____11 any; var root_2111 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_2112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2111, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2113 lang.IFn
					if linked_2112 == nil { ifn_2113 = lang.IFn_Cast(root_2111) } else { ifn_2113 = nil }; var arg_2114 any = u__10; if linked_2112 == nil { and__1927000168__auto____11 = ifn_2113.Invoke_O__O(arg_2114) } else { and__1927000168__auto____11 = linked_2112.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2111, arg_2114) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var tmp18 any = A_arbace_go_check_types_A_const_82; tmp17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp18, lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp17 = and__1927000168__auto____11 }
//line :771:1
					if jrt.J2g_Truth(tmp17) { var fs__11 any = lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(1)); var i__12 int64 = 0; var found__13 any = found__4; var next__14 any = next__5; L1: for {



						if lang.Numbers_Gte_J_J__Z_NoInit(i__12, int64(lang.RT_Count_O__I_NoInit(fs__11))) { return lang.Tuple_Create_O_O_O__IPersistentVector(found__13, next__14, seen__8) } else { var f__15 any = lang.RT_Nth_O_I__O_NoInit(fs__11, lang.RT_IntCast_J__I_NoInit(i__12)); var tmp19 any; var root_2115 any = A_arbace_go_check_types_A_const_218.GetRawRoot__O(); var linked_2116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2115, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_2117 lang.IFn



							if linked_2116 == nil { ifn_2117 = lang.IFn_Cast(root_2115) } else { ifn_2117 = nil }; var arg_2118 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(f__15); var arg_2119 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(f__15); var arg_2120 any = t.F_name; var arg_2121 any = t.F_pkg; if linked_2116 == nil { tmp19 = ifn_2117.Invoke_O_O_O_O__O(arg_2118, arg_2119, arg_2120, arg_2121) } else { tmp19 = linked_2116.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_2115, arg_2118, arg_2119, arg_2120, arg_2121) }
//line :778:1
							if jrt.J2g_Truth(tmp19) {

								var tmp20 any; var or__1927000174__auto____16 any = found__13; if jrt.J2g_Truth(or__1927000174__auto____16) { tmp20 = or__1927000174__auto____16 } else { tmp20 = A_arbace_go_check_types_A_const_220.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp20) {
									i__12, found__13, next__14 = lang.Numbers_Inc_J__J_NoInit(i__12), A_arbace_go_check_types_A_const_233, next__14; continue L1 } else {
										var tmp21 int64 = lang.Numbers_Inc_J__J_NoInit(i__12); var tmp22 any = A_arbace_go_check_types_A_const_226; var tmp23 any = A_arbace_go_check_types_A_const_234; var tmp24 any = A_arbace_go_check_types_A_const_58; var tmp25 any = A_arbace_go_check_types_A_const_230; var tmp26 any; var root_2149 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2150 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2149, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2151 lang.IFn; if linked_2150 == nil { ifn_2151 = lang.IFn_Cast(root_2149) } else { ifn_2151 = nil }; var arg_2152 any = A_arbace_go_check_types_A_const_230.Invoke_O__O(e__2); var arg_2153 any = jrt.Long_ValueOf_J__Long_NoInit(i__12).Ref(); if linked_2150 == nil { tmp26 = ifn_2151.Invoke_O_O__O(arg_2152, arg_2153) } else { tmp26 = linked_2150.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2149, arg_2152, arg_2153) }; var tmp27 any = tmp26; var tmp28 any = A_arbace_go_check_types_A_const_231; var tmp29 any = A_arbace_go_check_types_A_const_231.Invoke_O__O(e__2); var tmp30 any = A_arbace_go_check_types_A_const_232; i__12, found__13, next__14 = tmp21, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp23, tmp24, f__15, tmp25, tmp27, tmp28, tmp29, tmp30, A_arbace_go_check_types_A_const_232.Invoke_O__O(e__2))), next__14; continue L1 } } else {
//line :778:1
											var tmp31 any; var and__1927000168__auto____16 bool = lang.Util_Identical_O_O__Z_NoInit(found__13, nil)






											if and__1927000168__auto____16 { tmp31 = A_arbace_go_check_types_A_const_186.Invoke_O__O(f__15) } else { tmp31 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____16).Ref() }
//line :778:1
											if jrt.J2g_Truth(tmp31) { var vec__219000279__16 any; var root_2122 any = A_arbace_go_check_types_A_const_221.GetRawRoot__O(); var linked_2123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2122, A_arbace_go_check_types_deref_type_A_fn_class); var ifn_2124 lang.IFn







												if linked_2123 == nil { ifn_2124 = lang.IFn_Cast(root_2122) } else { ifn_2124 = nil }; var arg_2125 any = A_arbace_go_check_types_A_const_70.Invoke_O__O(f__15); if linked_2123 == nil { vec__219000279__16 = ifn_2124.Invoke_O__O(arg_2125) } else { vec__219000279__16 = linked_2123.(*A_arbace_go_check_types_deref_type_A).Invoke_O_O__O(root_2122, arg_2125) }
//line :778:1
												var ft__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000279__16, lang.RT_IntCast_J__I_NoInit(0), nil); var fp__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000279__16, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp32 int64 = lang.Numbers_Inc_J__J_NoInit(i__12); var tmp33 any; var root_2154 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2155 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2154, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2156 lang.IFn









												if linked_2155 == nil { ifn_2156 = lang.IFn_Cast(root_2154) } else { ifn_2156 = nil }; var arg_2157 any = next__14; var arg_2158 any; var tmp34 any = A_arbace_go_check_types_A_const_70; var tmp35 any = A_arbace_go_check_types_A_const_230; var tmp36 any; var root_2159 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2160 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2159, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2161 lang.IFn; if linked_2160 == nil { ifn_2161 = lang.IFn_Cast(root_2159) } else { ifn_2161 = nil }; var arg_2162 any = A_arbace_go_check_types_A_const_230.Invoke_O__O(e__2); var arg_2163 any = jrt.Long_ValueOf_J__Long_NoInit(i__12).Ref(); if linked_2160 == nil { tmp36 = ifn_2161.Invoke_O_O__O(arg_2162, arg_2163) } else { tmp36 = linked_2160.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2159, arg_2162, arg_2163) }; var tmp37 any = tmp36; var tmp38 any = A_arbace_go_check_types_A_const_231; var tmp39 any; var root_2164 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2165 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2164, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2166 lang.IFn
												if linked_2165 == nil { ifn_2166 = lang.IFn_Cast(root_2164) } else { ifn_2166 = nil }; var arg_2167 any = A_arbace_go_check_types_A_const_231.Invoke_O__O(e__2); var arg_2168 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(f__15); if linked_2165 == nil { tmp39 = ifn_2166.Invoke_O_O__O(arg_2167, arg_2168) } else { tmp39 = linked_2165.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2164, arg_2167, arg_2168) }
//line :788:1
												var tmp40 any = tmp39; var tmp41 any = A_arbace_go_check_types_A_const_232; var tmp42 any; var or__1927000174__auto____19 any = A_arbace_go_check_types_A_const_232.Invoke_O__O(e__2)

												if jrt.J2g_Truth(or__1927000174__auto____19) { tmp42 = or__1927000174__auto____19 } else { tmp42 = fp__18 }
//line :788:1
												var tmp43 any = tmp42; var tmp44 any = A_arbace_go_check_types_A_const_220; arg_2158 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp34, ft__17, tmp35, tmp37, tmp38, tmp40, tmp41, tmp43, tmp44, A_arbace_go_check_types_A_const_220.Invoke_O__O(e__2))); if linked_2155 == nil { tmp33 = ifn_2156.Invoke_O_O__O(arg_2157, arg_2158) } else { tmp33 = linked_2155.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2154, arg_2157, arg_2158) }
//line :787:1
												i__12, found__13, next__14 = tmp32, found__13, tmp33; continue L1 } else {
//line :778:1
													if A_arbace_go_check_types_A_const_88 != nil {













														i__12, found__13, next__14 = lang.Numbers_Inc_J__J_NoInit(i__12), found__13, next__14; continue L1 } else {
//line :778:1
															return nil } } } } } } else {
//line :771:1
																var tmp45 any; var and__1927000168__auto____11_2 any; var root_2126 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_2127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2126, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2128 lang.IFn





















																if linked_2127 == nil { ifn_2128 = lang.IFn_Cast(root_2126) } else { ifn_2128 = nil }; var arg_2129 any = u__10; if linked_2127 == nil { and__1927000168__auto____11_2 = ifn_2128.Invoke_O__O(arg_2129) } else { and__1927000168__auto____11_2 = linked_2127.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2126, arg_2129) }; if jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp46 any = A_arbace_go_check_types_A_const_67; tmp45 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp46, lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp45 = and__1927000168__auto____11_2 }
//line :771:1
																if jrt.J2g_Truth(tmp45) { var temp__1927000408__auto____11 any; var root_2130 any = A_arbace_go_check_types_A_const_224.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, A_arbace_go_check_types_iface_method_A_fn_class); var ifn_2132 lang.IFn






















																	if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any = u__10; var arg_2134 any = t.F_name; var arg_2135 any = t.F_pkg; if linked_2131 == nil { temp__1927000408__auto____11 = ifn_2132.Invoke_O_O_O__O(arg_2133, arg_2134, arg_2135) } else { temp__1927000408__auto____11 = linked_2131.(*A_arbace_go_check_types_iface_method_A).Invoke_O_O_O_O__O(root_2130, arg_2133, arg_2134, arg_2135) }; if jrt.J2g_Truth(temp__1927000408__auto____11) { var m__12 any = temp__1927000408__auto____11; var tmp47 any; var or__1927000174__auto____13 any = found__4
																		if jrt.J2g_Truth(or__1927000174__auto____13) { tmp47 = or__1927000174__auto____13 } else { tmp47 = A_arbace_go_check_types_A_const_220.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp47) { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_235, next__5, seen__8) } else { var tmp48 any = A_arbace_go_check_types_A_const_226; var tmp49 any = A_arbace_go_check_types_A_const_236; var tmp50 any = A_arbace_go_check_types_A_const_58; var tmp51 any; var root_2169 any = A_arbace_go_check_types_A_const_228.GetRawRoot__O(); var linked_2170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2169, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2171 lang.IFn

																			if linked_2170 == nil { ifn_2171 = lang.IFn_Cast(root_2169) } else { ifn_2171 = nil }; var arg_2172 any = m__12; if linked_2170 == nil { tmp51 = ifn_2171.Invoke_O__O(arg_2172) } else { tmp51 = linked_2170.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2169, arg_2172) }
//line :795:1
																			var tmp52 any = tmp51; var tmp53 any = A_arbace_go_check_types_A_const_163; var tmp54 any = A_arbace_go_check_types_A_const_230; var tmp55 any; var root_2173 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2174 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2173, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2175 lang.IFn

																			if linked_2174 == nil { ifn_2175 = lang.IFn_Cast(root_2173) } else { ifn_2175 = nil }; var arg_2176 any = A_arbace_go_check_types_A_const_230.Invoke_O__O(e__2); var arg_2177 any; var root_2178 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_2179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2178, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2180 lang.IFn; if linked_2179 == nil { ifn_2180 = lang.IFn_Cast(root_2178) } else { ifn_2180 = nil }; var arg_2181 any = m__12; if linked_2179 == nil { arg_2177 = ifn_2180.Invoke_O__O(arg_2181) } else { arg_2177 = linked_2179.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2178, arg_2181) }; if linked_2174 == nil { tmp55 = ifn_2175.Invoke_O_O__O(arg_2176, arg_2177) } else { tmp55 = linked_2174.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2173, arg_2176, arg_2177) }
//line :795:1
																			var tmp56 any = tmp55; var tmp57 any = A_arbace_go_check_types_A_const_231; var tmp58 any = A_arbace_go_check_types_A_const_231.Invoke_O__O(e__2); var tmp59 any = A_arbace_go_check_types_A_const_232; return lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp48, tmp49, tmp50, tmp52, tmp53, typ__7, tmp54, tmp56, tmp57, tmp58, tmp59, A_arbace_go_check_types_A_const_232.Invoke_O__O(e__2))), next__5, seen__8) } } else {
//line :794:1
																				return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__8) } } else {
//line :771:1
																					if A_arbace_go_check_types_A_const_88 != nil { return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__8) } else { return nil } } } } } }; /*line :759:1*/panic("j2g: unreachable") }




















































func A_arbace_go_check_types_lookup_A_New() *A_arbace_go_check_types_lookup_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_A{}; t.Ctor(); return t }
//line :812:1
func (t *A_arbace_go_check_types_lookup_A) Ctor() {}
//line :812:1
func (t *A_arbace_go_check_types_lookup_A) Invoke_O_O_O_O_O__O(self, T__0_, addressable__1, name__2, pkg__3 any) any {


	var tmp1 any; var and__1927000168__auto____5 any; var root_2195 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_2196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2195, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_2197 lang.IFn; if linked_2196 == nil { ifn_2197 = lang.IFn_Cast(root_2195) } else { ifn_2197 = nil }; var arg_2198 any = T__0_; if linked_2196 == nil { and__1927000168__auto____5 = ifn_2197.Invoke_O__O(arg_2198) } else { and__1927000168__auto____5 = linked_2196.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_2195, arg_2198) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_2199 any = A_arbace_go_check_types_A_const_242.GetRawRoot__O(); var linked_2200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2199, A_arbace_go_check_types_pointer_QMARK__A_fn_class); var ifn_2201 lang.IFn; if linked_2200 == nil { ifn_2201 = lang.IFn_Cast(root_2199) } else { ifn_2201 = nil }; var arg_2202 any = T__0_; if linked_2200 == nil { tmp1 = ifn_2201.Invoke_O__O(arg_2202) } else { tmp1 = linked_2200.(*A_arbace_go_check_types_pointer_QMARK__A).Invoke_O_O__O(root_2199, arg_2202) } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var r__5 any; var root_2203 any = A_arbace_go_check_types_A_const_243.GetRawRoot__O(); var linked_2204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2203, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_2205 lang.IFn
		if linked_2204 == nil { ifn_2205 = lang.IFn_Cast(root_2203) } else { ifn_2205 = nil }; var arg_2206 any; var root_2210 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_2211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2210, A_arbace_go_check_types_under_A_fn_class); var ifn_2212 lang.IFn; if linked_2211 == nil { ifn_2212 = lang.IFn_Cast(root_2210) } else { ifn_2212 = nil }; var arg_2213 any = T__0_; if linked_2211 == nil { arg_2206 = ifn_2212.Invoke_O__O(arg_2213) } else { arg_2206 = linked_2211.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2210, arg_2213) }; var arg_2207 any = jrt.Boolean_FALSE.Ref(); var arg_2208 any = name__2; var arg_2209 any = pkg__3; if linked_2204 == nil { r__5 = ifn_2205.Invoke_O_O_O_O__O(arg_2206, arg_2207, arg_2208, arg_2209) } else { r__5 = linked_2204.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_2203, arg_2206, arg_2207, arg_2208, arg_2209) }
		var tmp2 any = A_arbace_go_check_types_A_const_227; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_go_check_types_A_const_226.Invoke_O__O(r__5)) { return nil } else { return r__5 } } else {
			var root_2214 any = A_arbace_go_check_types_A_const_243.GetRawRoot__O(); var linked_2215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2214, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_2216 lang.IFn; if linked_2215 == nil { ifn_2216 = lang.IFn_Cast(root_2214) } else { ifn_2216 = nil }; var arg_2217 any = T__0_; var arg_2218 any = addressable__1; var arg_2219 any = name__2; var arg_2220 any = pkg__3; if linked_2215 == nil { return ifn_2216.Invoke_O_O_O_O__O(arg_2217, arg_2218, arg_2219, arg_2220) } else { return linked_2215.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_2214, arg_2217, arg_2218, arg_2219, arg_2220)
			}
		}
}
func A_arbace_go_check_types_sort_methods_A_New() *A_arbace_go_check_types_sort_methods_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sort_methods_A{}; t.Ctor(); return t }
//line :822:1
func (t *A_arbace_go_check_types_sort_methods_A) Ctor() {}
//line :822:1
func (t *A_arbace_go_check_types_sort_methods_A) Invoke_O_O__O(self, ms__0 any) any {


	var root_2221 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_2222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2221, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2223 lang.IFn; if linked_2222 == nil { ifn_2223 = lang.IFn_Cast(root_2221) } else { ifn_2223 = nil }; var arg_2224 any; var root_2225 any = A_arbace_go_check_types_A_const_182.GetRawRoot__O(); var linked_2226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2225, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2227 lang.IFn; if linked_2226 == nil { ifn_2227 = lang.IFn_Cast(root_2225) } else { ifn_2227 = nil }; var arg_2228 any; var tmp1 any = A_arbace_go_check_types_sort_methods_fn__219000285_A_New(); var tmp2 *jrt.Class; var fncls__2230 *jrt.Class = A_arbace_go_check_types_sort_methods_fn__219000285_A_fn_class; if fncls__2230 == nil { var fncls__2230d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_check_types_sort_methods_fn__219000285_A_fn_class = fncls__2230d; tmp2 = fncls__2230d } else { tmp2 = fncls__2230 }; arg_2228 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2229 any = ms__0; if linked_2226 == nil { arg_2224 = ifn_2227.Invoke_O_O__O(arg_2228, arg_2229) } else { arg_2224 = linked_2226.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2225, arg_2228, arg_2229) }; if linked_2222 == nil { return ifn_2223.Invoke_O__O(arg_2224) } else { return linked_2222.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2221, arg_2224) } }
//line :825:1
func A_arbace_go_check_types_sort_methods_fn__219000285_A_New() *A_arbace_go_check_types_sort_methods_fn__219000285_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sort_methods_fn__219000285_A{}; t.Ctor(); return t }
//line :825:1
func (t *A_arbace_go_check_types_sort_methods_fn__219000285_A) Ctor() {}
//line :825:1
func (t *A_arbace_go_check_types_sort_methods_fn__219000285_A) Invoke_O_O__O(self, m__1 any) any { var tmp1 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var tmp2 any; var or__1927000174__auto____2 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(m__1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = Lit_10 }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }

func A_arbace_go_check_types_method_data_A_New() *A_arbace_go_check_types_method_data_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_method_data_A{}; t.Ctor(); return t }
//line :827:1
func (t *A_arbace_go_check_types_method_data_A) Ctor() {}
//line :827:1
func (t *A_arbace_go_check_types_method_data_A) Invoke_O_O__O(self, m__0 any) any {


	var tmp1 any; var root_2231 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_2232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2231, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_2233 lang.IFn; if linked_2232 == nil { ifn_2233 = lang.IFn_Cast(root_2231) } else { ifn_2233 = nil }; var arg_2234 any = m__0; if linked_2232 == nil { tmp1 = ifn_2233.Invoke_O__O(arg_2234) } else { tmp1 = linked_2232.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_2231, arg_2234) }; if jrt.J2g_Truth(tmp1) { return m__0 } else { return lang.IFn_Cast(A_arbace_go_check_types_A_const_239.Get__O()).Invoke_O__O(m__0)
	} }
func A_arbace_go_check_types_missing_method_A_New() *A_arbace_go_check_types_missing_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_A{}; t.Ctor(); return t }
//line :832:1
func (t *A_arbace_go_check_types_missing_method_A) Ctor() {}
//line :832:1
func (t *A_arbace_go_check_types_missing_method_A) Invoke_O_O_O_O_O__O(self, V__0_, T__1_, static__2, same_QMARK___3 any) any { var tu__5 any; var root_2235 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_2236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2235, A_arbace_go_check_types_under_A_fn_class); var ifn_2237 lang.IFn; if





	linked_2236 == nil { ifn_2237 = lang.IFn_Cast(root_2235) } else { ifn_2237 = nil }; var arg_2238 any = T__1_; if linked_2236 == nil { tu__5 = ifn_2237.Invoke_O__O(arg_2238) } else { tu__5 = linked_2236.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2235, arg_2238) }; var vu__6 any; var root_2239 any = /*line :832:1*/A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_2240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2239, A_arbace_go_check_types_under_A_fn_class); var ifn_2241 lang.IFn; if






	linked_2240 == nil { ifn_2241 = lang.IFn_Cast(root_2239) } else { ifn_2241 = nil }; var arg_2242 any = V__0_; if linked_2240 == nil { vu__6 = ifn_2241.Invoke_O__O(arg_2242) } else { vu__6 = linked_2240.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2239, arg_2242) }; var tmp1 any; var tmp2 /*line :842:1*/*lang.Keyword = A_arbace_go_check_types_A_const_244; var or__1927000174__auto____7 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tu__5)); if jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { var tmp3 *lang.Keyword = A_arbace_go_check_types_A_const_244; tmp1 = tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(vu__6)) }; if jrt.J2g_Truth(tmp1) { return nil } else {
		var root_2243 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_2244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2243, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2245 lang.IFn; if linked_2244 == nil { ifn_2245 = lang.IFn_Cast(root_2243) } else { ifn_2245 = nil }; var arg_2246 any; var tmp4 any = A_arbace_go_check_types_missing_method_fn__219000289_A_New_O_O_O_O(static__2, V__0_, same_QMARK___3, vu__6); var tmp5 *jrt.Class; var fncls__2317 *jrt.Class = A_arbace_go_check_types_missing_method_fn__219000289_A_fn_class
		if fncls__2317 == nil { var fncls__2317d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_go_check_types_missing_method_fn__219000289_A_fn_class = fncls__2317d; tmp5 = fncls__2317d } else { tmp5 = fncls__2317 }; arg_2246 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)
//line :843:1
		var arg_2247 any = lang.RT_Nth_O_I__O_NoInit(tu__5, lang.RT_IntCast_J__I_NoInit(1)); if linked_2244 == nil { return ifn_2245.Invoke_O_O__O(arg_2246, arg_2247) } else { return linked_2244.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2243, arg_2246, arg_2247) } } }
//line :832:1
func (t *A_arbace_go_check_types_missing_method_A) Invoke_O_O_O_O__O(self, V__0_, T__1_, static__2 any) any {



	var root_2318 any = A_arbace_go_check_types_A_const_257.GetRawRoot__O(); var linked_2319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2318, A_arbace_go_check_types_missing_method_A_fn_class); var ifn_2320 lang.IFn; if linked_2319 == nil { ifn_2320 = lang.IFn_Cast(root_2318) } else { ifn_2320 = nil }; var arg_2321 any = V__0_; var arg_2322 any = T__1_; var arg_2323 any = static__2; var arg_2324 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); if linked_2319 == nil { return ifn_2320.Invoke_O_O_O_O__O(arg_2321, arg_2322, arg_2323, arg_2324) } else { return linked_2319.(*A_arbace_go_check_types_missing_method_A).Invoke_O_O_O_O_O__O(root_2318, arg_2321, arg_2322, arg_2323, arg_2324)
	}
}





func A_arbace_go_check_types_missing_method_fn__219000289_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_types_missing_method_fn__219000289_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_fn__219000289_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :844:1
func (t *A_arbace_go_check_types_missing_method_fn__219000289_A) Ctor_O_O_O_O(c__static, c__V, c__same_QMARK_, c__vu any) { t.F_static = c__static; t.F_V = c__V; t.F_same_QMARK_ = c__same_QMARK_; t.F_vu = c__vu }
//line :844:1
func (t *A_arbace_go_check_types_missing_method_fn__219000289_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_2248 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_2249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2248, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2250 lang.IFn; if linked_2249 == nil { ifn_2250 = lang.IFn_Cast(root_2248) } else { ifn_2250 = nil }; var arg_2251 any = t.F_vu; if linked_2249 == nil { and__1927000168__auto____2 = ifn_2250.Invoke_O__O(arg_2251) } else { and__1927000168__auto____2 = linked_2249.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2248, arg_2251) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_types_A_const_67; var tmp3 any = t.F_vu; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var f__2 any; var root_2252 any = A_arbace_go_check_types_A_const_224.GetRawRoot__O(); var linked_2253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2252, A_arbace_go_check_types_iface_method_A_fn_class); var ifn_2254 lang.IFn
		if linked_2253 == nil { ifn_2254 = lang.IFn_Cast(root_2252) } else { ifn_2254 = nil }; var arg_2255 any = t.F_vu; var arg_2256 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var arg_2257 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(m__1); if linked_2253 == nil { f__2 = ifn_2254.Invoke_O_O_O__O(arg_2255, arg_2256, arg_2257) } else { f__2 = linked_2253.(*A_arbace_go_check_types_iface_method_A).Invoke_O_O_O_O__O(root_2252, arg_2255, arg_2256, arg_2257) }
		if lang.Util_Identical_O_O__Z_NoInit(f__2, nil) {
			if jrt.J2g_Truth(t.F_static) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_227, m__1, A_arbace_go_check_types_A_const_245, A_arbace_go_check_types_A_const_246)) } else { return nil } } else {
//line :847:1
				var tmp4 any; var root_2258 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_2259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2258, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2260 lang.IFn

				if linked_2259 == nil { ifn_2260 = lang.IFn_Cast(root_2258) } else { ifn_2260 = nil }; var arg_2261 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_same_QMARK_); var tmp6 *lang.Keyword = A_arbace_go_check_types_A_const_70; var tmp7 any; var root_2262 any = A_arbace_go_check_types_A_const_228.GetRawRoot__O(); var linked_2263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2262, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2264 lang.IFn; if linked_2263 == nil { ifn_2264 = lang.IFn_Cast(root_2262) } else { ifn_2264 = nil }; var arg_2265 any = f__2; if linked_2263 == nil { tmp7 = ifn_2264.Invoke_O__O(arg_2265) } else { tmp7 = linked_2263.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2262, arg_2265) }; arg_2261 = tmp5.Invoke_O_O__O(tmp6.Invoke_O__O(tmp7), A_arbace_go_check_types_A_const_70.Invoke_O__O(m__1)); if linked_2259 == nil { tmp4 = ifn_2260.Invoke_O__O(arg_2261) } else { tmp4 = linked_2259.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2258, arg_2261) }
//line :847:1
				if jrt.J2g_Truth(tmp4) { var tmp8 any = A_arbace_go_check_types_A_const_227; var tmp9 any = A_arbace_go_check_types_A_const_245; var tmp10 any = A_arbace_go_check_types_A_const_247; var tmp11 any = A_arbace_go_check_types_A_const_248; var tmp12 any; var root_2266 any = A_arbace_go_check_types_A_const_228.GetRawRoot__O(); var linked_2267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2266, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2268 lang.IFn

					if linked_2267 == nil { ifn_2268 = lang.IFn_Cast(root_2266) } else { ifn_2268 = nil }; var arg_2269 any = f__2; if linked_2267 == nil { tmp12 = ifn_2268.Invoke_O__O(arg_2269) } else { tmp12 = linked_2267.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2266, arg_2269) }
//line :847:1
					return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, m__1, tmp9, tmp10, tmp11, tmp12)) } else { return nil } } } else {
//line :845:1
						var r__2 any; var root_2270 any = A_arbace_go_check_types_A_const_243.GetRawRoot__O(); var linked_2271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2270, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_2272 lang.IFn




						if linked_2271 == nil { ifn_2272 = lang.IFn_Cast(root_2270) } else { ifn_2272 = nil }; var arg_2273 any = t.F_V; var arg_2274 any = jrt.Boolean_FALSE.Ref(); var arg_2275 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var arg_2276 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(m__1); if linked_2271 == nil { r__2 = ifn_2272.Invoke_O_O_O_O__O(arg_2273, arg_2274, arg_2275, arg_2276) } else { r__2 = linked_2271.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_2270, arg_2273, arg_2274, arg_2275, arg_2276) }
						if jrt.J2g_Truth(A_arbace_go_check_types_A_const_238.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_227, m__1, A_arbace_go_check_types_A_const_245, A_arbace_go_check_types_A_const_238)) } else { if lang.Util_Identical_O_O__Z_NoInit(r__2, nil) { var fr__3 any; var root_2308 any = A_arbace_go_check_types_A_const_255.GetRawRoot__O(); var linked_2309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2308, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2310 lang.IFn



							if linked_2309 == nil { ifn_2310 = lang.IFn_Cast(root_2308) } else { ifn_2310 = nil }; var arg_2311 any = lang.IFn_Cast(A_arbace_go_check_types_A_const_256.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_214, jrt.Boolean_TRUE.Ref()); if linked_2309 == nil { ifn_2310.Invoke_O__O(arg_2311) } else { linked_2309.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2308, arg_2311) }; var tmp13 any = A_arbace_go_check_types_missing_method_fn__219000289_fn__219000290_A_New_O_O(m__1, t.F_V); var tmp14 *jrt.Class; var fncls__2287 *jrt.Class = A_arbace_go_check_types_missing_method_fn__219000289_fn__219000290_A_fn_class; if fncls__2287 == nil { var fncls__2287d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_go_check_types_missing_method_fn__219000289_fn__219000290_A_fn_class = fncls__2287d; tmp14 = fncls__2287d } else { tmp14 = fncls__2287 }; fr__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil).Invoke__O()
							var tmp15 any; var tmp16 any = A_arbace_go_check_types_A_const_227; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp16, A_arbace_go_check_types_A_const_226.Invoke_O__O(fr__3)); if and__1927000168__auto____4 { var root_2288 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_2289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2288, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2290 lang.IFn; if linked_2289 == nil { ifn_2290 = lang.IFn_Cast(root_2288) } else { ifn_2290 = nil }; var arg_2291 any = A_arbace_go_check_types_A_const_237.Invoke_O__O(fr__3); if linked_2289 == nil { tmp15 = ifn_2290.Invoke_O__O(arg_2291) } else { tmp15 = linked_2289.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2288, arg_2291) } } else { tmp15 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if jrt.J2g_Truth(tmp15) { var d__4 any; var root_2292 any = A_arbace_go_check_types_A_const_250.GetRawRoot__O(); var linked_2293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2292, A_arbace_go_check_types_method_data_A_fn_class); var ifn_2294 lang.IFn
								if linked_2293 == nil { ifn_2294 = lang.IFn_Cast(root_2292) } else { ifn_2294 = nil }; var arg_2295 any = A_arbace_go_check_types_A_const_58.Invoke_O__O(fr__3); if linked_2293 == nil { d__4 = ifn_2294.Invoke_O__O(arg_2295) } else { d__4 = linked_2293.(*A_arbace_go_check_types_method_data_A).Invoke_O_O__O(root_2292, arg_2295) }
//line :856:1
								var tmp17 any = A_arbace_go_check_types_A_const_227; var tmp18 any = A_arbace_go_check_types_A_const_245; var tmp19 *lang.Keyword

								if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_12.Invoke_O__O(d__4), A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1)) { tmp19 = A_arbace_go_check_types_A_const_251 } else { tmp19 = A_arbace_go_check_types_A_const_252 }
//line :856:1
								return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, m__1, tmp18, tmp19.Ref(), A_arbace_go_check_types_A_const_248, d__4)) } else { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_227, m__1, A_arbace_go_check_types_A_const_245, A_arbace_go_check_types_A_const_246)) } } else {
//line :851:1
									if jrt.J2g_Truth(A_arbace_go_check_types_A_const_237.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_227, m__1, A_arbace_go_check_types_A_const_245, A_arbace_go_check_types_A_const_246)) } else { var tmp20 any = A_arbace_go_check_types_A_const_234; if lang.Util_Equiv_O_O__Z_NoInit(tmp20, A_arbace_go_check_types_A_const_226.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_227, m__1, A_arbace_go_check_types_A_const_245, A_arbace_go_check_types_A_const_234)) } else { if A_arbace_go_check_types_A_const_88 != nil { var d__3 any; var root_2296 any = A_arbace_go_check_types_A_const_250.GetRawRoot__O(); var linked_2297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2296, A_arbace_go_check_types_method_data_A_fn_class); var ifn_2298 lang.IFn











										if linked_2297 == nil { ifn_2298 = lang.IFn_Cast(root_2296) } else { ifn_2298 = nil }; var arg_2299 any = A_arbace_go_check_types_A_const_58.Invoke_O__O(r__2); if linked_2297 == nil { d__3 = ifn_2298.Invoke_O__O(arg_2299) } else { d__3 = linked_2297.(*A_arbace_go_check_types_method_data_A).Invoke_O_O__O(root_2296, arg_2299) }
//line :851:1
										var d__4_2 any; var tmp21 any; var and__1927000168__auto____4_2 any = A_arbace_go_check_types_A_const_253.Get__O()












										if jrt.J2g_Truth(and__1927000168__auto____4_2) { var tmp22 any = A_arbace_go_check_types_A_const_227; tmp21 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp22, A_arbace_go_check_types_A_const_226.Invoke_O__O(r__2))).Ref() } else { tmp21 = and__1927000168__auto____4_2 }; if jrt.J2g_Truth(tmp21) { d__4_2 = lang.IFn_Cast(A_arbace_go_check_types_A_const_253.Get__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_229.Invoke_O__O(r__2), d__3) } else { d__4_2 = d__3
										}
										var tmp23 any; var or__1927000174__auto____5 any; var root_2300 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_2301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2300, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2302 lang.IFn; if linked_2301 == nil { ifn_2302 = lang.IFn_Cast(root_2300) } else { ifn_2302 = nil }; var arg_2303 any = A_arbace_go_check_types_A_const_254.Invoke_O__O(d__4_2); if linked_2301 == nil { or__1927000174__auto____5 = ifn_2302.Invoke_O__O(arg_2303) } else { or__1927000174__auto____5 = linked_2301.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2300, arg_2303) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp23 = or__1927000174__auto____5 } else { var root_2304 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_2305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2304, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2306 lang.IFn; if linked_2305 == nil { ifn_2306 = lang.IFn_Cast(root_2304) } else { ifn_2306 = nil }; var tmp24 lang.IFn = lang.IFn_Cast(t.F_same_QMARK_); var arg_2307 any = tmp24.Invoke_O_O__O(A_arbace_go_check_types_A_const_70.Invoke_O__O(d__4_2), A_arbace_go_check_types_A_const_70.Invoke_O__O(m__1)); if linked_2305 == nil { tmp23 = ifn_2306.Invoke_O__O(arg_2307) } else { tmp23 = linked_2305.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2304, arg_2307) } }; if jrt.J2g_Truth(tmp23) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_227, m__1, A_arbace_go_check_types_A_const_245, A_arbace_go_check_types_A_const_247, A_arbace_go_check_types_A_const_248, d__4_2)) } else { return nil } } else {
//line :851:1
											return nil
										}
									}
									} } } } }
func A_arbace_go_check_types_missing_method_fn__219000289_fn__219000290_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_missing_method_fn__219000289_fn__219000290_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_fn__219000289_fn__219000290_A{}; t.Ctor_O_O(p0, p1); return t }
//line :855:1
func (t *A_arbace_go_check_types_missing_method_fn__219000289_fn__219000290_A) Ctor_O_O(c__m, c__V any) { t.F_m = c__m; t.F_V = c__V }
//line :855:1
func (t *A_arbace_go_check_types_missing_method_fn__219000289_fn__219000290_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2277 any = A_arbace_go_check_types_A_const_243.GetRawRoot__O(); var linked_2278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2277, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_2279 lang.IFn; if linked_2278 == nil { ifn_2279 = lang.IFn_Cast(root_2277) } else { ifn_2279 = nil }; var arg_2280 any; var t_ any = t.F_V; t.F_V = nil; arg_2280 = t_; var arg_2281 any = jrt.Boolean_FALSE.Ref(); var arg_2282 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(t.F_m); var arg_2283 any; var tmp2 *lang.Keyword = A_arbace_go_check_types_A_const_57; var tmp3 any; var t__2 any = t.F_m; t.F_m = nil; tmp3 = t__2; arg_2283 = tmp2.Invoke_O__O(tmp3); if linked_2278 == nil { tmp1 = ifn_2279.Invoke_O_O_O_O__O(arg_2280, arg_2281, arg_2282, arg_2283) } else { tmp1 = linked_2278.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_2277, arg_2280, arg_2281, arg_2282, arg_2283) } }; return nil }(); var root_2284 any = A_arbace_go_check_types_A_const_249.GetRawRoot__O(); var linked_2285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2284, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2286 lang.IFn; if linked_2285 == nil { ifn_2286 = lang.IFn_Cast(root_2284) } else { ifn_2286 = nil }; if linked_2285 == nil { ifn_2286.Invoke__O() } else { linked_2285.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2284) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }
















func A_arbace_go_check_types_satisfies_cause_A_New() *A_arbace_go_check_types_satisfies_cause_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_A{}; t.Ctor(); return t }
//line :872:1
func (t *A_arbace_go_check_types_satisfies_cause_A) Ctor() {}
//line :872:1
func (t *A_arbace_go_check_types_satisfies_cause_A) Invoke_O_O_O__O(self, V__0_, b__1 any) any { var Ti__3_ any; var root_2325 any = A_arbace_go_check_types_A_const_164.GetRawRoot__O(); var linked_2326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2325, A_arbace_go_check_types_bound_iface_A_fn_class); var ifn_2327 lang.IFn; if



	linked_2326 == nil { ifn_2327 = lang.IFn_Cast(root_2325) } else { ifn_2327 = nil }; var arg_2328 any = b__1; if linked_2326 == nil { Ti__3_ = ifn_2327.Invoke_O__O(arg_2328) } else { Ti__3_ = linked_2326.(*A_arbace_go_check_types_bound_iface_A).Invoke_O_O__O(root_2325, arg_2328) }; var Vu__4_ any; var root_2329 any = /*line :872:1*/A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_2330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2329, A_arbace_go_check_types_under_A_fn_class); var ifn_2331 lang.IFn; if




	linked_2330 == nil { ifn_2331 = lang.IFn_Cast(root_2329) } else { ifn_2331 = nil }; var arg_2332 any = V__0_; if linked_2330 == nil { Vu__4_ = ifn_2331.Invoke_O__O(arg_2332) } else { Vu__4_ = linked_2330.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2329, arg_2332) }; var tmp1 any; var or__1927000174__auto____5 bool =
	lang.Util_Identical_O_O__Z_NoInit(Ti__3_, nil); if or__1927000174__auto____5 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_101, Vu__4_); if or__1927000174__auto____6 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var and__1927000168__auto____7 any; var root_2333 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_2334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2333, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2335 lang.IFn
		if linked_2334 == nil { ifn_2335 = lang.IFn_Cast(root_2333) } else { ifn_2335 = nil }; var arg_2336 any = Vu__4_; if linked_2334 == nil { and__1927000168__auto____7 = ifn_2335.Invoke_O__O(arg_2336) } else { and__1927000168__auto____7 = linked_2334.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2333, arg_2336) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp2 any = A_arbace_go_check_types_A_const_71; var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____8 { var tmp3 any = A_arbace_go_check_types_A_const_101; var tmp4 any; var root_2337 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_2338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2337, A_arbace_go_check_types_under_A_fn_class); var ifn_2339 lang.IFn; if linked_2338 == nil { ifn_2339 = lang.IFn_Cast(root_2337) } else { ifn_2339 = nil }; var arg_2340 any = lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(1)); if linked_2338 == nil { tmp4 = ifn_2339.Invoke_O__O(arg_2340) } else { tmp4 = linked_2338.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2337, arg_2340) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp1 = and__1927000168__auto____7 } } }; if /*line :878:1*/ jrt.J2g_Truth(tmp1) { return nil } else { var Tts__5_ any; var root_2341 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_2342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2341, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_2343 lang.IFn


			if linked_2342 == nil { ifn_2343 = lang.IFn_Cast(root_2341) } else { ifn_2343 = nil }; var arg_2344 any = Ti__3_; if linked_2342 == nil { Tts__5_ = ifn_2343.Invoke_O__O(arg_2344) } else { Tts__5_ = linked_2342.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_2341, arg_2344) }
//line :878:1
			var Vi__6_ any; var tmp5 any; var and__1927000168__auto____6 any; var root_2345 any = A_arbace_go_check_types_A_const_86.GetRawRoot__O(); var linked_2346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2345, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2347 lang.IFn



			if linked_2346 == nil { ifn_2347 = lang.IFn_Cast(root_2345) } else { ifn_2347 = nil }; var arg_2348 any = Vu__4_; if linked_2346 == nil { and__1927000168__auto____6 = ifn_2347.Invoke_O__O(arg_2348) } else { and__1927000168__auto____6 = linked_2346.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2345, arg_2348) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp6 any = A_arbace_go_check_types_A_const_67; tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp6, lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp5 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp5) { Vi__6_ = Vu__4_ } else { Vi__6_ = nil }
//line :878:1
			var Vts__7_ any




			if jrt.J2g_Truth(Vi__6_) { var root_2349 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_2350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2349, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_2351 lang.IFn; if linked_2350 == nil { ifn_2351 = lang.IFn_Cast(root_2349) } else { ifn_2351 = nil }; var arg_2352 any = Vi__6_; if linked_2350 == nil { Vts__7_ = ifn_2351.Invoke_O__O(arg_2352) } else { Vts__7_ = linked_2350.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_2349, arg_2352) } } else { Vts__7_ = nil }
//line :878:1
			var T_str__8_ any; var root_2353 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_2354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2353, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2355 lang.IFn





			if linked_2354 == nil { ifn_2355 = lang.IFn_Cast(root_2353) } else { ifn_2355 = nil }; var arg_2356 any = b__1; if linked_2354 == nil { T_str__8_ = ifn_2355.Invoke_O__O(arg_2356) } else { T_str__8_ = linked_2354.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2353, arg_2356) }
			var tmp7 any; var and__1927000168__auto____9 any; var root_2357 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_2358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2357, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2359 lang.IFn
			if linked_2358 == nil { ifn_2359 = lang.IFn_Cast(root_2357) } else { ifn_2359 = nil }; var arg_2360 any = lang.RT_Nth_O_I__O_NoInit(Ti__3_, lang.RT_IntCast_J__I_NoInit(1)); if linked_2358 == nil { and__1927000168__auto____9 = ifn_2359.Invoke_O__O(arg_2360) } else { and__1927000168__auto____9 = linked_2358.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2357, arg_2360) }; if jrt.J2g_Truth(and__1927000168__auto____9) { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(Ti__3_, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref() } else { tmp7 = and__1927000168__auto____9 }
//line :885:1
			if jrt.J2g_Truth(tmp7) { return nil } else { var tmp8 any
				var and__1927000168__auto____9_2 any = Vts__7_
				if jrt.J2g_Truth(and__1927000168__auto____9_2) { var root_2361 any = A_arbace_go_check_types_A_const_258.GetRawRoot__O(); var linked_2362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2361, A_arbace_go_check_types_tset_empty_QMARK__A_fn_class); var ifn_2363 lang.IFn; if linked_2362 == nil { ifn_2363 = lang.IFn_Cast(root_2361) } else { ifn_2363 = nil }; var arg_2364 any = Vts__7_; if linked_2362 == nil { tmp8 = ifn_2363.Invoke_O__O(arg_2364) } else { tmp8 = linked_2362.(*A_arbace_go_check_types_tset_empty_QMARK__A).Invoke_O_O__O(root_2361, arg_2364) } } else { tmp8 = and__1927000168__auto____9_2 }
//line :885:1
				if jrt.J2g_Truth(tmp8) { return nil } else { var tmp9 any; var root_2365 any = A_arbace_go_check_types_A_const_258.GetRawRoot__O(); var linked_2366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2365, A_arbace_go_check_types_tset_empty_QMARK__A_fn_class); var ifn_2367 lang.IFn


					if linked_2366 == nil { ifn_2367 = lang.IFn_Cast(root_2365) } else { ifn_2367 = nil }; var arg_2368 any = Tts__5_; if linked_2366 == nil { tmp9 = ifn_2367.Invoke_O__O(arg_2368) } else { tmp9 = linked_2366.(*A_arbace_go_check_types_tset_empty_QMARK__A).Invoke_O_O__O(root_2365, arg_2368) }
//line :885:1
					if jrt.J2g_Truth(tmp9) {


						return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_36, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, nil, T_str__8_, nil)).Ref() } else {
//line :885:1
							if A_arbace_go_check_types_A_const_88 != nil { var temp__1927000408__auto____9 any; var root_2369 any = A_arbace_go_check_types_A_const_257.GetRawRoot__O(); var linked_2370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2369, A_arbace_go_check_types_missing_method_A_fn_class); var ifn_2371 lang.IFn




								if linked_2370 == nil { ifn_2371 = lang.IFn_Cast(root_2369) } else { ifn_2371 = nil }; var arg_2372 any = V__0_; var arg_2373 any = Ti__3_; var arg_2374 any = jrt.Boolean_TRUE.Ref(); if linked_2370 == nil { temp__1927000408__auto____9 = ifn_2371.Invoke_O_O_O__O(arg_2372, arg_2373, arg_2374) } else { temp__1927000408__auto____9 = linked_2370.(*A_arbace_go_check_types_missing_method_A).Invoke_O_O_O_O__O(root_2369, arg_2372, arg_2373, arg_2374) }; if jrt.J2g_Truth(temp__1927000408__auto____9) { var mm__10 any = temp__1927000408__auto____9; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_38, nil, Lit_39, nil, Lit_32); var tmp11 any; var root_2375 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_2376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2375, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2377 lang.IFn
									if linked_2376 == nil { ifn_2377 = lang.IFn_Cast(root_2375) } else { ifn_2377 = nil }; var arg_2378 any = V__0_; if linked_2376 == nil { tmp11 = ifn_2377.Invoke_O__O(arg_2378) } else { tmp11 = linked_2376.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2375, arg_2378) }; var tmp12 *lang.Keyword = A_arbace_go_check_types_A_const_12; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp11, nil, T_str__8_, nil, tmp12.Invoke_O__O(A_arbace_go_check_types_A_const_227.Invoke_O__O(mm__10)), nil)).Ref() } else {
//line :890:1
										var comparability__10 any; var tmp13 any = A_arbace_go_check_types_satisfies_cause_comparability__219000294_A_New_O_O(Tts__5_, V__0_); var tmp14 *jrt.Class
										var fncls__2405 /*line :890:1*/*jrt.Class = A_arbace_go_check_types_satisfies_cause_comparability__219000294_A_fn_class


										if fncls__2405 == nil { var fncls__2405d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_check_types_satisfies_cause_comparability__219000294_A_fn_class = fncls__2405d; tmp14 = fncls__2405d } else { tmp14 = fncls__2405 }; comparability__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)








										var tmp15 any; var root_2406 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_2407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2406, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2408 lang.IFn
										if linked_2407 == nil { ifn_2408 = lang.IFn_Cast(root_2406) } else { ifn_2408 = nil }; var arg_2409 any; var root_2410 any = A_arbace_go_check_types_A_const_167.GetRawRoot__O(); var linked_2411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2410, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_2412 lang.IFn; if linked_2411 == nil { ifn_2412 = lang.IFn_Cast(root_2410) } else { ifn_2412 = nil }; var arg_2413 any = Tts__5_; if linked_2411 == nil { arg_2409 = ifn_2412.Invoke_O__O(arg_2413) } else { arg_2409 = linked_2411.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_2410, arg_2413) }; if linked_2407 == nil { tmp15 = ifn_2408.Invoke_O__O(arg_2409) } else { tmp15 = linked_2407.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2406, arg_2409) }
//line :902:1
										if jrt.J2g_Truth(tmp15) {
											return lang.IFn_Cast(comparability__10).Invoke__O() } else {
//line :902:1
												if jrt.J2g_Truth(Vts__7_) {

													var tmp16 any; var root_2414 any = A_arbace_go_check_types_A_const_260.GetRawRoot__O(); var linked_2415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2414, A_arbace_go_check_types_terms_subset_QMARK__A_fn_class); var ifn_2416 lang.IFn; if linked_2415 == nil { ifn_2416 = lang.IFn_Cast(root_2414) } else { ifn_2416 = nil }; var arg_2417 any = A_arbace_go_check_types_A_const_127.Invoke_O__O(Vts__7_); var arg_2418 any = A_arbace_go_check_types_A_const_127.Invoke_O__O(Tts__5_); if linked_2415 == nil { tmp16 = ifn_2416.Invoke_O_O__O(arg_2417, arg_2418) } else { tmp16 = linked_2415.(*A_arbace_go_check_types_terms_subset_QMARK__A).Invoke_O_O_O__O(root_2414, arg_2417, arg_2418) }; if jrt.J2g_Truth(tmp16) {
														return lang.IFn_Cast(comparability__10).Invoke__O() } else {
															var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_38, nil); var tmp18 any; var root_2419 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_2420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2419, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2421 lang.IFn; if linked_2420 == nil { ifn_2421 = lang.IFn_Cast(root_2419) } else { ifn_2421 = nil }; var arg_2422 any = V__0_; if linked_2420 == nil { tmp18 = ifn_2421.Invoke_O__O(arg_2422) } else { tmp18 = linked_2420.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2419, arg_2422) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, tmp18, nil, T_str__8_)).Ref() } } else {
//line :902:1
																var tmp19 any; var root_2423 any = A_arbace_go_check_types_A_const_261.GetRawRoot__O(); var linked_2424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2423, A_arbace_go_check_types_terms_includes_QMARK__A_fn_class); var ifn_2425 lang.IFn




																if linked_2424 == nil { ifn_2425 = lang.IFn_Cast(root_2423) } else { ifn_2425 = nil }; var arg_2426 any = A_arbace_go_check_types_A_const_127.Invoke_O__O(Tts__5_); var arg_2427 any = V__0_; if linked_2424 == nil { tmp19 = ifn_2425.Invoke_O_O__O(arg_2426, arg_2427) } else { tmp19 = linked_2424.(*A_arbace_go_check_types_terms_includes_QMARK__A).Invoke_O_O_O__O(root_2423, arg_2426, arg_2427) }
//line :902:1
																if jrt.J2g_Truth(tmp19) {




																	return lang.IFn_Cast(comparability__10).Invoke__O() } else {
//line :902:1
																		if A_arbace_go_check_types_A_const_88 != nil {





																			var tmp20 *jrt.RefArray = jrt.ConstRefArray("[0,8,ns18: does not satisfy ns2: (ns12: missing in ns1:)", []*jrt.Class{jrt.String_class}); var tmp21 any; var root_2428 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_2429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2428, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2430 lang.IFn; if linked_2429 == nil { ifn_2430 = lang.IFn_Cast(root_2428) } else { ifn_2430 = nil }; var arg_2431 any = V__0_; if linked_2429 == nil { tmp21 = ifn_2430.Invoke_O__O(arg_2431) } else { tmp21 = linked_2429.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2428, arg_2431) }; var tmp22 any = tmp21; var tmp23 any; var root_2432 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_2433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2432, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2434 lang.IFn; if linked_2433 == nil { ifn_2434 = lang.IFn_Cast(root_2432) } else { ifn_2434 = nil }; var arg_2435 any = V__0_; if linked_2433 == nil { tmp23 = ifn_2434.Invoke_O__O(arg_2435) } else { tmp23 = linked_2433.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2432, arg_2435) }; var tmp24 any = tmp23; var tmp25 any; var root_2436 any = A_arbace_go_check_types_A_const_197.GetRawRoot__O(); var linked_2437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2436, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_2438 lang.IFn
																			if linked_2437 == nil { ifn_2438 = lang.IFn_Cast(root_2436) } else { ifn_2438 = nil }; var arg_2439 any = A_arbace_go_check_types_A_const_127.Invoke_O__O(Tts__5_); if linked_2437 == nil { tmp25 = ifn_2438.Invoke_O__O(arg_2439) } else { tmp25 = linked_2437.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_2436, arg_2439) }
//line :908:1
																			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, tmp22, nil, T_str__8_, nil, tmp24, nil, tmp25, nil)).Ref() } else {
//line :902:1
																				return nil } } } } } } else {
//line :885:1
																					return nil } } } } } }







func A_arbace_go_check_types_satisfies_cause_comparability__219000294_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_satisfies_cause_comparability__219000294_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_comparability__219000294_A{}; t.Ctor_O_O(p0, p1); return t }
//line :893:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000294_A) Ctor_O_O(c__Tts, c__V any) { t.F_Tts = c__Tts; t.F_V = c__V }
//line :893:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000294_A) Invoke_O__O(self any) any {
	var tmp1 any; var root_2379 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_2380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2379, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2381 lang.IFn
	if linked_2380 == nil { ifn_2381 = lang.IFn_Cast(root_2379) } else { ifn_2381 = nil }; var arg_2382 any; var tmp2 any = A_arbace_go_check_types_A_const_126; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_go_check_types_A_const_127.Invoke_O__O(t.F_Tts)) {
		arg_2382 = A_arbace_go_check_types_A_const_128.Invoke_O__O(t.F_Tts) } else {
			var root_2383 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_2384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2383, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2385 lang.IFn; if linked_2384 == nil { ifn_2385 = lang.IFn_Cast(root_2383) } else { ifn_2385 = nil }; var arg_2386 any; var tmp3 any = A_arbace_go_check_types_satisfies_cause_comparability__219000294_fn__219000296_A_New(); var tmp4 *jrt.Class; var fncls__2392 *jrt.Class = A_arbace_go_check_types_satisfies_cause_comparability__219000294_fn__219000296_A_fn_class; if fncls__2392 == nil { var fncls__2392d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_check_types_satisfies_cause_comparability__219000294_fn__219000296_A_fn_class = fncls__2392d; tmp4 = fncls__2392d } else { tmp4 = fncls__2392 }; arg_2386 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_2387 any = A_arbace_go_check_types_A_const_127.Invoke_O__O(t.F_Tts); if linked_2384 == nil { arg_2382 = ifn_2385.Invoke_O_O__O(arg_2386, arg_2387) } else { arg_2382 = linked_2384.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2383, arg_2386, arg_2387) } }
//line :895:1
	if linked_2380 == nil { tmp1 = ifn_2381.Invoke_O__O(arg_2382) } else { tmp1 = linked_2380.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2379, arg_2382) }
//line :894:1
	if jrt.J2g_Truth(tmp1) { return nil } else { var tmp5 any; var root_2393 any = A_arbace_go_check_types_A_const_130.GetRawRoot__O(); var linked_2394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2393, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_2395 lang.IFn




		if linked_2394 == nil { ifn_2395 = lang.IFn_Cast(root_2393) } else { ifn_2395 = nil }; var arg_2396 any = t.F_V; if linked_2394 == nil { tmp5 = ifn_2395.Invoke_O__O(arg_2396) } else { tmp5 = linked_2394.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O__O(root_2393, arg_2396) }
//line :894:1
		if jrt.J2g_Truth(tmp5) { return nil } else { var tmp6 any; var root_2397 any = A_arbace_go_check_types_A_const_259.GetRawRoot__O(); var linked_2398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2397, A_arbace_go_check_types_comparable_QMARK__A_fn_class); var ifn_2399 lang.IFn





			if linked_2398 == nil { ifn_2399 = lang.IFn_Cast(root_2397) } else { ifn_2399 = nil }; var arg_2400 any = t.F_V; if linked_2398 == nil { tmp6 = ifn_2399.Invoke_O__O(arg_2400) } else { tmp6 = linked_2398.(*A_arbace_go_check_types_comparable_QMARK__A).Invoke_O_O__O(root_2397, arg_2400) }
//line :894:1
			if jrt.J2g_Truth(tmp6) { return nil } else { if A_arbace_go_check_types_A_const_88 != nil {






				var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_42); var tmp8 any; var root_2401 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_2402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2401, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2403 lang.IFn; if linked_2402 == nil { ifn_2403 = lang.IFn_Cast(root_2401) } else { ifn_2403 = nil }; var arg_2404 any = t.F_V; if linked_2402 == nil { tmp8 = ifn_2403.Invoke_O__O(arg_2404) } else { tmp8 = linked_2402.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2401, arg_2404) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8, nil)).Ref() } else {
//line :894:1
					return nil
				}
			} } } }
func A_arbace_go_check_types_satisfies_cause_comparability__219000294_fn__219000296_A_New() *A_arbace_go_check_types_satisfies_cause_comparability__219000294_fn__219000296_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_comparability__219000294_fn__219000296_A{}; t.Ctor(); return t }
//line :897:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000294_fn__219000296_A) Ctor() {}
//line :897:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000294_fn__219000296_A) Invoke_O_O__O(self, p__219000295__1 any) any { var vec__219000297__2 any = p__219000295__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000297__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000297__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2388 any = A_arbace_go_check_types_A_const_130.GetRawRoot__O(); var linked_2389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2388, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_2390 lang.IFn; _ = ___3; if linked_2389 == nil { ifn_2390 = lang.IFn_Cast(root_2388) } else { ifn_2390 = nil }; var arg_2391 any = ty__4; if linked_2389 == nil { return ifn_2390.Invoke_O__O(arg_2391) } else { return linked_2389.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O__O(root_2388, arg_2391) } }



























































type A_arbace_go_check_types_A struct{ jrt.Object }

var A_arbace_go_check_types_A_const_pool *jrt.RefArray

var A_arbace_go_check_types_A_const_0 *lang.Var

var A_arbace_go_check_types_A_const_1 any

var A_arbace_go_check_types_A_const_2 any

var A_arbace_go_check_types_A_const_3 *lang.Var

var A_arbace_go_check_types_A_const_4 any

var A_arbace_go_check_types_A_const_5 *lang.Var

var A_arbace_go_check_types_A_const_6 *lang.Var

var A_arbace_go_check_types_A_const_7 *lang.Var

var A_arbace_go_check_types_A_const_8 *lang.Var

var A_arbace_go_check_types_A_const_9 any

var A_arbace_go_check_types_A_const_10 *lang.Var

var A_arbace_go_check_types_A_const_11 *lang.Keyword

var A_arbace_go_check_types_A_const_12 *lang.Keyword

var A_arbace_go_check_types_A_const_13 *lang.Var

var A_arbace_go_check_types_A_const_14 *lang.Keyword

var A_arbace_go_check_types_A_const_15 any

var A_arbace_go_check_types_A_const_16 *lang.Keyword

var A_arbace_go_check_types_A_const_17 *lang.Keyword

var A_arbace_go_check_types_A_const_18 *lang.Keyword

var A_arbace_go_check_types_A_const_19 *lang.Keyword

var A_arbace_go_check_types_A_const_20 any

var A_arbace_go_check_types_A_const_21 *lang.Keyword

var A_arbace_go_check_types_A_const_22 any

var A_arbace_go_check_types_A_const_23 *lang.Keyword

var A_arbace_go_check_types_A_const_24 any

var A_arbace_go_check_types_A_const_25 *lang.Keyword

var A_arbace_go_check_types_A_const_26 *lang.Keyword

var A_arbace_go_check_types_A_const_27 *lang.Keyword

var A_arbace_go_check_types_A_const_28 *lang.Keyword

var A_arbace_go_check_types_A_const_29 *lang.Keyword

var A_arbace_go_check_types_A_const_30 *lang.Keyword

var A_arbace_go_check_types_A_const_31 *lang.Keyword

var A_arbace_go_check_types_A_const_32 *lang.Keyword

var A_arbace_go_check_types_A_const_33 *lang.Keyword

var A_arbace_go_check_types_A_const_34 *lang.Keyword

var A_arbace_go_check_types_A_const_35 *lang.Keyword

var A_arbace_go_check_types_A_const_36 *lang.Keyword

var A_arbace_go_check_types_A_const_37 *lang.Keyword

var A_arbace_go_check_types_A_const_38 *lang.Keyword

var A_arbace_go_check_types_A_const_39 any

var A_arbace_go_check_types_A_const_40 *lang.Keyword

var A_arbace_go_check_types_A_const_41 *lang.Keyword

var A_arbace_go_check_types_A_const_42 *lang.Keyword

var A_arbace_go_check_types_A_const_43 *lang.Keyword

var A_arbace_go_check_types_A_const_44 any

var A_arbace_go_check_types_A_const_45 *lang.Keyword

var A_arbace_go_check_types_A_const_46 *lang.Keyword

var A_arbace_go_check_types_A_const_47 *lang.Keyword

var A_arbace_go_check_types_A_const_48 *lang.Keyword

var A_arbace_go_check_types_A_const_49 *lang.Keyword

var A_arbace_go_check_types_A_const_50 *lang.Keyword

var A_arbace_go_check_types_A_const_51 *lang.Keyword

var A_arbace_go_check_types_A_const_52 *lang.Keyword

var A_arbace_go_check_types_A_const_53 *lang.Keyword

var A_arbace_go_check_types_A_const_54 *lang.Var

var A_arbace_go_check_types_A_const_55 *lang.Var

var A_arbace_go_check_types_A_const_56 *lang.Keyword

var A_arbace_go_check_types_A_const_57 *lang.Keyword

var A_arbace_go_check_types_A_const_58 *lang.Keyword

var A_arbace_go_check_types_A_const_59 *lang.Var

var A_arbace_go_check_types_A_const_60 *lang.Var

var A_arbace_go_check_types_A_const_61 *lang.Var

var A_arbace_go_check_types_A_const_62 *lang.Keyword

var A_arbace_go_check_types_A_const_63 *lang.Var

var A_arbace_go_check_types_A_const_64 any

var A_arbace_go_check_types_A_const_65 *lang.Var

var A_arbace_go_check_types_A_const_66 *lang.Var

var A_arbace_go_check_types_A_const_67 *lang.Keyword

var A_arbace_go_check_types_A_const_68 *lang.Var

var A_arbace_go_check_types_A_const_69 *lang.Var

var A_arbace_go_check_types_A_const_70 *lang.Keyword

var A_arbace_go_check_types_A_const_71 *lang.Keyword

var A_arbace_go_check_types_A_const_72 *lang.Keyword

var A_arbace_go_check_types_A_const_73 *lang.Keyword

var A_arbace_go_check_types_A_const_74 *lang.Keyword

var A_arbace_go_check_types_A_const_75 *lang.Keyword

var A_arbace_go_check_types_A_const_76 *lang.Keyword

var A_arbace_go_check_types_A_const_77 *lang.Keyword

var A_arbace_go_check_types_A_const_78 *lang.Keyword

var A_arbace_go_check_types_A_const_79 *lang.Var

var A_arbace_go_check_types_A_const_80 *lang.Var

var A_arbace_go_check_types_A_const_81 *lang.Var

var A_arbace_go_check_types_A_const_82 *lang.Keyword

var A_arbace_go_check_types_A_const_83 *lang.Var

var A_arbace_go_check_types_A_const_84 *lang.Var

var A_arbace_go_check_types_A_const_85 *lang.Var

var A_arbace_go_check_types_A_const_86 *lang.Var

var A_arbace_go_check_types_A_const_87 *lang.Var

var A_arbace_go_check_types_A_const_88 *lang.Keyword

var A_arbace_go_check_types_A_const_89 *lang.Var

var A_arbace_go_check_types_A_const_90 *lang.Var

var A_arbace_go_check_types_A_const_91 *lang.Var

var A_arbace_go_check_types_A_const_92 *lang.Var

var A_arbace_go_check_types_A_const_93 *lang.Var

var A_arbace_go_check_types_A_const_94 *lang.Keyword

var A_arbace_go_check_types_A_const_95 *lang.Var

var A_arbace_go_check_types_A_const_96 *lang.Keyword

var A_arbace_go_check_types_A_const_97 *lang.Var

var A_arbace_go_check_types_A_const_98 *lang.Keyword

var A_arbace_go_check_types_A_const_99 *lang.Var

var A_arbace_go_check_types_A_const_100 *lang.Var

var A_arbace_go_check_types_A_const_101 *lang.Keyword

var A_arbace_go_check_types_A_const_102 *lang.Var

var A_arbace_go_check_types_A_const_103 *lang.Keyword

var A_arbace_go_check_types_A_const_104 *lang.Var

var A_arbace_go_check_types_A_const_105 *lang.Var

var A_arbace_go_check_types_A_const_106 *lang.Var

var A_arbace_go_check_types_A_const_107 *lang.Var

var A_arbace_go_check_types_A_const_108 *lang.Var

var A_arbace_go_check_types_A_const_109 *lang.Var

var A_arbace_go_check_types_A_const_110 *lang.Var

var A_arbace_go_check_types_A_const_111 *lang.Var

var A_arbace_go_check_types_A_const_112 *lang.Var

var A_arbace_go_check_types_A_const_113 *lang.Var

var A_arbace_go_check_types_A_const_114 any

var A_arbace_go_check_types_A_const_115 *lang.Var

var A_arbace_go_check_types_A_const_116 *lang.Var

var A_arbace_go_check_types_A_const_117 *lang.Var

var A_arbace_go_check_types_A_const_118 *lang.Var

var A_arbace_go_check_types_A_const_119 *lang.Var

var A_arbace_go_check_types_A_const_120 *lang.Var

var A_arbace_go_check_types_A_const_121 any

var A_arbace_go_check_types_A_const_122 *lang.Var

var A_arbace_go_check_types_A_const_123 *lang.Var

var A_arbace_go_check_types_A_const_124 any

var A_arbace_go_check_types_A_const_125 *lang.Keyword

var A_arbace_go_check_types_A_const_126 *lang.Keyword

var A_arbace_go_check_types_A_const_127 *lang.Keyword

var A_arbace_go_check_types_A_const_128 *lang.Keyword

var A_arbace_go_check_types_A_const_129 *lang.Var

var A_arbace_go_check_types_A_const_130 *lang.Var

var A_arbace_go_check_types_A_const_131 *lang.Var

var A_arbace_go_check_types_A_const_132 *lang.Var

var A_arbace_go_check_types_A_const_133 *lang.Var

var A_arbace_go_check_types_A_const_134 *lang.Var

var A_arbace_go_check_types_A_const_135 *lang.Var

var A_arbace_go_check_types_A_const_136 *lang.Var

var A_arbace_go_check_types_A_const_137 *lang.Keyword

var A_arbace_go_check_types_A_const_138 *lang.Var

var A_arbace_go_check_types_A_const_139 *lang.Var

var A_arbace_go_check_types_A_const_140 *lang.Var

var A_arbace_go_check_types_A_const_141 *lang.Var

var A_arbace_go_check_types_A_const_142 *lang.Var

var A_arbace_go_check_types_A_const_143 *lang.Keyword

var A_arbace_go_check_types_A_const_144 *lang.Var

var A_arbace_go_check_types_A_const_145 *lang.Var

var A_arbace_go_check_types_A_const_146 *lang.Var

var A_arbace_go_check_types_A_const_147 *lang.Var

var A_arbace_go_check_types_A_const_148 *lang.Var

var A_arbace_go_check_types_A_const_149 *lang.Var

var A_arbace_go_check_types_A_const_150 *lang.Var

var A_arbace_go_check_types_A_const_151 *lang.Var

var A_arbace_go_check_types_A_const_152 *lang.Var

var A_arbace_go_check_types_A_const_153 *lang.Var

var A_arbace_go_check_types_A_const_154 *lang.Var

var A_arbace_go_check_types_A_const_155 *lang.Var

var A_arbace_go_check_types_A_const_156 *lang.Var

var A_arbace_go_check_types_A_const_157 *lang.Var

var A_arbace_go_check_types_A_const_158 *lang.Var

var A_arbace_go_check_types_A_const_159 *lang.Var

var A_arbace_go_check_types_A_const_160 *lang.Var

var A_arbace_go_check_types_A_const_161 *lang.Var

var A_arbace_go_check_types_A_const_162 *lang.Var

var A_arbace_go_check_types_A_const_163 *lang.Keyword

var A_arbace_go_check_types_A_const_164 *lang.Var

var A_arbace_go_check_types_A_const_165 *lang.Keyword

var A_arbace_go_check_types_A_const_166 *lang.Var

var A_arbace_go_check_types_A_const_167 *lang.Var

var A_arbace_go_check_types_A_const_168 any

var A_arbace_go_check_types_A_const_169 *lang.Var

var A_arbace_go_check_types_A_const_170 *lang.Var

var A_arbace_go_check_types_A_const_171 *lang.Var

var A_arbace_go_check_types_A_const_172 *lang.Var

var A_arbace_go_check_types_A_const_173 *lang.Var

var A_arbace_go_check_types_A_const_174 *lang.Var

var A_arbace_go_check_types_A_const_175 *lang.Var

var A_arbace_go_check_types_A_const_176 any

var A_arbace_go_check_types_A_const_177 *lang.Keyword

var A_arbace_go_check_types_A_const_178 any

var A_arbace_go_check_types_A_const_179 any

var A_arbace_go_check_types_A_const_180 *lang.Var

var A_arbace_go_check_types_A_const_181 *lang.Var

var A_arbace_go_check_types_A_const_182 *lang.Var

var A_arbace_go_check_types_A_const_183 *lang.Var

var A_arbace_go_check_types_A_const_184 *lang.Var

var A_arbace_go_check_types_A_const_185 *lang.Var

var A_arbace_go_check_types_A_const_186 *lang.Keyword

var A_arbace_go_check_types_A_const_187 *lang.Var

var A_arbace_go_check_types_A_const_188 *lang.Var

var A_arbace_go_check_types_A_const_189 *lang.Keyword

var A_arbace_go_check_types_A_const_190 *lang.Keyword

var A_arbace_go_check_types_A_const_191 *lang.Keyword

var A_arbace_go_check_types_A_const_192 *lang.Var

var A_arbace_go_check_types_A_const_193 *lang.Var

var A_arbace_go_check_types_A_const_194 *lang.Var

var A_arbace_go_check_types_A_const_195 any

var A_arbace_go_check_types_A_const_196 *lang.Var

var A_arbace_go_check_types_A_const_197 *lang.Var

var A_arbace_go_check_types_A_const_198 *lang.Keyword

var A_arbace_go_check_types_A_const_199 *lang.Keyword

var A_arbace_go_check_types_A_const_200 *lang.Var

var A_arbace_go_check_types_A_const_201 any

var A_arbace_go_check_types_A_const_202 *lang.Var

var A_arbace_go_check_types_A_const_203 *lang.Var

var A_arbace_go_check_types_A_const_204 *lang.Var

var A_arbace_go_check_types_A_const_205 any

var A_arbace_go_check_types_A_const_206 *lang.Var

var A_arbace_go_check_types_A_const_207 *lang.Var

var A_arbace_go_check_types_A_const_208 *lang.Var

var A_arbace_go_check_types_A_const_209 *lang.Var

var A_arbace_go_check_types_A_const_210 any

var A_arbace_go_check_types_A_const_211 *lang.Var

var A_arbace_go_check_types_A_const_212 *lang.Var

var A_arbace_go_check_types_A_const_213 *lang.Keyword

var A_arbace_go_check_types_A_const_214 *lang.Var

var A_arbace_go_check_types_A_const_215 *lang.Var

var A_arbace_go_check_types_A_const_216 *lang.Var

var A_arbace_go_check_types_A_const_217 *lang.Var

var A_arbace_go_check_types_A_const_218 *lang.Var

var A_arbace_go_check_types_A_const_219 *lang.Var

var A_arbace_go_check_types_A_const_220 *lang.Keyword

var A_arbace_go_check_types_A_const_221 *lang.Var

var A_arbace_go_check_types_A_const_222 *lang.Var

var A_arbace_go_check_types_A_const_223 *lang.Var

var A_arbace_go_check_types_A_const_224 *lang.Var

var A_arbace_go_check_types_A_const_225 any

var A_arbace_go_check_types_A_const_226 *lang.Keyword

var A_arbace_go_check_types_A_const_227 *lang.Keyword

var A_arbace_go_check_types_A_const_228 *lang.Var

var A_arbace_go_check_types_A_const_229 *lang.Keyword

var A_arbace_go_check_types_A_const_230 *lang.Keyword

var A_arbace_go_check_types_A_const_231 *lang.Keyword

var A_arbace_go_check_types_A_const_232 *lang.Keyword

var A_arbace_go_check_types_A_const_233 any

var A_arbace_go_check_types_A_const_234 *lang.Keyword

var A_arbace_go_check_types_A_const_235 any

var A_arbace_go_check_types_A_const_236 *lang.Keyword

var A_arbace_go_check_types_A_const_237 *lang.Keyword

var A_arbace_go_check_types_A_const_238 *lang.Keyword

var A_arbace_go_check_types_A_const_239 *lang.Var

var A_arbace_go_check_types_A_const_240 *lang.Keyword

var A_arbace_go_check_types_A_const_241 *lang.Var

var A_arbace_go_check_types_A_const_242 *lang.Var

var A_arbace_go_check_types_A_const_243 *lang.Var

var A_arbace_go_check_types_A_const_244 *lang.Keyword

var A_arbace_go_check_types_A_const_245 *lang.Keyword

var A_arbace_go_check_types_A_const_246 *lang.Keyword

var A_arbace_go_check_types_A_const_247 *lang.Keyword

var A_arbace_go_check_types_A_const_248 *lang.Keyword

var A_arbace_go_check_types_A_const_249 *lang.Var

var A_arbace_go_check_types_A_const_250 *lang.Var

var A_arbace_go_check_types_A_const_251 *lang.Keyword

var A_arbace_go_check_types_A_const_252 *lang.Keyword

var A_arbace_go_check_types_A_const_253 *lang.Var

var A_arbace_go_check_types_A_const_254 *lang.Keyword

var A_arbace_go_check_types_A_const_255 *lang.Var

var A_arbace_go_check_types_A_const_256 *lang.Var

var A_arbace_go_check_types_A_const_257 *lang.Var

var A_arbace_go_check_types_A_const_258 *lang.Var

var A_arbace_go_check_types_A_const_259 *lang.Var

var A_arbace_go_check_types_A_const_260 *lang.Var

var A_arbace_go_check_types_A_const_261 *lang.Var

var A_arbace_go_check_types_A_init jrt.ClassInit

func A_arbace_go_check_types_A_Init() { if !A_arbace_go_check_types_A_init.Done() { A_arbace_go_check_types_A_init.Run(A_arbace_go_check_types_A_clinit) } }

func A_arbace_go_check_types_A_clinit() { A_arbace_go_check_types_A_clinit_p0(); A_arbace_go_check_types_A_clinit_p1(); A_arbace_go_check_types_A_clinit_p2(); A_arbace_go_check_types_A_clinit_p3(); A_arbace_go_check_types_A_clinit_p4(); A_arbace_go_check_types_A_clinit_p5(); A_arbace_go_check_types_A_clinit_p6(); A_arbace_go_check_types_A_clinit_p7(); A_arbace_go_check_types_A_clinit_p8(); A_arbace_go_check_types_A_clinit_p9(); A_arbace_go_check_types_A_clinit_p10(); A_arbace_go_check_types_A_clinit_p11(); A_arbace_go_check_types_A_clinit_p12(); A_arbace_go_check_types_A_clinit_p13(); A_arbace_go_check_types_A_clinit_p14(); A_arbace_go_check_types_A_clinit_p15(); A_arbace_go_check_types_A_clinit_p16(); A_arbace_go_check_types_A_clinit_p17(); A_arbace_go_check_types_A_clinit_p18(); A_arbace_go_check_types_A_clinit_p19(); A_arbace_go_check_types_A_clinit_p20(); A_arbace_go_check_types_A_clinit_p21() }

func A_arbace_go_check_types_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_types_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 362); A_arbace_go_check_types_A_const_0 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[100]); A_arbace_go_check_types_A_const_1 = A_arbace_go_check_types_A_const_pool.A[101]; A_arbace_go_check_types_A_const_2 = A_arbace_go_check_types_A_const_pool.A[102]; A_arbace_go_check_types_A_const_3 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[103]); A_arbace_go_check_types_A_const_4 = A_arbace_go_check_types_A_const_pool.A[104]; A_arbace_go_check_types_A_const_5 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[105]); A_arbace_go_check_types_A_const_6 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[106]); A_arbace_go_check_types_A_const_7 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[107]); A_arbace_go_check_types_A_const_8 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[108]); A_arbace_go_check_types_A_const_9 = A_arbace_go_check_types_A_const_pool.A[109]; A_arbace_go_check_types_A_const_10 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[110]); A_arbace_go_check_types_A_const_11 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[111]) }

func A_arbace_go_check_types_A_clinit_p1() { A_arbace_go_check_types_A_const_12 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[112]); A_arbace_go_check_types_A_const_13 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[113]); A_arbace_go_check_types_A_const_14 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[114]); A_arbace_go_check_types_A_const_15 = A_arbace_go_check_types_A_const_pool.A[115]; A_arbace_go_check_types_A_const_16 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[116]); A_arbace_go_check_types_A_const_17 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[117]); A_arbace_go_check_types_A_const_18 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[118]); A_arbace_go_check_types_A_const_19 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[119]); A_arbace_go_check_types_A_const_20 = A_arbace_go_check_types_A_const_pool.A[120]; A_arbace_go_check_types_A_const_21 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[121]); A_arbace_go_check_types_A_const_22 = A_arbace_go_check_types_A_const_pool.A[122]; A_arbace_go_check_types_A_const_23 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[123]); A_arbace_go_check_types_A_const_24 = A_arbace_go_check_types_A_const_pool.A[124] }

func A_arbace_go_check_types_A_clinit_p2() { A_arbace_go_check_types_A_const_25 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[125]); A_arbace_go_check_types_A_const_26 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[126]); A_arbace_go_check_types_A_const_27 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[127]); A_arbace_go_check_types_A_const_28 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[128]); A_arbace_go_check_types_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[129]); A_arbace_go_check_types_A_const_30 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[130]); A_arbace_go_check_types_A_const_31 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[131]); A_arbace_go_check_types_A_const_32 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[132]); A_arbace_go_check_types_A_const_33 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[133]); A_arbace_go_check_types_A_const_34 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[134]); A_arbace_go_check_types_A_const_35 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[135]); A_arbace_go_check_types_A_const_36 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[136]) }

func A_arbace_go_check_types_A_clinit_p3() { A_arbace_go_check_types_A_const_37 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[137]); A_arbace_go_check_types_A_const_38 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[138]); A_arbace_go_check_types_A_const_39 = A_arbace_go_check_types_A_const_pool.A[139]; A_arbace_go_check_types_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[140]); A_arbace_go_check_types_A_const_41 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[141]); A_arbace_go_check_types_A_const_42 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[142]); A_arbace_go_check_types_A_const_43 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[143]); A_arbace_go_check_types_A_const_44 = A_arbace_go_check_types_A_const_pool.A[144]; A_arbace_go_check_types_A_const_45 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[145]); A_arbace_go_check_types_A_const_46 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[146]); A_arbace_go_check_types_A_const_47 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[147]); A_arbace_go_check_types_A_const_48 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[148]) }

func A_arbace_go_check_types_A_clinit_p4() { A_arbace_go_check_types_A_const_49 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[149]); A_arbace_go_check_types_A_const_50 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[150]); A_arbace_go_check_types_A_const_51 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[151]); A_arbace_go_check_types_A_const_52 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[152]); A_arbace_go_check_types_A_const_53 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[153]); A_arbace_go_check_types_A_const_54 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[154]); A_arbace_go_check_types_A_const_55 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[155]); A_arbace_go_check_types_A_const_56 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[156]); A_arbace_go_check_types_A_const_57 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[157]); A_arbace_go_check_types_A_const_58 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[158]); A_arbace_go_check_types_A_const_59 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[159]); A_arbace_go_check_types_A_const_60 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[160]) }

func A_arbace_go_check_types_A_clinit_p5() { A_arbace_go_check_types_A_const_61 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[161]); A_arbace_go_check_types_A_const_62 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[162]); A_arbace_go_check_types_A_const_63 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[163]); A_arbace_go_check_types_A_const_64 = A_arbace_go_check_types_A_const_pool.A[164]; A_arbace_go_check_types_A_const_65 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[165]); A_arbace_go_check_types_A_const_66 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[166]); A_arbace_go_check_types_A_const_67 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[167]); A_arbace_go_check_types_A_const_68 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[168]); A_arbace_go_check_types_A_const_69 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[169]); A_arbace_go_check_types_A_const_70 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[170]); A_arbace_go_check_types_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[171]); A_arbace_go_check_types_A_const_72 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[172]) }

func A_arbace_go_check_types_A_clinit_p6() { A_arbace_go_check_types_A_const_73 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[173]); A_arbace_go_check_types_A_const_74 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[174]); A_arbace_go_check_types_A_const_75 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[175]); A_arbace_go_check_types_A_const_76 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[176]); A_arbace_go_check_types_A_const_77 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[177]); A_arbace_go_check_types_A_const_78 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[178]); A_arbace_go_check_types_A_const_79 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[179]); A_arbace_go_check_types_A_const_80 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[180]); A_arbace_go_check_types_A_const_81 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[181]); A_arbace_go_check_types_A_const_82 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[182]); A_arbace_go_check_types_A_const_83 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[183]); A_arbace_go_check_types_A_const_84 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[184]) }

func A_arbace_go_check_types_A_clinit_p7() { A_arbace_go_check_types_A_const_85 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[185]); A_arbace_go_check_types_A_const_86 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[186]); A_arbace_go_check_types_A_const_87 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[187]); A_arbace_go_check_types_A_const_88 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[188]); A_arbace_go_check_types_A_const_89 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[189]); A_arbace_go_check_types_A_const_90 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[190]); A_arbace_go_check_types_A_const_91 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[191]); A_arbace_go_check_types_A_const_92 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[192]); A_arbace_go_check_types_A_const_93 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[193]); A_arbace_go_check_types_A_const_94 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[194]); A_arbace_go_check_types_A_const_95 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[195]); A_arbace_go_check_types_A_const_96 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[196]) }

func A_arbace_go_check_types_A_clinit_p8() { A_arbace_go_check_types_A_const_97 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[197]); A_arbace_go_check_types_A_const_98 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[198]); A_arbace_go_check_types_A_const_99 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[199]); A_arbace_go_check_types_A_const_100 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[200]); A_arbace_go_check_types_A_const_101 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[201]); A_arbace_go_check_types_A_const_102 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[202]); A_arbace_go_check_types_A_const_103 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[203]); A_arbace_go_check_types_A_const_104 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[204]); A_arbace_go_check_types_A_const_105 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[205]); A_arbace_go_check_types_A_const_106 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[206]); A_arbace_go_check_types_A_const_107 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[207]); A_arbace_go_check_types_A_const_108 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[208]) }

func A_arbace_go_check_types_A_clinit_p9() { A_arbace_go_check_types_A_const_109 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[209]); A_arbace_go_check_types_A_const_110 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[210]); A_arbace_go_check_types_A_const_111 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[211]); A_arbace_go_check_types_A_const_112 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[212]); A_arbace_go_check_types_A_const_113 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[213]); A_arbace_go_check_types_A_const_114 = A_arbace_go_check_types_A_const_pool.A[214]; A_arbace_go_check_types_A_const_115 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[215]); A_arbace_go_check_types_A_const_116 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[216]); A_arbace_go_check_types_A_const_117 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[217]); A_arbace_go_check_types_A_const_118 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[218]); A_arbace_go_check_types_A_const_119 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[219]); A_arbace_go_check_types_A_const_120 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[220]) }

func A_arbace_go_check_types_A_clinit_p10() { A_arbace_go_check_types_A_const_121 = A_arbace_go_check_types_A_const_pool.A[221]; A_arbace_go_check_types_A_const_122 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[222]); A_arbace_go_check_types_A_const_123 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[223]); A_arbace_go_check_types_A_const_124 = A_arbace_go_check_types_A_const_pool.A[224]; A_arbace_go_check_types_A_const_125 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[225]); A_arbace_go_check_types_A_const_126 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[226]); A_arbace_go_check_types_A_const_127 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[227]); A_arbace_go_check_types_A_const_128 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[228]); A_arbace_go_check_types_A_const_129 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[229]); A_arbace_go_check_types_A_const_130 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[230]); A_arbace_go_check_types_A_const_131 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[231]); A_arbace_go_check_types_A_const_132 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[232]) }

func A_arbace_go_check_types_A_clinit_p11() { A_arbace_go_check_types_A_const_133 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[233]); A_arbace_go_check_types_A_const_134 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[234]); A_arbace_go_check_types_A_const_135 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[235]); A_arbace_go_check_types_A_const_136 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[236]); A_arbace_go_check_types_A_const_137 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[237]); A_arbace_go_check_types_A_const_138 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[238]); A_arbace_go_check_types_A_const_139 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[239]); A_arbace_go_check_types_A_const_140 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[240]); A_arbace_go_check_types_A_const_141 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[241]); A_arbace_go_check_types_A_const_142 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[242]); A_arbace_go_check_types_A_const_143 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[243]); A_arbace_go_check_types_A_const_144 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[244]) }

func A_arbace_go_check_types_A_clinit_p12() { A_arbace_go_check_types_A_const_145 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[245]); A_arbace_go_check_types_A_const_146 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[246]); A_arbace_go_check_types_A_const_147 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[247]); A_arbace_go_check_types_A_const_148 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[248]); A_arbace_go_check_types_A_const_149 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[249]); A_arbace_go_check_types_A_const_150 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[250]); A_arbace_go_check_types_A_const_151 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[251]); A_arbace_go_check_types_A_const_152 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[252]); A_arbace_go_check_types_A_const_153 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[253]); A_arbace_go_check_types_A_const_154 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[254]); A_arbace_go_check_types_A_const_155 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[255]); A_arbace_go_check_types_A_const_156 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[256]) }

func A_arbace_go_check_types_A_clinit_p13() { A_arbace_go_check_types_A_const_157 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[257]); A_arbace_go_check_types_A_const_158 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[258]); A_arbace_go_check_types_A_const_159 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[259]); A_arbace_go_check_types_A_const_160 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[260]); A_arbace_go_check_types_A_const_161 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[261]); A_arbace_go_check_types_A_const_162 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[262]); A_arbace_go_check_types_A_const_163 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[263]); A_arbace_go_check_types_A_const_164 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[264]); A_arbace_go_check_types_A_const_165 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[265]); A_arbace_go_check_types_A_const_166 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[266]); A_arbace_go_check_types_A_const_167 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[267]); A_arbace_go_check_types_A_const_168 = A_arbace_go_check_types_A_const_pool.A[268] }

func A_arbace_go_check_types_A_clinit_p14() { A_arbace_go_check_types_A_const_169 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[269]); A_arbace_go_check_types_A_const_170 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[270]); A_arbace_go_check_types_A_const_171 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[271]); A_arbace_go_check_types_A_const_172 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[272]); A_arbace_go_check_types_A_const_173 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[273]); A_arbace_go_check_types_A_const_174 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[274]); A_arbace_go_check_types_A_const_175 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[275]); A_arbace_go_check_types_A_const_176 = A_arbace_go_check_types_A_const_pool.A[276]; A_arbace_go_check_types_A_const_177 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[277]); A_arbace_go_check_types_A_const_178 = A_arbace_go_check_types_A_const_pool.A[278]; A_arbace_go_check_types_A_const_179 = A_arbace_go_check_types_A_const_pool.A[279]; A_arbace_go_check_types_A_const_180 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[280]) }

func A_arbace_go_check_types_A_clinit_p15() { A_arbace_go_check_types_A_const_181 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[281]); A_arbace_go_check_types_A_const_182 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[282]); A_arbace_go_check_types_A_const_183 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[283]); A_arbace_go_check_types_A_const_184 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[284]); A_arbace_go_check_types_A_const_185 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[285]); A_arbace_go_check_types_A_const_186 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[286]); A_arbace_go_check_types_A_const_187 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[287]); A_arbace_go_check_types_A_const_188 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[288]); A_arbace_go_check_types_A_const_189 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[289]); A_arbace_go_check_types_A_const_190 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[290]); A_arbace_go_check_types_A_const_191 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[291]); A_arbace_go_check_types_A_const_192 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[292]) }

func A_arbace_go_check_types_A_clinit_p16() { A_arbace_go_check_types_A_const_193 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[293]); A_arbace_go_check_types_A_const_194 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[294]); A_arbace_go_check_types_A_const_195 = A_arbace_go_check_types_A_const_pool.A[295]; A_arbace_go_check_types_A_const_196 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[296]); A_arbace_go_check_types_A_const_197 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[297]); A_arbace_go_check_types_A_const_198 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[298]); A_arbace_go_check_types_A_const_199 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[299]); A_arbace_go_check_types_A_const_200 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[300]); A_arbace_go_check_types_A_const_201 = A_arbace_go_check_types_A_const_pool.A[301]; A_arbace_go_check_types_A_const_202 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[302]); A_arbace_go_check_types_A_const_203 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[303]); A_arbace_go_check_types_A_const_204 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[304]) }

func A_arbace_go_check_types_A_clinit_p17() { A_arbace_go_check_types_A_const_205 = A_arbace_go_check_types_A_const_pool.A[305]; A_arbace_go_check_types_A_const_206 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[306]); A_arbace_go_check_types_A_const_207 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[307]); A_arbace_go_check_types_A_const_208 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[308]); A_arbace_go_check_types_A_const_209 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[309]); A_arbace_go_check_types_A_const_210 = A_arbace_go_check_types_A_const_pool.A[310]; A_arbace_go_check_types_A_const_211 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[311]); A_arbace_go_check_types_A_const_212 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[312]); A_arbace_go_check_types_A_const_213 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[313]); A_arbace_go_check_types_A_const_214 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[314]); A_arbace_go_check_types_A_const_215 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[315]); A_arbace_go_check_types_A_const_216 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[316]) }

func A_arbace_go_check_types_A_clinit_p18() { A_arbace_go_check_types_A_const_217 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[317]); A_arbace_go_check_types_A_const_218 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[318]); A_arbace_go_check_types_A_const_219 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[319]); A_arbace_go_check_types_A_const_220 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[320]); A_arbace_go_check_types_A_const_221 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[321]); A_arbace_go_check_types_A_const_222 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[322]); A_arbace_go_check_types_A_const_223 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[323]); A_arbace_go_check_types_A_const_224 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[324]); A_arbace_go_check_types_A_const_225 = A_arbace_go_check_types_A_const_pool.A[325]; A_arbace_go_check_types_A_const_226 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[326]); A_arbace_go_check_types_A_const_227 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[327]); A_arbace_go_check_types_A_const_228 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[328]) }

func A_arbace_go_check_types_A_clinit_p19() { A_arbace_go_check_types_A_const_229 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[329]); A_arbace_go_check_types_A_const_230 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[330]); A_arbace_go_check_types_A_const_231 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[331]); A_arbace_go_check_types_A_const_232 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[332]); A_arbace_go_check_types_A_const_233 = A_arbace_go_check_types_A_const_pool.A[333]; A_arbace_go_check_types_A_const_234 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[334]); A_arbace_go_check_types_A_const_235 = A_arbace_go_check_types_A_const_pool.A[335]; A_arbace_go_check_types_A_const_236 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[336]); A_arbace_go_check_types_A_const_237 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[337]); A_arbace_go_check_types_A_const_238 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[338]); A_arbace_go_check_types_A_const_239 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[339]); A_arbace_go_check_types_A_const_240 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[340]) }

func A_arbace_go_check_types_A_clinit_p20() { A_arbace_go_check_types_A_const_241 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[341]); A_arbace_go_check_types_A_const_242 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[342]); A_arbace_go_check_types_A_const_243 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[343]); A_arbace_go_check_types_A_const_244 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[344]); A_arbace_go_check_types_A_const_245 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[345]); A_arbace_go_check_types_A_const_246 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[346]); A_arbace_go_check_types_A_const_247 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[347]); A_arbace_go_check_types_A_const_248 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[348]); A_arbace_go_check_types_A_const_249 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[349]); A_arbace_go_check_types_A_const_250 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[350]); A_arbace_go_check_types_A_const_251 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[351]); A_arbace_go_check_types_A_const_252 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[352]) }

func A_arbace_go_check_types_A_clinit_p21() { A_arbace_go_check_types_A_const_253 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[353]); A_arbace_go_check_types_A_const_254 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[354]); A_arbace_go_check_types_A_const_255 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[355]); A_arbace_go_check_types_A_const_256 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[356]); A_arbace_go_check_types_A_const_257 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[357]); A_arbace_go_check_types_A_const_258 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[358]); A_arbace_go_check_types_A_const_259 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[359]); A_arbace_go_check_types_A_const_260 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[360]); A_arbace_go_check_types_A_const_261 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[361]) }

func A_arbace_go_check_types_A_New() *A_arbace_go_check_types_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_A) Ctor() {}

func (t *A_arbace_go_check_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_A_class }

func (t *A_arbace_go_check_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_A); return ok }

func A_arbace_go_check_types_A_Cast(x any) *A_arbace_go_check_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_A_class)) }; return v }



type A_arbace_go_check_types_align_up_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_align_up_A_fn_class *jrt.Class



type A_arbace_go_check_types_alignof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alignof_A_fn_class *jrt.Class



type A_arbace_go_check_types_alignof_fn__219000252_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alignof_fn__219000252_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_basic_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_basic_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_basic_fn__219000185_A struct{ j2g_header uint64; F_pred any }

var A_arbace_go_check_types_all_basic_fn__219000185_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_boolean_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_boolean_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_complex_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_complex_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_float_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_float_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_integer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_integer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_or_string_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_or_string_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_ordered_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_ordered_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_string_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_string_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_unsigned_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_unsigned_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_basic_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_basic_A_fn_class *jrt.Class



type A_arbace_go_check_types_boolean_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_boolean_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_bound_iface_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_bound_iface_A_fn_class *jrt.Class



type A_arbace_go_check_types_canon_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_canon_A_fn_class *jrt.Class



type A_arbace_go_check_types_canon_kw_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_canon_kw_A_fn_class *jrt.Class



type A_arbace_go_check_types_canon_vec_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_canon_vec_A_fn_class *jrt.Class



type A_arbace_go_check_types_canon_vec_fn__219000025_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_canon_vec_fn__219000025_A_fn_class *jrt.Class



type A_arbace_go_check_types_canon_vec_fn__219000030_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_canon_vec_fn__219000030_A_fn_class *jrt.Class



type A_arbace_go_check_types_common_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_common_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_comparable_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A struct{ j2g_header uint64; F_seen, F_dynamic any }

var A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A_fn_class *jrt.Class



type A_arbace_go_check_types_complex_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_complex_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_consolidate_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_consolidate_A_fn_class *jrt.Class



type A_arbace_go_check_types_const_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_const_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_core_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_core_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_default_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_default_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_deref_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_deref_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_empty_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_empty_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_eval219000004_A struct{ jrt.Object }

func A_arbace_go_check_types_eval219000004_A_New() *A_arbace_go_check_types_eval219000004_A { t := &A_arbace_go_check_types_eval219000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_eval219000004_A) Ctor() {}

func (t *A_arbace_go_check_types_eval219000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_eval219000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_eval219000004_A_class }

func (t *A_arbace_go_check_types_eval219000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_eval219000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_eval219000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_eval219000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_eval219000004_A); return ok }

func A_arbace_go_check_types_eval219000004_A_Cast(x any) *A_arbace_go_check_types_eval219000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_eval219000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_eval219000004_A_class)) }; return v }



type A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_fn_class *jrt.Class



type A_arbace_go_check_types_eval219000008_A struct{ jrt.Object }

func A_arbace_go_check_types_eval219000008_A_New() *A_arbace_go_check_types_eval219000008_A { t := &A_arbace_go_check_types_eval219000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_eval219000008_A) Ctor() {}

func (t *A_arbace_go_check_types_eval219000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_eval219000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_eval219000008_A_class }

func (t *A_arbace_go_check_types_eval219000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_eval219000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_eval219000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_eval219000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_eval219000008_A); return ok }

func A_arbace_go_check_types_eval219000008_A_Cast(x any) *A_arbace_go_check_types_eval219000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_eval219000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_eval219000008_A_class)) }; return v }



type A_arbace_go_check_types_eval219000008_fn__219000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_eval219000008_fn__219000009_A_fn_class *jrt.Class



type A_arbace_go_check_types_exported_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_exported_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_field_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_field_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_flag_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_flag_A_fn_class *jrt.Class



type A_arbace_go_check_types_float_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_float_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_m__219000013_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class *jrt.Class



type A_arbace_go_check_types_has_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_name_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_has_nil_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_nil_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A_fn_class *jrt.Class



type A_arbace_go_check_types_has_terms_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_terms_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_identical_ignore_tags_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_identical_ignore_tags_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_iface_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_iface_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_iface_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_iface_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_ignore_tags_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ignore_tags_A_fn_class *jrt.Class



type A_arbace_go_check_types_ignore_tags_fn__219000073_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ignore_tags_fn__219000073_A_fn_class *jrt.Class



type A_arbace_go_check_types_incomparable_cause_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_incomparable_cause_A_fn_class *jrt.Class



type A_arbace_go_check_types_incomparable_cause_cause__219000090_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_incomparable_cause_cause__219000090_A_fn_class *jrt.Class



type A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A struct{ j2g_header uint64; F_cause, F_seen any }

var A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A_fn_class *jrt.Class



type A_arbace_go_check_types_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_info_A_fn_class *jrt.Class



type A_arbace_go_check_types_integer_or_float_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_integer_or_float_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_integer_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_integer_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_kind_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_kind_of_A_fn_class *jrt.Class



type A_arbace_go_check_types_kw_alias_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_kw_alias_A_fn_class *jrt.Class



type A_arbace_go_check_types_kw_alias_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_kw_alias_info_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_lookup_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_impl_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_lookup_impl_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_impl_fn__219000275_A struct{ j2g_header uint64; F_pkg, F_name any }

var A_arbace_go_check_types_lookup_impl_fn__219000275_A_fn_class *jrt.Class



type A_arbace_go_check_types_make_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_make_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_method_data_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_method_data_A_fn_class *jrt.Class



type A_arbace_go_check_types_method_set_iface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_method_set_iface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_methods_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_methods_of_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_missing_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_fn__219000289_A struct{ j2g_header uint64; F_static, F_V, F_same_QMARK_, F_vu any }

var A_arbace_go_check_types_missing_method_fn__219000289_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_fn__219000289_fn__219000290_A struct{ j2g_header uint64; F_m, F_V any }

var A_arbace_go_check_types_missing_method_fn__219000289_fn__219000290_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_named_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_new_named_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_new_named_A_fn_class *jrt.Class



type A_arbace_go_check_types_new_tparam_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_new_tparam_A_fn_class *jrt.Class



type A_arbace_go_check_types_next_id_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_next_id_A_fn_class *jrt.Class



type A_arbace_go_check_types_numeric_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_offsetsof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_offsetsof_A_fn_class *jrt.Class



type A_arbace_go_check_types_ordered_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ordered_A_fn_class *jrt.Class



type A_arbace_go_check_types_ordered_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ordered_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_params_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_params_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_params_str_fn__219000225_A struct{ j2g_header uint64; F_ps, F_variadic any }

var A_arbace_go_check_types_params_str_fn__219000225_A_fn_class *jrt.Class



type A_arbace_go_check_types_pointer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_pointer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_same_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_same_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_same_id_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_same_id_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_satisfies_cause_A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_comparability__219000294_A struct{ j2g_header uint64; F_Tts, F_V any }

var A_arbace_go_check_types_satisfies_cause_comparability__219000294_A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_comparability__219000294_fn__219000296_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_satisfies_cause_comparability__219000294_fn__219000296_A_fn_class *jrt.Class



type A_arbace_go_check_types_sig_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sig_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_sizeof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sizeof_A_fn_class *jrt.Class



type A_arbace_go_check_types_sort_methods_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sort_methods_A_fn_class *jrt.Class



type A_arbace_go_check_types_sort_methods_fn__219000285_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sort_methods_fn__219000285_A_fn_class *jrt.Class



type A_arbace_go_check_types_strictly_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_string_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_string_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_sync_atomic_align64_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_disjoint_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_includes_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_includes_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_intersect_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_intersect_A_fn_class *jrt.Class



type A_arbace_go_check_types_term_subset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_subset_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_union_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_union_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_includes_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_includes_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A struct{ j2g_header uint64; F_t any }

var A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_intersect_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A struct{ j2g_header uint64; F_y any }

var A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A struct{ j2g_header uint64; F_iter__219000120, F_s__219000121, F_y any }

var A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A struct{ j2g_header uint64; F_a any }

var A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A struct{ j2g_header uint64; F_iter__219000122, F_s__219000123, F_a any }

var A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A struct{ j2g_header uint64; F_b__219000125 any; F_size__1927001038__auto__ int32; F_a, F_c__1927001037__auto__ any }

var A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_norm_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_norm_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_norm_fn__219000115_A struct{ j2g_header uint64; F_i int64; F_n int32; F_used, F_ts any }

var A_arbace_go_check_types_terms_norm_fn__219000115_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000208__219000212_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_str_iter__219000208__219000212_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A struct{ j2g_header uint64; F_iter__219000208, F_s__219000209 any }

var A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A struct{ j2g_header uint64; F_b__219000211 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_subset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_subset_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A struct{ j2g_header uint64; F_yl any }

var A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_superset_of_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_superset_of_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A struct{ j2g_header uint64; F_y any }

var A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_union_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_union_A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_iface_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_iface_A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A struct{ j2g_header uint64; F_seen any }

var A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_empty_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tset_empty_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_type_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000238__219000242_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_type_str_iter__219000238__219000242_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_A struct{ j2g_header uint64; F_iter__219000238, F_s__219000239 any }

var A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_fn__219000244_A struct{ j2g_header uint64; F_b__219000241 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_type_str_iter__219000238__219000242_fn__219000243_fn__219000244_A_fn_class *jrt.Class



type A_arbace_go_check_types_typed_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typed_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_all_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_all_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_all_fn__219000175_A struct{ j2g_header uint64; F_f any }

var A_arbace_go_check_types_typeset_all_fn__219000175_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_pairs_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A struct{ j2g_header uint64; F_iter__219000157, F_s__219000158 any }

var A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A struct{ j2g_header uint64; F_b__219000160 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A_fn_class *jrt.Class



type A_arbace_go_check_types_uintptr_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_uintptr_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_under_is_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_under_is_A_fn_class *jrt.Class



type A_arbace_go_check_types_under_is_fn__219000181_A struct{ j2g_header uint64; F_f any }

var A_arbace_go_check_types_under_is_fn__219000181_A_fn_class *jrt.Class



type A_arbace_go_check_types_union_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_union_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_unsafe_pointer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_unsafe_pointer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_unsigned_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_unsigned_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_untyped_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_untyped_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_update_info_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_update_info_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_types_valid_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_valid_QMARK__A_fn_class *jrt.Class
