//line aot_arbace_go_check_types.ae:1
package aot_arbace_go_check_types

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_const"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_New() *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_types_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_types_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_go_check_types_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_1, A_arbace_go_check_types_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_types_eval219000008_fn__219000009_A_New() *A_arbace_go_check_types_eval219000008_fn__219000009_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_eval219000008_fn__219000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_types_eval219000008_fn__219000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_types_eval219000008_fn__219000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_go_check_types_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_types_A_const_8.GetRawRoot__O(), A_arbace_go_check_types_A_const_9) }






















func A_arbace_go_check_types_fn__219000012_A_New() *A_arbace_go_check_types_fn__219000012_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_A) Invoke_O__O(self any) any { var m__1 any; var tmp1 any = A_arbace_go_check_types_fn__219000012_m__219000013_A_New(); var tmp2 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, true); A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class = fncls__31d; tmp2 = fncls__31d } else { tmp2 = fncls__31 }; m__1 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp1, tmp2, nil, 2); var root_32 any =
										A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_36 any = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_14, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_16), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_17, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_19, A_arbace_go_check_types_A_const_20, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_21, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_23, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_25, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_26, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_28, A_arbace_go_check_types_A_const_20, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_29, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_30, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_31, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_32, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_33, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_34), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_35, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_34), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_36, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_37), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_38, A_arbace_go_check_types_A_const_39, A_arbace_go_check_types_A_const_37), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_40, A_arbace_go_check_types_A_const_39, A_arbace_go_check_types_A_const_41), lang.IFn_Cast(m__1).Invoke_O_O__O(A_arbace_go_check_types_A_const_42, A_arbace_go_check_types_A_const_24), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_43, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_16, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_46, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_47, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_48, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_34, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_49, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_37, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_50, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_41, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_51, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_45))); if linked_33 == nil { return ifn_34.Invoke_O_O__O(arg_35, arg_36) } else { return linked_33.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_32, arg_35, arg_36) } }
//line :24:1
func A_arbace_go_check_types_fn__219000012_m__219000013_A_New() *A_arbace_go_check_types_fn__219000012_m__219000013_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_m__219000013_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_A) DoInvoke_O_O_O_O__O(self, n__1, size__2, flags__3 any) any { var tmp1 any; var root_20 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_11, size__2, A_arbace_go_check_types_A_const_12, n__1)); var arg_24 any; var root_25 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any; var tmp2 any = A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; arg_28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_29 any = flags__3; if linked_26 == nil { arg_24 = ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { arg_24 = linked_26.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) }; if linked_21 == nil { tmp1 = ifn_22.Invoke_O_O__O(arg_23, arg_24) } else { tmp1 = linked_21.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_20, arg_23, arg_24) }; return lang.Tuple_Create_O_O__IPersistentVector(n__1, tmp1) }
//line :24:1
func A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_New() *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A) Invoke_O_O__O(self, f__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(f__1, jrt.Boolean_TRUE.Ref()) }


























func A_arbace_go_check_types_next_id_A_New() *A_arbace_go_check_types_next_id_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_next_id_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_go_check_types_next_id_A) Ctor() {}
//line :51:1
func (t *A_arbace_go_check_types_next_id_A) InvokePrim_O__J(self any) int64 { return jrt.Number_Cast(lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(A_arbace_go_check_types_A_const_52.GetRawRoot__O(), Lit_20, false)).LongValue__J() }
//line :51:1
func (t *A_arbace_go_check_types_next_id_A) Invoke_O__O(self any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O__J(self)).Ref() }

func A_arbace_go_check_types_named_QMARK__A_New() *A_arbace_go_check_types_named_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_QMARK__A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_go_check_types_named_QMARK__A) Ctor() {}
//line :53:1
func (t *A_arbace_go_check_types_named_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_37 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = t__0; if linked_38 == nil { and__1927000168__auto____2 = ifn_39.Invoke_O__O(arg_40) } else { and__1927000168__auto____2 = linked_38.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_37, arg_40) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_54; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_tparam_QMARK__A_New() *A_arbace_go_check_types_tparam_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_QMARK__A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_go_check_types_tparam_QMARK__A) Ctor() {}
//line :54:1
func (t *A_arbace_go_check_types_tparam_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_41 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = t__0; if linked_42 == nil { and__1927000168__auto____2 = ifn_43.Invoke_O__O(arg_44) } else { and__1927000168__auto____2 = linked_42.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_41, arg_44) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_55; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_info_A_New() *A_arbace_go_check_types_info_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_info_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_go_check_types_info_A) Ctor() {}
//line :55:1
func (t *A_arbace_go_check_types_info_A) Invoke_O_O__O(self, t__0 any) any { var root_45 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_46 == nil { return ifn_47.Invoke_O__O(arg_48) } else { return linked_46.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_45, arg_48) } }
func A_arbace_go_check_types_update_info_BANG__A_New() *A_arbace_go_check_types_update_info_BANG__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_update_info_BANG__A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_go_check_types_update_info_BANG__A) Ctor() {}
//line :56:1
func (t *A_arbace_go_check_types_update_info_BANG__A) DoInvoke_O_O_O_O__O(self, t__0, f__1, args__2 any) any { var root_49 any = A_arbace_go_check_types_A_const_56.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var arg_53 any; var root_54 any = A_arbace_go_check_types_A_const_57.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = f__1; var arg_58 any; var root_60 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_61 == nil { arg_58 = ifn_62.Invoke_O__O(arg_63) } else { arg_58 = linked_61.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_60, arg_63) }; var arg_59 any = args__2; if linked_55 == nil { arg_53 = ifn_56.Invoke_O_O_O__O(arg_57, arg_58, arg_59) } else { arg_53 = linked_55.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_54, arg_57, arg_58, arg_59) }; if linked_50 == nil { ifn_51.Invoke_O_O__O(arg_52, arg_53) } else { linked_50.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_49, arg_52, arg_53) }; return t__0 }

func A_arbace_go_check_types_new_named_A_New() *A_arbace_go_check_types_new_named_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_new_named_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_go_check_types_new_named_A) Ctor() {}
//line :58:1
func (t *A_arbace_go_check_types_new_named_A) Invoke_O_O__O(self, data__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_54; var tmp2 any; var root_64 any = A_arbace_go_check_types_A_const_58.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_66 lang.IFn; if


	linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_59.GetRawRoot__O()); var tmp4 any = A_arbace_go_check_types_A_const_60; var tmp5 any; var root_76 any = A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_76, A_arbace_go_check_types_next_id_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; if linked_77 == nil { tmp5 = ifn_78.Invoke__O() } else { tmp5 = jrt.Long_ValueOf_J__Long_NoInit(linked_77.(*A_arbace_go_check_types_next_id_A).InvokePrim_O__J(root_76)).Ref() }; arg_67 = tmp3.Invoke_O_O_O_O_O__O(data__0, tmp4, tmp5, A_arbace_go_check_types_A_const_62, lang.PersistentVector_EMPTY.Ref()); if linked_65 == nil { tmp2 = ifn_66.Invoke_O__O(arg_67) } else { tmp2 = linked_65.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_64, arg_67) }; return /*line :58:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }




func A_arbace_go_check_types_new_tparam_A_New() *A_arbace_go_check_types_new_tparam_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_new_tparam_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_go_check_types_new_tparam_A) Ctor() {}
//line :63:1
func (t *A_arbace_go_check_types_new_tparam_A) Invoke_O_O__O(self, data__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_55; var tmp2 any; var root_79 any = A_arbace_go_check_types_A_const_58.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_81 lang.IFn; if


	linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any; var root_83 any = A_arbace_go_check_types_A_const_59.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = data__0; var arg_87 any = A_arbace_go_check_types_A_const_60; var arg_88 any; var root_89 any = A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_89, A_arbace_go_check_types_next_id_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; if linked_90 == nil { arg_88 = ifn_91.Invoke__O() } else { arg_88 = jrt.Long_ValueOf_J__Long_NoInit(linked_90.(*A_arbace_go_check_types_next_id_A).InvokePrim_O__J(root_89)).Ref() }; if linked_84 == nil { arg_82 = ifn_85.Invoke_O_O_O__O(arg_86, arg_87, arg_88) } else { arg_82 = linked_84.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_83, arg_86, arg_87, arg_88) }; if linked_80 == nil { tmp2 = ifn_81.Invoke_O__O(arg_82) } else { tmp2 = linked_80.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_79, arg_82) }; return /*line :63:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }











func A_arbace_go_check_types_named_under_A_New() *A_arbace_go_check_types_named_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_under_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_go_check_types_named_under_A) Ctor() {}
//line :75:1
func (t *A_arbace_go_check_types_named_under_A) Invoke_O_O__O(self, t__0 any) any { { var t__2 any = t__0; var seen__3 any = lang.PersistentHashSet_EMPTY.Ref(); L1: for { var i__4 any; var root_92 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, A_arbace_go_check_types_info_A_fn_class); var ifn_94 lang.IFn

	if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = t__2; if linked_93 == nil { i__4 = ifn_94.Invoke_O__O(arg_95) } else { i__4 = linked_93.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_92, arg_95) }
//line :75:1
	var temp__1927000408__auto____5 any = A_arbace_go_check_types_A_const_64.Invoke_O__O(i__4)


	if jrt.J2g_Truth(temp__1927000408__auto____5) { var u__6 any = temp__1927000408__auto____5; var tmp1 any; var root_96 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_98 lang.IFn
		if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = u__6; if linked_97 == nil { tmp1 = ifn_98.Invoke_O__O(arg_99) } else { tmp1 = linked_97.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_96, arg_99) }; if jrt.J2g_Truth(tmp1) {

			var tmp2 any; var root_100 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = seen__3; var arg_104 any = u__6; if linked_101 == nil { tmp2 = ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { tmp2 = linked_101.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_100, arg_103, arg_104) }; if jrt.J2g_Truth(tmp2) { return A_arbace_go_check_types_A_const_67 } else {

				var tmp3 any; var root_113 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = seen__3; var arg_117 any = t__2; if linked_114 == nil { tmp3 = ifn_115.Invoke_O_O__O(arg_116, arg_117) } else { tmp3 = linked_114.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_113, arg_116, arg_117) }; t__2, seen__3 = u__6, tmp3; continue L1 } } else {
//line :79:1
					return u__6 } } else {





						var tmp4 any; var and__1927000168__auto____6 any = A_arbace_go_check_types_A_const_68.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_105 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = A_arbace_go_check_types_A_const_70.Invoke_O__O(i__4); if linked_106 == nil { and__1927000168__auto____7 = ifn_107.Invoke_O__O(arg_108) } else { and__1927000168__auto____7 = linked_106.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_105, arg_108) }; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp4 = A_arbace_go_check_types_A_const_71.Invoke_O__O(i__4) } else { tmp4 = and__1927000168__auto____7 } } else { tmp4 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp4) {
							lang.IFn_Cast(A_arbace_go_check_types_A_const_68.Get__O()).Invoke_O__O(t__2)
							var tmp5 *lang.Keyword = A_arbace_go_check_types_A_const_64; var tmp6 any; var root_109 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, A_arbace_go_check_types_info_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = t__2; if linked_110 == nil { tmp6 = ifn_111.Invoke_O__O(arg_112) } else { tmp6 = linked_110.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_109, arg_112) }; if jrt.J2g_Truth(tmp5.Invoke_O__O(tmp6)) { t__2, seen__3 = t__2, seen__3; continue L1 } else { return A_arbace_go_check_types_A_const_67 } } else {
//line :85:1
								return A_arbace_go_check_types_A_const_67 } } } }; /*line :75:1*/panic("j2g: unreachable") }














func A_arbace_go_check_types_under_A_New() *A_arbace_go_check_types_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_go_check_types_under_A) Ctor() {}
//line :90:1
func (t *A_arbace_go_check_types_under_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_118 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_120 lang.IFn
	if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = t__0; if linked_119 == nil { tmp1 = ifn_120.Invoke_O__O(arg_121) } else { tmp1 = linked_119.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_118, arg_121) }
//line :93:1
	if jrt.J2g_Truth(tmp1) { return t__0 } else { var tmp2 any = A_arbace_go_check_types_A_const_54; if lang.Util_Identical_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))) {

		var root_122 any = A_arbace_go_check_types_A_const_73.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, A_arbace_go_check_types_named_under_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = t__0; if linked_123 == nil { return ifn_124.Invoke_O__O(arg_125) } else { return linked_123.(*A_arbace_go_check_types_named_under_A).Invoke_O_O__O(root_122, arg_125) } } else {
//line :93:1
			var tmp3 any = A_arbace_go_check_types_A_const_55; if lang.Util_Identical_O_O__Z_NoInit(tmp3, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))) {


				var root_126 any = A_arbace_go_check_types_A_const_74.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, A_arbace_go_check_types_tparam_iface_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = t__0; if linked_127 == nil { return ifn_128.Invoke_O__O(arg_129) } else { return linked_127.(*A_arbace_go_check_types_tparam_iface_A).Invoke_O_O__O(root_126, arg_129) } } else {
//line :93:1
					if A_arbace_go_check_types_A_const_75 != nil { return t__0 } else { return nil
					}
				}
		}
	}
}


func A_arbace_go_check_types_basic_A_New() *A_arbace_go_check_types_basic_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_basic_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_check_types_basic_A) Ctor() {}
//line :101:1
func (t *A_arbace_go_check_types_basic_A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_130 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_go_check_types_under_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = t__0; if linked_131 == nil { u__2 = ifn_132.Invoke_O__O(arg_133) } else { u__2 = linked_131.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_130, arg_133) }; var tmp1 any; var root_134 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = u__2; if linked_135 == nil { tmp1 = ifn_136.Invoke_O__O(arg_137) } else { tmp1 = linked_135.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_134, arg_137) }; if jrt.J2g_Truth(tmp1) { return u__2 } else { return nil } }
func A_arbace_go_check_types_flag_A_New() *A_arbace_go_check_types_flag_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_flag_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_go_check_types_flag_A) Ctor() {}
//line :102:1
func (t *A_arbace_go_check_types_flag_A) Invoke_O_O_O__O(self, t__0, f__1 any) any { var b__3 any; var root_138 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, A_arbace_go_check_types_basic_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = t__0; if linked_139 == nil { b__3 = ifn_140.Invoke_O__O(arg_141) } else { b__3 = linked_139.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_138, arg_141) }; var tmp1 any; var and__1927000168__auto____4 any = b__3; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_go_check_types_A_const_78.GetRawRoot__O()).Invoke_O__O(b__3), f__1) } else { tmp1 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }
func A_arbace_go_check_types_integer_type_QMARK__A_New() *A_arbace_go_check_types_integer_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_integer_type_QMARK__A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_go_check_types_integer_type_QMARK__A) Ctor() {}
//line :103:1
func (t *A_arbace_go_check_types_integer_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_142 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, A_arbace_go_check_types_flag_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = t__0; var arg_146 any = A_arbace_go_check_types_A_const_18; if linked_143 == nil { return ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { return linked_143.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_142, arg_145, arg_146) } }
func A_arbace_go_check_types_unsigned_QMARK__A_New() *A_arbace_go_check_types_unsigned_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_unsigned_QMARK__A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_go_check_types_unsigned_QMARK__A) Ctor() {}
//line :104:1
func (t *A_arbace_go_check_types_unsigned_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_147 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, A_arbace_go_check_types_flag_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = t__0; var arg_151 any = A_arbace_go_check_types_A_const_27; if linked_148 == nil { return ifn_149.Invoke_O_O__O(arg_150, arg_151) } else { return linked_148.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_147, arg_150, arg_151) } }
func A_arbace_go_check_types_float_type_QMARK__A_New() *A_arbace_go_check_types_float_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_float_type_QMARK__A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_go_check_types_float_type_QMARK__A) Ctor() {}
//line :105:1
func (t *A_arbace_go_check_types_float_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_152 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, A_arbace_go_check_types_flag_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = t__0; var arg_156 any = A_arbace_go_check_types_A_const_34; if linked_153 == nil { return ifn_154.Invoke_O_O__O(arg_155, arg_156) } else { return linked_153.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_152, arg_155, arg_156) } }
func A_arbace_go_check_types_complex_type_QMARK__A_New() *A_arbace_go_check_types_complex_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_complex_type_QMARK__A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_go_check_types_complex_type_QMARK__A) Ctor() {}
//line :106:1
func (t *A_arbace_go_check_types_complex_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_157 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, A_arbace_go_check_types_flag_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = t__0; var arg_161 any = A_arbace_go_check_types_A_const_37; if linked_158 == nil { return ifn_159.Invoke_O_O__O(arg_160, arg_161) } else { return linked_158.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_157, arg_160, arg_161) } }
func A_arbace_go_check_types_numeric_QMARK__A_New() *A_arbace_go_check_types_numeric_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_numeric_QMARK__A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_go_check_types_numeric_QMARK__A) Ctor() {}
//line :107:1
func (t *A_arbace_go_check_types_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_162 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = t__0; if linked_163 == nil { or__1927000174__auto____2 = ifn_164.Invoke_O__O(arg_165) } else { or__1927000174__auto____2 = linked_163.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_162, arg_165) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_166 any = A_arbace_go_check_types_A_const_81.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = t__0; if linked_167 == nil { or__1927000174__auto____3 = ifn_168.Invoke_O__O(arg_169) } else { or__1927000174__auto____3 = linked_167.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_166, arg_169) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_170 any = A_arbace_go_check_types_A_const_82.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, A_arbace_go_check_types_complex_type_QMARK__A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = t__0; if linked_171 == nil { return ifn_172.Invoke_O__O(arg_173) } else { return linked_171.(*A_arbace_go_check_types_complex_type_QMARK__A).Invoke_O_O__O(root_170, arg_173) } } } }
func A_arbace_go_check_types_string_type_QMARK__A_New() *A_arbace_go_check_types_string_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_string_type_QMARK__A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_go_check_types_string_type_QMARK__A) Ctor() {}
//line :108:1
func (t *A_arbace_go_check_types_string_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_174 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, A_arbace_go_check_types_flag_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = t__0; var arg_178 any = A_arbace_go_check_types_A_const_41; if linked_175 == nil { return ifn_176.Invoke_O_O__O(arg_177, arg_178) } else { return linked_175.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_174, arg_177, arg_178) } }
func A_arbace_go_check_types_boolean_type_QMARK__A_New() *A_arbace_go_check_types_boolean_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_boolean_type_QMARK__A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_go_check_types_boolean_type_QMARK__A) Ctor() {}
//line :109:1
func (t *A_arbace_go_check_types_boolean_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_179 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, A_arbace_go_check_types_flag_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = t__0; var arg_183 any = A_arbace_go_check_types_A_const_16; if linked_180 == nil { return ifn_181.Invoke_O_O__O(arg_182, arg_183) } else { return linked_180.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_179, arg_182, arg_183) } }
func A_arbace_go_check_types_untyped_QMARK__A_New() *A_arbace_go_check_types_untyped_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_untyped_QMARK__A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_go_check_types_untyped_QMARK__A) Ctor() {}
//line :110:1
func (t *A_arbace_go_check_types_untyped_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_184 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = t__0; if linked_185 == nil { and__1927000168__auto____2 = ifn_186.Invoke_O__O(arg_187) } else { and__1927000168__auto____2 = linked_185.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_184, arg_187) }; if jrt.J2g_Truth(and__1927000168__auto____2) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_go_check_types_A_const_78.GetRawRoot__O()).Invoke_O__O(t__0), A_arbace_go_check_types_A_const_45))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_typed_QMARK__A_New() *A_arbace_go_check_types_typed_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typed_QMARK__A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_go_check_types_typed_QMARK__A) Ctor() {}
//line :111:1
func (t *A_arbace_go_check_types_typed_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_188 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any; var root_192 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, A_arbace_go_check_types_untyped_QMARK__A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = t__0; if linked_193 == nil { arg_191 = ifn_194.Invoke_O__O(arg_195) } else { arg_191 = linked_193.(*A_arbace_go_check_types_untyped_QMARK__A).Invoke_O_O__O(root_192, arg_195) }; if linked_189 == nil { return ifn_190.Invoke_O__O(arg_191) } else { return linked_189.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_188, arg_191) } }
func A_arbace_go_check_types_const_type_QMARK__A_New() *A_arbace_go_check_types_const_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_const_type_QMARK__A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_go_check_types_const_type_QMARK__A) Ctor() {}
//line :112:1
func (t *A_arbace_go_check_types_const_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var b__2 any; var root_196 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, A_arbace_go_check_types_basic_A_fn_class); var ifn_198 lang.IFn; if


	linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = t__0; if linked_197 == nil { b__2 = ifn_198.Invoke_O__O(arg_199) } else { b__2 = linked_197.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_196, arg_199) }; var and__1927000168__auto____3 any = b__2; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_200 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = lang.IFn_Cast(A_arbace_go_check_types_A_const_84).Invoke_O__O(b__2); if linked_201 == nil { return ifn_202.Invoke_O__O(arg_203) } else { return linked_201.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_200, arg_203) } } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_ordered_QMARK__A_New() *A_arbace_go_check_types_ordered_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ordered_QMARK__A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_go_check_types_ordered_QMARK__A) Ctor() {}
//line :116:1
func (t *A_arbace_go_check_types_ordered_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_204 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = t__0; if linked_205 == nil { or__1927000174__auto____2 = ifn_206.Invoke_O__O(arg_207) } else { or__1927000174__auto____2 = linked_205.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_204, arg_207) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_208 any = A_arbace_go_check_types_A_const_81.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = t__0; if linked_209 == nil { or__1927000174__auto____3 = ifn_210.Invoke_O__O(arg_211) } else { or__1927000174__auto____3 = linked_209.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_208, arg_211) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_212 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, A_arbace_go_check_types_string_type_QMARK__A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = t__0; if linked_213 == nil { return ifn_214.Invoke_O__O(arg_215) } else { return linked_213.(*A_arbace_go_check_types_string_type_QMARK__A).Invoke_O_O__O(root_212, arg_215) } } } }
func A_arbace_go_check_types_interface_QMARK__A_New() *A_arbace_go_check_types_interface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_interface_QMARK__A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_go_check_types_interface_QMARK__A) Ctor() {}
//line :117:1
func (t *A_arbace_go_check_types_interface_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_216 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, A_arbace_go_check_types_under_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = t__0; if linked_217 == nil { u__2 = ifn_218.Invoke_O__O(arg_219) } else { u__2 = linked_217.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_216, arg_219) }; var and__1927000168__auto____3 any; var root_220 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = u__2; if linked_221 == nil { and__1927000168__auto____3 = ifn_222.Invoke_O__O(arg_223) } else { and__1927000168__auto____3 = linked_221.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_220, arg_223) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_86; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_pointer_QMARK__A_New() *A_arbace_go_check_types_pointer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_pointer_QMARK__A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_go_check_types_pointer_QMARK__A) Ctor() {}
//line :118:1
func (t *A_arbace_go_check_types_pointer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_224 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, A_arbace_go_check_types_under_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = t__0; if linked_225 == nil { u__2 = ifn_226.Invoke_O__O(arg_227) } else { u__2 = linked_225.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_224, arg_227) }; var and__1927000168__auto____3 any; var root_228 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = u__2; if linked_229 == nil { and__1927000168__auto____3 = ifn_230.Invoke_O__O(arg_231) } else { and__1927000168__auto____3 = linked_229.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_228, arg_231) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_87; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_unsafe_pointer_QMARK__A_New() *A_arbace_go_check_types_unsafe_pointer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_unsafe_pointer_QMARK__A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_go_check_types_unsafe_pointer_QMARK__A) Ctor() {}
//line :119:1
func (t *A_arbace_go_check_types_unsafe_pointer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_42; var tmp2 any; var root_232 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, A_arbace_go_check_types_basic_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = t__0; if linked_233 == nil { tmp2 = ifn_234.Invoke_O__O(arg_235) } else { tmp2 = linked_233.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_232, arg_235) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }
func A_arbace_go_check_types_uintptr_QMARK__A_New() *A_arbace_go_check_types_uintptr_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_uintptr_QMARK__A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_go_check_types_uintptr_QMARK__A) Ctor() {}
//line :120:1
func (t *A_arbace_go_check_types_uintptr_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_32; var tmp2 any; var root_236 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, A_arbace_go_check_types_basic_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = t__0; if linked_237 == nil { tmp2 = ifn_238.Invoke_O__O(arg_239) } else { tmp2 = linked_237.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_236, arg_239) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }
func A_arbace_go_check_types_valid_QMARK__A_New() *A_arbace_go_check_types_valid_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_valid_QMARK__A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_go_check_types_valid_QMARK__A) Ctor() {}
//line :121:1
func (t *A_arbace_go_check_types_valid_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_240 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = A_arbace_go_check_types_A_const_67; var arg_244 any = t__0; if linked_241 == nil { return ifn_242.Invoke_O_O__O(arg_243, arg_244) } else { return linked_241.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_240, arg_243, arg_244) } }
func A_arbace_go_check_types_kind_of_A_New() *A_arbace_go_check_types_kind_of_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_kind_of_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_go_check_types_kind_of_A) Ctor() {}
//line :122:1
func (t *A_arbace_go_check_types_kind_of_A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_245 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, A_arbace_go_check_types_under_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = t__0; if linked_246 == nil { u__2 = ifn_247.Invoke_O__O(arg_248) } else { u__2 = linked_246.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_245, arg_248) }; var tmp1 any; var root_249 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = u__2; if linked_250 == nil { tmp1 = ifn_251.Invoke_O__O(arg_252) } else { tmp1 = linked_250.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_249, arg_252) }; if jrt.J2g_Truth(tmp1) { return u__2 } else { return lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)) } }
func A_arbace_go_check_types_has_name_QMARK__A_New() *A_arbace_go_check_types_has_name_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_name_QMARK__A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_go_check_types_has_name_QMARK__A) Ctor() {}
//line :123:1
func (t *A_arbace_go_check_types_has_name_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_253 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = t__0; if linked_254 == nil { or__1927000174__auto____2 = ifn_255.Invoke_O__O(arg_256) } else { or__1927000174__auto____2 = linked_254.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_253, arg_256) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_257 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = t__0; if linked_258 == nil { or__1927000174__auto____3 = ifn_259.Invoke_O__O(arg_260) } else { or__1927000174__auto____3 = linked_258.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_257, arg_260) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_261 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = t__0; if linked_262 == nil { return ifn_263.Invoke_O__O(arg_264) } else { return linked_262.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_261, arg_264) } } } }
func A_arbace_go_check_types_integer_or_float_QMARK__A_New() *A_arbace_go_check_types_integer_or_float_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_integer_or_float_QMARK__A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_go_check_types_integer_or_float_QMARK__A) Ctor() {}
//line :124:1
func (t *A_arbace_go_check_types_integer_or_float_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_265 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = t__0; if linked_266 == nil { or__1927000174__auto____2 = ifn_267.Invoke_O__O(arg_268) } else { or__1927000174__auto____2 = linked_266.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_265, arg_268) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_269 any = A_arbace_go_check_types_A_const_81.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = t__0; if linked_270 == nil { return ifn_271.Invoke_O__O(arg_272) } else { return linked_270.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_269, arg_272) } } }



func A_arbace_go_check_types_has_nil_QMARK__A_New() *A_arbace_go_check_types_has_nil_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_nil_QMARK__A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_go_check_types_has_nil_QMARK__A) Ctor() {}
//line :128:1
func (t *A_arbace_go_check_types_has_nil_QMARK__A) Invoke_O_O__O(self, t__0 any) any {



	var tmp1 any; var root_273 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = t__0; if linked_274 == nil { tmp1 = ifn_275.Invoke_O__O(arg_276) } else { tmp1 = linked_274.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_273, arg_276) }; if jrt.J2g_Truth(tmp1) {
		var root_277 any = A_arbace_go_check_types_A_const_90.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, A_arbace_go_check_types_under_is_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = t__0; var arg_281 any; var tmp2 any = A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A_New(); var tmp3 *jrt.Class; var fncls__290 *jrt.Class = A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A_fn_class; if fncls__290 == nil { var fncls__290d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A_fn_class = fncls__290d; tmp3 = fncls__290d } else { tmp3 = fncls__290 }; arg_281 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_278 == nil { return ifn_279.Invoke_O_O__O(arg_280, arg_281) } else { return linked_278.(*A_arbace_go_check_types_under_is_A).Invoke_O_O_O__O(root_277, arg_280, arg_281) } } else {
//line :132:1
			var u__2 any; var root_291 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, A_arbace_go_check_types_under_A_fn_class); var ifn_293 lang.IFn

			if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = t__0; if linked_292 == nil { u__2 = ifn_293.Invoke_O__O(arg_294) } else { u__2 = linked_292.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_291, arg_294) }
//line :132:1
			var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_42, u__2)


			if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_51, u__2); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var and__1927000168__auto____5 any; var root_295 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_297 lang.IFn
				if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = u__2; if linked_296 == nil { and__1927000168__auto____5 = ifn_297.Invoke_O__O(arg_298) } else { and__1927000168__auto____5 = linked_296.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_295, arg_298) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_299 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = A_arbace_go_check_types_A_const_93; var arg_303 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)); if linked_300 == nil { return ifn_301.Invoke_O_O__O(arg_302, arg_303) } else { return linked_300.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_299, arg_302, arg_303) } } else { return and__1927000168__auto____5 } } } } }
//line :133:1
func A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A_New() *A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A) Ctor() {}
//line :133:1
func (t *A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A) Invoke_O_O__O(self, u__1 any) any { var and__1927000168__auto____2 any; var root_282 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = u__1; if linked_283 == nil { and__1927000168__auto____2 = ifn_284.Invoke_O__O(arg_285) } else { and__1927000168__auto____2 = linked_283.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_282, arg_285) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_286 any = A_arbace_go_check_types_A_const_92.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, A_arbace_go_check_types_has_nil_QMARK__A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = u__1; if linked_287 == nil { return ifn_288.Invoke_O__O(arg_289) } else { return linked_287.(*A_arbace_go_check_types_has_nil_QMARK__A).Invoke_O_O__O(root_286, arg_289) } } else { return and__1927000168__auto____2 } }




func A_arbace_go_check_types_empty_interface_QMARK__A_New() *A_arbace_go_check_types_empty_interface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_empty_interface_QMARK__A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_go_check_types_empty_interface_QMARK__A) Ctor() {}
//line :138:1
func (t *A_arbace_go_check_types_empty_interface_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_304 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, A_arbace_go_check_types_under_A_fn_class); var ifn_306 lang.IFn; if
												linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = t__0; if linked_305 == nil { u__2 = ifn_306.Invoke_O__O(arg_307) } else { u__2 = linked_305.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_304, arg_307) }; var and__1927000168__auto____3 any; var root_308 any = /*line :138:1*/A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_310 lang.IFn; if
												linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = u__2; if linked_309 == nil { and__1927000168__auto____3 = ifn_310.Invoke_O__O(arg_311) } else { and__1927000168__auto____3 = linked_309.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_308, arg_311) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_86; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____4 { var and__1927000168__auto____5 any; var root_312 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_313 == nil { and__1927000168__auto____5 = ifn_314.Invoke_O__O(arg_315) } else { and__1927000168__auto____5 = linked_313.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_312, arg_315) }; if jrt.J2g_Truth(and__1927000168__auto____5) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref() } else { return and__1927000168__auto____5 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_default_type_A_New() *A_arbace_go_check_types_default_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_default_type_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_go_check_types_default_type_A) Ctor() {}
//line :141:1
func (t *A_arbace_go_check_types_default_type_A) Invoke_O_O__O(self, t__0 any) any { var G__219000052__2_ any = t__0; switch


	lang.Util_Hash_O__I_NoInit(G__219000052__2_) >> 19 & 7 { case 0: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_49) { return A_arbace_go_check_types_A_const_38 }; case 1: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_43) { return A_arbace_go_check_types_A_const_14 }; case 3: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_48) { return A_arbace_go_check_types_A_const_35 }; case 5: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_46) { return A_arbace_go_check_types_A_const_25 }; case 6: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_50) { return A_arbace_go_check_types_A_const_40 }; case 7: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_47) { return A_arbace_go_check_types_A_const_21 }; default:}; return t__0 }




func A_arbace_go_check_types_ignore_tags_A_New() *A_arbace_go_check_types_ignore_tags_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ignore_tags_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_go_check_types_ignore_tags_A) Ctor() {}
//line :149:1
func (t *A_arbace_go_check_types_ignore_tags_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_317 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = t__0; if linked_318 == nil { and__1927000168__auto____2 = ifn_319.Invoke_O__O(arg_320) } else { and__1927000168__auto____2 = linked_318.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_317, arg_320) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_321 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any; var root_325 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = t__0; if linked_326 == nil { arg_324 = ifn_327.Invoke_O__O(arg_328) } else { arg_324 = linked_326.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_325, arg_328) }; if linked_322 == nil { and__1927000168__auto____3 = ifn_323.Invoke_O__O(arg_324) } else { and__1927000168__auto____3 = linked_322.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_321, arg_324) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_329 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any; var root_333 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = t__0; if linked_334 == nil { arg_332 = ifn_335.Invoke_O__O(arg_336) } else { arg_332 = linked_334.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_333, arg_336) }; if linked_330 == nil { tmp1 = ifn_331.Invoke_O__O(arg_332) } else { tmp1 = linked_330.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_329, arg_332) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var G__219000055__2_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))
		switch lang.Util_Hash_O__I_NoInit(G__219000055__2_) >> 2 & 15 { case 1: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_95) { var tmp2 any = A_arbace_go_check_types_A_const_95; var tmp3 any; var root_338 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_340 lang.IFn




			if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_339 == nil { tmp3 = ifn_340.Invoke_O__O(arg_341) } else { tmp3 = linked_339.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_338, arg_341) }
//line :153:1
			var tmp4 any = tmp3; var tmp5 any; var root_342 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_344 lang.IFn




			if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_343 == nil { tmp5 = ifn_344.Invoke_O__O(arg_345) } else { tmp5 = linked_343.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_342, arg_345) }
//line :153:1
			return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp4, tmp5) }; case 2: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_96) { var tmp6 any = A_arbace_go_check_types_A_const_96; var tmp7 any; var root_346 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_348 lang.IFn


				if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_347 == nil { tmp7 = ifn_348.Invoke_O__O(arg_349) } else { tmp7 = linked_347.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_346, arg_349) }
//line :153:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7) }; case 3: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_97) { var tmp8 any = A_arbace_go_check_types_A_const_97; var tmp9 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp10 any; var root_350 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_352 lang.IFn



					if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_351 == nil { tmp10 = ifn_352.Invoke_O__O(arg_353) } else { tmp10 = linked_351.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_350, arg_353) }
//line :153:1
					return lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp9, tmp10) }; case 6: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_98) { var tmp11 any = A_arbace_go_check_types_A_const_98; var tmp12 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp13 any; var root_368 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_370 lang.IFn





						if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_369 == nil { tmp13 = ifn_370.Invoke_O__O(arg_371) } else { tmp13 = linked_369.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_368, arg_371) }
//line :153:1
						return lang.Tuple_Create_O_O_O__IPersistentVector(tmp11, tmp12, tmp13) }; case 7: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_100) {







							var root_354 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = A_arbace_go_check_types_A_const_101; var arg_358 any; var root_359 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var arg_363 any; var root_364 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = t__0; if linked_365 == nil { arg_363 = ifn_366.Invoke_O__O(arg_367) } else { arg_363 = linked_365.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_364, arg_367) }; if linked_360 == nil { arg_358 = ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { arg_358 = linked_360.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_359, arg_362, arg_363) }; if linked_355 == nil { return ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { return linked_355.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) } }
//line :153:1
		case 9: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_103) { var tmp14 any = A_arbace_go_check_types_A_const_103; var tmp15 any; var root_372 any = A_arbace_go_check_types_A_const_104.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_374 lang.IFn






			if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var arg_376 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_373 == nil { tmp15 = ifn_374.Invoke_O_O__O(arg_375, arg_376) } else { tmp15 = linked_373.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_372, arg_375, arg_376) }
//line :153:1
			var tmp16 any = tmp15; var tmp17 any; var root_377 any = A_arbace_go_check_types_A_const_104.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_377, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_379 lang.IFn






			if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; var arg_380 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var arg_381 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_378 == nil { tmp17 = ifn_379.Invoke_O_O__O(arg_380, arg_381) } else { tmp17 = linked_378.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_377, arg_380, arg_381) }
//line :153:1
			return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp14, tmp16, tmp17, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(3))) }; case 11: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_87) { var tmp18 any = A_arbace_go_check_types_A_const_87; var tmp19 any; var root_382 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_384 lang.IFn

				if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_383 == nil { tmp19 = ifn_384.Invoke_O__O(arg_385) } else { tmp19 = linked_383.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_382, arg_385) }
//line :153:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp18, tmp19) }; case 13: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_105) { var tmp20 any = A_arbace_go_check_types_A_const_105; var tmp21 any; var root_386 any = A_arbace_go_check_types_A_const_104.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_388 lang.IFn
					if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any; var tmp22 any = A_arbace_go_check_types_ignore_tags_fn__219000056_A_New(); var tmp23 *jrt.Class; var fncls__403 *jrt.Class = A_arbace_go_check_types_ignore_tags_fn__219000056_A_fn_class; if fncls__403 == nil { var fncls__403d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_check_types_ignore_tags_fn__219000056_A_fn_class = fncls__403d; tmp23 = fncls__403d } else { tmp23 = fncls__403 }; arg_389 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_390 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_387 == nil { tmp21 = ifn_388.Invoke_O_O__O(arg_389, arg_390) } else { tmp21 = linked_387.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_386, arg_389, arg_390) }
//line :153:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp20, tmp21) }; default:}; return t__0 } else {
//line :152:1
						return t__0
					} }
func A_arbace_go_check_types_ignore_tags_fn__219000056_A_New() *A_arbace_go_check_types_ignore_tags_fn__219000056_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ignore_tags_fn__219000056_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_go_check_types_ignore_tags_fn__219000056_A) Ctor() {}
//line :154:1
func (t *A_arbace_go_check_types_ignore_tags_fn__219000056_A) Invoke_O_O__O(self, p1__219000054_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_59.GetRawRoot__O()); var tmp2 any = A_arbace_go_check_types_A_const_106; var tmp3 any = A_arbace_go_check_types_A_const_107; var tmp4 any; var root_399 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(p1__219000054_SHARP___1); if linked_400 == nil { tmp4 = ifn_401.Invoke_O__O(arg_402) } else { tmp4 = linked_400.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_399, arg_402) }; return tmp1.Invoke_O_O_O_O_O__O(p1__219000054_SHARP___1, tmp2, nil, tmp3, tmp4) }










func A_arbace_go_check_types_identical_ignore_tags_QMARK__A_New() *A_arbace_go_check_types_identical_ignore_tags_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_identical_ignore_tags_QMARK__A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_go_check_types_identical_ignore_tags_QMARK__A) Ctor() {}
//line :165:1
func (t *A_arbace_go_check_types_identical_ignore_tags_QMARK__A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 any; var root_404 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = x__0; if linked_405 == nil { tmp1 = ifn_406.Invoke_O__O(arg_407) } else { tmp1 = linked_405.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_404, arg_407) }; var tmp2 any = tmp1; var tmp3 any; var root_408 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = y__1; if linked_409 == nil { tmp3 = ifn_410.Invoke_O__O(arg_411) } else { tmp3 = linked_409.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_408, arg_411) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() }





func A_arbace_go_check_types_tset_comparable_QMARK__A_New() *A_arbace_go_check_types_tset_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_comparable_QMARK__A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__A) Ctor() {}
//line :171:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__A) Invoke_O_O_O__O(self, ts__0, seen__1 any) any {


	var tmp1 any = A_arbace_go_check_types_A_const_108; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0)) {
		return A_arbace_go_check_types_A_const_110.Invoke_O__O(ts__0) } else {
//line :174:1
			var and__1927000168__auto____3 any; var root_412 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_414 lang.IFn

			if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0); if linked_413 == nil { and__1927000168__auto____3 = ifn_414.Invoke_O__O(arg_415) } else { and__1927000168__auto____3 = linked_413.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_412, arg_415) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_416 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any; var tmp2 any = A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A_New_O(seen__1); var tmp3 *jrt.Class; var fncls__426 *jrt.Class = A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A_fn_class; if fncls__426 == nil { var fncls__426d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A_fn_class = fncls__426d; tmp3 = fncls__426d } else { tmp3 = fncls__426 }; arg_419 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_420 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0); if linked_417 == nil { return ifn_418.Invoke_O_O__O(arg_419, arg_420) } else { return linked_417.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_416, arg_419, arg_420) } } else { return and__1927000168__auto____3 } } }
//line :176:1
func A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A_New_O(p0 any) *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A{}; t.Ctor_O(p0); return t }
//line :176:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A) Ctor_O(c__seen any) { t.F_seen = c__seen }
//line :176:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A) Invoke_O_O__O(self, p__219000060__1 any) any { var vec__219000062__2 any = p__219000060__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000062__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000062__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_421 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_423 lang.IFn; _ = ___3; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = ty__4; var arg_425 any = t.F_seen; if linked_422 == nil { return ifn_423.Invoke_O_O__O(arg_424, arg_425) } else { return linked_422.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O_O__O(root_421, arg_424, arg_425) } }

func A_arbace_go_check_types_comparable_type_QMARK__A_New() *A_arbace_go_check_types_comparable_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_type_QMARK__A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__A) Ctor() {}
//line :178:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__A) Invoke_O_O_O_O__O(self, t__0, dynamic__1, seen__2 any) any {




	var tmp1 any; var root_427 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = seen__2; var arg_431 any = t__0; if linked_428 == nil { tmp1 = ifn_429.Invoke_O_O__O(arg_430, arg_431) } else { tmp1 = linked_428.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_427, arg_430, arg_431) }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var seen__4 any; var root_432 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_434 lang.IFn

		if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = seen__2; var arg_436 any = t__0; if linked_433 == nil { seen__4 = ifn_434.Invoke_O_O__O(arg_435, arg_436) } else { seen__4 = linked_433.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_432, arg_435, arg_436) }
		var tmp2 any; var root_437 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = t__0; if linked_438 == nil { tmp2 = ifn_439.Invoke_O__O(arg_440) } else { tmp2 = linked_438.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_437, arg_440) }; if jrt.J2g_Truth(tmp2) {
			var tmp3 any; var root_441 any = A_arbace_go_check_types_A_const_114.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any; var root_446 any = A_arbace_go_check_types_A_const_115.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = t__0; if linked_447 == nil { arg_444 = ifn_448.Invoke_O__O(arg_449) } else { arg_444 = linked_447.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_446, arg_449) }; var arg_445 any = seen__4; if linked_442 == nil { tmp3 = ifn_443.Invoke_O_O__O(arg_444, arg_445) } else { tmp3 = linked_442.(*A_arbace_go_check_types_tset_comparable_QMARK__A).Invoke_O_O_O__O(root_441, arg_444, arg_445) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp3)).Ref() } else {
//line :186:1
				var u__5 any; var root_450 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, A_arbace_go_check_types_under_A_fn_class); var ifn_452 lang.IFn

				if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = t__0; if linked_451 == nil { u__5 = ifn_452.Invoke_O__O(arg_453) } else { u__5 = linked_451.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_450, arg_453) }
				var tmp4 any; var root_454 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_456 lang.IFn
				if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = u__5; if linked_455 == nil { tmp4 = ifn_456.Invoke_O__O(arg_457) } else { tmp4 = linked_455.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_454, arg_457) }
//line :189:1
				if jrt.J2g_Truth(tmp4) {
					var root_458 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = u__5; var arg_462 any = A_arbace_go_check_types_A_const_51; if linked_459 == nil { return ifn_460.Invoke_O_O__O(arg_461, arg_462) } else { return linked_459.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_458, arg_461, arg_462) } } else {
//line :189:1
						if A_arbace_go_check_types_A_const_75 != nil { var G__219000068__6_ any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(0))


							switch lang.Util_Hash_O__I_NoInit(G__219000068__6_) >> 4 & 7 { case 0: if any(G__219000068__6_) == any(A_arbace_go_check_types_A_const_97) {



								var root_464 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(2)); var arg_468 any = dynamic__1; var arg_469 any = seen__4; if linked_465 == nil { return ifn_466.Invoke_O_O_O__O(arg_467, arg_468, arg_469) } else { return linked_465.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_464, arg_467, arg_468, arg_469) } }
//line :192:1
							case 1: if any(G__219000068__6_) == any(A_arbace_go_check_types_A_const_98) { return jrt.Boolean_TRUE.Ref() }; case 3: if any(G__219000068__6_) == any(A_arbace_go_check_types_A_const_86) { var or__1927000174__auto____7 any = dynamic__1

								if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var tmp5 any; var root_470 any = A_arbace_go_check_types_A_const_114.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any; var root_475 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = u__5; if linked_476 == nil { arg_473 = ifn_477.Invoke_O__O(arg_478) } else { arg_473 = linked_476.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_475, arg_478) }; var arg_474 any = seen__4; if linked_471 == nil { tmp5 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { tmp5 = linked_471.(*A_arbace_go_check_types_tset_comparable_QMARK__A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp5)).Ref() } }
//line :192:1
							case 6: if any(G__219000068__6_) == any(A_arbace_go_check_types_A_const_87) { return jrt.Boolean_TRUE.Ref() }; case 7: if any(G__219000068__6_) == any(A_arbace_go_check_types_A_const_105) {


								var root_479 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any; var tmp6 any = A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A_New_O_O(seen__4, dynamic__1); var tmp7 *jrt.Class; var fncls__490 *jrt.Class = A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A_fn_class; if fncls__490 == nil { var fncls__490d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A_fn_class = fncls__490d; tmp7 = fncls__490d } else { tmp7 = fncls__490 }; arg_482 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_483 any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(1)); if linked_480 == nil { return ifn_481.Invoke_O_O__O(arg_482, arg_483) } else { return linked_480.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_479, arg_482, arg_483) } }
//line :192:1
							default:}; return jrt.Boolean_FALSE.Ref() } else {
//line :189:1
								return nil
							}
					}
			}
	}
}
func A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A{}; t.Ctor_O_O(p0, p1); return t }
//line :195:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A) Ctor_O_O(c__seen, c__dynamic any) { t.F_seen = c__seen; t.F_dynamic = c__dynamic }
//line :195:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A) Invoke_O_O__O(self, p1__219000067_SHARP___1 any) any { var root_484 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(p1__219000067_SHARP___1); var arg_488 any = t.F_dynamic; var arg_489 any = t.F_seen; if linked_485 == nil { return ifn_486.Invoke_O_O_O__O(arg_487, arg_488, arg_489) } else { return linked_485.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_484, arg_487, arg_488, arg_489) } }



func A_arbace_go_check_types_strictly_comparable_QMARK__A_New() *A_arbace_go_check_types_strictly_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_strictly_comparable_QMARK__A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Ctor() {}
//line :199:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Invoke_O_O_O__O(self, t__0, seen__1 any) any { var root_491 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = t__0; var arg_495 any = jrt.Boolean_FALSE.Ref(); var arg_496 any = seen__1; if linked_492 == nil { return ifn_493.Invoke_O_O_O__O(arg_494, arg_495, arg_496) } else { return linked_492.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_491, arg_494, arg_495, arg_496) } }
//line :199:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_497 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = t__0; var arg_501 any = jrt.Boolean_FALSE.Ref(); var arg_502 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_498 == nil { return ifn_499.Invoke_O_O_O__O(arg_500, arg_501, arg_502) } else { return linked_498.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_497, arg_500, arg_501, arg_502) } }

func A_arbace_go_check_types_comparable_QMARK__A_New() *A_arbace_go_check_types_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_QMARK__A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Ctor() {}
//line :201:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Invoke_O_O_O__O(self, t__0, seen__1 any) any {



	var root_503 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = t__0; var arg_507 any = jrt.Boolean_TRUE.Ref(); var arg_508 any = seen__1; if linked_504 == nil { return ifn_505.Invoke_O_O_O__O(arg_506, arg_507, arg_508) } else { return linked_504.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_503, arg_506, arg_507, arg_508) } }
//line :201:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Invoke_O_O__O(self, t__0 any) any {


	var root_509 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_511 lang.IFn; if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any = t__0; var arg_513 any = jrt.Boolean_TRUE.Ref(); var arg_514 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_510 == nil { return ifn_511.Invoke_O_O_O__O(arg_512, arg_513, arg_514) } else { return linked_510.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_509, arg_512, arg_513, arg_514)
	}
}











func A_arbace_go_check_types_union_QMARK__A_New() *A_arbace_go_check_types_union_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_union_QMARK__A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_go_check_types_union_QMARK__A) Ctor() {}
//line :218:1
func (t *A_arbace_go_check_types_union_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_515 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = t__0; if linked_516 == nil { and__1927000168__auto____2 = ifn_517.Invoke_O__O(arg_518) } else { and__1927000168__auto____2 = linked_516.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_515, arg_518) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_118; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_go_check_types_term_disjoint_QMARK__A_New() *A_arbace_go_check_types_term_disjoint_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_disjoint_QMARK__A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_go_check_types_term_disjoint_QMARK__A) Ctor() {}
//line :220:1
func (t *A_arbace_go_check_types_term_disjoint_QMARK__A) Invoke_O_O_O__O(self, p__219000075__0, p__219000076__1 any) any { var vec__219000077__3 any = p__219000075__0; var xt__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000077__3, lang.RT_IntCast_J__I_NoInit(0), nil); var x__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000077__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__219000080__6 any = p__219000076__1; var yt__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000080__6, lang.RT_IntCast_J__I_NoInit(0), nil); var y__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000080__6, lang.RT_IntCast_J__I_NoInit(1), nil); var root_519 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_521 lang.IFn; if
																linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any; if jrt.J2g_Truth(yt__7) { var root_524 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, A_arbace_go_check_types_under_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = x__5; if linked_525 == nil { arg_522 = ifn_526.Invoke_O__O(arg_527) } else { arg_522 = linked_525.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_524, arg_527) } } else { arg_522 = x__5 }; var arg_523 any; if jrt.J2g_Truth(xt__4) { var root_528 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, A_arbace_go_check_types_under_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = y__8; if linked_529 == nil { arg_523 = ifn_530.Invoke_O__O(arg_531) } else { arg_523 = linked_529.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_528, arg_531) } } else { arg_523 = y__8 }; if linked_520 == nil { return ifn_521.Invoke_O_O__O(arg_522, arg_523) } else { return linked_520.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_519, arg_522, arg_523) } }

func A_arbace_go_check_types_term_union_A_New() *A_arbace_go_check_types_term_union_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_union_A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_go_check_types_term_union_A) Ctor() {}
//line :223:1
func (t *A_arbace_go_check_types_term_union_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	var tmp1 any; var root_532 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_534 lang.IFn
	if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = x__0; var arg_536 any = y__1; if linked_533 == nil { tmp1 = ifn_534.Invoke_O_O__O(arg_535, arg_536) } else { tmp1 = linked_533.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_532, arg_535, arg_536) }
//line :224:1
	if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(x__0, y__1) } else { var tmp2 any; var or__1927000174__auto____3 any; var root_537 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_539 lang.IFn

		if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = x__0; if linked_538 == nil { or__1927000174__auto____3 = ifn_539.Invoke_O__O(arg_540) } else { or__1927000174__auto____3 = linked_538.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_537, arg_540) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_541 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any; var root_545 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = y__1; if linked_546 == nil { arg_544 = ifn_547.Invoke_O__O(arg_548) } else { arg_544 = linked_546.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_545, arg_548) }; if linked_542 == nil { tmp2 = ifn_543.Invoke_O__O(arg_544) } else { tmp2 = linked_542.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_541, arg_544) } }
//line :224:1
		if jrt.J2g_Truth(tmp2) { return lang.Tuple_Create_O__IPersistentVector(x__0) } else { if A_arbace_go_check_types_A_const_75 != nil { return lang.Tuple_Create_O__IPersistentVector(y__1) } else { return nil
		}
		}
	}
}
func A_arbace_go_check_types_term_intersect_A_New() *A_arbace_go_check_types_term_intersect_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_intersect_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_go_check_types_term_intersect_A) Ctor() {}
//line :229:1
func (t *A_arbace_go_check_types_term_intersect_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	var tmp1 any; var root_549 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_551 lang.IFn
	if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = x__0; var arg_553 any = y__1; if linked_550 == nil { tmp1 = ifn_551.Invoke_O_O__O(arg_552, arg_553) } else { tmp1 = linked_550.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_549, arg_552, arg_553) }
//line :230:1
	if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; var or__1927000174__auto____3 any; var root_554 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_556 lang.IFn

		if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any; var root_558 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_560 lang.IFn; if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = x__0; if linked_559 == nil { arg_557 = ifn_560.Invoke_O__O(arg_561) } else { arg_557 = linked_559.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_558, arg_561) }; if linked_555 == nil { or__1927000174__auto____3 = ifn_556.Invoke_O__O(arg_557) } else { or__1927000174__auto____3 = linked_555.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_554, arg_557) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_562 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = y__1; if linked_563 == nil { tmp2 = ifn_564.Invoke_O__O(arg_565) } else { tmp2 = linked_563.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_562, arg_565) } }
//line :230:1
		if jrt.J2g_Truth(tmp2) { return x__0 } else { if A_arbace_go_check_types_A_const_75 != nil { return y__1 } else { return nil
		}
		}
	}
}
func A_arbace_go_check_types_term_includes_QMARK__A_New() *A_arbace_go_check_types_term_includes_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_includes_QMARK__A{}; t.Ctor(); return t }
//line :235:1
func (t *A_arbace_go_check_types_term_includes_QMARK__A) Ctor() {}
//line :235:1
func (t *A_arbace_go_check_types_term_includes_QMARK__A) Invoke_O_O_O__O(self, p__219000086__0, t__1 any) any { var vec__219000087__3 any = p__219000086__0; var tilde__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000087__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000087__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; if jrt.J2g_Truth(tilde__4) { var root_566 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, A_arbace_go_check_types_under_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = t__1; if linked_567 == nil { tmp1 = ifn_568.Invoke_O__O(arg_569) } else { tmp1 = linked_567.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_566, arg_569) } } else { tmp1 = t__1 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(ty__5, tmp1)).Ref() }

func A_arbace_go_check_types_term_subset_QMARK__A_New() *A_arbace_go_check_types_term_subset_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_subset_QMARK__A{}; t.Ctor(); return t }
//line :237:1
func (t *A_arbace_go_check_types_term_subset_QMARK__A) Ctor() {}
//line :237:1
func (t *A_arbace_go_check_types_term_subset_QMARK__A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var and__1927000168__auto____3 any; var root_570 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any; var root_574 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = x__0; var arg_578 any = y__1; if linked_575 == nil { arg_573 = ifn_576.Invoke_O_O__O(arg_577, arg_578) } else { arg_573 = linked_575.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_574, arg_577, arg_578) }; if linked_571 == nil { and__1927000168__auto____3 = ifn_572.Invoke_O__O(arg_573) } else { and__1927000168__auto____3 = linked_571.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_570, arg_573) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var root_579 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any; var root_583 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = x__0; if linked_584 == nil { arg_582 = ifn_585.Invoke_O__O(arg_586) } else { arg_582 = linked_584.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_583, arg_586) }; if linked_580 == nil { or__1927000174__auto____4 = ifn_581.Invoke_O__O(arg_582) } else { or__1927000174__auto____4 = linked_580.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_579, arg_582) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var root_587 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = y__1; if linked_588 == nil { return ifn_589.Invoke_O__O(arg_590) } else { return linked_588.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_587, arg_590) } } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_terms_norm_A_New() *A_arbace_go_check_types_terms_norm_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_norm_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_go_check_types_terms_norm_A) Ctor() {}
//line :239:1
func (t *A_arbace_go_check_types_terms_norm_A) Invoke_O_O__O(self, ts__0 any) any { { var ts__2 any; var root_591 any = A_arbace_go_check_types_A_const_121.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_593 lang.IFn


	if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = ts__0; if linked_592 == nil { ts__2 = ifn_593.Invoke_O__O(arg_594) } else { ts__2 = linked_592.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_591, arg_594) }
//line :239:1
	var n__3 int32 = lang.RT_Count_O__I_NoInit(ts__2); var used__4 any = lang.Numbers_Boolean_array_O__Z1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref()).Ref(); var i__5 int64 = 0; var rl__6 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




		if lang.Util_Equiv_J_J__Z_NoInit(i__5, int64(n__3)) {

			var root_595 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any; var root_600 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = rl__6; if linked_601 == nil { arg_598 = ifn_602.Invoke_O__O(arg_603) } else { arg_598 = linked_601.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_600, arg_603) }; var arg_599 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_124, rl__6)); if linked_596 == nil { return ifn_597.Invoke_O_O__O(arg_598, arg_599) } else { return linked_596.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_595, arg_598, arg_599) } } else {
				if lang.RT_Aget_Z1_I__Z_NoInit(jrt.J2g_CastArray[*jrt.BooleanArray](used__4, jrt.Prim_boolean.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__5)) {
					i__5, rl__6 = lang.Numbers_Inc_J__J_NoInit(i__5), rl__6; continue L1 } else {
//line :247:1
						var xi__7 any; var tmp1 any = A_arbace_go_check_types_terms_norm_fn__219000092_A_New_J_I_O_O(i__5, n__3, used__4, ts__2); var tmp2 *jrt.Class
						var fncls__613 /*line :247:1*/*jrt.Class = A_arbace_go_check_types_terms_norm_fn__219000092_A_fn_class

						if fncls__613 == nil { var fncls__613d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_go_check_types_terms_norm_fn__219000092_A_fn_class = fncls__613d; tmp2 = fncls__613d } else { tmp2 = fncls__613 }; xi__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()







						var tmp3 int64 = lang.Numbers_Inc_J__J_NoInit(i__5); var tmp4 any; var root_614 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = rl__6; var arg_618 any = xi__7; if linked_615 == nil { tmp4 = ifn_616.Invoke_O_O__O(arg_617, arg_618) } else { tmp4 = linked_615.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_614, arg_617, arg_618) }; i__5, rl__6 = tmp3, tmp4; continue L1 } } } }; /*line :239:1*/panic("j2g: unreachable") }









func A_arbace_go_check_types_terms_norm_fn__219000092_A_New_J_I_O_O(p0 int64, p1 int32, p2, p3 any) *A_arbace_go_check_types_terms_norm_fn__219000092_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_norm_fn__219000092_A{}; t.Ctor_J_I_O_O(p0, p1, p2, p3); return t }
//line :249:1
func (t *A_arbace_go_check_types_terms_norm_fn__219000092_A) Ctor_J_I_O_O(c__i int64, c__n int32, c__used, c__ts any) { t.F_i = c__i; t.F_n = c__n; t.F_used = c__used; t.F_ts = c__ts }
//line :249:1
func (t *A_arbace_go_check_types_terms_norm_fn__219000092_A) Invoke_O__O(self any) any { { var j__1 int64 = lang.Numbers_Inc_J__J_NoInit(t.F_i); var tmp1 any = t.F_ts; var xi__2 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(t.F_i)); L1: for {
											if lang.Util_Equiv_J_J__Z_NoInit(j__1, int64(t.F_n)) { return xi__2 } else { var tmp2 *jrt.BooleanArray = jrt.J2g_CastArray[*jrt.BooleanArray](t.F_used, jrt.Prim_boolean.ArrayClass()); if lang.RT_Aget_Z1_I__Z_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(j__1)) {

		j__1, xi__2 = lang.Numbers_Inc_J__J_NoInit(j__1), xi__2; continue L1 } else {
//line :250:1
			if A_arbace_go_check_types_A_const_75 != nil { var u__3 any; var root_604 any = A_arbace_go_check_types_A_const_125.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_604, A_arbace_go_check_types_term_union_A_fn_class); var ifn_606 lang.IFn


				if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = xi__2; var tmp3 any = t.F_ts; var arg_608 any = lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(j__1)); if linked_605 == nil { u__3 = ifn_606.Invoke_O_O__O(arg_607, arg_608) } else { u__3 = linked_605.(*A_arbace_go_check_types_term_union_A).Invoke_O_O_O__O(root_604, arg_607, arg_608) }
				if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(u__3))) {
					var tmp4 *jrt.BooleanArray = jrt.J2g_CastArray[*jrt.BooleanArray](t.F_used, jrt.Prim_boolean.ArrayClass()); jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_Aset_Z1_I_Z__Z_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(j__1), jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z())); var tmp5 int64 = lang.Numbers_Inc_J__J_NoInit(j__1); var tmp6 any; var root_609 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = u__3; if linked_610 == nil { tmp6 = ifn_611.Invoke_O__O(arg_612) } else { tmp6 = linked_610.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_609, arg_612) }; j__1, xi__2 = tmp5, tmp6; continue L1 } else {
						j__1, xi__2 = lang.Numbers_Inc_J__J_NoInit(j__1), xi__2; continue L1 } } else {
//line :250:1
							return nil } } } } }; /*line :249:1*/panic("j2g: unreachable") }









func A_arbace_go_check_types_terms_union_A_New() *A_arbace_go_check_types_terms_union_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_union_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_go_check_types_terms_union_A) Ctor() {}
//line :259:1
func (t *A_arbace_go_check_types_terms_union_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, x__0); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, y__1) }; if tmp1 { return A_arbace_go_check_types_A_const_108 } else { var root_619 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, A_arbace_go_check_types_terms_norm_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any; var root_623 any = A_arbace_go_check_types_A_const_127.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_623, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_625 lang.IFn; if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = x__0; var arg_627 any = y__1; if linked_624 == nil { arg_622 = ifn_625.Invoke_O_O__O(arg_626, arg_627) } else { arg_622 = linked_624.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_623, arg_626, arg_627) }; if linked_620 == nil { return ifn_621.Invoke_O__O(arg_622) } else { return linked_620.(*A_arbace_go_check_types_terms_norm_A).Invoke_O_O__O(root_619, arg_622) } } }

func A_arbace_go_check_types_terms_intersect_A_New() *A_arbace_go_check_types_terms_intersect_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_go_check_types_terms_intersect_A) Ctor() {}
//line :261:1
func (t *A_arbace_go_check_types_terms_intersect_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, x__0) { return y__1 } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, y__1) { return x__0 } else { var tmp1 any; var or__1927000174__auto____3 any; var root_628 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_630 lang.IFn


		if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = x__0; if linked_629 == nil { or__1927000174__auto____3 = ifn_630.Invoke_O__O(arg_631) } else { or__1927000174__auto____3 = linked_629.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_628, arg_631) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_632 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_634 lang.IFn; if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = y__1; if linked_633 == nil { tmp1 = ifn_634.Invoke_O__O(arg_635) } else { tmp1 = linked_633.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_632, arg_635) } }
//line :262:1
		if jrt.J2g_Truth(tmp1) { return lang.PersistentHashSet_EMPTY.Ref() } else { if A_arbace_go_check_types_A_const_75 != nil {



			var root_636 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, A_arbace_go_check_types_terms_norm_A_fn_class); var ifn_638 lang.IFn; if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any; var iter__1927001039__auto____3 any; var tmp2 any = A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_A_New_O(y__1); var tmp3 *jrt.Class; var fncls__739 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_A_fn_class; if fncls__739 == nil { var fncls__739d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_A_fn_class = fncls__739d; tmp3 = fncls__739d } else { tmp3 = fncls__739 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); arg_639 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(x__0); if linked_637 == nil { return ifn_638.Invoke_O__O(arg_639) } else { return linked_637.(*A_arbace_go_check_types_terms_norm_A).Invoke_O_O__O(root_636, arg_639) } } else {
//line :262:1
				return nil
			}
		}
	} } }
func A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_A_New_O(p0 any) *A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_A{}; t.Ctor_O(p0); return t }
//line :266:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_A) Ctor_O(c__y any) { t.F_y = c__y }
//line :266:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_A) Invoke_O_O__O(self, s__219000097__1 any) any { var tmp1 any = A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_A_New_O_O_O(s__219000097__1, t.F_y, self); var tmp2 *jrt.Class; var fncls__738 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_A_fn_class; if fncls__738 == nil { var fncls__738d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_A_fn_class = fncls__738d; tmp2 = fncls__738d } else { tmp2 = fncls__738 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :266:1
func A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :266:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_A) Ctor_O_O_O(c__s__219000097, c__y, c__iter__219000096 any) { t.F_s__219000097 = c__s__219000097; t.F_y = c__y; t.F_iter__219000096 = c__iter__219000096 }
//line :266:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_A) Invoke_O__O(self any) any { { var s__219000097__1 any; var t_ any = t.F_s__219000097; t.F_s__219000097 = nil; s__219000097__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_640 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = s__219000097__1; if linked_641 == nil { temp__1927000414__auto____2 = ifn_642.Invoke_O__O(arg_643) } else { temp__1927000414__auto____2 = linked_641.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_640, arg_643) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var a__4 any; var root_644 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = xs__1927001018__auto____3; if linked_645 == nil { a__4 = ifn_646.Invoke_O__O(arg_647) } else { a__4 = linked_645.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_644, arg_647) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_A_New_O(a__4); var tmp2 *jrt.Class; var fncls__720 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_A_fn_class; if fncls__720 == nil { var fncls__720d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_A_fn_class = fncls__720d; tmp2 = fncls__720d } else { tmp2 = fncls__720 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_721 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(t.F_y); if linked_722 == nil { fs__1927001036__auto____6 = ifn_723.Invoke_O__O(arg_724) } else { fs__1927001036__auto____6 = linked_722.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_721, arg_724) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_725 any = A_arbace_go_check_types_A_const_127.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = fs__1927001036__auto____6; var arg_729 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__219000096); var tmp4 any; var root_730 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any = s__219000097__1; if linked_731 == nil { tmp4 = ifn_732.Invoke_O__O(arg_733) } else { tmp4 = linked_731.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_730, arg_733) }; arg_729 = tmp3.Invoke_O__O(tmp4); if linked_726 == nil { return ifn_727.Invoke_O_O__O(arg_728, arg_729) } else { return linked_726.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_725, arg_728, arg_729) } } else { var tmp5 any; var root_734 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any = s__219000097__1; if linked_735 == nil { tmp5 = ifn_736.Invoke_O__O(arg_737) } else { tmp5 = linked_735.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_734, arg_737) }; s__219000097__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :266:1
func A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_A_New_O(p0 any) *A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_A{}; t.Ctor_O(p0); return t }
//line :266:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_A) Ctor_O(c__a any) { t.F_a = c__a }
//line :266:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_A) Invoke_O_O__O(self, s__219000099__1 any) any { var tmp1 any = A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_A_New_O_O_O(self, s__219000099__1, t.F_a); var tmp2 *jrt.Class; var fncls__719 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_A_fn_class; if fncls__719 == nil { var fncls__719d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_A_fn_class = fncls__719d; tmp2 = fncls__719d } else { tmp2 = fncls__719 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :266:1
func A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :266:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_A) Ctor_O_O_O(c__iter__219000098, c__s__219000099, c__a any) { t.F_iter__219000098 = c__iter__219000098; t.F_s__219000099 = c__s__219000099; t.F_a = c__a }
//line :266:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_A) Invoke_O__O(self any) any { { var s__219000099__1 any; var t_ any = t.F_s__219000099; t.F_s__219000099 = nil; s__219000099__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_648 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = s__219000099__1; if linked_649 == nil { temp__1927000414__auto____2 = ifn_650.Invoke_O__O(arg_651) } else { temp__1927000414__auto____2 = linked_649.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_648, arg_651) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000099__3 any = temp__1927000414__auto____2; var tmp1 any; var root_652 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = s__219000099__3; if linked_653 == nil { tmp1 = ifn_654.Invoke_O__O(arg_655) } else { tmp1 = linked_653.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_652, arg_655) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_656 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = s__219000099__3; if linked_657 == nil { c__1927001037__auto____4 = ifn_658.Invoke_O__O(arg_659) } else { c__1927001037__auto____4 = linked_657.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_656, arg_659) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000101__6 any; var root_660 any = A_arbace_go_check_types_A_const_130.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_661 == nil { b__219000101__6 = ifn_662.Invoke_O__O(arg_663) } else { b__219000101__6 = linked_661.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_660, arg_663) }; var tmp2 any = A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_fn__219000106_A_New_O_I_O_O(b__219000101__6, size__1927001038__auto____5, t.F_a, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__674 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_fn__219000106_A_fn_class; if fncls__674 == nil { var fncls__674d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_fn__219000106_A_fn_class = fncls__674d; tmp3 = fncls__674d } else { tmp3 = fncls__674 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_675 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any; var root_680 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any = b__219000101__6; if linked_681 == nil { arg_678 = ifn_682.Invoke_O__O(arg_683) } else { arg_678 = linked_681.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_680, arg_683) }; var arg_679 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000098); var tmp5 any; var root_684 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = s__219000099__3; if linked_685 == nil { tmp5 = ifn_686.Invoke_O__O(arg_687) } else { tmp5 = linked_685.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_684, arg_687) }; arg_679 = tmp4.Invoke_O__O(tmp5); if linked_676 == nil { return ifn_677.Invoke_O_O__O(arg_678, arg_679) } else { return linked_676.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_675, arg_678, arg_679) } } else { var root_688 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any; var root_693 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = b__219000101__6; if linked_694 == nil { arg_691 = ifn_695.Invoke_O__O(arg_696) } else { arg_691 = linked_694.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_693, arg_696) }; var arg_692 any; if linked_689 == nil { return ifn_690.Invoke_O_O__O(arg_691, arg_692) } else { return linked_689.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_688, arg_691, arg_692) } } } else { var b__4 any; var root_697 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = s__219000099__3; if linked_698 == nil { b__4 = ifn_699.Invoke_O__O(arg_700) } else { b__4 = linked_698.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_697, arg_700) }; var r__5 any; var root_701 any = A_arbace_go_check_types_A_const_131.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, A_arbace_go_check_types_term_intersect_A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = t.F_a; var arg_705 any = b__4; if linked_702 == nil { r__5 = ifn_703.Invoke_O_O__O(arg_704, arg_705) } else { r__5 = linked_702.(*A_arbace_go_check_types_term_intersect_A).Invoke_O_O_O__O(root_701, arg_704, arg_705) }; if jrt.J2g_Truth(r__5) { var root_706 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = r__5; var arg_710 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__219000098); var tmp7 any; var root_711 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = s__219000099__3; if linked_712 == nil { tmp7 = ifn_713.Invoke_O__O(arg_714) } else { tmp7 = linked_712.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_711, arg_714) }; arg_710 = tmp6.Invoke_O__O(tmp7); if linked_707 == nil { return ifn_708.Invoke_O_O__O(arg_709, arg_710) } else { return linked_707.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_706, arg_709, arg_710) } } else { var tmp8 any; var root_715 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = s__219000099__3; if linked_716 == nil { tmp8 = ifn_717.Invoke_O__O(arg_718) } else { tmp8 = linked_716.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_715, arg_718) }; s__219000099__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :266:1
func A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_fn__219000106_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_fn__219000106_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_fn__219000106_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :266:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_fn__219000106_A) Ctor_O_I_O_O(c__b__219000101 any, c__size__1927001038__auto__ int32, c__a, c__c__1927001037__auto__ any) { t.F_b__219000101 = c__b__219000101; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_a = c__a; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :266:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_fn__219000106_A) Invoke_O__O(self any) any { { var i__219000100__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000100__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000100__1)); var r__3 any; var root_664 any = A_arbace_go_check_types_A_const_131.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, A_arbace_go_check_types_term_intersect_A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = t.F_a; var arg_668 any = b__2; if linked_665 == nil { r__3 = ifn_666.Invoke_O_O__O(arg_667, arg_668) } else { r__3 = linked_665.(*A_arbace_go_check_types_term_intersect_A).Invoke_O_O_O__O(root_664, arg_667, arg_668) }; if jrt.J2g_Truth(r__3) { var root_669 any = A_arbace_go_check_types_A_const_132.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = t.F_b__219000101; var arg_673 any = r__3; if linked_670 == nil { ifn_671.Invoke_O_O__O(arg_672, arg_673) } else { linked_670.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_669, arg_672, arg_673) }; i__219000100__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000100__1); continue L1 } else { i__219000100__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000100__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_types_terms_includes_QMARK__A_New() *A_arbace_go_check_types_terms_includes_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_includes_QMARK__A{}; t.Ctor(); return t }
//line :268:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__A) Ctor() {}
//line :268:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__A) Invoke_O_O_O__O(self, xl__0, t__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, xl__0); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp1 any; var root_740 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_742 lang.IFn; if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any; var tmp2 any = A_arbace_go_check_types_terms_includes_QMARK__fn__219000114_A_New_O(t__1); var tmp3 *jrt.Class; var fncls__750 *jrt.Class = A_arbace_go_check_types_terms_includes_QMARK__fn__219000114_A_fn_class; if fncls__750 == nil { var fncls__750d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_go_check_types_terms_includes_QMARK__fn__219000114_A_fn_class = fncls__750d; tmp3 = fncls__750d } else { tmp3 = fncls__750 }; arg_743 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_744 any = xl__0; if linked_741 == nil { tmp1 = ifn_742.Invoke_O_O__O(arg_743, arg_744) } else { tmp1 = linked_741.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_740, arg_743, arg_744) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } }
//line :268:1
func A_arbace_go_check_types_terms_includes_QMARK__fn__219000114_A_New_O(p0 any) *A_arbace_go_check_types_terms_includes_QMARK__fn__219000114_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_includes_QMARK__fn__219000114_A{}; t.Ctor_O(p0); return t }
//line :268:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__fn__219000114_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :268:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__fn__219000114_A) Invoke_O_O__O(self, p1__219000113_SHARP___1 any) any { var root_745 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, A_arbace_go_check_types_term_includes_QMARK__A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any = p1__219000113_SHARP___1; var arg_749 any = t.F_t; if linked_746 == nil { return ifn_747.Invoke_O_O__O(arg_748, arg_749) } else { return linked_746.(*A_arbace_go_check_types_term_includes_QMARK__A).Invoke_O_O_O__O(root_745, arg_748, arg_749) } }

func A_arbace_go_check_types_terms_superset_of_QMARK__A_New() *A_arbace_go_check_types_terms_superset_of_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_superset_of_QMARK__A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__A) Ctor() {}
//line :270:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__A) Invoke_O_O_O__O(self, xl__0, y__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, xl__0); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp1 any; var root_751 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any; var tmp2 any = A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000118_A_New_O(y__1); var tmp3 *jrt.Class; var fncls__761 *jrt.Class = A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000118_A_fn_class; if fncls__761 == nil { var fncls__761d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000118_A_fn_class = fncls__761d; tmp3 = fncls__761d } else { tmp3 = fncls__761 }; arg_754 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_755 any = xl__0; if linked_752 == nil { tmp1 = ifn_753.Invoke_O_O__O(arg_754, arg_755) } else { tmp1 = linked_752.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_751, arg_754, arg_755) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } }
//line :270:1
func A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000118_A_New_O(p0 any) *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000118_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000118_A{}; t.Ctor_O(p0); return t }
//line :270:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000118_A) Ctor_O(c__y any) { t.F_y = c__y }
//line :270:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000118_A) Invoke_O_O__O(self, p1__219000117_SHARP___1 any) any { var root_756 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, A_arbace_go_check_types_term_subset_QMARK__A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = t.F_y; var arg_760 any = p1__219000117_SHARP___1; if linked_757 == nil { return ifn_758.Invoke_O_O__O(arg_759, arg_760) } else { return linked_757.(*A_arbace_go_check_types_term_subset_QMARK__A).Invoke_O_O_O__O(root_756, arg_759, arg_760) } }

func A_arbace_go_check_types_terms_subset_QMARK__A_New() *A_arbace_go_check_types_terms_subset_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_subset_QMARK__A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__A) Ctor() {}
//line :272:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__A) Invoke_O_O_O__O(self, xl__0, yl__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, yl__1) { return jrt.Boolean_TRUE.Ref() } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, xl__0) { return jrt.Boolean_FALSE.Ref() } else { var tmp1 any; var root_762 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_764 lang.IFn


		if linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = yl__1; if linked_763 == nil { tmp1 = ifn_764.Invoke_O__O(arg_765) } else { tmp1 = linked_763.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_762, arg_765) }
//line :275:1
		if jrt.J2g_Truth(tmp1) {


			var root_766 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_768 lang.IFn; if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = xl__0; if linked_767 == nil { return ifn_768.Invoke_O__O(arg_769) } else { return linked_767.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_766, arg_769) } } else {
//line :275:1
				if A_arbace_go_check_types_A_const_75 != nil {



					var root_770 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any; var tmp2 any = A_arbace_go_check_types_terms_subset_QMARK__fn__219000122_A_New_O(yl__1); var tmp3 *jrt.Class; var fncls__780 *jrt.Class = A_arbace_go_check_types_terms_subset_QMARK__fn__219000122_A_fn_class; if fncls__780 == nil { var fncls__780d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_go_check_types_terms_subset_QMARK__fn__219000122_A_fn_class = fncls__780d; tmp3 = fncls__780d } else { tmp3 = fncls__780 }; arg_773 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_774 any = xl__0; if linked_771 == nil { return ifn_772.Invoke_O_O__O(arg_773, arg_774) } else { return linked_771.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_770, arg_773, arg_774) } } else {
//line :275:1
						return nil
					}
			}
	} } }
func A_arbace_go_check_types_terms_subset_QMARK__fn__219000122_A_New_O(p0 any) *A_arbace_go_check_types_terms_subset_QMARK__fn__219000122_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_subset_QMARK__fn__219000122_A{}; t.Ctor_O(p0); return t }
//line :279:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__fn__219000122_A) Ctor_O(c__yl any) { t.F_yl = c__yl }
//line :279:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__fn__219000122_A) Invoke_O_O__O(self, p1__219000121_SHARP___1 any) any { var root_775 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, A_arbace_go_check_types_terms_superset_of_QMARK__A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any = t.F_yl; var arg_779 any = p1__219000121_SHARP___1; if linked_776 == nil { return ifn_777.Invoke_O_O__O(arg_778, arg_779) } else { return linked_776.(*A_arbace_go_check_types_terms_superset_of_QMARK__A).Invoke_O_O_O__O(root_775, arg_778, arg_779) } }

func A_arbace_go_check_types_make_tset_A_New() *A_arbace_go_check_types_make_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_make_tset_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_go_check_types_make_tset_A) Ctor() {}
//line :281:1
func (t *A_arbace_go_check_types_make_tset_A) Invoke_O_O_O__O(self, terms__0, comparable__1 any) any {


	var tmp1 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, terms__0); if and__1927000168__auto____3 { var root_781 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = comparable__1; if linked_782 == nil { tmp1 = ifn_783.Invoke_O__O(arg_784) } else { tmp1 = linked_782.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_781, arg_784) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any = A_arbace_go_check_types_A_const_109; var tmp3 any = A_arbace_go_check_types_A_const_110; var tmp4 any; var and__1927000168__auto____3_2 any = comparable__1; if jrt.J2g_Truth(and__1927000168__auto____3_2) { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, terms__0)).Ref() } else { tmp4 = and__1927000168__auto____3_2 }; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, terms__0, tmp3, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp4)).Ref()))
	} }
func A_arbace_go_check_types_iface_tset_A_New() *A_arbace_go_check_types_iface_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_iface_tset_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_go_check_types_iface_tset_A) Ctor() {}
//line :286:1
func (t *A_arbace_go_check_types_iface_tset_A) Invoke_O_O__O(self, u__0 any) any { var ts__2 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(2)); var tmp1 any = A_arbace_go_check_types_A_const_62; var tmp2 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp3 any = A_arbace_go_check_types_A_const_109; var tmp4 any; var tmp5 any; var root_785 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_787 lang.IFn; if





	linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = ts__2; if linked_786 == nil { tmp5 = ifn_787.Invoke_O__O(arg_788) } else { tmp5 = linked_786.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_785, arg_788) }; if jrt.J2g_Truth(tmp5) { tmp4 = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__2) } else { tmp4 = A_arbace_go_check_types_A_const_108 }; var tmp6 any = tmp4; var tmp7 any = A_arbace_go_check_types_A_const_110; var tmp8 any; var and__1927000168__auto____3 any; var root_789 any = /*line :286:1*/A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_791 lang.IFn; if






	linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = ts__2; if linked_790 == nil { and__1927000168__auto____3 = ifn_791.Invoke_O__O(arg_792) } else { and__1927000168__auto____3 = linked_790.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_789, arg_792) }; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp8 = A_arbace_go_check_types_A_const_110.Invoke_O__O(ts__2) } else { tmp8 = and__1927000168__auto____3 }; return /*line :286:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp6, tmp7, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp8)).Ref())) }








func A_arbace_go_check_types_has_terms_QMARK__A_New() *A_arbace_go_check_types_has_terms_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_terms_QMARK__A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_go_check_types_has_terms_QMARK__A) Ctor() {}
//line :295:1
func (t *A_arbace_go_check_types_has_terms_QMARK__A) Invoke_O_O__O(self, ts__0 any) any { var terms__2 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0); var and__1927000168__auto____3 any; var root_793 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_793, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_795 lang.IFn; if


	linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = A_arbace_go_check_types_A_const_108; var arg_797 any = terms__2; if linked_794 == nil { and__1927000168__auto____3 = ifn_795.Invoke_O_O__O(arg_796, arg_797) } else { and__1927000168__auto____3 = linked_794.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_793, arg_796, arg_797) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_798 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = terms__2; if linked_799 == nil { return ifn_800.Invoke_O__O(arg_801) } else { return linked_799.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_798, arg_801) } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_tset_empty_QMARK__A_New() *A_arbace_go_check_types_tset_empty_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_empty_QMARK__A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_go_check_types_tset_empty_QMARK__A) Ctor() {}
//line :300:1
func (t *A_arbace_go_check_types_tset_empty_QMARK__A) Invoke_O_O__O(self, ts__0 any) any { var and__1927000168__auto____2 any; var root_802 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = A_arbace_go_check_types_A_const_108; var arg_806 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0); if linked_803 == nil { and__1927000168__auto____2 = ifn_804.Invoke_O_O__O(arg_805, arg_806) } else { and__1927000168__auto____2 = linked_803.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_802, arg_805, arg_806) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_807 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0); if linked_808 == nil { return ifn_809.Invoke_O__O(arg_810) } else { return linked_808.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_807, arg_810) } } else { return and__1927000168__auto____2 } }

func A_arbace_go_check_types_method_set_iface_QMARK__A_New() *A_arbace_go_check_types_method_set_iface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_method_set_iface_QMARK__A{}; t.Ctor(); return t }
//line :302:1
func (t *A_arbace_go_check_types_method_set_iface_QMARK__A) Ctor() {}
//line :302:1
func (t *A_arbace_go_check_types_method_set_iface_QMARK__A) Invoke_O_O__O(self, u__0 any) any {



	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref()
}
func A_arbace_go_check_types_bound_iface_A_New() *A_arbace_go_check_types_bound_iface_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_bound_iface_A{}; t.Ctor(); return t }
//line :308:1
func (t *A_arbace_go_check_types_bound_iface_A) Ctor() {}
//line :308:1
func (t *A_arbace_go_check_types_bound_iface_A) Invoke_O_O__O(self, b__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any = b__0; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_811 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_811, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_813 lang.IFn; if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any = A_arbace_go_check_types_A_const_67; var arg_815 any = b__0; if linked_812 == nil { tmp1 = ifn_813.Invoke_O_O__O(arg_814, arg_815) } else { tmp1 = linked_812.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_811, arg_814, arg_815) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var u__2 any; var root_816 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, A_arbace_go_check_types_under_A_fn_class); var ifn_818 lang.IFn
		if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = b__0; if linked_817 == nil { u__2 = ifn_818.Invoke_O__O(arg_819) } else { u__2 = linked_817.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_816, arg_819) }
		if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_67, u__2) { return nil } else { var tmp2 any; var and__1927000168__auto____3 any; var root_820 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_822 lang.IFn

			if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any = u__2; if linked_821 == nil { and__1927000168__auto____3 = ifn_822.Invoke_O__O(arg_823) } else { and__1927000168__auto____3 = linked_821.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_820, arg_823) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_go_check_types_A_const_86; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :314:1
			if jrt.J2g_Truth(tmp2) { return u__2 } else { var tmp4 any; var root_824 any = A_arbace_go_check_types_A_const_142.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_824, A_arbace_go_check_types_union_QMARK__A_fn_class); var ifn_826 lang.IFn


				if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = u__2; if linked_825 == nil { tmp4 = ifn_826.Invoke_O__O(arg_827) } else { tmp4 = linked_825.(*A_arbace_go_check_types_union_QMARK__A).Invoke_O_O__O(root_824, arg_827) }
//line :314:1
				if jrt.J2g_Truth(tmp4) { var tmp5 any = A_arbace_go_check_types_A_const_86; var tmp6 any = lang.PersistentVector_EMPTY.Ref(); var tmp7 any; var root_828 any = A_arbace_go_check_types_A_const_143.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, A_arbace_go_check_types_make_tset_A_fn_class); var ifn_830 lang.IFn


					if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); var arg_832 any = jrt.Boolean_FALSE.Ref(); if linked_829 == nil { tmp7 = ifn_830.Invoke_O_O__O(arg_831, arg_832) } else { tmp7 = linked_829.(*A_arbace_go_check_types_make_tset_A).Invoke_O_O_O__O(root_828, arg_831, arg_832) }
//line :314:1
					return lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, tmp7) } else { if A_arbace_go_check_types_A_const_75 != nil { var tmp8 any = A_arbace_go_check_types_A_const_86; var tmp9 any = lang.PersistentVector_EMPTY.Ref(); var tmp10 any; var root_833 any = A_arbace_go_check_types_A_const_143.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, A_arbace_go_check_types_make_tset_A_fn_class); var ifn_835 lang.IFn



						if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(jrt.Boolean_FALSE.Ref(), b__0))); var arg_837 any = jrt.Boolean_FALSE.Ref(); if linked_834 == nil { tmp10 = ifn_835.Invoke_O_O__O(arg_836, arg_837) } else { tmp10 = linked_834.(*A_arbace_go_check_types_make_tset_A).Invoke_O_O_O__O(root_833, arg_836, arg_837) }
//line :314:1
						return lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp9, tmp10) } else { return nil } } } } } else {
//line :312:1
							return nil
						}
}





func A_arbace_go_check_types_tparam_iface_A_New() *A_arbace_go_check_types_tparam_iface_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_iface_A{}; t.Ctor(); return t }
//line :320:1
func (t *A_arbace_go_check_types_tparam_iface_A) Ctor() {}
//line :320:1
func (t *A_arbace_go_check_types_tparam_iface_A) Invoke_O_O__O(self, tp__0 any) any { var i__2 any; var root_838 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, A_arbace_go_check_types_info_A_fn_class); var ifn_840 lang.IFn; if


	linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any = tp__0; if linked_839 == nil { i__2 = ifn_840.Invoke_O__O(arg_841) } else { i__2 = linked_839.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_838, arg_841) }; var or__1927000174__auto____3 any = /*line :320:1*/A_arbace_go_check_types_A_const_144.Invoke_O__O(i__2); if



	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000408__auto____4 any; var root_842 any = A_arbace_go_check_types_A_const_145.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, A_arbace_go_check_types_bound_iface_A_fn_class); var ifn_844 lang.IFn
		if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any = A_arbace_go_check_types_A_const_146.Invoke_O__O(i__2); if linked_843 == nil { temp__1927000408__auto____4 = ifn_844.Invoke_O__O(arg_845) } else { temp__1927000408__auto____4 = linked_843.(*A_arbace_go_check_types_bound_iface_A).Invoke_O_O__O(root_842, arg_845) }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var r__5 any = temp__1927000408__auto____4
			lang.IFn_Cast(A_arbace_go_check_types_A_const_147.GetRawRoot__O()).Invoke_O_O_O_O__O(tp__0, A_arbace_go_check_types_A_const_59.GetRawRoot__O(), A_arbace_go_check_types_A_const_144, r__5)
//line :325:1
			return r__5 } else { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_86, lang.PersistentVector_EMPTY.Ref(), nil) } } }



func A_arbace_go_check_types_tparam_tset_A_New() *A_arbace_go_check_types_tparam_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_tset_A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_go_check_types_tparam_tset_A) Ctor() {}
//line :329:1
func (t *A_arbace_go_check_types_tparam_tset_A) Invoke_O_O__O(self, tp__0 any) any { var root_853 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any; var root_857 any = A_arbace_go_check_types_A_const_74.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, A_arbace_go_check_types_tparam_iface_A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = tp__0; if linked_858 == nil { arg_856 = ifn_859.Invoke_O__O(arg_860) } else { arg_856 = linked_858.(*A_arbace_go_check_types_tparam_iface_A).Invoke_O_O__O(root_857, arg_860) }; if linked_854 == nil { return ifn_855.Invoke_O__O(arg_856) } else { return linked_854.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_853, arg_856) } }

func A_arbace_go_check_types_typeset_pairs_A_New() *A_arbace_go_check_types_typeset_pairs_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_go_check_types_typeset_pairs_A) Ctor() {}
//line :331:1
func (t *A_arbace_go_check_types_typeset_pairs_A) Invoke_O_O__O(self, t__0 any) any {



	var tmp1 any; var root_861 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = t__0; if linked_862 == nil { tmp1 = ifn_863.Invoke_O__O(arg_864) } else { tmp1 = linked_862.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_861, arg_864) }; if jrt.J2g_Truth(tmp1) { var ts__2 any; var root_865 any = A_arbace_go_check_types_A_const_115.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_867 lang.IFn
		if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = t__0; if linked_866 == nil { ts__2 = ifn_867.Invoke_O__O(arg_868) } else { ts__2 = linked_866.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_865, arg_868) }
		var tmp2 any; var root_869 any = A_arbace_go_check_types_A_const_148.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = ts__2; if linked_870 == nil { tmp2 = ifn_871.Invoke_O__O(arg_872) } else { tmp2 = linked_870.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_869, arg_872) }; if jrt.J2g_Truth(tmp2) { var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_A_New(); var tmp4 *jrt.Class; var fncls__939 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_A_fn_class
			if fncls__939 == nil { var fncls__939d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_A_fn_class = fncls__939d; tmp4 = fncls__939d } else { tmp4 = fncls__939 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); return lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__2)) } else {
//line :337:1
				return A_arbace_go_check_types_A_const_149 } } else {
//line :335:1
					var tmp5 any; var root_940 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, A_arbace_go_check_types_under_A_fn_class); var ifn_942 lang.IFn




					if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = t__0; if linked_941 == nil { tmp5 = ifn_942.Invoke_O__O(arg_943) } else { tmp5 = linked_941.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_940, arg_943) }
//line :335:1
					return lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(t__0, tmp5))
				}
}
func A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_A_New() *A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_A{}; t.Ctor(); return t }
//line :338:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_A) Ctor() {}
//line :338:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_A) Invoke_O_O__O(self, s__219000134__1 any) any { var tmp1 any = A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_A_New_O_O(self, s__219000134__1); var tmp2 *jrt.Class; var fncls__938 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_A_fn_class; if fncls__938 == nil { var fncls__938d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_A_fn_class = fncls__938d; tmp2 = fncls__938d } else { tmp2 = fncls__938 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :338:1
func A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_A{}; t.Ctor_O_O(p0, p1); return t }
//line :338:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_A) Ctor_O_O(c__iter__219000133, c__s__219000134 any) { t.F_iter__219000133 = c__iter__219000133; t.F_s__219000134 = c__s__219000134 }
//line :338:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_A) Invoke_O__O(self any) any { { var s__219000134__1 any; var t_ any = t.F_s__219000134; t.F_s__219000134 = nil; s__219000134__1 = t_; for { var temp__1927000414__auto____2 any; var root_873 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = s__219000134__1; if linked_874 == nil { temp__1927000414__auto____2 = ifn_875.Invoke_O__O(arg_876) } else { temp__1927000414__auto____2 = linked_874.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_873, arg_876) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000134__3 any = temp__1927000414__auto____2; var tmp1 any; var root_877 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_879 lang.IFn; if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = s__219000134__3; if linked_878 == nil { tmp1 = ifn_879.Invoke_O__O(arg_880) } else { tmp1 = linked_878.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_877, arg_880) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_881 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = s__219000134__3; if linked_882 == nil { c__1927001037__auto____4 = ifn_883.Invoke_O__O(arg_884) } else { c__1927001037__auto____4 = linked_882.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_881, arg_884) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000136__6 any; var root_885 any = A_arbace_go_check_types_A_const_130.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_886 == nil { b__219000136__6 = ifn_887.Invoke_O__O(arg_888) } else { b__219000136__6 = linked_886.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_885, arg_888) }; var tmp2 any = A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_fn__219000139_A_New_O_I_O(b__219000136__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__898 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_fn__219000139_A_fn_class; if fncls__898 == nil { var fncls__898d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_fn__219000139_A_fn_class = fncls__898d; tmp3 = fncls__898d } else { tmp3 = fncls__898 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_899 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any; var root_904 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = b__219000136__6; if linked_905 == nil { arg_902 = ifn_906.Invoke_O__O(arg_907) } else { arg_902 = linked_905.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_904, arg_907) }; var arg_903 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000133); var tmp5 any; var root_908 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = s__219000134__3; if linked_909 == nil { tmp5 = ifn_910.Invoke_O__O(arg_911) } else { tmp5 = linked_909.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_908, arg_911) }; arg_903 = tmp4.Invoke_O__O(tmp5); if linked_900 == nil { return ifn_901.Invoke_O_O__O(arg_902, arg_903) } else { return linked_900.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_899, arg_902, arg_903) } } else { var root_912 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_912, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_914 lang.IFn; if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any; var root_917 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_919 lang.IFn; if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any = b__219000136__6; if linked_918 == nil { arg_915 = ifn_919.Invoke_O__O(arg_920) } else { arg_915 = linked_918.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_917, arg_920) }; var arg_916 any; if linked_913 == nil { return ifn_914.Invoke_O_O__O(arg_915, arg_916) } else { return linked_913.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_912, arg_915, arg_916) } } } else { var vec__219000144__4 any; var root_921 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any = s__219000134__3; if linked_922 == nil { vec__219000144__4 = ifn_923.Invoke_O__O(arg_924) } else { vec__219000144__4 = linked_922.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_921, arg_924) }; var tilde__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000144__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000144__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_925 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_927 lang.IFn; if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any; var tmp6 any; if jrt.J2g_Truth(tilde__5) { tmp6 = ty__6 } else { var root_930 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, A_arbace_go_check_types_under_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = ty__6; if linked_931 == nil { tmp6 = ifn_932.Invoke_O__O(arg_933) } else { tmp6 = linked_931.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_930, arg_933) } }; arg_928 = lang.Tuple_Create_O_O__IPersistentVector(ty__6, tmp6); var arg_929 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__219000133); var tmp8 any; var root_934 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = s__219000134__3; if linked_935 == nil { tmp8 = ifn_936.Invoke_O__O(arg_937) } else { tmp8 = linked_935.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_934, arg_937) }; arg_929 = tmp7.Invoke_O__O(tmp8); if linked_926 == nil { return ifn_927.Invoke_O_O__O(arg_928, arg_929) } else { return linked_926.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_925, arg_928, arg_929) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :338:1
func A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_fn__219000139_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_fn__219000139_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_fn__219000139_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :338:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_fn__219000139_A) Ctor_O_I_O(c__b__219000136 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000136 = c__b__219000136; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :338:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_fn__219000139_A) Invoke_O__O(self any) any { { var i__219000135__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000135__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__219000140__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000135__1)); var tilde__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000140__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000140__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_889 any = A_arbace_go_check_types_A_const_132.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = t.F_b__219000136; var arg_893 any; var tmp2 any; if jrt.J2g_Truth(tilde__3) { tmp2 = ty__4 } else { var root_894 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, A_arbace_go_check_types_under_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = ty__4; if linked_895 == nil { tmp2 = ifn_896.Invoke_O__O(arg_897) } else { tmp2 = linked_895.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_894, arg_897) } }; arg_893 = lang.Tuple_Create_O_O__IPersistentVector(ty__4, tmp2); if linked_890 == nil { ifn_891.Invoke_O_O__O(arg_892, arg_893) } else { linked_890.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_889, arg_892, arg_893) }; i__219000135__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000135__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_go_check_types_typeset_all_A_New() *A_arbace_go_check_types_typeset_all_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_all_A{}; t.Ctor(); return t }
//line :342:1
func (t *A_arbace_go_check_types_typeset_all_A) Ctor() {}
//line :342:1
func (t *A_arbace_go_check_types_typeset_all_A) Invoke_O_O_O__O(self, t__0, f__1 any) any {


	var root_944 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_946 lang.IFn; if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any; var tmp1 any = A_arbace_go_check_types_typeset_all_fn__219000151_A_New_O(f__1); var tmp2 *jrt.Class; var fncls__949 *jrt.Class = A_arbace_go_check_types_typeset_all_fn__219000151_A_fn_class; if fncls__949 == nil { var fncls__949d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_go_check_types_typeset_all_fn__219000151_A_fn_class = fncls__949d; tmp2 = fncls__949d } else { tmp2 = fncls__949 }; arg_947 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_948 any; var root_950 any = A_arbace_go_check_types_A_const_150.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, A_arbace_go_check_types_typeset_pairs_A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = t__0; if linked_951 == nil { arg_948 = ifn_952.Invoke_O__O(arg_953) } else { arg_948 = linked_951.(*A_arbace_go_check_types_typeset_pairs_A).Invoke_O_O__O(root_950, arg_953) }; if linked_945 == nil { return ifn_946.Invoke_O_O__O(arg_947, arg_948) } else { return linked_945.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_944, arg_947, arg_948) } }
//line :345:1
func A_arbace_go_check_types_typeset_all_fn__219000151_A_New_O(p0 any) *A_arbace_go_check_types_typeset_all_fn__219000151_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_all_fn__219000151_A{}; t.Ctor_O(p0); return t }
//line :345:1
func (t *A_arbace_go_check_types_typeset_all_fn__219000151_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :345:1
func (t *A_arbace_go_check_types_typeset_all_fn__219000151_A) Invoke_O_O__O(self, p__219000150__1 any) any { var vec__219000152__2 any = p__219000150__1; var ty__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000152__2, lang.RT_IntCast_J__I_NoInit(0), nil); var u__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000152__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.IFn_Cast(t.F_f).Invoke_O_O__O(ty__3, u__4) }

func A_arbace_go_check_types_under_is_A_New() *A_arbace_go_check_types_under_is_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_is_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_go_check_types_under_is_A) Ctor() {}
//line :347:1
func (t *A_arbace_go_check_types_under_is_A) Invoke_O_O_O__O(self, t__0, f__1 any) any {



	var root_954 any = A_arbace_go_check_types_A_const_151.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, A_arbace_go_check_types_typeset_all_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = t__0; var arg_958 any; var tmp1 any = A_arbace_go_check_types_under_is_fn__219000157_A_New_O(f__1); var tmp2 *jrt.Class; var fncls__959 *jrt.Class = A_arbace_go_check_types_under_is_fn__219000157_A_fn_class; if fncls__959 == nil { var fncls__959d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_go_check_types_under_is_fn__219000157_A_fn_class = fncls__959d; tmp2 = fncls__959d } else { tmp2 = fncls__959 }; arg_958 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_955 == nil { return ifn_956.Invoke_O_O__O(arg_957, arg_958) } else { return linked_955.(*A_arbace_go_check_types_typeset_all_A).Invoke_O_O_O__O(root_954, arg_957, arg_958) } }
//line :351:1
func A_arbace_go_check_types_under_is_fn__219000157_A_New_O(p0 any) *A_arbace_go_check_types_under_is_fn__219000157_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_is_fn__219000157_A{}; t.Ctor_O(p0); return t }
//line :351:1
func (t *A_arbace_go_check_types_under_is_fn__219000157_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :351:1
func (t *A_arbace_go_check_types_under_is_fn__219000157_A) Invoke_O_O_O__O(self, ___1, u__2 any) any { return lang.IFn_Cast(t.F_f).Invoke_O__O(u__2) }

func A_arbace_go_check_types_all_basic_A_New() *A_arbace_go_check_types_all_basic_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_basic_A{}; t.Ctor(); return t }
//line :353:1
func (t *A_arbace_go_check_types_all_basic_A) Ctor() {}
//line :353:1
func (t *A_arbace_go_check_types_all_basic_A) Invoke_O_O_O__O(self, t__0, pred__1 any) any {



	var tmp1 any; var root_960 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_962 lang.IFn; if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any = t__0; if linked_961 == nil { tmp1 = ifn_962.Invoke_O__O(arg_963) } else { tmp1 = linked_961.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_960, arg_963) }; if jrt.J2g_Truth(tmp1) { var ts__3 any; var root_964 any = A_arbace_go_check_types_A_const_115.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_966 lang.IFn
		if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any = t__0; if linked_965 == nil { ts__3 = ifn_966.Invoke_O__O(arg_967) } else { ts__3 = linked_965.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_964, arg_967) }
		var tmp2 any; var and__1927000168__auto____4 any; var root_968 any = A_arbace_go_check_types_A_const_148.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_968, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = ts__3; if linked_969 == nil { and__1927000168__auto____4 = ifn_970.Invoke_O__O(arg_971) } else { and__1927000168__auto____4 = linked_969.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_968, arg_971) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_972 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_974 lang.IFn; if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any; var tmp3 any = A_arbace_go_check_types_all_basic_fn__219000161_A_New_O(pred__1); var tmp4 *jrt.Class; var fncls__977 *jrt.Class = A_arbace_go_check_types_all_basic_fn__219000161_A_fn_class; if fncls__977 == nil { var fncls__977d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_check_types_all_basic_fn__219000161_A_fn_class = fncls__977d; tmp4 = fncls__977d } else { tmp4 = fncls__977 }; arg_975 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_976 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__3); if linked_973 == nil { tmp2 = ifn_974.Invoke_O_O__O(arg_975, arg_976) } else { tmp2 = linked_973.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_972, arg_975, arg_976) } } else { tmp2 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp2)).Ref() } else {
			return lang.IFn_Cast(pred__1).Invoke_O__O(t__0) } }
//line :359:1
func A_arbace_go_check_types_all_basic_fn__219000161_A_New_O(p0 any) *A_arbace_go_check_types_all_basic_fn__219000161_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_basic_fn__219000161_A{}; t.Ctor_O(p0); return t }
//line :359:1
func (t *A_arbace_go_check_types_all_basic_fn__219000161_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :359:1
func (t *A_arbace_go_check_types_all_basic_fn__219000161_A) Invoke_O_O__O(self, p__219000160__1 any) any { var vec__219000162__2 any = p__219000160__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000162__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000162__2, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___3; return lang.IFn_Cast(t.F_pred).Invoke_O__O(ty__4) }


func A_arbace_go_check_types_all_integer_QMARK__A_New() *A_arbace_go_check_types_all_integer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_integer_QMARK__A{}; t.Ctor(); return t }
//line :362:1
func (t *A_arbace_go_check_types_all_integer_QMARK__A) Ctor() {}
//line :362:1
func (t *A_arbace_go_check_types_all_integer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_978 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_978, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_980 lang.IFn; if linked_979 == nil { ifn_980 = lang.IFn_Cast(root_978) } else { ifn_980 = nil }; var arg_981 any = t__0; var arg_982 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); if linked_979 == nil { return ifn_980.Invoke_O_O__O(arg_981, arg_982) } else { return linked_979.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_978, arg_981, arg_982) } }
func A_arbace_go_check_types_all_unsigned_QMARK__A_New() *A_arbace_go_check_types_all_unsigned_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_unsigned_QMARK__A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_go_check_types_all_unsigned_QMARK__A) Ctor() {}
//line :363:1
func (t *A_arbace_go_check_types_all_unsigned_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_983 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_983, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_985 lang.IFn; if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; var arg_986 any = t__0; var arg_987 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); if linked_984 == nil { return ifn_985.Invoke_O_O__O(arg_986, arg_987) } else { return linked_984.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_983, arg_986, arg_987) } }
func A_arbace_go_check_types_all_numeric_QMARK__A_New() *A_arbace_go_check_types_all_numeric_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_QMARK__A{}; t.Ctor(); return t }
//line :364:1
func (t *A_arbace_go_check_types_all_numeric_QMARK__A) Ctor() {}
//line :364:1
func (t *A_arbace_go_check_types_all_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_988 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = t__0; var arg_992 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); if linked_989 == nil { return ifn_990.Invoke_O_O__O(arg_991, arg_992) } else { return linked_989.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_988, arg_991, arg_992) } }
func A_arbace_go_check_types_all_string_QMARK__A_New() *A_arbace_go_check_types_all_string_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_string_QMARK__A{}; t.Ctor(); return t }
//line :365:1
func (t *A_arbace_go_check_types_all_string_QMARK__A) Ctor() {}
//line :365:1
func (t *A_arbace_go_check_types_all_string_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_993 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_993, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_995 lang.IFn; if linked_994 == nil { ifn_995 = lang.IFn_Cast(root_993) } else { ifn_995 = nil }; var arg_996 any = t__0; var arg_997 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); if linked_994 == nil { return ifn_995.Invoke_O_O__O(arg_996, arg_997) } else { return linked_994.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_993, arg_996, arg_997) } }
func A_arbace_go_check_types_all_boolean_QMARK__A_New() *A_arbace_go_check_types_all_boolean_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_boolean_QMARK__A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_go_check_types_all_boolean_QMARK__A) Ctor() {}
//line :366:1
func (t *A_arbace_go_check_types_all_boolean_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_998 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = t__0; var arg_1002 any = A_arbace_go_check_types_A_const_155.GetRawRoot__O(); if linked_999 == nil { return ifn_1000.Invoke_O_O__O(arg_1001, arg_1002) } else { return linked_999.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_998, arg_1001, arg_1002) } }
func A_arbace_go_check_types_all_ordered_QMARK__A_New() *A_arbace_go_check_types_all_ordered_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_ordered_QMARK__A{}; t.Ctor(); return t }
//line :367:1
func (t *A_arbace_go_check_types_all_ordered_QMARK__A) Ctor() {}
//line :367:1
func (t *A_arbace_go_check_types_all_ordered_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1003 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_1004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1003, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1005 lang.IFn; if linked_1004 == nil { ifn_1005 = lang.IFn_Cast(root_1003) } else { ifn_1005 = nil }; var arg_1006 any = t__0; var arg_1007 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); if linked_1004 == nil { return ifn_1005.Invoke_O_O__O(arg_1006, arg_1007) } else { return linked_1004.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1003, arg_1006, arg_1007) } }
func A_arbace_go_check_types_all_numeric_or_string_QMARK__A_New() *A_arbace_go_check_types_all_numeric_or_string_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_or_string_QMARK__A{}; t.Ctor(); return t }
//line :368:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__A) Ctor() {}
//line :368:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1008 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1008, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1010 lang.IFn; if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any = t__0; var arg_1012 any; var tmp1 any = A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000174_A_New(); var tmp2 *jrt.Class; var fncls__1021 *jrt.Class = A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000174_A_fn_class; if fncls__1021 == nil { var fncls__1021d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000174_A_fn_class = fncls__1021d; tmp2 = fncls__1021d } else { tmp2 = fncls__1021 }; arg_1012 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1009 == nil { return ifn_1010.Invoke_O_O__O(arg_1011, arg_1012) } else { return linked_1009.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1008, arg_1011, arg_1012) } }
//line :368:1
func A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000174_A_New() *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000174_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000174_A{}; t.Ctor(); return t }
//line :368:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000174_A) Ctor() {}
//line :368:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000174_A) Invoke_O_O__O(self, p1__219000173_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_1013 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, A_arbace_go_check_types_numeric_QMARK__A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any = p1__219000173_SHARP___1; if linked_1014 == nil { or__1927000174__auto____2 = ifn_1015.Invoke_O__O(arg_1016) } else { or__1927000174__auto____2 = linked_1014.(*A_arbace_go_check_types_numeric_QMARK__A).Invoke_O_O__O(root_1013, arg_1016) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_1017 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1017, A_arbace_go_check_types_string_type_QMARK__A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any = p1__219000173_SHARP___1; if linked_1018 == nil { return ifn_1019.Invoke_O__O(arg_1020) } else { return linked_1018.(*A_arbace_go_check_types_string_type_QMARK__A).Invoke_O_O__O(root_1017, arg_1020) } } }
func A_arbace_go_check_types_all_float_QMARK__A_New() *A_arbace_go_check_types_all_float_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_float_QMARK__A{}; t.Ctor(); return t }
//line :369:1
func (t *A_arbace_go_check_types_all_float_QMARK__A) Ctor() {}
//line :369:1
func (t *A_arbace_go_check_types_all_float_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1022 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = t__0; var arg_1026 any = A_arbace_go_check_types_A_const_81.GetRawRoot__O(); if linked_1023 == nil { return ifn_1024.Invoke_O_O__O(arg_1025, arg_1026) } else { return linked_1023.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1022, arg_1025, arg_1026) } }
func A_arbace_go_check_types_all_complex_QMARK__A_New() *A_arbace_go_check_types_all_complex_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_complex_QMARK__A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_go_check_types_all_complex_QMARK__A) Ctor() {}
//line :370:1
func (t *A_arbace_go_check_types_all_complex_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1027 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = t__0; var arg_1031 any = A_arbace_go_check_types_A_const_82.GetRawRoot__O(); if linked_1028 == nil { return ifn_1029.Invoke_O_O__O(arg_1030, arg_1031) } else { return linked_1028.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1027, arg_1030, arg_1031) } }

func A_arbace_go_check_types_common_under_A_New() *A_arbace_go_check_types_common_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_common_under_A{}; t.Ctor(); return t }
//line :372:1
func (t *A_arbace_go_check_types_common_under_A) Ctor() {}
//line :372:1
func (t *A_arbace_go_check_types_common_under_A) Invoke_O_O_O__O(self, t__0, cnd__1 any) any { { var ps__3 any; var root_1032 any = A_arbace_go_check_types_A_const_150.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, A_arbace_go_check_types_typeset_pairs_A_fn_class); var ifn_1034 lang.IFn





	if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = t__0; if linked_1033 == nil { ps__3 = ifn_1034.Invoke_O__O(arg_1035) } else { ps__3 = linked_1033.(*A_arbace_go_check_types_typeset_pairs_A).Invoke_O_O__O(root_1032, arg_1035) }
//line :372:1
	var ct__4 any; var cu__5 any; L1: for {






		var tmp1 any; var root_1036 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1036, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1038 lang.IFn; if linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = ps__3; if linked_1037 == nil { tmp1 = ifn_1038.Invoke_O__O(arg_1039) } else { tmp1 = linked_1037.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1036, arg_1039) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(cu__5, nil) } else { var vec__219000179__6 any; var root_1040 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1042 lang.IFn

			if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = ps__3; if linked_1041 == nil { vec__219000179__6 = ifn_1042.Invoke_O__O(arg_1043) } else { vec__219000179__6 = linked_1041.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1040, arg_1043) }
//line :379:1
			var ty__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000179__6, lang.RT_IntCast_J__I_NoInit(0), nil); var u__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000179__6, lang.RT_IntCast_J__I_NoInit(1), nil); var e__9 any


			if jrt.J2g_Truth(cnd__1) { e__9 = lang.IFn_Cast(cnd__1).Invoke_O_O__O(ty__7, u__8) } else { e__9 = nil }
			if jrt.J2g_Truth(e__9) { return lang.Tuple_Create_O_O__IPersistentVector(nil, e__9) } else { if lang.Util_Identical_O_O__Z_NoInit(u__8, nil) { return A_arbace_go_check_types_A_const_157 } else { if lang.Util_Identical_O_O__Z_NoInit(cu__5, nil) {


				var tmp2 any; var root_1067 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1069 lang.IFn; if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any = ps__3; if linked_1068 == nil { tmp2 = ifn_1069.Invoke_O__O(arg_1070) } else { tmp2 = linked_1068.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1067, arg_1070) }; ps__3, ct__4, cu__5 = tmp2, ty__7, u__8; continue L1 } else {
//line :383:1
					var tmp3 any; var and__1927000168__auto____10 any; var root_1044 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1046 lang.IFn



					if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = cu__5; if linked_1045 == nil { and__1927000168__auto____10 = ifn_1046.Invoke_O__O(arg_1047) } else { and__1927000168__auto____10 = linked_1045.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1044, arg_1047) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp4 any = A_arbace_go_check_types_A_const_98; var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____11 { var and__1927000168__auto____12 any; var root_1048 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any = u__8; if linked_1049 == nil { and__1927000168__auto____12 = ifn_1050.Invoke_O__O(arg_1051) } else { and__1927000168__auto____12 = linked_1049.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1048, arg_1051) }; if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp5 any = A_arbace_go_check_types_A_const_98; tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp5, lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp3 = and__1927000168__auto____12 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else { tmp3 = and__1927000168__auto____10 }
//line :383:1
					if jrt.J2g_Truth(tmp3) {




						var tmp6 any; var root_1052 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1052, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1054 lang.IFn
						if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any = lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(2)); var arg_1056 any = lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(2)); if linked_1053 == nil { tmp6 = ifn_1054.Invoke_O_O__O(arg_1055, arg_1056) } else { tmp6 = linked_1053.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1052, arg_1055, arg_1056) }
//line :388:1
						if jrt.J2g_Truth(tmp6) { return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_4, nil, Lit_5, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_go_check_types_A_const_161.GetRawRoot__O()).Invoke_O__O(ct__4), nil, lang.IFn_Cast(A_arbace_go_check_types_A_const_161.GetRawRoot__O()).Invoke_O__O(ty__7), nil)).Ref()) } else { if lang.Util_Equiv_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(1)), lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(1))) {

							var tmp7 any; var root_1079 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any = ps__3; if linked_1080 == nil { tmp7 = ifn_1081.Invoke_O__O(arg_1082) } else { tmp7 = linked_1080.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1079, arg_1082) }; ps__3, ct__4, cu__5 = tmp7, ct__4, cu__5; continue L1 } else {
//line :388:1
								var tmp8 any = A_arbace_go_check_types_A_const_158; if lang.Util_Equiv_O_O__Z_NoInit(tmp8, lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(1))) {


									var tmp9 any; var root_1083 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = ps__3; if linked_1084 == nil { tmp9 = ifn_1085.Invoke_O__O(arg_1086) } else { tmp9 = linked_1084.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1083, arg_1086) }; ps__3, ct__4, cu__5 = tmp9, ty__7, u__8; continue L1 } else {
//line :388:1
										var tmp10 any; var root_1057 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1059 lang.IFn



										if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = A_arbace_go_check_types_A_const_158; var arg_1061 any = lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(1)); if linked_1058 == nil { tmp10 = ifn_1059.Invoke_O_O__O(arg_1060, arg_1061) } else { tmp10 = linked_1058.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1057, arg_1060, arg_1061) }
//line :388:1
										if jrt.J2g_Truth(tmp10) { return A_arbace_go_check_types_A_const_159 } else { if A_arbace_go_check_types_A_const_75 != nil {




											var tmp11 any; var root_1087 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = ps__3; if linked_1088 == nil { tmp11 = ifn_1089.Invoke_O__O(arg_1090) } else { tmp11 = linked_1088.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1087, arg_1090) }; ps__3, ct__4, cu__5 = tmp11, ct__4, cu__5; continue L1 } else {
//line :388:1
												return nil } } } } } } else {
//line :383:1
													var tmp12 any; var root_1062 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1062, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1064 lang.IFn










													if linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any = cu__5; var arg_1066 any = u__8; if linked_1063 == nil { tmp12 = ifn_1064.Invoke_O_O__O(arg_1065, arg_1066) } else { tmp12 = linked_1063.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1062, arg_1065, arg_1066) }
//line :383:1
													if jrt.J2g_Truth(tmp12) { return A_arbace_go_check_types_A_const_160 } else { if A_arbace_go_check_types_A_const_75 != nil {











														var tmp13 any; var root_1091 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1093 lang.IFn; if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = ps__3; if linked_1092 == nil { tmp13 = ifn_1093.Invoke_O__O(arg_1094) } else { tmp13 = linked_1092.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1091, arg_1094) }; ps__3, ct__4, cu__5 = tmp13, ct__4, cu__5; continue L1 } else {
//line :383:1
															return nil } } } } } } } } }; /*line :372:1*/panic("j2g: unreachable") }
//line :372:1
func (t *A_arbace_go_check_types_common_under_A) Invoke_O_O__O(self, t__0 any) any {



	var root_1095 any = A_arbace_go_check_types_A_const_162.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, A_arbace_go_check_types_common_under_A_fn_class); var ifn_1097 lang.IFn; if linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = t__0; var arg_1099 any; if linked_1096 == nil { return ifn_1097.Invoke_O_O__O(arg_1098, arg_1099) } else { return linked_1096.(*A_arbace_go_check_types_common_under_A).Invoke_O_O_O__O(root_1095, arg_1098, arg_1099)
	}
}


















func A_arbace_go_check_types_core_type_A_New() *A_arbace_go_check_types_core_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_core_type_A{}; t.Ctor(); return t }
//line :397:1
func (t *A_arbace_go_check_types_core_type_A) Ctor() {}
//line :397:1
func (t *A_arbace_go_check_types_core_type_A) Invoke_O_O__O(self, t__0 any) any {


	var root_1100 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1102 lang.IFn; if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any; var root_1104 any = A_arbace_go_check_types_A_const_162.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, A_arbace_go_check_types_common_under_A_fn_class); var ifn_1106 lang.IFn; if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = t__0; if linked_1105 == nil { arg_1103 = ifn_1106.Invoke_O__O(arg_1107) } else { arg_1103 = linked_1105.(*A_arbace_go_check_types_common_under_A).Invoke_O_O__O(root_1104, arg_1107) }; if linked_1101 == nil { return ifn_1102.Invoke_O__O(arg_1103) } else { return linked_1101.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1100, arg_1103)
	}
}








func A_arbace_go_check_types_terms_str_A_New() *A_arbace_go_check_types_terms_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_A{}; t.Ctor(); return t }
//line :411:1
func (t *A_arbace_go_check_types_terms_str_A) Ctor() {}
//line :411:1
func (t *A_arbace_go_check_types_terms_str_A) Invoke_O_O__O(self, terms__0 any) any {
	var tmp1 any; var root_1108 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1110 lang.IFn; if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = terms__0; if linked_1109 == nil { tmp1 = ifn_1110.Invoke_O__O(arg_1111) } else { tmp1 = linked_1109.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1108, arg_1111) }; if jrt.J2g_Truth(tmp1) { return Lit_43 } else { var ts__2 any; var tmp2 *lang.Keyword = A_arbace_go_check_types_A_const_124; var or__1927000174__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(terms__0))

		if jrt.J2g_Truth(or__1927000174__auto____2) { ts__2 = or__1927000174__auto____2 } else { var root_1112 any = A_arbace_go_check_types_A_const_163.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1114 lang.IFn; if linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any = A_arbace_go_check_types_A_const_161.GetRawRoot__O(); var arg_1116 any = terms__0; if linked_1113 == nil { ts__2 = ifn_1114.Invoke_O_O__O(arg_1115, arg_1116) } else { ts__2 = linked_1113.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1112, arg_1115, arg_1116) } }
		var root_1117 any = A_arbace_go_check_types_A_const_164.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = Lit_44; var arg_1121 any; var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_go_check_types_terms_str_iter__219000184__219000188_A_New(); var tmp4 *jrt.Class; var fncls__1188 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000184__219000188_A_fn_class; if fncls__1188 == nil { var fncls__1188d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_go_check_types_terms_str_iter__219000184__219000188_A_fn_class = fncls__1188d; tmp4 = fncls__1188d } else { tmp4 = fncls__1188 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); arg_1121 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(ts__2); if linked_1118 == nil { return ifn_1119.Invoke_O_O__O(arg_1120, arg_1121) } else { return linked_1118.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1117, arg_1120, arg_1121) } } }
//line :415:1
func A_arbace_go_check_types_terms_str_iter__219000184__219000188_A_New() *A_arbace_go_check_types_terms_str_iter__219000184__219000188_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000184__219000188_A{}; t.Ctor(); return t }
//line :415:1
func (t *A_arbace_go_check_types_terms_str_iter__219000184__219000188_A) Ctor() {}
//line :415:1
func (t *A_arbace_go_check_types_terms_str_iter__219000184__219000188_A) Invoke_O_O__O(self, s__219000185__1 any) any { var tmp1 any = A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_A_New_O_O(s__219000185__1, self); var tmp2 *jrt.Class; var fncls__1187 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_A_fn_class; if fncls__1187 == nil { var fncls__1187d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_A_fn_class = fncls__1187d; tmp2 = fncls__1187d } else { tmp2 = fncls__1187 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :415:1
func A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_A{}; t.Ctor_O_O(p0, p1); return t }
//line :415:1
func (t *A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_A) Ctor_O_O(c__s__219000185, c__iter__219000184 any) { t.F_s__219000185 = c__s__219000185; t.F_iter__219000184 = c__iter__219000184 }
//line :415:1
func (t *A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_A) Invoke_O__O(self any) any { { var s__219000185__1 any; var t_ any = t.F_s__219000185; t.F_s__219000185 = nil; s__219000185__1 = t_; for { var temp__1927000414__auto____2 any; var root_1122 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_1123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1122, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1124 lang.IFn; if linked_1123 == nil { ifn_1124 = lang.IFn_Cast(root_1122) } else { ifn_1124 = nil }; var arg_1125 any = s__219000185__1; if linked_1123 == nil { temp__1927000414__auto____2 = ifn_1124.Invoke_O__O(arg_1125) } else { temp__1927000414__auto____2 = linked_1123.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1122, arg_1125) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000185__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1126 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1126, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1128 lang.IFn; if linked_1127 == nil { ifn_1128 = lang.IFn_Cast(root_1126) } else { ifn_1128 = nil }; var arg_1129 any = s__219000185__3; if linked_1127 == nil { tmp1 = ifn_1128.Invoke_O__O(arg_1129) } else { tmp1 = linked_1127.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1126, arg_1129) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1130 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_1131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1130, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1132 lang.IFn; if linked_1131 == nil { ifn_1132 = lang.IFn_Cast(root_1130) } else { ifn_1132 = nil }; var arg_1133 any = s__219000185__3; if linked_1131 == nil { c__1927001037__auto____4 = ifn_1132.Invoke_O__O(arg_1133) } else { c__1927001037__auto____4 = linked_1131.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1130, arg_1133) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000187__6 any; var root_1134 any = A_arbace_go_check_types_A_const_130.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1135 == nil { b__219000187__6 = ifn_1136.Invoke_O__O(arg_1137) } else { b__219000187__6 = linked_1135.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1134, arg_1137) }; var tmp2 any = A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_fn__219000190_A_New_O_I_O(b__219000187__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1147 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_fn__219000190_A_fn_class; if fncls__1147 == nil { var fncls__1147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_fn__219000190_A_fn_class = fncls__1147d; tmp3 = fncls__1147d } else { tmp3 = fncls__1147 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1148 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_1149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1148, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1150 lang.IFn; if linked_1149 == nil { ifn_1150 = lang.IFn_Cast(root_1148) } else { ifn_1150 = nil }; var arg_1151 any; var root_1153 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1153, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1155 lang.IFn; if linked_1154 == nil { ifn_1155 = lang.IFn_Cast(root_1153) } else { ifn_1155 = nil }; var arg_1156 any = b__219000187__6; if linked_1154 == nil { arg_1151 = ifn_1155.Invoke_O__O(arg_1156) } else { arg_1151 = linked_1154.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1153, arg_1156) }; var arg_1152 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000184); var tmp5 any; var root_1157 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any = s__219000185__3; if linked_1158 == nil { tmp5 = ifn_1159.Invoke_O__O(arg_1160) } else { tmp5 = linked_1158.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1157, arg_1160) }; arg_1152 = tmp4.Invoke_O__O(tmp5); if linked_1149 == nil { return ifn_1150.Invoke_O_O__O(arg_1151, arg_1152) } else { return linked_1149.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1148, arg_1151, arg_1152) } } else { var root_1161 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any; var root_1166 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = b__219000187__6; if linked_1167 == nil { arg_1164 = ifn_1168.Invoke_O__O(arg_1169) } else { arg_1164 = linked_1167.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1166, arg_1169) }; var arg_1165 any; if linked_1162 == nil { return ifn_1163.Invoke_O_O__O(arg_1164, arg_1165) } else { return linked_1162.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1161, arg_1164, arg_1165) } } } else { var vec__219000195__4 any; var root_1170 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1172 lang.IFn; if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any = s__219000185__3; if linked_1171 == nil { vec__219000195__4 = ifn_1172.Invoke_O__O(arg_1173) } else { vec__219000195__4 = linked_1171.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1170, arg_1173) }; var tilde__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000195__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000195__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1174 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1176 lang.IFn; if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 *jrt.String; if jrt.J2g_Truth(tilde__5) { tmp7 = Lit_48 } else { tmp7 = nil }; var tmp8 any = tmp7.Ref(); var tmp9 any; var root_1179 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any = ty__6; if linked_1180 == nil { tmp9 = ifn_1181.Invoke_O__O(arg_1182) } else { tmp9 = linked_1180.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1179, arg_1182) }; arg_1177 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9)).Ref(); var arg_1178 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__219000184); var tmp11 any; var root_1183 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1183, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1185 lang.IFn; if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any = s__219000185__3; if linked_1184 == nil { tmp11 = ifn_1185.Invoke_O__O(arg_1186) } else { tmp11 = linked_1184.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1183, arg_1186) }; arg_1178 = tmp10.Invoke_O__O(tmp11); if linked_1175 == nil { return ifn_1176.Invoke_O_O__O(arg_1177, arg_1178) } else { return linked_1175.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1174, arg_1177, arg_1178) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :415:1
func A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_fn__219000190_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_fn__219000190_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_fn__219000190_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :415:1
func (t *A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_fn__219000190_A) Ctor_O_I_O(c__b__219000187 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000187 = c__b__219000187; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :415:1
func (t *A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_fn__219000190_A) Invoke_O__O(self any) any { { var i__219000186__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000186__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__219000191__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000186__1)); var tilde__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000191__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000191__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1138 any = A_arbace_go_check_types_A_const_132.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any = t.F_b__219000187; var arg_1142 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 *jrt.String; if jrt.J2g_Truth(tilde__3) { tmp3 = Lit_48 } else { tmp3 = nil }; var tmp4 any = tmp3.Ref(); var tmp5 any; var root_1143 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1143, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1145 lang.IFn; if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = ty__4; if linked_1144 == nil { tmp5 = ifn_1145.Invoke_O__O(arg_1146) } else { tmp5 = linked_1144.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1143, arg_1146) }; arg_1142 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5)).Ref(); if linked_1139 == nil { ifn_1140.Invoke_O_O__O(arg_1141, arg_1142) } else { linked_1139.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1138, arg_1141, arg_1142) }; i__219000186__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000186__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_types_params_str_A_New() *A_arbace_go_check_types_params_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_params_str_A{}; t.Ctor(); return t }
//line :417:1
func (t *A_arbace_go_check_types_params_str_A) Ctor() {}
//line :417:1
func (t *A_arbace_go_check_types_params_str_A) Invoke_O_O_O__O(self, ps__0, variadic__1 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_21, nil, Lit_22); var tmp2 any; var root_1189 any = A_arbace_go_check_types_A_const_164.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1189, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1191 lang.IFn
	if linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var arg_1192 any = Lit_23; var arg_1193 any; var root_1194 any = A_arbace_go_check_types_A_const_166.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1194, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1196 lang.IFn; if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any; var tmp3 any = A_arbace_go_check_types_params_str_fn__219000201_A_New_O_O(ps__0, variadic__1); var tmp4 *jrt.Class; var fncls__1207 *jrt.Class = A_arbace_go_check_types_params_str_fn__219000201_A_fn_class; if fncls__1207 == nil { var fncls__1207d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_go_check_types_params_str_fn__219000201_A_fn_class = fncls__1207d; tmp4 = fncls__1207d } else { tmp4 = fncls__1207 }; arg_1197 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1198 any = ps__0; if linked_1195 == nil { arg_1193 = ifn_1196.Invoke_O_O__O(arg_1197, arg_1198) } else { arg_1193 = linked_1195.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1194, arg_1197, arg_1198) }; if linked_1190 == nil { tmp2 = ifn_1191.Invoke_O_O__O(arg_1192, arg_1193) } else { tmp2 = linked_1190.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1189, arg_1192, arg_1193) }
//line :418:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil)).Ref() }
func A_arbace_go_check_types_params_str_fn__219000201_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_params_str_fn__219000201_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_params_str_fn__219000201_A{}; t.Ctor_O_O(p0, p1); return t }
//line :419:1
func (t *A_arbace_go_check_types_params_str_fn__219000201_A) Ctor_O_O(c__ps, c__variadic any) { t.F_ps = c__ps; t.F_variadic = c__variadic }
//line :419:1
func (t *A_arbace_go_check_types_params_str_fn__219000201_A) Invoke_O_O_O__O(self, i__1, p__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = t.F_variadic; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_J__Z_NoInit(i__1, lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_ps))))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp3 any; var root_1199 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1201 lang.IFn; if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any = lang.RT_Nth_O_I__O_NoInit(p__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1200 == nil { tmp3 = ifn_1201.Invoke_O__O(arg_1202) } else { tmp3 = linked_1200.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1199, arg_1202) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else {
			var root_1203 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1203, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1205 lang.IFn; if linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any = p__2; if linked_1204 == nil { return ifn_1205.Invoke_O__O(arg_1206) } else { return linked_1204.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1203, arg_1206)
			}
		}
}
func A_arbace_go_check_types_sig_str_A_New() *A_arbace_go_check_types_sig_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sig_str_A{}; t.Ctor(); return t }
//line :426:1
func (t *A_arbace_go_check_types_sig_str_A) Ctor() {}
//line :426:1
func (t *A_arbace_go_check_types_sig_str_A) Invoke_O_O__O(self, p__219000204__0 any) any { var vec__219000205__2 any = p__219000204__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000205__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000205__2, lang.RT_IntCast_J__I_NoInit(1), nil); var rs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000205__2, lang.RT_IntCast_J__I_NoInit(2), nil); var variadic__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000205__2, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_1208 any = A_arbace_go_check_types_A_const_167.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1208, A_arbace_go_check_types_params_str_A_fn_class); var ifn_1210 lang.IFn; _ = ___3; if


	linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any = ps__4; var arg_1212 any = variadic__6; if linked_1209 == nil { tmp2 = ifn_1210.Invoke_O_O__O(arg_1211, arg_1212) } else { tmp2 = linked_1209.(*A_arbace_go_check_types_params_str_A).Invoke_O_O_O__O(root_1208, arg_1211, arg_1212) }; var tmp3 any = tmp2; var tmp4 *jrt.String; var G__219000208__9_ int32 = lang.RT_Count_O__I_NoInit(rs__5); L1:
	switch { default: switch G__219000208__9_ { case 0: tmp4 = Lit_8; break L1; case 1: var r__10 any; var root_1214 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_1215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1214, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1216 lang.IFn

		if linked_1215 == nil { ifn_1216 = lang.IFn_Cast(root_1214) } else { ifn_1216 = nil }; var arg_1217 any = rs__5; if linked_1215 == nil { r__10 = ifn_1216.Invoke_O__O(arg_1217) } else { r__10 = linked_1215.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1214, arg_1217) }; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_9, nil); var tmp6 any; var root_1218 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1218, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1220 lang.IFn; if linked_1219 == nil { ifn_1220 = lang.IFn_Cast(root_1218) } else { ifn_1220 = nil }; var arg_1221 any = r__10; if linked_1219 == nil { tmp6 = ifn_1220.Invoke_O__O(arg_1221) } else { tmp6 = linked_1219.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1218, arg_1221) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6))
//line :430:1
		break L1; default:
	}

		var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_33, nil, Lit_22); var tmp8 any; var root_1222 any = A_arbace_go_check_types_A_const_164.GetRawRoot__O(); var linked_1223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1222, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1224 lang.IFn; if linked_1223 == nil { ifn_1224 = lang.IFn_Cast(root_1222) } else { ifn_1224 = nil }; var arg_1225 any = Lit_23; var arg_1226 any; var root_1227 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1227, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1229 lang.IFn; if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var arg_1231 any = rs__5; if linked_1228 == nil { arg_1226 = ifn_1229.Invoke_O_O__O(arg_1230, arg_1231) } else { arg_1226 = linked_1228.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1227, arg_1230, arg_1231) }; if linked_1223 == nil { tmp8 = ifn_1224.Invoke_O_O__O(arg_1225, arg_1226) } else { tmp8 = linked_1223.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1222, arg_1225, arg_1226) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil))}; return /*line :429:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4.Ref())).Ref() }





func A_arbace_go_check_types_field_str_A_New() *A_arbace_go_check_types_field_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_field_str_A{}; t.Ctor(); return t }
//line :435:1
func (t *A_arbace_go_check_types_field_str_A) Ctor() {}
//line :435:1
func (t *A_arbace_go_check_types_field_str_A) Invoke_O_O__O(self, f__0 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 *jrt.String; if jrt.J2g_Truth(A_arbace_go_check_types_A_const_168.Invoke_O__O(f__0)) { tmp2 = Lit_8 } else { tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_12.Invoke_O__O(f__0), nil)) }; var tmp3 any = tmp2.Ref(); var tmp4 any; var root_1232 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(f__0); if linked_1233 == nil { tmp4 = ifn_1234.Invoke_O__O(arg_1235) } else { tmp4 = linked_1233.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1232, arg_1235) }; var tmp5 any = tmp4; var tmp6 *jrt.String
	if jrt.J2g_Truth(A_arbace_go_check_types_A_const_106.Invoke_O__O(f__0)) { var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_9, nil); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_161.GetRawRoot__O()); var tmp9 any; var root_1240 any = A_arbace_go_check_types_A_const_169.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = A_arbace_go_check_types_A_const_106.Invoke_O__O(f__0); if linked_1241 == nil { tmp9 = ifn_1242.Invoke_O__O(arg_1243) } else { tmp9 = linked_1241.(*aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A).Invoke_O_O__O(root_1240, arg_1243) }; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8.Invoke_O__O(tmp9))) } else { tmp6 = nil }
//line :436:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp5, tmp6.Ref())).Ref()
}

func A_arbace_go_check_types_named_str_A_New() *A_arbace_go_check_types_named_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_str_A{}; t.Ctor(); return t }
//line :439:1
func (t *A_arbace_go_check_types_named_str_A) Ctor() {}
//line :439:1
func (t *A_arbace_go_check_types_named_str_A) Invoke_O_O__O(self, t__0 any) any { var i__2 any; var root_1244 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, A_arbace_go_check_types_info_A_fn_class); var ifn_1246 lang.IFn; if
										linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any = t__0; if linked_1245 == nil { i__2 = ifn_1246.Invoke_O__O(arg_1247) } else { i__2 = linked_1245.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1244, arg_1247) }; var base__3 any; var tmp1 any; var and__1927000168__auto____3 any = /*line :439:1*/A_arbace_go_check_types_A_const_170.Invoke_O__O(i__2); if

	jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1248 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1250 lang.IFn; if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any = A_arbace_go_check_types_A_const_170.Invoke_O__O(i__2); var arg_1252 any = A_arbace_go_check_types_A_const_171.Get__O(); if linked_1249 == nil { and__1927000168__auto____4 = ifn_1250.Invoke_O_O__O(arg_1251, arg_1252) } else { and__1927000168__auto____4 = linked_1249.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1248, arg_1251, arg_1252) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1253 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1255 lang.IFn; if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = A_arbace_go_check_types_A_const_172.Invoke_O__O(i__2); if linked_1254 == nil { tmp1 = ifn_1255.Invoke_O__O(arg_1256) } else { tmp1 = linked_1254.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1253, arg_1256) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		base__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_173.Invoke_O__O(i__2), nil, A_arbace_go_check_types_A_const_12.Invoke_O__O(i__2))).Ref() } else {
			base__3 = A_arbace_go_check_types_A_const_12.Invoke_O__O(i__2) }; var tmp2 any; var root_1257 any =
	A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1259 lang.IFn; if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any = A_arbace_go_check_types_A_const_174.Invoke_O__O(i__2); if linked_1258 == nil { tmp2 = ifn_1259.Invoke_O__O(arg_1260) } else { tmp2 = linked_1258.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1257, arg_1260) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_17, nil, Lit_18); var tmp4 any; var root_1261 any = A_arbace_go_check_types_A_const_164.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1263 lang.IFn; if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any = Lit_19; var arg_1265 any; var root_1266 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1267 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1266, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1268 lang.IFn; if linked_1267 == nil { ifn_1268 = lang.IFn_Cast(root_1266) } else { ifn_1268 = nil }; var arg_1269 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var arg_1270 any = A_arbace_go_check_types_A_const_174.Invoke_O__O(i__2); if linked_1267 == nil { arg_1265 = ifn_1268.Invoke_O_O__O(arg_1269, arg_1270) } else { arg_1265 = linked_1267.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1266, arg_1269, arg_1270) }; if linked_1262 == nil { tmp4 = ifn_1263.Invoke_O_O__O(arg_1264, arg_1265) } else { tmp4 = linked_1262.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1261, arg_1264, arg_1265) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, base__3, nil, tmp4, nil)).Ref() } else {
//line :444:1
			return base__3 } }



func A_arbace_go_check_types_type_str_A_New() *A_arbace_go_check_types_type_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_A{}; t.Ctor(); return t }
//line :448:1
func (t *A_arbace_go_check_types_type_str_A) Ctor() {}
//line :448:1
func (t *A_arbace_go_check_types_type_str_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_1271 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_1273 lang.IFn
	if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = t__0; if linked_1272 == nil { tmp1 = ifn_1273.Invoke_O__O(arg_1274) } else { tmp1 = linked_1272.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_1271, arg_1274) }
//line :451:1
	if jrt.J2g_Truth(tmp1) {
		var tmp2 any = A_arbace_go_check_types_A_const_175.GetRawRoot__O(); var tmp3 any; var root_1275 any = A_arbace_go_check_types_A_const_176.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1275, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1277 lang.IFn; if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = t__0; if linked_1276 == nil { tmp3 = ifn_1277.Invoke_O__O(arg_1278) } else { tmp3 = linked_1276.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1275, arg_1278) }; return lang.RT_Get_O_O_O__O_NoInit(tmp2, t__0, tmp3) } else {
//line :451:1
			var tmp4 any; var root_1279 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1279, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1281 lang.IFn

			if linked_1280 == nil { ifn_1281 = lang.IFn_Cast(root_1279) } else { ifn_1281 = nil }; var arg_1282 any = t__0; if linked_1280 == nil { tmp4 = ifn_1281.Invoke_O__O(arg_1282) } else { tmp4 = linked_1280.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1279, arg_1282) }
//line :451:1
			if jrt.J2g_Truth(tmp4) {

				var root_1283 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1283, A_arbace_go_check_types_named_str_A_fn_class); var ifn_1285 lang.IFn; if linked_1284 == nil { ifn_1285 = lang.IFn_Cast(root_1283) } else { ifn_1285 = nil }; var arg_1286 any = t__0; if linked_1284 == nil { return ifn_1285.Invoke_O__O(arg_1286) } else { return linked_1284.(*A_arbace_go_check_types_named_str_A).Invoke_O_O__O(root_1283, arg_1286) } } else {
//line :451:1
					var tmp5 any; var root_1287 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_1288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1287, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_1289 lang.IFn


					if linked_1288 == nil { ifn_1289 = lang.IFn_Cast(root_1287) } else { ifn_1289 = nil }; var arg_1290 any = t__0; if linked_1288 == nil { tmp5 = ifn_1289.Invoke_O__O(arg_1290) } else { tmp5 = linked_1288.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_1287, arg_1290) }
//line :451:1
					if jrt.J2g_Truth(tmp5) {


						var tmp6 *lang.Keyword = A_arbace_go_check_types_A_const_12; var tmp7 any; var root_1291 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1291, A_arbace_go_check_types_info_A_fn_class); var ifn_1293 lang.IFn; if linked_1292 == nil { ifn_1293 = lang.IFn_Cast(root_1291) } else { ifn_1293 = nil }; var arg_1294 any = t__0; if linked_1292 == nil { tmp7 = ifn_1293.Invoke_O__O(arg_1294) } else { tmp7 = linked_1292.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1291, arg_1294) }; return tmp6.Invoke_O__O(tmp7) } else {
//line :451:1
							if A_arbace_go_check_types_A_const_75 != nil { var G__219000212__2_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))




								switch lang.Util_Hash_O__I_NoInit(G__219000212__2_) >> 5 & 31 { case 0: if any(G__219000212__2_) == any(A_arbace_go_check_types_A_const_100) {





















									var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_21, nil, Lit_22); var tmp9 any; var root_1296 any = A_arbace_go_check_types_A_const_164.GetRawRoot__O(); var linked_1297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1296, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1298 lang.IFn; if linked_1297 == nil { ifn_1298 = lang.IFn_Cast(root_1296) } else { ifn_1298 = nil }; var arg_1299 any = Lit_23; var arg_1300 any; var root_1301 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var arg_1305 any; var root_1306 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1306, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1308 lang.IFn; if linked_1307 == nil { ifn_1308 = lang.IFn_Cast(root_1306) } else { ifn_1308 = nil }; var arg_1309 any = t__0; if linked_1307 == nil { arg_1305 = ifn_1308.Invoke_O__O(arg_1309) } else { arg_1305 = linked_1307.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1306, arg_1309) }; if linked_1302 == nil { arg_1300 = ifn_1303.Invoke_O_O__O(arg_1304, arg_1305) } else { arg_1300 = linked_1302.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1301, arg_1304, arg_1305) }; if linked_1297 == nil { tmp9 = ifn_1298.Invoke_O_O__O(arg_1299, arg_1300) } else { tmp9 = linked_1297.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1296, arg_1299, arg_1300) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil)).Ref() }
//line :456:1
								case 1: if any(G__219000212__2_) == any(A_arbace_go_check_types_A_const_86) { var ms__3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var ts__4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var tmp10 any; var and__1927000168__auto____5 any; var root_1310 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1310, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1312 lang.IFn












									if linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any = ms__3; if linked_1311 == nil { and__1927000168__auto____5 = ifn_1312.Invoke_O__O(arg_1313) } else { and__1927000168__auto____5 = linked_1311.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1310, arg_1313) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(ts__4, nil)).Ref() } else { tmp10 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp10) { return Lit_52 } else {

										var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_53, nil, Lit_54); var tmp12 any; var root_1314 any = A_arbace_go_check_types_A_const_164.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1314, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1316 lang.IFn
										if linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any = Lit_55; var arg_1318 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_127.GetRawRoot__O()); var tmp14 any; if jrt.J2g_Truth(A_arbace_go_check_types_A_const_110.Invoke_O__O(ts__4)) { tmp14 = A_arbace_go_check_types_A_const_178 } else { tmp14 = nil }; var tmp15 any = tmp14; var tmp16 any; var iter__1927001039__auto____8 any; var tmp17 any = A_arbace_go_check_types_type_str_iter__219000213__219000217_A_New(); var tmp18 *jrt.Class; var fncls__1391 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000213__219000217_A_fn_class
										if fncls__1391 == nil { var fncls__1391d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_check_types_type_str_iter__219000213__219000217_A_fn_class = fncls__1391d; tmp18 = fncls__1391d } else { tmp18 = fncls__1391 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); tmp16 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(ms__3)
//line :472:1
										var tmp19 any = tmp16; var tmp20 lang.IPersistentVector; var tmp21 any; var and__1927000168__auto____8 any; var root_1392 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1392, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1394 lang.IFn

										if linked_1393 == nil { ifn_1394 = lang.IFn_Cast(root_1392) } else { ifn_1394 = nil }; var arg_1395 any = ts__4; if linked_1393 == nil { and__1927000168__auto____8 = ifn_1394.Invoke_O__O(arg_1395) } else { and__1927000168__auto____8 = linked_1393.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1392, arg_1395) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1396 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1396, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = A_arbace_go_check_types_A_const_108; var arg_1400 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__4); if linked_1397 == nil { tmp21 = ifn_1398.Invoke_O_O__O(arg_1399, arg_1400) } else { tmp21 = linked_1397.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1396, arg_1399, arg_1400) } } else { tmp21 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp21) { var tmp22 any; var root_1401 any = A_arbace_go_check_types_A_const_180.GetRawRoot__O(); var linked_1402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1401, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_1403 lang.IFn
											if linked_1402 == nil { ifn_1403 = lang.IFn_Cast(root_1401) } else { ifn_1403 = nil }; var arg_1404 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__4); if linked_1402 == nil { tmp22 = ifn_1403.Invoke_O__O(arg_1404) } else { tmp22 = linked_1402.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_1401, arg_1404) }
//line :474:1
											tmp20 = lang.Tuple_Create_O__IPersistentVector(tmp22) } else { tmp20 = nil }
//line :472:1
										arg_1318 = tmp13.Invoke_O_O_O__O(tmp15, tmp19, tmp20); if linked_1315 == nil { tmp12 = ifn_1316.Invoke_O_O__O(arg_1317, arg_1318) } else { tmp12 = linked_1315.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1314, arg_1317, arg_1318) }
//line :471:1
										return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, nil)).Ref() } }
//line :456:1
								case 3: if any(G__219000212__2_) == any(A_arbace_go_check_types_A_const_87) {
									var tmp23 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_57, nil); var tmp24 any; var root_1405 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1405, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1407 lang.IFn; if linked_1406 == nil { ifn_1407 = lang.IFn_Cast(root_1405) } else { ifn_1407 = nil }; var arg_1408 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1406 == nil { tmp24 = ifn_1407.Invoke_O__O(arg_1408) } else { tmp24 = linked_1406.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1405, arg_1408) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp23, jrt.RefArrayOf(jrt.Object_class, nil, tmp24)).Ref() }
//line :456:1
								case 4: if any(G__219000212__2_) == any(A_arbace_go_check_types_A_const_97) {


									var tmp25 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_17, nil, Lit_18, nil); var tmp26 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp27 any; var root_1409 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1409, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1411 lang.IFn; if linked_1410 == nil { ifn_1411 = lang.IFn_Cast(root_1409) } else { ifn_1411 = nil }; var arg_1412 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_1410 == nil { tmp27 = ifn_1411.Invoke_O__O(arg_1412) } else { tmp27 = linked_1410.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1409, arg_1412) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp25, jrt.RefArrayOf(jrt.Object_class, nil, tmp26, nil, tmp27)).Ref() }
//line :456:1
								case 8: if any(G__219000212__2_) == any(A_arbace_go_check_types_A_const_95) {



									var tmp28 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_58, nil, Lit_18, nil); var tmp29 any; var root_1417 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1417, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1418 == nil { tmp29 = ifn_1419.Invoke_O__O(arg_1420) } else { tmp29 = linked_1418.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1417, arg_1420) }; var tmp30 any = tmp29; var tmp31 any; var root_1421 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1421, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1423 lang.IFn; if linked_1422 == nil { ifn_1423 = lang.IFn_Cast(root_1421) } else { ifn_1423 = nil }; var arg_1424 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_1422 == nil { tmp31 = ifn_1423.Invoke_O__O(arg_1424) } else { tmp31 = linked_1422.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1421, arg_1424) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp28, jrt.RefArrayOf(jrt.Object_class, nil, tmp30, nil, tmp31)).Ref() }
//line :456:1
								case 14: if any(G__219000212__2_) == any(A_arbace_go_check_types_A_const_96) {

									var tmp32 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_59, nil); var tmp33 any; var root_1425 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1425, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1427 lang.IFn; if linked_1426 == nil { ifn_1427 = lang.IFn_Cast(root_1425) } else { ifn_1427 = nil }; var arg_1428 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1426 == nil { tmp33 = ifn_1427.Invoke_O__O(arg_1428) } else { tmp33 = linked_1426.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1425, arg_1428) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp32, jrt.RefArrayOf(jrt.Object_class, nil, tmp33)).Ref() }
//line :456:1
								case 16: if any(G__219000212__2_) == any(A_arbace_go_check_types_A_const_98) { var e__3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var es__4 any; var root_1429 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1429, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1431 lang.IFn





									if linked_1430 == nil { ifn_1431 = lang.IFn_Cast(root_1429) } else { ifn_1431 = nil }; var arg_1432 any = e__3; if linked_1430 == nil { es__4 = ifn_1431.Invoke_O__O(arg_1432) } else { es__4 = linked_1430.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1429, arg_1432) }
//line :456:1
									var es__5 any; var tmp34 any; var tmp35 any = A_arbace_go_check_types_A_const_158; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp35, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)))






									if and__1927000168__auto____5_2 { var and__1927000168__auto____6 any; var root_1433 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = e__3; if linked_1434 == nil { and__1927000168__auto____6 = ifn_1435.Invoke_O__O(arg_1436) } else { and__1927000168__auto____6 = linked_1434.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1433, arg_1436) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp36 any = A_arbace_go_check_types_A_const_98; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp36, lang.RT_Nth_O_I__O_NoInit(e__3, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____7 { var tmp37 any = A_arbace_go_check_types_A_const_181; tmp34 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp37, lang.RT_Nth_O_I__O_NoInit(e__3, lang.RT_IntCast_J__I_NoInit(1)))).Ref() } else { tmp34 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp34 = and__1927000168__auto____6 } } else { tmp34 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref() }; if jrt.J2g_Truth(tmp34) {
										es__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_21, nil, Lit_22), jrt.RefArrayOf(jrt.Object_class, nil, es__4, nil)).Ref() } else {
//line :463:1
											es__5 = es__4 }
//line :456:1
									var G__219000223__6_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1))








									switch lang.Util_Hash_O__I_NoInit(G__219000223__6_) >> 7 & 3 { case 0: if any(G__219000223__6_) == any(A_arbace_go_check_types_A_const_181) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_60, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; case 2: if any(G__219000223__6_) == any(A_arbace_go_check_types_A_const_158) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; case 3: if any(G__219000223__6_) == any(A_arbace_go_check_types_A_const_182) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_62, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__219000223__6_))))) }
//line :456:1
								case 27: if any(G__219000212__2_) == any(A_arbace_go_check_types_A_const_103) {









									var tmp38 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_64, nil); var tmp39 any; var root_1438 any = A_arbace_go_check_types_A_const_179.GetRawRoot__O(); var linked_1439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1438, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1440 lang.IFn; if linked_1439 == nil { ifn_1440 = lang.IFn_Cast(root_1438) } else { ifn_1440 = nil }; var arg_1441 any = t__0; if linked_1439 == nil { tmp39 = ifn_1440.Invoke_O__O(arg_1441) } else { tmp39 = linked_1439.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1438, arg_1441) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp38, jrt.RefArrayOf(jrt.Object_class, nil, tmp39)).Ref() }
//line :456:1
								case 28: if any(G__219000212__2_) == any(A_arbace_go_check_types_A_const_118) {




















									var root_1442 any = A_arbace_go_check_types_A_const_180.GetRawRoot__O(); var linked_1443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1442, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_1444 lang.IFn; if linked_1443 == nil { ifn_1444 = lang.IFn_Cast(root_1442) } else { ifn_1444 = nil }; var arg_1445 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1443 == nil { return ifn_1444.Invoke_O__O(arg_1445) } else { return linked_1443.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_1442, arg_1445) } }
//line :456:1
								case 31: if any(G__219000212__2_) == any(A_arbace_go_check_types_A_const_105) {










									var tmp40 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_65, nil, Lit_54); var tmp41 any; var root_1446 any = A_arbace_go_check_types_A_const_164.GetRawRoot__O(); var linked_1447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1446, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1448 lang.IFn; if linked_1447 == nil { ifn_1448 = lang.IFn_Cast(root_1446) } else { ifn_1448 = nil }; var arg_1449 any = Lit_55; var arg_1450 any; var root_1451 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1451, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1453 lang.IFn; if linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any = A_arbace_go_check_types_A_const_183.GetRawRoot__O(); var arg_1455 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1452 == nil { arg_1450 = ifn_1453.Invoke_O_O__O(arg_1454, arg_1455) } else { arg_1450 = linked_1452.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1451, arg_1454, arg_1455) }; if linked_1447 == nil { tmp41 = ifn_1448.Invoke_O_O__O(arg_1449, arg_1450) } else { tmp41 = linked_1447.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1446, arg_1449, arg_1450) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp40, jrt.RefArrayOf(jrt.Object_class, nil, tmp41, nil)).Ref() }
//line :456:1
								default:
								}





















								return lang.IFn_Cast(A_arbace_go_check_types_A_const_161.GetRawRoot__O()).Invoke_O__O(t__0) } else {
//line :451:1
									return nil
								}
						}
				}
		}
}
















func A_arbace_go_check_types_type_str_iter__219000213__219000217_A_New() *A_arbace_go_check_types_type_str_iter__219000213__219000217_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000213__219000217_A{}; t.Ctor(); return t }
//line :473:1
func (t *A_arbace_go_check_types_type_str_iter__219000213__219000217_A) Ctor() {}
//line :473:1
func (t *A_arbace_go_check_types_type_str_iter__219000213__219000217_A) Invoke_O_O__O(self, s__219000214__1 any) any { var tmp1 any = A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_A_New_O_O(self, s__219000214__1); var tmp2 *jrt.Class; var fncls__1390 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_A_fn_class; if fncls__1390 == nil { var fncls__1390d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_A_fn_class = fncls__1390d; tmp2 = fncls__1390d } else { tmp2 = fncls__1390 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :473:1
func A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_A{}; t.Ctor_O_O(p0, p1); return t }
//line :473:1
func (t *A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_A) Ctor_O_O(c__iter__219000213, c__s__219000214 any) { t.F_iter__219000213 = c__iter__219000213; t.F_s__219000214 = c__s__219000214 }
//line :473:1
func (t *A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_A) Invoke_O__O(self any) any { { var s__219000214__1 any; var t_ any = t.F_s__219000214; t.F_s__219000214 = nil; s__219000214__1 = t_; for { var temp__1927000414__auto____2 any; var root_1325 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1327 lang.IFn; if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any = s__219000214__1; if linked_1326 == nil { temp__1927000414__auto____2 = ifn_1327.Invoke_O__O(arg_1328) } else { temp__1927000414__auto____2 = linked_1326.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1325, arg_1328) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000214__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1329 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1329, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1331 lang.IFn; if linked_1330 == nil { ifn_1331 = lang.IFn_Cast(root_1329) } else { ifn_1331 = nil }; var arg_1332 any = s__219000214__3; if linked_1330 == nil { tmp1 = ifn_1331.Invoke_O__O(arg_1332) } else { tmp1 = linked_1330.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1329, arg_1332) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1333 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_1334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1333, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1335 lang.IFn; if linked_1334 == nil { ifn_1335 = lang.IFn_Cast(root_1333) } else { ifn_1335 = nil }; var arg_1336 any = s__219000214__3; if linked_1334 == nil { c__1927001037__auto____4 = ifn_1335.Invoke_O__O(arg_1336) } else { c__1927001037__auto____4 = linked_1334.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1333, arg_1336) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000216__6 any; var root_1337 any = A_arbace_go_check_types_A_const_130.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1337, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1339 lang.IFn; if linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1338 == nil { b__219000216__6 = ifn_1339.Invoke_O__O(arg_1340) } else { b__219000216__6 = linked_1338.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1337, arg_1340) }; var tmp2 any = A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_fn__219000219_A_New_O_I_O(b__219000216__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1350 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_fn__219000219_A_fn_class; if fncls__1350 == nil { var fncls__1350d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_fn__219000219_A_fn_class = fncls__1350d; tmp3 = fncls__1350d } else { tmp3 = fncls__1350 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1351 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1351, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1353 lang.IFn; if linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any; var root_1356 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1356, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1358 lang.IFn; if linked_1357 == nil { ifn_1358 = lang.IFn_Cast(root_1356) } else { ifn_1358 = nil }; var arg_1359 any = b__219000216__6; if linked_1357 == nil { arg_1354 = ifn_1358.Invoke_O__O(arg_1359) } else { arg_1354 = linked_1357.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1356, arg_1359) }; var arg_1355 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000213); var tmp5 any; var root_1360 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1360, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1362 lang.IFn; if linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; var arg_1363 any = s__219000214__3; if linked_1361 == nil { tmp5 = ifn_1362.Invoke_O__O(arg_1363) } else { tmp5 = linked_1361.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1360, arg_1363) }; arg_1355 = tmp4.Invoke_O__O(tmp5); if linked_1352 == nil { return ifn_1353.Invoke_O_O__O(arg_1354, arg_1355) } else { return linked_1352.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1351, arg_1354, arg_1355) } } else { var root_1364 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any; var root_1369 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1371 lang.IFn; if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var arg_1372 any = b__219000216__6; if linked_1370 == nil { arg_1367 = ifn_1371.Invoke_O__O(arg_1372) } else { arg_1367 = linked_1370.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1369, arg_1372) }; var arg_1368 any; if linked_1365 == nil { return ifn_1366.Invoke_O_O__O(arg_1367, arg_1368) } else { return linked_1365.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1364, arg_1367, arg_1368) } } } else { var m__4 any; var root_1373 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any = s__219000214__3; if linked_1374 == nil { m__4 = ifn_1375.Invoke_O__O(arg_1376) } else { m__4 = linked_1374.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1373, arg_1376) }; var root_1377 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__4); var tmp8 any; var root_1382 any = A_arbace_go_check_types_A_const_179.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1384 lang.IFn; if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(m__4); if linked_1383 == nil { tmp8 = ifn_1384.Invoke_O__O(arg_1385) } else { tmp8 = linked_1383.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1382, arg_1385) }; arg_1380 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8)).Ref(); var arg_1381 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__219000213); var tmp10 any; var root_1386 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1386, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1388 lang.IFn; if linked_1387 == nil { ifn_1388 = lang.IFn_Cast(root_1386) } else { ifn_1388 = nil }; var arg_1389 any = s__219000214__3; if linked_1387 == nil { tmp10 = ifn_1388.Invoke_O__O(arg_1389) } else { tmp10 = linked_1387.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1386, arg_1389) }; arg_1381 = tmp9.Invoke_O__O(tmp10); if linked_1378 == nil { return ifn_1379.Invoke_O_O__O(arg_1380, arg_1381) } else { return linked_1378.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1377, arg_1380, arg_1381) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :473:1
func A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_fn__219000219_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_fn__219000219_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_fn__219000219_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :473:1
func (t *A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_fn__219000219_A) Ctor_O_I_O(c__b__219000216 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000216 = c__b__219000216; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :473:1
func (t *A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_fn__219000219_A) Invoke_O__O(self any) any { { var i__219000215__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000215__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000215__1)); var root_1341 any = A_arbace_go_check_types_A_const_132.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1341, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1343 lang.IFn; if linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any = t.F_b__219000216; var arg_1345 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__2); var tmp4 any; var root_1346 any = A_arbace_go_check_types_A_const_179.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1348 lang.IFn; if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(m__2); if linked_1347 == nil { tmp4 = ifn_1348.Invoke_O__O(arg_1349) } else { tmp4 = linked_1347.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1346, arg_1349) }; arg_1345 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref(); if linked_1342 == nil { ifn_1343.Invoke_O_O__O(arg_1344, arg_1345) } else { linked_1342.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1341, arg_1344, arg_1345) }; i__219000215__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000215__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }














func A_arbace_go_check_types_align_up_A_New() *A_arbace_go_check_types_align_up_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_align_up_A{}; t.Ctor(); return t }
//line :488:1
func (t *A_arbace_go_check_types_align_up_A) Ctor() {}
//line :488:1
func (t *A_arbace_go_check_types_align_up_A) InvokePrim_O_J_J__J(self any, x__0, a__1 int64) int64 { return lang.Numbers_Multiply_J_J__J_NoInit(a__1, lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(x__0, lang.Numbers_Dec_J__J_NoInit(a__1)), a__1)) }
//line :488:1
func (t *A_arbace_go_check_types_align_up_A) Invoke_O_O_O__O(self, p_x__0, p_a__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_J__J(self, lang.RT_LongCast_O__J_NoInit(p_x__0), lang.RT_LongCast_O__J_NoInit(p_a__1))).Ref() }

func A_arbace_go_check_types_sync_atomic_align64_QMARK__A_New() *A_arbace_go_check_types_sync_atomic_align64_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sync_atomic_align64_QMARK__A{}; t.Ctor(); return t }
//line :490:1
func (t *A_arbace_go_check_types_sync_atomic_align64_QMARK__A) Ctor() {}
//line :490:1
func (t *A_arbace_go_check_types_sync_atomic_align64_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_1456 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1456, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1458 lang.IFn; if



	linked_1457 == nil { ifn_1458 = lang.IFn_Cast(root_1456) } else { ifn_1458 = nil }; var arg_1459 any = t__0; if linked_1457 == nil { and__1927000168__auto____2 = ifn_1458.Invoke_O__O(arg_1459) } else { and__1927000168__auto____2 = linked_1457.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1456, arg_1459) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var i__3 any; var root_1460 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1460, A_arbace_go_check_types_info_A_fn_class); var ifn_1462 lang.IFn
		if linked_1461 == nil { ifn_1462 = lang.IFn_Cast(root_1460) } else { ifn_1462 = nil }; var arg_1463 any = t__0; if linked_1461 == nil { i__3 = ifn_1462.Invoke_O__O(arg_1463) } else { i__3 = linked_1461.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1460, arg_1463) }
//line :494:1
		var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_35, A_arbace_go_check_types_A_const_12.Invoke_O__O(i__3))

		if and__1927000168__auto____4 {
			var root_1464 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1464, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1466 lang.IFn; if linked_1465 == nil { ifn_1466 = lang.IFn_Cast(root_1464) } else { ifn_1466 = nil }; var arg_1467 any = A_arbace_go_check_types_A_const_184; var arg_1468 any = A_arbace_go_check_types_A_const_170.Invoke_O__O(i__3); if linked_1465 == nil { return ifn_1466.Invoke_O_O__O(arg_1467, arg_1468) } else { return linked_1465.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1464, arg_1467, arg_1468) } } else {
//line :496:1
				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else {
//line :494:1
					return and__1927000168__auto____2 } }




func A_arbace_go_check_types_alignof_A_New() *A_arbace_go_check_types_alignof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alignof_A{}; t.Ctor(); return t }
//line :499:1
func (t *A_arbace_go_check_types_alignof_A) Ctor() {}
//line :499:1
func (t *A_arbace_go_check_types_alignof_A) InvokePrim_O_O__J(self, t__0 any) int64 { var tmp1 any; var u__2 any; var root_1469 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, A_arbace_go_check_types_under_A_fn_class); var ifn_1471 lang.IFn; if
											linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = t__0; if linked_1470 == nil { u__2 = ifn_1471.Invoke_O__O(arg_1472) } else { u__2 = linked_1470.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1469, arg_1472) }; var tmp2 any; var and__1927000168__auto____3 any; var root_1473 any =
											A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1475 lang.IFn; if
											linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = u__2; if linked_1474 == nil { and__1927000168__auto____3 = ifn_1475.Invoke_O__O(arg_1476) } else { and__1927000168__auto____3 = linked_1474.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1473, arg_1476) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_go_check_types_A_const_97; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp2 = and__1927000168__auto____3 }; if /*line :501:1*/ jrt.J2g_Truth(tmp2) {
												var root_1477 any = A_arbace_go_check_types_A_const_185.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1477, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1479 lang.IFn; if linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)); if linked_1478 == nil { tmp1 = ifn_1479.Invoke_O__O(arg_1480) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_1478.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1477, arg_1480)).Ref() } } else {
//line :501:1
			var tmp4 any; var and__1927000168__auto____3_2 any; var root_1481 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1481, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1483 lang.IFn

			if linked_1482 == nil { ifn_1483 = lang.IFn_Cast(root_1481) } else { ifn_1483 = nil }; var arg_1484 any = u__2; if linked_1482 == nil { and__1927000168__auto____3_2 = ifn_1483.Invoke_O__O(arg_1484) } else { and__1927000168__auto____3_2 = linked_1482.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1481, arg_1484) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) { var tmp5 any = A_arbace_go_check_types_A_const_105; tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp5, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp4 = and__1927000168__auto____3_2 }
//line :501:1
			if jrt.J2g_Truth(tmp4) {


				var tmp6 any; var and__1927000168__auto____3_3 any; var root_1485 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1485, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1487 lang.IFn; if linked_1486 == nil { ifn_1487 = lang.IFn_Cast(root_1485) } else { ifn_1487 = nil }; var arg_1488 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1486 == nil { and__1927000168__auto____3_3 = ifn_1487.Invoke_O__O(arg_1488) } else { and__1927000168__auto____3_3 = linked_1486.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1485, arg_1488) }; if jrt.J2g_Truth(and__1927000168__auto____3_3) { var root_1489 any = A_arbace_go_check_types_A_const_186.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1489, A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class); var ifn_1491 lang.IFn; if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any = t__0; if linked_1490 == nil { tmp6 = ifn_1491.Invoke_O__O(arg_1492) } else { tmp6 = linked_1490.(*A_arbace_go_check_types_sync_atomic_align64_QMARK__A).Invoke_O_O__O(root_1489, arg_1492) } } else { tmp6 = and__1927000168__auto____3_3 }; if jrt.J2g_Truth(tmp6) { tmp1 = A_arbace_go_check_types_A_const_24 } else {

					var root_1493 any = A_arbace_go_check_types_A_const_187.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1493, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1495 lang.IFn; if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any; var tmp7 any = A_arbace_go_check_types_alignof_fn__219000227_A_New(); var tmp8 *jrt.Class; var fncls__1503 *jrt.Class = A_arbace_go_check_types_alignof_fn__219000227_A_fn_class; if fncls__1503 == nil { var fncls__1503d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_go_check_types_alignof_fn__219000227_A_fn_class = fncls__1503d; tmp8 = fncls__1503d } else { tmp8 = fncls__1503 }; arg_1496 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_1497 any = A_arbace_go_check_types_A_const_15; var arg_1498 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1494 == nil { tmp1 = ifn_1495.Invoke_O_O_O__O(arg_1496, arg_1497, arg_1498) } else { tmp1 = linked_1494.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1493, arg_1496, arg_1497, arg_1498) } } } else {
//line :501:1
						var tmp9 any; var and__1927000168__auto____3_4 any; var root_1504 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1504, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1506 lang.IFn





						if linked_1505 == nil { ifn_1506 = lang.IFn_Cast(root_1504) } else { ifn_1506 = nil }; var arg_1507 any = u__2; if linked_1505 == nil { and__1927000168__auto____3_4 = ifn_1506.Invoke_O__O(arg_1507) } else { and__1927000168__auto____3_4 = linked_1505.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1504, arg_1507) }; if jrt.J2g_Truth(and__1927000168__auto____3_4) { var root_1508 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1508, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1510 lang.IFn; if linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any = A_arbace_go_check_types_A_const_188; var arg_1512 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)); if linked_1509 == nil { tmp9 = ifn_1510.Invoke_O_O__O(arg_1511, arg_1512) } else { tmp9 = linked_1509.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1508, arg_1511, arg_1512) } } else { tmp9 = and__1927000168__auto____3_4 }
//line :501:1
						if jrt.J2g_Truth(tmp9) { tmp1 = A_arbace_go_check_types_A_const_189.GetRawRoot__O() } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_40, u__2) { tmp1 = A_arbace_go_check_types_A_const_189.GetRawRoot__O() } else { if A_arbace_go_check_types_A_const_75 != nil { var a__3 any; var root_1513 any = A_arbace_go_check_types_A_const_190.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1513, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1515 lang.IFn








							if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = t__0; if linked_1514 == nil { a__3 = ifn_1515.Invoke_O__O(arg_1516) } else { a__3 = jrt.Long_ValueOf_J__Long_NoInit(linked_1514.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1513, arg_1516)).Ref() }
//line :501:1
							var a__4 any; var tmp10 bool
							var na_1517 any = a__3
							var na_1518 int64 = 1







							if jrt.Long_InstanceOf(na_1517) { var n0_1519 int64 = jrt.NN(jrt.Long_Cast(na_1517)).LongValue__J(); var n1_1520 int64 = na_1518; tmp10 = n0_1519 < n1_1520 } else { tmp10 = lang.Numbers_Lt_O_J__Z_NoInit(na_1517, na_1518) }; if tmp10 { a__4 = A_arbace_go_check_types_A_const_15 } else { a__4 = a__3 }
//line :501:1
							var a__5 any; var tmp11 any; var root_1522 any = A_arbace_go_check_types_A_const_82.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1522, A_arbace_go_check_types_complex_type_QMARK__A_fn_class); var ifn_1524 lang.IFn










							if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = t__0; if linked_1523 == nil { tmp11 = ifn_1524.Invoke_O__O(arg_1525) } else { tmp11 = linked_1523.(*A_arbace_go_check_types_complex_type_QMARK__A).Invoke_O_O__O(root_1522, arg_1525) }; if jrt.J2g_Truth(tmp11) { var na_1526 any = a__4; var na_1527 int64 = 2; if jrt.Long_InstanceOf(na_1526) { var n0_1528 int64 = jrt.NN(jrt.Long_Cast(na_1526)).LongValue__J(); var n1_1529 int64 = na_1527; if n1_1529 == 0 { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1526, na_1527) } else { a__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_1528 / n1_1529).Ref() } } else { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1526, na_1527) } } else { a__5 = a__4 }
							tmp1 = lang.Numbers_Min_O_O__O_NoInit(a__5, A_arbace_go_check_types_A_const_191.GetRawRoot__O()) } else {
//line :501:1
								tmp1 = nil } } } } }; return /*line :499:1*/ jrt.Number_Cast(tmp1).LongValue__J() }
//line :499:1
func (t *A_arbace_go_check_types_alignof_A) Invoke_O_O__O(self, t__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, t__0)).Ref() }






func A_arbace_go_check_types_alignof_fn__219000227_A_New() *A_arbace_go_check_types_alignof_fn__219000227_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alignof_fn__219000227_A{}; t.Ctor(); return t }
//line :506:1
func (t *A_arbace_go_check_types_alignof_fn__219000227_A) Ctor() {}
//line :506:1
func (t *A_arbace_go_check_types_alignof_fn__219000227_A) Invoke_O_O_O__O(self, m__1, f__2 any) any { var tmp1 int64; var root_1499 any = A_arbace_go_check_types_A_const_185.GetRawRoot__O(); var linked_1500 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1499, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1501 lang.IFn; if linked_1500 == nil { ifn_1501 = lang.IFn_Cast(root_1499) } else { ifn_1501 = nil }; var arg_1502 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(f__2); if linked_1500 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_1501.Invoke_O__O(arg_1502)) } else { tmp1 = linked_1500.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1499, arg_1502) }; return lang.Numbers_Max_O_J__O_NoInit(m__1, tmp1) }








func A_arbace_go_check_types_offsetsof_A_New() *A_arbace_go_check_types_offsetsof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_offsetsof_A{}; t.Ctor(); return t }
//line :515:1
func (t *A_arbace_go_check_types_offsetsof_A) Ctor() {}
//line :515:1
func (t *A_arbace_go_check_types_offsetsof_A) Invoke_O_O__O(self, fields__0 any) any { { var fs__2 any = fields__0; var offs__3 any = lang.RT_Box_J__Number_NoInit(0); var acc__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for {

	var tmp1 any; var root_1531 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1531, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1533 lang.IFn; if linked_1532 == nil { ifn_1533 = lang.IFn_Cast(root_1531) } else { ifn_1533 = nil }; var arg_1534 any = fs__2; if linked_1532 == nil { tmp1 = ifn_1533.Invoke_O__O(arg_1534) } else { tmp1 = linked_1532.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1531, arg_1534) }; if jrt.J2g_Truth(tmp1) { return acc__4 } else { var f__5 any; var root_1535 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_1536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1535, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1537 lang.IFn

		if linked_1536 == nil { ifn_1537 = lang.IFn_Cast(root_1535) } else { ifn_1537 = nil }; var arg_1538 any = fs__2; if linked_1536 == nil { f__5 = ifn_1537.Invoke_O__O(arg_1538) } else { f__5 = linked_1536.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1535, arg_1538) }
//line :517:1
		var o__6 any; var root_1539 any = A_arbace_go_check_types_A_const_192.GetRawRoot__O(); var linked_1540 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1539, A_arbace_go_check_types_align_up_A_fn_class); var ifn_1541 lang.IFn


		if linked_1540 == nil { ifn_1541 = lang.IFn_Cast(root_1539) } else { ifn_1541 = nil }; var arg_1542 any = offs__3; var arg_1543 any; var root_1544 any = A_arbace_go_check_types_A_const_185.GetRawRoot__O(); var linked_1545 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1544, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1546 lang.IFn; if linked_1545 == nil { ifn_1546 = lang.IFn_Cast(root_1544) } else { ifn_1546 = nil }; var arg_1547 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(f__5); if linked_1545 == nil { arg_1543 = ifn_1546.Invoke_O__O(arg_1547) } else { arg_1543 = jrt.Long_ValueOf_J__Long_NoInit(linked_1545.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1544, arg_1547)).Ref() }; if linked_1540 == nil { o__6 = ifn_1541.Invoke_O_O__O(arg_1542, arg_1543) } else { o__6 = jrt.Long_ValueOf_J__Long_NoInit(linked_1540.(*A_arbace_go_check_types_align_up_A).InvokePrim_O_J_J__J(root_1539, lang.RT_LongCast_O__J_NoInit(arg_1542), lang.RT_LongCast_O__J_NoInit(arg_1543))).Ref() }
		var tmp2 any; var root_1548 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1550 lang.IFn; if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any = fs__2; if linked_1549 == nil { tmp2 = ifn_1550.Invoke_O__O(arg_1551) } else { tmp2 = linked_1549.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1548, arg_1551) }; var tmp3 any = tmp2; var tmp4 jrt.Number_I; var na_1552 any = o__6; var na_1553 any; var root_1554 any = A_arbace_go_check_types_A_const_190.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1554, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1556 lang.IFn; if linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(f__5); if linked_1555 == nil { na_1553 = ifn_1556.Invoke_O__O(arg_1557) } else { na_1553 = jrt.Long_ValueOf_J__Long_NoInit(linked_1555.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1554, arg_1557)).Ref() }; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_1552); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_1553) }; tmp5 = tmp6; if tmp5 { var n0_1558 int64 = jrt.NN(jrt.Long_Cast(na_1552)).LongValue__J(); var n1_1559 int64 = jrt.NN(jrt.Long_Cast(na_1553)).LongValue__J(); var nr_1560 int64 = n0_1558 + n1_1559; if (n0_1558^nr_1560)&(n1_1559^nr_1560) >= 0 { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1560)) } else { tmp4 = lang.Numbers_Add_O_O__Number_NoInit(na_1552, na_1553) } } else { var tmp7 bool; var tmp8 bool; tmp8 = jrt.Double_InstanceOf(na_1552); if tmp8 { tmp8 = jrt.Double_InstanceOf(na_1553) }; tmp7 = tmp8; if tmp7 { var n0_1558_2 float64 = jrt.NN(jrt.Double_Cast(na_1552)).DoubleValue__D(); var n1_1559_2 float64 = jrt.NN(jrt.Double_Cast(na_1553)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1558_2 + n1_1559_2)) } else { tmp4 = lang.Numbers_Add_O_O__Number_NoInit(na_1552, na_1553) } }; var tmp9 any = tmp4; var tmp10 any; var root_1561 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1563 lang.IFn; if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any = acc__4; var arg_1565 any = o__6; if linked_1562 == nil { tmp10 = ifn_1563.Invoke_O_O__O(arg_1564, arg_1565) } else { tmp10 = linked_1562.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1561, arg_1564, arg_1565) }; fs__2, offs__3, acc__4 = tmp3, tmp9, tmp10; continue L1 } } }; /*line :515:1*/panic("j2g: unreachable") }







func A_arbace_go_check_types_sizeof_A_New() *A_arbace_go_check_types_sizeof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sizeof_A{}; t.Ctor(); return t }
//line :523:1
func (t *A_arbace_go_check_types_sizeof_A) Ctor() {}
//line :523:1
func (t *A_arbace_go_check_types_sizeof_A) InvokePrim_O_O__J(self, t__0 any) int64 { var tmp1 any; var u__2 any; var root_1566 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1566, A_arbace_go_check_types_under_A_fn_class); var ifn_1568 lang.IFn; if
											linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any = t__0; if linked_1567 == nil { u__2 = ifn_1568.Invoke_O__O(arg_1569) } else { u__2 = linked_1567.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1566, arg_1569) }; var tmp2 any; var root_1570 any =
											A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1570, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_1572 lang.IFn; if
											linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = u__2; if linked_1571 == nil { tmp2 = ifn_1572.Invoke_O__O(arg_1573) } else { tmp2 = linked_1571.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_1570, arg_1573) }; if /*line :525:1*/ jrt.J2g_Truth(tmp2) { var G__219000231__3_ any = u__2
											L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__219000231__3_) { case 717828005: if any(G__219000231__3_) == any(A_arbace_go_check_types_A_const_40) { var na_1575 int64 = 2; var na_1576 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1576) { var n0_1577 int64 = na_1575; var n1_1578 int64 = jrt.NN(jrt.Long_Cast(na_1576)).LongValue__J(); var nr_1579 int64 = n0_1577 * n1_1578; var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; tmp6 = n0_1577 == -9223372036854775808; if tmp6 { tmp6 = n1_1578 < 0 }; tmp5 = tmp6; tmp4 = !tmp5; if tmp4 { var tmp7 bool; tmp7 = n1_1578 == 0; if !tmp7 { tmp7 = nr_1579/n1_1578 == n0_1577 }; tmp4 = tmp7 }; tmp3 = tmp4; if tmp3 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1579).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1575, na_1576) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1575, na_1576) }; break L1 }; default:}; var tmp8 lang.IFn = A_arbace_go_check_types_A_const_11; tmp1 = tmp8.Invoke_O_O__O(lang.IFn_Cast(A_arbace_go_check_types_A_const_78.GetRawRoot__O()).Invoke_O__O(u__2), A_arbace_go_check_types_A_const_189.GetRawRoot__O())} } else {
//line :525:1
		if A_arbace_go_check_types_A_const_75 != nil { var G__219000232__3_ any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0))


		L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__219000232__3_) >> 5 & 3 { case 0: if any(G__219000232__3_) == any(A_arbace_go_check_types_A_const_97) { var n__4 int64 = lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)))

			if lang.Numbers_Lte_J_J__Z_NoInit(n__4, 0) { tmp1 = A_arbace_go_check_types_A_const_44 } else { var tmp9 int64; var root_1581 any = A_arbace_go_check_types_A_const_190.GetRawRoot__O(); var linked_1582 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1581, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1583 lang.IFn; if linked_1582 == nil { ifn_1583 = lang.IFn_Cast(root_1581) } else { ifn_1583 = nil }; var arg_1584 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)); if linked_1582 == nil { tmp9 = lang.RT_LongCast_O__J_NoInit(ifn_1583.Invoke_O__O(arg_1584)) } else { tmp9 = linked_1582.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1581, arg_1584) }; tmp1 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(n__4, tmp9)).Ref() }
//line :528:1
			break L2 }; case 1: if any(G__219000232__3_) == any(A_arbace_go_check_types_A_const_86) {











				var na_1585 int64 = 2; var na_1586 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1586) { var n0_1587 int64 = na_1585; var n1_1588 int64 = jrt.NN(jrt.Long_Cast(na_1586)).LongValue__J(); var nr_1589 int64 = n0_1587 * n1_1588; var tmp10 bool; var tmp11 bool; var tmp12 bool; var tmp13 bool; tmp13 = n0_1587 == -9223372036854775808; if tmp13 { tmp13 = n1_1588 < 0 }; tmp12 = tmp13; tmp11 = !tmp12; if tmp11 { var tmp14 bool; tmp14 = n1_1588 == 0; if !tmp14 { tmp14 = nr_1589/n1_1588 == n0_1587 }; tmp11 = tmp14 }; tmp10 = tmp11; if tmp10 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1589).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1585, na_1586) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1585, na_1586) }
//line :528:1
				break L2 }; case 2: if any(G__219000232__3_) == any(A_arbace_go_check_types_A_const_96) {


					var na_1590 int64 = 3; var na_1591 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1591) { var n0_1592 int64 = na_1590; var n1_1593 int64 = jrt.NN(jrt.Long_Cast(na_1591)).LongValue__J(); var nr_1594 int64 = n0_1592 * n1_1593; var tmp15 bool; var tmp16 bool; var tmp17 bool; var tmp18 bool; tmp18 = n0_1592 == -9223372036854775808; if tmp18 { tmp18 = n1_1593 < 0 }; tmp17 = tmp18; tmp16 = !tmp17; if tmp16 { var tmp19 bool; tmp19 = n1_1593 == 0; if !tmp19 { tmp19 = nr_1594/n1_1593 == n0_1592 }; tmp16 = tmp19 }; tmp15 = tmp16; if tmp15 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1594).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1590, na_1591) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1590, na_1591) }
//line :528:1
					break L2 }; case 3: if any(G__219000232__3_) == any(A_arbace_go_check_types_A_const_105) { var fs__4 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); var tmp20 any; var root_1595 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1597 lang.IFn




						if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any = fs__4; if linked_1596 == nil { tmp20 = ifn_1597.Invoke_O__O(arg_1598) } else { tmp20 = linked_1596.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1595, arg_1598) }; if jrt.J2g_Truth(tmp20) { tmp1 = A_arbace_go_check_types_A_const_44 } else { var offs__5 any; var root_1599 any = A_arbace_go_check_types_A_const_193.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, A_arbace_go_check_types_offsetsof_A_fn_class); var ifn_1601 lang.IFn

							if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = fs__4; if linked_1600 == nil { offs__5 = ifn_1601.Invoke_O__O(arg_1602) } else { offs__5 = linked_1600.(*A_arbace_go_check_types_offsetsof_A).Invoke_O_O__O(root_1599, arg_1602) }
//line :533:1
							var o__6 int64; var tmp21 any; var root_1603 any = A_arbace_go_check_types_A_const_194.GetRawRoot__O(); var linked_1604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1603, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_1605 lang.IFn


							if linked_1604 == nil { ifn_1605 = lang.IFn_Cast(root_1603) } else { ifn_1605 = nil }; var arg_1606 any = offs__5; if linked_1604 == nil { tmp21 = ifn_1605.Invoke_O__O(arg_1606) } else { tmp21 = linked_1604.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_1603, arg_1606) }; o__6 = lang.RT_LongCast_O__J_NoInit(tmp21)
//line :533:1
							var s__7 any; var root_1607 any = A_arbace_go_check_types_A_const_190.GetRawRoot__O(); var linked_1608 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1607, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1609 lang.IFn



							if linked_1608 == nil { ifn_1609 = lang.IFn_Cast(root_1607) } else { ifn_1609 = nil }; var arg_1610 any; var tmp22 *lang.Keyword = A_arbace_go_check_types_A_const_107; var tmp23 any; var root_1611 any = A_arbace_go_check_types_A_const_194.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1611, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_1613 lang.IFn; if linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any = fs__4; if linked_1612 == nil { tmp23 = ifn_1613.Invoke_O__O(arg_1614) } else { tmp23 = linked_1612.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_1611, arg_1614) }; arg_1610 = tmp22.Invoke_O__O(tmp23); if linked_1608 == nil { s__7 = ifn_1609.Invoke_O__O(arg_1610) } else { s__7 = jrt.Long_ValueOf_J__Long_NoInit(linked_1608.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1607, arg_1610)).Ref() }
//line :533:1
							var s__8 any; var tmp24 bool; var and__1927000168__auto____8 bool = lang.Numbers_IsPos_J__Z_NoInit(o__6)




							if and__1927000168__auto____8 { var na_1615 any = s__7; if jrt.Long_InstanceOf(na_1615) { var n0_1616 int64 = jrt.NN(jrt.Long_Cast(na_1615)).LongValue__J(); tmp24 = n0_1616 == 0 } else { if jrt.Double_InstanceOf(na_1615) { var n0_1616_2 float64 = jrt.NN(jrt.Double_Cast(na_1615)).DoubleValue__D(); tmp24 = n0_1616_2 == 0.0 } else { tmp24 = lang.Numbers_IsZero_O__Z_NoInit(na_1615) } } } else { tmp24 = and__1927000168__auto____8 }; if tmp24 { s__8 = A_arbace_go_check_types_A_const_15 } else { s__8 = s__7 }
							var root_1617 any = A_arbace_go_check_types_A_const_192.GetRawRoot__O(); var linked_1618 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1617, A_arbace_go_check_types_align_up_A_fn_class); var ifn_1619 lang.IFn; if linked_1618 == nil { ifn_1619 = lang.IFn_Cast(root_1617) } else { ifn_1619 = nil }; var arg_1620 any; var na_1622 int64 = o__6; var na_1623 any = s__8; if jrt.Long_InstanceOf(na_1623) { var n0_1624 int64 = na_1622; var n1_1625 int64 = jrt.NN(jrt.Long_Cast(na_1623)).LongValue__J(); var nr_1626 int64 = n0_1624 + n1_1625; if (n0_1624^nr_1626)&(n1_1625^nr_1626) >= 0 { arg_1620 = jrt.Long_ValueOf_J__Long_NoInit(nr_1626).Ref() } else { arg_1620 = lang.Numbers_Add_J_O__Number_NoInit(na_1622, na_1623) } } else { arg_1620 = lang.Numbers_Add_J_O__Number_NoInit(na_1622, na_1623) }; var arg_1621 any; var root_1627 any = A_arbace_go_check_types_A_const_185.GetRawRoot__O(); var linked_1628 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1627, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1629 lang.IFn; if linked_1628 == nil { ifn_1629 = lang.IFn_Cast(root_1627) } else { ifn_1629 = nil }; var arg_1630 any = t__0; if linked_1628 == nil { arg_1621 = ifn_1629.Invoke_O__O(arg_1630) } else { arg_1621 = jrt.Long_ValueOf_J__Long_NoInit(linked_1628.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1627, arg_1630)).Ref() }; if linked_1618 == nil { tmp1 = ifn_1619.Invoke_O_O__O(arg_1620, arg_1621) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_1618.(*A_arbace_go_check_types_align_up_A).InvokePrim_O_J_J__J(root_1617, lang.RT_LongCast_O__J_NoInit(arg_1620), lang.RT_LongCast_O__J_NoInit(arg_1621))).Ref() } }
//line :528:1
						break L2 }; default:}; tmp1 = A_arbace_go_check_types_A_const_189.GetRawRoot__O()} } else {
//line :525:1
							tmp1 = nil } }; return /*line :523:1*/ jrt.Number_Cast(tmp1).LongValue__J() }
//line :523:1
func (t *A_arbace_go_check_types_sizeof_A) Invoke_O_O__O(self, t__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, t__0)).Ref() }





















func A_arbace_go_check_types_deref_type_A_New() *A_arbace_go_check_types_deref_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_deref_type_A{}; t.Ctor(); return t }
//line :545:1
func (t *A_arbace_go_check_types_deref_type_A) Ctor() {}
//line :545:1
func (t *A_arbace_go_check_types_deref_type_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_1631 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1631, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1633 lang.IFn; if linked_1632 == nil { ifn_1633 = lang.IFn_Cast(root_1631) } else { ifn_1633 = nil }; var arg_1634 any = t__0; if linked_1632 == nil { and__1927000168__auto____2 = ifn_1633.Invoke_O__O(arg_1634) } else { and__1927000168__auto____2 = linked_1632.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1631, arg_1634) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_types_A_const_87; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)), jrt.Boolean_TRUE.Ref()) } else { return lang.Tuple_Create_O_O__IPersistentVector(t__0, jrt.Boolean_FALSE.Ref())
	} }
func A_arbace_go_check_types_methods_of_A_New() *A_arbace_go_check_types_methods_of_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_methods_of_A{}; t.Ctor(); return t }
//line :550:1
func (t *A_arbace_go_check_types_methods_of_A) Ctor() {}
//line :550:1
func (t *A_arbace_go_check_types_methods_of_A) Invoke_O_O__O(self, t__0 any) any { var t__2 any; var tmp1 *lang.Keyword = A_arbace_go_check_types_A_const_195; var tmp2 any; var root_1635 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1635, A_arbace_go_check_types_info_A_fn_class); var ifn_1637 lang.IFn; if


	linked_1636 == nil { ifn_1637 = lang.IFn_Cast(root_1635) } else { ifn_1637 = nil }; var arg_1638 any = t__0; if linked_1636 == nil { tmp2 = ifn_1637.Invoke_O__O(arg_1638) } else { tmp2 = linked_1636.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1635, arg_1638) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 *lang.Keyword = A_arbace_go_check_types_A_const_195; var tmp4 any; var root_1639 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1639, A_arbace_go_check_types_info_A_fn_class); var ifn_1641 lang.IFn; if linked_1640 == nil { ifn_1641 = lang.IFn_Cast(root_1639) } else { ifn_1641 = nil }; var arg_1642 any = t__0; if linked_1640 == nil { tmp4 = ifn_1641.Invoke_O__O(arg_1642) } else { tmp4 = linked_1640.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1639, arg_1642) }; t__2 = tmp3.Invoke_O__O(tmp4) } else { t__2 = t__0 }; var root_1647 any =
	A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1647, A_arbace_go_check_types_under_A_fn_class); var ifn_1649 lang.IFn; if linked_1648 == nil { ifn_1649 = lang.IFn_Cast(root_1647) } else { ifn_1649 = nil }; var arg_1650 any = t__2; if linked_1648 == nil { ifn_1649.Invoke_O__O(arg_1650) } else { linked_1648.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1647, arg_1650) }; var tmp5 /*line :555:1*/*lang.Keyword = A_arbace_go_check_types_A_const_62; var tmp6 any; var root_1643 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1643, A_arbace_go_check_types_info_A_fn_class); var ifn_1645 lang.IFn; if linked_1644 == nil { ifn_1645 = lang.IFn_Cast(root_1643) } else { ifn_1645 = nil }; var arg_1646 any = t__2; if linked_1644 == nil { tmp6 = ifn_1645.Invoke_O__O(arg_1646) } else { tmp6 = linked_1644.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1643, arg_1646) }; return tmp5.Invoke_O__O(tmp6) }





func A_arbace_go_check_types_same_id_QMARK__A_New() *A_arbace_go_check_types_same_id_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_same_id_QMARK__A{}; t.Ctor(); return t }
//line :561:1
func (t *A_arbace_go_check_types_same_id_QMARK__A) Ctor() {}
//line :561:1
func (t *A_arbace_go_check_types_same_id_QMARK__A) Invoke_O_O_O_O_O__O(self, n__0, p__1, name__2, pkg__3 any) any {



	var tmp1 any; var and__1927000168__auto____5 any = A_arbace_go_check_types_A_const_196.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.String_Cast(n__0)).EqualsIgnoreCase_String__Z(jrt.String_Cast(name__2))).Ref() } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, name__2)

		if and__1927000168__auto____5_2 { var or__1927000174__auto____6 bool = jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(name__2)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))
			if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(p__1, pkg__3); if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { return jrt.Boolean_FALSE.Ref() } } } else {
//line :567:1
				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref()
			}
	}
}


func A_arbace_go_check_types_exported_QMARK__A_New() *A_arbace_go_check_types_exported_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_exported_QMARK__A{}; t.Ctor(); return t }
//line :573:1
func (t *A_arbace_go_check_types_exported_QMARK__A) Ctor() {}
//line :573:1
func (t *A_arbace_go_check_types_exported_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var cp__2 int32 = jrt.NN(jrt.String_Cast(n__0)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(0)); return /*line :574:1*/ jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_I__Z_NoInit(cp__2)).Ref() }











func A_arbace_go_check_types_named_method_A_New() *A_arbace_go_check_types_named_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_method_A{}; t.Ctor(); return t }
//line :586:1
func (t *A_arbace_go_check_types_named_method_A) Ctor() {}
//line :586:1
func (t *A_arbace_go_check_types_named_method_A) Invoke_O_O_O_O__O(self, t__0, name__1, pkg__2 any) any { { var ms__4 any; var root_1651 any = A_arbace_go_check_types_A_const_197.GetRawRoot__O(); var linked_1652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1651, A_arbace_go_check_types_methods_of_A_fn_class); var ifn_1653 lang.IFn


	if linked_1652 == nil { ifn_1653 = lang.IFn_Cast(root_1651) } else { ifn_1653 = nil }; var arg_1654 any = t__0; if linked_1652 == nil { ms__4 = ifn_1653.Invoke_O__O(arg_1654) } else { ms__4 = linked_1652.(*A_arbace_go_check_types_methods_of_A).Invoke_O_O__O(root_1651, arg_1654) }
//line :586:1
	var i__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i__5, int64(lang.RT_Count_O__I_NoInit(ms__4))) { var m__6 any = lang.RT_Nth_O_I__O_NoInit(ms__4, lang.RT_IntCast_J__I_NoInit(i__5)); var map__219000238__7 any; var root_1655 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_1656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1655, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1657 lang.IFn
			if linked_1656 == nil { ifn_1657 = lang.IFn_Cast(root_1655) } else { ifn_1657 = nil }; var arg_1658 any = m__6; if linked_1656 == nil { map__219000238__7 = ifn_1657.Invoke_O__O(arg_1658) } else { map__219000238__7 = linked_1656.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1655, arg_1658) }
//line :591:1
			var map__219000238__8 any
			if lang.ISeq_InstanceOf(map__219000238__7) { var tmp1 any; var root_1659 any = A_arbace_go_check_types_A_const_198.GetRawRoot__O(); var linked_1660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1659, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1661 lang.IFn; if linked_1660 == nil { ifn_1661 = lang.IFn_Cast(root_1659) } else { ifn_1661 = nil }; var arg_1662 any = map__219000238__7; if linked_1660 == nil { tmp1 = ifn_1661.Invoke_O__O(arg_1662) } else { tmp1 = linked_1660.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1659, arg_1662) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1663 any = A_arbace_go_check_types_A_const_199.GetRawRoot__O(); var linked_1664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1663, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1665 lang.IFn; if linked_1664 == nil { ifn_1665 = lang.IFn_Cast(root_1663) } else { ifn_1665 = nil }; var arg_1666 any = map__219000238__7; if linked_1664 == nil { tmp2 = ifn_1665.Invoke_O__O(arg_1666) } else { tmp2 = linked_1664.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1663, arg_1666) }; map__219000238__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1667 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_1668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1667, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1669 lang.IFn; if linked_1668 == nil { ifn_1669 = lang.IFn_Cast(root_1667) } else { ifn_1669 = nil }; var arg_1670 any = map__219000238__7; if linked_1668 == nil { tmp3 = ifn_1669.Invoke_O__O(arg_1670) } else { tmp3 = linked_1668.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1667, arg_1670) }; if jrt.J2g_Truth(tmp3) { var root_1671 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1671, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any = map__219000238__7; if linked_1672 == nil { map__219000238__8 = ifn_1673.Invoke_O__O(arg_1674) } else { map__219000238__8 = linked_1672.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1671, arg_1674) } } else { map__219000238__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__219000238__8 = map__219000238__7 }
//line :591:1
			var mn__9 any = lang.RT_Get_O_O__O_NoInit(map__219000238__8, A_arbace_go_check_types_A_const_12); var mp__10 any = lang.RT_Get_O_O__O_NoInit(map__219000238__8, A_arbace_go_check_types_A_const_170); var tmp4 any; var root_1675 any = A_arbace_go_check_types_A_const_200.GetRawRoot__O(); var linked_1676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1675, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_1677 lang.IFn


			if linked_1676 == nil { ifn_1677 = lang.IFn_Cast(root_1675) } else { ifn_1677 = nil }; var arg_1678 any = mn__9; var arg_1679 any = mp__10; var arg_1680 any = name__1; var arg_1681 any = pkg__2; if linked_1676 == nil { tmp4 = ifn_1677.Invoke_O_O_O_O__O(arg_1678, arg_1679, arg_1680, arg_1681) } else { tmp4 = linked_1676.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_1675, arg_1678, arg_1679, arg_1680, arg_1681) }; if jrt.J2g_Truth(tmp4) { return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__5).Ref(), m__6) } else {

				i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } } else {
//line :591:1
					return nil } } }; /*line :586:1*/panic("j2g: unreachable") }











func A_arbace_go_check_types_iface_method_A_New() *A_arbace_go_check_types_iface_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_iface_method_A{}; t.Ctor(); return t }
//line :598:1
func (t *A_arbace_go_check_types_iface_method_A) Ctor() {}
//line :598:1
func (t *A_arbace_go_check_types_iface_method_A) Invoke_O_O_O_O__O(self, u__0, name__1, pkg__2 any) any { { var ms__4 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(1)); var i__5 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i__5, int64(lang.RT_Count_O__I_NoInit(ms__4))) { var m__6 any = lang.RT_Nth_O_I__O_NoInit(ms__4, lang.RT_IntCast_J__I_NoInit(i__5)); var tmp1 any; var root_1682 any = A_arbace_go_check_types_A_const_200.GetRawRoot__O(); var linked_1683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1682, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_1684 lang.IFn

		if linked_1683 == nil { ifn_1684 = lang.IFn_Cast(root_1682) } else { ifn_1684 = nil }; var arg_1685 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__6); var arg_1686 any = A_arbace_go_check_types_A_const_170.Invoke_O__O(m__6); var arg_1687 any = name__1; var arg_1688 any = pkg__2; if linked_1683 == nil { tmp1 = ifn_1684.Invoke_O_O_O_O__O(arg_1685, arg_1686, arg_1687, arg_1688) } else { tmp1 = linked_1683.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_1682, arg_1685, arg_1686, arg_1687, arg_1688) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__5).Ref(), m__6) } else {

			i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } } else {
//line :603:1
				return nil } } }; /*line :598:1*/panic("j2g: unreachable") }










func A_arbace_go_check_types_consolidate_A_New() *A_arbace_go_check_types_consolidate_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_consolidate_A{}; t.Ctor(); return t }
//line :609:1
func (t *A_arbace_go_check_types_consolidate_A) Ctor() {}
//line :609:1
func (t *A_arbace_go_check_types_consolidate_A) Invoke_O_O__O(self, entries__0 any) any { { var es__2 any = entries__0; var acc__3 any = lang.PersistentVector_EMPTY.Ref(); var idx__4 any = lang.PersistentArrayMap_EMPTY.Ref(); L1: for {



	var tmp1 any; var root_1689 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1689, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1691 lang.IFn; if linked_1690 == nil { ifn_1691 = lang.IFn_Cast(root_1689) } else { ifn_1691 = nil }; var arg_1692 any = es__2; if linked_1690 == nil { tmp1 = ifn_1691.Invoke_O__O(arg_1692) } else { tmp1 = linked_1690.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1689, arg_1692) }; if jrt.J2g_Truth(tmp1) { return acc__3 } else { var e__5 any; var root_1693 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1693, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1695 lang.IFn

		if linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var arg_1696 any = es__2; if linked_1694 == nil { e__5 = ifn_1695.Invoke_O__O(arg_1696) } else { e__5 = linked_1694.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1693, arg_1696) }
//line :613:1
		var k__6 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(e__5); var temp__1927000408__auto____7 any = lang.RT_Get_O_O__O_NoInit(idx__4, k__6)



		if jrt.J2g_Truth(temp__1927000408__auto____7) { var j__8 any = temp__1927000408__auto____7; var tmp2 any; var root_1697 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1697, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1699 lang.IFn
			if linked_1698 == nil { ifn_1699 = lang.IFn_Cast(root_1697) } else { ifn_1699 = nil }; var arg_1700 any = es__2; if linked_1698 == nil { tmp2 = ifn_1699.Invoke_O__O(arg_1700) } else { tmp2 = linked_1698.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1697, arg_1700) }; var tmp3 any = tmp2; var tmp4 any; var root_1701 any = A_arbace_go_check_types_A_const_201.GetRawRoot__O(); var linked_1702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1701, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1703 lang.IFn; if linked_1702 == nil { ifn_1703 = lang.IFn_Cast(root_1701) } else { ifn_1703 = nil }; var arg_1704 any = acc__3; var arg_1705 any = lang.Tuple_Create_O_O__IPersistentVector(j__8, A_arbace_go_check_types_A_const_202); var arg_1706 any = jrt.Boolean_TRUE.Ref(); if linked_1702 == nil { tmp4 = ifn_1703.Invoke_O_O_O__O(arg_1704, arg_1705, arg_1706) } else { tmp4 = linked_1702.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1701, arg_1704, arg_1705, arg_1706) }; es__2, acc__3, idx__4 = tmp3, tmp4, idx__4; continue L1 } else {
				var tmp5 any; var root_1707 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1707, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1709 lang.IFn; if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var arg_1710 any = es__2; if linked_1708 == nil { tmp5 = ifn_1709.Invoke_O__O(arg_1710) } else { tmp5 = linked_1708.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1707, arg_1710) }; var tmp6 any = tmp5; var tmp7 any; var root_1711 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1712 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1711, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1713 lang.IFn; if linked_1712 == nil { ifn_1713 = lang.IFn_Cast(root_1711) } else { ifn_1713 = nil }; var arg_1714 any = acc__3; var arg_1715 any = e__5; if linked_1712 == nil { tmp7 = ifn_1713.Invoke_O_O__O(arg_1714, arg_1715) } else { tmp7 = linked_1712.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1711, arg_1714, arg_1715) }; var tmp8 any = tmp7; var tmp9 any; var root_1716 any = A_arbace_go_check_types_A_const_59.GetRawRoot__O(); var linked_1717 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1716, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1718 lang.IFn; if linked_1717 == nil { ifn_1718 = lang.IFn_Cast(root_1716) } else { ifn_1718 = nil }; var arg_1719 any = idx__4; var arg_1720 any = k__6; var arg_1721 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(acc__3)).Ref(); if linked_1717 == nil { tmp9 = ifn_1718.Invoke_O_O_O__O(arg_1719, arg_1720, arg_1721) } else { tmp9 = linked_1717.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1716, arg_1719, arg_1720, arg_1721) }; es__2, acc__3, idx__4 = tmp6, tmp8, tmp9; continue L1 } } } }; /*line :609:1*/panic("j2g: unreachable") }











func A_arbace_go_check_types_lookup_impl_A_New() *A_arbace_go_check_types_lookup_impl_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_impl_A{}; t.Ctor(); return t }
//line :621:1
func (t *A_arbace_go_check_types_lookup_impl_A) Ctor() {}
//line :621:1
func (t *A_arbace_go_check_types_lookup_impl_A) Invoke_O_O_O_O_O__O(self, T__0_, addressable__1, name__2, pkg__3 any) any { { var vec__219000243__5 any; var root_1722 any = A_arbace_go_check_types_A_const_203.GetRawRoot__O(); var linked_1723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1722, A_arbace_go_check_types_deref_type_A_fn_class); var ifn_1724 lang.IFn





	if linked_1723 == nil { ifn_1724 = lang.IFn_Cast(root_1722) } else { ifn_1724 = nil }; var arg_1725 any = T__0_; if linked_1723 == nil { vec__219000243__5 = ifn_1724.Invoke_O__O(arg_1725) } else { vec__219000243__5 = linked_1723.(*A_arbace_go_check_types_deref_type_A).Invoke_O_O__O(root_1722, arg_1725) }
//line :621:1
	var typ__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000243__5, lang.RT_IntCast_J__I_NoInit(0), nil); var is_ptr__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000243__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any
	var and__1927000168__auto____8 any = is_ptr__7





	if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1726 any = A_arbace_go_check_types_A_const_204.GetRawRoot__O(); var linked_1727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1726, A_arbace_go_check_types_interface_QMARK__A_fn_class); var ifn_1728 lang.IFn; if linked_1727 == nil { ifn_1728 = lang.IFn_Cast(root_1726) } else { ifn_1728 = nil }; var arg_1729 any = typ__6; if linked_1727 == nil { tmp1 = ifn_1728.Invoke_O__O(arg_1729) } else { tmp1 = linked_1727.(*A_arbace_go_check_types_interface_QMARK__A).Invoke_O_O__O(root_1726, arg_1729) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return nil } else { var current__8 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_107, typ__6, A_arbace_go_check_types_A_const_212, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_types_A_const_213, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_types_A_const_214, is_ptr__7, A_arbace_go_check_types_A_const_202, jrt.Boolean_FALSE.Ref()))); var seen__9 any = lang.PersistentHashSet_EMPTY.Ref(); L1: for {



		var tmp2 any; var root_1730 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1730, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1732 lang.IFn; if linked_1731 == nil { ifn_1732 = lang.IFn_Cast(root_1730) } else { ifn_1732 = nil }; var arg_1733 any = current__8; if linked_1731 == nil { tmp2 = ifn_1732.Invoke_O__O(arg_1733) } else { tmp2 = linked_1731.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1730, arg_1733) }; if jrt.J2g_Truth(tmp2) { return nil } else { var vec__219000246__10 any; var root_1734 any = A_arbace_go_check_types_A_const_187.GetRawRoot__O(); var linked_1735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1734, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1736 lang.IFn


			if linked_1735 == nil { ifn_1736 = lang.IFn_Cast(root_1734) } else { ifn_1736 = nil }; var arg_1737 any; var tmp3 any = A_arbace_go_check_types_lookup_impl_fn__219000250_A_New_O_O(pkg__3, name__2); var tmp4 *jrt.Class; var fncls__1843 *jrt.Class = A_arbace_go_check_types_lookup_impl_fn__219000250_A_fn_class
			if fncls__1843 == nil { var fncls__1843d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_go_check_types_lookup_impl_fn__219000250_A_fn_class = fncls__1843d; tmp4 = fncls__1843d } else { tmp4 = fncls__1843 }; arg_1737 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)
//line :635:1
			var arg_1738 any = lang.Tuple_Create_O_O_O__IPersistentVector(nil, lang.PersistentVector_EMPTY.Ref(), seen__9); var arg_1739 any = current__8; if linked_1735 == nil { vec__219000246__10 = ifn_1736.Invoke_O_O_O__O(arg_1737, arg_1738, arg_1739) } else { vec__219000246__10 = linked_1735.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1734, arg_1737, arg_1738, arg_1739) }
//line :632:1
			var found__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000246__10, lang.RT_IntCast_J__I_NoInit(0), nil); var next__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000246__10, lang.RT_IntCast_J__I_NoInit(1), nil); var seen__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000246__10, lang.RT_IntCast_J__I_NoInit(2), nil)















































			if jrt.J2g_Truth(A_arbace_go_check_types_A_const_219.Invoke_O__O(found__11)) { return found__11 } else { if jrt.J2g_Truth(found__11) {


				var tmp5 any; var tmp6 any = A_arbace_go_check_types_A_const_209; var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_go_check_types_A_const_208.Invoke_O__O(found__11)); if and__1927000168__auto____14 { var tmp7 *lang.Keyword = A_arbace_go_check_types_A_const_220; var and__1927000168__auto____15 any = tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_go_check_types_A_const_221.Get__O()).Invoke_O__O(A_arbace_go_check_types_A_const_71.Invoke_O__O(found__11))); if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any; var root_1844 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1844, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1846 lang.IFn
					if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any = A_arbace_go_check_types_A_const_214.Invoke_O__O(found__11); if linked_1845 == nil { and__1927000168__auto____16 = ifn_1846.Invoke_O__O(arg_1847) } else { and__1927000168__auto____16 = linked_1845.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1844, arg_1847) }
//line :683:1
					if jrt.J2g_Truth(and__1927000168__auto____16) {
						var root_1848 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1848, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1850 lang.IFn; if linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = addressable__1; if linked_1849 == nil { tmp5 = ifn_1850.Invoke_O__O(arg_1851) } else { tmp5 = linked_1849.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1848, arg_1851) } } else {
//line :683:1
							tmp5 = and__1927000168__auto____16 } } else { tmp5 = and__1927000168__auto____15 } } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }; if jrt.J2g_Truth(tmp5) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_220, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_types_A_const_222, found__11)) } else { return found__11 } } else {
//line :680:1
								if A_arbace_go_check_types_A_const_75 != nil {






									var tmp8 any; var root_1852 any = A_arbace_go_check_types_A_const_223.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, A_arbace_go_check_types_consolidate_A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = next__12; if linked_1853 == nil { tmp8 = ifn_1854.Invoke_O__O(arg_1855) } else { tmp8 = linked_1853.(*A_arbace_go_check_types_consolidate_A).Invoke_O_O__O(root_1852, arg_1855) }; current__8, seen__9 = tmp8, seen__13; continue L1 } else {
//line :680:1
										return nil } } } } } } }; /*line :621:1*/panic("j2g: unreachable") }














func A_arbace_go_check_types_lookup_impl_fn__219000250_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_lookup_impl_fn__219000250_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_impl_fn__219000250_A{}; t.Ctor_O_O(p0, p1); return t }
//line :636:1
func (t *A_arbace_go_check_types_lookup_impl_fn__219000250_A) Ctor_O_O(c__pkg, c__name any) { t.F_pkg = c__pkg; t.F_name = c__name }
//line :636:1
func (t *A_arbace_go_check_types_lookup_impl_fn__219000250_A) Invoke_O_O_O__O(self, p__219000249__1, e__2 any) any { { var vec__219000251__3 any = p__219000249__1; var found__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000251__3, lang.RT_IntCast_J__I_NoInit(0), nil); var next__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000251__3, lang.RT_IntCast_J__I_NoInit(1), nil); var seen__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000251__3, lang.RT_IntCast_J__I_NoInit(2), nil); var typ__7 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(e__2); var tmp1 any; var and__1927000168__auto____8 any; var root_1740 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1740, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1742 lang.IFn

	if linked_1741 == nil { ifn_1742 = lang.IFn_Cast(root_1740) } else { ifn_1742 = nil }; var arg_1743 any = typ__7; if linked_1741 == nil { and__1927000168__auto____8 = ifn_1742.Invoke_O__O(arg_1743) } else { and__1927000168__auto____8 = linked_1741.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1740, arg_1743) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1744 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = seen__6; var arg_1748 any = typ__7; if linked_1745 == nil { tmp1 = ifn_1746.Invoke_O_O__O(arg_1747, arg_1748) } else { tmp1 = linked_1745.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1744, arg_1747, arg_1748) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__6) } else { var seen__8 any; var tmp2 any; var root_1749 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1749, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1751 lang.IFn

		if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any = typ__7; if linked_1750 == nil { tmp2 = ifn_1751.Invoke_O__O(arg_1752) } else { tmp2 = linked_1750.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1749, arg_1752) }; if jrt.J2g_Truth(tmp2) { var root_1753 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1754 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1753, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1755 lang.IFn; if linked_1754 == nil { ifn_1755 = lang.IFn_Cast(root_1753) } else { ifn_1755 = nil }; var arg_1756 any = seen__6; var arg_1757 any = typ__7; if linked_1754 == nil { seen__8 = ifn_1755.Invoke_O_O__O(arg_1756, arg_1757) } else { seen__8 = linked_1754.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1753, arg_1756, arg_1757) } } else { seen__8 = seen__6 }
//line :638:1
		var m__9 any; var tmp3 any; var root_1758 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1760 lang.IFn


		if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = typ__7; if linked_1759 == nil { tmp3 = ifn_1760.Invoke_O__O(arg_1761) } else { tmp3 = linked_1759.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1758, arg_1761) }; if jrt.J2g_Truth(tmp3) { var root_1762 any = A_arbace_go_check_types_A_const_205.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, A_arbace_go_check_types_named_method_A_fn_class); var ifn_1764 lang.IFn; if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var arg_1765 any = typ__7; var arg_1766 any = t.F_name; var arg_1767 any = t.F_pkg; if linked_1763 == nil { m__9 = ifn_1764.Invoke_O_O_O__O(arg_1765, arg_1766, arg_1767) } else { m__9 = linked_1763.(*A_arbace_go_check_types_named_method_A).Invoke_O_O_O_O__O(root_1762, arg_1765, arg_1766, arg_1767) } } else { m__9 = nil }
		if jrt.J2g_Truth(m__9) {
			var tmp4 any; var or__1927000174__auto____10 any = found__4; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp4 = or__1927000174__auto____10 } else { tmp4 = A_arbace_go_check_types_A_const_202.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp4) { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_207, next__5, seen__8) } else { var tmp5 any = A_arbace_go_check_types_A_const_208; var tmp6 any = A_arbace_go_check_types_A_const_209; var tmp7 any = A_arbace_go_check_types_A_const_71; var tmp8 any; var root_1797 any = A_arbace_go_check_types_A_const_210.GetRawRoot__O(); var linked_1798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1797, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1799 lang.IFn

				if linked_1798 == nil { ifn_1799 = lang.IFn_Cast(root_1797) } else { ifn_1799 = nil }; var arg_1800 any = m__9; if linked_1798 == nil { tmp8 = ifn_1799.Invoke_O__O(arg_1800) } else { tmp8 = linked_1798.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1797, arg_1800) }
//line :643:1
				var tmp9 any = tmp8; var tmp10 any = A_arbace_go_check_types_A_const_211; var tmp11 any = A_arbace_go_check_types_A_const_212; var tmp12 any; var root_1801 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1803 lang.IFn

				if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any = A_arbace_go_check_types_A_const_212.Invoke_O__O(e__2); var arg_1805 any; var root_1806 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_1807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1806, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1808 lang.IFn; if linked_1807 == nil { ifn_1808 = lang.IFn_Cast(root_1806) } else { ifn_1808 = nil }; var arg_1809 any = m__9; if linked_1807 == nil { arg_1805 = ifn_1808.Invoke_O__O(arg_1809) } else { arg_1805 = linked_1807.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1806, arg_1809) }; if linked_1802 == nil { tmp12 = ifn_1803.Invoke_O_O__O(arg_1804, arg_1805) } else { tmp12 = linked_1802.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1801, arg_1804, arg_1805) }
//line :643:1
				var tmp13 any = tmp12; var tmp14 any = A_arbace_go_check_types_A_const_213; var tmp15 any = A_arbace_go_check_types_A_const_213.Invoke_O__O(e__2); var tmp16 any = A_arbace_go_check_types_A_const_214; return lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, tmp9, tmp10, typ__7, tmp11, tmp13, tmp14, tmp15, tmp16, A_arbace_go_check_types_A_const_214.Invoke_O__O(e__2))), next__5, seen__8) } } else {
//line :642:1
					var u__10 any; var root_1768 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1768, A_arbace_go_check_types_under_A_fn_class); var ifn_1770 lang.IFn




					if linked_1769 == nil { ifn_1770 = lang.IFn_Cast(root_1768) } else { ifn_1770 = nil }; var arg_1771 any = typ__7; if linked_1769 == nil { u__10 = ifn_1770.Invoke_O__O(arg_1771) } else { u__10 = linked_1769.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1768, arg_1771) }
					var tmp17 any; var and__1927000168__auto____11 any; var root_1772 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1772, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1774 lang.IFn
					if linked_1773 == nil { ifn_1774 = lang.IFn_Cast(root_1772) } else { ifn_1774 = nil }; var arg_1775 any = u__10; if linked_1773 == nil { and__1927000168__auto____11 = ifn_1774.Invoke_O__O(arg_1775) } else { and__1927000168__auto____11 = linked_1773.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1772, arg_1775) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var tmp18 any = A_arbace_go_check_types_A_const_105; tmp17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp18, lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp17 = and__1927000168__auto____11 }
//line :648:1
					if jrt.J2g_Truth(tmp17) { var fs__11 any = lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(1)); var i__12 int64 = 0; var found__13 any = found__4; var next__14 any = next__5; L1: for {



						if lang.Numbers_Gte_J_J__Z_NoInit(i__12, int64(lang.RT_Count_O__I_NoInit(fs__11))) { return lang.Tuple_Create_O_O_O__IPersistentVector(found__13, next__14, seen__8) } else { var f__15 any = lang.RT_Nth_O_I__O_NoInit(fs__11, lang.RT_IntCast_J__I_NoInit(i__12)); var tmp19 any; var root_1776 any = A_arbace_go_check_types_A_const_200.GetRawRoot__O(); var linked_1777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1776, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_1778 lang.IFn



							if linked_1777 == nil { ifn_1778 = lang.IFn_Cast(root_1776) } else { ifn_1778 = nil }; var arg_1779 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(f__15); var arg_1780 any = A_arbace_go_check_types_A_const_170.Invoke_O__O(f__15); var arg_1781 any = t.F_name; var arg_1782 any = t.F_pkg; if linked_1777 == nil { tmp19 = ifn_1778.Invoke_O_O_O_O__O(arg_1779, arg_1780, arg_1781, arg_1782) } else { tmp19 = linked_1777.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_1776, arg_1779, arg_1780, arg_1781, arg_1782) }
//line :655:1
							if jrt.J2g_Truth(tmp19) {

								var tmp20 any; var or__1927000174__auto____16 any = found__13; if jrt.J2g_Truth(or__1927000174__auto____16) { tmp20 = or__1927000174__auto____16 } else { tmp20 = A_arbace_go_check_types_A_const_202.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp20) {
									i__12, found__13, next__14 = lang.Numbers_Inc_J__J_NoInit(i__12), A_arbace_go_check_types_A_const_215, next__14; continue L1 } else {
										var tmp21 int64 = lang.Numbers_Inc_J__J_NoInit(i__12); var tmp22 any = A_arbace_go_check_types_A_const_208; var tmp23 any = A_arbace_go_check_types_A_const_216; var tmp24 any = A_arbace_go_check_types_A_const_71; var tmp25 any = A_arbace_go_check_types_A_const_212; var tmp26 any; var root_1810 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1811 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1810, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1812 lang.IFn; if linked_1811 == nil { ifn_1812 = lang.IFn_Cast(root_1810) } else { ifn_1812 = nil }; var arg_1813 any = A_arbace_go_check_types_A_const_212.Invoke_O__O(e__2); var arg_1814 any = jrt.Long_ValueOf_J__Long_NoInit(i__12).Ref(); if linked_1811 == nil { tmp26 = ifn_1812.Invoke_O_O__O(arg_1813, arg_1814) } else { tmp26 = linked_1811.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1810, arg_1813, arg_1814) }; var tmp27 any = tmp26; var tmp28 any = A_arbace_go_check_types_A_const_213; var tmp29 any = A_arbace_go_check_types_A_const_213.Invoke_O__O(e__2); var tmp30 any = A_arbace_go_check_types_A_const_214; i__12, found__13, next__14 = tmp21, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp23, tmp24, f__15, tmp25, tmp27, tmp28, tmp29, tmp30, A_arbace_go_check_types_A_const_214.Invoke_O__O(e__2))), next__14; continue L1 } } else {
//line :655:1
											var tmp31 any; var and__1927000168__auto____16 bool = lang.Util_Identical_O_O__Z_NoInit(found__13, nil)






											if and__1927000168__auto____16 { tmp31 = A_arbace_go_check_types_A_const_168.Invoke_O__O(f__15) } else { tmp31 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____16).Ref() }
//line :655:1
											if jrt.J2g_Truth(tmp31) { var vec__219000254__16 any; var root_1783 any = A_arbace_go_check_types_A_const_203.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, A_arbace_go_check_types_deref_type_A_fn_class); var ifn_1785 lang.IFn







												if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(f__15); if linked_1784 == nil { vec__219000254__16 = ifn_1785.Invoke_O__O(arg_1786) } else { vec__219000254__16 = linked_1784.(*A_arbace_go_check_types_deref_type_A).Invoke_O_O__O(root_1783, arg_1786) }
//line :655:1
												var ft__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000254__16, lang.RT_IntCast_J__I_NoInit(0), nil); var fp__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000254__16, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp32 int64 = lang.Numbers_Inc_J__J_NoInit(i__12); var tmp33 any; var root_1815 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1816 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1815, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1817 lang.IFn









												if linked_1816 == nil { ifn_1817 = lang.IFn_Cast(root_1815) } else { ifn_1817 = nil }; var arg_1818 any = next__14; var arg_1819 any; var tmp34 any = A_arbace_go_check_types_A_const_107; var tmp35 any = A_arbace_go_check_types_A_const_212; var tmp36 any; var root_1820 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1821 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1820, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1822 lang.IFn; if linked_1821 == nil { ifn_1822 = lang.IFn_Cast(root_1820) } else { ifn_1822 = nil }; var arg_1823 any = A_arbace_go_check_types_A_const_212.Invoke_O__O(e__2); var arg_1824 any = jrt.Long_ValueOf_J__Long_NoInit(i__12).Ref(); if linked_1821 == nil { tmp36 = ifn_1822.Invoke_O_O__O(arg_1823, arg_1824) } else { tmp36 = linked_1821.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1820, arg_1823, arg_1824) }; var tmp37 any = tmp36; var tmp38 any = A_arbace_go_check_types_A_const_213; var tmp39 any; var root_1825 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1826 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1825, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1827 lang.IFn
												if linked_1826 == nil { ifn_1827 = lang.IFn_Cast(root_1825) } else { ifn_1827 = nil }; var arg_1828 any = A_arbace_go_check_types_A_const_213.Invoke_O__O(e__2); var arg_1829 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(f__15); if linked_1826 == nil { tmp39 = ifn_1827.Invoke_O_O__O(arg_1828, arg_1829) } else { tmp39 = linked_1826.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1825, arg_1828, arg_1829) }
//line :665:1
												var tmp40 any = tmp39; var tmp41 any = A_arbace_go_check_types_A_const_214; var tmp42 any; var or__1927000174__auto____19 any = A_arbace_go_check_types_A_const_214.Invoke_O__O(e__2)

												if jrt.J2g_Truth(or__1927000174__auto____19) { tmp42 = or__1927000174__auto____19 } else { tmp42 = fp__18 }
//line :665:1
												var tmp43 any = tmp42; var tmp44 any = A_arbace_go_check_types_A_const_202; arg_1819 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp34, ft__17, tmp35, tmp37, tmp38, tmp40, tmp41, tmp43, tmp44, A_arbace_go_check_types_A_const_202.Invoke_O__O(e__2))); if linked_1816 == nil { tmp33 = ifn_1817.Invoke_O_O__O(arg_1818, arg_1819) } else { tmp33 = linked_1816.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1815, arg_1818, arg_1819) }
//line :664:1
												i__12, found__13, next__14 = tmp32, found__13, tmp33; continue L1 } else {
//line :655:1
													if A_arbace_go_check_types_A_const_75 != nil {













														i__12, found__13, next__14 = lang.Numbers_Inc_J__J_NoInit(i__12), found__13, next__14; continue L1 } else {
//line :655:1
															return nil } } } } } } else {
//line :648:1
																var tmp45 any; var and__1927000168__auto____11_2 any; var root_1787 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1789 lang.IFn





















																if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = u__10; if linked_1788 == nil { and__1927000168__auto____11_2 = ifn_1789.Invoke_O__O(arg_1790) } else { and__1927000168__auto____11_2 = linked_1788.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1787, arg_1790) }; if jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp46 any = A_arbace_go_check_types_A_const_86; tmp45 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp46, lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp45 = and__1927000168__auto____11_2 }
//line :648:1
																if jrt.J2g_Truth(tmp45) { var temp__1927000408__auto____11 any; var root_1791 any = A_arbace_go_check_types_A_const_206.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, A_arbace_go_check_types_iface_method_A_fn_class); var ifn_1793 lang.IFn






















																	if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any = u__10; var arg_1795 any = t.F_name; var arg_1796 any = t.F_pkg; if linked_1792 == nil { temp__1927000408__auto____11 = ifn_1793.Invoke_O_O_O__O(arg_1794, arg_1795, arg_1796) } else { temp__1927000408__auto____11 = linked_1792.(*A_arbace_go_check_types_iface_method_A).Invoke_O_O_O_O__O(root_1791, arg_1794, arg_1795, arg_1796) }; if jrt.J2g_Truth(temp__1927000408__auto____11) { var m__12 any = temp__1927000408__auto____11; var tmp47 any; var or__1927000174__auto____13 any = found__4
																		if jrt.J2g_Truth(or__1927000174__auto____13) { tmp47 = or__1927000174__auto____13 } else { tmp47 = A_arbace_go_check_types_A_const_202.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp47) { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_217, next__5, seen__8) } else { var tmp48 any = A_arbace_go_check_types_A_const_208; var tmp49 any = A_arbace_go_check_types_A_const_218; var tmp50 any = A_arbace_go_check_types_A_const_71; var tmp51 any; var root_1830 any = A_arbace_go_check_types_A_const_210.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1830, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1832 lang.IFn

																			if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any = m__12; if linked_1831 == nil { tmp51 = ifn_1832.Invoke_O__O(arg_1833) } else { tmp51 = linked_1831.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1830, arg_1833) }
//line :672:1
																			var tmp52 any = tmp51; var tmp53 any = A_arbace_go_check_types_A_const_144; var tmp54 any = A_arbace_go_check_types_A_const_212; var tmp55 any; var root_1834 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1835 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1834, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1836 lang.IFn

																			if linked_1835 == nil { ifn_1836 = lang.IFn_Cast(root_1834) } else { ifn_1836 = nil }; var arg_1837 any = A_arbace_go_check_types_A_const_212.Invoke_O__O(e__2); var arg_1838 any; var root_1839 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_1840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1839, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1841 lang.IFn; if linked_1840 == nil { ifn_1841 = lang.IFn_Cast(root_1839) } else { ifn_1841 = nil }; var arg_1842 any = m__12; if linked_1840 == nil { arg_1838 = ifn_1841.Invoke_O__O(arg_1842) } else { arg_1838 = linked_1840.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1839, arg_1842) }; if linked_1835 == nil { tmp55 = ifn_1836.Invoke_O_O__O(arg_1837, arg_1838) } else { tmp55 = linked_1835.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1834, arg_1837, arg_1838) }
//line :672:1
																			var tmp56 any = tmp55; var tmp57 any = A_arbace_go_check_types_A_const_213; var tmp58 any = A_arbace_go_check_types_A_const_213.Invoke_O__O(e__2); var tmp59 any = A_arbace_go_check_types_A_const_214; return lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp48, tmp49, tmp50, tmp52, tmp53, typ__7, tmp54, tmp56, tmp57, tmp58, tmp59, A_arbace_go_check_types_A_const_214.Invoke_O__O(e__2))), next__5, seen__8) } } else {
//line :671:1
																				return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__8) } } else {
//line :648:1
																					if A_arbace_go_check_types_A_const_75 != nil { return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__8) } else { return nil } } } } } }; /*line :636:1*/panic("j2g: unreachable") }




















































func A_arbace_go_check_types_lookup_A_New() *A_arbace_go_check_types_lookup_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_A{}; t.Ctor(); return t }
//line :689:1
func (t *A_arbace_go_check_types_lookup_A) Ctor() {}
//line :689:1
func (t *A_arbace_go_check_types_lookup_A) Invoke_O_O_O_O_O__O(self, T__0_, addressable__1, name__2, pkg__3 any) any {


	var tmp1 any; var and__1927000168__auto____5 any; var root_1856 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1856, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1858 lang.IFn; if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any = T__0_; if linked_1857 == nil { and__1927000168__auto____5 = ifn_1858.Invoke_O__O(arg_1859) } else { and__1927000168__auto____5 = linked_1857.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1856, arg_1859) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1860 any = A_arbace_go_check_types_A_const_224.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, A_arbace_go_check_types_pointer_QMARK__A_fn_class); var ifn_1862 lang.IFn; if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any = T__0_; if linked_1861 == nil { tmp1 = ifn_1862.Invoke_O__O(arg_1863) } else { tmp1 = linked_1861.(*A_arbace_go_check_types_pointer_QMARK__A).Invoke_O_O__O(root_1860, arg_1863) } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var r__5 any; var root_1864 any = A_arbace_go_check_types_A_const_225.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1864, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_1866 lang.IFn
		if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any; var root_1871 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1871, A_arbace_go_check_types_under_A_fn_class); var ifn_1873 lang.IFn; if linked_1872 == nil { ifn_1873 = lang.IFn_Cast(root_1871) } else { ifn_1873 = nil }; var arg_1874 any = T__0_; if linked_1872 == nil { arg_1867 = ifn_1873.Invoke_O__O(arg_1874) } else { arg_1867 = linked_1872.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1871, arg_1874) }; var arg_1868 any = jrt.Boolean_FALSE.Ref(); var arg_1869 any = name__2; var arg_1870 any = pkg__3; if linked_1865 == nil { r__5 = ifn_1866.Invoke_O_O_O_O__O(arg_1867, arg_1868, arg_1869, arg_1870) } else { r__5 = linked_1865.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_1864, arg_1867, arg_1868, arg_1869, arg_1870) }
		var tmp2 any = A_arbace_go_check_types_A_const_209; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_go_check_types_A_const_208.Invoke_O__O(r__5)) { return nil } else { return r__5 } } else {
			var root_1875 any = A_arbace_go_check_types_A_const_225.GetRawRoot__O(); var linked_1876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1875, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_1877 lang.IFn; if linked_1876 == nil { ifn_1877 = lang.IFn_Cast(root_1875) } else { ifn_1877 = nil }; var arg_1878 any = T__0_; var arg_1879 any = addressable__1; var arg_1880 any = name__2; var arg_1881 any = pkg__3; if linked_1876 == nil { return ifn_1877.Invoke_O_O_O_O__O(arg_1878, arg_1879, arg_1880, arg_1881) } else { return linked_1876.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_1875, arg_1878, arg_1879, arg_1880, arg_1881)
			}
		}
}
func A_arbace_go_check_types_sort_methods_A_New() *A_arbace_go_check_types_sort_methods_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sort_methods_A{}; t.Ctor(); return t }
//line :699:1
func (t *A_arbace_go_check_types_sort_methods_A) Ctor() {}
//line :699:1
func (t *A_arbace_go_check_types_sort_methods_A) Invoke_O_O__O(self, ms__0 any) any {


	var root_1882 any = A_arbace_go_check_types_A_const_121.GetRawRoot__O(); var linked_1883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1882, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1884 lang.IFn; if linked_1883 == nil { ifn_1884 = lang.IFn_Cast(root_1882) } else { ifn_1884 = nil }; var arg_1885 any; var root_1886 any = A_arbace_go_check_types_A_const_163.GetRawRoot__O(); var linked_1887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1886, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1888 lang.IFn; if linked_1887 == nil { ifn_1888 = lang.IFn_Cast(root_1886) } else { ifn_1888 = nil }; var arg_1889 any; var tmp1 any = A_arbace_go_check_types_sort_methods_fn__219000260_A_New(); var tmp2 *jrt.Class; var fncls__1891 *jrt.Class = A_arbace_go_check_types_sort_methods_fn__219000260_A_fn_class; if fncls__1891 == nil { var fncls__1891d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_check_types_sort_methods_fn__219000260_A_fn_class = fncls__1891d; tmp2 = fncls__1891d } else { tmp2 = fncls__1891 }; arg_1889 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1890 any = ms__0; if linked_1887 == nil { arg_1885 = ifn_1888.Invoke_O_O__O(arg_1889, arg_1890) } else { arg_1885 = linked_1887.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1886, arg_1889, arg_1890) }; if linked_1883 == nil { return ifn_1884.Invoke_O__O(arg_1885) } else { return linked_1883.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1882, arg_1885) } }
//line :702:1
func A_arbace_go_check_types_sort_methods_fn__219000260_A_New() *A_arbace_go_check_types_sort_methods_fn__219000260_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sort_methods_fn__219000260_A{}; t.Ctor(); return t }
//line :702:1
func (t *A_arbace_go_check_types_sort_methods_fn__219000260_A) Ctor() {}
//line :702:1
func (t *A_arbace_go_check_types_sort_methods_fn__219000260_A) Invoke_O_O__O(self, m__1 any) any { var tmp1 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var tmp2 any; var or__1927000174__auto____2 any = A_arbace_go_check_types_A_const_170.Invoke_O__O(m__1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = Lit_8 }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }

func A_arbace_go_check_types_method_data_A_New() *A_arbace_go_check_types_method_data_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_method_data_A{}; t.Ctor(); return t }
//line :704:1
func (t *A_arbace_go_check_types_method_data_A) Ctor() {}
//line :704:1
func (t *A_arbace_go_check_types_method_data_A) Invoke_O_O__O(self, m__0 any) any {


	var tmp1 any; var root_1892 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1892, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1894 lang.IFn; if linked_1893 == nil { ifn_1894 = lang.IFn_Cast(root_1892) } else { ifn_1894 = nil }; var arg_1895 any = m__0; if linked_1893 == nil { tmp1 = ifn_1894.Invoke_O__O(arg_1895) } else { tmp1 = linked_1893.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1892, arg_1895) }; if jrt.J2g_Truth(tmp1) { return m__0 } else { return lang.IFn_Cast(A_arbace_go_check_types_A_const_221.Get__O()).Invoke_O__O(m__0)
	} }
func A_arbace_go_check_types_missing_method_A_New() *A_arbace_go_check_types_missing_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_A{}; t.Ctor(); return t }
//line :709:1
func (t *A_arbace_go_check_types_missing_method_A) Ctor() {}
//line :709:1
func (t *A_arbace_go_check_types_missing_method_A) Invoke_O_O_O_O_O__O(self, V__0_, T__1_, static__2, same_QMARK___3 any) any { var tu__5 any; var root_1896 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1896, A_arbace_go_check_types_under_A_fn_class); var ifn_1898 lang.IFn; if





	linked_1897 == nil { ifn_1898 = lang.IFn_Cast(root_1896) } else { ifn_1898 = nil }; var arg_1899 any = T__1_; if linked_1897 == nil { tu__5 = ifn_1898.Invoke_O__O(arg_1899) } else { tu__5 = linked_1897.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1896, arg_1899) }; var vu__6 any; var root_1900 any = /*line :709:1*/A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1900, A_arbace_go_check_types_under_A_fn_class); var ifn_1902 lang.IFn; if






	linked_1901 == nil { ifn_1902 = lang.IFn_Cast(root_1900) } else { ifn_1902 = nil }; var arg_1903 any = V__0_; if linked_1901 == nil { vu__6 = ifn_1902.Invoke_O__O(arg_1903) } else { vu__6 = linked_1901.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1900, arg_1903) }; var root_1904 any =
	A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_1905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1904, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1906 lang.IFn; if linked_1905 == nil { ifn_1906 = lang.IFn_Cast(root_1904) } else { ifn_1906 = nil }; var arg_1907 any; var tmp1 any = A_arbace_go_check_types_missing_method_fn__219000264_A_New_O_O_O_O(static__2, V__0_, same_QMARK___3, vu__6); var tmp2 *jrt.Class; var fncls__1950 *jrt.Class = A_arbace_go_check_types_missing_method_fn__219000264_A_fn_class; if
	fncls__1950 == nil { var fncls__1950d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_go_check_types_missing_method_fn__219000264_A_fn_class = fncls__1950d; tmp2 = fncls__1950d } else { tmp2 = fncls__1950 }; arg_1907 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1908 any = /*line :717:1*/lang.RT_Nth_O_I__O_NoInit(tu__5, lang.RT_IntCast_J__I_NoInit(1)); if linked_1905 == nil { return ifn_1906.Invoke_O_O__O(arg_1907, arg_1908) } else { return linked_1905.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1904, arg_1907, arg_1908) } }
//line :709:1
func (t *A_arbace_go_check_types_missing_method_A) Invoke_O_O_O_O__O(self, V__0_, T__1_, static__2 any) any {



	var root_1951 any = A_arbace_go_check_types_A_const_233.GetRawRoot__O(); var linked_1952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1951, A_arbace_go_check_types_missing_method_A_fn_class); var ifn_1953 lang.IFn; if linked_1952 == nil { ifn_1953 = lang.IFn_Cast(root_1951) } else { ifn_1953 = nil }; var arg_1954 any = V__0_; var arg_1955 any = T__1_; var arg_1956 any = static__2; var arg_1957 any = A_arbace_go_check_types_A_const_234.GetRawRoot__O(); if linked_1952 == nil { return ifn_1953.Invoke_O_O_O_O__O(arg_1954, arg_1955, arg_1956, arg_1957) } else { return linked_1952.(*A_arbace_go_check_types_missing_method_A).Invoke_O_O_O_O_O__O(root_1951, arg_1954, arg_1955, arg_1956, arg_1957)
	}
}


func A_arbace_go_check_types_missing_method_fn__219000264_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_types_missing_method_fn__219000264_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_fn__219000264_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :718:1
func (t *A_arbace_go_check_types_missing_method_fn__219000264_A) Ctor_O_O_O_O(c__static, c__V, c__same_QMARK_, c__vu any) { t.F_static = c__static; t.F_V = c__V; t.F_same_QMARK_ = c__same_QMARK_; t.F_vu = c__vu }
//line :718:1
func (t *A_arbace_go_check_types_missing_method_fn__219000264_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_1909 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1909, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1911 lang.IFn; if linked_1910 == nil { ifn_1911 = lang.IFn_Cast(root_1909) } else { ifn_1911 = nil }; var arg_1912 any = t.F_vu; if linked_1910 == nil { and__1927000168__auto____2 = ifn_1911.Invoke_O__O(arg_1912) } else { and__1927000168__auto____2 = linked_1910.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1909, arg_1912) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_types_A_const_86; var tmp3 any = t.F_vu; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var f__2 any; var root_1913 any = A_arbace_go_check_types_A_const_206.GetRawRoot__O(); var linked_1914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1913, A_arbace_go_check_types_iface_method_A_fn_class); var ifn_1915 lang.IFn
		if linked_1914 == nil { ifn_1915 = lang.IFn_Cast(root_1913) } else { ifn_1915 = nil }; var arg_1916 any = t.F_vu; var arg_1917 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var arg_1918 any = A_arbace_go_check_types_A_const_170.Invoke_O__O(m__1); if linked_1914 == nil { f__2 = ifn_1915.Invoke_O_O_O__O(arg_1916, arg_1917, arg_1918) } else { f__2 = linked_1914.(*A_arbace_go_check_types_iface_method_A).Invoke_O_O_O_O__O(root_1913, arg_1916, arg_1917, arg_1918) }
		if lang.Util_Identical_O_O__Z_NoInit(f__2, nil) {
			if jrt.J2g_Truth(t.F_static) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_209, m__1, A_arbace_go_check_types_A_const_226, A_arbace_go_check_types_A_const_227)) } else { return nil } } else {
//line :721:1
				var tmp4 any; var root_1919 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_1920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1919, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1921 lang.IFn

				if linked_1920 == nil { ifn_1921 = lang.IFn_Cast(root_1919) } else { ifn_1921 = nil }; var arg_1922 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_same_QMARK_); var tmp6 *lang.Keyword = A_arbace_go_check_types_A_const_107; var tmp7 any; var root_1923 any = A_arbace_go_check_types_A_const_210.GetRawRoot__O(); var linked_1924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1923, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1925 lang.IFn; if linked_1924 == nil { ifn_1925 = lang.IFn_Cast(root_1923) } else { ifn_1925 = nil }; var arg_1926 any = f__2; if linked_1924 == nil { tmp7 = ifn_1925.Invoke_O__O(arg_1926) } else { tmp7 = linked_1924.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1923, arg_1926) }; arg_1922 = tmp5.Invoke_O_O__O(tmp6.Invoke_O__O(tmp7), A_arbace_go_check_types_A_const_107.Invoke_O__O(m__1)); if linked_1920 == nil { tmp4 = ifn_1921.Invoke_O__O(arg_1922) } else { tmp4 = linked_1920.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1919, arg_1922) }
//line :721:1
				if jrt.J2g_Truth(tmp4) { var tmp8 any = A_arbace_go_check_types_A_const_209; var tmp9 any = A_arbace_go_check_types_A_const_226; var tmp10 any = A_arbace_go_check_types_A_const_228; var tmp11 any = A_arbace_go_check_types_A_const_229; var tmp12 any; var root_1927 any = A_arbace_go_check_types_A_const_210.GetRawRoot__O(); var linked_1928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1927, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1929 lang.IFn

					if linked_1928 == nil { ifn_1929 = lang.IFn_Cast(root_1927) } else { ifn_1929 = nil }; var arg_1930 any = f__2; if linked_1928 == nil { tmp12 = ifn_1929.Invoke_O__O(arg_1930) } else { tmp12 = linked_1928.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1927, arg_1930) }
//line :721:1
					return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, m__1, tmp9, tmp10, tmp11, tmp12)) } else { return nil } } } else {
//line :719:1
						var r__2 any; var root_1931 any = A_arbace_go_check_types_A_const_225.GetRawRoot__O(); var linked_1932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1931, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_1933 lang.IFn




						if linked_1932 == nil { ifn_1933 = lang.IFn_Cast(root_1931) } else { ifn_1933 = nil }; var arg_1934 any = t.F_V; var arg_1935 any = jrt.Boolean_FALSE.Ref(); var arg_1936 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var arg_1937 any = A_arbace_go_check_types_A_const_170.Invoke_O__O(m__1); if linked_1932 == nil { r__2 = ifn_1933.Invoke_O_O_O_O__O(arg_1934, arg_1935, arg_1936, arg_1937) } else { r__2 = linked_1932.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_1931, arg_1934, arg_1935, arg_1936, arg_1937) }
						if jrt.J2g_Truth(A_arbace_go_check_types_A_const_220.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_209, m__1, A_arbace_go_check_types_A_const_226, A_arbace_go_check_types_A_const_220)) } else { if lang.Util_Identical_O_O__Z_NoInit(r__2, nil) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_209, m__1, A_arbace_go_check_types_A_const_226, A_arbace_go_check_types_A_const_227)) } else { if jrt.J2g_Truth(A_arbace_go_check_types_A_const_219.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_209, m__1, A_arbace_go_check_types_A_const_226, A_arbace_go_check_types_A_const_227)) } else { var tmp13 any = A_arbace_go_check_types_A_const_216; if lang.Util_Equiv_O_O__Z_NoInit(tmp13, A_arbace_go_check_types_A_const_208.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_209, m__1, A_arbace_go_check_types_A_const_226, A_arbace_go_check_types_A_const_216)) } else { if A_arbace_go_check_types_A_const_75 != nil { var d__3 any; var root_1938 any = A_arbace_go_check_types_A_const_230.GetRawRoot__O(); var linked_1939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1938, A_arbace_go_check_types_method_data_A_fn_class); var ifn_1940 lang.IFn





							if linked_1939 == nil { ifn_1940 = lang.IFn_Cast(root_1938) } else { ifn_1940 = nil }; var arg_1941 any = A_arbace_go_check_types_A_const_71.Invoke_O__O(r__2); if linked_1939 == nil { d__3 = ifn_1940.Invoke_O__O(arg_1941) } else { d__3 = linked_1939.(*A_arbace_go_check_types_method_data_A).Invoke_O_O__O(root_1938, arg_1941) }
//line :725:1
							var d__4 any; var tmp14 any; var and__1927000168__auto____4 any = A_arbace_go_check_types_A_const_231.Get__O()






							if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp15 any = A_arbace_go_check_types_A_const_209; tmp14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp15, A_arbace_go_check_types_A_const_208.Invoke_O__O(r__2))).Ref() } else { tmp14 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp14) { d__4 = lang.IFn_Cast(A_arbace_go_check_types_A_const_231.Get__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_211.Invoke_O__O(r__2), d__3) } else { d__4 = d__3
							}
							var tmp16 any; var or__1927000174__auto____5 any; var root_1942 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_1943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1942, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1944 lang.IFn; if linked_1943 == nil { ifn_1944 = lang.IFn_Cast(root_1942) } else { ifn_1944 = nil }; var arg_1945 any = A_arbace_go_check_types_A_const_232.Invoke_O__O(d__4); if linked_1943 == nil { or__1927000174__auto____5 = ifn_1944.Invoke_O__O(arg_1945) } else { or__1927000174__auto____5 = linked_1943.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1942, arg_1945) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp16 = or__1927000174__auto____5 } else { var root_1946 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_1947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1946, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1948 lang.IFn; if linked_1947 == nil { ifn_1948 = lang.IFn_Cast(root_1946) } else { ifn_1948 = nil }; var tmp17 lang.IFn = lang.IFn_Cast(t.F_same_QMARK_); var arg_1949 any = tmp17.Invoke_O_O__O(A_arbace_go_check_types_A_const_107.Invoke_O__O(d__4), A_arbace_go_check_types_A_const_107.Invoke_O__O(m__1)); if linked_1947 == nil { tmp16 = ifn_1948.Invoke_O__O(arg_1949) } else { tmp16 = linked_1947.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1946, arg_1949) } }; if jrt.J2g_Truth(tmp16) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_209, m__1, A_arbace_go_check_types_A_const_226, A_arbace_go_check_types_A_const_228, A_arbace_go_check_types_A_const_229, d__4)) } else { return nil } } else {
//line :725:1
								return nil
							}
						}
						}
						}
						}
					}
}







func A_arbace_go_check_types_satisfies_cause_A_New() *A_arbace_go_check_types_satisfies_cause_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_A{}; t.Ctor(); return t }
//line :740:1
func (t *A_arbace_go_check_types_satisfies_cause_A) Ctor() {}
//line :740:1
func (t *A_arbace_go_check_types_satisfies_cause_A) Invoke_O_O_O__O(self, V__0_, b__1 any) any { var Ti__3_ any; var root_1958 any = A_arbace_go_check_types_A_const_145.GetRawRoot__O(); var linked_1959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1958, A_arbace_go_check_types_bound_iface_A_fn_class); var ifn_1960 lang.IFn; if



	linked_1959 == nil { ifn_1960 = lang.IFn_Cast(root_1958) } else { ifn_1960 = nil }; var arg_1961 any = b__1; if linked_1959 == nil { Ti__3_ = ifn_1960.Invoke_O__O(arg_1961) } else { Ti__3_ = linked_1959.(*A_arbace_go_check_types_bound_iface_A).Invoke_O_O__O(root_1958, arg_1961) }; var Vu__4_ any; var root_1962 any = /*line :740:1*/A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1962, A_arbace_go_check_types_under_A_fn_class); var ifn_1964 lang.IFn; if




	linked_1963 == nil { ifn_1964 = lang.IFn_Cast(root_1962) } else { ifn_1964 = nil }; var arg_1965 any = V__0_; if linked_1963 == nil { Vu__4_ = ifn_1964.Invoke_O__O(arg_1965) } else { Vu__4_ = linked_1963.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1962, arg_1965) }; var tmp1 any; var or__1927000174__auto____5 bool =
	lang.Util_Identical_O_O__Z_NoInit(Ti__3_, nil); if or__1927000174__auto____5 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_67, Vu__4_); if or__1927000174__auto____6 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var and__1927000168__auto____7 any; var root_1966 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1966, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1968 lang.IFn
		if linked_1967 == nil { ifn_1968 = lang.IFn_Cast(root_1966) } else { ifn_1968 = nil }; var arg_1969 any = Vu__4_; if linked_1967 == nil { and__1927000168__auto____7 = ifn_1968.Invoke_O__O(arg_1969) } else { and__1927000168__auto____7 = linked_1967.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1966, arg_1969) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp2 any = A_arbace_go_check_types_A_const_87; var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____8 { var tmp3 any = A_arbace_go_check_types_A_const_67; var tmp4 any; var root_1970 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1970, A_arbace_go_check_types_under_A_fn_class); var ifn_1972 lang.IFn; if linked_1971 == nil { ifn_1972 = lang.IFn_Cast(root_1970) } else { ifn_1972 = nil }; var arg_1973 any = lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(1)); if linked_1971 == nil { tmp4 = ifn_1972.Invoke_O__O(arg_1973) } else { tmp4 = linked_1971.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1970, arg_1973) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp1 = and__1927000168__auto____7 } } }; if /*line :746:1*/ jrt.J2g_Truth(tmp1) { return nil } else { var Tts__5_ any; var root_1974 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_1976 lang.IFn


			if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = Ti__3_; if linked_1975 == nil { Tts__5_ = ifn_1976.Invoke_O__O(arg_1977) } else { Tts__5_ = linked_1975.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_1974, arg_1977) }
//line :746:1
			var Vi__6_ any; var tmp5 any; var and__1927000168__auto____6 any; var root_1978 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1980 lang.IFn



			if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any = Vu__4_; if linked_1979 == nil { and__1927000168__auto____6 = ifn_1980.Invoke_O__O(arg_1981) } else { and__1927000168__auto____6 = linked_1979.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1978, arg_1981) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp6 any = A_arbace_go_check_types_A_const_86; tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp6, lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp5 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp5) { Vi__6_ = Vu__4_ } else { Vi__6_ = nil }
//line :746:1
			var Vts__7_ any




			if jrt.J2g_Truth(Vi__6_) { var root_1982 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_1983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1982, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_1984 lang.IFn; if linked_1983 == nil { ifn_1984 = lang.IFn_Cast(root_1982) } else { ifn_1984 = nil }; var arg_1985 any = Vi__6_; if linked_1983 == nil { Vts__7_ = ifn_1984.Invoke_O__O(arg_1985) } else { Vts__7_ = linked_1983.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_1982, arg_1985) } } else { Vts__7_ = nil }
//line :746:1
			var T_str__8_ any; var root_1986 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1986, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1988 lang.IFn





			if linked_1987 == nil { ifn_1988 = lang.IFn_Cast(root_1986) } else { ifn_1988 = nil }; var arg_1989 any = b__1; if linked_1987 == nil { T_str__8_ = ifn_1988.Invoke_O__O(arg_1989) } else { T_str__8_ = linked_1987.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1986, arg_1989) }
			var tmp7 any; var and__1927000168__auto____9 any; var root_1990 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1990, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1992 lang.IFn
			if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; var arg_1993 any = lang.RT_Nth_O_I__O_NoInit(Ti__3_, lang.RT_IntCast_J__I_NoInit(1)); if linked_1991 == nil { and__1927000168__auto____9 = ifn_1992.Invoke_O__O(arg_1993) } else { and__1927000168__auto____9 = linked_1991.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1990, arg_1993) }; if jrt.J2g_Truth(and__1927000168__auto____9) { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(Ti__3_, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref() } else { tmp7 = and__1927000168__auto____9 }
//line :753:1
			if jrt.J2g_Truth(tmp7) { return nil } else { var tmp8 any
				var and__1927000168__auto____9_2 any = Vts__7_
				if jrt.J2g_Truth(and__1927000168__auto____9_2) { var root_1994 any = A_arbace_go_check_types_A_const_235.GetRawRoot__O(); var linked_1995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1994, A_arbace_go_check_types_tset_empty_QMARK__A_fn_class); var ifn_1996 lang.IFn; if linked_1995 == nil { ifn_1996 = lang.IFn_Cast(root_1994) } else { ifn_1996 = nil }; var arg_1997 any = Vts__7_; if linked_1995 == nil { tmp8 = ifn_1996.Invoke_O__O(arg_1997) } else { tmp8 = linked_1995.(*A_arbace_go_check_types_tset_empty_QMARK__A).Invoke_O_O__O(root_1994, arg_1997) } } else { tmp8 = and__1927000168__auto____9_2 }
//line :753:1
				if jrt.J2g_Truth(tmp8) { return nil } else { var tmp9 any; var root_1998 any = A_arbace_go_check_types_A_const_235.GetRawRoot__O(); var linked_1999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1998, A_arbace_go_check_types_tset_empty_QMARK__A_fn_class); var ifn_2000 lang.IFn


					if linked_1999 == nil { ifn_2000 = lang.IFn_Cast(root_1998) } else { ifn_2000 = nil }; var arg_2001 any = Tts__5_; if linked_1999 == nil { tmp9 = ifn_2000.Invoke_O__O(arg_2001) } else { tmp9 = linked_1999.(*A_arbace_go_check_types_tset_empty_QMARK__A).Invoke_O_O__O(root_1998, arg_2001) }
//line :753:1
					if jrt.J2g_Truth(tmp9) {


						return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_27), jrt.RefArrayOf(jrt.Object_class, nil, T_str__8_, nil)).Ref() } else {
//line :753:1
							if A_arbace_go_check_types_A_const_75 != nil { var temp__1927000408__auto____9 any; var root_2002 any = A_arbace_go_check_types_A_const_233.GetRawRoot__O(); var linked_2003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2002, A_arbace_go_check_types_missing_method_A_fn_class); var ifn_2004 lang.IFn




								if linked_2003 == nil { ifn_2004 = lang.IFn_Cast(root_2002) } else { ifn_2004 = nil }; var arg_2005 any = V__0_; var arg_2006 any = Ti__3_; var arg_2007 any = jrt.Boolean_TRUE.Ref(); if linked_2003 == nil { temp__1927000408__auto____9 = ifn_2004.Invoke_O_O_O__O(arg_2005, arg_2006, arg_2007) } else { temp__1927000408__auto____9 = linked_2003.(*A_arbace_go_check_types_missing_method_A).Invoke_O_O_O_O__O(root_2002, arg_2005, arg_2006, arg_2007) }; if jrt.J2g_Truth(temp__1927000408__auto____9) { var mm__10 any = temp__1927000408__auto____9; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_28, nil, Lit_29, nil, Lit_22); var tmp11 any; var root_2008 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_2009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2008, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2010 lang.IFn
									if linked_2009 == nil { ifn_2010 = lang.IFn_Cast(root_2008) } else { ifn_2010 = nil }; var arg_2011 any = V__0_; if linked_2009 == nil { tmp11 = ifn_2010.Invoke_O__O(arg_2011) } else { tmp11 = linked_2009.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2008, arg_2011) }; var tmp12 *lang.Keyword = A_arbace_go_check_types_A_const_12; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp11, nil, T_str__8_, nil, tmp12.Invoke_O__O(A_arbace_go_check_types_A_const_209.Invoke_O__O(mm__10)), nil)).Ref() } else {
//line :758:1
										var comparability__10 any; var tmp13 any = A_arbace_go_check_types_satisfies_cause_comparability__219000267_A_New_O_O(Tts__5_, V__0_); var tmp14 *jrt.Class
										var fncls__2038 /*line :758:1*/*jrt.Class = A_arbace_go_check_types_satisfies_cause_comparability__219000267_A_fn_class


										if fncls__2038 == nil { var fncls__2038d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_go_check_types_satisfies_cause_comparability__219000267_A_fn_class = fncls__2038d; tmp14 = fncls__2038d } else { tmp14 = fncls__2038 }; comparability__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)








										var tmp15 any; var root_2039 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_2040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2039, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2041 lang.IFn
										if linked_2040 == nil { ifn_2041 = lang.IFn_Cast(root_2039) } else { ifn_2041 = nil }; var arg_2042 any; var root_2043 any = A_arbace_go_check_types_A_const_148.GetRawRoot__O(); var linked_2044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2043, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_2045 lang.IFn; if linked_2044 == nil { ifn_2045 = lang.IFn_Cast(root_2043) } else { ifn_2045 = nil }; var arg_2046 any = Tts__5_; if linked_2044 == nil { arg_2042 = ifn_2045.Invoke_O__O(arg_2046) } else { arg_2042 = linked_2044.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_2043, arg_2046) }; if linked_2040 == nil { tmp15 = ifn_2041.Invoke_O__O(arg_2042) } else { tmp15 = linked_2040.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2039, arg_2042) }
//line :770:1
										if jrt.J2g_Truth(tmp15) {
											return lang.IFn_Cast(comparability__10).Invoke__O() } else {
//line :770:1
												if jrt.J2g_Truth(Vts__7_) {

													var tmp16 any; var root_2047 any = A_arbace_go_check_types_A_const_237.GetRawRoot__O(); var linked_2048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2047, A_arbace_go_check_types_terms_subset_QMARK__A_fn_class); var ifn_2049 lang.IFn; if linked_2048 == nil { ifn_2049 = lang.IFn_Cast(root_2047) } else { ifn_2049 = nil }; var arg_2050 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(Vts__7_); var arg_2051 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(Tts__5_); if linked_2048 == nil { tmp16 = ifn_2049.Invoke_O_O__O(arg_2050, arg_2051) } else { tmp16 = linked_2048.(*A_arbace_go_check_types_terms_subset_QMARK__A).Invoke_O_O_O__O(root_2047, arg_2050, arg_2051) }; if jrt.J2g_Truth(tmp16) {
														return lang.IFn_Cast(comparability__10).Invoke__O() } else {
															var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_28, nil); var tmp18 any; var root_2052 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_2053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2052, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2054 lang.IFn; if linked_2053 == nil { ifn_2054 = lang.IFn_Cast(root_2052) } else { ifn_2054 = nil }; var arg_2055 any = V__0_; if linked_2053 == nil { tmp18 = ifn_2054.Invoke_O__O(arg_2055) } else { tmp18 = linked_2053.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2052, arg_2055) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, tmp18, nil, T_str__8_)).Ref() } } else {
//line :770:1
																var tmp19 any; var root_2056 any = A_arbace_go_check_types_A_const_238.GetRawRoot__O(); var linked_2057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2056, A_arbace_go_check_types_terms_includes_QMARK__A_fn_class); var ifn_2058 lang.IFn




																if linked_2057 == nil { ifn_2058 = lang.IFn_Cast(root_2056) } else { ifn_2058 = nil }; var arg_2059 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(Tts__5_); var arg_2060 any = V__0_; if linked_2057 == nil { tmp19 = ifn_2058.Invoke_O_O__O(arg_2059, arg_2060) } else { tmp19 = linked_2057.(*A_arbace_go_check_types_terms_includes_QMARK__A).Invoke_O_O_O__O(root_2056, arg_2059, arg_2060) }
//line :770:1
																if jrt.J2g_Truth(tmp19) {




																	return lang.IFn_Cast(comparability__10).Invoke__O() } else {
//line :770:1
																		if A_arbace_go_check_types_A_const_75 != nil {





																			var tmp20 *jrt.RefArray = jrt.ConstRefArray("[0,8,ns18: does not satisfy ns2: (ns12: missing in ns1:)", []*jrt.Class{jrt.String_class}); var tmp21 any; var root_2061 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_2062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2061, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2063 lang.IFn; if linked_2062 == nil { ifn_2063 = lang.IFn_Cast(root_2061) } else { ifn_2063 = nil }; var arg_2064 any = V__0_; if linked_2062 == nil { tmp21 = ifn_2063.Invoke_O__O(arg_2064) } else { tmp21 = linked_2062.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2061, arg_2064) }; var tmp22 any = tmp21; var tmp23 any; var root_2065 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_2066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2065, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2067 lang.IFn; if linked_2066 == nil { ifn_2067 = lang.IFn_Cast(root_2065) } else { ifn_2067 = nil }; var arg_2068 any = V__0_; if linked_2066 == nil { tmp23 = ifn_2067.Invoke_O__O(arg_2068) } else { tmp23 = linked_2066.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2065, arg_2068) }; var tmp24 any = tmp23; var tmp25 any; var root_2069 any = A_arbace_go_check_types_A_const_180.GetRawRoot__O(); var linked_2070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2069, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_2071 lang.IFn
																			if linked_2070 == nil { ifn_2071 = lang.IFn_Cast(root_2069) } else { ifn_2071 = nil }; var arg_2072 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(Tts__5_); if linked_2070 == nil { tmp25 = ifn_2071.Invoke_O__O(arg_2072) } else { tmp25 = linked_2070.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_2069, arg_2072) }
//line :776:1
																			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, tmp22, nil, T_str__8_, nil, tmp24, nil, tmp25, nil)).Ref() } else {
//line :770:1
																				return nil } } } } } } else {
//line :753:1
																					return nil } } } } } }







func A_arbace_go_check_types_satisfies_cause_comparability__219000267_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_satisfies_cause_comparability__219000267_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_comparability__219000267_A{}; t.Ctor_O_O(p0, p1); return t }
//line :761:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000267_A) Ctor_O_O(c__Tts, c__V any) { t.F_Tts = c__Tts; t.F_V = c__V }
//line :761:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000267_A) Invoke_O__O(self any) any {
	var tmp1 any; var root_2012 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_2013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2012, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2014 lang.IFn
	if linked_2013 == nil { ifn_2014 = lang.IFn_Cast(root_2012) } else { ifn_2014 = nil }; var arg_2015 any; var tmp2 any = A_arbace_go_check_types_A_const_108; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_go_check_types_A_const_109.Invoke_O__O(t.F_Tts)) {
		arg_2015 = A_arbace_go_check_types_A_const_110.Invoke_O__O(t.F_Tts) } else {
			var root_2016 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_2017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2016, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2018 lang.IFn; if linked_2017 == nil { ifn_2018 = lang.IFn_Cast(root_2016) } else { ifn_2018 = nil }; var arg_2019 any; var tmp3 any = A_arbace_go_check_types_satisfies_cause_comparability__219000267_fn__219000269_A_New(); var tmp4 *jrt.Class; var fncls__2025 *jrt.Class = A_arbace_go_check_types_satisfies_cause_comparability__219000267_fn__219000269_A_fn_class; if fncls__2025 == nil { var fncls__2025d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_go_check_types_satisfies_cause_comparability__219000267_fn__219000269_A_fn_class = fncls__2025d; tmp4 = fncls__2025d } else { tmp4 = fncls__2025 }; arg_2019 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_2020 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(t.F_Tts); if linked_2017 == nil { arg_2015 = ifn_2018.Invoke_O_O__O(arg_2019, arg_2020) } else { arg_2015 = linked_2017.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2016, arg_2019, arg_2020) } }
//line :763:1
	if linked_2013 == nil { tmp1 = ifn_2014.Invoke_O__O(arg_2015) } else { tmp1 = linked_2013.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2012, arg_2015) }
//line :762:1
	if jrt.J2g_Truth(tmp1) { return nil } else { var tmp5 any; var root_2026 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); var linked_2027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2026, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_2028 lang.IFn




		if linked_2027 == nil { ifn_2028 = lang.IFn_Cast(root_2026) } else { ifn_2028 = nil }; var arg_2029 any = t.F_V; if linked_2027 == nil { tmp5 = ifn_2028.Invoke_O__O(arg_2029) } else { tmp5 = linked_2027.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O__O(root_2026, arg_2029) }
//line :762:1
		if jrt.J2g_Truth(tmp5) { return nil } else { var tmp6 any; var root_2030 any = A_arbace_go_check_types_A_const_236.GetRawRoot__O(); var linked_2031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2030, A_arbace_go_check_types_comparable_QMARK__A_fn_class); var ifn_2032 lang.IFn





			if linked_2031 == nil { ifn_2032 = lang.IFn_Cast(root_2030) } else { ifn_2032 = nil }; var arg_2033 any = t.F_V; if linked_2031 == nil { tmp6 = ifn_2032.Invoke_O__O(arg_2033) } else { tmp6 = linked_2031.(*A_arbace_go_check_types_comparable_QMARK__A).Invoke_O_O__O(root_2030, arg_2033) }
//line :762:1
			if jrt.J2g_Truth(tmp6) { return nil } else { if A_arbace_go_check_types_A_const_75 != nil {






				var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_32); var tmp8 any; var root_2034 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_2035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2034, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2036 lang.IFn; if linked_2035 == nil { ifn_2036 = lang.IFn_Cast(root_2034) } else { ifn_2036 = nil }; var arg_2037 any = t.F_V; if linked_2035 == nil { tmp8 = ifn_2036.Invoke_O__O(arg_2037) } else { tmp8 = linked_2035.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2034, arg_2037) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8, nil)).Ref() } else {
//line :762:1
					return nil
				}
			} } } }
func A_arbace_go_check_types_satisfies_cause_comparability__219000267_fn__219000269_A_New() *A_arbace_go_check_types_satisfies_cause_comparability__219000267_fn__219000269_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_comparability__219000267_fn__219000269_A{}; t.Ctor(); return t }
//line :765:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000267_fn__219000269_A) Ctor() {}
//line :765:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000267_fn__219000269_A) Invoke_O_O__O(self, p__219000268__1 any) any { var vec__219000270__2 any = p__219000268__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000270__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000270__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2021 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); var linked_2022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2021, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_2023 lang.IFn; _ = ___3; if linked_2022 == nil { ifn_2023 = lang.IFn_Cast(root_2021) } else { ifn_2023 = nil }; var arg_2024 any = ty__4; if linked_2022 == nil { return ifn_2023.Invoke_O__O(arg_2024) } else { return linked_2022.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O__O(root_2021, arg_2024) } }

























































































type A_arbace_go_check_types_A struct{ jrt.Object }

var A_arbace_go_check_types_A_const_pool *jrt.RefArray

var A_arbace_go_check_types_A_const_0 *lang.Var

var A_arbace_go_check_types_A_const_1 any

var A_arbace_go_check_types_A_const_2 any

var A_arbace_go_check_types_A_const_3 *lang.Var

var A_arbace_go_check_types_A_const_4 any

var A_arbace_go_check_types_A_const_5 *lang.Var

var A_arbace_go_check_types_A_const_6 *lang.Var

var A_arbace_go_check_types_A_const_7 *lang.Var

var A_arbace_go_check_types_A_const_8 *lang.Var

var A_arbace_go_check_types_A_const_9 any

var A_arbace_go_check_types_A_const_10 *lang.Var

var A_arbace_go_check_types_A_const_11 *lang.Keyword

var A_arbace_go_check_types_A_const_12 *lang.Keyword

var A_arbace_go_check_types_A_const_13 *lang.Var

var A_arbace_go_check_types_A_const_14 *lang.Keyword

var A_arbace_go_check_types_A_const_15 any

var A_arbace_go_check_types_A_const_16 *lang.Keyword

var A_arbace_go_check_types_A_const_17 *lang.Keyword

var A_arbace_go_check_types_A_const_18 *lang.Keyword

var A_arbace_go_check_types_A_const_19 *lang.Keyword

var A_arbace_go_check_types_A_const_20 any

var A_arbace_go_check_types_A_const_21 *lang.Keyword

var A_arbace_go_check_types_A_const_22 any

var A_arbace_go_check_types_A_const_23 *lang.Keyword

var A_arbace_go_check_types_A_const_24 any

var A_arbace_go_check_types_A_const_25 *lang.Keyword

var A_arbace_go_check_types_A_const_26 *lang.Keyword

var A_arbace_go_check_types_A_const_27 *lang.Keyword

var A_arbace_go_check_types_A_const_28 *lang.Keyword

var A_arbace_go_check_types_A_const_29 *lang.Keyword

var A_arbace_go_check_types_A_const_30 *lang.Keyword

var A_arbace_go_check_types_A_const_31 *lang.Keyword

var A_arbace_go_check_types_A_const_32 *lang.Keyword

var A_arbace_go_check_types_A_const_33 *lang.Keyword

var A_arbace_go_check_types_A_const_34 *lang.Keyword

var A_arbace_go_check_types_A_const_35 *lang.Keyword

var A_arbace_go_check_types_A_const_36 *lang.Keyword

var A_arbace_go_check_types_A_const_37 *lang.Keyword

var A_arbace_go_check_types_A_const_38 *lang.Keyword

var A_arbace_go_check_types_A_const_39 any

var A_arbace_go_check_types_A_const_40 *lang.Keyword

var A_arbace_go_check_types_A_const_41 *lang.Keyword

var A_arbace_go_check_types_A_const_42 *lang.Keyword

var A_arbace_go_check_types_A_const_43 *lang.Keyword

var A_arbace_go_check_types_A_const_44 any

var A_arbace_go_check_types_A_const_45 *lang.Keyword

var A_arbace_go_check_types_A_const_46 *lang.Keyword

var A_arbace_go_check_types_A_const_47 *lang.Keyword

var A_arbace_go_check_types_A_const_48 *lang.Keyword

var A_arbace_go_check_types_A_const_49 *lang.Keyword

var A_arbace_go_check_types_A_const_50 *lang.Keyword

var A_arbace_go_check_types_A_const_51 *lang.Keyword

var A_arbace_go_check_types_A_const_52 *lang.Var

var A_arbace_go_check_types_A_const_53 *lang.Var

var A_arbace_go_check_types_A_const_54 *lang.Keyword

var A_arbace_go_check_types_A_const_55 *lang.Keyword

var A_arbace_go_check_types_A_const_56 *lang.Var

var A_arbace_go_check_types_A_const_57 *lang.Var

var A_arbace_go_check_types_A_const_58 *lang.Var

var A_arbace_go_check_types_A_const_59 *lang.Var

var A_arbace_go_check_types_A_const_60 *lang.Keyword

var A_arbace_go_check_types_A_const_61 *lang.Var

var A_arbace_go_check_types_A_const_62 *lang.Keyword

var A_arbace_go_check_types_A_const_63 *lang.Var

var A_arbace_go_check_types_A_const_64 *lang.Keyword

var A_arbace_go_check_types_A_const_65 *lang.Var

var A_arbace_go_check_types_A_const_66 *lang.Var

var A_arbace_go_check_types_A_const_67 *lang.Keyword

var A_arbace_go_check_types_A_const_68 *lang.Var

var A_arbace_go_check_types_A_const_69 *lang.Var

var A_arbace_go_check_types_A_const_70 *lang.Keyword

var A_arbace_go_check_types_A_const_71 *lang.Keyword

var A_arbace_go_check_types_A_const_72 *lang.Var

var A_arbace_go_check_types_A_const_73 *lang.Var

var A_arbace_go_check_types_A_const_74 *lang.Var

var A_arbace_go_check_types_A_const_75 *lang.Keyword

var A_arbace_go_check_types_A_const_76 *lang.Var

var A_arbace_go_check_types_A_const_77 *lang.Var

var A_arbace_go_check_types_A_const_78 *lang.Var

var A_arbace_go_check_types_A_const_79 *lang.Var

var A_arbace_go_check_types_A_const_80 *lang.Var

var A_arbace_go_check_types_A_const_81 *lang.Var

var A_arbace_go_check_types_A_const_82 *lang.Var

var A_arbace_go_check_types_A_const_83 *lang.Var

var A_arbace_go_check_types_A_const_84 any

var A_arbace_go_check_types_A_const_85 *lang.Var

var A_arbace_go_check_types_A_const_86 *lang.Keyword

var A_arbace_go_check_types_A_const_87 *lang.Keyword

var A_arbace_go_check_types_A_const_88 *lang.Var

var A_arbace_go_check_types_A_const_89 *lang.Var

var A_arbace_go_check_types_A_const_90 *lang.Var

var A_arbace_go_check_types_A_const_91 *lang.Var

var A_arbace_go_check_types_A_const_92 *lang.Var

var A_arbace_go_check_types_A_const_93 any

var A_arbace_go_check_types_A_const_94 *lang.Var

var A_arbace_go_check_types_A_const_95 *lang.Keyword

var A_arbace_go_check_types_A_const_96 *lang.Keyword

var A_arbace_go_check_types_A_const_97 *lang.Keyword

var A_arbace_go_check_types_A_const_98 *lang.Keyword

var A_arbace_go_check_types_A_const_99 *lang.Var

var A_arbace_go_check_types_A_const_100 *lang.Keyword

var A_arbace_go_check_types_A_const_101 any

var A_arbace_go_check_types_A_const_102 *lang.Var

var A_arbace_go_check_types_A_const_103 *lang.Keyword

var A_arbace_go_check_types_A_const_104 *lang.Var

var A_arbace_go_check_types_A_const_105 *lang.Keyword

var A_arbace_go_check_types_A_const_106 *lang.Keyword

var A_arbace_go_check_types_A_const_107 *lang.Keyword

var A_arbace_go_check_types_A_const_108 *lang.Keyword

var A_arbace_go_check_types_A_const_109 *lang.Keyword

var A_arbace_go_check_types_A_const_110 *lang.Keyword

var A_arbace_go_check_types_A_const_111 *lang.Var

var A_arbace_go_check_types_A_const_112 *lang.Var

var A_arbace_go_check_types_A_const_113 *lang.Var

var A_arbace_go_check_types_A_const_114 *lang.Var

var A_arbace_go_check_types_A_const_115 *lang.Var

var A_arbace_go_check_types_A_const_116 *lang.Var

var A_arbace_go_check_types_A_const_117 *lang.Var

var A_arbace_go_check_types_A_const_118 *lang.Keyword

var A_arbace_go_check_types_A_const_119 *lang.Var

var A_arbace_go_check_types_A_const_120 *lang.Var

var A_arbace_go_check_types_A_const_121 *lang.Var

var A_arbace_go_check_types_A_const_122 *lang.Var

var A_arbace_go_check_types_A_const_123 *lang.Var

var A_arbace_go_check_types_A_const_124 *lang.Keyword

var A_arbace_go_check_types_A_const_125 *lang.Var

var A_arbace_go_check_types_A_const_126 *lang.Var

var A_arbace_go_check_types_A_const_127 *lang.Var

var A_arbace_go_check_types_A_const_128 *lang.Var

var A_arbace_go_check_types_A_const_129 *lang.Var

var A_arbace_go_check_types_A_const_130 *lang.Var

var A_arbace_go_check_types_A_const_131 *lang.Var

var A_arbace_go_check_types_A_const_132 *lang.Var

var A_arbace_go_check_types_A_const_133 *lang.Var

var A_arbace_go_check_types_A_const_134 *lang.Var

var A_arbace_go_check_types_A_const_135 *lang.Var

var A_arbace_go_check_types_A_const_136 *lang.Var

var A_arbace_go_check_types_A_const_137 *lang.Var

var A_arbace_go_check_types_A_const_138 *lang.Var

var A_arbace_go_check_types_A_const_139 *lang.Var

var A_arbace_go_check_types_A_const_140 *lang.Var

var A_arbace_go_check_types_A_const_141 *lang.Var

var A_arbace_go_check_types_A_const_142 *lang.Var

var A_arbace_go_check_types_A_const_143 *lang.Var

var A_arbace_go_check_types_A_const_144 *lang.Keyword

var A_arbace_go_check_types_A_const_145 *lang.Var

var A_arbace_go_check_types_A_const_146 *lang.Keyword

var A_arbace_go_check_types_A_const_147 *lang.Var

var A_arbace_go_check_types_A_const_148 *lang.Var

var A_arbace_go_check_types_A_const_149 any

var A_arbace_go_check_types_A_const_150 *lang.Var

var A_arbace_go_check_types_A_const_151 *lang.Var

var A_arbace_go_check_types_A_const_152 *lang.Var

var A_arbace_go_check_types_A_const_153 *lang.Var

var A_arbace_go_check_types_A_const_154 *lang.Var

var A_arbace_go_check_types_A_const_155 *lang.Var

var A_arbace_go_check_types_A_const_156 *lang.Var

var A_arbace_go_check_types_A_const_157 any

var A_arbace_go_check_types_A_const_158 *lang.Keyword

var A_arbace_go_check_types_A_const_159 any

var A_arbace_go_check_types_A_const_160 any

var A_arbace_go_check_types_A_const_161 *lang.Var

var A_arbace_go_check_types_A_const_162 *lang.Var

var A_arbace_go_check_types_A_const_163 *lang.Var

var A_arbace_go_check_types_A_const_164 *lang.Var

var A_arbace_go_check_types_A_const_165 *lang.Var

var A_arbace_go_check_types_A_const_166 *lang.Var

var A_arbace_go_check_types_A_const_167 *lang.Var

var A_arbace_go_check_types_A_const_168 *lang.Keyword

var A_arbace_go_check_types_A_const_169 *lang.Var

var A_arbace_go_check_types_A_const_170 *lang.Keyword

var A_arbace_go_check_types_A_const_171 *lang.Var

var A_arbace_go_check_types_A_const_172 *lang.Keyword

var A_arbace_go_check_types_A_const_173 *lang.Keyword

var A_arbace_go_check_types_A_const_174 *lang.Keyword

var A_arbace_go_check_types_A_const_175 *lang.Var

var A_arbace_go_check_types_A_const_176 *lang.Var

var A_arbace_go_check_types_A_const_177 *lang.Var

var A_arbace_go_check_types_A_const_178 any

var A_arbace_go_check_types_A_const_179 *lang.Var

var A_arbace_go_check_types_A_const_180 *lang.Var

var A_arbace_go_check_types_A_const_181 *lang.Keyword

var A_arbace_go_check_types_A_const_182 *lang.Keyword

var A_arbace_go_check_types_A_const_183 *lang.Var

var A_arbace_go_check_types_A_const_184 any

var A_arbace_go_check_types_A_const_185 *lang.Var

var A_arbace_go_check_types_A_const_186 *lang.Var

var A_arbace_go_check_types_A_const_187 *lang.Var

var A_arbace_go_check_types_A_const_188 any

var A_arbace_go_check_types_A_const_189 *lang.Var

var A_arbace_go_check_types_A_const_190 *lang.Var

var A_arbace_go_check_types_A_const_191 *lang.Var

var A_arbace_go_check_types_A_const_192 *lang.Var

var A_arbace_go_check_types_A_const_193 *lang.Var

var A_arbace_go_check_types_A_const_194 *lang.Var

var A_arbace_go_check_types_A_const_195 *lang.Keyword

var A_arbace_go_check_types_A_const_196 *lang.Var

var A_arbace_go_check_types_A_const_197 *lang.Var

var A_arbace_go_check_types_A_const_198 *lang.Var

var A_arbace_go_check_types_A_const_199 *lang.Var

var A_arbace_go_check_types_A_const_200 *lang.Var

var A_arbace_go_check_types_A_const_201 *lang.Var

var A_arbace_go_check_types_A_const_202 *lang.Keyword

var A_arbace_go_check_types_A_const_203 *lang.Var

var A_arbace_go_check_types_A_const_204 *lang.Var

var A_arbace_go_check_types_A_const_205 *lang.Var

var A_arbace_go_check_types_A_const_206 *lang.Var

var A_arbace_go_check_types_A_const_207 any

var A_arbace_go_check_types_A_const_208 *lang.Keyword

var A_arbace_go_check_types_A_const_209 *lang.Keyword

var A_arbace_go_check_types_A_const_210 *lang.Var

var A_arbace_go_check_types_A_const_211 *lang.Keyword

var A_arbace_go_check_types_A_const_212 *lang.Keyword

var A_arbace_go_check_types_A_const_213 *lang.Keyword

var A_arbace_go_check_types_A_const_214 *lang.Keyword

var A_arbace_go_check_types_A_const_215 any

var A_arbace_go_check_types_A_const_216 *lang.Keyword

var A_arbace_go_check_types_A_const_217 any

var A_arbace_go_check_types_A_const_218 *lang.Keyword

var A_arbace_go_check_types_A_const_219 *lang.Keyword

var A_arbace_go_check_types_A_const_220 *lang.Keyword

var A_arbace_go_check_types_A_const_221 *lang.Var

var A_arbace_go_check_types_A_const_222 *lang.Keyword

var A_arbace_go_check_types_A_const_223 *lang.Var

var A_arbace_go_check_types_A_const_224 *lang.Var

var A_arbace_go_check_types_A_const_225 *lang.Var

var A_arbace_go_check_types_A_const_226 *lang.Keyword

var A_arbace_go_check_types_A_const_227 *lang.Keyword

var A_arbace_go_check_types_A_const_228 *lang.Keyword

var A_arbace_go_check_types_A_const_229 *lang.Keyword

var A_arbace_go_check_types_A_const_230 *lang.Var

var A_arbace_go_check_types_A_const_231 *lang.Var

var A_arbace_go_check_types_A_const_232 *lang.Keyword

var A_arbace_go_check_types_A_const_233 *lang.Var

var A_arbace_go_check_types_A_const_234 *lang.Var

var A_arbace_go_check_types_A_const_235 *lang.Var

var A_arbace_go_check_types_A_const_236 *lang.Var

var A_arbace_go_check_types_A_const_237 *lang.Var

var A_arbace_go_check_types_A_const_238 *lang.Var

var A_arbace_go_check_types_A_init jrt.ClassInit

func A_arbace_go_check_types_A_Init() { if !A_arbace_go_check_types_A_init.Done() { A_arbace_go_check_types_A_init.Run(A_arbace_go_check_types_A_clinit) } }

func A_arbace_go_check_types_A_clinit() { A_arbace_go_check_types_A_clinit_p0(); A_arbace_go_check_types_A_clinit_p1(); A_arbace_go_check_types_A_clinit_p2(); A_arbace_go_check_types_A_clinit_p3(); A_arbace_go_check_types_A_clinit_p4(); A_arbace_go_check_types_A_clinit_p5(); A_arbace_go_check_types_A_clinit_p6(); A_arbace_go_check_types_A_clinit_p7(); A_arbace_go_check_types_A_clinit_p8(); A_arbace_go_check_types_A_clinit_p9(); A_arbace_go_check_types_A_clinit_p10(); A_arbace_go_check_types_A_clinit_p11(); A_arbace_go_check_types_A_clinit_p12(); A_arbace_go_check_types_A_clinit_p13(); A_arbace_go_check_types_A_clinit_p14(); A_arbace_go_check_types_A_clinit_p15(); A_arbace_go_check_types_A_clinit_p16(); A_arbace_go_check_types_A_clinit_p17(); A_arbace_go_check_types_A_clinit_p18(); A_arbace_go_check_types_A_clinit_p19() }

func A_arbace_go_check_types_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_types_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 333); A_arbace_go_check_types_A_const_0 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[94]); A_arbace_go_check_types_A_const_1 = A_arbace_go_check_types_A_const_pool.A[95]; A_arbace_go_check_types_A_const_2 = A_arbace_go_check_types_A_const_pool.A[96]; A_arbace_go_check_types_A_const_3 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[97]); A_arbace_go_check_types_A_const_4 = A_arbace_go_check_types_A_const_pool.A[98]; A_arbace_go_check_types_A_const_5 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[99]); A_arbace_go_check_types_A_const_6 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[100]); A_arbace_go_check_types_A_const_7 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[101]); A_arbace_go_check_types_A_const_8 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[102]); A_arbace_go_check_types_A_const_9 = A_arbace_go_check_types_A_const_pool.A[103]; A_arbace_go_check_types_A_const_10 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[104]); A_arbace_go_check_types_A_const_11 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[105]) }

func A_arbace_go_check_types_A_clinit_p1() { A_arbace_go_check_types_A_const_12 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[106]); A_arbace_go_check_types_A_const_13 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[107]); A_arbace_go_check_types_A_const_14 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[108]); A_arbace_go_check_types_A_const_15 = A_arbace_go_check_types_A_const_pool.A[109]; A_arbace_go_check_types_A_const_16 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[110]); A_arbace_go_check_types_A_const_17 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[111]); A_arbace_go_check_types_A_const_18 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[112]); A_arbace_go_check_types_A_const_19 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[113]); A_arbace_go_check_types_A_const_20 = A_arbace_go_check_types_A_const_pool.A[114]; A_arbace_go_check_types_A_const_21 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[115]); A_arbace_go_check_types_A_const_22 = A_arbace_go_check_types_A_const_pool.A[116]; A_arbace_go_check_types_A_const_23 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[117]); A_arbace_go_check_types_A_const_24 = A_arbace_go_check_types_A_const_pool.A[118] }

func A_arbace_go_check_types_A_clinit_p2() { A_arbace_go_check_types_A_const_25 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[119]); A_arbace_go_check_types_A_const_26 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[120]); A_arbace_go_check_types_A_const_27 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[121]); A_arbace_go_check_types_A_const_28 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[122]); A_arbace_go_check_types_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[123]); A_arbace_go_check_types_A_const_30 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[124]); A_arbace_go_check_types_A_const_31 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[125]); A_arbace_go_check_types_A_const_32 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[126]); A_arbace_go_check_types_A_const_33 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[127]); A_arbace_go_check_types_A_const_34 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[128]); A_arbace_go_check_types_A_const_35 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[129]); A_arbace_go_check_types_A_const_36 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[130]) }

func A_arbace_go_check_types_A_clinit_p3() { A_arbace_go_check_types_A_const_37 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[131]); A_arbace_go_check_types_A_const_38 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[132]); A_arbace_go_check_types_A_const_39 = A_arbace_go_check_types_A_const_pool.A[133]; A_arbace_go_check_types_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[134]); A_arbace_go_check_types_A_const_41 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[135]); A_arbace_go_check_types_A_const_42 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[136]); A_arbace_go_check_types_A_const_43 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[137]); A_arbace_go_check_types_A_const_44 = A_arbace_go_check_types_A_const_pool.A[138]; A_arbace_go_check_types_A_const_45 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[139]); A_arbace_go_check_types_A_const_46 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[140]); A_arbace_go_check_types_A_const_47 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[141]); A_arbace_go_check_types_A_const_48 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[142]) }

func A_arbace_go_check_types_A_clinit_p4() { A_arbace_go_check_types_A_const_49 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[143]); A_arbace_go_check_types_A_const_50 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[144]); A_arbace_go_check_types_A_const_51 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[145]); A_arbace_go_check_types_A_const_52 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[146]); A_arbace_go_check_types_A_const_53 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[147]); A_arbace_go_check_types_A_const_54 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[148]); A_arbace_go_check_types_A_const_55 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[149]); A_arbace_go_check_types_A_const_56 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[150]); A_arbace_go_check_types_A_const_57 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[151]); A_arbace_go_check_types_A_const_58 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[152]); A_arbace_go_check_types_A_const_59 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[153]); A_arbace_go_check_types_A_const_60 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[154]) }

func A_arbace_go_check_types_A_clinit_p5() { A_arbace_go_check_types_A_const_61 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[155]); A_arbace_go_check_types_A_const_62 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[156]); A_arbace_go_check_types_A_const_63 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[157]); A_arbace_go_check_types_A_const_64 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[158]); A_arbace_go_check_types_A_const_65 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[159]); A_arbace_go_check_types_A_const_66 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[160]); A_arbace_go_check_types_A_const_67 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[161]); A_arbace_go_check_types_A_const_68 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[162]); A_arbace_go_check_types_A_const_69 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[163]); A_arbace_go_check_types_A_const_70 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[164]); A_arbace_go_check_types_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[165]); A_arbace_go_check_types_A_const_72 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[166]) }

func A_arbace_go_check_types_A_clinit_p6() { A_arbace_go_check_types_A_const_73 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[167]); A_arbace_go_check_types_A_const_74 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[168]); A_arbace_go_check_types_A_const_75 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[169]); A_arbace_go_check_types_A_const_76 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[170]); A_arbace_go_check_types_A_const_77 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[171]); A_arbace_go_check_types_A_const_78 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[172]); A_arbace_go_check_types_A_const_79 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[173]); A_arbace_go_check_types_A_const_80 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[174]); A_arbace_go_check_types_A_const_81 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[175]); A_arbace_go_check_types_A_const_82 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[176]); A_arbace_go_check_types_A_const_83 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[177]); A_arbace_go_check_types_A_const_84 = A_arbace_go_check_types_A_const_pool.A[178] }

func A_arbace_go_check_types_A_clinit_p7() { A_arbace_go_check_types_A_const_85 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[179]); A_arbace_go_check_types_A_const_86 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[180]); A_arbace_go_check_types_A_const_87 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[181]); A_arbace_go_check_types_A_const_88 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[182]); A_arbace_go_check_types_A_const_89 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[183]); A_arbace_go_check_types_A_const_90 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[184]); A_arbace_go_check_types_A_const_91 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[185]); A_arbace_go_check_types_A_const_92 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[186]); A_arbace_go_check_types_A_const_93 = A_arbace_go_check_types_A_const_pool.A[187]; A_arbace_go_check_types_A_const_94 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[188]); A_arbace_go_check_types_A_const_95 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[189]); A_arbace_go_check_types_A_const_96 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[190]) }

func A_arbace_go_check_types_A_clinit_p8() { A_arbace_go_check_types_A_const_97 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[191]); A_arbace_go_check_types_A_const_98 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[192]); A_arbace_go_check_types_A_const_99 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[193]); A_arbace_go_check_types_A_const_100 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[194]); A_arbace_go_check_types_A_const_101 = A_arbace_go_check_types_A_const_pool.A[195]; A_arbace_go_check_types_A_const_102 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[196]); A_arbace_go_check_types_A_const_103 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[197]); A_arbace_go_check_types_A_const_104 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[198]); A_arbace_go_check_types_A_const_105 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[199]); A_arbace_go_check_types_A_const_106 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[200]); A_arbace_go_check_types_A_const_107 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[201]); A_arbace_go_check_types_A_const_108 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[202]) }

func A_arbace_go_check_types_A_clinit_p9() { A_arbace_go_check_types_A_const_109 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[203]); A_arbace_go_check_types_A_const_110 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[204]); A_arbace_go_check_types_A_const_111 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[205]); A_arbace_go_check_types_A_const_112 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[206]); A_arbace_go_check_types_A_const_113 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[207]); A_arbace_go_check_types_A_const_114 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[208]); A_arbace_go_check_types_A_const_115 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[209]); A_arbace_go_check_types_A_const_116 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[210]); A_arbace_go_check_types_A_const_117 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[211]); A_arbace_go_check_types_A_const_118 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[212]); A_arbace_go_check_types_A_const_119 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[213]); A_arbace_go_check_types_A_const_120 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[214]) }

func A_arbace_go_check_types_A_clinit_p10() { A_arbace_go_check_types_A_const_121 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[215]); A_arbace_go_check_types_A_const_122 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[216]); A_arbace_go_check_types_A_const_123 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[217]); A_arbace_go_check_types_A_const_124 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[218]); A_arbace_go_check_types_A_const_125 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[219]); A_arbace_go_check_types_A_const_126 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[220]); A_arbace_go_check_types_A_const_127 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[221]); A_arbace_go_check_types_A_const_128 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[222]); A_arbace_go_check_types_A_const_129 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[223]); A_arbace_go_check_types_A_const_130 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[224]); A_arbace_go_check_types_A_const_131 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[225]); A_arbace_go_check_types_A_const_132 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[226]) }

func A_arbace_go_check_types_A_clinit_p11() { A_arbace_go_check_types_A_const_133 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[227]); A_arbace_go_check_types_A_const_134 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[228]); A_arbace_go_check_types_A_const_135 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[229]); A_arbace_go_check_types_A_const_136 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[230]); A_arbace_go_check_types_A_const_137 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[231]); A_arbace_go_check_types_A_const_138 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[232]); A_arbace_go_check_types_A_const_139 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[233]); A_arbace_go_check_types_A_const_140 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[234]); A_arbace_go_check_types_A_const_141 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[235]); A_arbace_go_check_types_A_const_142 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[236]); A_arbace_go_check_types_A_const_143 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[237]); A_arbace_go_check_types_A_const_144 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[238]) }

func A_arbace_go_check_types_A_clinit_p12() { A_arbace_go_check_types_A_const_145 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[239]); A_arbace_go_check_types_A_const_146 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[240]); A_arbace_go_check_types_A_const_147 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[241]); A_arbace_go_check_types_A_const_148 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[242]); A_arbace_go_check_types_A_const_149 = A_arbace_go_check_types_A_const_pool.A[243]; A_arbace_go_check_types_A_const_150 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[244]); A_arbace_go_check_types_A_const_151 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[245]); A_arbace_go_check_types_A_const_152 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[246]); A_arbace_go_check_types_A_const_153 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[247]); A_arbace_go_check_types_A_const_154 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[248]); A_arbace_go_check_types_A_const_155 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[249]); A_arbace_go_check_types_A_const_156 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[250]) }

func A_arbace_go_check_types_A_clinit_p13() { A_arbace_go_check_types_A_const_157 = A_arbace_go_check_types_A_const_pool.A[251]; A_arbace_go_check_types_A_const_158 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[252]); A_arbace_go_check_types_A_const_159 = A_arbace_go_check_types_A_const_pool.A[253]; A_arbace_go_check_types_A_const_160 = A_arbace_go_check_types_A_const_pool.A[254]; A_arbace_go_check_types_A_const_161 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[255]); A_arbace_go_check_types_A_const_162 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[256]); A_arbace_go_check_types_A_const_163 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[257]); A_arbace_go_check_types_A_const_164 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[258]); A_arbace_go_check_types_A_const_165 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[259]); A_arbace_go_check_types_A_const_166 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[260]); A_arbace_go_check_types_A_const_167 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[261]); A_arbace_go_check_types_A_const_168 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[262]) }

func A_arbace_go_check_types_A_clinit_p14() { A_arbace_go_check_types_A_const_169 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[263]); A_arbace_go_check_types_A_const_170 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[264]); A_arbace_go_check_types_A_const_171 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[265]); A_arbace_go_check_types_A_const_172 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[266]); A_arbace_go_check_types_A_const_173 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[267]); A_arbace_go_check_types_A_const_174 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[268]); A_arbace_go_check_types_A_const_175 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[269]); A_arbace_go_check_types_A_const_176 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[270]); A_arbace_go_check_types_A_const_177 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[271]); A_arbace_go_check_types_A_const_178 = A_arbace_go_check_types_A_const_pool.A[272]; A_arbace_go_check_types_A_const_179 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[273]); A_arbace_go_check_types_A_const_180 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[274]) }

func A_arbace_go_check_types_A_clinit_p15() { A_arbace_go_check_types_A_const_181 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[275]); A_arbace_go_check_types_A_const_182 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[276]); A_arbace_go_check_types_A_const_183 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[277]); A_arbace_go_check_types_A_const_184 = A_arbace_go_check_types_A_const_pool.A[278]; A_arbace_go_check_types_A_const_185 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[279]); A_arbace_go_check_types_A_const_186 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[280]); A_arbace_go_check_types_A_const_187 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[281]); A_arbace_go_check_types_A_const_188 = A_arbace_go_check_types_A_const_pool.A[282]; A_arbace_go_check_types_A_const_189 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[283]); A_arbace_go_check_types_A_const_190 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[284]); A_arbace_go_check_types_A_const_191 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[285]); A_arbace_go_check_types_A_const_192 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[286]) }

func A_arbace_go_check_types_A_clinit_p16() { A_arbace_go_check_types_A_const_193 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[287]); A_arbace_go_check_types_A_const_194 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[288]); A_arbace_go_check_types_A_const_195 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[289]); A_arbace_go_check_types_A_const_196 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[290]); A_arbace_go_check_types_A_const_197 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[291]); A_arbace_go_check_types_A_const_198 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[292]); A_arbace_go_check_types_A_const_199 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[293]); A_arbace_go_check_types_A_const_200 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[294]); A_arbace_go_check_types_A_const_201 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[295]); A_arbace_go_check_types_A_const_202 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[296]); A_arbace_go_check_types_A_const_203 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[297]); A_arbace_go_check_types_A_const_204 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[298]) }

func A_arbace_go_check_types_A_clinit_p17() { A_arbace_go_check_types_A_const_205 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[299]); A_arbace_go_check_types_A_const_206 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[300]); A_arbace_go_check_types_A_const_207 = A_arbace_go_check_types_A_const_pool.A[301]; A_arbace_go_check_types_A_const_208 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[302]); A_arbace_go_check_types_A_const_209 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[303]); A_arbace_go_check_types_A_const_210 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[304]); A_arbace_go_check_types_A_const_211 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[305]); A_arbace_go_check_types_A_const_212 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[306]); A_arbace_go_check_types_A_const_213 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[307]); A_arbace_go_check_types_A_const_214 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[308]); A_arbace_go_check_types_A_const_215 = A_arbace_go_check_types_A_const_pool.A[309]; A_arbace_go_check_types_A_const_216 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[310]) }

func A_arbace_go_check_types_A_clinit_p18() { A_arbace_go_check_types_A_const_217 = A_arbace_go_check_types_A_const_pool.A[311]; A_arbace_go_check_types_A_const_218 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[312]); A_arbace_go_check_types_A_const_219 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[313]); A_arbace_go_check_types_A_const_220 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[314]); A_arbace_go_check_types_A_const_221 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[315]); A_arbace_go_check_types_A_const_222 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[316]); A_arbace_go_check_types_A_const_223 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[317]); A_arbace_go_check_types_A_const_224 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[318]); A_arbace_go_check_types_A_const_225 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[319]); A_arbace_go_check_types_A_const_226 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[320]); A_arbace_go_check_types_A_const_227 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[321]); A_arbace_go_check_types_A_const_228 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[322]) }

func A_arbace_go_check_types_A_clinit_p19() { A_arbace_go_check_types_A_const_229 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[323]); A_arbace_go_check_types_A_const_230 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[324]); A_arbace_go_check_types_A_const_231 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[325]); A_arbace_go_check_types_A_const_232 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[326]); A_arbace_go_check_types_A_const_233 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[327]); A_arbace_go_check_types_A_const_234 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[328]); A_arbace_go_check_types_A_const_235 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[329]); A_arbace_go_check_types_A_const_236 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[330]); A_arbace_go_check_types_A_const_237 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[331]); A_arbace_go_check_types_A_const_238 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[332]) }

func A_arbace_go_check_types_A_New() *A_arbace_go_check_types_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_A) Ctor() {}

func (t *A_arbace_go_check_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_A_class }

func (t *A_arbace_go_check_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_A); return ok }

func A_arbace_go_check_types_A_Cast(x any) *A_arbace_go_check_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_A_class)) }; return v }



type A_arbace_go_check_types_align_up_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_align_up_A_fn_class *jrt.Class



type A_arbace_go_check_types_alignof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alignof_A_fn_class *jrt.Class



type A_arbace_go_check_types_alignof_fn__219000227_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alignof_fn__219000227_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_basic_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_basic_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_basic_fn__219000161_A struct{ j2g_header uint64; F_pred any }

var A_arbace_go_check_types_all_basic_fn__219000161_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_boolean_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_boolean_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_complex_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_complex_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_float_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_float_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_integer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_integer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_or_string_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_or_string_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000174_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000174_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_ordered_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_ordered_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_string_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_string_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_unsigned_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_unsigned_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_basic_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_basic_A_fn_class *jrt.Class



type A_arbace_go_check_types_boolean_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_boolean_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_bound_iface_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_bound_iface_A_fn_class *jrt.Class



type A_arbace_go_check_types_common_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_common_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_comparable_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A struct{ j2g_header uint64; F_seen, F_dynamic any }

var A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A_fn_class *jrt.Class



type A_arbace_go_check_types_complex_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_complex_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_consolidate_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_consolidate_A_fn_class *jrt.Class



type A_arbace_go_check_types_const_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_const_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_core_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_core_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_default_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_default_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_deref_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_deref_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_empty_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_empty_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_eval219000004_A struct{ jrt.Object }

func A_arbace_go_check_types_eval219000004_A_New() *A_arbace_go_check_types_eval219000004_A { t := &A_arbace_go_check_types_eval219000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_eval219000004_A) Ctor() {}

func (t *A_arbace_go_check_types_eval219000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_eval219000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_eval219000004_A_class }

func (t *A_arbace_go_check_types_eval219000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_eval219000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_eval219000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_eval219000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_eval219000004_A); return ok }

func A_arbace_go_check_types_eval219000004_A_Cast(x any) *A_arbace_go_check_types_eval219000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_eval219000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_eval219000004_A_class)) }; return v }



type A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_fn_class *jrt.Class



type A_arbace_go_check_types_eval219000008_A struct{ jrt.Object }

func A_arbace_go_check_types_eval219000008_A_New() *A_arbace_go_check_types_eval219000008_A { t := &A_arbace_go_check_types_eval219000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_eval219000008_A) Ctor() {}

func (t *A_arbace_go_check_types_eval219000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_eval219000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_eval219000008_A_class }

func (t *A_arbace_go_check_types_eval219000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_eval219000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_eval219000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_eval219000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_eval219000008_A); return ok }

func A_arbace_go_check_types_eval219000008_A_Cast(x any) *A_arbace_go_check_types_eval219000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_eval219000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_eval219000008_A_class)) }; return v }



type A_arbace_go_check_types_eval219000008_fn__219000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_eval219000008_fn__219000009_A_fn_class *jrt.Class



type A_arbace_go_check_types_exported_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_exported_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_field_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_field_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_flag_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_flag_A_fn_class *jrt.Class



type A_arbace_go_check_types_float_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_float_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_m__219000013_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class *jrt.Class



type A_arbace_go_check_types_has_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_name_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_has_nil_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_nil_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A_fn_class *jrt.Class



type A_arbace_go_check_types_has_terms_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_terms_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_identical_ignore_tags_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_identical_ignore_tags_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_iface_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_iface_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_iface_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_iface_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_ignore_tags_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ignore_tags_A_fn_class *jrt.Class



type A_arbace_go_check_types_ignore_tags_fn__219000056_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ignore_tags_fn__219000056_A_fn_class *jrt.Class



type A_arbace_go_check_types_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_info_A_fn_class *jrt.Class



type A_arbace_go_check_types_integer_or_float_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_integer_or_float_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_integer_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_integer_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_kind_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_kind_of_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_lookup_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_impl_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_lookup_impl_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_impl_fn__219000250_A struct{ j2g_header uint64; F_pkg, F_name any }

var A_arbace_go_check_types_lookup_impl_fn__219000250_A_fn_class *jrt.Class



type A_arbace_go_check_types_make_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_make_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_method_data_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_method_data_A_fn_class *jrt.Class



type A_arbace_go_check_types_method_set_iface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_method_set_iface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_methods_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_methods_of_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_missing_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_fn__219000264_A struct{ j2g_header uint64; F_static, F_V, F_same_QMARK_, F_vu any }

var A_arbace_go_check_types_missing_method_fn__219000264_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_named_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_new_named_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_new_named_A_fn_class *jrt.Class



type A_arbace_go_check_types_new_tparam_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_new_tparam_A_fn_class *jrt.Class



type A_arbace_go_check_types_next_id_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_next_id_A_fn_class *jrt.Class



type A_arbace_go_check_types_numeric_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_offsetsof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_offsetsof_A_fn_class *jrt.Class



type A_arbace_go_check_types_ordered_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ordered_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_params_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_params_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_params_str_fn__219000201_A struct{ j2g_header uint64; F_ps, F_variadic any }

var A_arbace_go_check_types_params_str_fn__219000201_A_fn_class *jrt.Class



type A_arbace_go_check_types_pointer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_pointer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_same_id_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_same_id_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_satisfies_cause_A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_comparability__219000267_A struct{ j2g_header uint64; F_Tts, F_V any }

var A_arbace_go_check_types_satisfies_cause_comparability__219000267_A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_comparability__219000267_fn__219000269_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_satisfies_cause_comparability__219000267_fn__219000269_A_fn_class *jrt.Class



type A_arbace_go_check_types_sig_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sig_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_sizeof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sizeof_A_fn_class *jrt.Class



type A_arbace_go_check_types_sort_methods_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sort_methods_A_fn_class *jrt.Class



type A_arbace_go_check_types_sort_methods_fn__219000260_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sort_methods_fn__219000260_A_fn_class *jrt.Class



type A_arbace_go_check_types_strictly_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_string_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_string_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_sync_atomic_align64_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_disjoint_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_includes_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_includes_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_intersect_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_intersect_A_fn_class *jrt.Class



type A_arbace_go_check_types_term_subset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_subset_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_union_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_union_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_includes_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_includes_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_includes_QMARK__fn__219000114_A struct{ j2g_header uint64; F_t any }

var A_arbace_go_check_types_terms_includes_QMARK__fn__219000114_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_intersect_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_A struct{ j2g_header uint64; F_y any }

var A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_A struct{ j2g_header uint64; F_s__219000097, F_y, F_iter__219000096 any }

var A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_A struct{ j2g_header uint64; F_a any }

var A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_A struct{ j2g_header uint64; F_iter__219000098, F_s__219000099, F_a any }

var A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_fn__219000106_A struct{ j2g_header uint64; F_b__219000101 any; F_size__1927001038__auto__ int32; F_a, F_c__1927001037__auto__ any }

var A_arbace_go_check_types_terms_intersect_iter__219000096__219000102_fn__219000103_iter__219000098__219000104_fn__219000105_fn__219000106_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_norm_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_norm_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_norm_fn__219000092_A struct{ j2g_header uint64; F_i int64; F_n int32; F_used, F_ts any }

var A_arbace_go_check_types_terms_norm_fn__219000092_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000184__219000188_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_str_iter__219000184__219000188_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_A struct{ j2g_header uint64; F_s__219000185, F_iter__219000184 any }

var A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_fn__219000190_A struct{ j2g_header uint64; F_b__219000187 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_terms_str_iter__219000184__219000188_fn__219000189_fn__219000190_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_subset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_subset_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_subset_QMARK__fn__219000122_A struct{ j2g_header uint64; F_yl any }

var A_arbace_go_check_types_terms_subset_QMARK__fn__219000122_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_superset_of_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_superset_of_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000118_A struct{ j2g_header uint64; F_y any }

var A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000118_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_union_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_union_A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_iface_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_iface_A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A struct{ j2g_header uint64; F_seen any }

var A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_empty_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tset_empty_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_type_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000213__219000217_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_type_str_iter__219000213__219000217_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_A struct{ j2g_header uint64; F_iter__219000213, F_s__219000214 any }

var A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_fn__219000219_A struct{ j2g_header uint64; F_b__219000216 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_type_str_iter__219000213__219000217_fn__219000218_fn__219000219_A_fn_class *jrt.Class



type A_arbace_go_check_types_typed_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typed_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_all_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_all_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_all_fn__219000151_A struct{ j2g_header uint64; F_f any }

var A_arbace_go_check_types_typeset_all_fn__219000151_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_pairs_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_A struct{ j2g_header uint64; F_iter__219000133, F_s__219000134 any }

var A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_fn__219000139_A struct{ j2g_header uint64; F_b__219000136 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_typeset_pairs_iter__219000133__219000137_fn__219000138_fn__219000139_A_fn_class *jrt.Class



type A_arbace_go_check_types_uintptr_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_uintptr_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_under_is_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_under_is_A_fn_class *jrt.Class



type A_arbace_go_check_types_under_is_fn__219000157_A struct{ j2g_header uint64; F_f any }

var A_arbace_go_check_types_under_is_fn__219000157_A_fn_class *jrt.Class



type A_arbace_go_check_types_union_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_union_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_unsafe_pointer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_unsafe_pointer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_unsigned_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_unsigned_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_untyped_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_untyped_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_update_info_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_update_info_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_types_valid_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_valid_QMARK__A_fn_class *jrt.Class
