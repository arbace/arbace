//line aot_arbace_go_check_types.ae:1
package aot_arbace_go_check_types

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_const"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_New() *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_types_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_types_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_go_check_types_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_1, A_arbace_go_check_types_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_types_eval219000008_fn__219000009_A_New() *A_arbace_go_check_types_eval219000008_fn__219000009_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_eval219000008_fn__219000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_types_eval219000008_fn__219000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_types_eval219000008_fn__219000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_go_check_types_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_types_A_const_8.GetRawRoot__O(), A_arbace_go_check_types_A_const_9) }






















func A_arbace_go_check_types_fn__219000012_A_New() *A_arbace_go_check_types_fn__219000012_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_A) Invoke_O__O(self any) any { var m__1 any; var fnbody__33 any = A_arbace_go_check_types_fn__219000012_m__219000013_A_New(); var tmp1 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, true, nil); A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class = fncls__32d; tmp1 = fncls__32d } else { tmp1 = fncls__32 }; m__1 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__33, tmp1, nil, 2); var root_34 any =
										A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_38 any = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_14, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_16), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_17, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_19, A_arbace_go_check_types_A_const_20, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_21, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_23, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_25, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_26, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_28, A_arbace_go_check_types_A_const_20, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_29, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_30, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_31, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_32, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_33, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_34), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_35, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_34), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_36, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_37), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_38, A_arbace_go_check_types_A_const_39, A_arbace_go_check_types_A_const_37), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_40, A_arbace_go_check_types_A_const_39, A_arbace_go_check_types_A_const_41), lang.IFn_Cast(m__1).Invoke_O_O__O(A_arbace_go_check_types_A_const_42, A_arbace_go_check_types_A_const_24), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_43, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_16, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_46, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_47, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_48, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_34, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_49, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_37, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_50, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_41, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_51, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_52, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_53, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_18))); if linked_35 == nil { return ifn_36.Invoke_O_O__O(arg_37, arg_38) } else { return linked_35.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_34, arg_37, arg_38) } }
//line :24:1
func A_arbace_go_check_types_fn__219000012_m__219000013_A_New() *A_arbace_go_check_types_fn__219000012_m__219000013_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_m__219000013_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_A) DoInvoke_O_O_O_O__O(self, n__1, size__2, flags__3 any) any { var tmp1 any; var root_20 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_11, size__2, A_arbace_go_check_types_A_const_12, n__1)); var arg_24 any; var root_25 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any; var fnbody__31 any = A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_New(); var tmp2 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, nil); A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class = fncls__30d; tmp2 = fncls__30d } else { tmp2 = fncls__30 }; arg_28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__31, tmp2, nil); var arg_29 any = flags__3; if linked_26 == nil { arg_24 = ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { arg_24 = linked_26.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) }; if linked_21 == nil { tmp1 = ifn_22.Invoke_O_O__O(arg_23, arg_24) } else { tmp1 = linked_21.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_20, arg_23, arg_24) }; return lang.Tuple_Create_O_O__IPersistentVector(n__1, tmp1) }
//line :24:1
func A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_New() *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A) Invoke_O_O__O(self, f__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(f__1, jrt.Boolean_TRUE.Ref()) }













































func A_arbace_go_check_types_kw_alias_A_New() *A_arbace_go_check_types_kw_alias_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_kw_alias_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_go_check_types_kw_alias_A) Ctor() {}
//line :70:1
func (t *A_arbace_go_check_types_kw_alias_A) Invoke_O_O_O_O_O_O_O__O(self, x__0, name__1, pkg__2, pkg_name__3, local__4, actual__5 any) any { var k__7 any; var root_39 any = A_arbace_go_check_types_A_const_54.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_41 lang.IFn; if



	linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = Lit_20; var arg_43 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_21, nil, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.System_IdentityHashCode_O__I(x__0)).Ref(), nil, name__1)).Ref(); if linked_40 == nil { k__7 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { k__7 = linked_40.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) };
	jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_go_check_types_A_const_55.GetRawRoot__O())).PutIfAbsent_O_O__O(k__7, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_56, actual__5, A_arbace_go_check_types_A_const_12, name__1, A_arbace_go_check_types_A_const_57, pkg__2, A_arbace_go_check_types_A_const_58, pkg_name__3, A_arbace_go_check_types_A_const_59, local__4, A_arbace_go_check_types_A_const_60, x__0))); return k__7 }



func A_arbace_go_check_types_kw_alias_info_A_New() *A_arbace_go_check_types_kw_alias_info_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_kw_alias_info_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_go_check_types_kw_alias_info_A) Ctor() {}
//line :79:1
func (t *A_arbace_go_check_types_kw_alias_info_A) Invoke_O_O__O(self, k__0 any) any { var tmp1 any; var root_44 any = A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = k__0; if linked_45 == nil { tmp1 = ifn_46.Invoke_O__O(arg_47) } else { tmp1 = linked_45.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_44, arg_47) }; if jrt.J2g_Truth(tmp1) { return jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_go_check_types_A_const_55.GetRawRoot__O())).Get_O__O(k__0) } else { return nil } }

func A_arbace_go_check_types_canon_kw_A_New() *A_arbace_go_check_types_canon_kw_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_canon_kw_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_go_check_types_canon_kw_A) Ctor() {}
//line :81:1
func (t *A_arbace_go_check_types_canon_kw_A) Invoke_O_O__O(self, t__0 any) any { var G__219000020__2_ any = t__0; switch


	lang.Util_Hash_O__I_NoInit(G__219000020__2_) >> 1 & 1 { case 0: if any(G__219000020__2_) == any(A_arbace_go_check_types_A_const_52) { return A_arbace_go_check_types_A_const_26 }; case 1: if any(G__219000020__2_) == any(A_arbace_go_check_types_A_const_53) { return A_arbace_go_check_types_A_const_21 }; default:}; var tmp1 any; var root_49 any =


	A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = t__0; if linked_50 == nil { tmp1 = ifn_51.Invoke_O__O(arg_52) } else { tmp1 = linked_50.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_49, arg_52) }; if jrt.J2g_Truth(tmp1) { var temp__1927000408__auto____3 any; var root_53 any = A_arbace_go_check_types_A_const_62.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, A_arbace_go_check_types_kw_alias_info_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = t__0; if linked_54 == nil { temp__1927000408__auto____3 = ifn_55.Invoke_O__O(arg_56) } else { temp__1927000408__auto____3 = linked_54.(*A_arbace_go_check_types_kw_alias_info_A).Invoke_O_O__O(root_53, arg_56) }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var a__4 any = temp__1927000408__auto____3; var root_57 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, A_arbace_go_check_types_canon_kw_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = A_arbace_go_check_types_A_const_56.Invoke_O__O(a__4); if linked_58 == nil { return ifn_59.Invoke_O__O(arg_60) } else { return linked_58.(*A_arbace_go_check_types_canon_kw_A).Invoke_O_O__O(root_57, arg_60) } } else { return t__0 } } else { return t__0 } }



func A_arbace_go_check_types_map_same_A_New() *A_arbace_go_check_types_map_same_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_map_same_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_go_check_types_map_same_A) Ctor() {}
//line :91:1
func (t *A_arbace_go_check_types_map_same_A) Invoke_O_O_O__O(self, f__0, v__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(v__1); var i__4 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, int64(n__3)) { var x__5 any = lang.RT_Nth_O_I__O_NoInit(v__1, lang.RT_IntCast_J__I_NoInit(i__4)); var c__6 any = lang.IFn_Cast(f__0).Invoke_O__O(x__5)

		if lang.Util_Identical_O_O__Z_NoInit(x__5, c__6) {
			i__4 = lang.Numbers_Inc_J__J_NoInit(i__4); continue L1 } else {
				var root_61 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any; var root_67 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any; var root_72 any = A_arbace_go_check_types_A_const_64.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = v__1; var arg_76 any = A_arbace_go_check_types_A_const_44; var arg_77 any = jrt.Long_ValueOf_J__Long_NoInit(i__4).Ref(); if linked_73 == nil { arg_70 = ifn_74.Invoke_O_O_O__O(arg_75, arg_76, arg_77) } else { arg_70 = linked_73.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_72, arg_75, arg_76, arg_77) }; var arg_71 any = c__6; if linked_68 == nil { arg_64 = ifn_69.Invoke_O_O__O(arg_70, arg_71) } else { arg_64 = linked_68.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_67, arg_70, arg_71) }; var arg_65 any; var root_78 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = f__0; if linked_79 == nil { arg_65 = ifn_80.Invoke_O__O(arg_81) } else { arg_65 = linked_79.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_78, arg_81) }; var arg_66 any; var root_82 any = A_arbace_go_check_types_A_const_64.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = v__1; var arg_86 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(i__4)).Ref(); if linked_83 == nil { arg_66 = ifn_84.Invoke_O_O__O(arg_85, arg_86) } else { arg_66 = linked_83.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O__O(root_82, arg_85, arg_86) }; if linked_62 == nil { return ifn_63.Invoke_O_O_O__O(arg_64, arg_65, arg_66) } else { return linked_62.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_61, arg_64, arg_65, arg_66) } } } else {
//line :96:1
					return v__1 } } }; /*line :91:1*/panic("j2g: unreachable") }











func A_arbace_go_check_types_canon_member_A_New() *A_arbace_go_check_types_canon_member_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_canon_member_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_go_check_types_canon_member_A) Ctor() {}
//line :103:1
func (t *A_arbace_go_check_types_canon_member_A) Invoke_O_O__O(self, m__0 any) any { var ty__2 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(m__0); var c__3 any; var root_87 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, A_arbace_go_check_types_canon_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = ty__2; if linked_88 == nil { c__3 = ifn_89.Invoke_O__O(arg_90) } else { c__3 = linked_88.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_87, arg_90) }; if lang.Util_Identical_O_O__Z_NoInit(ty__2, c__3) { return m__0 } else { var root_91 any = A_arbace_go_check_types_A_const_67.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = m__0; var arg_95 any = A_arbace_go_check_types_A_const_65; var arg_96 any = c__3; if linked_92 == nil { return ifn_93.Invoke_O_O_O__O(arg_94, arg_95, arg_96) } else { return linked_92.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_91, arg_94, arg_95, arg_96) } } }

func A_arbace_go_check_types_canon_vec_A_New() *A_arbace_go_check_types_canon_vec_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_canon_vec_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_go_check_types_canon_vec_A) Ctor() {}
//line :105:1
func (t *A_arbace_go_check_types_canon_vec_A) Invoke_O_O__O(self, t__0 any) any { var re__2 any; var fnbody__103 any = A_arbace_go_check_types_canon_vec_re__219000024_A_New_O(t__0); var tmp1 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_go_check_types_canon_vec_re__219000024_A_fn_class; if
										fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__103); A_arbace_go_check_types_canon_vec_re__219000024_A_fn_class = fncls__102d; tmp1 = fncls__102d } else { tmp1 = fncls__102 }; re__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__103, tmp1, nil); var G__219000026__3_ any = /*line :105:1*/lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)); switch

	lang.Util_Hash_O__I_NoInit(G__219000026__3_) >> 5 & 31 { case 0: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_69) { var xs__4 any; var root_105 any = A_arbace_go_check_types_A_const_64.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_107 lang.IFn











		if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = t__0; var arg_109 any = A_arbace_go_check_types_A_const_15; if linked_106 == nil { xs__4 = ifn_107.Invoke_O_O__O(arg_108, arg_109) } else { xs__4 = linked_106.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O__O(root_105, arg_108, arg_109) }
//line :107:1
		var c__5 any; var root_110 any = A_arbace_go_check_types_A_const_70.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, A_arbace_go_check_types_map_same_A_fn_class); var ifn_112 lang.IFn











		if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var arg_114 any = xs__4; if linked_111 == nil { c__5 = ifn_112.Invoke_O_O__O(arg_113, arg_114) } else { c__5 = linked_111.(*A_arbace_go_check_types_map_same_A).Invoke_O_O_O__O(root_110, arg_113, arg_114) }; if lang.Util_Identical_O_O__Z_NoInit(xs__4, c__5) { return t__0 } else { var tmp2 lang.IFn = lang.IFn_Cast(re__2); var tmp3 any; var root_128 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = A_arbace_go_check_types_A_const_75; var arg_132 any = c__5; if linked_129 == nil { tmp3 = ifn_130.Invoke_O_O__O(arg_131, arg_132) } else { tmp3 = linked_129.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_128, arg_131, arg_132) }; return tmp2.Invoke_O__O(tmp3) } }
//line :107:1
	case 1: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_71) { var ms__4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var c__5_2 any; var root_115 any = A_arbace_go_check_types_A_const_70.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, A_arbace_go_check_types_map_same_A_fn_class); var ifn_117 lang.IFn









		if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var arg_119 any = ms__4; if linked_116 == nil { c__5_2 = ifn_117.Invoke_O_O__O(arg_118, arg_119) } else { c__5_2 = linked_116.(*A_arbace_go_check_types_map_same_A).Invoke_O_O_O__O(root_115, arg_118, arg_119) }
		if lang.Util_Identical_O_O__Z_NoInit(ms__4, c__5_2) { return t__0 } else { var tmp4 any = A_arbace_go_check_types_A_const_71; return lang.IFn_Cast(re__2).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, c__5_2, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)))) } }
//line :107:1
	case 3: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_73) { var e__4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var c__5_3 any; var root_120 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, A_arbace_go_check_types_canon_A_fn_class); var ifn_122 lang.IFn

		if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = e__4; if linked_121 == nil { c__5_3 = ifn_122.Invoke_O__O(arg_123) } else { c__5_3 = linked_121.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_120, arg_123) }; if lang.Util_Identical_O_O__Z_NoInit(e__4, c__5_3) { return t__0 } else { return lang.IFn_Cast(re__2).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)), c__5_3)) } }
//line :107:1
	case 4: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_74) { var e__4_2 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var c__5_4 any; var root_124 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, A_arbace_go_check_types_canon_A_fn_class); var ifn_126 lang.IFn


		if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = e__4_2; if linked_125 == nil { c__5_4 = ifn_126.Invoke_O__O(arg_127) } else { c__5_4 = linked_125.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_124, arg_127) }; if lang.Util_Identical_O_O__Z_NoInit(e__4_2, c__5_4) { return t__0 } else { var tmp5 any = A_arbace_go_check_types_A_const_74; return lang.IFn_Cast(re__2).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)), c__5_4)) } }
//line :107:1
	case 5: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_76) { return t__0 }; case 8: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_77) { var k__4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var v__5 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var ck__6 any; var root_133 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, A_arbace_go_check_types_canon_A_fn_class); var ifn_135 lang.IFn




		if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = k__4; if linked_134 == nil { ck__6 = ifn_135.Invoke_O__O(arg_136) } else { ck__6 = linked_134.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_133, arg_136) }
//line :107:1
		var cv__7 any; var root_137 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, A_arbace_go_check_types_canon_A_fn_class); var ifn_139 lang.IFn




		if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = v__5; if linked_138 == nil { cv__7 = ifn_139.Invoke_O__O(arg_140) } else { cv__7 = linked_138.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_137, arg_140) }
		var tmp6 bool; var and__1927000168__auto____8 bool = lang.Util_Identical_O_O__Z_NoInit(k__4, ck__6); if and__1927000168__auto____8 { tmp6 = lang.Util_Identical_O_O__Z_NoInit(v__5, cv__7) } else { tmp6 = and__1927000168__auto____8 }; if tmp6 { return t__0 } else { return lang.IFn_Cast(re__2).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_77, ck__6, cv__7)) } }
//line :107:1
	case 14: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_78) { var e__4_3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var c__5_5 any; var root_141 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, A_arbace_go_check_types_canon_A_fn_class); var ifn_143 lang.IFn

		if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = e__4_3; if linked_142 == nil { c__5_5 = ifn_143.Invoke_O__O(arg_144) } else { c__5_5 = linked_142.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_141, arg_144) }; if lang.Util_Identical_O_O__Z_NoInit(e__4_3, c__5_5) { return t__0 } else { return lang.IFn_Cast(re__2).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)), c__5_5)) } }
//line :107:1
	case 16: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_79) { var e__4_4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var c__5_6 any; var root_145 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, A_arbace_go_check_types_canon_A_fn_class); var ifn_147 lang.IFn



		if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = e__4_4; if linked_146 == nil { c__5_6 = ifn_147.Invoke_O__O(arg_148) } else { c__5_6 = linked_146.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_145, arg_148) }; if lang.Util_Identical_O_O__Z_NoInit(e__4_4, c__5_6) { return t__0 } else { var tmp7 any = A_arbace_go_check_types_A_const_79; return lang.IFn_Cast(re__2).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp7, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)), c__5_6)) } }
//line :107:1
	case 17: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_80) { return t__0 }; case 27: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_81) { var vec__219000027__4 any = t__0; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000027__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000027__4, lang.RT_IntCast_J__I_NoInit(1), nil); var rs__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000027__4, lang.RT_IntCast_J__I_NoInit(2), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000027__4, lang.RT_IntCast_J__I_NoInit(3), nil); var cps__9 any; var root_149 any = A_arbace_go_check_types_A_const_70.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, A_arbace_go_check_types_map_same_A_fn_class); var ifn_151 lang.IFn; _ = ___5






		if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var arg_153 any = ps__6; if linked_150 == nil { cps__9 = ifn_151.Invoke_O_O__O(arg_152, arg_153) } else { cps__9 = linked_150.(*A_arbace_go_check_types_map_same_A).Invoke_O_O_O__O(root_149, arg_152, arg_153) }
//line :107:1
		var crs__10 any; var root_154 any = A_arbace_go_check_types_A_const_70.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, A_arbace_go_check_types_map_same_A_fn_class); var ifn_156 lang.IFn






		if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var arg_158 any = rs__7; if linked_155 == nil { crs__10 = ifn_156.Invoke_O_O__O(arg_157, arg_158) } else { crs__10 = linked_155.(*A_arbace_go_check_types_map_same_A).Invoke_O_O_O__O(root_154, arg_157, arg_158) }
		var tmp8 bool; var and__1927000168__auto____11 bool = lang.Util_Identical_O_O__Z_NoInit(ps__6, cps__9); if and__1927000168__auto____11 { tmp8 = lang.Util_Identical_O_O__Z_NoInit(rs__7, crs__10) } else { tmp8 = and__1927000168__auto____11 }; if tmp8 { return t__0 } else { return lang.IFn_Cast(re__2).Invoke_O__O(lang.Tuple_Create_O_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_81, cps__9, crs__10, v__8)) } }
//line :107:1
	case 31: if any(G__219000026__3_) == any(A_arbace_go_check_types_A_const_82) { var fs__4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var c__5_7 any; var root_159 any = A_arbace_go_check_types_A_const_70.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, A_arbace_go_check_types_map_same_A_fn_class); var ifn_161 lang.IFn








		if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var arg_163 any = fs__4; if linked_160 == nil { c__5_7 = ifn_161.Invoke_O_O__O(arg_162, arg_163) } else { c__5_7 = linked_160.(*A_arbace_go_check_types_map_same_A).Invoke_O_O_O__O(root_159, arg_162, arg_163) }; if lang.Util_Identical_O_O__Z_NoInit(fs__4, c__5_7) { return t__0 } else { return lang.IFn_Cast(re__2).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_types_A_const_82, c__5_7)) } }
//line :107:1
	default:}; return t__0 }
//line :106:1
func A_arbace_go_check_types_canon_vec_re__219000024_A_New_O(p0 any) *A_arbace_go_check_types_canon_vec_re__219000024_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_canon_vec_re__219000024_A{}; t.Ctor_O(p0); return t }
//line :106:1
func (t *A_arbace_go_check_types_canon_vec_re__219000024_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :106:1
func (t *A_arbace_go_check_types_canon_vec_re__219000024_A) Invoke_O_O__O(self, c__1 any) any { var root_97 any = A_arbace_go_check_types_A_const_68.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = c__1; var arg_101 any = lang.RT_Meta_O__IPersistentMap_NoInit(t.F_t); if linked_98 == nil { return ifn_99.Invoke_O_O__O(arg_100, arg_101) } else { return linked_98.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_97, arg_100, arg_101) } }















func A_arbace_go_check_types_alias_of_A_New() *A_arbace_go_check_types_alias_of_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alias_of_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_go_check_types_alias_of_A) Ctor() {}
//line :122:1
func (t *A_arbace_go_check_types_alias_of_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_164 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_166 lang.IFn
	if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = t__0; if linked_165 == nil { tmp1 = ifn_166.Invoke_O__O(arg_167) } else { tmp1 = linked_165.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_164, arg_167) }
//line :125:1
	if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_168 any = A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = t__0; if linked_169 == nil { tmp2 = ifn_170.Invoke_O__O(arg_171) } else { tmp2 = linked_169.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_168, arg_171) }; if jrt.J2g_Truth(tmp2) { var root_172 any = A_arbace_go_check_types_A_const_62.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, A_arbace_go_check_types_kw_alias_info_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = t__0; if linked_173 == nil { return ifn_174.Invoke_O__O(arg_175) } else { return linked_173.(*A_arbace_go_check_types_kw_alias_info_A).Invoke_O_O__O(root_172, arg_175) } } else { return nil } } else {
//line :125:1
			var tmp3 any; var root_176 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_178 lang.IFn

			if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = t__0; if linked_177 == nil { tmp3 = ifn_178.Invoke_O__O(arg_179) } else { tmp3 = linked_177.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_176, arg_179) }
//line :125:1
			if jrt.J2g_Truth(tmp3) {

				var tmp4 *lang.Keyword = A_arbace_go_check_types_A_const_85; return tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(t__0)) } else {
//line :125:1
					if A_arbace_go_check_types_A_const_86 != nil { return nil } else { return nil
					}
				}
		}
}
func A_arbace_go_check_types_unalias_A_New() *A_arbace_go_check_types_unalias_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_unalias_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_go_check_types_unalias_A) Ctor() {}
//line :130:1
func (t *A_arbace_go_check_types_unalias_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_180 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = t__0; if linked_181 == nil { and__1927000168__auto____2 = ifn_182.Invoke_O__O(arg_183) } else { and__1927000168__auto____2 = linked_181.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_180, arg_183) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Keyword = A_arbace_go_check_types_A_const_85; tmp1 = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(t__0)) } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_go_check_types_A_const_87.GetRawRoot__O()).Invoke_O_O_O__O(t__0, A_arbace_go_check_types_A_const_88.GetRawRoot__O(), A_arbace_go_check_types_A_const_85) } else {
//line :133:1
			return t__0
		}
}

func A_arbace_go_check_types_canon_A_New() *A_arbace_go_check_types_canon_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_canon_A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_go_check_types_canon_A) Ctor() {}
//line :137:1
func (t *A_arbace_go_check_types_canon_A) Invoke_O_O__O(self, t__0 any) any {




	var tmp1 any; var root_190 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_192 lang.IFn
	if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = t__0; if linked_191 == nil { tmp1 = ifn_192.Invoke_O__O(arg_193) } else { tmp1 = linked_191.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_190, arg_193) }
//line :142:1
	if jrt.J2g_Truth(tmp1) {
		var root_194 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, A_arbace_go_check_types_canon_kw_A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = t__0; if linked_195 == nil { return ifn_196.Invoke_O__O(arg_197) } else { return linked_195.(*A_arbace_go_check_types_canon_kw_A).Invoke_O_O__O(root_194, arg_197) } } else {
//line :142:1
			var tmp2 any; var root_198 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_200 lang.IFn

			if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = t__0; if linked_199 == nil { tmp2 = ifn_200.Invoke_O__O(arg_201) } else { tmp2 = linked_199.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_198, arg_201) }
//line :142:1
			if jrt.J2g_Truth(tmp2) {

				var root_202 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, A_arbace_go_check_types_canon_vec_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any; var root_206 any = A_arbace_go_check_types_A_const_90.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, A_arbace_go_check_types_unalias_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = t__0; if linked_207 == nil { arg_205 = ifn_208.Invoke_O__O(arg_209) } else { arg_205 = linked_207.(*A_arbace_go_check_types_unalias_A).Invoke_O_O__O(root_206, arg_209) }; if linked_203 == nil { return ifn_204.Invoke_O__O(arg_205) } else { return linked_203.(*A_arbace_go_check_types_canon_vec_A).Invoke_O_O__O(root_202, arg_205) } } else {
//line :142:1
					if A_arbace_go_check_types_A_const_86 != nil { return t__0 } else { return nil
					}
				}
		}
}
func A_arbace_go_check_types_same_QMARK__A_New() *A_arbace_go_check_types_same_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_same_QMARK__A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_go_check_types_same_QMARK__A) Ctor() {}
//line :147:1
func (t *A_arbace_go_check_types_same_QMARK__A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(x__0, y__1); if or__1927000174__auto____3 {


	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var cx__4 any; var root_210 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, A_arbace_go_check_types_canon_A_fn_class); var ifn_212 lang.IFn
		if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = x__0; if linked_211 == nil { cx__4 = ifn_212.Invoke_O__O(arg_213) } else { cx__4 = linked_211.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_210, arg_213) }
//line :150:1
		var cy__5 any; var root_214 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, A_arbace_go_check_types_canon_A_fn_class); var ifn_216 lang.IFn
		if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = y__1; if linked_215 == nil { cy__5 = ifn_216.Invoke_O__O(arg_217) } else { cy__5 = linked_215.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_214, arg_217) }
//line :150:1
		var and__1927000168__auto____6 any; var root_218 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_220 lang.IFn

		if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any; var and__1927000168__auto____6_2 bool = lang.Util_Identical_O_O__Z_NoInit(cx__4, x__0); if and__1927000168__auto____6_2 { arg_221 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(cy__5, y__1)).Ref() } else { arg_221 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6_2).Ref() }; if linked_219 == nil { and__1927000168__auto____6 = ifn_220.Invoke_O__O(arg_221) } else { and__1927000168__auto____6 = linked_219.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_218, arg_221) }; if jrt.J2g_Truth(and__1927000168__auto____6) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(cx__4, cy__5)).Ref() } else { return and__1927000168__auto____6 } } }




func A_arbace_go_check_types_next_id_A_New() *A_arbace_go_check_types_next_id_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_next_id_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_types_next_id_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_types_next_id_A) InvokePrim_O__J(self any) int64 { return jrt.Number_Cast(lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(A_arbace_go_check_types_A_const_92.GetRawRoot__O(), Lit_29, false)).LongValue__J() }
//line :157:1
func (t *A_arbace_go_check_types_next_id_A) Invoke_O__O(self any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O__J(self)).Ref() }

func A_arbace_go_check_types_named_QMARK__A_New() *A_arbace_go_check_types_named_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_QMARK__A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_go_check_types_named_QMARK__A) Ctor() {}
//line :159:1
func (t *A_arbace_go_check_types_named_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_222 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = t__0; if linked_223 == nil { and__1927000168__auto____2 = ifn_224.Invoke_O__O(arg_225) } else { and__1927000168__auto____2 = linked_223.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_222, arg_225) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_76; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_tparam_QMARK__A_New() *A_arbace_go_check_types_tparam_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_QMARK__A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_go_check_types_tparam_QMARK__A) Ctor() {}
//line :160:1
func (t *A_arbace_go_check_types_tparam_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_226 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = t__0; if linked_227 == nil { and__1927000168__auto____2 = ifn_228.Invoke_O__O(arg_229) } else { and__1927000168__auto____2 = linked_227.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_226, arg_229) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_80; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_info_A_New() *A_arbace_go_check_types_info_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_info_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_go_check_types_info_A) Ctor() {}
//line :161:1
func (t *A_arbace_go_check_types_info_A) Invoke_O_O__O(self, t__0 any) any { var root_230 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_231 == nil { return ifn_232.Invoke_O__O(arg_233) } else { return linked_231.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_230, arg_233) } }
func A_arbace_go_check_types_update_info_BANG__A_New() *A_arbace_go_check_types_update_info_BANG__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_update_info_BANG__A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_go_check_types_update_info_BANG__A) Ctor() {}
//line :162:1
func (t *A_arbace_go_check_types_update_info_BANG__A) DoInvoke_O_O_O_O__O(self, t__0, f__1, args__2 any) any { var root_234 any = A_arbace_go_check_types_A_const_93.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var arg_238 any; var root_239 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = f__1; var arg_243 any; var root_245 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_246 == nil { arg_243 = ifn_247.Invoke_O__O(arg_248) } else { arg_243 = linked_246.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_245, arg_248) }; var arg_244 any = args__2; if linked_240 == nil { arg_238 = ifn_241.Invoke_O_O_O__O(arg_242, arg_243, arg_244) } else { arg_238 = linked_240.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_239, arg_242, arg_243, arg_244) }; if linked_235 == nil { ifn_236.Invoke_O_O__O(arg_237, arg_238) } else { linked_235.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_234, arg_237, arg_238) }; return t__0 }

func A_arbace_go_check_types_new_named_A_New() *A_arbace_go_check_types_new_named_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_new_named_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_go_check_types_new_named_A) Ctor() {}
//line :164:1
func (t *A_arbace_go_check_types_new_named_A) Invoke_O_O__O(self, data__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_76; var tmp2 any; var root_249 any = A_arbace_go_check_types_A_const_95.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_251 lang.IFn; if


	linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_67.GetRawRoot__O()); var tmp4 any = A_arbace_go_check_types_A_const_96; var tmp5 any; var root_261 any = A_arbace_go_check_types_A_const_97.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_261, A_arbace_go_check_types_next_id_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; if linked_262 == nil { tmp5 = ifn_263.Invoke__O() } else { tmp5 = jrt.Long_ValueOf_J__Long_NoInit(linked_262.(*A_arbace_go_check_types_next_id_A).InvokePrim_O__J(root_261)).Ref() }; arg_252 = tmp3.Invoke_O_O_O_O_O__O(data__0, tmp4, tmp5, A_arbace_go_check_types_A_const_98, lang.PersistentVector_EMPTY.Ref()); if linked_250 == nil { tmp2 = ifn_251.Invoke_O__O(arg_252) } else { tmp2 = linked_250.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_249, arg_252) }; return /*line :164:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }




func A_arbace_go_check_types_new_tparam_A_New() *A_arbace_go_check_types_new_tparam_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_new_tparam_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_go_check_types_new_tparam_A) Ctor() {}
//line :169:1
func (t *A_arbace_go_check_types_new_tparam_A) Invoke_O_O__O(self, data__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_80; var tmp2 any; var root_264 any = A_arbace_go_check_types_A_const_95.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_266 lang.IFn; if


	linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any; var root_268 any = A_arbace_go_check_types_A_const_67.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = data__0; var arg_272 any = A_arbace_go_check_types_A_const_96; var arg_273 any; var root_274 any = A_arbace_go_check_types_A_const_97.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_274, A_arbace_go_check_types_next_id_A_fn_class); var ifn_276 lang.IFn; if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; if linked_275 == nil { arg_273 = ifn_276.Invoke__O() } else { arg_273 = jrt.Long_ValueOf_J__Long_NoInit(linked_275.(*A_arbace_go_check_types_next_id_A).InvokePrim_O__J(root_274)).Ref() }; if linked_269 == nil { arg_267 = ifn_270.Invoke_O_O_O__O(arg_271, arg_272, arg_273) } else { arg_267 = linked_269.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_268, arg_271, arg_272, arg_273) }; if linked_265 == nil { tmp2 = ifn_266.Invoke_O__O(arg_267) } else { tmp2 = linked_265.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_264, arg_267) }; return /*line :169:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }











func A_arbace_go_check_types_named_under_A_New() *A_arbace_go_check_types_named_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_under_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_go_check_types_named_under_A) Ctor() {}
//line :181:1
func (t *A_arbace_go_check_types_named_under_A) Invoke_O_O__O(self, t__0 any) any { { var t__2 any = t__0; var seen__3 any = lang.PersistentHashSet_EMPTY.Ref(); L1: for { var i__4 any; var root_277 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, A_arbace_go_check_types_info_A_fn_class); var ifn_279 lang.IFn

	if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = t__2; if linked_278 == nil { i__4 = ifn_279.Invoke_O__O(arg_280) } else { i__4 = linked_278.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_277, arg_280) }
//line :181:1
	var temp__1927000408__auto____5 any = A_arbace_go_check_types_A_const_100.Invoke_O__O(i__4)


	if jrt.J2g_Truth(temp__1927000408__auto____5) { var u__6 any = temp__1927000408__auto____5; var tmp1 any; var root_281 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_283 lang.IFn
		if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = u__6; if linked_282 == nil { tmp1 = ifn_283.Invoke_O__O(arg_284) } else { tmp1 = linked_282.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_281, arg_284) }; if jrt.J2g_Truth(tmp1) {

			var tmp2 any; var root_285 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = seen__3; var arg_289 any = u__6; if linked_286 == nil { tmp2 = ifn_287.Invoke_O_O__O(arg_288, arg_289) } else { tmp2 = linked_286.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_285, arg_288, arg_289) }; if jrt.J2g_Truth(tmp2) { return A_arbace_go_check_types_A_const_103 } else {

				var tmp3 any; var root_298 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = seen__3; var arg_302 any = t__2; if linked_299 == nil { tmp3 = ifn_300.Invoke_O_O__O(arg_301, arg_302) } else { tmp3 = linked_299.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_298, arg_301, arg_302) }; t__2, seen__3 = u__6, tmp3; continue L1 } } else {
//line :185:1
					return u__6 } } else {





						var tmp4 any; var and__1927000168__auto____6 any = A_arbace_go_check_types_A_const_104.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_290 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = A_arbace_go_check_types_A_const_105.Invoke_O__O(i__4); if linked_291 == nil { and__1927000168__auto____7 = ifn_292.Invoke_O__O(arg_293) } else { and__1927000168__auto____7 = linked_291.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_290, arg_293) }; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp4 = A_arbace_go_check_types_A_const_60.Invoke_O__O(i__4) } else { tmp4 = and__1927000168__auto____7 } } else { tmp4 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp4) {
							lang.IFn_Cast(A_arbace_go_check_types_A_const_104.Get__O()).Invoke_O__O(t__2)
							var tmp5 *lang.Keyword = A_arbace_go_check_types_A_const_100; var tmp6 any; var root_294 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, A_arbace_go_check_types_info_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = t__2; if linked_295 == nil { tmp6 = ifn_296.Invoke_O__O(arg_297) } else { tmp6 = linked_295.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_294, arg_297) }; if jrt.J2g_Truth(tmp5.Invoke_O__O(tmp6)) { t__2, seen__3 = t__2, seen__3; continue L1 } else { return A_arbace_go_check_types_A_const_103 } } else {
//line :191:1
								return A_arbace_go_check_types_A_const_103 } } } }; /*line :181:1*/panic("j2g: unreachable") }














func A_arbace_go_check_types_under_A_New() *A_arbace_go_check_types_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_A{}; t.Ctor(); return t }
//line :196:1
func (t *A_arbace_go_check_types_under_A) Ctor() {}
//line :196:1
func (t *A_arbace_go_check_types_under_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_303 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_305 lang.IFn
	if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = t__0; if linked_304 == nil { tmp1 = ifn_305.Invoke_O__O(arg_306) } else { tmp1 = linked_304.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_303, arg_306) }
//line :199:1
	if jrt.J2g_Truth(tmp1) {
		var root_307 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, A_arbace_go_check_types_canon_kw_A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any = t__0; if linked_308 == nil { return ifn_309.Invoke_O__O(arg_310) } else { return linked_308.(*A_arbace_go_check_types_canon_kw_A).Invoke_O_O__O(root_307, arg_310) } } else {
//line :199:1
			var tmp2 any = A_arbace_go_check_types_A_const_76; if lang.Util_Identical_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))) { var u__2 any; var root_311 any = A_arbace_go_check_types_A_const_106.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, A_arbace_go_check_types_named_under_A_fn_class); var ifn_313 lang.IFn

				if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any = t__0; if linked_312 == nil { u__2 = ifn_313.Invoke_O__O(arg_314) } else { u__2 = linked_312.(*A_arbace_go_check_types_named_under_A).Invoke_O_O__O(root_311, arg_314) }; var tmp3 any; var root_315 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = u__2; if linked_316 == nil { tmp3 = ifn_317.Invoke_O__O(arg_318) } else { tmp3 = linked_316.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_315, arg_318) }; if jrt.J2g_Truth(tmp3) { var root_319 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, A_arbace_go_check_types_canon_kw_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = u__2; if linked_320 == nil { return ifn_321.Invoke_O__O(arg_322) } else { return linked_320.(*A_arbace_go_check_types_canon_kw_A).Invoke_O_O__O(root_319, arg_322) } } else { return u__2 } } else {
//line :199:1
					var tmp4 any = A_arbace_go_check_types_A_const_80; if lang.Util_Identical_O_O__Z_NoInit(tmp4, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))) {


						var root_323 any = A_arbace_go_check_types_A_const_107.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, A_arbace_go_check_types_tparam_iface_A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = t__0; if linked_324 == nil { return ifn_325.Invoke_O__O(arg_326) } else { return linked_324.(*A_arbace_go_check_types_tparam_iface_A).Invoke_O_O__O(root_323, arg_326) } } else {
//line :199:1
							if A_arbace_go_check_types_A_const_86 != nil {



								var root_327 any = A_arbace_go_check_types_A_const_90.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, A_arbace_go_check_types_unalias_A_fn_class); var ifn_329 lang.IFn; if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = t__0; if linked_328 == nil { return ifn_329.Invoke_O__O(arg_330) } else { return linked_328.(*A_arbace_go_check_types_unalias_A).Invoke_O_O__O(root_327, arg_330) } } else {
//line :199:1
									return nil
								}
						}
				}
		}
}


func A_arbace_go_check_types_basic_A_New() *A_arbace_go_check_types_basic_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_basic_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_go_check_types_basic_A) Ctor() {}
//line :207:1
func (t *A_arbace_go_check_types_basic_A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_331 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_331, A_arbace_go_check_types_under_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any = t__0; if linked_332 == nil { u__2 = ifn_333.Invoke_O__O(arg_334) } else { u__2 = linked_332.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_331, arg_334) }; var tmp1 any; var root_335 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_335, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_337 lang.IFn; if linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any = u__2; if linked_336 == nil { tmp1 = ifn_337.Invoke_O__O(arg_338) } else { tmp1 = linked_336.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_335, arg_338) }; if jrt.J2g_Truth(tmp1) { return u__2 } else { return nil } }
func A_arbace_go_check_types_flag_A_New() *A_arbace_go_check_types_flag_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_flag_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_go_check_types_flag_A) Ctor() {}
//line :208:1
func (t *A_arbace_go_check_types_flag_A) Invoke_O_O_O__O(self, t__0, f__1 any) any { var b__3 any; var root_339 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, A_arbace_go_check_types_basic_A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = t__0; if linked_340 == nil { b__3 = ifn_341.Invoke_O__O(arg_342) } else { b__3 = linked_340.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_339, arg_342) }; var tmp1 any; var and__1927000168__auto____4 any = b__3; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_go_check_types_A_const_110.GetRawRoot__O()).Invoke_O__O(b__3), f__1) } else { tmp1 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }
func A_arbace_go_check_types_integer_type_QMARK__A_New() *A_arbace_go_check_types_integer_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_integer_type_QMARK__A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_go_check_types_integer_type_QMARK__A) Ctor() {}
//line :209:1
func (t *A_arbace_go_check_types_integer_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_343 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, A_arbace_go_check_types_flag_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = t__0; var arg_347 any = A_arbace_go_check_types_A_const_18; if linked_344 == nil { return ifn_345.Invoke_O_O__O(arg_346, arg_347) } else { return linked_344.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_343, arg_346, arg_347) } }
func A_arbace_go_check_types_unsigned_QMARK__A_New() *A_arbace_go_check_types_unsigned_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_unsigned_QMARK__A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_go_check_types_unsigned_QMARK__A) Ctor() {}
//line :210:1
func (t *A_arbace_go_check_types_unsigned_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_348 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, A_arbace_go_check_types_flag_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = t__0; var arg_352 any = A_arbace_go_check_types_A_const_27; if linked_349 == nil { return ifn_350.Invoke_O_O__O(arg_351, arg_352) } else { return linked_349.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_348, arg_351, arg_352) } }
func A_arbace_go_check_types_float_type_QMARK__A_New() *A_arbace_go_check_types_float_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_float_type_QMARK__A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_go_check_types_float_type_QMARK__A) Ctor() {}
//line :211:1
func (t *A_arbace_go_check_types_float_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_353 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, A_arbace_go_check_types_flag_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = t__0; var arg_357 any = A_arbace_go_check_types_A_const_34; if linked_354 == nil { return ifn_355.Invoke_O_O__O(arg_356, arg_357) } else { return linked_354.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_353, arg_356, arg_357) } }
func A_arbace_go_check_types_complex_type_QMARK__A_New() *A_arbace_go_check_types_complex_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_complex_type_QMARK__A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_go_check_types_complex_type_QMARK__A) Ctor() {}
//line :212:1
func (t *A_arbace_go_check_types_complex_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_358 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, A_arbace_go_check_types_flag_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = t__0; var arg_362 any = A_arbace_go_check_types_A_const_37; if linked_359 == nil { return ifn_360.Invoke_O_O__O(arg_361, arg_362) } else { return linked_359.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_358, arg_361, arg_362) } }
func A_arbace_go_check_types_numeric_QMARK__A_New() *A_arbace_go_check_types_numeric_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_numeric_QMARK__A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_go_check_types_numeric_QMARK__A) Ctor() {}
//line :213:1
func (t *A_arbace_go_check_types_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_363 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = t__0; if linked_364 == nil { or__1927000174__auto____2 = ifn_365.Invoke_O__O(arg_366) } else { or__1927000174__auto____2 = linked_364.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_363, arg_366) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_367 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = t__0; if linked_368 == nil { or__1927000174__auto____3 = ifn_369.Invoke_O__O(arg_370) } else { or__1927000174__auto____3 = linked_368.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_367, arg_370) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_371 any = A_arbace_go_check_types_A_const_114.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, A_arbace_go_check_types_complex_type_QMARK__A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = t__0; if linked_372 == nil { return ifn_373.Invoke_O__O(arg_374) } else { return linked_372.(*A_arbace_go_check_types_complex_type_QMARK__A).Invoke_O_O__O(root_371, arg_374) } } } }
func A_arbace_go_check_types_string_type_QMARK__A_New() *A_arbace_go_check_types_string_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_string_type_QMARK__A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_go_check_types_string_type_QMARK__A) Ctor() {}
//line :214:1
func (t *A_arbace_go_check_types_string_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_375 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, A_arbace_go_check_types_flag_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = t__0; var arg_379 any = A_arbace_go_check_types_A_const_41; if linked_376 == nil { return ifn_377.Invoke_O_O__O(arg_378, arg_379) } else { return linked_376.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_375, arg_378, arg_379) } }
func A_arbace_go_check_types_boolean_type_QMARK__A_New() *A_arbace_go_check_types_boolean_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_boolean_type_QMARK__A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_go_check_types_boolean_type_QMARK__A) Ctor() {}
//line :215:1
func (t *A_arbace_go_check_types_boolean_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_380 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, A_arbace_go_check_types_flag_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = t__0; var arg_384 any = A_arbace_go_check_types_A_const_16; if linked_381 == nil { return ifn_382.Invoke_O_O__O(arg_383, arg_384) } else { return linked_381.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_380, arg_383, arg_384) } }
func A_arbace_go_check_types_untyped_QMARK__A_New() *A_arbace_go_check_types_untyped_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_untyped_QMARK__A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_go_check_types_untyped_QMARK__A) Ctor() {}
//line :216:1
func (t *A_arbace_go_check_types_untyped_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_385 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = t__0; if linked_386 == nil { and__1927000168__auto____2 = ifn_387.Invoke_O__O(arg_388) } else { and__1927000168__auto____2 = linked_386.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_385, arg_388) }; if jrt.J2g_Truth(and__1927000168__auto____2) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_go_check_types_A_const_110.GetRawRoot__O()).Invoke_O__O(t__0), A_arbace_go_check_types_A_const_45))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_typed_QMARK__A_New() *A_arbace_go_check_types_typed_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typed_QMARK__A{}; t.Ctor(); return t }
//line :217:1
func (t *A_arbace_go_check_types_typed_QMARK__A) Ctor() {}
//line :217:1
func (t *A_arbace_go_check_types_typed_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_389 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any; var root_393 any = A_arbace_go_check_types_A_const_115.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, A_arbace_go_check_types_untyped_QMARK__A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = t__0; if linked_394 == nil { arg_392 = ifn_395.Invoke_O__O(arg_396) } else { arg_392 = linked_394.(*A_arbace_go_check_types_untyped_QMARK__A).Invoke_O_O__O(root_393, arg_396) }; if linked_390 == nil { return ifn_391.Invoke_O__O(arg_392) } else { return linked_390.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_389, arg_392) } }
func A_arbace_go_check_types_const_type_QMARK__A_New() *A_arbace_go_check_types_const_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_const_type_QMARK__A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_go_check_types_const_type_QMARK__A) Ctor() {}
//line :218:1
func (t *A_arbace_go_check_types_const_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var b__2 any; var root_397 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, A_arbace_go_check_types_basic_A_fn_class); var ifn_399 lang.IFn; if


	linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = t__0; if linked_398 == nil { b__2 = ifn_399.Invoke_O__O(arg_400) } else { b__2 = linked_398.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_397, arg_400) }; var and__1927000168__auto____3 any = b__2; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_401 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = lang.IFn_Cast(A_arbace_go_check_types_A_const_116).Invoke_O__O(b__2); if linked_402 == nil { return ifn_403.Invoke_O__O(arg_404) } else { return linked_402.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_401, arg_404) } } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_ordered_QMARK__A_New() *A_arbace_go_check_types_ordered_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ordered_QMARK__A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_go_check_types_ordered_QMARK__A) Ctor() {}
//line :222:1
func (t *A_arbace_go_check_types_ordered_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_405 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = t__0; if linked_406 == nil { or__1927000174__auto____2 = ifn_407.Invoke_O__O(arg_408) } else { or__1927000174__auto____2 = linked_406.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_405, arg_408) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_409 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_411 lang.IFn; if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = t__0; if linked_410 == nil { or__1927000174__auto____3 = ifn_411.Invoke_O__O(arg_412) } else { or__1927000174__auto____3 = linked_410.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_409, arg_412) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_413 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, A_arbace_go_check_types_string_type_QMARK__A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = t__0; if linked_414 == nil { return ifn_415.Invoke_O__O(arg_416) } else { return linked_414.(*A_arbace_go_check_types_string_type_QMARK__A).Invoke_O_O__O(root_413, arg_416) } } } }
func A_arbace_go_check_types_interface_QMARK__A_New() *A_arbace_go_check_types_interface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_interface_QMARK__A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_go_check_types_interface_QMARK__A) Ctor() {}
//line :223:1
func (t *A_arbace_go_check_types_interface_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_417 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, A_arbace_go_check_types_under_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = t__0; if linked_418 == nil { u__2 = ifn_419.Invoke_O__O(arg_420) } else { u__2 = linked_418.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_417, arg_420) }; var and__1927000168__auto____3 any; var root_421 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = u__2; if linked_422 == nil { and__1927000168__auto____3 = ifn_423.Invoke_O__O(arg_424) } else { and__1927000168__auto____3 = linked_422.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_421, arg_424) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_71; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_pointer_QMARK__A_New() *A_arbace_go_check_types_pointer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_pointer_QMARK__A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_go_check_types_pointer_QMARK__A) Ctor() {}
//line :224:1
func (t *A_arbace_go_check_types_pointer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_425 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, A_arbace_go_check_types_under_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = t__0; if linked_426 == nil { u__2 = ifn_427.Invoke_O__O(arg_428) } else { u__2 = linked_426.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_425, arg_428) }; var and__1927000168__auto____3 any; var root_429 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = u__2; if linked_430 == nil { and__1927000168__auto____3 = ifn_431.Invoke_O__O(arg_432) } else { and__1927000168__auto____3 = linked_430.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_429, arg_432) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_73; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_unsafe_pointer_QMARK__A_New() *A_arbace_go_check_types_unsafe_pointer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_unsafe_pointer_QMARK__A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_go_check_types_unsafe_pointer_QMARK__A) Ctor() {}
//line :225:1
func (t *A_arbace_go_check_types_unsafe_pointer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_42; var tmp2 any; var root_433 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, A_arbace_go_check_types_basic_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = t__0; if linked_434 == nil { tmp2 = ifn_435.Invoke_O__O(arg_436) } else { tmp2 = linked_434.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_433, arg_436) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }
func A_arbace_go_check_types_uintptr_QMARK__A_New() *A_arbace_go_check_types_uintptr_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_uintptr_QMARK__A{}; t.Ctor(); return t }
//line :226:1
func (t *A_arbace_go_check_types_uintptr_QMARK__A) Ctor() {}
//line :226:1
func (t *A_arbace_go_check_types_uintptr_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_32; var tmp2 any; var root_437 any = A_arbace_go_check_types_A_const_109.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, A_arbace_go_check_types_basic_A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = t__0; if linked_438 == nil { tmp2 = ifn_439.Invoke_O__O(arg_440) } else { tmp2 = linked_438.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_437, arg_440) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }
func A_arbace_go_check_types_valid_QMARK__A_New() *A_arbace_go_check_types_valid_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_valid_QMARK__A{}; t.Ctor(); return t }
//line :227:1
func (t *A_arbace_go_check_types_valid_QMARK__A) Ctor() {}
//line :227:1
func (t *A_arbace_go_check_types_valid_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_441 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = A_arbace_go_check_types_A_const_103; var arg_445 any = t__0; if linked_442 == nil { return ifn_443.Invoke_O_O__O(arg_444, arg_445) } else { return linked_442.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_441, arg_444, arg_445) } }
func A_arbace_go_check_types_kind_of_A_New() *A_arbace_go_check_types_kind_of_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_kind_of_A{}; t.Ctor(); return t }
//line :228:1
func (t *A_arbace_go_check_types_kind_of_A) Ctor() {}
//line :228:1
func (t *A_arbace_go_check_types_kind_of_A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_446 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, A_arbace_go_check_types_under_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = t__0; if linked_447 == nil { u__2 = ifn_448.Invoke_O__O(arg_449) } else { u__2 = linked_447.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_446, arg_449) }; var tmp1 any; var root_450 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = u__2; if linked_451 == nil { tmp1 = ifn_452.Invoke_O__O(arg_453) } else { tmp1 = linked_451.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_450, arg_453) }; if jrt.J2g_Truth(tmp1) { return u__2 } else { return lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)) } }
func A_arbace_go_check_types_has_name_QMARK__A_New() *A_arbace_go_check_types_has_name_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_name_QMARK__A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_go_check_types_has_name_QMARK__A) Ctor() {}
//line :229:1
func (t *A_arbace_go_check_types_has_name_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_454 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = t__0; if linked_455 == nil { or__1927000174__auto____2 = ifn_456.Invoke_O__O(arg_457) } else { or__1927000174__auto____2 = linked_455.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_454, arg_457) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_458 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = t__0; if linked_459 == nil { or__1927000174__auto____3 = ifn_460.Invoke_O__O(arg_461) } else { or__1927000174__auto____3 = linked_459.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_458, arg_461) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_462 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = t__0; if linked_463 == nil { return ifn_464.Invoke_O__O(arg_465) } else { return linked_463.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_462, arg_465) } } } }
func A_arbace_go_check_types_integer_or_float_QMARK__A_New() *A_arbace_go_check_types_integer_or_float_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_integer_or_float_QMARK__A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_go_check_types_integer_or_float_QMARK__A) Ctor() {}
//line :230:1
func (t *A_arbace_go_check_types_integer_or_float_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_466 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = t__0; if linked_467 == nil { or__1927000174__auto____2 = ifn_468.Invoke_O__O(arg_469) } else { or__1927000174__auto____2 = linked_467.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_466, arg_469) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_470 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = t__0; if linked_471 == nil { return ifn_472.Invoke_O__O(arg_473) } else { return linked_471.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_470, arg_473) } } }



func A_arbace_go_check_types_has_nil_QMARK__A_New() *A_arbace_go_check_types_has_nil_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_nil_QMARK__A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_go_check_types_has_nil_QMARK__A) Ctor() {}
//line :234:1
func (t *A_arbace_go_check_types_has_nil_QMARK__A) Invoke_O_O__O(self, t__0 any) any {



	var tmp1 any; var root_474 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = t__0; if linked_475 == nil { tmp1 = ifn_476.Invoke_O__O(arg_477) } else { tmp1 = linked_475.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_474, arg_477) }; if jrt.J2g_Truth(tmp1) {
		var root_478 any = A_arbace_go_check_types_A_const_120.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, A_arbace_go_check_types_under_is_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = t__0; var arg_482 any; var fnbody__492 any = A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A_New(); var tmp2 *jrt.Class; var fncls__491 *jrt.Class = A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A_fn_class; if fncls__491 == nil { var fncls__491d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, nil); A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A_fn_class = fncls__491d; tmp2 = fncls__491d } else { tmp2 = fncls__491 }; arg_482 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__492, tmp2, nil); if linked_479 == nil { return ifn_480.Invoke_O_O__O(arg_481, arg_482) } else { return linked_479.(*A_arbace_go_check_types_under_is_A).Invoke_O_O_O__O(root_478, arg_481, arg_482) } } else {
//line :238:1
			var u__2 any; var root_493 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, A_arbace_go_check_types_under_A_fn_class); var ifn_495 lang.IFn

			if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = t__0; if linked_494 == nil { u__2 = ifn_495.Invoke_O__O(arg_496) } else { u__2 = linked_494.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_493, arg_496) }
//line :238:1
			var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_42, u__2)


			if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_51, u__2); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var and__1927000168__auto____5 any; var root_497 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_499 lang.IFn
				if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = u__2; if linked_498 == nil { and__1927000168__auto____5 = ifn_499.Invoke_O__O(arg_500) } else { and__1927000168__auto____5 = linked_498.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_497, arg_500) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_501 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = A_arbace_go_check_types_A_const_123; var arg_505 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)); if linked_502 == nil { return ifn_503.Invoke_O_O__O(arg_504, arg_505) } else { return linked_502.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_501, arg_504, arg_505) } } else { return and__1927000168__auto____5 } } } } }
//line :239:1
func A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A_New() *A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A) Ctor() {}
//line :239:1
func (t *A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A) Invoke_O_O__O(self, u__1 any) any { var and__1927000168__auto____2 any; var root_483 any = A_arbace_go_check_types_A_const_121.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = u__1; if linked_484 == nil { and__1927000168__auto____2 = ifn_485.Invoke_O__O(arg_486) } else { and__1927000168__auto____2 = linked_484.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_483, arg_486) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_487 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, A_arbace_go_check_types_has_nil_QMARK__A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = u__1; if linked_488 == nil { return ifn_489.Invoke_O__O(arg_490) } else { return linked_488.(*A_arbace_go_check_types_has_nil_QMARK__A).Invoke_O_O__O(root_487, arg_490) } } else { return and__1927000168__auto____2 } }




func A_arbace_go_check_types_empty_interface_QMARK__A_New() *A_arbace_go_check_types_empty_interface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_empty_interface_QMARK__A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_go_check_types_empty_interface_QMARK__A) Ctor() {}
//line :244:1
func (t *A_arbace_go_check_types_empty_interface_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_506 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, A_arbace_go_check_types_under_A_fn_class); var ifn_508 lang.IFn; if
												linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = t__0; if linked_507 == nil { u__2 = ifn_508.Invoke_O__O(arg_509) } else { u__2 = linked_507.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_506, arg_509) }; var and__1927000168__auto____3 any; var root_510 any = /*line :244:1*/A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_512 lang.IFn; if
												linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = u__2; if linked_511 == nil { and__1927000168__auto____3 = ifn_512.Invoke_O__O(arg_513) } else { and__1927000168__auto____3 = linked_511.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_510, arg_513) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_71; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____4 { var and__1927000168__auto____5 any; var root_514 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_515 == nil { and__1927000168__auto____5 = ifn_516.Invoke_O__O(arg_517) } else { and__1927000168__auto____5 = linked_515.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_514, arg_517) }; if jrt.J2g_Truth(and__1927000168__auto____5) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref() } else { return and__1927000168__auto____5 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_default_type_A_New() *A_arbace_go_check_types_default_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_default_type_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_go_check_types_default_type_A) Ctor() {}
//line :247:1
func (t *A_arbace_go_check_types_default_type_A) Invoke_O_O__O(self, t__0 any) any { var G__219000069__2_ any = t__0; switch


	lang.Util_Hash_O__I_NoInit(G__219000069__2_) >> 19 & 7 { case 0: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_49) { return A_arbace_go_check_types_A_const_38 }; case 1: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_43) { return A_arbace_go_check_types_A_const_14 }; case 3: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_48) { return A_arbace_go_check_types_A_const_35 }; case 5: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_46) { return A_arbace_go_check_types_A_const_25 }; case 6: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_50) { return A_arbace_go_check_types_A_const_40 }; case 7: if any(G__219000069__2_) == any(A_arbace_go_check_types_A_const_47) {
		if jrt.J2g_Truth(A_arbace_go_check_types_A_const_125.Get__O()) { return A_arbace_go_check_types_A_const_53 } else { return A_arbace_go_check_types_A_const_21 } }
//line :250:1
	default:}; return t__0 }




func A_arbace_go_check_types_ignore_tags_A_New() *A_arbace_go_check_types_ignore_tags_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ignore_tags_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_go_check_types_ignore_tags_A) Ctor() {}
//line :255:1
func (t *A_arbace_go_check_types_ignore_tags_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_519 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = t__0; if linked_520 == nil { and__1927000168__auto____2 = ifn_521.Invoke_O__O(arg_522) } else { and__1927000168__auto____2 = linked_520.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_519, arg_522) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_523 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any; var root_527 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any = t__0; if linked_528 == nil { arg_526 = ifn_529.Invoke_O__O(arg_530) } else { arg_526 = linked_528.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_527, arg_530) }; if linked_524 == nil { and__1927000168__auto____3 = ifn_525.Invoke_O__O(arg_526) } else { and__1927000168__auto____3 = linked_524.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_523, arg_526) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_531 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any; var root_535 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = t__0; if linked_536 == nil { arg_534 = ifn_537.Invoke_O__O(arg_538) } else { arg_534 = linked_536.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_535, arg_538) }; if linked_532 == nil { tmp1 = ifn_533.Invoke_O__O(arg_534) } else { tmp1 = linked_532.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_531, arg_534) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var G__219000072__2_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))
		switch lang.Util_Hash_O__I_NoInit(G__219000072__2_) >> 2 & 15 { case 1: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_77) { var tmp2 any = A_arbace_go_check_types_A_const_77; var tmp3 any; var root_540 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_542 lang.IFn




			if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_541 == nil { tmp3 = ifn_542.Invoke_O__O(arg_543) } else { tmp3 = linked_541.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_540, arg_543) }
//line :259:1
			var tmp4 any = tmp3; var tmp5 any; var root_544 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_546 lang.IFn




			if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_545 == nil { tmp5 = ifn_546.Invoke_O__O(arg_547) } else { tmp5 = linked_545.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_544, arg_547) }
//line :259:1
			return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp4, tmp5) }; case 2: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_78) { var tmp6 any = A_arbace_go_check_types_A_const_78; var tmp7 any; var root_548 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_550 lang.IFn


				if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_549 == nil { tmp7 = ifn_550.Invoke_O__O(arg_551) } else { tmp7 = linked_549.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_548, arg_551) }
//line :259:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7) }; case 3: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_74) { var tmp8 any = A_arbace_go_check_types_A_const_74; var tmp9 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp10 any; var root_552 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_554 lang.IFn



					if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_553 == nil { tmp10 = ifn_554.Invoke_O__O(arg_555) } else { tmp10 = linked_553.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_552, arg_555) }
//line :259:1
					return lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp9, tmp10) }; case 6: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_79) { var tmp11 any = A_arbace_go_check_types_A_const_79; var tmp12 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp13 any; var root_570 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_572 lang.IFn





						if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_571 == nil { tmp13 = ifn_572.Invoke_O__O(arg_573) } else { tmp13 = linked_571.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_570, arg_573) }
//line :259:1
						return lang.Tuple_Create_O_O_O__IPersistentVector(tmp11, tmp12, tmp13) }; case 7: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_69) {







							var root_556 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = A_arbace_go_check_types_A_const_127; var arg_560 any; var root_561 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var arg_565 any; var root_566 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = t__0; if linked_567 == nil { arg_565 = ifn_568.Invoke_O__O(arg_569) } else { arg_565 = linked_567.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_566, arg_569) }; if linked_562 == nil { arg_560 = ifn_563.Invoke_O_O__O(arg_564, arg_565) } else { arg_560 = linked_562.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_561, arg_564, arg_565) }; if linked_557 == nil { return ifn_558.Invoke_O_O__O(arg_559, arg_560) } else { return linked_557.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_556, arg_559, arg_560) } }
//line :259:1
		case 9: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_81) { var tmp14 any = A_arbace_go_check_types_A_const_81; var tmp15 any; var root_574 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_576 lang.IFn






			if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var arg_578 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_575 == nil { tmp15 = ifn_576.Invoke_O_O__O(arg_577, arg_578) } else { tmp15 = linked_575.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_574, arg_577, arg_578) }
//line :259:1
			var tmp16 any = tmp15; var tmp17 any; var root_579 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_581 lang.IFn






			if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var arg_583 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_580 == nil { tmp17 = ifn_581.Invoke_O_O__O(arg_582, arg_583) } else { tmp17 = linked_580.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_579, arg_582, arg_583) }
//line :259:1
			return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp14, tmp16, tmp17, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(3))) }; case 11: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_73) { var tmp18 any = A_arbace_go_check_types_A_const_73; var tmp19 any; var root_584 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_586 lang.IFn

				if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_585 == nil { tmp19 = ifn_586.Invoke_O__O(arg_587) } else { tmp19 = linked_585.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_584, arg_587) }
//line :259:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp18, tmp19) }; case 13: if any(G__219000072__2_) == any(A_arbace_go_check_types_A_const_82) { var tmp20 any = A_arbace_go_check_types_A_const_82; var tmp21 any; var root_588 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_590 lang.IFn
					if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any; var fnbody__606 any = A_arbace_go_check_types_ignore_tags_fn__219000073_A_New(); var tmp22 *jrt.Class; var fncls__605 *jrt.Class = A_arbace_go_check_types_ignore_tags_fn__219000073_A_fn_class; if fncls__605 == nil { var fncls__605d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, nil); A_arbace_go_check_types_ignore_tags_fn__219000073_A_fn_class = fncls__605d; tmp22 = fncls__605d } else { tmp22 = fncls__605 }; arg_591 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__606, tmp22, nil); var arg_592 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_589 == nil { tmp21 = ifn_590.Invoke_O_O__O(arg_591, arg_592) } else { tmp21 = linked_589.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_588, arg_591, arg_592) }
//line :259:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp20, tmp21) }; default:}; return t__0 } else {
//line :258:1
						return t__0
					} }
func A_arbace_go_check_types_ignore_tags_fn__219000073_A_New() *A_arbace_go_check_types_ignore_tags_fn__219000073_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ignore_tags_fn__219000073_A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_go_check_types_ignore_tags_fn__219000073_A) Ctor() {}
//line :260:1
func (t *A_arbace_go_check_types_ignore_tags_fn__219000073_A) Invoke_O_O__O(self, p1__219000071_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_67.GetRawRoot__O()); var tmp2 any = A_arbace_go_check_types_A_const_130; var tmp3 any = A_arbace_go_check_types_A_const_65; var tmp4 any; var root_601 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_603 lang.IFn; if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(p1__219000071_SHARP___1); if linked_602 == nil { tmp4 = ifn_603.Invoke_O__O(arg_604) } else { tmp4 = linked_602.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_601, arg_604) }; return tmp1.Invoke_O_O_O_O_O__O(p1__219000071_SHARP___1, tmp2, nil, tmp3, tmp4) }










func A_arbace_go_check_types_identical_ignore_tags_QMARK__A_New() *A_arbace_go_check_types_identical_ignore_tags_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_identical_ignore_tags_QMARK__A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_go_check_types_identical_ignore_tags_QMARK__A) Ctor() {}
//line :271:1
func (t *A_arbace_go_check_types_identical_ignore_tags_QMARK__A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 any; var root_607 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, A_arbace_go_check_types_canon_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any; var root_611 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = x__0; if linked_612 == nil { arg_610 = ifn_613.Invoke_O__O(arg_614) } else { arg_610 = linked_612.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_611, arg_614) }; if linked_608 == nil { tmp1 = ifn_609.Invoke_O__O(arg_610) } else { tmp1 = linked_608.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_607, arg_610) }; var tmp2 any = tmp1; var tmp3 any; var root_615 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, A_arbace_go_check_types_canon_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any; var root_619 any = A_arbace_go_check_types_A_const_126.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = y__1; if linked_620 == nil { arg_618 = ifn_621.Invoke_O__O(arg_622) } else { arg_618 = linked_620.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_619, arg_622) }; if linked_616 == nil { tmp3 = ifn_617.Invoke_O__O(arg_618) } else { tmp3 = linked_616.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_615, arg_618) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() }





func A_arbace_go_check_types_tset_comparable_QMARK__A_New() *A_arbace_go_check_types_tset_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_comparable_QMARK__A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__A) Ctor() {}
//line :277:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__A) Invoke_O_O_O__O(self, ts__0, seen__1 any) any {


	var tmp1 any = A_arbace_go_check_types_A_const_131; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__0)) {
		return A_arbace_go_check_types_A_const_133.Invoke_O__O(ts__0) } else {
//line :280:1
			var and__1927000168__auto____3 any; var root_623 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_625 lang.IFn

			if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__0); if linked_624 == nil { and__1927000168__auto____3 = ifn_625.Invoke_O__O(arg_626) } else { and__1927000168__auto____3 = linked_624.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_623, arg_626) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_627 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_629 lang.IFn; if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any; var fnbody__638 any = A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A_New_O(seen__1); var tmp2 *jrt.Class; var fncls__637 *jrt.Class = A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A_fn_class; if fncls__637 == nil { var fncls__637d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__638); A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A_fn_class = fncls__637d; tmp2 = fncls__637d } else { tmp2 = fncls__637 }; arg_630 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__638, tmp2, nil); var arg_631 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__0); if linked_628 == nil { return ifn_629.Invoke_O_O__O(arg_630, arg_631) } else { return linked_628.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_627, arg_630, arg_631) } } else { return and__1927000168__auto____3 } } }
//line :282:1
func A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A_New_O(p0 any) *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A{}; t.Ctor_O(p0); return t }
//line :282:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A) Ctor_O(c__seen any) { t.F_seen = c__seen }
//line :282:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A) Invoke_O_O__O(self, p__219000077__1 any) any { var vec__219000079__2 any = p__219000077__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000079__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000079__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_632 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_634 lang.IFn; _ = ___3; if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = ty__4; var arg_636 any = t.F_seen; if linked_633 == nil { return ifn_634.Invoke_O_O__O(arg_635, arg_636) } else { return linked_633.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O_O__O(root_632, arg_635, arg_636) } }

func A_arbace_go_check_types_comparable_type_QMARK__A_New() *A_arbace_go_check_types_comparable_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_type_QMARK__A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__A) Ctor() {}
//line :284:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__A) Invoke_O_O_O_O__O(self, t__0, dynamic__1, seen__2 any) any {




	var tmp1 any; var root_639 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = seen__2; var arg_643 any = t__0; if linked_640 == nil { tmp1 = ifn_641.Invoke_O_O__O(arg_642, arg_643) } else { tmp1 = linked_640.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_639, arg_642, arg_643) }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var seen__4 any; var root_644 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_646 lang.IFn

		if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = seen__2; var arg_648 any = t__0; if linked_645 == nil { seen__4 = ifn_646.Invoke_O_O__O(arg_647, arg_648) } else { seen__4 = linked_645.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_644, arg_647, arg_648) }
		var tmp2 any; var root_649 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_651 lang.IFn; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = t__0; if linked_650 == nil { tmp2 = ifn_651.Invoke_O__O(arg_652) } else { tmp2 = linked_650.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_649, arg_652) }; if jrt.J2g_Truth(tmp2) {
			var tmp3 any; var root_653 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any; var root_658 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = t__0; if linked_659 == nil { arg_656 = ifn_660.Invoke_O__O(arg_661) } else { arg_656 = linked_659.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_658, arg_661) }; var arg_657 any = seen__4; if linked_654 == nil { tmp3 = ifn_655.Invoke_O_O__O(arg_656, arg_657) } else { tmp3 = linked_654.(*A_arbace_go_check_types_tset_comparable_QMARK__A).Invoke_O_O_O__O(root_653, arg_656, arg_657) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp3)).Ref() } else {
//line :292:1
				var u__5 any; var root_662 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_662, A_arbace_go_check_types_under_A_fn_class); var ifn_664 lang.IFn

				if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = t__0; if linked_663 == nil { u__5 = ifn_664.Invoke_O__O(arg_665) } else { u__5 = linked_663.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_662, arg_665) }
				var tmp4 any; var root_666 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_668 lang.IFn
				if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any = u__5; if linked_667 == nil { tmp4 = ifn_668.Invoke_O__O(arg_669) } else { tmp4 = linked_667.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_666, arg_669) }
//line :295:1
				if jrt.J2g_Truth(tmp4) {
					var root_670 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = u__5; var arg_674 any = A_arbace_go_check_types_A_const_51; if linked_671 == nil { return ifn_672.Invoke_O_O__O(arg_673, arg_674) } else { return linked_671.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_670, arg_673, arg_674) } } else {
//line :295:1
						if A_arbace_go_check_types_A_const_86 != nil { var G__219000085__6_ any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(0))


							switch lang.Util_Hash_O__I_NoInit(G__219000085__6_) >> 4 & 7 { case 0: if any(G__219000085__6_) == any(A_arbace_go_check_types_A_const_74) {



								var root_676 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(2)); var arg_680 any = dynamic__1; var arg_681 any = seen__4; if linked_677 == nil { return ifn_678.Invoke_O_O_O__O(arg_679, arg_680, arg_681) } else { return linked_677.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_676, arg_679, arg_680, arg_681) } }
//line :298:1
							case 1: if any(G__219000085__6_) == any(A_arbace_go_check_types_A_const_79) { return jrt.Boolean_TRUE.Ref() }; case 3: if any(G__219000085__6_) == any(A_arbace_go_check_types_A_const_71) { var or__1927000174__auto____7 any = dynamic__1

								if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var tmp5 any; var root_682 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any; var root_687 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_689 lang.IFn; if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = u__5; if linked_688 == nil { arg_685 = ifn_689.Invoke_O__O(arg_690) } else { arg_685 = linked_688.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_687, arg_690) }; var arg_686 any = seen__4; if linked_683 == nil { tmp5 = ifn_684.Invoke_O_O__O(arg_685, arg_686) } else { tmp5 = linked_683.(*A_arbace_go_check_types_tset_comparable_QMARK__A).Invoke_O_O_O__O(root_682, arg_685, arg_686) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp5)).Ref() } }
//line :298:1
							case 6: if any(G__219000085__6_) == any(A_arbace_go_check_types_A_const_73) { return jrt.Boolean_TRUE.Ref() }; case 7: if any(G__219000085__6_) == any(A_arbace_go_check_types_A_const_82) {


								var root_691 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any; var fnbody__703 any = A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A_New_O_O(seen__4, dynamic__1); var tmp6 *jrt.Class; var fncls__702 *jrt.Class = A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A_fn_class; if fncls__702 == nil { var fncls__702d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__703); A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A_fn_class = fncls__702d; tmp6 = fncls__702d } else { tmp6 = fncls__702 }; arg_694 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__703, tmp6, nil); var arg_695 any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(1)); if linked_692 == nil { return ifn_693.Invoke_O_O__O(arg_694, arg_695) } else { return linked_692.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_691, arg_694, arg_695) } }
//line :298:1
							default:}; return jrt.Boolean_FALSE.Ref() } else {
//line :295:1
								return nil
							}
					}
			}
	}
}
func A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A{}; t.Ctor_O_O(p0, p1); return t }
//line :301:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A) Ctor_O_O(c__seen, c__dynamic any) { t.F_seen = c__seen; t.F_dynamic = c__dynamic }
//line :301:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A) Invoke_O_O__O(self, p1__219000084_SHARP___1 any) any { var root_696 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(p1__219000084_SHARP___1); var arg_700 any = t.F_dynamic; var arg_701 any = t.F_seen; if linked_697 == nil { return ifn_698.Invoke_O_O_O__O(arg_699, arg_700, arg_701) } else { return linked_697.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_696, arg_699, arg_700, arg_701) } }



func A_arbace_go_check_types_strictly_comparable_QMARK__A_New() *A_arbace_go_check_types_strictly_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_strictly_comparable_QMARK__A{}; t.Ctor(); return t }
//line :305:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Ctor() {}
//line :305:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Invoke_O_O_O__O(self, t__0, seen__1 any) any { var root_704 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_704, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_706 lang.IFn; if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any = t__0; var arg_708 any = jrt.Boolean_FALSE.Ref(); var arg_709 any = seen__1; if linked_705 == nil { return ifn_706.Invoke_O_O_O__O(arg_707, arg_708, arg_709) } else { return linked_705.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_704, arg_707, arg_708, arg_709) } }
//line :305:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_710 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = t__0; var arg_714 any = jrt.Boolean_FALSE.Ref(); var arg_715 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_711 == nil { return ifn_712.Invoke_O_O_O__O(arg_713, arg_714, arg_715) } else { return linked_711.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_710, arg_713, arg_714, arg_715) } }

func A_arbace_go_check_types_incomparable_cause_A_New() *A_arbace_go_check_types_incomparable_cause_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_incomparable_cause_A{}; t.Ctor(); return t }
//line :307:1
func (t *A_arbace_go_check_types_incomparable_cause_A) Ctor() {}
//line :307:1
func (t *A_arbace_go_check_types_incomparable_cause_A) Invoke_O_O__O(self, t__0 any) any { var body_cause__2 *A_arbace_go_check_types_incomparable_cause_cause__219000090_A = A_arbace_go_check_types_incomparable_cause_cause__219000090_A_New(); var cause__2 any; var fnbody__764 any = any(body_cause__2); var tmp1 *jrt.Class; var fncls__763 *jrt.Class = A_arbace_go_check_types_incomparable_cause_cause__219000090_A_fn_class; if fncls__763 == nil { var fncls__763d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, nil); A_arbace_go_check_types_incomparable_cause_cause__219000090_A_fn_class = fncls__763d; tmp1 = fncls__763d } else { tmp1 = fncls__763 }; cause__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__764, tmp1, nil); var or__1927000174__auto____3 any = lang.IFn_Cast(cause__2).Invoke_O_O__O(t__0, lang.PersistentHashSet_EMPTY.Ref()); if




















	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { return Lit_10 } }
//line :311:1
func A_arbace_go_check_types_incomparable_cause_cause__219000090_A_New() *A_arbace_go_check_types_incomparable_cause_cause__219000090_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_incomparable_cause_cause__219000090_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000090_A) Ctor() {}
//line :311:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000090_A) Invoke_O_O_O__O(self, t__1, seen__2 any) any {
	var tmp1 any; var root_716 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = seen__2; var arg_720 any = t__1; if linked_717 == nil { tmp1 = ifn_718.Invoke_O_O__O(arg_719, arg_720) } else { tmp1 = linked_717.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_716, arg_719, arg_720) }; if jrt.J2g_Truth(tmp1) { return nil } else { var seen__3 any; var root_721 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_723 lang.IFn

		if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = seen__2; var arg_725 any = t__1; if linked_722 == nil { seen__3 = ifn_723.Invoke_O_O__O(arg_724, arg_725) } else { seen__3 = linked_722.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_721, arg_724, arg_725) }
		var tmp2 any; var root_726 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_728 lang.IFn; if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = t__1; if linked_727 == nil { tmp2 = ifn_728.Invoke_O__O(arg_729) } else { tmp2 = linked_727.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_726, arg_729) }; if jrt.J2g_Truth(tmp2) {
			var tmp3 any; var root_730 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any; var root_735 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_737 lang.IFn; if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = t__1; if linked_736 == nil { arg_733 = ifn_737.Invoke_O__O(arg_738) } else { arg_733 = linked_736.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_735, arg_738) }; var arg_734 any = seen__3; if linked_731 == nil { tmp3 = ifn_732.Invoke_O_O__O(arg_733, arg_734) } else { tmp3 = linked_731.(*A_arbace_go_check_types_tset_comparable_QMARK__A).Invoke_O_O_O__O(root_730, arg_733, arg_734) }; if jrt.J2g_Truth(tmp3) { return nil } else { return Lit_10 } } else {
//line :315:1
				var u__4 any; var root_739 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, A_arbace_go_check_types_under_A_fn_class); var ifn_741 lang.IFn

				if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any = t__1; if linked_740 == nil { u__4 = ifn_741.Invoke_O__O(arg_742) } else { u__4 = linked_740.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_739, arg_742) }
				var tmp4 any; var root_743 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_745 lang.IFn
				if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = u__4; if linked_744 == nil { tmp4 = ifn_745.Invoke_O__O(arg_746) } else { tmp4 = linked_744.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_743, arg_746) }
//line :318:1
				if jrt.J2g_Truth(tmp4) {
					if lang.Util_Equiv_O_O__Z_NoInit(u__4, A_arbace_go_check_types_A_const_51) { return Lit_10 } else { return nil } } else {
//line :318:1
						if A_arbace_go_check_types_A_const_86 != nil { var G__219000091__5_ any = lang.RT_Nth_O_I__O_NoInit(u__4, lang.RT_IntCast_J__I_NoInit(0))


							switch lang.Util_Hash_O__I_NoInit(G__219000091__5_) >> 4 & 7 { case 0: if any(G__219000091__5_) == any(A_arbace_go_check_types_A_const_74) {




								if jrt.J2g_Truth(lang.IFn_Cast(self).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(u__4, lang.RT_IntCast_J__I_NoInit(2)), seen__3)) { var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_17); var tmp6 any; var root_748 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, A_arbace_go_check_types_type_str_A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = t__1; if linked_749 == nil { tmp6 = ifn_750.Invoke_O__O(arg_751) } else { tmp6 = linked_749.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_748, arg_751) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil)).Ref() } else { return nil } }
//line :321:1
							case 1: if any(G__219000091__5_) == any(A_arbace_go_check_types_A_const_79) { return nil }; case 3: if any(G__219000091__5_) == any(A_arbace_go_check_types_A_const_71) { return nil }; case 6: if any(G__219000091__5_) == any(A_arbace_go_check_types_A_const_73) { return nil }; case 7: if any(G__219000091__5_) == any(A_arbace_go_check_types_A_const_82) {

								var root_752 any = A_arbace_go_check_types_A_const_142.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any; var fnbody__762 any = A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A_New_O_O(self, seen__3); var tmp7 *jrt.Class; var fncls__761 *jrt.Class = A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A_fn_class; if fncls__761 == nil { var fncls__761d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, fnbody__762); A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A_fn_class = fncls__761d; tmp7 = fncls__761d } else { tmp7 = fncls__761 }; arg_755 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__762, tmp7, nil); var arg_756 any = lang.RT_Nth_O_I__O_NoInit(u__4, lang.RT_IntCast_J__I_NoInit(1)); if linked_753 == nil { return ifn_754.Invoke_O_O__O(arg_755, arg_756) } else { return linked_753.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_752, arg_755, arg_756) } }
//line :321:1
							default:}; return Lit_10 } else {
//line :318:1
								return nil
							}
					}
			}
	} }
func A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A{}; t.Ctor_O_O(p0, p1); return t }
//line :323:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A) Ctor_O_O(c__cause, c__seen any) { t.F_cause = c__cause; t.F_seen = c__seen }
//line :323:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A) Invoke_O_O__O(self, fd__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_cause); if jrt.J2g_Truth(tmp1.Invoke_O_O__O(A_arbace_go_check_types_A_const_65.Invoke_O__O(fd__1), t.F_seen)) {
																var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_19, nil, Lit_17); var tmp3 any; var root_757 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, A_arbace_go_check_types_type_str_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(fd__1); if linked_758 == nil { tmp3 = ifn_759.Invoke_O__O(arg_760) } else { tmp3 = linked_758.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_757, arg_760) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref() } else {
//line :323:1
		return nil } }






func A_arbace_go_check_types_comparable_QMARK__A_New() *A_arbace_go_check_types_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_QMARK__A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Ctor() {}
//line :330:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Invoke_O_O_O__O(self, t__0, seen__1 any) any {



	var root_765 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any = t__0; var arg_769 any = jrt.Boolean_TRUE.Ref(); var arg_770 any = seen__1; if linked_766 == nil { return ifn_767.Invoke_O_O_O__O(arg_768, arg_769, arg_770) } else { return linked_766.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_765, arg_768, arg_769, arg_770) } }
//line :330:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Invoke_O_O__O(self, t__0 any) any {


	var root_771 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = t__0; var arg_775 any = jrt.Boolean_TRUE.Ref(); var arg_776 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_772 == nil { return ifn_773.Invoke_O_O_O__O(arg_774, arg_775, arg_776) } else { return linked_772.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_771, arg_774, arg_775, arg_776)
	}
}











func A_arbace_go_check_types_union_QMARK__A_New() *A_arbace_go_check_types_union_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_union_QMARK__A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_go_check_types_union_QMARK__A) Ctor() {}
//line :347:1
func (t *A_arbace_go_check_types_union_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_777 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_779 lang.IFn; if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = t__0; if linked_778 == nil { and__1927000168__auto____2 = ifn_779.Invoke_O__O(arg_780) } else { and__1927000168__auto____2 = linked_778.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_777, arg_780) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_143; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_go_check_types_term_disjoint_QMARK__A_New() *A_arbace_go_check_types_term_disjoint_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_disjoint_QMARK__A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_go_check_types_term_disjoint_QMARK__A) Ctor() {}
//line :349:1
func (t *A_arbace_go_check_types_term_disjoint_QMARK__A) Invoke_O_O_O__O(self, p__219000098__0, p__219000099__1 any) any { var vec__219000100__3 any = p__219000098__0; var xt__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000100__3, lang.RT_IntCast_J__I_NoInit(0), nil); var x__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000100__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__219000103__6 any = p__219000099__1; var yt__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000103__6, lang.RT_IntCast_J__I_NoInit(0), nil); var y__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000103__6, lang.RT_IntCast_J__I_NoInit(1), nil); var root_781 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_783 lang.IFn; if
																linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any; var root_785 any = A_arbace_go_check_types_A_const_144.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any; if jrt.J2g_Truth(yt__7) { var root_790 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, A_arbace_go_check_types_under_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = x__5; if linked_791 == nil { arg_788 = ifn_792.Invoke_O__O(arg_793) } else { arg_788 = linked_791.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_790, arg_793) } } else { arg_788 = x__5 }; var arg_789 any; if jrt.J2g_Truth(xt__4) { var root_794 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, A_arbace_go_check_types_under_A_fn_class); var ifn_796 lang.IFn; if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any = y__8; if linked_795 == nil { arg_789 = ifn_796.Invoke_O__O(arg_797) } else { arg_789 = linked_795.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_794, arg_797) } } else { arg_789 = y__8 }; if linked_786 == nil { arg_784 = ifn_787.Invoke_O_O__O(arg_788, arg_789) } else { arg_784 = linked_786.(*A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_785, arg_788, arg_789) }; if linked_782 == nil { return ifn_783.Invoke_O__O(arg_784) } else { return linked_782.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_781, arg_784) } }

func A_arbace_go_check_types_term_union_A_New() *A_arbace_go_check_types_term_union_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_union_A{}; t.Ctor(); return t }
//line :352:1
func (t *A_arbace_go_check_types_term_union_A) Ctor() {}
//line :352:1
func (t *A_arbace_go_check_types_term_union_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	var tmp1 any; var root_798 any = A_arbace_go_check_types_A_const_145.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_800 lang.IFn
	if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = x__0; var arg_802 any = y__1; if linked_799 == nil { tmp1 = ifn_800.Invoke_O_O__O(arg_801, arg_802) } else { tmp1 = linked_799.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_798, arg_801, arg_802) }
//line :353:1
	if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(x__0, y__1) } else { var tmp2 any; var or__1927000174__auto____3 any; var root_803 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_805 lang.IFn

		if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = x__0; if linked_804 == nil { or__1927000174__auto____3 = ifn_805.Invoke_O__O(arg_806) } else { or__1927000174__auto____3 = linked_804.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_803, arg_806) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_807 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any; var root_811 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_811, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_813 lang.IFn; if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any = y__1; if linked_812 == nil { arg_810 = ifn_813.Invoke_O__O(arg_814) } else { arg_810 = linked_812.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_811, arg_814) }; if linked_808 == nil { tmp2 = ifn_809.Invoke_O__O(arg_810) } else { tmp2 = linked_808.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_807, arg_810) } }
//line :353:1
		if jrt.J2g_Truth(tmp2) { return lang.Tuple_Create_O__IPersistentVector(x__0) } else { if A_arbace_go_check_types_A_const_86 != nil { return lang.Tuple_Create_O__IPersistentVector(y__1) } else { return nil
		}
		}
	}
}
func A_arbace_go_check_types_term_intersect_A_New() *A_arbace_go_check_types_term_intersect_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_intersect_A{}; t.Ctor(); return t }
//line :358:1
func (t *A_arbace_go_check_types_term_intersect_A) Ctor() {}
//line :358:1
func (t *A_arbace_go_check_types_term_intersect_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	var tmp1 any; var root_815 any = A_arbace_go_check_types_A_const_145.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_817 lang.IFn
	if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any = x__0; var arg_819 any = y__1; if linked_816 == nil { tmp1 = ifn_817.Invoke_O_O__O(arg_818, arg_819) } else { tmp1 = linked_816.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_815, arg_818, arg_819) }
//line :359:1
	if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; var or__1927000174__auto____3 any; var root_820 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_822 lang.IFn

		if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any; var root_824 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_824, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_826 lang.IFn; if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = x__0; if linked_825 == nil { arg_823 = ifn_826.Invoke_O__O(arg_827) } else { arg_823 = linked_825.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_824, arg_827) }; if linked_821 == nil { or__1927000174__auto____3 = ifn_822.Invoke_O__O(arg_823) } else { or__1927000174__auto____3 = linked_821.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_820, arg_823) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_828 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = y__1; if linked_829 == nil { tmp2 = ifn_830.Invoke_O__O(arg_831) } else { tmp2 = linked_829.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_828, arg_831) } }
//line :359:1
		if jrt.J2g_Truth(tmp2) { return x__0 } else { if A_arbace_go_check_types_A_const_86 != nil { return y__1 } else { return nil
		}
		}
	}
}
func A_arbace_go_check_types_term_includes_QMARK__A_New() *A_arbace_go_check_types_term_includes_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_includes_QMARK__A{}; t.Ctor(); return t }
//line :364:1
func (t *A_arbace_go_check_types_term_includes_QMARK__A) Ctor() {}
//line :364:1
func (t *A_arbace_go_check_types_term_includes_QMARK__A) Invoke_O_O_O__O(self, p__219000109__0, t__1 any) any { var vec__219000110__3 any = p__219000109__0; var tilde__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000110__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000110__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_832 any = A_arbace_go_check_types_A_const_144.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_834 lang.IFn; if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any = ty__5; var arg_836 any; if jrt.J2g_Truth(tilde__4) { var root_837 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, A_arbace_go_check_types_under_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any = t__1; if linked_838 == nil { arg_836 = ifn_839.Invoke_O__O(arg_840) } else { arg_836 = linked_838.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_837, arg_840) } } else { arg_836 = t__1 }; if linked_833 == nil { return ifn_834.Invoke_O_O__O(arg_835, arg_836) } else { return linked_833.(*A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_832, arg_835, arg_836) } }

func A_arbace_go_check_types_term_subset_QMARK__A_New() *A_arbace_go_check_types_term_subset_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_subset_QMARK__A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_go_check_types_term_subset_QMARK__A) Ctor() {}
//line :366:1
func (t *A_arbace_go_check_types_term_subset_QMARK__A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var and__1927000168__auto____3 any; var root_841 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any; var root_845 any = A_arbace_go_check_types_A_const_145.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_845, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any = x__0; var arg_849 any = y__1; if linked_846 == nil { arg_844 = ifn_847.Invoke_O_O__O(arg_848, arg_849) } else { arg_844 = linked_846.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_845, arg_848, arg_849) }; if linked_842 == nil { and__1927000168__auto____3 = ifn_843.Invoke_O__O(arg_844) } else { and__1927000168__auto____3 = linked_842.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_841, arg_844) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var root_850 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any; var root_854 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_856 lang.IFn; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any = x__0; if linked_855 == nil { arg_853 = ifn_856.Invoke_O__O(arg_857) } else { arg_853 = linked_855.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_854, arg_857) }; if linked_851 == nil { or__1927000174__auto____4 = ifn_852.Invoke_O__O(arg_853) } else { or__1927000174__auto____4 = linked_851.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_850, arg_853) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var root_858 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_858, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_860 lang.IFn; if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any = y__1; if linked_859 == nil { return ifn_860.Invoke_O__O(arg_861) } else { return linked_859.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_858, arg_861) } } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_terms_norm_A_New() *A_arbace_go_check_types_terms_norm_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_norm_A{}; t.Ctor(); return t }
//line :368:1
func (t *A_arbace_go_check_types_terms_norm_A) Ctor() {}
//line :368:1
func (t *A_arbace_go_check_types_terms_norm_A) Invoke_O_O__O(self, ts__0 any) any { { var ts__2 any; var root_862 any = A_arbace_go_check_types_A_const_147.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_862, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_864 lang.IFn


	if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any = ts__0; if linked_863 == nil { ts__2 = ifn_864.Invoke_O__O(arg_865) } else { ts__2 = linked_863.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_862, arg_865) }
//line :368:1
	var n__3 int32 = lang.RT_Count_O__I_NoInit(ts__2); var used__4 any = lang.Numbers_Boolean_array_O__Z1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref()).Ref(); var i__5 int64 = 0; var rl__6 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




		if lang.Util_Equiv_J_J__Z_NoInit(i__5, int64(n__3)) {

			var root_866 any = A_arbace_go_check_types_A_const_68.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any; var root_871 any = A_arbace_go_check_types_A_const_148.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_871, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_873 lang.IFn; if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any = rl__6; if linked_872 == nil { arg_869 = ifn_873.Invoke_O__O(arg_874) } else { arg_869 = linked_872.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_871, arg_874) }; var arg_870 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_149, rl__6)); if linked_867 == nil { return ifn_868.Invoke_O_O__O(arg_869, arg_870) } else { return linked_867.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_866, arg_869, arg_870) } } else {
				if lang.RT_Aget_Z1_I__Z_NoInit(jrt.BooleanArray_Cast(used__4), lang.RT_IntCast_J__I_NoInit(i__5)) {
					i__5, rl__6 = lang.Numbers_Inc_J__J_NoInit(i__5), rl__6; continue L1 } else {
//line :376:1
						var xi__7 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__885 any = A_arbace_go_check_types_terms_norm_fn__219000115_A_New_J_I_O_O(i__5, n__3, used__4, ts__2); var tmp2 *jrt.Class
						var fncls__884 /*line :376:1*/*jrt.Class = A_arbace_go_check_types_terms_norm_fn__219000115_A_fn_class

						if fncls__884 == nil { var fncls__884d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, fnbody__885); A_arbace_go_check_types_terms_norm_fn__219000115_A_fn_class = fncls__884d; tmp2 = fncls__884d } else { tmp2 = fncls__884 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__885, tmp2, nil); xi__7 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()







						var tmp3 int64 = lang.Numbers_Inc_J__J_NoInit(i__5); var tmp4 any; var root_886 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = rl__6; var arg_890 any = xi__7; if linked_887 == nil { tmp4 = ifn_888.Invoke_O_O__O(arg_889, arg_890) } else { tmp4 = linked_887.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_886, arg_889, arg_890) }; i__5, rl__6 = tmp3, tmp4; continue L1 } } } }; /*line :368:1*/panic("j2g: unreachable") }









func A_arbace_go_check_types_terms_norm_fn__219000115_A_New_J_I_O_O(p0 int64, p1 int32, p2, p3 any) *A_arbace_go_check_types_terms_norm_fn__219000115_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_norm_fn__219000115_A{}; t.Ctor_J_I_O_O(p0, p1, p2, p3); return t }
//line :378:1
func (t *A_arbace_go_check_types_terms_norm_fn__219000115_A) Ctor_J_I_O_O(c__i int64, c__n int32, c__used, c__ts any) { t.F_i = c__i; t.F_n = c__n; t.F_used = c__used; t.F_ts = c__ts }
//line :378:1
func (t *A_arbace_go_check_types_terms_norm_fn__219000115_A) Invoke_O__O(self any) any { { var j__1 int64 = lang.Numbers_Inc_J__J_NoInit(t.F_i); var tmp1 any = t.F_ts; var xi__2 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(t.F_i)); L1: for {
											if lang.Util_Equiv_J_J__Z_NoInit(j__1, int64(t.F_n)) { return xi__2 } else { var tmp2 *jrt.BooleanArray = jrt.BooleanArray_Cast(t.F_used); if lang.RT_Aget_Z1_I__Z_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(j__1)) {

		j__1, xi__2 = lang.Numbers_Inc_J__J_NoInit(j__1), xi__2; continue L1 } else {
//line :379:1
			if A_arbace_go_check_types_A_const_86 != nil { var u__3 any; var root_875 any = A_arbace_go_check_types_A_const_150.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, A_arbace_go_check_types_term_union_A_fn_class); var ifn_877 lang.IFn


				if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = xi__2; var tmp3 any = t.F_ts; var arg_879 any = lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(j__1)); if linked_876 == nil { u__3 = ifn_877.Invoke_O_O__O(arg_878, arg_879) } else { u__3 = linked_876.(*A_arbace_go_check_types_term_union_A).Invoke_O_O_O__O(root_875, arg_878, arg_879) }
				if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(u__3))) {
					var tmp4 *jrt.BooleanArray = jrt.BooleanArray_Cast(t.F_used); jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_Aset_Z1_I_Z__Z_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(j__1), jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z())); var tmp5 int64 = lang.Numbers_Inc_J__J_NoInit(j__1); var tmp6 any; var root_880 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = u__3; if linked_881 == nil { tmp6 = ifn_882.Invoke_O__O(arg_883) } else { tmp6 = linked_881.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_880, arg_883) }; j__1, xi__2 = tmp5, tmp6; continue L1 } else {
						j__1, xi__2 = lang.Numbers_Inc_J__J_NoInit(j__1), xi__2; continue L1 } } else {
//line :379:1
							return nil } } } } }; /*line :378:1*/panic("j2g: unreachable") }









func A_arbace_go_check_types_ordered_A_New() *A_arbace_go_check_types_ordered_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ordered_A{}; t.Ctor(); return t }
//line :388:1
func (t *A_arbace_go_check_types_ordered_A) Ctor() {}
//line :388:1
func (t *A_arbace_go_check_types_ordered_A) Invoke_O_O__O(self, ts__0 any) any { var tmp1 *lang.Keyword = A_arbace_go_check_types_A_const_149; var or__1927000174__auto____2 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(ts__0)); if


	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_891 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_893 lang.IFn; if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = ts__0; if linked_892 == nil { return ifn_893.Invoke_O__O(arg_894) } else { return linked_892.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_891, arg_894) } } }

func A_arbace_go_check_types_terms_union_A_New() *A_arbace_go_check_types_terms_union_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_union_A{}; t.Ctor(); return t }
//line :393:1
func (t *A_arbace_go_check_types_terms_union_A) Ctor() {}
//line :393:1
func (t *A_arbace_go_check_types_terms_union_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, x__0); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, y__1) }; if tmp1 { return A_arbace_go_check_types_A_const_131 } else { var root_895 any = A_arbace_go_check_types_A_const_151.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, A_arbace_go_check_types_terms_norm_A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any; var root_899 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_899, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any; var root_904 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, A_arbace_go_check_types_ordered_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = x__0; if linked_905 == nil { arg_902 = ifn_906.Invoke_O__O(arg_907) } else { arg_902 = linked_905.(*A_arbace_go_check_types_ordered_A).Invoke_O_O__O(root_904, arg_907) }; var arg_903 any; var root_908 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, A_arbace_go_check_types_ordered_A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = y__1; if linked_909 == nil { arg_903 = ifn_910.Invoke_O__O(arg_911) } else { arg_903 = linked_909.(*A_arbace_go_check_types_ordered_A).Invoke_O_O__O(root_908, arg_911) }; if linked_900 == nil { arg_898 = ifn_901.Invoke_O_O__O(arg_902, arg_903) } else { arg_898 = linked_900.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_899, arg_902, arg_903) }; if linked_896 == nil { return ifn_897.Invoke_O__O(arg_898) } else { return linked_896.(*A_arbace_go_check_types_terms_norm_A).Invoke_O_O__O(root_895, arg_898) } } }

func A_arbace_go_check_types_terms_intersect_A_New() *A_arbace_go_check_types_terms_intersect_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_A{}; t.Ctor(); return t }
//line :395:1
func (t *A_arbace_go_check_types_terms_intersect_A) Ctor() {}
//line :395:1
func (t *A_arbace_go_check_types_terms_intersect_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, x__0) { return y__1 } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, y__1) { return x__0 } else { var tmp1 any; var or__1927000174__auto____3 any; var root_912 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_912, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_914 lang.IFn


		if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any = x__0; if linked_913 == nil { or__1927000174__auto____3 = ifn_914.Invoke_O__O(arg_915) } else { or__1927000174__auto____3 = linked_913.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_912, arg_915) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_916 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any = y__1; if linked_917 == nil { tmp1 = ifn_918.Invoke_O__O(arg_919) } else { tmp1 = linked_917.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_916, arg_919) } }
//line :396:1
		if jrt.J2g_Truth(tmp1) { return lang.PersistentHashSet_EMPTY.Ref() } else { if A_arbace_go_check_types_A_const_86 != nil {



			var root_920 any = A_arbace_go_check_types_A_const_151.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, A_arbace_go_check_types_terms_norm_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any; var iter__1927001039__auto____3 any; var fnbody__1032 any = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A_New_O(y__1); var tmp2 *jrt.Class; var fncls__1031 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A_fn_class; if fncls__1031 == nil { var fncls__1031d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__1032); A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A_fn_class = fncls__1031d; tmp2 = fncls__1031d } else { tmp2 = fncls__1031 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1032, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_1033 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, A_arbace_go_check_types_ordered_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any = x__0; if linked_1034 == nil { tmp4 = ifn_1035.Invoke_O__O(arg_1036) } else { tmp4 = linked_1034.(*A_arbace_go_check_types_ordered_A).Invoke_O_O__O(root_1033, arg_1036) }; arg_923 = tmp3.Invoke_O__O(tmp4); if linked_921 == nil { return ifn_922.Invoke_O__O(arg_923) } else { return linked_921.(*A_arbace_go_check_types_terms_norm_A).Invoke_O_O__O(root_920, arg_923) } } else {
//line :396:1
				return nil
			}
		}
	} } }
func A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A_New_O(p0 any) *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A{}; t.Ctor_O(p0); return t }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A) Ctor_O(c__y any) { t.F_y = c__y }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A) Invoke_O_O__O(self, s__219000121__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1030 any = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A_New_O_O_O(self, s__219000121__1, t.F_y); var tmp2 *jrt.Class; var fncls__1029 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A_fn_class; if fncls__1029 == nil { var fncls__1029d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__1030); A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A_fn_class = fncls__1029d; tmp2 = fncls__1029d } else { tmp2 = fncls__1029 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1030, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :400:1
func A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A) Ctor_O_O_O(c__iter__219000120, c__s__219000121, c__y any) { t.F_iter__219000120 = c__iter__219000120; t.F_s__219000121 = c__s__219000121; t.F_y = c__y }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A) Invoke_O__O(self any) any { { var s__219000121__1 any; var t_ any = t.F_s__219000121; t.F_s__219000121 = nil; s__219000121__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_924 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_926 lang.IFn; if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = s__219000121__1; if linked_925 == nil { temp__1927000414__auto____2 = ifn_926.Invoke_O__O(arg_927) } else { temp__1927000414__auto____2 = linked_925.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_924, arg_927) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var a__4 any; var root_928 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_930 lang.IFn; if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = xs__1927001018__auto____3; if linked_929 == nil { a__4 = ifn_930.Invoke_O__O(arg_931) } else { a__4 = linked_929.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_928, arg_931) }; var iterys__1927001035__auto____5 any; var fnbody__1007 any = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A_New_O(a__4); var tmp1 *jrt.Class; var fncls__1006 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A_fn_class; if fncls__1006 == nil { var fncls__1006d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__1007); A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A_fn_class = fncls__1006d; tmp1 = fncls__1006d } else { tmp1 = fncls__1006 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1007, tmp1, nil); var fs__1927001036__auto____6 any; var root_1008 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1008, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1010 lang.IFn; if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_1012 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, A_arbace_go_check_types_ordered_A_fn_class); var ifn_1014 lang.IFn; if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = t.F_y; if linked_1013 == nil { tmp3 = ifn_1014.Invoke_O__O(arg_1015) } else { tmp3 = linked_1013.(*A_arbace_go_check_types_ordered_A).Invoke_O_O__O(root_1012, arg_1015) }; arg_1011 = tmp2.Invoke_O__O(tmp3); if linked_1009 == nil { fs__1927001036__auto____6 = ifn_1010.Invoke_O__O(arg_1011) } else { fs__1927001036__auto____6 = linked_1009.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1008, arg_1011) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1016 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1018 lang.IFn; if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = fs__1927001036__auto____6; var arg_1020 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000120); var tmp5 any; var root_1021 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1021, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1023 lang.IFn; if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any = s__219000121__1; if linked_1022 == nil { tmp5 = ifn_1023.Invoke_O__O(arg_1024) } else { tmp5 = linked_1022.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1021, arg_1024) }; arg_1020 = tmp4.Invoke_O__O(tmp5); if linked_1017 == nil { return ifn_1018.Invoke_O_O__O(arg_1019, arg_1020) } else { return linked_1017.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1016, arg_1019, arg_1020) } } else { var tmp6 any; var root_1025 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1025, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1027 lang.IFn; if linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any = s__219000121__1; if linked_1026 == nil { tmp6 = ifn_1027.Invoke_O__O(arg_1028) } else { tmp6 = linked_1026.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1025, arg_1028) }; s__219000121__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :400:1
func A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A_New_O(p0 any) *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A{}; t.Ctor_O(p0); return t }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A) Ctor_O(c__a any) { t.F_a = c__a }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A) Invoke_O_O__O(self, s__219000123__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1005 any = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A_New_O_O_O(self, s__219000123__1, t.F_a); var tmp2 *jrt.Class; var fncls__1004 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A_fn_class; if fncls__1004 == nil { var fncls__1004d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__1005); A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A_fn_class = fncls__1004d; tmp2 = fncls__1004d } else { tmp2 = fncls__1004 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1005, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :400:1
func A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A) Ctor_O_O_O(c__iter__219000122, c__s__219000123, c__a any) { t.F_iter__219000122 = c__iter__219000122; t.F_s__219000123 = c__s__219000123; t.F_a = c__a }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A) Invoke_O__O(self any) any { { var s__219000123__1 any; var t_ any = t.F_s__219000123; t.F_s__219000123 = nil; s__219000123__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_932 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = s__219000123__1; if linked_933 == nil { temp__1927000414__auto____2 = ifn_934.Invoke_O__O(arg_935) } else { temp__1927000414__auto____2 = linked_933.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_932, arg_935) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000123__3 any = temp__1927000414__auto____2; var tmp1 any; var root_936 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = s__219000123__3; if linked_937 == nil { tmp1 = ifn_938.Invoke_O__O(arg_939) } else { tmp1 = linked_937.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_936, arg_939) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_940 any = A_arbace_go_check_types_A_const_155.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_942 lang.IFn; if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = s__219000123__3; if linked_941 == nil { c__1927001037__auto____4 = ifn_942.Invoke_O__O(arg_943) } else { c__1927001037__auto____4 = linked_941.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_940, arg_943) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000125__6 any; var root_944 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_946 lang.IFn; if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_945 == nil { b__219000125__6 = ifn_946.Invoke_O__O(arg_947) } else { b__219000125__6 = linked_945.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_944, arg_947) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__959 any = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A_New_O_I_O_O(b__219000125__6, size__1927001038__auto____5, t.F_a, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__958 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A_fn_class; if fncls__958 == nil { var fncls__958d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__959); A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A_fn_class = fncls__958d; tmp3 = fncls__958d } else { tmp3 = fncls__958 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__959, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_960 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_962 lang.IFn; if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any; var root_965 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_967 lang.IFn; if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any = b__219000125__6; if linked_966 == nil { arg_963 = ifn_967.Invoke_O__O(arg_968) } else { arg_963 = linked_966.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_965, arg_968) }; var arg_964 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000122); var tmp5 any; var root_969 any = A_arbace_go_check_types_A_const_161.GetRawRoot__O(); var linked_970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_969, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_971 lang.IFn; if linked_970 == nil { ifn_971 = lang.IFn_Cast(root_969) } else { ifn_971 = nil }; var arg_972 any = s__219000123__3; if linked_970 == nil { tmp5 = ifn_971.Invoke_O__O(arg_972) } else { tmp5 = linked_970.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_969, arg_972) }; arg_964 = tmp4.Invoke_O__O(tmp5); if linked_961 == nil { return ifn_962.Invoke_O_O__O(arg_963, arg_964) } else { return linked_961.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_960, arg_963, arg_964) } } else { var root_973 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_975 lang.IFn; if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any; var root_978 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_978, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_980 lang.IFn; if linked_979 == nil { ifn_980 = lang.IFn_Cast(root_978) } else { ifn_980 = nil }; var arg_981 any = b__219000125__6; if linked_979 == nil { arg_976 = ifn_980.Invoke_O__O(arg_981) } else { arg_976 = linked_979.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_978, arg_981) }; var arg_977 any; if linked_974 == nil { return ifn_975.Invoke_O_O__O(arg_976, arg_977) } else { return linked_974.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_973, arg_976, arg_977) } } } else { var b__4 any; var root_982 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_982, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_984 lang.IFn; if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = s__219000123__3; if linked_983 == nil { b__4 = ifn_984.Invoke_O__O(arg_985) } else { b__4 = linked_983.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_982, arg_985) }; var r__5 any; var root_986 any = A_arbace_go_check_types_A_const_157.GetRawRoot__O(); var linked_987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_986, A_arbace_go_check_types_term_intersect_A_fn_class); var ifn_988 lang.IFn; if linked_987 == nil { ifn_988 = lang.IFn_Cast(root_986) } else { ifn_988 = nil }; var arg_989 any = t.F_a; var arg_990 any = b__4; if linked_987 == nil { r__5 = ifn_988.Invoke_O_O__O(arg_989, arg_990) } else { r__5 = linked_987.(*A_arbace_go_check_types_term_intersect_A).Invoke_O_O_O__O(root_986, arg_989, arg_990) }; if jrt.J2g_Truth(r__5) { var root_991 any = A_arbace_go_check_types_A_const_162.GetRawRoot__O(); var linked_992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_991, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_993 lang.IFn; if linked_992 == nil { ifn_993 = lang.IFn_Cast(root_991) } else { ifn_993 = nil }; var arg_994 any = r__5; var arg_995 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__219000122); var tmp7 any; var root_996 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = s__219000123__3; if linked_997 == nil { tmp7 = ifn_998.Invoke_O__O(arg_999) } else { tmp7 = linked_997.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_996, arg_999) }; arg_995 = tmp6.Invoke_O__O(tmp7); if linked_992 == nil { return ifn_993.Invoke_O_O__O(arg_994, arg_995) } else { return linked_992.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_991, arg_994, arg_995) } } else { var tmp8 any; var root_1000 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1002 lang.IFn; if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = s__219000123__3; if linked_1001 == nil { tmp8 = ifn_1002.Invoke_O__O(arg_1003) } else { tmp8 = linked_1001.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1000, arg_1003) }; s__219000123__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :400:1
func A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A) Ctor_O_I_O_O(c__b__219000125 any, c__size__1927001038__auto__ int32, c__a, c__c__1927001037__auto__ any) { t.F_b__219000125 = c__b__219000125; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_a = c__a; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :400:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A) Invoke_O__O(self any) any { { var i__219000124__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000124__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000124__1)); var r__3 any; var root_948 any = A_arbace_go_check_types_A_const_157.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, A_arbace_go_check_types_term_intersect_A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = t.F_a; var arg_952 any = b__2; if linked_949 == nil { r__3 = ifn_950.Invoke_O_O__O(arg_951, arg_952) } else { r__3 = linked_949.(*A_arbace_go_check_types_term_intersect_A).Invoke_O_O_O__O(root_948, arg_951, arg_952) }; if jrt.J2g_Truth(r__3) { var root_953 any = A_arbace_go_check_types_A_const_158.GetRawRoot__O(); var linked_954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_953, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_955 lang.IFn; if linked_954 == nil { ifn_955 = lang.IFn_Cast(root_953) } else { ifn_955 = nil }; var arg_956 any = t.F_b__219000125; var arg_957 any = r__3; if linked_954 == nil { ifn_955.Invoke_O_O__O(arg_956, arg_957) } else { linked_954.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_953, arg_956, arg_957) }; i__219000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000124__1); continue L1 } else { i__219000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000124__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_types_terms_includes_QMARK__A_New() *A_arbace_go_check_types_terms_includes_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_includes_QMARK__A{}; t.Ctor(); return t }
//line :402:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__A) Ctor() {}
//line :402:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__A) Invoke_O_O_O__O(self, xl__0, t__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, xl__0); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp1 any; var root_1037 any = A_arbace_go_check_types_A_const_142.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any; var fnbody__1048 any = A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A_New_O(t__1); var tmp2 *jrt.Class; var fncls__1047 *jrt.Class = A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A_fn_class; if fncls__1047 == nil { var fncls__1047d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__1048); A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A_fn_class = fncls__1047d; tmp2 = fncls__1047d } else { tmp2 = fncls__1047 }; arg_1040 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1048, tmp2, nil); var arg_1041 any = xl__0; if linked_1038 == nil { tmp1 = ifn_1039.Invoke_O_O__O(arg_1040, arg_1041) } else { tmp1 = linked_1038.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1037, arg_1040, arg_1041) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } }
//line :402:1
func A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A_New_O(p0 any) *A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A{}; t.Ctor_O(p0); return t }
//line :402:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :402:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A) Invoke_O_O__O(self, p1__219000137_SHARP___1 any) any { var root_1042 any = A_arbace_go_check_types_A_const_163.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, A_arbace_go_check_types_term_includes_QMARK__A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = p1__219000137_SHARP___1; var arg_1046 any = t.F_t; if linked_1043 == nil { return ifn_1044.Invoke_O_O__O(arg_1045, arg_1046) } else { return linked_1043.(*A_arbace_go_check_types_term_includes_QMARK__A).Invoke_O_O_O__O(root_1042, arg_1045, arg_1046) } }

func A_arbace_go_check_types_terms_superset_of_QMARK__A_New() *A_arbace_go_check_types_terms_superset_of_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_superset_of_QMARK__A{}; t.Ctor(); return t }
//line :404:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__A) Ctor() {}
//line :404:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__A) Invoke_O_O_O__O(self, xl__0, y__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, xl__0); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp1 any; var root_1049 any = A_arbace_go_check_types_A_const_142.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1049, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1051 lang.IFn; if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any; var fnbody__1060 any = A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A_New_O(y__1); var tmp2 *jrt.Class; var fncls__1059 *jrt.Class = A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A_fn_class; if fncls__1059 == nil { var fncls__1059d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__1060); A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A_fn_class = fncls__1059d; tmp2 = fncls__1059d } else { tmp2 = fncls__1059 }; arg_1052 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1060, tmp2, nil); var arg_1053 any = xl__0; if linked_1050 == nil { tmp1 = ifn_1051.Invoke_O_O__O(arg_1052, arg_1053) } else { tmp1 = linked_1050.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1049, arg_1052, arg_1053) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } }
//line :404:1
func A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A_New_O(p0 any) *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A{}; t.Ctor_O(p0); return t }
//line :404:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A) Ctor_O(c__y any) { t.F_y = c__y }
//line :404:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A) Invoke_O_O__O(self, p1__219000141_SHARP___1 any) any { var root_1054 any = A_arbace_go_check_types_A_const_164.GetRawRoot__O(); var linked_1055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1054, A_arbace_go_check_types_term_subset_QMARK__A_fn_class); var ifn_1056 lang.IFn; if linked_1055 == nil { ifn_1056 = lang.IFn_Cast(root_1054) } else { ifn_1056 = nil }; var arg_1057 any = t.F_y; var arg_1058 any = p1__219000141_SHARP___1; if linked_1055 == nil { return ifn_1056.Invoke_O_O__O(arg_1057, arg_1058) } else { return linked_1055.(*A_arbace_go_check_types_term_subset_QMARK__A).Invoke_O_O_O__O(root_1054, arg_1057, arg_1058) } }

func A_arbace_go_check_types_terms_subset_QMARK__A_New() *A_arbace_go_check_types_terms_subset_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_subset_QMARK__A{}; t.Ctor(); return t }
//line :406:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__A) Ctor() {}
//line :406:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__A) Invoke_O_O_O__O(self, xl__0, yl__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, yl__1) { return jrt.Boolean_TRUE.Ref() } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, xl__0) { return jrt.Boolean_FALSE.Ref() } else { var tmp1 any; var root_1061 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1063 lang.IFn


		if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = yl__1; if linked_1062 == nil { tmp1 = ifn_1063.Invoke_O__O(arg_1064) } else { tmp1 = linked_1062.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1061, arg_1064) }
//line :409:1
		if jrt.J2g_Truth(tmp1) {


			var root_1065 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = xl__0; if linked_1066 == nil { return ifn_1067.Invoke_O__O(arg_1068) } else { return linked_1066.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1065, arg_1068) } } else {
//line :409:1
				if A_arbace_go_check_types_A_const_86 != nil {



					var root_1069 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1071 lang.IFn; if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any; var fnbody__1080 any = A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A_New_O(yl__1); var tmp2 *jrt.Class; var fncls__1079 *jrt.Class = A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A_fn_class; if fncls__1079 == nil { var fncls__1079d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, fnbody__1080); A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A_fn_class = fncls__1079d; tmp2 = fncls__1079d } else { tmp2 = fncls__1079 }; arg_1072 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1080, tmp2, nil); var arg_1073 any = xl__0; if linked_1070 == nil { return ifn_1071.Invoke_O_O__O(arg_1072, arg_1073) } else { return linked_1070.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1069, arg_1072, arg_1073) } } else {
//line :409:1
						return nil
					}
			}
	} } }
func A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A_New_O(p0 any) *A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A{}; t.Ctor_O(p0); return t }
//line :413:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A) Ctor_O(c__yl any) { t.F_yl = c__yl }
//line :413:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A) Invoke_O_O__O(self, p1__219000145_SHARP___1 any) any { var root_1074 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, A_arbace_go_check_types_terms_superset_of_QMARK__A_fn_class); var ifn_1076 lang.IFn; if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = t.F_yl; var arg_1078 any = p1__219000145_SHARP___1; if linked_1075 == nil { return ifn_1076.Invoke_O_O__O(arg_1077, arg_1078) } else { return linked_1075.(*A_arbace_go_check_types_terms_superset_of_QMARK__A).Invoke_O_O_O__O(root_1074, arg_1077, arg_1078) } }

func A_arbace_go_check_types_make_tset_A_New() *A_arbace_go_check_types_make_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_make_tset_A{}; t.Ctor(); return t }
//line :415:1
func (t *A_arbace_go_check_types_make_tset_A) Ctor() {}
//line :415:1
func (t *A_arbace_go_check_types_make_tset_A) Invoke_O_O_O__O(self, terms__0, comparable__1 any) any {


	var tmp1 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, terms__0); if and__1927000168__auto____3 { var root_1081 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = comparable__1; if linked_1082 == nil { tmp1 = ifn_1083.Invoke_O__O(arg_1084) } else { tmp1 = linked_1082.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1081, arg_1084) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any = A_arbace_go_check_types_A_const_132; var tmp3 any = A_arbace_go_check_types_A_const_133; var tmp4 any; var and__1927000168__auto____3_2 any = comparable__1; if jrt.J2g_Truth(and__1927000168__auto____3_2) { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_131, terms__0)).Ref() } else { tmp4 = and__1927000168__auto____3_2 }; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, terms__0, tmp3, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp4)).Ref()))
	} }
func A_arbace_go_check_types_iface_tset_A_New() *A_arbace_go_check_types_iface_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_iface_tset_A{}; t.Ctor(); return t }
//line :420:1
func (t *A_arbace_go_check_types_iface_tset_A) Ctor() {}
//line :420:1
func (t *A_arbace_go_check_types_iface_tset_A) Invoke_O_O__O(self, u__0 any) any { var ts__2 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(2)); var tmp1 any = A_arbace_go_check_types_A_const_98; var tmp2 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp3 any = A_arbace_go_check_types_A_const_132; var tmp4 any; var tmp5 any; var root_1085 any = A_arbace_go_check_types_A_const_166.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1087 lang.IFn; if





	linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any = ts__2; if linked_1086 == nil { tmp5 = ifn_1087.Invoke_O__O(arg_1088) } else { tmp5 = linked_1086.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1085, arg_1088) }; if jrt.J2g_Truth(tmp5) { tmp4 = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__2) } else { tmp4 = A_arbace_go_check_types_A_const_131 }; var tmp6 any = tmp4; var tmp7 any = A_arbace_go_check_types_A_const_133; var tmp8 any; var and__1927000168__auto____3 any; var root_1089 any = /*line :420:1*/A_arbace_go_check_types_A_const_166.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1091 lang.IFn; if






	linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = ts__2; if linked_1090 == nil { and__1927000168__auto____3 = ifn_1091.Invoke_O__O(arg_1092) } else { and__1927000168__auto____3 = linked_1090.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1089, arg_1092) }; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp8 = A_arbace_go_check_types_A_const_133.Invoke_O__O(ts__2) } else { tmp8 = and__1927000168__auto____3 }; return /*line :420:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp6, tmp7, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp8)).Ref())) }








func A_arbace_go_check_types_has_terms_QMARK__A_New() *A_arbace_go_check_types_has_terms_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_terms_QMARK__A{}; t.Ctor(); return t }
//line :429:1
func (t *A_arbace_go_check_types_has_terms_QMARK__A) Ctor() {}
//line :429:1
func (t *A_arbace_go_check_types_has_terms_QMARK__A) Invoke_O_O__O(self, ts__0 any) any { var terms__2 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__0); var and__1927000168__auto____3 any; var root_1093 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1095 lang.IFn; if


	linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = A_arbace_go_check_types_A_const_131; var arg_1097 any = terms__2; if linked_1094 == nil { and__1927000168__auto____3 = ifn_1095.Invoke_O_O__O(arg_1096, arg_1097) } else { and__1927000168__auto____3 = linked_1094.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1093, arg_1096, arg_1097) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1098 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1098, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1100 lang.IFn; if linked_1099 == nil { ifn_1100 = lang.IFn_Cast(root_1098) } else { ifn_1100 = nil }; var arg_1101 any = terms__2; if linked_1099 == nil { return ifn_1100.Invoke_O__O(arg_1101) } else { return linked_1099.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1098, arg_1101) } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_tset_empty_QMARK__A_New() *A_arbace_go_check_types_tset_empty_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_empty_QMARK__A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_go_check_types_tset_empty_QMARK__A) Ctor() {}
//line :434:1
func (t *A_arbace_go_check_types_tset_empty_QMARK__A) Invoke_O_O__O(self, ts__0 any) any { var and__1927000168__auto____2 any; var root_1102 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1102, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1104 lang.IFn; if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any = A_arbace_go_check_types_A_const_131; var arg_1106 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__0); if linked_1103 == nil { and__1927000168__auto____2 = ifn_1104.Invoke_O_O__O(arg_1105, arg_1106) } else { and__1927000168__auto____2 = linked_1103.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1102, arg_1105, arg_1106) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1107 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__0); if linked_1108 == nil { return ifn_1109.Invoke_O__O(arg_1110) } else { return linked_1108.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1107, arg_1110) } } else { return and__1927000168__auto____2 } }

func A_arbace_go_check_types_method_set_iface_QMARK__A_New() *A_arbace_go_check_types_method_set_iface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_method_set_iface_QMARK__A{}; t.Ctor(); return t }
//line :436:1
func (t *A_arbace_go_check_types_method_set_iface_QMARK__A) Ctor() {}
//line :436:1
func (t *A_arbace_go_check_types_method_set_iface_QMARK__A) Invoke_O_O__O(self, u__0 any) any {



	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref()
}
func A_arbace_go_check_types_bound_iface_A_New() *A_arbace_go_check_types_bound_iface_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_bound_iface_A{}; t.Ctor(); return t }
//line :442:1
func (t *A_arbace_go_check_types_bound_iface_A) Ctor() {}
//line :442:1
func (t *A_arbace_go_check_types_bound_iface_A) Invoke_O_O__O(self, b__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any = b__0; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1111 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1113 lang.IFn; if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = A_arbace_go_check_types_A_const_103; var arg_1115 any = b__0; if linked_1112 == nil { tmp1 = ifn_1113.Invoke_O_O__O(arg_1114, arg_1115) } else { tmp1 = linked_1112.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1111, arg_1114, arg_1115) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var u__2 any; var root_1116 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, A_arbace_go_check_types_under_A_fn_class); var ifn_1118 lang.IFn
		if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any = b__0; if linked_1117 == nil { u__2 = ifn_1118.Invoke_O__O(arg_1119) } else { u__2 = linked_1117.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1116, arg_1119) }
		if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_103, u__2) { return nil } else { var tmp2 any; var and__1927000168__auto____3 any; var root_1120 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_1121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1120, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1122 lang.IFn

			if linked_1121 == nil { ifn_1122 = lang.IFn_Cast(root_1120) } else { ifn_1122 = nil }; var arg_1123 any = u__2; if linked_1121 == nil { and__1927000168__auto____3 = ifn_1122.Invoke_O__O(arg_1123) } else { and__1927000168__auto____3 = linked_1121.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1120, arg_1123) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_go_check_types_A_const_71; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :448:1
			if jrt.J2g_Truth(tmp2) { return u__2 } else { var tmp4 any; var root_1124 any = A_arbace_go_check_types_A_const_167.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1124, A_arbace_go_check_types_union_QMARK__A_fn_class); var ifn_1126 lang.IFn


				if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any = u__2; if linked_1125 == nil { tmp4 = ifn_1126.Invoke_O__O(arg_1127) } else { tmp4 = linked_1125.(*A_arbace_go_check_types_union_QMARK__A).Invoke_O_O__O(root_1124, arg_1127) }
//line :448:1
				if jrt.J2g_Truth(tmp4) { var tmp5 any = A_arbace_go_check_types_A_const_71; var tmp6 any = lang.PersistentVector_EMPTY.Ref(); var tmp7 any; var root_1128 any = A_arbace_go_check_types_A_const_168.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1128, A_arbace_go_check_types_make_tset_A_fn_class); var ifn_1130 lang.IFn


					if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); var arg_1132 any = jrt.Boolean_FALSE.Ref(); if linked_1129 == nil { tmp7 = ifn_1130.Invoke_O_O__O(arg_1131, arg_1132) } else { tmp7 = linked_1129.(*A_arbace_go_check_types_make_tset_A).Invoke_O_O_O__O(root_1128, arg_1131, arg_1132) }
//line :448:1
					return lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, tmp7) } else { if A_arbace_go_check_types_A_const_86 != nil { var tmp8 any = A_arbace_go_check_types_A_const_71; var tmp9 any = lang.PersistentVector_EMPTY.Ref(); var tmp10 any; var root_1133 any = A_arbace_go_check_types_A_const_168.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1133, A_arbace_go_check_types_make_tset_A_fn_class); var ifn_1135 lang.IFn



						if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(jrt.Boolean_FALSE.Ref(), b__0))); var arg_1137 any = jrt.Boolean_FALSE.Ref(); if linked_1134 == nil { tmp10 = ifn_1135.Invoke_O_O__O(arg_1136, arg_1137) } else { tmp10 = linked_1134.(*A_arbace_go_check_types_make_tset_A).Invoke_O_O_O__O(root_1133, arg_1136, arg_1137) }
//line :448:1
						return lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp9, tmp10) } else { return nil } } } } } else {
//line :446:1
							return nil
						}
}





func A_arbace_go_check_types_tparam_iface_A_New() *A_arbace_go_check_types_tparam_iface_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_iface_A{}; t.Ctor(); return t }
//line :454:1
func (t *A_arbace_go_check_types_tparam_iface_A) Ctor() {}
//line :454:1
func (t *A_arbace_go_check_types_tparam_iface_A) Invoke_O_O__O(self, tp__0 any) any { var i__2 any; var root_1138 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, A_arbace_go_check_types_info_A_fn_class); var ifn_1140 lang.IFn; if


	linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any = tp__0; if linked_1139 == nil { i__2 = ifn_1140.Invoke_O__O(arg_1141) } else { i__2 = linked_1139.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1138, arg_1141) }; var or__1927000174__auto____3 any = /*line :454:1*/A_arbace_go_check_types_A_const_169.Invoke_O__O(i__2); if



	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000408__auto____4 any; var root_1142 any = A_arbace_go_check_types_A_const_170.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1142, A_arbace_go_check_types_bound_iface_A_fn_class); var ifn_1144 lang.IFn
		if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any = A_arbace_go_check_types_A_const_171.Invoke_O__O(i__2); if linked_1143 == nil { temp__1927000408__auto____4 = ifn_1144.Invoke_O__O(arg_1145) } else { temp__1927000408__auto____4 = linked_1143.(*A_arbace_go_check_types_bound_iface_A).Invoke_O_O__O(root_1142, arg_1145) }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var r__5 any = temp__1927000408__auto____4
			lang.IFn_Cast(A_arbace_go_check_types_A_const_172.GetRawRoot__O()).Invoke_O_O_O_O__O(tp__0, A_arbace_go_check_types_A_const_67.GetRawRoot__O(), A_arbace_go_check_types_A_const_169, r__5)
//line :459:1
			return r__5 } else { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_71, lang.PersistentVector_EMPTY.Ref(), nil) } } }



func A_arbace_go_check_types_tparam_tset_A_New() *A_arbace_go_check_types_tparam_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_tset_A{}; t.Ctor(); return t }
//line :463:1
func (t *A_arbace_go_check_types_tparam_tset_A) Ctor() {}
//line :463:1
func (t *A_arbace_go_check_types_tparam_tset_A) Invoke_O_O__O(self, tp__0 any) any { var root_1153 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_1154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1153, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_1155 lang.IFn; if linked_1154 == nil { ifn_1155 = lang.IFn_Cast(root_1153) } else { ifn_1155 = nil }; var arg_1156 any; var root_1157 any = A_arbace_go_check_types_A_const_107.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, A_arbace_go_check_types_tparam_iface_A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any = tp__0; if linked_1158 == nil { arg_1156 = ifn_1159.Invoke_O__O(arg_1160) } else { arg_1156 = linked_1158.(*A_arbace_go_check_types_tparam_iface_A).Invoke_O_O__O(root_1157, arg_1160) }; if linked_1154 == nil { return ifn_1155.Invoke_O__O(arg_1156) } else { return linked_1154.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_1153, arg_1156) } }

func A_arbace_go_check_types_typeset_pairs_A_New() *A_arbace_go_check_types_typeset_pairs_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_A{}; t.Ctor(); return t }
//line :465:1
func (t *A_arbace_go_check_types_typeset_pairs_A) Ctor() {}
//line :465:1
func (t *A_arbace_go_check_types_typeset_pairs_A) Invoke_O_O__O(self, t__0 any) any {



	var tmp1 any; var root_1161 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = t__0; if linked_1162 == nil { tmp1 = ifn_1163.Invoke_O__O(arg_1164) } else { tmp1 = linked_1162.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_1161, arg_1164) }; if jrt.J2g_Truth(tmp1) { var ts__2 any; var root_1165 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_1167 lang.IFn
		if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any = t__0; if linked_1166 == nil { ts__2 = ifn_1167.Invoke_O__O(arg_1168) } else { ts__2 = linked_1166.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_1165, arg_1168) }
		var tmp2 any; var root_1169 any = A_arbace_go_check_types_A_const_173.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = ts__2; if linked_1170 == nil { tmp2 = ifn_1171.Invoke_O__O(arg_1172) } else { tmp2 = linked_1170.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_1169, arg_1172) }; if jrt.J2g_Truth(tmp2) { var iter__1927001039__auto____3 any; var fnbody__1242 any = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A_New(); var tmp3 *jrt.Class; var fncls__1241 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A_fn_class
			if fncls__1241 == nil { var fncls__1241d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, nil); A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A_fn_class = fncls__1241d; tmp3 = fncls__1241d } else { tmp3 = fncls__1241 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1242, tmp3, nil); return lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__2)) } else {
//line :471:1
				return A_arbace_go_check_types_A_const_174 } } else {
//line :469:1
					var tmp4 any; var root_1243 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_1244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1243, A_arbace_go_check_types_under_A_fn_class); var ifn_1245 lang.IFn




					if linked_1244 == nil { ifn_1245 = lang.IFn_Cast(root_1243) } else { ifn_1245 = nil }; var arg_1246 any = t__0; if linked_1244 == nil { tmp4 = ifn_1245.Invoke_O__O(arg_1246) } else { tmp4 = linked_1244.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1243, arg_1246) }
//line :469:1
					return lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(t__0, tmp4))
				}
}
func A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A_New() *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A{}; t.Ctor(); return t }
//line :472:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A) Ctor() {}
//line :472:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A) Invoke_O_O__O(self, s__219000158__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1240 any = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A_New_O_O(self, s__219000158__1); var tmp2 *jrt.Class; var fncls__1239 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A_fn_class; if fncls__1239 == nil { var fncls__1239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, fnbody__1240); A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A_fn_class = fncls__1239d; tmp2 = fncls__1239d } else { tmp2 = fncls__1239 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1240, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :472:1
func A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A{}; t.Ctor_O_O(p0, p1); return t }
//line :472:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A) Ctor_O_O(c__iter__219000157, c__s__219000158 any) { t.F_iter__219000157 = c__iter__219000157; t.F_s__219000158 = c__s__219000158 }
//line :472:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A) Invoke_O__O(self any) any { { var s__219000158__1 any; var t_ any = t.F_s__219000158; t.F_s__219000158 = nil; s__219000158__1 = t_; for { var temp__1927000414__auto____2 any; var root_1173 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1173, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1175 lang.IFn; if linked_1174 == nil { ifn_1175 = lang.IFn_Cast(root_1173) } else { ifn_1175 = nil }; var arg_1176 any = s__219000158__1; if linked_1174 == nil { temp__1927000414__auto____2 = ifn_1175.Invoke_O__O(arg_1176) } else { temp__1927000414__auto____2 = linked_1174.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1173, arg_1176) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000158__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1177 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1179 lang.IFn; if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any = s__219000158__3; if linked_1178 == nil { tmp1 = ifn_1179.Invoke_O__O(arg_1180) } else { tmp1 = linked_1178.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1177, arg_1180) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1181 any = A_arbace_go_check_types_A_const_155.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = s__219000158__3; if linked_1182 == nil { c__1927001037__auto____4 = ifn_1183.Invoke_O__O(arg_1184) } else { c__1927001037__auto____4 = linked_1182.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1181, arg_1184) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000160__6 any; var root_1185 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1187 lang.IFn; if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1186 == nil { b__219000160__6 = ifn_1187.Invoke_O__O(arg_1188) } else { b__219000160__6 = linked_1186.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1185, arg_1188) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1199 any = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A_New_O_I_O(b__219000160__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1198 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A_fn_class; if fncls__1198 == nil { var fncls__1198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, fnbody__1199); A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A_fn_class = fncls__1198d; tmp3 = fncls__1198d } else { tmp3 = fncls__1198 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1199, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1200 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1202 lang.IFn; if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any; var root_1205 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1205, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1207 lang.IFn; if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = b__219000160__6; if linked_1206 == nil { arg_1203 = ifn_1207.Invoke_O__O(arg_1208) } else { arg_1203 = linked_1206.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1205, arg_1208) }; var arg_1204 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000157); var tmp5 any; var root_1209 any = A_arbace_go_check_types_A_const_161.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any = s__219000158__3; if linked_1210 == nil { tmp5 = ifn_1211.Invoke_O__O(arg_1212) } else { tmp5 = linked_1210.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1209, arg_1212) }; arg_1204 = tmp4.Invoke_O__O(tmp5); if linked_1201 == nil { return ifn_1202.Invoke_O_O__O(arg_1203, arg_1204) } else { return linked_1201.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1200, arg_1203, arg_1204) } } else { var root_1213 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any; var root_1218 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_1219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1218, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1220 lang.IFn; if linked_1219 == nil { ifn_1220 = lang.IFn_Cast(root_1218) } else { ifn_1220 = nil }; var arg_1221 any = b__219000160__6; if linked_1219 == nil { arg_1216 = ifn_1220.Invoke_O__O(arg_1221) } else { arg_1216 = linked_1219.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1218, arg_1221) }; var arg_1217 any; if linked_1214 == nil { return ifn_1215.Invoke_O_O__O(arg_1216, arg_1217) } else { return linked_1214.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1213, arg_1216, arg_1217) } } } else { var vec__219000168__4 any; var root_1222 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_1223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1222, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1224 lang.IFn; if linked_1223 == nil { ifn_1224 = lang.IFn_Cast(root_1222) } else { ifn_1224 = nil }; var arg_1225 any = s__219000158__3; if linked_1223 == nil { vec__219000168__4 = ifn_1224.Invoke_O__O(arg_1225) } else { vec__219000168__4 = linked_1223.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1222, arg_1225) }; var tilde__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000168__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000168__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1226 any = A_arbace_go_check_types_A_const_162.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any; var tmp6 any; if jrt.J2g_Truth(tilde__5) { tmp6 = ty__6 } else { var root_1231 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_1232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1231, A_arbace_go_check_types_under_A_fn_class); var ifn_1233 lang.IFn; if linked_1232 == nil { ifn_1233 = lang.IFn_Cast(root_1231) } else { ifn_1233 = nil }; var arg_1234 any = ty__6; if linked_1232 == nil { tmp6 = ifn_1233.Invoke_O__O(arg_1234) } else { tmp6 = linked_1232.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1231, arg_1234) } }; arg_1229 = lang.Tuple_Create_O_O__IPersistentVector(ty__6, tmp6); var arg_1230 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__219000157); var tmp8 any; var root_1235 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1235, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1237 lang.IFn; if linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; var arg_1238 any = s__219000158__3; if linked_1236 == nil { tmp8 = ifn_1237.Invoke_O__O(arg_1238) } else { tmp8 = linked_1236.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1235, arg_1238) }; arg_1230 = tmp7.Invoke_O__O(tmp8); if linked_1227 == nil { return ifn_1228.Invoke_O_O__O(arg_1229, arg_1230) } else { return linked_1227.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1226, arg_1229, arg_1230) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :472:1
func A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :472:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A) Ctor_O_I_O(c__b__219000160 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000160 = c__b__219000160; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :472:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A) Invoke_O__O(self any) any { { var i__219000159__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000159__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__219000164__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000159__1)); var tilde__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000164__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000164__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1189 any = A_arbace_go_check_types_A_const_158.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1189, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1191 lang.IFn; if linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var arg_1192 any = t.F_b__219000160; var arg_1193 any; var tmp2 any; if jrt.J2g_Truth(tilde__3) { tmp2 = ty__4 } else { var root_1194 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1194, A_arbace_go_check_types_under_A_fn_class); var ifn_1196 lang.IFn; if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any = ty__4; if linked_1195 == nil { tmp2 = ifn_1196.Invoke_O__O(arg_1197) } else { tmp2 = linked_1195.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1194, arg_1197) } }; arg_1193 = lang.Tuple_Create_O_O__IPersistentVector(ty__4, tmp2); if linked_1190 == nil { ifn_1191.Invoke_O_O__O(arg_1192, arg_1193) } else { linked_1190.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1189, arg_1192, arg_1193) }; i__219000159__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000159__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_go_check_types_typeset_all_A_New() *A_arbace_go_check_types_typeset_all_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_all_A{}; t.Ctor(); return t }
//line :476:1
func (t *A_arbace_go_check_types_typeset_all_A) Ctor() {}
//line :476:1
func (t *A_arbace_go_check_types_typeset_all_A) Invoke_O_O_O__O(self, t__0, f__1 any) any {


	var root_1247 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1247, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1249 lang.IFn; if linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any; var fnbody__1253 any = A_arbace_go_check_types_typeset_all_fn__219000175_A_New_O(f__1); var tmp1 *jrt.Class; var fncls__1252 *jrt.Class = A_arbace_go_check_types_typeset_all_fn__219000175_A_fn_class; if fncls__1252 == nil { var fncls__1252d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, fnbody__1253); A_arbace_go_check_types_typeset_all_fn__219000175_A_fn_class = fncls__1252d; tmp1 = fncls__1252d } else { tmp1 = fncls__1252 }; arg_1250 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1253, tmp1, nil); var arg_1251 any; var root_1254 any = A_arbace_go_check_types_A_const_175.GetRawRoot__O(); var linked_1255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1254, A_arbace_go_check_types_typeset_pairs_A_fn_class); var ifn_1256 lang.IFn; if linked_1255 == nil { ifn_1256 = lang.IFn_Cast(root_1254) } else { ifn_1256 = nil }; var arg_1257 any = t__0; if linked_1255 == nil { arg_1251 = ifn_1256.Invoke_O__O(arg_1257) } else { arg_1251 = linked_1255.(*A_arbace_go_check_types_typeset_pairs_A).Invoke_O_O__O(root_1254, arg_1257) }; if linked_1248 == nil { return ifn_1249.Invoke_O_O__O(arg_1250, arg_1251) } else { return linked_1248.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1247, arg_1250, arg_1251) } }
//line :479:1
func A_arbace_go_check_types_typeset_all_fn__219000175_A_New_O(p0 any) *A_arbace_go_check_types_typeset_all_fn__219000175_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_all_fn__219000175_A{}; t.Ctor_O(p0); return t }
//line :479:1
func (t *A_arbace_go_check_types_typeset_all_fn__219000175_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :479:1
func (t *A_arbace_go_check_types_typeset_all_fn__219000175_A) Invoke_O_O__O(self, p__219000174__1 any) any { var vec__219000176__2 any = p__219000174__1; var ty__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000176__2, lang.RT_IntCast_J__I_NoInit(0), nil); var u__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000176__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.IFn_Cast(t.F_f).Invoke_O_O__O(ty__3, u__4) }

func A_arbace_go_check_types_under_is_A_New() *A_arbace_go_check_types_under_is_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_is_A{}; t.Ctor(); return t }
//line :481:1
func (t *A_arbace_go_check_types_under_is_A) Ctor() {}
//line :481:1
func (t *A_arbace_go_check_types_under_is_A) Invoke_O_O_O__O(self, t__0, f__1 any) any {



	var root_1258 any = A_arbace_go_check_types_A_const_176.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1258, A_arbace_go_check_types_typeset_all_A_fn_class); var ifn_1260 lang.IFn; if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var arg_1261 any = t__0; var arg_1262 any; var fnbody__1264 any = A_arbace_go_check_types_under_is_fn__219000181_A_New_O(f__1); var tmp1 *jrt.Class; var fncls__1263 *jrt.Class = A_arbace_go_check_types_under_is_fn__219000181_A_fn_class; if fncls__1263 == nil { var fncls__1263d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, fnbody__1264); A_arbace_go_check_types_under_is_fn__219000181_A_fn_class = fncls__1263d; tmp1 = fncls__1263d } else { tmp1 = fncls__1263 }; arg_1262 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1264, tmp1, nil); if linked_1259 == nil { return ifn_1260.Invoke_O_O__O(arg_1261, arg_1262) } else { return linked_1259.(*A_arbace_go_check_types_typeset_all_A).Invoke_O_O_O__O(root_1258, arg_1261, arg_1262) } }
//line :485:1
func A_arbace_go_check_types_under_is_fn__219000181_A_New_O(p0 any) *A_arbace_go_check_types_under_is_fn__219000181_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_is_fn__219000181_A{}; t.Ctor_O(p0); return t }
//line :485:1
func (t *A_arbace_go_check_types_under_is_fn__219000181_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :485:1
func (t *A_arbace_go_check_types_under_is_fn__219000181_A) Invoke_O_O_O__O(self, ___1, u__2 any) any { return lang.IFn_Cast(t.F_f).Invoke_O__O(u__2) }

func A_arbace_go_check_types_all_basic_A_New() *A_arbace_go_check_types_all_basic_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_basic_A{}; t.Ctor(); return t }
//line :487:1
func (t *A_arbace_go_check_types_all_basic_A) Ctor() {}
//line :487:1
func (t *A_arbace_go_check_types_all_basic_A) Invoke_O_O_O__O(self, t__0, pred__1 any) any {



	var tmp1 any; var root_1265 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = t__0; if linked_1266 == nil { tmp1 = ifn_1267.Invoke_O__O(arg_1268) } else { tmp1 = linked_1266.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_1265, arg_1268) }; if jrt.J2g_Truth(tmp1) { var ts__3 any; var root_1269 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_1271 lang.IFn
		if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = t__0; if linked_1270 == nil { ts__3 = ifn_1271.Invoke_O__O(arg_1272) } else { ts__3 = linked_1270.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_1269, arg_1272) }
		var tmp2 any; var and__1927000168__auto____4 any; var root_1273 any = A_arbace_go_check_types_A_const_173.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_1275 lang.IFn; if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = ts__3; if linked_1274 == nil { and__1927000168__auto____4 = ifn_1275.Invoke_O__O(arg_1276) } else { and__1927000168__auto____4 = linked_1274.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_1273, arg_1276) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1277 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any; var fnbody__1283 any = A_arbace_go_check_types_all_basic_fn__219000185_A_New_O(pred__1); var tmp3 *jrt.Class; var fncls__1282 *jrt.Class = A_arbace_go_check_types_all_basic_fn__219000185_A_fn_class; if fncls__1282 == nil { var fncls__1282d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__1283); A_arbace_go_check_types_all_basic_fn__219000185_A_fn_class = fncls__1282d; tmp3 = fncls__1282d } else { tmp3 = fncls__1282 }; arg_1280 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1283, tmp3, nil); var arg_1281 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__3); if linked_1278 == nil { tmp2 = ifn_1279.Invoke_O_O__O(arg_1280, arg_1281) } else { tmp2 = linked_1278.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1277, arg_1280, arg_1281) } } else { tmp2 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp2)).Ref() } else {
			return lang.IFn_Cast(pred__1).Invoke_O__O(t__0) } }
//line :493:1
func A_arbace_go_check_types_all_basic_fn__219000185_A_New_O(p0 any) *A_arbace_go_check_types_all_basic_fn__219000185_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_basic_fn__219000185_A{}; t.Ctor_O(p0); return t }
//line :493:1
func (t *A_arbace_go_check_types_all_basic_fn__219000185_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :493:1
func (t *A_arbace_go_check_types_all_basic_fn__219000185_A) Invoke_O_O__O(self, p__219000184__1 any) any { var vec__219000186__2 any = p__219000184__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000186__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000186__2, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___3; return lang.IFn_Cast(t.F_pred).Invoke_O__O(ty__4) }


func A_arbace_go_check_types_all_integer_QMARK__A_New() *A_arbace_go_check_types_all_integer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_integer_QMARK__A{}; t.Ctor(); return t }
//line :496:1
func (t *A_arbace_go_check_types_all_integer_QMARK__A) Ctor() {}
//line :496:1
func (t *A_arbace_go_check_types_all_integer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1284 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = t__0; var arg_1288 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); if linked_1285 == nil { return ifn_1286.Invoke_O_O__O(arg_1287, arg_1288) } else { return linked_1285.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1284, arg_1287, arg_1288) } }
func A_arbace_go_check_types_all_unsigned_QMARK__A_New() *A_arbace_go_check_types_all_unsigned_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_unsigned_QMARK__A{}; t.Ctor(); return t }
//line :497:1
func (t *A_arbace_go_check_types_all_unsigned_QMARK__A) Ctor() {}
//line :497:1
func (t *A_arbace_go_check_types_all_unsigned_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1289 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = t__0; var arg_1293 any = A_arbace_go_check_types_A_const_178.GetRawRoot__O(); if linked_1290 == nil { return ifn_1291.Invoke_O_O__O(arg_1292, arg_1293) } else { return linked_1290.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1289, arg_1292, arg_1293) } }
func A_arbace_go_check_types_all_numeric_QMARK__A_New() *A_arbace_go_check_types_all_numeric_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_QMARK__A{}; t.Ctor(); return t }
//line :498:1
func (t *A_arbace_go_check_types_all_numeric_QMARK__A) Ctor() {}
//line :498:1
func (t *A_arbace_go_check_types_all_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1294 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1294, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1296 lang.IFn; if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any = t__0; var arg_1298 any = A_arbace_go_check_types_A_const_179.GetRawRoot__O(); if linked_1295 == nil { return ifn_1296.Invoke_O_O__O(arg_1297, arg_1298) } else { return linked_1295.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1294, arg_1297, arg_1298) } }
func A_arbace_go_check_types_all_string_QMARK__A_New() *A_arbace_go_check_types_all_string_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_string_QMARK__A{}; t.Ctor(); return t }
//line :499:1
func (t *A_arbace_go_check_types_all_string_QMARK__A) Ctor() {}
//line :499:1
func (t *A_arbace_go_check_types_all_string_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1299 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = t__0; var arg_1303 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); if linked_1300 == nil { return ifn_1301.Invoke_O_O__O(arg_1302, arg_1303) } else { return linked_1300.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1299, arg_1302, arg_1303) } }
func A_arbace_go_check_types_all_boolean_QMARK__A_New() *A_arbace_go_check_types_all_boolean_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_boolean_QMARK__A{}; t.Ctor(); return t }
//line :500:1
func (t *A_arbace_go_check_types_all_boolean_QMARK__A) Ctor() {}
//line :500:1
func (t *A_arbace_go_check_types_all_boolean_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1304 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1304, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1306 lang.IFn; if linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any = t__0; var arg_1308 any = A_arbace_go_check_types_A_const_180.GetRawRoot__O(); if linked_1305 == nil { return ifn_1306.Invoke_O_O__O(arg_1307, arg_1308) } else { return linked_1305.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1304, arg_1307, arg_1308) } }
func A_arbace_go_check_types_all_ordered_QMARK__A_New() *A_arbace_go_check_types_all_ordered_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_ordered_QMARK__A{}; t.Ctor(); return t }
//line :501:1
func (t *A_arbace_go_check_types_all_ordered_QMARK__A) Ctor() {}
//line :501:1
func (t *A_arbace_go_check_types_all_ordered_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1309 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1309, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1311 lang.IFn; if linked_1310 == nil { ifn_1311 = lang.IFn_Cast(root_1309) } else { ifn_1311 = nil }; var arg_1312 any = t__0; var arg_1313 any = A_arbace_go_check_types_A_const_181.GetRawRoot__O(); if linked_1310 == nil { return ifn_1311.Invoke_O_O__O(arg_1312, arg_1313) } else { return linked_1310.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1309, arg_1312, arg_1313) } }
func A_arbace_go_check_types_all_numeric_or_string_QMARK__A_New() *A_arbace_go_check_types_all_numeric_or_string_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_or_string_QMARK__A{}; t.Ctor(); return t }
//line :502:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__A) Ctor() {}
//line :502:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1314 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1314, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1316 lang.IFn; if linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any = t__0; var arg_1318 any; var fnbody__1328 any = A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A_New(); var tmp1 *jrt.Class; var fncls__1327 *jrt.Class = A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A_fn_class; if fncls__1327 == nil { var fncls__1327d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A_fn_class = fncls__1327d; tmp1 = fncls__1327d } else { tmp1 = fncls__1327 }; arg_1318 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1328, tmp1, nil); if linked_1315 == nil { return ifn_1316.Invoke_O_O__O(arg_1317, arg_1318) } else { return linked_1315.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1314, arg_1317, arg_1318) } }
//line :502:1
func A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A_New() *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A{}; t.Ctor(); return t }
//line :502:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A) Ctor() {}
//line :502:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A) Invoke_O_O__O(self, p1__219000197_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_1319 any = A_arbace_go_check_types_A_const_179.GetRawRoot__O(); var linked_1320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1319, A_arbace_go_check_types_numeric_QMARK__A_fn_class); var ifn_1321 lang.IFn; if linked_1320 == nil { ifn_1321 = lang.IFn_Cast(root_1319) } else { ifn_1321 = nil }; var arg_1322 any = p1__219000197_SHARP___1; if linked_1320 == nil { or__1927000174__auto____2 = ifn_1321.Invoke_O__O(arg_1322) } else { or__1927000174__auto____2 = linked_1320.(*A_arbace_go_check_types_numeric_QMARK__A).Invoke_O_O__O(root_1319, arg_1322) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_1323 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, A_arbace_go_check_types_string_type_QMARK__A_fn_class); var ifn_1325 lang.IFn; if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = p1__219000197_SHARP___1; if linked_1324 == nil { return ifn_1325.Invoke_O__O(arg_1326) } else { return linked_1324.(*A_arbace_go_check_types_string_type_QMARK__A).Invoke_O_O__O(root_1323, arg_1326) } } }
func A_arbace_go_check_types_all_float_QMARK__A_New() *A_arbace_go_check_types_all_float_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_float_QMARK__A{}; t.Ctor(); return t }
//line :503:1
func (t *A_arbace_go_check_types_all_float_QMARK__A) Ctor() {}
//line :503:1
func (t *A_arbace_go_check_types_all_float_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1329 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1329, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1331 lang.IFn; if linked_1330 == nil { ifn_1331 = lang.IFn_Cast(root_1329) } else { ifn_1331 = nil }; var arg_1332 any = t__0; var arg_1333 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); if linked_1330 == nil { return ifn_1331.Invoke_O_O__O(arg_1332, arg_1333) } else { return linked_1330.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1329, arg_1332, arg_1333) } }
func A_arbace_go_check_types_all_complex_QMARK__A_New() *A_arbace_go_check_types_all_complex_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_complex_QMARK__A{}; t.Ctor(); return t }
//line :504:1
func (t *A_arbace_go_check_types_all_complex_QMARK__A) Ctor() {}
//line :504:1
func (t *A_arbace_go_check_types_all_complex_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1334 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = t__0; var arg_1338 any = A_arbace_go_check_types_A_const_114.GetRawRoot__O(); if linked_1335 == nil { return ifn_1336.Invoke_O_O__O(arg_1337, arg_1338) } else { return linked_1335.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1334, arg_1337, arg_1338) } }

func A_arbace_go_check_types_common_under_A_New() *A_arbace_go_check_types_common_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_common_under_A{}; t.Ctor(); return t }
//line :506:1
func (t *A_arbace_go_check_types_common_under_A) Ctor() {}
//line :506:1
func (t *A_arbace_go_check_types_common_under_A) Invoke_O_O_O__O(self, t__0, cnd__1 any) any { { var ps__3 any; var root_1339 any = A_arbace_go_check_types_A_const_175.GetRawRoot__O(); var linked_1340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1339, A_arbace_go_check_types_typeset_pairs_A_fn_class); var ifn_1341 lang.IFn





	if linked_1340 == nil { ifn_1341 = lang.IFn_Cast(root_1339) } else { ifn_1341 = nil }; var arg_1342 any = t__0; if linked_1340 == nil { ps__3 = ifn_1341.Invoke_O__O(arg_1342) } else { ps__3 = linked_1340.(*A_arbace_go_check_types_typeset_pairs_A).Invoke_O_O__O(root_1339, arg_1342) }
//line :506:1
	var ct__4 any; var cu__5 any; L1: for {






		var tmp1 any; var root_1343 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1345 lang.IFn; if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = ps__3; if linked_1344 == nil { tmp1 = ifn_1345.Invoke_O__O(arg_1346) } else { tmp1 = linked_1344.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1343, arg_1346) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(cu__5, nil) } else { var vec__219000203__6 any; var root_1347 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_1348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1347, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1349 lang.IFn

			if linked_1348 == nil { ifn_1349 = lang.IFn_Cast(root_1347) } else { ifn_1349 = nil }; var arg_1350 any = ps__3; if linked_1348 == nil { vec__219000203__6 = ifn_1349.Invoke_O__O(arg_1350) } else { vec__219000203__6 = linked_1348.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1347, arg_1350) }
//line :513:1
			var ty__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000203__6, lang.RT_IntCast_J__I_NoInit(0), nil); var u__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000203__6, lang.RT_IntCast_J__I_NoInit(1), nil); var e__9 any


			if jrt.J2g_Truth(cnd__1) { e__9 = lang.IFn_Cast(cnd__1).Invoke_O_O__O(ty__7, u__8) } else { e__9 = nil }
			if jrt.J2g_Truth(e__9) { return lang.Tuple_Create_O_O__IPersistentVector(nil, e__9) } else { if lang.Util_Identical_O_O__Z_NoInit(u__8, nil) { return A_arbace_go_check_types_A_const_182 } else { if lang.Util_Identical_O_O__Z_NoInit(cu__5, nil) {


				var tmp2 any; var root_1382 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1384 lang.IFn; if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = ps__3; if linked_1383 == nil { tmp2 = ifn_1384.Invoke_O__O(arg_1385) } else { tmp2 = linked_1383.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1382, arg_1385) }; ps__3, ct__4, cu__5 = tmp2, ty__7, u__8; continue L1 } else {
//line :517:1
					var tmp3 any; var and__1927000168__auto____10 any; var root_1351 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1351, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1353 lang.IFn



					if linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any = cu__5; if linked_1352 == nil { and__1927000168__auto____10 = ifn_1353.Invoke_O__O(arg_1354) } else { and__1927000168__auto____10 = linked_1352.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1351, arg_1354) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp4 any = A_arbace_go_check_types_A_const_79; var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____11 { var and__1927000168__auto____12 any; var root_1355 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_1356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1355, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1357 lang.IFn; if linked_1356 == nil { ifn_1357 = lang.IFn_Cast(root_1355) } else { ifn_1357 = nil }; var arg_1358 any = u__8; if linked_1356 == nil { and__1927000168__auto____12 = ifn_1357.Invoke_O__O(arg_1358) } else { and__1927000168__auto____12 = linked_1356.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1355, arg_1358) }; if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp5 any = A_arbace_go_check_types_A_const_79; tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp5, lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp3 = and__1927000168__auto____12 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else { tmp3 = and__1927000168__auto____10 }
//line :517:1
					if jrt.J2g_Truth(tmp3) {




						var tmp6 any; var root_1359 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1361 lang.IFn
						if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any; var root_1363 any = A_arbace_go_check_types_A_const_144.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1363, A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_1365 lang.IFn; if linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any = lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(2)); var arg_1367 any = lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(2)); if linked_1364 == nil { arg_1362 = ifn_1365.Invoke_O_O__O(arg_1366, arg_1367) } else { arg_1362 = linked_1364.(*A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_1363, arg_1366, arg_1367) }; if linked_1360 == nil { tmp6 = ifn_1361.Invoke_O__O(arg_1362) } else { tmp6 = linked_1360.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1359, arg_1362) }
//line :522:1
						if jrt.J2g_Truth(tmp6) { return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7, nil, Lit_8), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_go_check_types_A_const_186.GetRawRoot__O()).Invoke_O__O(ct__4), nil, lang.IFn_Cast(A_arbace_go_check_types_A_const_186.GetRawRoot__O()).Invoke_O__O(ty__7), nil)).Ref()) } else { if lang.Util_Equiv_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(1)), lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(1))) {

							var tmp7 any; var root_1394 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1394, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1396 lang.IFn; if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any = ps__3; if linked_1395 == nil { tmp7 = ifn_1396.Invoke_O__O(arg_1397) } else { tmp7 = linked_1395.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1394, arg_1397) }; ps__3, ct__4, cu__5 = tmp7, ct__4, cu__5; continue L1 } else {
//line :522:1
								var tmp8 any = A_arbace_go_check_types_A_const_183; if lang.Util_Equiv_O_O__Z_NoInit(tmp8, lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(1))) {


									var tmp9 any; var root_1398 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any = ps__3; if linked_1399 == nil { tmp9 = ifn_1400.Invoke_O__O(arg_1401) } else { tmp9 = linked_1399.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1398, arg_1401) }; ps__3, ct__4, cu__5 = tmp9, ty__7, u__8; continue L1 } else {
//line :522:1
										var tmp10 any; var root_1368 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1368, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1370 lang.IFn



										if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any = A_arbace_go_check_types_A_const_183; var arg_1372 any = lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(1)); if linked_1369 == nil { tmp10 = ifn_1370.Invoke_O_O__O(arg_1371, arg_1372) } else { tmp10 = linked_1369.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1368, arg_1371, arg_1372) }
//line :522:1
										if jrt.J2g_Truth(tmp10) { return A_arbace_go_check_types_A_const_184 } else { if A_arbace_go_check_types_A_const_86 != nil {




											var tmp11 any; var root_1402 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1404 lang.IFn; if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any = ps__3; if linked_1403 == nil { tmp11 = ifn_1404.Invoke_O__O(arg_1405) } else { tmp11 = linked_1403.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1402, arg_1405) }; ps__3, ct__4, cu__5 = tmp11, ct__4, cu__5; continue L1 } else {
//line :522:1
												return nil } } } } } } else {
//line :517:1
													var tmp12 any; var root_1373 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1375 lang.IFn










													if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any; var root_1377 any = A_arbace_go_check_types_A_const_144.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, A_arbace_go_check_types_same_QMARK__A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any = cu__5; var arg_1381 any = u__8; if linked_1378 == nil { arg_1376 = ifn_1379.Invoke_O_O__O(arg_1380, arg_1381) } else { arg_1376 = linked_1378.(*A_arbace_go_check_types_same_QMARK__A).Invoke_O_O_O__O(root_1377, arg_1380, arg_1381) }; if linked_1374 == nil { tmp12 = ifn_1375.Invoke_O__O(arg_1376) } else { tmp12 = linked_1374.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1373, arg_1376) }
//line :517:1
													if jrt.J2g_Truth(tmp12) { return A_arbace_go_check_types_A_const_185 } else { if A_arbace_go_check_types_A_const_86 != nil {











														var tmp13 any; var root_1406 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1408 lang.IFn; if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any = ps__3; if linked_1407 == nil { tmp13 = ifn_1408.Invoke_O__O(arg_1409) } else { tmp13 = linked_1407.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1406, arg_1409) }; ps__3, ct__4, cu__5 = tmp13, ct__4, cu__5; continue L1 } else {
//line :517:1
															return nil } } } } } } } } }; /*line :506:1*/panic("j2g: unreachable") }
//line :506:1
func (t *A_arbace_go_check_types_common_under_A) Invoke_O_O__O(self, t__0 any) any {



	var root_1410 any = A_arbace_go_check_types_A_const_187.GetRawRoot__O(); var linked_1411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1410, A_arbace_go_check_types_common_under_A_fn_class); var ifn_1412 lang.IFn; if linked_1411 == nil { ifn_1412 = lang.IFn_Cast(root_1410) } else { ifn_1412 = nil }; var arg_1413 any = t__0; var arg_1414 any; if linked_1411 == nil { return ifn_1412.Invoke_O_O__O(arg_1413, arg_1414) } else { return linked_1411.(*A_arbace_go_check_types_common_under_A).Invoke_O_O_O__O(root_1410, arg_1413, arg_1414)
	}
}


















func A_arbace_go_check_types_core_type_A_New() *A_arbace_go_check_types_core_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_core_type_A{}; t.Ctor(); return t }
//line :531:1
func (t *A_arbace_go_check_types_core_type_A) Ctor() {}
//line :531:1
func (t *A_arbace_go_check_types_core_type_A) Invoke_O_O__O(self, t__0 any) any {


	var root_1415 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_1416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1415, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1417 lang.IFn; if linked_1416 == nil { ifn_1417 = lang.IFn_Cast(root_1415) } else { ifn_1417 = nil }; var arg_1418 any; var root_1419 any = A_arbace_go_check_types_A_const_187.GetRawRoot__O(); var linked_1420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1419, A_arbace_go_check_types_common_under_A_fn_class); var ifn_1421 lang.IFn; if linked_1420 == nil { ifn_1421 = lang.IFn_Cast(root_1419) } else { ifn_1421 = nil }; var arg_1422 any = t__0; if linked_1420 == nil { arg_1418 = ifn_1421.Invoke_O__O(arg_1422) } else { arg_1418 = linked_1420.(*A_arbace_go_check_types_common_under_A).Invoke_O_O__O(root_1419, arg_1422) }; if linked_1416 == nil { return ifn_1417.Invoke_O__O(arg_1418) } else { return linked_1416.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1415, arg_1418)
	}
}








func A_arbace_go_check_types_terms_str_A_New() *A_arbace_go_check_types_terms_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_A{}; t.Ctor(); return t }
//line :545:1
func (t *A_arbace_go_check_types_terms_str_A) Ctor() {}
//line :545:1
func (t *A_arbace_go_check_types_terms_str_A) Invoke_O_O__O(self, terms__0 any) any {
	var tmp1 any; var root_1423 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1423, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1425 lang.IFn; if linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; var arg_1426 any = terms__0; if linked_1424 == nil { tmp1 = ifn_1425.Invoke_O__O(arg_1426) } else { tmp1 = linked_1424.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1423, arg_1426) }; if jrt.J2g_Truth(tmp1) { return Lit_52 } else { var ts__2 any; var tmp2 *lang.Keyword = A_arbace_go_check_types_A_const_149; var or__1927000174__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(terms__0))

		if jrt.J2g_Truth(or__1927000174__auto____2) { ts__2 = or__1927000174__auto____2 } else { var root_1427 any = A_arbace_go_check_types_A_const_188.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1429 lang.IFn; if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = A_arbace_go_check_types_A_const_186.GetRawRoot__O(); var arg_1431 any = terms__0; if linked_1428 == nil { ts__2 = ifn_1429.Invoke_O_O__O(arg_1430, arg_1431) } else { ts__2 = linked_1428.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1427, arg_1430, arg_1431) } }
		var root_1432 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); var linked_1433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1432, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1434 lang.IFn; if linked_1433 == nil { ifn_1434 = lang.IFn_Cast(root_1432) } else { ifn_1434 = nil }; var arg_1435 any = Lit_53; var arg_1436 any; var iter__1927001039__auto____3 any; var fnbody__1506 any = A_arbace_go_check_types_terms_str_iter__219000208__219000212_A_New(); var tmp3 *jrt.Class; var fncls__1505 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000208__219000212_A_fn_class; if fncls__1505 == nil { var fncls__1505d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); A_arbace_go_check_types_terms_str_iter__219000208__219000212_A_fn_class = fncls__1505d; tmp3 = fncls__1505d } else { tmp3 = fncls__1505 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1506, tmp3, nil); arg_1436 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(ts__2); if linked_1433 == nil { return ifn_1434.Invoke_O_O__O(arg_1435, arg_1436) } else { return linked_1433.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1432, arg_1435, arg_1436) } } }
//line :549:1
func A_arbace_go_check_types_terms_str_iter__219000208__219000212_A_New() *A_arbace_go_check_types_terms_str_iter__219000208__219000212_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000208__219000212_A{}; t.Ctor(); return t }
//line :549:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_A) Ctor() {}
//line :549:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_A) Invoke_O_O__O(self, s__219000209__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1504 any = A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A_New_O_O(self, s__219000209__1); var tmp2 *jrt.Class; var fncls__1503 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A_fn_class; if fncls__1503 == nil { var fncls__1503d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, fnbody__1504); A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A_fn_class = fncls__1503d; tmp2 = fncls__1503d } else { tmp2 = fncls__1503 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1504, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :549:1
func A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A{}; t.Ctor_O_O(p0, p1); return t }
//line :549:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A) Ctor_O_O(c__iter__219000208, c__s__219000209 any) { t.F_iter__219000208 = c__iter__219000208; t.F_s__219000209 = c__s__219000209 }
//line :549:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A) Invoke_O__O(self any) any { { var s__219000209__1 any; var t_ any = t.F_s__219000209; t.F_s__219000209 = nil; s__219000209__1 = t_; for { var temp__1927000414__auto____2 any; var root_1437 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1439 lang.IFn; if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any = s__219000209__1; if linked_1438 == nil { temp__1927000414__auto____2 = ifn_1439.Invoke_O__O(arg_1440) } else { temp__1927000414__auto____2 = linked_1438.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1437, arg_1440) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000209__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1441 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1441, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1443 lang.IFn; if linked_1442 == nil { ifn_1443 = lang.IFn_Cast(root_1441) } else { ifn_1443 = nil }; var arg_1444 any = s__219000209__3; if linked_1442 == nil { tmp1 = ifn_1443.Invoke_O__O(arg_1444) } else { tmp1 = linked_1442.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1441, arg_1444) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1445 any = A_arbace_go_check_types_A_const_155.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1445, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1447 lang.IFn; if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any = s__219000209__3; if linked_1446 == nil { c__1927001037__auto____4 = ifn_1447.Invoke_O__O(arg_1448) } else { c__1927001037__auto____4 = linked_1446.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1445, arg_1448) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000211__6 any; var root_1449 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1449, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1451 lang.IFn; if linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1450 == nil { b__219000211__6 = ifn_1451.Invoke_O__O(arg_1452) } else { b__219000211__6 = linked_1450.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1449, arg_1452) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1463 any = A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A_New_O_I_O(b__219000211__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1462 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A_fn_class; if fncls__1462 == nil { var fncls__1462d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__1463); A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A_fn_class = fncls__1462d; tmp3 = fncls__1462d } else { tmp3 = fncls__1462 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1463, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1464 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_1465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1464, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1466 lang.IFn; if linked_1465 == nil { ifn_1466 = lang.IFn_Cast(root_1464) } else { ifn_1466 = nil }; var arg_1467 any; var root_1469 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = b__219000211__6; if linked_1470 == nil { arg_1467 = ifn_1471.Invoke_O__O(arg_1472) } else { arg_1467 = linked_1470.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1469, arg_1472) }; var arg_1468 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000208); var tmp5 any; var root_1473 any = A_arbace_go_check_types_A_const_161.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = s__219000209__3; if linked_1474 == nil { tmp5 = ifn_1475.Invoke_O__O(arg_1476) } else { tmp5 = linked_1474.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1473, arg_1476) }; arg_1468 = tmp4.Invoke_O__O(tmp5); if linked_1465 == nil { return ifn_1466.Invoke_O_O__O(arg_1467, arg_1468) } else { return linked_1465.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1464, arg_1467, arg_1468) } } else { var root_1477 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1477, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1479 lang.IFn; if linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any; var root_1482 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1484 lang.IFn; if linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any = b__219000211__6; if linked_1483 == nil { arg_1480 = ifn_1484.Invoke_O__O(arg_1485) } else { arg_1480 = linked_1483.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1482, arg_1485) }; var arg_1481 any; if linked_1478 == nil { return ifn_1479.Invoke_O_O__O(arg_1480, arg_1481) } else { return linked_1478.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1477, arg_1480, arg_1481) } } } else { var vec__219000219__4 any; var root_1486 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_1487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1486, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1488 lang.IFn; if linked_1487 == nil { ifn_1488 = lang.IFn_Cast(root_1486) } else { ifn_1488 = nil }; var arg_1489 any = s__219000209__3; if linked_1487 == nil { vec__219000219__4 = ifn_1488.Invoke_O__O(arg_1489) } else { vec__219000219__4 = linked_1487.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1486, arg_1489) }; var tilde__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000219__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000219__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1490 any = A_arbace_go_check_types_A_const_162.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1490, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1492 lang.IFn; if linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 *jrt.String; if jrt.J2g_Truth(tilde__5) { tmp7 = Lit_57 } else { tmp7 = nil }; var tmp8 any = tmp7.Ref(); var tmp9 any; var root_1495 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1497 lang.IFn; if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any = ty__6; if linked_1496 == nil { tmp9 = ifn_1497.Invoke_O__O(arg_1498) } else { tmp9 = linked_1496.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1495, arg_1498) }; arg_1493 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9)).Ref(); var arg_1494 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__219000208); var tmp11 any; var root_1499 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1499, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1501 lang.IFn; if linked_1500 == nil { ifn_1501 = lang.IFn_Cast(root_1499) } else { ifn_1501 = nil }; var arg_1502 any = s__219000209__3; if linked_1500 == nil { tmp11 = ifn_1501.Invoke_O__O(arg_1502) } else { tmp11 = linked_1500.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1499, arg_1502) }; arg_1494 = tmp10.Invoke_O__O(tmp11); if linked_1491 == nil { return ifn_1492.Invoke_O_O__O(arg_1493, arg_1494) } else { return linked_1491.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1490, arg_1493, arg_1494) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :549:1
func A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :549:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A) Ctor_O_I_O(c__b__219000211 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000211 = c__b__219000211; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :549:1
func (t *A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A) Invoke_O__O(self any) any { { var i__219000210__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000210__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__219000215__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000210__1)); var tilde__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000215__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000215__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1453 any = A_arbace_go_check_types_A_const_158.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1455 lang.IFn; if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = t.F_b__219000211; var arg_1457 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 *jrt.String; if jrt.J2g_Truth(tilde__3) { tmp3 = Lit_57 } else { tmp3 = nil }; var tmp4 any = tmp3.Ref(); var tmp5 any; var root_1458 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1458, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1460 lang.IFn; if linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any = ty__4; if linked_1459 == nil { tmp5 = ifn_1460.Invoke_O__O(arg_1461) } else { tmp5 = linked_1459.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1458, arg_1461) }; arg_1457 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5)).Ref(); if linked_1454 == nil { ifn_1455.Invoke_O_O__O(arg_1456, arg_1457) } else { linked_1454.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1453, arg_1456, arg_1457) }; i__219000210__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000210__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_types_params_str_A_New() *A_arbace_go_check_types_params_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_params_str_A{}; t.Ctor(); return t }
//line :551:1
func (t *A_arbace_go_check_types_params_str_A) Ctor() {}
//line :551:1
func (t *A_arbace_go_check_types_params_str_A) Invoke_O_O_O__O(self, ps__0, variadic__1 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_30, nil, Lit_31); var tmp2 any; var root_1507 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1507, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1509 lang.IFn
	if linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any = Lit_32; var arg_1511 any; var root_1512 any = A_arbace_go_check_types_A_const_190.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1512, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1514 lang.IFn; if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; var arg_1515 any; var fnbody__1526 any = A_arbace_go_check_types_params_str_fn__219000225_A_New_O_O(ps__0, variadic__1); var tmp3 *jrt.Class; var fncls__1525 *jrt.Class = A_arbace_go_check_types_params_str_fn__219000225_A_fn_class; if fncls__1525 == nil { var fncls__1525d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__1526); A_arbace_go_check_types_params_str_fn__219000225_A_fn_class = fncls__1525d; tmp3 = fncls__1525d } else { tmp3 = fncls__1525 }; arg_1515 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1526, tmp3, nil); var arg_1516 any = ps__0; if linked_1513 == nil { arg_1511 = ifn_1514.Invoke_O_O__O(arg_1515, arg_1516) } else { arg_1511 = linked_1513.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1512, arg_1515, arg_1516) }; if linked_1508 == nil { tmp2 = ifn_1509.Invoke_O_O__O(arg_1510, arg_1511) } else { tmp2 = linked_1508.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1507, arg_1510, arg_1511) }
//line :552:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil)).Ref() }
func A_arbace_go_check_types_params_str_fn__219000225_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_params_str_fn__219000225_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_params_str_fn__219000225_A{}; t.Ctor_O_O(p0, p1); return t }
//line :553:1
func (t *A_arbace_go_check_types_params_str_fn__219000225_A) Ctor_O_O(c__ps, c__variadic any) { t.F_ps = c__ps; t.F_variadic = c__variadic }
//line :553:1
func (t *A_arbace_go_check_types_params_str_fn__219000225_A) Invoke_O_O_O__O(self, i__1, p__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = t.F_variadic; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_J__Z_NoInit(i__1, lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_ps))))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_34, nil); var tmp3 any; var root_1517 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1517, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1519 lang.IFn; if linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any = lang.RT_Nth_O_I__O_NoInit(p__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1518 == nil { tmp3 = ifn_1519.Invoke_O__O(arg_1520) } else { tmp3 = linked_1518.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1517, arg_1520) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else {
			var root_1521 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1521, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1523 lang.IFn; if linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1524 any = p__2; if linked_1522 == nil { return ifn_1523.Invoke_O__O(arg_1524) } else { return linked_1522.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1521, arg_1524)
			}
		}
}
func A_arbace_go_check_types_sig_str_A_New() *A_arbace_go_check_types_sig_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sig_str_A{}; t.Ctor(); return t }
//line :560:1
func (t *A_arbace_go_check_types_sig_str_A) Ctor() {}
//line :560:1
func (t *A_arbace_go_check_types_sig_str_A) Invoke_O_O__O(self, p__219000228__0 any) any { var vec__219000229__2 any = p__219000228__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000229__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000229__2, lang.RT_IntCast_J__I_NoInit(1), nil); var rs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000229__2, lang.RT_IntCast_J__I_NoInit(2), nil); var variadic__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000229__2, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_1527 any = A_arbace_go_check_types_A_const_191.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1527, A_arbace_go_check_types_params_str_A_fn_class); var ifn_1529 lang.IFn; _ = ___3; if


	linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any = ps__4; var arg_1531 any = variadic__6; if linked_1528 == nil { tmp2 = ifn_1529.Invoke_O_O__O(arg_1530, arg_1531) } else { tmp2 = linked_1528.(*A_arbace_go_check_types_params_str_A).Invoke_O_O_O__O(root_1527, arg_1530, arg_1531) }; var tmp3 any = tmp2; var tmp4 *jrt.String; var G__219000232__9_ int32 = lang.RT_Count_O__I_NoInit(rs__5); L1:
	switch { default: switch G__219000232__9_ { case 0: tmp4 = Lit_10; break L1; case 1: var r__10 any; var root_1533 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_1534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1533, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1535 lang.IFn

		if linked_1534 == nil { ifn_1535 = lang.IFn_Cast(root_1533) } else { ifn_1535 = nil }; var arg_1536 any = rs__5; if linked_1534 == nil { r__10 = ifn_1535.Invoke_O__O(arg_1536) } else { r__10 = linked_1534.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1533, arg_1536) }; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_11, nil); var tmp6 any; var root_1537 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = r__10; if linked_1538 == nil { tmp6 = ifn_1539.Invoke_O__O(arg_1540) } else { tmp6 = linked_1538.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1537, arg_1540) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6))
//line :564:1
		break L1; default:
	}

		var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_42, nil, Lit_31); var tmp8 any; var root_1541 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); var linked_1542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1541, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1543 lang.IFn; if linked_1542 == nil { ifn_1543 = lang.IFn_Cast(root_1541) } else { ifn_1543 = nil }; var arg_1544 any = Lit_32; var arg_1545 any; var root_1546 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1546, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1548 lang.IFn; if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var arg_1550 any = rs__5; if linked_1547 == nil { arg_1545 = ifn_1548.Invoke_O_O__O(arg_1549, arg_1550) } else { arg_1545 = linked_1547.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1546, arg_1549, arg_1550) }; if linked_1542 == nil { tmp8 = ifn_1543.Invoke_O_O__O(arg_1544, arg_1545) } else { tmp8 = linked_1542.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1541, arg_1544, arg_1545) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil))}; return /*line :563:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4.Ref())).Ref() }





func A_arbace_go_check_types_field_str_A_New() *A_arbace_go_check_types_field_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_field_str_A{}; t.Ctor(); return t }
//line :569:1
func (t *A_arbace_go_check_types_field_str_A) Ctor() {}
//line :569:1
func (t *A_arbace_go_check_types_field_str_A) Invoke_O_O__O(self, f__0 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 *jrt.String; if jrt.J2g_Truth(A_arbace_go_check_types_A_const_192.Invoke_O__O(f__0)) { tmp2 = Lit_10 } else { tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_12.Invoke_O__O(f__0), nil)) }; var tmp3 any = tmp2.Ref(); var tmp4 any; var root_1551 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1551, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1553 lang.IFn; if linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(f__0); if linked_1552 == nil { tmp4 = ifn_1553.Invoke_O__O(arg_1554) } else { tmp4 = linked_1552.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1551, arg_1554) }; var tmp5 any = tmp4; var tmp6 *jrt.String
	if jrt.J2g_Truth(A_arbace_go_check_types_A_const_130.Invoke_O__O(f__0)) { var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_11, nil); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_186.GetRawRoot__O()); var tmp9 any; var root_1559 any = A_arbace_go_check_types_A_const_193.GetRawRoot__O(); var linked_1560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1559, aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A_fn_class); var ifn_1561 lang.IFn; if linked_1560 == nil { ifn_1561 = lang.IFn_Cast(root_1559) } else { ifn_1561 = nil }; var arg_1562 any = A_arbace_go_check_types_A_const_130.Invoke_O__O(f__0); if linked_1560 == nil { tmp9 = ifn_1561.Invoke_O__O(arg_1562) } else { tmp9 = linked_1560.(*aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A).Invoke_O_O__O(root_1559, arg_1562) }; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8.Invoke_O__O(tmp9))) } else { tmp6 = nil }
//line :570:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp5, tmp6.Ref())).Ref()
}

func A_arbace_go_check_types_named_str_A_New() *A_arbace_go_check_types_named_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_str_A{}; t.Ctor(); return t }
//line :573:1
func (t *A_arbace_go_check_types_named_str_A) Ctor() {}
//line :573:1
func (t *A_arbace_go_check_types_named_str_A) Invoke_O_O__O(self, t__0 any) any { var i__2 any; var root_1563 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_1564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1563, A_arbace_go_check_types_info_A_fn_class); var ifn_1565 lang.IFn; if
										linked_1564 == nil { ifn_1565 = lang.IFn_Cast(root_1563) } else { ifn_1565 = nil }; var arg_1566 any = t__0; if linked_1564 == nil { i__2 = ifn_1565.Invoke_O__O(arg_1566) } else { i__2 = linked_1564.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1563, arg_1566) }; var base__3 any; var tmp1 any; var and__1927000168__auto____3 any = /*line :573:1*/A_arbace_go_check_types_A_const_57.Invoke_O__O(i__2); if

	jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1567 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1568 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1567, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1569 lang.IFn; if linked_1568 == nil { ifn_1569 = lang.IFn_Cast(root_1567) } else { ifn_1569 = nil }; var arg_1570 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(i__2); var arg_1571 any = A_arbace_go_check_types_A_const_194.Get__O(); if linked_1568 == nil { and__1927000168__auto____4 = ifn_1569.Invoke_O_O__O(arg_1570, arg_1571) } else { and__1927000168__auto____4 = linked_1568.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1567, arg_1570, arg_1571) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1572 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1574 lang.IFn; if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = A_arbace_go_check_types_A_const_59.Invoke_O__O(i__2); if linked_1573 == nil { tmp1 = ifn_1574.Invoke_O__O(arg_1575) } else { tmp1 = linked_1573.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1572, arg_1575) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		base__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_58.Invoke_O__O(i__2), nil, A_arbace_go_check_types_A_const_12.Invoke_O__O(i__2))).Ref() } else {
			base__3 = A_arbace_go_check_types_A_const_12.Invoke_O__O(i__2) }; var tmp2 any; var root_1576 any =
	A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1576, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1578 lang.IFn; if linked_1577 == nil { ifn_1578 = lang.IFn_Cast(root_1576) } else { ifn_1578 = nil }; var arg_1579 any = A_arbace_go_check_types_A_const_195.Invoke_O__O(i__2); if linked_1577 == nil { tmp2 = ifn_1578.Invoke_O__O(arg_1579) } else { tmp2 = linked_1577.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1576, arg_1579) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil, Lit_27); var tmp4 any; var root_1580 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); var linked_1581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1580, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1582 lang.IFn; if linked_1581 == nil { ifn_1582 = lang.IFn_Cast(root_1580) } else { ifn_1582 = nil }; var arg_1583 any = Lit_28; var arg_1584 any; var root_1585 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1585, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1587 lang.IFn; if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var arg_1588 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var arg_1589 any = A_arbace_go_check_types_A_const_195.Invoke_O__O(i__2); if linked_1586 == nil { arg_1584 = ifn_1587.Invoke_O_O__O(arg_1588, arg_1589) } else { arg_1584 = linked_1586.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1585, arg_1588, arg_1589) }; if linked_1581 == nil { tmp4 = ifn_1582.Invoke_O_O__O(arg_1583, arg_1584) } else { tmp4 = linked_1581.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1580, arg_1583, arg_1584) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, base__3, nil, tmp4, nil)).Ref() } else {
//line :578:1
			return base__3 } }



func A_arbace_go_check_types_alias_str_A_New() *A_arbace_go_check_types_alias_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alias_str_A{}; t.Ctor(); return t }
//line :582:1
func (t *A_arbace_go_check_types_alias_str_A) Ctor() {}
//line :582:1
func (t *A_arbace_go_check_types_alias_str_A) Invoke_O_O__O(self, a__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(a__0); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1590 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1591 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1590, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1592 lang.IFn; if linked_1591 == nil { ifn_1592 = lang.IFn_Cast(root_1590) } else { ifn_1592 = nil }; var arg_1593 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(a__0); var arg_1594 any = A_arbace_go_check_types_A_const_194.Get__O(); if linked_1591 == nil { and__1927000168__auto____3 = ifn_1592.Invoke_O_O__O(arg_1593, arg_1594) } else { and__1927000168__auto____3 = linked_1591.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1590, arg_1593, arg_1594) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1595 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1597 lang.IFn; if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any = A_arbace_go_check_types_A_const_59.Invoke_O__O(a__0); if linked_1596 == nil { tmp1 = ifn_1597.Invoke_O__O(arg_1598) } else { tmp1 = linked_1596.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1595, arg_1598) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_58.Invoke_O__O(a__0), nil, A_arbace_go_check_types_A_const_12.Invoke_O__O(a__0))).Ref() } else {
			return A_arbace_go_check_types_A_const_12.Invoke_O__O(a__0)
		} }
func A_arbace_go_check_types_type_str_A_New() *A_arbace_go_check_types_type_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_A{}; t.Ctor(); return t }
//line :589:1
func (t *A_arbace_go_check_types_type_str_A) Ctor() {}
//line :589:1
func (t *A_arbace_go_check_types_type_str_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_1599 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_1601 lang.IFn
	if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = t__0; if linked_1600 == nil { tmp1 = ifn_1601.Invoke_O__O(arg_1602) } else { tmp1 = linked_1600.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_1599, arg_1602) }
//line :592:1
	if jrt.J2g_Truth(tmp1) { var or__1927000174__auto____2 any = lang.RT_Get_O_O__O_NoInit(A_arbace_go_check_types_A_const_196.GetRawRoot__O(), t__0)
		if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var G__219000237__3_ any; var root_1603 any = A_arbace_go_check_types_A_const_62.GetRawRoot__O(); var linked_1604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1603, A_arbace_go_check_types_kw_alias_info_A_fn_class); var ifn_1605 lang.IFn; if linked_1604 == nil { ifn_1605 = lang.IFn_Cast(root_1603) } else { ifn_1605 = nil }; var arg_1606 any = t__0; if linked_1604 == nil { G__219000237__3_ = ifn_1605.Invoke_O__O(arg_1606) } else { G__219000237__3_ = linked_1604.(*A_arbace_go_check_types_kw_alias_info_A).Invoke_O_O__O(root_1603, arg_1606) }; if lang.Util_Identical_O_O__Z_NoInit(G__219000237__3_, nil) { or__1927000174__auto____3 = nil } else { var root_1607 any = A_arbace_go_check_types_A_const_197.GetRawRoot__O(); var linked_1608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1607, A_arbace_go_check_types_alias_str_A_fn_class); var ifn_1609 lang.IFn; if linked_1608 == nil { ifn_1609 = lang.IFn_Cast(root_1607) } else { ifn_1609 = nil }; var arg_1610 any = G__219000237__3_; if linked_1608 == nil { or__1927000174__auto____3 = ifn_1609.Invoke_O__O(arg_1610) } else { or__1927000174__auto____3 = linked_1608.(*A_arbace_go_check_types_alias_str_A).Invoke_O_O__O(root_1607, arg_1610) } }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_1611 any = A_arbace_go_check_types_A_const_198.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1611, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1613 lang.IFn; if linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any = t__0; if linked_1612 == nil { return ifn_1613.Invoke_O__O(arg_1614) } else { return linked_1612.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1611, arg_1614) } } } } else {
//line :592:1
			var tmp2 *lang.Keyword = A_arbace_go_check_types_A_const_85; if jrt.J2g_Truth(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(t__0))) {

				var root_1615 any = A_arbace_go_check_types_A_const_197.GetRawRoot__O(); var linked_1616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1615, A_arbace_go_check_types_alias_str_A_fn_class); var ifn_1617 lang.IFn; if linked_1616 == nil { ifn_1617 = lang.IFn_Cast(root_1615) } else { ifn_1617 = nil }; var tmp3 *lang.Keyword = A_arbace_go_check_types_A_const_85; var arg_1618 any = tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(t__0)); if linked_1616 == nil { return ifn_1617.Invoke_O__O(arg_1618) } else { return linked_1616.(*A_arbace_go_check_types_alias_str_A).Invoke_O_O__O(root_1615, arg_1618) } } else {
//line :592:1
					var tmp4 any; var root_1619 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_1620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1619, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1621 lang.IFn


					if linked_1620 == nil { ifn_1621 = lang.IFn_Cast(root_1619) } else { ifn_1621 = nil }; var arg_1622 any = t__0; if linked_1620 == nil { tmp4 = ifn_1621.Invoke_O__O(arg_1622) } else { tmp4 = linked_1620.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1619, arg_1622) }
//line :592:1
					if jrt.J2g_Truth(tmp4) {


						var root_1623 any = A_arbace_go_check_types_A_const_199.GetRawRoot__O(); var linked_1624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1623, A_arbace_go_check_types_named_str_A_fn_class); var ifn_1625 lang.IFn; if linked_1624 == nil { ifn_1625 = lang.IFn_Cast(root_1623) } else { ifn_1625 = nil }; var arg_1626 any = t__0; if linked_1624 == nil { return ifn_1625.Invoke_O__O(arg_1626) } else { return linked_1624.(*A_arbace_go_check_types_named_str_A).Invoke_O_O__O(root_1623, arg_1626) } } else {
//line :592:1
							var tmp5 any; var root_1627 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_1628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1627, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_1629 lang.IFn



							if linked_1628 == nil { ifn_1629 = lang.IFn_Cast(root_1627) } else { ifn_1629 = nil }; var arg_1630 any = t__0; if linked_1628 == nil { tmp5 = ifn_1629.Invoke_O__O(arg_1630) } else { tmp5 = linked_1628.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_1627, arg_1630) }
//line :592:1
							if jrt.J2g_Truth(tmp5) {



								var tmp6 *lang.Keyword = A_arbace_go_check_types_A_const_12; var tmp7 any; var root_1631 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_1632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1631, A_arbace_go_check_types_info_A_fn_class); var ifn_1633 lang.IFn; if linked_1632 == nil { ifn_1633 = lang.IFn_Cast(root_1631) } else { ifn_1633 = nil }; var arg_1634 any = t__0; if linked_1632 == nil { tmp7 = ifn_1633.Invoke_O__O(arg_1634) } else { tmp7 = linked_1632.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1631, arg_1634) }; return tmp6.Invoke_O__O(tmp7) } else {
//line :592:1
									if A_arbace_go_check_types_A_const_86 != nil { var G__219000238__2_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))





										switch lang.Util_Hash_O__I_NoInit(G__219000238__2_) >> 5 & 31 { case 0: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_69) {





















											var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_30, nil, Lit_31); var tmp9 any; var root_1636 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any = Lit_32; var arg_1640 any; var root_1641 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1642 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1641, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1643 lang.IFn; if linked_1642 == nil { ifn_1643 = lang.IFn_Cast(root_1641) } else { ifn_1643 = nil }; var arg_1644 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var arg_1645 any; var root_1646 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1646, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1648 lang.IFn; if linked_1647 == nil { ifn_1648 = lang.IFn_Cast(root_1646) } else { ifn_1648 = nil }; var arg_1649 any = t__0; if linked_1647 == nil { arg_1645 = ifn_1648.Invoke_O__O(arg_1649) } else { arg_1645 = linked_1647.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1646, arg_1649) }; if linked_1642 == nil { arg_1640 = ifn_1643.Invoke_O_O__O(arg_1644, arg_1645) } else { arg_1640 = linked_1642.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1641, arg_1644, arg_1645) }; if linked_1637 == nil { tmp9 = ifn_1638.Invoke_O_O__O(arg_1639, arg_1640) } else { tmp9 = linked_1637.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1636, arg_1639, arg_1640) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil)).Ref() }
//line :598:1
										case 1: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_71) { var ms__3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var ts__4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var tmp10 any; var and__1927000168__auto____5 any; var root_1650 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1650, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1652 lang.IFn












											if linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any = ms__3; if linked_1651 == nil { and__1927000168__auto____5 = ifn_1652.Invoke_O__O(arg_1653) } else { and__1927000168__auto____5 = linked_1651.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1650, arg_1653) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(ts__4, nil)).Ref() } else { tmp10 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp10) { return Lit_61 } else {

												var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil, Lit_63); var tmp12 any; var root_1654 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1654, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1656 lang.IFn
												if linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any = Lit_64; var arg_1658 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_152.GetRawRoot__O()); var tmp14 any; if jrt.J2g_Truth(A_arbace_go_check_types_A_const_133.Invoke_O__O(ts__4)) { tmp14 = A_arbace_go_check_types_A_const_200 } else { tmp14 = nil }; var tmp15 any = tmp14; var tmp16 any; var iter__1927001039__auto____8 any; var fnbody__1734 any = A_arbace_go_check_types_type_str_iter__219000239__219000243_A_New(); var tmp17 *jrt.Class; var fncls__1733 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000239__219000243_A_fn_class
												if fncls__1733 == nil { var fncls__1733d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, nil); A_arbace_go_check_types_type_str_iter__219000239__219000243_A_fn_class = fncls__1733d; tmp17 = fncls__1733d } else { tmp17 = fncls__1733 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1734, tmp17, nil); tmp16 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(ms__3)
//line :614:1
												var tmp18 any = tmp16; var tmp19 lang.IPersistentVector; var tmp20 any; var and__1927000168__auto____8 any; var root_1735 any = A_arbace_go_check_types_A_const_166.GetRawRoot__O(); var linked_1736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1735, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1737 lang.IFn

												if linked_1736 == nil { ifn_1737 = lang.IFn_Cast(root_1735) } else { ifn_1737 = nil }; var arg_1738 any = ts__4; if linked_1736 == nil { and__1927000168__auto____8 = ifn_1737.Invoke_O__O(arg_1738) } else { and__1927000168__auto____8 = linked_1736.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1735, arg_1738) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1739 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1740 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1739, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1741 lang.IFn; if linked_1740 == nil { ifn_1741 = lang.IFn_Cast(root_1739) } else { ifn_1741 = nil }; var arg_1742 any = A_arbace_go_check_types_A_const_131; var arg_1743 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__4); if linked_1740 == nil { tmp20 = ifn_1741.Invoke_O_O__O(arg_1742, arg_1743) } else { tmp20 = linked_1740.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1739, arg_1742, arg_1743) } } else { tmp20 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp20) { var tmp21 any; var root_1744 any = A_arbace_go_check_types_A_const_202.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_1746 lang.IFn
													if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(ts__4); if linked_1745 == nil { tmp21 = ifn_1746.Invoke_O__O(arg_1747) } else { tmp21 = linked_1745.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_1744, arg_1747) }
//line :616:1
													tmp19 = lang.Tuple_Create_O__IPersistentVector(tmp21) } else { tmp19 = nil }
//line :614:1
												arg_1658 = tmp13.Invoke_O_O_O__O(tmp15, tmp18, tmp19); if linked_1655 == nil { tmp12 = ifn_1656.Invoke_O_O__O(arg_1657, arg_1658) } else { tmp12 = linked_1655.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1654, arg_1657, arg_1658) }
//line :613:1
												return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, nil)).Ref() } }
//line :598:1
										case 3: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_73) {
											var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_66, nil); var tmp23 any; var root_1748 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1748, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1750 lang.IFn; if linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var arg_1751 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1749 == nil { tmp23 = ifn_1750.Invoke_O__O(arg_1751) } else { tmp23 = linked_1749.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1748, arg_1751) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23)).Ref() }
//line :598:1
										case 4: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_74) {


											var tmp24 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_27, nil); var tmp25 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp26 any; var root_1752 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1752, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1754 lang.IFn; if linked_1753 == nil { ifn_1754 = lang.IFn_Cast(root_1752) } else { ifn_1754 = nil }; var arg_1755 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_1753 == nil { tmp26 = ifn_1754.Invoke_O__O(arg_1755) } else { tmp26 = linked_1753.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1752, arg_1755) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp24, jrt.RefArrayOf(jrt.Object_class, nil, tmp25, nil, tmp26)).Ref() }
//line :598:1
										case 8: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_77) {



											var tmp27 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_67, nil, Lit_27, nil); var tmp28 any; var root_1760 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1760, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1762 lang.IFn; if linked_1761 == nil { ifn_1762 = lang.IFn_Cast(root_1760) } else { ifn_1762 = nil }; var arg_1763 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1761 == nil { tmp28 = ifn_1762.Invoke_O__O(arg_1763) } else { tmp28 = linked_1761.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1760, arg_1763) }; var tmp29 any = tmp28; var tmp30 any; var root_1764 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1764, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1766 lang.IFn; if linked_1765 == nil { ifn_1766 = lang.IFn_Cast(root_1764) } else { ifn_1766 = nil }; var arg_1767 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_1765 == nil { tmp30 = ifn_1766.Invoke_O__O(arg_1767) } else { tmp30 = linked_1765.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1764, arg_1767) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp27, jrt.RefArrayOf(jrt.Object_class, nil, tmp29, nil, tmp30)).Ref() }
//line :598:1
										case 14: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_78) {

											var tmp31 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil); var tmp32 any; var root_1768 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1768, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1770 lang.IFn; if linked_1769 == nil { ifn_1770 = lang.IFn_Cast(root_1768) } else { ifn_1770 = nil }; var arg_1771 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1769 == nil { tmp32 = ifn_1770.Invoke_O__O(arg_1771) } else { tmp32 = linked_1769.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1768, arg_1771) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp31, jrt.RefArrayOf(jrt.Object_class, nil, tmp32)).Ref() }
//line :598:1
										case 16: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_79) { var e__3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var es__4 any; var root_1772 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_1773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1772, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1774 lang.IFn





											if linked_1773 == nil { ifn_1774 = lang.IFn_Cast(root_1772) } else { ifn_1774 = nil }; var arg_1775 any = e__3; if linked_1773 == nil { es__4 = ifn_1774.Invoke_O__O(arg_1775) } else { es__4 = linked_1773.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1772, arg_1775) }
//line :598:1
											var es__5 any; var tmp33 any; var tmp34 any = A_arbace_go_check_types_A_const_183; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp34, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)))






											if and__1927000168__auto____5_2 { var and__1927000168__auto____6 any; var root_1776 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_1777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1776, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1778 lang.IFn; if linked_1777 == nil { ifn_1778 = lang.IFn_Cast(root_1776) } else { ifn_1778 = nil }; var arg_1779 any = e__3; if linked_1777 == nil { and__1927000168__auto____6 = ifn_1778.Invoke_O__O(arg_1779) } else { and__1927000168__auto____6 = linked_1777.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1776, arg_1779) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp35 any = A_arbace_go_check_types_A_const_79; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp35, lang.RT_Nth_O_I__O_NoInit(e__3, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____7 { var tmp36 any = A_arbace_go_check_types_A_const_203; tmp33 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp36, lang.RT_Nth_O_I__O_NoInit(e__3, lang.RT_IntCast_J__I_NoInit(1)))).Ref() } else { tmp33 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp33 = and__1927000168__auto____6 } } else { tmp33 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref() }; if jrt.J2g_Truth(tmp33) {
												es__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_30, nil, Lit_31), jrt.RefArrayOf(jrt.Object_class, nil, es__4, nil)).Ref() } else {
//line :605:1
													es__5 = es__4 }
//line :598:1
											var G__219000249__6_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1))








											switch lang.Util_Hash_O__I_NoInit(G__219000249__6_) >> 7 & 3 { case 0: if any(G__219000249__6_) == any(A_arbace_go_check_types_A_const_203) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_69, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; case 2: if any(G__219000249__6_) == any(A_arbace_go_check_types_A_const_183) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_70, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; case 3: if any(G__219000249__6_) == any(A_arbace_go_check_types_A_const_204) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_71, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__219000249__6_))))) }
//line :598:1
										case 27: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_81) {









											var tmp37 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_73, nil); var tmp38 any; var root_1781 any = A_arbace_go_check_types_A_const_201.GetRawRoot__O(); var linked_1782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1781, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1783 lang.IFn; if linked_1782 == nil { ifn_1783 = lang.IFn_Cast(root_1781) } else { ifn_1783 = nil }; var arg_1784 any = t__0; if linked_1782 == nil { tmp38 = ifn_1783.Invoke_O__O(arg_1784) } else { tmp38 = linked_1782.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1781, arg_1784) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp37, jrt.RefArrayOf(jrt.Object_class, nil, tmp38)).Ref() }
//line :598:1
										case 28: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_143) {




















											var root_1785 any = A_arbace_go_check_types_A_const_202.GetRawRoot__O(); var linked_1786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1785, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_1787 lang.IFn; if linked_1786 == nil { ifn_1787 = lang.IFn_Cast(root_1785) } else { ifn_1787 = nil }; var arg_1788 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1786 == nil { return ifn_1787.Invoke_O__O(arg_1788) } else { return linked_1786.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_1785, arg_1788) } }
//line :598:1
										case 31: if any(G__219000238__2_) == any(A_arbace_go_check_types_A_const_82) {










											var tmp39 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_74, nil, Lit_63); var tmp40 any; var root_1789 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); var linked_1790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1789, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1791 lang.IFn; if linked_1790 == nil { ifn_1791 = lang.IFn_Cast(root_1789) } else { ifn_1791 = nil }; var arg_1792 any = Lit_64; var arg_1793 any; var root_1794 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1795 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1794, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1796 lang.IFn; if linked_1795 == nil { ifn_1796 = lang.IFn_Cast(root_1794) } else { ifn_1796 = nil }; var arg_1797 any = A_arbace_go_check_types_A_const_205.GetRawRoot__O(); var arg_1798 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1795 == nil { arg_1793 = ifn_1796.Invoke_O_O__O(arg_1797, arg_1798) } else { arg_1793 = linked_1795.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1794, arg_1797, arg_1798) }; if linked_1790 == nil { tmp40 = ifn_1791.Invoke_O_O__O(arg_1792, arg_1793) } else { tmp40 = linked_1790.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1789, arg_1792, arg_1793) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp39, jrt.RefArrayOf(jrt.Object_class, nil, tmp40, nil)).Ref() }
//line :598:1
										default:
										}





















										return lang.IFn_Cast(A_arbace_go_check_types_A_const_186.GetRawRoot__O()).Invoke_O__O(t__0) } else {
//line :592:1
											return nil
										}
								}
						}
				}
		}
}
















func A_arbace_go_check_types_type_str_iter__219000239__219000243_A_New() *A_arbace_go_check_types_type_str_iter__219000239__219000243_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000239__219000243_A{}; t.Ctor(); return t }
//line :615:1
func (t *A_arbace_go_check_types_type_str_iter__219000239__219000243_A) Ctor() {}
//line :615:1
func (t *A_arbace_go_check_types_type_str_iter__219000239__219000243_A) Invoke_O_O__O(self, s__219000240__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1732 any = A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A_New_O_O(s__219000240__1, self); var tmp2 *jrt.Class; var fncls__1731 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A_fn_class; if fncls__1731 == nil { var fncls__1731d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, fnbody__1732); A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A_fn_class = fncls__1731d; tmp2 = fncls__1731d } else { tmp2 = fncls__1731 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1732, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :615:1
func A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A{}; t.Ctor_O_O(p0, p1); return t }
//line :615:1
func (t *A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A) Ctor_O_O(c__s__219000240, c__iter__219000239 any) { t.F_s__219000240 = c__s__219000240; t.F_iter__219000239 = c__iter__219000239 }
//line :615:1
func (t *A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A) Invoke_O__O(self any) any { { var s__219000240__1 any; var t_ any = t.F_s__219000240; t.F_s__219000240 = nil; s__219000240__1 = t_; for { var temp__1927000414__auto____2 any; var root_1665 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1665, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1667 lang.IFn; if linked_1666 == nil { ifn_1667 = lang.IFn_Cast(root_1665) } else { ifn_1667 = nil }; var arg_1668 any = s__219000240__1; if linked_1666 == nil { temp__1927000414__auto____2 = ifn_1667.Invoke_O__O(arg_1668) } else { temp__1927000414__auto____2 = linked_1666.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1665, arg_1668) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000240__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1669 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); var linked_1670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1669, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1671 lang.IFn; if linked_1670 == nil { ifn_1671 = lang.IFn_Cast(root_1669) } else { ifn_1671 = nil }; var arg_1672 any = s__219000240__3; if linked_1670 == nil { tmp1 = ifn_1671.Invoke_O__O(arg_1672) } else { tmp1 = linked_1670.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1669, arg_1672) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1673 any = A_arbace_go_check_types_A_const_155.GetRawRoot__O(); var linked_1674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1673, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1675 lang.IFn; if linked_1674 == nil { ifn_1675 = lang.IFn_Cast(root_1673) } else { ifn_1675 = nil }; var arg_1676 any = s__219000240__3; if linked_1674 == nil { c__1927001037__auto____4 = ifn_1675.Invoke_O__O(arg_1676) } else { c__1927001037__auto____4 = linked_1674.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1673, arg_1676) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000242__6 any; var root_1677 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); var linked_1678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1677, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1679 lang.IFn; if linked_1678 == nil { ifn_1679 = lang.IFn_Cast(root_1677) } else { ifn_1679 = nil }; var arg_1680 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1678 == nil { b__219000242__6 = ifn_1679.Invoke_O__O(arg_1680) } else { b__219000242__6 = linked_1678.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1677, arg_1680) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1691 any = A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A_New_O_I_O(b__219000242__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1690 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A_fn_class; if fncls__1690 == nil { var fncls__1690d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, fnbody__1691); A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A_fn_class = fncls__1690d; tmp3 = fncls__1690d } else { tmp3 = fncls__1690 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1691, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1692 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_1693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1692, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1694 lang.IFn; if linked_1693 == nil { ifn_1694 = lang.IFn_Cast(root_1692) } else { ifn_1694 = nil }; var arg_1695 any; var root_1697 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_1698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1697, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1699 lang.IFn; if linked_1698 == nil { ifn_1699 = lang.IFn_Cast(root_1697) } else { ifn_1699 = nil }; var arg_1700 any = b__219000242__6; if linked_1698 == nil { arg_1695 = ifn_1699.Invoke_O__O(arg_1700) } else { arg_1695 = linked_1698.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1697, arg_1700) }; var arg_1696 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000239); var tmp5 any; var root_1701 any = A_arbace_go_check_types_A_const_161.GetRawRoot__O(); var linked_1702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1701, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1703 lang.IFn; if linked_1702 == nil { ifn_1703 = lang.IFn_Cast(root_1701) } else { ifn_1703 = nil }; var arg_1704 any = s__219000240__3; if linked_1702 == nil { tmp5 = ifn_1703.Invoke_O__O(arg_1704) } else { tmp5 = linked_1702.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1701, arg_1704) }; arg_1696 = tmp4.Invoke_O__O(tmp5); if linked_1693 == nil { return ifn_1694.Invoke_O_O__O(arg_1695, arg_1696) } else { return linked_1693.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1692, arg_1695, arg_1696) } } else { var root_1705 any = A_arbace_go_check_types_A_const_159.GetRawRoot__O(); var linked_1706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1705, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1707 lang.IFn; if linked_1706 == nil { ifn_1707 = lang.IFn_Cast(root_1705) } else { ifn_1707 = nil }; var arg_1708 any; var root_1710 any = A_arbace_go_check_types_A_const_160.GetRawRoot__O(); var linked_1711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1710, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1712 lang.IFn; if linked_1711 == nil { ifn_1712 = lang.IFn_Cast(root_1710) } else { ifn_1712 = nil }; var arg_1713 any = b__219000242__6; if linked_1711 == nil { arg_1708 = ifn_1712.Invoke_O__O(arg_1713) } else { arg_1708 = linked_1711.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1710, arg_1713) }; var arg_1709 any; if linked_1706 == nil { return ifn_1707.Invoke_O_O__O(arg_1708, arg_1709) } else { return linked_1706.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1705, arg_1708, arg_1709) } } } else { var m__4 any; var root_1714 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_1715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1714, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1716 lang.IFn; if linked_1715 == nil { ifn_1716 = lang.IFn_Cast(root_1714) } else { ifn_1716 = nil }; var arg_1717 any = s__219000240__3; if linked_1715 == nil { m__4 = ifn_1716.Invoke_O__O(arg_1717) } else { m__4 = linked_1715.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1714, arg_1717) }; var root_1718 any = A_arbace_go_check_types_A_const_162.GetRawRoot__O(); var linked_1719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1718, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1720 lang.IFn; if linked_1719 == nil { ifn_1720 = lang.IFn_Cast(root_1718) } else { ifn_1720 = nil }; var arg_1721 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__4); var tmp8 any; var root_1723 any = A_arbace_go_check_types_A_const_201.GetRawRoot__O(); var linked_1724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1723, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1725 lang.IFn; if linked_1724 == nil { ifn_1725 = lang.IFn_Cast(root_1723) } else { ifn_1725 = nil }; var arg_1726 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(m__4); if linked_1724 == nil { tmp8 = ifn_1725.Invoke_O__O(arg_1726) } else { tmp8 = linked_1724.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1723, arg_1726) }; arg_1721 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8)).Ref(); var arg_1722 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__219000239); var tmp10 any; var root_1727 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1727, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1729 lang.IFn; if linked_1728 == nil { ifn_1729 = lang.IFn_Cast(root_1727) } else { ifn_1729 = nil }; var arg_1730 any = s__219000240__3; if linked_1728 == nil { tmp10 = ifn_1729.Invoke_O__O(arg_1730) } else { tmp10 = linked_1728.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1727, arg_1730) }; arg_1722 = tmp9.Invoke_O__O(tmp10); if linked_1719 == nil { return ifn_1720.Invoke_O_O__O(arg_1721, arg_1722) } else { return linked_1719.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1718, arg_1721, arg_1722) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :615:1
func A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :615:1
func (t *A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A) Ctor_O_I_O(c__b__219000242 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000242 = c__b__219000242; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :615:1
func (t *A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A) Invoke_O__O(self any) any { { var i__219000241__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000241__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000241__1)); var root_1681 any = A_arbace_go_check_types_A_const_158.GetRawRoot__O(); var linked_1682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1681, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1683 lang.IFn; if linked_1682 == nil { ifn_1683 = lang.IFn_Cast(root_1681) } else { ifn_1683 = nil }; var arg_1684 any = t.F_b__219000242; var arg_1685 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__2); var tmp4 any; var root_1686 any = A_arbace_go_check_types_A_const_201.GetRawRoot__O(); var linked_1687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1686, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1688 lang.IFn; if linked_1687 == nil { ifn_1688 = lang.IFn_Cast(root_1686) } else { ifn_1688 = nil }; var arg_1689 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(m__2); if linked_1687 == nil { tmp4 = ifn_1688.Invoke_O__O(arg_1689) } else { tmp4 = linked_1687.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1686, arg_1689) }; arg_1685 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref(); if linked_1682 == nil { ifn_1683.Invoke_O_O__O(arg_1684, arg_1685) } else { linked_1682.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1681, arg_1684, arg_1685) }; i__219000241__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000241__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }














func A_arbace_go_check_types_align_up_A_New() *A_arbace_go_check_types_align_up_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_align_up_A{}; t.Ctor(); return t }
//line :630:1
func (t *A_arbace_go_check_types_align_up_A) Ctor() {}
//line :630:1
func (t *A_arbace_go_check_types_align_up_A) InvokePrim_O_J_J__J(self any, x__0, a__1 int64) int64 {


	return lang.Numbers_AndNot_J_J__J_NoInit(lang.Numbers_Unchecked_add_J_J__J_NoInit(x__0, lang.Numbers_Dec_J__J_NoInit(a__1)), lang.Numbers_Dec_J__J_NoInit(a__1)) }
//line :630:1
func (t *A_arbace_go_check_types_align_up_A) Invoke_O_O_O__O(self, p_x__0, p_a__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_J__J(self, lang.RT_LongCast_O__J_NoInit(p_x__0), lang.RT_LongCast_O__J_NoInit(p_a__1))).Ref() }




func A_arbace_go_check_types_sync_atomic_align64_QMARK__A_New() *A_arbace_go_check_types_sync_atomic_align64_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sync_atomic_align64_QMARK__A{}; t.Ctor(); return t }
//line :635:1
func (t *A_arbace_go_check_types_sync_atomic_align64_QMARK__A) Ctor() {}
//line :635:1
func (t *A_arbace_go_check_types_sync_atomic_align64_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_1799 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_1800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1799, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1801 lang.IFn; if



	linked_1800 == nil { ifn_1801 = lang.IFn_Cast(root_1799) } else { ifn_1801 = nil }; var arg_1802 any = t__0; if linked_1800 == nil { and__1927000168__auto____2 = ifn_1801.Invoke_O__O(arg_1802) } else { and__1927000168__auto____2 = linked_1800.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1799, arg_1802) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var i__3 any; var root_1803 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_1804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1803, A_arbace_go_check_types_info_A_fn_class); var ifn_1805 lang.IFn
		if linked_1804 == nil { ifn_1805 = lang.IFn_Cast(root_1803) } else { ifn_1805 = nil }; var arg_1806 any = t__0; if linked_1804 == nil { i__3 = ifn_1805.Invoke_O__O(arg_1806) } else { i__3 = linked_1804.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1803, arg_1806) }
//line :639:1
		var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_44, A_arbace_go_check_types_A_const_12.Invoke_O__O(i__3))

		if and__1927000168__auto____4 {
			var root_1807 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1807, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1809 lang.IFn; if linked_1808 == nil { ifn_1809 = lang.IFn_Cast(root_1807) } else { ifn_1809 = nil }; var arg_1810 any = A_arbace_go_check_types_A_const_206; var arg_1811 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(i__3); if linked_1808 == nil { return ifn_1809.Invoke_O_O__O(arg_1810, arg_1811) } else { return linked_1808.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1807, arg_1810, arg_1811) } } else {
//line :641:1
				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else {
//line :639:1
					return and__1927000168__auto____2 } }




func A_arbace_go_check_types_alignof_A_New() *A_arbace_go_check_types_alignof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alignof_A{}; t.Ctor(); return t }
//line :644:1
func (t *A_arbace_go_check_types_alignof_A) Ctor() {}
//line :644:1
func (t *A_arbace_go_check_types_alignof_A) InvokePrim_O_O__J(self, t__0 any) int64 { var tmp1 any; var u__2 any; var root_1812 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_1813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1812, A_arbace_go_check_types_under_A_fn_class); var ifn_1814 lang.IFn; if
											linked_1813 == nil { ifn_1814 = lang.IFn_Cast(root_1812) } else { ifn_1814 = nil }; var arg_1815 any = t__0; if linked_1813 == nil { u__2 = ifn_1814.Invoke_O__O(arg_1815) } else { u__2 = linked_1813.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1812, arg_1815) }; var tmp2 any; var and__1927000168__auto____3 any; var root_1816 any =
											A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_1817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1816, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1818 lang.IFn; if
											linked_1817 == nil { ifn_1818 = lang.IFn_Cast(root_1816) } else { ifn_1818 = nil }; var arg_1819 any = u__2; if linked_1817 == nil { and__1927000168__auto____3 = ifn_1818.Invoke_O__O(arg_1819) } else { and__1927000168__auto____3 = linked_1817.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1816, arg_1819) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_go_check_types_A_const_74; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp2 = and__1927000168__auto____3 }; if /*line :646:1*/ jrt.J2g_Truth(tmp2) {
												var root_1820 any = A_arbace_go_check_types_A_const_207.GetRawRoot__O(); var linked_1821 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1820, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1822 lang.IFn; if linked_1821 == nil { ifn_1822 = lang.IFn_Cast(root_1820) } else { ifn_1822 = nil }; var arg_1823 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)); if linked_1821 == nil { tmp1 = ifn_1822.Invoke_O__O(arg_1823) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_1821.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1820, arg_1823)).Ref() } } else {
//line :646:1
			var tmp4 any; var and__1927000168__auto____3_2 any; var root_1824 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_1825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1824, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1826 lang.IFn

			if linked_1825 == nil { ifn_1826 = lang.IFn_Cast(root_1824) } else { ifn_1826 = nil }; var arg_1827 any = u__2; if linked_1825 == nil { and__1927000168__auto____3_2 = ifn_1826.Invoke_O__O(arg_1827) } else { and__1927000168__auto____3_2 = linked_1825.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1824, arg_1827) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) { var tmp5 any = A_arbace_go_check_types_A_const_82; tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp5, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp4 = and__1927000168__auto____3_2 }
//line :646:1
			if jrt.J2g_Truth(tmp4) {


				var tmp6 any; var and__1927000168__auto____3_3 any; var root_1828 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1830 lang.IFn; if linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; var arg_1831 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1829 == nil { and__1927000168__auto____3_3 = ifn_1830.Invoke_O__O(arg_1831) } else { and__1927000168__auto____3_3 = linked_1829.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1828, arg_1831) }; if jrt.J2g_Truth(and__1927000168__auto____3_3) { var root_1832 any = A_arbace_go_check_types_A_const_208.GetRawRoot__O(); var linked_1833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1832, A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class); var ifn_1834 lang.IFn; if linked_1833 == nil { ifn_1834 = lang.IFn_Cast(root_1832) } else { ifn_1834 = nil }; var arg_1835 any = t__0; if linked_1833 == nil { tmp6 = ifn_1834.Invoke_O__O(arg_1835) } else { tmp6 = linked_1833.(*A_arbace_go_check_types_sync_atomic_align64_QMARK__A).Invoke_O_O__O(root_1832, arg_1835) } } else { tmp6 = and__1927000168__auto____3_3 }; if jrt.J2g_Truth(tmp6) { tmp1 = A_arbace_go_check_types_A_const_24 } else {

					var root_1836 any = A_arbace_go_check_types_A_const_209.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any; var fnbody__1847 any = A_arbace_go_check_types_alignof_fn__219000253_A_New(); var tmp7 *jrt.Class; var fncls__1846 *jrt.Class = A_arbace_go_check_types_alignof_fn__219000253_A_fn_class; if fncls__1846 == nil { var fncls__1846d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); A_arbace_go_check_types_alignof_fn__219000253_A_fn_class = fncls__1846d; tmp7 = fncls__1846d } else { tmp7 = fncls__1846 }; arg_1839 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1847, tmp7, nil); var arg_1840 any = A_arbace_go_check_types_A_const_15; var arg_1841 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1837 == nil { tmp1 = ifn_1838.Invoke_O_O_O__O(arg_1839, arg_1840, arg_1841) } else { tmp1 = linked_1837.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1836, arg_1839, arg_1840, arg_1841) } } } else {
//line :646:1
						var tmp8 any; var and__1927000168__auto____3_4 any; var root_1848 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1848, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1850 lang.IFn





						if linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = u__2; if linked_1849 == nil { and__1927000168__auto____3_4 = ifn_1850.Invoke_O__O(arg_1851) } else { and__1927000168__auto____3_4 = linked_1849.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1848, arg_1851) }; if jrt.J2g_Truth(and__1927000168__auto____3_4) { var root_1852 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = A_arbace_go_check_types_A_const_210; var arg_1856 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)); if linked_1853 == nil { tmp8 = ifn_1854.Invoke_O_O__O(arg_1855, arg_1856) } else { tmp8 = linked_1853.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1852, arg_1855, arg_1856) } } else { tmp8 = and__1927000168__auto____3_4 }
//line :646:1
						if jrt.J2g_Truth(tmp8) { tmp1 = A_arbace_go_check_types_A_const_211.GetRawRoot__O() } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_40, u__2) { tmp1 = A_arbace_go_check_types_A_const_211.GetRawRoot__O() } else { if A_arbace_go_check_types_A_const_86 != nil { var a__3 any; var root_1857 any = A_arbace_go_check_types_A_const_212.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1857, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1859 lang.IFn








							if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any = t__0; if linked_1858 == nil { a__3 = ifn_1859.Invoke_O__O(arg_1860) } else { a__3 = jrt.Long_ValueOf_J__Long_NoInit(linked_1858.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1857, arg_1860)).Ref() }
//line :646:1
							var a__4 any; var tmp9 bool
							var na_1861 any = a__3
							var na_1862 int64 = 1







							if jrt.Long_InstanceOf(na_1861) { var n0_1863 int64 = jrt.NN(jrt.Long_Cast(na_1861)).LongValue__J(); var n1_1864 int64 = na_1862; tmp9 = n0_1863 < n1_1864 } else { tmp9 = lang.Numbers_Lt_O_J__Z_NoInit(na_1861, na_1862) }; if tmp9 { a__4 = A_arbace_go_check_types_A_const_15 } else { a__4 = a__3 }
//line :646:1
							var a__5 any; var tmp10 any; var root_1866 any = A_arbace_go_check_types_A_const_114.GetRawRoot__O(); var linked_1867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1866, A_arbace_go_check_types_complex_type_QMARK__A_fn_class); var ifn_1868 lang.IFn










							if linked_1867 == nil { ifn_1868 = lang.IFn_Cast(root_1866) } else { ifn_1868 = nil }; var arg_1869 any = t__0; if linked_1867 == nil { tmp10 = ifn_1868.Invoke_O__O(arg_1869) } else { tmp10 = linked_1867.(*A_arbace_go_check_types_complex_type_QMARK__A).Invoke_O_O__O(root_1866, arg_1869) }; if jrt.J2g_Truth(tmp10) { var na_1870 any = a__4; var na_1871 int64 = 2; if jrt.Long_InstanceOf(na_1870) { var n0_1872 int64 = jrt.NN(jrt.Long_Cast(na_1870)).LongValue__J(); var n1_1873 int64 = na_1871; if n1_1873 == 0 { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1870, na_1871) } else { a__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_1872 / n1_1873).Ref() } } else { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1870, na_1871) } } else { a__5 = a__4 }
							tmp1 = lang.Numbers_Min_O_O__O_NoInit(a__5, A_arbace_go_check_types_A_const_213.GetRawRoot__O()) } else {
//line :646:1
								tmp1 = nil } } } } }; return /*line :644:1*/ jrt.Number_Cast(tmp1).LongValue__J() }
//line :644:1
func (t *A_arbace_go_check_types_alignof_A) Invoke_O_O__O(self, t__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, t__0)).Ref() }






func A_arbace_go_check_types_alignof_fn__219000253_A_New() *A_arbace_go_check_types_alignof_fn__219000253_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alignof_fn__219000253_A{}; t.Ctor(); return t }
//line :651:1
func (t *A_arbace_go_check_types_alignof_fn__219000253_A) Ctor() {}
//line :651:1
func (t *A_arbace_go_check_types_alignof_fn__219000253_A) Invoke_O_O_O__O(self, m__1, f__2 any) any { var tmp1 int64; var root_1842 any = A_arbace_go_check_types_A_const_207.GetRawRoot__O(); var linked_1843 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1842, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1844 lang.IFn; if linked_1843 == nil { ifn_1844 = lang.IFn_Cast(root_1842) } else { ifn_1844 = nil }; var arg_1845 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(f__2); if linked_1843 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_1844.Invoke_O__O(arg_1845)) } else { tmp1 = linked_1843.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1842, arg_1845) }; return lang.Numbers_Max_O_J__O_NoInit(m__1, tmp1) }








func A_arbace_go_check_types_offsetsof_A_New() *A_arbace_go_check_types_offsetsof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_offsetsof_A{}; t.Ctor(); return t }
//line :660:1
func (t *A_arbace_go_check_types_offsetsof_A) Ctor() {}
//line :660:1
func (t *A_arbace_go_check_types_offsetsof_A) Invoke_O_O__O(self, fields__0 any) any { { var fs__2 any = fields__0; var offs__3 any = lang.RT_Box_J__Number_NoInit(0); var acc__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




	var tmp1 any; var root_1875 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1875, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1877 lang.IFn; if linked_1876 == nil { ifn_1877 = lang.IFn_Cast(root_1875) } else { ifn_1877 = nil }; var arg_1878 any = fs__2; if linked_1876 == nil { tmp1 = ifn_1877.Invoke_O__O(arg_1878) } else { tmp1 = linked_1876.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1875, arg_1878) }; if jrt.J2g_Truth(tmp1) { return acc__4 } else { var f__5 any; var root_1879 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_1880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1879, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1881 lang.IFn

		if linked_1880 == nil { ifn_1881 = lang.IFn_Cast(root_1879) } else { ifn_1881 = nil }; var arg_1882 any = fs__2; if linked_1880 == nil { f__5 = ifn_1881.Invoke_O__O(arg_1882) } else { f__5 = linked_1880.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1879, arg_1882) }
		var tmp2 bool; var na_1883 any = offs__3; if jrt.Long_InstanceOf(na_1883) { var n0_1884 int64 = jrt.NN(jrt.Long_Cast(na_1883)).LongValue__J(); tmp2 = n0_1884 < 0 } else { if jrt.Double_InstanceOf(na_1883) { var n0_1884_2 float64 = jrt.NN(jrt.Double_Cast(na_1883)).DoubleValue__D(); tmp2 = n0_1884_2 < 0.0 } else { tmp2 = lang.Numbers_IsNeg_O__Z_NoInit(na_1883) } }; if tmp2 {
			var tmp3 any; var root_1898 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1898, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1900 lang.IFn; if linked_1899 == nil { ifn_1900 = lang.IFn_Cast(root_1898) } else { ifn_1900 = nil }; var arg_1901 any = fs__2; if linked_1899 == nil { tmp3 = ifn_1900.Invoke_O__O(arg_1901) } else { tmp3 = linked_1899.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1898, arg_1901) }; var tmp4 any = tmp3; var tmp5 any; var root_1902 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1903 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1902, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1904 lang.IFn; if linked_1903 == nil { ifn_1904 = lang.IFn_Cast(root_1902) } else { ifn_1904 = nil }; var arg_1905 any = acc__4; var arg_1906 any = A_arbace_go_check_types_A_const_215; if linked_1903 == nil { tmp5 = ifn_1904.Invoke_O_O__O(arg_1905, arg_1906) } else { tmp5 = linked_1903.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1902, arg_1905, arg_1906) }; fs__2, offs__3, acc__4 = tmp4, offs__3, tmp5; continue L1 } else {
//line :668:1
				var o__6 any; var root_1885 any = A_arbace_go_check_types_A_const_214.GetRawRoot__O(); var linked_1886 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1885, A_arbace_go_check_types_align_up_A_fn_class); var ifn_1887 lang.IFn

				if linked_1886 == nil { ifn_1887 = lang.IFn_Cast(root_1885) } else { ifn_1887 = nil }; var arg_1888 any = offs__3; var arg_1889 any; var root_1890 any = A_arbace_go_check_types_A_const_207.GetRawRoot__O(); var linked_1891 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1890, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1892 lang.IFn; if linked_1891 == nil { ifn_1892 = lang.IFn_Cast(root_1890) } else { ifn_1892 = nil }; var arg_1893 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(f__5); if linked_1891 == nil { arg_1889 = ifn_1892.Invoke_O__O(arg_1893) } else { arg_1889 = jrt.Long_ValueOf_J__Long_NoInit(linked_1891.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1890, arg_1893)).Ref() }; if linked_1886 == nil { o__6 = ifn_1887.Invoke_O_O__O(arg_1888, arg_1889) } else { o__6 = jrt.Long_ValueOf_J__Long_NoInit(linked_1886.(*A_arbace_go_check_types_align_up_A).InvokePrim_O_J_J__J(root_1885, lang.RT_LongCast_O__J_NoInit(arg_1888), lang.RT_LongCast_O__J_NoInit(arg_1889))).Ref() }
//line :668:1
				var d__7 any; var root_1894 any = A_arbace_go_check_types_A_const_212.GetRawRoot__O(); var linked_1895 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1894, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1896 lang.IFn


				if linked_1895 == nil { ifn_1896 = lang.IFn_Cast(root_1894) } else { ifn_1896 = nil }; var arg_1897 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(f__5); if linked_1895 == nil { d__7 = ifn_1896.Invoke_O__O(arg_1897) } else { d__7 = jrt.Long_ValueOf_J__Long_NoInit(linked_1895.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1894, arg_1897)).Ref() }
				var tmp6 any; var root_1907 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1907, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1909 lang.IFn; if linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = fs__2; if linked_1908 == nil { tmp6 = ifn_1909.Invoke_O__O(arg_1910) } else { tmp6 = linked_1908.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1907, arg_1910) }; var tmp7 any = tmp6; var tmp8 any; var tmp9 bool; var and__1927000168__auto____8 bool; var na_1911 any = d__7; var na_1912 int64 = 0
				if jrt.Long_InstanceOf(na_1911) { var n0_1913 int64 = jrt.NN(jrt.Long_Cast(na_1911)).LongValue__J(); var n1_1914 int64 = na_1912; and__1927000168__auto____8 = n0_1913 >= n1_1914 } else { and__1927000168__auto____8 = lang.Numbers_Gte_O_J__Z_NoInit(na_1911, na_1912) }; if and__1927000168__auto____8 { var na_1916 any = o__6; var na_1917 int64 = 0; if jrt.Long_InstanceOf(na_1916) { var n0_1918 int64 = jrt.NN(jrt.Long_Cast(na_1916)).LongValue__J(); var n1_1919 int64 = na_1917; tmp9 = n0_1918 >= n1_1919 } else { tmp9 = lang.Numbers_Gte_O_J__Z_NoInit(na_1916, na_1917) } } else { tmp9 = and__1927000168__auto____8 }; if tmp9 { var na_1921 any = o__6; var na_1922 any = d__7; var tmp10 bool; var tmp11 bool; tmp11 = jrt.Long_InstanceOf(na_1921); if tmp11 { tmp11 = jrt.Long_InstanceOf(na_1922) }; tmp10 = tmp11; if tmp10 { var n0_1923 int64 = jrt.NN(jrt.Long_Cast(na_1921)).LongValue__J(); var n1_1924 int64 = jrt.NN(jrt.Long_Cast(na_1922)).LongValue__J(); tmp8 = jrt.Long_ValueOf_J__Long_NoInit(n0_1923 + n1_1924).Ref() } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_1921); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_1922) }; tmp12 = tmp13; if tmp12 { var n0_1923_2 float64 = jrt.NN(jrt.Double_Cast(na_1921)).DoubleValue__D(); var n1_1924_2 float64 = jrt.NN(jrt.Double_Cast(na_1922)).DoubleValue__D(); tmp8 = jrt.Double_ValueOf_D__Double_NoInit(n0_1923_2 + n1_1924_2).Ref() } else { tmp8 = lang.Numbers_Unchecked_add_O_O__Number_NoInit(na_1921, na_1922) } } } else { tmp8 = A_arbace_go_check_types_A_const_215 }
//line :672:1
				var tmp14 any = tmp8; var tmp15 any; var root_1926 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1927 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1926, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1928 lang.IFn

				if linked_1927 == nil { ifn_1928 = lang.IFn_Cast(root_1926) } else { ifn_1928 = nil }; var arg_1929 any = acc__4; var arg_1930 any = o__6; if linked_1927 == nil { tmp15 = ifn_1928.Invoke_O_O__O(arg_1929, arg_1930) } else { tmp15 = linked_1927.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1926, arg_1929, arg_1930) }
//line :672:1
				fs__2, offs__3, acc__4 = tmp7, tmp14, tmp15; continue L1 } } } }; /*line :660:1*/panic("j2g: unreachable") }















func A_arbace_go_check_types_sizeof_A_New() *A_arbace_go_check_types_sizeof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sizeof_A{}; t.Ctor(); return t }
//line :676:1
func (t *A_arbace_go_check_types_sizeof_A) Ctor() {}
//line :676:1
func (t *A_arbace_go_check_types_sizeof_A) InvokePrim_O_O__J(self, t__0 any) int64 { var tmp1 any; var u__2 any; var root_1931 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_1932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1931, A_arbace_go_check_types_under_A_fn_class); var ifn_1933 lang.IFn; if


	linked_1932 == nil { ifn_1933 = lang.IFn_Cast(root_1931) } else { ifn_1933 = nil }; var arg_1934 any = t__0; if linked_1932 == nil { u__2 = ifn_1933.Invoke_O__O(arg_1934) } else { u__2 = linked_1932.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1931, arg_1934) }; var tmp2 any; var root_1935 any =
	A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_1936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1935, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_1937 lang.IFn; if
	linked_1936 == nil { ifn_1937 = lang.IFn_Cast(root_1935) } else { ifn_1937 = nil }; var arg_1938 any = u__2; if linked_1936 == nil { tmp2 = ifn_1937.Invoke_O__O(arg_1938) } else { tmp2 = linked_1936.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_1935, arg_1938) }; if /*line :680:1*/ jrt.J2g_Truth(tmp2) { var G__219000257__3_ any = u__2
	L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__219000257__3_) { case 717828005: if any(G__219000257__3_) == any(A_arbace_go_check_types_A_const_40) { var na_1940 int64 = 2; var na_1941 any = A_arbace_go_check_types_A_const_211.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1941) { var n0_1942 int64 = na_1940; var n1_1943 int64 = jrt.NN(jrt.Long_Cast(na_1941)).LongValue__J(); var nr_1944 int64 = n0_1942 * n1_1943; var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; tmp6 = n0_1942 == -9223372036854775808; if tmp6 { tmp6 = n1_1943 < 0 }; tmp5 = tmp6; tmp4 = !tmp5; if tmp4 { var tmp7 bool; tmp7 = n1_1943 == 0; if !tmp7 { tmp7 = nr_1944/n1_1943 == n0_1942 }; tmp4 = tmp7 }; tmp3 = tmp4; if tmp3 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1944).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1940, na_1941) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1940, na_1941) }; break L1 }; default:}; var tmp8 lang.IFn = A_arbace_go_check_types_A_const_11; tmp1 = tmp8.Invoke_O_O__O(lang.IFn_Cast(A_arbace_go_check_types_A_const_110.GetRawRoot__O()).Invoke_O__O(u__2), A_arbace_go_check_types_A_const_211.GetRawRoot__O())} } else {
//line :680:1
		if A_arbace_go_check_types_A_const_86 != nil { var G__219000258__3_ any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0))


		L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__219000258__3_) >> 5 & 3 { case 0: if any(G__219000258__3_) == any(A_arbace_go_check_types_A_const_74) { var n__4 int64 = lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)))

			if lang.Numbers_Lte_J_J__Z_NoInit(n__4, 0) { tmp1 = A_arbace_go_check_types_A_const_44 } else { var es__5 any; var root_1946 any = A_arbace_go_check_types_A_const_212.GetRawRoot__O(); var linked_1947 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1946, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1948 lang.IFn

				if linked_1947 == nil { ifn_1948 = lang.IFn_Cast(root_1946) } else { ifn_1948 = nil }; var arg_1949 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)); if linked_1947 == nil { es__5 = ifn_1948.Invoke_O__O(arg_1949) } else { es__5 = jrt.Long_ValueOf_J__Long_NoInit(linked_1947.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1946, arg_1949)).Ref() }
				var tmp9 bool; var na_1950 any = es__5
				if jrt.Long_InstanceOf(na_1950) { var n0_1951 int64 = jrt.NN(jrt.Long_Cast(na_1950)).LongValue__J(); tmp9 = n0_1951 < 0 } else { if jrt.Double_InstanceOf(na_1950) { var n0_1951_2 float64 = jrt.NN(jrt.Double_Cast(na_1950)).DoubleValue__D(); tmp9 = n0_1951_2 < 0.0 } else { tmp9 = lang.Numbers_IsNeg_O__Z_NoInit(na_1950) } }
//line :688:1
				if tmp9 { tmp1 = A_arbace_go_check_types_A_const_215 } else { var tmp10 bool
					var na_1952 any = es__5
					if jrt.Long_InstanceOf(na_1952) { var n0_1953 int64 = jrt.NN(jrt.Long_Cast(na_1952)).LongValue__J(); tmp10 = n0_1953 == 0 } else { if jrt.Double_InstanceOf(na_1952) { var n0_1953_2 float64 = jrt.NN(jrt.Double_Cast(na_1952)).DoubleValue__D(); tmp10 = n0_1953_2 == 0.0 } else { tmp10 = lang.Numbers_IsZero_O__Z_NoInit(na_1952) } }
//line :688:1
					if tmp10 { tmp1 = A_arbace_go_check_types_A_const_44 } else { var tmp11 bool; var na_1954 any = es__5; var na_1955 int64 = lang.Numbers_Quotient_J_J__J_NoInit(9223372036854775807, n__4)


						if jrt.Long_InstanceOf(na_1954) { var n0_1956 int64 = jrt.NN(jrt.Long_Cast(na_1954)).LongValue__J(); var n1_1957 int64 = na_1955; tmp11 = n0_1956 > n1_1957 } else { tmp11 = lang.Numbers_Gt_O_J__Z_NoInit(na_1954, na_1955) }
//line :688:1
						if tmp11 { tmp1 = A_arbace_go_check_types_A_const_215 } else { if A_arbace_go_check_types_A_const_86 != nil {



							var na_1959 any = es__5; var na_1960 int64 = n__4; if jrt.Long_InstanceOf(na_1959) { var n0_1961 int64 = jrt.NN(jrt.Long_Cast(na_1959)).LongValue__J(); var n1_1962 int64 = na_1960; var nr_1963 int64 = n0_1961 * n1_1962; var tmp12 bool; var tmp13 bool; var tmp14 bool; var tmp15 bool; tmp15 = n0_1961 == -9223372036854775808; if tmp15 { tmp15 = n1_1962 < 0 }; tmp14 = tmp15; tmp13 = !tmp14; if tmp13 { var tmp16 bool; tmp16 = n1_1962 == 0; if !tmp16 { tmp16 = nr_1963/n1_1962 == n0_1961 }; tmp13 = tmp16 }; tmp12 = tmp13; if tmp12 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1963).Ref() } else { tmp1 = lang.Numbers_Multiply_O_J__Number_NoInit(na_1959, na_1960) } } else { tmp1 = lang.Numbers_Multiply_O_J__Number_NoInit(na_1959, na_1960) } } else {
//line :688:1
								tmp1 = nil } } } } }
//line :683:1
			break L2 }; case 1: if any(G__219000258__3_) == any(A_arbace_go_check_types_A_const_71) {





















				var na_1964 int64 = 2; var na_1965 any = A_arbace_go_check_types_A_const_211.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1965) { var n0_1966 int64 = na_1964; var n1_1967 int64 = jrt.NN(jrt.Long_Cast(na_1965)).LongValue__J(); var nr_1968 int64 = n0_1966 * n1_1967; var tmp17 bool; var tmp18 bool; var tmp19 bool; var tmp20 bool; tmp20 = n0_1966 == -9223372036854775808; if tmp20 { tmp20 = n1_1967 < 0 }; tmp19 = tmp20; tmp18 = !tmp19; if tmp18 { var tmp21 bool; tmp21 = n1_1967 == 0; if !tmp21 { tmp21 = nr_1968/n1_1967 == n0_1966 }; tmp18 = tmp21 }; tmp17 = tmp18; if tmp17 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1968).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1964, na_1965) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1964, na_1965) }
//line :683:1
				break L2 }; case 2: if any(G__219000258__3_) == any(A_arbace_go_check_types_A_const_78) {









					var na_1969 int64 = 3; var na_1970 any = A_arbace_go_check_types_A_const_211.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1970) { var n0_1971 int64 = na_1969; var n1_1972 int64 = jrt.NN(jrt.Long_Cast(na_1970)).LongValue__J(); var nr_1973 int64 = n0_1971 * n1_1972; var tmp22 bool; var tmp23 bool; var tmp24 bool; var tmp25 bool; tmp25 = n0_1971 == -9223372036854775808; if tmp25 { tmp25 = n1_1972 < 0 }; tmp24 = tmp25; tmp23 = !tmp24; if tmp23 { var tmp26 bool; tmp26 = n1_1972 == 0; if !tmp26 { tmp26 = nr_1973/n1_1972 == n0_1971 }; tmp23 = tmp26 }; tmp22 = tmp23; if tmp22 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1973).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1969, na_1970) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1969, na_1970) }
//line :683:1
					break L2 }; case 3: if any(G__219000258__3_) == any(A_arbace_go_check_types_A_const_82) { var fs__4 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); var tmp27 any; var root_1974 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1976 lang.IFn











						if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = fs__4; if linked_1975 == nil { tmp27 = ifn_1976.Invoke_O__O(arg_1977) } else { tmp27 = linked_1975.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1974, arg_1977) }; if jrt.J2g_Truth(tmp27) { tmp1 = A_arbace_go_check_types_A_const_44 } else { var offs__5 any; var root_1978 any = A_arbace_go_check_types_A_const_216.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, A_arbace_go_check_types_offsetsof_A_fn_class); var ifn_1980 lang.IFn

							if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any = fs__4; if linked_1979 == nil { offs__5 = ifn_1980.Invoke_O__O(arg_1981) } else { offs__5 = linked_1979.(*A_arbace_go_check_types_offsetsof_A).Invoke_O_O__O(root_1978, arg_1981) }
//line :695:1
							var o__6 int64; var tmp28 any; var root_1982 any = A_arbace_go_check_types_A_const_217.GetRawRoot__O(); var linked_1983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1982, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_1984 lang.IFn


							if linked_1983 == nil { ifn_1984 = lang.IFn_Cast(root_1982) } else { ifn_1984 = nil }; var arg_1985 any = offs__5; if linked_1983 == nil { tmp28 = ifn_1984.Invoke_O__O(arg_1985) } else { tmp28 = linked_1983.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_1982, arg_1985) }; o__6 = lang.RT_LongCast_O__J_NoInit(tmp28)
//line :695:1
							var s__7 any; var root_1986 any = A_arbace_go_check_types_A_const_212.GetRawRoot__O(); var linked_1987 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1986, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1988 lang.IFn



							if linked_1987 == nil { ifn_1988 = lang.IFn_Cast(root_1986) } else { ifn_1988 = nil }; var arg_1989 any; var tmp29 *lang.Keyword = A_arbace_go_check_types_A_const_65; var tmp30 any; var root_1990 any = A_arbace_go_check_types_A_const_217.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1990, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_1992 lang.IFn; if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; var arg_1993 any = fs__4; if linked_1991 == nil { tmp30 = ifn_1992.Invoke_O__O(arg_1993) } else { tmp30 = linked_1991.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_1990, arg_1993) }; arg_1989 = tmp29.Invoke_O__O(tmp30); if linked_1987 == nil { s__7 = ifn_1988.Invoke_O__O(arg_1989) } else { s__7 = jrt.Long_ValueOf_J__Long_NoInit(linked_1987.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1986, arg_1989)).Ref() }
							var tmp31 bool; var or__1927000174__auto____8 bool = lang.Numbers_IsNeg_J__Z_NoInit(o__6); if or__1927000174__auto____8 { tmp31 = or__1927000174__auto____8 } else { var na_1994 any = s__7; if jrt.Long_InstanceOf(na_1994) { var n0_1995 int64 = jrt.NN(jrt.Long_Cast(na_1994)).LongValue__J(); tmp31 = n0_1995 < 0 } else { if jrt.Double_InstanceOf(na_1994) { var n0_1995_2 float64 = jrt.NN(jrt.Double_Cast(na_1994)).DoubleValue__D(); tmp31 = n0_1995_2 < 0.0 } else { tmp31 = lang.Numbers_IsNeg_O__Z_NoInit(na_1994) } } }; if tmp31 { tmp1 = A_arbace_go_check_types_A_const_215 } else { var s__8 any; var tmp32 bool; var and__1927000168__auto____8 bool = lang.Numbers_IsPos_J__Z_NoInit(o__6)

								if and__1927000168__auto____8 { var na_1996 any = s__7; if jrt.Long_InstanceOf(na_1996) { var n0_1997 int64 = jrt.NN(jrt.Long_Cast(na_1996)).LongValue__J(); tmp32 = n0_1997 == 0 } else { if jrt.Double_InstanceOf(na_1996) { var n0_1997_2 float64 = jrt.NN(jrt.Double_Cast(na_1996)).DoubleValue__D(); tmp32 = n0_1997_2 == 0.0 } else { tmp32 = lang.Numbers_IsZero_O__Z_NoInit(na_1996) } } } else { tmp32 = and__1927000168__auto____8 }; if tmp32 { s__8 = A_arbace_go_check_types_A_const_15 } else { s__8 = s__7
								}
								var root_1998 any = A_arbace_go_check_types_A_const_214.GetRawRoot__O(); var linked_1999 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1998, A_arbace_go_check_types_align_up_A_fn_class); var ifn_2000 lang.IFn; if linked_1999 == nil { ifn_2000 = lang.IFn_Cast(root_1998) } else { ifn_2000 = nil }; var arg_2001 any; var na_2003 int64 = o__6; var na_2004 any = s__8; if jrt.Long_InstanceOf(na_2004) { var n0_2005 int64 = na_2003; var n1_2006 int64 = jrt.NN(jrt.Long_Cast(na_2004)).LongValue__J(); arg_2001 = jrt.Long_ValueOf_J__Long_NoInit(n0_2005 + n1_2006).Ref() } else { arg_2001 = lang.Numbers_Unchecked_add_J_O__Number_NoInit(na_2003, na_2004) }; var arg_2002 any; var root_2008 any = A_arbace_go_check_types_A_const_207.GetRawRoot__O(); var linked_2009 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2008, A_arbace_go_check_types_alignof_A_fn_class); var ifn_2010 lang.IFn; if linked_2009 == nil { ifn_2010 = lang.IFn_Cast(root_2008) } else { ifn_2010 = nil }; var arg_2011 any = t__0; if linked_2009 == nil { arg_2002 = ifn_2010.Invoke_O__O(arg_2011) } else { arg_2002 = jrt.Long_ValueOf_J__Long_NoInit(linked_2009.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_2008, arg_2011)).Ref() }; if linked_1999 == nil { tmp1 = ifn_2000.Invoke_O_O__O(arg_2001, arg_2002) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_1999.(*A_arbace_go_check_types_align_up_A).InvokePrim_O_J_J__J(root_1998, lang.RT_LongCast_O__J_NoInit(arg_2001), lang.RT_LongCast_O__J_NoInit(arg_2002))).Ref() } } }
//line :683:1
						break L2 }; default:}; tmp1 = A_arbace_go_check_types_A_const_211.GetRawRoot__O()} } else {
//line :680:1
							tmp1 = nil } }; return /*line :676:1*/ jrt.Number_Cast(tmp1).LongValue__J() }
//line :676:1
func (t *A_arbace_go_check_types_sizeof_A) Invoke_O_O__O(self, t__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, t__0)).Ref() }

































func A_arbace_go_check_types_deref_type_A_New() *A_arbace_go_check_types_deref_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_deref_type_A{}; t.Ctor(); return t }
//line :710:1
func (t *A_arbace_go_check_types_deref_type_A) Ctor() {}
//line :710:1
func (t *A_arbace_go_check_types_deref_type_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_2012 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_2013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2012, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2014 lang.IFn; if linked_2013 == nil { ifn_2014 = lang.IFn_Cast(root_2012) } else { ifn_2014 = nil }; var arg_2015 any = t__0; if linked_2013 == nil { and__1927000168__auto____2 = ifn_2014.Invoke_O__O(arg_2015) } else { and__1927000168__auto____2 = linked_2013.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2012, arg_2015) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_types_A_const_73; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)), jrt.Boolean_TRUE.Ref()) } else { return lang.Tuple_Create_O_O__IPersistentVector(t__0, jrt.Boolean_FALSE.Ref())
	} }
func A_arbace_go_check_types_methods_of_A_New() *A_arbace_go_check_types_methods_of_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_methods_of_A{}; t.Ctor(); return t }
//line :715:1
func (t *A_arbace_go_check_types_methods_of_A) Ctor() {}
//line :715:1
func (t *A_arbace_go_check_types_methods_of_A) Invoke_O_O__O(self, t__0 any) any { var t__2 any; var tmp1 *lang.Keyword = A_arbace_go_check_types_A_const_218; var tmp2 any; var root_2016 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_2017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2016, A_arbace_go_check_types_info_A_fn_class); var ifn_2018 lang.IFn; if


	linked_2017 == nil { ifn_2018 = lang.IFn_Cast(root_2016) } else { ifn_2018 = nil }; var arg_2019 any = t__0; if linked_2017 == nil { tmp2 = ifn_2018.Invoke_O__O(arg_2019) } else { tmp2 = linked_2017.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_2016, arg_2019) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 *lang.Keyword = A_arbace_go_check_types_A_const_218; var tmp4 any; var root_2020 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_2021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2020, A_arbace_go_check_types_info_A_fn_class); var ifn_2022 lang.IFn; if linked_2021 == nil { ifn_2022 = lang.IFn_Cast(root_2020) } else { ifn_2022 = nil }; var arg_2023 any = t__0; if linked_2021 == nil { tmp4 = ifn_2022.Invoke_O__O(arg_2023) } else { tmp4 = linked_2021.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_2020, arg_2023) }; t__2 = tmp3.Invoke_O__O(tmp4) } else { t__2 = t__0 }; var root_2028 any =
	A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_2029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2028, A_arbace_go_check_types_under_A_fn_class); var ifn_2030 lang.IFn; if linked_2029 == nil { ifn_2030 = lang.IFn_Cast(root_2028) } else { ifn_2030 = nil }; var arg_2031 any = t__2; if linked_2029 == nil { ifn_2030.Invoke_O__O(arg_2031) } else { linked_2029.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2028, arg_2031) }; var tmp5 /*line :720:1*/*lang.Keyword = A_arbace_go_check_types_A_const_98; var tmp6 any; var root_2024 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_2025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2024, A_arbace_go_check_types_info_A_fn_class); var ifn_2026 lang.IFn; if linked_2025 == nil { ifn_2026 = lang.IFn_Cast(root_2024) } else { ifn_2026 = nil }; var arg_2027 any = t__2; if linked_2025 == nil { tmp6 = ifn_2026.Invoke_O__O(arg_2027) } else { tmp6 = linked_2025.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_2024, arg_2027) }; return tmp5.Invoke_O__O(tmp6) }





func A_arbace_go_check_types_same_id_QMARK__A_New() *A_arbace_go_check_types_same_id_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_same_id_QMARK__A{}; t.Ctor(); return t }
//line :726:1
func (t *A_arbace_go_check_types_same_id_QMARK__A) Ctor() {}
//line :726:1
func (t *A_arbace_go_check_types_same_id_QMARK__A) Invoke_O_O_O_O_O__O(self, n__0, p__1, name__2, pkg__3 any) any {



	var tmp1 any; var and__1927000168__auto____5 any = A_arbace_go_check_types_A_const_219.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.String_Cast(n__0)).EqualsIgnoreCase_String__Z(jrt.String_Cast(name__2))).Ref() } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, name__2)

		if and__1927000168__auto____5_2 { var or__1927000174__auto____6 bool = jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(name__2)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))
			if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(p__1, pkg__3); if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { return jrt.Boolean_FALSE.Ref() } } } else {
//line :732:1
				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref()
			}
	}
}


func A_arbace_go_check_types_exported_QMARK__A_New() *A_arbace_go_check_types_exported_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_exported_QMARK__A{}; t.Ctor(); return t }
//line :738:1
func (t *A_arbace_go_check_types_exported_QMARK__A) Ctor() {}
//line :738:1
func (t *A_arbace_go_check_types_exported_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var cp__2 int32 = jrt.NN(jrt.String_Cast(n__0)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(0)); return /*line :739:1*/ jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_I__Z_NoInit(cp__2)).Ref() }











func A_arbace_go_check_types_named_method_A_New() *A_arbace_go_check_types_named_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_method_A{}; t.Ctor(); return t }
//line :751:1
func (t *A_arbace_go_check_types_named_method_A) Ctor() {}
//line :751:1
func (t *A_arbace_go_check_types_named_method_A) Invoke_O_O_O_O__O(self, t__0, name__1, pkg__2 any) any { { var ms__4 any; var root_2032 any = A_arbace_go_check_types_A_const_220.GetRawRoot__O(); var linked_2033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2032, A_arbace_go_check_types_methods_of_A_fn_class); var ifn_2034 lang.IFn


	if linked_2033 == nil { ifn_2034 = lang.IFn_Cast(root_2032) } else { ifn_2034 = nil }; var arg_2035 any = t__0; if linked_2033 == nil { ms__4 = ifn_2034.Invoke_O__O(arg_2035) } else { ms__4 = linked_2033.(*A_arbace_go_check_types_methods_of_A).Invoke_O_O__O(root_2032, arg_2035) }
//line :751:1
	var i__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i__5, int64(lang.RT_Count_O__I_NoInit(ms__4))) { var m__6 any = lang.RT_Nth_O_I__O_NoInit(ms__4, lang.RT_IntCast_J__I_NoInit(i__5)); var map__219000264__7 any; var root_2036 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_2037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2036, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2038 lang.IFn
			if linked_2037 == nil { ifn_2038 = lang.IFn_Cast(root_2036) } else { ifn_2038 = nil }; var arg_2039 any = m__6; if linked_2037 == nil { map__219000264__7 = ifn_2038.Invoke_O__O(arg_2039) } else { map__219000264__7 = linked_2037.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2036, arg_2039) }
//line :756:1
			var map__219000264__8 any
			if lang.ISeq_InstanceOf(map__219000264__7) { var tmp1 any; var root_2040 any = A_arbace_go_check_types_A_const_221.GetRawRoot__O(); var linked_2041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2040, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2042 lang.IFn; if linked_2041 == nil { ifn_2042 = lang.IFn_Cast(root_2040) } else { ifn_2042 = nil }; var arg_2043 any = map__219000264__7; if linked_2041 == nil { tmp1 = ifn_2042.Invoke_O__O(arg_2043) } else { tmp1 = linked_2041.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2040, arg_2043) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2044 any = A_arbace_go_check_types_A_const_222.GetRawRoot__O(); var linked_2045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2044, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2046 lang.IFn; if linked_2045 == nil { ifn_2046 = lang.IFn_Cast(root_2044) } else { ifn_2046 = nil }; var arg_2047 any = map__219000264__7; if linked_2045 == nil { tmp2 = ifn_2046.Invoke_O__O(arg_2047) } else { tmp2 = linked_2045.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2044, arg_2047) }; map__219000264__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_2048 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_2049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2048, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2050 lang.IFn; if linked_2049 == nil { ifn_2050 = lang.IFn_Cast(root_2048) } else { ifn_2050 = nil }; var arg_2051 any = map__219000264__7; if linked_2049 == nil { tmp3 = ifn_2050.Invoke_O__O(arg_2051) } else { tmp3 = linked_2049.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2048, arg_2051) }; if jrt.J2g_Truth(tmp3) { var root_2052 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_2053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2052, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2054 lang.IFn; if linked_2053 == nil { ifn_2054 = lang.IFn_Cast(root_2052) } else { ifn_2054 = nil }; var arg_2055 any = map__219000264__7; if linked_2053 == nil { map__219000264__8 = ifn_2054.Invoke_O__O(arg_2055) } else { map__219000264__8 = linked_2053.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2052, arg_2055) } } else { map__219000264__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__219000264__8 = map__219000264__7 }
//line :756:1
			var mn__9 any = lang.RT_Get_O_O__O_NoInit(map__219000264__8, A_arbace_go_check_types_A_const_12); var mp__10 any = lang.RT_Get_O_O__O_NoInit(map__219000264__8, A_arbace_go_check_types_A_const_57); var tmp4 any; var root_2056 any = A_arbace_go_check_types_A_const_223.GetRawRoot__O(); var linked_2057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2056, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_2058 lang.IFn


			if linked_2057 == nil { ifn_2058 = lang.IFn_Cast(root_2056) } else { ifn_2058 = nil }; var arg_2059 any = mn__9; var arg_2060 any = mp__10; var arg_2061 any = name__1; var arg_2062 any = pkg__2; if linked_2057 == nil { tmp4 = ifn_2058.Invoke_O_O_O_O__O(arg_2059, arg_2060, arg_2061, arg_2062) } else { tmp4 = linked_2057.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_2056, arg_2059, arg_2060, arg_2061, arg_2062) }; if jrt.J2g_Truth(tmp4) { return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__5).Ref(), m__6) } else {

				i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } } else {
//line :756:1
					return nil } } }; /*line :751:1*/panic("j2g: unreachable") }











func A_arbace_go_check_types_iface_method_A_New() *A_arbace_go_check_types_iface_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_iface_method_A{}; t.Ctor(); return t }
//line :763:1
func (t *A_arbace_go_check_types_iface_method_A) Ctor() {}
//line :763:1
func (t *A_arbace_go_check_types_iface_method_A) Invoke_O_O_O_O__O(self, u__0, name__1, pkg__2 any) any { { var ms__4 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(1)); var i__5 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i__5, int64(lang.RT_Count_O__I_NoInit(ms__4))) { var m__6 any = lang.RT_Nth_O_I__O_NoInit(ms__4, lang.RT_IntCast_J__I_NoInit(i__5)); var tmp1 any; var root_2063 any = A_arbace_go_check_types_A_const_223.GetRawRoot__O(); var linked_2064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2063, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_2065 lang.IFn

		if linked_2064 == nil { ifn_2065 = lang.IFn_Cast(root_2063) } else { ifn_2065 = nil }; var arg_2066 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__6); var arg_2067 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(m__6); var arg_2068 any = name__1; var arg_2069 any = pkg__2; if linked_2064 == nil { tmp1 = ifn_2065.Invoke_O_O_O_O__O(arg_2066, arg_2067, arg_2068, arg_2069) } else { tmp1 = linked_2064.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_2063, arg_2066, arg_2067, arg_2068, arg_2069) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__5).Ref(), m__6) } else {

			i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } } else {
//line :768:1
				return nil } } }; /*line :763:1*/panic("j2g: unreachable") }










func A_arbace_go_check_types_consolidate_A_New() *A_arbace_go_check_types_consolidate_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_consolidate_A{}; t.Ctor(); return t }
//line :774:1
func (t *A_arbace_go_check_types_consolidate_A) Ctor() {}
//line :774:1
func (t *A_arbace_go_check_types_consolidate_A) Invoke_O_O__O(self, entries__0 any) any { { var es__2 any = entries__0; var acc__3 any = lang.PersistentVector_EMPTY.Ref(); var idx__4 any = lang.PersistentArrayMap_EMPTY.Ref(); L1: for {



	var tmp1 any; var root_2070 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_2071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2070, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2072 lang.IFn; if linked_2071 == nil { ifn_2072 = lang.IFn_Cast(root_2070) } else { ifn_2072 = nil }; var arg_2073 any = es__2; if linked_2071 == nil { tmp1 = ifn_2072.Invoke_O__O(arg_2073) } else { tmp1 = linked_2071.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2070, arg_2073) }; if jrt.J2g_Truth(tmp1) { return acc__3 } else { var e__5 any; var root_2074 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_2075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2074, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2076 lang.IFn

		if linked_2075 == nil { ifn_2076 = lang.IFn_Cast(root_2074) } else { ifn_2076 = nil }; var arg_2077 any = es__2; if linked_2075 == nil { e__5 = ifn_2076.Invoke_O__O(arg_2077) } else { e__5 = linked_2075.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2074, arg_2077) }
//line :778:1
		var k__6 any; var root_2078 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_2079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2078, A_arbace_go_check_types_canon_A_fn_class); var ifn_2080 lang.IFn


		if linked_2079 == nil { ifn_2080 = lang.IFn_Cast(root_2078) } else { ifn_2080 = nil }; var arg_2081 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(e__5); if linked_2079 == nil { k__6 = ifn_2080.Invoke_O__O(arg_2081) } else { k__6 = linked_2079.(*A_arbace_go_check_types_canon_A).Invoke_O_O__O(root_2078, arg_2081) }
//line :778:1
		var temp__1927000408__auto____7 any = lang.RT_Get_O_O__O_NoInit(idx__4, k__6)



		if jrt.J2g_Truth(temp__1927000408__auto____7) { var j__8 any = temp__1927000408__auto____7; var tmp2 any; var root_2082 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_2083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2082, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2084 lang.IFn
			if linked_2083 == nil { ifn_2084 = lang.IFn_Cast(root_2082) } else { ifn_2084 = nil }; var arg_2085 any = es__2; if linked_2083 == nil { tmp2 = ifn_2084.Invoke_O__O(arg_2085) } else { tmp2 = linked_2083.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2082, arg_2085) }; var tmp3 any = tmp2; var tmp4 any; var root_2086 any = A_arbace_go_check_types_A_const_224.GetRawRoot__O(); var linked_2087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2086, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_2088 lang.IFn; if linked_2087 == nil { ifn_2088 = lang.IFn_Cast(root_2086) } else { ifn_2088 = nil }; var arg_2089 any = acc__3; var arg_2090 any = lang.Tuple_Create_O_O__IPersistentVector(j__8, A_arbace_go_check_types_A_const_225); var arg_2091 any = jrt.Boolean_TRUE.Ref(); if linked_2087 == nil { tmp4 = ifn_2088.Invoke_O_O_O__O(arg_2089, arg_2090, arg_2091) } else { tmp4 = linked_2087.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_2086, arg_2089, arg_2090, arg_2091) }; es__2, acc__3, idx__4 = tmp3, tmp4, idx__4; continue L1 } else {
				var tmp5 any; var root_2092 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_2093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2092, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2094 lang.IFn; if linked_2093 == nil { ifn_2094 = lang.IFn_Cast(root_2092) } else { ifn_2094 = nil }; var arg_2095 any = es__2; if linked_2093 == nil { tmp5 = ifn_2094.Invoke_O__O(arg_2095) } else { tmp5 = linked_2093.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2092, arg_2095) }; var tmp6 any = tmp5; var tmp7 any; var root_2096 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2097 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2096, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2098 lang.IFn; if linked_2097 == nil { ifn_2098 = lang.IFn_Cast(root_2096) } else { ifn_2098 = nil }; var arg_2099 any = acc__3; var arg_2100 any = e__5; if linked_2097 == nil { tmp7 = ifn_2098.Invoke_O_O__O(arg_2099, arg_2100) } else { tmp7 = linked_2097.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2096, arg_2099, arg_2100) }; var tmp8 any = tmp7; var tmp9 any; var root_2101 any = A_arbace_go_check_types_A_const_67.GetRawRoot__O(); var linked_2102 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2101, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2103 lang.IFn; if linked_2102 == nil { ifn_2103 = lang.IFn_Cast(root_2101) } else { ifn_2103 = nil }; var arg_2104 any = idx__4; var arg_2105 any = k__6; var arg_2106 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(acc__3)).Ref(); if linked_2102 == nil { tmp9 = ifn_2103.Invoke_O_O_O__O(arg_2104, arg_2105, arg_2106) } else { tmp9 = linked_2102.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2101, arg_2104, arg_2105, arg_2106) }; es__2, acc__3, idx__4 = tmp6, tmp8, tmp9; continue L1 } } } }; /*line :774:1*/panic("j2g: unreachable") }











func A_arbace_go_check_types_lookup_impl_A_New() *A_arbace_go_check_types_lookup_impl_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_impl_A{}; t.Ctor(); return t }
//line :786:1
func (t *A_arbace_go_check_types_lookup_impl_A) Ctor() {}
//line :786:1
func (t *A_arbace_go_check_types_lookup_impl_A) Invoke_O_O_O_O_O__O(self, T__0_, addressable__1, name__2, pkg__3 any) any { { var vec__219000269__5 any; var root_2107 any = A_arbace_go_check_types_A_const_226.GetRawRoot__O(); var linked_2108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2107, A_arbace_go_check_types_deref_type_A_fn_class); var ifn_2109 lang.IFn





	if linked_2108 == nil { ifn_2109 = lang.IFn_Cast(root_2107) } else { ifn_2109 = nil }; var arg_2110 any = T__0_; if linked_2108 == nil { vec__219000269__5 = ifn_2109.Invoke_O__O(arg_2110) } else { vec__219000269__5 = linked_2108.(*A_arbace_go_check_types_deref_type_A).Invoke_O_O__O(root_2107, arg_2110) }
//line :786:1
	var typ__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000269__5, lang.RT_IntCast_J__I_NoInit(0), nil); var is_ptr__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000269__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any
	var and__1927000168__auto____8 any = is_ptr__7





	if jrt.J2g_Truth(and__1927000168__auto____8) { var root_2111 any = A_arbace_go_check_types_A_const_227.GetRawRoot__O(); var linked_2112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2111, A_arbace_go_check_types_interface_QMARK__A_fn_class); var ifn_2113 lang.IFn; if linked_2112 == nil { ifn_2113 = lang.IFn_Cast(root_2111) } else { ifn_2113 = nil }; var arg_2114 any = typ__6; if linked_2112 == nil { tmp1 = ifn_2113.Invoke_O__O(arg_2114) } else { tmp1 = linked_2112.(*A_arbace_go_check_types_interface_QMARK__A).Invoke_O_O__O(root_2111, arg_2114) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return nil } else { var current__8 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_65, typ__6, A_arbace_go_check_types_A_const_235, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_types_A_const_236, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_types_A_const_237, is_ptr__7, A_arbace_go_check_types_A_const_225, jrt.Boolean_FALSE.Ref()))); var seen__9 any = lang.PersistentHashSet_EMPTY.Ref(); L1: for {



		var tmp2 any; var root_2115 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_2116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2115, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2117 lang.IFn; if linked_2116 == nil { ifn_2117 = lang.IFn_Cast(root_2115) } else { ifn_2117 = nil }; var arg_2118 any = current__8; if linked_2116 == nil { tmp2 = ifn_2117.Invoke_O__O(arg_2118) } else { tmp2 = linked_2116.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2115, arg_2118) }; if jrt.J2g_Truth(tmp2) { return nil } else { var vec__219000272__10 any; var root_2119 any = A_arbace_go_check_types_A_const_209.GetRawRoot__O(); var linked_2120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2119, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_2121 lang.IFn


			if linked_2120 == nil { ifn_2121 = lang.IFn_Cast(root_2119) } else { ifn_2121 = nil }; var arg_2122 any; var fnbody__2229 any = A_arbace_go_check_types_lookup_impl_fn__219000276_A_New_O_O(pkg__3, name__2); var tmp3 *jrt.Class; var fncls__2228 *jrt.Class = A_arbace_go_check_types_lookup_impl_fn__219000276_A_fn_class
			if fncls__2228 == nil { var fncls__2228d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__2229); A_arbace_go_check_types_lookup_impl_fn__219000276_A_fn_class = fncls__2228d; tmp3 = fncls__2228d } else { tmp3 = fncls__2228 }; arg_2122 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2229, tmp3, nil)
//line :800:1
			var arg_2123 any = lang.Tuple_Create_O_O_O__IPersistentVector(nil, lang.PersistentVector_EMPTY.Ref(), seen__9); var arg_2124 any = current__8; if linked_2120 == nil { vec__219000272__10 = ifn_2121.Invoke_O_O_O__O(arg_2122, arg_2123, arg_2124) } else { vec__219000272__10 = linked_2120.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_2119, arg_2122, arg_2123, arg_2124) }
//line :797:1
			var found__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000272__10, lang.RT_IntCast_J__I_NoInit(0), nil); var next__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000272__10, lang.RT_IntCast_J__I_NoInit(1), nil); var seen__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000272__10, lang.RT_IntCast_J__I_NoInit(2), nil)















































			if jrt.J2g_Truth(A_arbace_go_check_types_A_const_242.Invoke_O__O(found__11)) { return found__11 } else { if jrt.J2g_Truth(found__11) {


				var tmp4 any; var tmp5 any = A_arbace_go_check_types_A_const_232; var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_go_check_types_A_const_231.Invoke_O__O(found__11)); if and__1927000168__auto____14 { var tmp6 *lang.Keyword = A_arbace_go_check_types_A_const_243; var and__1927000168__auto____15 any = tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_go_check_types_A_const_244.Get__O()).Invoke_O__O(A_arbace_go_check_types_A_const_60.Invoke_O__O(found__11))); if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any; var root_2230 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_2231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2230, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2232 lang.IFn
					if linked_2231 == nil { ifn_2232 = lang.IFn_Cast(root_2230) } else { ifn_2232 = nil }; var arg_2233 any = A_arbace_go_check_types_A_const_237.Invoke_O__O(found__11); if linked_2231 == nil { and__1927000168__auto____16 = ifn_2232.Invoke_O__O(arg_2233) } else { and__1927000168__auto____16 = linked_2231.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2230, arg_2233) }
//line :848:1
					if jrt.J2g_Truth(and__1927000168__auto____16) {
						var root_2234 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_2235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2234, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2236 lang.IFn; if linked_2235 == nil { ifn_2236 = lang.IFn_Cast(root_2234) } else { ifn_2236 = nil }; var arg_2237 any = addressable__1; if linked_2235 == nil { tmp4 = ifn_2236.Invoke_O__O(arg_2237) } else { tmp4 = linked_2235.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2234, arg_2237) } } else {
//line :848:1
							tmp4 = and__1927000168__auto____16 } } else { tmp4 = and__1927000168__auto____15 } } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }; if jrt.J2g_Truth(tmp4) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_243, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_types_A_const_245, found__11)) } else { return found__11 } } else {
//line :845:1
								if A_arbace_go_check_types_A_const_86 != nil {






									var tmp7 any; var root_2238 any = A_arbace_go_check_types_A_const_246.GetRawRoot__O(); var linked_2239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2238, A_arbace_go_check_types_consolidate_A_fn_class); var ifn_2240 lang.IFn; if linked_2239 == nil { ifn_2240 = lang.IFn_Cast(root_2238) } else { ifn_2240 = nil }; var arg_2241 any = next__12; if linked_2239 == nil { tmp7 = ifn_2240.Invoke_O__O(arg_2241) } else { tmp7 = linked_2239.(*A_arbace_go_check_types_consolidate_A).Invoke_O_O__O(root_2238, arg_2241) }; current__8, seen__9 = tmp7, seen__13; continue L1 } else {
//line :845:1
										return nil } } } } } } }; /*line :786:1*/panic("j2g: unreachable") }














func A_arbace_go_check_types_lookup_impl_fn__219000276_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_lookup_impl_fn__219000276_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_impl_fn__219000276_A{}; t.Ctor_O_O(p0, p1); return t }
//line :801:1
func (t *A_arbace_go_check_types_lookup_impl_fn__219000276_A) Ctor_O_O(c__pkg, c__name any) { t.F_pkg = c__pkg; t.F_name = c__name }
//line :801:1
func (t *A_arbace_go_check_types_lookup_impl_fn__219000276_A) Invoke_O_O_O__O(self, p__219000275__1, e__2 any) any { { var vec__219000277__3 any = p__219000275__1; var found__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000277__3, lang.RT_IntCast_J__I_NoInit(0), nil); var next__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000277__3, lang.RT_IntCast_J__I_NoInit(1), nil); var seen__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000277__3, lang.RT_IntCast_J__I_NoInit(2), nil); var typ__7 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(e__2); var tmp1 any; var and__1927000168__auto____8 any; var root_2125 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_2126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2125, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_2127 lang.IFn

	if linked_2126 == nil { ifn_2127 = lang.IFn_Cast(root_2125) } else { ifn_2127 = nil }; var arg_2128 any = typ__7; if linked_2126 == nil { and__1927000168__auto____8 = ifn_2127.Invoke_O__O(arg_2128) } else { and__1927000168__auto____8 = linked_2126.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_2125, arg_2128) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_2129 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_2130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2129, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2131 lang.IFn; if linked_2130 == nil { ifn_2131 = lang.IFn_Cast(root_2129) } else { ifn_2131 = nil }; var arg_2132 any = seen__6; var arg_2133 any = typ__7; if linked_2130 == nil { tmp1 = ifn_2131.Invoke_O_O__O(arg_2132, arg_2133) } else { tmp1 = linked_2130.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2129, arg_2132, arg_2133) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__6) } else { var seen__8 any; var tmp2 any; var root_2134 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2134, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_2136 lang.IFn

		if linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any = typ__7; if linked_2135 == nil { tmp2 = ifn_2136.Invoke_O__O(arg_2137) } else { tmp2 = linked_2135.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_2134, arg_2137) }; if jrt.J2g_Truth(tmp2) { var root_2138 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2139 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2138, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2140 lang.IFn; if linked_2139 == nil { ifn_2140 = lang.IFn_Cast(root_2138) } else { ifn_2140 = nil }; var arg_2141 any = seen__6; var arg_2142 any = typ__7; if linked_2139 == nil { seen__8 = ifn_2140.Invoke_O_O__O(arg_2141, arg_2142) } else { seen__8 = linked_2139.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2138, arg_2141, arg_2142) } } else { seen__8 = seen__6 }
//line :803:1
		var m__9 any; var tmp3 any; var root_2143 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_2144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2143, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_2145 lang.IFn


		if linked_2144 == nil { ifn_2145 = lang.IFn_Cast(root_2143) } else { ifn_2145 = nil }; var arg_2146 any = typ__7; if linked_2144 == nil { tmp3 = ifn_2145.Invoke_O__O(arg_2146) } else { tmp3 = linked_2144.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_2143, arg_2146) }; if jrt.J2g_Truth(tmp3) { var root_2147 any = A_arbace_go_check_types_A_const_228.GetRawRoot__O(); var linked_2148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2147, A_arbace_go_check_types_named_method_A_fn_class); var ifn_2149 lang.IFn; if linked_2148 == nil { ifn_2149 = lang.IFn_Cast(root_2147) } else { ifn_2149 = nil }; var arg_2150 any = typ__7; var arg_2151 any = t.F_name; var arg_2152 any = t.F_pkg; if linked_2148 == nil { m__9 = ifn_2149.Invoke_O_O_O__O(arg_2150, arg_2151, arg_2152) } else { m__9 = linked_2148.(*A_arbace_go_check_types_named_method_A).Invoke_O_O_O_O__O(root_2147, arg_2150, arg_2151, arg_2152) } } else { m__9 = nil }
		if jrt.J2g_Truth(m__9) {
			var tmp4 any; var or__1927000174__auto____10 any = found__4; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp4 = or__1927000174__auto____10 } else { tmp4 = A_arbace_go_check_types_A_const_225.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp4) { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_230, next__5, seen__8) } else { var tmp5 any = A_arbace_go_check_types_A_const_231; var tmp6 any = A_arbace_go_check_types_A_const_232; var tmp7 any = A_arbace_go_check_types_A_const_60; var tmp8 any; var root_2182 any = A_arbace_go_check_types_A_const_233.GetRawRoot__O(); var linked_2183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2182, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2184 lang.IFn

				if linked_2183 == nil { ifn_2184 = lang.IFn_Cast(root_2182) } else { ifn_2184 = nil }; var arg_2185 any = m__9; if linked_2183 == nil { tmp8 = ifn_2184.Invoke_O__O(arg_2185) } else { tmp8 = linked_2183.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2182, arg_2185) }
//line :808:1
				var tmp9 any = tmp8; var tmp10 any = A_arbace_go_check_types_A_const_234; var tmp11 any = A_arbace_go_check_types_A_const_235; var tmp12 any; var root_2186 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2187 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2186, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2188 lang.IFn

				if linked_2187 == nil { ifn_2188 = lang.IFn_Cast(root_2186) } else { ifn_2188 = nil }; var arg_2189 any = A_arbace_go_check_types_A_const_235.Invoke_O__O(e__2); var arg_2190 any; var root_2191 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_2192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2191, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2193 lang.IFn; if linked_2192 == nil { ifn_2193 = lang.IFn_Cast(root_2191) } else { ifn_2193 = nil }; var arg_2194 any = m__9; if linked_2192 == nil { arg_2190 = ifn_2193.Invoke_O__O(arg_2194) } else { arg_2190 = linked_2192.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2191, arg_2194) }; if linked_2187 == nil { tmp12 = ifn_2188.Invoke_O_O__O(arg_2189, arg_2190) } else { tmp12 = linked_2187.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2186, arg_2189, arg_2190) }
//line :808:1
				var tmp13 any = tmp12; var tmp14 any = A_arbace_go_check_types_A_const_236; var tmp15 any = A_arbace_go_check_types_A_const_236.Invoke_O__O(e__2); var tmp16 any = A_arbace_go_check_types_A_const_237; return lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, tmp9, tmp10, typ__7, tmp11, tmp13, tmp14, tmp15, tmp16, A_arbace_go_check_types_A_const_237.Invoke_O__O(e__2))), next__5, seen__8) } } else {
//line :807:1
					var u__10 any; var root_2153 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_2154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2153, A_arbace_go_check_types_under_A_fn_class); var ifn_2155 lang.IFn




					if linked_2154 == nil { ifn_2155 = lang.IFn_Cast(root_2153) } else { ifn_2155 = nil }; var arg_2156 any = typ__7; if linked_2154 == nil { u__10 = ifn_2155.Invoke_O__O(arg_2156) } else { u__10 = linked_2154.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2153, arg_2156) }
					var tmp17 any; var and__1927000168__auto____11 any; var root_2157 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_2158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2157, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2159 lang.IFn
					if linked_2158 == nil { ifn_2159 = lang.IFn_Cast(root_2157) } else { ifn_2159 = nil }; var arg_2160 any = u__10; if linked_2158 == nil { and__1927000168__auto____11 = ifn_2159.Invoke_O__O(arg_2160) } else { and__1927000168__auto____11 = linked_2158.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2157, arg_2160) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var tmp18 any = A_arbace_go_check_types_A_const_82; tmp17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp18, lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp17 = and__1927000168__auto____11 }
//line :813:1
					if jrt.J2g_Truth(tmp17) { var fs__11 any = lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(1)); var i__12 int64 = 0; var found__13 any = found__4; var next__14 any = next__5; L1: for {



						if lang.Numbers_Gte_J_J__Z_NoInit(i__12, int64(lang.RT_Count_O__I_NoInit(fs__11))) { return lang.Tuple_Create_O_O_O__IPersistentVector(found__13, next__14, seen__8) } else { var f__15 any = lang.RT_Nth_O_I__O_NoInit(fs__11, lang.RT_IntCast_J__I_NoInit(i__12)); var tmp19 any; var root_2161 any = A_arbace_go_check_types_A_const_223.GetRawRoot__O(); var linked_2162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2161, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_2163 lang.IFn



							if linked_2162 == nil { ifn_2163 = lang.IFn_Cast(root_2161) } else { ifn_2163 = nil }; var arg_2164 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(f__15); var arg_2165 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(f__15); var arg_2166 any = t.F_name; var arg_2167 any = t.F_pkg; if linked_2162 == nil { tmp19 = ifn_2163.Invoke_O_O_O_O__O(arg_2164, arg_2165, arg_2166, arg_2167) } else { tmp19 = linked_2162.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_2161, arg_2164, arg_2165, arg_2166, arg_2167) }
//line :820:1
							if jrt.J2g_Truth(tmp19) {

								var tmp20 any; var or__1927000174__auto____16 any = found__13; if jrt.J2g_Truth(or__1927000174__auto____16) { tmp20 = or__1927000174__auto____16 } else { tmp20 = A_arbace_go_check_types_A_const_225.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp20) {
									i__12, found__13, next__14 = lang.Numbers_Inc_J__J_NoInit(i__12), A_arbace_go_check_types_A_const_238, next__14; continue L1 } else {
										var tmp21 int64 = lang.Numbers_Inc_J__J_NoInit(i__12); var tmp22 any = A_arbace_go_check_types_A_const_231; var tmp23 any = A_arbace_go_check_types_A_const_239; var tmp24 any = A_arbace_go_check_types_A_const_60; var tmp25 any = A_arbace_go_check_types_A_const_235; var tmp26 any; var root_2195 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2196 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2195, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2197 lang.IFn; if linked_2196 == nil { ifn_2197 = lang.IFn_Cast(root_2195) } else { ifn_2197 = nil }; var arg_2198 any = A_arbace_go_check_types_A_const_235.Invoke_O__O(e__2); var arg_2199 any = jrt.Long_ValueOf_J__Long_NoInit(i__12).Ref(); if linked_2196 == nil { tmp26 = ifn_2197.Invoke_O_O__O(arg_2198, arg_2199) } else { tmp26 = linked_2196.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2195, arg_2198, arg_2199) }; var tmp27 any = tmp26; var tmp28 any = A_arbace_go_check_types_A_const_236; var tmp29 any = A_arbace_go_check_types_A_const_236.Invoke_O__O(e__2); var tmp30 any = A_arbace_go_check_types_A_const_237; i__12, found__13, next__14 = tmp21, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp23, tmp24, f__15, tmp25, tmp27, tmp28, tmp29, tmp30, A_arbace_go_check_types_A_const_237.Invoke_O__O(e__2))), next__14; continue L1 } } else {
//line :820:1
											var tmp31 any; var and__1927000168__auto____16 bool = lang.Util_Identical_O_O__Z_NoInit(found__13, nil)






											if and__1927000168__auto____16 { tmp31 = A_arbace_go_check_types_A_const_192.Invoke_O__O(f__15) } else { tmp31 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____16).Ref() }
//line :820:1
											if jrt.J2g_Truth(tmp31) { var vec__219000280__16 any; var root_2168 any = A_arbace_go_check_types_A_const_226.GetRawRoot__O(); var linked_2169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2168, A_arbace_go_check_types_deref_type_A_fn_class); var ifn_2170 lang.IFn







												if linked_2169 == nil { ifn_2170 = lang.IFn_Cast(root_2168) } else { ifn_2170 = nil }; var arg_2171 any = A_arbace_go_check_types_A_const_65.Invoke_O__O(f__15); if linked_2169 == nil { vec__219000280__16 = ifn_2170.Invoke_O__O(arg_2171) } else { vec__219000280__16 = linked_2169.(*A_arbace_go_check_types_deref_type_A).Invoke_O_O__O(root_2168, arg_2171) }
//line :820:1
												var ft__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000280__16, lang.RT_IntCast_J__I_NoInit(0), nil); var fp__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000280__16, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp32 int64 = lang.Numbers_Inc_J__J_NoInit(i__12); var tmp33 any; var root_2200 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2201 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2200, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2202 lang.IFn









												if linked_2201 == nil { ifn_2202 = lang.IFn_Cast(root_2200) } else { ifn_2202 = nil }; var arg_2203 any = next__14; var arg_2204 any; var tmp34 any = A_arbace_go_check_types_A_const_65; var tmp35 any = A_arbace_go_check_types_A_const_235; var tmp36 any; var root_2205 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2206 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2205, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2207 lang.IFn; if linked_2206 == nil { ifn_2207 = lang.IFn_Cast(root_2205) } else { ifn_2207 = nil }; var arg_2208 any = A_arbace_go_check_types_A_const_235.Invoke_O__O(e__2); var arg_2209 any = jrt.Long_ValueOf_J__Long_NoInit(i__12).Ref(); if linked_2206 == nil { tmp36 = ifn_2207.Invoke_O_O__O(arg_2208, arg_2209) } else { tmp36 = linked_2206.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2205, arg_2208, arg_2209) }; var tmp37 any = tmp36; var tmp38 any = A_arbace_go_check_types_A_const_236; var tmp39 any; var root_2210 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2211 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2210, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2212 lang.IFn
												if linked_2211 == nil { ifn_2212 = lang.IFn_Cast(root_2210) } else { ifn_2212 = nil }; var arg_2213 any = A_arbace_go_check_types_A_const_236.Invoke_O__O(e__2); var arg_2214 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(f__15); if linked_2211 == nil { tmp39 = ifn_2212.Invoke_O_O__O(arg_2213, arg_2214) } else { tmp39 = linked_2211.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2210, arg_2213, arg_2214) }
//line :830:1
												var tmp40 any = tmp39; var tmp41 any = A_arbace_go_check_types_A_const_237; var tmp42 any; var or__1927000174__auto____19 any = A_arbace_go_check_types_A_const_237.Invoke_O__O(e__2)

												if jrt.J2g_Truth(or__1927000174__auto____19) { tmp42 = or__1927000174__auto____19 } else { tmp42 = fp__18 }
//line :830:1
												var tmp43 any = tmp42; var tmp44 any = A_arbace_go_check_types_A_const_225; arg_2204 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp34, ft__17, tmp35, tmp37, tmp38, tmp40, tmp41, tmp43, tmp44, A_arbace_go_check_types_A_const_225.Invoke_O__O(e__2))); if linked_2201 == nil { tmp33 = ifn_2202.Invoke_O_O__O(arg_2203, arg_2204) } else { tmp33 = linked_2201.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2200, arg_2203, arg_2204) }
//line :829:1
												i__12, found__13, next__14 = tmp32, found__13, tmp33; continue L1 } else {
//line :820:1
													if A_arbace_go_check_types_A_const_86 != nil {













														i__12, found__13, next__14 = lang.Numbers_Inc_J__J_NoInit(i__12), found__13, next__14; continue L1 } else {
//line :820:1
															return nil } } } } } } else {
//line :813:1
																var tmp45 any; var and__1927000168__auto____11_2 any; var root_2172 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_2173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2172, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2174 lang.IFn





















																if linked_2173 == nil { ifn_2174 = lang.IFn_Cast(root_2172) } else { ifn_2174 = nil }; var arg_2175 any = u__10; if linked_2173 == nil { and__1927000168__auto____11_2 = ifn_2174.Invoke_O__O(arg_2175) } else { and__1927000168__auto____11_2 = linked_2173.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2172, arg_2175) }; if jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp46 any = A_arbace_go_check_types_A_const_71; tmp45 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp46, lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp45 = and__1927000168__auto____11_2 }
//line :813:1
																if jrt.J2g_Truth(tmp45) { var temp__1927000408__auto____11 any; var root_2176 any = A_arbace_go_check_types_A_const_229.GetRawRoot__O(); var linked_2177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2176, A_arbace_go_check_types_iface_method_A_fn_class); var ifn_2178 lang.IFn






















																	if linked_2177 == nil { ifn_2178 = lang.IFn_Cast(root_2176) } else { ifn_2178 = nil }; var arg_2179 any = u__10; var arg_2180 any = t.F_name; var arg_2181 any = t.F_pkg; if linked_2177 == nil { temp__1927000408__auto____11 = ifn_2178.Invoke_O_O_O__O(arg_2179, arg_2180, arg_2181) } else { temp__1927000408__auto____11 = linked_2177.(*A_arbace_go_check_types_iface_method_A).Invoke_O_O_O_O__O(root_2176, arg_2179, arg_2180, arg_2181) }; if jrt.J2g_Truth(temp__1927000408__auto____11) { var m__12 any = temp__1927000408__auto____11; var tmp47 any; var or__1927000174__auto____13 any = found__4
																		if jrt.J2g_Truth(or__1927000174__auto____13) { tmp47 = or__1927000174__auto____13 } else { tmp47 = A_arbace_go_check_types_A_const_225.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp47) { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_240, next__5, seen__8) } else { var tmp48 any = A_arbace_go_check_types_A_const_231; var tmp49 any = A_arbace_go_check_types_A_const_241; var tmp50 any = A_arbace_go_check_types_A_const_60; var tmp51 any; var root_2215 any = A_arbace_go_check_types_A_const_233.GetRawRoot__O(); var linked_2216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2215, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2217 lang.IFn

																			if linked_2216 == nil { ifn_2217 = lang.IFn_Cast(root_2215) } else { ifn_2217 = nil }; var arg_2218 any = m__12; if linked_2216 == nil { tmp51 = ifn_2217.Invoke_O__O(arg_2218) } else { tmp51 = linked_2216.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2215, arg_2218) }
//line :837:1
																			var tmp52 any = tmp51; var tmp53 any = A_arbace_go_check_types_A_const_169; var tmp54 any = A_arbace_go_check_types_A_const_235; var tmp55 any; var root_2219 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_2220 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2219, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2221 lang.IFn

																			if linked_2220 == nil { ifn_2221 = lang.IFn_Cast(root_2219) } else { ifn_2221 = nil }; var arg_2222 any = A_arbace_go_check_types_A_const_235.Invoke_O__O(e__2); var arg_2223 any; var root_2224 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_2225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2224, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2226 lang.IFn; if linked_2225 == nil { ifn_2226 = lang.IFn_Cast(root_2224) } else { ifn_2226 = nil }; var arg_2227 any = m__12; if linked_2225 == nil { arg_2223 = ifn_2226.Invoke_O__O(arg_2227) } else { arg_2223 = linked_2225.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2224, arg_2227) }; if linked_2220 == nil { tmp55 = ifn_2221.Invoke_O_O__O(arg_2222, arg_2223) } else { tmp55 = linked_2220.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2219, arg_2222, arg_2223) }
//line :837:1
																			var tmp56 any = tmp55; var tmp57 any = A_arbace_go_check_types_A_const_236; var tmp58 any = A_arbace_go_check_types_A_const_236.Invoke_O__O(e__2); var tmp59 any = A_arbace_go_check_types_A_const_237; return lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp48, tmp49, tmp50, tmp52, tmp53, typ__7, tmp54, tmp56, tmp57, tmp58, tmp59, A_arbace_go_check_types_A_const_237.Invoke_O__O(e__2))), next__5, seen__8) } } else {
//line :836:1
																				return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__8) } } else {
//line :813:1
																					if A_arbace_go_check_types_A_const_86 != nil { return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__8) } else { return nil } } } } } }; /*line :801:1*/panic("j2g: unreachable") }




















































func A_arbace_go_check_types_lookup_A_New() *A_arbace_go_check_types_lookup_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_A{}; t.Ctor(); return t }
//line :854:1
func (t *A_arbace_go_check_types_lookup_A) Ctor() {}
//line :854:1
func (t *A_arbace_go_check_types_lookup_A) Invoke_O_O_O_O_O__O(self, T__0_, addressable__1, name__2, pkg__3 any) any {


	var tmp1 any; var and__1927000168__auto____5 any; var root_2242 any = A_arbace_go_check_types_A_const_101.GetRawRoot__O(); var linked_2243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2242, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_2244 lang.IFn; if linked_2243 == nil { ifn_2244 = lang.IFn_Cast(root_2242) } else { ifn_2244 = nil }; var arg_2245 any = T__0_; if linked_2243 == nil { and__1927000168__auto____5 = ifn_2244.Invoke_O__O(arg_2245) } else { and__1927000168__auto____5 = linked_2243.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_2242, arg_2245) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_2246 any = A_arbace_go_check_types_A_const_247.GetRawRoot__O(); var linked_2247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2246, A_arbace_go_check_types_pointer_QMARK__A_fn_class); var ifn_2248 lang.IFn; if linked_2247 == nil { ifn_2248 = lang.IFn_Cast(root_2246) } else { ifn_2248 = nil }; var arg_2249 any = T__0_; if linked_2247 == nil { tmp1 = ifn_2248.Invoke_O__O(arg_2249) } else { tmp1 = linked_2247.(*A_arbace_go_check_types_pointer_QMARK__A).Invoke_O_O__O(root_2246, arg_2249) } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var r__5 any; var root_2250 any = A_arbace_go_check_types_A_const_248.GetRawRoot__O(); var linked_2251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2250, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_2252 lang.IFn
		if linked_2251 == nil { ifn_2252 = lang.IFn_Cast(root_2250) } else { ifn_2252 = nil }; var arg_2253 any; var root_2257 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_2258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2257, A_arbace_go_check_types_under_A_fn_class); var ifn_2259 lang.IFn; if linked_2258 == nil { ifn_2259 = lang.IFn_Cast(root_2257) } else { ifn_2259 = nil }; var arg_2260 any = T__0_; if linked_2258 == nil { arg_2253 = ifn_2259.Invoke_O__O(arg_2260) } else { arg_2253 = linked_2258.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2257, arg_2260) }; var arg_2254 any = jrt.Boolean_FALSE.Ref(); var arg_2255 any = name__2; var arg_2256 any = pkg__3; if linked_2251 == nil { r__5 = ifn_2252.Invoke_O_O_O_O__O(arg_2253, arg_2254, arg_2255, arg_2256) } else { r__5 = linked_2251.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_2250, arg_2253, arg_2254, arg_2255, arg_2256) }
		var tmp2 any = A_arbace_go_check_types_A_const_232; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_go_check_types_A_const_231.Invoke_O__O(r__5)) { return nil } else { return r__5 } } else {
			var root_2261 any = A_arbace_go_check_types_A_const_248.GetRawRoot__O(); var linked_2262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2261, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_2263 lang.IFn; if linked_2262 == nil { ifn_2263 = lang.IFn_Cast(root_2261) } else { ifn_2263 = nil }; var arg_2264 any = T__0_; var arg_2265 any = addressable__1; var arg_2266 any = name__2; var arg_2267 any = pkg__3; if linked_2262 == nil { return ifn_2263.Invoke_O_O_O_O__O(arg_2264, arg_2265, arg_2266, arg_2267) } else { return linked_2262.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_2261, arg_2264, arg_2265, arg_2266, arg_2267)
			}
		}
}
func A_arbace_go_check_types_sort_methods_A_New() *A_arbace_go_check_types_sort_methods_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sort_methods_A{}; t.Ctor(); return t }
//line :864:1
func (t *A_arbace_go_check_types_sort_methods_A) Ctor() {}
//line :864:1
func (t *A_arbace_go_check_types_sort_methods_A) Invoke_O_O__O(self, ms__0 any) any {


	var root_2268 any = A_arbace_go_check_types_A_const_147.GetRawRoot__O(); var linked_2269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2268, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2270 lang.IFn; if linked_2269 == nil { ifn_2270 = lang.IFn_Cast(root_2268) } else { ifn_2270 = nil }; var arg_2271 any; var root_2272 any = A_arbace_go_check_types_A_const_188.GetRawRoot__O(); var linked_2273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2272, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2274 lang.IFn; if linked_2273 == nil { ifn_2274 = lang.IFn_Cast(root_2272) } else { ifn_2274 = nil }; var arg_2275 any; var fnbody__2278 any = A_arbace_go_check_types_sort_methods_fn__219000286_A_New(); var tmp1 *jrt.Class; var fncls__2277 *jrt.Class = A_arbace_go_check_types_sort_methods_fn__219000286_A_fn_class; if fncls__2277 == nil { var fncls__2277d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, nil); A_arbace_go_check_types_sort_methods_fn__219000286_A_fn_class = fncls__2277d; tmp1 = fncls__2277d } else { tmp1 = fncls__2277 }; arg_2275 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2278, tmp1, nil); var arg_2276 any = ms__0; if linked_2273 == nil { arg_2271 = ifn_2274.Invoke_O_O__O(arg_2275, arg_2276) } else { arg_2271 = linked_2273.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2272, arg_2275, arg_2276) }; if linked_2269 == nil { return ifn_2270.Invoke_O__O(arg_2271) } else { return linked_2269.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2268, arg_2271) } }
//line :867:1
func A_arbace_go_check_types_sort_methods_fn__219000286_A_New() *A_arbace_go_check_types_sort_methods_fn__219000286_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sort_methods_fn__219000286_A{}; t.Ctor(); return t }
//line :867:1
func (t *A_arbace_go_check_types_sort_methods_fn__219000286_A) Ctor() {}
//line :867:1
func (t *A_arbace_go_check_types_sort_methods_fn__219000286_A) Invoke_O_O__O(self, m__1 any) any { var tmp1 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var tmp2 any; var or__1927000174__auto____2 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(m__1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = Lit_10 }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }

func A_arbace_go_check_types_method_data_A_New() *A_arbace_go_check_types_method_data_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_method_data_A{}; t.Ctor(); return t }
//line :869:1
func (t *A_arbace_go_check_types_method_data_A) Ctor() {}
//line :869:1
func (t *A_arbace_go_check_types_method_data_A) Invoke_O_O__O(self, m__0 any) any {


	var tmp1 any; var root_2279 any = A_arbace_go_check_types_A_const_166.GetRawRoot__O(); var linked_2280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2279, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_2281 lang.IFn; if linked_2280 == nil { ifn_2281 = lang.IFn_Cast(root_2279) } else { ifn_2281 = nil }; var arg_2282 any = m__0; if linked_2280 == nil { tmp1 = ifn_2281.Invoke_O__O(arg_2282) } else { tmp1 = linked_2280.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_2279, arg_2282) }; if jrt.J2g_Truth(tmp1) { return m__0 } else { return lang.IFn_Cast(A_arbace_go_check_types_A_const_244.Get__O()).Invoke_O__O(m__0)
	} }
func A_arbace_go_check_types_missing_method_A_New() *A_arbace_go_check_types_missing_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_A{}; t.Ctor(); return t }
//line :874:1
func (t *A_arbace_go_check_types_missing_method_A) Ctor() {}
//line :874:1
func (t *A_arbace_go_check_types_missing_method_A) Invoke_O_O_O_O_O__O(self, V__0_, T__1_, static__2, same_QMARK___3 any) any { var tu__5 any; var root_2283 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_2284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2283, A_arbace_go_check_types_under_A_fn_class); var ifn_2285 lang.IFn; if





	linked_2284 == nil { ifn_2285 = lang.IFn_Cast(root_2283) } else { ifn_2285 = nil }; var arg_2286 any = T__1_; if linked_2284 == nil { tu__5 = ifn_2285.Invoke_O__O(arg_2286) } else { tu__5 = linked_2284.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2283, arg_2286) }; var vu__6 any; var root_2287 any = /*line :874:1*/A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_2288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2287, A_arbace_go_check_types_under_A_fn_class); var ifn_2289 lang.IFn; if






	linked_2288 == nil { ifn_2289 = lang.IFn_Cast(root_2287) } else { ifn_2289 = nil }; var arg_2290 any = V__0_; if linked_2288 == nil { vu__6 = ifn_2289.Invoke_O__O(arg_2290) } else { vu__6 = linked_2288.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2287, arg_2290) }; var tmp1 any; var tmp2 /*line :884:1*/*lang.Keyword = A_arbace_go_check_types_A_const_249; var or__1927000174__auto____7 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tu__5)); if jrt.J2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { var tmp3 *lang.Keyword = A_arbace_go_check_types_A_const_249; tmp1 = tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(vu__6)) }; if jrt.J2g_Truth(tmp1) { return nil } else {
		var root_2291 any = A_arbace_go_check_types_A_const_142.GetRawRoot__O(); var linked_2292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2291, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2293 lang.IFn; if linked_2292 == nil { ifn_2293 = lang.IFn_Cast(root_2291) } else { ifn_2293 = nil }; var arg_2294 any; var fnbody__2367 any = A_arbace_go_check_types_missing_method_fn__219000290_A_New_O_O_O_O(static__2, V__0_, same_QMARK___3, vu__6); var tmp4 *jrt.Class; var fncls__2366 *jrt.Class = A_arbace_go_check_types_missing_method_fn__219000290_A_fn_class
		if fncls__2366 == nil { var fncls__2366d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__2367); A_arbace_go_check_types_missing_method_fn__219000290_A_fn_class = fncls__2366d; tmp4 = fncls__2366d } else { tmp4 = fncls__2366 }; arg_2294 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2367, tmp4, nil)
//line :885:1
		var arg_2295 any = lang.RT_Nth_O_I__O_NoInit(tu__5, lang.RT_IntCast_J__I_NoInit(1)); if linked_2292 == nil { return ifn_2293.Invoke_O_O__O(arg_2294, arg_2295) } else { return linked_2292.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2291, arg_2294, arg_2295) } } }
//line :874:1
func (t *A_arbace_go_check_types_missing_method_A) Invoke_O_O_O_O__O(self, V__0_, T__1_, static__2 any) any {



	var root_2368 any = A_arbace_go_check_types_A_const_262.GetRawRoot__O(); var linked_2369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2368, A_arbace_go_check_types_missing_method_A_fn_class); var ifn_2370 lang.IFn; if linked_2369 == nil { ifn_2370 = lang.IFn_Cast(root_2368) } else { ifn_2370 = nil }; var arg_2371 any = V__0_; var arg_2372 any = T__1_; var arg_2373 any = static__2; var arg_2374 any = A_arbace_go_check_types_A_const_144.GetRawRoot__O(); if linked_2369 == nil { return ifn_2370.Invoke_O_O_O_O__O(arg_2371, arg_2372, arg_2373, arg_2374) } else { return linked_2369.(*A_arbace_go_check_types_missing_method_A).Invoke_O_O_O_O_O__O(root_2368, arg_2371, arg_2372, arg_2373, arg_2374)
	}
}





func A_arbace_go_check_types_missing_method_fn__219000290_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_types_missing_method_fn__219000290_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_fn__219000290_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :886:1
func (t *A_arbace_go_check_types_missing_method_fn__219000290_A) Ctor_O_O_O_O(c__static, c__V, c__same_QMARK_, c__vu any) { t.F_static = c__static; t.F_V = c__V; t.F_same_QMARK_ = c__same_QMARK_; t.F_vu = c__vu }
//line :886:1
func (t *A_arbace_go_check_types_missing_method_fn__219000290_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_2296 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_2297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2296, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2298 lang.IFn; if linked_2297 == nil { ifn_2298 = lang.IFn_Cast(root_2296) } else { ifn_2298 = nil }; var arg_2299 any = t.F_vu; if linked_2297 == nil { and__1927000168__auto____2 = ifn_2298.Invoke_O__O(arg_2299) } else { and__1927000168__auto____2 = linked_2297.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2296, arg_2299) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_types_A_const_71; var tmp3 any = t.F_vu; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var f__2 any; var root_2300 any = A_arbace_go_check_types_A_const_229.GetRawRoot__O(); var linked_2301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2300, A_arbace_go_check_types_iface_method_A_fn_class); var ifn_2302 lang.IFn
		if linked_2301 == nil { ifn_2302 = lang.IFn_Cast(root_2300) } else { ifn_2302 = nil }; var arg_2303 any = t.F_vu; var arg_2304 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var arg_2305 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(m__1); if linked_2301 == nil { f__2 = ifn_2302.Invoke_O_O_O__O(arg_2303, arg_2304, arg_2305) } else { f__2 = linked_2301.(*A_arbace_go_check_types_iface_method_A).Invoke_O_O_O_O__O(root_2300, arg_2303, arg_2304, arg_2305) }
		if lang.Util_Identical_O_O__Z_NoInit(f__2, nil) {
			if jrt.J2g_Truth(t.F_static) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_232, m__1, A_arbace_go_check_types_A_const_250, A_arbace_go_check_types_A_const_251)) } else { return nil } } else {
//line :889:1
				var tmp4 any; var root_2306 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_2307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2306, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2308 lang.IFn

				if linked_2307 == nil { ifn_2308 = lang.IFn_Cast(root_2306) } else { ifn_2308 = nil }; var arg_2309 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_same_QMARK_); var tmp6 *lang.Keyword = A_arbace_go_check_types_A_const_65; var tmp7 any; var root_2310 any = A_arbace_go_check_types_A_const_233.GetRawRoot__O(); var linked_2311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2310, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2312 lang.IFn; if linked_2311 == nil { ifn_2312 = lang.IFn_Cast(root_2310) } else { ifn_2312 = nil }; var arg_2313 any = f__2; if linked_2311 == nil { tmp7 = ifn_2312.Invoke_O__O(arg_2313) } else { tmp7 = linked_2311.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2310, arg_2313) }; arg_2309 = tmp5.Invoke_O_O__O(tmp6.Invoke_O__O(tmp7), A_arbace_go_check_types_A_const_65.Invoke_O__O(m__1)); if linked_2307 == nil { tmp4 = ifn_2308.Invoke_O__O(arg_2309) } else { tmp4 = linked_2307.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2306, arg_2309) }
//line :889:1
				if jrt.J2g_Truth(tmp4) { var tmp8 any = A_arbace_go_check_types_A_const_232; var tmp9 any = A_arbace_go_check_types_A_const_250; var tmp10 any = A_arbace_go_check_types_A_const_252; var tmp11 any = A_arbace_go_check_types_A_const_253; var tmp12 any; var root_2314 any = A_arbace_go_check_types_A_const_233.GetRawRoot__O(); var linked_2315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2314, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2316 lang.IFn

					if linked_2315 == nil { ifn_2316 = lang.IFn_Cast(root_2314) } else { ifn_2316 = nil }; var arg_2317 any = f__2; if linked_2315 == nil { tmp12 = ifn_2316.Invoke_O__O(arg_2317) } else { tmp12 = linked_2315.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2314, arg_2317) }
//line :889:1
					return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, m__1, tmp9, tmp10, tmp11, tmp12)) } else { return nil } } } else {
//line :887:1
						var r__2 any; var root_2318 any = A_arbace_go_check_types_A_const_248.GetRawRoot__O(); var linked_2319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2318, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_2320 lang.IFn




						if linked_2319 == nil { ifn_2320 = lang.IFn_Cast(root_2318) } else { ifn_2320 = nil }; var arg_2321 any = t.F_V; var arg_2322 any = jrt.Boolean_FALSE.Ref(); var arg_2323 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var arg_2324 any = A_arbace_go_check_types_A_const_57.Invoke_O__O(m__1); if linked_2319 == nil { r__2 = ifn_2320.Invoke_O_O_O_O__O(arg_2321, arg_2322, arg_2323, arg_2324) } else { r__2 = linked_2319.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_2318, arg_2321, arg_2322, arg_2323, arg_2324) }
						if jrt.J2g_Truth(A_arbace_go_check_types_A_const_243.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_232, m__1, A_arbace_go_check_types_A_const_250, A_arbace_go_check_types_A_const_243)) } else { if lang.Util_Identical_O_O__Z_NoInit(r__2, nil) { var fr__3 any; var root_2357 any = A_arbace_go_check_types_A_const_260.GetRawRoot__O(); var linked_2358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2357, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2359 lang.IFn



							if linked_2358 == nil { ifn_2359 = lang.IFn_Cast(root_2357) } else { ifn_2359 = nil }; var arg_2360 any = lang.IFn_Cast(A_arbace_go_check_types_A_const_261.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_219, jrt.Boolean_TRUE.Ref()); if linked_2358 == nil { ifn_2359.Invoke_O__O(arg_2360) } else { linked_2358.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2357, arg_2360) }; var tmp13 *lang.Compiler_AOTFn; var fnbody__2336 any = A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A_New_O_O(m__1, t.F_V); var tmp14 *jrt.Class; var fncls__2335 *jrt.Class = A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A_fn_class; if fncls__2335 == nil { var fncls__2335d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, fnbody__2336); A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A_fn_class = fncls__2335d; tmp14 = fncls__2335d } else { tmp14 = fncls__2335 }; tmp13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2336, tmp14, nil); fr__3 = Up_Compiler_AOTFn_IFn(tmp13).Invoke__O()
							var tmp15 any; var tmp16 any = A_arbace_go_check_types_A_const_232; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp16, A_arbace_go_check_types_A_const_231.Invoke_O__O(fr__3)); if and__1927000168__auto____4 { var root_2337 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_2338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2337, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2339 lang.IFn; if linked_2338 == nil { ifn_2339 = lang.IFn_Cast(root_2337) } else { ifn_2339 = nil }; var arg_2340 any = A_arbace_go_check_types_A_const_242.Invoke_O__O(fr__3); if linked_2338 == nil { tmp15 = ifn_2339.Invoke_O__O(arg_2340) } else { tmp15 = linked_2338.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2337, arg_2340) } } else { tmp15 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if jrt.J2g_Truth(tmp15) { var d__4 any; var root_2341 any = A_arbace_go_check_types_A_const_255.GetRawRoot__O(); var linked_2342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2341, A_arbace_go_check_types_method_data_A_fn_class); var ifn_2343 lang.IFn
								if linked_2342 == nil { ifn_2343 = lang.IFn_Cast(root_2341) } else { ifn_2343 = nil }; var arg_2344 any = A_arbace_go_check_types_A_const_60.Invoke_O__O(fr__3); if linked_2342 == nil { d__4 = ifn_2343.Invoke_O__O(arg_2344) } else { d__4 = linked_2342.(*A_arbace_go_check_types_method_data_A).Invoke_O_O__O(root_2341, arg_2344) }
//line :898:1
								var tmp17 any = A_arbace_go_check_types_A_const_232; var tmp18 any = A_arbace_go_check_types_A_const_250; var tmp19 *lang.Keyword

								if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_12.Invoke_O__O(d__4), A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1)) { tmp19 = A_arbace_go_check_types_A_const_256 } else { tmp19 = A_arbace_go_check_types_A_const_257 }
//line :898:1
								return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, m__1, tmp18, tmp19.Ref(), A_arbace_go_check_types_A_const_253, d__4)) } else { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_232, m__1, A_arbace_go_check_types_A_const_250, A_arbace_go_check_types_A_const_251)) } } else {
//line :893:1
									if jrt.J2g_Truth(A_arbace_go_check_types_A_const_242.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_232, m__1, A_arbace_go_check_types_A_const_250, A_arbace_go_check_types_A_const_251)) } else { var tmp20 any = A_arbace_go_check_types_A_const_239; if lang.Util_Equiv_O_O__Z_NoInit(tmp20, A_arbace_go_check_types_A_const_231.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_232, m__1, A_arbace_go_check_types_A_const_250, A_arbace_go_check_types_A_const_239)) } else { if A_arbace_go_check_types_A_const_86 != nil { var d__3 any; var root_2345 any = A_arbace_go_check_types_A_const_255.GetRawRoot__O(); var linked_2346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2345, A_arbace_go_check_types_method_data_A_fn_class); var ifn_2347 lang.IFn











										if linked_2346 == nil { ifn_2347 = lang.IFn_Cast(root_2345) } else { ifn_2347 = nil }; var arg_2348 any = A_arbace_go_check_types_A_const_60.Invoke_O__O(r__2); if linked_2346 == nil { d__3 = ifn_2347.Invoke_O__O(arg_2348) } else { d__3 = linked_2346.(*A_arbace_go_check_types_method_data_A).Invoke_O_O__O(root_2345, arg_2348) }
//line :893:1
										var d__4_2 any; var tmp21 any; var and__1927000168__auto____4_2 any = A_arbace_go_check_types_A_const_258.Get__O()












										if jrt.J2g_Truth(and__1927000168__auto____4_2) { var tmp22 any = A_arbace_go_check_types_A_const_232; tmp21 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp22, A_arbace_go_check_types_A_const_231.Invoke_O__O(r__2))).Ref() } else { tmp21 = and__1927000168__auto____4_2 }; if jrt.J2g_Truth(tmp21) { d__4_2 = lang.IFn_Cast(A_arbace_go_check_types_A_const_258.Get__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_234.Invoke_O__O(r__2), d__3) } else { d__4_2 = d__3
										}
										var tmp23 any; var or__1927000174__auto____5 any; var root_2349 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_2350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2349, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2351 lang.IFn; if linked_2350 == nil { ifn_2351 = lang.IFn_Cast(root_2349) } else { ifn_2351 = nil }; var arg_2352 any = A_arbace_go_check_types_A_const_259.Invoke_O__O(d__4_2); if linked_2350 == nil { or__1927000174__auto____5 = ifn_2351.Invoke_O__O(arg_2352) } else { or__1927000174__auto____5 = linked_2350.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2349, arg_2352) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp23 = or__1927000174__auto____5 } else { var root_2353 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_2354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2353, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2355 lang.IFn; if linked_2354 == nil { ifn_2355 = lang.IFn_Cast(root_2353) } else { ifn_2355 = nil }; var tmp24 lang.IFn = lang.IFn_Cast(t.F_same_QMARK_); var arg_2356 any = tmp24.Invoke_O_O__O(A_arbace_go_check_types_A_const_65.Invoke_O__O(d__4_2), A_arbace_go_check_types_A_const_65.Invoke_O__O(m__1)); if linked_2354 == nil { tmp23 = ifn_2355.Invoke_O__O(arg_2356) } else { tmp23 = linked_2354.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2353, arg_2356) } }; if jrt.J2g_Truth(tmp23) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_232, m__1, A_arbace_go_check_types_A_const_250, A_arbace_go_check_types_A_const_252, A_arbace_go_check_types_A_const_253, d__4_2)) } else { return nil } } else {
//line :893:1
											return nil
										}
									}
									} } } } }
func A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A{}; t.Ctor_O_O(p0, p1); return t }
//line :897:1
func (t *A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A) Ctor_O_O(c__m, c__V any) { t.F_m = c__m; t.F_V = c__V }
//line :897:1
func (t *A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2325 any = A_arbace_go_check_types_A_const_248.GetRawRoot__O(); var linked_2326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2325, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_2327 lang.IFn; if linked_2326 == nil { ifn_2327 = lang.IFn_Cast(root_2325) } else { ifn_2327 = nil }; var arg_2328 any; var t_ any = t.F_V; t.F_V = nil; arg_2328 = t_; var arg_2329 any = jrt.Boolean_FALSE.Ref(); var arg_2330 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(t.F_m); var arg_2331 any; var tmp2 *lang.Keyword = A_arbace_go_check_types_A_const_57; var tmp3 any; var t__2 any = t.F_m; t.F_m = nil; tmp3 = t__2; arg_2331 = tmp2.Invoke_O__O(tmp3); if linked_2326 == nil { tmp1 = ifn_2327.Invoke_O_O_O_O__O(arg_2328, arg_2329, arg_2330, arg_2331) } else { tmp1 = linked_2326.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_2325, arg_2328, arg_2329, arg_2330, arg_2331) } }; return nil }(); var root_2332 any = A_arbace_go_check_types_A_const_254.GetRawRoot__O(); var linked_2333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2332, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2334 lang.IFn; if linked_2333 == nil { ifn_2334 = lang.IFn_Cast(root_2332) } else { ifn_2334 = nil }; if linked_2333 == nil { ifn_2334.Invoke__O() } else { linked_2333.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2332) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }
















func A_arbace_go_check_types_satisfies_cause_A_New() *A_arbace_go_check_types_satisfies_cause_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_A{}; t.Ctor(); return t }
//line :914:1
func (t *A_arbace_go_check_types_satisfies_cause_A) Ctor() {}
//line :914:1
func (t *A_arbace_go_check_types_satisfies_cause_A) Invoke_O_O_O__O(self, V__0_, b__1 any) any { var Ti__3_ any; var root_2375 any = A_arbace_go_check_types_A_const_170.GetRawRoot__O(); var linked_2376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2375, A_arbace_go_check_types_bound_iface_A_fn_class); var ifn_2377 lang.IFn; if



	linked_2376 == nil { ifn_2377 = lang.IFn_Cast(root_2375) } else { ifn_2377 = nil }; var arg_2378 any = b__1; if linked_2376 == nil { Ti__3_ = ifn_2377.Invoke_O__O(arg_2378) } else { Ti__3_ = linked_2376.(*A_arbace_go_check_types_bound_iface_A).Invoke_O_O__O(root_2375, arg_2378) }; var Vu__4_ any; var root_2379 any = /*line :914:1*/A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_2380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2379, A_arbace_go_check_types_under_A_fn_class); var ifn_2381 lang.IFn; if




	linked_2380 == nil { ifn_2381 = lang.IFn_Cast(root_2379) } else { ifn_2381 = nil }; var arg_2382 any = V__0_; if linked_2380 == nil { Vu__4_ = ifn_2381.Invoke_O__O(arg_2382) } else { Vu__4_ = linked_2380.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2379, arg_2382) }; var tmp1 any; var or__1927000174__auto____5 bool =
	lang.Util_Identical_O_O__Z_NoInit(Ti__3_, nil); if or__1927000174__auto____5 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_103, Vu__4_); if or__1927000174__auto____6 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var and__1927000168__auto____7 any; var root_2383 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_2384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2383, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2385 lang.IFn
		if linked_2384 == nil { ifn_2385 = lang.IFn_Cast(root_2383) } else { ifn_2385 = nil }; var arg_2386 any = Vu__4_; if linked_2384 == nil { and__1927000168__auto____7 = ifn_2385.Invoke_O__O(arg_2386) } else { and__1927000168__auto____7 = linked_2384.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2383, arg_2386) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp2 any = A_arbace_go_check_types_A_const_73; var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____8 { var tmp3 any = A_arbace_go_check_types_A_const_103; var tmp4 any; var root_2387 any = A_arbace_go_check_types_A_const_108.GetRawRoot__O(); var linked_2388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2387, A_arbace_go_check_types_under_A_fn_class); var ifn_2389 lang.IFn; if linked_2388 == nil { ifn_2389 = lang.IFn_Cast(root_2387) } else { ifn_2389 = nil }; var arg_2390 any = lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(1)); if linked_2388 == nil { tmp4 = ifn_2389.Invoke_O__O(arg_2390) } else { tmp4 = linked_2388.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2387, arg_2390) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp1 = and__1927000168__auto____7 } } }; if /*line :920:1*/ jrt.J2g_Truth(tmp1) { return nil } else { var Tts__5_ any; var root_2391 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_2392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2391, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_2393 lang.IFn


			if linked_2392 == nil { ifn_2393 = lang.IFn_Cast(root_2391) } else { ifn_2393 = nil }; var arg_2394 any = Ti__3_; if linked_2392 == nil { Tts__5_ = ifn_2393.Invoke_O__O(arg_2394) } else { Tts__5_ = linked_2392.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_2391, arg_2394) }
//line :920:1
			var Vi__6_ any; var tmp5 any; var and__1927000168__auto____6 any; var root_2395 any = A_arbace_go_check_types_A_const_84.GetRawRoot__O(); var linked_2396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2395, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2397 lang.IFn



			if linked_2396 == nil { ifn_2397 = lang.IFn_Cast(root_2395) } else { ifn_2397 = nil }; var arg_2398 any = Vu__4_; if linked_2396 == nil { and__1927000168__auto____6 = ifn_2397.Invoke_O__O(arg_2398) } else { and__1927000168__auto____6 = linked_2396.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2395, arg_2398) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp6 any = A_arbace_go_check_types_A_const_71; tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp6, lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp5 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp5) { Vi__6_ = Vu__4_ } else { Vi__6_ = nil }
//line :920:1
			var Vts__7_ any




			if jrt.J2g_Truth(Vi__6_) { var root_2399 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_2400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2399, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_2401 lang.IFn; if linked_2400 == nil { ifn_2401 = lang.IFn_Cast(root_2399) } else { ifn_2401 = nil }; var arg_2402 any = Vi__6_; if linked_2400 == nil { Vts__7_ = ifn_2401.Invoke_O__O(arg_2402) } else { Vts__7_ = linked_2400.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_2399, arg_2402) } } else { Vts__7_ = nil }
//line :920:1
			var T_str__8_ any; var root_2403 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_2404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2403, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2405 lang.IFn





			if linked_2404 == nil { ifn_2405 = lang.IFn_Cast(root_2403) } else { ifn_2405 = nil }; var arg_2406 any = b__1; if linked_2404 == nil { T_str__8_ = ifn_2405.Invoke_O__O(arg_2406) } else { T_str__8_ = linked_2404.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2403, arg_2406) }
			var tmp7 any; var and__1927000168__auto____9 any; var root_2407 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_2408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2407, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2409 lang.IFn
			if linked_2408 == nil { ifn_2409 = lang.IFn_Cast(root_2407) } else { ifn_2409 = nil }; var arg_2410 any = lang.RT_Nth_O_I__O_NoInit(Ti__3_, lang.RT_IntCast_J__I_NoInit(1)); if linked_2408 == nil { and__1927000168__auto____9 = ifn_2409.Invoke_O__O(arg_2410) } else { and__1927000168__auto____9 = linked_2408.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2407, arg_2410) }; if jrt.J2g_Truth(and__1927000168__auto____9) { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(Ti__3_, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref() } else { tmp7 = and__1927000168__auto____9 }
//line :927:1
			if jrt.J2g_Truth(tmp7) { return nil } else { var tmp8 any
				var and__1927000168__auto____9_2 any = Vts__7_
				if jrt.J2g_Truth(and__1927000168__auto____9_2) { var root_2411 any = A_arbace_go_check_types_A_const_263.GetRawRoot__O(); var linked_2412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2411, A_arbace_go_check_types_tset_empty_QMARK__A_fn_class); var ifn_2413 lang.IFn; if linked_2412 == nil { ifn_2413 = lang.IFn_Cast(root_2411) } else { ifn_2413 = nil }; var arg_2414 any = Vts__7_; if linked_2412 == nil { tmp8 = ifn_2413.Invoke_O__O(arg_2414) } else { tmp8 = linked_2412.(*A_arbace_go_check_types_tset_empty_QMARK__A).Invoke_O_O__O(root_2411, arg_2414) } } else { tmp8 = and__1927000168__auto____9_2 }
//line :927:1
				if jrt.J2g_Truth(tmp8) { return nil } else { var tmp9 any; var root_2415 any = A_arbace_go_check_types_A_const_263.GetRawRoot__O(); var linked_2416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2415, A_arbace_go_check_types_tset_empty_QMARK__A_fn_class); var ifn_2417 lang.IFn


					if linked_2416 == nil { ifn_2417 = lang.IFn_Cast(root_2415) } else { ifn_2417 = nil }; var arg_2418 any = Tts__5_; if linked_2416 == nil { tmp9 = ifn_2417.Invoke_O__O(arg_2418) } else { tmp9 = linked_2416.(*A_arbace_go_check_types_tset_empty_QMARK__A).Invoke_O_O__O(root_2415, arg_2418) }
//line :927:1
					if jrt.J2g_Truth(tmp9) {


						return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_35, nil, Lit_36), jrt.RefArrayOf(jrt.Object_class, nil, T_str__8_, nil)).Ref() } else {
//line :927:1
							if A_arbace_go_check_types_A_const_86 != nil { var temp__1927000408__auto____9 any; var root_2419 any = A_arbace_go_check_types_A_const_262.GetRawRoot__O(); var linked_2420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2419, A_arbace_go_check_types_missing_method_A_fn_class); var ifn_2421 lang.IFn




								if linked_2420 == nil { ifn_2421 = lang.IFn_Cast(root_2419) } else { ifn_2421 = nil }; var arg_2422 any = V__0_; var arg_2423 any = Ti__3_; var arg_2424 any = jrt.Boolean_TRUE.Ref(); if linked_2420 == nil { temp__1927000408__auto____9 = ifn_2421.Invoke_O_O_O__O(arg_2422, arg_2423, arg_2424) } else { temp__1927000408__auto____9 = linked_2420.(*A_arbace_go_check_types_missing_method_A).Invoke_O_O_O_O__O(root_2419, arg_2422, arg_2423, arg_2424) }; if jrt.J2g_Truth(temp__1927000408__auto____9) { var mm__10 any = temp__1927000408__auto____9; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_37, nil, Lit_38, nil, Lit_31); var tmp11 any; var root_2425 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_2426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2425, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2427 lang.IFn
									if linked_2426 == nil { ifn_2427 = lang.IFn_Cast(root_2425) } else { ifn_2427 = nil }; var arg_2428 any = V__0_; if linked_2426 == nil { tmp11 = ifn_2427.Invoke_O__O(arg_2428) } else { tmp11 = linked_2426.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2425, arg_2428) }; var tmp12 *lang.Keyword = A_arbace_go_check_types_A_const_12; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp11, nil, T_str__8_, nil, tmp12.Invoke_O__O(A_arbace_go_check_types_A_const_232.Invoke_O__O(mm__10)), nil)).Ref() } else {
//line :932:1
										var comparability__10 any; var fnbody__2457 any = A_arbace_go_check_types_satisfies_cause_comparability__219000295_A_New_O_O(Tts__5_, V__0_); var tmp13 *jrt.Class
										var fncls__2456 /*line :932:1*/*jrt.Class = A_arbace_go_check_types_satisfies_cause_comparability__219000295_A_fn_class


										if fncls__2456 == nil { var fncls__2456d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, fnbody__2457); A_arbace_go_check_types_satisfies_cause_comparability__219000295_A_fn_class = fncls__2456d; tmp13 = fncls__2456d } else { tmp13 = fncls__2456 }; comparability__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2457, tmp13, nil)








										var tmp14 any; var root_2458 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_2459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2458, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2460 lang.IFn
										if linked_2459 == nil { ifn_2460 = lang.IFn_Cast(root_2458) } else { ifn_2460 = nil }; var arg_2461 any; var root_2462 any = A_arbace_go_check_types_A_const_173.GetRawRoot__O(); var linked_2463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2462, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_2464 lang.IFn; if linked_2463 == nil { ifn_2464 = lang.IFn_Cast(root_2462) } else { ifn_2464 = nil }; var arg_2465 any = Tts__5_; if linked_2463 == nil { arg_2461 = ifn_2464.Invoke_O__O(arg_2465) } else { arg_2461 = linked_2463.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_2462, arg_2465) }; if linked_2459 == nil { tmp14 = ifn_2460.Invoke_O__O(arg_2461) } else { tmp14 = linked_2459.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2458, arg_2461) }
//line :944:1
										if jrt.J2g_Truth(tmp14) {
											return lang.IFn_Cast(comparability__10).Invoke__O() } else {
//line :944:1
												if jrt.J2g_Truth(Vts__7_) {

													var tmp15 any; var root_2466 any = A_arbace_go_check_types_A_const_265.GetRawRoot__O(); var linked_2467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2466, A_arbace_go_check_types_terms_subset_QMARK__A_fn_class); var ifn_2468 lang.IFn; if linked_2467 == nil { ifn_2468 = lang.IFn_Cast(root_2466) } else { ifn_2468 = nil }; var arg_2469 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(Vts__7_); var arg_2470 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(Tts__5_); if linked_2467 == nil { tmp15 = ifn_2468.Invoke_O_O__O(arg_2469, arg_2470) } else { tmp15 = linked_2467.(*A_arbace_go_check_types_terms_subset_QMARK__A).Invoke_O_O_O__O(root_2466, arg_2469, arg_2470) }; if jrt.J2g_Truth(tmp15) {
														return lang.IFn_Cast(comparability__10).Invoke__O() } else {
															var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_37, nil); var tmp17 any; var root_2471 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_2472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2471, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2473 lang.IFn; if linked_2472 == nil { ifn_2473 = lang.IFn_Cast(root_2471) } else { ifn_2473 = nil }; var arg_2474 any = V__0_; if linked_2472 == nil { tmp17 = ifn_2473.Invoke_O__O(arg_2474) } else { tmp17 = linked_2472.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2471, arg_2474) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, tmp17, nil, T_str__8_)).Ref() } } else {
//line :944:1
																var tmp18 any; var root_2475 any = A_arbace_go_check_types_A_const_266.GetRawRoot__O(); var linked_2476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2475, A_arbace_go_check_types_terms_includes_QMARK__A_fn_class); var ifn_2477 lang.IFn




																if linked_2476 == nil { ifn_2477 = lang.IFn_Cast(root_2475) } else { ifn_2477 = nil }; var arg_2478 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(Tts__5_); var arg_2479 any = V__0_; if linked_2476 == nil { tmp18 = ifn_2477.Invoke_O_O__O(arg_2478, arg_2479) } else { tmp18 = linked_2476.(*A_arbace_go_check_types_terms_includes_QMARK__A).Invoke_O_O_O__O(root_2475, arg_2478, arg_2479) }
//line :944:1
																if jrt.J2g_Truth(tmp18) {




																	return lang.IFn_Cast(comparability__10).Invoke__O() } else {
//line :944:1
																		if A_arbace_go_check_types_A_const_86 != nil {





																			var tmp19 *jrt.RefArray = jrt.ConstRefArray("[0,8,ns18: does not satisfy ns2: (ns12: missing in ns1:)", []*jrt.Class{jrt.String_class}); var tmp20 any; var root_2480 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_2481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2480, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2482 lang.IFn; if linked_2481 == nil { ifn_2482 = lang.IFn_Cast(root_2480) } else { ifn_2482 = nil }; var arg_2483 any = V__0_; if linked_2481 == nil { tmp20 = ifn_2482.Invoke_O__O(arg_2483) } else { tmp20 = linked_2481.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2480, arg_2483) }; var tmp21 any = tmp20; var tmp22 any; var root_2484 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_2485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2484, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2486 lang.IFn; if linked_2485 == nil { ifn_2486 = lang.IFn_Cast(root_2484) } else { ifn_2486 = nil }; var arg_2487 any = V__0_; if linked_2485 == nil { tmp22 = ifn_2486.Invoke_O__O(arg_2487) } else { tmp22 = linked_2485.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2484, arg_2487) }; var tmp23 any = tmp22; var tmp24 any; var root_2488 any = A_arbace_go_check_types_A_const_202.GetRawRoot__O(); var linked_2489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2488, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_2490 lang.IFn
																			if linked_2489 == nil { ifn_2490 = lang.IFn_Cast(root_2488) } else { ifn_2490 = nil }; var arg_2491 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(Tts__5_); if linked_2489 == nil { tmp24 = ifn_2490.Invoke_O__O(arg_2491) } else { tmp24 = linked_2489.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_2488, arg_2491) }
//line :950:1
																			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp19, jrt.RefArrayOf(jrt.Object_class, tmp21, nil, T_str__8_, nil, tmp23, nil, tmp24, nil)).Ref() } else {
//line :944:1
																				return nil } } } } } } else {
//line :927:1
																					return nil } } } } } }







func A_arbace_go_check_types_satisfies_cause_comparability__219000295_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_satisfies_cause_comparability__219000295_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_comparability__219000295_A{}; t.Ctor_O_O(p0, p1); return t }
//line :935:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000295_A) Ctor_O_O(c__Tts, c__V any) { t.F_Tts = c__Tts; t.F_V = c__V }
//line :935:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000295_A) Invoke_O__O(self any) any {
	var tmp1 any; var root_2429 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_2430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2429, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2431 lang.IFn
	if linked_2430 == nil { ifn_2431 = lang.IFn_Cast(root_2429) } else { ifn_2431 = nil }; var arg_2432 any; var tmp2 any = A_arbace_go_check_types_A_const_131; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_go_check_types_A_const_132.Invoke_O__O(t.F_Tts)) {
		arg_2432 = A_arbace_go_check_types_A_const_133.Invoke_O__O(t.F_Tts) } else {
			var root_2433 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_2434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2433, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2435 lang.IFn; if linked_2434 == nil { ifn_2435 = lang.IFn_Cast(root_2433) } else { ifn_2435 = nil }; var arg_2436 any; var fnbody__2443 any = A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A_New(); var tmp3 *jrt.Class; var fncls__2442 *jrt.Class = A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A_fn_class; if fncls__2442 == nil { var fncls__2442d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A_fn_class = fncls__2442d; tmp3 = fncls__2442d } else { tmp3 = fncls__2442 }; arg_2436 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2443, tmp3, nil); var arg_2437 any = A_arbace_go_check_types_A_const_132.Invoke_O__O(t.F_Tts); if linked_2434 == nil { arg_2432 = ifn_2435.Invoke_O_O__O(arg_2436, arg_2437) } else { arg_2432 = linked_2434.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2433, arg_2436, arg_2437) } }
//line :937:1
	if linked_2430 == nil { tmp1 = ifn_2431.Invoke_O__O(arg_2432) } else { tmp1 = linked_2430.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2429, arg_2432) }
//line :936:1
	if jrt.J2g_Truth(tmp1) { return nil } else { var tmp4 any; var root_2444 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_2445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2444, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_2446 lang.IFn




		if linked_2445 == nil { ifn_2446 = lang.IFn_Cast(root_2444) } else { ifn_2446 = nil }; var arg_2447 any = t.F_V; if linked_2445 == nil { tmp4 = ifn_2446.Invoke_O__O(arg_2447) } else { tmp4 = linked_2445.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O__O(root_2444, arg_2447) }
//line :936:1
		if jrt.J2g_Truth(tmp4) { return nil } else { var tmp5 any; var root_2448 any = A_arbace_go_check_types_A_const_264.GetRawRoot__O(); var linked_2449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2448, A_arbace_go_check_types_comparable_QMARK__A_fn_class); var ifn_2450 lang.IFn





			if linked_2449 == nil { ifn_2450 = lang.IFn_Cast(root_2448) } else { ifn_2450 = nil }; var arg_2451 any = t.F_V; if linked_2449 == nil { tmp5 = ifn_2450.Invoke_O__O(arg_2451) } else { tmp5 = linked_2449.(*A_arbace_go_check_types_comparable_QMARK__A).Invoke_O_O__O(root_2448, arg_2451) }
//line :936:1
			if jrt.J2g_Truth(tmp5) { return nil } else { if A_arbace_go_check_types_A_const_86 != nil {






				var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_41); var tmp7 any; var root_2452 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_2453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2452, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2454 lang.IFn; if linked_2453 == nil { ifn_2454 = lang.IFn_Cast(root_2452) } else { ifn_2454 = nil }; var arg_2455 any = t.F_V; if linked_2453 == nil { tmp7 = ifn_2454.Invoke_O__O(arg_2455) } else { tmp7 = linked_2453.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2452, arg_2455) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil)).Ref() } else {
//line :936:1
					return nil
				}
			} } } }
func A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A_New() *A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A{}; t.Ctor(); return t }
//line :939:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A) Ctor() {}
//line :939:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A) Invoke_O_O__O(self, p__219000296__1 any) any { var vec__219000298__2 any = p__219000296__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000298__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000298__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2438 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_2439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2438, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_2440 lang.IFn; _ = ___3; if linked_2439 == nil { ifn_2440 = lang.IFn_Cast(root_2438) } else { ifn_2440 = nil }; var arg_2441 any = ty__4; if linked_2439 == nil { return ifn_2440.Invoke_O__O(arg_2441) } else { return linked_2439.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O__O(root_2438, arg_2441) } }

























































type A_arbace_go_check_types_A struct{ jrt.Object }

var A_arbace_go_check_types_A_const_pool *jrt.RefArray

var A_arbace_go_check_types_A_const_0 *lang.Var

var A_arbace_go_check_types_A_const_1 any

var A_arbace_go_check_types_A_const_2 any

var A_arbace_go_check_types_A_const_3 *lang.Var

var A_arbace_go_check_types_A_const_4 any

var A_arbace_go_check_types_A_const_5 *lang.Var

var A_arbace_go_check_types_A_const_6 *lang.Var

var A_arbace_go_check_types_A_const_7 *lang.Var

var A_arbace_go_check_types_A_const_8 *lang.Var

var A_arbace_go_check_types_A_const_9 any

var A_arbace_go_check_types_A_const_10 *lang.Var

var A_arbace_go_check_types_A_const_11 *lang.Keyword

var A_arbace_go_check_types_A_const_12 *lang.Keyword

var A_arbace_go_check_types_A_const_13 *lang.Var

var A_arbace_go_check_types_A_const_14 *lang.Keyword

var A_arbace_go_check_types_A_const_15 any

var A_arbace_go_check_types_A_const_16 *lang.Keyword

var A_arbace_go_check_types_A_const_17 *lang.Keyword

var A_arbace_go_check_types_A_const_18 *lang.Keyword

var A_arbace_go_check_types_A_const_19 *lang.Keyword

var A_arbace_go_check_types_A_const_20 any

var A_arbace_go_check_types_A_const_21 *lang.Keyword

var A_arbace_go_check_types_A_const_22 any

var A_arbace_go_check_types_A_const_23 *lang.Keyword

var A_arbace_go_check_types_A_const_24 any

var A_arbace_go_check_types_A_const_25 *lang.Keyword

var A_arbace_go_check_types_A_const_26 *lang.Keyword

var A_arbace_go_check_types_A_const_27 *lang.Keyword

var A_arbace_go_check_types_A_const_28 *lang.Keyword

var A_arbace_go_check_types_A_const_29 *lang.Keyword

var A_arbace_go_check_types_A_const_30 *lang.Keyword

var A_arbace_go_check_types_A_const_31 *lang.Keyword

var A_arbace_go_check_types_A_const_32 *lang.Keyword

var A_arbace_go_check_types_A_const_33 *lang.Keyword

var A_arbace_go_check_types_A_const_34 *lang.Keyword

var A_arbace_go_check_types_A_const_35 *lang.Keyword

var A_arbace_go_check_types_A_const_36 *lang.Keyword

var A_arbace_go_check_types_A_const_37 *lang.Keyword

var A_arbace_go_check_types_A_const_38 *lang.Keyword

var A_arbace_go_check_types_A_const_39 any

var A_arbace_go_check_types_A_const_40 *lang.Keyword

var A_arbace_go_check_types_A_const_41 *lang.Keyword

var A_arbace_go_check_types_A_const_42 *lang.Keyword

var A_arbace_go_check_types_A_const_43 *lang.Keyword

var A_arbace_go_check_types_A_const_44 any

var A_arbace_go_check_types_A_const_45 *lang.Keyword

var A_arbace_go_check_types_A_const_46 *lang.Keyword

var A_arbace_go_check_types_A_const_47 *lang.Keyword

var A_arbace_go_check_types_A_const_48 *lang.Keyword

var A_arbace_go_check_types_A_const_49 *lang.Keyword

var A_arbace_go_check_types_A_const_50 *lang.Keyword

var A_arbace_go_check_types_A_const_51 *lang.Keyword

var A_arbace_go_check_types_A_const_52 *lang.Keyword

var A_arbace_go_check_types_A_const_53 *lang.Keyword

var A_arbace_go_check_types_A_const_54 *lang.Var

var A_arbace_go_check_types_A_const_55 *lang.Var

var A_arbace_go_check_types_A_const_56 *lang.Keyword

var A_arbace_go_check_types_A_const_57 *lang.Keyword

var A_arbace_go_check_types_A_const_58 *lang.Keyword

var A_arbace_go_check_types_A_const_59 *lang.Keyword

var A_arbace_go_check_types_A_const_60 *lang.Keyword

var A_arbace_go_check_types_A_const_61 *lang.Var

var A_arbace_go_check_types_A_const_62 *lang.Var

var A_arbace_go_check_types_A_const_63 *lang.Var

var A_arbace_go_check_types_A_const_64 *lang.Var

var A_arbace_go_check_types_A_const_65 *lang.Keyword

var A_arbace_go_check_types_A_const_66 *lang.Var

var A_arbace_go_check_types_A_const_67 *lang.Var

var A_arbace_go_check_types_A_const_68 *lang.Var

var A_arbace_go_check_types_A_const_69 *lang.Keyword

var A_arbace_go_check_types_A_const_70 *lang.Var

var A_arbace_go_check_types_A_const_71 *lang.Keyword

var A_arbace_go_check_types_A_const_72 *lang.Var

var A_arbace_go_check_types_A_const_73 *lang.Keyword

var A_arbace_go_check_types_A_const_74 *lang.Keyword

var A_arbace_go_check_types_A_const_75 any

var A_arbace_go_check_types_A_const_76 *lang.Keyword

var A_arbace_go_check_types_A_const_77 *lang.Keyword

var A_arbace_go_check_types_A_const_78 *lang.Keyword

var A_arbace_go_check_types_A_const_79 *lang.Keyword

var A_arbace_go_check_types_A_const_80 *lang.Keyword

var A_arbace_go_check_types_A_const_81 *lang.Keyword

var A_arbace_go_check_types_A_const_82 *lang.Keyword

var A_arbace_go_check_types_A_const_83 *lang.Var

var A_arbace_go_check_types_A_const_84 *lang.Var

var A_arbace_go_check_types_A_const_85 *lang.Keyword

var A_arbace_go_check_types_A_const_86 *lang.Keyword

var A_arbace_go_check_types_A_const_87 *lang.Var

var A_arbace_go_check_types_A_const_88 *lang.Var

var A_arbace_go_check_types_A_const_89 *lang.Var

var A_arbace_go_check_types_A_const_90 *lang.Var

var A_arbace_go_check_types_A_const_91 *lang.Var

var A_arbace_go_check_types_A_const_92 *lang.Var

var A_arbace_go_check_types_A_const_93 *lang.Var

var A_arbace_go_check_types_A_const_94 *lang.Var

var A_arbace_go_check_types_A_const_95 *lang.Var

var A_arbace_go_check_types_A_const_96 *lang.Keyword

var A_arbace_go_check_types_A_const_97 *lang.Var

var A_arbace_go_check_types_A_const_98 *lang.Keyword

var A_arbace_go_check_types_A_const_99 *lang.Var

var A_arbace_go_check_types_A_const_100 *lang.Keyword

var A_arbace_go_check_types_A_const_101 *lang.Var

var A_arbace_go_check_types_A_const_102 *lang.Var

var A_arbace_go_check_types_A_const_103 *lang.Keyword

var A_arbace_go_check_types_A_const_104 *lang.Var

var A_arbace_go_check_types_A_const_105 *lang.Keyword

var A_arbace_go_check_types_A_const_106 *lang.Var

var A_arbace_go_check_types_A_const_107 *lang.Var

var A_arbace_go_check_types_A_const_108 *lang.Var

var A_arbace_go_check_types_A_const_109 *lang.Var

var A_arbace_go_check_types_A_const_110 *lang.Var

var A_arbace_go_check_types_A_const_111 *lang.Var

var A_arbace_go_check_types_A_const_112 *lang.Var

var A_arbace_go_check_types_A_const_113 *lang.Var

var A_arbace_go_check_types_A_const_114 *lang.Var

var A_arbace_go_check_types_A_const_115 *lang.Var

var A_arbace_go_check_types_A_const_116 any

var A_arbace_go_check_types_A_const_117 *lang.Var

var A_arbace_go_check_types_A_const_118 *lang.Var

var A_arbace_go_check_types_A_const_119 *lang.Var

var A_arbace_go_check_types_A_const_120 *lang.Var

var A_arbace_go_check_types_A_const_121 *lang.Var

var A_arbace_go_check_types_A_const_122 *lang.Var

var A_arbace_go_check_types_A_const_123 any

var A_arbace_go_check_types_A_const_124 *lang.Var

var A_arbace_go_check_types_A_const_125 *lang.Var

var A_arbace_go_check_types_A_const_126 *lang.Var

var A_arbace_go_check_types_A_const_127 any

var A_arbace_go_check_types_A_const_128 *lang.Var

var A_arbace_go_check_types_A_const_129 *lang.Var

var A_arbace_go_check_types_A_const_130 *lang.Keyword

var A_arbace_go_check_types_A_const_131 *lang.Keyword

var A_arbace_go_check_types_A_const_132 *lang.Keyword

var A_arbace_go_check_types_A_const_133 *lang.Keyword

var A_arbace_go_check_types_A_const_134 *lang.Var

var A_arbace_go_check_types_A_const_135 *lang.Var

var A_arbace_go_check_types_A_const_136 *lang.Var

var A_arbace_go_check_types_A_const_137 *lang.Var

var A_arbace_go_check_types_A_const_138 *lang.Var

var A_arbace_go_check_types_A_const_139 *lang.Var

var A_arbace_go_check_types_A_const_140 *lang.Var

var A_arbace_go_check_types_A_const_141 *lang.Var

var A_arbace_go_check_types_A_const_142 *lang.Var

var A_arbace_go_check_types_A_const_143 *lang.Keyword

var A_arbace_go_check_types_A_const_144 *lang.Var

var A_arbace_go_check_types_A_const_145 *lang.Var

var A_arbace_go_check_types_A_const_146 *lang.Var

var A_arbace_go_check_types_A_const_147 *lang.Var

var A_arbace_go_check_types_A_const_148 *lang.Var

var A_arbace_go_check_types_A_const_149 *lang.Keyword

var A_arbace_go_check_types_A_const_150 *lang.Var

var A_arbace_go_check_types_A_const_151 *lang.Var

var A_arbace_go_check_types_A_const_152 *lang.Var

var A_arbace_go_check_types_A_const_153 *lang.Var

var A_arbace_go_check_types_A_const_154 *lang.Var

var A_arbace_go_check_types_A_const_155 *lang.Var

var A_arbace_go_check_types_A_const_156 *lang.Var

var A_arbace_go_check_types_A_const_157 *lang.Var

var A_arbace_go_check_types_A_const_158 *lang.Var

var A_arbace_go_check_types_A_const_159 *lang.Var

var A_arbace_go_check_types_A_const_160 *lang.Var

var A_arbace_go_check_types_A_const_161 *lang.Var

var A_arbace_go_check_types_A_const_162 *lang.Var

var A_arbace_go_check_types_A_const_163 *lang.Var

var A_arbace_go_check_types_A_const_164 *lang.Var

var A_arbace_go_check_types_A_const_165 *lang.Var

var A_arbace_go_check_types_A_const_166 *lang.Var

var A_arbace_go_check_types_A_const_167 *lang.Var

var A_arbace_go_check_types_A_const_168 *lang.Var

var A_arbace_go_check_types_A_const_169 *lang.Keyword

var A_arbace_go_check_types_A_const_170 *lang.Var

var A_arbace_go_check_types_A_const_171 *lang.Keyword

var A_arbace_go_check_types_A_const_172 *lang.Var

var A_arbace_go_check_types_A_const_173 *lang.Var

var A_arbace_go_check_types_A_const_174 any

var A_arbace_go_check_types_A_const_175 *lang.Var

var A_arbace_go_check_types_A_const_176 *lang.Var

var A_arbace_go_check_types_A_const_177 *lang.Var

var A_arbace_go_check_types_A_const_178 *lang.Var

var A_arbace_go_check_types_A_const_179 *lang.Var

var A_arbace_go_check_types_A_const_180 *lang.Var

var A_arbace_go_check_types_A_const_181 *lang.Var

var A_arbace_go_check_types_A_const_182 any

var A_arbace_go_check_types_A_const_183 *lang.Keyword

var A_arbace_go_check_types_A_const_184 any

var A_arbace_go_check_types_A_const_185 any

var A_arbace_go_check_types_A_const_186 *lang.Var

var A_arbace_go_check_types_A_const_187 *lang.Var

var A_arbace_go_check_types_A_const_188 *lang.Var

var A_arbace_go_check_types_A_const_189 *lang.Var

var A_arbace_go_check_types_A_const_190 *lang.Var

var A_arbace_go_check_types_A_const_191 *lang.Var

var A_arbace_go_check_types_A_const_192 *lang.Keyword

var A_arbace_go_check_types_A_const_193 *lang.Var

var A_arbace_go_check_types_A_const_194 *lang.Var

var A_arbace_go_check_types_A_const_195 *lang.Keyword

var A_arbace_go_check_types_A_const_196 *lang.Var

var A_arbace_go_check_types_A_const_197 *lang.Var

var A_arbace_go_check_types_A_const_198 *lang.Var

var A_arbace_go_check_types_A_const_199 *lang.Var

var A_arbace_go_check_types_A_const_200 any

var A_arbace_go_check_types_A_const_201 *lang.Var

var A_arbace_go_check_types_A_const_202 *lang.Var

var A_arbace_go_check_types_A_const_203 *lang.Keyword

var A_arbace_go_check_types_A_const_204 *lang.Keyword

var A_arbace_go_check_types_A_const_205 *lang.Var

var A_arbace_go_check_types_A_const_206 any

var A_arbace_go_check_types_A_const_207 *lang.Var

var A_arbace_go_check_types_A_const_208 *lang.Var

var A_arbace_go_check_types_A_const_209 *lang.Var

var A_arbace_go_check_types_A_const_210 any

var A_arbace_go_check_types_A_const_211 *lang.Var

var A_arbace_go_check_types_A_const_212 *lang.Var

var A_arbace_go_check_types_A_const_213 *lang.Var

var A_arbace_go_check_types_A_const_214 *lang.Var

var A_arbace_go_check_types_A_const_215 any

var A_arbace_go_check_types_A_const_216 *lang.Var

var A_arbace_go_check_types_A_const_217 *lang.Var

var A_arbace_go_check_types_A_const_218 *lang.Keyword

var A_arbace_go_check_types_A_const_219 *lang.Var

var A_arbace_go_check_types_A_const_220 *lang.Var

var A_arbace_go_check_types_A_const_221 *lang.Var

var A_arbace_go_check_types_A_const_222 *lang.Var

var A_arbace_go_check_types_A_const_223 *lang.Var

var A_arbace_go_check_types_A_const_224 *lang.Var

var A_arbace_go_check_types_A_const_225 *lang.Keyword

var A_arbace_go_check_types_A_const_226 *lang.Var

var A_arbace_go_check_types_A_const_227 *lang.Var

var A_arbace_go_check_types_A_const_228 *lang.Var

var A_arbace_go_check_types_A_const_229 *lang.Var

var A_arbace_go_check_types_A_const_230 any

var A_arbace_go_check_types_A_const_231 *lang.Keyword

var A_arbace_go_check_types_A_const_232 *lang.Keyword

var A_arbace_go_check_types_A_const_233 *lang.Var

var A_arbace_go_check_types_A_const_234 *lang.Keyword

var A_arbace_go_check_types_A_const_235 *lang.Keyword

var A_arbace_go_check_types_A_const_236 *lang.Keyword

var A_arbace_go_check_types_A_const_237 *lang.Keyword

var A_arbace_go_check_types_A_const_238 any

var A_arbace_go_check_types_A_const_239 *lang.Keyword

var A_arbace_go_check_types_A_const_240 any

var A_arbace_go_check_types_A_const_241 *lang.Keyword

var A_arbace_go_check_types_A_const_242 *lang.Keyword

var A_arbace_go_check_types_A_const_243 *lang.Keyword

var A_arbace_go_check_types_A_const_244 *lang.Var

var A_arbace_go_check_types_A_const_245 *lang.Keyword

var A_arbace_go_check_types_A_const_246 *lang.Var

var A_arbace_go_check_types_A_const_247 *lang.Var

var A_arbace_go_check_types_A_const_248 *lang.Var

var A_arbace_go_check_types_A_const_249 *lang.Keyword

var A_arbace_go_check_types_A_const_250 *lang.Keyword

var A_arbace_go_check_types_A_const_251 *lang.Keyword

var A_arbace_go_check_types_A_const_252 *lang.Keyword

var A_arbace_go_check_types_A_const_253 *lang.Keyword

var A_arbace_go_check_types_A_const_254 *lang.Var

var A_arbace_go_check_types_A_const_255 *lang.Var

var A_arbace_go_check_types_A_const_256 *lang.Keyword

var A_arbace_go_check_types_A_const_257 *lang.Keyword

var A_arbace_go_check_types_A_const_258 *lang.Var

var A_arbace_go_check_types_A_const_259 *lang.Keyword

var A_arbace_go_check_types_A_const_260 *lang.Var

var A_arbace_go_check_types_A_const_261 *lang.Var

var A_arbace_go_check_types_A_const_262 *lang.Var

var A_arbace_go_check_types_A_const_263 *lang.Var

var A_arbace_go_check_types_A_const_264 *lang.Var

var A_arbace_go_check_types_A_const_265 *lang.Var

var A_arbace_go_check_types_A_const_266 *lang.Var

var A_arbace_go_check_types_A_init jrt.ClassInit

func A_arbace_go_check_types_A_Init() { if !A_arbace_go_check_types_A_init.Done() { A_arbace_go_check_types_A_init.Run(A_arbace_go_check_types_A_clinit) } }

func A_arbace_go_check_types_A_clinit() { A_arbace_go_check_types_A_clinit_p0(); A_arbace_go_check_types_A_clinit_p1(); A_arbace_go_check_types_A_clinit_p2(); A_arbace_go_check_types_A_clinit_p3(); A_arbace_go_check_types_A_clinit_p4(); A_arbace_go_check_types_A_clinit_p5(); A_arbace_go_check_types_A_clinit_p6(); A_arbace_go_check_types_A_clinit_p7(); A_arbace_go_check_types_A_clinit_p8(); A_arbace_go_check_types_A_clinit_p9(); A_arbace_go_check_types_A_clinit_p10(); A_arbace_go_check_types_A_clinit_p11(); A_arbace_go_check_types_A_clinit_p12(); A_arbace_go_check_types_A_clinit_p13(); A_arbace_go_check_types_A_clinit_p14(); A_arbace_go_check_types_A_clinit_p15(); A_arbace_go_check_types_A_clinit_p16(); A_arbace_go_check_types_A_clinit_p17(); A_arbace_go_check_types_A_clinit_p18(); A_arbace_go_check_types_A_clinit_p19(); A_arbace_go_check_types_A_clinit_p20(); A_arbace_go_check_types_A_clinit_p21(); A_arbace_go_check_types_A_clinit_p22() }

func A_arbace_go_check_types_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_types_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 368); A_arbace_go_check_types_A_const_0 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[101]); A_arbace_go_check_types_A_const_1 = A_arbace_go_check_types_A_const_pool.A[102]; A_arbace_go_check_types_A_const_2 = A_arbace_go_check_types_A_const_pool.A[103]; A_arbace_go_check_types_A_const_3 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[104]); A_arbace_go_check_types_A_const_4 = A_arbace_go_check_types_A_const_pool.A[105]; A_arbace_go_check_types_A_const_5 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[106]); A_arbace_go_check_types_A_const_6 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[107]); A_arbace_go_check_types_A_const_7 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[108]); A_arbace_go_check_types_A_const_8 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[109]); A_arbace_go_check_types_A_const_9 = A_arbace_go_check_types_A_const_pool.A[110]; A_arbace_go_check_types_A_const_10 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[111]); A_arbace_go_check_types_A_const_11 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[112]) }

func A_arbace_go_check_types_A_clinit_p1() { A_arbace_go_check_types_A_const_12 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[113]); A_arbace_go_check_types_A_const_13 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[114]); A_arbace_go_check_types_A_const_14 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[115]); A_arbace_go_check_types_A_const_15 = A_arbace_go_check_types_A_const_pool.A[116]; A_arbace_go_check_types_A_const_16 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[117]); A_arbace_go_check_types_A_const_17 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[118]); A_arbace_go_check_types_A_const_18 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[119]); A_arbace_go_check_types_A_const_19 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[120]); A_arbace_go_check_types_A_const_20 = A_arbace_go_check_types_A_const_pool.A[121]; A_arbace_go_check_types_A_const_21 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[122]); A_arbace_go_check_types_A_const_22 = A_arbace_go_check_types_A_const_pool.A[123]; A_arbace_go_check_types_A_const_23 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[124]); A_arbace_go_check_types_A_const_24 = A_arbace_go_check_types_A_const_pool.A[125] }

func A_arbace_go_check_types_A_clinit_p2() { A_arbace_go_check_types_A_const_25 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[126]); A_arbace_go_check_types_A_const_26 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[127]); A_arbace_go_check_types_A_const_27 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[128]); A_arbace_go_check_types_A_const_28 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[129]); A_arbace_go_check_types_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[130]); A_arbace_go_check_types_A_const_30 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[131]); A_arbace_go_check_types_A_const_31 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[132]); A_arbace_go_check_types_A_const_32 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[133]); A_arbace_go_check_types_A_const_33 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[134]); A_arbace_go_check_types_A_const_34 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[135]); A_arbace_go_check_types_A_const_35 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[136]); A_arbace_go_check_types_A_const_36 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[137]) }

func A_arbace_go_check_types_A_clinit_p3() { A_arbace_go_check_types_A_const_37 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[138]); A_arbace_go_check_types_A_const_38 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[139]); A_arbace_go_check_types_A_const_39 = A_arbace_go_check_types_A_const_pool.A[140]; A_arbace_go_check_types_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[141]); A_arbace_go_check_types_A_const_41 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[142]); A_arbace_go_check_types_A_const_42 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[143]); A_arbace_go_check_types_A_const_43 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[144]); A_arbace_go_check_types_A_const_44 = A_arbace_go_check_types_A_const_pool.A[145]; A_arbace_go_check_types_A_const_45 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[146]); A_arbace_go_check_types_A_const_46 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[147]); A_arbace_go_check_types_A_const_47 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[148]); A_arbace_go_check_types_A_const_48 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[149]) }

func A_arbace_go_check_types_A_clinit_p4() { A_arbace_go_check_types_A_const_49 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[150]); A_arbace_go_check_types_A_const_50 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[151]); A_arbace_go_check_types_A_const_51 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[152]); A_arbace_go_check_types_A_const_52 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[153]); A_arbace_go_check_types_A_const_53 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[154]); A_arbace_go_check_types_A_const_54 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[155]); A_arbace_go_check_types_A_const_55 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[156]); A_arbace_go_check_types_A_const_56 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[157]); A_arbace_go_check_types_A_const_57 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[158]); A_arbace_go_check_types_A_const_58 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[159]); A_arbace_go_check_types_A_const_59 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[160]); A_arbace_go_check_types_A_const_60 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[161]) }

func A_arbace_go_check_types_A_clinit_p5() { A_arbace_go_check_types_A_const_61 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[162]); A_arbace_go_check_types_A_const_62 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[163]); A_arbace_go_check_types_A_const_63 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[164]); A_arbace_go_check_types_A_const_64 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[165]); A_arbace_go_check_types_A_const_65 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[166]); A_arbace_go_check_types_A_const_66 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[167]); A_arbace_go_check_types_A_const_67 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[168]); A_arbace_go_check_types_A_const_68 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[169]); A_arbace_go_check_types_A_const_69 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[170]); A_arbace_go_check_types_A_const_70 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[171]); A_arbace_go_check_types_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[172]); A_arbace_go_check_types_A_const_72 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[173]) }

func A_arbace_go_check_types_A_clinit_p6() { A_arbace_go_check_types_A_const_73 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[174]); A_arbace_go_check_types_A_const_74 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[175]); A_arbace_go_check_types_A_const_75 = A_arbace_go_check_types_A_const_pool.A[176]; A_arbace_go_check_types_A_const_76 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[177]); A_arbace_go_check_types_A_const_77 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[178]); A_arbace_go_check_types_A_const_78 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[179]); A_arbace_go_check_types_A_const_79 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[180]); A_arbace_go_check_types_A_const_80 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[181]); A_arbace_go_check_types_A_const_81 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[182]); A_arbace_go_check_types_A_const_82 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[183]); A_arbace_go_check_types_A_const_83 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[184]); A_arbace_go_check_types_A_const_84 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[185]) }

func A_arbace_go_check_types_A_clinit_p7() { A_arbace_go_check_types_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[186]); A_arbace_go_check_types_A_const_86 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[187]); A_arbace_go_check_types_A_const_87 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[188]); A_arbace_go_check_types_A_const_88 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[189]); A_arbace_go_check_types_A_const_89 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[190]); A_arbace_go_check_types_A_const_90 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[191]); A_arbace_go_check_types_A_const_91 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[192]); A_arbace_go_check_types_A_const_92 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[193]); A_arbace_go_check_types_A_const_93 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[194]); A_arbace_go_check_types_A_const_94 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[195]); A_arbace_go_check_types_A_const_95 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[196]); A_arbace_go_check_types_A_const_96 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[197]) }

func A_arbace_go_check_types_A_clinit_p8() { A_arbace_go_check_types_A_const_97 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[198]); A_arbace_go_check_types_A_const_98 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[199]); A_arbace_go_check_types_A_const_99 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[200]); A_arbace_go_check_types_A_const_100 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[201]); A_arbace_go_check_types_A_const_101 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[202]); A_arbace_go_check_types_A_const_102 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[203]); A_arbace_go_check_types_A_const_103 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[204]); A_arbace_go_check_types_A_const_104 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[205]); A_arbace_go_check_types_A_const_105 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[206]); A_arbace_go_check_types_A_const_106 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[207]); A_arbace_go_check_types_A_const_107 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[208]); A_arbace_go_check_types_A_const_108 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[209]) }

func A_arbace_go_check_types_A_clinit_p9() { A_arbace_go_check_types_A_const_109 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[210]); A_arbace_go_check_types_A_const_110 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[211]); A_arbace_go_check_types_A_const_111 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[212]); A_arbace_go_check_types_A_const_112 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[213]); A_arbace_go_check_types_A_const_113 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[214]); A_arbace_go_check_types_A_const_114 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[215]); A_arbace_go_check_types_A_const_115 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[216]); A_arbace_go_check_types_A_const_116 = A_arbace_go_check_types_A_const_pool.A[217]; A_arbace_go_check_types_A_const_117 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[218]); A_arbace_go_check_types_A_const_118 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[219]); A_arbace_go_check_types_A_const_119 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[220]); A_arbace_go_check_types_A_const_120 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[221]) }

func A_arbace_go_check_types_A_clinit_p10() { A_arbace_go_check_types_A_const_121 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[222]); A_arbace_go_check_types_A_const_122 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[223]); A_arbace_go_check_types_A_const_123 = A_arbace_go_check_types_A_const_pool.A[224]; A_arbace_go_check_types_A_const_124 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[225]); A_arbace_go_check_types_A_const_125 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[226]); A_arbace_go_check_types_A_const_126 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[227]); A_arbace_go_check_types_A_const_127 = A_arbace_go_check_types_A_const_pool.A[228]; A_arbace_go_check_types_A_const_128 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[229]); A_arbace_go_check_types_A_const_129 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[230]); A_arbace_go_check_types_A_const_130 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[231]); A_arbace_go_check_types_A_const_131 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[232]); A_arbace_go_check_types_A_const_132 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[233]) }

func A_arbace_go_check_types_A_clinit_p11() { A_arbace_go_check_types_A_const_133 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[234]); A_arbace_go_check_types_A_const_134 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[235]); A_arbace_go_check_types_A_const_135 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[236]); A_arbace_go_check_types_A_const_136 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[237]); A_arbace_go_check_types_A_const_137 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[238]); A_arbace_go_check_types_A_const_138 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[239]); A_arbace_go_check_types_A_const_139 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[240]); A_arbace_go_check_types_A_const_140 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[241]); A_arbace_go_check_types_A_const_141 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[242]); A_arbace_go_check_types_A_const_142 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[243]); A_arbace_go_check_types_A_const_143 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[244]); A_arbace_go_check_types_A_const_144 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[245]) }

func A_arbace_go_check_types_A_clinit_p12() { A_arbace_go_check_types_A_const_145 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[246]); A_arbace_go_check_types_A_const_146 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[247]); A_arbace_go_check_types_A_const_147 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[248]); A_arbace_go_check_types_A_const_148 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[249]); A_arbace_go_check_types_A_const_149 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[250]); A_arbace_go_check_types_A_const_150 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[251]); A_arbace_go_check_types_A_const_151 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[252]); A_arbace_go_check_types_A_const_152 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[253]); A_arbace_go_check_types_A_const_153 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[254]); A_arbace_go_check_types_A_const_154 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[255]); A_arbace_go_check_types_A_const_155 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[256]); A_arbace_go_check_types_A_const_156 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[257]) }

func A_arbace_go_check_types_A_clinit_p13() { A_arbace_go_check_types_A_const_157 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[258]); A_arbace_go_check_types_A_const_158 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[259]); A_arbace_go_check_types_A_const_159 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[260]); A_arbace_go_check_types_A_const_160 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[261]); A_arbace_go_check_types_A_const_161 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[262]); A_arbace_go_check_types_A_const_162 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[263]); A_arbace_go_check_types_A_const_163 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[264]); A_arbace_go_check_types_A_const_164 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[265]); A_arbace_go_check_types_A_const_165 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[266]); A_arbace_go_check_types_A_const_166 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[267]); A_arbace_go_check_types_A_const_167 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[268]); A_arbace_go_check_types_A_const_168 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[269]) }

func A_arbace_go_check_types_A_clinit_p14() { A_arbace_go_check_types_A_const_169 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[270]); A_arbace_go_check_types_A_const_170 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[271]); A_arbace_go_check_types_A_const_171 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[272]); A_arbace_go_check_types_A_const_172 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[273]); A_arbace_go_check_types_A_const_173 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[274]); A_arbace_go_check_types_A_const_174 = A_arbace_go_check_types_A_const_pool.A[275]; A_arbace_go_check_types_A_const_175 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[276]); A_arbace_go_check_types_A_const_176 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[277]); A_arbace_go_check_types_A_const_177 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[278]); A_arbace_go_check_types_A_const_178 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[279]); A_arbace_go_check_types_A_const_179 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[280]); A_arbace_go_check_types_A_const_180 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[281]) }

func A_arbace_go_check_types_A_clinit_p15() { A_arbace_go_check_types_A_const_181 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[282]); A_arbace_go_check_types_A_const_182 = A_arbace_go_check_types_A_const_pool.A[283]; A_arbace_go_check_types_A_const_183 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[284]); A_arbace_go_check_types_A_const_184 = A_arbace_go_check_types_A_const_pool.A[285]; A_arbace_go_check_types_A_const_185 = A_arbace_go_check_types_A_const_pool.A[286]; A_arbace_go_check_types_A_const_186 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[287]); A_arbace_go_check_types_A_const_187 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[288]); A_arbace_go_check_types_A_const_188 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[289]); A_arbace_go_check_types_A_const_189 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[290]); A_arbace_go_check_types_A_const_190 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[291]); A_arbace_go_check_types_A_const_191 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[292]); A_arbace_go_check_types_A_const_192 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[293]) }

func A_arbace_go_check_types_A_clinit_p16() { A_arbace_go_check_types_A_const_193 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[294]); A_arbace_go_check_types_A_const_194 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[295]); A_arbace_go_check_types_A_const_195 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[296]); A_arbace_go_check_types_A_const_196 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[297]); A_arbace_go_check_types_A_const_197 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[298]); A_arbace_go_check_types_A_const_198 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[299]); A_arbace_go_check_types_A_const_199 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[300]); A_arbace_go_check_types_A_const_200 = A_arbace_go_check_types_A_const_pool.A[301]; A_arbace_go_check_types_A_const_201 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[302]); A_arbace_go_check_types_A_const_202 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[303]); A_arbace_go_check_types_A_const_203 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[304]); A_arbace_go_check_types_A_const_204 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[305]) }

func A_arbace_go_check_types_A_clinit_p17() { A_arbace_go_check_types_A_const_205 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[306]); A_arbace_go_check_types_A_const_206 = A_arbace_go_check_types_A_const_pool.A[307]; A_arbace_go_check_types_A_const_207 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[308]); A_arbace_go_check_types_A_const_208 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[309]); A_arbace_go_check_types_A_const_209 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[310]); A_arbace_go_check_types_A_const_210 = A_arbace_go_check_types_A_const_pool.A[311]; A_arbace_go_check_types_A_const_211 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[312]); A_arbace_go_check_types_A_const_212 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[313]); A_arbace_go_check_types_A_const_213 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[314]); A_arbace_go_check_types_A_const_214 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[315]); A_arbace_go_check_types_A_const_215 = A_arbace_go_check_types_A_const_pool.A[316]; A_arbace_go_check_types_A_const_216 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[317]) }

func A_arbace_go_check_types_A_clinit_p18() { A_arbace_go_check_types_A_const_217 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[318]); A_arbace_go_check_types_A_const_218 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[319]); A_arbace_go_check_types_A_const_219 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[320]); A_arbace_go_check_types_A_const_220 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[321]); A_arbace_go_check_types_A_const_221 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[322]); A_arbace_go_check_types_A_const_222 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[323]); A_arbace_go_check_types_A_const_223 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[324]); A_arbace_go_check_types_A_const_224 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[325]); A_arbace_go_check_types_A_const_225 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[326]); A_arbace_go_check_types_A_const_226 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[327]); A_arbace_go_check_types_A_const_227 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[328]); A_arbace_go_check_types_A_const_228 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[329]) }

func A_arbace_go_check_types_A_clinit_p19() { A_arbace_go_check_types_A_const_229 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[330]); A_arbace_go_check_types_A_const_230 = A_arbace_go_check_types_A_const_pool.A[331]; A_arbace_go_check_types_A_const_231 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[332]); A_arbace_go_check_types_A_const_232 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[333]); A_arbace_go_check_types_A_const_233 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[334]); A_arbace_go_check_types_A_const_234 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[335]); A_arbace_go_check_types_A_const_235 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[336]); A_arbace_go_check_types_A_const_236 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[337]); A_arbace_go_check_types_A_const_237 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[338]); A_arbace_go_check_types_A_const_238 = A_arbace_go_check_types_A_const_pool.A[339]; A_arbace_go_check_types_A_const_239 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[340]); A_arbace_go_check_types_A_const_240 = A_arbace_go_check_types_A_const_pool.A[341] }

func A_arbace_go_check_types_A_clinit_p20() { A_arbace_go_check_types_A_const_241 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[342]); A_arbace_go_check_types_A_const_242 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[343]); A_arbace_go_check_types_A_const_243 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[344]); A_arbace_go_check_types_A_const_244 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[345]); A_arbace_go_check_types_A_const_245 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[346]); A_arbace_go_check_types_A_const_246 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[347]); A_arbace_go_check_types_A_const_247 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[348]); A_arbace_go_check_types_A_const_248 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[349]); A_arbace_go_check_types_A_const_249 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[350]); A_arbace_go_check_types_A_const_250 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[351]); A_arbace_go_check_types_A_const_251 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[352]); A_arbace_go_check_types_A_const_252 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[353]) }

func A_arbace_go_check_types_A_clinit_p21() { A_arbace_go_check_types_A_const_253 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[354]); A_arbace_go_check_types_A_const_254 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[355]); A_arbace_go_check_types_A_const_255 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[356]); A_arbace_go_check_types_A_const_256 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[357]); A_arbace_go_check_types_A_const_257 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[358]); A_arbace_go_check_types_A_const_258 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[359]); A_arbace_go_check_types_A_const_259 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[360]); A_arbace_go_check_types_A_const_260 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[361]); A_arbace_go_check_types_A_const_261 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[362]); A_arbace_go_check_types_A_const_262 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[363]); A_arbace_go_check_types_A_const_263 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[364]); A_arbace_go_check_types_A_const_264 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[365]) }

func A_arbace_go_check_types_A_clinit_p22() { A_arbace_go_check_types_A_const_265 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[366]); A_arbace_go_check_types_A_const_266 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[367]) }

func A_arbace_go_check_types_A_New() *A_arbace_go_check_types_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_A) Ctor() {}

func (t *A_arbace_go_check_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_A_class }

func (t *A_arbace_go_check_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_A); return ok }

func A_arbace_go_check_types_A_Cast(x any) *A_arbace_go_check_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_A_class)) }; return v }



type A_arbace_go_check_types_alias_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alias_of_A_fn_class *jrt.Class



type A_arbace_go_check_types_alias_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alias_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_align_up_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_align_up_A_fn_class *jrt.Class



type A_arbace_go_check_types_alignof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alignof_A_fn_class *jrt.Class



type A_arbace_go_check_types_alignof_fn__219000253_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alignof_fn__219000253_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_basic_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_basic_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_basic_fn__219000185_A struct{ j2g_header uint64; F_pred any }

var A_arbace_go_check_types_all_basic_fn__219000185_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_boolean_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_boolean_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_complex_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_complex_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_float_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_float_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_integer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_integer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_or_string_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_or_string_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000198_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_ordered_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_ordered_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_string_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_string_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_unsigned_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_unsigned_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_basic_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_basic_A_fn_class *jrt.Class



type A_arbace_go_check_types_boolean_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_boolean_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_bound_iface_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_bound_iface_A_fn_class *jrt.Class



type A_arbace_go_check_types_canon_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_canon_A_fn_class *jrt.Class



type A_arbace_go_check_types_canon_kw_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_canon_kw_A_fn_class *jrt.Class



type A_arbace_go_check_types_canon_member_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_canon_member_A_fn_class *jrt.Class



type A_arbace_go_check_types_canon_vec_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_canon_vec_A_fn_class *jrt.Class



type A_arbace_go_check_types_canon_vec_re__219000024_A struct{ j2g_header uint64; F_t any }

var A_arbace_go_check_types_canon_vec_re__219000024_A_fn_class *jrt.Class



type A_arbace_go_check_types_common_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_common_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_comparable_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A struct{ j2g_header uint64; F_seen, F_dynamic any }

var A_arbace_go_check_types_comparable_type_QMARK__fn__219000086_A_fn_class *jrt.Class



type A_arbace_go_check_types_complex_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_complex_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_consolidate_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_consolidate_A_fn_class *jrt.Class



type A_arbace_go_check_types_const_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_const_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_core_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_core_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_default_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_default_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_deref_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_deref_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_empty_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_empty_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_eval219000004_A struct{ jrt.Object }

func A_arbace_go_check_types_eval219000004_A_New() *A_arbace_go_check_types_eval219000004_A { t := &A_arbace_go_check_types_eval219000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_eval219000004_A) Ctor() {}

func (t *A_arbace_go_check_types_eval219000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_eval219000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_eval219000004_A_class }

func (t *A_arbace_go_check_types_eval219000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_eval219000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_eval219000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_eval219000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_eval219000004_A); return ok }

func A_arbace_go_check_types_eval219000004_A_Cast(x any) *A_arbace_go_check_types_eval219000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_eval219000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_eval219000004_A_class)) }; return v }



type A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_fn_class *jrt.Class



type A_arbace_go_check_types_eval219000008_A struct{ jrt.Object }

func A_arbace_go_check_types_eval219000008_A_New() *A_arbace_go_check_types_eval219000008_A { t := &A_arbace_go_check_types_eval219000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_eval219000008_A) Ctor() {}

func (t *A_arbace_go_check_types_eval219000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_eval219000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_eval219000008_A_class }

func (t *A_arbace_go_check_types_eval219000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_eval219000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_eval219000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_eval219000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_eval219000008_A); return ok }

func A_arbace_go_check_types_eval219000008_A_Cast(x any) *A_arbace_go_check_types_eval219000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_eval219000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_eval219000008_A_class)) }; return v }



type A_arbace_go_check_types_eval219000008_fn__219000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_eval219000008_fn__219000009_A_fn_class *jrt.Class



type A_arbace_go_check_types_exported_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_exported_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_field_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_field_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_flag_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_flag_A_fn_class *jrt.Class



type A_arbace_go_check_types_float_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_float_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_m__219000013_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class *jrt.Class



type A_arbace_go_check_types_has_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_name_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_has_nil_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_nil_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_nil_QMARK__fn__219000065_A_fn_class *jrt.Class



type A_arbace_go_check_types_has_terms_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_terms_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_identical_ignore_tags_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_identical_ignore_tags_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_iface_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_iface_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_iface_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_iface_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_ignore_tags_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ignore_tags_A_fn_class *jrt.Class



type A_arbace_go_check_types_ignore_tags_fn__219000073_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ignore_tags_fn__219000073_A_fn_class *jrt.Class



type A_arbace_go_check_types_incomparable_cause_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_incomparable_cause_A_fn_class *jrt.Class



type A_arbace_go_check_types_incomparable_cause_cause__219000090_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_incomparable_cause_cause__219000090_A_fn_class *jrt.Class



type A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A struct{ j2g_header uint64; F_cause, F_seen any }

var A_arbace_go_check_types_incomparable_cause_cause__219000090_fn__219000092_A_fn_class *jrt.Class



type A_arbace_go_check_types_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_info_A_fn_class *jrt.Class



type A_arbace_go_check_types_integer_or_float_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_integer_or_float_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_integer_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_integer_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_kind_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_kind_of_A_fn_class *jrt.Class



type A_arbace_go_check_types_kw_alias_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_kw_alias_A_fn_class *jrt.Class



type A_arbace_go_check_types_kw_alias_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_kw_alias_info_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_lookup_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_impl_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_lookup_impl_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_impl_fn__219000276_A struct{ j2g_header uint64; F_pkg, F_name any }

var A_arbace_go_check_types_lookup_impl_fn__219000276_A_fn_class *jrt.Class



type A_arbace_go_check_types_make_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_make_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_map_same_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_map_same_A_fn_class *jrt.Class



type A_arbace_go_check_types_method_data_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_method_data_A_fn_class *jrt.Class



type A_arbace_go_check_types_method_set_iface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_method_set_iface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_methods_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_methods_of_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_missing_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_fn__219000290_A struct{ j2g_header uint64; F_static, F_V, F_same_QMARK_, F_vu any }

var A_arbace_go_check_types_missing_method_fn__219000290_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A struct{ j2g_header uint64; F_m, F_V any }

var A_arbace_go_check_types_missing_method_fn__219000290_fn__219000291_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_named_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_new_named_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_new_named_A_fn_class *jrt.Class



type A_arbace_go_check_types_new_tparam_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_new_tparam_A_fn_class *jrt.Class



type A_arbace_go_check_types_next_id_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_next_id_A_fn_class *jrt.Class



type A_arbace_go_check_types_numeric_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_offsetsof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_offsetsof_A_fn_class *jrt.Class



type A_arbace_go_check_types_ordered_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ordered_A_fn_class *jrt.Class



type A_arbace_go_check_types_ordered_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ordered_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_params_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_params_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_params_str_fn__219000225_A struct{ j2g_header uint64; F_ps, F_variadic any }

var A_arbace_go_check_types_params_str_fn__219000225_A_fn_class *jrt.Class



type A_arbace_go_check_types_pointer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_pointer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_same_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_same_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_same_id_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_same_id_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_satisfies_cause_A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_comparability__219000295_A struct{ j2g_header uint64; F_Tts, F_V any }

var A_arbace_go_check_types_satisfies_cause_comparability__219000295_A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_satisfies_cause_comparability__219000295_fn__219000297_A_fn_class *jrt.Class



type A_arbace_go_check_types_sig_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sig_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_sizeof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sizeof_A_fn_class *jrt.Class



type A_arbace_go_check_types_sort_methods_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sort_methods_A_fn_class *jrt.Class



type A_arbace_go_check_types_sort_methods_fn__219000286_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sort_methods_fn__219000286_A_fn_class *jrt.Class



type A_arbace_go_check_types_strictly_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_string_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_string_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_sync_atomic_align64_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_disjoint_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_includes_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_includes_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_intersect_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_intersect_A_fn_class *jrt.Class



type A_arbace_go_check_types_term_subset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_subset_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_union_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_union_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_includes_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_includes_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A struct{ j2g_header uint64; F_t any }

var A_arbace_go_check_types_terms_includes_QMARK__fn__219000138_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_intersect_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A struct{ j2g_header uint64; F_y any }

var A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A struct{ j2g_header uint64; F_iter__219000120, F_s__219000121, F_y any }

var A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A struct{ j2g_header uint64; F_a any }

var A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A struct{ j2g_header uint64; F_iter__219000122, F_s__219000123, F_a any }

var A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A struct{ j2g_header uint64; F_b__219000125 any; F_size__1927001038__auto__ int32; F_a, F_c__1927001037__auto__ any }

var A_arbace_go_check_types_terms_intersect_iter__219000120__219000126_fn__219000127_iter__219000122__219000128_fn__219000129_fn__219000130_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_norm_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_norm_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_norm_fn__219000115_A struct{ j2g_header uint64; F_i int64; F_n int32; F_used, F_ts any }

var A_arbace_go_check_types_terms_norm_fn__219000115_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000208__219000212_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_str_iter__219000208__219000212_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A struct{ j2g_header uint64; F_iter__219000208, F_s__219000209 any }

var A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A struct{ j2g_header uint64; F_b__219000211 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_terms_str_iter__219000208__219000212_fn__219000213_fn__219000214_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_subset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_subset_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A struct{ j2g_header uint64; F_yl any }

var A_arbace_go_check_types_terms_subset_QMARK__fn__219000146_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_superset_of_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_superset_of_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A struct{ j2g_header uint64; F_y any }

var A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000142_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_union_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_union_A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_iface_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_iface_A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A struct{ j2g_header uint64; F_seen any }

var A_arbace_go_check_types_tset_comparable_QMARK__fn__219000078_A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_empty_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tset_empty_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_type_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000239__219000243_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_type_str_iter__219000239__219000243_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A struct{ j2g_header uint64; F_s__219000240, F_iter__219000239 any }

var A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A struct{ j2g_header uint64; F_b__219000242 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_type_str_iter__219000239__219000243_fn__219000244_fn__219000245_A_fn_class *jrt.Class



type A_arbace_go_check_types_typed_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typed_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_all_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_all_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_all_fn__219000175_A struct{ j2g_header uint64; F_f any }

var A_arbace_go_check_types_typeset_all_fn__219000175_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_pairs_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A struct{ j2g_header uint64; F_iter__219000157, F_s__219000158 any }

var A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A struct{ j2g_header uint64; F_b__219000160 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_typeset_pairs_iter__219000157__219000161_fn__219000162_fn__219000163_A_fn_class *jrt.Class



type A_arbace_go_check_types_uintptr_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_uintptr_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_unalias_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_unalias_A_fn_class *jrt.Class



type A_arbace_go_check_types_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_under_is_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_under_is_A_fn_class *jrt.Class



type A_arbace_go_check_types_under_is_fn__219000181_A struct{ j2g_header uint64; F_f any }

var A_arbace_go_check_types_under_is_fn__219000181_A_fn_class *jrt.Class



type A_arbace_go_check_types_union_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_union_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_unsafe_pointer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_unsafe_pointer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_unsigned_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_unsigned_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_untyped_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_untyped_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_update_info_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_update_info_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_types_valid_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_valid_QMARK__A_fn_class *jrt.Class
