//line aot_arbace_go_check_types.ae:1
package aot_arbace_go_check_types

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_const"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_New() *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_types_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_types_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_go_check_types_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_1, A_arbace_go_check_types_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_types_eval219000008_fn__219000009_A_New() *A_arbace_go_check_types_eval219000008_fn__219000009_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_eval219000008_fn__219000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_types_eval219000008_fn__219000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_types_eval219000008_fn__219000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_go_check_types_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_types_A_const_8.GetRawRoot__O(), A_arbace_go_check_types_A_const_9) }






















func A_arbace_go_check_types_fn__219000012_A_New() *A_arbace_go_check_types_fn__219000012_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_A) Invoke_O__O(self any) any { var m__1 any; var tmp1 any = A_arbace_go_check_types_fn__219000012_m__219000013_A_New(); var tmp2 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, true); A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class = fncls__31d; tmp2 = fncls__31d } else { tmp2 = fncls__31 }; m__1 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp1, tmp2, nil, 2); var root_32 any =
										A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_36 any = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_14, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_16), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_17, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_19, A_arbace_go_check_types_A_const_20, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_21, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_23, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_25, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_26, A_arbace_go_check_types_A_const_15, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_28, A_arbace_go_check_types_A_const_20, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_29, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_30, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_31, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_32, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_27), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_33, A_arbace_go_check_types_A_const_22, A_arbace_go_check_types_A_const_34), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_35, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_34), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_36, A_arbace_go_check_types_A_const_24, A_arbace_go_check_types_A_const_37), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_38, A_arbace_go_check_types_A_const_39, A_arbace_go_check_types_A_const_37), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_40, A_arbace_go_check_types_A_const_39, A_arbace_go_check_types_A_const_41), lang.IFn_Cast(m__1).Invoke_O_O__O(A_arbace_go_check_types_A_const_42, A_arbace_go_check_types_A_const_24), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_43, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_16, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_46, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_47, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_18, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_48, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_34, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_49, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_37, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O_O__O(A_arbace_go_check_types_A_const_50, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_41, A_arbace_go_check_types_A_const_45), lang.IFn_Cast(m__1).Invoke_O_O_O__O(A_arbace_go_check_types_A_const_51, A_arbace_go_check_types_A_const_44, A_arbace_go_check_types_A_const_45))); if linked_33 == nil { return ifn_34.Invoke_O_O__O(arg_35, arg_36) } else { return linked_33.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_32, arg_35, arg_36) } }
//line :24:1
func A_arbace_go_check_types_fn__219000012_m__219000013_A_New() *A_arbace_go_check_types_fn__219000012_m__219000013_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_m__219000013_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_A) DoInvoke_O_O_O_O__O(self, n__1, size__2, flags__3 any) any { var tmp1 any; var root_20 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_11, size__2, A_arbace_go_check_types_A_const_12, n__1)); var arg_24 any; var root_25 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any; var tmp2 any = A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; arg_28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_29 any = flags__3; if linked_26 == nil { arg_24 = ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { arg_24 = linked_26.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) }; if linked_21 == nil { tmp1 = ifn_22.Invoke_O_O__O(arg_23, arg_24) } else { tmp1 = linked_21.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_20, arg_23, arg_24) }; return lang.Tuple_Create_O_O__IPersistentVector(n__1, tmp1) }
//line :24:1
func A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_New() *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A) Invoke_O_O__O(self, f__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(f__1, jrt.Boolean_TRUE.Ref()) }


























func A_arbace_go_check_types_next_id_A_New() *A_arbace_go_check_types_next_id_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_next_id_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_go_check_types_next_id_A) Ctor() {}
//line :51:1
func (t *A_arbace_go_check_types_next_id_A) InvokePrim_O__J(self any) int64 { return jrt.Number_Cast(lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(A_arbace_go_check_types_A_const_52.GetRawRoot__O(), Lit_24, false)).LongValue__J() }
//line :51:1
func (t *A_arbace_go_check_types_next_id_A) Invoke_O__O(self any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O__J(self)).Ref() }

func A_arbace_go_check_types_named_QMARK__A_New() *A_arbace_go_check_types_named_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_QMARK__A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_go_check_types_named_QMARK__A) Ctor() {}
//line :53:1
func (t *A_arbace_go_check_types_named_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_37 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = t__0; if linked_38 == nil { and__1927000168__auto____2 = ifn_39.Invoke_O__O(arg_40) } else { and__1927000168__auto____2 = linked_38.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_37, arg_40) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_54; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_tparam_QMARK__A_New() *A_arbace_go_check_types_tparam_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_QMARK__A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_go_check_types_tparam_QMARK__A) Ctor() {}
//line :54:1
func (t *A_arbace_go_check_types_tparam_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_41 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = t__0; if linked_42 == nil { and__1927000168__auto____2 = ifn_43.Invoke_O__O(arg_44) } else { and__1927000168__auto____2 = linked_42.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_41, arg_44) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_55; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_info_A_New() *A_arbace_go_check_types_info_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_info_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_go_check_types_info_A) Ctor() {}
//line :55:1
func (t *A_arbace_go_check_types_info_A) Invoke_O_O__O(self, t__0 any) any { var root_45 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_46 == nil { return ifn_47.Invoke_O__O(arg_48) } else { return linked_46.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_45, arg_48) } }
func A_arbace_go_check_types_update_info_BANG__A_New() *A_arbace_go_check_types_update_info_BANG__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_update_info_BANG__A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_go_check_types_update_info_BANG__A) Ctor() {}
//line :56:1
func (t *A_arbace_go_check_types_update_info_BANG__A) DoInvoke_O_O_O_O__O(self, t__0, f__1, args__2 any) any { var root_49 any = A_arbace_go_check_types_A_const_56.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var arg_53 any; var root_54 any = A_arbace_go_check_types_A_const_57.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = f__1; var arg_58 any; var root_60 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_61 == nil { arg_58 = ifn_62.Invoke_O__O(arg_63) } else { arg_58 = linked_61.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_60, arg_63) }; var arg_59 any = args__2; if linked_55 == nil { arg_53 = ifn_56.Invoke_O_O_O__O(arg_57, arg_58, arg_59) } else { arg_53 = linked_55.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_54, arg_57, arg_58, arg_59) }; if linked_50 == nil { ifn_51.Invoke_O_O__O(arg_52, arg_53) } else { linked_50.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_49, arg_52, arg_53) }; return t__0 }

func A_arbace_go_check_types_new_named_A_New() *A_arbace_go_check_types_new_named_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_new_named_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_go_check_types_new_named_A) Ctor() {}
//line :58:1
func (t *A_arbace_go_check_types_new_named_A) Invoke_O_O__O(self, data__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_54; var tmp2 any; var root_64 any = A_arbace_go_check_types_A_const_58.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_66 lang.IFn; if


	linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_59.GetRawRoot__O()); var tmp4 any = A_arbace_go_check_types_A_const_60; var tmp5 any; var root_76 any = A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_76, A_arbace_go_check_types_next_id_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; if linked_77 == nil { tmp5 = ifn_78.Invoke__O() } else { tmp5 = jrt.Long_ValueOf_J__Long_NoInit(linked_77.(*A_arbace_go_check_types_next_id_A).InvokePrim_O__J(root_76)).Ref() }; arg_67 = tmp3.Invoke_O_O_O_O_O__O(data__0, tmp4, tmp5, A_arbace_go_check_types_A_const_62, lang.PersistentVector_EMPTY.Ref()); if linked_65 == nil { tmp2 = ifn_66.Invoke_O__O(arg_67) } else { tmp2 = linked_65.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_64, arg_67) }; return /*line :58:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }




func A_arbace_go_check_types_new_tparam_A_New() *A_arbace_go_check_types_new_tparam_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_new_tparam_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_go_check_types_new_tparam_A) Ctor() {}
//line :63:1
func (t *A_arbace_go_check_types_new_tparam_A) Invoke_O_O__O(self, data__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_55; var tmp2 any; var root_79 any = A_arbace_go_check_types_A_const_58.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_81 lang.IFn; if


	linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any; var root_83 any = A_arbace_go_check_types_A_const_59.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = data__0; var arg_87 any = A_arbace_go_check_types_A_const_60; var arg_88 any; var root_89 any = A_arbace_go_check_types_A_const_61.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_89, A_arbace_go_check_types_next_id_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; if linked_90 == nil { arg_88 = ifn_91.Invoke__O() } else { arg_88 = jrt.Long_ValueOf_J__Long_NoInit(linked_90.(*A_arbace_go_check_types_next_id_A).InvokePrim_O__J(root_89)).Ref() }; if linked_84 == nil { arg_82 = ifn_85.Invoke_O_O_O__O(arg_86, arg_87, arg_88) } else { arg_82 = linked_84.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_83, arg_86, arg_87, arg_88) }; if linked_80 == nil { tmp2 = ifn_81.Invoke_O__O(arg_82) } else { tmp2 = linked_80.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_79, arg_82) }; return /*line :63:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }











func A_arbace_go_check_types_named_under_A_New() *A_arbace_go_check_types_named_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_under_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_go_check_types_named_under_A) Ctor() {}
//line :75:1
func (t *A_arbace_go_check_types_named_under_A) Invoke_O_O__O(self, t__0 any) any { { var t__2 any = t__0; var seen__3 any = lang.PersistentHashSet_EMPTY.Ref(); L1: for { var i__4 any; var root_92 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, A_arbace_go_check_types_info_A_fn_class); var ifn_94 lang.IFn

	if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = t__2; if linked_93 == nil { i__4 = ifn_94.Invoke_O__O(arg_95) } else { i__4 = linked_93.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_92, arg_95) }
//line :75:1
	var temp__1927000408__auto____5 any = A_arbace_go_check_types_A_const_64.Invoke_O__O(i__4)


	if jrt.J2g_Truth(temp__1927000408__auto____5) { var u__6 any = temp__1927000408__auto____5; var tmp1 any; var root_96 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_98 lang.IFn
		if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = u__6; if linked_97 == nil { tmp1 = ifn_98.Invoke_O__O(arg_99) } else { tmp1 = linked_97.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_96, arg_99) }; if jrt.J2g_Truth(tmp1) {

			var tmp2 any; var root_100 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = seen__3; var arg_104 any = u__6; if linked_101 == nil { tmp2 = ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { tmp2 = linked_101.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_100, arg_103, arg_104) }; if jrt.J2g_Truth(tmp2) { return A_arbace_go_check_types_A_const_67 } else {

				var tmp3 any; var root_113 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = seen__3; var arg_117 any = t__2; if linked_114 == nil { tmp3 = ifn_115.Invoke_O_O__O(arg_116, arg_117) } else { tmp3 = linked_114.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_113, arg_116, arg_117) }; t__2, seen__3 = u__6, tmp3; continue L1 } } else {
//line :79:1
					return u__6 } } else {





						var tmp4 any; var and__1927000168__auto____6 any = A_arbace_go_check_types_A_const_68.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_105 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = A_arbace_go_check_types_A_const_70.Invoke_O__O(i__4); if linked_106 == nil { and__1927000168__auto____7 = ifn_107.Invoke_O__O(arg_108) } else { and__1927000168__auto____7 = linked_106.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_105, arg_108) }; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp4 = A_arbace_go_check_types_A_const_71.Invoke_O__O(i__4) } else { tmp4 = and__1927000168__auto____7 } } else { tmp4 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp4) {
							lang.IFn_Cast(A_arbace_go_check_types_A_const_68.Get__O()).Invoke_O__O(t__2)
							var tmp5 *lang.Keyword = A_arbace_go_check_types_A_const_64; var tmp6 any; var root_109 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, A_arbace_go_check_types_info_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = t__2; if linked_110 == nil { tmp6 = ifn_111.Invoke_O__O(arg_112) } else { tmp6 = linked_110.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_109, arg_112) }; if jrt.J2g_Truth(tmp5.Invoke_O__O(tmp6)) { t__2, seen__3 = t__2, seen__3; continue L1 } else { return A_arbace_go_check_types_A_const_67 } } else {
//line :85:1
								return A_arbace_go_check_types_A_const_67 } } } }; /*line :75:1*/panic("j2g: unreachable") }














func A_arbace_go_check_types_under_A_New() *A_arbace_go_check_types_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_go_check_types_under_A) Ctor() {}
//line :90:1
func (t *A_arbace_go_check_types_under_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_118 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_120 lang.IFn
	if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = t__0; if linked_119 == nil { tmp1 = ifn_120.Invoke_O__O(arg_121) } else { tmp1 = linked_119.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_118, arg_121) }
//line :93:1
	if jrt.J2g_Truth(tmp1) { return t__0 } else { var tmp2 any = A_arbace_go_check_types_A_const_54; if lang.Util_Identical_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))) {

		var root_122 any = A_arbace_go_check_types_A_const_73.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, A_arbace_go_check_types_named_under_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = t__0; if linked_123 == nil { return ifn_124.Invoke_O__O(arg_125) } else { return linked_123.(*A_arbace_go_check_types_named_under_A).Invoke_O_O__O(root_122, arg_125) } } else {
//line :93:1
			var tmp3 any = A_arbace_go_check_types_A_const_55; if lang.Util_Identical_O_O__Z_NoInit(tmp3, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))) {


				var root_126 any = A_arbace_go_check_types_A_const_74.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, A_arbace_go_check_types_tparam_iface_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = t__0; if linked_127 == nil { return ifn_128.Invoke_O__O(arg_129) } else { return linked_127.(*A_arbace_go_check_types_tparam_iface_A).Invoke_O_O__O(root_126, arg_129) } } else {
//line :93:1
					if A_arbace_go_check_types_A_const_75 != nil { return t__0 } else { return nil
					}
				}
		}
	}
}


func A_arbace_go_check_types_basic_A_New() *A_arbace_go_check_types_basic_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_basic_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_check_types_basic_A) Ctor() {}
//line :101:1
func (t *A_arbace_go_check_types_basic_A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_130 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_go_check_types_under_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = t__0; if linked_131 == nil { u__2 = ifn_132.Invoke_O__O(arg_133) } else { u__2 = linked_131.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_130, arg_133) }; var tmp1 any; var root_134 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = u__2; if linked_135 == nil { tmp1 = ifn_136.Invoke_O__O(arg_137) } else { tmp1 = linked_135.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_134, arg_137) }; if jrt.J2g_Truth(tmp1) { return u__2 } else { return nil } }
func A_arbace_go_check_types_flag_A_New() *A_arbace_go_check_types_flag_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_flag_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_go_check_types_flag_A) Ctor() {}
//line :102:1
func (t *A_arbace_go_check_types_flag_A) Invoke_O_O_O__O(self, t__0, f__1 any) any { var b__3 any; var root_138 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, A_arbace_go_check_types_basic_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = t__0; if linked_139 == nil { b__3 = ifn_140.Invoke_O__O(arg_141) } else { b__3 = linked_139.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_138, arg_141) }; var tmp1 any; var and__1927000168__auto____4 any = b__3; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_go_check_types_A_const_78.GetRawRoot__O()).Invoke_O__O(b__3), f__1) } else { tmp1 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }
func A_arbace_go_check_types_integer_type_QMARK__A_New() *A_arbace_go_check_types_integer_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_integer_type_QMARK__A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_go_check_types_integer_type_QMARK__A) Ctor() {}
//line :103:1
func (t *A_arbace_go_check_types_integer_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_142 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, A_arbace_go_check_types_flag_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = t__0; var arg_146 any = A_arbace_go_check_types_A_const_18; if linked_143 == nil { return ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { return linked_143.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_142, arg_145, arg_146) } }
func A_arbace_go_check_types_unsigned_QMARK__A_New() *A_arbace_go_check_types_unsigned_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_unsigned_QMARK__A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_go_check_types_unsigned_QMARK__A) Ctor() {}
//line :104:1
func (t *A_arbace_go_check_types_unsigned_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_147 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, A_arbace_go_check_types_flag_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = t__0; var arg_151 any = A_arbace_go_check_types_A_const_27; if linked_148 == nil { return ifn_149.Invoke_O_O__O(arg_150, arg_151) } else { return linked_148.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_147, arg_150, arg_151) } }
func A_arbace_go_check_types_float_type_QMARK__A_New() *A_arbace_go_check_types_float_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_float_type_QMARK__A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_go_check_types_float_type_QMARK__A) Ctor() {}
//line :105:1
func (t *A_arbace_go_check_types_float_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_152 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, A_arbace_go_check_types_flag_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = t__0; var arg_156 any = A_arbace_go_check_types_A_const_34; if linked_153 == nil { return ifn_154.Invoke_O_O__O(arg_155, arg_156) } else { return linked_153.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_152, arg_155, arg_156) } }
func A_arbace_go_check_types_complex_type_QMARK__A_New() *A_arbace_go_check_types_complex_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_complex_type_QMARK__A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_go_check_types_complex_type_QMARK__A) Ctor() {}
//line :106:1
func (t *A_arbace_go_check_types_complex_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_157 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, A_arbace_go_check_types_flag_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = t__0; var arg_161 any = A_arbace_go_check_types_A_const_37; if linked_158 == nil { return ifn_159.Invoke_O_O__O(arg_160, arg_161) } else { return linked_158.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_157, arg_160, arg_161) } }
func A_arbace_go_check_types_numeric_QMARK__A_New() *A_arbace_go_check_types_numeric_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_numeric_QMARK__A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_go_check_types_numeric_QMARK__A) Ctor() {}
//line :107:1
func (t *A_arbace_go_check_types_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_162 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = t__0; if linked_163 == nil { or__1927000174__auto____2 = ifn_164.Invoke_O__O(arg_165) } else { or__1927000174__auto____2 = linked_163.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_162, arg_165) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_166 any = A_arbace_go_check_types_A_const_81.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = t__0; if linked_167 == nil { or__1927000174__auto____3 = ifn_168.Invoke_O__O(arg_169) } else { or__1927000174__auto____3 = linked_167.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_166, arg_169) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_170 any = A_arbace_go_check_types_A_const_82.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, A_arbace_go_check_types_complex_type_QMARK__A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = t__0; if linked_171 == nil { return ifn_172.Invoke_O__O(arg_173) } else { return linked_171.(*A_arbace_go_check_types_complex_type_QMARK__A).Invoke_O_O__O(root_170, arg_173) } } } }
func A_arbace_go_check_types_string_type_QMARK__A_New() *A_arbace_go_check_types_string_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_string_type_QMARK__A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_go_check_types_string_type_QMARK__A) Ctor() {}
//line :108:1
func (t *A_arbace_go_check_types_string_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_174 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, A_arbace_go_check_types_flag_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = t__0; var arg_178 any = A_arbace_go_check_types_A_const_41; if linked_175 == nil { return ifn_176.Invoke_O_O__O(arg_177, arg_178) } else { return linked_175.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_174, arg_177, arg_178) } }
func A_arbace_go_check_types_boolean_type_QMARK__A_New() *A_arbace_go_check_types_boolean_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_boolean_type_QMARK__A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_go_check_types_boolean_type_QMARK__A) Ctor() {}
//line :109:1
func (t *A_arbace_go_check_types_boolean_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_179 any = A_arbace_go_check_types_A_const_79.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, A_arbace_go_check_types_flag_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = t__0; var arg_183 any = A_arbace_go_check_types_A_const_16; if linked_180 == nil { return ifn_181.Invoke_O_O__O(arg_182, arg_183) } else { return linked_180.(*A_arbace_go_check_types_flag_A).Invoke_O_O_O__O(root_179, arg_182, arg_183) } }
func A_arbace_go_check_types_untyped_QMARK__A_New() *A_arbace_go_check_types_untyped_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_untyped_QMARK__A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_go_check_types_untyped_QMARK__A) Ctor() {}
//line :110:1
func (t *A_arbace_go_check_types_untyped_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_184 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = t__0; if linked_185 == nil { and__1927000168__auto____2 = ifn_186.Invoke_O__O(arg_187) } else { and__1927000168__auto____2 = linked_185.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_184, arg_187) }; if jrt.J2g_Truth(and__1927000168__auto____2) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_go_check_types_A_const_78.GetRawRoot__O()).Invoke_O__O(t__0), A_arbace_go_check_types_A_const_45))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_types_typed_QMARK__A_New() *A_arbace_go_check_types_typed_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typed_QMARK__A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_go_check_types_typed_QMARK__A) Ctor() {}
//line :111:1
func (t *A_arbace_go_check_types_typed_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_188 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any; var root_192 any = A_arbace_go_check_types_A_const_83.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, A_arbace_go_check_types_untyped_QMARK__A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = t__0; if linked_193 == nil { arg_191 = ifn_194.Invoke_O__O(arg_195) } else { arg_191 = linked_193.(*A_arbace_go_check_types_untyped_QMARK__A).Invoke_O_O__O(root_192, arg_195) }; if linked_189 == nil { return ifn_190.Invoke_O__O(arg_191) } else { return linked_189.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_188, arg_191) } }
func A_arbace_go_check_types_const_type_QMARK__A_New() *A_arbace_go_check_types_const_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_const_type_QMARK__A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_go_check_types_const_type_QMARK__A) Ctor() {}
//line :112:1
func (t *A_arbace_go_check_types_const_type_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var b__2 any; var root_196 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, A_arbace_go_check_types_basic_A_fn_class); var ifn_198 lang.IFn; if


	linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = t__0; if linked_197 == nil { b__2 = ifn_198.Invoke_O__O(arg_199) } else { b__2 = linked_197.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_196, arg_199) }; var and__1927000168__auto____3 any = b__2; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_200 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = lang.IFn_Cast(A_arbace_go_check_types_A_const_84).Invoke_O__O(b__2); if linked_201 == nil { return ifn_202.Invoke_O__O(arg_203) } else { return linked_201.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_200, arg_203) } } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_ordered_QMARK__A_New() *A_arbace_go_check_types_ordered_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ordered_QMARK__A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_go_check_types_ordered_QMARK__A) Ctor() {}
//line :116:1
func (t *A_arbace_go_check_types_ordered_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_204 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = t__0; if linked_205 == nil { or__1927000174__auto____2 = ifn_206.Invoke_O__O(arg_207) } else { or__1927000174__auto____2 = linked_205.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_204, arg_207) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_208 any = A_arbace_go_check_types_A_const_81.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = t__0; if linked_209 == nil { or__1927000174__auto____3 = ifn_210.Invoke_O__O(arg_211) } else { or__1927000174__auto____3 = linked_209.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_208, arg_211) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_212 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, A_arbace_go_check_types_string_type_QMARK__A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = t__0; if linked_213 == nil { return ifn_214.Invoke_O__O(arg_215) } else { return linked_213.(*A_arbace_go_check_types_string_type_QMARK__A).Invoke_O_O__O(root_212, arg_215) } } } }
func A_arbace_go_check_types_interface_QMARK__A_New() *A_arbace_go_check_types_interface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_interface_QMARK__A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_go_check_types_interface_QMARK__A) Ctor() {}
//line :117:1
func (t *A_arbace_go_check_types_interface_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_216 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, A_arbace_go_check_types_under_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = t__0; if linked_217 == nil { u__2 = ifn_218.Invoke_O__O(arg_219) } else { u__2 = linked_217.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_216, arg_219) }; var and__1927000168__auto____3 any; var root_220 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = u__2; if linked_221 == nil { and__1927000168__auto____3 = ifn_222.Invoke_O__O(arg_223) } else { and__1927000168__auto____3 = linked_221.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_220, arg_223) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_86; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_pointer_QMARK__A_New() *A_arbace_go_check_types_pointer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_pointer_QMARK__A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_go_check_types_pointer_QMARK__A) Ctor() {}
//line :118:1
func (t *A_arbace_go_check_types_pointer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_224 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, A_arbace_go_check_types_under_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = t__0; if linked_225 == nil { u__2 = ifn_226.Invoke_O__O(arg_227) } else { u__2 = linked_225.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_224, arg_227) }; var and__1927000168__auto____3 any; var root_228 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = u__2; if linked_229 == nil { and__1927000168__auto____3 = ifn_230.Invoke_O__O(arg_231) } else { and__1927000168__auto____3 = linked_229.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_228, arg_231) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_87; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____3 } }
func A_arbace_go_check_types_unsafe_pointer_QMARK__A_New() *A_arbace_go_check_types_unsafe_pointer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_unsafe_pointer_QMARK__A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_go_check_types_unsafe_pointer_QMARK__A) Ctor() {}
//line :119:1
func (t *A_arbace_go_check_types_unsafe_pointer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_42; var tmp2 any; var root_232 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, A_arbace_go_check_types_basic_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = t__0; if linked_233 == nil { tmp2 = ifn_234.Invoke_O__O(arg_235) } else { tmp2 = linked_233.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_232, arg_235) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }
func A_arbace_go_check_types_uintptr_QMARK__A_New() *A_arbace_go_check_types_uintptr_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_uintptr_QMARK__A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_go_check_types_uintptr_QMARK__A) Ctor() {}
//line :120:1
func (t *A_arbace_go_check_types_uintptr_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var tmp1 any = A_arbace_go_check_types_A_const_32; var tmp2 any; var root_236 any = A_arbace_go_check_types_A_const_77.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, A_arbace_go_check_types_basic_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = t__0; if linked_237 == nil { tmp2 = ifn_238.Invoke_O__O(arg_239) } else { tmp2 = linked_237.(*A_arbace_go_check_types_basic_A).Invoke_O_O__O(root_236, arg_239) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }
func A_arbace_go_check_types_valid_QMARK__A_New() *A_arbace_go_check_types_valid_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_valid_QMARK__A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_go_check_types_valid_QMARK__A) Ctor() {}
//line :121:1
func (t *A_arbace_go_check_types_valid_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_240 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = A_arbace_go_check_types_A_const_67; var arg_244 any = t__0; if linked_241 == nil { return ifn_242.Invoke_O_O__O(arg_243, arg_244) } else { return linked_241.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_240, arg_243, arg_244) } }
func A_arbace_go_check_types_kind_of_A_New() *A_arbace_go_check_types_kind_of_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_kind_of_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_go_check_types_kind_of_A) Ctor() {}
//line :122:1
func (t *A_arbace_go_check_types_kind_of_A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_245 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, A_arbace_go_check_types_under_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = t__0; if linked_246 == nil { u__2 = ifn_247.Invoke_O__O(arg_248) } else { u__2 = linked_246.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_245, arg_248) }; var tmp1 any; var root_249 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = u__2; if linked_250 == nil { tmp1 = ifn_251.Invoke_O__O(arg_252) } else { tmp1 = linked_250.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_249, arg_252) }; if jrt.J2g_Truth(tmp1) { return u__2 } else { return lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)) } }
func A_arbace_go_check_types_has_name_QMARK__A_New() *A_arbace_go_check_types_has_name_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_name_QMARK__A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_go_check_types_has_name_QMARK__A) Ctor() {}
//line :123:1
func (t *A_arbace_go_check_types_has_name_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_253 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = t__0; if linked_254 == nil { or__1927000174__auto____2 = ifn_255.Invoke_O__O(arg_256) } else { or__1927000174__auto____2 = linked_254.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_253, arg_256) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_257 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = t__0; if linked_258 == nil { or__1927000174__auto____3 = ifn_259.Invoke_O__O(arg_260) } else { or__1927000174__auto____3 = linked_258.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_257, arg_260) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_261 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = t__0; if linked_262 == nil { return ifn_263.Invoke_O__O(arg_264) } else { return linked_262.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_261, arg_264) } } } }
func A_arbace_go_check_types_integer_or_float_QMARK__A_New() *A_arbace_go_check_types_integer_or_float_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_integer_or_float_QMARK__A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_go_check_types_integer_or_float_QMARK__A) Ctor() {}
//line :124:1
func (t *A_arbace_go_check_types_integer_or_float_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var or__1927000174__auto____2 any; var root_265 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, A_arbace_go_check_types_integer_type_QMARK__A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = t__0; if linked_266 == nil { or__1927000174__auto____2 = ifn_267.Invoke_O__O(arg_268) } else { or__1927000174__auto____2 = linked_266.(*A_arbace_go_check_types_integer_type_QMARK__A).Invoke_O_O__O(root_265, arg_268) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_269 any = A_arbace_go_check_types_A_const_81.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, A_arbace_go_check_types_float_type_QMARK__A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = t__0; if linked_270 == nil { return ifn_271.Invoke_O__O(arg_272) } else { return linked_270.(*A_arbace_go_check_types_float_type_QMARK__A).Invoke_O_O__O(root_269, arg_272) } } }



func A_arbace_go_check_types_has_nil_QMARK__A_New() *A_arbace_go_check_types_has_nil_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_nil_QMARK__A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_go_check_types_has_nil_QMARK__A) Ctor() {}
//line :128:1
func (t *A_arbace_go_check_types_has_nil_QMARK__A) Invoke_O_O__O(self, t__0 any) any {



	var tmp1 any; var root_273 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = t__0; if linked_274 == nil { tmp1 = ifn_275.Invoke_O__O(arg_276) } else { tmp1 = linked_274.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_273, arg_276) }; if jrt.J2g_Truth(tmp1) {
		var root_277 any = A_arbace_go_check_types_A_const_90.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, A_arbace_go_check_types_under_is_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = t__0; var arg_281 any; var tmp2 any = A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A_New(); var tmp3 *jrt.Class; var fncls__290 *jrt.Class = A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A_fn_class; if fncls__290 == nil { var fncls__290d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A_fn_class = fncls__290d; tmp3 = fncls__290d } else { tmp3 = fncls__290 }; arg_281 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_278 == nil { return ifn_279.Invoke_O_O__O(arg_280, arg_281) } else { return linked_278.(*A_arbace_go_check_types_under_is_A).Invoke_O_O_O__O(root_277, arg_280, arg_281) } } else {
//line :132:1
			var u__2 any; var root_291 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, A_arbace_go_check_types_under_A_fn_class); var ifn_293 lang.IFn

			if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = t__0; if linked_292 == nil { u__2 = ifn_293.Invoke_O__O(arg_294) } else { u__2 = linked_292.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_291, arg_294) }
//line :132:1
			var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_42, u__2)


			if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_51, u__2); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var and__1927000168__auto____5 any; var root_295 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_297 lang.IFn
				if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = u__2; if linked_296 == nil { and__1927000168__auto____5 = ifn_297.Invoke_O__O(arg_298) } else { and__1927000168__auto____5 = linked_296.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_295, arg_298) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_299 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = A_arbace_go_check_types_A_const_93; var arg_303 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)); if linked_300 == nil { return ifn_301.Invoke_O_O__O(arg_302, arg_303) } else { return linked_300.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_299, arg_302, arg_303) } } else { return and__1927000168__auto____5 } } } } }
//line :133:1
func A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A_New() *A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A) Ctor() {}
//line :133:1
func (t *A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A) Invoke_O_O__O(self, u__1 any) any { var and__1927000168__auto____2 any; var root_282 any = A_arbace_go_check_types_A_const_91.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = u__1; if linked_283 == nil { and__1927000168__auto____2 = ifn_284.Invoke_O__O(arg_285) } else { and__1927000168__auto____2 = linked_283.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_282, arg_285) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_286 any = A_arbace_go_check_types_A_const_92.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, A_arbace_go_check_types_has_nil_QMARK__A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = u__1; if linked_287 == nil { return ifn_288.Invoke_O__O(arg_289) } else { return linked_287.(*A_arbace_go_check_types_has_nil_QMARK__A).Invoke_O_O__O(root_286, arg_289) } } else { return and__1927000168__auto____2 } }




func A_arbace_go_check_types_empty_interface_QMARK__A_New() *A_arbace_go_check_types_empty_interface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_empty_interface_QMARK__A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_go_check_types_empty_interface_QMARK__A) Ctor() {}
//line :138:1
func (t *A_arbace_go_check_types_empty_interface_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var u__2 any; var root_304 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, A_arbace_go_check_types_under_A_fn_class); var ifn_306 lang.IFn; if
												linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = t__0; if linked_305 == nil { u__2 = ifn_306.Invoke_O__O(arg_307) } else { u__2 = linked_305.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_304, arg_307) }; var and__1927000168__auto____3 any; var root_308 any = /*line :138:1*/A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_310 lang.IFn; if
												linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = u__2; if linked_309 == nil { and__1927000168__auto____3 = ifn_310.Invoke_O__O(arg_311) } else { and__1927000168__auto____3 = linked_309.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_308, arg_311) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp1 any = A_arbace_go_check_types_A_const_86; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____4 { var and__1927000168__auto____5 any; var root_312 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_313 == nil { and__1927000168__auto____5 = ifn_314.Invoke_O__O(arg_315) } else { and__1927000168__auto____5 = linked_313.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_312, arg_315) }; if jrt.J2g_Truth(and__1927000168__auto____5) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref() } else { return and__1927000168__auto____5 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_default_type_A_New() *A_arbace_go_check_types_default_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_default_type_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_go_check_types_default_type_A) Ctor() {}
//line :141:1
func (t *A_arbace_go_check_types_default_type_A) Invoke_O_O__O(self, t__0 any) any { var G__219000052__2_ any = t__0; switch


	lang.Util_Hash_O__I_NoInit(G__219000052__2_) >> 19 & 7 { case 0: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_49) { return A_arbace_go_check_types_A_const_38 }; case 1: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_43) { return A_arbace_go_check_types_A_const_14 }; case 3: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_48) { return A_arbace_go_check_types_A_const_35 }; case 5: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_46) { return A_arbace_go_check_types_A_const_25 }; case 6: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_50) { return A_arbace_go_check_types_A_const_40 }; case 7: if any(G__219000052__2_) == any(A_arbace_go_check_types_A_const_47) { return A_arbace_go_check_types_A_const_21 }; default:}; return t__0 }




func A_arbace_go_check_types_ignore_tags_A_New() *A_arbace_go_check_types_ignore_tags_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ignore_tags_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_go_check_types_ignore_tags_A) Ctor() {}
//line :149:1
func (t *A_arbace_go_check_types_ignore_tags_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_317 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = t__0; if linked_318 == nil { and__1927000168__auto____2 = ifn_319.Invoke_O__O(arg_320) } else { and__1927000168__auto____2 = linked_318.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_317, arg_320) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_321 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any; var root_325 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = t__0; if linked_326 == nil { arg_324 = ifn_327.Invoke_O__O(arg_328) } else { arg_324 = linked_326.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_325, arg_328) }; if linked_322 == nil { and__1927000168__auto____3 = ifn_323.Invoke_O__O(arg_324) } else { and__1927000168__auto____3 = linked_322.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_321, arg_324) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_329 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any; var root_333 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = t__0; if linked_334 == nil { arg_332 = ifn_335.Invoke_O__O(arg_336) } else { arg_332 = linked_334.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_333, arg_336) }; if linked_330 == nil { tmp1 = ifn_331.Invoke_O__O(arg_332) } else { tmp1 = linked_330.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_329, arg_332) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var G__219000055__2_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))
		switch lang.Util_Hash_O__I_NoInit(G__219000055__2_) >> 2 & 15 { case 1: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_95) { var tmp2 any = A_arbace_go_check_types_A_const_95; var tmp3 any; var root_338 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_340 lang.IFn




			if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_339 == nil { tmp3 = ifn_340.Invoke_O__O(arg_341) } else { tmp3 = linked_339.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_338, arg_341) }
//line :153:1
			var tmp4 any = tmp3; var tmp5 any; var root_342 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_344 lang.IFn




			if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_343 == nil { tmp5 = ifn_344.Invoke_O__O(arg_345) } else { tmp5 = linked_343.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_342, arg_345) }
//line :153:1
			return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp4, tmp5) }; case 2: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_96) { var tmp6 any = A_arbace_go_check_types_A_const_96; var tmp7 any; var root_346 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_348 lang.IFn


				if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_347 == nil { tmp7 = ifn_348.Invoke_O__O(arg_349) } else { tmp7 = linked_347.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_346, arg_349) }
//line :153:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7) }; case 3: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_97) { var tmp8 any = A_arbace_go_check_types_A_const_97; var tmp9 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp10 any; var root_350 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_352 lang.IFn



					if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_351 == nil { tmp10 = ifn_352.Invoke_O__O(arg_353) } else { tmp10 = linked_351.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_350, arg_353) }
//line :153:1
					return lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp9, tmp10) }; case 6: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_98) { var tmp11 any = A_arbace_go_check_types_A_const_98; var tmp12 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp13 any; var root_368 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_370 lang.IFn





						if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_369 == nil { tmp13 = ifn_370.Invoke_O__O(arg_371) } else { tmp13 = linked_369.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_368, arg_371) }
//line :153:1
						return lang.Tuple_Create_O_O_O__IPersistentVector(tmp11, tmp12, tmp13) }; case 7: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_100) {







							var root_354 any = A_arbace_go_check_types_A_const_10.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = A_arbace_go_check_types_A_const_101; var arg_358 any; var root_359 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var arg_363 any; var root_364 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = t__0; if linked_365 == nil { arg_363 = ifn_366.Invoke_O__O(arg_367) } else { arg_363 = linked_365.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_364, arg_367) }; if linked_360 == nil { arg_358 = ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { arg_358 = linked_360.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_359, arg_362, arg_363) }; if linked_355 == nil { return ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { return linked_355.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) } }
//line :153:1
		case 9: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_103) { var tmp14 any = A_arbace_go_check_types_A_const_103; var tmp15 any; var root_372 any = A_arbace_go_check_types_A_const_104.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_374 lang.IFn






			if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var arg_376 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_373 == nil { tmp15 = ifn_374.Invoke_O_O__O(arg_375, arg_376) } else { tmp15 = linked_373.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_372, arg_375, arg_376) }
//line :153:1
			var tmp16 any = tmp15; var tmp17 any; var root_377 any = A_arbace_go_check_types_A_const_104.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_377, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_379 lang.IFn






			if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; var arg_380 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var arg_381 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_378 == nil { tmp17 = ifn_379.Invoke_O_O__O(arg_380, arg_381) } else { tmp17 = linked_378.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_377, arg_380, arg_381) }
//line :153:1
			return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp14, tmp16, tmp17, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(3))) }; case 11: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_87) { var tmp18 any = A_arbace_go_check_types_A_const_87; var tmp19 any; var root_382 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_384 lang.IFn

				if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_383 == nil { tmp19 = ifn_384.Invoke_O__O(arg_385) } else { tmp19 = linked_383.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_382, arg_385) }
//line :153:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp18, tmp19) }; case 13: if any(G__219000055__2_) == any(A_arbace_go_check_types_A_const_105) { var tmp20 any = A_arbace_go_check_types_A_const_105; var tmp21 any; var root_386 any = A_arbace_go_check_types_A_const_104.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_388 lang.IFn
					if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any; var tmp22 any = A_arbace_go_check_types_ignore_tags_fn__219000056_A_New(); var tmp23 *jrt.Class; var fncls__403 *jrt.Class = A_arbace_go_check_types_ignore_tags_fn__219000056_A_fn_class; if fncls__403 == nil { var fncls__403d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_check_types_ignore_tags_fn__219000056_A_fn_class = fncls__403d; tmp23 = fncls__403d } else { tmp23 = fncls__403 }; arg_389 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_390 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_387 == nil { tmp21 = ifn_388.Invoke_O_O__O(arg_389, arg_390) } else { tmp21 = linked_387.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_386, arg_389, arg_390) }
//line :153:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp20, tmp21) }; default:}; return t__0 } else {
//line :152:1
						return t__0
					} }
func A_arbace_go_check_types_ignore_tags_fn__219000056_A_New() *A_arbace_go_check_types_ignore_tags_fn__219000056_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_ignore_tags_fn__219000056_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_go_check_types_ignore_tags_fn__219000056_A) Ctor() {}
//line :154:1
func (t *A_arbace_go_check_types_ignore_tags_fn__219000056_A) Invoke_O_O__O(self, p1__219000054_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_59.GetRawRoot__O()); var tmp2 any = A_arbace_go_check_types_A_const_106; var tmp3 any = A_arbace_go_check_types_A_const_107; var tmp4 any; var root_399 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(p1__219000054_SHARP___1); if linked_400 == nil { tmp4 = ifn_401.Invoke_O__O(arg_402) } else { tmp4 = linked_400.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_399, arg_402) }; return tmp1.Invoke_O_O_O_O_O__O(p1__219000054_SHARP___1, tmp2, nil, tmp3, tmp4) }










func A_arbace_go_check_types_identical_ignore_tags_QMARK__A_New() *A_arbace_go_check_types_identical_ignore_tags_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_identical_ignore_tags_QMARK__A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_go_check_types_identical_ignore_tags_QMARK__A) Ctor() {}
//line :165:1
func (t *A_arbace_go_check_types_identical_ignore_tags_QMARK__A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 any; var root_404 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = x__0; if linked_405 == nil { tmp1 = ifn_406.Invoke_O__O(arg_407) } else { tmp1 = linked_405.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_404, arg_407) }; var tmp2 any = tmp1; var tmp3 any; var root_408 any = A_arbace_go_check_types_A_const_99.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, A_arbace_go_check_types_ignore_tags_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = y__1; if linked_409 == nil { tmp3 = ifn_410.Invoke_O__O(arg_411) } else { tmp3 = linked_409.(*A_arbace_go_check_types_ignore_tags_A).Invoke_O_O__O(root_408, arg_411) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() }





func A_arbace_go_check_types_tset_comparable_QMARK__A_New() *A_arbace_go_check_types_tset_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_comparable_QMARK__A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__A) Ctor() {}
//line :171:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__A) Invoke_O_O_O__O(self, ts__0, seen__1 any) any {


	var tmp1 any = A_arbace_go_check_types_A_const_108; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0)) {
		return A_arbace_go_check_types_A_const_110.Invoke_O__O(ts__0) } else {
//line :174:1
			var and__1927000168__auto____3 any; var root_412 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_414 lang.IFn

			if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0); if linked_413 == nil { and__1927000168__auto____3 = ifn_414.Invoke_O__O(arg_415) } else { and__1927000168__auto____3 = linked_413.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_412, arg_415) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_416 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any; var tmp2 any = A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A_New_O(seen__1); var tmp3 *jrt.Class; var fncls__426 *jrt.Class = A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A_fn_class; if fncls__426 == nil { var fncls__426d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A_fn_class = fncls__426d; tmp3 = fncls__426d } else { tmp3 = fncls__426 }; arg_419 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_420 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0); if linked_417 == nil { return ifn_418.Invoke_O_O__O(arg_419, arg_420) } else { return linked_417.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_416, arg_419, arg_420) } } else { return and__1927000168__auto____3 } } }
//line :176:1
func A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A_New_O(p0 any) *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A{}; t.Ctor_O(p0); return t }
//line :176:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A) Ctor_O(c__seen any) { t.F_seen = c__seen }
//line :176:1
func (t *A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A) Invoke_O_O__O(self, p__219000060__1 any) any { var vec__219000062__2 any = p__219000060__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000062__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000062__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_421 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_423 lang.IFn; _ = ___3; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = ty__4; var arg_425 any = t.F_seen; if linked_422 == nil { return ifn_423.Invoke_O_O__O(arg_424, arg_425) } else { return linked_422.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O_O__O(root_421, arg_424, arg_425) } }

func A_arbace_go_check_types_comparable_type_QMARK__A_New() *A_arbace_go_check_types_comparable_type_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_type_QMARK__A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__A) Ctor() {}
//line :178:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__A) Invoke_O_O_O_O__O(self, t__0, dynamic__1, seen__2 any) any {




	var tmp1 any; var root_427 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = seen__2; var arg_431 any = t__0; if linked_428 == nil { tmp1 = ifn_429.Invoke_O_O__O(arg_430, arg_431) } else { tmp1 = linked_428.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_427, arg_430, arg_431) }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var seen__4 any; var root_432 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_434 lang.IFn

		if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = seen__2; var arg_436 any = t__0; if linked_433 == nil { seen__4 = ifn_434.Invoke_O_O__O(arg_435, arg_436) } else { seen__4 = linked_433.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_432, arg_435, arg_436) }
		var tmp2 any; var root_437 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = t__0; if linked_438 == nil { tmp2 = ifn_439.Invoke_O__O(arg_440) } else { tmp2 = linked_438.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_437, arg_440) }; if jrt.J2g_Truth(tmp2) {
			var tmp3 any; var root_441 any = A_arbace_go_check_types_A_const_114.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any; var root_446 any = A_arbace_go_check_types_A_const_115.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = t__0; if linked_447 == nil { arg_444 = ifn_448.Invoke_O__O(arg_449) } else { arg_444 = linked_447.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_446, arg_449) }; var arg_445 any = seen__4; if linked_442 == nil { tmp3 = ifn_443.Invoke_O_O__O(arg_444, arg_445) } else { tmp3 = linked_442.(*A_arbace_go_check_types_tset_comparable_QMARK__A).Invoke_O_O_O__O(root_441, arg_444, arg_445) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp3)).Ref() } else {
//line :186:1
				var u__5 any; var root_450 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, A_arbace_go_check_types_under_A_fn_class); var ifn_452 lang.IFn

				if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = t__0; if linked_451 == nil { u__5 = ifn_452.Invoke_O__O(arg_453) } else { u__5 = linked_451.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_450, arg_453) }
				var tmp4 any; var root_454 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_456 lang.IFn
				if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = u__5; if linked_455 == nil { tmp4 = ifn_456.Invoke_O__O(arg_457) } else { tmp4 = linked_455.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_454, arg_457) }
//line :189:1
				if jrt.J2g_Truth(tmp4) {
					var root_458 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = u__5; var arg_462 any = A_arbace_go_check_types_A_const_51; if linked_459 == nil { return ifn_460.Invoke_O_O__O(arg_461, arg_462) } else { return linked_459.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_458, arg_461, arg_462) } } else {
//line :189:1
						if A_arbace_go_check_types_A_const_75 != nil { var G__219000068__6_ any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(0))


							switch lang.Util_Hash_O__I_NoInit(G__219000068__6_) >> 4 & 7 { case 0: if any(G__219000068__6_) == any(A_arbace_go_check_types_A_const_97) {



								var root_464 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(2)); var arg_468 any = dynamic__1; var arg_469 any = seen__4; if linked_465 == nil { return ifn_466.Invoke_O_O_O__O(arg_467, arg_468, arg_469) } else { return linked_465.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_464, arg_467, arg_468, arg_469) } }
//line :192:1
							case 1: if any(G__219000068__6_) == any(A_arbace_go_check_types_A_const_98) { return jrt.Boolean_TRUE.Ref() }; case 3: if any(G__219000068__6_) == any(A_arbace_go_check_types_A_const_86) { var or__1927000174__auto____7 any = dynamic__1

								if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var tmp5 any; var root_470 any = A_arbace_go_check_types_A_const_114.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any; var root_475 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = u__5; if linked_476 == nil { arg_473 = ifn_477.Invoke_O__O(arg_478) } else { arg_473 = linked_476.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_475, arg_478) }; var arg_474 any = seen__4; if linked_471 == nil { tmp5 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { tmp5 = linked_471.(*A_arbace_go_check_types_tset_comparable_QMARK__A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp5)).Ref() } }
//line :192:1
							case 6: if any(G__219000068__6_) == any(A_arbace_go_check_types_A_const_87) { return jrt.Boolean_TRUE.Ref() }; case 7: if any(G__219000068__6_) == any(A_arbace_go_check_types_A_const_105) {


								var root_479 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any; var tmp6 any = A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A_New_O_O(seen__4, dynamic__1); var tmp7 *jrt.Class; var fncls__490 *jrt.Class = A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A_fn_class; if fncls__490 == nil { var fncls__490d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A_fn_class = fncls__490d; tmp7 = fncls__490d } else { tmp7 = fncls__490 }; arg_482 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_483 any = lang.RT_Nth_O_I__O_NoInit(u__5, lang.RT_IntCast_J__I_NoInit(1)); if linked_480 == nil { return ifn_481.Invoke_O_O__O(arg_482, arg_483) } else { return linked_480.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_479, arg_482, arg_483) } }
//line :192:1
							default:}; return jrt.Boolean_FALSE.Ref() } else {
//line :189:1
								return nil
							}
					}
			}
	}
}
func A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A{}; t.Ctor_O_O(p0, p1); return t }
//line :195:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A) Ctor_O_O(c__seen, c__dynamic any) { t.F_seen = c__seen; t.F_dynamic = c__dynamic }
//line :195:1
func (t *A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A) Invoke_O_O__O(self, p1__219000067_SHARP___1 any) any { var root_484 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(p1__219000067_SHARP___1); var arg_488 any = t.F_dynamic; var arg_489 any = t.F_seen; if linked_485 == nil { return ifn_486.Invoke_O_O_O__O(arg_487, arg_488, arg_489) } else { return linked_485.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_484, arg_487, arg_488, arg_489) } }



func A_arbace_go_check_types_strictly_comparable_QMARK__A_New() *A_arbace_go_check_types_strictly_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_strictly_comparable_QMARK__A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Ctor() {}
//line :199:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Invoke_O_O_O__O(self, t__0, seen__1 any) any { var root_491 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = t__0; var arg_495 any = jrt.Boolean_FALSE.Ref(); var arg_496 any = seen__1; if linked_492 == nil { return ifn_493.Invoke_O_O_O__O(arg_494, arg_495, arg_496) } else { return linked_492.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_491, arg_494, arg_495, arg_496) } }
//line :199:1
func (t *A_arbace_go_check_types_strictly_comparable_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_497 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = t__0; var arg_501 any = jrt.Boolean_FALSE.Ref(); var arg_502 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_498 == nil { return ifn_499.Invoke_O_O_O__O(arg_500, arg_501, arg_502) } else { return linked_498.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_497, arg_500, arg_501, arg_502) } }

func A_arbace_go_check_types_incomparable_cause_A_New() *A_arbace_go_check_types_incomparable_cause_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_incomparable_cause_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_go_check_types_incomparable_cause_A) Ctor() {}
//line :201:1
func (t *A_arbace_go_check_types_incomparable_cause_A) Invoke_O_O__O(self, t__0 any) any { var body_cause__2 *A_arbace_go_check_types_incomparable_cause_cause__219000073_A = A_arbace_go_check_types_incomparable_cause_cause__219000073_A_New(); var cause__2 any; var tmp1 *jrt.Class; var fncls__549 *jrt.Class = A_arbace_go_check_types_incomparable_cause_cause__219000073_A_fn_class; if fncls__549 == nil { var fncls__549d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_go_check_types_incomparable_cause_cause__219000073_A_fn_class = fncls__549d; tmp1 = fncls__549d } else { tmp1 = fncls__549 }; cause__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_cause__2), tmp1, nil); var or__1927000174__auto____3 any = lang.IFn_Cast(cause__2).Invoke_O_O__O(t__0, lang.PersistentHashSet_EMPTY.Ref()); if




















	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { return Lit_8 } }
//line :205:1
func A_arbace_go_check_types_incomparable_cause_cause__219000073_A_New() *A_arbace_go_check_types_incomparable_cause_cause__219000073_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_incomparable_cause_cause__219000073_A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000073_A) Ctor() {}
//line :205:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000073_A) Invoke_O_O_O__O(self, t__1, seen__2 any) any {
	var tmp1 any; var root_503 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = seen__2; var arg_507 any = t__1; if linked_504 == nil { tmp1 = ifn_505.Invoke_O_O__O(arg_506, arg_507) } else { tmp1 = linked_504.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_503, arg_506, arg_507) }; if jrt.J2g_Truth(tmp1) { return nil } else { var seen__3 any; var root_508 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_510 lang.IFn

		if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = seen__2; var arg_512 any = t__1; if linked_509 == nil { seen__3 = ifn_510.Invoke_O_O__O(arg_511, arg_512) } else { seen__3 = linked_509.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_508, arg_511, arg_512) }
		var tmp2 any; var root_513 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_515 lang.IFn; if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any = t__1; if linked_514 == nil { tmp2 = ifn_515.Invoke_O__O(arg_516) } else { tmp2 = linked_514.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_513, arg_516) }; if jrt.J2g_Truth(tmp2) {
			var tmp3 any; var root_517 any = A_arbace_go_check_types_A_const_114.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any; var root_522 any = A_arbace_go_check_types_A_const_115.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = t__1; if linked_523 == nil { arg_520 = ifn_524.Invoke_O__O(arg_525) } else { arg_520 = linked_523.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_522, arg_525) }; var arg_521 any = seen__3; if linked_518 == nil { tmp3 = ifn_519.Invoke_O_O__O(arg_520, arg_521) } else { tmp3 = linked_518.(*A_arbace_go_check_types_tset_comparable_QMARK__A).Invoke_O_O_O__O(root_517, arg_520, arg_521) }; if jrt.J2g_Truth(tmp3) { return nil } else { return Lit_8 } } else {
//line :209:1
				var u__4 any; var root_526 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_526, A_arbace_go_check_types_under_A_fn_class); var ifn_528 lang.IFn

				if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any = t__1; if linked_527 == nil { u__4 = ifn_528.Invoke_O__O(arg_529) } else { u__4 = linked_527.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_526, arg_529) }
				var tmp4 any; var root_530 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_532 lang.IFn
				if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = u__4; if linked_531 == nil { tmp4 = ifn_532.Invoke_O__O(arg_533) } else { tmp4 = linked_531.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_530, arg_533) }
//line :212:1
				if jrt.J2g_Truth(tmp4) {
					if lang.Util_Equiv_O_O__Z_NoInit(u__4, A_arbace_go_check_types_A_const_51) { return Lit_8 } else { return nil } } else {
//line :212:1
						if A_arbace_go_check_types_A_const_75 != nil { var G__219000074__5_ any = lang.RT_Nth_O_I__O_NoInit(u__4, lang.RT_IntCast_J__I_NoInit(0))


							switch lang.Util_Hash_O__I_NoInit(G__219000074__5_) >> 4 & 7 { case 0: if any(G__219000074__5_) == any(A_arbace_go_check_types_A_const_97) {




								if jrt.J2g_Truth(lang.IFn_Cast(self).Invoke_O_O__O(lang.RT_Nth_O_I__O_NoInit(u__4, lang.RT_IntCast_J__I_NoInit(2)), seen__3)) { var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_15); var tmp6 any; var root_535 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, A_arbace_go_check_types_type_str_A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = t__1; if linked_536 == nil { tmp6 = ifn_537.Invoke_O__O(arg_538) } else { tmp6 = linked_536.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_535, arg_538) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil)).Ref() } else { return nil } }
//line :215:1
							case 1: if any(G__219000074__5_) == any(A_arbace_go_check_types_A_const_98) { return nil }; case 3: if any(G__219000074__5_) == any(A_arbace_go_check_types_A_const_86) { return nil }; case 6: if any(G__219000074__5_) == any(A_arbace_go_check_types_A_const_87) { return nil }; case 7: if any(G__219000074__5_) == any(A_arbace_go_check_types_A_const_105) {

								var root_539 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any; var tmp7 any = A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A_New_O_O(self, seen__3); var tmp8 *jrt.Class; var fncls__548 *jrt.Class = A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A_fn_class; if fncls__548 == nil { var fncls__548d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A_fn_class = fncls__548d; tmp8 = fncls__548d } else { tmp8 = fncls__548 }; arg_542 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_543 any = lang.RT_Nth_O_I__O_NoInit(u__4, lang.RT_IntCast_J__I_NoInit(1)); if linked_540 == nil { return ifn_541.Invoke_O_O__O(arg_542, arg_543) } else { return linked_540.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_539, arg_542, arg_543) } }
//line :215:1
							default:}; return Lit_8 } else {
//line :212:1
								return nil
							}
					}
			}
	} }
func A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A{}; t.Ctor_O_O(p0, p1); return t }
//line :217:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A) Ctor_O_O(c__cause, c__seen any) { t.F_cause = c__cause; t.F_seen = c__seen }
//line :217:1
func (t *A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A) Invoke_O_O__O(self, fd__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_cause); if jrt.J2g_Truth(tmp1.Invoke_O_O__O(A_arbace_go_check_types_A_const_107.Invoke_O__O(fd__1), t.F_seen)) {
																var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_17, nil, Lit_15); var tmp3 any; var root_544 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, A_arbace_go_check_types_type_str_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(fd__1); if linked_545 == nil { tmp3 = ifn_546.Invoke_O__O(arg_547) } else { tmp3 = linked_545.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_544, arg_547) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref() } else {
//line :217:1
		return nil } }






func A_arbace_go_check_types_comparable_QMARK__A_New() *A_arbace_go_check_types_comparable_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_comparable_QMARK__A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Ctor() {}
//line :224:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Invoke_O_O_O__O(self, t__0, seen__1 any) any {



	var root_550 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = t__0; var arg_554 any = jrt.Boolean_TRUE.Ref(); var arg_555 any = seen__1; if linked_551 == nil { return ifn_552.Invoke_O_O_O__O(arg_553, arg_554, arg_555) } else { return linked_551.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_550, arg_553, arg_554, arg_555) } }
//line :224:1
func (t *A_arbace_go_check_types_comparable_QMARK__A) Invoke_O_O__O(self, t__0 any) any {


	var root_556 any = A_arbace_go_check_types_A_const_116.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, A_arbace_go_check_types_comparable_type_QMARK__A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = t__0; var arg_560 any = jrt.Boolean_TRUE.Ref(); var arg_561 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_557 == nil { return ifn_558.Invoke_O_O_O__O(arg_559, arg_560, arg_561) } else { return linked_557.(*A_arbace_go_check_types_comparable_type_QMARK__A).Invoke_O_O_O_O__O(root_556, arg_559, arg_560, arg_561)
	}
}











func A_arbace_go_check_types_union_QMARK__A_New() *A_arbace_go_check_types_union_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_union_QMARK__A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_go_check_types_union_QMARK__A) Ctor() {}
//line :241:1
func (t *A_arbace_go_check_types_union_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_562 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = t__0; if linked_563 == nil { and__1927000168__auto____2 = ifn_564.Invoke_O__O(arg_565) } else { and__1927000168__auto____2 = linked_563.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_562, arg_565) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_types_A_const_120; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_go_check_types_term_disjoint_QMARK__A_New() *A_arbace_go_check_types_term_disjoint_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_disjoint_QMARK__A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_go_check_types_term_disjoint_QMARK__A) Ctor() {}
//line :243:1
func (t *A_arbace_go_check_types_term_disjoint_QMARK__A) Invoke_O_O_O__O(self, p__219000081__0, p__219000082__1 any) any { var vec__219000083__3 any = p__219000081__0; var xt__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000083__3, lang.RT_IntCast_J__I_NoInit(0), nil); var x__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000083__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__219000086__6 any = p__219000082__1; var yt__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000086__6, lang.RT_IntCast_J__I_NoInit(0), nil); var y__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000086__6, lang.RT_IntCast_J__I_NoInit(1), nil); var root_566 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_568 lang.IFn; if
																linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any; if jrt.J2g_Truth(yt__7) { var root_571 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, A_arbace_go_check_types_under_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = x__5; if linked_572 == nil { arg_569 = ifn_573.Invoke_O__O(arg_574) } else { arg_569 = linked_572.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_571, arg_574) } } else { arg_569 = x__5 }; var arg_570 any; if jrt.J2g_Truth(xt__4) { var root_575 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, A_arbace_go_check_types_under_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = y__8; if linked_576 == nil { arg_570 = ifn_577.Invoke_O__O(arg_578) } else { arg_570 = linked_576.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_575, arg_578) } } else { arg_570 = y__8 }; if linked_567 == nil { return ifn_568.Invoke_O_O__O(arg_569, arg_570) } else { return linked_567.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_566, arg_569, arg_570) } }

func A_arbace_go_check_types_term_union_A_New() *A_arbace_go_check_types_term_union_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_union_A{}; t.Ctor(); return t }
//line :246:1
func (t *A_arbace_go_check_types_term_union_A) Ctor() {}
//line :246:1
func (t *A_arbace_go_check_types_term_union_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	var tmp1 any; var root_579 any = A_arbace_go_check_types_A_const_121.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_581 lang.IFn
	if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = x__0; var arg_583 any = y__1; if linked_580 == nil { tmp1 = ifn_581.Invoke_O_O__O(arg_582, arg_583) } else { tmp1 = linked_580.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_579, arg_582, arg_583) }
//line :247:1
	if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(x__0, y__1) } else { var tmp2 any; var or__1927000174__auto____3 any; var root_584 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_586 lang.IFn

		if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = x__0; if linked_585 == nil { or__1927000174__auto____3 = ifn_586.Invoke_O__O(arg_587) } else { or__1927000174__auto____3 = linked_585.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_584, arg_587) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_588 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any; var root_592 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = y__1; if linked_593 == nil { arg_591 = ifn_594.Invoke_O__O(arg_595) } else { arg_591 = linked_593.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_592, arg_595) }; if linked_589 == nil { tmp2 = ifn_590.Invoke_O__O(arg_591) } else { tmp2 = linked_589.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_588, arg_591) } }
//line :247:1
		if jrt.J2g_Truth(tmp2) { return lang.Tuple_Create_O__IPersistentVector(x__0) } else { if A_arbace_go_check_types_A_const_75 != nil { return lang.Tuple_Create_O__IPersistentVector(y__1) } else { return nil
		}
		}
	}
}
func A_arbace_go_check_types_term_intersect_A_New() *A_arbace_go_check_types_term_intersect_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_intersect_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_go_check_types_term_intersect_A) Ctor() {}
//line :252:1
func (t *A_arbace_go_check_types_term_intersect_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	var tmp1 any; var root_596 any = A_arbace_go_check_types_A_const_121.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_598 lang.IFn
	if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = x__0; var arg_600 any = y__1; if linked_597 == nil { tmp1 = ifn_598.Invoke_O_O__O(arg_599, arg_600) } else { tmp1 = linked_597.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_596, arg_599, arg_600) }
//line :253:1
	if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; var or__1927000174__auto____3 any; var root_601 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_603 lang.IFn

		if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any; var root_605 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = x__0; if linked_606 == nil { arg_604 = ifn_607.Invoke_O__O(arg_608) } else { arg_604 = linked_606.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_605, arg_608) }; if linked_602 == nil { or__1927000174__auto____3 = ifn_603.Invoke_O__O(arg_604) } else { or__1927000174__auto____3 = linked_602.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_601, arg_604) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_609 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = y__1; if linked_610 == nil { tmp2 = ifn_611.Invoke_O__O(arg_612) } else { tmp2 = linked_610.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_609, arg_612) } }
//line :253:1
		if jrt.J2g_Truth(tmp2) { return x__0 } else { if A_arbace_go_check_types_A_const_75 != nil { return y__1 } else { return nil
		}
		}
	}
}
func A_arbace_go_check_types_term_includes_QMARK__A_New() *A_arbace_go_check_types_term_includes_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_includes_QMARK__A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_go_check_types_term_includes_QMARK__A) Ctor() {}
//line :258:1
func (t *A_arbace_go_check_types_term_includes_QMARK__A) Invoke_O_O_O__O(self, p__219000092__0, t__1 any) any { var vec__219000093__3 any = p__219000092__0; var tilde__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000093__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000093__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; if jrt.J2g_Truth(tilde__4) { var root_613 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_613, A_arbace_go_check_types_under_A_fn_class); var ifn_615 lang.IFn; if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any = t__1; if linked_614 == nil { tmp1 = ifn_615.Invoke_O__O(arg_616) } else { tmp1 = linked_614.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_613, arg_616) } } else { tmp1 = t__1 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(ty__5, tmp1)).Ref() }

func A_arbace_go_check_types_term_subset_QMARK__A_New() *A_arbace_go_check_types_term_subset_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_term_subset_QMARK__A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_go_check_types_term_subset_QMARK__A) Ctor() {}
//line :260:1
func (t *A_arbace_go_check_types_term_subset_QMARK__A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var and__1927000168__auto____3 any; var root_617 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any; var root_621 any = A_arbace_go_check_types_A_const_121.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = x__0; var arg_625 any = y__1; if linked_622 == nil { arg_620 = ifn_623.Invoke_O_O__O(arg_624, arg_625) } else { arg_620 = linked_622.(*A_arbace_go_check_types_term_disjoint_QMARK__A).Invoke_O_O_O__O(root_621, arg_624, arg_625) }; if linked_618 == nil { and__1927000168__auto____3 = ifn_619.Invoke_O__O(arg_620) } else { and__1927000168__auto____3 = linked_618.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_617, arg_620) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var root_626 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any; var root_630 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = x__0; if linked_631 == nil { arg_629 = ifn_632.Invoke_O__O(arg_633) } else { arg_629 = linked_631.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_630, arg_633) }; if linked_627 == nil { or__1927000174__auto____4 = ifn_628.Invoke_O__O(arg_629) } else { or__1927000174__auto____4 = linked_627.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_626, arg_629) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var root_634 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = y__1; if linked_635 == nil { return ifn_636.Invoke_O__O(arg_637) } else { return linked_635.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_634, arg_637) } } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_terms_norm_A_New() *A_arbace_go_check_types_terms_norm_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_norm_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_go_check_types_terms_norm_A) Ctor() {}
//line :262:1
func (t *A_arbace_go_check_types_terms_norm_A) Invoke_O_O__O(self, ts__0 any) any { { var ts__2 any; var root_638 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_640 lang.IFn


	if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = ts__0; if linked_639 == nil { ts__2 = ifn_640.Invoke_O__O(arg_641) } else { ts__2 = linked_639.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_638, arg_641) }
//line :262:1
	var n__3 int32 = lang.RT_Count_O__I_NoInit(ts__2); var used__4 any = lang.Numbers_Boolean_array_O__Z1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref()).Ref(); var i__5 int64 = 0; var rl__6 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




		if lang.Util_Equiv_J_J__Z_NoInit(i__5, int64(n__3)) {

			var root_642 any = A_arbace_go_check_types_A_const_124.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any; var root_647 any = A_arbace_go_check_types_A_const_125.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = rl__6; if linked_648 == nil { arg_645 = ifn_649.Invoke_O__O(arg_650) } else { arg_645 = linked_648.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_647, arg_650) }; var arg_646 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_126, rl__6)); if linked_643 == nil { return ifn_644.Invoke_O_O__O(arg_645, arg_646) } else { return linked_643.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_642, arg_645, arg_646) } } else {
				if lang.RT_Aget_Z1_I__Z_NoInit(jrt.J2g_CastArray[*jrt.BooleanArray](used__4, jrt.Prim_boolean.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__5)) {
					i__5, rl__6 = lang.Numbers_Inc_J__J_NoInit(i__5), rl__6; continue L1 } else {
//line :270:1
						var xi__7 any; var tmp1 any = A_arbace_go_check_types_terms_norm_fn__219000098_A_New_J_I_O_O(i__5, n__3, used__4, ts__2); var tmp2 *jrt.Class
						var fncls__660 /*line :270:1*/*jrt.Class = A_arbace_go_check_types_terms_norm_fn__219000098_A_fn_class

						if fncls__660 == nil { var fncls__660d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_check_types_terms_norm_fn__219000098_A_fn_class = fncls__660d; tmp2 = fncls__660d } else { tmp2 = fncls__660 }; xi__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()







						var tmp3 int64 = lang.Numbers_Inc_J__J_NoInit(i__5); var tmp4 any; var root_661 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = rl__6; var arg_665 any = xi__7; if linked_662 == nil { tmp4 = ifn_663.Invoke_O_O__O(arg_664, arg_665) } else { tmp4 = linked_662.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_661, arg_664, arg_665) }; i__5, rl__6 = tmp3, tmp4; continue L1 } } } }; /*line :262:1*/panic("j2g: unreachable") }









func A_arbace_go_check_types_terms_norm_fn__219000098_A_New_J_I_O_O(p0 int64, p1 int32, p2, p3 any) *A_arbace_go_check_types_terms_norm_fn__219000098_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_norm_fn__219000098_A{}; t.Ctor_J_I_O_O(p0, p1, p2, p3); return t }
//line :272:1
func (t *A_arbace_go_check_types_terms_norm_fn__219000098_A) Ctor_J_I_O_O(c__i int64, c__n int32, c__used, c__ts any) { t.F_i = c__i; t.F_n = c__n; t.F_used = c__used; t.F_ts = c__ts }
//line :272:1
func (t *A_arbace_go_check_types_terms_norm_fn__219000098_A) Invoke_O__O(self any) any { { var j__1 int64 = lang.Numbers_Inc_J__J_NoInit(t.F_i); var tmp1 any = t.F_ts; var xi__2 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(t.F_i)); L1: for {
											if lang.Util_Equiv_J_J__Z_NoInit(j__1, int64(t.F_n)) { return xi__2 } else { var tmp2 *jrt.BooleanArray = jrt.J2g_CastArray[*jrt.BooleanArray](t.F_used, jrt.Prim_boolean.ArrayClass()); if lang.RT_Aget_Z1_I__Z_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(j__1)) {

		j__1, xi__2 = lang.Numbers_Inc_J__J_NoInit(j__1), xi__2; continue L1 } else {
//line :273:1
			if A_arbace_go_check_types_A_const_75 != nil { var u__3 any; var root_651 any = A_arbace_go_check_types_A_const_127.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, A_arbace_go_check_types_term_union_A_fn_class); var ifn_653 lang.IFn


				if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = xi__2; var tmp3 any = t.F_ts; var arg_655 any = lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(j__1)); if linked_652 == nil { u__3 = ifn_653.Invoke_O_O__O(arg_654, arg_655) } else { u__3 = linked_652.(*A_arbace_go_check_types_term_union_A).Invoke_O_O_O__O(root_651, arg_654, arg_655) }
				if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(u__3))) {
					var tmp4 *jrt.BooleanArray = jrt.J2g_CastArray[*jrt.BooleanArray](t.F_used, jrt.Prim_boolean.ArrayClass()); jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_Aset_Z1_I_Z__Z_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(j__1), jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z())); var tmp5 int64 = lang.Numbers_Inc_J__J_NoInit(j__1); var tmp6 any; var root_656 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = u__3; if linked_657 == nil { tmp6 = ifn_658.Invoke_O__O(arg_659) } else { tmp6 = linked_657.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_656, arg_659) }; j__1, xi__2 = tmp5, tmp6; continue L1 } else {
						j__1, xi__2 = lang.Numbers_Inc_J__J_NoInit(j__1), xi__2; continue L1 } } else {
//line :273:1
							return nil } } } } }; /*line :272:1*/panic("j2g: unreachable") }









func A_arbace_go_check_types_terms_union_A_New() *A_arbace_go_check_types_terms_union_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_union_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_go_check_types_terms_union_A) Ctor() {}
//line :282:1
func (t *A_arbace_go_check_types_terms_union_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, x__0); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, y__1) }; if tmp1 { return A_arbace_go_check_types_A_const_108 } else { var root_666 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, A_arbace_go_check_types_terms_norm_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any; var root_670 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = x__0; var arg_674 any = y__1; if linked_671 == nil { arg_669 = ifn_672.Invoke_O_O__O(arg_673, arg_674) } else { arg_669 = linked_671.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_670, arg_673, arg_674) }; if linked_667 == nil { return ifn_668.Invoke_O__O(arg_669) } else { return linked_667.(*A_arbace_go_check_types_terms_norm_A).Invoke_O_O__O(root_666, arg_669) } } }

func A_arbace_go_check_types_terms_intersect_A_New() *A_arbace_go_check_types_terms_intersect_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_go_check_types_terms_intersect_A) Ctor() {}
//line :284:1
func (t *A_arbace_go_check_types_terms_intersect_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, x__0) { return y__1 } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, y__1) { return x__0 } else { var tmp1 any; var or__1927000174__auto____3 any; var root_675 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_677 lang.IFn


		if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = x__0; if linked_676 == nil { or__1927000174__auto____3 = ifn_677.Invoke_O__O(arg_678) } else { or__1927000174__auto____3 = linked_676.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_675, arg_678) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_679 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = y__1; if linked_680 == nil { tmp1 = ifn_681.Invoke_O__O(arg_682) } else { tmp1 = linked_680.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_679, arg_682) } }
//line :285:1
		if jrt.J2g_Truth(tmp1) { return lang.PersistentHashSet_EMPTY.Ref() } else { if A_arbace_go_check_types_A_const_75 != nil {



			var root_683 any = A_arbace_go_check_types_A_const_128.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, A_arbace_go_check_types_terms_norm_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any; var iter__1927001039__auto____3 any; var tmp2 any = A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_A_New_O(y__1); var tmp3 *jrt.Class; var fncls__786 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_A_fn_class; if fncls__786 == nil { var fncls__786d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_A_fn_class = fncls__786d; tmp3 = fncls__786d } else { tmp3 = fncls__786 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); arg_686 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(x__0); if linked_684 == nil { return ifn_685.Invoke_O__O(arg_686) } else { return linked_684.(*A_arbace_go_check_types_terms_norm_A).Invoke_O_O__O(root_683, arg_686) } } else {
//line :285:1
				return nil
			}
		}
	} } }
func A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_A_New_O(p0 any) *A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_A{}; t.Ctor_O(p0); return t }
//line :289:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_A) Ctor_O(c__y any) { t.F_y = c__y }
//line :289:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_A) Invoke_O_O__O(self, s__219000103__1 any) any { var tmp1 any = A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_A_New_O_O_O(self, s__219000103__1, t.F_y); var tmp2 *jrt.Class; var fncls__785 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_A_fn_class; if fncls__785 == nil { var fncls__785d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_A_fn_class = fncls__785d; tmp2 = fncls__785d } else { tmp2 = fncls__785 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :289:1
func A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :289:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_A) Ctor_O_O_O(c__iter__219000102, c__s__219000103, c__y any) { t.F_iter__219000102 = c__iter__219000102; t.F_s__219000103 = c__s__219000103; t.F_y = c__y }
//line :289:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_A) Invoke_O__O(self any) any { { var s__219000103__1 any; var t_ any = t.F_s__219000103; t.F_s__219000103 = nil; s__219000103__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_687 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_689 lang.IFn; if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = s__219000103__1; if linked_688 == nil { temp__1927000414__auto____2 = ifn_689.Invoke_O__O(arg_690) } else { temp__1927000414__auto____2 = linked_688.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_687, arg_690) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var a__4 any; var root_691 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = xs__1927001018__auto____3; if linked_692 == nil { a__4 = ifn_693.Invoke_O__O(arg_694) } else { a__4 = linked_692.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_691, arg_694) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_A_New_O(a__4); var tmp2 *jrt.Class; var fncls__767 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_A_fn_class; if fncls__767 == nil { var fncls__767d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_A_fn_class = fncls__767d; tmp2 = fncls__767d } else { tmp2 = fncls__767 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_768 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(t.F_y); if linked_769 == nil { fs__1927001036__auto____6 = ifn_770.Invoke_O__O(arg_771) } else { fs__1927001036__auto____6 = linked_769.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_768, arg_771) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_772 any = A_arbace_go_check_types_A_const_129.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any = fs__1927001036__auto____6; var arg_776 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__219000102); var tmp4 any; var root_777 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_779 lang.IFn; if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = s__219000103__1; if linked_778 == nil { tmp4 = ifn_779.Invoke_O__O(arg_780) } else { tmp4 = linked_778.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_777, arg_780) }; arg_776 = tmp3.Invoke_O__O(tmp4); if linked_773 == nil { return ifn_774.Invoke_O_O__O(arg_775, arg_776) } else { return linked_773.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_772, arg_775, arg_776) } } else { var tmp5 any; var root_781 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = s__219000103__1; if linked_782 == nil { tmp5 = ifn_783.Invoke_O__O(arg_784) } else { tmp5 = linked_782.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_781, arg_784) }; s__219000103__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :289:1
func A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_A_New_O(p0 any) *A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_A{}; t.Ctor_O(p0); return t }
//line :289:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_A) Ctor_O(c__a any) { t.F_a = c__a }
//line :289:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_A) Invoke_O_O__O(self, s__219000105__1 any) any { var tmp1 any = A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_A_New_O_O_O(self, s__219000105__1, t.F_a); var tmp2 *jrt.Class; var fncls__766 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_A_fn_class; if fncls__766 == nil { var fncls__766d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_A_fn_class = fncls__766d; tmp2 = fncls__766d } else { tmp2 = fncls__766 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :289:1
func A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :289:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_A) Ctor_O_O_O(c__iter__219000104, c__s__219000105, c__a any) { t.F_iter__219000104 = c__iter__219000104; t.F_s__219000105 = c__s__219000105; t.F_a = c__a }
//line :289:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_A) Invoke_O__O(self any) any { { var s__219000105__1 any; var t_ any = t.F_s__219000105; t.F_s__219000105 = nil; s__219000105__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_695 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = s__219000105__1; if linked_696 == nil { temp__1927000414__auto____2 = ifn_697.Invoke_O__O(arg_698) } else { temp__1927000414__auto____2 = linked_696.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_695, arg_698) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000105__3 any = temp__1927000414__auto____2; var tmp1 any; var root_699 any = A_arbace_go_check_types_A_const_130.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any = s__219000105__3; if linked_700 == nil { tmp1 = ifn_701.Invoke_O__O(arg_702) } else { tmp1 = linked_700.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_699, arg_702) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_703 any = A_arbace_go_check_types_A_const_131.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = s__219000105__3; if linked_704 == nil { c__1927001037__auto____4 = ifn_705.Invoke_O__O(arg_706) } else { c__1927001037__auto____4 = linked_704.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_703, arg_706) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000107__6 any; var root_707 any = A_arbace_go_check_types_A_const_132.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_708 == nil { b__219000107__6 = ifn_709.Invoke_O__O(arg_710) } else { b__219000107__6 = linked_708.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_707, arg_710) }; var tmp2 any = A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_fn__219000112_A_New_O_I_O_O(b__219000107__6, size__1927001038__auto____5, t.F_a, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__721 *jrt.Class = A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_fn__219000112_A_fn_class; if fncls__721 == nil { var fncls__721d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_fn__219000112_A_fn_class = fncls__721d; tmp3 = fncls__721d } else { tmp3 = fncls__721 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_722 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_722, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_724 lang.IFn; if linked_723 == nil { ifn_724 = lang.IFn_Cast(root_722) } else { ifn_724 = nil }; var arg_725 any; var root_727 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = b__219000107__6; if linked_728 == nil { arg_725 = ifn_729.Invoke_O__O(arg_730) } else { arg_725 = linked_728.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_727, arg_730) }; var arg_726 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000104); var tmp5 any; var root_731 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_731, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_733 lang.IFn; if linked_732 == nil { ifn_733 = lang.IFn_Cast(root_731) } else { ifn_733 = nil }; var arg_734 any = s__219000105__3; if linked_732 == nil { tmp5 = ifn_733.Invoke_O__O(arg_734) } else { tmp5 = linked_732.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_731, arg_734) }; arg_726 = tmp4.Invoke_O__O(tmp5); if linked_723 == nil { return ifn_724.Invoke_O_O__O(arg_725, arg_726) } else { return linked_723.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_722, arg_725, arg_726) } } else { var root_735 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_737 lang.IFn; if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any; var root_740 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_742 lang.IFn; if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any = b__219000107__6; if linked_741 == nil { arg_738 = ifn_742.Invoke_O__O(arg_743) } else { arg_738 = linked_741.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_740, arg_743) }; var arg_739 any; if linked_736 == nil { return ifn_737.Invoke_O_O__O(arg_738, arg_739) } else { return linked_736.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_735, arg_738, arg_739) } } } else { var b__4 any; var root_744 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_744, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_746 lang.IFn; if linked_745 == nil { ifn_746 = lang.IFn_Cast(root_744) } else { ifn_746 = nil }; var arg_747 any = s__219000105__3; if linked_745 == nil { b__4 = ifn_746.Invoke_O__O(arg_747) } else { b__4 = linked_745.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_744, arg_747) }; var r__5 any; var root_748 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, A_arbace_go_check_types_term_intersect_A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = t.F_a; var arg_752 any = b__4; if linked_749 == nil { r__5 = ifn_750.Invoke_O_O__O(arg_751, arg_752) } else { r__5 = linked_749.(*A_arbace_go_check_types_term_intersect_A).Invoke_O_O_O__O(root_748, arg_751, arg_752) }; if jrt.J2g_Truth(r__5) { var root_753 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any = r__5; var arg_757 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__219000104); var tmp7 any; var root_758 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_758, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_760 lang.IFn; if linked_759 == nil { ifn_760 = lang.IFn_Cast(root_758) } else { ifn_760 = nil }; var arg_761 any = s__219000105__3; if linked_759 == nil { tmp7 = ifn_760.Invoke_O__O(arg_761) } else { tmp7 = linked_759.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_758, arg_761) }; arg_757 = tmp6.Invoke_O__O(tmp7); if linked_754 == nil { return ifn_755.Invoke_O_O__O(arg_756, arg_757) } else { return linked_754.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_753, arg_756, arg_757) } } else { var tmp8 any; var root_762 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_764 lang.IFn; if linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = s__219000105__3; if linked_763 == nil { tmp8 = ifn_764.Invoke_O__O(arg_765) } else { tmp8 = linked_763.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_762, arg_765) }; s__219000105__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :289:1
func A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_fn__219000112_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_fn__219000112_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_fn__219000112_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :289:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_fn__219000112_A) Ctor_O_I_O_O(c__b__219000107 any, c__size__1927001038__auto__ int32, c__a, c__c__1927001037__auto__ any) { t.F_b__219000107 = c__b__219000107; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_a = c__a; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :289:1
func (t *A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_fn__219000112_A) Invoke_O__O(self any) any { { var i__219000106__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000106__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000106__1)); var r__3 any; var root_711 any = A_arbace_go_check_types_A_const_133.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, A_arbace_go_check_types_term_intersect_A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = t.F_a; var arg_715 any = b__2; if linked_712 == nil { r__3 = ifn_713.Invoke_O_O__O(arg_714, arg_715) } else { r__3 = linked_712.(*A_arbace_go_check_types_term_intersect_A).Invoke_O_O_O__O(root_711, arg_714, arg_715) }; if jrt.J2g_Truth(r__3) { var root_716 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = t.F_b__219000107; var arg_720 any = r__3; if linked_717 == nil { ifn_718.Invoke_O_O__O(arg_719, arg_720) } else { linked_717.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_716, arg_719, arg_720) }; i__219000106__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000106__1); continue L1 } else { i__219000106__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000106__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_types_terms_includes_QMARK__A_New() *A_arbace_go_check_types_terms_includes_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_includes_QMARK__A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__A) Ctor() {}
//line :291:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__A) Invoke_O_O_O__O(self, xl__0, t__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, xl__0); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp1 any; var root_787 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_789 lang.IFn; if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any; var tmp2 any = A_arbace_go_check_types_terms_includes_QMARK__fn__219000120_A_New_O(t__1); var tmp3 *jrt.Class; var fncls__797 *jrt.Class = A_arbace_go_check_types_terms_includes_QMARK__fn__219000120_A_fn_class; if fncls__797 == nil { var fncls__797d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_check_types_terms_includes_QMARK__fn__219000120_A_fn_class = fncls__797d; tmp3 = fncls__797d } else { tmp3 = fncls__797 }; arg_790 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_791 any = xl__0; if linked_788 == nil { tmp1 = ifn_789.Invoke_O_O__O(arg_790, arg_791) } else { tmp1 = linked_788.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_787, arg_790, arg_791) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } }
//line :291:1
func A_arbace_go_check_types_terms_includes_QMARK__fn__219000120_A_New_O(p0 any) *A_arbace_go_check_types_terms_includes_QMARK__fn__219000120_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_includes_QMARK__fn__219000120_A{}; t.Ctor_O(p0); return t }
//line :291:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__fn__219000120_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :291:1
func (t *A_arbace_go_check_types_terms_includes_QMARK__fn__219000120_A) Invoke_O_O__O(self, p1__219000119_SHARP___1 any) any { var root_792 any = A_arbace_go_check_types_A_const_139.GetRawRoot__O(); var linked_793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_792, A_arbace_go_check_types_term_includes_QMARK__A_fn_class); var ifn_794 lang.IFn; if linked_793 == nil { ifn_794 = lang.IFn_Cast(root_792) } else { ifn_794 = nil }; var arg_795 any = p1__219000119_SHARP___1; var arg_796 any = t.F_t; if linked_793 == nil { return ifn_794.Invoke_O_O__O(arg_795, arg_796) } else { return linked_793.(*A_arbace_go_check_types_term_includes_QMARK__A).Invoke_O_O_O__O(root_792, arg_795, arg_796) } }

func A_arbace_go_check_types_terms_superset_of_QMARK__A_New() *A_arbace_go_check_types_terms_superset_of_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_superset_of_QMARK__A{}; t.Ctor(); return t }
//line :293:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__A) Ctor() {}
//line :293:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__A) Invoke_O_O_O__O(self, xl__0, y__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, xl__0); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var tmp1 any; var root_798 any = A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any; var tmp2 any = A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000124_A_New_O(y__1); var tmp3 *jrt.Class; var fncls__808 *jrt.Class = A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000124_A_fn_class; if fncls__808 == nil { var fncls__808d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000124_A_fn_class = fncls__808d; tmp3 = fncls__808d } else { tmp3 = fncls__808 }; arg_801 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_802 any = xl__0; if linked_799 == nil { tmp1 = ifn_800.Invoke_O_O__O(arg_801, arg_802) } else { tmp1 = linked_799.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_798, arg_801, arg_802) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } }
//line :293:1
func A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000124_A_New_O(p0 any) *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000124_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000124_A{}; t.Ctor_O(p0); return t }
//line :293:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000124_A) Ctor_O(c__y any) { t.F_y = c__y }
//line :293:1
func (t *A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000124_A) Invoke_O_O__O(self, p1__219000123_SHARP___1 any) any { var root_803 any = A_arbace_go_check_types_A_const_140.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, A_arbace_go_check_types_term_subset_QMARK__A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = t.F_y; var arg_807 any = p1__219000123_SHARP___1; if linked_804 == nil { return ifn_805.Invoke_O_O__O(arg_806, arg_807) } else { return linked_804.(*A_arbace_go_check_types_term_subset_QMARK__A).Invoke_O_O_O__O(root_803, arg_806, arg_807) } }

func A_arbace_go_check_types_terms_subset_QMARK__A_New() *A_arbace_go_check_types_terms_subset_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_subset_QMARK__A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__A) Ctor() {}
//line :295:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__A) Invoke_O_O_O__O(self, xl__0, yl__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, yl__1) { return jrt.Boolean_TRUE.Ref() } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, xl__0) { return jrt.Boolean_FALSE.Ref() } else { var tmp1 any; var root_809 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_811 lang.IFn


		if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = yl__1; if linked_810 == nil { tmp1 = ifn_811.Invoke_O__O(arg_812) } else { tmp1 = linked_810.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_809, arg_812) }
//line :298:1
		if jrt.J2g_Truth(tmp1) {


			var root_813 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_815 lang.IFn; if linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = xl__0; if linked_814 == nil { return ifn_815.Invoke_O__O(arg_816) } else { return linked_814.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_813, arg_816) } } else {
//line :298:1
				if A_arbace_go_check_types_A_const_75 != nil {



					var root_817 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any; var tmp2 any = A_arbace_go_check_types_terms_subset_QMARK__fn__219000128_A_New_O(yl__1); var tmp3 *jrt.Class; var fncls__827 *jrt.Class = A_arbace_go_check_types_terms_subset_QMARK__fn__219000128_A_fn_class; if fncls__827 == nil { var fncls__827d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_go_check_types_terms_subset_QMARK__fn__219000128_A_fn_class = fncls__827d; tmp3 = fncls__827d } else { tmp3 = fncls__827 }; arg_820 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_821 any = xl__0; if linked_818 == nil { return ifn_819.Invoke_O_O__O(arg_820, arg_821) } else { return linked_818.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_817, arg_820, arg_821) } } else {
//line :298:1
						return nil
					}
			}
	} } }
func A_arbace_go_check_types_terms_subset_QMARK__fn__219000128_A_New_O(p0 any) *A_arbace_go_check_types_terms_subset_QMARK__fn__219000128_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_subset_QMARK__fn__219000128_A{}; t.Ctor_O(p0); return t }
//line :302:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__fn__219000128_A) Ctor_O(c__yl any) { t.F_yl = c__yl }
//line :302:1
func (t *A_arbace_go_check_types_terms_subset_QMARK__fn__219000128_A) Invoke_O_O__O(self, p1__219000127_SHARP___1 any) any { var root_822 any = A_arbace_go_check_types_A_const_141.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, A_arbace_go_check_types_terms_superset_of_QMARK__A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = t.F_yl; var arg_826 any = p1__219000127_SHARP___1; if linked_823 == nil { return ifn_824.Invoke_O_O__O(arg_825, arg_826) } else { return linked_823.(*A_arbace_go_check_types_terms_superset_of_QMARK__A).Invoke_O_O_O__O(root_822, arg_825, arg_826) } }

func A_arbace_go_check_types_make_tset_A_New() *A_arbace_go_check_types_make_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_make_tset_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_go_check_types_make_tset_A) Ctor() {}
//line :304:1
func (t *A_arbace_go_check_types_make_tset_A) Invoke_O_O_O__O(self, terms__0, comparable__1 any) any {


	var tmp1 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, terms__0); if and__1927000168__auto____3 { var root_828 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = comparable__1; if linked_829 == nil { tmp1 = ifn_830.Invoke_O__O(arg_831) } else { tmp1 = linked_829.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_828, arg_831) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any = A_arbace_go_check_types_A_const_109; var tmp3 any = A_arbace_go_check_types_A_const_110; var tmp4 any; var and__1927000168__auto____3_2 any = comparable__1; if jrt.J2g_Truth(and__1927000168__auto____3_2) { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_108, terms__0)).Ref() } else { tmp4 = and__1927000168__auto____3_2 }; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, terms__0, tmp3, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp4)).Ref()))
	} }
func A_arbace_go_check_types_iface_tset_A_New() *A_arbace_go_check_types_iface_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_iface_tset_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_go_check_types_iface_tset_A) Ctor() {}
//line :309:1
func (t *A_arbace_go_check_types_iface_tset_A) Invoke_O_O__O(self, u__0 any) any { var ts__2 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(2)); var tmp1 any = A_arbace_go_check_types_A_const_62; var tmp2 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp3 any = A_arbace_go_check_types_A_const_109; var tmp4 any; var tmp5 any; var root_832 any = A_arbace_go_check_types_A_const_142.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_834 lang.IFn; if





	linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any = ts__2; if linked_833 == nil { tmp5 = ifn_834.Invoke_O__O(arg_835) } else { tmp5 = linked_833.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_832, arg_835) }; if jrt.J2g_Truth(tmp5) { tmp4 = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__2) } else { tmp4 = A_arbace_go_check_types_A_const_108 }; var tmp6 any = tmp4; var tmp7 any = A_arbace_go_check_types_A_const_110; var tmp8 any; var and__1927000168__auto____3 any; var root_836 any = /*line :309:1*/A_arbace_go_check_types_A_const_142.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_838 lang.IFn; if






	linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = ts__2; if linked_837 == nil { and__1927000168__auto____3 = ifn_838.Invoke_O__O(arg_839) } else { and__1927000168__auto____3 = linked_837.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_836, arg_839) }; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp8 = A_arbace_go_check_types_A_const_110.Invoke_O__O(ts__2) } else { tmp8 = and__1927000168__auto____3 }; return /*line :309:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp6, tmp7, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp8)).Ref())) }








func A_arbace_go_check_types_has_terms_QMARK__A_New() *A_arbace_go_check_types_has_terms_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_has_terms_QMARK__A{}; t.Ctor(); return t }
//line :318:1
func (t *A_arbace_go_check_types_has_terms_QMARK__A) Ctor() {}
//line :318:1
func (t *A_arbace_go_check_types_has_terms_QMARK__A) Invoke_O_O__O(self, ts__0 any) any { var terms__2 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0); var and__1927000168__auto____3 any; var root_840 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_842 lang.IFn; if


	linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = A_arbace_go_check_types_A_const_108; var arg_844 any = terms__2; if linked_841 == nil { and__1927000168__auto____3 = ifn_842.Invoke_O_O__O(arg_843, arg_844) } else { and__1927000168__auto____3 = linked_841.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_840, arg_843, arg_844) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_845 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_845, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any = terms__2; if linked_846 == nil { return ifn_847.Invoke_O__O(arg_848) } else { return linked_846.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_845, arg_848) } } else { return and__1927000168__auto____3 } }

func A_arbace_go_check_types_tset_empty_QMARK__A_New() *A_arbace_go_check_types_tset_empty_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tset_empty_QMARK__A{}; t.Ctor(); return t }
//line :323:1
func (t *A_arbace_go_check_types_tset_empty_QMARK__A) Ctor() {}
//line :323:1
func (t *A_arbace_go_check_types_tset_empty_QMARK__A) Invoke_O_O__O(self, ts__0 any) any { var and__1927000168__auto____2 any; var root_849 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_850 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_849, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_851 lang.IFn; if linked_850 == nil { ifn_851 = lang.IFn_Cast(root_849) } else { ifn_851 = nil }; var arg_852 any = A_arbace_go_check_types_A_const_108; var arg_853 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0); if linked_850 == nil { and__1927000168__auto____2 = ifn_851.Invoke_O_O__O(arg_852, arg_853) } else { and__1927000168__auto____2 = linked_850.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_849, arg_852, arg_853) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_854 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_856 lang.IFn; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__0); if linked_855 == nil { return ifn_856.Invoke_O__O(arg_857) } else { return linked_855.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_854, arg_857) } } else { return and__1927000168__auto____2 } }

func A_arbace_go_check_types_method_set_iface_QMARK__A_New() *A_arbace_go_check_types_method_set_iface_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_method_set_iface_QMARK__A{}; t.Ctor(); return t }
//line :325:1
func (t *A_arbace_go_check_types_method_set_iface_QMARK__A) Ctor() {}
//line :325:1
func (t *A_arbace_go_check_types_method_set_iface_QMARK__A) Invoke_O_O__O(self, u__0 any) any {



	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref()
}
func A_arbace_go_check_types_bound_iface_A_New() *A_arbace_go_check_types_bound_iface_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_bound_iface_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_go_check_types_bound_iface_A) Ctor() {}
//line :331:1
func (t *A_arbace_go_check_types_bound_iface_A) Invoke_O_O__O(self, b__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any = b__0; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_858 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_858, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_860 lang.IFn; if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any = A_arbace_go_check_types_A_const_67; var arg_862 any = b__0; if linked_859 == nil { tmp1 = ifn_860.Invoke_O_O__O(arg_861, arg_862) } else { tmp1 = linked_859.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_858, arg_861, arg_862) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var u__2 any; var root_863 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_863, A_arbace_go_check_types_under_A_fn_class); var ifn_865 lang.IFn
		if linked_864 == nil { ifn_865 = lang.IFn_Cast(root_863) } else { ifn_865 = nil }; var arg_866 any = b__0; if linked_864 == nil { u__2 = ifn_865.Invoke_O__O(arg_866) } else { u__2 = linked_864.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_863, arg_866) }
		if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_67, u__2) { return nil } else { var tmp2 any; var and__1927000168__auto____3 any; var root_867 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_869 lang.IFn

			if linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any = u__2; if linked_868 == nil { and__1927000168__auto____3 = ifn_869.Invoke_O__O(arg_870) } else { and__1927000168__auto____3 = linked_868.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_867, arg_870) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_go_check_types_A_const_86; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :337:1
			if jrt.J2g_Truth(tmp2) { return u__2 } else { var tmp4 any; var root_871 any = A_arbace_go_check_types_A_const_143.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_871, A_arbace_go_check_types_union_QMARK__A_fn_class); var ifn_873 lang.IFn


				if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any = u__2; if linked_872 == nil { tmp4 = ifn_873.Invoke_O__O(arg_874) } else { tmp4 = linked_872.(*A_arbace_go_check_types_union_QMARK__A).Invoke_O_O__O(root_871, arg_874) }
//line :337:1
				if jrt.J2g_Truth(tmp4) { var tmp5 any = A_arbace_go_check_types_A_const_86; var tmp6 any = lang.PersistentVector_EMPTY.Ref(); var tmp7 any; var root_875 any = A_arbace_go_check_types_A_const_144.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, A_arbace_go_check_types_make_tset_A_fn_class); var ifn_877 lang.IFn


					if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); var arg_879 any = jrt.Boolean_FALSE.Ref(); if linked_876 == nil { tmp7 = ifn_877.Invoke_O_O__O(arg_878, arg_879) } else { tmp7 = linked_876.(*A_arbace_go_check_types_make_tset_A).Invoke_O_O_O__O(root_875, arg_878, arg_879) }
//line :337:1
					return lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, tmp7) } else { if A_arbace_go_check_types_A_const_75 != nil { var tmp8 any = A_arbace_go_check_types_A_const_86; var tmp9 any = lang.PersistentVector_EMPTY.Ref(); var tmp10 any; var root_880 any = A_arbace_go_check_types_A_const_144.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, A_arbace_go_check_types_make_tset_A_fn_class); var ifn_882 lang.IFn



						if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(jrt.Boolean_FALSE.Ref(), b__0))); var arg_884 any = jrt.Boolean_FALSE.Ref(); if linked_881 == nil { tmp10 = ifn_882.Invoke_O_O__O(arg_883, arg_884) } else { tmp10 = linked_881.(*A_arbace_go_check_types_make_tset_A).Invoke_O_O_O__O(root_880, arg_883, arg_884) }
//line :337:1
						return lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp9, tmp10) } else { return nil } } } } } else {
//line :335:1
							return nil
						}
}





func A_arbace_go_check_types_tparam_iface_A_New() *A_arbace_go_check_types_tparam_iface_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_iface_A{}; t.Ctor(); return t }
//line :343:1
func (t *A_arbace_go_check_types_tparam_iface_A) Ctor() {}
//line :343:1
func (t *A_arbace_go_check_types_tparam_iface_A) Invoke_O_O__O(self, tp__0 any) any { var i__2 any; var root_885 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, A_arbace_go_check_types_info_A_fn_class); var ifn_887 lang.IFn; if


	linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = tp__0; if linked_886 == nil { i__2 = ifn_887.Invoke_O__O(arg_888) } else { i__2 = linked_886.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_885, arg_888) }; var or__1927000174__auto____3 any = /*line :343:1*/A_arbace_go_check_types_A_const_145.Invoke_O__O(i__2); if



	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000408__auto____4 any; var root_889 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, A_arbace_go_check_types_bound_iface_A_fn_class); var ifn_891 lang.IFn
		if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = A_arbace_go_check_types_A_const_147.Invoke_O__O(i__2); if linked_890 == nil { temp__1927000408__auto____4 = ifn_891.Invoke_O__O(arg_892) } else { temp__1927000408__auto____4 = linked_890.(*A_arbace_go_check_types_bound_iface_A).Invoke_O_O__O(root_889, arg_892) }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var r__5 any = temp__1927000408__auto____4
			lang.IFn_Cast(A_arbace_go_check_types_A_const_148.GetRawRoot__O()).Invoke_O_O_O_O__O(tp__0, A_arbace_go_check_types_A_const_59.GetRawRoot__O(), A_arbace_go_check_types_A_const_145, r__5)
//line :348:1
			return r__5 } else { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_86, lang.PersistentVector_EMPTY.Ref(), nil) } } }



func A_arbace_go_check_types_tparam_tset_A_New() *A_arbace_go_check_types_tparam_tset_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_tparam_tset_A{}; t.Ctor(); return t }
//line :352:1
func (t *A_arbace_go_check_types_tparam_tset_A) Ctor() {}
//line :352:1
func (t *A_arbace_go_check_types_tparam_tset_A) Invoke_O_O__O(self, tp__0 any) any { var root_900 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any; var root_904 any = A_arbace_go_check_types_A_const_74.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, A_arbace_go_check_types_tparam_iface_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = tp__0; if linked_905 == nil { arg_903 = ifn_906.Invoke_O__O(arg_907) } else { arg_903 = linked_905.(*A_arbace_go_check_types_tparam_iface_A).Invoke_O_O__O(root_904, arg_907) }; if linked_901 == nil { return ifn_902.Invoke_O__O(arg_903) } else { return linked_901.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_900, arg_903) } }

func A_arbace_go_check_types_typeset_pairs_A_New() *A_arbace_go_check_types_typeset_pairs_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_go_check_types_typeset_pairs_A) Ctor() {}
//line :354:1
func (t *A_arbace_go_check_types_typeset_pairs_A) Invoke_O_O__O(self, t__0 any) any {



	var tmp1 any; var root_908 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = t__0; if linked_909 == nil { tmp1 = ifn_910.Invoke_O__O(arg_911) } else { tmp1 = linked_909.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_908, arg_911) }; if jrt.J2g_Truth(tmp1) { var ts__2 any; var root_912 any = A_arbace_go_check_types_A_const_115.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_912, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_914 lang.IFn
		if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any = t__0; if linked_913 == nil { ts__2 = ifn_914.Invoke_O__O(arg_915) } else { ts__2 = linked_913.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_912, arg_915) }
		var tmp2 any; var root_916 any = A_arbace_go_check_types_A_const_149.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any = ts__2; if linked_917 == nil { tmp2 = ifn_918.Invoke_O__O(arg_919) } else { tmp2 = linked_917.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_916, arg_919) }; if jrt.J2g_Truth(tmp2) { var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_A_New(); var tmp4 *jrt.Class; var fncls__986 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_A_fn_class
			if fncls__986 == nil { var fncls__986d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_A_fn_class = fncls__986d; tmp4 = fncls__986d } else { tmp4 = fncls__986 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); return lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__2)) } else {
//line :360:1
				return A_arbace_go_check_types_A_const_150 } } else {
//line :358:1
					var tmp5 any; var root_987 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_987, A_arbace_go_check_types_under_A_fn_class); var ifn_989 lang.IFn




					if linked_988 == nil { ifn_989 = lang.IFn_Cast(root_987) } else { ifn_989 = nil }; var arg_990 any = t__0; if linked_988 == nil { tmp5 = ifn_989.Invoke_O__O(arg_990) } else { tmp5 = linked_988.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_987, arg_990) }
//line :358:1
					return lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(t__0, tmp5))
				}
}
func A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_A_New() *A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_A{}; t.Ctor(); return t }
//line :361:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_A) Ctor() {}
//line :361:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_A) Invoke_O_O__O(self, s__219000140__1 any) any { var tmp1 any = A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_A_New_O_O(s__219000140__1, self); var tmp2 *jrt.Class; var fncls__985 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_A_fn_class; if fncls__985 == nil { var fncls__985d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_A_fn_class = fncls__985d; tmp2 = fncls__985d } else { tmp2 = fncls__985 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :361:1
func A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_A{}; t.Ctor_O_O(p0, p1); return t }
//line :361:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_A) Ctor_O_O(c__s__219000140, c__iter__219000139 any) { t.F_s__219000140 = c__s__219000140; t.F_iter__219000139 = c__iter__219000139 }
//line :361:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_A) Invoke_O__O(self any) any { { var s__219000140__1 any; var t_ any = t.F_s__219000140; t.F_s__219000140 = nil; s__219000140__1 = t_; for { var temp__1927000414__auto____2 any; var root_920 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = s__219000140__1; if linked_921 == nil { temp__1927000414__auto____2 = ifn_922.Invoke_O__O(arg_923) } else { temp__1927000414__auto____2 = linked_921.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_920, arg_923) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000140__3 any = temp__1927000414__auto____2; var tmp1 any; var root_924 any = A_arbace_go_check_types_A_const_130.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_926 lang.IFn; if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = s__219000140__3; if linked_925 == nil { tmp1 = ifn_926.Invoke_O__O(arg_927) } else { tmp1 = linked_925.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_924, arg_927) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_928 any = A_arbace_go_check_types_A_const_131.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_930 lang.IFn; if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = s__219000140__3; if linked_929 == nil { c__1927001037__auto____4 = ifn_930.Invoke_O__O(arg_931) } else { c__1927001037__auto____4 = linked_929.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_928, arg_931) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000142__6 any; var root_932 any = A_arbace_go_check_types_A_const_132.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_933 == nil { b__219000142__6 = ifn_934.Invoke_O__O(arg_935) } else { b__219000142__6 = linked_933.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_932, arg_935) }; var tmp2 any = A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_fn__219000145_A_New_O_I_O(b__219000142__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__945 *jrt.Class = A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_fn__219000145_A_fn_class; if fncls__945 == nil { var fncls__945d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_fn__219000145_A_fn_class = fncls__945d; tmp3 = fncls__945d } else { tmp3 = fncls__945 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_946 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any; var root_951 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = b__219000142__6; if linked_952 == nil { arg_949 = ifn_953.Invoke_O__O(arg_954) } else { arg_949 = linked_952.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_951, arg_954) }; var arg_950 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000139); var tmp5 any; var root_955 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_955, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = s__219000140__3; if linked_956 == nil { tmp5 = ifn_957.Invoke_O__O(arg_958) } else { tmp5 = linked_956.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_955, arg_958) }; arg_950 = tmp4.Invoke_O__O(tmp5); if linked_947 == nil { return ifn_948.Invoke_O_O__O(arg_949, arg_950) } else { return linked_947.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_946, arg_949, arg_950) } } else { var root_959 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any; var root_964 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_966 lang.IFn; if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any = b__219000142__6; if linked_965 == nil { arg_962 = ifn_966.Invoke_O__O(arg_967) } else { arg_962 = linked_965.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_964, arg_967) }; var arg_963 any; if linked_960 == nil { return ifn_961.Invoke_O_O__O(arg_962, arg_963) } else { return linked_960.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_959, arg_962, arg_963) } } } else { var vec__219000150__4 any; var root_968 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_968, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = s__219000140__3; if linked_969 == nil { vec__219000150__4 = ifn_970.Invoke_O__O(arg_971) } else { vec__219000150__4 = linked_969.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_968, arg_971) }; var tilde__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000150__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000150__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_972 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_974 lang.IFn; if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any; var tmp6 any; if jrt.J2g_Truth(tilde__5) { tmp6 = ty__6 } else { var root_977 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_977, A_arbace_go_check_types_under_A_fn_class); var ifn_979 lang.IFn; if linked_978 == nil { ifn_979 = lang.IFn_Cast(root_977) } else { ifn_979 = nil }; var arg_980 any = ty__6; if linked_978 == nil { tmp6 = ifn_979.Invoke_O__O(arg_980) } else { tmp6 = linked_978.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_977, arg_980) } }; arg_975 = lang.Tuple_Create_O_O__IPersistentVector(ty__6, tmp6); var arg_976 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__219000139); var tmp8 any; var root_981 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_981, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_983 lang.IFn; if linked_982 == nil { ifn_983 = lang.IFn_Cast(root_981) } else { ifn_983 = nil }; var arg_984 any = s__219000140__3; if linked_982 == nil { tmp8 = ifn_983.Invoke_O__O(arg_984) } else { tmp8 = linked_982.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_981, arg_984) }; arg_976 = tmp7.Invoke_O__O(tmp8); if linked_973 == nil { return ifn_974.Invoke_O_O__O(arg_975, arg_976) } else { return linked_973.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_972, arg_975, arg_976) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :361:1
func A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_fn__219000145_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_fn__219000145_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_fn__219000145_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :361:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_fn__219000145_A) Ctor_O_I_O(c__b__219000142 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000142 = c__b__219000142; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :361:1
func (t *A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_fn__219000145_A) Invoke_O__O(self any) any { { var i__219000141__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000141__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__219000146__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000141__1)); var tilde__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000146__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000146__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_936 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = t.F_b__219000142; var arg_940 any; var tmp2 any; if jrt.J2g_Truth(tilde__3) { tmp2 = ty__4 } else { var root_941 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, A_arbace_go_check_types_under_A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = ty__4; if linked_942 == nil { tmp2 = ifn_943.Invoke_O__O(arg_944) } else { tmp2 = linked_942.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_941, arg_944) } }; arg_940 = lang.Tuple_Create_O_O__IPersistentVector(ty__4, tmp2); if linked_937 == nil { ifn_938.Invoke_O_O__O(arg_939, arg_940) } else { linked_937.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_936, arg_939, arg_940) }; i__219000141__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000141__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_go_check_types_typeset_all_A_New() *A_arbace_go_check_types_typeset_all_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_all_A{}; t.Ctor(); return t }
//line :365:1
func (t *A_arbace_go_check_types_typeset_all_A) Ctor() {}
//line :365:1
func (t *A_arbace_go_check_types_typeset_all_A) Invoke_O_O_O__O(self, t__0, f__1 any) any {


	var root_991 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_991, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_993 lang.IFn; if linked_992 == nil { ifn_993 = lang.IFn_Cast(root_991) } else { ifn_993 = nil }; var arg_994 any; var tmp1 any = A_arbace_go_check_types_typeset_all_fn__219000157_A_New_O(f__1); var tmp2 *jrt.Class; var fncls__996 *jrt.Class = A_arbace_go_check_types_typeset_all_fn__219000157_A_fn_class; if fncls__996 == nil { var fncls__996d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_go_check_types_typeset_all_fn__219000157_A_fn_class = fncls__996d; tmp2 = fncls__996d } else { tmp2 = fncls__996 }; arg_994 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_995 any; var root_997 any = A_arbace_go_check_types_A_const_151.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, A_arbace_go_check_types_typeset_pairs_A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any = t__0; if linked_998 == nil { arg_995 = ifn_999.Invoke_O__O(arg_1000) } else { arg_995 = linked_998.(*A_arbace_go_check_types_typeset_pairs_A).Invoke_O_O__O(root_997, arg_1000) }; if linked_992 == nil { return ifn_993.Invoke_O_O__O(arg_994, arg_995) } else { return linked_992.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_991, arg_994, arg_995) } }
//line :368:1
func A_arbace_go_check_types_typeset_all_fn__219000157_A_New_O(p0 any) *A_arbace_go_check_types_typeset_all_fn__219000157_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_typeset_all_fn__219000157_A{}; t.Ctor_O(p0); return t }
//line :368:1
func (t *A_arbace_go_check_types_typeset_all_fn__219000157_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :368:1
func (t *A_arbace_go_check_types_typeset_all_fn__219000157_A) Invoke_O_O__O(self, p__219000156__1 any) any { var vec__219000158__2 any = p__219000156__1; var ty__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000158__2, lang.RT_IntCast_J__I_NoInit(0), nil); var u__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000158__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.IFn_Cast(t.F_f).Invoke_O_O__O(ty__3, u__4) }

func A_arbace_go_check_types_under_is_A_New() *A_arbace_go_check_types_under_is_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_is_A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_go_check_types_under_is_A) Ctor() {}
//line :370:1
func (t *A_arbace_go_check_types_under_is_A) Invoke_O_O_O__O(self, t__0, f__1 any) any {



	var root_1001 any = A_arbace_go_check_types_A_const_152.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1001, A_arbace_go_check_types_typeset_all_A_fn_class); var ifn_1003 lang.IFn; if linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any = t__0; var arg_1005 any; var tmp1 any = A_arbace_go_check_types_under_is_fn__219000163_A_New_O(f__1); var tmp2 *jrt.Class; var fncls__1006 *jrt.Class = A_arbace_go_check_types_under_is_fn__219000163_A_fn_class; if fncls__1006 == nil { var fncls__1006d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_go_check_types_under_is_fn__219000163_A_fn_class = fncls__1006d; tmp2 = fncls__1006d } else { tmp2 = fncls__1006 }; arg_1005 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1002 == nil { return ifn_1003.Invoke_O_O__O(arg_1004, arg_1005) } else { return linked_1002.(*A_arbace_go_check_types_typeset_all_A).Invoke_O_O_O__O(root_1001, arg_1004, arg_1005) } }
//line :374:1
func A_arbace_go_check_types_under_is_fn__219000163_A_New_O(p0 any) *A_arbace_go_check_types_under_is_fn__219000163_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_under_is_fn__219000163_A{}; t.Ctor_O(p0); return t }
//line :374:1
func (t *A_arbace_go_check_types_under_is_fn__219000163_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :374:1
func (t *A_arbace_go_check_types_under_is_fn__219000163_A) Invoke_O_O_O__O(self, ___1, u__2 any) any { return lang.IFn_Cast(t.F_f).Invoke_O__O(u__2) }

func A_arbace_go_check_types_all_basic_A_New() *A_arbace_go_check_types_all_basic_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_basic_A{}; t.Ctor(); return t }
//line :376:1
func (t *A_arbace_go_check_types_all_basic_A) Ctor() {}
//line :376:1
func (t *A_arbace_go_check_types_all_basic_A) Invoke_O_O_O__O(self, t__0, pred__1 any) any {



	var tmp1 any; var root_1007 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any = t__0; if linked_1008 == nil { tmp1 = ifn_1009.Invoke_O__O(arg_1010) } else { tmp1 = linked_1008.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_1007, arg_1010) }; if jrt.J2g_Truth(tmp1) { var ts__3 any; var root_1011 any = A_arbace_go_check_types_A_const_115.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, A_arbace_go_check_types_tparam_tset_A_fn_class); var ifn_1013 lang.IFn
		if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = t__0; if linked_1012 == nil { ts__3 = ifn_1013.Invoke_O__O(arg_1014) } else { ts__3 = linked_1012.(*A_arbace_go_check_types_tparam_tset_A).Invoke_O_O__O(root_1011, arg_1014) }
		var tmp2 any; var and__1927000168__auto____4 any; var root_1015 any = A_arbace_go_check_types_A_const_149.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_1017 lang.IFn; if linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any = ts__3; if linked_1016 == nil { and__1927000168__auto____4 = ifn_1017.Invoke_O__O(arg_1018) } else { and__1927000168__auto____4 = linked_1016.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_1015, arg_1018) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1019 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1021 lang.IFn; if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any; var tmp3 any = A_arbace_go_check_types_all_basic_fn__219000167_A_New_O(pred__1); var tmp4 *jrt.Class; var fncls__1024 *jrt.Class = A_arbace_go_check_types_all_basic_fn__219000167_A_fn_class; if fncls__1024 == nil { var fncls__1024d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_check_types_all_basic_fn__219000167_A_fn_class = fncls__1024d; tmp4 = fncls__1024d } else { tmp4 = fncls__1024 }; arg_1022 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1023 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__3); if linked_1020 == nil { tmp2 = ifn_1021.Invoke_O_O__O(arg_1022, arg_1023) } else { tmp2 = linked_1020.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1019, arg_1022, arg_1023) } } else { tmp2 = and__1927000168__auto____4 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp2)).Ref() } else {
			return lang.IFn_Cast(pred__1).Invoke_O__O(t__0) } }
//line :382:1
func A_arbace_go_check_types_all_basic_fn__219000167_A_New_O(p0 any) *A_arbace_go_check_types_all_basic_fn__219000167_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_basic_fn__219000167_A{}; t.Ctor_O(p0); return t }
//line :382:1
func (t *A_arbace_go_check_types_all_basic_fn__219000167_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :382:1
func (t *A_arbace_go_check_types_all_basic_fn__219000167_A) Invoke_O_O__O(self, p__219000166__1 any) any { var vec__219000168__2 any = p__219000166__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000168__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000168__2, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___3; return lang.IFn_Cast(t.F_pred).Invoke_O__O(ty__4) }


func A_arbace_go_check_types_all_integer_QMARK__A_New() *A_arbace_go_check_types_all_integer_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_integer_QMARK__A{}; t.Ctor(); return t }
//line :385:1
func (t *A_arbace_go_check_types_all_integer_QMARK__A) Ctor() {}
//line :385:1
func (t *A_arbace_go_check_types_all_integer_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1025 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1025, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1027 lang.IFn; if linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any = t__0; var arg_1029 any = A_arbace_go_check_types_A_const_80.GetRawRoot__O(); if linked_1026 == nil { return ifn_1027.Invoke_O_O__O(arg_1028, arg_1029) } else { return linked_1026.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1025, arg_1028, arg_1029) } }
func A_arbace_go_check_types_all_unsigned_QMARK__A_New() *A_arbace_go_check_types_all_unsigned_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_unsigned_QMARK__A{}; t.Ctor(); return t }
//line :386:1
func (t *A_arbace_go_check_types_all_unsigned_QMARK__A) Ctor() {}
//line :386:1
func (t *A_arbace_go_check_types_all_unsigned_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1030 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1030, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1032 lang.IFn; if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any = t__0; var arg_1034 any = A_arbace_go_check_types_A_const_154.GetRawRoot__O(); if linked_1031 == nil { return ifn_1032.Invoke_O_O__O(arg_1033, arg_1034) } else { return linked_1031.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1030, arg_1033, arg_1034) } }
func A_arbace_go_check_types_all_numeric_QMARK__A_New() *A_arbace_go_check_types_all_numeric_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_QMARK__A{}; t.Ctor(); return t }
//line :387:1
func (t *A_arbace_go_check_types_all_numeric_QMARK__A) Ctor() {}
//line :387:1
func (t *A_arbace_go_check_types_all_numeric_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1035 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any = t__0; var arg_1039 any = A_arbace_go_check_types_A_const_155.GetRawRoot__O(); if linked_1036 == nil { return ifn_1037.Invoke_O_O__O(arg_1038, arg_1039) } else { return linked_1036.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1035, arg_1038, arg_1039) } }
func A_arbace_go_check_types_all_string_QMARK__A_New() *A_arbace_go_check_types_all_string_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_string_QMARK__A{}; t.Ctor(); return t }
//line :388:1
func (t *A_arbace_go_check_types_all_string_QMARK__A) Ctor() {}
//line :388:1
func (t *A_arbace_go_check_types_all_string_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1040 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = t__0; var arg_1044 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); if linked_1041 == nil { return ifn_1042.Invoke_O_O__O(arg_1043, arg_1044) } else { return linked_1041.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1040, arg_1043, arg_1044) } }
func A_arbace_go_check_types_all_boolean_QMARK__A_New() *A_arbace_go_check_types_all_boolean_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_boolean_QMARK__A{}; t.Ctor(); return t }
//line :389:1
func (t *A_arbace_go_check_types_all_boolean_QMARK__A) Ctor() {}
//line :389:1
func (t *A_arbace_go_check_types_all_boolean_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1045 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1047 lang.IFn; if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any = t__0; var arg_1049 any = A_arbace_go_check_types_A_const_156.GetRawRoot__O(); if linked_1046 == nil { return ifn_1047.Invoke_O_O__O(arg_1048, arg_1049) } else { return linked_1046.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1045, arg_1048, arg_1049) } }
func A_arbace_go_check_types_all_ordered_QMARK__A_New() *A_arbace_go_check_types_all_ordered_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_ordered_QMARK__A{}; t.Ctor(); return t }
//line :390:1
func (t *A_arbace_go_check_types_all_ordered_QMARK__A) Ctor() {}
//line :390:1
func (t *A_arbace_go_check_types_all_ordered_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1050 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1050, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = t__0; var arg_1054 any = A_arbace_go_check_types_A_const_157.GetRawRoot__O(); if linked_1051 == nil { return ifn_1052.Invoke_O_O__O(arg_1053, arg_1054) } else { return linked_1051.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1050, arg_1053, arg_1054) } }
func A_arbace_go_check_types_all_numeric_or_string_QMARK__A_New() *A_arbace_go_check_types_all_numeric_or_string_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_or_string_QMARK__A{}; t.Ctor(); return t }
//line :391:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__A) Ctor() {}
//line :391:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1055 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1055, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1057 lang.IFn; if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = t__0; var arg_1059 any; var tmp1 any = A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000180_A_New(); var tmp2 *jrt.Class; var fncls__1068 *jrt.Class = A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000180_A_fn_class; if fncls__1068 == nil { var fncls__1068d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000180_A_fn_class = fncls__1068d; tmp2 = fncls__1068d } else { tmp2 = fncls__1068 }; arg_1059 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1056 == nil { return ifn_1057.Invoke_O_O__O(arg_1058, arg_1059) } else { return linked_1056.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1055, arg_1058, arg_1059) } }
//line :391:1
func A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000180_A_New() *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000180_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000180_A{}; t.Ctor(); return t }
//line :391:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000180_A) Ctor() {}
//line :391:1
func (t *A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000180_A) Invoke_O_O__O(self, p1__219000179_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_1060 any = A_arbace_go_check_types_A_const_155.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1060, A_arbace_go_check_types_numeric_QMARK__A_fn_class); var ifn_1062 lang.IFn; if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 any = p1__219000179_SHARP___1; if linked_1061 == nil { or__1927000174__auto____2 = ifn_1062.Invoke_O__O(arg_1063) } else { or__1927000174__auto____2 = linked_1061.(*A_arbace_go_check_types_numeric_QMARK__A).Invoke_O_O__O(root_1060, arg_1063) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_1064 any = A_arbace_go_check_types_A_const_85.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, A_arbace_go_check_types_string_type_QMARK__A_fn_class); var ifn_1066 lang.IFn; if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any = p1__219000179_SHARP___1; if linked_1065 == nil { return ifn_1066.Invoke_O__O(arg_1067) } else { return linked_1065.(*A_arbace_go_check_types_string_type_QMARK__A).Invoke_O_O__O(root_1064, arg_1067) } } }
func A_arbace_go_check_types_all_float_QMARK__A_New() *A_arbace_go_check_types_all_float_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_float_QMARK__A{}; t.Ctor(); return t }
//line :392:1
func (t *A_arbace_go_check_types_all_float_QMARK__A) Ctor() {}
//line :392:1
func (t *A_arbace_go_check_types_all_float_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1069 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1071 lang.IFn; if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = t__0; var arg_1073 any = A_arbace_go_check_types_A_const_81.GetRawRoot__O(); if linked_1070 == nil { return ifn_1071.Invoke_O_O__O(arg_1072, arg_1073) } else { return linked_1070.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1069, arg_1072, arg_1073) } }
func A_arbace_go_check_types_all_complex_QMARK__A_New() *A_arbace_go_check_types_all_complex_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_all_complex_QMARK__A{}; t.Ctor(); return t }
//line :393:1
func (t *A_arbace_go_check_types_all_complex_QMARK__A) Ctor() {}
//line :393:1
func (t *A_arbace_go_check_types_all_complex_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var root_1074 any = A_arbace_go_check_types_A_const_153.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, A_arbace_go_check_types_all_basic_A_fn_class); var ifn_1076 lang.IFn; if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = t__0; var arg_1078 any = A_arbace_go_check_types_A_const_82.GetRawRoot__O(); if linked_1075 == nil { return ifn_1076.Invoke_O_O__O(arg_1077, arg_1078) } else { return linked_1075.(*A_arbace_go_check_types_all_basic_A).Invoke_O_O_O__O(root_1074, arg_1077, arg_1078) } }

func A_arbace_go_check_types_common_under_A_New() *A_arbace_go_check_types_common_under_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_common_under_A{}; t.Ctor(); return t }
//line :395:1
func (t *A_arbace_go_check_types_common_under_A) Ctor() {}
//line :395:1
func (t *A_arbace_go_check_types_common_under_A) Invoke_O_O_O__O(self, t__0, cnd__1 any) any { { var ps__3 any; var root_1079 any = A_arbace_go_check_types_A_const_151.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, A_arbace_go_check_types_typeset_pairs_A_fn_class); var ifn_1081 lang.IFn





	if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any = t__0; if linked_1080 == nil { ps__3 = ifn_1081.Invoke_O__O(arg_1082) } else { ps__3 = linked_1080.(*A_arbace_go_check_types_typeset_pairs_A).Invoke_O_O__O(root_1079, arg_1082) }
//line :395:1
	var ct__4 any; var cu__5 any; L1: for {






		var tmp1 any; var root_1083 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = ps__3; if linked_1084 == nil { tmp1 = ifn_1085.Invoke_O__O(arg_1086) } else { tmp1 = linked_1084.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1083, arg_1086) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(cu__5, nil) } else { var vec__219000185__6 any; var root_1087 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1089 lang.IFn

			if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = ps__3; if linked_1088 == nil { vec__219000185__6 = ifn_1089.Invoke_O__O(arg_1090) } else { vec__219000185__6 = linked_1088.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1087, arg_1090) }
//line :402:1
			var ty__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000185__6, lang.RT_IntCast_J__I_NoInit(0), nil); var u__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000185__6, lang.RT_IntCast_J__I_NoInit(1), nil); var e__9 any


			if jrt.J2g_Truth(cnd__1) { e__9 = lang.IFn_Cast(cnd__1).Invoke_O_O__O(ty__7, u__8) } else { e__9 = nil }
			if jrt.J2g_Truth(e__9) { return lang.Tuple_Create_O_O__IPersistentVector(nil, e__9) } else { if lang.Util_Identical_O_O__Z_NoInit(u__8, nil) { return A_arbace_go_check_types_A_const_158 } else { if lang.Util_Identical_O_O__Z_NoInit(cu__5, nil) {


				var tmp2 any; var root_1114 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1114, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1116 lang.IFn; if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any = ps__3; if linked_1115 == nil { tmp2 = ifn_1116.Invoke_O__O(arg_1117) } else { tmp2 = linked_1115.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1114, arg_1117) }; ps__3, ct__4, cu__5 = tmp2, ty__7, u__8; continue L1 } else {
//line :406:1
					var tmp3 any; var and__1927000168__auto____10 any; var root_1091 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1093 lang.IFn



					if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = cu__5; if linked_1092 == nil { and__1927000168__auto____10 = ifn_1093.Invoke_O__O(arg_1094) } else { and__1927000168__auto____10 = linked_1092.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1091, arg_1094) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp4 any = A_arbace_go_check_types_A_const_98; var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____11 { var and__1927000168__auto____12 any; var root_1095 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1097 lang.IFn; if linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = u__8; if linked_1096 == nil { and__1927000168__auto____12 = ifn_1097.Invoke_O__O(arg_1098) } else { and__1927000168__auto____12 = linked_1096.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1095, arg_1098) }; if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp5 any = A_arbace_go_check_types_A_const_98; tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp5, lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp3 = and__1927000168__auto____12 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else { tmp3 = and__1927000168__auto____10 }
//line :406:1
					if jrt.J2g_Truth(tmp3) {




						var tmp6 any; var root_1099 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1099, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1101 lang.IFn
						if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(2)); var arg_1103 any = lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(2)); if linked_1100 == nil { tmp6 = ifn_1101.Invoke_O_O__O(arg_1102, arg_1103) } else { tmp6 = linked_1100.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1099, arg_1102, arg_1103) }
//line :411:1
						if jrt.J2g_Truth(tmp6) { return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_4, nil, Lit_5, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_go_check_types_A_const_162.GetRawRoot__O()).Invoke_O__O(ct__4), nil, lang.IFn_Cast(A_arbace_go_check_types_A_const_162.GetRawRoot__O()).Invoke_O__O(ty__7), nil)).Ref()) } else { if lang.Util_Equiv_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(1)), lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(1))) {

							var tmp7 any; var root_1126 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1126, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1128 lang.IFn; if linked_1127 == nil { ifn_1128 = lang.IFn_Cast(root_1126) } else { ifn_1128 = nil }; var arg_1129 any = ps__3; if linked_1127 == nil { tmp7 = ifn_1128.Invoke_O__O(arg_1129) } else { tmp7 = linked_1127.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1126, arg_1129) }; ps__3, ct__4, cu__5 = tmp7, ct__4, cu__5; continue L1 } else {
//line :411:1
								var tmp8 any = A_arbace_go_check_types_A_const_159; if lang.Util_Equiv_O_O__Z_NoInit(tmp8, lang.RT_Nth_O_I__O_NoInit(cu__5, lang.RT_IntCast_J__I_NoInit(1))) {


									var tmp9 any; var root_1130 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1130, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1132 lang.IFn; if linked_1131 == nil { ifn_1132 = lang.IFn_Cast(root_1130) } else { ifn_1132 = nil }; var arg_1133 any = ps__3; if linked_1131 == nil { tmp9 = ifn_1132.Invoke_O__O(arg_1133) } else { tmp9 = linked_1131.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1130, arg_1133) }; ps__3, ct__4, cu__5 = tmp9, ty__7, u__8; continue L1 } else {
//line :411:1
										var tmp10 any; var root_1104 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1104, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1106 lang.IFn



										if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = A_arbace_go_check_types_A_const_159; var arg_1108 any = lang.RT_Nth_O_I__O_NoInit(u__8, lang.RT_IntCast_J__I_NoInit(1)); if linked_1105 == nil { tmp10 = ifn_1106.Invoke_O_O__O(arg_1107, arg_1108) } else { tmp10 = linked_1105.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1104, arg_1107, arg_1108) }
//line :411:1
										if jrt.J2g_Truth(tmp10) { return A_arbace_go_check_types_A_const_160 } else { if A_arbace_go_check_types_A_const_75 != nil {




											var tmp11 any; var root_1134 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = ps__3; if linked_1135 == nil { tmp11 = ifn_1136.Invoke_O__O(arg_1137) } else { tmp11 = linked_1135.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1134, arg_1137) }; ps__3, ct__4, cu__5 = tmp11, ct__4, cu__5; continue L1 } else {
//line :411:1
												return nil } } } } } } else {
//line :406:1
													var tmp12 any; var root_1109 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1111 lang.IFn










													if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any = cu__5; var arg_1113 any = u__8; if linked_1110 == nil { tmp12 = ifn_1111.Invoke_O_O__O(arg_1112, arg_1113) } else { tmp12 = linked_1110.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1109, arg_1112, arg_1113) }
//line :406:1
													if jrt.J2g_Truth(tmp12) { return A_arbace_go_check_types_A_const_161 } else { if A_arbace_go_check_types_A_const_75 != nil {











														var tmp13 any; var root_1138 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any = ps__3; if linked_1139 == nil { tmp13 = ifn_1140.Invoke_O__O(arg_1141) } else { tmp13 = linked_1139.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1138, arg_1141) }; ps__3, ct__4, cu__5 = tmp13, ct__4, cu__5; continue L1 } else {
//line :406:1
															return nil } } } } } } } } }; /*line :395:1*/panic("j2g: unreachable") }
//line :395:1
func (t *A_arbace_go_check_types_common_under_A) Invoke_O_O__O(self, t__0 any) any {



	var root_1142 any = A_arbace_go_check_types_A_const_163.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1142, A_arbace_go_check_types_common_under_A_fn_class); var ifn_1144 lang.IFn; if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any = t__0; var arg_1146 any; if linked_1143 == nil { return ifn_1144.Invoke_O_O__O(arg_1145, arg_1146) } else { return linked_1143.(*A_arbace_go_check_types_common_under_A).Invoke_O_O_O__O(root_1142, arg_1145, arg_1146)
	}
}


















func A_arbace_go_check_types_core_type_A_New() *A_arbace_go_check_types_core_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_core_type_A{}; t.Ctor(); return t }
//line :420:1
func (t *A_arbace_go_check_types_core_type_A) Ctor() {}
//line :420:1
func (t *A_arbace_go_check_types_core_type_A) Invoke_O_O__O(self, t__0 any) any {


	var root_1147 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any; var root_1151 any = A_arbace_go_check_types_A_const_163.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, A_arbace_go_check_types_common_under_A_fn_class); var ifn_1153 lang.IFn; if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any = t__0; if linked_1152 == nil { arg_1150 = ifn_1153.Invoke_O__O(arg_1154) } else { arg_1150 = linked_1152.(*A_arbace_go_check_types_common_under_A).Invoke_O_O__O(root_1151, arg_1154) }; if linked_1148 == nil { return ifn_1149.Invoke_O__O(arg_1150) } else { return linked_1148.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1147, arg_1150)
	}
}








func A_arbace_go_check_types_terms_str_A_New() *A_arbace_go_check_types_terms_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_go_check_types_terms_str_A) Ctor() {}
//line :434:1
func (t *A_arbace_go_check_types_terms_str_A) Invoke_O_O__O(self, terms__0 any) any {
	var tmp1 any; var root_1155 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1157 lang.IFn; if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any = terms__0; if linked_1156 == nil { tmp1 = ifn_1157.Invoke_O__O(arg_1158) } else { tmp1 = linked_1156.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1155, arg_1158) }; if jrt.J2g_Truth(tmp1) { return Lit_47 } else { var ts__2 any; var tmp2 *lang.Keyword = A_arbace_go_check_types_A_const_126; var or__1927000174__auto____2 any = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(terms__0))

		if jrt.J2g_Truth(or__1927000174__auto____2) { ts__2 = or__1927000174__auto____2 } else { var root_1159 any = A_arbace_go_check_types_A_const_164.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1159, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1161 lang.IFn; if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = A_arbace_go_check_types_A_const_162.GetRawRoot__O(); var arg_1163 any = terms__0; if linked_1160 == nil { ts__2 = ifn_1161.Invoke_O_O__O(arg_1162, arg_1163) } else { ts__2 = linked_1160.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1159, arg_1162, arg_1163) } }
		var root_1164 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1166 lang.IFn; if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = Lit_48; var arg_1168 any; var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_go_check_types_terms_str_iter__219000190__219000194_A_New(); var tmp4 *jrt.Class; var fncls__1235 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000190__219000194_A_fn_class; if fncls__1235 == nil { var fncls__1235d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_go_check_types_terms_str_iter__219000190__219000194_A_fn_class = fncls__1235d; tmp4 = fncls__1235d } else { tmp4 = fncls__1235 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); arg_1168 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(ts__2); if linked_1165 == nil { return ifn_1166.Invoke_O_O__O(arg_1167, arg_1168) } else { return linked_1165.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1164, arg_1167, arg_1168) } } }
//line :438:1
func A_arbace_go_check_types_terms_str_iter__219000190__219000194_A_New() *A_arbace_go_check_types_terms_str_iter__219000190__219000194_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000190__219000194_A{}; t.Ctor(); return t }
//line :438:1
func (t *A_arbace_go_check_types_terms_str_iter__219000190__219000194_A) Ctor() {}
//line :438:1
func (t *A_arbace_go_check_types_terms_str_iter__219000190__219000194_A) Invoke_O_O__O(self, s__219000191__1 any) any { var tmp1 any = A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_A_New_O_O(self, s__219000191__1); var tmp2 *jrt.Class; var fncls__1234 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_A_fn_class; if fncls__1234 == nil { var fncls__1234d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_A_fn_class = fncls__1234d; tmp2 = fncls__1234d } else { tmp2 = fncls__1234 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :438:1
func A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_A{}; t.Ctor_O_O(p0, p1); return t }
//line :438:1
func (t *A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_A) Ctor_O_O(c__iter__219000190, c__s__219000191 any) { t.F_iter__219000190 = c__iter__219000190; t.F_s__219000191 = c__s__219000191 }
//line :438:1
func (t *A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_A) Invoke_O__O(self any) any { { var s__219000191__1 any; var t_ any = t.F_s__219000191; t.F_s__219000191 = nil; s__219000191__1 = t_; for { var temp__1927000414__auto____2 any; var root_1169 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = s__219000191__1; if linked_1170 == nil { temp__1927000414__auto____2 = ifn_1171.Invoke_O__O(arg_1172) } else { temp__1927000414__auto____2 = linked_1170.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1169, arg_1172) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000191__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1173 any = A_arbace_go_check_types_A_const_130.GetRawRoot__O(); var linked_1174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1173, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1175 lang.IFn; if linked_1174 == nil { ifn_1175 = lang.IFn_Cast(root_1173) } else { ifn_1175 = nil }; var arg_1176 any = s__219000191__3; if linked_1174 == nil { tmp1 = ifn_1175.Invoke_O__O(arg_1176) } else { tmp1 = linked_1174.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1173, arg_1176) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1177 any = A_arbace_go_check_types_A_const_131.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1179 lang.IFn; if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any = s__219000191__3; if linked_1178 == nil { c__1927001037__auto____4 = ifn_1179.Invoke_O__O(arg_1180) } else { c__1927001037__auto____4 = linked_1178.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1177, arg_1180) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000193__6 any; var root_1181 any = A_arbace_go_check_types_A_const_132.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1182 == nil { b__219000193__6 = ifn_1183.Invoke_O__O(arg_1184) } else { b__219000193__6 = linked_1182.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1181, arg_1184) }; var tmp2 any = A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_fn__219000196_A_New_O_I_O(b__219000193__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1194 *jrt.Class = A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_fn__219000196_A_fn_class; if fncls__1194 == nil { var fncls__1194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_fn__219000196_A_fn_class = fncls__1194d; tmp3 = fncls__1194d } else { tmp3 = fncls__1194 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1195 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1197 lang.IFn; if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any; var root_1200 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1202 lang.IFn; if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = b__219000193__6; if linked_1201 == nil { arg_1198 = ifn_1202.Invoke_O__O(arg_1203) } else { arg_1198 = linked_1201.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1200, arg_1203) }; var arg_1199 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000190); var tmp5 any; var root_1204 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any = s__219000191__3; if linked_1205 == nil { tmp5 = ifn_1206.Invoke_O__O(arg_1207) } else { tmp5 = linked_1205.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1204, arg_1207) }; arg_1199 = tmp4.Invoke_O__O(tmp5); if linked_1196 == nil { return ifn_1197.Invoke_O_O__O(arg_1198, arg_1199) } else { return linked_1196.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1195, arg_1198, arg_1199) } } else { var root_1208 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1208, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1210 lang.IFn; if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any; var root_1213 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = b__219000193__6; if linked_1214 == nil { arg_1211 = ifn_1215.Invoke_O__O(arg_1216) } else { arg_1211 = linked_1214.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1213, arg_1216) }; var arg_1212 any; if linked_1209 == nil { return ifn_1210.Invoke_O_O__O(arg_1211, arg_1212) } else { return linked_1209.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1208, arg_1211, arg_1212) } } } else { var vec__219000201__4 any; var root_1217 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = s__219000191__3; if linked_1218 == nil { vec__219000201__4 = ifn_1219.Invoke_O__O(arg_1220) } else { vec__219000201__4 = linked_1218.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1217, arg_1220) }; var tilde__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000201__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000201__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1221 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1221, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1223 lang.IFn; if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 *jrt.String; if jrt.J2g_Truth(tilde__5) { tmp7 = Lit_52 } else { tmp7 = nil }; var tmp8 any = tmp7.Ref(); var tmp9 any; var root_1226 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any = ty__6; if linked_1227 == nil { tmp9 = ifn_1228.Invoke_O__O(arg_1229) } else { tmp9 = linked_1227.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1226, arg_1229) }; arg_1224 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9)).Ref(); var arg_1225 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__219000190); var tmp11 any; var root_1230 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1230, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1232 lang.IFn; if linked_1231 == nil { ifn_1232 = lang.IFn_Cast(root_1230) } else { ifn_1232 = nil }; var arg_1233 any = s__219000191__3; if linked_1231 == nil { tmp11 = ifn_1232.Invoke_O__O(arg_1233) } else { tmp11 = linked_1231.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1230, arg_1233) }; arg_1225 = tmp10.Invoke_O__O(tmp11); if linked_1222 == nil { return ifn_1223.Invoke_O_O__O(arg_1224, arg_1225) } else { return linked_1222.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1221, arg_1224, arg_1225) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :438:1
func A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_fn__219000196_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_fn__219000196_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_fn__219000196_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :438:1
func (t *A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_fn__219000196_A) Ctor_O_I_O(c__b__219000193 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000193 = c__b__219000193; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :438:1
func (t *A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_fn__219000196_A) Invoke_O__O(self any) any { { var i__219000192__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000192__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__219000197__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000192__1)); var tilde__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000197__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000197__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1185 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1187 lang.IFn; if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = t.F_b__219000193; var arg_1189 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 *jrt.String; if jrt.J2g_Truth(tilde__3) { tmp3 = Lit_52 } else { tmp3 = nil }; var tmp4 any = tmp3.Ref(); var tmp5 any; var root_1190 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = ty__4; if linked_1191 == nil { tmp5 = ifn_1192.Invoke_O__O(arg_1193) } else { tmp5 = linked_1191.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1190, arg_1193) }; arg_1189 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5)).Ref(); if linked_1186 == nil { ifn_1187.Invoke_O_O__O(arg_1188, arg_1189) } else { linked_1186.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1185, arg_1188, arg_1189) }; i__219000192__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000192__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_types_params_str_A_New() *A_arbace_go_check_types_params_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_params_str_A{}; t.Ctor(); return t }
//line :440:1
func (t *A_arbace_go_check_types_params_str_A) Ctor() {}
//line :440:1
func (t *A_arbace_go_check_types_params_str_A) Invoke_O_O_O__O(self, ps__0, variadic__1 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil, Lit_26); var tmp2 any; var root_1236 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1238 lang.IFn
	if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = Lit_27; var arg_1240 any; var root_1241 any = A_arbace_go_check_types_A_const_166.GetRawRoot__O(); var linked_1242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1241, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1243 lang.IFn; if linked_1242 == nil { ifn_1243 = lang.IFn_Cast(root_1241) } else { ifn_1243 = nil }; var arg_1244 any; var tmp3 any = A_arbace_go_check_types_params_str_fn__219000207_A_New_O_O(ps__0, variadic__1); var tmp4 *jrt.Class; var fncls__1254 *jrt.Class = A_arbace_go_check_types_params_str_fn__219000207_A_fn_class; if fncls__1254 == nil { var fncls__1254d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_go_check_types_params_str_fn__219000207_A_fn_class = fncls__1254d; tmp4 = fncls__1254d } else { tmp4 = fncls__1254 }; arg_1244 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1245 any = ps__0; if linked_1242 == nil { arg_1240 = ifn_1243.Invoke_O_O__O(arg_1244, arg_1245) } else { arg_1240 = linked_1242.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1241, arg_1244, arg_1245) }; if linked_1237 == nil { tmp2 = ifn_1238.Invoke_O_O__O(arg_1239, arg_1240) } else { tmp2 = linked_1237.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1236, arg_1239, arg_1240) }
//line :441:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil)).Ref() }
func A_arbace_go_check_types_params_str_fn__219000207_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_params_str_fn__219000207_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_params_str_fn__219000207_A{}; t.Ctor_O_O(p0, p1); return t }
//line :442:1
func (t *A_arbace_go_check_types_params_str_fn__219000207_A) Ctor_O_O(c__ps, c__variadic any) { t.F_ps = c__ps; t.F_variadic = c__variadic }
//line :442:1
func (t *A_arbace_go_check_types_params_str_fn__219000207_A) Invoke_O_O_O__O(self, i__1, p__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = t.F_variadic; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_J__Z_NoInit(i__1, lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_ps))))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_29, nil); var tmp3 any; var root_1246 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1246, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var arg_1249 any = lang.RT_Nth_O_I__O_NoInit(p__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1247 == nil { tmp3 = ifn_1248.Invoke_O__O(arg_1249) } else { tmp3 = linked_1247.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1246, arg_1249) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else {
			var root_1250 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1250, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1252 lang.IFn; if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = p__2; if linked_1251 == nil { return ifn_1252.Invoke_O__O(arg_1253) } else { return linked_1251.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1250, arg_1253)
			}
		}
}
func A_arbace_go_check_types_sig_str_A_New() *A_arbace_go_check_types_sig_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sig_str_A{}; t.Ctor(); return t }
//line :449:1
func (t *A_arbace_go_check_types_sig_str_A) Ctor() {}
//line :449:1
func (t *A_arbace_go_check_types_sig_str_A) Invoke_O_O__O(self, p__219000210__0 any) any { var vec__219000211__2 any = p__219000210__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000211__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000211__2, lang.RT_IntCast_J__I_NoInit(1), nil); var rs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000211__2, lang.RT_IntCast_J__I_NoInit(2), nil); var variadic__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000211__2, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_1255 any = A_arbace_go_check_types_A_const_167.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1255, A_arbace_go_check_types_params_str_A_fn_class); var ifn_1257 lang.IFn; _ = ___3; if


	linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any = ps__4; var arg_1259 any = variadic__6; if linked_1256 == nil { tmp2 = ifn_1257.Invoke_O_O__O(arg_1258, arg_1259) } else { tmp2 = linked_1256.(*A_arbace_go_check_types_params_str_A).Invoke_O_O_O__O(root_1255, arg_1258, arg_1259) }; var tmp3 any = tmp2; var tmp4 *jrt.String; var G__219000214__9_ int32 = lang.RT_Count_O__I_NoInit(rs__5); L1:
	switch { default: switch G__219000214__9_ { case 0: tmp4 = Lit_8; break L1; case 1: var r__10 any; var root_1261 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1263 lang.IFn

		if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any = rs__5; if linked_1262 == nil { r__10 = ifn_1263.Invoke_O__O(arg_1264) } else { r__10 = linked_1262.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1261, arg_1264) }; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_9, nil); var tmp6 any; var root_1265 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = r__10; if linked_1266 == nil { tmp6 = ifn_1267.Invoke_O__O(arg_1268) } else { tmp6 = linked_1266.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1265, arg_1268) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6))
//line :453:1
		break L1; default:
	}

		var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_37, nil, Lit_26); var tmp8 any; var root_1269 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = Lit_27; var arg_1273 any; var root_1274 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1275 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1274, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1276 lang.IFn; if linked_1275 == nil { ifn_1276 = lang.IFn_Cast(root_1274) } else { ifn_1276 = nil }; var arg_1277 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var arg_1278 any = rs__5; if linked_1275 == nil { arg_1273 = ifn_1276.Invoke_O_O__O(arg_1277, arg_1278) } else { arg_1273 = linked_1275.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1274, arg_1277, arg_1278) }; if linked_1270 == nil { tmp8 = ifn_1271.Invoke_O_O__O(arg_1272, arg_1273) } else { tmp8 = linked_1270.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1269, arg_1272, arg_1273) }; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil))}; return /*line :452:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4.Ref())).Ref() }





func A_arbace_go_check_types_field_str_A_New() *A_arbace_go_check_types_field_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_field_str_A{}; t.Ctor(); return t }
//line :458:1
func (t *A_arbace_go_check_types_field_str_A) Ctor() {}
//line :458:1
func (t *A_arbace_go_check_types_field_str_A) Invoke_O_O__O(self, f__0 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 *jrt.String; if jrt.J2g_Truth(A_arbace_go_check_types_A_const_168.Invoke_O__O(f__0)) { tmp2 = Lit_8 } else { tmp2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_12.Invoke_O__O(f__0), nil)) }; var tmp3 any = tmp2.Ref(); var tmp4 any; var root_1279 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1279, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1281 lang.IFn; if linked_1280 == nil { ifn_1281 = lang.IFn_Cast(root_1279) } else { ifn_1281 = nil }; var arg_1282 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(f__0); if linked_1280 == nil { tmp4 = ifn_1281.Invoke_O__O(arg_1282) } else { tmp4 = linked_1280.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1279, arg_1282) }; var tmp5 any = tmp4; var tmp6 *jrt.String
	if jrt.J2g_Truth(A_arbace_go_check_types_A_const_106.Invoke_O__O(f__0)) { var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_9, nil); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_162.GetRawRoot__O()); var tmp9 any; var root_1287 any = A_arbace_go_check_types_A_const_169.GetRawRoot__O(); var linked_1288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1287, aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A_fn_class); var ifn_1289 lang.IFn; if linked_1288 == nil { ifn_1289 = lang.IFn_Cast(root_1287) } else { ifn_1289 = nil }; var arg_1290 any = A_arbace_go_check_types_A_const_106.Invoke_O__O(f__0); if linked_1288 == nil { tmp9 = ifn_1289.Invoke_O__O(arg_1290) } else { tmp9 = linked_1288.(*aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A).Invoke_O_O__O(root_1287, arg_1290) }; tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8.Invoke_O__O(tmp9))) } else { tmp6 = nil }
//line :459:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp5, tmp6.Ref())).Ref()
}

func A_arbace_go_check_types_named_str_A_New() *A_arbace_go_check_types_named_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_str_A{}; t.Ctor(); return t }
//line :462:1
func (t *A_arbace_go_check_types_named_str_A) Ctor() {}
//line :462:1
func (t *A_arbace_go_check_types_named_str_A) Invoke_O_O__O(self, t__0 any) any { var i__2 any; var root_1291 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1291, A_arbace_go_check_types_info_A_fn_class); var ifn_1293 lang.IFn; if
										linked_1292 == nil { ifn_1293 = lang.IFn_Cast(root_1291) } else { ifn_1293 = nil }; var arg_1294 any = t__0; if linked_1292 == nil { i__2 = ifn_1293.Invoke_O__O(arg_1294) } else { i__2 = linked_1292.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1291, arg_1294) }; var base__3 any; var tmp1 any; var and__1927000168__auto____3 any = /*line :462:1*/A_arbace_go_check_types_A_const_170.Invoke_O__O(i__2); if

	jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1295 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1295, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1297 lang.IFn; if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any = A_arbace_go_check_types_A_const_170.Invoke_O__O(i__2); var arg_1299 any = A_arbace_go_check_types_A_const_171.Get__O(); if linked_1296 == nil { and__1927000168__auto____4 = ifn_1297.Invoke_O_O__O(arg_1298, arg_1299) } else { and__1927000168__auto____4 = linked_1296.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1295, arg_1298, arg_1299) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1300 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_1301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1300, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1302 lang.IFn; if linked_1301 == nil { ifn_1302 = lang.IFn_Cast(root_1300) } else { ifn_1302 = nil }; var arg_1303 any = A_arbace_go_check_types_A_const_172.Invoke_O__O(i__2); if linked_1301 == nil { tmp1 = ifn_1302.Invoke_O__O(arg_1303) } else { tmp1 = linked_1301.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1300, arg_1303) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		base__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_173.Invoke_O__O(i__2), nil, A_arbace_go_check_types_A_const_12.Invoke_O__O(i__2))).Ref() } else {
			base__3 = A_arbace_go_check_types_A_const_12.Invoke_O__O(i__2) }; var tmp2 any; var root_1304 any =
	A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1304, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1306 lang.IFn; if linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any = A_arbace_go_check_types_A_const_174.Invoke_O__O(i__2); if linked_1305 == nil { tmp2 = ifn_1306.Invoke_O__O(arg_1307) } else { tmp2 = linked_1305.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1304, arg_1307) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_21, nil, Lit_22); var tmp4 any; var root_1308 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1308, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1310 lang.IFn; if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any = Lit_23; var arg_1312 any; var root_1313 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1313, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1315 lang.IFn; if linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var arg_1317 any = A_arbace_go_check_types_A_const_174.Invoke_O__O(i__2); if linked_1314 == nil { arg_1312 = ifn_1315.Invoke_O_O__O(arg_1316, arg_1317) } else { arg_1312 = linked_1314.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1313, arg_1316, arg_1317) }; if linked_1309 == nil { tmp4 = ifn_1310.Invoke_O_O__O(arg_1311, arg_1312) } else { tmp4 = linked_1309.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1308, arg_1311, arg_1312) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, base__3, nil, tmp4, nil)).Ref() } else {
//line :467:1
			return base__3 } }



func A_arbace_go_check_types_type_str_A_New() *A_arbace_go_check_types_type_str_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_A{}; t.Ctor(); return t }
//line :471:1
func (t *A_arbace_go_check_types_type_str_A) Ctor() {}
//line :471:1
func (t *A_arbace_go_check_types_type_str_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_1318 any = A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1318, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_1320 lang.IFn
	if linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any = t__0; if linked_1319 == nil { tmp1 = ifn_1320.Invoke_O__O(arg_1321) } else { tmp1 = linked_1319.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_1318, arg_1321) }
//line :474:1
	if jrt.J2g_Truth(tmp1) {
		var tmp2 any = A_arbace_go_check_types_A_const_175.GetRawRoot__O(); var tmp3 any; var root_1322 any = A_arbace_go_check_types_A_const_176.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1322, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1324 lang.IFn; if linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any = t__0; if linked_1323 == nil { tmp3 = ifn_1324.Invoke_O__O(arg_1325) } else { tmp3 = linked_1323.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1322, arg_1325) }; return lang.RT_Get_O_O_O__O_NoInit(tmp2, t__0, tmp3) } else {
//line :474:1
			var tmp4 any; var root_1326 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1326, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1328 lang.IFn

			if linked_1327 == nil { ifn_1328 = lang.IFn_Cast(root_1326) } else { ifn_1328 = nil }; var arg_1329 any = t__0; if linked_1327 == nil { tmp4 = ifn_1328.Invoke_O__O(arg_1329) } else { tmp4 = linked_1327.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1326, arg_1329) }
//line :474:1
			if jrt.J2g_Truth(tmp4) {

				var root_1330 any = A_arbace_go_check_types_A_const_177.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, A_arbace_go_check_types_named_str_A_fn_class); var ifn_1332 lang.IFn; if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = t__0; if linked_1331 == nil { return ifn_1332.Invoke_O__O(arg_1333) } else { return linked_1331.(*A_arbace_go_check_types_named_str_A).Invoke_O_O__O(root_1330, arg_1333) } } else {
//line :474:1
					var tmp5 any; var root_1334 any = A_arbace_go_check_types_A_const_89.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_1336 lang.IFn


					if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = t__0; if linked_1335 == nil { tmp5 = ifn_1336.Invoke_O__O(arg_1337) } else { tmp5 = linked_1335.(*A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_1334, arg_1337) }
//line :474:1
					if jrt.J2g_Truth(tmp5) {


						var tmp6 *lang.Keyword = A_arbace_go_check_types_A_const_12; var tmp7 any; var root_1338 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, A_arbace_go_check_types_info_A_fn_class); var ifn_1340 lang.IFn; if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = t__0; if linked_1339 == nil { tmp7 = ifn_1340.Invoke_O__O(arg_1341) } else { tmp7 = linked_1339.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1338, arg_1341) }; return tmp6.Invoke_O__O(tmp7) } else {
//line :474:1
							if A_arbace_go_check_types_A_const_75 != nil { var G__219000218__2_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0))




								switch lang.Util_Hash_O__I_NoInit(G__219000218__2_) >> 5 & 31 { case 0: if any(G__219000218__2_) == any(A_arbace_go_check_types_A_const_100) {





















									var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil, Lit_26); var tmp9 any; var root_1343 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1345 lang.IFn; if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = Lit_27; var arg_1347 any; var root_1348 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1348, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var arg_1352 any; var root_1353 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any = t__0; if linked_1354 == nil { arg_1352 = ifn_1355.Invoke_O__O(arg_1356) } else { arg_1352 = linked_1354.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1353, arg_1356) }; if linked_1349 == nil { arg_1347 = ifn_1350.Invoke_O_O__O(arg_1351, arg_1352) } else { arg_1347 = linked_1349.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1348, arg_1351, arg_1352) }; if linked_1344 == nil { tmp9 = ifn_1345.Invoke_O_O__O(arg_1346, arg_1347) } else { tmp9 = linked_1344.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1343, arg_1346, arg_1347) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil)).Ref() }
//line :479:1
								case 1: if any(G__219000218__2_) == any(A_arbace_go_check_types_A_const_86) { var ms__3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var ts__4 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var tmp10 any; var and__1927000168__auto____5 any; var root_1357 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1357, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1359 lang.IFn












									if linked_1358 == nil { ifn_1359 = lang.IFn_Cast(root_1357) } else { ifn_1359 = nil }; var arg_1360 any = ms__3; if linked_1358 == nil { and__1927000168__auto____5 = ifn_1359.Invoke_O__O(arg_1360) } else { and__1927000168__auto____5 = linked_1358.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1357, arg_1360) }; if jrt.J2g_Truth(and__1927000168__auto____5) { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(ts__4, nil)).Ref() } else { tmp10 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp10) { return Lit_56 } else {

										var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_57, nil, Lit_58); var tmp12 any; var root_1361 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1361, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1363 lang.IFn
										if linked_1362 == nil { ifn_1363 = lang.IFn_Cast(root_1361) } else { ifn_1363 = nil }; var arg_1364 any = Lit_59; var arg_1365 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_check_types_A_const_129.GetRawRoot__O()); var tmp14 any; if jrt.J2g_Truth(A_arbace_go_check_types_A_const_110.Invoke_O__O(ts__4)) { tmp14 = A_arbace_go_check_types_A_const_178 } else { tmp14 = nil }; var tmp15 any = tmp14; var tmp16 any; var iter__1927001039__auto____8 any; var tmp17 any = A_arbace_go_check_types_type_str_iter__219000219__219000223_A_New(); var tmp18 *jrt.Class; var fncls__1438 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000219__219000223_A_fn_class
										if fncls__1438 == nil { var fncls__1438d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_go_check_types_type_str_iter__219000219__219000223_A_fn_class = fncls__1438d; tmp18 = fncls__1438d } else { tmp18 = fncls__1438 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); tmp16 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(ms__3)
//line :495:1
										var tmp19 any = tmp16; var tmp20 lang.IPersistentVector; var tmp21 any; var and__1927000168__auto____8 any; var root_1439 any = A_arbace_go_check_types_A_const_142.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1441 lang.IFn

										if linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any = ts__4; if linked_1440 == nil { and__1927000168__auto____8 = ifn_1441.Invoke_O__O(arg_1442) } else { and__1927000168__auto____8 = linked_1440.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1439, arg_1442) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1443 any = A_arbace_go_check_types_A_const_88.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1445 lang.IFn; if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any = A_arbace_go_check_types_A_const_108; var arg_1447 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__4); if linked_1444 == nil { tmp21 = ifn_1445.Invoke_O_O__O(arg_1446, arg_1447) } else { tmp21 = linked_1444.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1443, arg_1446, arg_1447) } } else { tmp21 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp21) { var tmp22 any; var root_1448 any = A_arbace_go_check_types_A_const_180.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_1450 lang.IFn
											if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(ts__4); if linked_1449 == nil { tmp22 = ifn_1450.Invoke_O__O(arg_1451) } else { tmp22 = linked_1449.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_1448, arg_1451) }
//line :497:1
											tmp20 = lang.Tuple_Create_O__IPersistentVector(tmp22) } else { tmp20 = nil }
//line :495:1
										arg_1365 = tmp13.Invoke_O_O_O__O(tmp15, tmp19, tmp20); if linked_1362 == nil { tmp12 = ifn_1363.Invoke_O_O__O(arg_1364, arg_1365) } else { tmp12 = linked_1362.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1361, arg_1364, arg_1365) }
//line :494:1
										return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, nil)).Ref() } }
//line :479:1
								case 3: if any(G__219000218__2_) == any(A_arbace_go_check_types_A_const_87) {
									var tmp23 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil); var tmp24 any; var root_1452 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1454 lang.IFn; if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1453 == nil { tmp24 = ifn_1454.Invoke_O__O(arg_1455) } else { tmp24 = linked_1453.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1452, arg_1455) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp23, jrt.RefArrayOf(jrt.Object_class, nil, tmp24)).Ref() }
//line :479:1
								case 4: if any(G__219000218__2_) == any(A_arbace_go_check_types_A_const_97) {


									var tmp25 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_21, nil, Lit_22, nil); var tmp26 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); var tmp27 any; var root_1456 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1456, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1458 lang.IFn; if linked_1457 == nil { ifn_1458 = lang.IFn_Cast(root_1456) } else { ifn_1458 = nil }; var arg_1459 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_1457 == nil { tmp27 = ifn_1458.Invoke_O__O(arg_1459) } else { tmp27 = linked_1457.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1456, arg_1459) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp25, jrt.RefArrayOf(jrt.Object_class, nil, tmp26, nil, tmp27)).Ref() }
//line :479:1
								case 8: if any(G__219000218__2_) == any(A_arbace_go_check_types_A_const_95) {



									var tmp28 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil, Lit_22, nil); var tmp29 any; var root_1464 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1464, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1466 lang.IFn; if linked_1465 == nil { ifn_1466 = lang.IFn_Cast(root_1464) } else { ifn_1466 = nil }; var arg_1467 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1465 == nil { tmp29 = ifn_1466.Invoke_O__O(arg_1467) } else { tmp29 = linked_1465.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1464, arg_1467) }; var tmp30 any = tmp29; var tmp31 any; var root_1468 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1468, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1470 lang.IFn; if linked_1469 == nil { ifn_1470 = lang.IFn_Cast(root_1468) } else { ifn_1470 = nil }; var arg_1471 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_1469 == nil { tmp31 = ifn_1470.Invoke_O__O(arg_1471) } else { tmp31 = linked_1469.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1468, arg_1471) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp28, jrt.RefArrayOf(jrt.Object_class, nil, tmp30, nil, tmp31)).Ref() }
//line :479:1
								case 14: if any(G__219000218__2_) == any(A_arbace_go_check_types_A_const_96) {

									var tmp32 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_63, nil); var tmp33 any; var root_1472 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1472, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1474 lang.IFn; if linked_1473 == nil { ifn_1474 = lang.IFn_Cast(root_1472) } else { ifn_1474 = nil }; var arg_1475 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1473 == nil { tmp33 = ifn_1474.Invoke_O__O(arg_1475) } else { tmp33 = linked_1473.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1472, arg_1475) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp32, jrt.RefArrayOf(jrt.Object_class, nil, tmp33)).Ref() }
//line :479:1
								case 16: if any(G__219000218__2_) == any(A_arbace_go_check_types_A_const_98) { var e__3 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)); var es__4 any; var root_1476 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_1477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1476, A_arbace_go_check_types_type_str_A_fn_class); var ifn_1478 lang.IFn





									if linked_1477 == nil { ifn_1478 = lang.IFn_Cast(root_1476) } else { ifn_1478 = nil }; var arg_1479 any = e__3; if linked_1477 == nil { es__4 = ifn_1478.Invoke_O__O(arg_1479) } else { es__4 = linked_1477.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_1476, arg_1479) }
//line :479:1
									var es__5 any; var tmp34 any; var tmp35 any = A_arbace_go_check_types_A_const_159; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp35, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)))






									if and__1927000168__auto____5_2 { var and__1927000168__auto____6 any; var root_1480 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any = e__3; if linked_1481 == nil { and__1927000168__auto____6 = ifn_1482.Invoke_O__O(arg_1483) } else { and__1927000168__auto____6 = linked_1481.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1480, arg_1483) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp36 any = A_arbace_go_check_types_A_const_98; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp36, lang.RT_Nth_O_I__O_NoInit(e__3, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____7 { var tmp37 any = A_arbace_go_check_types_A_const_181; tmp34 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp37, lang.RT_Nth_O_I__O_NoInit(e__3, lang.RT_IntCast_J__I_NoInit(1)))).Ref() } else { tmp34 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp34 = and__1927000168__auto____6 } } else { tmp34 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref() }; if jrt.J2g_Truth(tmp34) {
										es__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil, Lit_26), jrt.RefArrayOf(jrt.Object_class, nil, es__4, nil)).Ref() } else {
//line :486:1
											es__5 = es__4 }
//line :479:1
									var G__219000229__6_ any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1))








									switch lang.Util_Hash_O__I_NoInit(G__219000229__6_) >> 7 & 3 { case 0: if any(G__219000229__6_) == any(A_arbace_go_check_types_A_const_181) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_64, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; case 2: if any(G__219000229__6_) == any(A_arbace_go_check_types_A_const_159) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_65, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; case 3: if any(G__219000229__6_) == any(A_arbace_go_check_types_A_const_182) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_66, nil), jrt.RefArrayOf(jrt.Object_class, nil, es__5)).Ref() }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__219000229__6_))))) }
//line :479:1
								case 27: if any(G__219000218__2_) == any(A_arbace_go_check_types_A_const_103) {









									var tmp38 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil); var tmp39 any; var root_1485 any = A_arbace_go_check_types_A_const_179.GetRawRoot__O(); var linked_1486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1485, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1487 lang.IFn; if linked_1486 == nil { ifn_1487 = lang.IFn_Cast(root_1485) } else { ifn_1487 = nil }; var arg_1488 any = t__0; if linked_1486 == nil { tmp39 = ifn_1487.Invoke_O__O(arg_1488) } else { tmp39 = linked_1486.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1485, arg_1488) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp38, jrt.RefArrayOf(jrt.Object_class, nil, tmp39)).Ref() }
//line :479:1
								case 28: if any(G__219000218__2_) == any(A_arbace_go_check_types_A_const_120) {




















									var root_1489 any = A_arbace_go_check_types_A_const_180.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1489, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_1491 lang.IFn; if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1490 == nil { return ifn_1491.Invoke_O__O(arg_1492) } else { return linked_1490.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_1489, arg_1492) } }
//line :479:1
								case 31: if any(G__219000218__2_) == any(A_arbace_go_check_types_A_const_105) {










									var tmp40 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_69, nil, Lit_58); var tmp41 any; var root_1493 any = A_arbace_go_check_types_A_const_165.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1493, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1495 lang.IFn; if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any = Lit_59; var arg_1497 any; var root_1498 any = A_arbace_go_check_types_A_const_13.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1498, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1500 lang.IFn; if linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any = A_arbace_go_check_types_A_const_183.GetRawRoot__O(); var arg_1502 any = lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_1499 == nil { arg_1497 = ifn_1500.Invoke_O_O__O(arg_1501, arg_1502) } else { arg_1497 = linked_1499.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1498, arg_1501, arg_1502) }; if linked_1494 == nil { tmp41 = ifn_1495.Invoke_O_O__O(arg_1496, arg_1497) } else { tmp41 = linked_1494.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1493, arg_1496, arg_1497) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp40, jrt.RefArrayOf(jrt.Object_class, nil, tmp41, nil)).Ref() }
//line :479:1
								default:
								}





















								return lang.IFn_Cast(A_arbace_go_check_types_A_const_162.GetRawRoot__O()).Invoke_O__O(t__0) } else {
//line :474:1
									return nil
								}
						}
				}
		}
}
















func A_arbace_go_check_types_type_str_iter__219000219__219000223_A_New() *A_arbace_go_check_types_type_str_iter__219000219__219000223_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000219__219000223_A{}; t.Ctor(); return t }
//line :496:1
func (t *A_arbace_go_check_types_type_str_iter__219000219__219000223_A) Ctor() {}
//line :496:1
func (t *A_arbace_go_check_types_type_str_iter__219000219__219000223_A) Invoke_O_O__O(self, s__219000220__1 any) any { var tmp1 any = A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_A_New_O_O(s__219000220__1, self); var tmp2 *jrt.Class; var fncls__1437 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_A_fn_class; if fncls__1437 == nil { var fncls__1437d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_A_fn_class = fncls__1437d; tmp2 = fncls__1437d } else { tmp2 = fncls__1437 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :496:1
func A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_A{}; t.Ctor_O_O(p0, p1); return t }
//line :496:1
func (t *A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_A) Ctor_O_O(c__s__219000220, c__iter__219000219 any) { t.F_s__219000220 = c__s__219000220; t.F_iter__219000219 = c__iter__219000219 }
//line :496:1
func (t *A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_A) Invoke_O__O(self any) any { { var s__219000220__1 any; var t_ any = t.F_s__219000220; t.F_s__219000220 = nil; s__219000220__1 = t_; for { var temp__1927000414__auto____2 any; var root_1372 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_1373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1372, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1374 lang.IFn; if linked_1373 == nil { ifn_1374 = lang.IFn_Cast(root_1372) } else { ifn_1374 = nil }; var arg_1375 any = s__219000220__1; if linked_1373 == nil { temp__1927000414__auto____2 = ifn_1374.Invoke_O__O(arg_1375) } else { temp__1927000414__auto____2 = linked_1373.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1372, arg_1375) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__219000220__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1376 any = A_arbace_go_check_types_A_const_130.GetRawRoot__O(); var linked_1377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1376, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1378 lang.IFn; if linked_1377 == nil { ifn_1378 = lang.IFn_Cast(root_1376) } else { ifn_1378 = nil }; var arg_1379 any = s__219000220__3; if linked_1377 == nil { tmp1 = ifn_1378.Invoke_O__O(arg_1379) } else { tmp1 = linked_1377.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1376, arg_1379) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1380 any = A_arbace_go_check_types_A_const_131.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1380, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1382 lang.IFn; if linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any = s__219000220__3; if linked_1381 == nil { c__1927001037__auto____4 = ifn_1382.Invoke_O__O(arg_1383) } else { c__1927001037__auto____4 = linked_1381.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1380, arg_1383) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__219000222__6 any; var root_1384 any = A_arbace_go_check_types_A_const_132.GetRawRoot__O(); var linked_1385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1384, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1386 lang.IFn; if linked_1385 == nil { ifn_1386 = lang.IFn_Cast(root_1384) } else { ifn_1386 = nil }; var arg_1387 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1385 == nil { b__219000222__6 = ifn_1386.Invoke_O__O(arg_1387) } else { b__219000222__6 = linked_1385.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1384, arg_1387) }; var tmp2 any = A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_fn__219000225_A_New_O_I_O(b__219000222__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1397 *jrt.Class = A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_fn__219000225_A_fn_class; if fncls__1397 == nil { var fncls__1397d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_fn__219000225_A_fn_class = fncls__1397d; tmp3 = fncls__1397d } else { tmp3 = fncls__1397 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1398 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any; var root_1403 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = b__219000222__6; if linked_1404 == nil { arg_1401 = ifn_1405.Invoke_O__O(arg_1406) } else { arg_1401 = linked_1404.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1403, arg_1406) }; var arg_1402 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__219000219); var tmp5 any; var root_1407 any = A_arbace_go_check_types_A_const_137.GetRawRoot__O(); var linked_1408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1407, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1409 lang.IFn; if linked_1408 == nil { ifn_1409 = lang.IFn_Cast(root_1407) } else { ifn_1409 = nil }; var arg_1410 any = s__219000220__3; if linked_1408 == nil { tmp5 = ifn_1409.Invoke_O__O(arg_1410) } else { tmp5 = linked_1408.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1407, arg_1410) }; arg_1402 = tmp4.Invoke_O__O(tmp5); if linked_1399 == nil { return ifn_1400.Invoke_O_O__O(arg_1401, arg_1402) } else { return linked_1399.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1398, arg_1401, arg_1402) } } else { var root_1411 any = A_arbace_go_check_types_A_const_135.GetRawRoot__O(); var linked_1412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1411, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1413 lang.IFn; if linked_1412 == nil { ifn_1413 = lang.IFn_Cast(root_1411) } else { ifn_1413 = nil }; var arg_1414 any; var root_1416 any = A_arbace_go_check_types_A_const_136.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = b__219000222__6; if linked_1417 == nil { arg_1414 = ifn_1418.Invoke_O__O(arg_1419) } else { arg_1414 = linked_1417.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1416, arg_1419) }; var arg_1415 any; if linked_1412 == nil { return ifn_1413.Invoke_O_O__O(arg_1414, arg_1415) } else { return linked_1412.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1411, arg_1414, arg_1415) } } } else { var m__4 any; var root_1420 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1420, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any = s__219000220__3; if linked_1421 == nil { m__4 = ifn_1422.Invoke_O__O(arg_1423) } else { m__4 = linked_1421.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1420, arg_1423) }; var root_1424 any = A_arbace_go_check_types_A_const_138.GetRawRoot__O(); var linked_1425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1424, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1426 lang.IFn; if linked_1425 == nil { ifn_1426 = lang.IFn_Cast(root_1424) } else { ifn_1426 = nil }; var arg_1427 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__4); var tmp8 any; var root_1429 any = A_arbace_go_check_types_A_const_179.GetRawRoot__O(); var linked_1430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1429, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1431 lang.IFn; if linked_1430 == nil { ifn_1431 = lang.IFn_Cast(root_1429) } else { ifn_1431 = nil }; var arg_1432 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(m__4); if linked_1430 == nil { tmp8 = ifn_1431.Invoke_O__O(arg_1432) } else { tmp8 = linked_1430.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1429, arg_1432) }; arg_1427 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8)).Ref(); var arg_1428 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__219000219); var tmp10 any; var root_1433 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = s__219000220__3; if linked_1434 == nil { tmp10 = ifn_1435.Invoke_O__O(arg_1436) } else { tmp10 = linked_1434.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1433, arg_1436) }; arg_1428 = tmp9.Invoke_O__O(tmp10); if linked_1425 == nil { return ifn_1426.Invoke_O_O__O(arg_1427, arg_1428) } else { return linked_1425.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1424, arg_1427, arg_1428) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :496:1
func A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_fn__219000225_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_fn__219000225_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_fn__219000225_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :496:1
func (t *A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_fn__219000225_A) Ctor_O_I_O(c__b__219000222 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__219000222 = c__b__219000222; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :496:1
func (t *A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_fn__219000225_A) Invoke_O__O(self any) any { { var i__219000221__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__219000221__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__219000221__1)); var root_1388 any = A_arbace_go_check_types_A_const_134.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1390 lang.IFn; if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = t.F_b__219000222; var arg_1392 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__2); var tmp4 any; var root_1393 any = A_arbace_go_check_types_A_const_179.GetRawRoot__O(); var linked_1394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1393, A_arbace_go_check_types_sig_str_A_fn_class); var ifn_1395 lang.IFn; if linked_1394 == nil { ifn_1395 = lang.IFn_Cast(root_1393) } else { ifn_1395 = nil }; var arg_1396 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(m__2); if linked_1394 == nil { tmp4 = ifn_1395.Invoke_O__O(arg_1396) } else { tmp4 = linked_1394.(*A_arbace_go_check_types_sig_str_A).Invoke_O_O__O(root_1393, arg_1396) }; arg_1392 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref(); if linked_1389 == nil { ifn_1390.Invoke_O_O__O(arg_1391, arg_1392) } else { linked_1389.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1388, arg_1391, arg_1392) }; i__219000221__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__219000221__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }














func A_arbace_go_check_types_align_up_A_New() *A_arbace_go_check_types_align_up_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_align_up_A{}; t.Ctor(); return t }
//line :511:1
func (t *A_arbace_go_check_types_align_up_A) Ctor() {}
//line :511:1
func (t *A_arbace_go_check_types_align_up_A) InvokePrim_O_J_J__J(self any, x__0, a__1 int64) int64 { return lang.Numbers_Multiply_J_J__J_NoInit(a__1, lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(x__0, lang.Numbers_Dec_J__J_NoInit(a__1)), a__1)) }
//line :511:1
func (t *A_arbace_go_check_types_align_up_A) Invoke_O_O_O__O(self, p_x__0, p_a__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_J__J(self, lang.RT_LongCast_O__J_NoInit(p_x__0), lang.RT_LongCast_O__J_NoInit(p_a__1))).Ref() }

func A_arbace_go_check_types_sync_atomic_align64_QMARK__A_New() *A_arbace_go_check_types_sync_atomic_align64_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sync_atomic_align64_QMARK__A{}; t.Ctor(); return t }
//line :513:1
func (t *A_arbace_go_check_types_sync_atomic_align64_QMARK__A) Ctor() {}
//line :513:1
func (t *A_arbace_go_check_types_sync_atomic_align64_QMARK__A) Invoke_O_O__O(self, t__0 any) any { var and__1927000168__auto____2 any; var root_1503 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1503, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1505 lang.IFn; if



	linked_1504 == nil { ifn_1505 = lang.IFn_Cast(root_1503) } else { ifn_1505 = nil }; var arg_1506 any = t__0; if linked_1504 == nil { and__1927000168__auto____2 = ifn_1505.Invoke_O__O(arg_1506) } else { and__1927000168__auto____2 = linked_1504.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1503, arg_1506) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var i__3 any; var root_1507 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1507, A_arbace_go_check_types_info_A_fn_class); var ifn_1509 lang.IFn
		if linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any = t__0; if linked_1508 == nil { i__3 = ifn_1509.Invoke_O__O(arg_1510) } else { i__3 = linked_1508.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1507, arg_1510) }
//line :517:1
		var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_39, A_arbace_go_check_types_A_const_12.Invoke_O__O(i__3))

		if and__1927000168__auto____4 {
			var root_1511 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1511, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1513 lang.IFn; if linked_1512 == nil { ifn_1513 = lang.IFn_Cast(root_1511) } else { ifn_1513 = nil }; var arg_1514 any = A_arbace_go_check_types_A_const_184; var arg_1515 any = A_arbace_go_check_types_A_const_170.Invoke_O__O(i__3); if linked_1512 == nil { return ifn_1513.Invoke_O_O__O(arg_1514, arg_1515) } else { return linked_1512.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1511, arg_1514, arg_1515) } } else {
//line :519:1
				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else {
//line :517:1
					return and__1927000168__auto____2 } }




func A_arbace_go_check_types_alignof_A_New() *A_arbace_go_check_types_alignof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alignof_A{}; t.Ctor(); return t }
//line :522:1
func (t *A_arbace_go_check_types_alignof_A) Ctor() {}
//line :522:1
func (t *A_arbace_go_check_types_alignof_A) InvokePrim_O_O__J(self, t__0 any) int64 { var tmp1 any; var u__2 any; var root_1516 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1516, A_arbace_go_check_types_under_A_fn_class); var ifn_1518 lang.IFn; if
											linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any = t__0; if linked_1517 == nil { u__2 = ifn_1518.Invoke_O__O(arg_1519) } else { u__2 = linked_1517.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1516, arg_1519) }; var tmp2 any; var and__1927000168__auto____3 any; var root_1520 any =
											A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1520, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1522 lang.IFn; if
											linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any = u__2; if linked_1521 == nil { and__1927000168__auto____3 = ifn_1522.Invoke_O__O(arg_1523) } else { and__1927000168__auto____3 = linked_1521.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1520, arg_1523) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_go_check_types_A_const_97; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp2 = and__1927000168__auto____3 }; if /*line :524:1*/ jrt.J2g_Truth(tmp2) {
												var root_1524 any = A_arbace_go_check_types_A_const_185.GetRawRoot__O(); var linked_1525 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1524, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1526 lang.IFn; if linked_1525 == nil { ifn_1526 = lang.IFn_Cast(root_1524) } else { ifn_1526 = nil }; var arg_1527 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)); if linked_1525 == nil { tmp1 = ifn_1526.Invoke_O__O(arg_1527) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_1525.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1524, arg_1527)).Ref() } } else {
//line :524:1
			var tmp4 any; var and__1927000168__auto____3_2 any; var root_1528 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1528, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1530 lang.IFn

			if linked_1529 == nil { ifn_1530 = lang.IFn_Cast(root_1528) } else { ifn_1530 = nil }; var arg_1531 any = u__2; if linked_1529 == nil { and__1927000168__auto____3_2 = ifn_1530.Invoke_O__O(arg_1531) } else { and__1927000168__auto____3_2 = linked_1529.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1528, arg_1531) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) { var tmp5 any = A_arbace_go_check_types_A_const_105; tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp5, lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp4 = and__1927000168__auto____3_2 }
//line :524:1
			if jrt.J2g_Truth(tmp4) {


				var tmp6 any; var and__1927000168__auto____3_3 any; var root_1532 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1533 == nil { and__1927000168__auto____3_3 = ifn_1534.Invoke_O__O(arg_1535) } else { and__1927000168__auto____3_3 = linked_1533.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1532, arg_1535) }; if jrt.J2g_Truth(and__1927000168__auto____3_3) { var root_1536 any = A_arbace_go_check_types_A_const_186.GetRawRoot__O(); var linked_1537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1536, A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class); var ifn_1538 lang.IFn; if linked_1537 == nil { ifn_1538 = lang.IFn_Cast(root_1536) } else { ifn_1538 = nil }; var arg_1539 any = t__0; if linked_1537 == nil { tmp6 = ifn_1538.Invoke_O__O(arg_1539) } else { tmp6 = linked_1537.(*A_arbace_go_check_types_sync_atomic_align64_QMARK__A).Invoke_O_O__O(root_1536, arg_1539) } } else { tmp6 = and__1927000168__auto____3_3 }; if jrt.J2g_Truth(tmp6) { tmp1 = A_arbace_go_check_types_A_const_24 } else {

					var root_1540 any = A_arbace_go_check_types_A_const_187.GetRawRoot__O(); var linked_1541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1540, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1542 lang.IFn; if linked_1541 == nil { ifn_1542 = lang.IFn_Cast(root_1540) } else { ifn_1542 = nil }; var arg_1543 any; var tmp7 any = A_arbace_go_check_types_alignof_fn__219000233_A_New(); var tmp8 *jrt.Class; var fncls__1550 *jrt.Class = A_arbace_go_check_types_alignof_fn__219000233_A_fn_class; if fncls__1550 == nil { var fncls__1550d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_go_check_types_alignof_fn__219000233_A_fn_class = fncls__1550d; tmp8 = fncls__1550d } else { tmp8 = fncls__1550 }; arg_1543 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_1544 any = A_arbace_go_check_types_A_const_15; var arg_1545 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_1541 == nil { tmp1 = ifn_1542.Invoke_O_O_O__O(arg_1543, arg_1544, arg_1545) } else { tmp1 = linked_1541.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1540, arg_1543, arg_1544, arg_1545) } } } else {
//line :524:1
						var tmp9 any; var and__1927000168__auto____3_4 any; var root_1551 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1551, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1553 lang.IFn





						if linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any = u__2; if linked_1552 == nil { and__1927000168__auto____3_4 = ifn_1553.Invoke_O__O(arg_1554) } else { and__1927000168__auto____3_4 = linked_1552.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1551, arg_1554) }; if jrt.J2g_Truth(and__1927000168__auto____3_4) { var root_1555 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1555, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1557 lang.IFn; if linked_1556 == nil { ifn_1557 = lang.IFn_Cast(root_1555) } else { ifn_1557 = nil }; var arg_1558 any = A_arbace_go_check_types_A_const_188; var arg_1559 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0)); if linked_1556 == nil { tmp9 = ifn_1557.Invoke_O_O__O(arg_1558, arg_1559) } else { tmp9 = linked_1556.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1555, arg_1558, arg_1559) } } else { tmp9 = and__1927000168__auto____3_4 }
//line :524:1
						if jrt.J2g_Truth(tmp9) { tmp1 = A_arbace_go_check_types_A_const_189.GetRawRoot__O() } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_40, u__2) { tmp1 = A_arbace_go_check_types_A_const_189.GetRawRoot__O() } else { if A_arbace_go_check_types_A_const_75 != nil { var a__3 any; var root_1560 any = A_arbace_go_check_types_A_const_190.GetRawRoot__O(); var linked_1561 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1560, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1562 lang.IFn








							if linked_1561 == nil { ifn_1562 = lang.IFn_Cast(root_1560) } else { ifn_1562 = nil }; var arg_1563 any = t__0; if linked_1561 == nil { a__3 = ifn_1562.Invoke_O__O(arg_1563) } else { a__3 = jrt.Long_ValueOf_J__Long_NoInit(linked_1561.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1560, arg_1563)).Ref() }
//line :524:1
							var a__4 any; var tmp10 bool
							var na_1564 any = a__3
							var na_1565 int64 = 1







							if jrt.Long_InstanceOf(na_1564) { var n0_1566 int64 = jrt.NN(jrt.Long_Cast(na_1564)).LongValue__J(); var n1_1567 int64 = na_1565; tmp10 = n0_1566 < n1_1567 } else { tmp10 = lang.Numbers_Lt_O_J__Z_NoInit(na_1564, na_1565) }; if tmp10 { a__4 = A_arbace_go_check_types_A_const_15 } else { a__4 = a__3 }
//line :524:1
							var a__5 any; var tmp11 any; var root_1569 any = A_arbace_go_check_types_A_const_82.GetRawRoot__O(); var linked_1570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1569, A_arbace_go_check_types_complex_type_QMARK__A_fn_class); var ifn_1571 lang.IFn










							if linked_1570 == nil { ifn_1571 = lang.IFn_Cast(root_1569) } else { ifn_1571 = nil }; var arg_1572 any = t__0; if linked_1570 == nil { tmp11 = ifn_1571.Invoke_O__O(arg_1572) } else { tmp11 = linked_1570.(*A_arbace_go_check_types_complex_type_QMARK__A).Invoke_O_O__O(root_1569, arg_1572) }; if jrt.J2g_Truth(tmp11) { var na_1573 any = a__4; var na_1574 int64 = 2; if jrt.Long_InstanceOf(na_1573) { var n0_1575 int64 = jrt.NN(jrt.Long_Cast(na_1573)).LongValue__J(); var n1_1576 int64 = na_1574; if n1_1576 == 0 { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1573, na_1574) } else { a__5 = jrt.Long_ValueOf_J__Long_NoInit(n0_1575 / n1_1576).Ref() } } else { a__5 = lang.Numbers_Quotient_O_J__Number_NoInit(na_1573, na_1574) } } else { a__5 = a__4 }
							tmp1 = lang.Numbers_Min_O_O__O_NoInit(a__5, A_arbace_go_check_types_A_const_191.GetRawRoot__O()) } else {
//line :524:1
								tmp1 = nil } } } } }; return /*line :522:1*/ jrt.Number_Cast(tmp1).LongValue__J() }
//line :522:1
func (t *A_arbace_go_check_types_alignof_A) Invoke_O_O__O(self, t__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, t__0)).Ref() }






func A_arbace_go_check_types_alignof_fn__219000233_A_New() *A_arbace_go_check_types_alignof_fn__219000233_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_alignof_fn__219000233_A{}; t.Ctor(); return t }
//line :529:1
func (t *A_arbace_go_check_types_alignof_fn__219000233_A) Ctor() {}
//line :529:1
func (t *A_arbace_go_check_types_alignof_fn__219000233_A) Invoke_O_O_O__O(self, m__1, f__2 any) any { var tmp1 int64; var root_1546 any = A_arbace_go_check_types_A_const_185.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1546, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1548 lang.IFn; if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(f__2); if linked_1547 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_1548.Invoke_O__O(arg_1549)) } else { tmp1 = linked_1547.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1546, arg_1549) }; return lang.Numbers_Max_O_J__O_NoInit(m__1, tmp1) }








func A_arbace_go_check_types_offsetsof_A_New() *A_arbace_go_check_types_offsetsof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_offsetsof_A{}; t.Ctor(); return t }
//line :538:1
func (t *A_arbace_go_check_types_offsetsof_A) Ctor() {}
//line :538:1
func (t *A_arbace_go_check_types_offsetsof_A) Invoke_O_O__O(self, fields__0 any) any { { var fs__2 any = fields__0; var offs__3 any = lang.RT_Box_J__Number_NoInit(0); var acc__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for {

	var tmp1 any; var root_1578 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1578, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1580 lang.IFn; if linked_1579 == nil { ifn_1580 = lang.IFn_Cast(root_1578) } else { ifn_1580 = nil }; var arg_1581 any = fs__2; if linked_1579 == nil { tmp1 = ifn_1580.Invoke_O__O(arg_1581) } else { tmp1 = linked_1579.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1578, arg_1581) }; if jrt.J2g_Truth(tmp1) { return acc__4 } else { var f__5 any; var root_1582 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1584 lang.IFn

		if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = fs__2; if linked_1583 == nil { f__5 = ifn_1584.Invoke_O__O(arg_1585) } else { f__5 = linked_1583.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1582, arg_1585) }
//line :540:1
		var o__6 any; var root_1586 any = A_arbace_go_check_types_A_const_192.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1586, A_arbace_go_check_types_align_up_A_fn_class); var ifn_1588 lang.IFn


		if linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; var arg_1589 any = offs__3; var arg_1590 any; var root_1591 any = A_arbace_go_check_types_A_const_185.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1591, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(f__5); if linked_1592 == nil { arg_1590 = ifn_1593.Invoke_O__O(arg_1594) } else { arg_1590 = jrt.Long_ValueOf_J__Long_NoInit(linked_1592.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1591, arg_1594)).Ref() }; if linked_1587 == nil { o__6 = ifn_1588.Invoke_O_O__O(arg_1589, arg_1590) } else { o__6 = jrt.Long_ValueOf_J__Long_NoInit(linked_1587.(*A_arbace_go_check_types_align_up_A).InvokePrim_O_J_J__J(root_1586, lang.RT_LongCast_O__J_NoInit(arg_1589), lang.RT_LongCast_O__J_NoInit(arg_1590))).Ref() }
		var tmp2 any; var root_1595 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1597 lang.IFn; if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any = fs__2; if linked_1596 == nil { tmp2 = ifn_1597.Invoke_O__O(arg_1598) } else { tmp2 = linked_1596.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1595, arg_1598) }; var tmp3 any = tmp2; var tmp4 jrt.Number_I; var na_1599 any = o__6; var na_1600 any; var root_1601 any = A_arbace_go_check_types_A_const_190.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1601, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(f__5); if linked_1602 == nil { na_1600 = ifn_1603.Invoke_O__O(arg_1604) } else { na_1600 = jrt.Long_ValueOf_J__Long_NoInit(linked_1602.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1601, arg_1604)).Ref() }; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_1599); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_1600) }; tmp5 = tmp6; if tmp5 { var n0_1605 int64 = jrt.NN(jrt.Long_Cast(na_1599)).LongValue__J(); var n1_1606 int64 = jrt.NN(jrt.Long_Cast(na_1600)).LongValue__J(); var nr_1607 int64 = n0_1605 + n1_1606; if (n0_1605^nr_1607)&(n1_1606^nr_1607) >= 0 { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1607)) } else { tmp4 = lang.Numbers_Add_O_O__Number_NoInit(na_1599, na_1600) } } else { var tmp7 bool; var tmp8 bool; tmp8 = jrt.Double_InstanceOf(na_1599); if tmp8 { tmp8 = jrt.Double_InstanceOf(na_1600) }; tmp7 = tmp8; if tmp7 { var n0_1605_2 float64 = jrt.NN(jrt.Double_Cast(na_1599)).DoubleValue__D(); var n1_1606_2 float64 = jrt.NN(jrt.Double_Cast(na_1600)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1605_2 + n1_1606_2)) } else { tmp4 = lang.Numbers_Add_O_O__Number_NoInit(na_1599, na_1600) } }; var tmp9 any = tmp4; var tmp10 any; var root_1608 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = acc__4; var arg_1612 any = o__6; if linked_1609 == nil { tmp10 = ifn_1610.Invoke_O_O__O(arg_1611, arg_1612) } else { tmp10 = linked_1609.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1608, arg_1611, arg_1612) }; fs__2, offs__3, acc__4 = tmp3, tmp9, tmp10; continue L1 } } }; /*line :538:1*/panic("j2g: unreachable") }







func A_arbace_go_check_types_sizeof_A_New() *A_arbace_go_check_types_sizeof_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sizeof_A{}; t.Ctor(); return t }
//line :546:1
func (t *A_arbace_go_check_types_sizeof_A) Ctor() {}
//line :546:1
func (t *A_arbace_go_check_types_sizeof_A) InvokePrim_O_O__J(self, t__0 any) int64 { var tmp1 any; var u__2 any; var root_1613 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1613, A_arbace_go_check_types_under_A_fn_class); var ifn_1615 lang.IFn; if
											linked_1614 == nil { ifn_1615 = lang.IFn_Cast(root_1613) } else { ifn_1615 = nil }; var arg_1616 any = t__0; if linked_1614 == nil { u__2 = ifn_1615.Invoke_O__O(arg_1616) } else { u__2 = linked_1614.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1613, arg_1616) }; var tmp2 any; var root_1617 any =
											A_arbace_go_check_types_A_const_72.GetRawRoot__O(); var linked_1618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1617, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_1619 lang.IFn; if
											linked_1618 == nil { ifn_1619 = lang.IFn_Cast(root_1617) } else { ifn_1619 = nil }; var arg_1620 any = u__2; if linked_1618 == nil { tmp2 = ifn_1619.Invoke_O__O(arg_1620) } else { tmp2 = linked_1618.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_1617, arg_1620) }; if /*line :548:1*/ jrt.J2g_Truth(tmp2) { var G__219000237__3_ any = u__2
											L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__219000237__3_) { case 717828005: if any(G__219000237__3_) == any(A_arbace_go_check_types_A_const_40) { var na_1622 int64 = 2; var na_1623 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1623) { var n0_1624 int64 = na_1622; var n1_1625 int64 = jrt.NN(jrt.Long_Cast(na_1623)).LongValue__J(); var nr_1626 int64 = n0_1624 * n1_1625; var tmp3 bool; var tmp4 bool; var tmp5 bool; var tmp6 bool; tmp6 = n0_1624 == -9223372036854775808; if tmp6 { tmp6 = n1_1625 < 0 }; tmp5 = tmp6; tmp4 = !tmp5; if tmp4 { var tmp7 bool; tmp7 = n1_1625 == 0; if !tmp7 { tmp7 = nr_1626/n1_1625 == n0_1624 }; tmp4 = tmp7 }; tmp3 = tmp4; if tmp3 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1626).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1622, na_1623) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1622, na_1623) }; break L1 }; default:}; var tmp8 lang.IFn = A_arbace_go_check_types_A_const_11; tmp1 = tmp8.Invoke_O_O__O(lang.IFn_Cast(A_arbace_go_check_types_A_const_78.GetRawRoot__O()).Invoke_O__O(u__2), A_arbace_go_check_types_A_const_189.GetRawRoot__O())} } else {
//line :548:1
		if A_arbace_go_check_types_A_const_75 != nil { var G__219000238__3_ any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(0))


		L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__219000238__3_) >> 5 & 3 { case 0: if any(G__219000238__3_) == any(A_arbace_go_check_types_A_const_97) { var n__4 int64 = lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)))

			if lang.Numbers_Lte_J_J__Z_NoInit(n__4, 0) { tmp1 = A_arbace_go_check_types_A_const_44 } else { var tmp9 int64; var root_1628 any = A_arbace_go_check_types_A_const_190.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1628, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1630 lang.IFn; if linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(2)); if linked_1629 == nil { tmp9 = lang.RT_LongCast_O__J_NoInit(ifn_1630.Invoke_O__O(arg_1631)) } else { tmp9 = linked_1629.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1628, arg_1631) }; tmp1 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(n__4, tmp9)).Ref() }
//line :551:1
			break L2 }; case 1: if any(G__219000238__3_) == any(A_arbace_go_check_types_A_const_86) {











				var na_1632 int64 = 2; var na_1633 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1633) { var n0_1634 int64 = na_1632; var n1_1635 int64 = jrt.NN(jrt.Long_Cast(na_1633)).LongValue__J(); var nr_1636 int64 = n0_1634 * n1_1635; var tmp10 bool; var tmp11 bool; var tmp12 bool; var tmp13 bool; tmp13 = n0_1634 == -9223372036854775808; if tmp13 { tmp13 = n1_1635 < 0 }; tmp12 = tmp13; tmp11 = !tmp12; if tmp11 { var tmp14 bool; tmp14 = n1_1635 == 0; if !tmp14 { tmp14 = nr_1636/n1_1635 == n0_1634 }; tmp11 = tmp14 }; tmp10 = tmp11; if tmp10 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1636).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1632, na_1633) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1632, na_1633) }
//line :551:1
				break L2 }; case 2: if any(G__219000238__3_) == any(A_arbace_go_check_types_A_const_96) {


					var na_1637 int64 = 3; var na_1638 any = A_arbace_go_check_types_A_const_189.GetRawRoot__O(); if jrt.Long_InstanceOf(na_1638) { var n0_1639 int64 = na_1637; var n1_1640 int64 = jrt.NN(jrt.Long_Cast(na_1638)).LongValue__J(); var nr_1641 int64 = n0_1639 * n1_1640; var tmp15 bool; var tmp16 bool; var tmp17 bool; var tmp18 bool; tmp18 = n0_1639 == -9223372036854775808; if tmp18 { tmp18 = n1_1640 < 0 }; tmp17 = tmp18; tmp16 = !tmp17; if tmp16 { var tmp19 bool; tmp19 = n1_1640 == 0; if !tmp19 { tmp19 = nr_1641/n1_1640 == n0_1639 }; tmp16 = tmp19 }; tmp15 = tmp16; if tmp15 { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(nr_1641).Ref() } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1637, na_1638) } } else { tmp1 = lang.Numbers_Multiply_J_O__Number_NoInit(na_1637, na_1638) }
//line :551:1
					break L2 }; case 3: if any(G__219000238__3_) == any(A_arbace_go_check_types_A_const_105) { var fs__4 any = lang.RT_Nth_O_I__O_NoInit(u__2, lang.RT_IntCast_J__I_NoInit(1)); var tmp20 any; var root_1642 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1642, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1644 lang.IFn




						if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any = fs__4; if linked_1643 == nil { tmp20 = ifn_1644.Invoke_O__O(arg_1645) } else { tmp20 = linked_1643.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1642, arg_1645) }; if jrt.J2g_Truth(tmp20) { tmp1 = A_arbace_go_check_types_A_const_44 } else { var offs__5 any; var root_1646 any = A_arbace_go_check_types_A_const_193.GetRawRoot__O(); var linked_1647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1646, A_arbace_go_check_types_offsetsof_A_fn_class); var ifn_1648 lang.IFn

							if linked_1647 == nil { ifn_1648 = lang.IFn_Cast(root_1646) } else { ifn_1648 = nil }; var arg_1649 any = fs__4; if linked_1647 == nil { offs__5 = ifn_1648.Invoke_O__O(arg_1649) } else { offs__5 = linked_1647.(*A_arbace_go_check_types_offsetsof_A).Invoke_O_O__O(root_1646, arg_1649) }
//line :556:1
							var o__6 int64; var tmp21 any; var root_1650 any = A_arbace_go_check_types_A_const_194.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1650, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_1652 lang.IFn


							if linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any = offs__5; if linked_1651 == nil { tmp21 = ifn_1652.Invoke_O__O(arg_1653) } else { tmp21 = linked_1651.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_1650, arg_1653) }; o__6 = lang.RT_LongCast_O__J_NoInit(tmp21)
//line :556:1
							var s__7 any; var root_1654 any = A_arbace_go_check_types_A_const_190.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1654, A_arbace_go_check_types_sizeof_A_fn_class); var ifn_1656 lang.IFn



							if linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any; var tmp22 *lang.Keyword = A_arbace_go_check_types_A_const_107; var tmp23 any; var root_1658 any = A_arbace_go_check_types_A_const_194.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_1660 lang.IFn; if linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any = fs__4; if linked_1659 == nil { tmp23 = ifn_1660.Invoke_O__O(arg_1661) } else { tmp23 = linked_1659.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_1658, arg_1661) }; arg_1657 = tmp22.Invoke_O__O(tmp23); if linked_1655 == nil { s__7 = ifn_1656.Invoke_O__O(arg_1657) } else { s__7 = jrt.Long_ValueOf_J__Long_NoInit(linked_1655.(*A_arbace_go_check_types_sizeof_A).InvokePrim_O_O__J(root_1654, arg_1657)).Ref() }
//line :556:1
							var s__8 any; var tmp24 bool; var and__1927000168__auto____8 bool = lang.Numbers_IsPos_J__Z_NoInit(o__6)




							if and__1927000168__auto____8 { var na_1662 any = s__7; if jrt.Long_InstanceOf(na_1662) { var n0_1663 int64 = jrt.NN(jrt.Long_Cast(na_1662)).LongValue__J(); tmp24 = n0_1663 == 0 } else { if jrt.Double_InstanceOf(na_1662) { var n0_1663_2 float64 = jrt.NN(jrt.Double_Cast(na_1662)).DoubleValue__D(); tmp24 = n0_1663_2 == 0.0 } else { tmp24 = lang.Numbers_IsZero_O__Z_NoInit(na_1662) } } } else { tmp24 = and__1927000168__auto____8 }; if tmp24 { s__8 = A_arbace_go_check_types_A_const_15 } else { s__8 = s__7 }
							var root_1664 any = A_arbace_go_check_types_A_const_192.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1664, A_arbace_go_check_types_align_up_A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any; var na_1669 int64 = o__6; var na_1670 any = s__8; if jrt.Long_InstanceOf(na_1670) { var n0_1671 int64 = na_1669; var n1_1672 int64 = jrt.NN(jrt.Long_Cast(na_1670)).LongValue__J(); var nr_1673 int64 = n0_1671 + n1_1672; if (n0_1671^nr_1673)&(n1_1672^nr_1673) >= 0 { arg_1667 = jrt.Long_ValueOf_J__Long_NoInit(nr_1673).Ref() } else { arg_1667 = lang.Numbers_Add_J_O__Number_NoInit(na_1669, na_1670) } } else { arg_1667 = lang.Numbers_Add_J_O__Number_NoInit(na_1669, na_1670) }; var arg_1668 any; var root_1674 any = A_arbace_go_check_types_A_const_185.GetRawRoot__O(); var linked_1675 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1674, A_arbace_go_check_types_alignof_A_fn_class); var ifn_1676 lang.IFn; if linked_1675 == nil { ifn_1676 = lang.IFn_Cast(root_1674) } else { ifn_1676 = nil }; var arg_1677 any = t__0; if linked_1675 == nil { arg_1668 = ifn_1676.Invoke_O__O(arg_1677) } else { arg_1668 = jrt.Long_ValueOf_J__Long_NoInit(linked_1675.(*A_arbace_go_check_types_alignof_A).InvokePrim_O_O__J(root_1674, arg_1677)).Ref() }; if linked_1665 == nil { tmp1 = ifn_1666.Invoke_O_O__O(arg_1667, arg_1668) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_1665.(*A_arbace_go_check_types_align_up_A).InvokePrim_O_J_J__J(root_1664, lang.RT_LongCast_O__J_NoInit(arg_1667), lang.RT_LongCast_O__J_NoInit(arg_1668))).Ref() } }
//line :551:1
						break L2 }; default:}; tmp1 = A_arbace_go_check_types_A_const_189.GetRawRoot__O()} } else {
//line :548:1
							tmp1 = nil } }; return /*line :546:1*/ jrt.Number_Cast(tmp1).LongValue__J() }
//line :546:1
func (t *A_arbace_go_check_types_sizeof_A) Invoke_O_O__O(self, t__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, t__0)).Ref() }





















func A_arbace_go_check_types_deref_type_A_New() *A_arbace_go_check_types_deref_type_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_deref_type_A{}; t.Ctor(); return t }
//line :568:1
func (t *A_arbace_go_check_types_deref_type_A) Ctor() {}
//line :568:1
func (t *A_arbace_go_check_types_deref_type_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_1678 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1678, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1680 lang.IFn; if linked_1679 == nil { ifn_1680 = lang.IFn_Cast(root_1678) } else { ifn_1680 = nil }; var arg_1681 any = t__0; if linked_1679 == nil { and__1927000168__auto____2 = ifn_1680.Invoke_O__O(arg_1681) } else { and__1927000168__auto____2 = linked_1679.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1678, arg_1681) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_types_A_const_87; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(1)), jrt.Boolean_TRUE.Ref()) } else { return lang.Tuple_Create_O_O__IPersistentVector(t__0, jrt.Boolean_FALSE.Ref())
	} }
func A_arbace_go_check_types_methods_of_A_New() *A_arbace_go_check_types_methods_of_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_methods_of_A{}; t.Ctor(); return t }
//line :573:1
func (t *A_arbace_go_check_types_methods_of_A) Ctor() {}
//line :573:1
func (t *A_arbace_go_check_types_methods_of_A) Invoke_O_O__O(self, t__0 any) any { var t__2 any; var tmp1 *lang.Keyword = A_arbace_go_check_types_A_const_195; var tmp2 any; var root_1682 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1682, A_arbace_go_check_types_info_A_fn_class); var ifn_1684 lang.IFn; if


	linked_1683 == nil { ifn_1684 = lang.IFn_Cast(root_1682) } else { ifn_1684 = nil }; var arg_1685 any = t__0; if linked_1683 == nil { tmp2 = ifn_1684.Invoke_O__O(arg_1685) } else { tmp2 = linked_1683.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1682, arg_1685) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var tmp3 *lang.Keyword = A_arbace_go_check_types_A_const_195; var tmp4 any; var root_1686 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1686, A_arbace_go_check_types_info_A_fn_class); var ifn_1688 lang.IFn; if linked_1687 == nil { ifn_1688 = lang.IFn_Cast(root_1686) } else { ifn_1688 = nil }; var arg_1689 any = t__0; if linked_1687 == nil { tmp4 = ifn_1688.Invoke_O__O(arg_1689) } else { tmp4 = linked_1687.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1686, arg_1689) }; t__2 = tmp3.Invoke_O__O(tmp4) } else { t__2 = t__0 }; var root_1694 any =
	A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1694, A_arbace_go_check_types_under_A_fn_class); var ifn_1696 lang.IFn; if linked_1695 == nil { ifn_1696 = lang.IFn_Cast(root_1694) } else { ifn_1696 = nil }; var arg_1697 any = t__2; if linked_1695 == nil { ifn_1696.Invoke_O__O(arg_1697) } else { linked_1695.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1694, arg_1697) }; var tmp5 /*line :578:1*/*lang.Keyword = A_arbace_go_check_types_A_const_62; var tmp6 any; var root_1690 any = A_arbace_go_check_types_A_const_63.GetRawRoot__O(); var linked_1691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1690, A_arbace_go_check_types_info_A_fn_class); var ifn_1692 lang.IFn; if linked_1691 == nil { ifn_1692 = lang.IFn_Cast(root_1690) } else { ifn_1692 = nil }; var arg_1693 any = t__2; if linked_1691 == nil { tmp6 = ifn_1692.Invoke_O__O(arg_1693) } else { tmp6 = linked_1691.(*A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1690, arg_1693) }; return tmp5.Invoke_O__O(tmp6) }





func A_arbace_go_check_types_same_id_QMARK__A_New() *A_arbace_go_check_types_same_id_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_same_id_QMARK__A{}; t.Ctor(); return t }
//line :584:1
func (t *A_arbace_go_check_types_same_id_QMARK__A) Ctor() {}
//line :584:1
func (t *A_arbace_go_check_types_same_id_QMARK__A) Invoke_O_O_O_O_O__O(self, n__0, p__1, name__2, pkg__3 any) any {



	var tmp1 any; var and__1927000168__auto____5 any = A_arbace_go_check_types_A_const_196.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.String_Cast(n__0)).EqualsIgnoreCase_String__Z(jrt.String_Cast(name__2))).Ref() } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, name__2)

		if and__1927000168__auto____5_2 { var or__1927000174__auto____6 bool = jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(name__2)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)))
			if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(p__1, pkg__3); if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { return jrt.Boolean_FALSE.Ref() } } } else {
//line :590:1
				return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref()
			}
	}
}


func A_arbace_go_check_types_exported_QMARK__A_New() *A_arbace_go_check_types_exported_QMARK__A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_exported_QMARK__A{}; t.Ctor(); return t }
//line :596:1
func (t *A_arbace_go_check_types_exported_QMARK__A) Ctor() {}
//line :596:1
func (t *A_arbace_go_check_types_exported_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var cp__2 int32 = jrt.NN(jrt.String_Cast(n__0)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(0)); return /*line :597:1*/ jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsUpperCase_I__Z_NoInit(cp__2)).Ref() }











func A_arbace_go_check_types_named_method_A_New() *A_arbace_go_check_types_named_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_named_method_A{}; t.Ctor(); return t }
//line :609:1
func (t *A_arbace_go_check_types_named_method_A) Ctor() {}
//line :609:1
func (t *A_arbace_go_check_types_named_method_A) Invoke_O_O_O_O__O(self, t__0, name__1, pkg__2 any) any { { var ms__4 any; var root_1698 any = A_arbace_go_check_types_A_const_197.GetRawRoot__O(); var linked_1699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1698, A_arbace_go_check_types_methods_of_A_fn_class); var ifn_1700 lang.IFn


	if linked_1699 == nil { ifn_1700 = lang.IFn_Cast(root_1698) } else { ifn_1700 = nil }; var arg_1701 any = t__0; if linked_1699 == nil { ms__4 = ifn_1700.Invoke_O__O(arg_1701) } else { ms__4 = linked_1699.(*A_arbace_go_check_types_methods_of_A).Invoke_O_O__O(root_1698, arg_1701) }
//line :609:1
	var i__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i__5, int64(lang.RT_Count_O__I_NoInit(ms__4))) { var m__6 any = lang.RT_Nth_O_I__O_NoInit(ms__4, lang.RT_IntCast_J__I_NoInit(i__5)); var map__219000244__7 any; var root_1702 any = A_arbace_go_check_types_A_const_6.GetRawRoot__O(); var linked_1703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1702, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1704 lang.IFn
			if linked_1703 == nil { ifn_1704 = lang.IFn_Cast(root_1702) } else { ifn_1704 = nil }; var arg_1705 any = m__6; if linked_1703 == nil { map__219000244__7 = ifn_1704.Invoke_O__O(arg_1705) } else { map__219000244__7 = linked_1703.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1702, arg_1705) }
//line :614:1
			var map__219000244__8 any
			if lang.ISeq_InstanceOf(map__219000244__7) { var tmp1 any; var root_1706 any = A_arbace_go_check_types_A_const_198.GetRawRoot__O(); var linked_1707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1706, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1708 lang.IFn; if linked_1707 == nil { ifn_1708 = lang.IFn_Cast(root_1706) } else { ifn_1708 = nil }; var arg_1709 any = map__219000244__7; if linked_1707 == nil { tmp1 = ifn_1708.Invoke_O__O(arg_1709) } else { tmp1 = linked_1707.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1706, arg_1709) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1710 any = A_arbace_go_check_types_A_const_199.GetRawRoot__O(); var linked_1711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1710, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1712 lang.IFn; if linked_1711 == nil { ifn_1712 = lang.IFn_Cast(root_1710) } else { ifn_1712 = nil }; var arg_1713 any = map__219000244__7; if linked_1711 == nil { tmp2 = ifn_1712.Invoke_O__O(arg_1713) } else { tmp2 = linked_1711.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1710, arg_1713) }; map__219000244__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1714 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_1715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1714, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1716 lang.IFn; if linked_1715 == nil { ifn_1716 = lang.IFn_Cast(root_1714) } else { ifn_1716 = nil }; var arg_1717 any = map__219000244__7; if linked_1715 == nil { tmp3 = ifn_1716.Invoke_O__O(arg_1717) } else { tmp3 = linked_1715.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1714, arg_1717) }; if jrt.J2g_Truth(tmp3) { var root_1718 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1718, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1720 lang.IFn; if linked_1719 == nil { ifn_1720 = lang.IFn_Cast(root_1718) } else { ifn_1720 = nil }; var arg_1721 any = map__219000244__7; if linked_1719 == nil { map__219000244__8 = ifn_1720.Invoke_O__O(arg_1721) } else { map__219000244__8 = linked_1719.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1718, arg_1721) } } else { map__219000244__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__219000244__8 = map__219000244__7 }
//line :614:1
			var mn__9 any = lang.RT_Get_O_O__O_NoInit(map__219000244__8, A_arbace_go_check_types_A_const_12); var mp__10 any = lang.RT_Get_O_O__O_NoInit(map__219000244__8, A_arbace_go_check_types_A_const_170); var tmp4 any; var root_1722 any = A_arbace_go_check_types_A_const_200.GetRawRoot__O(); var linked_1723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1722, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_1724 lang.IFn


			if linked_1723 == nil { ifn_1724 = lang.IFn_Cast(root_1722) } else { ifn_1724 = nil }; var arg_1725 any = mn__9; var arg_1726 any = mp__10; var arg_1727 any = name__1; var arg_1728 any = pkg__2; if linked_1723 == nil { tmp4 = ifn_1724.Invoke_O_O_O_O__O(arg_1725, arg_1726, arg_1727, arg_1728) } else { tmp4 = linked_1723.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_1722, arg_1725, arg_1726, arg_1727, arg_1728) }; if jrt.J2g_Truth(tmp4) { return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__5).Ref(), m__6) } else {

				i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } } else {
//line :614:1
					return nil } } }; /*line :609:1*/panic("j2g: unreachable") }











func A_arbace_go_check_types_iface_method_A_New() *A_arbace_go_check_types_iface_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_iface_method_A{}; t.Ctor(); return t }
//line :621:1
func (t *A_arbace_go_check_types_iface_method_A) Ctor() {}
//line :621:1
func (t *A_arbace_go_check_types_iface_method_A) Invoke_O_O_O_O__O(self, u__0, name__1, pkg__2 any) any { { var ms__4 any = lang.RT_Nth_O_I__O_NoInit(u__0, lang.RT_IntCast_J__I_NoInit(1)); var i__5 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i__5, int64(lang.RT_Count_O__I_NoInit(ms__4))) { var m__6 any = lang.RT_Nth_O_I__O_NoInit(ms__4, lang.RT_IntCast_J__I_NoInit(i__5)); var tmp1 any; var root_1729 any = A_arbace_go_check_types_A_const_200.GetRawRoot__O(); var linked_1730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1729, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_1731 lang.IFn

		if linked_1730 == nil { ifn_1731 = lang.IFn_Cast(root_1729) } else { ifn_1731 = nil }; var arg_1732 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__6); var arg_1733 any = A_arbace_go_check_types_A_const_170.Invoke_O__O(m__6); var arg_1734 any = name__1; var arg_1735 any = pkg__2; if linked_1730 == nil { tmp1 = ifn_1731.Invoke_O_O_O_O__O(arg_1732, arg_1733, arg_1734, arg_1735) } else { tmp1 = linked_1730.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_1729, arg_1732, arg_1733, arg_1734, arg_1735) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__5).Ref(), m__6) } else {

			i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } } else {
//line :626:1
				return nil } } }; /*line :621:1*/panic("j2g: unreachable") }










func A_arbace_go_check_types_consolidate_A_New() *A_arbace_go_check_types_consolidate_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_consolidate_A{}; t.Ctor(); return t }
//line :632:1
func (t *A_arbace_go_check_types_consolidate_A) Ctor() {}
//line :632:1
func (t *A_arbace_go_check_types_consolidate_A) Invoke_O_O__O(self, entries__0 any) any { { var es__2 any = entries__0; var acc__3 any = lang.PersistentVector_EMPTY.Ref(); var idx__4 any = lang.PersistentArrayMap_EMPTY.Ref(); L1: for {



	var tmp1 any; var root_1736 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1736, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1738 lang.IFn; if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var arg_1739 any = es__2; if linked_1737 == nil { tmp1 = ifn_1738.Invoke_O__O(arg_1739) } else { tmp1 = linked_1737.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1736, arg_1739) }; if jrt.J2g_Truth(tmp1) { return acc__3 } else { var e__5 any; var root_1740 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1740, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1742 lang.IFn

		if linked_1741 == nil { ifn_1742 = lang.IFn_Cast(root_1740) } else { ifn_1742 = nil }; var arg_1743 any = es__2; if linked_1741 == nil { e__5 = ifn_1742.Invoke_O__O(arg_1743) } else { e__5 = linked_1741.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1740, arg_1743) }
//line :636:1
		var k__6 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(e__5); var temp__1927000408__auto____7 any = lang.RT_Get_O_O__O_NoInit(idx__4, k__6)



		if jrt.J2g_Truth(temp__1927000408__auto____7) { var j__8 any = temp__1927000408__auto____7; var tmp2 any; var root_1744 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1746 lang.IFn
			if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = es__2; if linked_1745 == nil { tmp2 = ifn_1746.Invoke_O__O(arg_1747) } else { tmp2 = linked_1745.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1744, arg_1747) }; var tmp3 any = tmp2; var tmp4 any; var root_1748 any = A_arbace_go_check_types_A_const_201.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1748, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1750 lang.IFn; if linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var arg_1751 any = acc__3; var arg_1752 any = lang.Tuple_Create_O_O__IPersistentVector(j__8, A_arbace_go_check_types_A_const_202); var arg_1753 any = jrt.Boolean_TRUE.Ref(); if linked_1749 == nil { tmp4 = ifn_1750.Invoke_O_O_O__O(arg_1751, arg_1752, arg_1753) } else { tmp4 = linked_1749.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1748, arg_1751, arg_1752, arg_1753) }; es__2, acc__3, idx__4 = tmp3, tmp4, idx__4; continue L1 } else {
				var tmp5 any; var root_1754 any = A_arbace_go_check_types_A_const_102.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = es__2; if linked_1755 == nil { tmp5 = ifn_1756.Invoke_O__O(arg_1757) } else { tmp5 = linked_1755.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1754, arg_1757) }; var tmp6 any = tmp5; var tmp7 any; var root_1758 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1758, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1760 lang.IFn; if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = acc__3; var arg_1762 any = e__5; if linked_1759 == nil { tmp7 = ifn_1760.Invoke_O_O__O(arg_1761, arg_1762) } else { tmp7 = linked_1759.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1758, arg_1761, arg_1762) }; var tmp8 any = tmp7; var tmp9 any; var root_1763 any = A_arbace_go_check_types_A_const_59.GetRawRoot__O(); var linked_1764 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1763, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1765 lang.IFn; if linked_1764 == nil { ifn_1765 = lang.IFn_Cast(root_1763) } else { ifn_1765 = nil }; var arg_1766 any = idx__4; var arg_1767 any = k__6; var arg_1768 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(acc__3)).Ref(); if linked_1764 == nil { tmp9 = ifn_1765.Invoke_O_O_O__O(arg_1766, arg_1767, arg_1768) } else { tmp9 = linked_1764.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1763, arg_1766, arg_1767, arg_1768) }; es__2, acc__3, idx__4 = tmp6, tmp8, tmp9; continue L1 } } } }; /*line :632:1*/panic("j2g: unreachable") }











func A_arbace_go_check_types_lookup_impl_A_New() *A_arbace_go_check_types_lookup_impl_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_impl_A{}; t.Ctor(); return t }
//line :644:1
func (t *A_arbace_go_check_types_lookup_impl_A) Ctor() {}
//line :644:1
func (t *A_arbace_go_check_types_lookup_impl_A) Invoke_O_O_O_O_O__O(self, T__0_, addressable__1, name__2, pkg__3 any) any { { var vec__219000249__5 any; var root_1769 any = A_arbace_go_check_types_A_const_203.GetRawRoot__O(); var linked_1770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1769, A_arbace_go_check_types_deref_type_A_fn_class); var ifn_1771 lang.IFn





	if linked_1770 == nil { ifn_1771 = lang.IFn_Cast(root_1769) } else { ifn_1771 = nil }; var arg_1772 any = T__0_; if linked_1770 == nil { vec__219000249__5 = ifn_1771.Invoke_O__O(arg_1772) } else { vec__219000249__5 = linked_1770.(*A_arbace_go_check_types_deref_type_A).Invoke_O_O__O(root_1769, arg_1772) }
//line :644:1
	var typ__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000249__5, lang.RT_IntCast_J__I_NoInit(0), nil); var is_ptr__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000249__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any
	var and__1927000168__auto____8 any = is_ptr__7





	if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1773 any = A_arbace_go_check_types_A_const_204.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, A_arbace_go_check_types_interface_QMARK__A_fn_class); var ifn_1775 lang.IFn; if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any = typ__6; if linked_1774 == nil { tmp1 = ifn_1775.Invoke_O__O(arg_1776) } else { tmp1 = linked_1774.(*A_arbace_go_check_types_interface_QMARK__A).Invoke_O_O__O(root_1773, arg_1776) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return nil } else { var current__8 any = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_107, typ__6, A_arbace_go_check_types_A_const_212, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_types_A_const_213, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_types_A_const_214, is_ptr__7, A_arbace_go_check_types_A_const_202, jrt.Boolean_FALSE.Ref()))); var seen__9 any = lang.PersistentHashSet_EMPTY.Ref(); L1: for {



		var tmp2 any; var root_1777 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_1778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1777, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1779 lang.IFn; if linked_1778 == nil { ifn_1779 = lang.IFn_Cast(root_1777) } else { ifn_1779 = nil }; var arg_1780 any = current__8; if linked_1778 == nil { tmp2 = ifn_1779.Invoke_O__O(arg_1780) } else { tmp2 = linked_1778.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1777, arg_1780) }; if jrt.J2g_Truth(tmp2) { return nil } else { var vec__219000252__10 any; var root_1781 any = A_arbace_go_check_types_A_const_187.GetRawRoot__O(); var linked_1782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1781, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1783 lang.IFn


			if linked_1782 == nil { ifn_1783 = lang.IFn_Cast(root_1781) } else { ifn_1783 = nil }; var arg_1784 any; var tmp3 any = A_arbace_go_check_types_lookup_impl_fn__219000256_A_New_O_O(pkg__3, name__2); var tmp4 *jrt.Class; var fncls__1890 *jrt.Class = A_arbace_go_check_types_lookup_impl_fn__219000256_A_fn_class
			if fncls__1890 == nil { var fncls__1890d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_go_check_types_lookup_impl_fn__219000256_A_fn_class = fncls__1890d; tmp4 = fncls__1890d } else { tmp4 = fncls__1890 }; arg_1784 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)
//line :658:1
			var arg_1785 any = lang.Tuple_Create_O_O_O__IPersistentVector(nil, lang.PersistentVector_EMPTY.Ref(), seen__9); var arg_1786 any = current__8; if linked_1782 == nil { vec__219000252__10 = ifn_1783.Invoke_O_O_O__O(arg_1784, arg_1785, arg_1786) } else { vec__219000252__10 = linked_1782.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1781, arg_1784, arg_1785, arg_1786) }
//line :655:1
			var found__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000252__10, lang.RT_IntCast_J__I_NoInit(0), nil); var next__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000252__10, lang.RT_IntCast_J__I_NoInit(1), nil); var seen__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000252__10, lang.RT_IntCast_J__I_NoInit(2), nil)















































			if jrt.J2g_Truth(A_arbace_go_check_types_A_const_219.Invoke_O__O(found__11)) { return found__11 } else { if jrt.J2g_Truth(found__11) {


				var tmp5 any; var tmp6 any = A_arbace_go_check_types_A_const_209; var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_go_check_types_A_const_208.Invoke_O__O(found__11)); if and__1927000168__auto____14 { var tmp7 *lang.Keyword = A_arbace_go_check_types_A_const_220; var and__1927000168__auto____15 any = tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_go_check_types_A_const_221.Get__O()).Invoke_O__O(A_arbace_go_check_types_A_const_71.Invoke_O__O(found__11))); if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any; var root_1891 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_1892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1891, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1893 lang.IFn
					if linked_1892 == nil { ifn_1893 = lang.IFn_Cast(root_1891) } else { ifn_1893 = nil }; var arg_1894 any = A_arbace_go_check_types_A_const_214.Invoke_O__O(found__11); if linked_1892 == nil { and__1927000168__auto____16 = ifn_1893.Invoke_O__O(arg_1894) } else { and__1927000168__auto____16 = linked_1892.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1891, arg_1894) }
//line :706:1
					if jrt.J2g_Truth(and__1927000168__auto____16) {
						var root_1895 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_1896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1895, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1897 lang.IFn; if linked_1896 == nil { ifn_1897 = lang.IFn_Cast(root_1895) } else { ifn_1897 = nil }; var arg_1898 any = addressable__1; if linked_1896 == nil { tmp5 = ifn_1897.Invoke_O__O(arg_1898) } else { tmp5 = linked_1896.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1895, arg_1898) } } else {
//line :706:1
							tmp5 = and__1927000168__auto____16 } } else { tmp5 = and__1927000168__auto____15 } } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }; if jrt.J2g_Truth(tmp5) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_220, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_types_A_const_222, found__11)) } else { return found__11 } } else {
//line :703:1
								if A_arbace_go_check_types_A_const_75 != nil {






									var tmp8 any; var root_1899 any = A_arbace_go_check_types_A_const_223.GetRawRoot__O(); var linked_1900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1899, A_arbace_go_check_types_consolidate_A_fn_class); var ifn_1901 lang.IFn; if linked_1900 == nil { ifn_1901 = lang.IFn_Cast(root_1899) } else { ifn_1901 = nil }; var arg_1902 any = next__12; if linked_1900 == nil { tmp8 = ifn_1901.Invoke_O__O(arg_1902) } else { tmp8 = linked_1900.(*A_arbace_go_check_types_consolidate_A).Invoke_O_O__O(root_1899, arg_1902) }; current__8, seen__9 = tmp8, seen__13; continue L1 } else {
//line :703:1
										return nil } } } } } } }; /*line :644:1*/panic("j2g: unreachable") }














func A_arbace_go_check_types_lookup_impl_fn__219000256_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_lookup_impl_fn__219000256_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_impl_fn__219000256_A{}; t.Ctor_O_O(p0, p1); return t }
//line :659:1
func (t *A_arbace_go_check_types_lookup_impl_fn__219000256_A) Ctor_O_O(c__pkg, c__name any) { t.F_pkg = c__pkg; t.F_name = c__name }
//line :659:1
func (t *A_arbace_go_check_types_lookup_impl_fn__219000256_A) Invoke_O_O_O__O(self, p__219000255__1, e__2 any) any { { var vec__219000257__3 any = p__219000255__1; var found__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000257__3, lang.RT_IntCast_J__I_NoInit(0), nil); var next__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000257__3, lang.RT_IntCast_J__I_NoInit(1), nil); var seen__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000257__3, lang.RT_IntCast_J__I_NoInit(2), nil); var typ__7 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(e__2); var tmp1 any; var and__1927000168__auto____8 any; var root_1787 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1789 lang.IFn

	if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = typ__7; if linked_1788 == nil { and__1927000168__auto____8 = ifn_1789.Invoke_O__O(arg_1790) } else { and__1927000168__auto____8 = linked_1788.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1787, arg_1790) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1791 any = A_arbace_go_check_types_A_const_66.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1793 lang.IFn; if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any = seen__6; var arg_1795 any = typ__7; if linked_1792 == nil { tmp1 = ifn_1793.Invoke_O_O__O(arg_1794, arg_1795) } else { tmp1 = linked_1792.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1791, arg_1794, arg_1795) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__6) } else { var seen__8 any; var tmp2 any; var root_1796 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1798 lang.IFn

		if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any = typ__7; if linked_1797 == nil { tmp2 = ifn_1798.Invoke_O__O(arg_1799) } else { tmp2 = linked_1797.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1796, arg_1799) }; if jrt.J2g_Truth(tmp2) { var root_1800 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1801 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1800, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1802 lang.IFn; if linked_1801 == nil { ifn_1802 = lang.IFn_Cast(root_1800) } else { ifn_1802 = nil }; var arg_1803 any = seen__6; var arg_1804 any = typ__7; if linked_1801 == nil { seen__8 = ifn_1802.Invoke_O_O__O(arg_1803, arg_1804) } else { seen__8 = linked_1801.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1800, arg_1803, arg_1804) } } else { seen__8 = seen__6 }
//line :661:1
		var m__9 any; var tmp3 any; var root_1805 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1807 lang.IFn


		if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any = typ__7; if linked_1806 == nil { tmp3 = ifn_1807.Invoke_O__O(arg_1808) } else { tmp3 = linked_1806.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1805, arg_1808) }; if jrt.J2g_Truth(tmp3) { var root_1809 any = A_arbace_go_check_types_A_const_205.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, A_arbace_go_check_types_named_method_A_fn_class); var ifn_1811 lang.IFn; if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = typ__7; var arg_1813 any = t.F_name; var arg_1814 any = t.F_pkg; if linked_1810 == nil { m__9 = ifn_1811.Invoke_O_O_O__O(arg_1812, arg_1813, arg_1814) } else { m__9 = linked_1810.(*A_arbace_go_check_types_named_method_A).Invoke_O_O_O_O__O(root_1809, arg_1812, arg_1813, arg_1814) } } else { m__9 = nil }
		if jrt.J2g_Truth(m__9) {
			var tmp4 any; var or__1927000174__auto____10 any = found__4; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp4 = or__1927000174__auto____10 } else { tmp4 = A_arbace_go_check_types_A_const_202.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp4) { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_207, next__5, seen__8) } else { var tmp5 any = A_arbace_go_check_types_A_const_208; var tmp6 any = A_arbace_go_check_types_A_const_209; var tmp7 any = A_arbace_go_check_types_A_const_71; var tmp8 any; var root_1844 any = A_arbace_go_check_types_A_const_210.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1844, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1846 lang.IFn

				if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any = m__9; if linked_1845 == nil { tmp8 = ifn_1846.Invoke_O__O(arg_1847) } else { tmp8 = linked_1845.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1844, arg_1847) }
//line :666:1
				var tmp9 any = tmp8; var tmp10 any = A_arbace_go_check_types_A_const_211; var tmp11 any = A_arbace_go_check_types_A_const_212; var tmp12 any; var root_1848 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1848, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1850 lang.IFn

				if linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = A_arbace_go_check_types_A_const_212.Invoke_O__O(e__2); var arg_1852 any; var root_1853 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1853, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1855 lang.IFn; if linked_1854 == nil { ifn_1855 = lang.IFn_Cast(root_1853) } else { ifn_1855 = nil }; var arg_1856 any = m__9; if linked_1854 == nil { arg_1852 = ifn_1855.Invoke_O__O(arg_1856) } else { arg_1852 = linked_1854.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1853, arg_1856) }; if linked_1849 == nil { tmp12 = ifn_1850.Invoke_O_O__O(arg_1851, arg_1852) } else { tmp12 = linked_1849.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1848, arg_1851, arg_1852) }
//line :666:1
				var tmp13 any = tmp12; var tmp14 any = A_arbace_go_check_types_A_const_213; var tmp15 any = A_arbace_go_check_types_A_const_213.Invoke_O__O(e__2); var tmp16 any = A_arbace_go_check_types_A_const_214; return lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, tmp9, tmp10, typ__7, tmp11, tmp13, tmp14, tmp15, tmp16, A_arbace_go_check_types_A_const_214.Invoke_O__O(e__2))), next__5, seen__8) } } else {
//line :665:1
					var u__10 any; var root_1815 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1815, A_arbace_go_check_types_under_A_fn_class); var ifn_1817 lang.IFn




					if linked_1816 == nil { ifn_1817 = lang.IFn_Cast(root_1815) } else { ifn_1817 = nil }; var arg_1818 any = typ__7; if linked_1816 == nil { u__10 = ifn_1817.Invoke_O__O(arg_1818) } else { u__10 = linked_1816.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1815, arg_1818) }
					var tmp17 any; var and__1927000168__auto____11 any; var root_1819 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1819, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1821 lang.IFn
					if linked_1820 == nil { ifn_1821 = lang.IFn_Cast(root_1819) } else { ifn_1821 = nil }; var arg_1822 any = u__10; if linked_1820 == nil { and__1927000168__auto____11 = ifn_1821.Invoke_O__O(arg_1822) } else { and__1927000168__auto____11 = linked_1820.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1819, arg_1822) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var tmp18 any = A_arbace_go_check_types_A_const_105; tmp17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp18, lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp17 = and__1927000168__auto____11 }
//line :671:1
					if jrt.J2g_Truth(tmp17) { var fs__11 any = lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(1)); var i__12 int64 = 0; var found__13 any = found__4; var next__14 any = next__5; L1: for {



						if lang.Numbers_Gte_J_J__Z_NoInit(i__12, int64(lang.RT_Count_O__I_NoInit(fs__11))) { return lang.Tuple_Create_O_O_O__IPersistentVector(found__13, next__14, seen__8) } else { var f__15 any = lang.RT_Nth_O_I__O_NoInit(fs__11, lang.RT_IntCast_J__I_NoInit(i__12)); var tmp19 any; var root_1823 any = A_arbace_go_check_types_A_const_200.GetRawRoot__O(); var linked_1824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1823, A_arbace_go_check_types_same_id_QMARK__A_fn_class); var ifn_1825 lang.IFn



							if linked_1824 == nil { ifn_1825 = lang.IFn_Cast(root_1823) } else { ifn_1825 = nil }; var arg_1826 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(f__15); var arg_1827 any = A_arbace_go_check_types_A_const_170.Invoke_O__O(f__15); var arg_1828 any = t.F_name; var arg_1829 any = t.F_pkg; if linked_1824 == nil { tmp19 = ifn_1825.Invoke_O_O_O_O__O(arg_1826, arg_1827, arg_1828, arg_1829) } else { tmp19 = linked_1824.(*A_arbace_go_check_types_same_id_QMARK__A).Invoke_O_O_O_O_O__O(root_1823, arg_1826, arg_1827, arg_1828, arg_1829) }
//line :678:1
							if jrt.J2g_Truth(tmp19) {

								var tmp20 any; var or__1927000174__auto____16 any = found__13; if jrt.J2g_Truth(or__1927000174__auto____16) { tmp20 = or__1927000174__auto____16 } else { tmp20 = A_arbace_go_check_types_A_const_202.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp20) {
									i__12, found__13, next__14 = lang.Numbers_Inc_J__J_NoInit(i__12), A_arbace_go_check_types_A_const_215, next__14; continue L1 } else {
										var tmp21 int64 = lang.Numbers_Inc_J__J_NoInit(i__12); var tmp22 any = A_arbace_go_check_types_A_const_208; var tmp23 any = A_arbace_go_check_types_A_const_216; var tmp24 any = A_arbace_go_check_types_A_const_71; var tmp25 any = A_arbace_go_check_types_A_const_212; var tmp26 any; var root_1857 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1857, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1859 lang.IFn; if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any = A_arbace_go_check_types_A_const_212.Invoke_O__O(e__2); var arg_1861 any = jrt.Long_ValueOf_J__Long_NoInit(i__12).Ref(); if linked_1858 == nil { tmp26 = ifn_1859.Invoke_O_O__O(arg_1860, arg_1861) } else { tmp26 = linked_1858.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1857, arg_1860, arg_1861) }; var tmp27 any = tmp26; var tmp28 any = A_arbace_go_check_types_A_const_213; var tmp29 any = A_arbace_go_check_types_A_const_213.Invoke_O__O(e__2); var tmp30 any = A_arbace_go_check_types_A_const_214; i__12, found__13, next__14 = tmp21, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp23, tmp24, f__15, tmp25, tmp27, tmp28, tmp29, tmp30, A_arbace_go_check_types_A_const_214.Invoke_O__O(e__2))), next__14; continue L1 } } else {
//line :678:1
											var tmp31 any; var and__1927000168__auto____16 bool = lang.Util_Identical_O_O__Z_NoInit(found__13, nil)






											if and__1927000168__auto____16 { tmp31 = A_arbace_go_check_types_A_const_168.Invoke_O__O(f__15) } else { tmp31 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____16).Ref() }
//line :678:1
											if jrt.J2g_Truth(tmp31) { var vec__219000260__16 any; var root_1830 any = A_arbace_go_check_types_A_const_203.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1830, A_arbace_go_check_types_deref_type_A_fn_class); var ifn_1832 lang.IFn







												if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any = A_arbace_go_check_types_A_const_107.Invoke_O__O(f__15); if linked_1831 == nil { vec__219000260__16 = ifn_1832.Invoke_O__O(arg_1833) } else { vec__219000260__16 = linked_1831.(*A_arbace_go_check_types_deref_type_A).Invoke_O_O__O(root_1830, arg_1833) }
//line :678:1
												var ft__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000260__16, lang.RT_IntCast_J__I_NoInit(0), nil); var fp__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000260__16, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp32 int64 = lang.Numbers_Inc_J__J_NoInit(i__12); var tmp33 any; var root_1862 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1863 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1862, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1864 lang.IFn









												if linked_1863 == nil { ifn_1864 = lang.IFn_Cast(root_1862) } else { ifn_1864 = nil }; var arg_1865 any = next__14; var arg_1866 any; var tmp34 any = A_arbace_go_check_types_A_const_107; var tmp35 any = A_arbace_go_check_types_A_const_212; var tmp36 any; var root_1867 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1868 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1867, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1869 lang.IFn; if linked_1868 == nil { ifn_1869 = lang.IFn_Cast(root_1867) } else { ifn_1869 = nil }; var arg_1870 any = A_arbace_go_check_types_A_const_212.Invoke_O__O(e__2); var arg_1871 any = jrt.Long_ValueOf_J__Long_NoInit(i__12).Ref(); if linked_1868 == nil { tmp36 = ifn_1869.Invoke_O_O__O(arg_1870, arg_1871) } else { tmp36 = linked_1868.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1867, arg_1870, arg_1871) }; var tmp37 any = tmp36; var tmp38 any = A_arbace_go_check_types_A_const_213; var tmp39 any; var root_1872 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1872, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1874 lang.IFn
												if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any = A_arbace_go_check_types_A_const_213.Invoke_O__O(e__2); var arg_1876 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(f__15); if linked_1873 == nil { tmp39 = ifn_1874.Invoke_O_O__O(arg_1875, arg_1876) } else { tmp39 = linked_1873.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1872, arg_1875, arg_1876) }
//line :688:1
												var tmp40 any = tmp39; var tmp41 any = A_arbace_go_check_types_A_const_214; var tmp42 any; var or__1927000174__auto____19 any = A_arbace_go_check_types_A_const_214.Invoke_O__O(e__2)

												if jrt.J2g_Truth(or__1927000174__auto____19) { tmp42 = or__1927000174__auto____19 } else { tmp42 = fp__18 }
//line :688:1
												var tmp43 any = tmp42; var tmp44 any = A_arbace_go_check_types_A_const_202; arg_1866 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp34, ft__17, tmp35, tmp37, tmp38, tmp40, tmp41, tmp43, tmp44, A_arbace_go_check_types_A_const_202.Invoke_O__O(e__2))); if linked_1863 == nil { tmp33 = ifn_1864.Invoke_O_O__O(arg_1865, arg_1866) } else { tmp33 = linked_1863.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1862, arg_1865, arg_1866) }
//line :687:1
												i__12, found__13, next__14 = tmp32, found__13, tmp33; continue L1 } else {
//line :678:1
													if A_arbace_go_check_types_A_const_75 != nil {













														i__12, found__13, next__14 = lang.Numbers_Inc_J__J_NoInit(i__12), found__13, next__14; continue L1 } else {
//line :678:1
															return nil } } } } } } else {
//line :671:1
																var tmp45 any; var and__1927000168__auto____11_2 any; var root_1834 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1834, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1836 lang.IFn





















																if linked_1835 == nil { ifn_1836 = lang.IFn_Cast(root_1834) } else { ifn_1836 = nil }; var arg_1837 any = u__10; if linked_1835 == nil { and__1927000168__auto____11_2 = ifn_1836.Invoke_O__O(arg_1837) } else { and__1927000168__auto____11_2 = linked_1835.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1834, arg_1837) }; if jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp46 any = A_arbace_go_check_types_A_const_86; tmp45 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp46, lang.RT_Nth_O_I__O_NoInit(u__10, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp45 = and__1927000168__auto____11_2 }
//line :671:1
																if jrt.J2g_Truth(tmp45) { var temp__1927000408__auto____11 any; var root_1838 any = A_arbace_go_check_types_A_const_206.GetRawRoot__O(); var linked_1839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1838, A_arbace_go_check_types_iface_method_A_fn_class); var ifn_1840 lang.IFn






















																	if linked_1839 == nil { ifn_1840 = lang.IFn_Cast(root_1838) } else { ifn_1840 = nil }; var arg_1841 any = u__10; var arg_1842 any = t.F_name; var arg_1843 any = t.F_pkg; if linked_1839 == nil { temp__1927000408__auto____11 = ifn_1840.Invoke_O_O_O__O(arg_1841, arg_1842, arg_1843) } else { temp__1927000408__auto____11 = linked_1839.(*A_arbace_go_check_types_iface_method_A).Invoke_O_O_O_O__O(root_1838, arg_1841, arg_1842, arg_1843) }; if jrt.J2g_Truth(temp__1927000408__auto____11) { var m__12 any = temp__1927000408__auto____11; var tmp47 any; var or__1927000174__auto____13 any = found__4
																		if jrt.J2g_Truth(or__1927000174__auto____13) { tmp47 = or__1927000174__auto____13 } else { tmp47 = A_arbace_go_check_types_A_const_202.Invoke_O__O(e__2) }; if jrt.J2g_Truth(tmp47) { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_types_A_const_217, next__5, seen__8) } else { var tmp48 any = A_arbace_go_check_types_A_const_208; var tmp49 any = A_arbace_go_check_types_A_const_218; var tmp50 any = A_arbace_go_check_types_A_const_71; var tmp51 any; var root_1877 any = A_arbace_go_check_types_A_const_210.GetRawRoot__O(); var linked_1878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1877, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1879 lang.IFn

																			if linked_1878 == nil { ifn_1879 = lang.IFn_Cast(root_1877) } else { ifn_1879 = nil }; var arg_1880 any = m__12; if linked_1878 == nil { tmp51 = ifn_1879.Invoke_O__O(arg_1880) } else { tmp51 = linked_1878.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1877, arg_1880) }
//line :695:1
																			var tmp52 any = tmp51; var tmp53 any = A_arbace_go_check_types_A_const_145; var tmp54 any = A_arbace_go_check_types_A_const_212; var tmp55 any; var root_1881 any = A_arbace_go_check_types_A_const_8.GetRawRoot__O(); var linked_1882 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1881, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1883 lang.IFn

																			if linked_1882 == nil { ifn_1883 = lang.IFn_Cast(root_1881) } else { ifn_1883 = nil }; var arg_1884 any = A_arbace_go_check_types_A_const_212.Invoke_O__O(e__2); var arg_1885 any; var root_1886 any = A_arbace_go_check_types_A_const_122.GetRawRoot__O(); var linked_1887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1886, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1888 lang.IFn; if linked_1887 == nil { ifn_1888 = lang.IFn_Cast(root_1886) } else { ifn_1888 = nil }; var arg_1889 any = m__12; if linked_1887 == nil { arg_1885 = ifn_1888.Invoke_O__O(arg_1889) } else { arg_1885 = linked_1887.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1886, arg_1889) }; if linked_1882 == nil { tmp55 = ifn_1883.Invoke_O_O__O(arg_1884, arg_1885) } else { tmp55 = linked_1882.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1881, arg_1884, arg_1885) }
//line :695:1
																			var tmp56 any = tmp55; var tmp57 any = A_arbace_go_check_types_A_const_213; var tmp58 any = A_arbace_go_check_types_A_const_213.Invoke_O__O(e__2); var tmp59 any = A_arbace_go_check_types_A_const_214; return lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp48, tmp49, tmp50, tmp52, tmp53, typ__7, tmp54, tmp56, tmp57, tmp58, tmp59, A_arbace_go_check_types_A_const_214.Invoke_O__O(e__2))), next__5, seen__8) } } else {
//line :694:1
																				return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__8) } } else {
//line :671:1
																					if A_arbace_go_check_types_A_const_75 != nil { return lang.Tuple_Create_O_O_O__IPersistentVector(found__4, next__5, seen__8) } else { return nil } } } } } }; /*line :659:1*/panic("j2g: unreachable") }




















































func A_arbace_go_check_types_lookup_A_New() *A_arbace_go_check_types_lookup_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_lookup_A{}; t.Ctor(); return t }
//line :712:1
func (t *A_arbace_go_check_types_lookup_A) Ctor() {}
//line :712:1
func (t *A_arbace_go_check_types_lookup_A) Invoke_O_O_O_O_O__O(self, T__0_, addressable__1, name__2, pkg__3 any) any {


	var tmp1 any; var and__1927000168__auto____5 any; var root_1903 any = A_arbace_go_check_types_A_const_65.GetRawRoot__O(); var linked_1904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1903, A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_1905 lang.IFn; if linked_1904 == nil { ifn_1905 = lang.IFn_Cast(root_1903) } else { ifn_1905 = nil }; var arg_1906 any = T__0_; if linked_1904 == nil { and__1927000168__auto____5 = ifn_1905.Invoke_O__O(arg_1906) } else { and__1927000168__auto____5 = linked_1904.(*A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_1903, arg_1906) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1907 any = A_arbace_go_check_types_A_const_224.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1907, A_arbace_go_check_types_pointer_QMARK__A_fn_class); var ifn_1909 lang.IFn; if linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = T__0_; if linked_1908 == nil { tmp1 = ifn_1909.Invoke_O__O(arg_1910) } else { tmp1 = linked_1908.(*A_arbace_go_check_types_pointer_QMARK__A).Invoke_O_O__O(root_1907, arg_1910) } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var r__5 any; var root_1911 any = A_arbace_go_check_types_A_const_225.GetRawRoot__O(); var linked_1912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1911, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_1913 lang.IFn
		if linked_1912 == nil { ifn_1913 = lang.IFn_Cast(root_1911) } else { ifn_1913 = nil }; var arg_1914 any; var root_1918 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1918, A_arbace_go_check_types_under_A_fn_class); var ifn_1920 lang.IFn; if linked_1919 == nil { ifn_1920 = lang.IFn_Cast(root_1918) } else { ifn_1920 = nil }; var arg_1921 any = T__0_; if linked_1919 == nil { arg_1914 = ifn_1920.Invoke_O__O(arg_1921) } else { arg_1914 = linked_1919.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1918, arg_1921) }; var arg_1915 any = jrt.Boolean_FALSE.Ref(); var arg_1916 any = name__2; var arg_1917 any = pkg__3; if linked_1912 == nil { r__5 = ifn_1913.Invoke_O_O_O_O__O(arg_1914, arg_1915, arg_1916, arg_1917) } else { r__5 = linked_1912.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_1911, arg_1914, arg_1915, arg_1916, arg_1917) }
		var tmp2 any = A_arbace_go_check_types_A_const_209; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_go_check_types_A_const_208.Invoke_O__O(r__5)) { return nil } else { return r__5 } } else {
			var root_1922 any = A_arbace_go_check_types_A_const_225.GetRawRoot__O(); var linked_1923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1922, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_1924 lang.IFn; if linked_1923 == nil { ifn_1924 = lang.IFn_Cast(root_1922) } else { ifn_1924 = nil }; var arg_1925 any = T__0_; var arg_1926 any = addressable__1; var arg_1927 any = name__2; var arg_1928 any = pkg__3; if linked_1923 == nil { return ifn_1924.Invoke_O_O_O_O__O(arg_1925, arg_1926, arg_1927, arg_1928) } else { return linked_1923.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_1922, arg_1925, arg_1926, arg_1927, arg_1928)
			}
		}
}
func A_arbace_go_check_types_sort_methods_A_New() *A_arbace_go_check_types_sort_methods_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sort_methods_A{}; t.Ctor(); return t }
//line :722:1
func (t *A_arbace_go_check_types_sort_methods_A) Ctor() {}
//line :722:1
func (t *A_arbace_go_check_types_sort_methods_A) Invoke_O_O__O(self, ms__0 any) any {


	var root_1929 any = A_arbace_go_check_types_A_const_123.GetRawRoot__O(); var linked_1930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1929, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1931 lang.IFn; if linked_1930 == nil { ifn_1931 = lang.IFn_Cast(root_1929) } else { ifn_1931 = nil }; var arg_1932 any; var root_1933 any = A_arbace_go_check_types_A_const_164.GetRawRoot__O(); var linked_1934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1933, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1935 lang.IFn; if linked_1934 == nil { ifn_1935 = lang.IFn_Cast(root_1933) } else { ifn_1935 = nil }; var arg_1936 any; var tmp1 any = A_arbace_go_check_types_sort_methods_fn__219000266_A_New(); var tmp2 *jrt.Class; var fncls__1938 *jrt.Class = A_arbace_go_check_types_sort_methods_fn__219000266_A_fn_class; if fncls__1938 == nil { var fncls__1938d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_go_check_types_sort_methods_fn__219000266_A_fn_class = fncls__1938d; tmp2 = fncls__1938d } else { tmp2 = fncls__1938 }; arg_1936 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1937 any = ms__0; if linked_1934 == nil { arg_1932 = ifn_1935.Invoke_O_O__O(arg_1936, arg_1937) } else { arg_1932 = linked_1934.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1933, arg_1936, arg_1937) }; if linked_1930 == nil { return ifn_1931.Invoke_O__O(arg_1932) } else { return linked_1930.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1929, arg_1932) } }
//line :725:1
func A_arbace_go_check_types_sort_methods_fn__219000266_A_New() *A_arbace_go_check_types_sort_methods_fn__219000266_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_sort_methods_fn__219000266_A{}; t.Ctor(); return t }
//line :725:1
func (t *A_arbace_go_check_types_sort_methods_fn__219000266_A) Ctor() {}
//line :725:1
func (t *A_arbace_go_check_types_sort_methods_fn__219000266_A) Invoke_O_O__O(self, m__1 any) any { var tmp1 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var tmp2 any; var or__1927000174__auto____2 any = A_arbace_go_check_types_A_const_170.Invoke_O__O(m__1); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = Lit_8 }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }

func A_arbace_go_check_types_method_data_A_New() *A_arbace_go_check_types_method_data_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_method_data_A{}; t.Ctor(); return t }
//line :727:1
func (t *A_arbace_go_check_types_method_data_A) Ctor() {}
//line :727:1
func (t *A_arbace_go_check_types_method_data_A) Invoke_O_O__O(self, m__0 any) any {


	var tmp1 any; var root_1939 any = A_arbace_go_check_types_A_const_142.GetRawRoot__O(); var linked_1940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1939, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1941 lang.IFn; if linked_1940 == nil { ifn_1941 = lang.IFn_Cast(root_1939) } else { ifn_1941 = nil }; var arg_1942 any = m__0; if linked_1940 == nil { tmp1 = ifn_1941.Invoke_O__O(arg_1942) } else { tmp1 = linked_1940.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1939, arg_1942) }; if jrt.J2g_Truth(tmp1) { return m__0 } else { return lang.IFn_Cast(A_arbace_go_check_types_A_const_221.Get__O()).Invoke_O__O(m__0)
	} }
func A_arbace_go_check_types_missing_method_A_New() *A_arbace_go_check_types_missing_method_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_A{}; t.Ctor(); return t }
//line :732:1
func (t *A_arbace_go_check_types_missing_method_A) Ctor() {}
//line :732:1
func (t *A_arbace_go_check_types_missing_method_A) Invoke_O_O_O_O_O__O(self, V__0_, T__1_, static__2, same_QMARK___3 any) any { var tu__5 any; var root_1943 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1943, A_arbace_go_check_types_under_A_fn_class); var ifn_1945 lang.IFn; if





	linked_1944 == nil { ifn_1945 = lang.IFn_Cast(root_1943) } else { ifn_1945 = nil }; var arg_1946 any = T__1_; if linked_1944 == nil { tu__5 = ifn_1945.Invoke_O__O(arg_1946) } else { tu__5 = linked_1944.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1943, arg_1946) }; var vu__6 any; var root_1947 any = /*line :732:1*/A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_1948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1947, A_arbace_go_check_types_under_A_fn_class); var ifn_1949 lang.IFn; if






	linked_1948 == nil { ifn_1949 = lang.IFn_Cast(root_1947) } else { ifn_1949 = nil }; var arg_1950 any = V__0_; if linked_1948 == nil { vu__6 = ifn_1949.Invoke_O__O(arg_1950) } else { vu__6 = linked_1948.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_1947, arg_1950) }; var root_1951 any =
	A_arbace_go_check_types_A_const_119.GetRawRoot__O(); var linked_1952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1951, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1953 lang.IFn; if linked_1952 == nil { ifn_1953 = lang.IFn_Cast(root_1951) } else { ifn_1953 = nil }; var arg_1954 any; var tmp1 any = A_arbace_go_check_types_missing_method_fn__219000270_A_New_O_O_O_O(static__2, V__0_, same_QMARK___3, vu__6); var tmp2 *jrt.Class; var fncls__1997 *jrt.Class = A_arbace_go_check_types_missing_method_fn__219000270_A_fn_class; if
	fncls__1997 == nil { var fncls__1997d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_go_check_types_missing_method_fn__219000270_A_fn_class = fncls__1997d; tmp2 = fncls__1997d } else { tmp2 = fncls__1997 }; arg_1954 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1955 any = /*line :740:1*/lang.RT_Nth_O_I__O_NoInit(tu__5, lang.RT_IntCast_J__I_NoInit(1)); if linked_1952 == nil { return ifn_1953.Invoke_O_O__O(arg_1954, arg_1955) } else { return linked_1952.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1951, arg_1954, arg_1955) } }
//line :732:1
func (t *A_arbace_go_check_types_missing_method_A) Invoke_O_O_O_O__O(self, V__0_, T__1_, static__2 any) any {



	var root_1998 any = A_arbace_go_check_types_A_const_233.GetRawRoot__O(); var linked_1999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1998, A_arbace_go_check_types_missing_method_A_fn_class); var ifn_2000 lang.IFn; if linked_1999 == nil { ifn_2000 = lang.IFn_Cast(root_1998) } else { ifn_2000 = nil }; var arg_2001 any = V__0_; var arg_2002 any = T__1_; var arg_2003 any = static__2; var arg_2004 any = A_arbace_go_check_types_A_const_234.GetRawRoot__O(); if linked_1999 == nil { return ifn_2000.Invoke_O_O_O_O__O(arg_2001, arg_2002, arg_2003, arg_2004) } else { return linked_1999.(*A_arbace_go_check_types_missing_method_A).Invoke_O_O_O_O_O__O(root_1998, arg_2001, arg_2002, arg_2003, arg_2004)
	}
}


func A_arbace_go_check_types_missing_method_fn__219000270_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_types_missing_method_fn__219000270_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_missing_method_fn__219000270_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :741:1
func (t *A_arbace_go_check_types_missing_method_fn__219000270_A) Ctor_O_O_O_O(c__static, c__V, c__same_QMARK_, c__vu any) { t.F_static = c__static; t.F_V = c__V; t.F_same_QMARK_ = c__same_QMARK_; t.F_vu = c__vu }
//line :741:1
func (t *A_arbace_go_check_types_missing_method_fn__219000270_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_1956 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_1957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1956, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1958 lang.IFn; if linked_1957 == nil { ifn_1958 = lang.IFn_Cast(root_1956) } else { ifn_1958 = nil }; var arg_1959 any = t.F_vu; if linked_1957 == nil { and__1927000168__auto____2 = ifn_1958.Invoke_O__O(arg_1959) } else { and__1927000168__auto____2 = linked_1957.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1956, arg_1959) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_types_A_const_86; var tmp3 any = t.F_vu; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var f__2 any; var root_1960 any = A_arbace_go_check_types_A_const_206.GetRawRoot__O(); var linked_1961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1960, A_arbace_go_check_types_iface_method_A_fn_class); var ifn_1962 lang.IFn
		if linked_1961 == nil { ifn_1962 = lang.IFn_Cast(root_1960) } else { ifn_1962 = nil }; var arg_1963 any = t.F_vu; var arg_1964 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var arg_1965 any = A_arbace_go_check_types_A_const_170.Invoke_O__O(m__1); if linked_1961 == nil { f__2 = ifn_1962.Invoke_O_O_O__O(arg_1963, arg_1964, arg_1965) } else { f__2 = linked_1961.(*A_arbace_go_check_types_iface_method_A).Invoke_O_O_O_O__O(root_1960, arg_1963, arg_1964, arg_1965) }
		if lang.Util_Identical_O_O__Z_NoInit(f__2, nil) {
			if jrt.J2g_Truth(t.F_static) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_209, m__1, A_arbace_go_check_types_A_const_226, A_arbace_go_check_types_A_const_227)) } else { return nil } } else {
//line :744:1
				var tmp4 any; var root_1966 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_1967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1966, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1968 lang.IFn

				if linked_1967 == nil { ifn_1968 = lang.IFn_Cast(root_1966) } else { ifn_1968 = nil }; var arg_1969 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_same_QMARK_); var tmp6 *lang.Keyword = A_arbace_go_check_types_A_const_107; var tmp7 any; var root_1970 any = A_arbace_go_check_types_A_const_210.GetRawRoot__O(); var linked_1971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1970, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1972 lang.IFn; if linked_1971 == nil { ifn_1972 = lang.IFn_Cast(root_1970) } else { ifn_1972 = nil }; var arg_1973 any = f__2; if linked_1971 == nil { tmp7 = ifn_1972.Invoke_O__O(arg_1973) } else { tmp7 = linked_1971.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1970, arg_1973) }; arg_1969 = tmp5.Invoke_O_O__O(tmp6.Invoke_O__O(tmp7), A_arbace_go_check_types_A_const_107.Invoke_O__O(m__1)); if linked_1967 == nil { tmp4 = ifn_1968.Invoke_O__O(arg_1969) } else { tmp4 = linked_1967.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1966, arg_1969) }
//line :744:1
				if jrt.J2g_Truth(tmp4) { var tmp8 any = A_arbace_go_check_types_A_const_209; var tmp9 any = A_arbace_go_check_types_A_const_226; var tmp10 any = A_arbace_go_check_types_A_const_228; var tmp11 any = A_arbace_go_check_types_A_const_229; var tmp12 any; var root_1974 any = A_arbace_go_check_types_A_const_210.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1976 lang.IFn

					if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = f__2; if linked_1975 == nil { tmp12 = ifn_1976.Invoke_O__O(arg_1977) } else { tmp12 = linked_1975.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1974, arg_1977) }
//line :744:1
					return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, m__1, tmp9, tmp10, tmp11, tmp12)) } else { return nil } } } else {
//line :742:1
						var r__2 any; var root_1978 any = A_arbace_go_check_types_A_const_225.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, A_arbace_go_check_types_lookup_impl_A_fn_class); var ifn_1980 lang.IFn




						if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any = t.F_V; var arg_1982 any = jrt.Boolean_FALSE.Ref(); var arg_1983 any = A_arbace_go_check_types_A_const_12.Invoke_O__O(m__1); var arg_1984 any = A_arbace_go_check_types_A_const_170.Invoke_O__O(m__1); if linked_1979 == nil { r__2 = ifn_1980.Invoke_O_O_O_O__O(arg_1981, arg_1982, arg_1983, arg_1984) } else { r__2 = linked_1979.(*A_arbace_go_check_types_lookup_impl_A).Invoke_O_O_O_O_O__O(root_1978, arg_1981, arg_1982, arg_1983, arg_1984) }
						if jrt.J2g_Truth(A_arbace_go_check_types_A_const_220.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_209, m__1, A_arbace_go_check_types_A_const_226, A_arbace_go_check_types_A_const_220)) } else { if lang.Util_Identical_O_O__Z_NoInit(r__2, nil) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_209, m__1, A_arbace_go_check_types_A_const_226, A_arbace_go_check_types_A_const_227)) } else { if jrt.J2g_Truth(A_arbace_go_check_types_A_const_219.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_209, m__1, A_arbace_go_check_types_A_const_226, A_arbace_go_check_types_A_const_227)) } else { var tmp13 any = A_arbace_go_check_types_A_const_216; if lang.Util_Equiv_O_O__Z_NoInit(tmp13, A_arbace_go_check_types_A_const_208.Invoke_O__O(r__2)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_209, m__1, A_arbace_go_check_types_A_const_226, A_arbace_go_check_types_A_const_216)) } else { if A_arbace_go_check_types_A_const_75 != nil { var d__3 any; var root_1985 any = A_arbace_go_check_types_A_const_230.GetRawRoot__O(); var linked_1986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1985, A_arbace_go_check_types_method_data_A_fn_class); var ifn_1987 lang.IFn





							if linked_1986 == nil { ifn_1987 = lang.IFn_Cast(root_1985) } else { ifn_1987 = nil }; var arg_1988 any = A_arbace_go_check_types_A_const_71.Invoke_O__O(r__2); if linked_1986 == nil { d__3 = ifn_1987.Invoke_O__O(arg_1988) } else { d__3 = linked_1986.(*A_arbace_go_check_types_method_data_A).Invoke_O_O__O(root_1985, arg_1988) }
//line :748:1
							var d__4 any; var tmp14 any; var and__1927000168__auto____4 any = A_arbace_go_check_types_A_const_231.Get__O()






							if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp15 any = A_arbace_go_check_types_A_const_209; tmp14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp15, A_arbace_go_check_types_A_const_208.Invoke_O__O(r__2))).Ref() } else { tmp14 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp14) { d__4 = lang.IFn_Cast(A_arbace_go_check_types_A_const_231.Get__O()).Invoke_O_O__O(A_arbace_go_check_types_A_const_211.Invoke_O__O(r__2), d__3) } else { d__4 = d__3
							}
							var tmp16 any; var or__1927000174__auto____5 any; var root_1989 any = A_arbace_go_check_types_A_const_111.GetRawRoot__O(); var linked_1990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1989, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1991 lang.IFn; if linked_1990 == nil { ifn_1991 = lang.IFn_Cast(root_1989) } else { ifn_1991 = nil }; var arg_1992 any = A_arbace_go_check_types_A_const_232.Invoke_O__O(d__4); if linked_1990 == nil { or__1927000174__auto____5 = ifn_1991.Invoke_O__O(arg_1992) } else { or__1927000174__auto____5 = linked_1990.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1989, arg_1992) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp16 = or__1927000174__auto____5 } else { var root_1993 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_1994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1993, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1995 lang.IFn; if linked_1994 == nil { ifn_1995 = lang.IFn_Cast(root_1993) } else { ifn_1995 = nil }; var tmp17 lang.IFn = lang.IFn_Cast(t.F_same_QMARK_); var arg_1996 any = tmp17.Invoke_O_O__O(A_arbace_go_check_types_A_const_107.Invoke_O__O(d__4), A_arbace_go_check_types_A_const_107.Invoke_O__O(m__1)); if linked_1994 == nil { tmp16 = ifn_1995.Invoke_O__O(arg_1996) } else { tmp16 = linked_1994.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1993, arg_1996) } }; if jrt.J2g_Truth(tmp16) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_types_A_const_209, m__1, A_arbace_go_check_types_A_const_226, A_arbace_go_check_types_A_const_228, A_arbace_go_check_types_A_const_229, d__4)) } else { return nil } } else {
//line :748:1
								return nil
							}
						}
						}
						}
						}
					}
}







func A_arbace_go_check_types_satisfies_cause_A_New() *A_arbace_go_check_types_satisfies_cause_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_A{}; t.Ctor(); return t }
//line :763:1
func (t *A_arbace_go_check_types_satisfies_cause_A) Ctor() {}
//line :763:1
func (t *A_arbace_go_check_types_satisfies_cause_A) Invoke_O_O_O__O(self, V__0_, b__1 any) any { var Ti__3_ any; var root_2005 any = A_arbace_go_check_types_A_const_146.GetRawRoot__O(); var linked_2006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2005, A_arbace_go_check_types_bound_iface_A_fn_class); var ifn_2007 lang.IFn; if



	linked_2006 == nil { ifn_2007 = lang.IFn_Cast(root_2005) } else { ifn_2007 = nil }; var arg_2008 any = b__1; if linked_2006 == nil { Ti__3_ = ifn_2007.Invoke_O__O(arg_2008) } else { Ti__3_ = linked_2006.(*A_arbace_go_check_types_bound_iface_A).Invoke_O_O__O(root_2005, arg_2008) }; var Vu__4_ any; var root_2009 any = /*line :763:1*/A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_2010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2009, A_arbace_go_check_types_under_A_fn_class); var ifn_2011 lang.IFn; if




	linked_2010 == nil { ifn_2011 = lang.IFn_Cast(root_2009) } else { ifn_2011 = nil }; var arg_2012 any = V__0_; if linked_2010 == nil { Vu__4_ = ifn_2011.Invoke_O__O(arg_2012) } else { Vu__4_ = linked_2010.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2009, arg_2012) }; var tmp1 any; var or__1927000174__auto____5 bool =
	lang.Util_Identical_O_O__Z_NoInit(Ti__3_, nil); if or__1927000174__auto____5 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_types_A_const_67, Vu__4_); if or__1927000174__auto____6 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var and__1927000168__auto____7 any; var root_2013 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_2014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2013, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2015 lang.IFn
		if linked_2014 == nil { ifn_2015 = lang.IFn_Cast(root_2013) } else { ifn_2015 = nil }; var arg_2016 any = Vu__4_; if linked_2014 == nil { and__1927000168__auto____7 = ifn_2015.Invoke_O__O(arg_2016) } else { and__1927000168__auto____7 = linked_2014.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2013, arg_2016) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp2 any = A_arbace_go_check_types_A_const_87; var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(0))); if and__1927000168__auto____8 { var tmp3 any = A_arbace_go_check_types_A_const_67; var tmp4 any; var root_2017 any = A_arbace_go_check_types_A_const_76.GetRawRoot__O(); var linked_2018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2017, A_arbace_go_check_types_under_A_fn_class); var ifn_2019 lang.IFn; if linked_2018 == nil { ifn_2019 = lang.IFn_Cast(root_2017) } else { ifn_2019 = nil }; var arg_2020 any = lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(1)); if linked_2018 == nil { tmp4 = ifn_2019.Invoke_O__O(arg_2020) } else { tmp4 = linked_2018.(*A_arbace_go_check_types_under_A).Invoke_O_O__O(root_2017, arg_2020) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() } } else { tmp1 = and__1927000168__auto____7 } } }; if /*line :769:1*/ jrt.J2g_Truth(tmp1) { return nil } else { var Tts__5_ any; var root_2021 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_2022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2021, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_2023 lang.IFn


			if linked_2022 == nil { ifn_2023 = lang.IFn_Cast(root_2021) } else { ifn_2023 = nil }; var arg_2024 any = Ti__3_; if linked_2022 == nil { Tts__5_ = ifn_2023.Invoke_O__O(arg_2024) } else { Tts__5_ = linked_2022.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_2021, arg_2024) }
//line :769:1
			var Vi__6_ any; var tmp5 any; var and__1927000168__auto____6 any; var root_2025 any = A_arbace_go_check_types_A_const_53.GetRawRoot__O(); var linked_2026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2025, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2027 lang.IFn



			if linked_2026 == nil { ifn_2027 = lang.IFn_Cast(root_2025) } else { ifn_2027 = nil }; var arg_2028 any = Vu__4_; if linked_2026 == nil { and__1927000168__auto____6 = ifn_2027.Invoke_O__O(arg_2028) } else { and__1927000168__auto____6 = linked_2026.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2025, arg_2028) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp6 any = A_arbace_go_check_types_A_const_86; tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp6, lang.RT_Nth_O_I__O_NoInit(Vu__4_, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { tmp5 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp5) { Vi__6_ = Vu__4_ } else { Vi__6_ = nil }
//line :769:1
			var Vts__7_ any




			if jrt.J2g_Truth(Vi__6_) { var root_2029 any = A_arbace_go_check_types_A_const_117.GetRawRoot__O(); var linked_2030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2029, A_arbace_go_check_types_iface_tset_A_fn_class); var ifn_2031 lang.IFn; if linked_2030 == nil { ifn_2031 = lang.IFn_Cast(root_2029) } else { ifn_2031 = nil }; var arg_2032 any = Vi__6_; if linked_2030 == nil { Vts__7_ = ifn_2031.Invoke_O__O(arg_2032) } else { Vts__7_ = linked_2030.(*A_arbace_go_check_types_iface_tset_A).Invoke_O_O__O(root_2029, arg_2032) } } else { Vts__7_ = nil }
//line :769:1
			var T_str__8_ any; var root_2033 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_2034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2033, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2035 lang.IFn





			if linked_2034 == nil { ifn_2035 = lang.IFn_Cast(root_2033) } else { ifn_2035 = nil }; var arg_2036 any = b__1; if linked_2034 == nil { T_str__8_ = ifn_2035.Invoke_O__O(arg_2036) } else { T_str__8_ = linked_2034.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2033, arg_2036) }
			var tmp7 any; var and__1927000168__auto____9 any; var root_2037 any = A_arbace_go_check_types_A_const_94.GetRawRoot__O(); var linked_2038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2037, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2039 lang.IFn
			if linked_2038 == nil { ifn_2039 = lang.IFn_Cast(root_2037) } else { ifn_2039 = nil }; var arg_2040 any = lang.RT_Nth_O_I__O_NoInit(Ti__3_, lang.RT_IntCast_J__I_NoInit(1)); if linked_2038 == nil { and__1927000168__auto____9 = ifn_2039.Invoke_O__O(arg_2040) } else { and__1927000168__auto____9 = linked_2038.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2037, arg_2040) }; if jrt.J2g_Truth(and__1927000168__auto____9) { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(lang.RT_Nth_O_I__O_NoInit(Ti__3_, lang.RT_IntCast_J__I_NoInit(2)), nil)).Ref() } else { tmp7 = and__1927000168__auto____9 }
//line :776:1
			if jrt.J2g_Truth(tmp7) { return nil } else { var tmp8 any
				var and__1927000168__auto____9_2 any = Vts__7_
				if jrt.J2g_Truth(and__1927000168__auto____9_2) { var root_2041 any = A_arbace_go_check_types_A_const_235.GetRawRoot__O(); var linked_2042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2041, A_arbace_go_check_types_tset_empty_QMARK__A_fn_class); var ifn_2043 lang.IFn; if linked_2042 == nil { ifn_2043 = lang.IFn_Cast(root_2041) } else { ifn_2043 = nil }; var arg_2044 any = Vts__7_; if linked_2042 == nil { tmp8 = ifn_2043.Invoke_O__O(arg_2044) } else { tmp8 = linked_2042.(*A_arbace_go_check_types_tset_empty_QMARK__A).Invoke_O_O__O(root_2041, arg_2044) } } else { tmp8 = and__1927000168__auto____9_2 }
//line :776:1
				if jrt.J2g_Truth(tmp8) { return nil } else { var tmp9 any; var root_2045 any = A_arbace_go_check_types_A_const_235.GetRawRoot__O(); var linked_2046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2045, A_arbace_go_check_types_tset_empty_QMARK__A_fn_class); var ifn_2047 lang.IFn


					if linked_2046 == nil { ifn_2047 = lang.IFn_Cast(root_2045) } else { ifn_2047 = nil }; var arg_2048 any = Tts__5_; if linked_2046 == nil { tmp9 = ifn_2047.Invoke_O__O(arg_2048) } else { tmp9 = linked_2046.(*A_arbace_go_check_types_tset_empty_QMARK__A).Invoke_O_O__O(root_2045, arg_2048) }
//line :776:1
					if jrt.J2g_Truth(tmp9) {


						return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_30, nil, Lit_31), jrt.RefArrayOf(jrt.Object_class, nil, T_str__8_, nil)).Ref() } else {
//line :776:1
							if A_arbace_go_check_types_A_const_75 != nil { var temp__1927000408__auto____9 any; var root_2049 any = A_arbace_go_check_types_A_const_233.GetRawRoot__O(); var linked_2050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2049, A_arbace_go_check_types_missing_method_A_fn_class); var ifn_2051 lang.IFn




								if linked_2050 == nil { ifn_2051 = lang.IFn_Cast(root_2049) } else { ifn_2051 = nil }; var arg_2052 any = V__0_; var arg_2053 any = Ti__3_; var arg_2054 any = jrt.Boolean_TRUE.Ref(); if linked_2050 == nil { temp__1927000408__auto____9 = ifn_2051.Invoke_O_O_O__O(arg_2052, arg_2053, arg_2054) } else { temp__1927000408__auto____9 = linked_2050.(*A_arbace_go_check_types_missing_method_A).Invoke_O_O_O_O__O(root_2049, arg_2052, arg_2053, arg_2054) }; if jrt.J2g_Truth(temp__1927000408__auto____9) { var mm__10 any = temp__1927000408__auto____9; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_32, nil, Lit_33, nil, Lit_26); var tmp11 any; var root_2055 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_2056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2055, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2057 lang.IFn
									if linked_2056 == nil { ifn_2057 = lang.IFn_Cast(root_2055) } else { ifn_2057 = nil }; var arg_2058 any = V__0_; if linked_2056 == nil { tmp11 = ifn_2057.Invoke_O__O(arg_2058) } else { tmp11 = linked_2056.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2055, arg_2058) }; var tmp12 *lang.Keyword = A_arbace_go_check_types_A_const_12; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp11, nil, T_str__8_, nil, tmp12.Invoke_O__O(A_arbace_go_check_types_A_const_209.Invoke_O__O(mm__10)), nil)).Ref() } else {
//line :781:1
										var comparability__10 any; var tmp13 any = A_arbace_go_check_types_satisfies_cause_comparability__219000273_A_New_O_O(Tts__5_, V__0_); var tmp14 *jrt.Class
										var fncls__2085 /*line :781:1*/*jrt.Class = A_arbace_go_check_types_satisfies_cause_comparability__219000273_A_fn_class


										if fncls__2085 == nil { var fncls__2085d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_check_types_satisfies_cause_comparability__219000273_A_fn_class = fncls__2085d; tmp14 = fncls__2085d } else { tmp14 = fncls__2085 }; comparability__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)








										var tmp15 any; var root_2086 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_2087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2086, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2088 lang.IFn
										if linked_2087 == nil { ifn_2088 = lang.IFn_Cast(root_2086) } else { ifn_2088 = nil }; var arg_2089 any; var root_2090 any = A_arbace_go_check_types_A_const_149.GetRawRoot__O(); var linked_2091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2090, A_arbace_go_check_types_has_terms_QMARK__A_fn_class); var ifn_2092 lang.IFn; if linked_2091 == nil { ifn_2092 = lang.IFn_Cast(root_2090) } else { ifn_2092 = nil }; var arg_2093 any = Tts__5_; if linked_2091 == nil { arg_2089 = ifn_2092.Invoke_O__O(arg_2093) } else { arg_2089 = linked_2091.(*A_arbace_go_check_types_has_terms_QMARK__A).Invoke_O_O__O(root_2090, arg_2093) }; if linked_2087 == nil { tmp15 = ifn_2088.Invoke_O__O(arg_2089) } else { tmp15 = linked_2087.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2086, arg_2089) }
//line :793:1
										if jrt.J2g_Truth(tmp15) {
											return lang.IFn_Cast(comparability__10).Invoke__O() } else {
//line :793:1
												if jrt.J2g_Truth(Vts__7_) {

													var tmp16 any; var root_2094 any = A_arbace_go_check_types_A_const_237.GetRawRoot__O(); var linked_2095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2094, A_arbace_go_check_types_terms_subset_QMARK__A_fn_class); var ifn_2096 lang.IFn; if linked_2095 == nil { ifn_2096 = lang.IFn_Cast(root_2094) } else { ifn_2096 = nil }; var arg_2097 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(Vts__7_); var arg_2098 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(Tts__5_); if linked_2095 == nil { tmp16 = ifn_2096.Invoke_O_O__O(arg_2097, arg_2098) } else { tmp16 = linked_2095.(*A_arbace_go_check_types_terms_subset_QMARK__A).Invoke_O_O_O__O(root_2094, arg_2097, arg_2098) }; if jrt.J2g_Truth(tmp16) {
														return lang.IFn_Cast(comparability__10).Invoke__O() } else {
															var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_32, nil); var tmp18 any; var root_2099 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_2100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2099, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2101 lang.IFn; if linked_2100 == nil { ifn_2101 = lang.IFn_Cast(root_2099) } else { ifn_2101 = nil }; var arg_2102 any = V__0_; if linked_2100 == nil { tmp18 = ifn_2101.Invoke_O__O(arg_2102) } else { tmp18 = linked_2100.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2099, arg_2102) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, tmp18, nil, T_str__8_)).Ref() } } else {
//line :793:1
																var tmp19 any; var root_2103 any = A_arbace_go_check_types_A_const_238.GetRawRoot__O(); var linked_2104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2103, A_arbace_go_check_types_terms_includes_QMARK__A_fn_class); var ifn_2105 lang.IFn




																if linked_2104 == nil { ifn_2105 = lang.IFn_Cast(root_2103) } else { ifn_2105 = nil }; var arg_2106 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(Tts__5_); var arg_2107 any = V__0_; if linked_2104 == nil { tmp19 = ifn_2105.Invoke_O_O__O(arg_2106, arg_2107) } else { tmp19 = linked_2104.(*A_arbace_go_check_types_terms_includes_QMARK__A).Invoke_O_O_O__O(root_2103, arg_2106, arg_2107) }
//line :793:1
																if jrt.J2g_Truth(tmp19) {




																	return lang.IFn_Cast(comparability__10).Invoke__O() } else {
//line :793:1
																		if A_arbace_go_check_types_A_const_75 != nil {





																			var tmp20 *jrt.RefArray = jrt.ConstRefArray("[0,8,ns18: does not satisfy ns2: (ns12: missing in ns1:)", []*jrt.Class{jrt.String_class}); var tmp21 any; var root_2108 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_2109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2108, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2110 lang.IFn; if linked_2109 == nil { ifn_2110 = lang.IFn_Cast(root_2108) } else { ifn_2110 = nil }; var arg_2111 any = V__0_; if linked_2109 == nil { tmp21 = ifn_2110.Invoke_O__O(arg_2111) } else { tmp21 = linked_2109.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2108, arg_2111) }; var tmp22 any = tmp21; var tmp23 any; var root_2112 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_2113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2112, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2114 lang.IFn; if linked_2113 == nil { ifn_2114 = lang.IFn_Cast(root_2112) } else { ifn_2114 = nil }; var arg_2115 any = V__0_; if linked_2113 == nil { tmp23 = ifn_2114.Invoke_O__O(arg_2115) } else { tmp23 = linked_2113.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2112, arg_2115) }; var tmp24 any = tmp23; var tmp25 any; var root_2116 any = A_arbace_go_check_types_A_const_180.GetRawRoot__O(); var linked_2117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2116, A_arbace_go_check_types_terms_str_A_fn_class); var ifn_2118 lang.IFn
																			if linked_2117 == nil { ifn_2118 = lang.IFn_Cast(root_2116) } else { ifn_2118 = nil }; var arg_2119 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(Tts__5_); if linked_2117 == nil { tmp25 = ifn_2118.Invoke_O__O(arg_2119) } else { tmp25 = linked_2117.(*A_arbace_go_check_types_terms_str_A).Invoke_O_O__O(root_2116, arg_2119) }
//line :799:1
																			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, tmp22, nil, T_str__8_, nil, tmp24, nil, tmp25, nil)).Ref() } else {
//line :793:1
																				return nil } } } } } } else {
//line :776:1
																					return nil } } } } } }







func A_arbace_go_check_types_satisfies_cause_comparability__219000273_A_New_O_O(p0, p1 any) *A_arbace_go_check_types_satisfies_cause_comparability__219000273_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_comparability__219000273_A{}; t.Ctor_O_O(p0, p1); return t }
//line :784:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000273_A) Ctor_O_O(c__Tts, c__V any) { t.F_Tts = c__Tts; t.F_V = c__V }
//line :784:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000273_A) Invoke_O__O(self any) any {
	var tmp1 any; var root_2059 any = A_arbace_go_check_types_A_const_69.GetRawRoot__O(); var linked_2060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2059, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2061 lang.IFn
	if linked_2060 == nil { ifn_2061 = lang.IFn_Cast(root_2059) } else { ifn_2061 = nil }; var arg_2062 any; var tmp2 any = A_arbace_go_check_types_A_const_108; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_go_check_types_A_const_109.Invoke_O__O(t.F_Tts)) {
		arg_2062 = A_arbace_go_check_types_A_const_110.Invoke_O__O(t.F_Tts) } else {
			var root_2063 any = A_arbace_go_check_types_A_const_112.GetRawRoot__O(); var linked_2064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2063, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2065 lang.IFn; if linked_2064 == nil { ifn_2065 = lang.IFn_Cast(root_2063) } else { ifn_2065 = nil }; var arg_2066 any; var tmp3 any = A_arbace_go_check_types_satisfies_cause_comparability__219000273_fn__219000275_A_New(); var tmp4 *jrt.Class; var fncls__2072 *jrt.Class = A_arbace_go_check_types_satisfies_cause_comparability__219000273_fn__219000275_A_fn_class; if fncls__2072 == nil { var fncls__2072d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_check_types_satisfies_cause_comparability__219000273_fn__219000275_A_fn_class = fncls__2072d; tmp4 = fncls__2072d } else { tmp4 = fncls__2072 }; arg_2066 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_2067 any = A_arbace_go_check_types_A_const_109.Invoke_O__O(t.F_Tts); if linked_2064 == nil { arg_2062 = ifn_2065.Invoke_O_O__O(arg_2066, arg_2067) } else { arg_2062 = linked_2064.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2063, arg_2066, arg_2067) } }
//line :786:1
	if linked_2060 == nil { tmp1 = ifn_2061.Invoke_O__O(arg_2062) } else { tmp1 = linked_2060.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2059, arg_2062) }
//line :785:1
	if jrt.J2g_Truth(tmp1) { return nil } else { var tmp5 any; var root_2073 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); var linked_2074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2073, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_2075 lang.IFn




		if linked_2074 == nil { ifn_2075 = lang.IFn_Cast(root_2073) } else { ifn_2075 = nil }; var arg_2076 any = t.F_V; if linked_2074 == nil { tmp5 = ifn_2075.Invoke_O__O(arg_2076) } else { tmp5 = linked_2074.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O__O(root_2073, arg_2076) }
//line :785:1
		if jrt.J2g_Truth(tmp5) { return nil } else { var tmp6 any; var root_2077 any = A_arbace_go_check_types_A_const_236.GetRawRoot__O(); var linked_2078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2077, A_arbace_go_check_types_comparable_QMARK__A_fn_class); var ifn_2079 lang.IFn





			if linked_2078 == nil { ifn_2079 = lang.IFn_Cast(root_2077) } else { ifn_2079 = nil }; var arg_2080 any = t.F_V; if linked_2078 == nil { tmp6 = ifn_2079.Invoke_O__O(arg_2080) } else { tmp6 = linked_2078.(*A_arbace_go_check_types_comparable_QMARK__A).Invoke_O_O__O(root_2077, arg_2080) }
//line :785:1
			if jrt.J2g_Truth(tmp6) { return nil } else { if A_arbace_go_check_types_A_const_75 != nil {






				var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_36); var tmp8 any; var root_2081 any = A_arbace_go_check_types_A_const_118.GetRawRoot__O(); var linked_2082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2081, A_arbace_go_check_types_type_str_A_fn_class); var ifn_2083 lang.IFn; if linked_2082 == nil { ifn_2083 = lang.IFn_Cast(root_2081) } else { ifn_2083 = nil }; var arg_2084 any = t.F_V; if linked_2082 == nil { tmp8 = ifn_2083.Invoke_O__O(arg_2084) } else { tmp8 = linked_2082.(*A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_2081, arg_2084) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8, nil)).Ref() } else {
//line :785:1
					return nil
				}
			} } } }
func A_arbace_go_check_types_satisfies_cause_comparability__219000273_fn__219000275_A_New() *A_arbace_go_check_types_satisfies_cause_comparability__219000273_fn__219000275_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_satisfies_cause_comparability__219000273_fn__219000275_A{}; t.Ctor(); return t }
//line :788:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000273_fn__219000275_A) Ctor() {}
//line :788:1
func (t *A_arbace_go_check_types_satisfies_cause_comparability__219000273_fn__219000275_A) Invoke_O_O__O(self, p__219000274__1 any) any { var vec__219000276__2 any = p__219000274__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000276__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ty__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__219000276__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2068 any = A_arbace_go_check_types_A_const_113.GetRawRoot__O(); var linked_2069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2068, A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class); var ifn_2070 lang.IFn; _ = ___3; if linked_2069 == nil { ifn_2070 = lang.IFn_Cast(root_2068) } else { ifn_2070 = nil }; var arg_2071 any = ty__4; if linked_2069 == nil { return ifn_2070.Invoke_O__O(arg_2071) } else { return linked_2069.(*A_arbace_go_check_types_strictly_comparable_QMARK__A).Invoke_O_O__O(root_2068, arg_2071) } }




















































































type A_arbace_go_check_types_A struct{ jrt.Object }

var A_arbace_go_check_types_A_const_pool *jrt.RefArray

var A_arbace_go_check_types_A_const_0 *lang.Var

var A_arbace_go_check_types_A_const_1 any

var A_arbace_go_check_types_A_const_2 any

var A_arbace_go_check_types_A_const_3 *lang.Var

var A_arbace_go_check_types_A_const_4 any

var A_arbace_go_check_types_A_const_5 *lang.Var

var A_arbace_go_check_types_A_const_6 *lang.Var

var A_arbace_go_check_types_A_const_7 *lang.Var

var A_arbace_go_check_types_A_const_8 *lang.Var

var A_arbace_go_check_types_A_const_9 any

var A_arbace_go_check_types_A_const_10 *lang.Var

var A_arbace_go_check_types_A_const_11 *lang.Keyword

var A_arbace_go_check_types_A_const_12 *lang.Keyword

var A_arbace_go_check_types_A_const_13 *lang.Var

var A_arbace_go_check_types_A_const_14 *lang.Keyword

var A_arbace_go_check_types_A_const_15 any

var A_arbace_go_check_types_A_const_16 *lang.Keyword

var A_arbace_go_check_types_A_const_17 *lang.Keyword

var A_arbace_go_check_types_A_const_18 *lang.Keyword

var A_arbace_go_check_types_A_const_19 *lang.Keyword

var A_arbace_go_check_types_A_const_20 any

var A_arbace_go_check_types_A_const_21 *lang.Keyword

var A_arbace_go_check_types_A_const_22 any

var A_arbace_go_check_types_A_const_23 *lang.Keyword

var A_arbace_go_check_types_A_const_24 any

var A_arbace_go_check_types_A_const_25 *lang.Keyword

var A_arbace_go_check_types_A_const_26 *lang.Keyword

var A_arbace_go_check_types_A_const_27 *lang.Keyword

var A_arbace_go_check_types_A_const_28 *lang.Keyword

var A_arbace_go_check_types_A_const_29 *lang.Keyword

var A_arbace_go_check_types_A_const_30 *lang.Keyword

var A_arbace_go_check_types_A_const_31 *lang.Keyword

var A_arbace_go_check_types_A_const_32 *lang.Keyword

var A_arbace_go_check_types_A_const_33 *lang.Keyword

var A_arbace_go_check_types_A_const_34 *lang.Keyword

var A_arbace_go_check_types_A_const_35 *lang.Keyword

var A_arbace_go_check_types_A_const_36 *lang.Keyword

var A_arbace_go_check_types_A_const_37 *lang.Keyword

var A_arbace_go_check_types_A_const_38 *lang.Keyword

var A_arbace_go_check_types_A_const_39 any

var A_arbace_go_check_types_A_const_40 *lang.Keyword

var A_arbace_go_check_types_A_const_41 *lang.Keyword

var A_arbace_go_check_types_A_const_42 *lang.Keyword

var A_arbace_go_check_types_A_const_43 *lang.Keyword

var A_arbace_go_check_types_A_const_44 any

var A_arbace_go_check_types_A_const_45 *lang.Keyword

var A_arbace_go_check_types_A_const_46 *lang.Keyword

var A_arbace_go_check_types_A_const_47 *lang.Keyword

var A_arbace_go_check_types_A_const_48 *lang.Keyword

var A_arbace_go_check_types_A_const_49 *lang.Keyword

var A_arbace_go_check_types_A_const_50 *lang.Keyword

var A_arbace_go_check_types_A_const_51 *lang.Keyword

var A_arbace_go_check_types_A_const_52 *lang.Var

var A_arbace_go_check_types_A_const_53 *lang.Var

var A_arbace_go_check_types_A_const_54 *lang.Keyword

var A_arbace_go_check_types_A_const_55 *lang.Keyword

var A_arbace_go_check_types_A_const_56 *lang.Var

var A_arbace_go_check_types_A_const_57 *lang.Var

var A_arbace_go_check_types_A_const_58 *lang.Var

var A_arbace_go_check_types_A_const_59 *lang.Var

var A_arbace_go_check_types_A_const_60 *lang.Keyword

var A_arbace_go_check_types_A_const_61 *lang.Var

var A_arbace_go_check_types_A_const_62 *lang.Keyword

var A_arbace_go_check_types_A_const_63 *lang.Var

var A_arbace_go_check_types_A_const_64 *lang.Keyword

var A_arbace_go_check_types_A_const_65 *lang.Var

var A_arbace_go_check_types_A_const_66 *lang.Var

var A_arbace_go_check_types_A_const_67 *lang.Keyword

var A_arbace_go_check_types_A_const_68 *lang.Var

var A_arbace_go_check_types_A_const_69 *lang.Var

var A_arbace_go_check_types_A_const_70 *lang.Keyword

var A_arbace_go_check_types_A_const_71 *lang.Keyword

var A_arbace_go_check_types_A_const_72 *lang.Var

var A_arbace_go_check_types_A_const_73 *lang.Var

var A_arbace_go_check_types_A_const_74 *lang.Var

var A_arbace_go_check_types_A_const_75 *lang.Keyword

var A_arbace_go_check_types_A_const_76 *lang.Var

var A_arbace_go_check_types_A_const_77 *lang.Var

var A_arbace_go_check_types_A_const_78 *lang.Var

var A_arbace_go_check_types_A_const_79 *lang.Var

var A_arbace_go_check_types_A_const_80 *lang.Var

var A_arbace_go_check_types_A_const_81 *lang.Var

var A_arbace_go_check_types_A_const_82 *lang.Var

var A_arbace_go_check_types_A_const_83 *lang.Var

var A_arbace_go_check_types_A_const_84 any

var A_arbace_go_check_types_A_const_85 *lang.Var

var A_arbace_go_check_types_A_const_86 *lang.Keyword

var A_arbace_go_check_types_A_const_87 *lang.Keyword

var A_arbace_go_check_types_A_const_88 *lang.Var

var A_arbace_go_check_types_A_const_89 *lang.Var

var A_arbace_go_check_types_A_const_90 *lang.Var

var A_arbace_go_check_types_A_const_91 *lang.Var

var A_arbace_go_check_types_A_const_92 *lang.Var

var A_arbace_go_check_types_A_const_93 any

var A_arbace_go_check_types_A_const_94 *lang.Var

var A_arbace_go_check_types_A_const_95 *lang.Keyword

var A_arbace_go_check_types_A_const_96 *lang.Keyword

var A_arbace_go_check_types_A_const_97 *lang.Keyword

var A_arbace_go_check_types_A_const_98 *lang.Keyword

var A_arbace_go_check_types_A_const_99 *lang.Var

var A_arbace_go_check_types_A_const_100 *lang.Keyword

var A_arbace_go_check_types_A_const_101 any

var A_arbace_go_check_types_A_const_102 *lang.Var

var A_arbace_go_check_types_A_const_103 *lang.Keyword

var A_arbace_go_check_types_A_const_104 *lang.Var

var A_arbace_go_check_types_A_const_105 *lang.Keyword

var A_arbace_go_check_types_A_const_106 *lang.Keyword

var A_arbace_go_check_types_A_const_107 *lang.Keyword

var A_arbace_go_check_types_A_const_108 *lang.Keyword

var A_arbace_go_check_types_A_const_109 *lang.Keyword

var A_arbace_go_check_types_A_const_110 *lang.Keyword

var A_arbace_go_check_types_A_const_111 *lang.Var

var A_arbace_go_check_types_A_const_112 *lang.Var

var A_arbace_go_check_types_A_const_113 *lang.Var

var A_arbace_go_check_types_A_const_114 *lang.Var

var A_arbace_go_check_types_A_const_115 *lang.Var

var A_arbace_go_check_types_A_const_116 *lang.Var

var A_arbace_go_check_types_A_const_117 *lang.Var

var A_arbace_go_check_types_A_const_118 *lang.Var

var A_arbace_go_check_types_A_const_119 *lang.Var

var A_arbace_go_check_types_A_const_120 *lang.Keyword

var A_arbace_go_check_types_A_const_121 *lang.Var

var A_arbace_go_check_types_A_const_122 *lang.Var

var A_arbace_go_check_types_A_const_123 *lang.Var

var A_arbace_go_check_types_A_const_124 *lang.Var

var A_arbace_go_check_types_A_const_125 *lang.Var

var A_arbace_go_check_types_A_const_126 *lang.Keyword

var A_arbace_go_check_types_A_const_127 *lang.Var

var A_arbace_go_check_types_A_const_128 *lang.Var

var A_arbace_go_check_types_A_const_129 *lang.Var

var A_arbace_go_check_types_A_const_130 *lang.Var

var A_arbace_go_check_types_A_const_131 *lang.Var

var A_arbace_go_check_types_A_const_132 *lang.Var

var A_arbace_go_check_types_A_const_133 *lang.Var

var A_arbace_go_check_types_A_const_134 *lang.Var

var A_arbace_go_check_types_A_const_135 *lang.Var

var A_arbace_go_check_types_A_const_136 *lang.Var

var A_arbace_go_check_types_A_const_137 *lang.Var

var A_arbace_go_check_types_A_const_138 *lang.Var

var A_arbace_go_check_types_A_const_139 *lang.Var

var A_arbace_go_check_types_A_const_140 *lang.Var

var A_arbace_go_check_types_A_const_141 *lang.Var

var A_arbace_go_check_types_A_const_142 *lang.Var

var A_arbace_go_check_types_A_const_143 *lang.Var

var A_arbace_go_check_types_A_const_144 *lang.Var

var A_arbace_go_check_types_A_const_145 *lang.Keyword

var A_arbace_go_check_types_A_const_146 *lang.Var

var A_arbace_go_check_types_A_const_147 *lang.Keyword

var A_arbace_go_check_types_A_const_148 *lang.Var

var A_arbace_go_check_types_A_const_149 *lang.Var

var A_arbace_go_check_types_A_const_150 any

var A_arbace_go_check_types_A_const_151 *lang.Var

var A_arbace_go_check_types_A_const_152 *lang.Var

var A_arbace_go_check_types_A_const_153 *lang.Var

var A_arbace_go_check_types_A_const_154 *lang.Var

var A_arbace_go_check_types_A_const_155 *lang.Var

var A_arbace_go_check_types_A_const_156 *lang.Var

var A_arbace_go_check_types_A_const_157 *lang.Var

var A_arbace_go_check_types_A_const_158 any

var A_arbace_go_check_types_A_const_159 *lang.Keyword

var A_arbace_go_check_types_A_const_160 any

var A_arbace_go_check_types_A_const_161 any

var A_arbace_go_check_types_A_const_162 *lang.Var

var A_arbace_go_check_types_A_const_163 *lang.Var

var A_arbace_go_check_types_A_const_164 *lang.Var

var A_arbace_go_check_types_A_const_165 *lang.Var

var A_arbace_go_check_types_A_const_166 *lang.Var

var A_arbace_go_check_types_A_const_167 *lang.Var

var A_arbace_go_check_types_A_const_168 *lang.Keyword

var A_arbace_go_check_types_A_const_169 *lang.Var

var A_arbace_go_check_types_A_const_170 *lang.Keyword

var A_arbace_go_check_types_A_const_171 *lang.Var

var A_arbace_go_check_types_A_const_172 *lang.Keyword

var A_arbace_go_check_types_A_const_173 *lang.Keyword

var A_arbace_go_check_types_A_const_174 *lang.Keyword

var A_arbace_go_check_types_A_const_175 *lang.Var

var A_arbace_go_check_types_A_const_176 *lang.Var

var A_arbace_go_check_types_A_const_177 *lang.Var

var A_arbace_go_check_types_A_const_178 any

var A_arbace_go_check_types_A_const_179 *lang.Var

var A_arbace_go_check_types_A_const_180 *lang.Var

var A_arbace_go_check_types_A_const_181 *lang.Keyword

var A_arbace_go_check_types_A_const_182 *lang.Keyword

var A_arbace_go_check_types_A_const_183 *lang.Var

var A_arbace_go_check_types_A_const_184 any

var A_arbace_go_check_types_A_const_185 *lang.Var

var A_arbace_go_check_types_A_const_186 *lang.Var

var A_arbace_go_check_types_A_const_187 *lang.Var

var A_arbace_go_check_types_A_const_188 any

var A_arbace_go_check_types_A_const_189 *lang.Var

var A_arbace_go_check_types_A_const_190 *lang.Var

var A_arbace_go_check_types_A_const_191 *lang.Var

var A_arbace_go_check_types_A_const_192 *lang.Var

var A_arbace_go_check_types_A_const_193 *lang.Var

var A_arbace_go_check_types_A_const_194 *lang.Var

var A_arbace_go_check_types_A_const_195 *lang.Keyword

var A_arbace_go_check_types_A_const_196 *lang.Var

var A_arbace_go_check_types_A_const_197 *lang.Var

var A_arbace_go_check_types_A_const_198 *lang.Var

var A_arbace_go_check_types_A_const_199 *lang.Var

var A_arbace_go_check_types_A_const_200 *lang.Var

var A_arbace_go_check_types_A_const_201 *lang.Var

var A_arbace_go_check_types_A_const_202 *lang.Keyword

var A_arbace_go_check_types_A_const_203 *lang.Var

var A_arbace_go_check_types_A_const_204 *lang.Var

var A_arbace_go_check_types_A_const_205 *lang.Var

var A_arbace_go_check_types_A_const_206 *lang.Var

var A_arbace_go_check_types_A_const_207 any

var A_arbace_go_check_types_A_const_208 *lang.Keyword

var A_arbace_go_check_types_A_const_209 *lang.Keyword

var A_arbace_go_check_types_A_const_210 *lang.Var

var A_arbace_go_check_types_A_const_211 *lang.Keyword

var A_arbace_go_check_types_A_const_212 *lang.Keyword

var A_arbace_go_check_types_A_const_213 *lang.Keyword

var A_arbace_go_check_types_A_const_214 *lang.Keyword

var A_arbace_go_check_types_A_const_215 any

var A_arbace_go_check_types_A_const_216 *lang.Keyword

var A_arbace_go_check_types_A_const_217 any

var A_arbace_go_check_types_A_const_218 *lang.Keyword

var A_arbace_go_check_types_A_const_219 *lang.Keyword

var A_arbace_go_check_types_A_const_220 *lang.Keyword

var A_arbace_go_check_types_A_const_221 *lang.Var

var A_arbace_go_check_types_A_const_222 *lang.Keyword

var A_arbace_go_check_types_A_const_223 *lang.Var

var A_arbace_go_check_types_A_const_224 *lang.Var

var A_arbace_go_check_types_A_const_225 *lang.Var

var A_arbace_go_check_types_A_const_226 *lang.Keyword

var A_arbace_go_check_types_A_const_227 *lang.Keyword

var A_arbace_go_check_types_A_const_228 *lang.Keyword

var A_arbace_go_check_types_A_const_229 *lang.Keyword

var A_arbace_go_check_types_A_const_230 *lang.Var

var A_arbace_go_check_types_A_const_231 *lang.Var

var A_arbace_go_check_types_A_const_232 *lang.Keyword

var A_arbace_go_check_types_A_const_233 *lang.Var

var A_arbace_go_check_types_A_const_234 *lang.Var

var A_arbace_go_check_types_A_const_235 *lang.Var

var A_arbace_go_check_types_A_const_236 *lang.Var

var A_arbace_go_check_types_A_const_237 *lang.Var

var A_arbace_go_check_types_A_const_238 *lang.Var

var A_arbace_go_check_types_A_init jrt.ClassInit

func A_arbace_go_check_types_A_Init() { if !A_arbace_go_check_types_A_init.Done() { A_arbace_go_check_types_A_init.Run(A_arbace_go_check_types_A_clinit) } }

func A_arbace_go_check_types_A_clinit() { A_arbace_go_check_types_A_clinit_p0(); A_arbace_go_check_types_A_clinit_p1(); A_arbace_go_check_types_A_clinit_p2(); A_arbace_go_check_types_A_clinit_p3(); A_arbace_go_check_types_A_clinit_p4(); A_arbace_go_check_types_A_clinit_p5(); A_arbace_go_check_types_A_clinit_p6(); A_arbace_go_check_types_A_clinit_p7(); A_arbace_go_check_types_A_clinit_p8(); A_arbace_go_check_types_A_clinit_p9(); A_arbace_go_check_types_A_clinit_p10(); A_arbace_go_check_types_A_clinit_p11(); A_arbace_go_check_types_A_clinit_p12(); A_arbace_go_check_types_A_clinit_p13(); A_arbace_go_check_types_A_clinit_p14(); A_arbace_go_check_types_A_clinit_p15(); A_arbace_go_check_types_A_clinit_p16(); A_arbace_go_check_types_A_clinit_p17(); A_arbace_go_check_types_A_clinit_p18(); A_arbace_go_check_types_A_clinit_p19() }

func A_arbace_go_check_types_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_types_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 333); A_arbace_go_check_types_A_const_0 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[94]); A_arbace_go_check_types_A_const_1 = A_arbace_go_check_types_A_const_pool.A[95]; A_arbace_go_check_types_A_const_2 = A_arbace_go_check_types_A_const_pool.A[96]; A_arbace_go_check_types_A_const_3 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[97]); A_arbace_go_check_types_A_const_4 = A_arbace_go_check_types_A_const_pool.A[98]; A_arbace_go_check_types_A_const_5 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[99]); A_arbace_go_check_types_A_const_6 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[100]); A_arbace_go_check_types_A_const_7 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[101]); A_arbace_go_check_types_A_const_8 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[102]); A_arbace_go_check_types_A_const_9 = A_arbace_go_check_types_A_const_pool.A[103]; A_arbace_go_check_types_A_const_10 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[104]); A_arbace_go_check_types_A_const_11 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[105]) }

func A_arbace_go_check_types_A_clinit_p1() { A_arbace_go_check_types_A_const_12 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[106]); A_arbace_go_check_types_A_const_13 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[107]); A_arbace_go_check_types_A_const_14 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[108]); A_arbace_go_check_types_A_const_15 = A_arbace_go_check_types_A_const_pool.A[109]; A_arbace_go_check_types_A_const_16 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[110]); A_arbace_go_check_types_A_const_17 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[111]); A_arbace_go_check_types_A_const_18 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[112]); A_arbace_go_check_types_A_const_19 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[113]); A_arbace_go_check_types_A_const_20 = A_arbace_go_check_types_A_const_pool.A[114]; A_arbace_go_check_types_A_const_21 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[115]); A_arbace_go_check_types_A_const_22 = A_arbace_go_check_types_A_const_pool.A[116]; A_arbace_go_check_types_A_const_23 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[117]); A_arbace_go_check_types_A_const_24 = A_arbace_go_check_types_A_const_pool.A[118] }

func A_arbace_go_check_types_A_clinit_p2() { A_arbace_go_check_types_A_const_25 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[119]); A_arbace_go_check_types_A_const_26 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[120]); A_arbace_go_check_types_A_const_27 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[121]); A_arbace_go_check_types_A_const_28 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[122]); A_arbace_go_check_types_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[123]); A_arbace_go_check_types_A_const_30 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[124]); A_arbace_go_check_types_A_const_31 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[125]); A_arbace_go_check_types_A_const_32 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[126]); A_arbace_go_check_types_A_const_33 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[127]); A_arbace_go_check_types_A_const_34 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[128]); A_arbace_go_check_types_A_const_35 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[129]); A_arbace_go_check_types_A_const_36 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[130]) }

func A_arbace_go_check_types_A_clinit_p3() { A_arbace_go_check_types_A_const_37 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[131]); A_arbace_go_check_types_A_const_38 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[132]); A_arbace_go_check_types_A_const_39 = A_arbace_go_check_types_A_const_pool.A[133]; A_arbace_go_check_types_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[134]); A_arbace_go_check_types_A_const_41 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[135]); A_arbace_go_check_types_A_const_42 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[136]); A_arbace_go_check_types_A_const_43 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[137]); A_arbace_go_check_types_A_const_44 = A_arbace_go_check_types_A_const_pool.A[138]; A_arbace_go_check_types_A_const_45 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[139]); A_arbace_go_check_types_A_const_46 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[140]); A_arbace_go_check_types_A_const_47 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[141]); A_arbace_go_check_types_A_const_48 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[142]) }

func A_arbace_go_check_types_A_clinit_p4() { A_arbace_go_check_types_A_const_49 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[143]); A_arbace_go_check_types_A_const_50 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[144]); A_arbace_go_check_types_A_const_51 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[145]); A_arbace_go_check_types_A_const_52 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[146]); A_arbace_go_check_types_A_const_53 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[147]); A_arbace_go_check_types_A_const_54 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[148]); A_arbace_go_check_types_A_const_55 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[149]); A_arbace_go_check_types_A_const_56 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[150]); A_arbace_go_check_types_A_const_57 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[151]); A_arbace_go_check_types_A_const_58 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[152]); A_arbace_go_check_types_A_const_59 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[153]); A_arbace_go_check_types_A_const_60 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[154]) }

func A_arbace_go_check_types_A_clinit_p5() { A_arbace_go_check_types_A_const_61 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[155]); A_arbace_go_check_types_A_const_62 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[156]); A_arbace_go_check_types_A_const_63 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[157]); A_arbace_go_check_types_A_const_64 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[158]); A_arbace_go_check_types_A_const_65 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[159]); A_arbace_go_check_types_A_const_66 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[160]); A_arbace_go_check_types_A_const_67 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[161]); A_arbace_go_check_types_A_const_68 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[162]); A_arbace_go_check_types_A_const_69 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[163]); A_arbace_go_check_types_A_const_70 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[164]); A_arbace_go_check_types_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[165]); A_arbace_go_check_types_A_const_72 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[166]) }

func A_arbace_go_check_types_A_clinit_p6() { A_arbace_go_check_types_A_const_73 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[167]); A_arbace_go_check_types_A_const_74 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[168]); A_arbace_go_check_types_A_const_75 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[169]); A_arbace_go_check_types_A_const_76 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[170]); A_arbace_go_check_types_A_const_77 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[171]); A_arbace_go_check_types_A_const_78 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[172]); A_arbace_go_check_types_A_const_79 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[173]); A_arbace_go_check_types_A_const_80 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[174]); A_arbace_go_check_types_A_const_81 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[175]); A_arbace_go_check_types_A_const_82 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[176]); A_arbace_go_check_types_A_const_83 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[177]); A_arbace_go_check_types_A_const_84 = A_arbace_go_check_types_A_const_pool.A[178] }

func A_arbace_go_check_types_A_clinit_p7() { A_arbace_go_check_types_A_const_85 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[179]); A_arbace_go_check_types_A_const_86 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[180]); A_arbace_go_check_types_A_const_87 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[181]); A_arbace_go_check_types_A_const_88 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[182]); A_arbace_go_check_types_A_const_89 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[183]); A_arbace_go_check_types_A_const_90 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[184]); A_arbace_go_check_types_A_const_91 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[185]); A_arbace_go_check_types_A_const_92 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[186]); A_arbace_go_check_types_A_const_93 = A_arbace_go_check_types_A_const_pool.A[187]; A_arbace_go_check_types_A_const_94 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[188]); A_arbace_go_check_types_A_const_95 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[189]); A_arbace_go_check_types_A_const_96 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[190]) }

func A_arbace_go_check_types_A_clinit_p8() { A_arbace_go_check_types_A_const_97 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[191]); A_arbace_go_check_types_A_const_98 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[192]); A_arbace_go_check_types_A_const_99 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[193]); A_arbace_go_check_types_A_const_100 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[194]); A_arbace_go_check_types_A_const_101 = A_arbace_go_check_types_A_const_pool.A[195]; A_arbace_go_check_types_A_const_102 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[196]); A_arbace_go_check_types_A_const_103 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[197]); A_arbace_go_check_types_A_const_104 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[198]); A_arbace_go_check_types_A_const_105 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[199]); A_arbace_go_check_types_A_const_106 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[200]); A_arbace_go_check_types_A_const_107 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[201]); A_arbace_go_check_types_A_const_108 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[202]) }

func A_arbace_go_check_types_A_clinit_p9() { A_arbace_go_check_types_A_const_109 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[203]); A_arbace_go_check_types_A_const_110 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[204]); A_arbace_go_check_types_A_const_111 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[205]); A_arbace_go_check_types_A_const_112 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[206]); A_arbace_go_check_types_A_const_113 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[207]); A_arbace_go_check_types_A_const_114 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[208]); A_arbace_go_check_types_A_const_115 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[209]); A_arbace_go_check_types_A_const_116 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[210]); A_arbace_go_check_types_A_const_117 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[211]); A_arbace_go_check_types_A_const_118 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[212]); A_arbace_go_check_types_A_const_119 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[213]); A_arbace_go_check_types_A_const_120 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[214]) }

func A_arbace_go_check_types_A_clinit_p10() { A_arbace_go_check_types_A_const_121 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[215]); A_arbace_go_check_types_A_const_122 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[216]); A_arbace_go_check_types_A_const_123 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[217]); A_arbace_go_check_types_A_const_124 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[218]); A_arbace_go_check_types_A_const_125 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[219]); A_arbace_go_check_types_A_const_126 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[220]); A_arbace_go_check_types_A_const_127 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[221]); A_arbace_go_check_types_A_const_128 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[222]); A_arbace_go_check_types_A_const_129 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[223]); A_arbace_go_check_types_A_const_130 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[224]); A_arbace_go_check_types_A_const_131 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[225]); A_arbace_go_check_types_A_const_132 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[226]) }

func A_arbace_go_check_types_A_clinit_p11() { A_arbace_go_check_types_A_const_133 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[227]); A_arbace_go_check_types_A_const_134 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[228]); A_arbace_go_check_types_A_const_135 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[229]); A_arbace_go_check_types_A_const_136 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[230]); A_arbace_go_check_types_A_const_137 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[231]); A_arbace_go_check_types_A_const_138 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[232]); A_arbace_go_check_types_A_const_139 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[233]); A_arbace_go_check_types_A_const_140 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[234]); A_arbace_go_check_types_A_const_141 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[235]); A_arbace_go_check_types_A_const_142 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[236]); A_arbace_go_check_types_A_const_143 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[237]); A_arbace_go_check_types_A_const_144 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[238]) }

func A_arbace_go_check_types_A_clinit_p12() { A_arbace_go_check_types_A_const_145 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[239]); A_arbace_go_check_types_A_const_146 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[240]); A_arbace_go_check_types_A_const_147 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[241]); A_arbace_go_check_types_A_const_148 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[242]); A_arbace_go_check_types_A_const_149 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[243]); A_arbace_go_check_types_A_const_150 = A_arbace_go_check_types_A_const_pool.A[244]; A_arbace_go_check_types_A_const_151 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[245]); A_arbace_go_check_types_A_const_152 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[246]); A_arbace_go_check_types_A_const_153 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[247]); A_arbace_go_check_types_A_const_154 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[248]); A_arbace_go_check_types_A_const_155 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[249]); A_arbace_go_check_types_A_const_156 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[250]) }

func A_arbace_go_check_types_A_clinit_p13() { A_arbace_go_check_types_A_const_157 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[251]); A_arbace_go_check_types_A_const_158 = A_arbace_go_check_types_A_const_pool.A[252]; A_arbace_go_check_types_A_const_159 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[253]); A_arbace_go_check_types_A_const_160 = A_arbace_go_check_types_A_const_pool.A[254]; A_arbace_go_check_types_A_const_161 = A_arbace_go_check_types_A_const_pool.A[255]; A_arbace_go_check_types_A_const_162 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[256]); A_arbace_go_check_types_A_const_163 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[257]); A_arbace_go_check_types_A_const_164 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[258]); A_arbace_go_check_types_A_const_165 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[259]); A_arbace_go_check_types_A_const_166 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[260]); A_arbace_go_check_types_A_const_167 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[261]); A_arbace_go_check_types_A_const_168 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[262]) }

func A_arbace_go_check_types_A_clinit_p14() { A_arbace_go_check_types_A_const_169 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[263]); A_arbace_go_check_types_A_const_170 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[264]); A_arbace_go_check_types_A_const_171 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[265]); A_arbace_go_check_types_A_const_172 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[266]); A_arbace_go_check_types_A_const_173 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[267]); A_arbace_go_check_types_A_const_174 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[268]); A_arbace_go_check_types_A_const_175 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[269]); A_arbace_go_check_types_A_const_176 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[270]); A_arbace_go_check_types_A_const_177 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[271]); A_arbace_go_check_types_A_const_178 = A_arbace_go_check_types_A_const_pool.A[272]; A_arbace_go_check_types_A_const_179 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[273]); A_arbace_go_check_types_A_const_180 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[274]) }

func A_arbace_go_check_types_A_clinit_p15() { A_arbace_go_check_types_A_const_181 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[275]); A_arbace_go_check_types_A_const_182 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[276]); A_arbace_go_check_types_A_const_183 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[277]); A_arbace_go_check_types_A_const_184 = A_arbace_go_check_types_A_const_pool.A[278]; A_arbace_go_check_types_A_const_185 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[279]); A_arbace_go_check_types_A_const_186 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[280]); A_arbace_go_check_types_A_const_187 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[281]); A_arbace_go_check_types_A_const_188 = A_arbace_go_check_types_A_const_pool.A[282]; A_arbace_go_check_types_A_const_189 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[283]); A_arbace_go_check_types_A_const_190 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[284]); A_arbace_go_check_types_A_const_191 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[285]); A_arbace_go_check_types_A_const_192 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[286]) }

func A_arbace_go_check_types_A_clinit_p16() { A_arbace_go_check_types_A_const_193 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[287]); A_arbace_go_check_types_A_const_194 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[288]); A_arbace_go_check_types_A_const_195 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[289]); A_arbace_go_check_types_A_const_196 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[290]); A_arbace_go_check_types_A_const_197 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[291]); A_arbace_go_check_types_A_const_198 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[292]); A_arbace_go_check_types_A_const_199 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[293]); A_arbace_go_check_types_A_const_200 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[294]); A_arbace_go_check_types_A_const_201 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[295]); A_arbace_go_check_types_A_const_202 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[296]); A_arbace_go_check_types_A_const_203 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[297]); A_arbace_go_check_types_A_const_204 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[298]) }

func A_arbace_go_check_types_A_clinit_p17() { A_arbace_go_check_types_A_const_205 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[299]); A_arbace_go_check_types_A_const_206 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[300]); A_arbace_go_check_types_A_const_207 = A_arbace_go_check_types_A_const_pool.A[301]; A_arbace_go_check_types_A_const_208 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[302]); A_arbace_go_check_types_A_const_209 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[303]); A_arbace_go_check_types_A_const_210 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[304]); A_arbace_go_check_types_A_const_211 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[305]); A_arbace_go_check_types_A_const_212 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[306]); A_arbace_go_check_types_A_const_213 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[307]); A_arbace_go_check_types_A_const_214 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[308]); A_arbace_go_check_types_A_const_215 = A_arbace_go_check_types_A_const_pool.A[309]; A_arbace_go_check_types_A_const_216 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[310]) }

func A_arbace_go_check_types_A_clinit_p18() { A_arbace_go_check_types_A_const_217 = A_arbace_go_check_types_A_const_pool.A[311]; A_arbace_go_check_types_A_const_218 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[312]); A_arbace_go_check_types_A_const_219 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[313]); A_arbace_go_check_types_A_const_220 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[314]); A_arbace_go_check_types_A_const_221 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[315]); A_arbace_go_check_types_A_const_222 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[316]); A_arbace_go_check_types_A_const_223 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[317]); A_arbace_go_check_types_A_const_224 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[318]); A_arbace_go_check_types_A_const_225 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[319]); A_arbace_go_check_types_A_const_226 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[320]); A_arbace_go_check_types_A_const_227 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[321]); A_arbace_go_check_types_A_const_228 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[322]) }

func A_arbace_go_check_types_A_clinit_p19() { A_arbace_go_check_types_A_const_229 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[323]); A_arbace_go_check_types_A_const_230 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[324]); A_arbace_go_check_types_A_const_231 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[325]); A_arbace_go_check_types_A_const_232 = lang.Keyword_Cast(A_arbace_go_check_types_A_const_pool.A[326]); A_arbace_go_check_types_A_const_233 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[327]); A_arbace_go_check_types_A_const_234 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[328]); A_arbace_go_check_types_A_const_235 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[329]); A_arbace_go_check_types_A_const_236 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[330]); A_arbace_go_check_types_A_const_237 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[331]); A_arbace_go_check_types_A_const_238 = lang.Var_Cast(A_arbace_go_check_types_A_const_pool.A[332]) }

func A_arbace_go_check_types_A_New() *A_arbace_go_check_types_A { A_arbace_go_check_types_A_Init(); t := &A_arbace_go_check_types_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_A) Ctor() {}

func (t *A_arbace_go_check_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_A_class }

func (t *A_arbace_go_check_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_A); return ok }

func A_arbace_go_check_types_A_Cast(x any) *A_arbace_go_check_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_A_class)) }; return v }



type A_arbace_go_check_types_align_up_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_align_up_A_fn_class *jrt.Class



type A_arbace_go_check_types_alignof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alignof_A_fn_class *jrt.Class



type A_arbace_go_check_types_alignof_fn__219000233_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_alignof_fn__219000233_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_basic_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_basic_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_basic_fn__219000167_A struct{ j2g_header uint64; F_pred any }

var A_arbace_go_check_types_all_basic_fn__219000167_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_boolean_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_boolean_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_complex_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_complex_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_float_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_float_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_integer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_integer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_or_string_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_or_string_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000180_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_numeric_or_string_QMARK__fn__219000180_A_fn_class *jrt.Class



type A_arbace_go_check_types_all_ordered_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_ordered_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_string_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_string_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_all_unsigned_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_all_unsigned_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_basic_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_basic_A_fn_class *jrt.Class



type A_arbace_go_check_types_boolean_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_boolean_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_bound_iface_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_bound_iface_A_fn_class *jrt.Class



type A_arbace_go_check_types_common_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_common_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_comparable_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A struct{ j2g_header uint64; F_seen, F_dynamic any }

var A_arbace_go_check_types_comparable_type_QMARK__fn__219000069_A_fn_class *jrt.Class



type A_arbace_go_check_types_complex_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_complex_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_consolidate_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_consolidate_A_fn_class *jrt.Class



type A_arbace_go_check_types_const_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_const_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_core_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_core_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_default_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_default_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_deref_type_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_deref_type_A_fn_class *jrt.Class



type A_arbace_go_check_types_empty_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_empty_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_eval219000004_A struct{ jrt.Object }

func A_arbace_go_check_types_eval219000004_A_New() *A_arbace_go_check_types_eval219000004_A { t := &A_arbace_go_check_types_eval219000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_eval219000004_A) Ctor() {}

func (t *A_arbace_go_check_types_eval219000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_eval219000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_eval219000004_A_class }

func (t *A_arbace_go_check_types_eval219000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_eval219000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_eval219000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_eval219000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_eval219000004_A); return ok }

func A_arbace_go_check_types_eval219000004_A_Cast(x any) *A_arbace_go_check_types_eval219000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_eval219000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_eval219000004_A_class)) }; return v }



type A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_fn_class *jrt.Class



type A_arbace_go_check_types_eval219000008_A struct{ jrt.Object }

func A_arbace_go_check_types_eval219000008_A_New() *A_arbace_go_check_types_eval219000008_A { t := &A_arbace_go_check_types_eval219000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types_eval219000008_A) Ctor() {}

func (t *A_arbace_go_check_types_eval219000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types_eval219000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types_eval219000008_A_class }

func (t *A_arbace_go_check_types_eval219000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types_eval219000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types_eval219000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types_eval219000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types_eval219000008_A); return ok }

func A_arbace_go_check_types_eval219000008_A_Cast(x any) *A_arbace_go_check_types_eval219000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types_eval219000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types_eval219000008_A_class)) }; return v }



type A_arbace_go_check_types_eval219000008_fn__219000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_eval219000008_fn__219000009_A_fn_class *jrt.Class



type A_arbace_go_check_types_exported_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_exported_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_field_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_field_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_flag_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_flag_A_fn_class *jrt.Class



type A_arbace_go_check_types_float_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_float_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_m__219000013_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_m__219000013_A_fn_class *jrt.Class



type A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_fn__219000012_m__219000013_fn__219000014_A_fn_class *jrt.Class



type A_arbace_go_check_types_has_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_name_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_has_nil_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_nil_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_nil_QMARK__fn__219000048_A_fn_class *jrt.Class



type A_arbace_go_check_types_has_terms_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_has_terms_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_identical_ignore_tags_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_identical_ignore_tags_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_iface_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_iface_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_iface_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_iface_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_ignore_tags_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ignore_tags_A_fn_class *jrt.Class



type A_arbace_go_check_types_ignore_tags_fn__219000056_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ignore_tags_fn__219000056_A_fn_class *jrt.Class



type A_arbace_go_check_types_incomparable_cause_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_incomparable_cause_A_fn_class *jrt.Class



type A_arbace_go_check_types_incomparable_cause_cause__219000073_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_incomparable_cause_cause__219000073_A_fn_class *jrt.Class



type A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A struct{ j2g_header uint64; F_cause, F_seen any }

var A_arbace_go_check_types_incomparable_cause_cause__219000073_fn__219000075_A_fn_class *jrt.Class



type A_arbace_go_check_types_info_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_info_A_fn_class *jrt.Class



type A_arbace_go_check_types_integer_or_float_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_integer_or_float_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_integer_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_integer_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_kind_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_kind_of_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_lookup_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_impl_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_lookup_impl_A_fn_class *jrt.Class



type A_arbace_go_check_types_lookup_impl_fn__219000256_A struct{ j2g_header uint64; F_pkg, F_name any }

var A_arbace_go_check_types_lookup_impl_fn__219000256_A_fn_class *jrt.Class



type A_arbace_go_check_types_make_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_make_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_method_data_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_method_data_A_fn_class *jrt.Class



type A_arbace_go_check_types_method_set_iface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_method_set_iface_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_methods_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_methods_of_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_missing_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_missing_method_fn__219000270_A struct{ j2g_header uint64; F_static, F_V, F_same_QMARK_, F_vu any }

var A_arbace_go_check_types_missing_method_fn__219000270_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_named_method_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_method_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_named_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_named_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_new_named_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_new_named_A_fn_class *jrt.Class



type A_arbace_go_check_types_new_tparam_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_new_tparam_A_fn_class *jrt.Class



type A_arbace_go_check_types_next_id_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_next_id_A_fn_class *jrt.Class



type A_arbace_go_check_types_numeric_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_numeric_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_offsetsof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_offsetsof_A_fn_class *jrt.Class



type A_arbace_go_check_types_ordered_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_ordered_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_params_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_params_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_params_str_fn__219000207_A struct{ j2g_header uint64; F_ps, F_variadic any }

var A_arbace_go_check_types_params_str_fn__219000207_A_fn_class *jrt.Class



type A_arbace_go_check_types_pointer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_pointer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_same_id_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_same_id_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_satisfies_cause_A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_comparability__219000273_A struct{ j2g_header uint64; F_Tts, F_V any }

var A_arbace_go_check_types_satisfies_cause_comparability__219000273_A_fn_class *jrt.Class



type A_arbace_go_check_types_satisfies_cause_comparability__219000273_fn__219000275_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_satisfies_cause_comparability__219000273_fn__219000275_A_fn_class *jrt.Class



type A_arbace_go_check_types_sig_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sig_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_sizeof_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sizeof_A_fn_class *jrt.Class



type A_arbace_go_check_types_sort_methods_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sort_methods_A_fn_class *jrt.Class



type A_arbace_go_check_types_sort_methods_fn__219000266_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sort_methods_fn__219000266_A_fn_class *jrt.Class



type A_arbace_go_check_types_strictly_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_string_type_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_string_type_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_sync_atomic_align64_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_disjoint_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_includes_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_includes_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_intersect_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_intersect_A_fn_class *jrt.Class



type A_arbace_go_check_types_term_subset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_subset_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_term_union_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_term_union_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_includes_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_includes_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_includes_QMARK__fn__219000120_A struct{ j2g_header uint64; F_t any }

var A_arbace_go_check_types_terms_includes_QMARK__fn__219000120_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_intersect_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_A struct{ j2g_header uint64; F_y any }

var A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_A struct{ j2g_header uint64; F_iter__219000102, F_s__219000103, F_y any }

var A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_A struct{ j2g_header uint64; F_a any }

var A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_A struct{ j2g_header uint64; F_iter__219000104, F_s__219000105, F_a any }

var A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_fn__219000112_A struct{ j2g_header uint64; F_b__219000107 any; F_size__1927001038__auto__ int32; F_a, F_c__1927001037__auto__ any }

var A_arbace_go_check_types_terms_intersect_iter__219000102__219000108_fn__219000109_iter__219000104__219000110_fn__219000111_fn__219000112_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_norm_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_norm_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_norm_fn__219000098_A struct{ j2g_header uint64; F_i int64; F_n int32; F_used, F_ts any }

var A_arbace_go_check_types_terms_norm_fn__219000098_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000190__219000194_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_str_iter__219000190__219000194_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_A struct{ j2g_header uint64; F_iter__219000190, F_s__219000191 any }

var A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_fn__219000196_A struct{ j2g_header uint64; F_b__219000193 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_terms_str_iter__219000190__219000194_fn__219000195_fn__219000196_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_subset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_subset_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_subset_QMARK__fn__219000128_A struct{ j2g_header uint64; F_yl any }

var A_arbace_go_check_types_terms_subset_QMARK__fn__219000128_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_superset_of_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_superset_of_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000124_A struct{ j2g_header uint64; F_y any }

var A_arbace_go_check_types_terms_superset_of_QMARK__fn__219000124_A_fn_class *jrt.Class



type A_arbace_go_check_types_terms_union_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_terms_union_A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_iface_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_iface_A_fn_class *jrt.Class



type A_arbace_go_check_types_tparam_tset_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tparam_tset_A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_comparable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A struct{ j2g_header uint64; F_seen any }

var A_arbace_go_check_types_tset_comparable_QMARK__fn__219000061_A_fn_class *jrt.Class



type A_arbace_go_check_types_tset_empty_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_tset_empty_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_type_str_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000219__219000223_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_type_str_iter__219000219__219000223_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_A struct{ j2g_header uint64; F_s__219000220, F_iter__219000219 any }

var A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_A_fn_class *jrt.Class



type A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_fn__219000225_A struct{ j2g_header uint64; F_b__219000222 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_type_str_iter__219000219__219000223_fn__219000224_fn__219000225_A_fn_class *jrt.Class



type A_arbace_go_check_types_typed_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typed_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_all_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_all_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_all_fn__219000157_A struct{ j2g_header uint64; F_f any }

var A_arbace_go_check_types_typeset_all_fn__219000157_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_pairs_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_A struct{ j2g_header uint64; F_s__219000140, F_iter__219000139 any }

var A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_A_fn_class *jrt.Class



type A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_fn__219000145_A struct{ j2g_header uint64; F_b__219000142 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_types_typeset_pairs_iter__219000139__219000143_fn__219000144_fn__219000145_A_fn_class *jrt.Class



type A_arbace_go_check_types_uintptr_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_uintptr_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_under_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_under_A_fn_class *jrt.Class



type A_arbace_go_check_types_under_is_A struct{ j2g_header uint64 }

var A_arbace_go_check_types_under_is_A_fn_class *jrt.Class



type A_arbace_go_check_types_under_is_fn__219000163_A struct{ j2g_header uint64; F_f any }

var A_arbace_go_check_types_under_is_fn__219000163_A_fn_class *jrt.Class



type A_arbace_go_check_types_union_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_union_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_unsafe_pointer_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_unsafe_pointer_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_unsigned_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_unsigned_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_untyped_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_untyped_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_types_update_info_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_update_info_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_types_valid_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_types_valid_QMARK__A_fn_class *jrt.Class
