//line aot_arbace_go_check_types__init.ae:1
package aot_arbace_go_check_types

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_types__init_part0_A_Unit0__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_check_types__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_types__init_part0_A_const_1) }
//line :1:1
func A_arbace_go_check_types__init_part0_A_Unit1__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_check_types__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_2)) }
//line :1:1
func A_arbace_go_check_types__init_part0_A_Unit2__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, nil); A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_go_check_types__init_part0_A_Unit3__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_check_types__init_part0_A_const_1)).Equals_O__Z(A_arbace_go_check_types__init_part0_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_go_check_types_eval219000008_fn__219000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_types_eval219000008_fn__219000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, nil); A_arbace_go_check_types_eval219000008_fn__219000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }
//line :1:1
func A_arbace_go_check_types__init_part0_A_Init__O() any { A_arbace_go_check_types__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_go_check_types__init_part0_A_Load__O() any { A_arbace_go_check_types__init_part0_A_Init(); A_arbace_go_check_types__init_part0_A_Unit0__O(); A_arbace_go_check_types__init_part0_A_Unit1__O(); A_arbace_go_check_types__init_part0_A_Unit2__O(); A_arbace_go_check_types__init_part0_A_Unit3__O(); A_arbace_go_check_types__init_part0_A_Unit4__O(); A_arbace_go_check_types__init_part0_A_Unit5__O(); A_arbace_go_check_types__init_part0_A_Unit6__O(); A_arbace_go_check_types__init_part0_A_Unit7__O(); A_arbace_go_check_types__init_part0_A_Unit8__O(); A_arbace_go_check_types__init_part0_A_Unit9__O(); A_arbace_go_check_types__init_part0_A_Unit10__O(); A_arbace_go_check_types__init_part0_A_Unit11__O(); A_arbace_go_check_types__init_part0_A_Unit12__O(); A_arbace_go_check_types__init_part0_A_Unit13__O(); A_arbace_go_check_types__init_part0_A_Unit14__O(); A_arbace_go_check_types__init_part0_A_Unit15__O(); A_arbace_go_check_types__init_part0_A_Unit16__O(); A_arbace_go_check_types__init_part0_A_Unit17__O(); A_arbace_go_check_types__init_part0_A_Unit18__O(); A_arbace_go_check_types__init_part0_A_Unit19__O(); A_arbace_go_check_types__init_part0_A_Unit20__O(); A_arbace_go_check_types__init_part0_A_Unit21__O(); A_arbace_go_check_types__init_part0_A_Unit22__O(); A_arbace_go_check_types__init_part0_A_Unit23__O(); A_arbace_go_check_types__init_part0_A_Unit24__O(); A_arbace_go_check_types__init_part0_A_Unit25__O(); A_arbace_go_check_types__init_part0_A_Unit26__O(); A_arbace_go_check_types__init_part0_A_Unit27__O(); A_arbace_go_check_types__init_part0_A_Unit28__O(); A_arbace_go_check_types__init_part0_A_Unit29__O(); A_arbace_go_check_types__init_part0_A_Unit30__O(); A_arbace_go_check_types__init_part0_A_Unit31__O(); A_arbace_go_check_types__init_part0_A_Unit32__O(); A_arbace_go_check_types__init_part0_A_Unit33__O(); A_arbace_go_check_types__init_part0_A_Unit34__O(); A_arbace_go_check_types__init_part0_A_Unit35__O(); A_arbace_go_check_types__init_part0_A_Unit36__O(); A_arbace_go_check_types__init_part0_A_Unit37__O(); A_arbace_go_check_types__init_part0_A_Unit38__O(); A_arbace_go_check_types__init_part0_A_Unit39__O(); A_arbace_go_check_types__init_part0_A_Unit40__O(); A_arbace_go_check_types__init_part0_A_Unit41__O(); A_arbace_go_check_types__init_part0_A_Unit42__O(); A_arbace_go_check_types__init_part0_A_Unit43__O(); A_arbace_go_check_types__init_part0_A_Unit44__O(); A_arbace_go_check_types__init_part0_A_Unit45__O(); A_arbace_go_check_types__init_part0_A_Unit46__O(); A_arbace_go_check_types__init_part0_A_Unit47__O(); A_arbace_go_check_types__init_part0_A_Unit48__O(); A_arbace_go_check_types__init_part0_A_Unit49__O(); A_arbace_go_check_types__init_part0_A_Unit50__O(); A_arbace_go_check_types__init_part0_A_Unit51__O(); A_arbace_go_check_types__init_part0_A_Unit52__O(); A_arbace_go_check_types__init_part0_A_Unit53__O(); A_arbace_go_check_types__init_part0_A_Unit54__O(); A_arbace_go_check_types__init_part0_A_Unit55__O(); A_arbace_go_check_types__init_part0_A_Unit56__O(); A_arbace_go_check_types__init_part0_A_Unit57__O(); A_arbace_go_check_types__init_part0_A_Unit58__O(); A_arbace_go_check_types__init_part0_A_Unit59__O(); A_arbace_go_check_types__init_part0_A_Unit60__O(); A_arbace_go_check_types__init_part0_A_Unit61__O(); A_arbace_go_check_types__init_part0_A_Unit62__O(); A_arbace_go_check_types__init_part0_A_Unit63__O(); A_arbace_go_check_types__init_part0_A_Unit64__O(); A_arbace_go_check_types__init_part0_A_Unit65__O(); A_arbace_go_check_types__init_part0_A_Unit66__O(); A_arbace_go_check_types__init_part0_A_Unit67__O(); A_arbace_go_check_types__init_part0_A_Unit68__O(); A_arbace_go_check_types__init_part0_A_Unit69__O(); A_arbace_go_check_types__init_part0_A_Unit70__O(); A_arbace_go_check_types__init_part0_A_Unit71__O(); A_arbace_go_check_types__init_part0_A_Unit72__O(); A_arbace_go_check_types__init_part0_A_Unit73__O(); A_arbace_go_check_types__init_part0_A_Unit74__O(); A_arbace_go_check_types__init_part0_A_Unit75__O(); A_arbace_go_check_types__init_part0_A_Unit76__O(); A_arbace_go_check_types__init_part0_A_Unit77__O(); A_arbace_go_check_types__init_part0_A_Unit78__O(); A_arbace_go_check_types__init_part0_A_Unit79__O(); A_arbace_go_check_types__init_part0_A_Unit80__O(); A_arbace_go_check_types__init_part0_A_Unit81__O(); A_arbace_go_check_types__init_part0_A_Unit82__O(); A_arbace_go_check_types__init_part0_A_Unit83__O(); A_arbace_go_check_types__init_part0_A_Unit84__O(); A_arbace_go_check_types__init_part0_A_Unit85__O(); A_arbace_go_check_types__init_part0_A_Unit86__O(); A_arbace_go_check_types__init_part0_A_Unit87__O(); A_arbace_go_check_types__init_part0_A_Unit88__O(); A_arbace_go_check_types__init_part0_A_Unit89__O(); A_arbace_go_check_types__init_part0_A_Unit90__O(); A_arbace_go_check_types__init_part0_A_Unit91__O(); A_arbace_go_check_types__init_part0_A_Unit92__O(); A_arbace_go_check_types__init_part0_A_Unit93__O(); A_arbace_go_check_types__init_part0_A_Unit94__O(); A_arbace_go_check_types__init_part0_A_Unit95__O(); A_arbace_go_check_types__init_part0_A_Unit96__O(); A_arbace_go_check_types__init_part0_A_Unit97__O(); A_arbace_go_check_types__init_part0_A_Unit98__O(); A_arbace_go_check_types__init_part0_A_Unit99__O(); return nil }



func A_arbace_go_check_types__init_A_Load__O() any { jrt.StartCheck(); A_arbace_go_check_types__init_part0_A_Init__O(); A_arbace_go_check_types__init_part1_A_Init__O(); A_arbace_go_check_types__init_part0_A_Load__O(); A_arbace_go_check_types__init_part1_A_Load__O(); return nil }
















func A_arbace_go_check_types__init_part0_A_Unit4__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_go_check_types_fn__219000012_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_types_fn__219000012_A_fn_class; if

	fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, nil); A_arbace_go_check_types_fn__219000012_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); /*line :22:1*/tmp1.BindRoot_O__V(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_5)); return A_arbace_go_check_types__init_part0_A_const_4 }


















func A_arbace_go_check_types__init_part0_A_Unit5__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); A_arbace_go_check_types__init_part0_A_const_6.BindRoot_O__V(A_arbace_go_check_types__init_part0_A_const_7); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_8)); return A_arbace_go_check_types__init_part0_A_const_6 }



















func A_arbace_go_check_types__init_part0_A_Unit6__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(61, 1); A_arbace_go_check_types__init_part0_A_const_9.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_9; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_10)); return A_arbace_go_check_types__init_part0_A_const_9.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_types__init_part0_A_Unit7__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(65, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_11; tmp1.BindRoot_O__V(jrt.ConcurrentHashMap_New()); var tmp2 *lang.Var = A_arbace_go_check_types__init_part0_A_const_11; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_12)); return A_arbace_go_check_types__init_part0_A_const_11 }




func A_arbace_go_check_types__init_part0_A_Unit8__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(70, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_go_check_types_kw_alias_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_types_kw_alias_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, nil); A_arbace_go_check_types_kw_alias_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_14)); return A_arbace_go_check_types__init_part0_A_const_13 }








func A_arbace_go_check_types__init_part0_A_Unit9__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(79, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_go_check_types_kw_alias_info_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_types_kw_alias_info_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, nil); A_arbace_go_check_types_kw_alias_info_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_16)); return A_arbace_go_check_types__init_part0_A_const_15 }

func A_arbace_go_check_types__init_part0_A_Unit10__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(81, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_go_check_types_canon_kw_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_types_canon_kw_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, nil); A_arbace_go_check_types_canon_kw_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_18)); return A_arbace_go_check_types__init_part0_A_const_17 }







func A_arbace_go_check_types__init_part0_A_Unit11__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_19; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_20)); return A_arbace_go_check_types__init_part0_A_const_19 }

func A_arbace_go_check_types__init_part0_A_Unit12__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(91, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_go_check_types_map_same_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_types_map_same_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, nil); A_arbace_go_check_types_map_same_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_22)); return A_arbace_go_check_types__init_part0_A_const_21 }











func A_arbace_go_check_types__init_part0_A_Unit13__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(103, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_go_check_types_canon_member_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_types_canon_member_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, nil); A_arbace_go_check_types_canon_member_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_24)); return A_arbace_go_check_types__init_part0_A_const_23 }

func A_arbace_go_check_types__init_part0_A_Unit14__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(105, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_go_check_types_canon_vec_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_check_types_canon_vec_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, nil); A_arbace_go_check_types_canon_vec_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_26)); return A_arbace_go_check_types__init_part0_A_const_25 }
















func A_arbace_go_check_types__init_part0_A_Unit15__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(122, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_go_check_types_alias_of_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_check_types_alias_of_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, nil); A_arbace_go_check_types_alias_of_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_28)); return A_arbace_go_check_types__init_part0_A_const_27 }







func A_arbace_go_check_types__init_part0_A_Unit16__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(130, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_go_check_types_unalias_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_check_types_unalias_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, nil); A_arbace_go_check_types_unalias_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_30)); return A_arbace_go_check_types__init_part0_A_const_29 }






func A_arbace_go_check_types__init_part0_A_Unit17__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(137, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_go_check_types_canon_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_check_types_canon_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, false, nil); A_arbace_go_check_types_canon_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_31)); return A_arbace_go_check_types__init_part0_A_const_19 }









func A_arbace_go_check_types__init_part0_A_Unit18__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(147, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_go_check_types_same_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_check_types_same_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_95, false, nil); A_arbace_go_check_types_same_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_33)); return A_arbace_go_check_types__init_part0_A_const_32 }








func A_arbace_go_check_types__init_part0_A_Unit19__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(156, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_34; tmp1.BindRoot_O__V(jrt.AtomicLong_New_J(0)); var tmp2 *lang.Var = A_arbace_go_check_types__init_part0_A_const_34; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_35)); return A_arbace_go_check_types__init_part0_A_const_34 }
func A_arbace_go_check_types__init_part0_A_Unit20__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(157, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_go_check_types_next_id_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_check_types_next_id_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_96, false, nil); A_arbace_go_check_types_next_id_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_37)); return A_arbace_go_check_types__init_part0_A_const_36 }

func A_arbace_go_check_types__init_part0_A_Unit21__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(159, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_go_check_types_named_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_check_types_named_QMARK__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_97, false, nil); A_arbace_go_check_types_named_QMARK__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_39)); return A_arbace_go_check_types__init_part0_A_const_38 }
func A_arbace_go_check_types__init_part0_A_Unit22__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(160, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_go_check_types_tparam_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_types_tparam_QMARK__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, nil); A_arbace_go_check_types_tparam_QMARK__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_41)); return A_arbace_go_check_types__init_part0_A_const_40 }
func A_arbace_go_check_types__init_part0_A_Unit23__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_go_check_types_info_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_check_types_info_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, nil); A_arbace_go_check_types_info_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_43)); return A_arbace_go_check_types__init_part0_A_const_42 }
func A_arbace_go_check_types__init_part0_A_Unit24__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(162, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_44; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__36 any = A_arbace_go_check_types_update_info_BANG__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_check_types_update_info_BANG__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_100, true, nil); A_arbace_go_check_types_update_info_BANG__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__36, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_45)); return A_arbace_go_check_types__init_part0_A_const_44 }

func A_arbace_go_check_types__init_part0_A_Unit25__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_go_check_types_new_named_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_check_types_new_named_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_101, false, nil); A_arbace_go_check_types_new_named_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_47)); return A_arbace_go_check_types__init_part0_A_const_46 }




func A_arbace_go_check_types__init_part0_A_Unit26__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(169, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_go_check_types_new_tparam_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_check_types_new_tparam_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_102, false, nil); A_arbace_go_check_types_new_tparam_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_49)); return A_arbace_go_check_types__init_part0_A_const_48 }




func A_arbace_go_check_types__init_part0_A_Unit27__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(174, 1); A_arbace_go_check_types__init_part0_A_const_50.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_50; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_51)); return A_arbace_go_check_types__init_part0_A_const_50.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_types__init_part0_A_Unit28__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(179, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_52; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_53)); return A_arbace_go_check_types__init_part0_A_const_52 }
//line :179:1
func A_arbace_go_check_types__init_part0_A_Unit29__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(179, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_54; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_55)); return A_arbace_go_check_types__init_part0_A_const_54 }

func A_arbace_go_check_types__init_part0_A_Unit30__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(181, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_go_check_types_named_under_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_check_types_named_under_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_103, false, nil); A_arbace_go_check_types_named_under_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_57)); return A_arbace_go_check_types__init_part0_A_const_56 }














func A_arbace_go_check_types__init_part0_A_Unit31__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(196, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_go_check_types_under_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_check_types_under_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_104, false, nil); A_arbace_go_check_types_under_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_58)); return A_arbace_go_check_types__init_part0_A_const_52 }










func A_arbace_go_check_types__init_part0_A_Unit32__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(207, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_go_check_types_basic_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_check_types_basic_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_105, false, nil); A_arbace_go_check_types_basic_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_60)); return A_arbace_go_check_types__init_part0_A_const_59 }
func A_arbace_go_check_types__init_part0_A_Unit33__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(208, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_go_check_types_flag_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_check_types_flag_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_106, false, nil); A_arbace_go_check_types_flag_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_62)); return A_arbace_go_check_types__init_part0_A_const_61 }
func A_arbace_go_check_types__init_part0_A_Unit34__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(209, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_go_check_types_integer_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_check_types_integer_type_QMARK__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_107, false, nil); A_arbace_go_check_types_integer_type_QMARK__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_64)); return A_arbace_go_check_types__init_part0_A_const_63 }
func A_arbace_go_check_types__init_part0_A_Unit35__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(210, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_go_check_types_unsigned_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_check_types_unsigned_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_108, false, nil); A_arbace_go_check_types_unsigned_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_66)); return A_arbace_go_check_types__init_part0_A_const_65 }
func A_arbace_go_check_types__init_part0_A_Unit36__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(211, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_go_check_types_float_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_check_types_float_type_QMARK__A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_109, false, nil); A_arbace_go_check_types_float_type_QMARK__A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_68)); return A_arbace_go_check_types__init_part0_A_const_67 }
func A_arbace_go_check_types__init_part0_A_Unit37__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(212, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_go_check_types_complex_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_check_types_complex_type_QMARK__A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_110, false, nil); A_arbace_go_check_types_complex_type_QMARK__A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_70)); return A_arbace_go_check_types__init_part0_A_const_69 }
func A_arbace_go_check_types__init_part0_A_Unit38__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(213, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_go_check_types_numeric_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_check_types_numeric_QMARK__A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_111, false, nil); A_arbace_go_check_types_numeric_QMARK__A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_72)); return A_arbace_go_check_types__init_part0_A_const_71 }
func A_arbace_go_check_types__init_part0_A_Unit39__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(214, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_go_check_types_string_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_go_check_types_string_type_QMARK__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_112, false, nil); A_arbace_go_check_types_string_type_QMARK__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_74)); return A_arbace_go_check_types__init_part0_A_const_73 }
func A_arbace_go_check_types__init_part0_A_Unit40__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(215, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_go_check_types_boolean_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_go_check_types_boolean_type_QMARK__A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_113, false, nil); A_arbace_go_check_types_boolean_type_QMARK__A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_76)); return A_arbace_go_check_types__init_part0_A_const_75 }
func A_arbace_go_check_types__init_part0_A_Unit41__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(216, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_77; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_go_check_types_untyped_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_go_check_types_untyped_QMARK__A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_114, false, nil); A_arbace_go_check_types_untyped_QMARK__A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_78)); return A_arbace_go_check_types__init_part0_A_const_77 }
func A_arbace_go_check_types__init_part0_A_Unit42__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(217, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_go_check_types_typed_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_go_check_types_typed_QMARK__A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_115, false, nil); A_arbace_go_check_types_typed_QMARK__A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_80)); return A_arbace_go_check_types__init_part0_A_const_79 }
func A_arbace_go_check_types__init_part0_A_Unit43__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(218, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_go_check_types_const_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_go_check_types_const_type_QMARK__A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_116, false, nil); A_arbace_go_check_types_const_type_QMARK__A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_82)); return A_arbace_go_check_types__init_part0_A_const_81 }



func A_arbace_go_check_types__init_part0_A_Unit44__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(222, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_go_check_types_ordered_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_go_check_types_ordered_QMARK__A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_117, false, nil); A_arbace_go_check_types_ordered_QMARK__A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_84)); return A_arbace_go_check_types__init_part0_A_const_83 }
func A_arbace_go_check_types__init_part0_A_Unit45__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(223, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_go_check_types_interface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_go_check_types_interface_QMARK__A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_118, false, nil); A_arbace_go_check_types_interface_QMARK__A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_86)); return A_arbace_go_check_types__init_part0_A_const_85 }
func A_arbace_go_check_types__init_part0_A_Unit46__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(224, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_87; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_go_check_types_pointer_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_go_check_types_pointer_QMARK__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_119, false, nil); A_arbace_go_check_types_pointer_QMARK__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_88)); return A_arbace_go_check_types__init_part0_A_const_87 }
func A_arbace_go_check_types__init_part0_A_Unit47__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(225, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_89; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_go_check_types_unsafe_pointer_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_go_check_types_unsafe_pointer_QMARK__A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_120, false, nil); A_arbace_go_check_types_unsafe_pointer_QMARK__A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_90)); return A_arbace_go_check_types__init_part0_A_const_89 }
func A_arbace_go_check_types__init_part0_A_Unit48__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(226, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_go_check_types_uintptr_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_go_check_types_uintptr_QMARK__A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_121, false, nil); A_arbace_go_check_types_uintptr_QMARK__A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_92)); return A_arbace_go_check_types__init_part0_A_const_91 }
func A_arbace_go_check_types__init_part0_A_Unit49__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(227, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_93; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_go_check_types_valid_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_go_check_types_valid_QMARK__A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_122, false, nil); A_arbace_go_check_types_valid_QMARK__A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_94)); return A_arbace_go_check_types__init_part0_A_const_93 }
func A_arbace_go_check_types__init_part0_A_Unit50__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(228, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_go_check_types_kind_of_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_go_check_types_kind_of_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_123, false, nil); A_arbace_go_check_types_kind_of_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_96)); return A_arbace_go_check_types__init_part0_A_const_95 }
func A_arbace_go_check_types__init_part0_A_Unit51__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_go_check_types_has_name_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_go_check_types_has_name_QMARK__A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_124, false, nil); A_arbace_go_check_types_has_name_QMARK__A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_98)); return A_arbace_go_check_types__init_part0_A_const_97 }
func A_arbace_go_check_types__init_part0_A_Unit52__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(230, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_99; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_go_check_types_integer_or_float_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_go_check_types_integer_or_float_QMARK__A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_125, false, nil); A_arbace_go_check_types_integer_or_float_QMARK__A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_100)); return A_arbace_go_check_types__init_part0_A_const_99 }

func A_arbace_go_check_types__init_part0_A_Unit53__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_101; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_102)); return A_arbace_go_check_types__init_part0_A_const_101 }

func A_arbace_go_check_types__init_part0_A_Unit54__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(234, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_103; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_go_check_types_has_nil_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_go_check_types_has_nil_QMARK__A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_126, false, nil); A_arbace_go_check_types_has_nil_QMARK__A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_104)); return A_arbace_go_check_types__init_part0_A_const_103 }









func A_arbace_go_check_types__init_part0_A_Unit55__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(244, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_go_check_types_empty_interface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_go_check_types_empty_interface_QMARK__A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_127, false, nil); A_arbace_go_check_types_empty_interface_QMARK__A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_106)); return A_arbace_go_check_types__init_part0_A_const_105 }


func A_arbace_go_check_types__init_part0_A_Unit56__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(247, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_107; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_go_check_types_default_type_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_go_check_types_default_type_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_128, false, nil); A_arbace_go_check_types_default_type_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_108)); return A_arbace_go_check_types__init_part0_A_const_107 }







func A_arbace_go_check_types__init_part0_A_Unit57__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(255, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_109; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_go_check_types_ignore_tags_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_go_check_types_ignore_tags_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_129, false, nil); A_arbace_go_check_types_ignore_tags_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_110)); return A_arbace_go_check_types__init_part0_A_const_109 }















func A_arbace_go_check_types__init_part0_A_Unit58__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(271, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_111; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_go_check_types_identical_ignore_tags_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_go_check_types_identical_ignore_tags_QMARK__A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_130, false, nil); A_arbace_go_check_types_identical_ignore_tags_QMARK__A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_112)); return A_arbace_go_check_types__init_part0_A_const_111 }

func A_arbace_go_check_types__init_part0_A_Unit59__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(273, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_113; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_114)); return A_arbace_go_check_types__init_part0_A_const_113 }
//line :273:1
func A_arbace_go_check_types__init_part0_A_Unit60__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(273, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_115; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_116)); return A_arbace_go_check_types__init_part0_A_const_115 }

func A_arbace_go_check_types__init_part0_A_Unit61__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(275, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_117; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_118)); return A_arbace_go_check_types__init_part0_A_const_117 }
//line :275:1
func A_arbace_go_check_types__init_part0_A_Unit62__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(275, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_119; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_120)); return A_arbace_go_check_types__init_part0_A_const_119 }
//line :275:1
func A_arbace_go_check_types__init_part0_A_Unit63__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(275, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_121; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_122)); return A_arbace_go_check_types__init_part0_A_const_121 }

func A_arbace_go_check_types__init_part0_A_Unit64__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(277, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_go_check_types_tset_comparable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_131, false, nil); A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_124)); return A_arbace_go_check_types__init_part0_A_const_123 }






func A_arbace_go_check_types__init_part0_A_Unit65__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(284, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_go_check_types_comparable_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_go_check_types_comparable_type_QMARK__A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_132, false, nil); A_arbace_go_check_types_comparable_type_QMARK__A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_126)); return A_arbace_go_check_types__init_part0_A_const_125 }




















func A_arbace_go_check_types__init_part0_A_Unit66__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(305, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_119; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_go_check_types_strictly_comparable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_133, false, nil); A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_127)); return A_arbace_go_check_types__init_part0_A_const_119 }

func A_arbace_go_check_types__init_part0_A_Unit67__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(307, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_128; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_go_check_types_incomparable_cause_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_go_check_types_incomparable_cause_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_134, false, nil); A_arbace_go_check_types_incomparable_cause_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_129)); return A_arbace_go_check_types__init_part0_A_const_128 }






















func A_arbace_go_check_types__init_part0_A_Unit68__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(330, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_113; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_go_check_types_comparable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_go_check_types_comparable_QMARK__A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_135, false, nil); A_arbace_go_check_types_comparable_QMARK__A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_130)); return A_arbace_go_check_types__init_part0_A_const_113 }
















func A_arbace_go_check_types__init_part0_A_Unit69__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(347, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_go_check_types_union_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_go_check_types_union_QMARK__A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_136, false, nil); A_arbace_go_check_types_union_QMARK__A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_132)); return A_arbace_go_check_types__init_part0_A_const_131 }

func A_arbace_go_check_types__init_part0_A_Unit70__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(349, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_go_check_types_term_disjoint_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_137, false, nil); A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_134)); return A_arbace_go_check_types__init_part0_A_const_133 }


func A_arbace_go_check_types__init_part0_A_Unit71__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(352, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_135; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_go_check_types_term_union_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_go_check_types_term_union_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_138, false, nil); A_arbace_go_check_types_term_union_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_136)); return A_arbace_go_check_types__init_part0_A_const_135 }





func A_arbace_go_check_types__init_part0_A_Unit72__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(358, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_137; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_go_check_types_term_intersect_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_go_check_types_term_intersect_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_139, false, nil); A_arbace_go_check_types_term_intersect_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_138)); return A_arbace_go_check_types__init_part0_A_const_137 }





func A_arbace_go_check_types__init_part0_A_Unit73__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(364, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_139; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_go_check_types_term_includes_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_go_check_types_term_includes_QMARK__A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_140, false, nil); A_arbace_go_check_types_term_includes_QMARK__A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_140)); return A_arbace_go_check_types__init_part0_A_const_139 }

func A_arbace_go_check_types__init_part0_A_Unit74__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(366, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_141; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_go_check_types_term_subset_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_go_check_types_term_subset_QMARK__A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_141, false, nil); A_arbace_go_check_types_term_subset_QMARK__A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_142)); return A_arbace_go_check_types__init_part0_A_const_141 }

func A_arbace_go_check_types__init_part0_A_Unit75__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(368, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_143; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_go_check_types_terms_norm_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_go_check_types_terms_norm_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_142, false, nil); A_arbace_go_check_types_terms_norm_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_143; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_144)); return A_arbace_go_check_types__init_part0_A_const_143 }



















func A_arbace_go_check_types__init_part0_A_Unit76__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(388, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_145; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_go_check_types_ordered_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_go_check_types_ordered_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_143, false, nil); A_arbace_go_check_types_ordered_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_146)); return A_arbace_go_check_types__init_part0_A_const_145 }




func A_arbace_go_check_types__init_part0_A_Unit77__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(393, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_147; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_go_check_types_terms_union_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_go_check_types_terms_union_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_144, false, nil); A_arbace_go_check_types_terms_union_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_148)); return A_arbace_go_check_types__init_part0_A_const_147 }

func A_arbace_go_check_types__init_part0_A_Unit78__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(395, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_149; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_go_check_types_terms_intersect_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_go_check_types_terms_intersect_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_145, false, nil); A_arbace_go_check_types_terms_intersect_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_150)); return A_arbace_go_check_types__init_part0_A_const_149 }






func A_arbace_go_check_types__init_part0_A_Unit79__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(402, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_151; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_go_check_types_terms_includes_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_go_check_types_terms_includes_QMARK__A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_146, false, nil); A_arbace_go_check_types_terms_includes_QMARK__A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_151; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_152)); return A_arbace_go_check_types__init_part0_A_const_151 }

func A_arbace_go_check_types__init_part0_A_Unit80__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(404, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_153; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_go_check_types_terms_superset_of_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_go_check_types_terms_superset_of_QMARK__A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_147, false, nil); A_arbace_go_check_types_terms_superset_of_QMARK__A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_153; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_154)); return A_arbace_go_check_types__init_part0_A_const_153 }

func A_arbace_go_check_types__init_part0_A_Unit81__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(406, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_155; var tmp2 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_go_check_types_terms_subset_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_go_check_types_terms_subset_QMARK__A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_148, false, nil); A_arbace_go_check_types_terms_subset_QMARK__A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_155; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_156)); return A_arbace_go_check_types__init_part0_A_const_155 }








func A_arbace_go_check_types__init_part0_A_Unit82__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(415, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_157; var tmp2 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_go_check_types_make_tset_A_New(); var tmp3 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_go_check_types_make_tset_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_149, false, nil); A_arbace_go_check_types_make_tset_A_fn_class = fncls__133d; tmp3 = fncls__133d } else { tmp3 = fncls__133 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_157; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_158)); return A_arbace_go_check_types__init_part0_A_const_157 }




func A_arbace_go_check_types__init_part0_A_Unit83__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(420, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__136 any = A_arbace_go_check_types_iface_tset_A_New(); var tmp3 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_go_check_types_iface_tset_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_150, false, nil); A_arbace_go_check_types_iface_tset_A_fn_class = fncls__135d; tmp3 = fncls__135d } else { tmp3 = fncls__135 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_159)); return A_arbace_go_check_types__init_part0_A_const_121 }








func A_arbace_go_check_types__init_part0_A_Unit84__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(429, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_160; var tmp2 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_go_check_types_has_terms_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_go_check_types_has_terms_QMARK__A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_151, false, nil); A_arbace_go_check_types_has_terms_QMARK__A_fn_class = fncls__137d; tmp3 = fncls__137d } else { tmp3 = fncls__137 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_160; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_161)); return A_arbace_go_check_types__init_part0_A_const_160 }




func A_arbace_go_check_types__init_part0_A_Unit85__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(434, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_162; var tmp2 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_go_check_types_tset_empty_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_go_check_types_tset_empty_QMARK__A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_152, false, nil); A_arbace_go_check_types_tset_empty_QMARK__A_fn_class = fncls__139d; tmp3 = fncls__139d } else { tmp3 = fncls__139 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_162; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_163)); return A_arbace_go_check_types__init_part0_A_const_162 }

func A_arbace_go_check_types__init_part0_A_Unit86__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(436, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_164; var tmp2 *lang.Compiler_AOTFn; var fnbody__142 any = A_arbace_go_check_types_method_set_iface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_go_check_types_method_set_iface_QMARK__A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_153, false, nil); A_arbace_go_check_types_method_set_iface_QMARK__A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__142, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_164; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_165)); return A_arbace_go_check_types__init_part0_A_const_164 }





func A_arbace_go_check_types__init_part0_A_Unit87__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(442, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_166; var tmp2 *lang.Compiler_AOTFn; var fnbody__144 any = A_arbace_go_check_types_bound_iface_A_New(); var tmp3 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_go_check_types_bound_iface_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_154, false, nil); A_arbace_go_check_types_bound_iface_A_fn_class = fncls__143d; tmp3 = fncls__143d } else { tmp3 = fncls__143 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__144, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_166; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_167)); return A_arbace_go_check_types__init_part0_A_const_166 }











func A_arbace_go_check_types__init_part0_A_Unit88__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(454, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_go_check_types_tparam_iface_A_New(); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_go_check_types_tparam_iface_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_155, false, nil); A_arbace_go_check_types_tparam_iface_A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_168)); return A_arbace_go_check_types__init_part0_A_const_54 }








func A_arbace_go_check_types__init_part0_A_Unit89__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(463, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_117; var tmp2 *lang.Compiler_AOTFn; var fnbody__148 any = A_arbace_go_check_types_tparam_tset_A_New(); var tmp3 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_go_check_types_tparam_tset_A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_156, false, nil); A_arbace_go_check_types_tparam_tset_A_fn_class = fncls__147d; tmp3 = fncls__147d } else { tmp3 = fncls__147 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__148, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_169)); return A_arbace_go_check_types__init_part0_A_const_117 }

func A_arbace_go_check_types__init_part0_A_Unit90__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(465, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_170; var tmp2 *lang.Compiler_AOTFn; var fnbody__150 any = A_arbace_go_check_types_typeset_pairs_A_New(); var tmp3 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_go_check_types_typeset_pairs_A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_157, false, nil); A_arbace_go_check_types_typeset_pairs_A_fn_class = fncls__149d; tmp3 = fncls__149d } else { tmp3 = fncls__149 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__150, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_170; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_171)); return A_arbace_go_check_types__init_part0_A_const_170 }










func A_arbace_go_check_types__init_part0_A_Unit91__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(476, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_172; var tmp2 *lang.Compiler_AOTFn; var fnbody__152 any = A_arbace_go_check_types_typeset_all_A_New(); var tmp3 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_go_check_types_typeset_all_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_158, false, nil); A_arbace_go_check_types_typeset_all_A_fn_class = fncls__151d; tmp3 = fncls__151d } else { tmp3 = fncls__151 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__152, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_172; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_173)); return A_arbace_go_check_types__init_part0_A_const_172 }




func A_arbace_go_check_types__init_part0_A_Unit92__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(481, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_101; var tmp2 *lang.Compiler_AOTFn; var fnbody__154 any = A_arbace_go_check_types_under_is_A_New(); var tmp3 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_go_check_types_under_is_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_159, false, nil); A_arbace_go_check_types_under_is_A_fn_class = fncls__153d; tmp3 = fncls__153d } else { tmp3 = fncls__153 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__154, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_174)); return A_arbace_go_check_types__init_part0_A_const_101 }





func A_arbace_go_check_types__init_part0_A_Unit93__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(487, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_175; var tmp2 *lang.Compiler_AOTFn; var fnbody__156 any = A_arbace_go_check_types_all_basic_A_New(); var tmp3 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_go_check_types_all_basic_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_160, false, nil); A_arbace_go_check_types_all_basic_A_fn_class = fncls__155d; tmp3 = fncls__155d } else { tmp3 = fncls__155 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__156, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_175; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_176)); return A_arbace_go_check_types__init_part0_A_const_175 }








func A_arbace_go_check_types__init_part0_A_Unit94__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(496, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_177; var tmp2 *lang.Compiler_AOTFn; var fnbody__158 any = A_arbace_go_check_types_all_integer_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_go_check_types_all_integer_QMARK__A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_161, false, nil); A_arbace_go_check_types_all_integer_QMARK__A_fn_class = fncls__157d; tmp3 = fncls__157d } else { tmp3 = fncls__157 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__158, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_177; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_178)); return A_arbace_go_check_types__init_part0_A_const_177 }
func A_arbace_go_check_types__init_part0_A_Unit95__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(497, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_179; var tmp2 *lang.Compiler_AOTFn; var fnbody__160 any = A_arbace_go_check_types_all_unsigned_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_go_check_types_all_unsigned_QMARK__A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_162, false, nil); A_arbace_go_check_types_all_unsigned_QMARK__A_fn_class = fncls__159d; tmp3 = fncls__159d } else { tmp3 = fncls__159 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__160, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_179; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_180)); return A_arbace_go_check_types__init_part0_A_const_179 }
func A_arbace_go_check_types__init_part0_A_Unit96__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(498, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_181; var tmp2 *lang.Compiler_AOTFn; var fnbody__162 any = A_arbace_go_check_types_all_numeric_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_go_check_types_all_numeric_QMARK__A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_163, false, nil); A_arbace_go_check_types_all_numeric_QMARK__A_fn_class = fncls__161d; tmp3 = fncls__161d } else { tmp3 = fncls__161 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__162, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_181; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_182)); return A_arbace_go_check_types__init_part0_A_const_181 }
func A_arbace_go_check_types__init_part0_A_Unit97__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(499, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_183; var tmp2 *lang.Compiler_AOTFn; var fnbody__164 any = A_arbace_go_check_types_all_string_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_go_check_types_all_string_QMARK__A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_164, false, nil); A_arbace_go_check_types_all_string_QMARK__A_fn_class = fncls__163d; tmp3 = fncls__163d } else { tmp3 = fncls__163 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__164, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_183; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_184)); return A_arbace_go_check_types__init_part0_A_const_183 }
func A_arbace_go_check_types__init_part0_A_Unit98__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(500, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_185; var tmp2 *lang.Compiler_AOTFn; var fnbody__166 any = A_arbace_go_check_types_all_boolean_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__165 *jrt.Class = A_arbace_go_check_types_all_boolean_QMARK__A_fn_class; if fncls__165 == nil { var fncls__165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_165, false, nil); A_arbace_go_check_types_all_boolean_QMARK__A_fn_class = fncls__165d; tmp3 = fncls__165d } else { tmp3 = fncls__165 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__166, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_185; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_186)); return A_arbace_go_check_types__init_part0_A_const_185 }
func A_arbace_go_check_types__init_part0_A_Unit99__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(501, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_187; var tmp2 *lang.Compiler_AOTFn; var fnbody__168 any = A_arbace_go_check_types_all_ordered_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__167 *jrt.Class = A_arbace_go_check_types_all_ordered_QMARK__A_fn_class; if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_166, false, nil); A_arbace_go_check_types_all_ordered_QMARK__A_fn_class = fncls__167d; tmp3 = fncls__167d } else { tmp3 = fncls__167 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__168, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_187; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_188)); return A_arbace_go_check_types__init_part0_A_const_187 }
func A_arbace_go_check_types__init_part1_A_Unit100__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(502, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_go_check_types_all_numeric_or_string_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_types_all_numeric_or_string_QMARK__A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_168, false, nil); A_arbace_go_check_types_all_numeric_or_string_QMARK__A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_1)); return A_arbace_go_check_types__init_part1_A_const_0 }
//line :502:1
func A_arbace_go_check_types__init_part1_A_Init__O() any { A_arbace_go_check_types__init_part1_A_Init(); return nil }
//line :502:1
func A_arbace_go_check_types__init_part1_A_Load__O() any { A_arbace_go_check_types__init_part1_A_Init(); A_arbace_go_check_types__init_part1_A_Unit100__O(); A_arbace_go_check_types__init_part1_A_Unit101__O(); A_arbace_go_check_types__init_part1_A_Unit102__O(); A_arbace_go_check_types__init_part1_A_Unit103__O(); A_arbace_go_check_types__init_part1_A_Unit104__O(); A_arbace_go_check_types__init_part1_A_Unit105__O(); A_arbace_go_check_types__init_part1_A_Unit106__O(); A_arbace_go_check_types__init_part1_A_Unit107__O(); A_arbace_go_check_types__init_part1_A_Unit108__O(); A_arbace_go_check_types__init_part1_A_Unit109__O(); A_arbace_go_check_types__init_part1_A_Unit110__O(); A_arbace_go_check_types__init_part1_A_Unit111__O(); A_arbace_go_check_types__init_part1_A_Unit112__O(); A_arbace_go_check_types__init_part1_A_Unit113__O(); A_arbace_go_check_types__init_part1_A_Unit114__O(); A_arbace_go_check_types__init_part1_A_Unit115__O(); A_arbace_go_check_types__init_part1_A_Unit116__O(); A_arbace_go_check_types__init_part1_A_Unit117__O(); A_arbace_go_check_types__init_part1_A_Unit118__O(); A_arbace_go_check_types__init_part1_A_Unit119__O(); A_arbace_go_check_types__init_part1_A_Unit120__O(); A_arbace_go_check_types__init_part1_A_Unit121__O(); A_arbace_go_check_types__init_part1_A_Unit122__O(); A_arbace_go_check_types__init_part1_A_Unit123__O(); A_arbace_go_check_types__init_part1_A_Unit124__O(); A_arbace_go_check_types__init_part1_A_Unit125__O(); A_arbace_go_check_types__init_part1_A_Unit126__O(); A_arbace_go_check_types__init_part1_A_Unit127__O(); A_arbace_go_check_types__init_part1_A_Unit128__O(); A_arbace_go_check_types__init_part1_A_Unit129__O(); A_arbace_go_check_types__init_part1_A_Unit130__O(); A_arbace_go_check_types__init_part1_A_Unit131__O(); A_arbace_go_check_types__init_part1_A_Unit132__O(); A_arbace_go_check_types__init_part1_A_Unit133__O(); A_arbace_go_check_types__init_part1_A_Unit134__O(); A_arbace_go_check_types__init_part1_A_Unit135__O(); A_arbace_go_check_types__init_part1_A_Unit136__O(); A_arbace_go_check_types__init_part1_A_Unit137__O(); return nil }
func A_arbace_go_check_types__init_part1_A_Unit101__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(503, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_go_check_types_all_float_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_types_all_float_QMARK__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_169, false, nil); A_arbace_go_check_types_all_float_QMARK__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_3)); return A_arbace_go_check_types__init_part1_A_const_2 }
func A_arbace_go_check_types__init_part1_A_Unit102__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(504, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_go_check_types_all_complex_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_types_all_complex_QMARK__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_170, false, nil); A_arbace_go_check_types_all_complex_QMARK__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_5)); return A_arbace_go_check_types__init_part1_A_const_4 }

func A_arbace_go_check_types__init_part1_A_Unit103__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(506, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_go_check_types_common_under_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_types_common_under_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_171, false, nil); A_arbace_go_check_types_common_under_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_7)); return A_arbace_go_check_types__init_part1_A_const_6 }
























func A_arbace_go_check_types__init_part1_A_Unit104__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(531, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_go_check_types_core_type_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_types_core_type_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_172, false, nil); A_arbace_go_check_types_core_type_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_9)); return A_arbace_go_check_types__init_part1_A_const_8 }






func A_arbace_go_check_types__init_part1_A_Unit105__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(538, 1); A_arbace_go_check_types__init_part1_A_const_10.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_11)); return A_arbace_go_check_types__init_part1_A_const_10.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_types__init_part1_A_Unit106__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(543, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_13)); return A_arbace_go_check_types__init_part1_A_const_12 }

func A_arbace_go_check_types__init_part1_A_Unit107__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(545, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_go_check_types_terms_str_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_types_terms_str_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_173, false, nil); A_arbace_go_check_types_terms_str_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_15)); return A_arbace_go_check_types__init_part1_A_const_14 }





func A_arbace_go_check_types__init_part1_A_Unit108__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(551, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_go_check_types_params_str_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_types_params_str_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_174, false, nil); A_arbace_go_check_types_params_str_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_17)); return A_arbace_go_check_types__init_part1_A_const_16 }








func A_arbace_go_check_types__init_part1_A_Unit109__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(560, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_go_check_types_sig_str_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_types_sig_str_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_175, false, nil); A_arbace_go_check_types_sig_str_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_19)); return A_arbace_go_check_types__init_part1_A_const_18 }








func A_arbace_go_check_types__init_part1_A_Unit110__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(569, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_go_check_types_field_str_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_check_types_field_str_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_176, false, nil); A_arbace_go_check_types_field_str_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_21)); return A_arbace_go_check_types__init_part1_A_const_20 }



func A_arbace_go_check_types__init_part1_A_Unit111__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(573, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_go_check_types_named_str_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_check_types_named_str_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_177, false, nil); A_arbace_go_check_types_named_str_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_23)); return A_arbace_go_check_types__init_part1_A_const_22 }








func A_arbace_go_check_types__init_part1_A_Unit112__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(582, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_go_check_types_alias_str_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_check_types_alias_str_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_178, false, nil); A_arbace_go_check_types_alias_str_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_25)); return A_arbace_go_check_types__init_part1_A_const_24 }






func A_arbace_go_check_types__init_part1_A_Unit113__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(589, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_go_check_types_type_str_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_check_types_type_str_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_179, false, nil); A_arbace_go_check_types_type_str_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_26)); return A_arbace_go_check_types__init_part1_A_const_12 }



































func A_arbace_go_check_types__init_part1_A_Unit114__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(625, 1); A_arbace_go_check_types__init_part1_A_const_27.BindRoot_O__V(A_arbace_go_check_types__init_part1_A_const_28); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_27; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_29)); return A_arbace_go_check_types__init_part1_A_const_27 }
func A_arbace_go_check_types__init_part1_A_Unit115__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(626, 1); A_arbace_go_check_types__init_part1_A_const_30.BindRoot_O__V(A_arbace_go_check_types__init_part1_A_const_28); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_31)); return A_arbace_go_check_types__init_part1_A_const_30 }

func A_arbace_go_check_types__init_part1_A_Unit116__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(628, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_32; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_33)); return A_arbace_go_check_types__init_part1_A_const_32 }

func A_arbace_go_check_types__init_part1_A_Unit117__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(630, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_go_check_types_align_up_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_check_types_align_up_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_180, false, nil); A_arbace_go_check_types_align_up_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_35)); return A_arbace_go_check_types__init_part1_A_const_34 }




func A_arbace_go_check_types__init_part1_A_Unit118__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(635, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_go_check_types_sync_atomic_align64_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_181, false, nil); A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_37)); return A_arbace_go_check_types__init_part1_A_const_36 }








func A_arbace_go_check_types__init_part1_A_Unit119__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(644, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_go_check_types_alignof_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_check_types_alignof_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_182, false, nil); A_arbace_go_check_types_alignof_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_39)); return A_arbace_go_check_types__init_part1_A_const_38 }















func A_arbace_go_check_types__init_part1_A_Unit120__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(660, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_go_check_types_offsetsof_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_types_offsetsof_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_183, false, nil); A_arbace_go_check_types_offsetsof_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_41)); return A_arbace_go_check_types__init_part1_A_const_40 }















func A_arbace_go_check_types__init_part1_A_Unit121__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(676, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_go_check_types_sizeof_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_check_types_sizeof_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_184, false, nil); A_arbace_go_check_types_sizeof_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_42)); return A_arbace_go_check_types__init_part1_A_const_32 }

































func A_arbace_go_check_types__init_part1_A_Unit122__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(710, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_go_check_types_deref_type_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_check_types_deref_type_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_185, false, nil); A_arbace_go_check_types_deref_type_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_44)); return A_arbace_go_check_types__init_part1_A_const_43 }




func A_arbace_go_check_types__init_part1_A_Unit123__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(715, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_go_check_types_methods_of_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_check_types_methods_of_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_186, false, nil); A_arbace_go_check_types_methods_of_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_46)); return A_arbace_go_check_types__init_part1_A_const_45 }






func A_arbace_go_check_types__init_part1_A_Unit124__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(722, 1); A_arbace_go_check_types__init_part1_A_const_47.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_47; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_48)); return A_arbace_go_check_types__init_part1_A_const_47.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_types__init_part1_A_Unit125__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(726, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_go_check_types_same_id_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_check_types_same_id_QMARK__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_187, false, nil); A_arbace_go_check_types_same_id_QMARK__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_50)); return A_arbace_go_check_types__init_part1_A_const_49 }











func A_arbace_go_check_types__init_part1_A_Unit126__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(738, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_go_check_types_exported_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_check_types_exported_QMARK__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_188, false, nil); A_arbace_go_check_types_exported_QMARK__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_52)); return A_arbace_go_check_types__init_part1_A_const_51 }


func A_arbace_go_check_types__init_part1_A_Unit127__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(741, 1); A_arbace_go_check_types__init_part1_A_const_53.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_53; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_54)); return A_arbace_go_check_types__init_part1_A_const_53.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_types__init_part1_A_Unit128__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(746, 1); A_arbace_go_check_types__init_part1_A_const_55.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_55; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_56)); return A_arbace_go_check_types__init_part1_A_const_55.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_types__init_part1_A_Unit129__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(751, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_go_check_types_named_method_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_check_types_named_method_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_189, false, nil); A_arbace_go_check_types_named_method_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_58)); return A_arbace_go_check_types__init_part1_A_const_57 }











func A_arbace_go_check_types__init_part1_A_Unit130__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(763, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_go_check_types_iface_method_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_check_types_iface_method_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_190, false, nil); A_arbace_go_check_types_iface_method_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_60)); return A_arbace_go_check_types__init_part1_A_const_59 }










func A_arbace_go_check_types__init_part1_A_Unit131__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(774, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_go_check_types_consolidate_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_check_types_consolidate_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_191, false, nil); A_arbace_go_check_types_consolidate_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_62)); return A_arbace_go_check_types__init_part1_A_const_61 }











func A_arbace_go_check_types__init_part1_A_Unit132__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(786, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_go_check_types_lookup_impl_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_check_types_lookup_impl_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_192, false, nil); A_arbace_go_check_types_lookup_impl_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_64)); return A_arbace_go_check_types__init_part1_A_const_63 }



































































func A_arbace_go_check_types__init_part1_A_Unit133__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(854, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_go_check_types_lookup_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_check_types_lookup_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_193, false, nil); A_arbace_go_check_types_lookup_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_66)); return A_arbace_go_check_types__init_part1_A_const_65 }









func A_arbace_go_check_types__init_part1_A_Unit134__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(864, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_go_check_types_sort_methods_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_check_types_sort_methods_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_194, false, nil); A_arbace_go_check_types_sort_methods_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_68)); return A_arbace_go_check_types__init_part1_A_const_67 }




func A_arbace_go_check_types__init_part1_A_Unit135__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(869, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_go_check_types_method_data_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_check_types_method_data_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_195, false, nil); A_arbace_go_check_types_method_data_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_70)); return A_arbace_go_check_types__init_part1_A_const_69 }




func A_arbace_go_check_types__init_part1_A_Unit136__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(874, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_go_check_types_missing_method_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_check_types_missing_method_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_196, false, nil); A_arbace_go_check_types_missing_method_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_72)); return A_arbace_go_check_types__init_part1_A_const_71 }







































func A_arbace_go_check_types__init_part1_A_Unit137__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(914, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_go_check_types_satisfies_cause_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_go_check_types_satisfies_cause_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_197, false, nil); A_arbace_go_check_types_satisfies_cause_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_74)); return A_arbace_go_check_types__init_part1_A_const_73 }



type A_arbace_go_check_types__init_A struct{ jrt.Object }

func A_arbace_go_check_types__init_A_New() *A_arbace_go_check_types__init_A { t := &A_arbace_go_check_types__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types__init_A) Ctor() {}

func (t *A_arbace_go_check_types__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types__init_A_class }

func (t *A_arbace_go_check_types__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types__init_A); return ok }

func A_arbace_go_check_types__init_A_Cast(x any) *A_arbace_go_check_types__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types__init_A_class)) }; return v }



type A_arbace_go_check_types__init_part0_A struct{ jrt.Object }

var A_arbace_go_check_types__init_part0_A_const_pool *jrt.RefArray

var A_arbace_go_check_types__init_part0_A_const_0 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_1 any

var A_arbace_go_check_types__init_part0_A_const_2 any

var A_arbace_go_check_types__init_part0_A_const_3 any

var A_arbace_go_check_types__init_part0_A_const_4 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_5 any

var A_arbace_go_check_types__init_part0_A_const_6 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_7 any

var A_arbace_go_check_types__init_part0_A_const_8 any

var A_arbace_go_check_types__init_part0_A_const_9 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_10 any

var A_arbace_go_check_types__init_part0_A_const_11 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_12 any

var A_arbace_go_check_types__init_part0_A_const_13 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_14 any

var A_arbace_go_check_types__init_part0_A_const_15 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_16 any

var A_arbace_go_check_types__init_part0_A_const_17 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_18 any

var A_arbace_go_check_types__init_part0_A_const_19 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_20 any

var A_arbace_go_check_types__init_part0_A_const_21 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_22 any

var A_arbace_go_check_types__init_part0_A_const_23 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_24 any

var A_arbace_go_check_types__init_part0_A_const_25 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_26 any

var A_arbace_go_check_types__init_part0_A_const_27 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_28 any

var A_arbace_go_check_types__init_part0_A_const_29 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_30 any

var A_arbace_go_check_types__init_part0_A_const_31 any

var A_arbace_go_check_types__init_part0_A_const_32 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_33 any

var A_arbace_go_check_types__init_part0_A_const_34 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_35 any

var A_arbace_go_check_types__init_part0_A_const_36 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_37 any

var A_arbace_go_check_types__init_part0_A_const_38 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_39 any

var A_arbace_go_check_types__init_part0_A_const_40 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_41 any

var A_arbace_go_check_types__init_part0_A_const_42 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_43 any

var A_arbace_go_check_types__init_part0_A_const_44 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_45 any

var A_arbace_go_check_types__init_part0_A_const_46 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_47 any

var A_arbace_go_check_types__init_part0_A_const_48 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_49 any

var A_arbace_go_check_types__init_part0_A_const_50 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_51 any

var A_arbace_go_check_types__init_part0_A_const_52 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_53 any

var A_arbace_go_check_types__init_part0_A_const_54 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_55 any

var A_arbace_go_check_types__init_part0_A_const_56 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_57 any

var A_arbace_go_check_types__init_part0_A_const_58 any

var A_arbace_go_check_types__init_part0_A_const_59 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_60 any

var A_arbace_go_check_types__init_part0_A_const_61 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_62 any

var A_arbace_go_check_types__init_part0_A_const_63 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_64 any

var A_arbace_go_check_types__init_part0_A_const_65 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_66 any

var A_arbace_go_check_types__init_part0_A_const_67 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_68 any

var A_arbace_go_check_types__init_part0_A_const_69 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_70 any

var A_arbace_go_check_types__init_part0_A_const_71 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_72 any

var A_arbace_go_check_types__init_part0_A_const_73 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_74 any

var A_arbace_go_check_types__init_part0_A_const_75 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_76 any

var A_arbace_go_check_types__init_part0_A_const_77 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_78 any

var A_arbace_go_check_types__init_part0_A_const_79 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_80 any

var A_arbace_go_check_types__init_part0_A_const_81 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_82 any

var A_arbace_go_check_types__init_part0_A_const_83 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_84 any

var A_arbace_go_check_types__init_part0_A_const_85 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_86 any

var A_arbace_go_check_types__init_part0_A_const_87 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_88 any

var A_arbace_go_check_types__init_part0_A_const_89 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_90 any

var A_arbace_go_check_types__init_part0_A_const_91 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_92 any

var A_arbace_go_check_types__init_part0_A_const_93 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_94 any

var A_arbace_go_check_types__init_part0_A_const_95 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_96 any

var A_arbace_go_check_types__init_part0_A_const_97 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_98 any

var A_arbace_go_check_types__init_part0_A_const_99 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_100 any

var A_arbace_go_check_types__init_part0_A_const_101 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_102 any

var A_arbace_go_check_types__init_part0_A_const_103 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_104 any

var A_arbace_go_check_types__init_part0_A_const_105 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_106 any

var A_arbace_go_check_types__init_part0_A_const_107 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_108 any

var A_arbace_go_check_types__init_part0_A_const_109 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_110 any

var A_arbace_go_check_types__init_part0_A_const_111 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_112 any

var A_arbace_go_check_types__init_part0_A_const_113 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_114 any

var A_arbace_go_check_types__init_part0_A_const_115 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_116 any

var A_arbace_go_check_types__init_part0_A_const_117 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_118 any

var A_arbace_go_check_types__init_part0_A_const_119 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_120 any

var A_arbace_go_check_types__init_part0_A_const_121 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_122 any

var A_arbace_go_check_types__init_part0_A_const_123 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_124 any

var A_arbace_go_check_types__init_part0_A_const_125 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_126 any

var A_arbace_go_check_types__init_part0_A_const_127 any

var A_arbace_go_check_types__init_part0_A_const_128 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_129 any

var A_arbace_go_check_types__init_part0_A_const_130 any

var A_arbace_go_check_types__init_part0_A_const_131 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_132 any

var A_arbace_go_check_types__init_part0_A_const_133 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_134 any

var A_arbace_go_check_types__init_part0_A_const_135 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_136 any

var A_arbace_go_check_types__init_part0_A_const_137 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_138 any

var A_arbace_go_check_types__init_part0_A_const_139 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_140 any

var A_arbace_go_check_types__init_part0_A_const_141 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_142 any

var A_arbace_go_check_types__init_part0_A_const_143 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_144 any

var A_arbace_go_check_types__init_part0_A_const_145 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_146 any

var A_arbace_go_check_types__init_part0_A_const_147 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_148 any

var A_arbace_go_check_types__init_part0_A_const_149 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_150 any

var A_arbace_go_check_types__init_part0_A_const_151 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_152 any

var A_arbace_go_check_types__init_part0_A_const_153 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_154 any

var A_arbace_go_check_types__init_part0_A_const_155 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_156 any

var A_arbace_go_check_types__init_part0_A_const_157 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_158 any

var A_arbace_go_check_types__init_part0_A_const_159 any

var A_arbace_go_check_types__init_part0_A_const_160 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_161 any

var A_arbace_go_check_types__init_part0_A_const_162 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_163 any

var A_arbace_go_check_types__init_part0_A_const_164 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_165 any

var A_arbace_go_check_types__init_part0_A_const_166 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_167 any

var A_arbace_go_check_types__init_part0_A_const_168 any

var A_arbace_go_check_types__init_part0_A_const_169 any

var A_arbace_go_check_types__init_part0_A_const_170 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_171 any

var A_arbace_go_check_types__init_part0_A_const_172 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_173 any

var A_arbace_go_check_types__init_part0_A_const_174 any

var A_arbace_go_check_types__init_part0_A_const_175 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_176 any

var A_arbace_go_check_types__init_part0_A_const_177 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_178 any

var A_arbace_go_check_types__init_part0_A_const_179 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_180 any

var A_arbace_go_check_types__init_part0_A_const_181 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_182 any

var A_arbace_go_check_types__init_part0_A_const_183 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_184 any

var A_arbace_go_check_types__init_part0_A_const_185 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_186 any

var A_arbace_go_check_types__init_part0_A_const_187 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_188 any

var A_arbace_go_check_types__init_part0_A_init jrt.ClassInit

func A_arbace_go_check_types__init_part0_A_Init() { if !A_arbace_go_check_types__init_part0_A_init.Done() { A_arbace_go_check_types__init_part0_A_init.Run(A_arbace_go_check_types__init_part0_A_clinit) } }

func A_arbace_go_check_types__init_part0_A_clinit() { A_arbace_go_check_types__init_part0_A_clinit_p0(); A_arbace_go_check_types__init_part0_A_clinit_p1(); A_arbace_go_check_types__init_part0_A_clinit_p2(); A_arbace_go_check_types__init_part0_A_clinit_p3(); A_arbace_go_check_types__init_part0_A_clinit_p4(); A_arbace_go_check_types__init_part0_A_clinit_p5(); A_arbace_go_check_types__init_part0_A_clinit_p6(); A_arbace_go_check_types__init_part0_A_clinit_p7(); A_arbace_go_check_types__init_part0_A_clinit_p8(); A_arbace_go_check_types__init_part0_A_clinit_p9(); A_arbace_go_check_types__init_part0_A_clinit_p10(); A_arbace_go_check_types__init_part0_A_clinit_p11(); A_arbace_go_check_types__init_part0_A_clinit_p12(); A_arbace_go_check_types__init_part0_A_clinit_p13(); A_arbace_go_check_types__init_part0_A_clinit_p14() }

func A_arbace_go_check_types__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_types__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_82, 258); A_arbace_go_check_types__init_part0_A_const_0 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[69]); A_arbace_go_check_types__init_part0_A_const_1 = A_arbace_go_check_types__init_part0_A_const_pool.A[70]; A_arbace_go_check_types__init_part0_A_const_2 = A_arbace_go_check_types__init_part0_A_const_pool.A[71]; A_arbace_go_check_types__init_part0_A_const_3 = A_arbace_go_check_types__init_part0_A_const_pool.A[72]; A_arbace_go_check_types__init_part0_A_const_4 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[73]); A_arbace_go_check_types__init_part0_A_const_5 = A_arbace_go_check_types__init_part0_A_const_pool.A[74]; A_arbace_go_check_types__init_part0_A_const_6 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[75]); A_arbace_go_check_types__init_part0_A_const_7 = A_arbace_go_check_types__init_part0_A_const_pool.A[76]; A_arbace_go_check_types__init_part0_A_const_8 = A_arbace_go_check_types__init_part0_A_const_pool.A[77]; A_arbace_go_check_types__init_part0_A_const_9 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[78]); A_arbace_go_check_types__init_part0_A_const_10 = A_arbace_go_check_types__init_part0_A_const_pool.A[79]; A_arbace_go_check_types__init_part0_A_const_11 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[80]); A_arbace_go_check_types__init_part0_A_const_12 = A_arbace_go_check_types__init_part0_A_const_pool.A[81] }

func A_arbace_go_check_types__init_part0_A_clinit_p1() { A_arbace_go_check_types__init_part0_A_const_13 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[82]); A_arbace_go_check_types__init_part0_A_const_14 = A_arbace_go_check_types__init_part0_A_const_pool.A[83]; A_arbace_go_check_types__init_part0_A_const_15 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[84]); A_arbace_go_check_types__init_part0_A_const_16 = A_arbace_go_check_types__init_part0_A_const_pool.A[85]; A_arbace_go_check_types__init_part0_A_const_17 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[86]); A_arbace_go_check_types__init_part0_A_const_18 = A_arbace_go_check_types__init_part0_A_const_pool.A[87]; A_arbace_go_check_types__init_part0_A_const_19 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[88]); A_arbace_go_check_types__init_part0_A_const_20 = A_arbace_go_check_types__init_part0_A_const_pool.A[89]; A_arbace_go_check_types__init_part0_A_const_21 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[90]); A_arbace_go_check_types__init_part0_A_const_22 = A_arbace_go_check_types__init_part0_A_const_pool.A[91]; A_arbace_go_check_types__init_part0_A_const_23 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[92]); A_arbace_go_check_types__init_part0_A_const_24 = A_arbace_go_check_types__init_part0_A_const_pool.A[93]; A_arbace_go_check_types__init_part0_A_const_25 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[94]) }

func A_arbace_go_check_types__init_part0_A_clinit_p2() { A_arbace_go_check_types__init_part0_A_const_26 = A_arbace_go_check_types__init_part0_A_const_pool.A[95]; A_arbace_go_check_types__init_part0_A_const_27 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[96]); A_arbace_go_check_types__init_part0_A_const_28 = A_arbace_go_check_types__init_part0_A_const_pool.A[97]; A_arbace_go_check_types__init_part0_A_const_29 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[98]); A_arbace_go_check_types__init_part0_A_const_30 = A_arbace_go_check_types__init_part0_A_const_pool.A[99]; A_arbace_go_check_types__init_part0_A_const_31 = A_arbace_go_check_types__init_part0_A_const_pool.A[100]; A_arbace_go_check_types__init_part0_A_const_32 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[101]); A_arbace_go_check_types__init_part0_A_const_33 = A_arbace_go_check_types__init_part0_A_const_pool.A[102]; A_arbace_go_check_types__init_part0_A_const_34 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[103]); A_arbace_go_check_types__init_part0_A_const_35 = A_arbace_go_check_types__init_part0_A_const_pool.A[104]; A_arbace_go_check_types__init_part0_A_const_36 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[105]); A_arbace_go_check_types__init_part0_A_const_37 = A_arbace_go_check_types__init_part0_A_const_pool.A[106]; A_arbace_go_check_types__init_part0_A_const_38 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[107]); A_arbace_go_check_types__init_part0_A_const_39 = A_arbace_go_check_types__init_part0_A_const_pool.A[108] }

func A_arbace_go_check_types__init_part0_A_clinit_p3() { A_arbace_go_check_types__init_part0_A_const_40 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[109]); A_arbace_go_check_types__init_part0_A_const_41 = A_arbace_go_check_types__init_part0_A_const_pool.A[110]; A_arbace_go_check_types__init_part0_A_const_42 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[111]); A_arbace_go_check_types__init_part0_A_const_43 = A_arbace_go_check_types__init_part0_A_const_pool.A[112]; A_arbace_go_check_types__init_part0_A_const_44 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[113]); A_arbace_go_check_types__init_part0_A_const_45 = A_arbace_go_check_types__init_part0_A_const_pool.A[114]; A_arbace_go_check_types__init_part0_A_const_46 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[115]); A_arbace_go_check_types__init_part0_A_const_47 = A_arbace_go_check_types__init_part0_A_const_pool.A[116]; A_arbace_go_check_types__init_part0_A_const_48 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[117]); A_arbace_go_check_types__init_part0_A_const_49 = A_arbace_go_check_types__init_part0_A_const_pool.A[118]; A_arbace_go_check_types__init_part0_A_const_50 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[119]); A_arbace_go_check_types__init_part0_A_const_51 = A_arbace_go_check_types__init_part0_A_const_pool.A[120]; A_arbace_go_check_types__init_part0_A_const_52 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[121]) }

func A_arbace_go_check_types__init_part0_A_clinit_p4() { A_arbace_go_check_types__init_part0_A_const_53 = A_arbace_go_check_types__init_part0_A_const_pool.A[122]; A_arbace_go_check_types__init_part0_A_const_54 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[123]); A_arbace_go_check_types__init_part0_A_const_55 = A_arbace_go_check_types__init_part0_A_const_pool.A[124]; A_arbace_go_check_types__init_part0_A_const_56 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[125]); A_arbace_go_check_types__init_part0_A_const_57 = A_arbace_go_check_types__init_part0_A_const_pool.A[126]; A_arbace_go_check_types__init_part0_A_const_58 = A_arbace_go_check_types__init_part0_A_const_pool.A[127]; A_arbace_go_check_types__init_part0_A_const_59 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[128]); A_arbace_go_check_types__init_part0_A_const_60 = A_arbace_go_check_types__init_part0_A_const_pool.A[129]; A_arbace_go_check_types__init_part0_A_const_61 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[130]); A_arbace_go_check_types__init_part0_A_const_62 = A_arbace_go_check_types__init_part0_A_const_pool.A[131]; A_arbace_go_check_types__init_part0_A_const_63 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[132]); A_arbace_go_check_types__init_part0_A_const_64 = A_arbace_go_check_types__init_part0_A_const_pool.A[133]; A_arbace_go_check_types__init_part0_A_const_65 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[134]); A_arbace_go_check_types__init_part0_A_const_66 = A_arbace_go_check_types__init_part0_A_const_pool.A[135] }

func A_arbace_go_check_types__init_part0_A_clinit_p5() { A_arbace_go_check_types__init_part0_A_const_67 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[136]); A_arbace_go_check_types__init_part0_A_const_68 = A_arbace_go_check_types__init_part0_A_const_pool.A[137]; A_arbace_go_check_types__init_part0_A_const_69 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[138]); A_arbace_go_check_types__init_part0_A_const_70 = A_arbace_go_check_types__init_part0_A_const_pool.A[139]; A_arbace_go_check_types__init_part0_A_const_71 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[140]); A_arbace_go_check_types__init_part0_A_const_72 = A_arbace_go_check_types__init_part0_A_const_pool.A[141]; A_arbace_go_check_types__init_part0_A_const_73 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[142]); A_arbace_go_check_types__init_part0_A_const_74 = A_arbace_go_check_types__init_part0_A_const_pool.A[143]; A_arbace_go_check_types__init_part0_A_const_75 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[144]); A_arbace_go_check_types__init_part0_A_const_76 = A_arbace_go_check_types__init_part0_A_const_pool.A[145]; A_arbace_go_check_types__init_part0_A_const_77 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[146]); A_arbace_go_check_types__init_part0_A_const_78 = A_arbace_go_check_types__init_part0_A_const_pool.A[147]; A_arbace_go_check_types__init_part0_A_const_79 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[148]) }

func A_arbace_go_check_types__init_part0_A_clinit_p6() { A_arbace_go_check_types__init_part0_A_const_80 = A_arbace_go_check_types__init_part0_A_const_pool.A[149]; A_arbace_go_check_types__init_part0_A_const_81 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[150]); A_arbace_go_check_types__init_part0_A_const_82 = A_arbace_go_check_types__init_part0_A_const_pool.A[151]; A_arbace_go_check_types__init_part0_A_const_83 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[152]); A_arbace_go_check_types__init_part0_A_const_84 = A_arbace_go_check_types__init_part0_A_const_pool.A[153]; A_arbace_go_check_types__init_part0_A_const_85 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[154]); A_arbace_go_check_types__init_part0_A_const_86 = A_arbace_go_check_types__init_part0_A_const_pool.A[155]; A_arbace_go_check_types__init_part0_A_const_87 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[156]); A_arbace_go_check_types__init_part0_A_const_88 = A_arbace_go_check_types__init_part0_A_const_pool.A[157]; A_arbace_go_check_types__init_part0_A_const_89 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[158]); A_arbace_go_check_types__init_part0_A_const_90 = A_arbace_go_check_types__init_part0_A_const_pool.A[159]; A_arbace_go_check_types__init_part0_A_const_91 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[160]); A_arbace_go_check_types__init_part0_A_const_92 = A_arbace_go_check_types__init_part0_A_const_pool.A[161] }

func A_arbace_go_check_types__init_part0_A_clinit_p7() { A_arbace_go_check_types__init_part0_A_const_93 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[162]); A_arbace_go_check_types__init_part0_A_const_94 = A_arbace_go_check_types__init_part0_A_const_pool.A[163]; A_arbace_go_check_types__init_part0_A_const_95 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[164]); A_arbace_go_check_types__init_part0_A_const_96 = A_arbace_go_check_types__init_part0_A_const_pool.A[165]; A_arbace_go_check_types__init_part0_A_const_97 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[166]); A_arbace_go_check_types__init_part0_A_const_98 = A_arbace_go_check_types__init_part0_A_const_pool.A[167]; A_arbace_go_check_types__init_part0_A_const_99 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[168]); A_arbace_go_check_types__init_part0_A_const_100 = A_arbace_go_check_types__init_part0_A_const_pool.A[169]; A_arbace_go_check_types__init_part0_A_const_101 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[170]); A_arbace_go_check_types__init_part0_A_const_102 = A_arbace_go_check_types__init_part0_A_const_pool.A[171]; A_arbace_go_check_types__init_part0_A_const_103 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[172]); A_arbace_go_check_types__init_part0_A_const_104 = A_arbace_go_check_types__init_part0_A_const_pool.A[173]; A_arbace_go_check_types__init_part0_A_const_105 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[174]) }

func A_arbace_go_check_types__init_part0_A_clinit_p8() { A_arbace_go_check_types__init_part0_A_const_106 = A_arbace_go_check_types__init_part0_A_const_pool.A[175]; A_arbace_go_check_types__init_part0_A_const_107 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[176]); A_arbace_go_check_types__init_part0_A_const_108 = A_arbace_go_check_types__init_part0_A_const_pool.A[177]; A_arbace_go_check_types__init_part0_A_const_109 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[178]); A_arbace_go_check_types__init_part0_A_const_110 = A_arbace_go_check_types__init_part0_A_const_pool.A[179]; A_arbace_go_check_types__init_part0_A_const_111 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[180]); A_arbace_go_check_types__init_part0_A_const_112 = A_arbace_go_check_types__init_part0_A_const_pool.A[181]; A_arbace_go_check_types__init_part0_A_const_113 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[182]); A_arbace_go_check_types__init_part0_A_const_114 = A_arbace_go_check_types__init_part0_A_const_pool.A[183]; A_arbace_go_check_types__init_part0_A_const_115 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[184]); A_arbace_go_check_types__init_part0_A_const_116 = A_arbace_go_check_types__init_part0_A_const_pool.A[185]; A_arbace_go_check_types__init_part0_A_const_117 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[186]); A_arbace_go_check_types__init_part0_A_const_118 = A_arbace_go_check_types__init_part0_A_const_pool.A[187] }

func A_arbace_go_check_types__init_part0_A_clinit_p9() { A_arbace_go_check_types__init_part0_A_const_119 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[188]); A_arbace_go_check_types__init_part0_A_const_120 = A_arbace_go_check_types__init_part0_A_const_pool.A[189]; A_arbace_go_check_types__init_part0_A_const_121 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[190]); A_arbace_go_check_types__init_part0_A_const_122 = A_arbace_go_check_types__init_part0_A_const_pool.A[191]; A_arbace_go_check_types__init_part0_A_const_123 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[192]); A_arbace_go_check_types__init_part0_A_const_124 = A_arbace_go_check_types__init_part0_A_const_pool.A[193]; A_arbace_go_check_types__init_part0_A_const_125 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[194]); A_arbace_go_check_types__init_part0_A_const_126 = A_arbace_go_check_types__init_part0_A_const_pool.A[195]; A_arbace_go_check_types__init_part0_A_const_127 = A_arbace_go_check_types__init_part0_A_const_pool.A[196]; A_arbace_go_check_types__init_part0_A_const_128 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[197]); A_arbace_go_check_types__init_part0_A_const_129 = A_arbace_go_check_types__init_part0_A_const_pool.A[198]; A_arbace_go_check_types__init_part0_A_const_130 = A_arbace_go_check_types__init_part0_A_const_pool.A[199]; A_arbace_go_check_types__init_part0_A_const_131 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[200]); A_arbace_go_check_types__init_part0_A_const_132 = A_arbace_go_check_types__init_part0_A_const_pool.A[201] }

func A_arbace_go_check_types__init_part0_A_clinit_p10() { A_arbace_go_check_types__init_part0_A_const_133 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[202]); A_arbace_go_check_types__init_part0_A_const_134 = A_arbace_go_check_types__init_part0_A_const_pool.A[203]; A_arbace_go_check_types__init_part0_A_const_135 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[204]); A_arbace_go_check_types__init_part0_A_const_136 = A_arbace_go_check_types__init_part0_A_const_pool.A[205]; A_arbace_go_check_types__init_part0_A_const_137 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[206]); A_arbace_go_check_types__init_part0_A_const_138 = A_arbace_go_check_types__init_part0_A_const_pool.A[207]; A_arbace_go_check_types__init_part0_A_const_139 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[208]); A_arbace_go_check_types__init_part0_A_const_140 = A_arbace_go_check_types__init_part0_A_const_pool.A[209]; A_arbace_go_check_types__init_part0_A_const_141 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[210]); A_arbace_go_check_types__init_part0_A_const_142 = A_arbace_go_check_types__init_part0_A_const_pool.A[211]; A_arbace_go_check_types__init_part0_A_const_143 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[212]); A_arbace_go_check_types__init_part0_A_const_144 = A_arbace_go_check_types__init_part0_A_const_pool.A[213]; A_arbace_go_check_types__init_part0_A_const_145 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[214]) }

func A_arbace_go_check_types__init_part0_A_clinit_p11() { A_arbace_go_check_types__init_part0_A_const_146 = A_arbace_go_check_types__init_part0_A_const_pool.A[215]; A_arbace_go_check_types__init_part0_A_const_147 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[216]); A_arbace_go_check_types__init_part0_A_const_148 = A_arbace_go_check_types__init_part0_A_const_pool.A[217]; A_arbace_go_check_types__init_part0_A_const_149 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[218]); A_arbace_go_check_types__init_part0_A_const_150 = A_arbace_go_check_types__init_part0_A_const_pool.A[219]; A_arbace_go_check_types__init_part0_A_const_151 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[220]); A_arbace_go_check_types__init_part0_A_const_152 = A_arbace_go_check_types__init_part0_A_const_pool.A[221]; A_arbace_go_check_types__init_part0_A_const_153 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[222]); A_arbace_go_check_types__init_part0_A_const_154 = A_arbace_go_check_types__init_part0_A_const_pool.A[223]; A_arbace_go_check_types__init_part0_A_const_155 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[224]); A_arbace_go_check_types__init_part0_A_const_156 = A_arbace_go_check_types__init_part0_A_const_pool.A[225]; A_arbace_go_check_types__init_part0_A_const_157 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[226]); A_arbace_go_check_types__init_part0_A_const_158 = A_arbace_go_check_types__init_part0_A_const_pool.A[227]; A_arbace_go_check_types__init_part0_A_const_159 = A_arbace_go_check_types__init_part0_A_const_pool.A[228] }

func A_arbace_go_check_types__init_part0_A_clinit_p12() { A_arbace_go_check_types__init_part0_A_const_160 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[229]); A_arbace_go_check_types__init_part0_A_const_161 = A_arbace_go_check_types__init_part0_A_const_pool.A[230]; A_arbace_go_check_types__init_part0_A_const_162 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[231]); A_arbace_go_check_types__init_part0_A_const_163 = A_arbace_go_check_types__init_part0_A_const_pool.A[232]; A_arbace_go_check_types__init_part0_A_const_164 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[233]); A_arbace_go_check_types__init_part0_A_const_165 = A_arbace_go_check_types__init_part0_A_const_pool.A[234]; A_arbace_go_check_types__init_part0_A_const_166 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[235]); A_arbace_go_check_types__init_part0_A_const_167 = A_arbace_go_check_types__init_part0_A_const_pool.A[236]; A_arbace_go_check_types__init_part0_A_const_168 = A_arbace_go_check_types__init_part0_A_const_pool.A[237]; A_arbace_go_check_types__init_part0_A_const_169 = A_arbace_go_check_types__init_part0_A_const_pool.A[238]; A_arbace_go_check_types__init_part0_A_const_170 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[239]); A_arbace_go_check_types__init_part0_A_const_171 = A_arbace_go_check_types__init_part0_A_const_pool.A[240]; A_arbace_go_check_types__init_part0_A_const_172 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[241]); A_arbace_go_check_types__init_part0_A_const_173 = A_arbace_go_check_types__init_part0_A_const_pool.A[242] }

func A_arbace_go_check_types__init_part0_A_clinit_p13() { A_arbace_go_check_types__init_part0_A_const_174 = A_arbace_go_check_types__init_part0_A_const_pool.A[243]; A_arbace_go_check_types__init_part0_A_const_175 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[244]); A_arbace_go_check_types__init_part0_A_const_176 = A_arbace_go_check_types__init_part0_A_const_pool.A[245]; A_arbace_go_check_types__init_part0_A_const_177 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[246]); A_arbace_go_check_types__init_part0_A_const_178 = A_arbace_go_check_types__init_part0_A_const_pool.A[247]; A_arbace_go_check_types__init_part0_A_const_179 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[248]); A_arbace_go_check_types__init_part0_A_const_180 = A_arbace_go_check_types__init_part0_A_const_pool.A[249]; A_arbace_go_check_types__init_part0_A_const_181 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[250]); A_arbace_go_check_types__init_part0_A_const_182 = A_arbace_go_check_types__init_part0_A_const_pool.A[251]; A_arbace_go_check_types__init_part0_A_const_183 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[252]); A_arbace_go_check_types__init_part0_A_const_184 = A_arbace_go_check_types__init_part0_A_const_pool.A[253]; A_arbace_go_check_types__init_part0_A_const_185 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[254]); A_arbace_go_check_types__init_part0_A_const_186 = A_arbace_go_check_types__init_part0_A_const_pool.A[255] }

func A_arbace_go_check_types__init_part0_A_clinit_p14() { A_arbace_go_check_types__init_part0_A_const_187 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[256]); A_arbace_go_check_types__init_part0_A_const_188 = A_arbace_go_check_types__init_part0_A_const_pool.A[257] }

func A_arbace_go_check_types__init_part0_A_New() *A_arbace_go_check_types__init_part0_A { A_arbace_go_check_types__init_part0_A_Init(); t := &A_arbace_go_check_types__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types__init_part0_A) Ctor() {}

func (t *A_arbace_go_check_types__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types__init_part0_A_class }

func (t *A_arbace_go_check_types__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types__init_part0_A); return ok }

func A_arbace_go_check_types__init_part0_A_Cast(x any) *A_arbace_go_check_types__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types__init_part0_A_class)) }; return v }



type A_arbace_go_check_types__init_part1_A struct{ jrt.Object }

var A_arbace_go_check_types__init_part1_A_const_pool *jrt.RefArray

var A_arbace_go_check_types__init_part1_A_const_0 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_1 any

var A_arbace_go_check_types__init_part1_A_const_2 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_3 any

var A_arbace_go_check_types__init_part1_A_const_4 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_5 any

var A_arbace_go_check_types__init_part1_A_const_6 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_7 any

var A_arbace_go_check_types__init_part1_A_const_8 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_9 any

var A_arbace_go_check_types__init_part1_A_const_10 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_11 any

var A_arbace_go_check_types__init_part1_A_const_12 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_13 any

var A_arbace_go_check_types__init_part1_A_const_14 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_15 any

var A_arbace_go_check_types__init_part1_A_const_16 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_17 any

var A_arbace_go_check_types__init_part1_A_const_18 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_19 any

var A_arbace_go_check_types__init_part1_A_const_20 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_21 any

var A_arbace_go_check_types__init_part1_A_const_22 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_23 any

var A_arbace_go_check_types__init_part1_A_const_24 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_25 any

var A_arbace_go_check_types__init_part1_A_const_26 any

var A_arbace_go_check_types__init_part1_A_const_27 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_28 any

var A_arbace_go_check_types__init_part1_A_const_29 any

var A_arbace_go_check_types__init_part1_A_const_30 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_31 any

var A_arbace_go_check_types__init_part1_A_const_32 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_33 any

var A_arbace_go_check_types__init_part1_A_const_34 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_35 any

var A_arbace_go_check_types__init_part1_A_const_36 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_37 any

var A_arbace_go_check_types__init_part1_A_const_38 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_39 any

var A_arbace_go_check_types__init_part1_A_const_40 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_41 any

var A_arbace_go_check_types__init_part1_A_const_42 any

var A_arbace_go_check_types__init_part1_A_const_43 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_44 any

var A_arbace_go_check_types__init_part1_A_const_45 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_46 any

var A_arbace_go_check_types__init_part1_A_const_47 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_48 any

var A_arbace_go_check_types__init_part1_A_const_49 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_50 any

var A_arbace_go_check_types__init_part1_A_const_51 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_52 any

var A_arbace_go_check_types__init_part1_A_const_53 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_54 any

var A_arbace_go_check_types__init_part1_A_const_55 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_56 any

var A_arbace_go_check_types__init_part1_A_const_57 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_58 any

var A_arbace_go_check_types__init_part1_A_const_59 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_60 any

var A_arbace_go_check_types__init_part1_A_const_61 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_62 any

var A_arbace_go_check_types__init_part1_A_const_63 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_64 any

var A_arbace_go_check_types__init_part1_A_const_65 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_66 any

var A_arbace_go_check_types__init_part1_A_const_67 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_68 any

var A_arbace_go_check_types__init_part1_A_const_69 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_70 any

var A_arbace_go_check_types__init_part1_A_const_71 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_72 any

var A_arbace_go_check_types__init_part1_A_const_73 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_74 any

var A_arbace_go_check_types__init_part1_A_init jrt.ClassInit

func A_arbace_go_check_types__init_part1_A_Init() { if !A_arbace_go_check_types__init_part1_A_init.Done() { A_arbace_go_check_types__init_part1_A_init.Run(A_arbace_go_check_types__init_part1_A_clinit) } }

func A_arbace_go_check_types__init_part1_A_clinit() { A_arbace_go_check_types__init_part1_A_clinit_p0(); A_arbace_go_check_types__init_part1_A_clinit_p1() }

func A_arbace_go_check_types__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_types__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_167, 109); A_arbace_go_check_types__init_part1_A_const_0 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[35]); A_arbace_go_check_types__init_part1_A_const_1 = A_arbace_go_check_types__init_part1_A_const_pool.A[36]; A_arbace_go_check_types__init_part1_A_const_2 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[37]); A_arbace_go_check_types__init_part1_A_const_3 = A_arbace_go_check_types__init_part1_A_const_pool.A[38]; A_arbace_go_check_types__init_part1_A_const_4 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[39]); A_arbace_go_check_types__init_part1_A_const_5 = A_arbace_go_check_types__init_part1_A_const_pool.A[40]; A_arbace_go_check_types__init_part1_A_const_6 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[41]); A_arbace_go_check_types__init_part1_A_const_7 = A_arbace_go_check_types__init_part1_A_const_pool.A[42]; A_arbace_go_check_types__init_part1_A_const_8 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[43]); A_arbace_go_check_types__init_part1_A_const_9 = A_arbace_go_check_types__init_part1_A_const_pool.A[44]; A_arbace_go_check_types__init_part1_A_const_10 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[45]); A_arbace_go_check_types__init_part1_A_const_11 = A_arbace_go_check_types__init_part1_A_const_pool.A[46] }

func A_arbace_go_check_types__init_part1_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_go_check_types__init_part0_A_Init(); tmp1 = A_arbace_go_check_types__init_part0_A_const_115; A_arbace_go_check_types__init_part1_A_const_12 = tmp1; A_arbace_go_check_types__init_part1_A_const_13 = A_arbace_go_check_types__init_part1_A_const_pool.A[47]; A_arbace_go_check_types__init_part1_A_const_14 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[48]); A_arbace_go_check_types__init_part1_A_const_15 = A_arbace_go_check_types__init_part1_A_const_pool.A[49]; A_arbace_go_check_types__init_part1_A_const_16 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[50]); A_arbace_go_check_types__init_part1_A_const_17 = A_arbace_go_check_types__init_part1_A_const_pool.A[51]; A_arbace_go_check_types__init_part1_A_const_18 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[52]); A_arbace_go_check_types__init_part1_A_const_19 = A_arbace_go_check_types__init_part1_A_const_pool.A[53]; A_arbace_go_check_types__init_part1_A_const_20 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[54]); A_arbace_go_check_types__init_part1_A_const_21 = A_arbace_go_check_types__init_part1_A_const_pool.A[55]; A_arbace_go_check_types__init_part1_A_const_22 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[56]); A_arbace_go_check_types__init_part1_A_const_23 = A_arbace_go_check_types__init_part1_A_const_pool.A[57]; A_arbace_go_check_types__init_part1_A_const_24 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[58]); A_arbace_go_check_types__init_part1_A_const_25 = A_arbace_go_check_types__init_part1_A_const_pool.A[59]; A_arbace_go_check_types__init_part1_A_const_26 = A_arbace_go_check_types__init_part1_A_const_pool.A[60]; A_arbace_go_check_types__init_part1_A_const_27 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[61]); A_arbace_go_check_types__init_part1_A_const_28 = A_arbace_go_check_types__init_part1_A_const_pool.A[62]; A_arbace_go_check_types__init_part1_A_const_29 = A_arbace_go_check_types__init_part1_A_const_pool.A[63]; A_arbace_go_check_types__init_part1_A_const_30 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[64]); A_arbace_go_check_types__init_part1_A_const_31 = A_arbace_go_check_types__init_part1_A_const_pool.A[65]; A_arbace_go_check_types__init_part1_A_const_32 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[66]); A_arbace_go_check_types__init_part1_A_const_33 = A_arbace_go_check_types__init_part1_A_const_pool.A[67]; A_arbace_go_check_types__init_part1_A_const_34 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[68]); A_arbace_go_check_types__init_part1_A_const_35 = A_arbace_go_check_types__init_part1_A_const_pool.A[69]; A_arbace_go_check_types__init_part1_A_const_36 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[70]); A_arbace_go_check_types__init_part1_A_const_37 = A_arbace_go_check_types__init_part1_A_const_pool.A[71]; A_arbace_go_check_types__init_part1_A_const_38 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[72]); A_arbace_go_check_types__init_part1_A_const_39 = A_arbace_go_check_types__init_part1_A_const_pool.A[73]; A_arbace_go_check_types__init_part1_A_const_40 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[74]); A_arbace_go_check_types__init_part1_A_const_41 = A_arbace_go_check_types__init_part1_A_const_pool.A[75]; A_arbace_go_check_types__init_part1_A_const_42 = A_arbace_go_check_types__init_part1_A_const_pool.A[76]; A_arbace_go_check_types__init_part1_A_const_43 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[77]); A_arbace_go_check_types__init_part1_A_const_44 = A_arbace_go_check_types__init_part1_A_const_pool.A[78]; A_arbace_go_check_types__init_part1_A_const_45 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[79]); A_arbace_go_check_types__init_part1_A_const_46 = A_arbace_go_check_types__init_part1_A_const_pool.A[80]; A_arbace_go_check_types__init_part1_A_const_47 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[81]); A_arbace_go_check_types__init_part1_A_const_48 = A_arbace_go_check_types__init_part1_A_const_pool.A[82]; A_arbace_go_check_types__init_part1_A_const_49 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[83]); A_arbace_go_check_types__init_part1_A_const_50 = A_arbace_go_check_types__init_part1_A_const_pool.A[84]; A_arbace_go_check_types__init_part1_A_const_51 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[85]); A_arbace_go_check_types__init_part1_A_const_52 = A_arbace_go_check_types__init_part1_A_const_pool.A[86]; A_arbace_go_check_types__init_part1_A_const_53 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[87]); A_arbace_go_check_types__init_part1_A_const_54 = A_arbace_go_check_types__init_part1_A_const_pool.A[88]; A_arbace_go_check_types__init_part1_A_const_55 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[89]); A_arbace_go_check_types__init_part1_A_const_56 = A_arbace_go_check_types__init_part1_A_const_pool.A[90]; A_arbace_go_check_types__init_part1_A_const_57 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[91]); A_arbace_go_check_types__init_part1_A_const_58 = A_arbace_go_check_types__init_part1_A_const_pool.A[92]; A_arbace_go_check_types__init_part1_A_const_59 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[93]); A_arbace_go_check_types__init_part1_A_const_60 = A_arbace_go_check_types__init_part1_A_const_pool.A[94]; A_arbace_go_check_types__init_part1_A_const_61 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[95]); A_arbace_go_check_types__init_part1_A_const_62 = A_arbace_go_check_types__init_part1_A_const_pool.A[96]; A_arbace_go_check_types__init_part1_A_const_63 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[97]); A_arbace_go_check_types__init_part1_A_const_64 = A_arbace_go_check_types__init_part1_A_const_pool.A[98]; A_arbace_go_check_types__init_part1_A_const_65 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[99]); A_arbace_go_check_types__init_part1_A_const_66 = A_arbace_go_check_types__init_part1_A_const_pool.A[100]; A_arbace_go_check_types__init_part1_A_const_67 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[101]); A_arbace_go_check_types__init_part1_A_const_68 = A_arbace_go_check_types__init_part1_A_const_pool.A[102]; A_arbace_go_check_types__init_part1_A_const_69 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[103]); A_arbace_go_check_types__init_part1_A_const_70 = A_arbace_go_check_types__init_part1_A_const_pool.A[104]; A_arbace_go_check_types__init_part1_A_const_71 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[105]); A_arbace_go_check_types__init_part1_A_const_72 = A_arbace_go_check_types__init_part1_A_const_pool.A[106]; A_arbace_go_check_types__init_part1_A_const_73 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[107]); A_arbace_go_check_types__init_part1_A_const_74 = A_arbace_go_check_types__init_part1_A_const_pool.A[108] }

func A_arbace_go_check_types__init_part1_A_New() *A_arbace_go_check_types__init_part1_A { A_arbace_go_check_types__init_part1_A_Init(); t := &A_arbace_go_check_types__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types__init_part1_A) Ctor() {}

func (t *A_arbace_go_check_types__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types__init_part1_A_class }

func (t *A_arbace_go_check_types__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types__init_part1_A); return ok }

func A_arbace_go_check_types__init_part1_A_Cast(x any) *A_arbace_go_check_types__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types__init_part1_A_class)) }; return v }
