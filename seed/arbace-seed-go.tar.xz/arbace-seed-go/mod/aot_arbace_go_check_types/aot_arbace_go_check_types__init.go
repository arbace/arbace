//line aot_arbace_go_check_types__init.ae:1
package aot_arbace_go_check_types

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_types__init_part0_A_Unit0__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_check_types__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_types__init_part0_A_const_1) }
//line :1:1
func A_arbace_go_check_types__init_part0_A_Unit1__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_check_types__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_2)) }
//line :1:1
func A_arbace_go_check_types__init_part0_A_Unit2__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_go_check_types_eval219000004_loading__1927001464__auto____219000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_go_check_types__init_part0_A_Unit3__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_check_types__init_part0_A_const_1)).Equals_O__Z(A_arbace_go_check_types__init_part0_A_const_3) { return nil } else { var tmp1 any = A_arbace_go_check_types_eval219000008_fn__219000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_go_check_types_eval219000008_fn__219000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_go_check_types_eval219000008_fn__219000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
//line :1:1
func A_arbace_go_check_types__init_part0_A_Init__O() any { A_arbace_go_check_types__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_go_check_types__init_part0_A_Load__O() any { A_arbace_go_check_types__init_part0_A_Init(); A_arbace_go_check_types__init_part0_A_Unit0__O(); A_arbace_go_check_types__init_part0_A_Unit1__O(); A_arbace_go_check_types__init_part0_A_Unit2__O(); A_arbace_go_check_types__init_part0_A_Unit3__O(); A_arbace_go_check_types__init_part0_A_Unit4__O(); A_arbace_go_check_types__init_part0_A_Unit5__O(); A_arbace_go_check_types__init_part0_A_Unit6__O(); A_arbace_go_check_types__init_part0_A_Unit7__O(); A_arbace_go_check_types__init_part0_A_Unit8__O(); A_arbace_go_check_types__init_part0_A_Unit9__O(); A_arbace_go_check_types__init_part0_A_Unit10__O(); A_arbace_go_check_types__init_part0_A_Unit11__O(); A_arbace_go_check_types__init_part0_A_Unit12__O(); A_arbace_go_check_types__init_part0_A_Unit13__O(); A_arbace_go_check_types__init_part0_A_Unit14__O(); A_arbace_go_check_types__init_part0_A_Unit15__O(); A_arbace_go_check_types__init_part0_A_Unit16__O(); A_arbace_go_check_types__init_part0_A_Unit17__O(); A_arbace_go_check_types__init_part0_A_Unit18__O(); A_arbace_go_check_types__init_part0_A_Unit19__O(); A_arbace_go_check_types__init_part0_A_Unit20__O(); A_arbace_go_check_types__init_part0_A_Unit21__O(); A_arbace_go_check_types__init_part0_A_Unit22__O(); A_arbace_go_check_types__init_part0_A_Unit23__O(); A_arbace_go_check_types__init_part0_A_Unit24__O(); A_arbace_go_check_types__init_part0_A_Unit25__O(); A_arbace_go_check_types__init_part0_A_Unit26__O(); A_arbace_go_check_types__init_part0_A_Unit27__O(); A_arbace_go_check_types__init_part0_A_Unit28__O(); A_arbace_go_check_types__init_part0_A_Unit29__O(); A_arbace_go_check_types__init_part0_A_Unit30__O(); A_arbace_go_check_types__init_part0_A_Unit31__O(); A_arbace_go_check_types__init_part0_A_Unit32__O(); A_arbace_go_check_types__init_part0_A_Unit33__O(); A_arbace_go_check_types__init_part0_A_Unit34__O(); A_arbace_go_check_types__init_part0_A_Unit35__O(); A_arbace_go_check_types__init_part0_A_Unit36__O(); A_arbace_go_check_types__init_part0_A_Unit37__O(); A_arbace_go_check_types__init_part0_A_Unit38__O(); A_arbace_go_check_types__init_part0_A_Unit39__O(); A_arbace_go_check_types__init_part0_A_Unit40__O(); A_arbace_go_check_types__init_part0_A_Unit41__O(); A_arbace_go_check_types__init_part0_A_Unit42__O(); A_arbace_go_check_types__init_part0_A_Unit43__O(); A_arbace_go_check_types__init_part0_A_Unit44__O(); A_arbace_go_check_types__init_part0_A_Unit45__O(); A_arbace_go_check_types__init_part0_A_Unit46__O(); A_arbace_go_check_types__init_part0_A_Unit47__O(); A_arbace_go_check_types__init_part0_A_Unit48__O(); A_arbace_go_check_types__init_part0_A_Unit49__O(); A_arbace_go_check_types__init_part0_A_Unit50__O(); A_arbace_go_check_types__init_part0_A_Unit51__O(); A_arbace_go_check_types__init_part0_A_Unit52__O(); A_arbace_go_check_types__init_part0_A_Unit53__O(); A_arbace_go_check_types__init_part0_A_Unit54__O(); A_arbace_go_check_types__init_part0_A_Unit55__O(); A_arbace_go_check_types__init_part0_A_Unit56__O(); A_arbace_go_check_types__init_part0_A_Unit57__O(); A_arbace_go_check_types__init_part0_A_Unit58__O(); A_arbace_go_check_types__init_part0_A_Unit59__O(); A_arbace_go_check_types__init_part0_A_Unit60__O(); A_arbace_go_check_types__init_part0_A_Unit61__O(); A_arbace_go_check_types__init_part0_A_Unit62__O(); A_arbace_go_check_types__init_part0_A_Unit63__O(); A_arbace_go_check_types__init_part0_A_Unit64__O(); A_arbace_go_check_types__init_part0_A_Unit65__O(); A_arbace_go_check_types__init_part0_A_Unit66__O(); A_arbace_go_check_types__init_part0_A_Unit67__O(); A_arbace_go_check_types__init_part0_A_Unit68__O(); A_arbace_go_check_types__init_part0_A_Unit69__O(); A_arbace_go_check_types__init_part0_A_Unit70__O(); A_arbace_go_check_types__init_part0_A_Unit71__O(); A_arbace_go_check_types__init_part0_A_Unit72__O(); A_arbace_go_check_types__init_part0_A_Unit73__O(); A_arbace_go_check_types__init_part0_A_Unit74__O(); A_arbace_go_check_types__init_part0_A_Unit75__O(); A_arbace_go_check_types__init_part0_A_Unit76__O(); A_arbace_go_check_types__init_part0_A_Unit77__O(); A_arbace_go_check_types__init_part0_A_Unit78__O(); A_arbace_go_check_types__init_part0_A_Unit79__O(); A_arbace_go_check_types__init_part0_A_Unit80__O(); A_arbace_go_check_types__init_part0_A_Unit81__O(); A_arbace_go_check_types__init_part0_A_Unit82__O(); A_arbace_go_check_types__init_part0_A_Unit83__O(); A_arbace_go_check_types__init_part0_A_Unit84__O(); A_arbace_go_check_types__init_part0_A_Unit85__O(); A_arbace_go_check_types__init_part0_A_Unit86__O(); A_arbace_go_check_types__init_part0_A_Unit87__O(); A_arbace_go_check_types__init_part0_A_Unit88__O(); A_arbace_go_check_types__init_part0_A_Unit89__O(); A_arbace_go_check_types__init_part0_A_Unit90__O(); A_arbace_go_check_types__init_part0_A_Unit91__O(); A_arbace_go_check_types__init_part0_A_Unit92__O(); A_arbace_go_check_types__init_part0_A_Unit93__O(); A_arbace_go_check_types__init_part0_A_Unit94__O(); A_arbace_go_check_types__init_part0_A_Unit95__O(); A_arbace_go_check_types__init_part0_A_Unit96__O(); A_arbace_go_check_types__init_part0_A_Unit97__O(); A_arbace_go_check_types__init_part0_A_Unit98__O(); A_arbace_go_check_types__init_part0_A_Unit99__O(); return nil }



func A_arbace_go_check_types__init_A_Load__O() any { jrt.StartCheck(); A_arbace_go_check_types__init_part0_A_Init__O(); A_arbace_go_check_types__init_part1_A_Init__O(); A_arbace_go_check_types__init_part0_A_Load__O(); A_arbace_go_check_types__init_part1_A_Load__O(); return nil }
















func A_arbace_go_check_types__init_part0_A_Unit4__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_4; var tmp2 any = A_arbace_go_check_types_fn__219000012_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_types_fn__219000012_A_fn_class; if

	fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_go_check_types_fn__219000012_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; /*line :22:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_5)); return A_arbace_go_check_types__init_part0_A_const_4 }
















func A_arbace_go_check_types__init_part0_A_Unit5__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); A_arbace_go_check_types__init_part0_A_const_6.BindRoot_O__V(A_arbace_go_check_types__init_part0_A_const_7); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_8)); return A_arbace_go_check_types__init_part0_A_const_6 }










func A_arbace_go_check_types__init_part0_A_Unit6__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_9; tmp1.BindRoot_O__V(jrt.AtomicLong_New_J(0)); var tmp2 *lang.Var = A_arbace_go_check_types__init_part0_A_const_9; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_10)); return A_arbace_go_check_types__init_part0_A_const_9 }
func A_arbace_go_check_types__init_part0_A_Unit7__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(51, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_11; var tmp2 any = A_arbace_go_check_types_next_id_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_go_check_types_next_id_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_go_check_types_next_id_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_12)); return A_arbace_go_check_types__init_part0_A_const_11 }

func A_arbace_go_check_types__init_part0_A_Unit8__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_13; var tmp2 any = A_arbace_go_check_types_named_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_types_named_QMARK__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_go_check_types_named_QMARK__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_14)); return A_arbace_go_check_types__init_part0_A_const_13 }
func A_arbace_go_check_types__init_part0_A_Unit9__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(54, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_15; var tmp2 any = A_arbace_go_check_types_tparam_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_go_check_types_tparam_QMARK__A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_go_check_types_tparam_QMARK__A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_16)); return A_arbace_go_check_types__init_part0_A_const_15 }
func A_arbace_go_check_types__init_part0_A_Unit10__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(55, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_17; var tmp2 any = A_arbace_go_check_types_info_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_types_info_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_go_check_types_info_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_18)); return A_arbace_go_check_types__init_part0_A_const_17 }
func A_arbace_go_check_types__init_part0_A_Unit11__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_19; var tmp2 any = A_arbace_go_check_types_update_info_BANG__A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_go_check_types_update_info_BANG__A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, true); A_arbace_go_check_types_update_info_BANG__A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_20)); return A_arbace_go_check_types__init_part0_A_const_19 }

func A_arbace_go_check_types__init_part0_A_Unit12__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_21; var tmp2 any = A_arbace_go_check_types_new_named_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_types_new_named_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_go_check_types_new_named_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_22)); return A_arbace_go_check_types__init_part0_A_const_21 }




func A_arbace_go_check_types__init_part0_A_Unit13__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(63, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_23; var tmp2 any = A_arbace_go_check_types_new_tparam_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_go_check_types_new_tparam_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_go_check_types_new_tparam_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_24)); return A_arbace_go_check_types__init_part0_A_const_23 }




func A_arbace_go_check_types__init_part0_A_Unit14__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(68, 1); A_arbace_go_check_types__init_part0_A_const_25.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_25; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_26)); return A_arbace_go_check_types__init_part0_A_const_25.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_types__init_part0_A_Unit15__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_27; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_28)); return A_arbace_go_check_types__init_part0_A_const_27 }
//line :73:1
func A_arbace_go_check_types__init_part0_A_Unit16__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_29; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_30)); return A_arbace_go_check_types__init_part0_A_const_29 }

func A_arbace_go_check_types__init_part0_A_Unit17__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(75, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_31; var tmp2 any = A_arbace_go_check_types_named_under_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_types_named_under_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_go_check_types_named_under_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_32)); return A_arbace_go_check_types__init_part0_A_const_31 }














func A_arbace_go_check_types__init_part0_A_Unit18__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(90, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_27; var tmp2 any = A_arbace_go_check_types_under_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_go_check_types_under_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_go_check_types_under_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_33)); return A_arbace_go_check_types__init_part0_A_const_27 }










func A_arbace_go_check_types__init_part0_A_Unit19__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_34; var tmp2 any = A_arbace_go_check_types_basic_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_types_basic_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_go_check_types_basic_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_35)); return A_arbace_go_check_types__init_part0_A_const_34 }
func A_arbace_go_check_types__init_part0_A_Unit20__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(102, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_36; var tmp2 any = A_arbace_go_check_types_flag_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_go_check_types_flag_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_go_check_types_flag_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_37)); return A_arbace_go_check_types__init_part0_A_const_36 }
func A_arbace_go_check_types__init_part0_A_Unit21__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(103, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_38; var tmp2 any = A_arbace_go_check_types_integer_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_types_integer_type_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_go_check_types_integer_type_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_39)); return A_arbace_go_check_types__init_part0_A_const_38 }
func A_arbace_go_check_types__init_part0_A_Unit22__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(104, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_40; var tmp2 any = A_arbace_go_check_types_unsigned_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_go_check_types_unsigned_QMARK__A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_go_check_types_unsigned_QMARK__A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_41)); return A_arbace_go_check_types__init_part0_A_const_40 }
func A_arbace_go_check_types__init_part0_A_Unit23__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(105, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_42; var tmp2 any = A_arbace_go_check_types_float_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_check_types_float_type_QMARK__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_go_check_types_float_type_QMARK__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_43)); return A_arbace_go_check_types__init_part0_A_const_42 }
func A_arbace_go_check_types__init_part0_A_Unit24__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_44; var tmp2 any = A_arbace_go_check_types_complex_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_go_check_types_complex_type_QMARK__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_go_check_types_complex_type_QMARK__A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_45)); return A_arbace_go_check_types__init_part0_A_const_44 }
func A_arbace_go_check_types__init_part0_A_Unit25__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_46; var tmp2 any = A_arbace_go_check_types_numeric_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_check_types_numeric_QMARK__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_go_check_types_numeric_QMARK__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_47)); return A_arbace_go_check_types__init_part0_A_const_46 }
func A_arbace_go_check_types__init_part0_A_Unit26__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(108, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_48; var tmp2 any = A_arbace_go_check_types_string_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_go_check_types_string_type_QMARK__A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_go_check_types_string_type_QMARK__A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_49)); return A_arbace_go_check_types__init_part0_A_const_48 }
func A_arbace_go_check_types__init_part0_A_Unit27__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_50; var tmp2 any = A_arbace_go_check_types_boolean_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_check_types_boolean_type_QMARK__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_go_check_types_boolean_type_QMARK__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_51)); return A_arbace_go_check_types__init_part0_A_const_50 }
func A_arbace_go_check_types__init_part0_A_Unit28__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(110, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_52; var tmp2 any = A_arbace_go_check_types_untyped_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_go_check_types_untyped_QMARK__A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_go_check_types_untyped_QMARK__A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_53)); return A_arbace_go_check_types__init_part0_A_const_52 }
func A_arbace_go_check_types__init_part0_A_Unit29__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(111, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_54; var tmp2 any = A_arbace_go_check_types_typed_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_check_types_typed_QMARK__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_go_check_types_typed_QMARK__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_55)); return A_arbace_go_check_types__init_part0_A_const_54 }
func A_arbace_go_check_types__init_part0_A_Unit30__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(112, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_56; var tmp2 any = A_arbace_go_check_types_const_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_go_check_types_const_type_QMARK__A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_go_check_types_const_type_QMARK__A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_57)); return A_arbace_go_check_types__init_part0_A_const_56 }



func A_arbace_go_check_types__init_part0_A_Unit31__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(116, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_58; var tmp2 any = A_arbace_go_check_types_ordered_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_check_types_ordered_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_go_check_types_ordered_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_59)); return A_arbace_go_check_types__init_part0_A_const_58 }
func A_arbace_go_check_types__init_part0_A_Unit32__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(117, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_60; var tmp2 any = A_arbace_go_check_types_interface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_go_check_types_interface_QMARK__A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_go_check_types_interface_QMARK__A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_61)); return A_arbace_go_check_types__init_part0_A_const_60 }
func A_arbace_go_check_types__init_part0_A_Unit33__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(118, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_62; var tmp2 any = A_arbace_go_check_types_pointer_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_check_types_pointer_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_go_check_types_pointer_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_63)); return A_arbace_go_check_types__init_part0_A_const_62 }
func A_arbace_go_check_types__init_part0_A_Unit34__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(119, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_64; var tmp2 any = A_arbace_go_check_types_unsafe_pointer_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_go_check_types_unsafe_pointer_QMARK__A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_go_check_types_unsafe_pointer_QMARK__A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_65)); return A_arbace_go_check_types__init_part0_A_const_64 }
func A_arbace_go_check_types__init_part0_A_Unit35__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(120, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_66; var tmp2 any = A_arbace_go_check_types_uintptr_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_check_types_uintptr_QMARK__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_107, false); A_arbace_go_check_types_uintptr_QMARK__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_67)); return A_arbace_go_check_types__init_part0_A_const_66 }
func A_arbace_go_check_types__init_part0_A_Unit36__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(121, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_68; var tmp2 any = A_arbace_go_check_types_valid_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_check_types_valid_QMARK__A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_go_check_types_valid_QMARK__A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_69)); return A_arbace_go_check_types__init_part0_A_const_68 }
func A_arbace_go_check_types__init_part0_A_Unit37__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(122, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_70; var tmp2 any = A_arbace_go_check_types_kind_of_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_types_kind_of_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_go_check_types_kind_of_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_71)); return A_arbace_go_check_types__init_part0_A_const_70 }
func A_arbace_go_check_types__init_part0_A_Unit38__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_72; var tmp2 any = A_arbace_go_check_types_has_name_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_go_check_types_has_name_QMARK__A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_go_check_types_has_name_QMARK__A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_73)); return A_arbace_go_check_types__init_part0_A_const_72 }
func A_arbace_go_check_types__init_part0_A_Unit39__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_74; var tmp2 any = A_arbace_go_check_types_integer_or_float_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_check_types_integer_or_float_QMARK__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_go_check_types_integer_or_float_QMARK__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_75)); return A_arbace_go_check_types__init_part0_A_const_74 }

func A_arbace_go_check_types__init_part0_A_Unit40__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_77)); return A_arbace_go_check_types__init_part0_A_const_76 }

func A_arbace_go_check_types__init_part0_A_Unit41__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_78; var tmp2 any = A_arbace_go_check_types_has_nil_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_go_check_types_has_nil_QMARK__A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_go_check_types_has_nil_QMARK__A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_79)); return A_arbace_go_check_types__init_part0_A_const_78 }









func A_arbace_go_check_types__init_part0_A_Unit42__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(138, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_80; var tmp2 any = A_arbace_go_check_types_empty_interface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_check_types_empty_interface_QMARK__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_113, false); A_arbace_go_check_types_empty_interface_QMARK__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_81)); return A_arbace_go_check_types__init_part0_A_const_80 }


func A_arbace_go_check_types__init_part0_A_Unit43__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_82; var tmp2 any = A_arbace_go_check_types_default_type_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_go_check_types_default_type_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_go_check_types_default_type_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_83)); return A_arbace_go_check_types__init_part0_A_const_82 }







func A_arbace_go_check_types__init_part0_A_Unit44__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(149, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_84; var tmp2 any = A_arbace_go_check_types_ignore_tags_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_check_types_ignore_tags_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_go_check_types_ignore_tags_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_85)); return A_arbace_go_check_types__init_part0_A_const_84 }















func A_arbace_go_check_types__init_part0_A_Unit45__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(165, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_86; var tmp2 any = A_arbace_go_check_types_identical_ignore_tags_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_go_check_types_identical_ignore_tags_QMARK__A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_go_check_types_identical_ignore_tags_QMARK__A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_87)); return A_arbace_go_check_types__init_part0_A_const_86 }

func A_arbace_go_check_types__init_part0_A_Unit46__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(167, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_88; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_89)); return A_arbace_go_check_types__init_part0_A_const_88 }
//line :167:1
func A_arbace_go_check_types__init_part0_A_Unit47__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(167, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_90; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_91)); return A_arbace_go_check_types__init_part0_A_const_90 }

func A_arbace_go_check_types__init_part0_A_Unit48__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(169, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_92; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_93)); return A_arbace_go_check_types__init_part0_A_const_92 }
//line :169:1
func A_arbace_go_check_types__init_part0_A_Unit49__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(169, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_94; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_95)); return A_arbace_go_check_types__init_part0_A_const_94 }
//line :169:1
func A_arbace_go_check_types__init_part0_A_Unit50__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(169, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_96; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_97)); return A_arbace_go_check_types__init_part0_A_const_96 }

func A_arbace_go_check_types__init_part0_A_Unit51__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(171, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_98; var tmp2 any = A_arbace_go_check_types_tset_comparable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_go_check_types_tset_comparable_QMARK__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_99)); return A_arbace_go_check_types__init_part0_A_const_98 }






func A_arbace_go_check_types__init_part0_A_Unit52__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_100; var tmp2 any = A_arbace_go_check_types_comparable_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_go_check_types_comparable_type_QMARK__A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_go_check_types_comparable_type_QMARK__A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_101)); return A_arbace_go_check_types__init_part0_A_const_100 }




















func A_arbace_go_check_types__init_part0_A_Unit53__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(199, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_94; var tmp2 any = A_arbace_go_check_types_strictly_comparable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_go_check_types_strictly_comparable_QMARK__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_102)); return A_arbace_go_check_types__init_part0_A_const_94 }

func A_arbace_go_check_types__init_part0_A_Unit54__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_103; var tmp2 any = A_arbace_go_check_types_incomparable_cause_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_go_check_types_incomparable_cause_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_go_check_types_incomparable_cause_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_104)); return A_arbace_go_check_types__init_part0_A_const_103 }






















func A_arbace_go_check_types__init_part0_A_Unit55__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(224, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_88; var tmp2 any = A_arbace_go_check_types_comparable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_check_types_comparable_QMARK__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_go_check_types_comparable_QMARK__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_105)); return A_arbace_go_check_types__init_part0_A_const_88 }
















func A_arbace_go_check_types__init_part0_A_Unit56__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(241, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_106; var tmp2 any = A_arbace_go_check_types_union_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_check_types_union_QMARK__A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_go_check_types_union_QMARK__A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_107)); return A_arbace_go_check_types__init_part0_A_const_106 }

func A_arbace_go_check_types__init_part0_A_Unit57__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(243, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_108; var tmp2 any = A_arbace_go_check_types_term_disjoint_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_go_check_types_term_disjoint_QMARK__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_109)); return A_arbace_go_check_types__init_part0_A_const_108 }


func A_arbace_go_check_types__init_part0_A_Unit58__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(246, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_110; var tmp2 any = A_arbace_go_check_types_term_union_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_go_check_types_term_union_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_go_check_types_term_union_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_111)); return A_arbace_go_check_types__init_part0_A_const_110 }





func A_arbace_go_check_types__init_part0_A_Unit59__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(252, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_112; var tmp2 any = A_arbace_go_check_types_term_intersect_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_check_types_term_intersect_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_go_check_types_term_intersect_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_113)); return A_arbace_go_check_types__init_part0_A_const_112 }





func A_arbace_go_check_types__init_part0_A_Unit60__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(258, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_114; var tmp2 any = A_arbace_go_check_types_term_includes_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_go_check_types_term_includes_QMARK__A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_go_check_types_term_includes_QMARK__A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_115)); return A_arbace_go_check_types__init_part0_A_const_114 }

func A_arbace_go_check_types__init_part0_A_Unit61__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(260, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_116; var tmp2 any = A_arbace_go_check_types_term_subset_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_check_types_term_subset_QMARK__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_go_check_types_term_subset_QMARK__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_117)); return A_arbace_go_check_types__init_part0_A_const_116 }

func A_arbace_go_check_types__init_part0_A_Unit62__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(262, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_118; var tmp2 any = A_arbace_go_check_types_terms_norm_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_go_check_types_terms_norm_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_go_check_types_terms_norm_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_119)); return A_arbace_go_check_types__init_part0_A_const_118 }



















func A_arbace_go_check_types__init_part0_A_Unit63__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(282, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_120; var tmp2 any = A_arbace_go_check_types_ordered_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_check_types_ordered_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_go_check_types_ordered_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_121)); return A_arbace_go_check_types__init_part0_A_const_120 }




func A_arbace_go_check_types__init_part0_A_Unit64__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(287, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_122; var tmp2 any = A_arbace_go_check_types_terms_union_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_go_check_types_terms_union_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_go_check_types_terms_union_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_123)); return A_arbace_go_check_types__init_part0_A_const_122 }

func A_arbace_go_check_types__init_part0_A_Unit65__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(289, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_124; var tmp2 any = A_arbace_go_check_types_terms_intersect_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_check_types_terms_intersect_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_go_check_types_terms_intersect_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_125)); return A_arbace_go_check_types__init_part0_A_const_124 }






func A_arbace_go_check_types__init_part0_A_Unit66__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(296, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_126; var tmp2 any = A_arbace_go_check_types_terms_includes_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_go_check_types_terms_includes_QMARK__A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_go_check_types_terms_includes_QMARK__A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_127)); return A_arbace_go_check_types__init_part0_A_const_126 }

func A_arbace_go_check_types__init_part0_A_Unit67__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_128; var tmp2 any = A_arbace_go_check_types_terms_superset_of_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_check_types_terms_superset_of_QMARK__A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_go_check_types_terms_superset_of_QMARK__A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_129)); return A_arbace_go_check_types__init_part0_A_const_128 }

func A_arbace_go_check_types__init_part0_A_Unit68__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(300, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_130; var tmp2 any = A_arbace_go_check_types_terms_subset_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_go_check_types_terms_subset_QMARK__A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_go_check_types_terms_subset_QMARK__A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_131)); return A_arbace_go_check_types__init_part0_A_const_130 }








func A_arbace_go_check_types__init_part0_A_Unit69__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(309, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_132; var tmp2 any = A_arbace_go_check_types_make_tset_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_check_types_make_tset_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_go_check_types_make_tset_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_132; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_133)); return A_arbace_go_check_types__init_part0_A_const_132 }




func A_arbace_go_check_types__init_part0_A_Unit70__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(314, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_96; var tmp2 any = A_arbace_go_check_types_iface_tset_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_go_check_types_iface_tset_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_go_check_types_iface_tset_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_134)); return A_arbace_go_check_types__init_part0_A_const_96 }








func A_arbace_go_check_types__init_part0_A_Unit71__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(323, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_135; var tmp2 any = A_arbace_go_check_types_has_terms_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_go_check_types_has_terms_QMARK__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_go_check_types_has_terms_QMARK__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_136)); return A_arbace_go_check_types__init_part0_A_const_135 }




func A_arbace_go_check_types__init_part0_A_Unit72__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(328, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_137; var tmp2 any = A_arbace_go_check_types_tset_empty_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_go_check_types_tset_empty_QMARK__A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_go_check_types_tset_empty_QMARK__A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_138)); return A_arbace_go_check_types__init_part0_A_const_137 }

func A_arbace_go_check_types__init_part0_A_Unit73__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(330, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_139; var tmp2 any = A_arbace_go_check_types_method_set_iface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_go_check_types_method_set_iface_QMARK__A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_go_check_types_method_set_iface_QMARK__A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_140)); return A_arbace_go_check_types__init_part0_A_const_139 }





func A_arbace_go_check_types__init_part0_A_Unit74__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(336, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_141; var tmp2 any = A_arbace_go_check_types_bound_iface_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_go_check_types_bound_iface_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, false); A_arbace_go_check_types_bound_iface_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_142)); return A_arbace_go_check_types__init_part0_A_const_141 }











func A_arbace_go_check_types__init_part0_A_Unit75__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(348, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_29; var tmp2 any = A_arbace_go_check_types_tparam_iface_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_go_check_types_tparam_iface_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_go_check_types_tparam_iface_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_143)); return A_arbace_go_check_types__init_part0_A_const_29 }








func A_arbace_go_check_types__init_part0_A_Unit76__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(357, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_92; var tmp2 any = A_arbace_go_check_types_tparam_tset_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_go_check_types_tparam_tset_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_go_check_types_tparam_tset_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_144)); return A_arbace_go_check_types__init_part0_A_const_92 }

func A_arbace_go_check_types__init_part0_A_Unit77__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(359, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_145; var tmp2 any = A_arbace_go_check_types_typeset_pairs_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_go_check_types_typeset_pairs_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_go_check_types_typeset_pairs_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_146)); return A_arbace_go_check_types__init_part0_A_const_145 }










func A_arbace_go_check_types__init_part0_A_Unit78__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(370, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_147; var tmp2 any = A_arbace_go_check_types_typeset_all_A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_go_check_types_typeset_all_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_go_check_types_typeset_all_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_148)); return A_arbace_go_check_types__init_part0_A_const_147 }




func A_arbace_go_check_types__init_part0_A_Unit79__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(375, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_76; var tmp2 any = A_arbace_go_check_types_under_is_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_go_check_types_under_is_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_go_check_types_under_is_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_149)); return A_arbace_go_check_types__init_part0_A_const_76 }





func A_arbace_go_check_types__init_part0_A_Unit80__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(381, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_150; var tmp2 any = A_arbace_go_check_types_all_basic_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_go_check_types_all_basic_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_go_check_types_all_basic_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_150; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_151)); return A_arbace_go_check_types__init_part0_A_const_150 }








func A_arbace_go_check_types__init_part0_A_Unit81__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(390, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_152; var tmp2 any = A_arbace_go_check_types_all_integer_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_go_check_types_all_integer_QMARK__A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_go_check_types_all_integer_QMARK__A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_153)); return A_arbace_go_check_types__init_part0_A_const_152 }
func A_arbace_go_check_types__init_part0_A_Unit82__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(391, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_154; var tmp2 any = A_arbace_go_check_types_all_unsigned_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_go_check_types_all_unsigned_QMARK__A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_go_check_types_all_unsigned_QMARK__A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_155)); return A_arbace_go_check_types__init_part0_A_const_154 }
func A_arbace_go_check_types__init_part0_A_Unit83__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(392, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_156; var tmp2 any = A_arbace_go_check_types_all_numeric_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_go_check_types_all_numeric_QMARK__A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_go_check_types_all_numeric_QMARK__A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_157)); return A_arbace_go_check_types__init_part0_A_const_156 }
func A_arbace_go_check_types__init_part0_A_Unit84__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(393, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_158; var tmp2 any = A_arbace_go_check_types_all_string_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_go_check_types_all_string_QMARK__A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_go_check_types_all_string_QMARK__A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_158; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_159)); return A_arbace_go_check_types__init_part0_A_const_158 }
func A_arbace_go_check_types__init_part0_A_Unit85__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(394, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_160; var tmp2 any = A_arbace_go_check_types_all_boolean_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_go_check_types_all_boolean_QMARK__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_go_check_types_all_boolean_QMARK__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_160; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_161)); return A_arbace_go_check_types__init_part0_A_const_160 }
func A_arbace_go_check_types__init_part0_A_Unit86__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(395, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_162; var tmp2 any = A_arbace_go_check_types_all_ordered_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_go_check_types_all_ordered_QMARK__A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_go_check_types_all_ordered_QMARK__A_fn_class = fncls__74d; tmp3 = fncls__74d } else { tmp3 = fncls__74 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_162; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_163)); return A_arbace_go_check_types__init_part0_A_const_162 }
func A_arbace_go_check_types__init_part0_A_Unit87__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(396, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_164; var tmp2 any = A_arbace_go_check_types_all_numeric_or_string_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_go_check_types_all_numeric_or_string_QMARK__A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_go_check_types_all_numeric_or_string_QMARK__A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_164; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_165)); return A_arbace_go_check_types__init_part0_A_const_164 }
func A_arbace_go_check_types__init_part0_A_Unit88__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(397, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_166; var tmp2 any = A_arbace_go_check_types_all_float_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_go_check_types_all_float_QMARK__A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_go_check_types_all_float_QMARK__A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_166; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_167)); return A_arbace_go_check_types__init_part0_A_const_166 }
func A_arbace_go_check_types__init_part0_A_Unit89__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(398, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_168; var tmp2 any = A_arbace_go_check_types_all_complex_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_go_check_types_all_complex_QMARK__A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_155, false); A_arbace_go_check_types_all_complex_QMARK__A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_168; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_169)); return A_arbace_go_check_types__init_part0_A_const_168 }

func A_arbace_go_check_types__init_part0_A_Unit90__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(400, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_170; var tmp2 any = A_arbace_go_check_types_common_under_A_New(); var tmp3 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_go_check_types_common_under_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_156, false); A_arbace_go_check_types_common_under_A_fn_class = fncls__78d; tmp3 = fncls__78d } else { tmp3 = fncls__78 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_170; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_171)); return A_arbace_go_check_types__init_part0_A_const_170 }
























func A_arbace_go_check_types__init_part0_A_Unit91__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(425, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_172; var tmp2 any = A_arbace_go_check_types_core_type_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_go_check_types_core_type_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_157, false); A_arbace_go_check_types_core_type_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_172; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_173)); return A_arbace_go_check_types__init_part0_A_const_172 }






func A_arbace_go_check_types__init_part0_A_Unit92__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(432, 1); A_arbace_go_check_types__init_part0_A_const_174.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_174; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_175)); return A_arbace_go_check_types__init_part0_A_const_174.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_types__init_part0_A_Unit93__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(437, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_90; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_176)); return A_arbace_go_check_types__init_part0_A_const_90 }

func A_arbace_go_check_types__init_part0_A_Unit94__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(439, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_177; var tmp2 any = A_arbace_go_check_types_terms_str_A_New(); var tmp3 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_go_check_types_terms_str_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_158, false); A_arbace_go_check_types_terms_str_A_fn_class = fncls__80d; tmp3 = fncls__80d } else { tmp3 = fncls__80 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_177; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_178)); return A_arbace_go_check_types__init_part0_A_const_177 }





func A_arbace_go_check_types__init_part0_A_Unit95__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(445, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_179; var tmp2 any = A_arbace_go_check_types_params_str_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_go_check_types_params_str_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_159, false); A_arbace_go_check_types_params_str_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_179; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_180)); return A_arbace_go_check_types__init_part0_A_const_179 }








func A_arbace_go_check_types__init_part0_A_Unit96__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(454, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_181; var tmp2 any = A_arbace_go_check_types_sig_str_A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_go_check_types_sig_str_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_160, false); A_arbace_go_check_types_sig_str_A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_181; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_182)); return A_arbace_go_check_types__init_part0_A_const_181 }








func A_arbace_go_check_types__init_part0_A_Unit97__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(463, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_183; var tmp2 any = A_arbace_go_check_types_field_str_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_go_check_types_field_str_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_161, false); A_arbace_go_check_types_field_str_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_183; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_184)); return A_arbace_go_check_types__init_part0_A_const_183 }



func A_arbace_go_check_types__init_part0_A_Unit98__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(467, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_185; var tmp2 any = A_arbace_go_check_types_named_str_A_New(); var tmp3 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_go_check_types_named_str_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_162, false); A_arbace_go_check_types_named_str_A_fn_class = fncls__84d; tmp3 = fncls__84d } else { tmp3 = fncls__84 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_185; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_186)); return A_arbace_go_check_types__init_part0_A_const_185 }








func A_arbace_go_check_types__init_part0_A_Unit99__O() any { A_arbace_go_check_types__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(476, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part0_A_const_90; var tmp2 any = A_arbace_go_check_types_type_str_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_go_check_types_type_str_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_163, false); A_arbace_go_check_types_type_str_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part0_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part0_A_const_187)); return A_arbace_go_check_types__init_part0_A_const_90 }


































func A_arbace_go_check_types__init_part1_A_Unit100__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(511, 1); A_arbace_go_check_types__init_part1_A_const_0.BindRoot_O__V(A_arbace_go_check_types__init_part1_A_const_1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_0; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_2)); return A_arbace_go_check_types__init_part1_A_const_0 }
//line :511:1
func A_arbace_go_check_types__init_part1_A_Init__O() any { A_arbace_go_check_types__init_part1_A_Init(); return nil }
//line :511:1
func A_arbace_go_check_types__init_part1_A_Load__O() any { A_arbace_go_check_types__init_part1_A_Init(); A_arbace_go_check_types__init_part1_A_Unit100__O(); A_arbace_go_check_types__init_part1_A_Unit101__O(); A_arbace_go_check_types__init_part1_A_Unit102__O(); A_arbace_go_check_types__init_part1_A_Unit103__O(); A_arbace_go_check_types__init_part1_A_Unit104__O(); A_arbace_go_check_types__init_part1_A_Unit105__O(); A_arbace_go_check_types__init_part1_A_Unit106__O(); A_arbace_go_check_types__init_part1_A_Unit107__O(); A_arbace_go_check_types__init_part1_A_Unit108__O(); A_arbace_go_check_types__init_part1_A_Unit109__O(); A_arbace_go_check_types__init_part1_A_Unit110__O(); A_arbace_go_check_types__init_part1_A_Unit111__O(); A_arbace_go_check_types__init_part1_A_Unit112__O(); A_arbace_go_check_types__init_part1_A_Unit113__O(); A_arbace_go_check_types__init_part1_A_Unit114__O(); A_arbace_go_check_types__init_part1_A_Unit115__O(); A_arbace_go_check_types__init_part1_A_Unit116__O(); A_arbace_go_check_types__init_part1_A_Unit117__O(); A_arbace_go_check_types__init_part1_A_Unit118__O(); A_arbace_go_check_types__init_part1_A_Unit119__O(); A_arbace_go_check_types__init_part1_A_Unit120__O(); A_arbace_go_check_types__init_part1_A_Unit121__O(); A_arbace_go_check_types__init_part1_A_Unit122__O(); A_arbace_go_check_types__init_part1_A_Unit123__O(); return nil }
func A_arbace_go_check_types__init_part1_A_Unit101__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(512, 1); A_arbace_go_check_types__init_part1_A_const_3.BindRoot_O__V(A_arbace_go_check_types__init_part1_A_const_1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_3; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_4)); return A_arbace_go_check_types__init_part1_A_const_3 }

func A_arbace_go_check_types__init_part1_A_Unit102__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(514, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_5; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_6)); return A_arbace_go_check_types__init_part1_A_const_5 }

func A_arbace_go_check_types__init_part1_A_Unit103__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(516, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_7; var tmp2 any = A_arbace_go_check_types_align_up_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_types_align_up_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_165, false); A_arbace_go_check_types_align_up_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_8)); return A_arbace_go_check_types__init_part1_A_const_7 }




func A_arbace_go_check_types__init_part1_A_Unit104__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(521, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_9; var tmp2 any = A_arbace_go_check_types_sync_atomic_align64_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_166, false); A_arbace_go_check_types_sync_atomic_align64_QMARK__A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_10)); return A_arbace_go_check_types__init_part1_A_const_9 }








func A_arbace_go_check_types__init_part1_A_Unit105__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(530, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_11; var tmp2 any = A_arbace_go_check_types_alignof_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_types_alignof_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_167, false); A_arbace_go_check_types_alignof_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_12)); return A_arbace_go_check_types__init_part1_A_const_11 }















func A_arbace_go_check_types__init_part1_A_Unit106__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(546, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_13; var tmp2 any = A_arbace_go_check_types_offsetsof_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_go_check_types_offsetsof_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_168, false); A_arbace_go_check_types_offsetsof_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_14)); return A_arbace_go_check_types__init_part1_A_const_13 }















func A_arbace_go_check_types__init_part1_A_Unit107__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(562, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_5; var tmp2 any = A_arbace_go_check_types_sizeof_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_types_sizeof_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_169, false); A_arbace_go_check_types_sizeof_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_5; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_15)); return A_arbace_go_check_types__init_part1_A_const_5 }

































func A_arbace_go_check_types__init_part1_A_Unit108__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(596, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_16; var tmp2 any = A_arbace_go_check_types_deref_type_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_go_check_types_deref_type_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_170, false); A_arbace_go_check_types_deref_type_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_17)); return A_arbace_go_check_types__init_part1_A_const_16 }




func A_arbace_go_check_types__init_part1_A_Unit109__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(601, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_18; var tmp2 any = A_arbace_go_check_types_methods_of_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_types_methods_of_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_171, false); A_arbace_go_check_types_methods_of_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_19)); return A_arbace_go_check_types__init_part1_A_const_18 }






func A_arbace_go_check_types__init_part1_A_Unit110__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(608, 1); A_arbace_go_check_types__init_part1_A_const_20.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_21)); return A_arbace_go_check_types__init_part1_A_const_20.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_types__init_part1_A_Unit111__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(612, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_22; var tmp2 any = A_arbace_go_check_types_same_id_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_go_check_types_same_id_QMARK__A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_172, false); A_arbace_go_check_types_same_id_QMARK__A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_23)); return A_arbace_go_check_types__init_part1_A_const_22 }











func A_arbace_go_check_types__init_part1_A_Unit112__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(624, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_24; var tmp2 any = A_arbace_go_check_types_exported_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_types_exported_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_173, false); A_arbace_go_check_types_exported_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_25)); return A_arbace_go_check_types__init_part1_A_const_24 }


func A_arbace_go_check_types__init_part1_A_Unit113__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(627, 1); A_arbace_go_check_types__init_part1_A_const_26.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_27)); return A_arbace_go_check_types__init_part1_A_const_26.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_types__init_part1_A_Unit114__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(632, 1); A_arbace_go_check_types__init_part1_A_const_28.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_29)); return A_arbace_go_check_types__init_part1_A_const_28.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_types__init_part1_A_Unit115__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(637, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_30; var tmp2 any = A_arbace_go_check_types_named_method_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_go_check_types_named_method_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_174, false); A_arbace_go_check_types_named_method_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_31)); return A_arbace_go_check_types__init_part1_A_const_30 }











func A_arbace_go_check_types__init_part1_A_Unit116__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(649, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_32; var tmp2 any = A_arbace_go_check_types_iface_method_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_types_iface_method_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_175, false); A_arbace_go_check_types_iface_method_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_33)); return A_arbace_go_check_types__init_part1_A_const_32 }










func A_arbace_go_check_types__init_part1_A_Unit117__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(660, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_34; var tmp2 any = A_arbace_go_check_types_consolidate_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_go_check_types_consolidate_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_176, false); A_arbace_go_check_types_consolidate_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_35)); return A_arbace_go_check_types__init_part1_A_const_34 }











func A_arbace_go_check_types__init_part1_A_Unit118__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(672, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_36; var tmp2 any = A_arbace_go_check_types_lookup_impl_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_types_lookup_impl_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_177, false); A_arbace_go_check_types_lookup_impl_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_37)); return A_arbace_go_check_types__init_part1_A_const_36 }



































































func A_arbace_go_check_types__init_part1_A_Unit119__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(740, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_38; var tmp2 any = A_arbace_go_check_types_lookup_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_go_check_types_lookup_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_178, false); A_arbace_go_check_types_lookup_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_39)); return A_arbace_go_check_types__init_part1_A_const_38 }









func A_arbace_go_check_types__init_part1_A_Unit120__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(750, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_40; var tmp2 any = A_arbace_go_check_types_sort_methods_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_types_sort_methods_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_179, false); A_arbace_go_check_types_sort_methods_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_41)); return A_arbace_go_check_types__init_part1_A_const_40 }




func A_arbace_go_check_types__init_part1_A_Unit121__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(755, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_42; var tmp2 any = A_arbace_go_check_types_method_data_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_go_check_types_method_data_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_180, false); A_arbace_go_check_types_method_data_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_43)); return A_arbace_go_check_types__init_part1_A_const_42 }




func A_arbace_go_check_types__init_part1_A_Unit122__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(760, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_44; var tmp2 any = A_arbace_go_check_types_missing_method_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_check_types_missing_method_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_181, false); A_arbace_go_check_types_missing_method_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_45)); return A_arbace_go_check_types__init_part1_A_const_44 }







































func A_arbace_go_check_types__init_part1_A_Unit123__O() any { A_arbace_go_check_types__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(800, 1); var tmp1 *lang.Var = A_arbace_go_check_types__init_part1_A_const_46; var tmp2 any = A_arbace_go_check_types_satisfies_cause_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_go_check_types_satisfies_cause_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_182, false); A_arbace_go_check_types_satisfies_cause_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_types__init_part1_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_types__init_part1_A_const_47)); return A_arbace_go_check_types__init_part1_A_const_46 }



type A_arbace_go_check_types__init_A struct{ jrt.Object }

func A_arbace_go_check_types__init_A_New() *A_arbace_go_check_types__init_A { t := &A_arbace_go_check_types__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types__init_A) Ctor() {}

func (t *A_arbace_go_check_types__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types__init_A_class }

func (t *A_arbace_go_check_types__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types__init_A); return ok }

func A_arbace_go_check_types__init_A_Cast(x any) *A_arbace_go_check_types__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types__init_A_class)) }; return v }



type A_arbace_go_check_types__init_part0_A struct{ jrt.Object }

var A_arbace_go_check_types__init_part0_A_const_pool *jrt.RefArray

var A_arbace_go_check_types__init_part0_A_const_0 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_1 any

var A_arbace_go_check_types__init_part0_A_const_2 any

var A_arbace_go_check_types__init_part0_A_const_3 any

var A_arbace_go_check_types__init_part0_A_const_4 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_5 any

var A_arbace_go_check_types__init_part0_A_const_6 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_7 any

var A_arbace_go_check_types__init_part0_A_const_8 any

var A_arbace_go_check_types__init_part0_A_const_9 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_10 any

var A_arbace_go_check_types__init_part0_A_const_11 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_12 any

var A_arbace_go_check_types__init_part0_A_const_13 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_14 any

var A_arbace_go_check_types__init_part0_A_const_15 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_16 any

var A_arbace_go_check_types__init_part0_A_const_17 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_18 any

var A_arbace_go_check_types__init_part0_A_const_19 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_20 any

var A_arbace_go_check_types__init_part0_A_const_21 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_22 any

var A_arbace_go_check_types__init_part0_A_const_23 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_24 any

var A_arbace_go_check_types__init_part0_A_const_25 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_26 any

var A_arbace_go_check_types__init_part0_A_const_27 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_28 any

var A_arbace_go_check_types__init_part0_A_const_29 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_30 any

var A_arbace_go_check_types__init_part0_A_const_31 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_32 any

var A_arbace_go_check_types__init_part0_A_const_33 any

var A_arbace_go_check_types__init_part0_A_const_34 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_35 any

var A_arbace_go_check_types__init_part0_A_const_36 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_37 any

var A_arbace_go_check_types__init_part0_A_const_38 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_39 any

var A_arbace_go_check_types__init_part0_A_const_40 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_41 any

var A_arbace_go_check_types__init_part0_A_const_42 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_43 any

var A_arbace_go_check_types__init_part0_A_const_44 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_45 any

var A_arbace_go_check_types__init_part0_A_const_46 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_47 any

var A_arbace_go_check_types__init_part0_A_const_48 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_49 any

var A_arbace_go_check_types__init_part0_A_const_50 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_51 any

var A_arbace_go_check_types__init_part0_A_const_52 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_53 any

var A_arbace_go_check_types__init_part0_A_const_54 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_55 any

var A_arbace_go_check_types__init_part0_A_const_56 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_57 any

var A_arbace_go_check_types__init_part0_A_const_58 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_59 any

var A_arbace_go_check_types__init_part0_A_const_60 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_61 any

var A_arbace_go_check_types__init_part0_A_const_62 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_63 any

var A_arbace_go_check_types__init_part0_A_const_64 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_65 any

var A_arbace_go_check_types__init_part0_A_const_66 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_67 any

var A_arbace_go_check_types__init_part0_A_const_68 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_69 any

var A_arbace_go_check_types__init_part0_A_const_70 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_71 any

var A_arbace_go_check_types__init_part0_A_const_72 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_73 any

var A_arbace_go_check_types__init_part0_A_const_74 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_75 any

var A_arbace_go_check_types__init_part0_A_const_76 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_77 any

var A_arbace_go_check_types__init_part0_A_const_78 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_79 any

var A_arbace_go_check_types__init_part0_A_const_80 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_81 any

var A_arbace_go_check_types__init_part0_A_const_82 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_83 any

var A_arbace_go_check_types__init_part0_A_const_84 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_85 any

var A_arbace_go_check_types__init_part0_A_const_86 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_87 any

var A_arbace_go_check_types__init_part0_A_const_88 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_89 any

var A_arbace_go_check_types__init_part0_A_const_90 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_91 any

var A_arbace_go_check_types__init_part0_A_const_92 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_93 any

var A_arbace_go_check_types__init_part0_A_const_94 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_95 any

var A_arbace_go_check_types__init_part0_A_const_96 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_97 any

var A_arbace_go_check_types__init_part0_A_const_98 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_99 any

var A_arbace_go_check_types__init_part0_A_const_100 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_101 any

var A_arbace_go_check_types__init_part0_A_const_102 any

var A_arbace_go_check_types__init_part0_A_const_103 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_104 any

var A_arbace_go_check_types__init_part0_A_const_105 any

var A_arbace_go_check_types__init_part0_A_const_106 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_107 any

var A_arbace_go_check_types__init_part0_A_const_108 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_109 any

var A_arbace_go_check_types__init_part0_A_const_110 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_111 any

var A_arbace_go_check_types__init_part0_A_const_112 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_113 any

var A_arbace_go_check_types__init_part0_A_const_114 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_115 any

var A_arbace_go_check_types__init_part0_A_const_116 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_117 any

var A_arbace_go_check_types__init_part0_A_const_118 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_119 any

var A_arbace_go_check_types__init_part0_A_const_120 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_121 any

var A_arbace_go_check_types__init_part0_A_const_122 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_123 any

var A_arbace_go_check_types__init_part0_A_const_124 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_125 any

var A_arbace_go_check_types__init_part0_A_const_126 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_127 any

var A_arbace_go_check_types__init_part0_A_const_128 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_129 any

var A_arbace_go_check_types__init_part0_A_const_130 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_131 any

var A_arbace_go_check_types__init_part0_A_const_132 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_133 any

var A_arbace_go_check_types__init_part0_A_const_134 any

var A_arbace_go_check_types__init_part0_A_const_135 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_136 any

var A_arbace_go_check_types__init_part0_A_const_137 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_138 any

var A_arbace_go_check_types__init_part0_A_const_139 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_140 any

var A_arbace_go_check_types__init_part0_A_const_141 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_142 any

var A_arbace_go_check_types__init_part0_A_const_143 any

var A_arbace_go_check_types__init_part0_A_const_144 any

var A_arbace_go_check_types__init_part0_A_const_145 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_146 any

var A_arbace_go_check_types__init_part0_A_const_147 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_148 any

var A_arbace_go_check_types__init_part0_A_const_149 any

var A_arbace_go_check_types__init_part0_A_const_150 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_151 any

var A_arbace_go_check_types__init_part0_A_const_152 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_153 any

var A_arbace_go_check_types__init_part0_A_const_154 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_155 any

var A_arbace_go_check_types__init_part0_A_const_156 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_157 any

var A_arbace_go_check_types__init_part0_A_const_158 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_159 any

var A_arbace_go_check_types__init_part0_A_const_160 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_161 any

var A_arbace_go_check_types__init_part0_A_const_162 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_163 any

var A_arbace_go_check_types__init_part0_A_const_164 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_165 any

var A_arbace_go_check_types__init_part0_A_const_166 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_167 any

var A_arbace_go_check_types__init_part0_A_const_168 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_169 any

var A_arbace_go_check_types__init_part0_A_const_170 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_171 any

var A_arbace_go_check_types__init_part0_A_const_172 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_173 any

var A_arbace_go_check_types__init_part0_A_const_174 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_175 any

var A_arbace_go_check_types__init_part0_A_const_176 any

var A_arbace_go_check_types__init_part0_A_const_177 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_178 any

var A_arbace_go_check_types__init_part0_A_const_179 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_180 any

var A_arbace_go_check_types__init_part0_A_const_181 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_182 any

var A_arbace_go_check_types__init_part0_A_const_183 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_184 any

var A_arbace_go_check_types__init_part0_A_const_185 *lang.Var

var A_arbace_go_check_types__init_part0_A_const_186 any

var A_arbace_go_check_types__init_part0_A_const_187 any

var A_arbace_go_check_types__init_part0_A_init jrt.ClassInit

func A_arbace_go_check_types__init_part0_A_Init() { if !A_arbace_go_check_types__init_part0_A_init.Done() { A_arbace_go_check_types__init_part0_A_init.Run(A_arbace_go_check_types__init_part0_A_clinit) } }

func A_arbace_go_check_types__init_part0_A_clinit() { A_arbace_go_check_types__init_part0_A_clinit_p0(); A_arbace_go_check_types__init_part0_A_clinit_p1(); A_arbace_go_check_types__init_part0_A_clinit_p2(); A_arbace_go_check_types__init_part0_A_clinit_p3(); A_arbace_go_check_types__init_part0_A_clinit_p4(); A_arbace_go_check_types__init_part0_A_clinit_p5(); A_arbace_go_check_types__init_part0_A_clinit_p6(); A_arbace_go_check_types__init_part0_A_clinit_p7(); A_arbace_go_check_types__init_part0_A_clinit_p8(); A_arbace_go_check_types__init_part0_A_clinit_p9(); A_arbace_go_check_types__init_part0_A_clinit_p10(); A_arbace_go_check_types__init_part0_A_clinit_p11(); A_arbace_go_check_types__init_part0_A_clinit_p12(); A_arbace_go_check_types__init_part0_A_clinit_p13(); A_arbace_go_check_types__init_part0_A_clinit_p14() }

func A_arbace_go_check_types__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_types__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_78, 252); A_arbace_go_check_types__init_part0_A_const_0 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[64]); A_arbace_go_check_types__init_part0_A_const_1 = A_arbace_go_check_types__init_part0_A_const_pool.A[65]; A_arbace_go_check_types__init_part0_A_const_2 = A_arbace_go_check_types__init_part0_A_const_pool.A[66]; A_arbace_go_check_types__init_part0_A_const_3 = A_arbace_go_check_types__init_part0_A_const_pool.A[67]; A_arbace_go_check_types__init_part0_A_const_4 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[68]); A_arbace_go_check_types__init_part0_A_const_5 = A_arbace_go_check_types__init_part0_A_const_pool.A[69]; A_arbace_go_check_types__init_part0_A_const_6 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[70]); A_arbace_go_check_types__init_part0_A_const_7 = A_arbace_go_check_types__init_part0_A_const_pool.A[71]; A_arbace_go_check_types__init_part0_A_const_8 = A_arbace_go_check_types__init_part0_A_const_pool.A[72]; A_arbace_go_check_types__init_part0_A_const_9 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[73]); A_arbace_go_check_types__init_part0_A_const_10 = A_arbace_go_check_types__init_part0_A_const_pool.A[74]; A_arbace_go_check_types__init_part0_A_const_11 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[75]); A_arbace_go_check_types__init_part0_A_const_12 = A_arbace_go_check_types__init_part0_A_const_pool.A[76] }

func A_arbace_go_check_types__init_part0_A_clinit_p1() { A_arbace_go_check_types__init_part0_A_const_13 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[77]); A_arbace_go_check_types__init_part0_A_const_14 = A_arbace_go_check_types__init_part0_A_const_pool.A[78]; A_arbace_go_check_types__init_part0_A_const_15 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[79]); A_arbace_go_check_types__init_part0_A_const_16 = A_arbace_go_check_types__init_part0_A_const_pool.A[80]; A_arbace_go_check_types__init_part0_A_const_17 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[81]); A_arbace_go_check_types__init_part0_A_const_18 = A_arbace_go_check_types__init_part0_A_const_pool.A[82]; A_arbace_go_check_types__init_part0_A_const_19 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[83]); A_arbace_go_check_types__init_part0_A_const_20 = A_arbace_go_check_types__init_part0_A_const_pool.A[84]; A_arbace_go_check_types__init_part0_A_const_21 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[85]); A_arbace_go_check_types__init_part0_A_const_22 = A_arbace_go_check_types__init_part0_A_const_pool.A[86]; A_arbace_go_check_types__init_part0_A_const_23 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[87]); A_arbace_go_check_types__init_part0_A_const_24 = A_arbace_go_check_types__init_part0_A_const_pool.A[88]; A_arbace_go_check_types__init_part0_A_const_25 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[89]) }

func A_arbace_go_check_types__init_part0_A_clinit_p2() { A_arbace_go_check_types__init_part0_A_const_26 = A_arbace_go_check_types__init_part0_A_const_pool.A[90]; A_arbace_go_check_types__init_part0_A_const_27 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[91]); A_arbace_go_check_types__init_part0_A_const_28 = A_arbace_go_check_types__init_part0_A_const_pool.A[92]; A_arbace_go_check_types__init_part0_A_const_29 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[93]); A_arbace_go_check_types__init_part0_A_const_30 = A_arbace_go_check_types__init_part0_A_const_pool.A[94]; A_arbace_go_check_types__init_part0_A_const_31 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[95]); A_arbace_go_check_types__init_part0_A_const_32 = A_arbace_go_check_types__init_part0_A_const_pool.A[96]; A_arbace_go_check_types__init_part0_A_const_33 = A_arbace_go_check_types__init_part0_A_const_pool.A[97]; A_arbace_go_check_types__init_part0_A_const_34 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[98]); A_arbace_go_check_types__init_part0_A_const_35 = A_arbace_go_check_types__init_part0_A_const_pool.A[99]; A_arbace_go_check_types__init_part0_A_const_36 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[100]); A_arbace_go_check_types__init_part0_A_const_37 = A_arbace_go_check_types__init_part0_A_const_pool.A[101]; A_arbace_go_check_types__init_part0_A_const_38 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[102]); A_arbace_go_check_types__init_part0_A_const_39 = A_arbace_go_check_types__init_part0_A_const_pool.A[103] }

func A_arbace_go_check_types__init_part0_A_clinit_p3() { A_arbace_go_check_types__init_part0_A_const_40 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[104]); A_arbace_go_check_types__init_part0_A_const_41 = A_arbace_go_check_types__init_part0_A_const_pool.A[105]; A_arbace_go_check_types__init_part0_A_const_42 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[106]); A_arbace_go_check_types__init_part0_A_const_43 = A_arbace_go_check_types__init_part0_A_const_pool.A[107]; A_arbace_go_check_types__init_part0_A_const_44 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[108]); A_arbace_go_check_types__init_part0_A_const_45 = A_arbace_go_check_types__init_part0_A_const_pool.A[109]; A_arbace_go_check_types__init_part0_A_const_46 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[110]); A_arbace_go_check_types__init_part0_A_const_47 = A_arbace_go_check_types__init_part0_A_const_pool.A[111]; A_arbace_go_check_types__init_part0_A_const_48 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[112]); A_arbace_go_check_types__init_part0_A_const_49 = A_arbace_go_check_types__init_part0_A_const_pool.A[113]; A_arbace_go_check_types__init_part0_A_const_50 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[114]); A_arbace_go_check_types__init_part0_A_const_51 = A_arbace_go_check_types__init_part0_A_const_pool.A[115]; A_arbace_go_check_types__init_part0_A_const_52 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[116]) }

func A_arbace_go_check_types__init_part0_A_clinit_p4() { A_arbace_go_check_types__init_part0_A_const_53 = A_arbace_go_check_types__init_part0_A_const_pool.A[117]; A_arbace_go_check_types__init_part0_A_const_54 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[118]); A_arbace_go_check_types__init_part0_A_const_55 = A_arbace_go_check_types__init_part0_A_const_pool.A[119]; A_arbace_go_check_types__init_part0_A_const_56 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[120]); A_arbace_go_check_types__init_part0_A_const_57 = A_arbace_go_check_types__init_part0_A_const_pool.A[121]; A_arbace_go_check_types__init_part0_A_const_58 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[122]); A_arbace_go_check_types__init_part0_A_const_59 = A_arbace_go_check_types__init_part0_A_const_pool.A[123]; A_arbace_go_check_types__init_part0_A_const_60 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[124]); A_arbace_go_check_types__init_part0_A_const_61 = A_arbace_go_check_types__init_part0_A_const_pool.A[125]; A_arbace_go_check_types__init_part0_A_const_62 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[126]); A_arbace_go_check_types__init_part0_A_const_63 = A_arbace_go_check_types__init_part0_A_const_pool.A[127]; A_arbace_go_check_types__init_part0_A_const_64 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[128]); A_arbace_go_check_types__init_part0_A_const_65 = A_arbace_go_check_types__init_part0_A_const_pool.A[129] }

func A_arbace_go_check_types__init_part0_A_clinit_p5() { A_arbace_go_check_types__init_part0_A_const_66 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[130]); A_arbace_go_check_types__init_part0_A_const_67 = A_arbace_go_check_types__init_part0_A_const_pool.A[131]; A_arbace_go_check_types__init_part0_A_const_68 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[132]); A_arbace_go_check_types__init_part0_A_const_69 = A_arbace_go_check_types__init_part0_A_const_pool.A[133]; A_arbace_go_check_types__init_part0_A_const_70 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[134]); A_arbace_go_check_types__init_part0_A_const_71 = A_arbace_go_check_types__init_part0_A_const_pool.A[135]; A_arbace_go_check_types__init_part0_A_const_72 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[136]); A_arbace_go_check_types__init_part0_A_const_73 = A_arbace_go_check_types__init_part0_A_const_pool.A[137]; A_arbace_go_check_types__init_part0_A_const_74 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[138]); A_arbace_go_check_types__init_part0_A_const_75 = A_arbace_go_check_types__init_part0_A_const_pool.A[139]; A_arbace_go_check_types__init_part0_A_const_76 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[140]); A_arbace_go_check_types__init_part0_A_const_77 = A_arbace_go_check_types__init_part0_A_const_pool.A[141]; A_arbace_go_check_types__init_part0_A_const_78 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[142]) }

func A_arbace_go_check_types__init_part0_A_clinit_p6() { A_arbace_go_check_types__init_part0_A_const_79 = A_arbace_go_check_types__init_part0_A_const_pool.A[143]; A_arbace_go_check_types__init_part0_A_const_80 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[144]); A_arbace_go_check_types__init_part0_A_const_81 = A_arbace_go_check_types__init_part0_A_const_pool.A[145]; A_arbace_go_check_types__init_part0_A_const_82 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[146]); A_arbace_go_check_types__init_part0_A_const_83 = A_arbace_go_check_types__init_part0_A_const_pool.A[147]; A_arbace_go_check_types__init_part0_A_const_84 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[148]); A_arbace_go_check_types__init_part0_A_const_85 = A_arbace_go_check_types__init_part0_A_const_pool.A[149]; A_arbace_go_check_types__init_part0_A_const_86 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[150]); A_arbace_go_check_types__init_part0_A_const_87 = A_arbace_go_check_types__init_part0_A_const_pool.A[151]; A_arbace_go_check_types__init_part0_A_const_88 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[152]); A_arbace_go_check_types__init_part0_A_const_89 = A_arbace_go_check_types__init_part0_A_const_pool.A[153]; A_arbace_go_check_types__init_part0_A_const_90 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[154]); A_arbace_go_check_types__init_part0_A_const_91 = A_arbace_go_check_types__init_part0_A_const_pool.A[155] }

func A_arbace_go_check_types__init_part0_A_clinit_p7() { A_arbace_go_check_types__init_part0_A_const_92 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[156]); A_arbace_go_check_types__init_part0_A_const_93 = A_arbace_go_check_types__init_part0_A_const_pool.A[157]; A_arbace_go_check_types__init_part0_A_const_94 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[158]); A_arbace_go_check_types__init_part0_A_const_95 = A_arbace_go_check_types__init_part0_A_const_pool.A[159]; A_arbace_go_check_types__init_part0_A_const_96 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[160]); A_arbace_go_check_types__init_part0_A_const_97 = A_arbace_go_check_types__init_part0_A_const_pool.A[161]; A_arbace_go_check_types__init_part0_A_const_98 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[162]); A_arbace_go_check_types__init_part0_A_const_99 = A_arbace_go_check_types__init_part0_A_const_pool.A[163]; A_arbace_go_check_types__init_part0_A_const_100 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[164]); A_arbace_go_check_types__init_part0_A_const_101 = A_arbace_go_check_types__init_part0_A_const_pool.A[165]; A_arbace_go_check_types__init_part0_A_const_102 = A_arbace_go_check_types__init_part0_A_const_pool.A[166]; A_arbace_go_check_types__init_part0_A_const_103 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[167]); A_arbace_go_check_types__init_part0_A_const_104 = A_arbace_go_check_types__init_part0_A_const_pool.A[168]; A_arbace_go_check_types__init_part0_A_const_105 = A_arbace_go_check_types__init_part0_A_const_pool.A[169] }

func A_arbace_go_check_types__init_part0_A_clinit_p8() { A_arbace_go_check_types__init_part0_A_const_106 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[170]); A_arbace_go_check_types__init_part0_A_const_107 = A_arbace_go_check_types__init_part0_A_const_pool.A[171]; A_arbace_go_check_types__init_part0_A_const_108 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[172]); A_arbace_go_check_types__init_part0_A_const_109 = A_arbace_go_check_types__init_part0_A_const_pool.A[173]; A_arbace_go_check_types__init_part0_A_const_110 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[174]); A_arbace_go_check_types__init_part0_A_const_111 = A_arbace_go_check_types__init_part0_A_const_pool.A[175]; A_arbace_go_check_types__init_part0_A_const_112 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[176]); A_arbace_go_check_types__init_part0_A_const_113 = A_arbace_go_check_types__init_part0_A_const_pool.A[177]; A_arbace_go_check_types__init_part0_A_const_114 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[178]); A_arbace_go_check_types__init_part0_A_const_115 = A_arbace_go_check_types__init_part0_A_const_pool.A[179]; A_arbace_go_check_types__init_part0_A_const_116 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[180]); A_arbace_go_check_types__init_part0_A_const_117 = A_arbace_go_check_types__init_part0_A_const_pool.A[181]; A_arbace_go_check_types__init_part0_A_const_118 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[182]) }

func A_arbace_go_check_types__init_part0_A_clinit_p9() { A_arbace_go_check_types__init_part0_A_const_119 = A_arbace_go_check_types__init_part0_A_const_pool.A[183]; A_arbace_go_check_types__init_part0_A_const_120 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[184]); A_arbace_go_check_types__init_part0_A_const_121 = A_arbace_go_check_types__init_part0_A_const_pool.A[185]; A_arbace_go_check_types__init_part0_A_const_122 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[186]); A_arbace_go_check_types__init_part0_A_const_123 = A_arbace_go_check_types__init_part0_A_const_pool.A[187]; A_arbace_go_check_types__init_part0_A_const_124 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[188]); A_arbace_go_check_types__init_part0_A_const_125 = A_arbace_go_check_types__init_part0_A_const_pool.A[189]; A_arbace_go_check_types__init_part0_A_const_126 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[190]); A_arbace_go_check_types__init_part0_A_const_127 = A_arbace_go_check_types__init_part0_A_const_pool.A[191]; A_arbace_go_check_types__init_part0_A_const_128 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[192]); A_arbace_go_check_types__init_part0_A_const_129 = A_arbace_go_check_types__init_part0_A_const_pool.A[193]; A_arbace_go_check_types__init_part0_A_const_130 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[194]); A_arbace_go_check_types__init_part0_A_const_131 = A_arbace_go_check_types__init_part0_A_const_pool.A[195] }

func A_arbace_go_check_types__init_part0_A_clinit_p10() { A_arbace_go_check_types__init_part0_A_const_132 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[196]); A_arbace_go_check_types__init_part0_A_const_133 = A_arbace_go_check_types__init_part0_A_const_pool.A[197]; A_arbace_go_check_types__init_part0_A_const_134 = A_arbace_go_check_types__init_part0_A_const_pool.A[198]; A_arbace_go_check_types__init_part0_A_const_135 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[199]); A_arbace_go_check_types__init_part0_A_const_136 = A_arbace_go_check_types__init_part0_A_const_pool.A[200]; A_arbace_go_check_types__init_part0_A_const_137 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[201]); A_arbace_go_check_types__init_part0_A_const_138 = A_arbace_go_check_types__init_part0_A_const_pool.A[202]; A_arbace_go_check_types__init_part0_A_const_139 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[203]); A_arbace_go_check_types__init_part0_A_const_140 = A_arbace_go_check_types__init_part0_A_const_pool.A[204]; A_arbace_go_check_types__init_part0_A_const_141 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[205]); A_arbace_go_check_types__init_part0_A_const_142 = A_arbace_go_check_types__init_part0_A_const_pool.A[206]; A_arbace_go_check_types__init_part0_A_const_143 = A_arbace_go_check_types__init_part0_A_const_pool.A[207]; A_arbace_go_check_types__init_part0_A_const_144 = A_arbace_go_check_types__init_part0_A_const_pool.A[208]; A_arbace_go_check_types__init_part0_A_const_145 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[209]) }

func A_arbace_go_check_types__init_part0_A_clinit_p11() { A_arbace_go_check_types__init_part0_A_const_146 = A_arbace_go_check_types__init_part0_A_const_pool.A[210]; A_arbace_go_check_types__init_part0_A_const_147 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[211]); A_arbace_go_check_types__init_part0_A_const_148 = A_arbace_go_check_types__init_part0_A_const_pool.A[212]; A_arbace_go_check_types__init_part0_A_const_149 = A_arbace_go_check_types__init_part0_A_const_pool.A[213]; A_arbace_go_check_types__init_part0_A_const_150 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[214]); A_arbace_go_check_types__init_part0_A_const_151 = A_arbace_go_check_types__init_part0_A_const_pool.A[215]; A_arbace_go_check_types__init_part0_A_const_152 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[216]); A_arbace_go_check_types__init_part0_A_const_153 = A_arbace_go_check_types__init_part0_A_const_pool.A[217]; A_arbace_go_check_types__init_part0_A_const_154 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[218]); A_arbace_go_check_types__init_part0_A_const_155 = A_arbace_go_check_types__init_part0_A_const_pool.A[219]; A_arbace_go_check_types__init_part0_A_const_156 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[220]); A_arbace_go_check_types__init_part0_A_const_157 = A_arbace_go_check_types__init_part0_A_const_pool.A[221]; A_arbace_go_check_types__init_part0_A_const_158 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[222]); A_arbace_go_check_types__init_part0_A_const_159 = A_arbace_go_check_types__init_part0_A_const_pool.A[223] }

func A_arbace_go_check_types__init_part0_A_clinit_p12() { A_arbace_go_check_types__init_part0_A_const_160 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[224]); A_arbace_go_check_types__init_part0_A_const_161 = A_arbace_go_check_types__init_part0_A_const_pool.A[225]; A_arbace_go_check_types__init_part0_A_const_162 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[226]); A_arbace_go_check_types__init_part0_A_const_163 = A_arbace_go_check_types__init_part0_A_const_pool.A[227]; A_arbace_go_check_types__init_part0_A_const_164 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[228]); A_arbace_go_check_types__init_part0_A_const_165 = A_arbace_go_check_types__init_part0_A_const_pool.A[229]; A_arbace_go_check_types__init_part0_A_const_166 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[230]); A_arbace_go_check_types__init_part0_A_const_167 = A_arbace_go_check_types__init_part0_A_const_pool.A[231]; A_arbace_go_check_types__init_part0_A_const_168 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[232]); A_arbace_go_check_types__init_part0_A_const_169 = A_arbace_go_check_types__init_part0_A_const_pool.A[233]; A_arbace_go_check_types__init_part0_A_const_170 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[234]); A_arbace_go_check_types__init_part0_A_const_171 = A_arbace_go_check_types__init_part0_A_const_pool.A[235]; A_arbace_go_check_types__init_part0_A_const_172 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[236]) }

func A_arbace_go_check_types__init_part0_A_clinit_p13() { A_arbace_go_check_types__init_part0_A_const_173 = A_arbace_go_check_types__init_part0_A_const_pool.A[237]; A_arbace_go_check_types__init_part0_A_const_174 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[238]); A_arbace_go_check_types__init_part0_A_const_175 = A_arbace_go_check_types__init_part0_A_const_pool.A[239]; A_arbace_go_check_types__init_part0_A_const_176 = A_arbace_go_check_types__init_part0_A_const_pool.A[240]; A_arbace_go_check_types__init_part0_A_const_177 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[241]); A_arbace_go_check_types__init_part0_A_const_178 = A_arbace_go_check_types__init_part0_A_const_pool.A[242]; A_arbace_go_check_types__init_part0_A_const_179 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[243]); A_arbace_go_check_types__init_part0_A_const_180 = A_arbace_go_check_types__init_part0_A_const_pool.A[244]; A_arbace_go_check_types__init_part0_A_const_181 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[245]); A_arbace_go_check_types__init_part0_A_const_182 = A_arbace_go_check_types__init_part0_A_const_pool.A[246]; A_arbace_go_check_types__init_part0_A_const_183 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[247]); A_arbace_go_check_types__init_part0_A_const_184 = A_arbace_go_check_types__init_part0_A_const_pool.A[248]; A_arbace_go_check_types__init_part0_A_const_185 = lang.Var_Cast(A_arbace_go_check_types__init_part0_A_const_pool.A[249]); A_arbace_go_check_types__init_part0_A_const_186 = A_arbace_go_check_types__init_part0_A_const_pool.A[250] }

func A_arbace_go_check_types__init_part0_A_clinit_p14() { A_arbace_go_check_types__init_part0_A_const_187 = A_arbace_go_check_types__init_part0_A_const_pool.A[251] }

func A_arbace_go_check_types__init_part0_A_New() *A_arbace_go_check_types__init_part0_A { A_arbace_go_check_types__init_part0_A_Init(); t := &A_arbace_go_check_types__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types__init_part0_A) Ctor() {}

func (t *A_arbace_go_check_types__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types__init_part0_A_class }

func (t *A_arbace_go_check_types__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types__init_part0_A); return ok }

func A_arbace_go_check_types__init_part0_A_Cast(x any) *A_arbace_go_check_types__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types__init_part0_A_class)) }; return v }



type A_arbace_go_check_types__init_part1_A struct{ jrt.Object }

var A_arbace_go_check_types__init_part1_A_const_pool *jrt.RefArray

var A_arbace_go_check_types__init_part1_A_const_0 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_1 any

var A_arbace_go_check_types__init_part1_A_const_2 any

var A_arbace_go_check_types__init_part1_A_const_3 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_4 any

var A_arbace_go_check_types__init_part1_A_const_5 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_6 any

var A_arbace_go_check_types__init_part1_A_const_7 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_8 any

var A_arbace_go_check_types__init_part1_A_const_9 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_10 any

var A_arbace_go_check_types__init_part1_A_const_11 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_12 any

var A_arbace_go_check_types__init_part1_A_const_13 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_14 any

var A_arbace_go_check_types__init_part1_A_const_15 any

var A_arbace_go_check_types__init_part1_A_const_16 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_17 any

var A_arbace_go_check_types__init_part1_A_const_18 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_19 any

var A_arbace_go_check_types__init_part1_A_const_20 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_21 any

var A_arbace_go_check_types__init_part1_A_const_22 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_23 any

var A_arbace_go_check_types__init_part1_A_const_24 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_25 any

var A_arbace_go_check_types__init_part1_A_const_26 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_27 any

var A_arbace_go_check_types__init_part1_A_const_28 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_29 any

var A_arbace_go_check_types__init_part1_A_const_30 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_31 any

var A_arbace_go_check_types__init_part1_A_const_32 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_33 any

var A_arbace_go_check_types__init_part1_A_const_34 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_35 any

var A_arbace_go_check_types__init_part1_A_const_36 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_37 any

var A_arbace_go_check_types__init_part1_A_const_38 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_39 any

var A_arbace_go_check_types__init_part1_A_const_40 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_41 any

var A_arbace_go_check_types__init_part1_A_const_42 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_43 any

var A_arbace_go_check_types__init_part1_A_const_44 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_45 any

var A_arbace_go_check_types__init_part1_A_const_46 *lang.Var

var A_arbace_go_check_types__init_part1_A_const_47 any

var A_arbace_go_check_types__init_part1_A_init jrt.ClassInit

func A_arbace_go_check_types__init_part1_A_Init() { if !A_arbace_go_check_types__init_part1_A_init.Done() { A_arbace_go_check_types__init_part1_A_init.Run(A_arbace_go_check_types__init_part1_A_clinit) } }

func A_arbace_go_check_types__init_part1_A_clinit() { A_arbace_go_check_types__init_part1_A_clinit_p0(); A_arbace_go_check_types__init_part1_A_clinit_p1(); A_arbace_go_check_types__init_part1_A_clinit_p2(); A_arbace_go_check_types__init_part1_A_clinit_p3() }

func A_arbace_go_check_types__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_types__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_164, 75); A_arbace_go_check_types__init_part1_A_const_0 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[27]); A_arbace_go_check_types__init_part1_A_const_1 = A_arbace_go_check_types__init_part1_A_const_pool.A[28]; A_arbace_go_check_types__init_part1_A_const_2 = A_arbace_go_check_types__init_part1_A_const_pool.A[29]; A_arbace_go_check_types__init_part1_A_const_3 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[30]); A_arbace_go_check_types__init_part1_A_const_4 = A_arbace_go_check_types__init_part1_A_const_pool.A[31]; A_arbace_go_check_types__init_part1_A_const_5 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[32]); A_arbace_go_check_types__init_part1_A_const_6 = A_arbace_go_check_types__init_part1_A_const_pool.A[33]; A_arbace_go_check_types__init_part1_A_const_7 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[34]); A_arbace_go_check_types__init_part1_A_const_8 = A_arbace_go_check_types__init_part1_A_const_pool.A[35]; A_arbace_go_check_types__init_part1_A_const_9 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[36]); A_arbace_go_check_types__init_part1_A_const_10 = A_arbace_go_check_types__init_part1_A_const_pool.A[37]; A_arbace_go_check_types__init_part1_A_const_11 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[38]); A_arbace_go_check_types__init_part1_A_const_12 = A_arbace_go_check_types__init_part1_A_const_pool.A[39] }

func A_arbace_go_check_types__init_part1_A_clinit_p1() { A_arbace_go_check_types__init_part1_A_const_13 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[40]); A_arbace_go_check_types__init_part1_A_const_14 = A_arbace_go_check_types__init_part1_A_const_pool.A[41]; A_arbace_go_check_types__init_part1_A_const_15 = A_arbace_go_check_types__init_part1_A_const_pool.A[42]; A_arbace_go_check_types__init_part1_A_const_16 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[43]); A_arbace_go_check_types__init_part1_A_const_17 = A_arbace_go_check_types__init_part1_A_const_pool.A[44]; A_arbace_go_check_types__init_part1_A_const_18 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[45]); A_arbace_go_check_types__init_part1_A_const_19 = A_arbace_go_check_types__init_part1_A_const_pool.A[46]; A_arbace_go_check_types__init_part1_A_const_20 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[47]); A_arbace_go_check_types__init_part1_A_const_21 = A_arbace_go_check_types__init_part1_A_const_pool.A[48]; A_arbace_go_check_types__init_part1_A_const_22 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[49]); A_arbace_go_check_types__init_part1_A_const_23 = A_arbace_go_check_types__init_part1_A_const_pool.A[50]; A_arbace_go_check_types__init_part1_A_const_24 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[51]); A_arbace_go_check_types__init_part1_A_const_25 = A_arbace_go_check_types__init_part1_A_const_pool.A[52] }

func A_arbace_go_check_types__init_part1_A_clinit_p2() { A_arbace_go_check_types__init_part1_A_const_26 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[53]); A_arbace_go_check_types__init_part1_A_const_27 = A_arbace_go_check_types__init_part1_A_const_pool.A[54]; A_arbace_go_check_types__init_part1_A_const_28 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[55]); A_arbace_go_check_types__init_part1_A_const_29 = A_arbace_go_check_types__init_part1_A_const_pool.A[56]; A_arbace_go_check_types__init_part1_A_const_30 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[57]); A_arbace_go_check_types__init_part1_A_const_31 = A_arbace_go_check_types__init_part1_A_const_pool.A[58]; A_arbace_go_check_types__init_part1_A_const_32 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[59]); A_arbace_go_check_types__init_part1_A_const_33 = A_arbace_go_check_types__init_part1_A_const_pool.A[60]; A_arbace_go_check_types__init_part1_A_const_34 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[61]); A_arbace_go_check_types__init_part1_A_const_35 = A_arbace_go_check_types__init_part1_A_const_pool.A[62]; A_arbace_go_check_types__init_part1_A_const_36 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[63]); A_arbace_go_check_types__init_part1_A_const_37 = A_arbace_go_check_types__init_part1_A_const_pool.A[64]; A_arbace_go_check_types__init_part1_A_const_38 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[65]) }

func A_arbace_go_check_types__init_part1_A_clinit_p3() { A_arbace_go_check_types__init_part1_A_const_39 = A_arbace_go_check_types__init_part1_A_const_pool.A[66]; A_arbace_go_check_types__init_part1_A_const_40 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[67]); A_arbace_go_check_types__init_part1_A_const_41 = A_arbace_go_check_types__init_part1_A_const_pool.A[68]; A_arbace_go_check_types__init_part1_A_const_42 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[69]); A_arbace_go_check_types__init_part1_A_const_43 = A_arbace_go_check_types__init_part1_A_const_pool.A[70]; A_arbace_go_check_types__init_part1_A_const_44 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[71]); A_arbace_go_check_types__init_part1_A_const_45 = A_arbace_go_check_types__init_part1_A_const_pool.A[72]; A_arbace_go_check_types__init_part1_A_const_46 = lang.Var_Cast(A_arbace_go_check_types__init_part1_A_const_pool.A[73]); A_arbace_go_check_types__init_part1_A_const_47 = A_arbace_go_check_types__init_part1_A_const_pool.A[74] }

func A_arbace_go_check_types__init_part1_A_New() *A_arbace_go_check_types__init_part1_A { A_arbace_go_check_types__init_part1_A_Init(); t := &A_arbace_go_check_types__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_types__init_part1_A) Ctor() {}

func (t *A_arbace_go_check_types__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_types__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_types__init_part1_A_class }

func (t *A_arbace_go_check_types__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_types__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_types__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_types__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_types__init_part1_A); return ok }

func A_arbace_go_check_types__init_part1_A_Cast(x any) *A_arbace_go_check_types__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_types__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_types__init_part1_A_class)) }; return v }
