//line a2g_up.ae:1
package aot_arbace_core_print

import "arbace/lang"


func Up_Symbol_IObj(p *lang.Symbol) lang.IObj { if p == nil { return nil }; return p }
