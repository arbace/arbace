//line aot_arbace_core_print__init.ae:1
package aot_arbace_core_print

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_print__init_A_Load__O() any { A_arbace_core_print__init_A_Init(); A_arbace_core_print__init_A_Unit0__O(); A_arbace_core_print__init_A_Unit1__O(); A_arbace_core_print__init_A_Unit2__O(); A_arbace_core_print__init_A_Unit3__O(); A_arbace_core_print__init_A_Unit4__O(); A_arbace_core_print__init_A_Unit5__O(); A_arbace_core_print__init_A_Unit6__O(); A_arbace_core_print__init_A_Unit7__O(); A_arbace_core_print__init_A_Unit8__O(); A_arbace_core_print__init_A_Unit9__O(); A_arbace_core_print__init_A_Unit10__O(); A_arbace_core_print__init_A_Unit11__O(); A_arbace_core_print__init_A_Unit12__O(); A_arbace_core_print__init_A_Unit13__O(); A_arbace_core_print__init_A_Unit14__O(); A_arbace_core_print__init_A_Unit15__O(); A_arbace_core_print__init_A_Unit16__O(); A_arbace_core_print__init_A_Unit17__O(); A_arbace_core_print__init_A_Unit18__O(); A_arbace_core_print__init_A_Unit19__O(); A_arbace_core_print__init_A_Unit20__O(); A_arbace_core_print__init_A_Unit21__O(); A_arbace_core_print__init_A_Unit22__O(); A_arbace_core_print__init_A_Unit23__O(); A_arbace_core_print__init_A_Unit24__O(); A_arbace_core_print__init_A_Unit25__O(); A_arbace_core_print__init_A_Unit26__O(); A_arbace_core_print__init_A_Unit27__O(); A_arbace_core_print__init_A_Unit28__O(); A_arbace_core_print__init_A_Unit29__O(); A_arbace_core_print__init_A_Unit30__O(); A_arbace_core_print__init_A_Unit31__O(); A_arbace_core_print__init_A_Unit32__O(); A_arbace_core_print__init_A_Unit33__O(); A_arbace_core_print__init_A_Unit34__O(); A_arbace_core_print__init_A_Unit35__O(); A_arbace_core_print__init_A_Unit36__O(); A_arbace_core_print__init_A_Unit37__O(); A_arbace_core_print__init_A_Unit38__O(); A_arbace_core_print__init_A_Unit39__O(); A_arbace_core_print__init_A_Unit40__O(); A_arbace_core_print__init_A_Unit41__O(); A_arbace_core_print__init_A_Unit42__O(); A_arbace_core_print__init_A_Unit43__O(); A_arbace_core_print__init_A_Unit44__O(); A_arbace_core_print__init_A_Unit45__O(); A_arbace_core_print__init_A_Unit46__O(); A_arbace_core_print__init_A_Unit47__O(); A_arbace_core_print__init_A_Unit48__O(); A_arbace_core_print__init_A_Unit49__O(); A_arbace_core_print__init_A_Unit50__O(); A_arbace_core_print__init_A_Unit51__O(); A_arbace_core_print__init_A_Unit52__O(); A_arbace_core_print__init_A_Unit53__O(); A_arbace_core_print__init_A_Unit54__O(); A_arbace_core_print__init_A_Unit55__O(); A_arbace_core_print__init_A_Unit56__O(); A_arbace_core_print__init_A_Unit57__O(); A_arbace_core_print__init_A_Unit58__O(); A_arbace_core_print__init_A_Unit59__O(); A_arbace_core_print__init_A_Unit60__O(); A_arbace_core_print__init_A_Unit61__O(); A_arbace_core_print__init_A_Unit62__O(); A_arbace_core_print__init_A_Unit63__O(); A_arbace_core_print__init_A_Unit64__O(); A_arbace_core_print__init_A_Unit65__O(); A_arbace_core_print__init_A_Unit66__O(); A_arbace_core_print__init_A_Unit67__O(); A_arbace_core_print__init_A_Unit68__O(); A_arbace_core_print__init_A_Unit69__O(); A_arbace_core_print__init_A_Unit70__O(); A_arbace_core_print__init_A_Unit71__O(); A_arbace_core_print__init_A_Unit72__O(); A_arbace_core_print__init_A_Unit73__O(); A_arbace_core_print__init_A_Unit74__O(); A_arbace_core_print__init_A_Unit75__O(); A_arbace_core_print__init_A_Unit76__O(); A_arbace_core_print__init_A_Unit77__O(); A_arbace_core_print__init_A_Unit78__O(); A_arbace_core_print__init_A_Unit79__O(); A_arbace_core_print__init_A_Unit80__O(); A_arbace_core_print__init_A_Unit81__O(); A_arbace_core_print__init_A_Unit82__O(); A_arbace_core_print__init_A_Unit83__O(); A_arbace_core_print__init_A_Unit84__O(); A_arbace_core_print__init_A_Unit85__O(); A_arbace_core_print__init_A_Unit86__O(); A_arbace_core_print__init_A_Unit87__O(); A_arbace_core_print__init_A_Unit88__O(); A_arbace_core_print__init_A_Unit89__O(); A_arbace_core_print__init_A_Unit90__O(); A_arbace_core_print__init_A_Unit91__O(); A_arbace_core_print__init_A_Unit92__O(); A_arbace_core_print__init_A_Unit93__O(); A_arbace_core_print__init_A_Unit94__O(); A_arbace_core_print__init_A_Unit95__O(); A_arbace_core_print__init_A_Unit96__O(); A_arbace_core_print__init_A_Unit97__O(); A_arbace_core_print__init_A_Unit98__O(); A_arbace_core_print__init_A_Unit99__O(); A_arbace_core_print__init_A_Unit100__O(); A_arbace_core_print__init_A_Unit101__O(); A_arbace_core_print__init_A_Unit102__O(); return nil }



func A_arbace_core_print__init_A_Unit0__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_core_print__init_A_const_1) }



func A_arbace_core_print__init_A_Unit1__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_127)); return nil }

func A_arbace_core_print__init_A_Unit2__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(15, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_2; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return jrt.NN(tmp1).Set_O__O(tmp2.Ref()) }
func A_arbace_core_print__init_A_Unit3__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(16, 1); jrt.NN(A_arbace_core_print__init_A_const_3).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_3; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_4)); return jrt.NN(A_arbace_core_print__init_A_const_3).SetDynamic_Z__Var(true).Ref() }










func A_arbace_core_print__init_A_Unit4__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(27, 1); jrt.NN(A_arbace_core_print__init_A_const_5).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_5; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_6)); return jrt.NN(A_arbace_core_print__init_A_const_5).SetDynamic_Z__Var(true).Ref() }











func A_arbace_core_print__init_A_Unit5__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_7; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; jrt.NN(tmp1).BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_core_print__init_A_const_7; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_8)); return jrt.NN(A_arbace_core_print__init_A_const_7).SetDynamic_Z__Var(true).Ref() }

func A_arbace_core_print__init_A_Unit6__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(41, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_9; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; jrt.NN(tmp1).BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_core_print__init_A_const_9; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_10)); return jrt.NN(A_arbace_core_print__init_A_const_9).SetDynamic_Z__Var(true).Ref() }






func A_arbace_core_print__init_A_Unit7__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_11; var tmp2 any = aot_arbace_core.A_arbace_core_print_sequential_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_print_sequential_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_print_sequential_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_A_const_11; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_12)); return A_arbace_core_print__init_A_const_11.Ref() }























func A_arbace_core_print__init_A_Unit8__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(72, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_13; var tmp2 any = aot_arbace_core.A_arbace_core_print_meta_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_print_meta_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_print_meta_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_A_const_13; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_14)); return A_arbace_core_print__init_A_const_13.Ref() }










func A_arbace_core_print__init_A_Unit9__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(83, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_15; var tmp2 any = aot_arbace_core.A_arbace_core_print_simple_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_print_simple_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_print_simple_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_A_const_15; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_16)); return A_arbace_core_print__init_A_const_15.Ref() }



func A_arbace_core_print__init_A_Unit10__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(87, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_18.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000030_fn__1769000031_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000030_fn__1769000031_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000030_fn__1769000031_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_core_print__init_A_Unit11__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(92, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = aot_arbace_core.A_arbace_core_eval1769000036_fn__1769000037_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000036_fn__1769000037_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_eval1769000036_fn__1769000037_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(nil, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)).Ref() }


func A_arbace_core_print__init_A_Unit12__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(95, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = aot_arbace_core.A_arbace_core_eval1769000040_fn__1769000041_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000040_fn__1769000041_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_eval1769000040_fn__1769000041_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(nil, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)).Ref() }

func A_arbace_core_print__init_A_Unit13__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_20; var tmp2 any = aot_arbace_core.A_arbace_core_print_ctor_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_print_ctor_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_print_ctor_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_21)); return A_arbace_core_print__init_A_const_20.Ref() }






func A_arbace_core_print__init_A_Unit14__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(104, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_22; var tmp2 any = aot_arbace_core.A_arbace_core_print_tagged_object_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_print_tagged_object_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_print_tagged_object_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_23)); return A_arbace_core_print__init_A_const_22.Ref() }












func A_arbace_core_print__init_A_Unit15__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(117, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_24; var tmp2 any = aot_arbace_core.A_arbace_core_print_object_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_print_object_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_print_object_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_25)); return A_arbace_core_print__init_A_const_24.Ref() }


func A_arbace_core_print__init_A_Unit16__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(120, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_26.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000047_fn__1769000048_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000047_fn__1769000048_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000047_fn__1769000048_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_A_Unit17__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(123, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_27.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000051_fn__1769000052_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000051_fn__1769000052_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000051_fn__1769000052_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_A_Unit18__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(126, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_27.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000055_fn__1769000056_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000055_fn__1769000056_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000055_fn__1769000056_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_A_Unit19__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(128, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_28.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000059_fn__1769000060_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000059_fn__1769000060_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000059_fn__1769000060_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_A_Unit20__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(131, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_29.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000063_fn__1769000064_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000063_fn__1769000064_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000063_fn__1769000064_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_A_Unit21__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(138, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_30.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000067_fn__1769000068_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000067_fn__1769000068_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000067_fn__1769000068_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_A_Unit22__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(145, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_28.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000071_fn__1769000072_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000071_fn__1769000072_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000071_fn__1769000072_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_core_print__init_A_Unit23__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(151, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_31.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000077_fn__1769000078_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000077_fn__1769000078_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000077_fn__1769000078_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_A_Unit24__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(154, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O(), A_arbace_core_print__init_A_const_33.Ref(), A_arbace_core_print__init_A_const_31.Ref()) }
func A_arbace_core_print__init_A_Unit25__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(155, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O(), A_arbace_core_print__init_A_const_34.Ref(), A_arbace_core_print__init_A_const_31.Ref()) }
func A_arbace_core_print__init_A_Unit26__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(156, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O(), A_arbace_core_print__init_A_const_35.Ref(), A_arbace_core_print__init_A_const_31.Ref()) }

func A_arbace_core_print__init_A_Unit27__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(158, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_36.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000089_fn__1769000090_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000089_fn__1769000090_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000089_fn__1769000090_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_A_Unit28__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(161, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_36.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000093_fn__1769000094_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000093_fn__1769000094_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000093_fn__1769000094_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_A_Unit29__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(163, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_37.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000097_fn__1769000098_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000097_fn__1769000098_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000097_fn__1769000098_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_A_Unit30__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(166, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_37.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000101_fn__1769000102_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000101_fn__1769000102_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000101_fn__1769000102_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_A_Unit31__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(168, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_38.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000105_fn__1769000106_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000105_fn__1769000106_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000105_fn__1769000106_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_A_Unit32__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(171, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_38.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000109_fn__1769000110_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000109_fn__1769000110_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000109_fn__1769000110_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_A_Unit33__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(174, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_39.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000113_fn__1769000114_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000113_fn__1769000114_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000113_fn__1769000114_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_core_print__init_A_Unit34__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(178, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_39.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000117_fn__1769000118_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000117_fn__1769000118_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000117_fn__1769000118_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_A_Unit35__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(179, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_40.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000121_fn__1769000122_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000121_fn__1769000122_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000121_fn__1769000122_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_A_Unit36__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(180, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O(), A_arbace_core_print__init_A_const_39.Ref(), A_arbace_core_print__init_A_const_33.Ref()) }
func A_arbace_core_print__init_A_Unit37__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(181, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O(), A_arbace_core_print__init_A_const_39.Ref(), A_arbace_core_print__init_A_const_33.Ref()) }
func A_arbace_core_print__init_A_Unit38__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(182, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O(), A_arbace_core_print__init_A_const_39.Ref(), A_arbace_core_print__init_A_const_35.Ref()) }
func A_arbace_core_print__init_A_Unit39__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(183, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O(), A_arbace_core_print__init_A_const_39.Ref(), A_arbace_core_print__init_A_const_35.Ref()) }

func A_arbace_core_print__init_A_Unit40__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(185, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_35.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000135_fn__1769000136_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000135_fn__1769000136_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000135_fn__1769000136_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_A_Unit41__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(188, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_33.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000141_fn__1769000142_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000141_fn__1769000142_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000141_fn__1769000142_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_core_print__init_A_Unit42__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(196, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O(), A_arbace_core_print__init_A_const_33.Ref(), A_arbace_core_print__init_A_const_35.Ref()) }

func A_arbace_core_print__init_A_Unit43__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); jrt.NN(A_arbace_core_print__init_A_const_41).BindRoot_O__V(A_arbace_core_print__init_A_const_42); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_41; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_43)); return A_arbace_core_print__init_A_const_41.Ref() }











func A_arbace_core_print__init_A_Unit44__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(210, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_44.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000147_fn__1769000148_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000147_fn__1769000148_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000147_fn__1769000148_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }










func A_arbace_core_print__init_A_Unit45__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(221, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_44.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000151_fn__1769000152_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000151_fn__1769000152_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000151_fn__1769000152_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_A_Unit46__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(223, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_45.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000155_fn__1769000156_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000155_fn__1769000156_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000155_fn__1769000156_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_core_print__init_A_Unit47__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(227, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_46; var tmp2 any = aot_arbace_core.A_arbace_core_print_prefix_map_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_print_prefix_map_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_print_prefix_map_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_A_const_46; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_47)); return A_arbace_core_print__init_A_const_46.Ref() }








func A_arbace_core_print__init_A_Unit48__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(236, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_48; var tmp2 any = aot_arbace_core.A_arbace_core_print_map_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_print_map_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_print_map_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_A_const_48; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_49)); return A_arbace_core_print__init_A_const_48.Ref() }


func A_arbace_core_print__init_A_Unit49__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(239, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_50; var tmp2 any = aot_arbace_core.A_arbace_core_strip_ns_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_strip_ns_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_strip_ns_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_A_const_50; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_51)); return A_arbace_core_print__init_A_const_50.Ref() }





func A_arbace_core_print__init_A_Unit50__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(245, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_52; var tmp2 any = aot_arbace_core.A_arbace_core_lift_ns_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_lift_ns_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_lift_ns_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_A_const_52; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_53)); return A_arbace_core_print__init_A_const_52.Ref() }















func A_arbace_core_print__init_A_Unit51__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(261, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_54.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000188_fn__1769000189_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000188_fn__1769000189_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000188_fn__1769000189_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_A_Unit52__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(268, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_34.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000197_fn__1769000198_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000197_fn__1769000198_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000197_fn__1769000198_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_A_Unit53__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(271, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_54.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000203_fn__1769000204_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000203_fn__1769000204_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000203_fn__1769000204_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }








func A_arbace_core_print__init_A_Unit54__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(280, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O(), A_arbace_core_print__init_A_const_33.Ref(), A_arbace_core_print__init_A_const_35.Ref()) }
func A_arbace_core_print__init_A_Unit55__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(281, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O(), A_arbace_core_print__init_A_const_33.Ref(), A_arbace_core_print__init_A_const_55.Ref()) }
func A_arbace_core_print__init_A_Unit56__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(282, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O(), A_arbace_core_print__init_A_const_55.Ref(), A_arbace_core_print__init_A_const_56.Ref()) }
func A_arbace_core_print__init_A_Unit57__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(283, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O(), A_arbace_core_print__init_A_const_33.Ref(), A_arbace_core_print__init_A_const_34.Ref()) }

func A_arbace_core_print__init_A_Unit58__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(285, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_56.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000215_fn__1769000216_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000215_fn__1769000216_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000215_fn__1769000216_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_A_Unit59__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(292, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_55.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000219_fn__1769000220_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000219_fn__1769000220_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000219_fn__1769000220_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_A_Unit60__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(299, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_34.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000223_fn__1769000224_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000223_fn__1769000224_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000223_fn__1769000224_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_A_Unit61__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(306, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_57.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000227_fn__1769000228_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000227_fn__1769000228_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000227_fn__1769000228_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }








func A_arbace_core_print__init_A_Unit62__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(315, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_58.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000231_fn__1769000232_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000231_fn__1769000232_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000231_fn__1769000232_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_core_print__init_A_Unit63__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(321, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_58.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000235_fn__1769000236_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000235_fn__1769000236_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000235_fn__1769000236_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_core_print__init_A_Unit64__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(329, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O(), A_arbace_core_print__init_A_const_58.Ref(), A_arbace_core_print__init_A_const_34.Ref()) }
func A_arbace_core_print__init_A_Unit65__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(330, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O(), A_arbace_core_print__init_A_const_58.Ref(), A_arbace_core_print__init_A_const_54.Ref()) }
func A_arbace_core_print__init_A_Unit66__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(331, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O(), A_arbace_core_print__init_A_const_58.Ref(), A_arbace_core_print__init_A_const_54.Ref()) }
func A_arbace_core_print__init_A_Unit67__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(332, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O(), A_arbace_core_print__init_A_const_33.Ref(), A_arbace_core_print__init_A_const_34.Ref()) }
func A_arbace_core_print__init_A_Unit68__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(333, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O(), A_arbace_core_print__init_A_const_58.Ref(), A_arbace_core_print__init_A_const_33.Ref()) }
func A_arbace_core_print__init_A_Unit69__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(334, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_32).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O(), A_arbace_core_print__init_A_const_58.Ref(), A_arbace_core_print__init_A_const_34.Ref()) }

func A_arbace_core_print__init_A_Unit70__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(336, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_59.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000251_fn__1769000252_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000251_fn__1769000252_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000251_fn__1769000252_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_core_print__init_A_Unit71__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(340, 1); jrt.NN(A_arbace_core_print__init_A_const_60).BindRoot_O__V(A_arbace_core_print__init_A_const_61); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_60; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_62)); return A_arbace_core_print__init_A_const_60.Ref() }










func A_arbace_core_print__init_A_Unit72__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(351, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_63.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000255_fn__1769000256_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000255_fn__1769000256_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000255_fn__1769000256_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_core_print__init_A_Unit73__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(359, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_63.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000259_fn__1769000260_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000259_fn__1769000260_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000259_fn__1769000260_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_A_Unit74__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(360, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_64.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000263_fn__1769000264_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000263_fn__1769000264_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000263_fn__1769000264_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_A_Unit75__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(361, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_29.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000267_fn__1769000268_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000267_fn__1769000268_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000267_fn__1769000268_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_A_Unit76__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(362, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_65.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000271_fn__1769000272_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000271_fn__1769000272_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000271_fn__1769000272_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_A_Unit77__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(363, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_66.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000275_fn__1769000276_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000275_fn__1769000276_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000275_fn__1769000276_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_A_Unit78__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(364, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_67.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000279_fn__1769000280_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000279_fn__1769000280_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000279_fn__1769000280_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_A_Unit79__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(365, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_68.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000283_fn__1769000284_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000283_fn__1769000284_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000283_fn__1769000284_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_A_Unit80__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(366, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_69.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000287_fn__1769000288_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000287_fn__1769000288_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000287_fn__1769000288_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_A_Unit81__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(367, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_70.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000291_fn__1769000292_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000291_fn__1769000292_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000291_fn__1769000292_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_A_Unit82__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(368, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_71.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000295_fn__1769000296_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000295_fn__1769000296_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000295_fn__1769000296_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_A_Unit83__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(370, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_72; var tmp2 *jrt.Class; jrt.Float_Init(); tmp2 = jrt.Float_TYPE; var tmp3 any = tmp2.Ref(); var tmp4 *jrt.Class; jrt.Integer_Init(); tmp4 = jrt.Integer_TYPE; var tmp5 any = tmp4.Ref(); var tmp6 *jrt.Class; jrt.Long_Init(); tmp6 = jrt.Long_TYPE; var tmp7 any = tmp6.Ref(); var tmp8 *jrt.Class; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TYPE; var tmp9 any = tmp8.Ref(); var tmp10 *jrt.Class; jrt.Character_Init(); tmp10 = jrt.Character_TYPE; var tmp11 any = tmp10.Ref(); var tmp12 *jrt.Class; jrt.Double_Init(); tmp12 = jrt.Double_TYPE; var tmp13 any = tmp12.Ref(); var tmp14 *jrt.Class; jrt.Byte_Init(); tmp14 = jrt.Byte_TYPE; var tmp15 any = tmp14.Ref(); var tmp16 *jrt.Class; jrt.Short_Init(); tmp16 = jrt.Short_TYPE; jrt.NN(tmp1).BindRoot_O__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, Lit_128, tmp5, Lit_129, tmp7, Lit_130, tmp9, Lit_131, tmp11, Lit_132, tmp13, Lit_133, tmp15, Lit_134, tmp16.Ref(), Lit_135))); var tmp17 *lang.Var = A_arbace_core_print__init_A_const_72; jrt.NN(tmp17).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_73)); return A_arbace_core_print__init_A_const_72.Ref() }









func A_arbace_core_print__init_A_Unit84__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(380, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_74.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000299_fn__1769000300_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000299_fn__1769000300_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000299_fn__1769000300_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_core_print__init_A_Unit85__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(385, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_74.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000303_fn__1769000304_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000303_fn__1769000304_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000303_fn__1769000304_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }













func A_arbace_core_print__init_A_Unit86__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(399, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_66.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000307_fn__1769000308_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000307_fn__1769000308_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000307_fn__1769000308_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_core_print__init_A_Unit87__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(403, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_67.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000311_fn__1769000312_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000311_fn__1769000312_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000311_fn__1769000312_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_core_print__init_A_Unit88__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(407, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_75.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000315_fn__1769000316_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000315_fn__1769000316_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000315_fn__1769000316_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





















func A_arbace_core_print__init_A_Unit89__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(429, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_75.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000332_fn__1769000333_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000332_fn__1769000333_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000332_fn__1769000333_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_A_Unit90__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(431, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_76.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000336_fn__1769000337_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000336_fn__1769000337_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000336_fn__1769000337_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_core_print__init_A_Unit91__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(436, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_77; var tmp2 any = aot_arbace_core.A_arbace_core_deref_as_map_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_deref_as_map_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_deref_as_map_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_A_const_77; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_78)); return A_arbace_core_print__init_A_const_77.Ref() }






















func A_arbace_core_print__init_A_Unit92__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(459, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_79.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000346_fn__1769000347_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000346_fn__1769000347_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000346_fn__1769000347_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_A_Unit93__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(462, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_80.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000350_fn__1769000351_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000350_fn__1769000351_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000350_fn__1769000351_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_A_Unit94__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(465, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_81; var tmp2 any = aot_arbace_core.A_arbace_core_StackTraceElement__GT_vec_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_StackTraceElement__GT_vec_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_StackTraceElement__GT_vec_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_A_const_81; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_82)); return A_arbace_core_print__init_A_const_81.Ref() }





func A_arbace_core_print__init_A_Unit95__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(471, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_83; var tmp2 any = aot_arbace_core.A_arbace_core_Throwable__GT_map_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_Throwable__GT_map_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_Throwable__GT_map_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_A_const_83; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_84)); return A_arbace_core_print__init_A_const_83.Ref() }



































func A_arbace_core_print__init_A_Unit96__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(507, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_85; var tmp2 any = aot_arbace_core.A_arbace_core_print_throwable_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_print_throwable_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_print_throwable_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_A_const_85; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_86)); return A_arbace_core_print__init_A_const_85.Ref() }



































func A_arbace_core_print__init_A_Unit97__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(543, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_87.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000374_fn__1769000375_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000374_fn__1769000375_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000374_fn__1769000375_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_A_Unit98__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(546, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_88.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000378_fn__1769000379_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000378_fn__1769000379_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000378_fn__1769000379_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_core_print__init_A_Unit99__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(552, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_19).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_88.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000382_fn__1769000383_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000382_fn__1769000383_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000382_fn__1769000383_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_A_Unit100__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(554, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_17).GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_A_const_89.Ref(); var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000386_fn__1769000387_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_eval1769000386_fn__1769000387_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_eval1769000386_fn__1769000387_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_core_print__init_A_Unit101__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(559, 1); var tmp1 *lang.Var = A_arbace_core_print__init_A_const_90; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; jrt.NN(tmp1).BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_core_print__init_A_const_90; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_91)); return A_arbace_core_print__init_A_const_90.Ref() }

func A_arbace_core_print__init_A_Unit102__O() any { A_arbace_core_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(561, 1); var tmp1 any = A_arbace_core_print__init_A_const_95.Ref(); lang.IFn_Cast(jrt.NN(A_arbace_core_print__init_A_const_94).GetRawRoot__O()).ApplyTo_ISeq__O(lang.RT_Cons_O_O__ISeq(tmp1, lang.RT_Seq_O__ISeq(jrt.RefArrayOf(jrt.Object_class)))); var tmp2 *lang.Var = A_arbace_core_print__init_A_const_92; var tmp3 any = aot_arbace_core.A_arbace_core_PrintWriter_on_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_PrintWriter_on_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_PrintWriter_on_A_fn_class; jrt.NN(tmp2).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); var tmp5 *lang.Var = A_arbace_core_print__init_A_const_92; jrt.NN(tmp5).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_A_const_93)); return A_arbace_core_print__init_A_const_92.Ref() }



type A_arbace_core_print__init_A struct{ jrt.Object }

var A_arbace_core_print__init_A_const_0 *lang.Var

var A_arbace_core_print__init_A_const_1 any

var A_arbace_core_print__init_A_const_2 *lang.Var

var A_arbace_core_print__init_A_const_3 *lang.Var

var A_arbace_core_print__init_A_const_4 any

var A_arbace_core_print__init_A_const_5 *lang.Var

var A_arbace_core_print__init_A_const_6 any

var A_arbace_core_print__init_A_const_7 *lang.Var

var A_arbace_core_print__init_A_const_8 any

var A_arbace_core_print__init_A_const_9 *lang.Var

var A_arbace_core_print__init_A_const_10 any

var A_arbace_core_print__init_A_const_11 *lang.Var

var A_arbace_core_print__init_A_const_12 any

var A_arbace_core_print__init_A_const_13 *lang.Var

var A_arbace_core_print__init_A_const_14 any

var A_arbace_core_print__init_A_const_15 *lang.Var

var A_arbace_core_print__init_A_const_16 any

var A_arbace_core_print__init_A_const_17 *lang.Var

var A_arbace_core_print__init_A_const_18 *lang.Keyword

var A_arbace_core_print__init_A_const_19 *lang.Var

var A_arbace_core_print__init_A_const_20 *lang.Var

var A_arbace_core_print__init_A_const_21 any

var A_arbace_core_print__init_A_const_22 *lang.Var

var A_arbace_core_print__init_A_const_23 any

var A_arbace_core_print__init_A_const_24 *lang.Var

var A_arbace_core_print__init_A_const_25 any

var A_arbace_core_print__init_A_const_26 *jrt.Class

var A_arbace_core_print__init_A_const_27 *jrt.Class

var A_arbace_core_print__init_A_const_28 *jrt.Class

var A_arbace_core_print__init_A_const_29 *jrt.Class

var A_arbace_core_print__init_A_const_30 *jrt.Class

var A_arbace_core_print__init_A_const_31 *jrt.Class

var A_arbace_core_print__init_A_const_32 *lang.Var

var A_arbace_core_print__init_A_const_33 *jrt.Class

var A_arbace_core_print__init_A_const_34 *jrt.Class

var A_arbace_core_print__init_A_const_35 *jrt.Class

var A_arbace_core_print__init_A_const_36 *jrt.Class

var A_arbace_core_print__init_A_const_37 *jrt.Class

var A_arbace_core_print__init_A_const_38 *jrt.Class

var A_arbace_core_print__init_A_const_39 *jrt.Class

var A_arbace_core_print__init_A_const_40 *jrt.Class

var A_arbace_core_print__init_A_const_41 *lang.Var

var A_arbace_core_print__init_A_const_42 any

var A_arbace_core_print__init_A_const_43 any

var A_arbace_core_print__init_A_const_44 *jrt.Class

var A_arbace_core_print__init_A_const_45 *jrt.Class

var A_arbace_core_print__init_A_const_46 *lang.Var

var A_arbace_core_print__init_A_const_47 any

var A_arbace_core_print__init_A_const_48 *lang.Var

var A_arbace_core_print__init_A_const_49 any

var A_arbace_core_print__init_A_const_50 *lang.Var

var A_arbace_core_print__init_A_const_51 any

var A_arbace_core_print__init_A_const_52 *lang.Var

var A_arbace_core_print__init_A_const_53 any

var A_arbace_core_print__init_A_const_54 *jrt.Class

var A_arbace_core_print__init_A_const_55 *jrt.Class

var A_arbace_core_print__init_A_const_56 *jrt.Class

var A_arbace_core_print__init_A_const_57 *jrt.Class

var A_arbace_core_print__init_A_const_58 *jrt.Class

var A_arbace_core_print__init_A_const_59 *jrt.Class

var A_arbace_core_print__init_A_const_60 *lang.Var

var A_arbace_core_print__init_A_const_61 any

var A_arbace_core_print__init_A_const_62 any

var A_arbace_core_print__init_A_const_63 *jrt.Class

var A_arbace_core_print__init_A_const_64 *jrt.Class

var A_arbace_core_print__init_A_const_65 *jrt.Class

var A_arbace_core_print__init_A_const_66 *jrt.Class

var A_arbace_core_print__init_A_const_67 *jrt.Class

var A_arbace_core_print__init_A_const_68 *jrt.Class

var A_arbace_core_print__init_A_const_69 *jrt.Class

var A_arbace_core_print__init_A_const_70 *jrt.Class

var A_arbace_core_print__init_A_const_71 *jrt.Class

var A_arbace_core_print__init_A_const_72 *lang.Var

var A_arbace_core_print__init_A_const_73 any

var A_arbace_core_print__init_A_const_74 *jrt.Class

var A_arbace_core_print__init_A_const_75 *jrt.Class

var A_arbace_core_print__init_A_const_76 *jrt.Class

var A_arbace_core_print__init_A_const_77 *lang.Var

var A_arbace_core_print__init_A_const_78 any

var A_arbace_core_print__init_A_const_79 *jrt.Class

var A_arbace_core_print__init_A_const_80 *jrt.Class

var A_arbace_core_print__init_A_const_81 *lang.Var

var A_arbace_core_print__init_A_const_82 any

var A_arbace_core_print__init_A_const_83 *lang.Var

var A_arbace_core_print__init_A_const_84 any

var A_arbace_core_print__init_A_const_85 *lang.Var

var A_arbace_core_print__init_A_const_86 any

var A_arbace_core_print__init_A_const_87 *jrt.Class

var A_arbace_core_print__init_A_const_88 *jrt.Class

var A_arbace_core_print__init_A_const_89 *jrt.Class

var A_arbace_core_print__init_A_const_90 *lang.Var

var A_arbace_core_print__init_A_const_91 any

var A_arbace_core_print__init_A_const_92 *lang.Var

var A_arbace_core_print__init_A_const_93 any

var A_arbace_core_print__init_A_const_94 *lang.Var

var A_arbace_core_print__init_A_const_95 *jrt.Class

var A_arbace_core_print__init_A_init jrt.ClassInit

func A_arbace_core_print__init_A_Init() { if !A_arbace_core_print__init_A_init.Done() { A_arbace_core_print__init_A_init.Run(A_arbace_core_print__init_A_clinit) } }

func A_arbace_core_print__init_A_clinit() { A_arbace_core_print__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_core_print__init_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_core_print__init_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_core_print__init_A_const_3 = lang.RT_Var_String_String__Var(Lit_0, Lit_3); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp2 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(); var tmp3 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; var tmp5 any = tmp4.Ref(); A_arbace_core_print__init_A_const_4 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, Lit_5, tmp2, Lit_7, tmp3, tmp5, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(16).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); var tmp6 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(); var tmp8 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_TRUE; var tmp10 any = tmp9.Ref(); A_arbace_core_print__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, Lit_14, tmp7, Lit_7, tmp8, tmp10, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(27).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); var tmp11 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_TRUE; var tmp13 any = tmp12.Ref(); A_arbace_core_print__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp13, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(39).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); var tmp14 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp15 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_core_print__init_A_const_10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp14, Lit_17, tmp15, Lit_18, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(41).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_core_print__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_22)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_24).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_26)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_24).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_24).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_28).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_29)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_30).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(48).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_core_print__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_29)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_30).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(72).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_core_print__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_29)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_30).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(83).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_core_print__init_A_const_18 = lang.RT_Keyword_String_String__Keyword(nil, Lit_35); A_arbace_core_print__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_core_print__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_core_print__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_29)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_30).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(97).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_core_print__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_40).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_29)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_30).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(104).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_core_print__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_29)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_30).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(117).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_26 = lang.RT_ClassForNameNonLoading_String__Class(Lit_42); A_arbace_core_print__init_A_const_27 = lang.RT_ClassForNameNonLoading_String__Class(Lit_43); A_arbace_core_print__init_A_const_28 = lang.RT_ClassForNameNonLoading_String__Class(Lit_44); A_arbace_core_print__init_A_const_29 = lang.RT_ClassForNameNonLoading_String__Class(Lit_45); A_arbace_core_print__init_A_const_30 = lang.RT_ClassForNameNonLoading_String__Class(Lit_46); A_arbace_core_print__init_A_const_31 = lang.RT_ClassForNameNonLoading_String__Class(Lit_47); A_arbace_core_print__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_core_print__init_A_const_33 = lang.RT_ClassForNameNonLoading_String__Class(Lit_49); A_arbace_core_print__init_A_const_34 = lang.RT_ClassForNameNonLoading_String__Class(Lit_50); A_arbace_core_print__init_A_const_35 = lang.RT_ClassForNameNonLoading_String__Class(Lit_51); A_arbace_core_print__init_A_const_36 = lang.RT_ClassForNameNonLoading_String__Class(Lit_52); A_arbace_core_print__init_A_const_37 = lang.RT_ClassForNameNonLoading_String__Class(Lit_53); A_arbace_core_print__init_A_const_38 = lang.RT_ClassForNameNonLoading_String__Class(Lit_54); A_arbace_core_print__init_A_const_39 = lang.RT_ClassForNameNonLoading_String__Class(Lit_55); A_arbace_core_print__init_A_const_40 = lang.RT_ClassForNameNonLoading_String__Class(Lit_56); A_arbace_core_print__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_core_print__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, jrt.Character_ValueOf_C__Character(10).Ref(), Lit_58, jrt.Character_ValueOf_C__Character(9).Ref(), Lit_59, jrt.Character_ValueOf_C__Character(13).Ref(), Lit_60, jrt.Character_ValueOf_C__Character(34).Ref(), Lit_61, jrt.Character_ValueOf_C__Character(92).Ref(), Lit_62, jrt.Character_ValueOf_C__Character(12).Ref(), Lit_63, jrt.Character_ValueOf_C__Character(8).Ref(), Lit_64)); A_arbace_core_print__init_A_const_43 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), lang.RT_ClassForNameNonLoading_String__Class(Lit_65).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_66, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(198).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_44 = lang.RT_ClassForNameNonLoading_String__Class(Lit_65); A_arbace_core_print__init_A_const_45 = lang.RT_ClassForNameNonLoading_String__Class(Lit_67); A_arbace_core_print__init_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_68); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_core_print__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_69).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_70).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(227).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_0, Lit_71); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_core_print__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_72).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(236).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_73); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_core_print__init_A_const_51 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_74).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(239).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_75); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_core_print__init_A_const_53 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_72).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_76, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(245).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_54 = lang.RT_ClassForNameNonLoading_String__Class(Lit_77); A_arbace_core_print__init_A_const_55 = lang.RT_ClassForNameNonLoading_String__Class(Lit_78); A_arbace_core_print__init_A_const_56 = lang.RT_ClassForNameNonLoading_String__Class(Lit_79); A_arbace_core_print__init_A_const_57 = lang.RT_ClassForNameNonLoading_String__Class(Lit_80); A_arbace_core_print__init_A_const_58 = lang.RT_ClassForNameNonLoading_String__Class(Lit_81); A_arbace_core_print__init_A_const_59 = lang.RT_ClassForNameNonLoading_String__Class(Lit_82); A_arbace_core_print__init_A_const_60 = lang.RT_Var_String_String__Var(Lit_0, Lit_83); A_arbace_core_print__init_A_const_61 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, jrt.Character_ValueOf_C__Character(10).Ref(), Lit_84, jrt.Character_ValueOf_C__Character(9).Ref(), Lit_85, jrt.Character_ValueOf_C__Character(32).Ref(), Lit_86, jrt.Character_ValueOf_C__Character(8).Ref(), Lit_87, jrt.Character_ValueOf_C__Character(12).Ref(), Lit_88, jrt.Character_ValueOf_C__Character(13).Ref(), Lit_89)); A_arbace_core_print__init_A_const_62 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), lang.RT_ClassForNameNonLoading_String__Class(Lit_65).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_90, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(340).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_63 = lang.RT_ClassForNameNonLoading_String__Class(Lit_91); A_arbace_core_print__init_A_const_64 = lang.RT_ClassForNameNonLoading_String__Class(Lit_92); A_arbace_core_print__init_A_const_65 = lang.RT_ClassForNameNonLoading_String__Class(Lit_93); A_arbace_core_print__init_A_const_66 = lang.RT_ClassForNameNonLoading_String__Class(Lit_94); A_arbace_core_print__init_A_const_67 = lang.RT_ClassForNameNonLoading_String__Class(Lit_95); A_arbace_core_print__init_A_const_68 = lang.RT_ClassForNameNonLoading_String__Class(Lit_96); A_arbace_core_print__init_A_const_69 = lang.RT_ClassForNameNonLoading_String__Class(Lit_97); A_arbace_core_print__init_A_const_70 = lang.RT_ClassForNameNonLoading_String__Class(Lit_98); A_arbace_core_print__init_A_const_71 = lang.RT_ClassForNameNonLoading_String__Class(Lit_99); A_arbace_core_print__init_A_const_72 = lang.RT_Var_String_String__Var(Lit_0, Lit_100); A_arbace_core_print__init_A_const_73 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(370).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_74 = lang.RT_ClassForNameNonLoading_String__Class(Lit_101); A_arbace_core_print__init_A_const_75 = lang.RT_ClassForNameNonLoading_String__Class(Lit_102); A_arbace_core_print__init_A_const_76 = lang.RT_ClassForNameNonLoading_String__Class(Lit_103); A_arbace_core_print__init_A_const_77 = lang.RT_Var_String_String__Var(Lit_0, Lit_104); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_core_print__init_A_const_78 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_32)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_105).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(436).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_79 = lang.RT_ClassForNameNonLoading_String__Class(Lit_105); A_arbace_core_print__init_A_const_80 = lang.RT_ClassForNameNonLoading_String__Class(Lit_106); A_arbace_core_print__init_A_const_81 = lang.RT_Var_String_String__Var(Lit_0, Lit_107); A_arbace_core_print__init_A_const_82 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_32)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_108).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_109, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_18, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(465).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_83 = lang.RT_Var_String_String__Var(Lit_0, Lit_110); A_arbace_core_print__init_A_const_84 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_32)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_111).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_112, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_113, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(471).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_85 = lang.RT_Var_String_String__Var(Lit_0, Lit_114); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_core_print__init_A_const_86 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_32)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_111).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_29)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_30).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(507).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_87 = lang.RT_ClassForNameNonLoading_String__Class(Lit_115); A_arbace_core_print__init_A_const_88 = lang.RT_ClassForNameNonLoading_String__Class(Lit_116); A_arbace_core_print__init_A_const_89 = lang.RT_ClassForNameNonLoading_String__Class(Lit_117); A_arbace_core_print__init_A_const_90 = lang.RT_Var_String_String__Var(Lit_0, Lit_118); var tmp49 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(); var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_TRUE; var tmp51 any = tmp50.Ref(); A_arbace_core_print__init_A_const_91 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp51, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(559).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_92 = lang.RT_Var_String_String__Var(Lit_0, Lit_119); A_arbace_core_print__init_A_const_93 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), lang.RT_ClassForNameNonLoading_String__Class(Lit_120).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_121).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_122).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_121).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_122).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_123).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), Lit_124, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_125, lang.RT_Keyword_String_String__Keyword(nil, Lit_9).Ref(), jrt.Integer_ValueOf_I__Integer(561).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), Lit_12)); A_arbace_core_print__init_A_const_94 = lang.RT_Var_String_String__Var(Lit_0, Lit_126); A_arbace_core_print__init_A_const_95 = lang.RT_ClassForNameNonLoading_String__Class(Lit_127) }

func A_arbace_core_print__init_A_New() *A_arbace_core_print__init_A { A_arbace_core_print__init_A_Init(); t := &A_arbace_core_print__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_print__init_A) Ctor() {}

func (t *A_arbace_core_print__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_print__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_print__init_A_class }

func (t *A_arbace_core_print__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_print__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_print__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_print__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_print__init_A); return ok }

func A_arbace_core_print__init_A_Cast(x any) *A_arbace_core_print__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_print__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_print__init_A_class)) }; return v }
