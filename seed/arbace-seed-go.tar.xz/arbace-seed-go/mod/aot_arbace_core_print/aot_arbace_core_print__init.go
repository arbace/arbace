//line aot_arbace_core_print__init.ae:1
package aot_arbace_core_print

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_print__init_A_Load__O() any { jrt.StartCheck(); A_arbace_core_print__init_part0_A_Init__O(); A_arbace_core_print__init_part1_A_Init__O(); A_arbace_core_print__init_part0_A_Load__O(); A_arbace_core_print__init_part1_A_Load__O(); return nil }



func A_arbace_core_print__init_part0_A_Unit0__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_print__init_part0_A_const_1) }
//line :9:1
func A_arbace_core_print__init_part0_A_Init__O() any { A_arbace_core_print__init_part0_A_Init(); return nil }
//line :9:1
func A_arbace_core_print__init_part0_A_Load__O() any { A_arbace_core_print__init_part0_A_Init(); A_arbace_core_print__init_part0_A_Unit0__O(); A_arbace_core_print__init_part0_A_Unit1__O(); A_arbace_core_print__init_part0_A_Unit2__O(); A_arbace_core_print__init_part0_A_Unit3__O(); A_arbace_core_print__init_part0_A_Unit4__O(); A_arbace_core_print__init_part0_A_Unit5__O(); A_arbace_core_print__init_part0_A_Unit6__O(); A_arbace_core_print__init_part0_A_Unit7__O(); A_arbace_core_print__init_part0_A_Unit8__O(); A_arbace_core_print__init_part0_A_Unit9__O(); A_arbace_core_print__init_part0_A_Unit10__O(); A_arbace_core_print__init_part0_A_Unit11__O(); A_arbace_core_print__init_part0_A_Unit12__O(); A_arbace_core_print__init_part0_A_Unit13__O(); A_arbace_core_print__init_part0_A_Unit14__O(); A_arbace_core_print__init_part0_A_Unit15__O(); A_arbace_core_print__init_part0_A_Unit16__O(); A_arbace_core_print__init_part0_A_Unit17__O(); A_arbace_core_print__init_part0_A_Unit18__O(); A_arbace_core_print__init_part0_A_Unit19__O(); A_arbace_core_print__init_part0_A_Unit20__O(); A_arbace_core_print__init_part0_A_Unit21__O(); A_arbace_core_print__init_part0_A_Unit22__O(); A_arbace_core_print__init_part0_A_Unit23__O(); A_arbace_core_print__init_part0_A_Unit24__O(); A_arbace_core_print__init_part0_A_Unit25__O(); A_arbace_core_print__init_part0_A_Unit26__O(); A_arbace_core_print__init_part0_A_Unit27__O(); A_arbace_core_print__init_part0_A_Unit28__O(); A_arbace_core_print__init_part0_A_Unit29__O(); A_arbace_core_print__init_part0_A_Unit30__O(); A_arbace_core_print__init_part0_A_Unit31__O(); A_arbace_core_print__init_part0_A_Unit32__O(); A_arbace_core_print__init_part0_A_Unit33__O(); A_arbace_core_print__init_part0_A_Unit34__O(); A_arbace_core_print__init_part0_A_Unit35__O(); A_arbace_core_print__init_part0_A_Unit36__O(); A_arbace_core_print__init_part0_A_Unit37__O(); A_arbace_core_print__init_part0_A_Unit38__O(); A_arbace_core_print__init_part0_A_Unit39__O(); A_arbace_core_print__init_part0_A_Unit40__O(); A_arbace_core_print__init_part0_A_Unit41__O(); A_arbace_core_print__init_part0_A_Unit42__O(); A_arbace_core_print__init_part0_A_Unit43__O(); A_arbace_core_print__init_part0_A_Unit44__O(); A_arbace_core_print__init_part0_A_Unit45__O(); A_arbace_core_print__init_part0_A_Unit46__O(); A_arbace_core_print__init_part0_A_Unit47__O(); A_arbace_core_print__init_part0_A_Unit48__O(); A_arbace_core_print__init_part0_A_Unit49__O(); A_arbace_core_print__init_part0_A_Unit50__O(); A_arbace_core_print__init_part0_A_Unit51__O(); A_arbace_core_print__init_part0_A_Unit52__O(); A_arbace_core_print__init_part0_A_Unit53__O(); A_arbace_core_print__init_part0_A_Unit54__O(); A_arbace_core_print__init_part0_A_Unit55__O(); A_arbace_core_print__init_part0_A_Unit56__O(); A_arbace_core_print__init_part0_A_Unit57__O(); A_arbace_core_print__init_part0_A_Unit58__O(); A_arbace_core_print__init_part0_A_Unit59__O(); A_arbace_core_print__init_part0_A_Unit60__O(); A_arbace_core_print__init_part0_A_Unit61__O(); A_arbace_core_print__init_part0_A_Unit62__O(); A_arbace_core_print__init_part0_A_Unit63__O(); A_arbace_core_print__init_part0_A_Unit64__O(); A_arbace_core_print__init_part0_A_Unit65__O(); A_arbace_core_print__init_part0_A_Unit66__O(); A_arbace_core_print__init_part0_A_Unit67__O(); A_arbace_core_print__init_part0_A_Unit68__O(); A_arbace_core_print__init_part0_A_Unit69__O(); A_arbace_core_print__init_part0_A_Unit70__O(); A_arbace_core_print__init_part0_A_Unit71__O(); A_arbace_core_print__init_part0_A_Unit72__O(); A_arbace_core_print__init_part0_A_Unit73__O(); A_arbace_core_print__init_part0_A_Unit74__O(); A_arbace_core_print__init_part0_A_Unit75__O(); A_arbace_core_print__init_part0_A_Unit76__O(); A_arbace_core_print__init_part0_A_Unit77__O(); A_arbace_core_print__init_part0_A_Unit78__O(); A_arbace_core_print__init_part0_A_Unit79__O(); A_arbace_core_print__init_part0_A_Unit80__O(); A_arbace_core_print__init_part0_A_Unit81__O(); A_arbace_core_print__init_part0_A_Unit82__O(); A_arbace_core_print__init_part0_A_Unit83__O(); A_arbace_core_print__init_part0_A_Unit84__O(); A_arbace_core_print__init_part0_A_Unit85__O(); A_arbace_core_print__init_part0_A_Unit86__O(); A_arbace_core_print__init_part0_A_Unit87__O(); A_arbace_core_print__init_part0_A_Unit88__O(); A_arbace_core_print__init_part0_A_Unit89__O(); A_arbace_core_print__init_part0_A_Unit90__O(); A_arbace_core_print__init_part0_A_Unit91__O(); A_arbace_core_print__init_part0_A_Unit92__O(); A_arbace_core_print__init_part0_A_Unit93__O(); A_arbace_core_print__init_part0_A_Unit94__O(); A_arbace_core_print__init_part0_A_Unit95__O(); A_arbace_core_print__init_part0_A_Unit96__O(); A_arbace_core_print__init_part0_A_Unit97__O(); A_arbace_core_print__init_part0_A_Unit98__O(); A_arbace_core_print__init_part0_A_Unit99__O(); return nil }



func A_arbace_core_print__init_part0_A_Unit1__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)).Ref() }

func A_arbace_core_print__init_part0_A_Unit2__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); return A_arbace_core_print__init_part0_A_const_2.Set_O__O(jrt.Boolean_TRUE.Ref()) }
func A_arbace_core_print__init_part0_A_Unit3__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); A_arbace_core_print__init_part0_A_const_3.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_3; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_4)); return A_arbace_core_print__init_part0_A_const_3.SetDynamic_Z__Var(true).Ref() }










func A_arbace_core_print__init_part0_A_Unit4__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(27, 1); A_arbace_core_print__init_part0_A_const_5.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_5; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_6)); return A_arbace_core_print__init_part0_A_const_5.SetDynamic_Z__Var(true).Ref() }











func A_arbace_core_print__init_part0_A_Unit5__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); A_arbace_core_print__init_part0_A_const_7.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_7; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_8)); return A_arbace_core_print__init_part0_A_const_7.SetDynamic_Z__Var(true).Ref() }

func A_arbace_core_print__init_part0_A_Unit6__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); A_arbace_core_print__init_part0_A_const_9.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_9; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_10)); return A_arbace_core_print__init_part0_A_const_9.SetDynamic_Z__Var(true).Ref() }






func A_arbace_core_print__init_part0_A_Unit7__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_11; var tmp2 any = aot_arbace_core.A_arbace_core_print_sequential_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_core.A_arbace_core_print_sequential_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); aot_arbace_core.A_arbace_core_print_sequential_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_12)); return A_arbace_core_print__init_part0_A_const_11 }























func A_arbace_core_print__init_part0_A_Unit8__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_13; var tmp2 any = aot_arbace_core.A_arbace_core_print_meta_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_core.A_arbace_core_print_meta_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); aot_arbace_core.A_arbace_core_print_meta_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_14)); return A_arbace_core_print__init_part0_A_const_13 }










func A_arbace_core_print__init_part0_A_Unit9__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_15; var tmp2 any = aot_arbace_core.A_arbace_core_print_simple_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_core.A_arbace_core_print_simple_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); aot_arbace_core.A_arbace_core_print_simple_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_16)); return A_arbace_core_print__init_part0_A_const_15 }



func A_arbace_core_print__init_part0_A_Unit10__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(87, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_18; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000030_fn__1769000031_A_New(); var tmp4 *jrt.Class; var fncls__4 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000030_fn__1769000031_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); aot_arbace_core.A_arbace_core_eval1769000030_fn__1769000031_A_fn_class = fncls__4d; tmp4 = fncls__4d } else { tmp4 = fncls__4 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_core_print__init_part0_A_Unit11__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = aot_arbace_core.A_arbace_core_eval1769000036_fn__1769000037_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000036_fn__1769000037_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); aot_arbace_core.A_arbace_core_eval1769000036_fn__1769000037_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(nil, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit12__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = aot_arbace_core.A_arbace_core_eval1769000040_fn__1769000041_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000040_fn__1769000041_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); aot_arbace_core.A_arbace_core_eval1769000040_fn__1769000041_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(nil, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)).Ref() }

func A_arbace_core_print__init_part0_A_Unit13__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_20; var tmp2 any = aot_arbace_core.A_arbace_core_print_ctor_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_core.A_arbace_core_print_ctor_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); aot_arbace_core.A_arbace_core_print_ctor_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_21)); return A_arbace_core_print__init_part0_A_const_20 }






func A_arbace_core_print__init_part0_A_Unit14__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(104, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_22; var tmp2 any = aot_arbace_core.A_arbace_core_print_tagged_object_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = aot_arbace_core.A_arbace_core_print_tagged_object_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); aot_arbace_core.A_arbace_core_print_tagged_object_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_23)); return A_arbace_core_print__init_part0_A_const_22 }












func A_arbace_core_print__init_part0_A_Unit15__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(117, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_24; var tmp2 any = aot_arbace_core.A_arbace_core_print_object_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_core.A_arbace_core_print_object_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); aot_arbace_core.A_arbace_core_print_object_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_25)); return A_arbace_core_print__init_part0_A_const_24 }


func A_arbace_core_print__init_part0_A_Unit16__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(120, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_26; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000047_fn__1769000048_A_New(); var tmp4 *jrt.Class; var fncls__10 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000047_fn__1769000048_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); aot_arbace_core.A_arbace_core_eval1769000047_fn__1769000048_A_fn_class = fncls__10d; tmp4 = fncls__10d } else { tmp4 = fncls__10 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit17__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_27; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000051_fn__1769000052_A_New(); var tmp4 *jrt.Class; var fncls__11 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000051_fn__1769000052_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); aot_arbace_core.A_arbace_core_eval1769000051_fn__1769000052_A_fn_class = fncls__11d; tmp4 = fncls__11d } else { tmp4 = fncls__11 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit18__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_27; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000055_fn__1769000056_A_New(); var tmp4 *jrt.Class; var fncls__12 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000055_fn__1769000056_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); aot_arbace_core.A_arbace_core_eval1769000055_fn__1769000056_A_fn_class = fncls__12d; tmp4 = fncls__12d } else { tmp4 = fncls__12 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_part0_A_Unit19__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_28; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000059_fn__1769000060_A_New(); var tmp4 *jrt.Class; var fncls__13 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000059_fn__1769000060_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); aot_arbace_core.A_arbace_core_eval1769000059_fn__1769000060_A_fn_class = fncls__13d; tmp4 = fncls__13d } else { tmp4 = fncls__13 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit20__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(131, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_29; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000063_fn__1769000064_A_New(); var tmp4 *jrt.Class; var fncls__14 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000063_fn__1769000064_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); aot_arbace_core.A_arbace_core_eval1769000063_fn__1769000064_A_fn_class = fncls__14d; tmp4 = fncls__14d } else { tmp4 = fncls__14 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_part0_A_Unit21__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(138, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_30; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000067_fn__1769000068_A_New(); var tmp4 *jrt.Class; var fncls__15 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000067_fn__1769000068_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); aot_arbace_core.A_arbace_core_eval1769000067_fn__1769000068_A_fn_class = fncls__15d; tmp4 = fncls__15d } else { tmp4 = fncls__15 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_part0_A_Unit22__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(145, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_28; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000071_fn__1769000072_A_New(); var tmp4 *jrt.Class; var fncls__16 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000071_fn__1769000072_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); aot_arbace_core.A_arbace_core_eval1769000071_fn__1769000072_A_fn_class = fncls__16d; tmp4 = fncls__16d } else { tmp4 = fncls__16 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_core_print__init_part0_A_Unit23__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(151, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_31; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000077_fn__1769000078_A_New(); var tmp4 *jrt.Class; var fncls__17 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000077_fn__1769000078_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); aot_arbace_core.A_arbace_core_eval1769000077_fn__1769000078_A_fn_class = fncls__17d; tmp4 = fncls__17d } else { tmp4 = fncls__17 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit24__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(154, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_33, A_arbace_core_print__init_part0_A_const_31) }
func A_arbace_core_print__init_part0_A_Unit25__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(155, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_34, A_arbace_core_print__init_part0_A_const_31) }
func A_arbace_core_print__init_part0_A_Unit26__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(156, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_35, A_arbace_core_print__init_part0_A_const_31) }

func A_arbace_core_print__init_part0_A_Unit27__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_36; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000089_fn__1769000090_A_New(); var tmp4 *jrt.Class; var fncls__18 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000089_fn__1769000090_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); aot_arbace_core.A_arbace_core_eval1769000089_fn__1769000090_A_fn_class = fncls__18d; tmp4 = fncls__18d } else { tmp4 = fncls__18 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit28__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_36; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000093_fn__1769000094_A_New(); var tmp4 *jrt.Class; var fncls__19 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000093_fn__1769000094_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); aot_arbace_core.A_arbace_core_eval1769000093_fn__1769000094_A_fn_class = fncls__19d; tmp4 = fncls__19d } else { tmp4 = fncls__19 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_part0_A_Unit29__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(163, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_37; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000097_fn__1769000098_A_New(); var tmp4 *jrt.Class; var fncls__20 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000097_fn__1769000098_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); aot_arbace_core.A_arbace_core_eval1769000097_fn__1769000098_A_fn_class = fncls__20d; tmp4 = fncls__20d } else { tmp4 = fncls__20 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit30__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(166, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_37; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000101_fn__1769000102_A_New(); var tmp4 *jrt.Class; var fncls__21 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000101_fn__1769000102_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); aot_arbace_core.A_arbace_core_eval1769000101_fn__1769000102_A_fn_class = fncls__21d; tmp4 = fncls__21d } else { tmp4 = fncls__21 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_part0_A_Unit31__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(168, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_38; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000105_fn__1769000106_A_New(); var tmp4 *jrt.Class; var fncls__22 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000105_fn__1769000106_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); aot_arbace_core.A_arbace_core_eval1769000105_fn__1769000106_A_fn_class = fncls__22d; tmp4 = fncls__22d } else { tmp4 = fncls__22 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit32__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(171, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_38; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000109_fn__1769000110_A_New(); var tmp4 *jrt.Class; var fncls__23 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000109_fn__1769000110_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); aot_arbace_core.A_arbace_core_eval1769000109_fn__1769000110_A_fn_class = fncls__23d; tmp4 = fncls__23d } else { tmp4 = fncls__23 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit33__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(174, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_39; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000113_fn__1769000114_A_New(); var tmp4 *jrt.Class; var fncls__24 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000113_fn__1769000114_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); aot_arbace_core.A_arbace_core_eval1769000113_fn__1769000114_A_fn_class = fncls__24d; tmp4 = fncls__24d } else { tmp4 = fncls__24 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_core_print__init_part0_A_Unit34__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_39; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000117_fn__1769000118_A_New(); var tmp4 *jrt.Class; var fncls__25 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000117_fn__1769000118_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); aot_arbace_core.A_arbace_core_eval1769000117_fn__1769000118_A_fn_class = fncls__25d; tmp4 = fncls__25d } else { tmp4 = fncls__25 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit35__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(179, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_40; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000121_fn__1769000122_A_New(); var tmp4 *jrt.Class; var fncls__26 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000121_fn__1769000122_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); aot_arbace_core.A_arbace_core_eval1769000121_fn__1769000122_A_fn_class = fncls__26d; tmp4 = fncls__26d } else { tmp4 = fncls__26 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit36__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(180, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_39, A_arbace_core_print__init_part0_A_const_33) }
func A_arbace_core_print__init_part0_A_Unit37__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(181, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_39, A_arbace_core_print__init_part0_A_const_33) }
func A_arbace_core_print__init_part0_A_Unit38__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(182, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_39, A_arbace_core_print__init_part0_A_const_35) }
func A_arbace_core_print__init_part0_A_Unit39__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(183, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_39, A_arbace_core_print__init_part0_A_const_35) }

func A_arbace_core_print__init_part0_A_Unit40__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(185, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_35; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000135_fn__1769000136_A_New(); var tmp4 *jrt.Class; var fncls__27 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000135_fn__1769000136_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); aot_arbace_core.A_arbace_core_eval1769000135_fn__1769000136_A_fn_class = fncls__27d; tmp4 = fncls__27d } else { tmp4 = fncls__27 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit41__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(188, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_33; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000141_fn__1769000142_A_New(); var tmp4 *jrt.Class; var fncls__28 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000141_fn__1769000142_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); aot_arbace_core.A_arbace_core_eval1769000141_fn__1769000142_A_fn_class = fncls__28d; tmp4 = fncls__28d } else { tmp4 = fncls__28 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_core_print__init_part0_A_Unit42__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(196, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_33, A_arbace_core_print__init_part0_A_const_35) }

func A_arbace_core_print__init_part0_A_Unit43__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); A_arbace_core_print__init_part0_A_const_41.BindRoot_O__V(A_arbace_core_print__init_part0_A_const_42); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_41; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_43)); return A_arbace_core_print__init_part0_A_const_41 }











func A_arbace_core_print__init_part0_A_Unit44__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(210, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_44; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000147_fn__1769000148_A_New(); var tmp4 *jrt.Class; var fncls__29 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000147_fn__1769000148_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); aot_arbace_core.A_arbace_core_eval1769000147_fn__1769000148_A_fn_class = fncls__29d; tmp4 = fncls__29d } else { tmp4 = fncls__29 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }










func A_arbace_core_print__init_part0_A_Unit45__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(221, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_44; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000151_fn__1769000152_A_New(); var tmp4 *jrt.Class; var fncls__30 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000151_fn__1769000152_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); aot_arbace_core.A_arbace_core_eval1769000151_fn__1769000152_A_fn_class = fncls__30d; tmp4 = fncls__30d } else { tmp4 = fncls__30 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_part0_A_Unit46__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(223, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_45; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000155_fn__1769000156_A_New(); var tmp4 *jrt.Class; var fncls__31 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000155_fn__1769000156_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); aot_arbace_core.A_arbace_core_eval1769000155_fn__1769000156_A_fn_class = fncls__31d; tmp4 = fncls__31d } else { tmp4 = fncls__31 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_core_print__init_part0_A_Unit47__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(227, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_46; var tmp2 any = aot_arbace_core.A_arbace_core_print_prefix_map_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = aot_arbace_core.A_arbace_core_print_prefix_map_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); aot_arbace_core.A_arbace_core_print_prefix_map_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_47)); return A_arbace_core_print__init_part0_A_const_46 }








func A_arbace_core_print__init_part0_A_Unit48__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(236, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_48; var tmp2 any = aot_arbace_core.A_arbace_core_print_map_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = aot_arbace_core.A_arbace_core_print_map_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); aot_arbace_core.A_arbace_core_print_map_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_49)); return A_arbace_core_print__init_part0_A_const_48 }


func A_arbace_core_print__init_part0_A_Unit49__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(239, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_50; var tmp2 any = aot_arbace_core.A_arbace_core_strip_ns_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = aot_arbace_core.A_arbace_core_strip_ns_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); aot_arbace_core.A_arbace_core_strip_ns_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_51)); return A_arbace_core_print__init_part0_A_const_50 }





func A_arbace_core_print__init_part0_A_Unit50__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(245, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_52; var tmp2 any = aot_arbace_core.A_arbace_core_lift_ns_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = aot_arbace_core.A_arbace_core_lift_ns_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); aot_arbace_core.A_arbace_core_lift_ns_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_53)); return A_arbace_core_print__init_part0_A_const_52 }















func A_arbace_core_print__init_part0_A_Unit51__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(261, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_54; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000188_fn__1769000189_A_New(); var tmp4 *jrt.Class; var fncls__36 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000188_fn__1769000189_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); aot_arbace_core.A_arbace_core_eval1769000188_fn__1769000189_A_fn_class = fncls__36d; tmp4 = fncls__36d } else { tmp4 = fncls__36 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_part0_A_Unit52__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(268, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_34; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000197_fn__1769000198_A_New(); var tmp4 *jrt.Class; var fncls__37 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000197_fn__1769000198_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); aot_arbace_core.A_arbace_core_eval1769000197_fn__1769000198_A_fn_class = fncls__37d; tmp4 = fncls__37d } else { tmp4 = fncls__37 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit53__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(271, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_54; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000203_fn__1769000204_A_New(); var tmp4 *jrt.Class; var fncls__38 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000203_fn__1769000204_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); aot_arbace_core.A_arbace_core_eval1769000203_fn__1769000204_A_fn_class = fncls__38d; tmp4 = fncls__38d } else { tmp4 = fncls__38 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }








func A_arbace_core_print__init_part0_A_Unit54__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(280, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_33, A_arbace_core_print__init_part0_A_const_35) }
func A_arbace_core_print__init_part0_A_Unit55__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(281, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_33, A_arbace_core_print__init_part0_A_const_55) }
func A_arbace_core_print__init_part0_A_Unit56__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(282, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_55, A_arbace_core_print__init_part0_A_const_56) }
func A_arbace_core_print__init_part0_A_Unit57__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(283, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_33, A_arbace_core_print__init_part0_A_const_34) }

func A_arbace_core_print__init_part0_A_Unit58__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(285, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_56; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000215_fn__1769000216_A_New(); var tmp4 *jrt.Class; var fncls__39 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000215_fn__1769000216_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); aot_arbace_core.A_arbace_core_eval1769000215_fn__1769000216_A_fn_class = fncls__39d; tmp4 = fncls__39d } else { tmp4 = fncls__39 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_part0_A_Unit59__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(292, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_55; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000219_fn__1769000220_A_New(); var tmp4 *jrt.Class; var fncls__40 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000219_fn__1769000220_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); aot_arbace_core.A_arbace_core_eval1769000219_fn__1769000220_A_fn_class = fncls__40d; tmp4 = fncls__40d } else { tmp4 = fncls__40 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_part0_A_Unit60__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(299, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_34; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000223_fn__1769000224_A_New(); var tmp4 *jrt.Class; var fncls__41 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000223_fn__1769000224_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); aot_arbace_core.A_arbace_core_eval1769000223_fn__1769000224_A_fn_class = fncls__41d; tmp4 = fncls__41d } else { tmp4 = fncls__41 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_part0_A_Unit61__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(306, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_57; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000227_fn__1769000228_A_New(); var tmp4 *jrt.Class; var fncls__42 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000227_fn__1769000228_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); aot_arbace_core.A_arbace_core_eval1769000227_fn__1769000228_A_fn_class = fncls__42d; tmp4 = fncls__42d } else { tmp4 = fncls__42 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }








func A_arbace_core_print__init_part0_A_Unit62__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(315, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_58; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000231_fn__1769000232_A_New(); var tmp4 *jrt.Class; var fncls__43 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000231_fn__1769000232_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); aot_arbace_core.A_arbace_core_eval1769000231_fn__1769000232_A_fn_class = fncls__43d; tmp4 = fncls__43d } else { tmp4 = fncls__43 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_core_print__init_part0_A_Unit63__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(321, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_58; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000235_fn__1769000236_A_New(); var tmp4 *jrt.Class; var fncls__44 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000235_fn__1769000236_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); aot_arbace_core.A_arbace_core_eval1769000235_fn__1769000236_A_fn_class = fncls__44d; tmp4 = fncls__44d } else { tmp4 = fncls__44 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_core_print__init_part0_A_Unit64__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(329, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_58, A_arbace_core_print__init_part0_A_const_34) }
func A_arbace_core_print__init_part0_A_Unit65__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(330, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_58, A_arbace_core_print__init_part0_A_const_54) }
func A_arbace_core_print__init_part0_A_Unit66__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(331, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_58, A_arbace_core_print__init_part0_A_const_54) }
func A_arbace_core_print__init_part0_A_Unit67__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(332, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_33, A_arbace_core_print__init_part0_A_const_34) }
func A_arbace_core_print__init_part0_A_Unit68__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(333, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_58, A_arbace_core_print__init_part0_A_const_33) }
func A_arbace_core_print__init_part0_A_Unit69__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(334, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_32.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(), A_arbace_core_print__init_part0_A_const_58, A_arbace_core_print__init_part0_A_const_34) }

func A_arbace_core_print__init_part0_A_Unit70__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(336, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_59; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000251_fn__1769000252_A_New(); var tmp4 *jrt.Class; var fncls__45 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000251_fn__1769000252_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); aot_arbace_core.A_arbace_core_eval1769000251_fn__1769000252_A_fn_class = fncls__45d; tmp4 = fncls__45d } else { tmp4 = fncls__45 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_core_print__init_part0_A_Unit71__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(340, 1); A_arbace_core_print__init_part0_A_const_60.BindRoot_O__V(A_arbace_core_print__init_part0_A_const_61); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_60; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_62)); return A_arbace_core_print__init_part0_A_const_60 }










func A_arbace_core_print__init_part0_A_Unit72__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(351, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_63; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000255_fn__1769000256_A_New(); var tmp4 *jrt.Class; var fncls__46 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000255_fn__1769000256_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); aot_arbace_core.A_arbace_core_eval1769000255_fn__1769000256_A_fn_class = fncls__46d; tmp4 = fncls__46d } else { tmp4 = fncls__46 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_core_print__init_part0_A_Unit73__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(359, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_63; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000259_fn__1769000260_A_New(); var tmp4 *jrt.Class; var fncls__47 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000259_fn__1769000260_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); aot_arbace_core.A_arbace_core_eval1769000259_fn__1769000260_A_fn_class = fncls__47d; tmp4 = fncls__47d } else { tmp4 = fncls__47 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit74__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(360, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_64; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000263_fn__1769000264_A_New(); var tmp4 *jrt.Class; var fncls__48 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000263_fn__1769000264_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); aot_arbace_core.A_arbace_core_eval1769000263_fn__1769000264_A_fn_class = fncls__48d; tmp4 = fncls__48d } else { tmp4 = fncls__48 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit75__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(361, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_29; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000267_fn__1769000268_A_New(); var tmp4 *jrt.Class; var fncls__49 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000267_fn__1769000268_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); aot_arbace_core.A_arbace_core_eval1769000267_fn__1769000268_A_fn_class = fncls__49d; tmp4 = fncls__49d } else { tmp4 = fncls__49 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit76__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(362, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_65; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000271_fn__1769000272_A_New(); var tmp4 *jrt.Class; var fncls__50 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000271_fn__1769000272_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); aot_arbace_core.A_arbace_core_eval1769000271_fn__1769000272_A_fn_class = fncls__50d; tmp4 = fncls__50d } else { tmp4 = fncls__50 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit77__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(363, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_66; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000275_fn__1769000276_A_New(); var tmp4 *jrt.Class; var fncls__51 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000275_fn__1769000276_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); aot_arbace_core.A_arbace_core_eval1769000275_fn__1769000276_A_fn_class = fncls__51d; tmp4 = fncls__51d } else { tmp4 = fncls__51 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit78__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(364, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_67; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000279_fn__1769000280_A_New(); var tmp4 *jrt.Class; var fncls__52 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000279_fn__1769000280_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); aot_arbace_core.A_arbace_core_eval1769000279_fn__1769000280_A_fn_class = fncls__52d; tmp4 = fncls__52d } else { tmp4 = fncls__52 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit79__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(365, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_68; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000283_fn__1769000284_A_New(); var tmp4 *jrt.Class; var fncls__53 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000283_fn__1769000284_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); aot_arbace_core.A_arbace_core_eval1769000283_fn__1769000284_A_fn_class = fncls__53d; tmp4 = fncls__53d } else { tmp4 = fncls__53 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit80__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(366, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_69; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000287_fn__1769000288_A_New(); var tmp4 *jrt.Class; var fncls__54 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000287_fn__1769000288_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); aot_arbace_core.A_arbace_core_eval1769000287_fn__1769000288_A_fn_class = fncls__54d; tmp4 = fncls__54d } else { tmp4 = fncls__54 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit81__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(367, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_70; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000291_fn__1769000292_A_New(); var tmp4 *jrt.Class; var fncls__55 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000291_fn__1769000292_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); aot_arbace_core.A_arbace_core_eval1769000291_fn__1769000292_A_fn_class = fncls__55d; tmp4 = fncls__55d } else { tmp4 = fncls__55 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit82__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(368, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_71; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000295_fn__1769000296_A_New(); var tmp4 *jrt.Class; var fncls__56 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000295_fn__1769000296_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); aot_arbace_core.A_arbace_core_eval1769000295_fn__1769000296_A_fn_class = fncls__56d; tmp4 = fncls__56d } else { tmp4 = fncls__56 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_part0_A_Unit83__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(370, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_72; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, jrt.Float_TYPE.Ref(), Lit_58, jrt.Integer_TYPE.Ref(), Lit_59, jrt.Long_TYPE.Ref(), Lit_60, jrt.Boolean_TYPE.Ref(), Lit_61, jrt.Character_TYPE.Ref(), Lit_62, jrt.Double_TYPE.Ref(), Lit_63, jrt.Byte_TYPE.Ref(), Lit_64, jrt.Short_TYPE.Ref(), Lit_65))); var tmp2 *lang.Var = A_arbace_core_print__init_part0_A_const_72; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_73)); return A_arbace_core_print__init_part0_A_const_72 }









func A_arbace_core_print__init_part0_A_Unit84__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(380, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_74; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000299_fn__1769000300_A_New(); var tmp4 *jrt.Class; var fncls__57 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000299_fn__1769000300_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); aot_arbace_core.A_arbace_core_eval1769000299_fn__1769000300_A_fn_class = fncls__57d; tmp4 = fncls__57d } else { tmp4 = fncls__57 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_core_print__init_part0_A_Unit85__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(385, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_74; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000303_fn__1769000304_A_New(); var tmp4 *jrt.Class; var fncls__58 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000303_fn__1769000304_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); aot_arbace_core.A_arbace_core_eval1769000303_fn__1769000304_A_fn_class = fncls__58d; tmp4 = fncls__58d } else { tmp4 = fncls__58 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }













func A_arbace_core_print__init_part0_A_Unit86__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(399, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_66; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000307_fn__1769000308_A_New(); var tmp4 *jrt.Class; var fncls__59 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000307_fn__1769000308_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); aot_arbace_core.A_arbace_core_eval1769000307_fn__1769000308_A_fn_class = fncls__59d; tmp4 = fncls__59d } else { tmp4 = fncls__59 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_core_print__init_part0_A_Unit87__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(403, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_67; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000311_fn__1769000312_A_New(); var tmp4 *jrt.Class; var fncls__60 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000311_fn__1769000312_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); aot_arbace_core.A_arbace_core_eval1769000311_fn__1769000312_A_fn_class = fncls__60d; tmp4 = fncls__60d } else { tmp4 = fncls__60 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_core_print__init_part0_A_Unit88__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(407, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_75; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000315_fn__1769000316_A_New(); var tmp4 *jrt.Class; var fncls__61 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000315_fn__1769000316_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); aot_arbace_core.A_arbace_core_eval1769000315_fn__1769000316_A_fn_class = fncls__61d; tmp4 = fncls__61d } else { tmp4 = fncls__61 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





















func A_arbace_core_print__init_part0_A_Unit89__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(429, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_75; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000332_fn__1769000333_A_New(); var tmp4 *jrt.Class; var fncls__62 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000332_fn__1769000333_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); aot_arbace_core.A_arbace_core_eval1769000332_fn__1769000333_A_fn_class = fncls__62d; tmp4 = fncls__62d } else { tmp4 = fncls__62 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_part0_A_Unit90__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(431, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_76; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000336_fn__1769000337_A_New(); var tmp4 *jrt.Class; var fncls__63 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000336_fn__1769000337_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); aot_arbace_core.A_arbace_core_eval1769000336_fn__1769000337_A_fn_class = fncls__63d; tmp4 = fncls__63d } else { tmp4 = fncls__63 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_core_print__init_part0_A_Unit91__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(436, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_77; var tmp2 any = aot_arbace_core.A_arbace_core_deref_as_map_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = aot_arbace_core.A_arbace_core_deref_as_map_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); aot_arbace_core.A_arbace_core_deref_as_map_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_78)); return A_arbace_core_print__init_part0_A_const_77 }






















func A_arbace_core_print__init_part0_A_Unit92__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(459, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_79; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000346_fn__1769000347_A_New(); var tmp4 *jrt.Class; var fncls__65 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000346_fn__1769000347_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); aot_arbace_core.A_arbace_core_eval1769000346_fn__1769000347_A_fn_class = fncls__65d; tmp4 = fncls__65d } else { tmp4 = fncls__65 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit93__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(462, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_80; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000350_fn__1769000351_A_New(); var tmp4 *jrt.Class; var fncls__66 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000350_fn__1769000351_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); aot_arbace_core.A_arbace_core_eval1769000350_fn__1769000351_A_fn_class = fncls__66d; tmp4 = fncls__66d } else { tmp4 = fncls__66 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit94__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(465, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_81; var tmp2 any = aot_arbace_core.A_arbace_core_StackTraceElement__GT_vec_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = aot_arbace_core.A_arbace_core_StackTraceElement__GT_vec_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); aot_arbace_core.A_arbace_core_StackTraceElement__GT_vec_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_82)); return A_arbace_core_print__init_part0_A_const_81 }





func A_arbace_core_print__init_part0_A_Unit95__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(471, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_83; var tmp2 any = aot_arbace_core.A_arbace_core_Throwable__GT_map_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = aot_arbace_core.A_arbace_core_Throwable__GT_map_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); aot_arbace_core.A_arbace_core_Throwable__GT_map_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_84)); return A_arbace_core_print__init_part0_A_const_83 }



































func A_arbace_core_print__init_part0_A_Unit96__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(507, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_85; var tmp2 any = aot_arbace_core.A_arbace_core_print_throwable_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = aot_arbace_core.A_arbace_core_print_throwable_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); aot_arbace_core.A_arbace_core_print_throwable_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_86)); return A_arbace_core_print__init_part0_A_const_85 }



































func A_arbace_core_print__init_part0_A_Unit97__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(543, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_87; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000374_fn__1769000375_A_New(); var tmp4 *jrt.Class; var fncls__70 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000374_fn__1769000375_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); aot_arbace_core.A_arbace_core_eval1769000374_fn__1769000375_A_fn_class = fncls__70d; tmp4 = fncls__70d } else { tmp4 = fncls__70 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit98__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(546, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_88; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000378_fn__1769000379_A_New(); var tmp4 *jrt.Class; var fncls__71 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000378_fn__1769000379_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); aot_arbace_core.A_arbace_core_eval1769000378_fn__1769000379_A_fn_class = fncls__71d; tmp4 = fncls__71d } else { tmp4 = fncls__71 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_core_print__init_part0_A_Unit99__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(552, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_88; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000382_fn__1769000383_A_New(); var tmp4 *jrt.Class; var fncls__72 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000382_fn__1769000383_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); aot_arbace_core.A_arbace_core_eval1769000382_fn__1769000383_A_fn_class = fncls__72d; tmp4 = fncls__72d } else { tmp4 = fncls__72 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_part1_A_Unit100__O() any { A_arbace_core_print__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(554, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part1_A_const_1; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000386_fn__1769000387_A_New(); var tmp4 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000386_fn__1769000387_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); aot_arbace_core.A_arbace_core_eval1769000386_fn__1769000387_A_fn_class = fncls__1d; tmp4 = fncls__1d } else { tmp4 = fncls__1 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
//line :554:1
func A_arbace_core_print__init_part1_A_Init__O() any { A_arbace_core_print__init_part1_A_Init(); return nil }
//line :554:1
func A_arbace_core_print__init_part1_A_Load__O() any { A_arbace_core_print__init_part1_A_Init(); A_arbace_core_print__init_part1_A_Unit100__O(); A_arbace_core_print__init_part1_A_Unit101__O(); A_arbace_core_print__init_part1_A_Unit102__O(); return nil }




func A_arbace_core_print__init_part1_A_Unit101__O() any { A_arbace_core_print__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(559, 1); A_arbace_core_print__init_part1_A_const_2.BindRoot_O__V(jrt.Boolean_TRUE.Ref()); var tmp1 *lang.Var = A_arbace_core_print__init_part1_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part1_A_const_3)); return A_arbace_core_print__init_part1_A_const_2 }

func A_arbace_core_print__init_part1_A_Unit102__O() any { A_arbace_core_print__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(561, 1); var tmp1 any = A_arbace_core_print__init_part1_A_const_7; lang.IFn_Cast(A_arbace_core_print__init_part1_A_const_6.GetRawRoot__O()).ApplyTo_ISeq__O(lang.RT_Cons_O_O__ISeq_NoInit(tmp1, lang.RT_Seq_O__ISeq_NoInit(jrt.RefArrayOf(jrt.Object_class)))); var tmp2 *lang.Var = A_arbace_core_print__init_part1_A_const_4; var tmp3 any = aot_arbace_core.A_arbace_core_PrintWriter_on_A_New(); var tmp4 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_core.A_arbace_core_PrintWriter_on_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); aot_arbace_core.A_arbace_core_PrintWriter_on_A_fn_class = fncls__2d; tmp4 = fncls__2d } else { tmp4 = fncls__2 }; tmp2.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); var tmp5 *lang.Var = A_arbace_core_print__init_part1_A_const_4; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part1_A_const_5)); return A_arbace_core_print__init_part1_A_const_4 }



type A_arbace_core_print__init_A struct{ jrt.Object }

func A_arbace_core_print__init_A_New() *A_arbace_core_print__init_A { t := &A_arbace_core_print__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_print__init_A) Ctor() {}

func (t *A_arbace_core_print__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_print__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_print__init_A_class }

func (t *A_arbace_core_print__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_print__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_print__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_print__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_print__init_A); return ok }

func A_arbace_core_print__init_A_Cast(x any) *A_arbace_core_print__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_print__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_print__init_A_class)) }; return v }



type A_arbace_core_print__init_part0_A struct{ jrt.Object }

var A_arbace_core_print__init_part0_A_const_pool *jrt.RefArray

var A_arbace_core_print__init_part0_A_const_0 *lang.Var

var A_arbace_core_print__init_part0_A_const_1 any

var A_arbace_core_print__init_part0_A_const_2 *lang.Var

var A_arbace_core_print__init_part0_A_const_3 *lang.Var

var A_arbace_core_print__init_part0_A_const_4 any

var A_arbace_core_print__init_part0_A_const_5 *lang.Var

var A_arbace_core_print__init_part0_A_const_6 any

var A_arbace_core_print__init_part0_A_const_7 *lang.Var

var A_arbace_core_print__init_part0_A_const_8 any

var A_arbace_core_print__init_part0_A_const_9 *lang.Var

var A_arbace_core_print__init_part0_A_const_10 any

var A_arbace_core_print__init_part0_A_const_11 *lang.Var

var A_arbace_core_print__init_part0_A_const_12 any

var A_arbace_core_print__init_part0_A_const_13 *lang.Var

var A_arbace_core_print__init_part0_A_const_14 any

var A_arbace_core_print__init_part0_A_const_15 *lang.Var

var A_arbace_core_print__init_part0_A_const_16 any

var A_arbace_core_print__init_part0_A_const_17 *lang.Var

var A_arbace_core_print__init_part0_A_const_18 *lang.Keyword

var A_arbace_core_print__init_part0_A_const_19 *lang.Var

var A_arbace_core_print__init_part0_A_const_20 *lang.Var

var A_arbace_core_print__init_part0_A_const_21 any

var A_arbace_core_print__init_part0_A_const_22 *lang.Var

var A_arbace_core_print__init_part0_A_const_23 any

var A_arbace_core_print__init_part0_A_const_24 *lang.Var

var A_arbace_core_print__init_part0_A_const_25 any

var A_arbace_core_print__init_part0_A_const_26 *jrt.Class

var A_arbace_core_print__init_part0_A_const_27 *jrt.Class

var A_arbace_core_print__init_part0_A_const_28 *jrt.Class

var A_arbace_core_print__init_part0_A_const_29 *jrt.Class

var A_arbace_core_print__init_part0_A_const_30 *jrt.Class

var A_arbace_core_print__init_part0_A_const_31 *jrt.Class

var A_arbace_core_print__init_part0_A_const_32 *lang.Var

var A_arbace_core_print__init_part0_A_const_33 *jrt.Class

var A_arbace_core_print__init_part0_A_const_34 *jrt.Class

var A_arbace_core_print__init_part0_A_const_35 *jrt.Class

var A_arbace_core_print__init_part0_A_const_36 *jrt.Class

var A_arbace_core_print__init_part0_A_const_37 *jrt.Class

var A_arbace_core_print__init_part0_A_const_38 *jrt.Class

var A_arbace_core_print__init_part0_A_const_39 *jrt.Class

var A_arbace_core_print__init_part0_A_const_40 *jrt.Class

var A_arbace_core_print__init_part0_A_const_41 *lang.Var

var A_arbace_core_print__init_part0_A_const_42 any

var A_arbace_core_print__init_part0_A_const_43 any

var A_arbace_core_print__init_part0_A_const_44 *jrt.Class

var A_arbace_core_print__init_part0_A_const_45 *jrt.Class

var A_arbace_core_print__init_part0_A_const_46 *lang.Var

var A_arbace_core_print__init_part0_A_const_47 any

var A_arbace_core_print__init_part0_A_const_48 *lang.Var

var A_arbace_core_print__init_part0_A_const_49 any

var A_arbace_core_print__init_part0_A_const_50 *lang.Var

var A_arbace_core_print__init_part0_A_const_51 any

var A_arbace_core_print__init_part0_A_const_52 *lang.Var

var A_arbace_core_print__init_part0_A_const_53 any

var A_arbace_core_print__init_part0_A_const_54 *jrt.Class

var A_arbace_core_print__init_part0_A_const_55 *jrt.Class

var A_arbace_core_print__init_part0_A_const_56 *jrt.Class

var A_arbace_core_print__init_part0_A_const_57 *jrt.Class

var A_arbace_core_print__init_part0_A_const_58 *jrt.Class

var A_arbace_core_print__init_part0_A_const_59 *jrt.Class

var A_arbace_core_print__init_part0_A_const_60 *lang.Var

var A_arbace_core_print__init_part0_A_const_61 any

var A_arbace_core_print__init_part0_A_const_62 any

var A_arbace_core_print__init_part0_A_const_63 *jrt.Class

var A_arbace_core_print__init_part0_A_const_64 *jrt.Class

var A_arbace_core_print__init_part0_A_const_65 *jrt.Class

var A_arbace_core_print__init_part0_A_const_66 *jrt.Class

var A_arbace_core_print__init_part0_A_const_67 *jrt.Class

var A_arbace_core_print__init_part0_A_const_68 *jrt.Class

var A_arbace_core_print__init_part0_A_const_69 *jrt.Class

var A_arbace_core_print__init_part0_A_const_70 *jrt.Class

var A_arbace_core_print__init_part0_A_const_71 *jrt.Class

var A_arbace_core_print__init_part0_A_const_72 *lang.Var

var A_arbace_core_print__init_part0_A_const_73 any

var A_arbace_core_print__init_part0_A_const_74 *jrt.Class

var A_arbace_core_print__init_part0_A_const_75 *jrt.Class

var A_arbace_core_print__init_part0_A_const_76 *jrt.Class

var A_arbace_core_print__init_part0_A_const_77 *lang.Var

var A_arbace_core_print__init_part0_A_const_78 any

var A_arbace_core_print__init_part0_A_const_79 *jrt.Class

var A_arbace_core_print__init_part0_A_const_80 *jrt.Class

var A_arbace_core_print__init_part0_A_const_81 *lang.Var

var A_arbace_core_print__init_part0_A_const_82 any

var A_arbace_core_print__init_part0_A_const_83 *lang.Var

var A_arbace_core_print__init_part0_A_const_84 any

var A_arbace_core_print__init_part0_A_const_85 *lang.Var

var A_arbace_core_print__init_part0_A_const_86 any

var A_arbace_core_print__init_part0_A_const_87 *jrt.Class

var A_arbace_core_print__init_part0_A_const_88 *jrt.Class

var A_arbace_core_print__init_part0_A_init jrt.ClassInit

func A_arbace_core_print__init_part0_A_Init() { if !A_arbace_core_print__init_part0_A_init.Done() { A_arbace_core_print__init_part0_A_init.Run(A_arbace_core_print__init_part0_A_clinit) } }

func A_arbace_core_print__init_part0_A_clinit() { A_arbace_core_print__init_part0_A_clinit_p0(); A_arbace_core_print__init_part0_A_clinit_p1(); A_arbace_core_print__init_part0_A_clinit_p2(); A_arbace_core_print__init_part0_A_clinit_p3(); A_arbace_core_print__init_part0_A_clinit_p4(); A_arbace_core_print__init_part0_A_clinit_p5(); A_arbace_core_print__init_part0_A_clinit_p6(); A_arbace_core_print__init_part0_A_clinit_p7() }

func A_arbace_core_print__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_core_print__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 115); A_arbace_core_print__init_part0_A_const_0 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[26]); A_arbace_core_print__init_part0_A_const_1 = A_arbace_core_print__init_part0_A_const_pool.A[27]; A_arbace_core_print__init_part0_A_const_2 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[28]); A_arbace_core_print__init_part0_A_const_3 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[29]); A_arbace_core_print__init_part0_A_const_4 = A_arbace_core_print__init_part0_A_const_pool.A[30]; A_arbace_core_print__init_part0_A_const_5 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[31]); A_arbace_core_print__init_part0_A_const_6 = A_arbace_core_print__init_part0_A_const_pool.A[32]; A_arbace_core_print__init_part0_A_const_7 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[33]); A_arbace_core_print__init_part0_A_const_8 = A_arbace_core_print__init_part0_A_const_pool.A[34]; A_arbace_core_print__init_part0_A_const_9 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[35]); A_arbace_core_print__init_part0_A_const_10 = A_arbace_core_print__init_part0_A_const_pool.A[36]; A_arbace_core_print__init_part0_A_const_11 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[37]) }

func A_arbace_core_print__init_part0_A_clinit_p1() { A_arbace_core_print__init_part0_A_const_12 = A_arbace_core_print__init_part0_A_const_pool.A[38]; A_arbace_core_print__init_part0_A_const_13 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[39]); A_arbace_core_print__init_part0_A_const_14 = A_arbace_core_print__init_part0_A_const_pool.A[40]; A_arbace_core_print__init_part0_A_const_15 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[41]); A_arbace_core_print__init_part0_A_const_16 = A_arbace_core_print__init_part0_A_const_pool.A[42]; A_arbace_core_print__init_part0_A_const_17 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[43]); A_arbace_core_print__init_part0_A_const_18 = lang.Keyword_Cast(A_arbace_core_print__init_part0_A_const_pool.A[44]); A_arbace_core_print__init_part0_A_const_19 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[45]); A_arbace_core_print__init_part0_A_const_20 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[46]); A_arbace_core_print__init_part0_A_const_21 = A_arbace_core_print__init_part0_A_const_pool.A[47]; A_arbace_core_print__init_part0_A_const_22 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[48]); A_arbace_core_print__init_part0_A_const_23 = A_arbace_core_print__init_part0_A_const_pool.A[49]; A_arbace_core_print__init_part0_A_const_24 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[50]) }

func A_arbace_core_print__init_part0_A_clinit_p2() { A_arbace_core_print__init_part0_A_const_25 = A_arbace_core_print__init_part0_A_const_pool.A[51]; A_arbace_core_print__init_part0_A_const_26 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[52]); A_arbace_core_print__init_part0_A_const_27 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[53]); A_arbace_core_print__init_part0_A_const_28 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[54]); A_arbace_core_print__init_part0_A_const_29 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[55]); A_arbace_core_print__init_part0_A_const_30 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[56]); A_arbace_core_print__init_part0_A_const_31 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[57]); A_arbace_core_print__init_part0_A_const_32 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[58]); A_arbace_core_print__init_part0_A_const_33 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[59]); A_arbace_core_print__init_part0_A_const_34 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[60]); A_arbace_core_print__init_part0_A_const_35 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[61]); A_arbace_core_print__init_part0_A_const_36 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[62]) }

func A_arbace_core_print__init_part0_A_clinit_p3() { A_arbace_core_print__init_part0_A_const_37 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[63]); A_arbace_core_print__init_part0_A_const_38 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[64]); A_arbace_core_print__init_part0_A_const_39 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[65]); A_arbace_core_print__init_part0_A_const_40 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[66]); A_arbace_core_print__init_part0_A_const_41 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[67]); A_arbace_core_print__init_part0_A_const_42 = A_arbace_core_print__init_part0_A_const_pool.A[68]; A_arbace_core_print__init_part0_A_const_43 = A_arbace_core_print__init_part0_A_const_pool.A[69]; A_arbace_core_print__init_part0_A_const_44 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[70]); A_arbace_core_print__init_part0_A_const_45 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[71]); A_arbace_core_print__init_part0_A_const_46 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[72]); A_arbace_core_print__init_part0_A_const_47 = A_arbace_core_print__init_part0_A_const_pool.A[73]; A_arbace_core_print__init_part0_A_const_48 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[74]); A_arbace_core_print__init_part0_A_const_49 = A_arbace_core_print__init_part0_A_const_pool.A[75] }

func A_arbace_core_print__init_part0_A_clinit_p4() { A_arbace_core_print__init_part0_A_const_50 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[76]); A_arbace_core_print__init_part0_A_const_51 = A_arbace_core_print__init_part0_A_const_pool.A[77]; A_arbace_core_print__init_part0_A_const_52 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[78]); A_arbace_core_print__init_part0_A_const_53 = A_arbace_core_print__init_part0_A_const_pool.A[79]; A_arbace_core_print__init_part0_A_const_54 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[80]); A_arbace_core_print__init_part0_A_const_55 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[81]); A_arbace_core_print__init_part0_A_const_56 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[82]); A_arbace_core_print__init_part0_A_const_57 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[83]); A_arbace_core_print__init_part0_A_const_58 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[84]); A_arbace_core_print__init_part0_A_const_59 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[85]); A_arbace_core_print__init_part0_A_const_60 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[86]); A_arbace_core_print__init_part0_A_const_61 = A_arbace_core_print__init_part0_A_const_pool.A[87]; A_arbace_core_print__init_part0_A_const_62 = A_arbace_core_print__init_part0_A_const_pool.A[88] }

func A_arbace_core_print__init_part0_A_clinit_p5() { A_arbace_core_print__init_part0_A_const_63 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[89]); A_arbace_core_print__init_part0_A_const_64 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[90]); A_arbace_core_print__init_part0_A_const_65 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[91]); A_arbace_core_print__init_part0_A_const_66 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[92]); A_arbace_core_print__init_part0_A_const_67 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[93]); A_arbace_core_print__init_part0_A_const_68 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[94]); A_arbace_core_print__init_part0_A_const_69 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[95]); A_arbace_core_print__init_part0_A_const_70 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[96]); A_arbace_core_print__init_part0_A_const_71 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[97]); A_arbace_core_print__init_part0_A_const_72 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[98]); A_arbace_core_print__init_part0_A_const_73 = A_arbace_core_print__init_part0_A_const_pool.A[99]; A_arbace_core_print__init_part0_A_const_74 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[100]) }

func A_arbace_core_print__init_part0_A_clinit_p6() { A_arbace_core_print__init_part0_A_const_75 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[101]); A_arbace_core_print__init_part0_A_const_76 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[102]); A_arbace_core_print__init_part0_A_const_77 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[103]); A_arbace_core_print__init_part0_A_const_78 = A_arbace_core_print__init_part0_A_const_pool.A[104]; A_arbace_core_print__init_part0_A_const_79 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[105]); A_arbace_core_print__init_part0_A_const_80 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[106]); A_arbace_core_print__init_part0_A_const_81 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[107]); A_arbace_core_print__init_part0_A_const_82 = A_arbace_core_print__init_part0_A_const_pool.A[108]; A_arbace_core_print__init_part0_A_const_83 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[109]); A_arbace_core_print__init_part0_A_const_84 = A_arbace_core_print__init_part0_A_const_pool.A[110]; A_arbace_core_print__init_part0_A_const_85 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[111]); A_arbace_core_print__init_part0_A_const_86 = A_arbace_core_print__init_part0_A_const_pool.A[112]; A_arbace_core_print__init_part0_A_const_87 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[113]) }

func A_arbace_core_print__init_part0_A_clinit_p7() { A_arbace_core_print__init_part0_A_const_88 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[114]) }

func A_arbace_core_print__init_part0_A_New() *A_arbace_core_print__init_part0_A { A_arbace_core_print__init_part0_A_Init(); t := &A_arbace_core_print__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_core_print__init_part0_A) Ctor() {}

func (t *A_arbace_core_print__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_print__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_core_print__init_part0_A_class }

func (t *A_arbace_core_print__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_print__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_print__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_print__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_print__init_part0_A); return ok }

func A_arbace_core_print__init_part0_A_Cast(x any) *A_arbace_core_print__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_print__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_print__init_part0_A_class)) }; return v }



type A_arbace_core_print__init_part1_A struct{ jrt.Object }

var A_arbace_core_print__init_part1_A_const_pool *jrt.RefArray

var A_arbace_core_print__init_part1_A_const_0 *lang.Var

var A_arbace_core_print__init_part1_A_const_1 *jrt.Class

var A_arbace_core_print__init_part1_A_const_2 *lang.Var

var A_arbace_core_print__init_part1_A_const_3 any

var A_arbace_core_print__init_part1_A_const_4 *lang.Var

var A_arbace_core_print__init_part1_A_const_5 any

var A_arbace_core_print__init_part1_A_const_6 *lang.Var

var A_arbace_core_print__init_part1_A_const_7 *jrt.Class

var A_arbace_core_print__init_part1_A_init jrt.ClassInit

func A_arbace_core_print__init_part1_A_Init() { if !A_arbace_core_print__init_part1_A_init.Done() { A_arbace_core_print__init_part1_A_init.Run(A_arbace_core_print__init_part1_A_clinit) } }

func A_arbace_core_print__init_part1_A_clinit() { jrt.StartCheck(); A_arbace_core_print__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_82, 18); var tmp1 *lang.Var; A_arbace_core_print__init_part0_A_Init(); tmp1 = A_arbace_core_print__init_part0_A_const_17; A_arbace_core_print__init_part1_A_const_0 = tmp1; A_arbace_core_print__init_part1_A_const_1 = jrt.Class_Cast(A_arbace_core_print__init_part1_A_const_pool.A[11]); A_arbace_core_print__init_part1_A_const_2 = lang.Var_Cast(A_arbace_core_print__init_part1_A_const_pool.A[12]); A_arbace_core_print__init_part1_A_const_3 = A_arbace_core_print__init_part1_A_const_pool.A[13]; A_arbace_core_print__init_part1_A_const_4 = lang.Var_Cast(A_arbace_core_print__init_part1_A_const_pool.A[14]); A_arbace_core_print__init_part1_A_const_5 = A_arbace_core_print__init_part1_A_const_pool.A[15]; A_arbace_core_print__init_part1_A_const_6 = lang.Var_Cast(A_arbace_core_print__init_part1_A_const_pool.A[16]); A_arbace_core_print__init_part1_A_const_7 = jrt.Class_Cast(A_arbace_core_print__init_part1_A_const_pool.A[17]) }

func A_arbace_core_print__init_part1_A_New() *A_arbace_core_print__init_part1_A { A_arbace_core_print__init_part1_A_Init(); t := &A_arbace_core_print__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_core_print__init_part1_A) Ctor() {}

func (t *A_arbace_core_print__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_print__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_core_print__init_part1_A_class }

func (t *A_arbace_core_print__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_print__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_print__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_print__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_print__init_part1_A); return ok }

func A_arbace_core_print__init_part1_A_Cast(x any) *A_arbace_core_print__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_print__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_print__init_part1_A_class)) }; return v }
