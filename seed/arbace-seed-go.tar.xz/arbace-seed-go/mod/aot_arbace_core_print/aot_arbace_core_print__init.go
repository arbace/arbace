//line aot_arbace_core_print__init.ae:1
package aot_arbace_core_print

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_print__init_A_Load__O() any { jrt.StartCheck(); A_arbace_core_print__init_part0_A_Init__O(); A_arbace_core_print__init_part1_A_Init__O(); A_arbace_core_print__init_part0_A_Load__O(); A_arbace_core_print__init_part1_A_Load__O(); return nil }



func A_arbace_core_print__init_part0_A_Unit0__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_print__init_part0_A_const_1) }
//line :9:1
func A_arbace_core_print__init_part0_A_Init__O() any { A_arbace_core_print__init_part0_A_Init(); return nil }
//line :9:1
func A_arbace_core_print__init_part0_A_Load__O() any { A_arbace_core_print__init_part0_A_Init(); A_arbace_core_print__init_part0_A_Unit0__O(); A_arbace_core_print__init_part0_A_Unit1__O(); A_arbace_core_print__init_part0_A_Unit2__O(); A_arbace_core_print__init_part0_A_Unit3__O(); A_arbace_core_print__init_part0_A_Unit4__O(); A_arbace_core_print__init_part0_A_Unit5__O(); A_arbace_core_print__init_part0_A_Unit6__O(); A_arbace_core_print__init_part0_A_Unit7__O(); A_arbace_core_print__init_part0_A_Unit8__O(); A_arbace_core_print__init_part0_A_Unit9__O(); A_arbace_core_print__init_part0_A_Unit10__O(); A_arbace_core_print__init_part0_A_Unit11__O(); A_arbace_core_print__init_part0_A_Unit12__O(); A_arbace_core_print__init_part0_A_Unit13__O(); A_arbace_core_print__init_part0_A_Unit14__O(); A_arbace_core_print__init_part0_A_Unit15__O(); A_arbace_core_print__init_part0_A_Unit16__O(); A_arbace_core_print__init_part0_A_Unit17__O(); A_arbace_core_print__init_part0_A_Unit18__O(); A_arbace_core_print__init_part0_A_Unit19__O(); A_arbace_core_print__init_part0_A_Unit20__O(); A_arbace_core_print__init_part0_A_Unit21__O(); A_arbace_core_print__init_part0_A_Unit22__O(); A_arbace_core_print__init_part0_A_Unit23__O(); A_arbace_core_print__init_part0_A_Unit24__O(); A_arbace_core_print__init_part0_A_Unit25__O(); A_arbace_core_print__init_part0_A_Unit26__O(); A_arbace_core_print__init_part0_A_Unit27__O(); A_arbace_core_print__init_part0_A_Unit28__O(); A_arbace_core_print__init_part0_A_Unit29__O(); A_arbace_core_print__init_part0_A_Unit30__O(); A_arbace_core_print__init_part0_A_Unit31__O(); A_arbace_core_print__init_part0_A_Unit32__O(); A_arbace_core_print__init_part0_A_Unit33__O(); A_arbace_core_print__init_part0_A_Unit34__O(); A_arbace_core_print__init_part0_A_Unit35__O(); A_arbace_core_print__init_part0_A_Unit36__O(); A_arbace_core_print__init_part0_A_Unit37__O(); A_arbace_core_print__init_part0_A_Unit38__O(); A_arbace_core_print__init_part0_A_Unit39__O(); A_arbace_core_print__init_part0_A_Unit40__O(); A_arbace_core_print__init_part0_A_Unit41__O(); A_arbace_core_print__init_part0_A_Unit42__O(); A_arbace_core_print__init_part0_A_Unit43__O(); A_arbace_core_print__init_part0_A_Unit44__O(); A_arbace_core_print__init_part0_A_Unit45__O(); A_arbace_core_print__init_part0_A_Unit46__O(); A_arbace_core_print__init_part0_A_Unit47__O(); A_arbace_core_print__init_part0_A_Unit48__O(); A_arbace_core_print__init_part0_A_Unit49__O(); A_arbace_core_print__init_part0_A_Unit50__O(); A_arbace_core_print__init_part0_A_Unit51__O(); A_arbace_core_print__init_part0_A_Unit52__O(); A_arbace_core_print__init_part0_A_Unit53__O(); A_arbace_core_print__init_part0_A_Unit54__O(); A_arbace_core_print__init_part0_A_Unit55__O(); A_arbace_core_print__init_part0_A_Unit56__O(); A_arbace_core_print__init_part0_A_Unit57__O(); A_arbace_core_print__init_part0_A_Unit58__O(); A_arbace_core_print__init_part0_A_Unit59__O(); A_arbace_core_print__init_part0_A_Unit60__O(); A_arbace_core_print__init_part0_A_Unit61__O(); A_arbace_core_print__init_part0_A_Unit62__O(); A_arbace_core_print__init_part0_A_Unit63__O(); A_arbace_core_print__init_part0_A_Unit64__O(); A_arbace_core_print__init_part0_A_Unit65__O(); A_arbace_core_print__init_part0_A_Unit66__O(); A_arbace_core_print__init_part0_A_Unit67__O(); A_arbace_core_print__init_part0_A_Unit68__O(); A_arbace_core_print__init_part0_A_Unit69__O(); A_arbace_core_print__init_part0_A_Unit70__O(); A_arbace_core_print__init_part0_A_Unit71__O(); A_arbace_core_print__init_part0_A_Unit72__O(); A_arbace_core_print__init_part0_A_Unit73__O(); A_arbace_core_print__init_part0_A_Unit74__O(); A_arbace_core_print__init_part0_A_Unit75__O(); A_arbace_core_print__init_part0_A_Unit76__O(); A_arbace_core_print__init_part0_A_Unit77__O(); A_arbace_core_print__init_part0_A_Unit78__O(); A_arbace_core_print__init_part0_A_Unit79__O(); A_arbace_core_print__init_part0_A_Unit80__O(); A_arbace_core_print__init_part0_A_Unit81__O(); A_arbace_core_print__init_part0_A_Unit82__O(); A_arbace_core_print__init_part0_A_Unit83__O(); A_arbace_core_print__init_part0_A_Unit84__O(); A_arbace_core_print__init_part0_A_Unit85__O(); A_arbace_core_print__init_part0_A_Unit86__O(); A_arbace_core_print__init_part0_A_Unit87__O(); A_arbace_core_print__init_part0_A_Unit88__O(); A_arbace_core_print__init_part0_A_Unit89__O(); A_arbace_core_print__init_part0_A_Unit90__O(); A_arbace_core_print__init_part0_A_Unit91__O(); A_arbace_core_print__init_part0_A_Unit92__O(); A_arbace_core_print__init_part0_A_Unit93__O(); A_arbace_core_print__init_part0_A_Unit94__O(); A_arbace_core_print__init_part0_A_Unit95__O(); A_arbace_core_print__init_part0_A_Unit96__O(); A_arbace_core_print__init_part0_A_Unit97__O(); A_arbace_core_print__init_part0_A_Unit98__O(); A_arbace_core_print__init_part0_A_Unit99__O(); return nil }



func A_arbace_core_print__init_part0_A_Unit1__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)).Ref() }

func A_arbace_core_print__init_part0_A_Unit2__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); return A_arbace_core_print__init_part0_A_const_2.Set_O__O(jrt.Boolean_TRUE.Ref()) }
func A_arbace_core_print__init_part0_A_Unit3__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); A_arbace_core_print__init_part0_A_const_3.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_3; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_4)); return A_arbace_core_print__init_part0_A_const_3.SetDynamic_Z__Var(true).Ref() }










func A_arbace_core_print__init_part0_A_Unit4__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(27, 1); A_arbace_core_print__init_part0_A_const_5.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_5; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_6)); return A_arbace_core_print__init_part0_A_const_5.SetDynamic_Z__Var(true).Ref() }











func A_arbace_core_print__init_part0_A_Unit5__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); A_arbace_core_print__init_part0_A_const_7.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_7; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_8)); return A_arbace_core_print__init_part0_A_const_7.SetDynamic_Z__Var(true).Ref() }

func A_arbace_core_print__init_part0_A_Unit6__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); A_arbace_core_print__init_part0_A_const_9.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_9; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_10)); return A_arbace_core_print__init_part0_A_const_9.SetDynamic_Z__Var(true).Ref() }






func A_arbace_core_print__init_part0_A_Unit7__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_11; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = aot_arbace_core.A_arbace_core_print_sequential_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_core.A_arbace_core_print_sequential_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); aot_arbace_core.A_arbace_core_print_sequential_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_12)); return A_arbace_core_print__init_part0_A_const_11 }























func A_arbace_core_print__init_part0_A_Unit8__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = aot_arbace_core.A_arbace_core_print_meta_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_core.A_arbace_core_print_meta_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); aot_arbace_core.A_arbace_core_print_meta_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_14)); return A_arbace_core_print__init_part0_A_const_13 }










func A_arbace_core_print__init_part0_A_Unit9__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = aot_arbace_core.A_arbace_core_print_simple_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_core.A_arbace_core_print_simple_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); aot_arbace_core.A_arbace_core_print_simple_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_16)); return A_arbace_core_print__init_part0_A_const_15 }



func A_arbace_core_print__init_part0_A_Unit10__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(87, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_18; var tmp3 *lang.Compiler_AOTFn; var fnbody__8 any = aot_arbace_core.A_arbace_core_eval1769000030_fn__1769000031_A_New(); var tmp4 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000030_fn__1769000031_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, nil); aot_arbace_core.A_arbace_core_eval1769000030_fn__1769000031_A_fn_class = fncls__7d; tmp4 = fncls__7d } else { tmp4 = fncls__7 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }




func A_arbace_core_print__init_part0_A_Unit11__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = aot_arbace_core.A_arbace_core_eval1769000036_fn__1769000037_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000036_fn__1769000037_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, nil); aot_arbace_core.A_arbace_core_eval1769000036_fn__1769000037_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(nil, Up_Compiler_AOTFn_IFn(tmp2)).Ref() }


func A_arbace_core_print__init_part0_A_Unit12__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = aot_arbace_core.A_arbace_core_eval1769000040_fn__1769000041_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000040_fn__1769000041_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, nil); aot_arbace_core.A_arbace_core_eval1769000040_fn__1769000041_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(nil, Up_Compiler_AOTFn_IFn(tmp2)).Ref() }

func A_arbace_core_print__init_part0_A_Unit13__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = aot_arbace_core.A_arbace_core_print_ctor_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = aot_arbace_core.A_arbace_core_print_ctor_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, nil); aot_arbace_core.A_arbace_core_print_ctor_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_21)); return A_arbace_core_print__init_part0_A_const_20 }






func A_arbace_core_print__init_part0_A_Unit14__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(104, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = aot_arbace_core.A_arbace_core_print_tagged_object_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = aot_arbace_core.A_arbace_core_print_tagged_object_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, nil); aot_arbace_core.A_arbace_core_print_tagged_object_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_23)); return A_arbace_core_print__init_part0_A_const_22 }












func A_arbace_core_print__init_part0_A_Unit15__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(117, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = aot_arbace_core.A_arbace_core_print_object_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = aot_arbace_core.A_arbace_core_print_object_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, nil); aot_arbace_core.A_arbace_core_print_object_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_25)); return A_arbace_core_print__init_part0_A_const_24 }


func A_arbace_core_print__init_part0_A_Unit16__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(120, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_26; var tmp3 *lang.Compiler_AOTFn; var fnbody__20 any = aot_arbace_core.A_arbace_core_eval1769000047_fn__1769000048_A_New(); var tmp4 *jrt.Class; var fncls__19 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000047_fn__1769000048_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, nil); aot_arbace_core.A_arbace_core_eval1769000047_fn__1769000048_A_fn_class = fncls__19d; tmp4 = fncls__19d } else { tmp4 = fncls__19 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_core_print__init_part0_A_Unit17__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_27; var tmp3 *lang.Compiler_AOTFn; var fnbody__22 any = aot_arbace_core.A_arbace_core_eval1769000051_fn__1769000052_A_New(); var tmp4 *jrt.Class; var fncls__21 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000051_fn__1769000052_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, nil); aot_arbace_core.A_arbace_core_eval1769000051_fn__1769000052_A_fn_class = fncls__21d; tmp4 = fncls__21d } else { tmp4 = fncls__21 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }




func A_arbace_core_print__init_part0_A_Unit18__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_28; var tmp3 *lang.Compiler_AOTFn; var fnbody__24 any = aot_arbace_core.A_arbace_core_eval1769000055_fn__1769000056_A_New(); var tmp4 *jrt.Class; var fncls__23 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000055_fn__1769000056_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, nil); aot_arbace_core.A_arbace_core_eval1769000055_fn__1769000056_A_fn_class = fncls__23d; tmp4 = fncls__23d } else { tmp4 = fncls__23 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_core_print__init_part0_A_Unit19__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_27; var tmp3 *lang.Compiler_AOTFn; var fnbody__26 any = aot_arbace_core.A_arbace_core_eval1769000059_fn__1769000060_A_New(); var tmp4 *jrt.Class; var fncls__25 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000059_fn__1769000060_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, nil); aot_arbace_core.A_arbace_core_eval1769000059_fn__1769000060_A_fn_class = fncls__25d; tmp4 = fncls__25d } else { tmp4 = fncls__25 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }

func A_arbace_core_print__init_part0_A_Unit20__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(134, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_29; var tmp3 *lang.Compiler_AOTFn; var fnbody__28 any = aot_arbace_core.A_arbace_core_eval1769000063_fn__1769000064_A_New(); var tmp4 *jrt.Class; var fncls__27 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000063_fn__1769000064_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, nil); aot_arbace_core.A_arbace_core_eval1769000063_fn__1769000064_A_fn_class = fncls__27d; tmp4 = fncls__27d } else { tmp4 = fncls__27 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_core_print__init_part0_A_Unit21__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(137, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_30; var tmp3 *lang.Compiler_AOTFn; var fnbody__30 any = aot_arbace_core.A_arbace_core_eval1769000067_fn__1769000068_A_New(); var tmp4 *jrt.Class; var fncls__29 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000067_fn__1769000068_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, nil); aot_arbace_core.A_arbace_core_eval1769000067_fn__1769000068_A_fn_class = fncls__29d; tmp4 = fncls__29d } else { tmp4 = fncls__29 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }






func A_arbace_core_print__init_part0_A_Unit22__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(144, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_31; var tmp3 *lang.Compiler_AOTFn; var fnbody__32 any = aot_arbace_core.A_arbace_core_eval1769000071_fn__1769000072_A_New(); var tmp4 *jrt.Class; var fncls__31 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000071_fn__1769000072_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, nil); aot_arbace_core.A_arbace_core_eval1769000071_fn__1769000072_A_fn_class = fncls__31d; tmp4 = fncls__31d } else { tmp4 = fncls__31 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }






func A_arbace_core_print__init_part0_A_Unit23__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(151, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_29; var tmp3 *lang.Compiler_AOTFn; var fnbody__34 any = aot_arbace_core.A_arbace_core_eval1769000075_fn__1769000076_A_New(); var tmp4 *jrt.Class; var fncls__33 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000075_fn__1769000076_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, nil); aot_arbace_core.A_arbace_core_eval1769000075_fn__1769000076_A_fn_class = fncls__33d; tmp4 = fncls__33d } else { tmp4 = fncls__33 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }





func A_arbace_core_print__init_part0_A_Unit24__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(157, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_32; var tmp3 *lang.Compiler_AOTFn; var fnbody__36 any = aot_arbace_core.A_arbace_core_eval1769000081_fn__1769000082_A_New(); var tmp4 *jrt.Class; var fncls__35 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000081_fn__1769000082_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); aot_arbace_core.A_arbace_core_eval1769000081_fn__1769000082_A_fn_class = fncls__35d; tmp4 = fncls__35d } else { tmp4 = fncls__35 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_core_print__init_part0_A_Unit25__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(160, 1); var root_37 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_41 any = A_arbace_core_print__init_part0_A_const_34; var arg_42 any = A_arbace_core_print__init_part0_A_const_32; if linked_38 == nil { return ifn_39.Invoke_O_O_O__O(arg_40, arg_41, arg_42) } else { return linked_38.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_37, arg_40, arg_41, arg_42) } }
func A_arbace_core_print__init_part0_A_Unit26__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var root_43 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_47 any = A_arbace_core_print__init_part0_A_const_35; var arg_48 any = A_arbace_core_print__init_part0_A_const_32; if linked_44 == nil { return ifn_45.Invoke_O_O_O__O(arg_46, arg_47, arg_48) } else { return linked_44.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_43, arg_46, arg_47, arg_48) } }
func A_arbace_core_print__init_part0_A_Unit27__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(162, 1); var root_49 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_53 any = A_arbace_core_print__init_part0_A_const_36; var arg_54 any = A_arbace_core_print__init_part0_A_const_32; if linked_50 == nil { return ifn_51.Invoke_O_O_O__O(arg_52, arg_53, arg_54) } else { return linked_50.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_49, arg_52, arg_53, arg_54) } }

func A_arbace_core_print__init_part0_A_Unit28__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_37; var tmp3 *lang.Compiler_AOTFn; var fnbody__56 any = aot_arbace_core.A_arbace_core_eval1769000093_fn__1769000094_A_New(); var tmp4 *jrt.Class; var fncls__55 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000093_fn__1769000094_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); aot_arbace_core.A_arbace_core_eval1769000093_fn__1769000094_A_fn_class = fncls__55d; tmp4 = fncls__55d } else { tmp4 = fncls__55 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_core_print__init_part0_A_Unit29__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(167, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_37; var tmp3 *lang.Compiler_AOTFn; var fnbody__58 any = aot_arbace_core.A_arbace_core_eval1769000097_fn__1769000098_A_New(); var tmp4 *jrt.Class; var fncls__57 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000097_fn__1769000098_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, nil); aot_arbace_core.A_arbace_core_eval1769000097_fn__1769000098_A_fn_class = fncls__57d; tmp4 = fncls__57d } else { tmp4 = fncls__57 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }

func A_arbace_core_print__init_part0_A_Unit30__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(169, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_38; var tmp3 *lang.Compiler_AOTFn; var fnbody__60 any = aot_arbace_core.A_arbace_core_eval1769000101_fn__1769000102_A_New(); var tmp4 *jrt.Class; var fncls__59 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000101_fn__1769000102_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, nil); aot_arbace_core.A_arbace_core_eval1769000101_fn__1769000102_A_fn_class = fncls__59d; tmp4 = fncls__59d } else { tmp4 = fncls__59 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_core_print__init_part0_A_Unit31__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(172, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_38; var tmp3 *lang.Compiler_AOTFn; var fnbody__62 any = aot_arbace_core.A_arbace_core_eval1769000105_fn__1769000106_A_New(); var tmp4 *jrt.Class; var fncls__61 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000105_fn__1769000106_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, nil); aot_arbace_core.A_arbace_core_eval1769000105_fn__1769000106_A_fn_class = fncls__61d; tmp4 = fncls__61d } else { tmp4 = fncls__61 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }

func A_arbace_core_print__init_part0_A_Unit32__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(174, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_39; var tmp3 *lang.Compiler_AOTFn; var fnbody__64 any = aot_arbace_core.A_arbace_core_eval1769000109_fn__1769000110_A_New(); var tmp4 *jrt.Class; var fncls__63 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000109_fn__1769000110_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, nil); aot_arbace_core.A_arbace_core_eval1769000109_fn__1769000110_A_fn_class = fncls__63d; tmp4 = fncls__63d } else { tmp4 = fncls__63 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_core_print__init_part0_A_Unit33__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(177, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_39; var tmp3 *lang.Compiler_AOTFn; var fnbody__66 any = aot_arbace_core.A_arbace_core_eval1769000113_fn__1769000114_A_New(); var tmp4 *jrt.Class; var fncls__65 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000113_fn__1769000114_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, nil); aot_arbace_core.A_arbace_core_eval1769000113_fn__1769000114_A_fn_class = fncls__65d; tmp4 = fncls__65d } else { tmp4 = fncls__65 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_core_print__init_part0_A_Unit34__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(180, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_40; var tmp3 *lang.Compiler_AOTFn; var fnbody__68 any = aot_arbace_core.A_arbace_core_eval1769000117_fn__1769000118_A_New(); var tmp4 *jrt.Class; var fncls__67 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000117_fn__1769000118_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, nil); aot_arbace_core.A_arbace_core_eval1769000117_fn__1769000118_A_fn_class = fncls__67d; tmp4 = fncls__67d } else { tmp4 = fncls__67 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_core_print__init_part0_A_Unit35__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(184, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_40; var tmp3 *lang.Compiler_AOTFn; var fnbody__70 any = aot_arbace_core.A_arbace_core_eval1769000121_fn__1769000122_A_New(); var tmp4 *jrt.Class; var fncls__69 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000121_fn__1769000122_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); aot_arbace_core.A_arbace_core_eval1769000121_fn__1769000122_A_fn_class = fncls__69d; tmp4 = fncls__69d } else { tmp4 = fncls__69 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }
func A_arbace_core_print__init_part0_A_Unit36__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(185, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_41; var tmp3 *lang.Compiler_AOTFn; var fnbody__72 any = aot_arbace_core.A_arbace_core_eval1769000125_fn__1769000126_A_New(); var tmp4 *jrt.Class; var fncls__71 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000125_fn__1769000126_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, nil); aot_arbace_core.A_arbace_core_eval1769000125_fn__1769000126_A_fn_class = fncls__71d; tmp4 = fncls__71d } else { tmp4 = fncls__71 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }
func A_arbace_core_print__init_part0_A_Unit37__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(186, 1); var root_73 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(); var arg_77 any = A_arbace_core_print__init_part0_A_const_40; var arg_78 any = A_arbace_core_print__init_part0_A_const_34; if linked_74 == nil { return ifn_75.Invoke_O_O_O__O(arg_76, arg_77, arg_78) } else { return linked_74.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_73, arg_76, arg_77, arg_78) } }
func A_arbace_core_print__init_part0_A_Unit38__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(187, 1); var root_79 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_83 any = A_arbace_core_print__init_part0_A_const_40; var arg_84 any = A_arbace_core_print__init_part0_A_const_34; if linked_80 == nil { return ifn_81.Invoke_O_O_O__O(arg_82, arg_83, arg_84) } else { return linked_80.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_79, arg_82, arg_83, arg_84) } }
func A_arbace_core_print__init_part0_A_Unit39__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(188, 1); var root_85 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(); var arg_89 any = A_arbace_core_print__init_part0_A_const_40; var arg_90 any = A_arbace_core_print__init_part0_A_const_36; if linked_86 == nil { return ifn_87.Invoke_O_O_O__O(arg_88, arg_89, arg_90) } else { return linked_86.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_85, arg_88, arg_89, arg_90) } }
func A_arbace_core_print__init_part0_A_Unit40__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(189, 1); var root_91 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_95 any = A_arbace_core_print__init_part0_A_const_40; var arg_96 any = A_arbace_core_print__init_part0_A_const_36; if linked_92 == nil { return ifn_93.Invoke_O_O_O__O(arg_94, arg_95, arg_96) } else { return linked_92.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_91, arg_94, arg_95, arg_96) } }

func A_arbace_core_print__init_part0_A_Unit41__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(191, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_36; var tmp3 *lang.Compiler_AOTFn; var fnbody__98 any = aot_arbace_core.A_arbace_core_eval1769000139_fn__1769000140_A_New(); var tmp4 *jrt.Class; var fncls__97 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000139_fn__1769000140_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); aot_arbace_core.A_arbace_core_eval1769000139_fn__1769000140_A_fn_class = fncls__97d; tmp4 = fncls__97d } else { tmp4 = fncls__97 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_core_print__init_part0_A_Unit42__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(194, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_34; var tmp3 *lang.Compiler_AOTFn; var fnbody__100 any = aot_arbace_core.A_arbace_core_eval1769000145_fn__1769000146_A_New(); var tmp4 *jrt.Class; var fncls__99 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000145_fn__1769000146_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); aot_arbace_core.A_arbace_core_eval1769000145_fn__1769000146_A_fn_class = fncls__99d; tmp4 = fncls__99d } else { tmp4 = fncls__99 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }







func A_arbace_core_print__init_part0_A_Unit43__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); var root_101 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_105 any = A_arbace_core_print__init_part0_A_const_34; var arg_106 any = A_arbace_core_print__init_part0_A_const_36; if linked_102 == nil { return ifn_103.Invoke_O_O_O__O(arg_104, arg_105, arg_106) } else { return linked_102.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_101, arg_104, arg_105, arg_106) } }

func A_arbace_core_print__init_part0_A_Unit44__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(204, 1); A_arbace_core_print__init_part0_A_const_42.BindRoot_O__V(A_arbace_core_print__init_part0_A_const_43); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_42; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_44)); return A_arbace_core_print__init_part0_A_const_42 }











func A_arbace_core_print__init_part0_A_Unit45__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(216, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_45; var tmp3 *lang.Compiler_AOTFn; var fnbody__108 any = aot_arbace_core.A_arbace_core_eval1769000151_fn__1769000152_A_New(); var tmp4 *jrt.Class; var fncls__107 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000151_fn__1769000152_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, nil); aot_arbace_core.A_arbace_core_eval1769000151_fn__1769000152_A_fn_class = fncls__107d; tmp4 = fncls__107d } else { tmp4 = fncls__107 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }










func A_arbace_core_print__init_part0_A_Unit46__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(227, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_45; var tmp3 *lang.Compiler_AOTFn; var fnbody__110 any = aot_arbace_core.A_arbace_core_eval1769000155_fn__1769000156_A_New(); var tmp4 *jrt.Class; var fncls__109 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000155_fn__1769000156_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); aot_arbace_core.A_arbace_core_eval1769000155_fn__1769000156_A_fn_class = fncls__109d; tmp4 = fncls__109d } else { tmp4 = fncls__109 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }

func A_arbace_core_print__init_part0_A_Unit47__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_46; var tmp3 *lang.Compiler_AOTFn; var fnbody__112 any = aot_arbace_core.A_arbace_core_eval1769000159_fn__1769000160_A_New(); var tmp4 *jrt.Class; var fncls__111 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000159_fn__1769000160_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); aot_arbace_core.A_arbace_core_eval1769000159_fn__1769000160_A_fn_class = fncls__111d; tmp4 = fncls__111d } else { tmp4 = fncls__111 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_core_print__init_part0_A_Unit48__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(233, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = aot_arbace_core.A_arbace_core_print_prefix_map_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = aot_arbace_core.A_arbace_core_print_prefix_map_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, nil); aot_arbace_core.A_arbace_core_print_prefix_map_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_48)); return A_arbace_core_print__init_part0_A_const_47 }








func A_arbace_core_print__init_part0_A_Unit49__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(242, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = aot_arbace_core.A_arbace_core_print_map_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = aot_arbace_core.A_arbace_core_print_map_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); aot_arbace_core.A_arbace_core_print_map_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_50)); return A_arbace_core_print__init_part0_A_const_49 }


func A_arbace_core_print__init_part0_A_Unit50__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(245, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = aot_arbace_core.A_arbace_core_strip_ns_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = aot_arbace_core.A_arbace_core_strip_ns_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, nil); aot_arbace_core.A_arbace_core_strip_ns_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_52)); return A_arbace_core_print__init_part0_A_const_51 }





func A_arbace_core_print__init_part0_A_Unit51__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(251, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = aot_arbace_core.A_arbace_core_lift_ns_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = aot_arbace_core.A_arbace_core_lift_ns_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, nil); aot_arbace_core.A_arbace_core_lift_ns_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_54)); return A_arbace_core_print__init_part0_A_const_53 }















func A_arbace_core_print__init_part0_A_Unit52__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(267, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_55; var tmp3 *lang.Compiler_AOTFn; var fnbody__122 any = aot_arbace_core.A_arbace_core_eval1769000192_fn__1769000193_A_New(); var tmp4 *jrt.Class; var fncls__121 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000192_fn__1769000193_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, nil); aot_arbace_core.A_arbace_core_eval1769000192_fn__1769000193_A_fn_class = fncls__121d; tmp4 = fncls__121d } else { tmp4 = fncls__121 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }






func A_arbace_core_print__init_part0_A_Unit53__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(274, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_35; var tmp3 *lang.Compiler_AOTFn; var fnbody__124 any = aot_arbace_core.A_arbace_core_eval1769000201_fn__1769000202_A_New(); var tmp4 *jrt.Class; var fncls__123 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000201_fn__1769000202_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); aot_arbace_core.A_arbace_core_eval1769000201_fn__1769000202_A_fn_class = fncls__123d; tmp4 = fncls__123d } else { tmp4 = fncls__123 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_core_print__init_part0_A_Unit54__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(277, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_55; var tmp3 *lang.Compiler_AOTFn; var fnbody__126 any = aot_arbace_core.A_arbace_core_eval1769000207_fn__1769000208_A_New(); var tmp4 *jrt.Class; var fncls__125 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000207_fn__1769000208_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); aot_arbace_core.A_arbace_core_eval1769000207_fn__1769000208_A_fn_class = fncls__125d; tmp4 = fncls__125d } else { tmp4 = fncls__125 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }








func A_arbace_core_print__init_part0_A_Unit55__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(286, 1); var root_127 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(); var arg_131 any = A_arbace_core_print__init_part0_A_const_34; var arg_132 any = A_arbace_core_print__init_part0_A_const_36; if linked_128 == nil { return ifn_129.Invoke_O_O_O__O(arg_130, arg_131, arg_132) } else { return linked_128.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_127, arg_130, arg_131, arg_132) } }
func A_arbace_core_print__init_part0_A_Unit56__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(287, 1); var root_133 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(); var arg_137 any = A_arbace_core_print__init_part0_A_const_34; var arg_138 any = A_arbace_core_print__init_part0_A_const_56; if linked_134 == nil { return ifn_135.Invoke_O_O_O__O(arg_136, arg_137, arg_138) } else { return linked_134.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_133, arg_136, arg_137, arg_138) } }
func A_arbace_core_print__init_part0_A_Unit57__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); var root_139 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(); var arg_143 any = A_arbace_core_print__init_part0_A_const_56; var arg_144 any = A_arbace_core_print__init_part0_A_const_57; if linked_140 == nil { return ifn_141.Invoke_O_O_O__O(arg_142, arg_143, arg_144) } else { return linked_140.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_139, arg_142, arg_143, arg_144) } }
func A_arbace_core_print__init_part0_A_Unit58__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(289, 1); var root_145 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(); var arg_149 any = A_arbace_core_print__init_part0_A_const_34; var arg_150 any = A_arbace_core_print__init_part0_A_const_35; if linked_146 == nil { return ifn_147.Invoke_O_O_O__O(arg_148, arg_149, arg_150) } else { return linked_146.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_145, arg_148, arg_149, arg_150) } }

func A_arbace_core_print__init_part0_A_Unit59__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(291, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_57; var tmp3 *lang.Compiler_AOTFn; var fnbody__152 any = aot_arbace_core.A_arbace_core_eval1769000219_fn__1769000220_A_New(); var tmp4 *jrt.Class; var fncls__151 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000219_fn__1769000220_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, nil); aot_arbace_core.A_arbace_core_eval1769000219_fn__1769000220_A_fn_class = fncls__151d; tmp4 = fncls__151d } else { tmp4 = fncls__151 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__152, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }






func A_arbace_core_print__init_part0_A_Unit60__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_56; var tmp3 *lang.Compiler_AOTFn; var fnbody__154 any = aot_arbace_core.A_arbace_core_eval1769000223_fn__1769000224_A_New(); var tmp4 *jrt.Class; var fncls__153 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000223_fn__1769000224_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, nil); aot_arbace_core.A_arbace_core_eval1769000223_fn__1769000224_A_fn_class = fncls__153d; tmp4 = fncls__153d } else { tmp4 = fncls__153 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__154, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }






func A_arbace_core_print__init_part0_A_Unit61__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(305, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_35; var tmp3 *lang.Compiler_AOTFn; var fnbody__156 any = aot_arbace_core.A_arbace_core_eval1769000227_fn__1769000228_A_New(); var tmp4 *jrt.Class; var fncls__155 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000227_fn__1769000228_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, nil); aot_arbace_core.A_arbace_core_eval1769000227_fn__1769000228_A_fn_class = fncls__155d; tmp4 = fncls__155d } else { tmp4 = fncls__155 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__156, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }






func A_arbace_core_print__init_part0_A_Unit62__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(312, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_58; var tmp3 *lang.Compiler_AOTFn; var fnbody__158 any = aot_arbace_core.A_arbace_core_eval1769000231_fn__1769000232_A_New(); var tmp4 *jrt.Class; var fncls__157 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000231_fn__1769000232_A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); aot_arbace_core.A_arbace_core_eval1769000231_fn__1769000232_A_fn_class = fncls__157d; tmp4 = fncls__157d } else { tmp4 = fncls__157 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__158, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }








func A_arbace_core_print__init_part0_A_Unit63__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(321, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_59; var tmp3 *lang.Compiler_AOTFn; var fnbody__160 any = aot_arbace_core.A_arbace_core_eval1769000235_fn__1769000236_A_New(); var tmp4 *jrt.Class; var fncls__159 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000235_fn__1769000236_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, nil); aot_arbace_core.A_arbace_core_eval1769000235_fn__1769000236_A_fn_class = fncls__159d; tmp4 = fncls__159d } else { tmp4 = fncls__159 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__160, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }





func A_arbace_core_print__init_part0_A_Unit64__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(327, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_59; var tmp3 *lang.Compiler_AOTFn; var fnbody__162 any = aot_arbace_core.A_arbace_core_eval1769000239_fn__1769000240_A_New(); var tmp4 *jrt.Class; var fncls__161 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000239_fn__1769000240_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, nil); aot_arbace_core.A_arbace_core_eval1769000239_fn__1769000240_A_fn_class = fncls__161d; tmp4 = fncls__161d } else { tmp4 = fncls__161 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__162, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }







func A_arbace_core_print__init_part0_A_Unit65__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(335, 1); var root_163 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(); var arg_167 any = A_arbace_core_print__init_part0_A_const_59; var arg_168 any = A_arbace_core_print__init_part0_A_const_35; if linked_164 == nil { return ifn_165.Invoke_O_O_O__O(arg_166, arg_167, arg_168) } else { return linked_164.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_163, arg_166, arg_167, arg_168) } }
func A_arbace_core_print__init_part0_A_Unit66__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(336, 1); var root_169 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(); var arg_173 any = A_arbace_core_print__init_part0_A_const_59; var arg_174 any = A_arbace_core_print__init_part0_A_const_55; if linked_170 == nil { return ifn_171.Invoke_O_O_O__O(arg_172, arg_173, arg_174) } else { return linked_170.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_169, arg_172, arg_173, arg_174) } }
func A_arbace_core_print__init_part0_A_Unit67__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(337, 1); var root_175 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_179 any = A_arbace_core_print__init_part0_A_const_59; var arg_180 any = A_arbace_core_print__init_part0_A_const_55; if linked_176 == nil { return ifn_177.Invoke_O_O_O__O(arg_178, arg_179, arg_180) } else { return linked_176.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_175, arg_178, arg_179, arg_180) } }
func A_arbace_core_print__init_part0_A_Unit68__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(338, 1); var root_181 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_185 any = A_arbace_core_print__init_part0_A_const_34; var arg_186 any = A_arbace_core_print__init_part0_A_const_35; if linked_182 == nil { return ifn_183.Invoke_O_O_O__O(arg_184, arg_185, arg_186) } else { return linked_182.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_181, arg_184, arg_185, arg_186) } }
func A_arbace_core_print__init_part0_A_Unit69__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(339, 1); var root_187 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_191 any = A_arbace_core_print__init_part0_A_const_59; var arg_192 any = A_arbace_core_print__init_part0_A_const_34; if linked_188 == nil { return ifn_189.Invoke_O_O_O__O(arg_190, arg_191, arg_192) } else { return linked_188.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_187, arg_190, arg_191, arg_192) } }
func A_arbace_core_print__init_part0_A_Unit70__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(340, 1); var root_193 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_197 any = A_arbace_core_print__init_part0_A_const_59; var arg_198 any = A_arbace_core_print__init_part0_A_const_35; if linked_194 == nil { return ifn_195.Invoke_O_O_O__O(arg_196, arg_197, arg_198) } else { return linked_194.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_193, arg_196, arg_197, arg_198) } }

func A_arbace_core_print__init_part0_A_Unit71__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(342, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_60; var tmp3 *lang.Compiler_AOTFn; var fnbody__200 any = aot_arbace_core.A_arbace_core_eval1769000255_fn__1769000256_A_New(); var tmp4 *jrt.Class; var fncls__199 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000255_fn__1769000256_A_fn_class; if fncls__199 == nil { var fncls__199d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, nil); aot_arbace_core.A_arbace_core_eval1769000255_fn__1769000256_A_fn_class = fncls__199d; tmp4 = fncls__199d } else { tmp4 = fncls__199 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__200, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_core_print__init_part0_A_Unit72__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(346, 1); A_arbace_core_print__init_part0_A_const_61.BindRoot_O__V(A_arbace_core_print__init_part0_A_const_62); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_61; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_63)); return A_arbace_core_print__init_part0_A_const_61 }










func A_arbace_core_print__init_part0_A_Unit73__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(357, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_64; var tmp3 *lang.Compiler_AOTFn; var fnbody__202 any = aot_arbace_core.A_arbace_core_eval1769000259_fn__1769000260_A_New(); var tmp4 *jrt.Class; var fncls__201 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000259_fn__1769000260_A_fn_class; if fncls__201 == nil { var fncls__201d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, nil); aot_arbace_core.A_arbace_core_eval1769000259_fn__1769000260_A_fn_class = fncls__201d; tmp4 = fncls__201d } else { tmp4 = fncls__201 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__202, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }







func A_arbace_core_print__init_part0_A_Unit74__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(365, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_64; var tmp3 *lang.Compiler_AOTFn; var fnbody__204 any = aot_arbace_core.A_arbace_core_eval1769000263_fn__1769000264_A_New(); var tmp4 *jrt.Class; var fncls__203 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000263_fn__1769000264_A_fn_class; if fncls__203 == nil { var fncls__203d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, nil); aot_arbace_core.A_arbace_core_eval1769000263_fn__1769000264_A_fn_class = fncls__203d; tmp4 = fncls__203d } else { tmp4 = fncls__203 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__204, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }
func A_arbace_core_print__init_part0_A_Unit75__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(366, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_65; var tmp3 *lang.Compiler_AOTFn; var fnbody__206 any = aot_arbace_core.A_arbace_core_eval1769000267_fn__1769000268_A_New(); var tmp4 *jrt.Class; var fncls__205 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000267_fn__1769000268_A_fn_class; if fncls__205 == nil { var fncls__205d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, nil); aot_arbace_core.A_arbace_core_eval1769000267_fn__1769000268_A_fn_class = fncls__205d; tmp4 = fncls__205d } else { tmp4 = fncls__205 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__206, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }
func A_arbace_core_print__init_part0_A_Unit76__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(367, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_30; var tmp3 *lang.Compiler_AOTFn; var fnbody__208 any = aot_arbace_core.A_arbace_core_eval1769000271_fn__1769000272_A_New(); var tmp4 *jrt.Class; var fncls__207 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000271_fn__1769000272_A_fn_class; if fncls__207 == nil { var fncls__207d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, nil); aot_arbace_core.A_arbace_core_eval1769000271_fn__1769000272_A_fn_class = fncls__207d; tmp4 = fncls__207d } else { tmp4 = fncls__207 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__208, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }
func A_arbace_core_print__init_part0_A_Unit77__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(368, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_66; var tmp3 *lang.Compiler_AOTFn; var fnbody__210 any = aot_arbace_core.A_arbace_core_eval1769000275_fn__1769000276_A_New(); var tmp4 *jrt.Class; var fncls__209 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000275_fn__1769000276_A_fn_class; if fncls__209 == nil { var fncls__209d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, nil); aot_arbace_core.A_arbace_core_eval1769000275_fn__1769000276_A_fn_class = fncls__209d; tmp4 = fncls__209d } else { tmp4 = fncls__209 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__210, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }
func A_arbace_core_print__init_part0_A_Unit78__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(369, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_67; var tmp3 *lang.Compiler_AOTFn; var fnbody__212 any = aot_arbace_core.A_arbace_core_eval1769000279_fn__1769000280_A_New(); var tmp4 *jrt.Class; var fncls__211 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000279_fn__1769000280_A_fn_class; if fncls__211 == nil { var fncls__211d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, nil); aot_arbace_core.A_arbace_core_eval1769000279_fn__1769000280_A_fn_class = fncls__211d; tmp4 = fncls__211d } else { tmp4 = fncls__211 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__212, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }
func A_arbace_core_print__init_part0_A_Unit79__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(370, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_68; var tmp3 *lang.Compiler_AOTFn; var fnbody__214 any = aot_arbace_core.A_arbace_core_eval1769000283_fn__1769000284_A_New(); var tmp4 *jrt.Class; var fncls__213 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000283_fn__1769000284_A_fn_class; if fncls__213 == nil { var fncls__213d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); aot_arbace_core.A_arbace_core_eval1769000283_fn__1769000284_A_fn_class = fncls__213d; tmp4 = fncls__213d } else { tmp4 = fncls__213 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__214, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }
func A_arbace_core_print__init_part0_A_Unit80__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(371, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_69; var tmp3 *lang.Compiler_AOTFn; var fnbody__216 any = aot_arbace_core.A_arbace_core_eval1769000287_fn__1769000288_A_New(); var tmp4 *jrt.Class; var fncls__215 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000287_fn__1769000288_A_fn_class; if fncls__215 == nil { var fncls__215d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, nil); aot_arbace_core.A_arbace_core_eval1769000287_fn__1769000288_A_fn_class = fncls__215d; tmp4 = fncls__215d } else { tmp4 = fncls__215 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__216, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }
func A_arbace_core_print__init_part0_A_Unit81__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(372, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_70; var tmp3 *lang.Compiler_AOTFn; var fnbody__218 any = aot_arbace_core.A_arbace_core_eval1769000291_fn__1769000292_A_New(); var tmp4 *jrt.Class; var fncls__217 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000291_fn__1769000292_A_fn_class; if fncls__217 == nil { var fncls__217d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, nil); aot_arbace_core.A_arbace_core_eval1769000291_fn__1769000292_A_fn_class = fncls__217d; tmp4 = fncls__217d } else { tmp4 = fncls__217 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__218, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }
func A_arbace_core_print__init_part0_A_Unit82__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(373, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_71; var tmp3 *lang.Compiler_AOTFn; var fnbody__220 any = aot_arbace_core.A_arbace_core_eval1769000295_fn__1769000296_A_New(); var tmp4 *jrt.Class; var fncls__219 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000295_fn__1769000296_A_fn_class; if fncls__219 == nil { var fncls__219d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, nil); aot_arbace_core.A_arbace_core_eval1769000295_fn__1769000296_A_fn_class = fncls__219d; tmp4 = fncls__219d } else { tmp4 = fncls__219 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__220, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }
func A_arbace_core_print__init_part0_A_Unit83__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(374, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_72; var tmp3 *lang.Compiler_AOTFn; var fnbody__222 any = aot_arbace_core.A_arbace_core_eval1769000299_fn__1769000300_A_New(); var tmp4 *jrt.Class; var fncls__221 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000299_fn__1769000300_A_fn_class; if fncls__221 == nil { var fncls__221d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, nil); aot_arbace_core.A_arbace_core_eval1769000299_fn__1769000300_A_fn_class = fncls__221d; tmp4 = fncls__221d } else { tmp4 = fncls__221 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__222, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }

func A_arbace_core_print__init_part0_A_Unit84__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(376, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_73; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, jrt.Float_TYPE.Ref(), Lit_59, jrt.Integer_TYPE.Ref(), Lit_60, jrt.Long_TYPE.Ref(), Lit_61, jrt.Boolean_TYPE.Ref(), Lit_62, jrt.Character_TYPE.Ref(), Lit_63, jrt.Double_TYPE.Ref(), Lit_64, jrt.Byte_TYPE.Ref(), Lit_65, jrt.Short_TYPE.Ref(), Lit_66))); var tmp2 *lang.Var = A_arbace_core_print__init_part0_A_const_73; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_74)); return A_arbace_core_print__init_part0_A_const_73 }









func A_arbace_core_print__init_part0_A_Unit85__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(386, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_75; var tmp3 *lang.Compiler_AOTFn; var fnbody__224 any = aot_arbace_core.A_arbace_core_eval1769000303_fn__1769000304_A_New(); var tmp4 *jrt.Class; var fncls__223 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000303_fn__1769000304_A_fn_class; if fncls__223 == nil { var fncls__223d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, nil); aot_arbace_core.A_arbace_core_eval1769000303_fn__1769000304_A_fn_class = fncls__223d; tmp4 = fncls__223d } else { tmp4 = fncls__223 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__224, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }




func A_arbace_core_print__init_part0_A_Unit86__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(391, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_75; var tmp3 *lang.Compiler_AOTFn; var fnbody__226 any = aot_arbace_core.A_arbace_core_eval1769000307_fn__1769000308_A_New(); var tmp4 *jrt.Class; var fncls__225 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000307_fn__1769000308_A_fn_class; if fncls__225 == nil { var fncls__225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, nil); aot_arbace_core.A_arbace_core_eval1769000307_fn__1769000308_A_fn_class = fncls__225d; tmp4 = fncls__225d } else { tmp4 = fncls__225 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__226, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }













func A_arbace_core_print__init_part0_A_Unit87__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(405, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_67; var tmp3 *lang.Compiler_AOTFn; var fnbody__228 any = aot_arbace_core.A_arbace_core_eval1769000311_fn__1769000312_A_New(); var tmp4 *jrt.Class; var fncls__227 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000311_fn__1769000312_A_fn_class; if fncls__227 == nil { var fncls__227d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, nil); aot_arbace_core.A_arbace_core_eval1769000311_fn__1769000312_A_fn_class = fncls__227d; tmp4 = fncls__227d } else { tmp4 = fncls__227 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__228, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_core_print__init_part0_A_Unit88__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(409, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_68; var tmp3 *lang.Compiler_AOTFn; var fnbody__230 any = aot_arbace_core.A_arbace_core_eval1769000315_fn__1769000316_A_New(); var tmp4 *jrt.Class; var fncls__229 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000315_fn__1769000316_A_fn_class; if fncls__229 == nil { var fncls__229d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, nil); aot_arbace_core.A_arbace_core_eval1769000315_fn__1769000316_A_fn_class = fncls__229d; tmp4 = fncls__229d } else { tmp4 = fncls__229 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__230, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_core_print__init_part0_A_Unit89__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(413, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_76; var tmp3 *lang.Compiler_AOTFn; var fnbody__232 any = aot_arbace_core.A_arbace_core_eval1769000319_fn__1769000320_A_New(); var tmp4 *jrt.Class; var fncls__231 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000319_fn__1769000320_A_fn_class; if fncls__231 == nil { var fncls__231d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, nil); aot_arbace_core.A_arbace_core_eval1769000319_fn__1769000320_A_fn_class = fncls__231d; tmp4 = fncls__231d } else { tmp4 = fncls__231 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__232, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }





















func A_arbace_core_print__init_part0_A_Unit90__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(435, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_76; var tmp3 *lang.Compiler_AOTFn; var fnbody__234 any = aot_arbace_core.A_arbace_core_eval1769000336_fn__1769000337_A_New(); var tmp4 *jrt.Class; var fncls__233 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000336_fn__1769000337_A_fn_class; if fncls__233 == nil { var fncls__233d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, nil); aot_arbace_core.A_arbace_core_eval1769000336_fn__1769000337_A_fn_class = fncls__233d; tmp4 = fncls__233d } else { tmp4 = fncls__233 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__234, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }

func A_arbace_core_print__init_part0_A_Unit91__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(437, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_77; var tmp3 *lang.Compiler_AOTFn; var fnbody__236 any = aot_arbace_core.A_arbace_core_eval1769000340_fn__1769000341_A_New(); var tmp4 *jrt.Class; var fncls__235 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000340_fn__1769000341_A_fn_class; if fncls__235 == nil { var fncls__235d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, nil); aot_arbace_core.A_arbace_core_eval1769000340_fn__1769000341_A_fn_class = fncls__235d; tmp4 = fncls__235d } else { tmp4 = fncls__235 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__236, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }




func A_arbace_core_print__init_part0_A_Unit92__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(442, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__238 any = aot_arbace_core.A_arbace_core_deref_as_map_A_New(); var tmp3 *jrt.Class; var fncls__237 *jrt.Class = aot_arbace_core.A_arbace_core_deref_as_map_A_fn_class; if fncls__237 == nil { var fncls__237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, nil); aot_arbace_core.A_arbace_core_deref_as_map_A_fn_class = fncls__237d; tmp3 = fncls__237d } else { tmp3 = fncls__237 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__238, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_79)); return A_arbace_core_print__init_part0_A_const_78 }






















func A_arbace_core_print__init_part0_A_Unit93__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(465, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_80; var tmp3 *lang.Compiler_AOTFn; var fnbody__240 any = aot_arbace_core.A_arbace_core_eval1769000350_fn__1769000351_A_New(); var tmp4 *jrt.Class; var fncls__239 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000350_fn__1769000351_A_fn_class; if fncls__239 == nil { var fncls__239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, nil); aot_arbace_core.A_arbace_core_eval1769000350_fn__1769000351_A_fn_class = fncls__239d; tmp4 = fncls__239d } else { tmp4 = fncls__239 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__240, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_core_print__init_part0_A_Unit94__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(468, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_81; var tmp3 *lang.Compiler_AOTFn; var fnbody__242 any = aot_arbace_core.A_arbace_core_eval1769000354_fn__1769000355_A_New(); var tmp4 *jrt.Class; var fncls__241 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000354_fn__1769000355_A_fn_class; if fncls__241 == nil { var fncls__241d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, nil); aot_arbace_core.A_arbace_core_eval1769000354_fn__1769000355_A_fn_class = fncls__241d; tmp4 = fncls__241d } else { tmp4 = fncls__241 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__242, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_core_print__init_part0_A_Unit95__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(471, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__244 any = aot_arbace_core.A_arbace_core_StackTraceElement__GT_vec_A_New(); var tmp3 *jrt.Class; var fncls__243 *jrt.Class = aot_arbace_core.A_arbace_core_StackTraceElement__GT_vec_A_fn_class; if fncls__243 == nil { var fncls__243d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, nil); aot_arbace_core.A_arbace_core_StackTraceElement__GT_vec_A_fn_class = fncls__243d; tmp3 = fncls__243d } else { tmp3 = fncls__243 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__244, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_83)); return A_arbace_core_print__init_part0_A_const_82 }





func A_arbace_core_print__init_part0_A_Unit96__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(477, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_84; var tmp2 *lang.Compiler_AOTFn; var fnbody__246 any = aot_arbace_core.A_arbace_core_Throwable__GT_map_A_New(); var tmp3 *jrt.Class; var fncls__245 *jrt.Class = aot_arbace_core.A_arbace_core_Throwable__GT_map_A_fn_class; if fncls__245 == nil { var fncls__245d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, nil); aot_arbace_core.A_arbace_core_Throwable__GT_map_A_fn_class = fncls__245d; tmp3 = fncls__245d } else { tmp3 = fncls__245 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__246, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_85)); return A_arbace_core_print__init_part0_A_const_84 }



































func A_arbace_core_print__init_part0_A_Unit97__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(513, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_86; var tmp2 *lang.Compiler_AOTFn; var fnbody__248 any = aot_arbace_core.A_arbace_core_print_throwable_A_New(); var tmp3 *jrt.Class; var fncls__247 *jrt.Class = aot_arbace_core.A_arbace_core_print_throwable_A_fn_class; if fncls__247 == nil { var fncls__247d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, nil); aot_arbace_core.A_arbace_core_print_throwable_A_fn_class = fncls__247d; tmp3 = fncls__247d } else { tmp3 = fncls__247 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__248, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_87)); return A_arbace_core_print__init_part0_A_const_86 }



































func A_arbace_core_print__init_part0_A_Unit98__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(549, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_88; var tmp3 *lang.Compiler_AOTFn; var fnbody__250 any = aot_arbace_core.A_arbace_core_eval1769000378_fn__1769000379_A_New(); var tmp4 *jrt.Class; var fncls__249 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000378_fn__1769000379_A_fn_class; if fncls__249 == nil { var fncls__249d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, nil); aot_arbace_core.A_arbace_core_eval1769000378_fn__1769000379_A_fn_class = fncls__249d; tmp4 = fncls__249d } else { tmp4 = fncls__249 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__250, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_core_print__init_part0_A_Unit99__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(552, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_89; var tmp3 *lang.Compiler_AOTFn; var fnbody__252 any = aot_arbace_core.A_arbace_core_eval1769000382_fn__1769000383_A_New(); var tmp4 *jrt.Class; var fncls__251 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000382_fn__1769000383_A_fn_class; if fncls__251 == nil { var fncls__251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, nil); aot_arbace_core.A_arbace_core_eval1769000382_fn__1769000383_A_fn_class = fncls__251d; tmp4 = fncls__251d } else { tmp4 = fncls__251 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__252, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }





func A_arbace_core_print__init_part1_A_Unit100__O() any { A_arbace_core_print__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(558, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part1_A_const_1; var tmp3 *lang.Compiler_AOTFn; var fnbody__2 any = aot_arbace_core.A_arbace_core_eval1769000386_fn__1769000387_A_New(); var tmp4 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000386_fn__1769000387_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, nil); aot_arbace_core.A_arbace_core_eval1769000386_fn__1769000387_A_fn_class = fncls__1d; tmp4 = fncls__1d } else { tmp4 = fncls__1 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }
//line :558:1
func A_arbace_core_print__init_part1_A_Init__O() any { A_arbace_core_print__init_part1_A_Init(); return nil }
//line :558:1
func A_arbace_core_print__init_part1_A_Load__O() any { A_arbace_core_print__init_part1_A_Init(); A_arbace_core_print__init_part1_A_Unit100__O(); A_arbace_core_print__init_part1_A_Unit101__O(); A_arbace_core_print__init_part1_A_Unit102__O(); A_arbace_core_print__init_part1_A_Unit103__O(); return nil }

func A_arbace_core_print__init_part1_A_Unit101__O() any { A_arbace_core_print__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(560, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part1_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part1_A_const_3; var tmp3 *lang.Compiler_AOTFn; var fnbody__4 any = aot_arbace_core.A_arbace_core_eval1769000390_fn__1769000391_A_New(); var tmp4 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000390_fn__1769000391_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, nil); aot_arbace_core.A_arbace_core_eval1769000390_fn__1769000391_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }




func A_arbace_core_print__init_part1_A_Unit102__O() any { A_arbace_core_print__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(565, 1); A_arbace_core_print__init_part1_A_const_4.BindRoot_O__V(jrt.Boolean_TRUE.Ref()); var tmp1 *lang.Var = A_arbace_core_print__init_part1_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part1_A_const_5)); return A_arbace_core_print__init_part1_A_const_4 }

func A_arbace_core_print__init_part1_A_Unit103__O() any { A_arbace_core_print__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(567, 1); var tmp1 any = A_arbace_core_print__init_part1_A_const_9; lang.IFn_Cast(A_arbace_core_print__init_part1_A_const_8.GetRawRoot__O()).ApplyTo_ISeq__O(lang.RT_Cons_O_O__ISeq_NoInit(tmp1, lang.RT_Seq_O__ISeq_NoInit(jrt.RefArrayOf(jrt.Object_class)))); var tmp2 *lang.Var = A_arbace_core_print__init_part1_A_const_6; var tmp3 *lang.Compiler_AOTFn; var fnbody__6 any = aot_arbace_core.A_arbace_core_PrintWriter_on_A_New(); var tmp4 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_core.A_arbace_core_PrintWriter_on_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, nil); aot_arbace_core.A_arbace_core_PrintWriter_on_A_fn_class = fncls__5d; tmp4 = fncls__5d } else { tmp4 = fncls__5 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp4, nil); tmp2.BindRoot_O__V(tmp3.Ref()); var tmp5 *lang.Var = A_arbace_core_print__init_part1_A_const_6; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part1_A_const_7)); return A_arbace_core_print__init_part1_A_const_6 }



type A_arbace_core_print__init_A struct{ jrt.Object }

func A_arbace_core_print__init_A_New() *A_arbace_core_print__init_A { t := &A_arbace_core_print__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_print__init_A) Ctor() {}

func (t *A_arbace_core_print__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_print__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_print__init_A_class }

func (t *A_arbace_core_print__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_print__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_print__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_print__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_print__init_A); return ok }

func A_arbace_core_print__init_A_Cast(x any) *A_arbace_core_print__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_print__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_print__init_A_class)) }; return v }



type A_arbace_core_print__init_part0_A struct{ jrt.Object }

var A_arbace_core_print__init_part0_A_const_pool *jrt.RefArray

var A_arbace_core_print__init_part0_A_const_0 *lang.Var

var A_arbace_core_print__init_part0_A_const_1 any

var A_arbace_core_print__init_part0_A_const_2 *lang.Var

var A_arbace_core_print__init_part0_A_const_3 *lang.Var

var A_arbace_core_print__init_part0_A_const_4 any

var A_arbace_core_print__init_part0_A_const_5 *lang.Var

var A_arbace_core_print__init_part0_A_const_6 any

var A_arbace_core_print__init_part0_A_const_7 *lang.Var

var A_arbace_core_print__init_part0_A_const_8 any

var A_arbace_core_print__init_part0_A_const_9 *lang.Var

var A_arbace_core_print__init_part0_A_const_10 any

var A_arbace_core_print__init_part0_A_const_11 *lang.Var

var A_arbace_core_print__init_part0_A_const_12 any

var A_arbace_core_print__init_part0_A_const_13 *lang.Var

var A_arbace_core_print__init_part0_A_const_14 any

var A_arbace_core_print__init_part0_A_const_15 *lang.Var

var A_arbace_core_print__init_part0_A_const_16 any

var A_arbace_core_print__init_part0_A_const_17 *lang.Var

var A_arbace_core_print__init_part0_A_const_18 *lang.Keyword

var A_arbace_core_print__init_part0_A_const_19 *lang.Var

var A_arbace_core_print__init_part0_A_const_20 *lang.Var

var A_arbace_core_print__init_part0_A_const_21 any

var A_arbace_core_print__init_part0_A_const_22 *lang.Var

var A_arbace_core_print__init_part0_A_const_23 any

var A_arbace_core_print__init_part0_A_const_24 *lang.Var

var A_arbace_core_print__init_part0_A_const_25 any

var A_arbace_core_print__init_part0_A_const_26 *jrt.Class

var A_arbace_core_print__init_part0_A_const_27 *jrt.Class

var A_arbace_core_print__init_part0_A_const_28 *jrt.Class

var A_arbace_core_print__init_part0_A_const_29 *jrt.Class

var A_arbace_core_print__init_part0_A_const_30 *jrt.Class

var A_arbace_core_print__init_part0_A_const_31 *jrt.Class

var A_arbace_core_print__init_part0_A_const_32 *jrt.Class

var A_arbace_core_print__init_part0_A_const_33 *lang.Var

var A_arbace_core_print__init_part0_A_const_34 *jrt.Class

var A_arbace_core_print__init_part0_A_const_35 *jrt.Class

var A_arbace_core_print__init_part0_A_const_36 *jrt.Class

var A_arbace_core_print__init_part0_A_const_37 *jrt.Class

var A_arbace_core_print__init_part0_A_const_38 *jrt.Class

var A_arbace_core_print__init_part0_A_const_39 *jrt.Class

var A_arbace_core_print__init_part0_A_const_40 *jrt.Class

var A_arbace_core_print__init_part0_A_const_41 *jrt.Class

var A_arbace_core_print__init_part0_A_const_42 *lang.Var

var A_arbace_core_print__init_part0_A_const_43 any

var A_arbace_core_print__init_part0_A_const_44 any

var A_arbace_core_print__init_part0_A_const_45 *jrt.Class

var A_arbace_core_print__init_part0_A_const_46 *jrt.Class

var A_arbace_core_print__init_part0_A_const_47 *lang.Var

var A_arbace_core_print__init_part0_A_const_48 any

var A_arbace_core_print__init_part0_A_const_49 *lang.Var

var A_arbace_core_print__init_part0_A_const_50 any

var A_arbace_core_print__init_part0_A_const_51 *lang.Var

var A_arbace_core_print__init_part0_A_const_52 any

var A_arbace_core_print__init_part0_A_const_53 *lang.Var

var A_arbace_core_print__init_part0_A_const_54 any

var A_arbace_core_print__init_part0_A_const_55 *jrt.Class

var A_arbace_core_print__init_part0_A_const_56 *jrt.Class

var A_arbace_core_print__init_part0_A_const_57 *jrt.Class

var A_arbace_core_print__init_part0_A_const_58 *jrt.Class

var A_arbace_core_print__init_part0_A_const_59 *jrt.Class

var A_arbace_core_print__init_part0_A_const_60 *jrt.Class

var A_arbace_core_print__init_part0_A_const_61 *lang.Var

var A_arbace_core_print__init_part0_A_const_62 any

var A_arbace_core_print__init_part0_A_const_63 any

var A_arbace_core_print__init_part0_A_const_64 *jrt.Class

var A_arbace_core_print__init_part0_A_const_65 *jrt.Class

var A_arbace_core_print__init_part0_A_const_66 *jrt.Class

var A_arbace_core_print__init_part0_A_const_67 *jrt.Class

var A_arbace_core_print__init_part0_A_const_68 *jrt.Class

var A_arbace_core_print__init_part0_A_const_69 *jrt.Class

var A_arbace_core_print__init_part0_A_const_70 *jrt.Class

var A_arbace_core_print__init_part0_A_const_71 *jrt.Class

var A_arbace_core_print__init_part0_A_const_72 *jrt.Class

var A_arbace_core_print__init_part0_A_const_73 *lang.Var

var A_arbace_core_print__init_part0_A_const_74 any

var A_arbace_core_print__init_part0_A_const_75 *jrt.Class

var A_arbace_core_print__init_part0_A_const_76 *jrt.Class

var A_arbace_core_print__init_part0_A_const_77 *jrt.Class

var A_arbace_core_print__init_part0_A_const_78 *lang.Var

var A_arbace_core_print__init_part0_A_const_79 any

var A_arbace_core_print__init_part0_A_const_80 *jrt.Class

var A_arbace_core_print__init_part0_A_const_81 *jrt.Class

var A_arbace_core_print__init_part0_A_const_82 *lang.Var

var A_arbace_core_print__init_part0_A_const_83 any

var A_arbace_core_print__init_part0_A_const_84 *lang.Var

var A_arbace_core_print__init_part0_A_const_85 any

var A_arbace_core_print__init_part0_A_const_86 *lang.Var

var A_arbace_core_print__init_part0_A_const_87 any

var A_arbace_core_print__init_part0_A_const_88 *jrt.Class

var A_arbace_core_print__init_part0_A_const_89 *jrt.Class

var A_arbace_core_print__init_part0_A_init jrt.ClassInit

func A_arbace_core_print__init_part0_A_Init() { if !A_arbace_core_print__init_part0_A_init.Done() { A_arbace_core_print__init_part0_A_init.Run(A_arbace_core_print__init_part0_A_clinit) } }

func A_arbace_core_print__init_part0_A_clinit() { A_arbace_core_print__init_part0_A_clinit_p0(); A_arbace_core_print__init_part0_A_clinit_p1(); A_arbace_core_print__init_part0_A_clinit_p2(); A_arbace_core_print__init_part0_A_clinit_p3(); A_arbace_core_print__init_part0_A_clinit_p4(); A_arbace_core_print__init_part0_A_clinit_p5(); A_arbace_core_print__init_part0_A_clinit_p6(); A_arbace_core_print__init_part0_A_clinit_p7() }

func A_arbace_core_print__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_core_print__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 116); A_arbace_core_print__init_part0_A_const_0 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[26]); A_arbace_core_print__init_part0_A_const_1 = A_arbace_core_print__init_part0_A_const_pool.A[27]; A_arbace_core_print__init_part0_A_const_2 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[28]); A_arbace_core_print__init_part0_A_const_3 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[29]); A_arbace_core_print__init_part0_A_const_4 = A_arbace_core_print__init_part0_A_const_pool.A[30]; A_arbace_core_print__init_part0_A_const_5 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[31]); A_arbace_core_print__init_part0_A_const_6 = A_arbace_core_print__init_part0_A_const_pool.A[32]; A_arbace_core_print__init_part0_A_const_7 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[33]); A_arbace_core_print__init_part0_A_const_8 = A_arbace_core_print__init_part0_A_const_pool.A[34]; A_arbace_core_print__init_part0_A_const_9 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[35]); A_arbace_core_print__init_part0_A_const_10 = A_arbace_core_print__init_part0_A_const_pool.A[36]; A_arbace_core_print__init_part0_A_const_11 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[37]) }

func A_arbace_core_print__init_part0_A_clinit_p1() { A_arbace_core_print__init_part0_A_const_12 = A_arbace_core_print__init_part0_A_const_pool.A[38]; A_arbace_core_print__init_part0_A_const_13 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[39]); A_arbace_core_print__init_part0_A_const_14 = A_arbace_core_print__init_part0_A_const_pool.A[40]; A_arbace_core_print__init_part0_A_const_15 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[41]); A_arbace_core_print__init_part0_A_const_16 = A_arbace_core_print__init_part0_A_const_pool.A[42]; A_arbace_core_print__init_part0_A_const_17 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[43]); A_arbace_core_print__init_part0_A_const_18 = lang.Keyword_Cast(A_arbace_core_print__init_part0_A_const_pool.A[44]); A_arbace_core_print__init_part0_A_const_19 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[45]); A_arbace_core_print__init_part0_A_const_20 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[46]); A_arbace_core_print__init_part0_A_const_21 = A_arbace_core_print__init_part0_A_const_pool.A[47]; A_arbace_core_print__init_part0_A_const_22 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[48]); A_arbace_core_print__init_part0_A_const_23 = A_arbace_core_print__init_part0_A_const_pool.A[49]; A_arbace_core_print__init_part0_A_const_24 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[50]) }

func A_arbace_core_print__init_part0_A_clinit_p2() { A_arbace_core_print__init_part0_A_const_25 = A_arbace_core_print__init_part0_A_const_pool.A[51]; A_arbace_core_print__init_part0_A_const_26 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[52]); A_arbace_core_print__init_part0_A_const_27 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[53]); A_arbace_core_print__init_part0_A_const_28 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[54]); A_arbace_core_print__init_part0_A_const_29 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[55]); A_arbace_core_print__init_part0_A_const_30 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[56]); A_arbace_core_print__init_part0_A_const_31 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[57]); A_arbace_core_print__init_part0_A_const_32 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[58]); A_arbace_core_print__init_part0_A_const_33 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[59]); A_arbace_core_print__init_part0_A_const_34 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[60]); A_arbace_core_print__init_part0_A_const_35 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[61]); A_arbace_core_print__init_part0_A_const_36 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[62]) }

func A_arbace_core_print__init_part0_A_clinit_p3() { A_arbace_core_print__init_part0_A_const_37 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[63]); A_arbace_core_print__init_part0_A_const_38 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[64]); A_arbace_core_print__init_part0_A_const_39 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[65]); A_arbace_core_print__init_part0_A_const_40 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[66]); A_arbace_core_print__init_part0_A_const_41 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[67]); A_arbace_core_print__init_part0_A_const_42 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[68]); A_arbace_core_print__init_part0_A_const_43 = A_arbace_core_print__init_part0_A_const_pool.A[69]; A_arbace_core_print__init_part0_A_const_44 = A_arbace_core_print__init_part0_A_const_pool.A[70]; A_arbace_core_print__init_part0_A_const_45 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[71]); A_arbace_core_print__init_part0_A_const_46 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[72]); A_arbace_core_print__init_part0_A_const_47 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[73]); A_arbace_core_print__init_part0_A_const_48 = A_arbace_core_print__init_part0_A_const_pool.A[74] }

func A_arbace_core_print__init_part0_A_clinit_p4() { A_arbace_core_print__init_part0_A_const_49 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[75]); A_arbace_core_print__init_part0_A_const_50 = A_arbace_core_print__init_part0_A_const_pool.A[76]; A_arbace_core_print__init_part0_A_const_51 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[77]); A_arbace_core_print__init_part0_A_const_52 = A_arbace_core_print__init_part0_A_const_pool.A[78]; A_arbace_core_print__init_part0_A_const_53 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[79]); A_arbace_core_print__init_part0_A_const_54 = A_arbace_core_print__init_part0_A_const_pool.A[80]; A_arbace_core_print__init_part0_A_const_55 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[81]); A_arbace_core_print__init_part0_A_const_56 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[82]); A_arbace_core_print__init_part0_A_const_57 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[83]); A_arbace_core_print__init_part0_A_const_58 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[84]); A_arbace_core_print__init_part0_A_const_59 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[85]); A_arbace_core_print__init_part0_A_const_60 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[86]) }

func A_arbace_core_print__init_part0_A_clinit_p5() { A_arbace_core_print__init_part0_A_const_61 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[87]); A_arbace_core_print__init_part0_A_const_62 = A_arbace_core_print__init_part0_A_const_pool.A[88]; A_arbace_core_print__init_part0_A_const_63 = A_arbace_core_print__init_part0_A_const_pool.A[89]; A_arbace_core_print__init_part0_A_const_64 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[90]); A_arbace_core_print__init_part0_A_const_65 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[91]); A_arbace_core_print__init_part0_A_const_66 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[92]); A_arbace_core_print__init_part0_A_const_67 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[93]); A_arbace_core_print__init_part0_A_const_68 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[94]); A_arbace_core_print__init_part0_A_const_69 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[95]); A_arbace_core_print__init_part0_A_const_70 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[96]); A_arbace_core_print__init_part0_A_const_71 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[97]); A_arbace_core_print__init_part0_A_const_72 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[98]) }

func A_arbace_core_print__init_part0_A_clinit_p6() { A_arbace_core_print__init_part0_A_const_73 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[99]); A_arbace_core_print__init_part0_A_const_74 = A_arbace_core_print__init_part0_A_const_pool.A[100]; A_arbace_core_print__init_part0_A_const_75 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[101]); A_arbace_core_print__init_part0_A_const_76 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[102]); A_arbace_core_print__init_part0_A_const_77 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[103]); A_arbace_core_print__init_part0_A_const_78 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[104]); A_arbace_core_print__init_part0_A_const_79 = A_arbace_core_print__init_part0_A_const_pool.A[105]; A_arbace_core_print__init_part0_A_const_80 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[106]); A_arbace_core_print__init_part0_A_const_81 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[107]); A_arbace_core_print__init_part0_A_const_82 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[108]); A_arbace_core_print__init_part0_A_const_83 = A_arbace_core_print__init_part0_A_const_pool.A[109]; A_arbace_core_print__init_part0_A_const_84 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[110]); A_arbace_core_print__init_part0_A_const_85 = A_arbace_core_print__init_part0_A_const_pool.A[111] }

func A_arbace_core_print__init_part0_A_clinit_p7() { A_arbace_core_print__init_part0_A_const_86 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[112]); A_arbace_core_print__init_part0_A_const_87 = A_arbace_core_print__init_part0_A_const_pool.A[113]; A_arbace_core_print__init_part0_A_const_88 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[114]); A_arbace_core_print__init_part0_A_const_89 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[115]) }

func A_arbace_core_print__init_part0_A_New() *A_arbace_core_print__init_part0_A { A_arbace_core_print__init_part0_A_Init(); t := &A_arbace_core_print__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_core_print__init_part0_A) Ctor() {}

func (t *A_arbace_core_print__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_print__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_core_print__init_part0_A_class }

func (t *A_arbace_core_print__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_print__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_print__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_print__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_print__init_part0_A); return ok }

func A_arbace_core_print__init_part0_A_Cast(x any) *A_arbace_core_print__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_print__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_print__init_part0_A_class)) }; return v }



type A_arbace_core_print__init_part1_A struct{ jrt.Object }

var A_arbace_core_print__init_part1_A_const_pool *jrt.RefArray

var A_arbace_core_print__init_part1_A_const_0 *lang.Var

var A_arbace_core_print__init_part1_A_const_1 *jrt.Class

var A_arbace_core_print__init_part1_A_const_2 *lang.Var

var A_arbace_core_print__init_part1_A_const_3 *jrt.Class

var A_arbace_core_print__init_part1_A_const_4 *lang.Var

var A_arbace_core_print__init_part1_A_const_5 any

var A_arbace_core_print__init_part1_A_const_6 *lang.Var

var A_arbace_core_print__init_part1_A_const_7 any

var A_arbace_core_print__init_part1_A_const_8 *lang.Var

var A_arbace_core_print__init_part1_A_const_9 *jrt.Class

var A_arbace_core_print__init_part1_A_init jrt.ClassInit

func A_arbace_core_print__init_part1_A_Init() { if !A_arbace_core_print__init_part1_A_init.Done() { A_arbace_core_print__init_part1_A_init.Run(A_arbace_core_print__init_part1_A_clinit) } }

func A_arbace_core_print__init_part1_A_clinit() { jrt.StartCheck(); A_arbace_core_print__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_82, 18); var tmp1 *lang.Var; A_arbace_core_print__init_part0_A_Init(); tmp1 = A_arbace_core_print__init_part0_A_const_19; A_arbace_core_print__init_part1_A_const_0 = tmp1; var tmp2 *jrt.Class; A_arbace_core_print__init_part0_A_Init(); tmp2 = A_arbace_core_print__init_part0_A_const_89; A_arbace_core_print__init_part1_A_const_1 = tmp2; var tmp3 *lang.Var; A_arbace_core_print__init_part0_A_Init(); tmp3 = A_arbace_core_print__init_part0_A_const_17; A_arbace_core_print__init_part1_A_const_2 = tmp3; A_arbace_core_print__init_part1_A_const_3 = jrt.Class_Cast(A_arbace_core_print__init_part1_A_const_pool.A[11]); A_arbace_core_print__init_part1_A_const_4 = lang.Var_Cast(A_arbace_core_print__init_part1_A_const_pool.A[12]); A_arbace_core_print__init_part1_A_const_5 = A_arbace_core_print__init_part1_A_const_pool.A[13]; A_arbace_core_print__init_part1_A_const_6 = lang.Var_Cast(A_arbace_core_print__init_part1_A_const_pool.A[14]); A_arbace_core_print__init_part1_A_const_7 = A_arbace_core_print__init_part1_A_const_pool.A[15]; A_arbace_core_print__init_part1_A_const_8 = lang.Var_Cast(A_arbace_core_print__init_part1_A_const_pool.A[16]); A_arbace_core_print__init_part1_A_const_9 = jrt.Class_Cast(A_arbace_core_print__init_part1_A_const_pool.A[17]) }

func A_arbace_core_print__init_part1_A_New() *A_arbace_core_print__init_part1_A { A_arbace_core_print__init_part1_A_Init(); t := &A_arbace_core_print__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_core_print__init_part1_A) Ctor() {}

func (t *A_arbace_core_print__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_print__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_core_print__init_part1_A_class }

func (t *A_arbace_core_print__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_print__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_print__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_print__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_print__init_part1_A); return ok }

func A_arbace_core_print__init_part1_A_Cast(x any) *A_arbace_core_print__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_print__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_print__init_part1_A_class)) }; return v }
