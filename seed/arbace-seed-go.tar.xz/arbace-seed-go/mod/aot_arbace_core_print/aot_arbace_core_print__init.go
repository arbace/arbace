//line aot_arbace_core_print__init.ae:1
package aot_arbace_core_print

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_print__init_A_Load__O() any { jrt.StartCheck(); A_arbace_core_print__init_part0_A_Init__O(); A_arbace_core_print__init_part1_A_Init__O(); A_arbace_core_print__init_part0_A_Load__O(); A_arbace_core_print__init_part1_A_Load__O(); return nil }



func A_arbace_core_print__init_part0_A_Unit0__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return lang.IFn_Cast(A_arbace_core_print__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_print__init_part0_A_const_1) }
//line :9:1
func A_arbace_core_print__init_part0_A_Init__O() any { A_arbace_core_print__init_part0_A_Init(); return nil }
//line :9:1
func A_arbace_core_print__init_part0_A_Load__O() any { A_arbace_core_print__init_part0_A_Init(); A_arbace_core_print__init_part0_A_Unit0__O(); A_arbace_core_print__init_part0_A_Unit1__O(); A_arbace_core_print__init_part0_A_Unit2__O(); A_arbace_core_print__init_part0_A_Unit3__O(); A_arbace_core_print__init_part0_A_Unit4__O(); A_arbace_core_print__init_part0_A_Unit5__O(); A_arbace_core_print__init_part0_A_Unit6__O(); A_arbace_core_print__init_part0_A_Unit7__O(); A_arbace_core_print__init_part0_A_Unit8__O(); A_arbace_core_print__init_part0_A_Unit9__O(); A_arbace_core_print__init_part0_A_Unit10__O(); A_arbace_core_print__init_part0_A_Unit11__O(); A_arbace_core_print__init_part0_A_Unit12__O(); A_arbace_core_print__init_part0_A_Unit13__O(); A_arbace_core_print__init_part0_A_Unit14__O(); A_arbace_core_print__init_part0_A_Unit15__O(); A_arbace_core_print__init_part0_A_Unit16__O(); A_arbace_core_print__init_part0_A_Unit17__O(); A_arbace_core_print__init_part0_A_Unit18__O(); A_arbace_core_print__init_part0_A_Unit19__O(); A_arbace_core_print__init_part0_A_Unit20__O(); A_arbace_core_print__init_part0_A_Unit21__O(); A_arbace_core_print__init_part0_A_Unit22__O(); A_arbace_core_print__init_part0_A_Unit23__O(); A_arbace_core_print__init_part0_A_Unit24__O(); A_arbace_core_print__init_part0_A_Unit25__O(); A_arbace_core_print__init_part0_A_Unit26__O(); A_arbace_core_print__init_part0_A_Unit27__O(); A_arbace_core_print__init_part0_A_Unit28__O(); A_arbace_core_print__init_part0_A_Unit29__O(); A_arbace_core_print__init_part0_A_Unit30__O(); A_arbace_core_print__init_part0_A_Unit31__O(); A_arbace_core_print__init_part0_A_Unit32__O(); A_arbace_core_print__init_part0_A_Unit33__O(); A_arbace_core_print__init_part0_A_Unit34__O(); A_arbace_core_print__init_part0_A_Unit35__O(); A_arbace_core_print__init_part0_A_Unit36__O(); A_arbace_core_print__init_part0_A_Unit37__O(); A_arbace_core_print__init_part0_A_Unit38__O(); A_arbace_core_print__init_part0_A_Unit39__O(); A_arbace_core_print__init_part0_A_Unit40__O(); A_arbace_core_print__init_part0_A_Unit41__O(); A_arbace_core_print__init_part0_A_Unit42__O(); A_arbace_core_print__init_part0_A_Unit43__O(); A_arbace_core_print__init_part0_A_Unit44__O(); A_arbace_core_print__init_part0_A_Unit45__O(); A_arbace_core_print__init_part0_A_Unit46__O(); A_arbace_core_print__init_part0_A_Unit47__O(); A_arbace_core_print__init_part0_A_Unit48__O(); A_arbace_core_print__init_part0_A_Unit49__O(); A_arbace_core_print__init_part0_A_Unit50__O(); A_arbace_core_print__init_part0_A_Unit51__O(); A_arbace_core_print__init_part0_A_Unit52__O(); A_arbace_core_print__init_part0_A_Unit53__O(); A_arbace_core_print__init_part0_A_Unit54__O(); A_arbace_core_print__init_part0_A_Unit55__O(); A_arbace_core_print__init_part0_A_Unit56__O(); A_arbace_core_print__init_part0_A_Unit57__O(); A_arbace_core_print__init_part0_A_Unit58__O(); A_arbace_core_print__init_part0_A_Unit59__O(); A_arbace_core_print__init_part0_A_Unit60__O(); A_arbace_core_print__init_part0_A_Unit61__O(); A_arbace_core_print__init_part0_A_Unit62__O(); A_arbace_core_print__init_part0_A_Unit63__O(); A_arbace_core_print__init_part0_A_Unit64__O(); A_arbace_core_print__init_part0_A_Unit65__O(); A_arbace_core_print__init_part0_A_Unit66__O(); A_arbace_core_print__init_part0_A_Unit67__O(); A_arbace_core_print__init_part0_A_Unit68__O(); A_arbace_core_print__init_part0_A_Unit69__O(); A_arbace_core_print__init_part0_A_Unit70__O(); A_arbace_core_print__init_part0_A_Unit71__O(); A_arbace_core_print__init_part0_A_Unit72__O(); A_arbace_core_print__init_part0_A_Unit73__O(); A_arbace_core_print__init_part0_A_Unit74__O(); A_arbace_core_print__init_part0_A_Unit75__O(); A_arbace_core_print__init_part0_A_Unit76__O(); A_arbace_core_print__init_part0_A_Unit77__O(); A_arbace_core_print__init_part0_A_Unit78__O(); A_arbace_core_print__init_part0_A_Unit79__O(); A_arbace_core_print__init_part0_A_Unit80__O(); A_arbace_core_print__init_part0_A_Unit81__O(); A_arbace_core_print__init_part0_A_Unit82__O(); A_arbace_core_print__init_part0_A_Unit83__O(); A_arbace_core_print__init_part0_A_Unit84__O(); A_arbace_core_print__init_part0_A_Unit85__O(); A_arbace_core_print__init_part0_A_Unit86__O(); A_arbace_core_print__init_part0_A_Unit87__O(); A_arbace_core_print__init_part0_A_Unit88__O(); A_arbace_core_print__init_part0_A_Unit89__O(); A_arbace_core_print__init_part0_A_Unit90__O(); A_arbace_core_print__init_part0_A_Unit91__O(); A_arbace_core_print__init_part0_A_Unit92__O(); A_arbace_core_print__init_part0_A_Unit93__O(); A_arbace_core_print__init_part0_A_Unit94__O(); A_arbace_core_print__init_part0_A_Unit95__O(); A_arbace_core_print__init_part0_A_Unit96__O(); A_arbace_core_print__init_part0_A_Unit97__O(); A_arbace_core_print__init_part0_A_Unit98__O(); A_arbace_core_print__init_part0_A_Unit99__O(); return nil }



func A_arbace_core_print__init_part0_A_Unit1__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)).Ref() }

func A_arbace_core_print__init_part0_A_Unit2__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); return A_arbace_core_print__init_part0_A_const_2.Set_O__O(jrt.Boolean_TRUE.Ref()) }
func A_arbace_core_print__init_part0_A_Unit3__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); A_arbace_core_print__init_part0_A_const_3.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_3; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_4)); return A_arbace_core_print__init_part0_A_const_3.SetDynamic_Z__Var(true).Ref() }










func A_arbace_core_print__init_part0_A_Unit4__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(27, 1); A_arbace_core_print__init_part0_A_const_5.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_5; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_6)); return A_arbace_core_print__init_part0_A_const_5.SetDynamic_Z__Var(true).Ref() }











func A_arbace_core_print__init_part0_A_Unit5__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); A_arbace_core_print__init_part0_A_const_7.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_7; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_8)); return A_arbace_core_print__init_part0_A_const_7.SetDynamic_Z__Var(true).Ref() }

func A_arbace_core_print__init_part0_A_Unit6__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); A_arbace_core_print__init_part0_A_const_9.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_9; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_10)); return A_arbace_core_print__init_part0_A_const_9.SetDynamic_Z__Var(true).Ref() }






func A_arbace_core_print__init_part0_A_Unit7__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_11; var tmp2 any = aot_arbace_core.A_arbace_core_print_sequential_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_core.A_arbace_core_print_sequential_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); aot_arbace_core.A_arbace_core_print_sequential_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_12)); return A_arbace_core_print__init_part0_A_const_11 }























func A_arbace_core_print__init_part0_A_Unit8__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_13; var tmp2 any = aot_arbace_core.A_arbace_core_print_meta_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_core.A_arbace_core_print_meta_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); aot_arbace_core.A_arbace_core_print_meta_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_14)); return A_arbace_core_print__init_part0_A_const_13 }










func A_arbace_core_print__init_part0_A_Unit9__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_15; var tmp2 any = aot_arbace_core.A_arbace_core_print_simple_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_core.A_arbace_core_print_simple_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); aot_arbace_core.A_arbace_core_print_simple_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_16)); return A_arbace_core_print__init_part0_A_const_15 }



func A_arbace_core_print__init_part0_A_Unit10__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(87, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_18; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000030_fn__1769000031_A_New(); var tmp4 *jrt.Class; var fncls__4 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000030_fn__1769000031_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); aot_arbace_core.A_arbace_core_eval1769000030_fn__1769000031_A_fn_class = fncls__4d; tmp4 = fncls__4d } else { tmp4 = fncls__4 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_core_print__init_part0_A_Unit11__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = aot_arbace_core.A_arbace_core_eval1769000036_fn__1769000037_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000036_fn__1769000037_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); aot_arbace_core.A_arbace_core_eval1769000036_fn__1769000037_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(nil, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit12__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = aot_arbace_core.A_arbace_core_eval1769000040_fn__1769000041_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000040_fn__1769000041_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); aot_arbace_core.A_arbace_core_eval1769000040_fn__1769000041_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(nil, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)).Ref() }

func A_arbace_core_print__init_part0_A_Unit13__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_20; var tmp2 any = aot_arbace_core.A_arbace_core_print_ctor_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_core.A_arbace_core_print_ctor_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); aot_arbace_core.A_arbace_core_print_ctor_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_21)); return A_arbace_core_print__init_part0_A_const_20 }






func A_arbace_core_print__init_part0_A_Unit14__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(104, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_22; var tmp2 any = aot_arbace_core.A_arbace_core_print_tagged_object_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = aot_arbace_core.A_arbace_core_print_tagged_object_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); aot_arbace_core.A_arbace_core_print_tagged_object_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_23)); return A_arbace_core_print__init_part0_A_const_22 }












func A_arbace_core_print__init_part0_A_Unit15__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(117, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_24; var tmp2 any = aot_arbace_core.A_arbace_core_print_object_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_core.A_arbace_core_print_object_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); aot_arbace_core.A_arbace_core_print_object_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_25)); return A_arbace_core_print__init_part0_A_const_24 }


func A_arbace_core_print__init_part0_A_Unit16__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(120, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_26; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000047_fn__1769000048_A_New(); var tmp4 *jrt.Class; var fncls__10 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000047_fn__1769000048_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); aot_arbace_core.A_arbace_core_eval1769000047_fn__1769000048_A_fn_class = fncls__10d; tmp4 = fncls__10d } else { tmp4 = fncls__10 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit17__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_27; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000051_fn__1769000052_A_New(); var tmp4 *jrt.Class; var fncls__11 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000051_fn__1769000052_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); aot_arbace_core.A_arbace_core_eval1769000051_fn__1769000052_A_fn_class = fncls__11d; tmp4 = fncls__11d } else { tmp4 = fncls__11 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_core_print__init_part0_A_Unit18__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_28; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000055_fn__1769000056_A_New(); var tmp4 *jrt.Class; var fncls__12 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000055_fn__1769000056_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); aot_arbace_core.A_arbace_core_eval1769000055_fn__1769000056_A_fn_class = fncls__12d; tmp4 = fncls__12d } else { tmp4 = fncls__12 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_core_print__init_part0_A_Unit19__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_27; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000059_fn__1769000060_A_New(); var tmp4 *jrt.Class; var fncls__13 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000059_fn__1769000060_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); aot_arbace_core.A_arbace_core_eval1769000059_fn__1769000060_A_fn_class = fncls__13d; tmp4 = fncls__13d } else { tmp4 = fncls__13 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_part0_A_Unit20__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(134, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_29; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000063_fn__1769000064_A_New(); var tmp4 *jrt.Class; var fncls__14 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000063_fn__1769000064_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); aot_arbace_core.A_arbace_core_eval1769000063_fn__1769000064_A_fn_class = fncls__14d; tmp4 = fncls__14d } else { tmp4 = fncls__14 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit21__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(137, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_30; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000067_fn__1769000068_A_New(); var tmp4 *jrt.Class; var fncls__15 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000067_fn__1769000068_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); aot_arbace_core.A_arbace_core_eval1769000067_fn__1769000068_A_fn_class = fncls__15d; tmp4 = fncls__15d } else { tmp4 = fncls__15 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_part0_A_Unit22__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(144, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_31; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000071_fn__1769000072_A_New(); var tmp4 *jrt.Class; var fncls__16 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000071_fn__1769000072_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); aot_arbace_core.A_arbace_core_eval1769000071_fn__1769000072_A_fn_class = fncls__16d; tmp4 = fncls__16d } else { tmp4 = fncls__16 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_part0_A_Unit23__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(151, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_29; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000075_fn__1769000076_A_New(); var tmp4 *jrt.Class; var fncls__17 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000075_fn__1769000076_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); aot_arbace_core.A_arbace_core_eval1769000075_fn__1769000076_A_fn_class = fncls__17d; tmp4 = fncls__17d } else { tmp4 = fncls__17 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_core_print__init_part0_A_Unit24__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(157, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_32; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000081_fn__1769000082_A_New(); var tmp4 *jrt.Class; var fncls__18 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000081_fn__1769000082_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); aot_arbace_core.A_arbace_core_eval1769000081_fn__1769000082_A_fn_class = fncls__18d; tmp4 = fncls__18d } else { tmp4 = fncls__18 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit25__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(160, 1); var root_19 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_23 any = A_arbace_core_print__init_part0_A_const_34; var arg_24 any = A_arbace_core_print__init_part0_A_const_32; if linked_20 == nil { return ifn_21.Invoke_O_O_O__O(arg_22, arg_23, arg_24) } else { return linked_20.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_19, arg_22, arg_23, arg_24) } }
func A_arbace_core_print__init_part0_A_Unit26__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var root_25 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_29 any = A_arbace_core_print__init_part0_A_const_35; var arg_30 any = A_arbace_core_print__init_part0_A_const_32; if linked_26 == nil { return ifn_27.Invoke_O_O_O__O(arg_28, arg_29, arg_30) } else { return linked_26.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_25, arg_28, arg_29, arg_30) } }
func A_arbace_core_print__init_part0_A_Unit27__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(162, 1); var root_31 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_35 any = A_arbace_core_print__init_part0_A_const_36; var arg_36 any = A_arbace_core_print__init_part0_A_const_32; if linked_32 == nil { return ifn_33.Invoke_O_O_O__O(arg_34, arg_35, arg_36) } else { return linked_32.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_31, arg_34, arg_35, arg_36) } }

func A_arbace_core_print__init_part0_A_Unit28__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_37; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000093_fn__1769000094_A_New(); var tmp4 *jrt.Class; var fncls__37 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000093_fn__1769000094_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); aot_arbace_core.A_arbace_core_eval1769000093_fn__1769000094_A_fn_class = fncls__37d; tmp4 = fncls__37d } else { tmp4 = fncls__37 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit29__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(167, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_37; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000097_fn__1769000098_A_New(); var tmp4 *jrt.Class; var fncls__38 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000097_fn__1769000098_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); aot_arbace_core.A_arbace_core_eval1769000097_fn__1769000098_A_fn_class = fncls__38d; tmp4 = fncls__38d } else { tmp4 = fncls__38 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_part0_A_Unit30__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(169, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_38; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000101_fn__1769000102_A_New(); var tmp4 *jrt.Class; var fncls__39 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000101_fn__1769000102_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); aot_arbace_core.A_arbace_core_eval1769000101_fn__1769000102_A_fn_class = fncls__39d; tmp4 = fncls__39d } else { tmp4 = fncls__39 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit31__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(172, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_38; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000105_fn__1769000106_A_New(); var tmp4 *jrt.Class; var fncls__40 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000105_fn__1769000106_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); aot_arbace_core.A_arbace_core_eval1769000105_fn__1769000106_A_fn_class = fncls__40d; tmp4 = fncls__40d } else { tmp4 = fncls__40 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_part0_A_Unit32__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(174, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_39; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000109_fn__1769000110_A_New(); var tmp4 *jrt.Class; var fncls__41 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000109_fn__1769000110_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); aot_arbace_core.A_arbace_core_eval1769000109_fn__1769000110_A_fn_class = fncls__41d; tmp4 = fncls__41d } else { tmp4 = fncls__41 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit33__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(177, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_39; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000113_fn__1769000114_A_New(); var tmp4 *jrt.Class; var fncls__42 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000113_fn__1769000114_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); aot_arbace_core.A_arbace_core_eval1769000113_fn__1769000114_A_fn_class = fncls__42d; tmp4 = fncls__42d } else { tmp4 = fncls__42 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit34__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(180, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_40; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000117_fn__1769000118_A_New(); var tmp4 *jrt.Class; var fncls__43 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000117_fn__1769000118_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); aot_arbace_core.A_arbace_core_eval1769000117_fn__1769000118_A_fn_class = fncls__43d; tmp4 = fncls__43d } else { tmp4 = fncls__43 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_core_print__init_part0_A_Unit35__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(184, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_40; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000121_fn__1769000122_A_New(); var tmp4 *jrt.Class; var fncls__44 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000121_fn__1769000122_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); aot_arbace_core.A_arbace_core_eval1769000121_fn__1769000122_A_fn_class = fncls__44d; tmp4 = fncls__44d } else { tmp4 = fncls__44 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit36__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(185, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_41; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000125_fn__1769000126_A_New(); var tmp4 *jrt.Class; var fncls__45 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000125_fn__1769000126_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); aot_arbace_core.A_arbace_core_eval1769000125_fn__1769000126_A_fn_class = fncls__45d; tmp4 = fncls__45d } else { tmp4 = fncls__45 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit37__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(186, 1); var root_46 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(); var arg_50 any = A_arbace_core_print__init_part0_A_const_40; var arg_51 any = A_arbace_core_print__init_part0_A_const_34; if linked_47 == nil { return ifn_48.Invoke_O_O_O__O(arg_49, arg_50, arg_51) } else { return linked_47.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_46, arg_49, arg_50, arg_51) } }
func A_arbace_core_print__init_part0_A_Unit38__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(187, 1); var root_52 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_56 any = A_arbace_core_print__init_part0_A_const_40; var arg_57 any = A_arbace_core_print__init_part0_A_const_34; if linked_53 == nil { return ifn_54.Invoke_O_O_O__O(arg_55, arg_56, arg_57) } else { return linked_53.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_52, arg_55, arg_56, arg_57) } }
func A_arbace_core_print__init_part0_A_Unit39__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(188, 1); var root_58 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(); var arg_62 any = A_arbace_core_print__init_part0_A_const_40; var arg_63 any = A_arbace_core_print__init_part0_A_const_36; if linked_59 == nil { return ifn_60.Invoke_O_O_O__O(arg_61, arg_62, arg_63) } else { return linked_59.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_58, arg_61, arg_62, arg_63) } }
func A_arbace_core_print__init_part0_A_Unit40__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(189, 1); var root_64 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_68 any = A_arbace_core_print__init_part0_A_const_40; var arg_69 any = A_arbace_core_print__init_part0_A_const_36; if linked_65 == nil { return ifn_66.Invoke_O_O_O__O(arg_67, arg_68, arg_69) } else { return linked_65.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_64, arg_67, arg_68, arg_69) } }

func A_arbace_core_print__init_part0_A_Unit41__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(191, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_36; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000139_fn__1769000140_A_New(); var tmp4 *jrt.Class; var fncls__70 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000139_fn__1769000140_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); aot_arbace_core.A_arbace_core_eval1769000139_fn__1769000140_A_fn_class = fncls__70d; tmp4 = fncls__70d } else { tmp4 = fncls__70 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit42__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(194, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_34; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000145_fn__1769000146_A_New(); var tmp4 *jrt.Class; var fncls__71 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000145_fn__1769000146_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); aot_arbace_core.A_arbace_core_eval1769000145_fn__1769000146_A_fn_class = fncls__71d; tmp4 = fncls__71d } else { tmp4 = fncls__71 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_core_print__init_part0_A_Unit43__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); var root_72 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_76 any = A_arbace_core_print__init_part0_A_const_34; var arg_77 any = A_arbace_core_print__init_part0_A_const_36; if linked_73 == nil { return ifn_74.Invoke_O_O_O__O(arg_75, arg_76, arg_77) } else { return linked_73.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_72, arg_75, arg_76, arg_77) } }

func A_arbace_core_print__init_part0_A_Unit44__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(204, 1); A_arbace_core_print__init_part0_A_const_42.BindRoot_O__V(A_arbace_core_print__init_part0_A_const_43); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_42; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_44)); return A_arbace_core_print__init_part0_A_const_42 }











func A_arbace_core_print__init_part0_A_Unit45__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(216, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_45; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000151_fn__1769000152_A_New(); var tmp4 *jrt.Class; var fncls__78 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000151_fn__1769000152_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); aot_arbace_core.A_arbace_core_eval1769000151_fn__1769000152_A_fn_class = fncls__78d; tmp4 = fncls__78d } else { tmp4 = fncls__78 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }










func A_arbace_core_print__init_part0_A_Unit46__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(227, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_45; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000155_fn__1769000156_A_New(); var tmp4 *jrt.Class; var fncls__79 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000155_fn__1769000156_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); aot_arbace_core.A_arbace_core_eval1769000155_fn__1769000156_A_fn_class = fncls__79d; tmp4 = fncls__79d } else { tmp4 = fncls__79 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_part0_A_Unit47__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_46; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000159_fn__1769000160_A_New(); var tmp4 *jrt.Class; var fncls__80 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000159_fn__1769000160_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); aot_arbace_core.A_arbace_core_eval1769000159_fn__1769000160_A_fn_class = fncls__80d; tmp4 = fncls__80d } else { tmp4 = fncls__80 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_core_print__init_part0_A_Unit48__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(233, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_47; var tmp2 any = aot_arbace_core.A_arbace_core_print_prefix_map_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = aot_arbace_core.A_arbace_core_print_prefix_map_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); aot_arbace_core.A_arbace_core_print_prefix_map_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_48)); return A_arbace_core_print__init_part0_A_const_47 }








func A_arbace_core_print__init_part0_A_Unit49__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(242, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_49; var tmp2 any = aot_arbace_core.A_arbace_core_print_map_A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = aot_arbace_core.A_arbace_core_print_map_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); aot_arbace_core.A_arbace_core_print_map_A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_50)); return A_arbace_core_print__init_part0_A_const_49 }


func A_arbace_core_print__init_part0_A_Unit50__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(245, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_51; var tmp2 any = aot_arbace_core.A_arbace_core_strip_ns_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = aot_arbace_core.A_arbace_core_strip_ns_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); aot_arbace_core.A_arbace_core_strip_ns_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_52)); return A_arbace_core_print__init_part0_A_const_51 }





func A_arbace_core_print__init_part0_A_Unit51__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(251, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_53; var tmp2 any = aot_arbace_core.A_arbace_core_lift_ns_A_New(); var tmp3 *jrt.Class; var fncls__84 *jrt.Class = aot_arbace_core.A_arbace_core_lift_ns_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); aot_arbace_core.A_arbace_core_lift_ns_A_fn_class = fncls__84d; tmp3 = fncls__84d } else { tmp3 = fncls__84 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_54)); return A_arbace_core_print__init_part0_A_const_53 }















func A_arbace_core_print__init_part0_A_Unit52__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(267, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_55; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000192_fn__1769000193_A_New(); var tmp4 *jrt.Class; var fncls__85 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000192_fn__1769000193_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); aot_arbace_core.A_arbace_core_eval1769000192_fn__1769000193_A_fn_class = fncls__85d; tmp4 = fncls__85d } else { tmp4 = fncls__85 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_part0_A_Unit53__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(274, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_35; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000201_fn__1769000202_A_New(); var tmp4 *jrt.Class; var fncls__86 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000201_fn__1769000202_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); aot_arbace_core.A_arbace_core_eval1769000201_fn__1769000202_A_fn_class = fncls__86d; tmp4 = fncls__86d } else { tmp4 = fncls__86 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit54__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(277, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_55; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000207_fn__1769000208_A_New(); var tmp4 *jrt.Class; var fncls__87 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000207_fn__1769000208_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); aot_arbace_core.A_arbace_core_eval1769000207_fn__1769000208_A_fn_class = fncls__87d; tmp4 = fncls__87d } else { tmp4 = fncls__87 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }








func A_arbace_core_print__init_part0_A_Unit55__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(286, 1); var root_88 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(); var arg_92 any = A_arbace_core_print__init_part0_A_const_34; var arg_93 any = A_arbace_core_print__init_part0_A_const_36; if linked_89 == nil { return ifn_90.Invoke_O_O_O__O(arg_91, arg_92, arg_93) } else { return linked_89.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_88, arg_91, arg_92, arg_93) } }
func A_arbace_core_print__init_part0_A_Unit56__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(287, 1); var root_94 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(); var arg_98 any = A_arbace_core_print__init_part0_A_const_34; var arg_99 any = A_arbace_core_print__init_part0_A_const_56; if linked_95 == nil { return ifn_96.Invoke_O_O_O__O(arg_97, arg_98, arg_99) } else { return linked_95.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_94, arg_97, arg_98, arg_99) } }
func A_arbace_core_print__init_part0_A_Unit57__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); var root_100 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(); var arg_104 any = A_arbace_core_print__init_part0_A_const_56; var arg_105 any = A_arbace_core_print__init_part0_A_const_57; if linked_101 == nil { return ifn_102.Invoke_O_O_O__O(arg_103, arg_104, arg_105) } else { return linked_101.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_100, arg_103, arg_104, arg_105) } }
func A_arbace_core_print__init_part0_A_Unit58__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(289, 1); var root_106 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(); var arg_110 any = A_arbace_core_print__init_part0_A_const_34; var arg_111 any = A_arbace_core_print__init_part0_A_const_35; if linked_107 == nil { return ifn_108.Invoke_O_O_O__O(arg_109, arg_110, arg_111) } else { return linked_107.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_106, arg_109, arg_110, arg_111) } }

func A_arbace_core_print__init_part0_A_Unit59__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(291, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_57; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000219_fn__1769000220_A_New(); var tmp4 *jrt.Class; var fncls__112 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000219_fn__1769000220_A_fn_class; if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); aot_arbace_core.A_arbace_core_eval1769000219_fn__1769000220_A_fn_class = fncls__112d; tmp4 = fncls__112d } else { tmp4 = fncls__112 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_part0_A_Unit60__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_56; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000223_fn__1769000224_A_New(); var tmp4 *jrt.Class; var fncls__113 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000223_fn__1769000224_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); aot_arbace_core.A_arbace_core_eval1769000223_fn__1769000224_A_fn_class = fncls__113d; tmp4 = fncls__113d } else { tmp4 = fncls__113 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_part0_A_Unit61__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(305, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_35; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000227_fn__1769000228_A_New(); var tmp4 *jrt.Class; var fncls__114 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000227_fn__1769000228_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); aot_arbace_core.A_arbace_core_eval1769000227_fn__1769000228_A_fn_class = fncls__114d; tmp4 = fncls__114d } else { tmp4 = fncls__114 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_core_print__init_part0_A_Unit62__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(312, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_58; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000231_fn__1769000232_A_New(); var tmp4 *jrt.Class; var fncls__115 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000231_fn__1769000232_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); aot_arbace_core.A_arbace_core_eval1769000231_fn__1769000232_A_fn_class = fncls__115d; tmp4 = fncls__115d } else { tmp4 = fncls__115 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }








func A_arbace_core_print__init_part0_A_Unit63__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(321, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_59; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000235_fn__1769000236_A_New(); var tmp4 *jrt.Class; var fncls__116 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000235_fn__1769000236_A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); aot_arbace_core.A_arbace_core_eval1769000235_fn__1769000236_A_fn_class = fncls__116d; tmp4 = fncls__116d } else { tmp4 = fncls__116 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_core_print__init_part0_A_Unit64__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(327, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_59; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000239_fn__1769000240_A_New(); var tmp4 *jrt.Class; var fncls__117 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000239_fn__1769000240_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); aot_arbace_core.A_arbace_core_eval1769000239_fn__1769000240_A_fn_class = fncls__117d; tmp4 = fncls__117d } else { tmp4 = fncls__117 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_core_print__init_part0_A_Unit65__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(335, 1); var root_118 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(); var arg_122 any = A_arbace_core_print__init_part0_A_const_59; var arg_123 any = A_arbace_core_print__init_part0_A_const_35; if linked_119 == nil { return ifn_120.Invoke_O_O_O__O(arg_121, arg_122, arg_123) } else { return linked_119.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_118, arg_121, arg_122, arg_123) } }
func A_arbace_core_print__init_part0_A_Unit66__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(336, 1); var root_124 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O(); var arg_128 any = A_arbace_core_print__init_part0_A_const_59; var arg_129 any = A_arbace_core_print__init_part0_A_const_55; if linked_125 == nil { return ifn_126.Invoke_O_O_O__O(arg_127, arg_128, arg_129) } else { return linked_125.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_124, arg_127, arg_128, arg_129) } }
func A_arbace_core_print__init_part0_A_Unit67__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(337, 1); var root_130 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_134 any = A_arbace_core_print__init_part0_A_const_59; var arg_135 any = A_arbace_core_print__init_part0_A_const_55; if linked_131 == nil { return ifn_132.Invoke_O_O_O__O(arg_133, arg_134, arg_135) } else { return linked_131.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_130, arg_133, arg_134, arg_135) } }
func A_arbace_core_print__init_part0_A_Unit68__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(338, 1); var root_136 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_140 any = A_arbace_core_print__init_part0_A_const_34; var arg_141 any = A_arbace_core_print__init_part0_A_const_35; if linked_137 == nil { return ifn_138.Invoke_O_O_O__O(arg_139, arg_140, arg_141) } else { return linked_137.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_136, arg_139, arg_140, arg_141) } }
func A_arbace_core_print__init_part0_A_Unit69__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(339, 1); var root_142 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_146 any = A_arbace_core_print__init_part0_A_const_59; var arg_147 any = A_arbace_core_print__init_part0_A_const_34; if linked_143 == nil { return ifn_144.Invoke_O_O_O__O(arg_145, arg_146, arg_147) } else { return linked_143.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_142, arg_145, arg_146, arg_147) } }
func A_arbace_core_print__init_part0_A_Unit70__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(340, 1); var root_148 any = A_arbace_core_print__init_part0_A_const_33.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_prefer_method_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O(); var arg_152 any = A_arbace_core_print__init_part0_A_const_59; var arg_153 any = A_arbace_core_print__init_part0_A_const_35; if linked_149 == nil { return ifn_150.Invoke_O_O_O__O(arg_151, arg_152, arg_153) } else { return linked_149.(*aot_arbace_core.A_arbace_core_prefer_method_A).Invoke_O_O_O_O__O(root_148, arg_151, arg_152, arg_153) } }

func A_arbace_core_print__init_part0_A_Unit71__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(342, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_60; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000255_fn__1769000256_A_New(); var tmp4 *jrt.Class; var fncls__154 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000255_fn__1769000256_A_fn_class; if fncls__154 == nil { var fncls__154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); aot_arbace_core.A_arbace_core_eval1769000255_fn__1769000256_A_fn_class = fncls__154d; tmp4 = fncls__154d } else { tmp4 = fncls__154 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_core_print__init_part0_A_Unit72__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(346, 1); A_arbace_core_print__init_part0_A_const_61.BindRoot_O__V(A_arbace_core_print__init_part0_A_const_62); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_61; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_63)); return A_arbace_core_print__init_part0_A_const_61 }










func A_arbace_core_print__init_part0_A_Unit73__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(357, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_64; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000259_fn__1769000260_A_New(); var tmp4 *jrt.Class; var fncls__155 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000259_fn__1769000260_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); aot_arbace_core.A_arbace_core_eval1769000259_fn__1769000260_A_fn_class = fncls__155d; tmp4 = fncls__155d } else { tmp4 = fncls__155 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_core_print__init_part0_A_Unit74__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(365, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_64; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000263_fn__1769000264_A_New(); var tmp4 *jrt.Class; var fncls__156 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000263_fn__1769000264_A_fn_class; if fncls__156 == nil { var fncls__156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); aot_arbace_core.A_arbace_core_eval1769000263_fn__1769000264_A_fn_class = fncls__156d; tmp4 = fncls__156d } else { tmp4 = fncls__156 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit75__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(366, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_65; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000267_fn__1769000268_A_New(); var tmp4 *jrt.Class; var fncls__157 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000267_fn__1769000268_A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); aot_arbace_core.A_arbace_core_eval1769000267_fn__1769000268_A_fn_class = fncls__157d; tmp4 = fncls__157d } else { tmp4 = fncls__157 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit76__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(367, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_30; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000271_fn__1769000272_A_New(); var tmp4 *jrt.Class; var fncls__158 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000271_fn__1769000272_A_fn_class; if fncls__158 == nil { var fncls__158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); aot_arbace_core.A_arbace_core_eval1769000271_fn__1769000272_A_fn_class = fncls__158d; tmp4 = fncls__158d } else { tmp4 = fncls__158 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit77__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(368, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_66; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000275_fn__1769000276_A_New(); var tmp4 *jrt.Class; var fncls__159 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000275_fn__1769000276_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); aot_arbace_core.A_arbace_core_eval1769000275_fn__1769000276_A_fn_class = fncls__159d; tmp4 = fncls__159d } else { tmp4 = fncls__159 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit78__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(369, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_67; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000279_fn__1769000280_A_New(); var tmp4 *jrt.Class; var fncls__160 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000279_fn__1769000280_A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); aot_arbace_core.A_arbace_core_eval1769000279_fn__1769000280_A_fn_class = fncls__160d; tmp4 = fncls__160d } else { tmp4 = fncls__160 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit79__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(370, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_68; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000283_fn__1769000284_A_New(); var tmp4 *jrt.Class; var fncls__161 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000283_fn__1769000284_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); aot_arbace_core.A_arbace_core_eval1769000283_fn__1769000284_A_fn_class = fncls__161d; tmp4 = fncls__161d } else { tmp4 = fncls__161 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit80__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(371, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_69; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000287_fn__1769000288_A_New(); var tmp4 *jrt.Class; var fncls__162 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000287_fn__1769000288_A_fn_class; if fncls__162 == nil { var fncls__162d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); aot_arbace_core.A_arbace_core_eval1769000287_fn__1769000288_A_fn_class = fncls__162d; tmp4 = fncls__162d } else { tmp4 = fncls__162 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit81__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(372, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_70; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000291_fn__1769000292_A_New(); var tmp4 *jrt.Class; var fncls__163 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000291_fn__1769000292_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); aot_arbace_core.A_arbace_core_eval1769000291_fn__1769000292_A_fn_class = fncls__163d; tmp4 = fncls__163d } else { tmp4 = fncls__163 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit82__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(373, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_71; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000295_fn__1769000296_A_New(); var tmp4 *jrt.Class; var fncls__164 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000295_fn__1769000296_A_fn_class; if fncls__164 == nil { var fncls__164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); aot_arbace_core.A_arbace_core_eval1769000295_fn__1769000296_A_fn_class = fncls__164d; tmp4 = fncls__164d } else { tmp4 = fncls__164 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_core_print__init_part0_A_Unit83__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(374, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_72; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000299_fn__1769000300_A_New(); var tmp4 *jrt.Class; var fncls__165 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000299_fn__1769000300_A_fn_class; if fncls__165 == nil { var fncls__165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); aot_arbace_core.A_arbace_core_eval1769000299_fn__1769000300_A_fn_class = fncls__165d; tmp4 = fncls__165d } else { tmp4 = fncls__165 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_part0_A_Unit84__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(376, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_73; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, jrt.Float_TYPE.Ref(), Lit_59, jrt.Integer_TYPE.Ref(), Lit_60, jrt.Long_TYPE.Ref(), Lit_61, jrt.Boolean_TYPE.Ref(), Lit_62, jrt.Character_TYPE.Ref(), Lit_63, jrt.Double_TYPE.Ref(), Lit_64, jrt.Byte_TYPE.Ref(), Lit_65, jrt.Short_TYPE.Ref(), Lit_66))); var tmp2 *lang.Var = A_arbace_core_print__init_part0_A_const_73; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_74)); return A_arbace_core_print__init_part0_A_const_73 }









func A_arbace_core_print__init_part0_A_Unit85__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(386, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_75; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000303_fn__1769000304_A_New(); var tmp4 *jrt.Class; var fncls__166 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000303_fn__1769000304_A_fn_class; if fncls__166 == nil { var fncls__166d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); aot_arbace_core.A_arbace_core_eval1769000303_fn__1769000304_A_fn_class = fncls__166d; tmp4 = fncls__166d } else { tmp4 = fncls__166 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_core_print__init_part0_A_Unit86__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(391, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_75; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000307_fn__1769000308_A_New(); var tmp4 *jrt.Class; var fncls__167 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000307_fn__1769000308_A_fn_class; if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); aot_arbace_core.A_arbace_core_eval1769000307_fn__1769000308_A_fn_class = fncls__167d; tmp4 = fncls__167d } else { tmp4 = fncls__167 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }













func A_arbace_core_print__init_part0_A_Unit87__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(405, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_67; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000311_fn__1769000312_A_New(); var tmp4 *jrt.Class; var fncls__168 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000311_fn__1769000312_A_fn_class; if fncls__168 == nil { var fncls__168d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); aot_arbace_core.A_arbace_core_eval1769000311_fn__1769000312_A_fn_class = fncls__168d; tmp4 = fncls__168d } else { tmp4 = fncls__168 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_core_print__init_part0_A_Unit88__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(409, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_68; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000315_fn__1769000316_A_New(); var tmp4 *jrt.Class; var fncls__169 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000315_fn__1769000316_A_fn_class; if fncls__169 == nil { var fncls__169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); aot_arbace_core.A_arbace_core_eval1769000315_fn__1769000316_A_fn_class = fncls__169d; tmp4 = fncls__169d } else { tmp4 = fncls__169 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_core_print__init_part0_A_Unit89__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(413, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_76; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000319_fn__1769000320_A_New(); var tmp4 *jrt.Class; var fncls__170 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000319_fn__1769000320_A_fn_class; if fncls__170 == nil { var fncls__170d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); aot_arbace_core.A_arbace_core_eval1769000319_fn__1769000320_A_fn_class = fncls__170d; tmp4 = fncls__170d } else { tmp4 = fncls__170 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





















func A_arbace_core_print__init_part0_A_Unit90__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(435, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_76; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000336_fn__1769000337_A_New(); var tmp4 *jrt.Class; var fncls__171 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000336_fn__1769000337_A_fn_class; if fncls__171 == nil { var fncls__171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); aot_arbace_core.A_arbace_core_eval1769000336_fn__1769000337_A_fn_class = fncls__171d; tmp4 = fncls__171d } else { tmp4 = fncls__171 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_core_print__init_part0_A_Unit91__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(437, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_77; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000340_fn__1769000341_A_New(); var tmp4 *jrt.Class; var fncls__172 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000340_fn__1769000341_A_fn_class; if fncls__172 == nil { var fncls__172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); aot_arbace_core.A_arbace_core_eval1769000340_fn__1769000341_A_fn_class = fncls__172d; tmp4 = fncls__172d } else { tmp4 = fncls__172 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_core_print__init_part0_A_Unit92__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(442, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_78; var tmp2 any = aot_arbace_core.A_arbace_core_deref_as_map_A_New(); var tmp3 *jrt.Class; var fncls__173 *jrt.Class = aot_arbace_core.A_arbace_core_deref_as_map_A_fn_class; if fncls__173 == nil { var fncls__173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); aot_arbace_core.A_arbace_core_deref_as_map_A_fn_class = fncls__173d; tmp3 = fncls__173d } else { tmp3 = fncls__173 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_79)); return A_arbace_core_print__init_part0_A_const_78 }






















func A_arbace_core_print__init_part0_A_Unit93__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(465, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_80; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000350_fn__1769000351_A_New(); var tmp4 *jrt.Class; var fncls__174 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000350_fn__1769000351_A_fn_class; if fncls__174 == nil { var fncls__174d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); aot_arbace_core.A_arbace_core_eval1769000350_fn__1769000351_A_fn_class = fncls__174d; tmp4 = fncls__174d } else { tmp4 = fncls__174 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit94__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(468, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_81; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000354_fn__1769000355_A_New(); var tmp4 *jrt.Class; var fncls__175 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000354_fn__1769000355_A_fn_class; if fncls__175 == nil { var fncls__175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); aot_arbace_core.A_arbace_core_eval1769000354_fn__1769000355_A_fn_class = fncls__175d; tmp4 = fncls__175d } else { tmp4 = fncls__175 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit95__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(471, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_82; var tmp2 any = aot_arbace_core.A_arbace_core_StackTraceElement__GT_vec_A_New(); var tmp3 *jrt.Class; var fncls__176 *jrt.Class = aot_arbace_core.A_arbace_core_StackTraceElement__GT_vec_A_fn_class; if fncls__176 == nil { var fncls__176d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); aot_arbace_core.A_arbace_core_StackTraceElement__GT_vec_A_fn_class = fncls__176d; tmp3 = fncls__176d } else { tmp3 = fncls__176 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_83)); return A_arbace_core_print__init_part0_A_const_82 }





func A_arbace_core_print__init_part0_A_Unit96__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(477, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_84; var tmp2 any = aot_arbace_core.A_arbace_core_Throwable__GT_map_A_New(); var tmp3 *jrt.Class; var fncls__177 *jrt.Class = aot_arbace_core.A_arbace_core_Throwable__GT_map_A_fn_class; if fncls__177 == nil { var fncls__177d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); aot_arbace_core.A_arbace_core_Throwable__GT_map_A_fn_class = fncls__177d; tmp3 = fncls__177d } else { tmp3 = fncls__177 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_85)); return A_arbace_core_print__init_part0_A_const_84 }



































func A_arbace_core_print__init_part0_A_Unit97__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(513, 1); var tmp1 *lang.Var = A_arbace_core_print__init_part0_A_const_86; var tmp2 any = aot_arbace_core.A_arbace_core_print_throwable_A_New(); var tmp3 *jrt.Class; var fncls__178 *jrt.Class = aot_arbace_core.A_arbace_core_print_throwable_A_fn_class; if fncls__178 == nil { var fncls__178d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); aot_arbace_core.A_arbace_core_print_throwable_A_fn_class = fncls__178d; tmp3 = fncls__178d } else { tmp3 = fncls__178 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_print__init_part0_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part0_A_const_87)); return A_arbace_core_print__init_part0_A_const_86 }



































func A_arbace_core_print__init_part0_A_Unit98__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(549, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_88; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000378_fn__1769000379_A_New(); var tmp4 *jrt.Class; var fncls__179 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000378_fn__1769000379_A_fn_class; if fncls__179 == nil { var fncls__179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); aot_arbace_core.A_arbace_core_eval1769000378_fn__1769000379_A_fn_class = fncls__179d; tmp4 = fncls__179d } else { tmp4 = fncls__179 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_core_print__init_part0_A_Unit99__O() any { A_arbace_core_print__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(552, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part0_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part0_A_const_89; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000382_fn__1769000383_A_New(); var tmp4 *jrt.Class; var fncls__180 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000382_fn__1769000383_A_fn_class; if fncls__180 == nil { var fncls__180d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); aot_arbace_core.A_arbace_core_eval1769000382_fn__1769000383_A_fn_class = fncls__180d; tmp4 = fncls__180d } else { tmp4 = fncls__180 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_core_print__init_part1_A_Unit100__O() any { A_arbace_core_print__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(558, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part1_A_const_1; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000386_fn__1769000387_A_New(); var tmp4 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000386_fn__1769000387_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); aot_arbace_core.A_arbace_core_eval1769000386_fn__1769000387_A_fn_class = fncls__1d; tmp4 = fncls__1d } else { tmp4 = fncls__1 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
//line :558:1
func A_arbace_core_print__init_part1_A_Init__O() any { A_arbace_core_print__init_part1_A_Init(); return nil }
//line :558:1
func A_arbace_core_print__init_part1_A_Load__O() any { A_arbace_core_print__init_part1_A_Init(); A_arbace_core_print__init_part1_A_Unit100__O(); A_arbace_core_print__init_part1_A_Unit101__O(); A_arbace_core_print__init_part1_A_Unit102__O(); A_arbace_core_print__init_part1_A_Unit103__O(); return nil }

func A_arbace_core_print__init_part1_A_Unit101__O() any { A_arbace_core_print__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(560, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core_print__init_part1_A_const_2.GetRawRoot__O()); var tmp2 any = A_arbace_core_print__init_part1_A_const_3; var tmp3 any = aot_arbace_core.A_arbace_core_eval1769000390_fn__1769000391_A_New(); var tmp4 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_core.A_arbace_core_eval1769000390_fn__1769000391_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); aot_arbace_core.A_arbace_core_eval1769000390_fn__1769000391_A_fn_class = fncls__2d; tmp4 = fncls__2d } else { tmp4 = fncls__2 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_core_print__init_part1_A_Unit102__O() any { A_arbace_core_print__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(565, 1); A_arbace_core_print__init_part1_A_const_4.BindRoot_O__V(jrt.Boolean_TRUE.Ref()); var tmp1 *lang.Var = A_arbace_core_print__init_part1_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part1_A_const_5)); return A_arbace_core_print__init_part1_A_const_4 }

func A_arbace_core_print__init_part1_A_Unit103__O() any { A_arbace_core_print__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(567, 1); var tmp1 any = A_arbace_core_print__init_part1_A_const_9; lang.IFn_Cast(A_arbace_core_print__init_part1_A_const_8.GetRawRoot__O()).ApplyTo_ISeq__O(lang.RT_Cons_O_O__ISeq_NoInit(tmp1, lang.RT_Seq_O__ISeq_NoInit(jrt.RefArrayOf(jrt.Object_class)))); var tmp2 *lang.Var = A_arbace_core_print__init_part1_A_const_6; var tmp3 any = aot_arbace_core.A_arbace_core_PrintWriter_on_A_New(); var tmp4 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_core.A_arbace_core_PrintWriter_on_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); aot_arbace_core.A_arbace_core_PrintWriter_on_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; tmp2.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); var tmp5 *lang.Var = A_arbace_core_print__init_part1_A_const_6; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_print__init_part1_A_const_7)); return A_arbace_core_print__init_part1_A_const_6 }



type A_arbace_core_print__init_A struct{ jrt.Object }

func A_arbace_core_print__init_A_New() *A_arbace_core_print__init_A { t := &A_arbace_core_print__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_print__init_A) Ctor() {}

func (t *A_arbace_core_print__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_print__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_print__init_A_class }

func (t *A_arbace_core_print__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_print__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_print__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_print__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_print__init_A); return ok }

func A_arbace_core_print__init_A_Cast(x any) *A_arbace_core_print__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_print__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_print__init_A_class)) }; return v }



type A_arbace_core_print__init_part0_A struct{ jrt.Object }

var A_arbace_core_print__init_part0_A_const_pool *jrt.RefArray

var A_arbace_core_print__init_part0_A_const_0 *lang.Var

var A_arbace_core_print__init_part0_A_const_1 any

var A_arbace_core_print__init_part0_A_const_2 *lang.Var

var A_arbace_core_print__init_part0_A_const_3 *lang.Var

var A_arbace_core_print__init_part0_A_const_4 any

var A_arbace_core_print__init_part0_A_const_5 *lang.Var

var A_arbace_core_print__init_part0_A_const_6 any

var A_arbace_core_print__init_part0_A_const_7 *lang.Var

var A_arbace_core_print__init_part0_A_const_8 any

var A_arbace_core_print__init_part0_A_const_9 *lang.Var

var A_arbace_core_print__init_part0_A_const_10 any

var A_arbace_core_print__init_part0_A_const_11 *lang.Var

var A_arbace_core_print__init_part0_A_const_12 any

var A_arbace_core_print__init_part0_A_const_13 *lang.Var

var A_arbace_core_print__init_part0_A_const_14 any

var A_arbace_core_print__init_part0_A_const_15 *lang.Var

var A_arbace_core_print__init_part0_A_const_16 any

var A_arbace_core_print__init_part0_A_const_17 *lang.Var

var A_arbace_core_print__init_part0_A_const_18 *lang.Keyword

var A_arbace_core_print__init_part0_A_const_19 *lang.Var

var A_arbace_core_print__init_part0_A_const_20 *lang.Var

var A_arbace_core_print__init_part0_A_const_21 any

var A_arbace_core_print__init_part0_A_const_22 *lang.Var

var A_arbace_core_print__init_part0_A_const_23 any

var A_arbace_core_print__init_part0_A_const_24 *lang.Var

var A_arbace_core_print__init_part0_A_const_25 any

var A_arbace_core_print__init_part0_A_const_26 *jrt.Class

var A_arbace_core_print__init_part0_A_const_27 *jrt.Class

var A_arbace_core_print__init_part0_A_const_28 *jrt.Class

var A_arbace_core_print__init_part0_A_const_29 *jrt.Class

var A_arbace_core_print__init_part0_A_const_30 *jrt.Class

var A_arbace_core_print__init_part0_A_const_31 *jrt.Class

var A_arbace_core_print__init_part0_A_const_32 *jrt.Class

var A_arbace_core_print__init_part0_A_const_33 *lang.Var

var A_arbace_core_print__init_part0_A_const_34 *jrt.Class

var A_arbace_core_print__init_part0_A_const_35 *jrt.Class

var A_arbace_core_print__init_part0_A_const_36 *jrt.Class

var A_arbace_core_print__init_part0_A_const_37 *jrt.Class

var A_arbace_core_print__init_part0_A_const_38 *jrt.Class

var A_arbace_core_print__init_part0_A_const_39 *jrt.Class

var A_arbace_core_print__init_part0_A_const_40 *jrt.Class

var A_arbace_core_print__init_part0_A_const_41 *jrt.Class

var A_arbace_core_print__init_part0_A_const_42 *lang.Var

var A_arbace_core_print__init_part0_A_const_43 any

var A_arbace_core_print__init_part0_A_const_44 any

var A_arbace_core_print__init_part0_A_const_45 *jrt.Class

var A_arbace_core_print__init_part0_A_const_46 *jrt.Class

var A_arbace_core_print__init_part0_A_const_47 *lang.Var

var A_arbace_core_print__init_part0_A_const_48 any

var A_arbace_core_print__init_part0_A_const_49 *lang.Var

var A_arbace_core_print__init_part0_A_const_50 any

var A_arbace_core_print__init_part0_A_const_51 *lang.Var

var A_arbace_core_print__init_part0_A_const_52 any

var A_arbace_core_print__init_part0_A_const_53 *lang.Var

var A_arbace_core_print__init_part0_A_const_54 any

var A_arbace_core_print__init_part0_A_const_55 *jrt.Class

var A_arbace_core_print__init_part0_A_const_56 *jrt.Class

var A_arbace_core_print__init_part0_A_const_57 *jrt.Class

var A_arbace_core_print__init_part0_A_const_58 *jrt.Class

var A_arbace_core_print__init_part0_A_const_59 *jrt.Class

var A_arbace_core_print__init_part0_A_const_60 *jrt.Class

var A_arbace_core_print__init_part0_A_const_61 *lang.Var

var A_arbace_core_print__init_part0_A_const_62 any

var A_arbace_core_print__init_part0_A_const_63 any

var A_arbace_core_print__init_part0_A_const_64 *jrt.Class

var A_arbace_core_print__init_part0_A_const_65 *jrt.Class

var A_arbace_core_print__init_part0_A_const_66 *jrt.Class

var A_arbace_core_print__init_part0_A_const_67 *jrt.Class

var A_arbace_core_print__init_part0_A_const_68 *jrt.Class

var A_arbace_core_print__init_part0_A_const_69 *jrt.Class

var A_arbace_core_print__init_part0_A_const_70 *jrt.Class

var A_arbace_core_print__init_part0_A_const_71 *jrt.Class

var A_arbace_core_print__init_part0_A_const_72 *jrt.Class

var A_arbace_core_print__init_part0_A_const_73 *lang.Var

var A_arbace_core_print__init_part0_A_const_74 any

var A_arbace_core_print__init_part0_A_const_75 *jrt.Class

var A_arbace_core_print__init_part0_A_const_76 *jrt.Class

var A_arbace_core_print__init_part0_A_const_77 *jrt.Class

var A_arbace_core_print__init_part0_A_const_78 *lang.Var

var A_arbace_core_print__init_part0_A_const_79 any

var A_arbace_core_print__init_part0_A_const_80 *jrt.Class

var A_arbace_core_print__init_part0_A_const_81 *jrt.Class

var A_arbace_core_print__init_part0_A_const_82 *lang.Var

var A_arbace_core_print__init_part0_A_const_83 any

var A_arbace_core_print__init_part0_A_const_84 *lang.Var

var A_arbace_core_print__init_part0_A_const_85 any

var A_arbace_core_print__init_part0_A_const_86 *lang.Var

var A_arbace_core_print__init_part0_A_const_87 any

var A_arbace_core_print__init_part0_A_const_88 *jrt.Class

var A_arbace_core_print__init_part0_A_const_89 *jrt.Class

var A_arbace_core_print__init_part0_A_init jrt.ClassInit

func A_arbace_core_print__init_part0_A_Init() { if !A_arbace_core_print__init_part0_A_init.Done() { A_arbace_core_print__init_part0_A_init.Run(A_arbace_core_print__init_part0_A_clinit) } }

func A_arbace_core_print__init_part0_A_clinit() { A_arbace_core_print__init_part0_A_clinit_p0(); A_arbace_core_print__init_part0_A_clinit_p1(); A_arbace_core_print__init_part0_A_clinit_p2(); A_arbace_core_print__init_part0_A_clinit_p3(); A_arbace_core_print__init_part0_A_clinit_p4(); A_arbace_core_print__init_part0_A_clinit_p5(); A_arbace_core_print__init_part0_A_clinit_p6(); A_arbace_core_print__init_part0_A_clinit_p7() }

func A_arbace_core_print__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_core_print__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 116); A_arbace_core_print__init_part0_A_const_0 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[26]); A_arbace_core_print__init_part0_A_const_1 = A_arbace_core_print__init_part0_A_const_pool.A[27]; A_arbace_core_print__init_part0_A_const_2 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[28]); A_arbace_core_print__init_part0_A_const_3 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[29]); A_arbace_core_print__init_part0_A_const_4 = A_arbace_core_print__init_part0_A_const_pool.A[30]; A_arbace_core_print__init_part0_A_const_5 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[31]); A_arbace_core_print__init_part0_A_const_6 = A_arbace_core_print__init_part0_A_const_pool.A[32]; A_arbace_core_print__init_part0_A_const_7 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[33]); A_arbace_core_print__init_part0_A_const_8 = A_arbace_core_print__init_part0_A_const_pool.A[34]; A_arbace_core_print__init_part0_A_const_9 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[35]); A_arbace_core_print__init_part0_A_const_10 = A_arbace_core_print__init_part0_A_const_pool.A[36]; A_arbace_core_print__init_part0_A_const_11 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[37]) }

func A_arbace_core_print__init_part0_A_clinit_p1() { A_arbace_core_print__init_part0_A_const_12 = A_arbace_core_print__init_part0_A_const_pool.A[38]; A_arbace_core_print__init_part0_A_const_13 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[39]); A_arbace_core_print__init_part0_A_const_14 = A_arbace_core_print__init_part0_A_const_pool.A[40]; A_arbace_core_print__init_part0_A_const_15 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[41]); A_arbace_core_print__init_part0_A_const_16 = A_arbace_core_print__init_part0_A_const_pool.A[42]; A_arbace_core_print__init_part0_A_const_17 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[43]); A_arbace_core_print__init_part0_A_const_18 = lang.Keyword_Cast(A_arbace_core_print__init_part0_A_const_pool.A[44]); A_arbace_core_print__init_part0_A_const_19 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[45]); A_arbace_core_print__init_part0_A_const_20 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[46]); A_arbace_core_print__init_part0_A_const_21 = A_arbace_core_print__init_part0_A_const_pool.A[47]; A_arbace_core_print__init_part0_A_const_22 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[48]); A_arbace_core_print__init_part0_A_const_23 = A_arbace_core_print__init_part0_A_const_pool.A[49]; A_arbace_core_print__init_part0_A_const_24 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[50]) }

func A_arbace_core_print__init_part0_A_clinit_p2() { A_arbace_core_print__init_part0_A_const_25 = A_arbace_core_print__init_part0_A_const_pool.A[51]; A_arbace_core_print__init_part0_A_const_26 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[52]); A_arbace_core_print__init_part0_A_const_27 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[53]); A_arbace_core_print__init_part0_A_const_28 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[54]); A_arbace_core_print__init_part0_A_const_29 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[55]); A_arbace_core_print__init_part0_A_const_30 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[56]); A_arbace_core_print__init_part0_A_const_31 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[57]); A_arbace_core_print__init_part0_A_const_32 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[58]); A_arbace_core_print__init_part0_A_const_33 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[59]); A_arbace_core_print__init_part0_A_const_34 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[60]); A_arbace_core_print__init_part0_A_const_35 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[61]); A_arbace_core_print__init_part0_A_const_36 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[62]) }

func A_arbace_core_print__init_part0_A_clinit_p3() { A_arbace_core_print__init_part0_A_const_37 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[63]); A_arbace_core_print__init_part0_A_const_38 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[64]); A_arbace_core_print__init_part0_A_const_39 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[65]); A_arbace_core_print__init_part0_A_const_40 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[66]); A_arbace_core_print__init_part0_A_const_41 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[67]); A_arbace_core_print__init_part0_A_const_42 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[68]); A_arbace_core_print__init_part0_A_const_43 = A_arbace_core_print__init_part0_A_const_pool.A[69]; A_arbace_core_print__init_part0_A_const_44 = A_arbace_core_print__init_part0_A_const_pool.A[70]; A_arbace_core_print__init_part0_A_const_45 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[71]); A_arbace_core_print__init_part0_A_const_46 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[72]); A_arbace_core_print__init_part0_A_const_47 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[73]); A_arbace_core_print__init_part0_A_const_48 = A_arbace_core_print__init_part0_A_const_pool.A[74] }

func A_arbace_core_print__init_part0_A_clinit_p4() { A_arbace_core_print__init_part0_A_const_49 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[75]); A_arbace_core_print__init_part0_A_const_50 = A_arbace_core_print__init_part0_A_const_pool.A[76]; A_arbace_core_print__init_part0_A_const_51 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[77]); A_arbace_core_print__init_part0_A_const_52 = A_arbace_core_print__init_part0_A_const_pool.A[78]; A_arbace_core_print__init_part0_A_const_53 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[79]); A_arbace_core_print__init_part0_A_const_54 = A_arbace_core_print__init_part0_A_const_pool.A[80]; A_arbace_core_print__init_part0_A_const_55 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[81]); A_arbace_core_print__init_part0_A_const_56 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[82]); A_arbace_core_print__init_part0_A_const_57 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[83]); A_arbace_core_print__init_part0_A_const_58 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[84]); A_arbace_core_print__init_part0_A_const_59 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[85]); A_arbace_core_print__init_part0_A_const_60 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[86]) }

func A_arbace_core_print__init_part0_A_clinit_p5() { A_arbace_core_print__init_part0_A_const_61 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[87]); A_arbace_core_print__init_part0_A_const_62 = A_arbace_core_print__init_part0_A_const_pool.A[88]; A_arbace_core_print__init_part0_A_const_63 = A_arbace_core_print__init_part0_A_const_pool.A[89]; A_arbace_core_print__init_part0_A_const_64 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[90]); A_arbace_core_print__init_part0_A_const_65 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[91]); A_arbace_core_print__init_part0_A_const_66 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[92]); A_arbace_core_print__init_part0_A_const_67 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[93]); A_arbace_core_print__init_part0_A_const_68 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[94]); A_arbace_core_print__init_part0_A_const_69 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[95]); A_arbace_core_print__init_part0_A_const_70 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[96]); A_arbace_core_print__init_part0_A_const_71 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[97]); A_arbace_core_print__init_part0_A_const_72 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[98]) }

func A_arbace_core_print__init_part0_A_clinit_p6() { A_arbace_core_print__init_part0_A_const_73 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[99]); A_arbace_core_print__init_part0_A_const_74 = A_arbace_core_print__init_part0_A_const_pool.A[100]; A_arbace_core_print__init_part0_A_const_75 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[101]); A_arbace_core_print__init_part0_A_const_76 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[102]); A_arbace_core_print__init_part0_A_const_77 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[103]); A_arbace_core_print__init_part0_A_const_78 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[104]); A_arbace_core_print__init_part0_A_const_79 = A_arbace_core_print__init_part0_A_const_pool.A[105]; A_arbace_core_print__init_part0_A_const_80 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[106]); A_arbace_core_print__init_part0_A_const_81 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[107]); A_arbace_core_print__init_part0_A_const_82 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[108]); A_arbace_core_print__init_part0_A_const_83 = A_arbace_core_print__init_part0_A_const_pool.A[109]; A_arbace_core_print__init_part0_A_const_84 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[110]); A_arbace_core_print__init_part0_A_const_85 = A_arbace_core_print__init_part0_A_const_pool.A[111] }

func A_arbace_core_print__init_part0_A_clinit_p7() { A_arbace_core_print__init_part0_A_const_86 = lang.Var_Cast(A_arbace_core_print__init_part0_A_const_pool.A[112]); A_arbace_core_print__init_part0_A_const_87 = A_arbace_core_print__init_part0_A_const_pool.A[113]; A_arbace_core_print__init_part0_A_const_88 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[114]); A_arbace_core_print__init_part0_A_const_89 = jrt.Class_Cast(A_arbace_core_print__init_part0_A_const_pool.A[115]) }

func A_arbace_core_print__init_part0_A_New() *A_arbace_core_print__init_part0_A { A_arbace_core_print__init_part0_A_Init(); t := &A_arbace_core_print__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_core_print__init_part0_A) Ctor() {}

func (t *A_arbace_core_print__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_print__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_core_print__init_part0_A_class }

func (t *A_arbace_core_print__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_print__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_print__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_print__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_print__init_part0_A); return ok }

func A_arbace_core_print__init_part0_A_Cast(x any) *A_arbace_core_print__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_print__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_print__init_part0_A_class)) }; return v }



type A_arbace_core_print__init_part1_A struct{ jrt.Object }

var A_arbace_core_print__init_part1_A_const_pool *jrt.RefArray

var A_arbace_core_print__init_part1_A_const_0 *lang.Var

var A_arbace_core_print__init_part1_A_const_1 *jrt.Class

var A_arbace_core_print__init_part1_A_const_2 *lang.Var

var A_arbace_core_print__init_part1_A_const_3 *jrt.Class

var A_arbace_core_print__init_part1_A_const_4 *lang.Var

var A_arbace_core_print__init_part1_A_const_5 any

var A_arbace_core_print__init_part1_A_const_6 *lang.Var

var A_arbace_core_print__init_part1_A_const_7 any

var A_arbace_core_print__init_part1_A_const_8 *lang.Var

var A_arbace_core_print__init_part1_A_const_9 *jrt.Class

var A_arbace_core_print__init_part1_A_init jrt.ClassInit

func A_arbace_core_print__init_part1_A_Init() { if !A_arbace_core_print__init_part1_A_init.Done() { A_arbace_core_print__init_part1_A_init.Run(A_arbace_core_print__init_part1_A_clinit) } }

func A_arbace_core_print__init_part1_A_clinit() { jrt.StartCheck(); A_arbace_core_print__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_82, 18); var tmp1 *lang.Var; A_arbace_core_print__init_part0_A_Init(); tmp1 = A_arbace_core_print__init_part0_A_const_19; A_arbace_core_print__init_part1_A_const_0 = tmp1; var tmp2 *jrt.Class; A_arbace_core_print__init_part0_A_Init(); tmp2 = A_arbace_core_print__init_part0_A_const_89; A_arbace_core_print__init_part1_A_const_1 = tmp2; var tmp3 *lang.Var; A_arbace_core_print__init_part0_A_Init(); tmp3 = A_arbace_core_print__init_part0_A_const_17; A_arbace_core_print__init_part1_A_const_2 = tmp3; A_arbace_core_print__init_part1_A_const_3 = jrt.Class_Cast(A_arbace_core_print__init_part1_A_const_pool.A[11]); A_arbace_core_print__init_part1_A_const_4 = lang.Var_Cast(A_arbace_core_print__init_part1_A_const_pool.A[12]); A_arbace_core_print__init_part1_A_const_5 = A_arbace_core_print__init_part1_A_const_pool.A[13]; A_arbace_core_print__init_part1_A_const_6 = lang.Var_Cast(A_arbace_core_print__init_part1_A_const_pool.A[14]); A_arbace_core_print__init_part1_A_const_7 = A_arbace_core_print__init_part1_A_const_pool.A[15]; A_arbace_core_print__init_part1_A_const_8 = lang.Var_Cast(A_arbace_core_print__init_part1_A_const_pool.A[16]); A_arbace_core_print__init_part1_A_const_9 = jrt.Class_Cast(A_arbace_core_print__init_part1_A_const_pool.A[17]) }

func A_arbace_core_print__init_part1_A_New() *A_arbace_core_print__init_part1_A { A_arbace_core_print__init_part1_A_Init(); t := &A_arbace_core_print__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_core_print__init_part1_A) Ctor() {}

func (t *A_arbace_core_print__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_print__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_core_print__init_part1_A_class }

func (t *A_arbace_core_print__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_print__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_print__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_print__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_print__init_part1_A); return ok }

func A_arbace_core_print__init_part1_A_Cast(x any) *A_arbace_core_print__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_print__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_print__init_part1_A_class)) }; return v }
