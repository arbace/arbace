//line j2g_classes.ae:1
package aot_arbace_core_print

import "arbace/jrt"


func A_arbace_core_print__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_core_print__init_A_Load__O()}; return nil }

func A_arbace_core_print__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_print__init_A_New()}; return nil }

var A_arbace_core_print__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_core_print__init_A_invoke, New: A_arbace_core_print__init_A_new}

var A_arbace_core_print__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core_print__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_core_print.A_arbace_core_print__init_A", Source: "core_print.ae"})

func init() { i := A_arbace_core_print__init_A_class.Info(); i.IsInstance = A_arbace_core_print__init_A_InstanceOf; i.Table = A_arbace_core_print__init_A_members }

var A_arbace_core_print__init_part0_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core_print__init$part0", Modifiers: 24, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_print__init_A_class, Simple: "part0", Go: "arbace/aot_arbace_core_print.A_arbace_core_print__init_part0_A", Source: "core_print.ae"})

func init() { i := A_arbace_core_print__init_part0_A_class.Info(); i.IsInstance = A_arbace_core_print__init_part0_A_InstanceOf; i.Init = A_arbace_core_print__init_part0_A_Init }

var A_arbace_core_print__init_part1_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core_print__init$part1", Modifiers: 24, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_print__init_A_class, Simple: "part1", Go: "arbace/aot_arbace_core_print.A_arbace_core_print__init_part1_A", Source: "core_print.ae"})

func init() { i := A_arbace_core_print__init_part1_A_class.Info(); i.IsInstance = A_arbace_core_print__init_part1_A_InstanceOf; i.Init = A_arbace_core_print__init_part1_A_Init }
