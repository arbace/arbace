//line a2g_strings.ae:1
package aot_arbace_core_print

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn3,dockn5,addedkn7,dynamickn4,linekn6,columnkn4,filekn7,privatekn8,arglistskn3,tagyn6,Stringyn9,print-oneyn8,sequenceyn6,Writeryn1,okn7,defaultyn10,print-argsyn3,repyn6,prefixyn3,kvsyn1,wyn1,myn5,namedyn18,arbace.lang.IDerefyn17,StackTraceElementyn9,Throwablev11,arbace.core5,in-nsR0,v11,arbace.core20,*warn-on-reflection*v11,arbace.core14,*print-length*m12,R1,s434,*print-length* controls how many items of each collection the\n  printer will print. If it is bound to logical false, there is no\n  limit. Otherwise, it must be bound to an integer indicating the maximum\n  number of items of each collection to print. If a collection contains\n  more items, the printer will print items up to the limit followed by\n  '...' to represent the remaining items. The root binding is nil\n  indicating no limit.R2,s3,1.0R3,TR4,i16,R5,i1,R6,s20,arbace/core_print.aev11,arbace.core13,*print-level*m12,R1,s527,*print-level* controls how many levels deep the printer will\n  print nested objects. If it is bound to logical false, there is no\n  limit. Otherwise, it must be bound to an integer indicating the maximum\n  level to print. Each argument to print is at level 0; if an argument is a\n  collection, its items are at level 1; and so on. If an object is a\n  collection and is at a level greater than or equal to the value bound to\n  *print-level*, the printer prints '#' to represent it. The root binding\n  is nil indicating no limit.R2,s3,1.0R3,TR4,i27,R5,i1,R6,s20,arbace/core_print.aev11,arbace.core20,*verbose-defrecords*m8,R3,TR4,i39,R5,i1,R6,s20,arbace/core_print.aev11,arbace.core22,*print-namespace-maps*m12,R1,s146,*print-namespace-maps* controls whether the printer will print\n  namespace map literal syntax. It defaults to false, but the REPL binds\n  to true.R2,s3,1.9R3,TR4,i41,R5,i1,R6,s20,arbace/core_print.aev11,arbace.core16,print-sequentialm10,R7,TR8,L1,V6,Myn5,beginm2,R9,R10,R11,Myn3,sepm2,R9,R10,Myn3,endm2,R9,R10,R12,Myn1,wm2,R9,R13,R4,i48,R5,i1,R6,s20,arbace/core_print.aev11,arbace.core10,print-metam10,R7,TR8,L1,V2,R14,Myn1,wm2,R9,R13,R4,i72,R5,i1,R6,s20,arbace/core_print.aev11,arbace.core12,print-simplem8,R8,L1,V2,R14,Myn1,wm2,R9,R13,R4,i83,R5,i1,R6,s20,arbace/core_print.aev11,arbace.core12,print-methodR15,v11,arbace.core9,print-dupv11,arbace.core10,print-ctorm8,R8,L1,V3,R14,R16,Myn1,wm2,R9,R13,R4,i97,R5,i1,R6,s20,arbace/core_print.aev11,arbace.core19,print-tagged-objectm10,R7,TR8,L1,V3,R14,R17,Myn1,wm2,R9,R13,R4,i104,R5,i1,R6,s20,arbace/core_print.aev11,arbace.core12,print-objectm10,R7,TR8,L1,V2,R14,Myn1,wm2,R9,R13,R4,i117,R5,i1,R6,s20,arbace/core_print.aeC16,java.lang.ObjectC19,arbace.lang.KeywordC16,java.lang.NumberC16,java.lang.DoubleC15,java.lang.FloatC14,arbace.lang.Fnv11,arbace.core13,prefer-methodC33,arbace.lang.IPersistentCollectionC13,java.util.MapC20,java.util.CollectionC17,java.lang.BooleanC18,arbace.lang.SymbolC15,arbace.lang.VarC16,arbace.lang.ISeqC27,arbace.lang.IPersistentListv11,arbace.core18,char-escape-stringm14,c10,s2,\\nc9,s2,\\tc13,s2,\\rc34,s2,\\\"c92,s2,\\\\c12,s2,\\fc8,s2,\\bm12,R9,C16,java.lang.StringR1,s45,Returns escape string for char or nil if noneR2,s3,1.0R4,i198,R5,i1,R6,s20,arbace/core_print.aeC16,java.lang.StringC29,arbace.lang.IPersistentVectorv11,arbace.core16,print-prefix-mapm10,R7,TR8,L1,V4,R18,R19,R11,R20,R4,i227,R5,i1,R6,s20,arbace/core_print.aev11,arbace.core9,print-mapm10,R7,TR8,L1,V3,R21,R11,R20,R4,i236,R5,i1,R6,s20,arbace/core_print.aev11,arbace.core8,strip-nsm10,R7,TR8,L1,V1,R22,R4,i239,R5,i1,R6,s20,arbace/core_print.aev11,arbace.core7,lift-nsm12,R7,TR8,L1,V1,R21,R1,s59,Returns [lifted-ns lifted-kvs] or nil if m can't be lifted.R4,i245,R5,i1,R6,s20,arbace/core_print.aeC26,arbace.lang.IPersistentMapC22,java.util.RandomAccessC14,java.util.ListC13,java.util.SetC19,arbace.lang.IRecordC26,arbace.lang.IPersistentSetv11,arbace.core16,char-name-stringm12,c10,s7,newlinec9,s3,tabc32,s5,spacec8,s9,backspacec12,s8,formfeedc13,s6,returnm12,R9,C16,java.lang.StringR1,s43,Returns name string for char or nil if noneR2,s3,1.0R4,i340,R5,i1,R6,s20,arbace/core_print.aeC19,java.lang.CharacterC14,java.lang.LongC17,arbace.lang.RatioC20,java.math.BigDecimalC18,arbace.lang.BigIntC29,arbace.lang.PersistentHashMapC29,arbace.lang.PersistentHashSetC28,arbace.lang.PersistentVectorC34,arbace.lang.LazilyPersistentVectorv11,arbace.core21,primitives-classnamesm6,R4,i370,R5,i1,R6,s20,arbace/core_print.aeC15,java.lang.ClassC23,java.util.regex.PatternC21,arbace.lang.Namespacev11,arbace.core12,deref-as-mapm10,R7,TR8,L1,V1,Myn1,om2,R9,R23,R4,i436,R5,i1,R6,s20,arbace/core_print.aeC18,arbace.lang.IDerefC27,java.lang.StackTraceElementv11,arbace.core22,StackTraceElement->vecm12,R8,L1,V1,Myn1,om2,R9,R24,R1,s82,Constructs a data representation for a StackTraceElement: [class method file line]R2,s3,1.9R4,i465,R5,i1,R6,s20,arbace/core_print.aev11,arbace.core14,Throwable->mapm12,R8,L1,V1,Myn1,om2,R9,R25,R1,s348,Constructs a data representation for a Throwable with keys:\n    :cause - root cause message\n    :phase - error phase\n    :via - cause chain, with cause keys:\n             :type - exception class symbol\n             :message - exception message\n             :data - ex-data\n             :at - top stack element\n    :trace - root cause stack elementsR2,s3,1.7R4,i471,R5,i1,R6,s20,arbace/core_print.aev11,arbace.core15,print-throwablem10,R7,TR8,L1,V2,Myn1,om2,R9,R25,Myn1,wm2,R9,R13,R4,i507,R5,i1,R6,s20,arbace/core_print.aeC19,java.lang.ThrowableC25,arbace.lang.TaggedLiteral")

var Lit_1 *jrt.String = jrt.Intern("java.io.Writer")

var Lit_2 *jrt.String = jrt.Intern("arbace.core$print_sequential")

var Lit_3 *jrt.String = jrt.Intern("arbace.core$print_meta")

var Lit_4 *jrt.String = jrt.Intern("arbace.core$print_simple")

var Lit_5 *jrt.String = jrt.Intern("arbace.core$eval1769000030$fn__1769000031")

var Lit_6 *jrt.String = jrt.Intern("arbace.core$eval1769000036$fn__1769000037")

var Lit_7 *jrt.String = jrt.Intern("arbace.core$eval1769000040$fn__1769000041")

var Lit_8 *jrt.String = jrt.Intern("arbace.core$print_ctor")

var Lit_9 *jrt.String = jrt.Intern("arbace.core$print_tagged_object")

var Lit_10 *jrt.String = jrt.Intern("arbace.core$print_object")

var Lit_11 *jrt.String = jrt.Intern("arbace.core$eval1769000047$fn__1769000048")

var Lit_12 *jrt.String = jrt.Intern("arbace.core$eval1769000051$fn__1769000052")

var Lit_13 *jrt.String = jrt.Intern("arbace.core$eval1769000055$fn__1769000056")

var Lit_14 *jrt.String = jrt.Intern("arbace.core$eval1769000059$fn__1769000060")

var Lit_15 *jrt.String = jrt.Intern("arbace.core$eval1769000063$fn__1769000064")

var Lit_16 *jrt.String = jrt.Intern("arbace.core$eval1769000067$fn__1769000068")

var Lit_17 *jrt.String = jrt.Intern("arbace.core$eval1769000071$fn__1769000072")

var Lit_18 *jrt.String = jrt.Intern("arbace.core$eval1769000077$fn__1769000078")

var Lit_19 *jrt.String = jrt.Intern("arbace.core$eval1769000089$fn__1769000090")

var Lit_20 *jrt.String = jrt.Intern("arbace.core$eval1769000093$fn__1769000094")

var Lit_21 *jrt.String = jrt.Intern("arbace.core$eval1769000097$fn__1769000098")

var Lit_22 *jrt.String = jrt.Intern("arbace.core$eval1769000101$fn__1769000102")

var Lit_23 *jrt.String = jrt.Intern("arbace.core$eval1769000105$fn__1769000106")

var Lit_24 *jrt.String = jrt.Intern("arbace.core$eval1769000109$fn__1769000110")

var Lit_25 *jrt.String = jrt.Intern("arbace.core$eval1769000113$fn__1769000114")

var Lit_26 *jrt.String = jrt.Intern("arbace.core$eval1769000117$fn__1769000118")

var Lit_27 *jrt.String = jrt.Intern("arbace.core$eval1769000121$fn__1769000122")

var Lit_28 *jrt.String = jrt.Intern("arbace.core$eval1769000135$fn__1769000136")

var Lit_29 *jrt.String = jrt.Intern("arbace.core$eval1769000141$fn__1769000142")

var Lit_30 *jrt.String = jrt.Intern("arbace.core$eval1769000147$fn__1769000148")

var Lit_31 *jrt.String = jrt.Intern("arbace.core$eval1769000151$fn__1769000152")

var Lit_32 *jrt.String = jrt.Intern("arbace.core$eval1769000155$fn__1769000156")

var Lit_33 *jrt.String = jrt.Intern("arbace.core$print_prefix_map")

var Lit_34 *jrt.String = jrt.Intern("arbace.core$print_map")

var Lit_35 *jrt.String = jrt.Intern("arbace.core$strip_ns")

var Lit_36 *jrt.String = jrt.Intern("arbace.core$lift_ns")

var Lit_37 *jrt.String = jrt.Intern("arbace.core$eval1769000188$fn__1769000189")

var Lit_38 *jrt.String = jrt.Intern("arbace.core$eval1769000197$fn__1769000198")

var Lit_39 *jrt.String = jrt.Intern("arbace.core$eval1769000203$fn__1769000204")

var Lit_40 *jrt.String = jrt.Intern("arbace.core$eval1769000215$fn__1769000216")

var Lit_41 *jrt.String = jrt.Intern("arbace.core$eval1769000219$fn__1769000220")

var Lit_42 *jrt.String = jrt.Intern("arbace.core$eval1769000223$fn__1769000224")

var Lit_43 *jrt.String = jrt.Intern("arbace.core$eval1769000227$fn__1769000228")

var Lit_44 *jrt.String = jrt.Intern("arbace.core$eval1769000231$fn__1769000232")

var Lit_45 *jrt.String = jrt.Intern("arbace.core$eval1769000235$fn__1769000236")

var Lit_46 *jrt.String = jrt.Intern("arbace.core$eval1769000251$fn__1769000252")

var Lit_47 *jrt.String = jrt.Intern("arbace.core$eval1769000255$fn__1769000256")

var Lit_48 *jrt.String = jrt.Intern("arbace.core$eval1769000259$fn__1769000260")

var Lit_49 *jrt.String = jrt.Intern("arbace.core$eval1769000263$fn__1769000264")

var Lit_50 *jrt.String = jrt.Intern("arbace.core$eval1769000267$fn__1769000268")

var Lit_51 *jrt.String = jrt.Intern("arbace.core$eval1769000271$fn__1769000272")

var Lit_52 *jrt.String = jrt.Intern("arbace.core$eval1769000275$fn__1769000276")

var Lit_53 *jrt.String = jrt.Intern("arbace.core$eval1769000279$fn__1769000280")

var Lit_54 *jrt.String = jrt.Intern("arbace.core$eval1769000283$fn__1769000284")

var Lit_55 *jrt.String = jrt.Intern("arbace.core$eval1769000287$fn__1769000288")

var Lit_56 *jrt.String = jrt.Intern("arbace.core$eval1769000291$fn__1769000292")

var Lit_57 *jrt.String = jrt.Intern("arbace.core$eval1769000295$fn__1769000296")

var Lit_58 *jrt.String = jrt.Intern("Float/TYPE")

var Lit_59 *jrt.String = jrt.Intern("Integer/TYPE")

var Lit_60 *jrt.String = jrt.Intern("Long/TYPE")

var Lit_61 *jrt.String = jrt.Intern("Boolean/TYPE")

var Lit_62 *jrt.String = jrt.Intern("Character/TYPE")

var Lit_63 *jrt.String = jrt.Intern("Double/TYPE")

var Lit_64 *jrt.String = jrt.Intern("Byte/TYPE")

var Lit_65 *jrt.String = jrt.Intern("Short/TYPE")

var Lit_66 *jrt.String = jrt.Intern("arbace.core$eval1769000299$fn__1769000300")

var Lit_67 *jrt.String = jrt.Intern("arbace.core$eval1769000303$fn__1769000304")

var Lit_68 *jrt.String = jrt.Intern("arbace.core$eval1769000307$fn__1769000308")

var Lit_69 *jrt.String = jrt.Intern("arbace.core$eval1769000311$fn__1769000312")

var Lit_70 *jrt.String = jrt.Intern("arbace.core$eval1769000315$fn__1769000316")

var Lit_71 *jrt.String = jrt.Intern("arbace.core$eval1769000332$fn__1769000333")

var Lit_72 *jrt.String = jrt.Intern("arbace.core$eval1769000336$fn__1769000337")

var Lit_73 *jrt.String = jrt.Intern("arbace.core$deref_as_map")

var Lit_74 *jrt.String = jrt.Intern("arbace.core$eval1769000346$fn__1769000347")

var Lit_75 *jrt.String = jrt.Intern("arbace.core$eval1769000350$fn__1769000351")

var Lit_76 *jrt.String = jrt.Intern("arbace.core$StackTraceElement__GT_vec")

var Lit_77 *jrt.String = jrt.Intern("arbace.core$Throwable__GT_map")

var Lit_78 *jrt.String = jrt.Intern("arbace.core$print_throwable")

var Lit_79 *jrt.String = jrt.Intern("arbace.core$eval1769000374$fn__1769000375")

var Lit_80 *jrt.String = jrt.Intern("arbace.core$eval1769000378$fn__1769000379")

var Lit_81 *jrt.String = jrt.Intern("arbace.core$eval1769000382$fn__1769000383")

var Lit_82 *jrt.String = jrt.Intern("kn7,privatekn4,linekn6,columnkn4,filekn3,tagkn8,arglistsyn8,flush-fnyn8,close-fnyn10,autoflush?kn3,dockn5,addedC29,arbace.lang.ReaderConditionalv11,arbace.core17,print-initializedm8,R0,TR1,i559,R2,i1,R3,s20,arbace/core_print.aev11,arbace.core14,PrintWriter-onm14,R4,C19,java.io.PrintWriterR5,L2,V2,R6,R7,V3,R6,R7,R8,R9,s306,implements java.io.PrintWriter given flush-fn, which will be called\n  when .flush() is called, with a string built up since the last call to .flush().\n  if not nil, close-fn will be called with no arguments when .close is called.\n  autoflush? determines if the PrintWriter will autoflush, false by default.R10,s4,1.10R1,i561,R2,i1,R3,s20,arbace/core_print.aev11,arbace.core15,get-proxy-classC14,java.io.Writer")

var Lit_83 *jrt.String = jrt.Intern("arbace.core$eval1769000386$fn__1769000387")

var Lit_84 *jrt.String = jrt.Intern("arbace.core$PrintWriter_on")
