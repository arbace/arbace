//line a2g_strings.ae:1
package aot_arbace_core_print

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("in-ns")

var Lit_2 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_3 *jrt.String = jrt.Intern("*print-length*")

var Lit_4 *jrt.String = jrt.Intern("doc")

var Lit_5 *jrt.String = jrt.Intern("*print-length* controls how many items of each collection the\n  printer will print. If it is bound to logical false, there is no\n  limit. Otherwise, it must be bound to an integer indicating the maximum\n  number of items of each collection to print. If a collection contains\n  more items, the printer will print items up to the limit followed by\n  '...' to represent the remaining items. The root binding is nil\n  indicating no limit.")

var Lit_6 *jrt.String = jrt.Intern("added")

var Lit_7 *jrt.String = jrt.Intern("1.0")

var Lit_8 *jrt.String = jrt.Intern("dynamic")

var Lit_9 *jrt.String = jrt.Intern("line")

var Lit_10 *jrt.String = jrt.Intern("column")

var Lit_11 *jrt.String = jrt.Intern("file")

var Lit_12 *jrt.String = jrt.Intern("arbace/core_print.ae")

var Lit_13 *jrt.String = jrt.Intern("*print-level*")

var Lit_14 *jrt.String = jrt.Intern("*print-level* controls how many levels deep the printer will\n  print nested objects. If it is bound to logical false, there is no\n  limit. Otherwise, it must be bound to an integer indicating the maximum\n  level to print. Each argument to print is at level 0; if an argument is a\n  collection, its items are at level 1; and so on. If an object is a\n  collection and is at a level greater than or equal to the value bound to\n  *print-level*, the printer prints '#' to represent it. The root binding\n  is nil indicating no limit.")

var Lit_15 *jrt.String = jrt.Intern("*verbose-defrecords*")

var Lit_16 *jrt.String = jrt.Intern("*print-namespace-maps*")

var Lit_17 *jrt.String = jrt.Intern("*print-namespace-maps* controls whether the printer will print\n  namespace map literal syntax. It defaults to false, but the REPL binds\n  to true.")

var Lit_18 *jrt.String = jrt.Intern("1.9")

var Lit_19 *jrt.String = jrt.Intern("print-sequential")

var Lit_20 *jrt.String = jrt.Intern("private")

var Lit_21 *jrt.String = jrt.Intern("arglists")

var Lit_22 *jrt.String = jrt.Intern("begin")

var Lit_23 *jrt.String = jrt.Intern("tag")

var Lit_24 *jrt.String = jrt.Intern("String")

var Lit_25 *jrt.String = jrt.Intern("print-one")

var Lit_26 *jrt.String = jrt.Intern("sep")

var Lit_27 *jrt.String = jrt.Intern("end")

var Lit_28 *jrt.String = jrt.Intern("sequence")

var Lit_29 *jrt.String = jrt.Intern("w")

var Lit_30 *jrt.String = jrt.Intern("Writer")

var Lit_31 *jrt.String = jrt.Intern("print-meta")

var Lit_32 *jrt.String = jrt.Intern("o")

var Lit_33 *jrt.String = jrt.Intern("print-simple")

var Lit_34 *jrt.String = jrt.Intern("print-method")

var Lit_35 *jrt.String = jrt.Intern("default")

var Lit_36 *jrt.String = jrt.Intern("print-dup")

var Lit_37 *jrt.String = jrt.Intern("print-ctor")

var Lit_38 *jrt.String = jrt.Intern("print-args")

var Lit_39 *jrt.String = jrt.Intern("print-tagged-object")

var Lit_40 *jrt.String = jrt.Intern("rep")

var Lit_41 *jrt.String = jrt.Intern("print-object")

var Lit_42 *jrt.String = jrt.Intern("java.lang.Object")

var Lit_43 *jrt.String = jrt.Intern("arbace.lang.Keyword")

var Lit_44 *jrt.String = jrt.Intern("java.lang.Number")

var Lit_45 *jrt.String = jrt.Intern("java.lang.Double")

var Lit_46 *jrt.String = jrt.Intern("java.lang.Float")

var Lit_47 *jrt.String = jrt.Intern("arbace.lang.Fn")

var Lit_48 *jrt.String = jrt.Intern("prefer-method")

var Lit_49 *jrt.String = jrt.Intern("arbace.lang.IPersistentCollection")

var Lit_50 *jrt.String = jrt.Intern("java.util.Map")

var Lit_51 *jrt.String = jrt.Intern("java.util.Collection")

var Lit_52 *jrt.String = jrt.Intern("java.lang.Boolean")

var Lit_53 *jrt.String = jrt.Intern("arbace.lang.Symbol")

var Lit_54 *jrt.String = jrt.Intern("arbace.lang.Var")

var Lit_55 *jrt.String = jrt.Intern("arbace.lang.ISeq")

var Lit_56 *jrt.String = jrt.Intern("arbace.lang.IPersistentList")

var Lit_57 *jrt.String = jrt.Intern("char-escape-string")

var Lit_58 *jrt.String = jrt.Intern("\\n")

var Lit_59 *jrt.String = jrt.Intern("\\t")

var Lit_60 *jrt.String = jrt.Intern("\\r")

var Lit_61 *jrt.String = jrt.Intern("\\\"")

var Lit_62 *jrt.String = jrt.Intern("\\\\")

var Lit_63 *jrt.String = jrt.Intern("\\f")

var Lit_64 *jrt.String = jrt.Intern("\\b")

var Lit_65 *jrt.String = jrt.Intern("java.lang.String")

var Lit_66 *jrt.String = jrt.Intern("Returns escape string for char or nil if none")

var Lit_67 *jrt.String = jrt.Intern("arbace.lang.IPersistentVector")

var Lit_68 *jrt.String = jrt.Intern("print-prefix-map")

var Lit_69 *jrt.String = jrt.Intern("prefix")

var Lit_70 *jrt.String = jrt.Intern("kvs")

var Lit_71 *jrt.String = jrt.Intern("print-map")

var Lit_72 *jrt.String = jrt.Intern("m")

var Lit_73 *jrt.String = jrt.Intern("strip-ns")

var Lit_74 *jrt.String = jrt.Intern("named")

var Lit_75 *jrt.String = jrt.Intern("lift-ns")

var Lit_76 *jrt.String = jrt.Intern("Returns [lifted-ns lifted-kvs] or nil if m can't be lifted.")

var Lit_77 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_78 *jrt.String = jrt.Intern("java.util.RandomAccess")

var Lit_79 *jrt.String = jrt.Intern("java.util.List")

var Lit_80 *jrt.String = jrt.Intern("java.util.Set")

var Lit_81 *jrt.String = jrt.Intern("arbace.lang.IRecord")

var Lit_82 *jrt.String = jrt.Intern("arbace.lang.IPersistentSet")

var Lit_83 *jrt.String = jrt.Intern("char-name-string")

var Lit_84 *jrt.String = jrt.Intern("newline")

var Lit_85 *jrt.String = jrt.Intern("tab")

var Lit_86 *jrt.String = jrt.Intern("space")

var Lit_87 *jrt.String = jrt.Intern("backspace")

var Lit_88 *jrt.String = jrt.Intern("formfeed")

var Lit_89 *jrt.String = jrt.Intern("return")

var Lit_90 *jrt.String = jrt.Intern("Returns name string for char or nil if none")

var Lit_91 *jrt.String = jrt.Intern("java.lang.Character")

var Lit_92 *jrt.String = jrt.Intern("java.lang.Long")

var Lit_93 *jrt.String = jrt.Intern("arbace.lang.Ratio")

var Lit_94 *jrt.String = jrt.Intern("java.math.BigDecimal")

var Lit_95 *jrt.String = jrt.Intern("arbace.lang.BigInt")

var Lit_96 *jrt.String = jrt.Intern("arbace.lang.PersistentHashMap")

var Lit_97 *jrt.String = jrt.Intern("arbace.lang.PersistentHashSet")

var Lit_98 *jrt.String = jrt.Intern("arbace.lang.PersistentVector")

var Lit_99 *jrt.String = jrt.Intern("arbace.lang.LazilyPersistentVector")

var Lit_100 *jrt.String = jrt.Intern("primitives-classnames")

var Lit_101 *jrt.String = jrt.Intern("java.lang.Class")

var Lit_102 *jrt.String = jrt.Intern("java.util.regex.Pattern")

var Lit_103 *jrt.String = jrt.Intern("arbace.lang.Namespace")

var Lit_104 *jrt.String = jrt.Intern("deref-as-map")

var Lit_105 *jrt.String = jrt.Intern("arbace.lang.IDeref")

var Lit_106 *jrt.String = jrt.Intern("java.lang.StackTraceElement")

var Lit_107 *jrt.String = jrt.Intern("StackTraceElement->vec")

var Lit_108 *jrt.String = jrt.Intern("StackTraceElement")

var Lit_109 *jrt.String = jrt.Intern("Constructs a data representation for a StackTraceElement: [class method file line]")

var Lit_110 *jrt.String = jrt.Intern("Throwable->map")

var Lit_111 *jrt.String = jrt.Intern("Throwable")

var Lit_112 *jrt.String = jrt.Intern("Constructs a data representation for a Throwable with keys:\n    :cause - root cause message\n    :phase - error phase\n    :via - cause chain, with cause keys:\n             :type - exception class symbol\n             :message - exception message\n             :data - ex-data\n             :at - top stack element\n    :trace - root cause stack elements")

var Lit_113 *jrt.String = jrt.Intern("1.7")

var Lit_114 *jrt.String = jrt.Intern("print-throwable")

var Lit_115 *jrt.String = jrt.Intern("java.lang.Throwable")

var Lit_116 *jrt.String = jrt.Intern("arbace.lang.TaggedLiteral")

var Lit_117 *jrt.String = jrt.Intern("arbace.lang.ReaderConditional")

var Lit_118 *jrt.String = jrt.Intern("print-initialized")

var Lit_119 *jrt.String = jrt.Intern("PrintWriter-on")

var Lit_120 *jrt.String = jrt.Intern("java.io.PrintWriter")

var Lit_121 *jrt.String = jrt.Intern("flush-fn")

var Lit_122 *jrt.String = jrt.Intern("close-fn")

var Lit_123 *jrt.String = jrt.Intern("autoflush?")

var Lit_124 *jrt.String = jrt.Intern("implements java.io.PrintWriter given flush-fn, which will be called\n  when .flush() is called, with a string built up since the last call to .flush().\n  if not nil, close-fn will be called with no arguments when .close is called.\n  autoflush? determines if the PrintWriter will autoflush, false by default.")

var Lit_125 *jrt.String = jrt.Intern("1.10")

var Lit_126 *jrt.String = jrt.Intern("get-proxy-class")

var Lit_127 *jrt.String = jrt.Intern("java.io.Writer")

var Lit_128 *jrt.String = jrt.Intern("Float/TYPE")

var Lit_129 *jrt.String = jrt.Intern("Integer/TYPE")

var Lit_130 *jrt.String = jrt.Intern("Long/TYPE")

var Lit_131 *jrt.String = jrt.Intern("Boolean/TYPE")

var Lit_132 *jrt.String = jrt.Intern("Character/TYPE")

var Lit_133 *jrt.String = jrt.Intern("Double/TYPE")

var Lit_134 *jrt.String = jrt.Intern("Byte/TYPE")

var Lit_135 *jrt.String = jrt.Intern("Short/TYPE")
