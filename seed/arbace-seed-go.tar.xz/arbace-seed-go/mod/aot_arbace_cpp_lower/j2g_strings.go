//line j2g_strings.ae:1
package aot_arbace_cpp_lower

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn16,arbace.repr.llvmyn4,llvmyn13,arbace.repr.cyn2,rcyn20,arbace.repr.c.layoutyn6,layoutyn11,arbace.corekn3,docks5,lower7,refusedyn4,agetyn4,convyn1,*yn4,voidkn4,linekn6,columnkn4,elseyn1,gkn4,nameyn1,%yn6,opaquekn6,opaquekn4,typeyn6,vectoryn5,arrayyn3,ptryn6,packedyn6,structyn13,unsigned-charyn14,unsigned-shortyn8,unsignedyn13,unsigned-longyn17,unsigned-__int128yn16,unsigned-bit-intyn11,signed-charyn5,shortyn3,intyn4,longyn8,__int128yn7,bit-intyn6,cx$f80yn6,cx$c80kn6,unionskn4,defsys1,c5,unionyn1,vkn3,tagyn11,long-doubleyn7,complexks1,c5,attrsyn13,__attribute__yn7,alignedyn1,bys1,c13,static-assertyn2,==yn11,sizeof-typeyn5,unionyn3,.-vyn4,initkn4,tagsys1,c6,structkn6,vectoryn1,eyn8,x86_fp80yn6,doubleyn8,_Float16yn2,fnyn5,floatyn9,_Float128yn3,lityn6,bit-oryn2,<<yn1,-yn14,__builtin_inflyn14,__builtin_nanlkn10,float-typekn12,float-formatyn13,__builtin_infyn13,__builtin_nanyn14,__builtin_nansyn2,>>yn7,bit-andyn4,addrkn1,cyn17,__builtin_complexkn5,valuekn8,metadatayn2,fpyn8,c-stringyn12,compound-lityn6,c-expryn5,splatkn3,gepyn1,+yn4,charyn4,sremyn2,oryn3,andyn3,addkn2,opyn4,fdivyn4,fremyn4,faddyn4,fsubyn3,xoryn4,uremyn7,bit-xoryn4,ashryn3,shlyn4,udivyn3,subyn1,/yn4,sdivyn3,mulyn4,lshryn15,__builtin_fmodfyn14,__builtin_fmodyn15,__builtin_fmodlyn4,fmulyn3,.-eyn6,uitofpyn8,ptrtointyn6,sitofpyn6,fptosiyn13,addrspacecastyn8,inttoptryn7,bitcastyn6,fptouiyn9,stmt-expryn3,letyn4,cx$uys1,c3,varyn4,cx$syn16,__builtin_memcpyyn5,truncyn5,fpextyn4,zextyn4,sextyn7,fptruncyn13,getelementptryn20,dso_local_equivalentyn6,no_cfiyn12,blockaddressyn3,asmkn10,inline-asmkn5,constyn11,byte-stringyn1,&kn5,byvalyn10,landingpadkn11,instructionyn7,cmpxchgyn4,fnegyn2,i1yn6,freezeyn4,callyn6,allocayn4,loadyn13,shufflevectoryn4,icmpyn9,atomicrmwyn4,fcmpyn12,extractvalueyn11,insertvalueyn6,invokeyn11,catchswitchkn10,windows-ehyn6,va_argyn13,insertelementyn6,selectyn3,phiyn14,extractelementyn6,callbryn10,cleanuppadyn8,catchpadkn5,alignkn5,cconvkn7,bundleskn6,unwindkn4,weakkn9,ret-attrskn3,fmfkn4,tailkn5,countkn9,syncscopekn5,attrskn9,addrspacekn8,volatilekn6,atomickn2,mdkn2,tokn8,nounwindkn4,voidyn6,returnyn4,cx$zyn4,nullkn3,allyn4,set!yn14,__builtin_trapkn3,dynkn9,intrinsicyn18,unsigned-long-longyn20,__builtin_popcountllyn1,?yn2,!=yn15,__builtin_ctzllyn15,__builtin_clzllyn3,notyn21,__builtin_issignalingkn9,coroutineyn16,__builtin_ldexplyn17,__builtin_memmoveyn16,__builtin_memsetyn5,cx$vayn17,__builtin_va_listyn18,__builtin_va_startkn10,last-paramkn2,vayn5,derefyn16,__builtin_va_endyn17,__builtin_va_copyyn24,__builtin_return_addressyn23,__builtin_frame_addressyn6,cx$dynyn14,cx$dyn_restoreyn4,.-f0yn4,.-f1yn1,<yn2,cxyn1,>yn20,__builtin_fpclassifyyn17,__builtin_signbityn17,__builtin_bswap64yn2,<=yn2,>=kn5,blockkn4,phiskn3,phiyn4,gotokn2,eqkn2,nekn3,ugtkn3,ugekn3,ultkn3,ulekn3,sgtkn3,sgekn3,sltkn3,slekn3,ordkn3,ogekn5,falsekn3,olekn3,unokn3,ueqkn4,truekn3,oeqkn3,unekn3,oltkn3,onekn3,ogtkn8,va-listsys4,llvm7,declarekn4,formkn4,kindkn2,fnkn3,sigyn10,label-addryn8,offsetofyn6,sizeofyn7,alignofyn5,commayn4,realyn8,bit-castyn4,asetyn7,genericyn2,atyn4,imagys1,c4,callyn2,ifyn10,cx$pendingyn2,doyn4,whenkn7,cleanupyn5,catchyn6,filteryn10,cx$catcheskn4,specyn15,cx$spec_catchesyn12,cx$exceptionkn7,acquirekn9,monotonickn7,acq_relkn7,releasekn9,unorderedkn7,seq_cstyn3,i32yn3,i64yn8,volatileyn1,=yn6,switchkn6,switchyn4,caseyn7,defaultyn5,storeyn16,__atomic_store_nyn14,__atomic_storeyn10,cleanupretyn27,__atomic_compare_exchange_nyn2,brkn11,entry-blockkn7,allocasks1,c7,alignasyn12,cx$dyn_allocyn27,__builtin_alloca_with_alignkn9,ptr-loadsyn15,__atomic_load_nyn13,__atomic_loadyn22,extractelement-dynamickn9,va-fieldskn3,addyn18,__atomic_fetch_addkn3,subyn18,__atomic_fetch_subkn3,andyn18,__atomic_fetch_andkn2,oryn17,__atomic_fetch_orkn3,xoryn18,__atomic_fetch_xorkn4,nandyn19,__atomic_fetch_nandkn4,xchgkn4,umaxkn3,minkn3,maxkn4,faddkn4,fsubyn19,__atomic_exchange_nyn17,__atomic_exchangekn4,uminyn7,bit-notyn8,do-whileyn25,__atomic_compare_exchangeyn3,retyn11,unreachableyn5,cx$vpyn6,va-argyn10,indirectbryn5,fenceyn8,catchretyn21,__atomic_signal_fenceyn21,__atomic_thread_fencekn6,callbryn6,resumeyn9,cx$resumeyn5,blockkn4,bodykn5,localyn5,labelys1,c4,defnkn6,c-declkn7,linkagekn7,privatekn8,internalkn8,linkoncekn11,extern_weakkn12,linkonce_odrkn8,weak_odryn4,weakkn6,hiddenkn10,visibilityyn10,visibilitykn6,staticks1,c10,decl-attrsks1,c9,asm-labelys4,llvm4,typeys4,llvm10,attributesys4,llvm10,datalayoutkn10,datalayoutys4,llvm6,globalys4,llvm5,aliasys4,llvm6,definekn3,asmkn3,varys1,c7,declarekn6,targetyn5,aliaskn12,thread-localkn12,thread_localkn7,sectionkn6,externkn20,available_externallyyn11,constructoryn11,cx$uncaughtyn10,destructoryn4,argcyn4,argvyn4,envpyn2,tiyn1,nyn2,alyn1,hyn2,toys4,llvm10,module-asmkn1,nkn5,aliasyn4,mainyn1,ryn7,cx$mainyn1,oyn10,cx$va_fullyn8,cx$va_rsys1,c9,directivekn3,gccys1,c4,filekn3,stdkn5,gnu23kn2,aeks4,llvm7,refusedkn7,refusedkn7,messagekn5,crashv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,v11,arbace.core5,referR9,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn16,arbace.cpp.lowerm2,R10,s868,The lowering of LLVM forms to C forms (doc/cpp/LLVM.md §8; doc/cpp/CPP-SURVEY.md §5.3, §5.4, \"As built: CX6\"):\n  one C function per define, a C variable per SSA value, phi as copies on the edges, blocks as labels and gotos,\n  allocas as aligned byte arrays, getelementptr as byte offsets computed from the data layout (x86-64 SysV), the\n  intrinsics by a table, aggregates as C structs of the IR's layout (each with a static assertion of its size),\n  exceptions by a pending flag (§5.4): a call that may unwind is followed by a test of `cx$pending`, an invoke jumps\n  to its landing pad, whose clauses are matched by the runtime (arbace/cpp/rt/eh.c.ae, C forms), x86_fp80 as C's\n  long double (C forms' `long-double`, CS35's class in ci). `lower-module` gives a unit's C forms; a construct the\n  lowering does not take is refused: (ex-info ... {:lower/refused class}).v11,arbace.core7,ex-infov11,arbace.core5,applyv11,arbace.core3,strR11,v16,arbace.cpp.lower12,*blockaddrs*v11,arbace.core5,swap!v11,arbace.core5,assocv11,arbace.core4,listR12,l1,R13,ML2,R14,ML2,R14,R15,m4,R16,i49,R17,i31,m4,R16,i49,R17,i28,v11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstc95,v11,arbace.core6,formatc46,R18,v11,arbace.core10,chunk-restv11,arbace.core4,nextv11,arbace.core7,symbol?v11,arbace.core4,namev11,arbace.core4,seq?R19,v11,arbace.core6,secondv16,arbace.cpp.lower6,refuseR20,v11,arbace.core6,pr-strv11,arbace.core10,re-matchesp22,[A-Za-z_][A-Za-z0-9_]*v11,arbace.core3,notv16,arbace.cpp.lower10,c-keywordsv13,arbace.string12,starts-with?v11,arbace.core6,symbolv16,arbace.cpp.lower3,escv11,arbace.core4,subsR21,v16,arbace.cpp.lower9,lname-strv11,arbace.core7,keywordp9,i([0-9]+)R21,v16,arbace.cpp.lower6,named?v16,arbace.cpp.lower7,*types*R22,R23,v16,arbace.cpp.lower10,size-alignv16,arbace.cpp.lower12,resolve-typev16,arbace.cpp.lower8,int-bitsV2,l1,l1,V2,l2,l2,V2,l4,l4,V2,l8,l8,V2,l8,l8,V2,l2,l2,V2,l2,l2,V2,l16,l16,R24,R25,S5,l128,l32,l64,l16,l8,R26,R27,V2,l8,l8,R28,v16,arbace.cpp.lower13,struct-layoutv11,arbace.core4,restl16,V2,l4,l4,V2,l16,l16,V2,l8,l8,R29,l8,l32,l64,l128,m10,l8,R30,l16,R31,l32,R32,l64,R33,l128,R34,R35,m10,l8,R36,l16,R37,l32,R38,l64,R39,l128,R40,R41,v16,arbace.cpp.lower14,container-bitsv11,arbace.core3,mapv16,arbace.cpp.lower11,complex-ld?R42,R43,v11,arbace.core6,get-inv16,arbace.cpp.lower9,*structs*R44,v11,arbace.core6,updateR45,R46,v11,arbace.core9,with-metaR47,R48,R49,ML2,R50,R49,m4,R16,i192,R17,i76,R51,R52,V2,R53,l16,R54,R26,R30,R55,R56,R57,R58,v11,arbace.core8,assoc-inR58,v16,arbace.cpp.lower10,slot-type?v16,arbace.cpp.lower10,slot-unionv16,arbace.cpp.lower5,ctypeR59,R60,R61,v16,arbace.cpp.lower10,sha256-hexl0,R22,R62,v16,arbace.cpp.lower14,packed-vector?v16,arbace.cpp.lower26,packed-vector-c-size-alignS3,R28,R29,R26,v11,arbace.core4,someR26,R63,R25,R26,R28,v11,arbace.core3,vecv11,arbace.core11,map-indexedv16,arbace.cpp.lower5,mtypeR29,R25,R28,R62,R55,R56,R57,R29,R64,R26,R52,R53,R52,R28,ML3,R29,R65,R65,m4,R16,i253,R17,i13,v16,arbace.cpp.lower5,utypeR66,R67,R15,R49,ML2,R50,R49,m4,R16,i266,R17,i24,R25,R26,R27,ML2,R14,R15,m4,R16,i268,R17,i23,R68,R29,v16,arbace.cpp.lower10,struct-tagR69,R70,ML2,R14,R15,m4,R16,i263,R17,i28,R29,R28,R29,S5,s5,floats5,fp128s4,halfs6,doubles8,x86_fp80R27,R27,S4,R28,R29,R26,R25,R25,v11,arbace.core8,integer?v11,arbace.core10,bigintegerv11,arbace.core5,true?v11,arbace.core6,false?v16,arbace.cpp.lower3,bigv16,arbace.cpp.lower5,two64R71,R32,R71,R33,v11,arbace.core6,bigintR71,R35,R13,R34,R71,R33,R72,R73,R13,R34,R71,R33,R71,R33,l4,v11,arbace.core8,bit-testl15,ML2,R74,ML1,R75,m4,R16,i315,R17,i34,m4,R16,i315,R17,i31,ML1,R75,m4,R16,i315,R17,i53,ML2,R74,ML2,R76,s0,m4,R16,i316,R17,i34,m4,R16,i316,R17,i31,ML2,R76,s0,m4,R16,i316,R17,i56,ML2,R74,ML3,R71,R49,d0,m4,R16,i317,R17,i40,m4,R16,i317,R17,i37,ML3,R71,R49,d0,m4,R16,i317,R17,i64,R74,R71,R49,R71,R49,m6,s5,floatR69,s6,doubleR66,s8,x86_fp80R49,m6,s5,floats1,fs6,doubles0,s8,x86_fp80s1,lp32,[-+](inf|qnan|snan|nan)(\\(.*\\))?R77,R78,v16,arbace.cpp.lower10,fp80-valuel3,v16,arbace.cpp.lower6,fp-litp40,[-+]?[0-9]+(\\.[0-9]*)?([eE][-+]?[0-9]+)?ML2,R74,ML3,R71,R49,d0,m4,R16,i352,R17,i71,m4,R16,i352,R17,i68,ML3,R71,R49,d0,m4,R16,i352,R17,i95,p11,0x[KLMHR].*l2,m6,s5,floatR69,s6,doubleR66,s8,x86_fp80R49,l51,ML1,R79,m4,R16,i368,R17,i44,R66,v11,arbace.core4,not=R66,R74,R74,R71,R49,R71,R49,R80,R81,R71,R13,R74,R13,v16,arbace.cpp.lower9,wide-bitsR74,R13,R38,R13,v16,arbace.cpp.lower5,stypeR82,R13,R73,R13,S5,l128,l32,l64,l16,l8,R83,v16,arbace.cpp.lower7,int-litl128,v11,arbace.core9,namespacev16,arbace.cpp.lower9,gname-strv16,arbace.cpp.lower9,*globals*v16,arbace.cpp.lower17,refused-externalsR13,ML2,R14,R15,m4,R16,i421,R17,i18,R84,R85,R21,v16,arbace.cpp.lower10,global-refS5,s6,poisons4,nones4,nulls5,undefs15,zeroinitializerv16,arbace.cpp.lower9,ptr-type?ML3,R13,ML2,R14,R15,m4,R16,i432,R17,i30,l0,m4,R16,i432,R17,i24,v16,arbace.cpp.lower11,float-type?ML3,R86,ML3,R71,R49,d0,m4,R16,i435,R17,i45,ML3,R71,R49,d0,m4,R16,i435,R17,i67,m4,R16,i435,R17,i26,v16,arbace.cpp.lower10,aggregate?R87,v16,arbace.cpp.lower8,md-head?R88,v16,arbace.cpp.lower9,local-symR19,R89,S5,R28,R29,R26,R25,R90,R90,v16,arbace.cpp.lower5,valuev16,arbace.cpp.lower9,slot-initR86,S3,R26,R25,R90,R91,R92,R93,v16,arbace.cpp.lower11,splat-valuev16,arbace.cpp.lower10,const-exprR13,R91,R13,ML2,R14,R15,m4,R16,i443,R17,i44,R71,R33,R91,R60,R94,R13,R39,v16,arbace.cpp.lower4,svalv11,arbace.core4,atomv11,arbace.core7,number?v11,arbace.core1,+R14,v11,arbace.core6,empty?v16,arbace.cpp.lower10,index-exprS2,R28,R29,R28,S2,R26,R25,R13,ML2,R14,R15,m4,R16,i497,R17,i22,R95,R13,ML2,R14,R96,m4,R16,i497,R17,i59,v11,arbace.core10,split-withv11,arbace.core8,keyword?v16,arbace.cpp.lower4,uvalR97,R98,R99,R100,R101,v16,arbace.cpp.lower4,maskR102,R103,R104,R105,R21,R72,R83,R106,R95,R107,R108,R109,R21,R110,R82,R111,R73,R112,R113,R114,R74,R115,R113,R116,R14,R82,R113,m6,s5,floatR117,s6,doubleR118,s8,x86_fp80R119,R95,R120,R74,R14,v16,arbace.cpp.lower9,vec-type?v16,arbace.cpp.lower6,vec-etS5,l128,l32,l64,l16,l8,R33,R34,R25,v16,arbace.cpp.lower9,bits-typeR72,R13,v11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendR73,R13,R13,R12,R121,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consv11,arbace.core5,rangeR13,R13,R25,R91,R60,R13,R82,R122,R123,R13,R13,R33,R124,R125,R13,R13,R13,R13,R126,R127,R128,v16,arbace.cpp.lower10,bits-valuev16,arbace.cpp.lower10,value-bitsR13,ML2,R14,R15,m4,R16,i571,R17,i29,R13,R33,R129,R13,R130,R131,R132,R133,R134,R133,R132,R135,R84,R132,R84,R134,R130,R131,R132,R133,R132,R135,R84,R132,R84,R91,R136,R13,R137,R138,R13,R139,R13,R13,R140,R141,v16,arbace.cpp.lower11,split-flagsv16,arbace.cpp.lower8,gep-exprv16,arbace.cpp.lower11,typed-valuev11,arbace.core10,take-whilev11,arbace.core7,vector?S13,R139,R129,R123,R137,R128,R124,R140,R138,R136,R127,R125,R122,R126,v16,arbace.cpp.lower9,cast-exprS9,R100,R110,R116,R112,R98,R115,R106,R109,R99,v16,arbace.cpp.lower5,binopR142,R143,R144,R145,R146,R147,R13,ML2,R14,R15,m4,R16,i605,R17,i57,R13,R33,v16,arbace.cpp.lower11,block-tokenS3,s6,poisons5,undefs15,zeroinitializerML1,R60,m4,R16,i622,R17,i53,R90,v16,arbace.cpp.lower15,long-string-minR90,S2,R26,R25,S2,R28,R29,R60,v16,arbace.cpp.lower5,cinitR60,R60,R148,R60,R60,R60,R60,v11,arbace.core6,mapcatv16,arbace.cpp.lower13,*attr-groups*R149,v16,arbace.cpp.lower10,param-attrR150,v11,arbace.core6,removeS1,R149,S1,R149,S1,R149,R151,R129,R112,R109,R152,R136,R103,R122,R153,R154,R29,R155,R156,R106,R157,R68,R111,R104,R123,R105,R124,R107,R158,R27,R159,R160,R137,R25,v16,arbace.cpp.lower5,vec-nR161,R155,R141,R27,R25,R155,R162,R163,R120,R164,v11,arbace.core5,nnextR110,S2,R28,R29,R165,R138,R166,R167,R168,R169,R170,R102,R171,R125,R139,R172,R115,R97,R99,R140,R173,R114,R116,R98,R174,R175,R100,R126,R176,R127,R128,v11,arbace.core8,hash-mapv11,arbace.core10,drop-whileS16,R177,R178,R179,R180,R181,R182,R183,R184,R185,R186,R187,R188,R189,R190,R191,R192,R19,v16,arbace.cpp.lower9,has-attr?v16,arbace.cpp.lower11,group-attrsR193,R187,R194,v16,arbace.cpp.lower4,*fn*ML1,R195,m4,R16,i702,R17,i50,ML2,R195,R196,m4,R16,i702,R17,i60,R197,R198,v16,arbace.cpp.lower9,*typeids*v11,arbace.core4,peekR199,p67,llvm\\.([a-z_.0-9]+?)(\\.(p0|i[0-9]+|f[0-9]+|v[0-9].*|f80|isVoid).*)?v13,arbace.string5,splitp2,\\.p27,llvm\\.memcpy(\\.inline)?\\..*p17,llvm\\.memmove\\..*p27,llvm\\.memset(\\.inline)?\\..*p140,llvm\\.(lifetime|dbg|assume|experimental\\.noalias|sideeffect|donothing|prefetch|var\\.annotation|invariant\\.end|codeview|x86\\.sse2\\.pause)\\b.*p44,llvm\\.(expect|expect\\.with\\.probability)\\..*p99,llvm\\.(threadlocal\\.address|launder\\.invariant\\.group|strip\\.invariant\\.group|invariant\\.start)\\..*p22,llvm\\.is\\.constant\\..*p20,llvm\\.objectsize\\..*S3,s14,llvm.ubsantraps9,llvm.traps14,llvm.debugtrapV1,ML1,R200,m4,R16,i731,R17,i63,v16,arbace.cpp.lower4,*ci*p27,llvm\\.va_(start|end|copy).*p16,llvm\\.va_start.*p14,llvm\\.va_end.*p15,llvm\\.va_copy.*p21,llvm\\.returnaddress.*p20,llvm\\.frameaddress.*R201,p17,llvm\\.stacksave.*p20,llvm\\.stackrestore.*p17,llvm\\.stacksave.*p20,llvm\\.stackrestore.*p50,llvm\\.([su])(add|sub|mul)\\.with\\.overflow\\.i[0-9]+p29,llvm\\.([su])(add|sub|mul)\\..*p35,llvm\\.([su])(add|sub)\\.sat\\.i[0-9]+p25,llvm\\.([su])(add|sub)\\..*S5,l128,l32,l64,l16,l8,R202,p31,llvm\\.(smax|smin|umax|umin)\\..*p18,llvm\\.([a-z]+)\\..*l5,p13,llvm\\.abs\\..*p29,llvm\\.(ctpop|ctlz|cttz)\\.i128l128,p31,llvm\\.frexp\\.(f32|f64|f80)\\.i32m6,s3,f32s1,fs3,f64s0,s3,f80s1,lp32,llvm\\.(ctpop|ctlz|cttz)\\.i[0-9]+R13,R203,R82,R95,R204,v11,arbace.core6,reduceR205,R206,R95,R207,v11,arbace.core7,reverseR205,R206,R74,R95,R208,p15,llvm\\.ctpop\\..*p14,llvm\\.ctlz\\..*p14,llvm\\.cttz\\..*p24,llvm\\.bswap\\.i(16|32|64)p21,llvm\\.is\\.fpclass\\..*R99,R56,R209,R56,R210,R99,R56,R209,R210,l6,l7,l9,p19,llvm\\.([su])cmp\\..*p22,llvm\\.fsh[lr]\\.i[0-9]+p49,llvm\\.(l|ll)(round|rint)\\.i(32|64)\\.(f32|f64|f80)p49,llvm\\.(l|ll)(round|rint)\\.i(32|64)\\.(f32|f64|f80)p17,llvm\\.fmuladd\\..*p23,llvm\\.eh\\.typeid\\.for.*p32,llvm\\.([a-z0-9]+)\\.(f32|f64|f80)v16,arbace.cpp.lower8,math-fnsm6,s3,f32s1,fs3,f64s0,s3,f80s1,lp14,llvm\\.coro\\..*R211,p25,llvm\\.bitreverse\\.i[0-9]+l128,p44,llvm\\.fpto[su]i\\.sat\\.i[0-9]+\\.(f32|f64|f80)c115,R212,R71,R49,d4607182418800017408,p22,llvm\\.ptrmask\\.p0\\.i64p30,llvm\\.powi\\.(f32|f64|f80)\\.i32p44,llvm\\.(minimumnum|maximumnum)\\.(f32|f64|f80)p30,llvm\\.load\\.relative\\.i(32|64)R135,R213,R214,R13,R38,v13,arbace.string9,includes?l-1,R135,l24,R131,R133,R215,m2,R48,R216,R217,R215,R218,R219,R199,l48,R12,R13,ML2,R14,R32,m4,R16,i736,R17,i64,R199,l176,R12,R13,ML2,R14,R32,m4,R16,i737,R17,i64,R199,v16,arbace.cpp.lower11,va-overflowR13,ML2,R14,R15,m4,R16,i738,R17,i72,R215,R199,ML3,R13,ML2,R14,R15,m4,R16,i739,R17,i94,l0,m4,R16,i739,R17,i88,R12,R13,ML2,R14,ML2,R14,R15,m4,R16,i739,R17,i67,m4,R16,i739,R17,i64,R217,R220,R13,ML2,R14,R216,m4,R16,i742,R17,i96,R221,R220,R13,ML2,R14,R216,m4,R16,i743,R17,i92,R222,R220,R13,ML2,R14,R216,m4,R16,i744,R17,i94,R220,R13,ML2,R14,R216,m4,R16,i744,R17,i150,R223,R224,R225,R226,ML2,R84,R225,m4,R16,i749,R17,i95,ML3,R13,ML2,R14,R15,m4,R16,i750,R17,i60,l0,m4,R16,i750,R17,i54,R13,R14,R84,R227,R84,R227,S5,l128,l32,l64,l16,l8,R199,R228,R13,R13,R82,R13,R205,R229,R13,R74,R74,R13,R130,R131,R133,R230,R205,ML2,R84,R230,m4,R16,i771,R17,i112,R13,R230,R205,R231,R229,R205,R229,R74,R13,R203,R82,R13,R203,R95,R204,R204,R205,R206,R207,R205,l128,R206,R95,R207,R205,R206,R208,R205,l128,R206,R95,R208,R13,R34,R199,R59,R227,R227,R13,ML2,R14,R38,m4,R16,i787,R17,i147,R84,R228,R13,R204,R13,R203,R205,R56,R74,R208,R13,R203,R205,R56,R207,R13,R203,R232,R233,R98,R74,R231,R229,R21,R205,R56,R72,R73,R82,R74,R72,R73,R74,R82,m6,s3,f32s1,fs3,f64s0,s3,f80s1,lR95,R14,v16,arbace.cpp.lower6,typeidR72,R73,R83,R82,R72,R73,R13,R34,R234,R13,R33,R13,R34,R234,R13,R33,R82,S5,l128,l32,l64,l16,l8,R205,R206,R205,R235,R74,R205,R236,R13,R13,R205,R209,R231,d-4616189618054758400,R205,R236,R13,R13,ML2,R14,R15,m4,R16,i862,R17,i29,R83,R13,R33,m6,s3,f32s1,fs3,f64s0,s3,f80s1,lm6,s3,f32s1,fs3,f64s0,s3,f80s1,lR13,ML2,R14,R15,m4,R16,i868,R17,i29,R95,R13,ML2,R14,R96,m4,R16,i868,R17,i60,R220,R13,ML2,R14,R38,m4,R16,i869,R17,i70,R95,R13,ML2,R14,R96,m4,R16,i869,R17,i100,R237,R238,R239,R199,R240,v16,arbace.cpp.lower8,label-kwR12,R121,R13,R39,m20,R241,R56,R242,R206,R243,R231,R244,R236,R245,R229,R246,R235,R247,R231,R248,R236,R249,R229,R250,R235,S4,R247,R250,R249,R248,R13,R33,R13,R33,R246,R251,R252,R253,R99,R56,R56,R98,R206,R206,R209,R231,R236,R243,R254,R209,R235,R244,R235,R255,R209,R229,R256,R257,R209,R98,R229,R231,R258,R245,R56,R259,R209,R236,R260,R206,R261,R229,R262,R98,R229,R231,R231,R91,R60,v11,arbace.core6,repeatR93,p2,\\.S2,s4,fmuls4,faddv16,arbace.cpp.lower4,lanev16,arbace.cpp.lower5,lanesS2,s4,smaxs4,sminR106,R205,R231,m6,s5,floats1,fs6,doubles0,s8,x86_fp80s1,lm6,s5,floats1,fs6,doubles0,s8,x86_fp80s1,lR95,R100,R14,R115,R205,R229,R99,R98,R199,R199,p2,\\.p33,llvm\\.vector\\.reduce\\.[a-z]+\\.v.*v16,arbace.cpp.lower12,reduce-stmtsv11,arbace.core7,re-findp18,\\.v\\d+([if]\\d+|p0)v16,arbace.cpp.lower15,lane-intrinsicsv13,arbace.string7,replacep18,\\.v\\d+([if]\\d+|p0)v16,arbace.cpp.lower10,intrinsic*v11,arbace.core4,mapvR92,S18,R100,R110,R116,R103,R112,R104,R107,R98,R111,R102,R97,R120,R115,R114,R106,R109,R105,R99,R199,R154,R199,R74,R161,v11,arbace.core4,lastR199,v16,arbace.cpp.lower9,icmp-exprR163,R199,v16,arbace.cpp.lower9,fcmp-exprS12,R139,R129,R123,R137,R124,R140,R138,R136,R127,R125,R122,R126,R199,R171,R199,R205,R160,v16,arbace.cpp.lower15,shuffle-indicesR199,v16,arbace.cpp.lower4,optsR68,R68,S1,R149,R19,R145,R15,R145,R15,v16,arbace.cpp.lower9,intrinsicv11,arbace.core9,contains?R263,R220,R13,R14,R220,R13,ML2,R14,R216,m4,R16,i1029,R17,i113,ML2,R14,R216,m4,R16,i1029,R17,i113,R264,R265,v16,arbace.cpp.lower12,va-list-argsR266,R267,R268,v11,arbace.core6,subvecS1,R149,v16,arbace.cpp.lower8,c-paramsv11,arbace.core4,takeS20,R12,R269,R60,R270,R271,R272,R273,R98,R274,R71,R209,R84,R275,R13,R276,R277,R278,R220,R279,R99,R280,v16,arbace.cpp.lower11,may-unwind?R166,v11,arbace.core4,intov16,arbace.cpp.lower4,edgeR192,R68,V1,R149,V1,R15,R149,R13,R27,R14,R199,R281,R282,R283,R180,R283,R284,R282,v16,arbace.cpp.lower12,dummy-returnS1,R285,S1,R285,R286,R287,R26,R205,R288,R197,ML3,R13,ML2,R14,R15,m4,R16,i1067,R17,i84,l0,m4,R16,i1067,R17,i78,R289,R205,R98,R290,ML3,R199,R282,l0,m4,R16,i1083,R17,i7,R199,ML1,R291,m4,R16,i1080,R17,i36,R227,R199,R228,R284,R56,R228,R292,R293,R294,R295,R190,R296,R297,S5,l128,l32,l64,l16,l8,v11,arbace.core2,<=m4,s5,floatR298,s6,doubleR299,R13,R14,R189,R300,R301,S2,R157,R166,S8,R177,R181,R185,R186,R188,R189,R190,R191,R199,R151,v16,arbace.cpp.lower16,landingpad-stmtsR129,R25,R302,R112,R128,R303,R302,v11,arbace.core6,concatR304,ML1,R305,m4,R16,i1306,R17,i39,R306,v16,arbace.cpp.lower11,store-bytesv16,arbace.cpp.lower9,atomic-n?v16,arbace.cpp.lower10,atomic-intv16,arbace.cpp.lower12,packed-bytesR109,R300,R307,v16,arbace.cpp.lower12,atomic-placev16,arbace.cpp.lower12,atomic-orderR307,R128,R308,R84,R91,R135,R84,R91,R135,R84,R91,R199,R220,R13,R14,R136,R103,R309,R122,R153,R154,R199,R227,R199,R228,R310,R181,v16,arbace.cpp.lower10,order-joinR84,R227,R156,R74,R106,R157,v16,arbace.cpp.lower10,call-stmtsR111,R104,R123,R105,R311,R124,R281,R155,R283,R283,R107,R158,R185,R177,R312,R26,v11,arbace.core4,fnilR159,R313,R314,R26,R30,R13,ML2,R14,R15,m4,R16,i1167,R17,i38,R14,R315,ML2,R84,R225,m4,R16,i1170,R17,i53,R316,R160,R300,R317,R318,R128,R318,R319,R84,R130,R131,R132,R133,R132,R135,R84,R132,R220,R13,R14,R130,R131,R132,R133,R132,R13,R135,R84,R132,R220,R13,R14,R137,R161,R141,v16,arbace.cpp.lower8,va-fieldR320,v11,arbace.core6,every?R321,R162,m12,R322,R323,R324,R325,R326,R327,R328,R329,R330,R331,R332,R333,R334,R335,S2,R336,R337,R338,R339,R337,S2,R336,R337,R163,R340,R128,R340,R128,R341,R84,R91,R84,R205,S2,R337,R335,R231,R229,R95,R74,R336,S2,R336,R337,S2,R337,R335,R342,S2,R336,R337,S2,R337,R335,R332,R343,R99,S2,R337,R335,R199,R318,R199,R128,R318,R319,R84,R344,R209,R345,R84,R84,R91,R120,R346,V1,ML3,R226,ML2,R84,R225,m4,R16,i1297,R17,i63,ML3,R13,ML2,R14,R15,m4,R16,i1297,R17,i83,l0,m4,R16,i1297,R17,i77,m4,R16,i1297,R17,i47,R15,V1,ML1,R195,m4,R16,i1298,R17,i44,R195,R164,R110,S2,R28,R29,R274,R279,R65,v16,arbace.cpp.lower8,slot-getR12,R121,R347,V1,ML1,R200,m4,R16,i1307,R17,i21,R165,S2,R28,R29,R274,R279,R65,R12,R121,R138,R199,R199,R166,R167,R169,R170,R130,R131,R133,R348,m2,R48,ML2,R14,R15,m4,R16,i1325,R17,i92,R199,R13,ML2,R14,R15,m4,R16,i1326,R17,i90,R95,ML3,R13,ML2,R14,R96,m4,R16,i1326,R17,i115,R348,m4,R16,i1326,R17,i109,R220,R13,R348,R14,R349,R220,R13,ML2,R14,R216,m4,R16,i1328,R17,i63,R102,R199,R199,R12,R121,R171,R125,R25,R281,R199,R199,R205,R139,R350,R351,R302,R13,R33,R304,v11,arbace.core8,distinctV2,ML1,R305,m4,R16,i1312,R17,i38,ML1,R200,m4,R16,i1312,R17,i49,R352,R186,R353,R354,R172,R115,R97,R99,R140,R173,R114,R12,R121,R116,R98,R174,R15,R145,R355,R175,R100,R126,R176,R127,R128,R356,R357,R227,R301,S7,R159,R172,R157,R306,R141,R158,R166,v16,arbace.cpp.lower12,vector-stmtsv16,arbace.cpp.lower11,inst-stmts*R191,v11,arbace.core4,dropR301,R301,v11,arbace.core6,filterp7,%[0-9]+R358,v16,arbace.cpp.lower8,dbg-freeR359,R360,v11,arbace.core6,vectorS1,R149,p18,llvm\\.stackrestoreR15,v11,arbace.core9,vary-metav11,arbace.core10,constantlyR301,v16,arbace.cpp.lower11,result-typeR172,v11,arbace.core9,update-inR361,R199,v16,arbace.cpp.lower10,inst-stmtsv11,arbace.core19,pop-thread-bindingsv11,arbace.core8,to-arrayR133,m2,R48,ML2,R14,R15,m4,R16,i1390,R17,i103,R13,ML2,R14,R15,m4,R16,i1390,R17,i127,R84,m2,R48,ML2,R14,R15,m4,R16,i1390,R17,i103,ML2,R14,R15,m4,R16,i1390,R17,i127,R133,R15,R133,v11,arbace.core7,sort-byv11,arbace.core4,compv11,arbace.core3,keyR133,R15,R133,R196,ML1,R60,m4,R16,i1394,R17,i90,R133,R225,m2,R48,ML2,R14,R15,m4,R16,i1395,R17,i66,ML3,R13,ML2,R14,R15,m4,R16,i1395,R17,i84,l0,m4,R16,i1395,R17,i78,S1,R149,V1,R15,S1,R149,R149,v11,arbace.core20,push-thread-bindingsR362,R363,R131,R364,S2,R365,R366,S5,R367,R181,R368,R369,R370,V1,R371,R372,R373,V1,V2,R374,s6,hiddenR375,R376,R52,R377,p8,([\\\\\\\"])R378,R379,R380,v16,arbace.cpp.lower15,expected-layoutR381,R382,R382,S5,s9,llvm.useds17,llvm.global_ctorss17,llvm.global_dtorss23,llvm.global.annotationss18,llvm.compiler.usedS4,R382,R383,R264,R384,v16,arbace.cpp.lower15,runtime-renamesv16,arbace.cpp.lower13,c-global-nameR385,S2,R382,R383,R386,S2,R382,R383,S2,R264,R384,v16,arbace.cpp.lower6,fn-sigS4,R382,R383,R264,R384,S2,R382,R383,S2,R382,R383,S2,R264,R384,S2,R264,R384,S2,R264,R384,S1,R149,V1,R15,S1,R149,R149,R387,v16,arbace.cpp.lower12,linkage-metaS1,R149,V1,R15,S1,R149,R388,V1,R15,R149,R389,R387,V1,R15,R382,v11,arbace.core5,mergeR390,m2,R391,TR392,S1,s13,llvm.metadatav11,arbace.core5,some?R133,v11,arbace.core6,dissocR393,R133,m2,R391,TS1,s13,llvm.metadataR391,R133,R384,R394,R53,v16,arbace.cpp.lower12,lower-defineR362,R52,R395,R395,V1,R15,m2,R48,R15,ML3,R284,R282,ML1,R396,m4,R16,i1501,R17,i54,m4,R16,i1501,R17,i37,V1,R15,m2,R48,R15,ML3,R284,R282,ML1,R396,m4,R16,i1501,R17,i54,m4,R16,i1501,R17,i37,R362,R52,R397,R397,V1,R15,m2,R48,R15,ML3,R284,R282,ML1,R396,m4,R16,i1507,R17,i54,m4,R16,i1507,R17,i37,V1,R15,m2,R48,R15,ML3,R284,R282,ML1,R396,m4,R16,i1507,R17,i54,m4,R16,i1507,R17,i37,R384,V3,ML3,R13,R32,R398,m4,R16,i1511,R17,i44,ML3,R13,ML2,R14,R15,m4,R16,i1511,R17,i72,R399,m4,R16,i1511,R17,i66,ML3,R13,ML2,R14,R15,m4,R16,i1511,R17,i94,R400,m4,R16,i1511,R17,i88,R387,R290,R401,m2,R48,ML2,R14,R15,m4,R16,i1522,R17,i113,m2,R48,R38,R387,R315,R402,m2,R48,R33,R403,m2,R48,R33,R404,m2,R48,ML2,R14,ML2,R14,R15,m4,R16,i1523,R17,i173,m4,R16,i1523,R17,i170,m2,R48,ML2,R14,R15,m4,R16,i1523,R17,i193,R387,R226,R404,m2,R48,ML2,R14,ML2,R14,R15,m4,R16,i1524,R17,i100,m4,R16,i1524,R17,i97,R405,m2,R48,ML2,R14,R15,m4,R16,i1524,R17,i134,m2,R48,R15,R406,R407,R383,R19,R68,R408,R362,R409,R398,m2,R48,R38,R399,m2,R48,ML2,R14,ML2,R14,R96,m4,R16,i1512,R17,i114,m4,R16,i1512,R17,i111,R400,m2,R48,ML2,R14,ML2,R14,R96,m4,R16,i1512,R17,i153,m4,R16,i1512,R17,i150,m2,R48,R38,R131,ML3,R284,R282,ML1,R396,m4,R16,i1514,R17,i55,m4,R16,i1514,R17,i38,ML2,R195,R410,m4,R16,i1515,R17,i38,R410,m2,R48,R38,R13,R38,R411,R133,R282,m6,R393,TR391,TR48,R38,R387,R291,V1,R15,m2,R48,ML2,R14,R15,m4,R16,i1517,R17,i76,R387,R288,R401,m2,R48,ML2,R14,R15,m4,R16,i1518,R17,i82,m2,R48,R38,R387,R357,R412,m2,R48,ML2,R14,R15,m4,R16,i1519,R17,i80,m2,R48,R15,R387,R396,V1,R15,m2,R48,R15,R133,R413,m4,R393,TR48,ML3,R26,l2,R32,m4,R16,i1528,R17,i90,R133,R414,m4,R393,TR48,ML2,R14,R15,m4,R16,i1529,R17,i88,R415,R415,R416,v16,arbace.cpp.lower15,va-field-macrosR415,v11,arbace.core4,keepR417,R418,R419,v20,arbace.repr.c.layout8,form-strv13,arbace.string4,joinv11,arbace.core7,string?v16,arbace.repr.llvm7,read-llv16,arbace.cpp.lower12,lower-modulep4,\\.c$p13,[^A-Za-z0-9_]v16,arbace.cpp.lower12,c-forms-textv13,arbace.repr.c14,read-unit-textR420,v13,arbace.repr.c7,print-cv11,arbace.core7,ex-dataR421,R422,R423,R424,v11,arbace.core5,slurpv16,arbace.cpp.lower10,lower-filep5,\\.ll$v11,arbace.core5,flushp2,\\tv16,arbace.repr.llvm13,roundtrip-onev11,arbace.core4,spitp6,[\\t\\n]v16,arbace.repr.llvm11,spit-latin1m2,R48,C29,java.util.concurrent.Callablev11,arbace.core7,printlnv16,arbace.cpp.lower9,runtime-cv11,arbace.core5,*out*v11,arbace.core5,*err*v11,arbace.core5,printv13,arbace.string11,split-lines")

var Lit_1 *jrt.String = jrt.Intern("lower")

var Lit_2 *jrt.String = jrt.Intern("-o")

var Lit_3 *jrt.String = jrt.Intern(".c")

var Lit_4 *jrt.String = jrt.Intern("arbace.cpp.lower$_main$fn__1915001370")

var Lit_5 *jrt.String = jrt.Intern("--forms")

var Lit_6 *jrt.String = jrt.Intern("lower-list")

var Lit_7 *jrt.String = jrt.Intern("arbace.cpp.lower$_main$iter__1915001375__1915001379")

var Lit_8 *jrt.String = jrt.Intern("CPPI_THREADS")

var Lit_9 *jrt.String = jrt.Intern("4")

var Lit_10 *jrt.String = jrt.Intern("arbace.cpp.lower$_main$fn__1915001386")

var Lit_11 *jrt.String = jrt.Intern("lowered or refused")

var Lit_12 *jrt.String = jrt.Intern("lower-rt")

var Lit_13 *jrt.String = jrt.Intern("cppi: lower, lower-rt or lower-list (the judges: arbace.cpp.check)")

var Lit_14 *jrt.String = jrt.Intern(": refused (")

var Lit_15 *jrt.String = jrt.Intern("): ")

var Lit_16 *jrt.String = jrt.Intern("arbace.cpp.lower$_main$fn__1915001386$fn__1915001390")

var Lit_17 *jrt.String = jrt.Intern("arbace.cpp.lower$_main$fn__1915001386$fn__1915001390$fn__1915001394")

var Lit_18 *jrt.String = jrt.Intern("/forms.ae")

var Lit_19 *jrt.String = jrt.Intern("/print.ll")

var Lit_20 *jrt.String = jrt.Intern("/rt.status")

var Lit_21 *jrt.String = jrt.Intern("\t")

var Lit_22 *jrt.String = jrt.Intern("\n")

var Lit_23 *jrt.String = jrt.Intern("/lower.refused")

var Lit_24 *jrt.String = jrt.Intern(" ")

var Lit_25 *jrt.String = jrt.Intern("/lowered.c.ae")

var Lit_26 *jrt.String = jrt.Intern("/lowered.c")

var Lit_27 *jrt.String = jrt.Intern("arbace.cpp.lower$_main$iter__1915001375__1915001379$fn__1915001380")

var Lit_28 *jrt.String = jrt.Intern("arbace.cpp.lower$_main$iter__1915001375__1915001379$fn__1915001380$fn__1915001381")

var Lit_29 *jrt.String = jrt.Intern("the ordering ")

var Lit_30 *jrt.String = jrt.Intern("arbace.cpp.lower$binop$u__1915000136")

var Lit_31 *jrt.String = jrt.Intern("arbace.cpp.lower$binop$s__1915000138")

var Lit_32 *jrt.String = jrt.Intern("the integer operator ")

var Lit_33 *jrt.String = jrt.Intern("the floating operator ")

var Lit_34 *jrt.String = jrt.Intern("the operator ")

var Lit_35 *jrt.String = jrt.Intern(" on ")

var Lit_36 *jrt.String = jrt.Intern("a bitcast of ")

var Lit_37 *jrt.String = jrt.Intern(" bits")

var Lit_38 *jrt.String = jrt.Intern("a bitcast to ")

var Lit_39 *jrt.String = jrt.Intern(" through bits")

var Lit_40 *jrt.String = jrt.Intern("arbace.cpp.lower$bits_value$iter__1915000163__1915000167")

var Lit_41 *jrt.String = jrt.Intern("arbace.cpp.lower$bits_value$iter__1915000163__1915000167$fn__1915000168")

var Lit_42 *jrt.String = jrt.Intern("arbace.cpp.lower$bits_value$iter__1915000163__1915000167$fn__1915000168$fn__1915000169")

var Lit_43 *jrt.String = jrt.Intern("cx")

var Lit_44 *jrt.String = jrt.Intern("__atomic_")

var Lit_45 *jrt.String = jrt.Intern("__sync_")

var Lit_46 *jrt.String = jrt.Intern("__builtin_")

var Lit_47 *jrt.String = jrt.Intern("g$")

var Lit_48 *jrt.String = jrt.Intern("arbace.cpp.lower$c_params$iter__1915000231__1915000235")

var Lit_49 *jrt.String = jrt.Intern("arbace.cpp.lower$c_params$iter__1915000231__1915000235$fn__1915000236")

var Lit_50 *jrt.String = jrt.Intern("arbace.cpp.lower$c_params$iter__1915000231__1915000235$fn__1915000236$fn__1915000237")

var Lit_51 *jrt.String = jrt.Intern("g")

var Lit_52 *jrt.String = jrt.Intern("")

var Lit_53 *jrt.String = jrt.Intern("inline assembly")

var Lit_54 *jrt.String = jrt.Intern("calls ")

var Lit_55 *jrt.String = jrt.Intern("llvm.")

var Lit_56 *jrt.String = jrt.Intern("arbace.cpp.lower$call_stmts$iter__1915000502__1915000506")

var Lit_57 *jrt.String = jrt.Intern("arbace.cpp.lower$call_stmts$fn__1915000512")

var Lit_58 *jrt.String = jrt.Intern("arbace.cpp.lower$call_stmts$fn__1915000517")

var Lit_59 *jrt.String = jrt.Intern("arbace.cpp.lower$call_stmts$iter__1915000502__1915000506$fn__1915000507")

var Lit_60 *jrt.String = jrt.Intern("arbace.cpp.lower$call_stmts$iter__1915000502__1915000506$fn__1915000507$fn__1915000508")

var Lit_61 *jrt.String = jrt.Intern("the cast ")

var Lit_62 *jrt.String = jrt.Intern("arbace.cpp.lower$cinit$fn__1915000200")

var Lit_63 *jrt.String = jrt.Intern("arbace.cpp.lower$cinit$fn__1915000202")

var Lit_64 *jrt.String = jrt.Intern("arbace.cpp.lower$cinit$fn__1915000204")

var Lit_65 *jrt.String = jrt.Intern("arbace.cpp.lower$cinit$fn__1915000207")

var Lit_66 *jrt.String = jrt.Intern("arbace.cpp.lower$cinit$fn__1915000213")

var Lit_67 *jrt.String = jrt.Intern("a metadata value")

var Lit_68 *jrt.String = jrt.Intern("the constant ")

var Lit_69 *jrt.String = jrt.Intern("double")

var Lit_70 *jrt.String = jrt.Intern("half")

var Lit_71 *jrt.String = jrt.Intern("void")

var Lit_72 *jrt.String = jrt.Intern("x86_fp80")

var Lit_73 *jrt.String = jrt.Intern("float")

var Lit_74 *jrt.String = jrt.Intern("fp128")

var Lit_75 *jrt.String = jrt.Intern("ptr")

var Lit_76 *jrt.String = jrt.Intern("type ")

var Lit_77 *jrt.String = jrt.Intern("a function type by value")

var Lit_78 *jrt.String = jrt.Intern("arbace.cpp.lower$dbg_free$strip__1915000804")

var Lit_79 *jrt.String = jrt.Intern("arbace.cpp.lower$dbg_free$iter__1915000811__1915000815")

var Lit_80 *jrt.String = jrt.Intern("arbace.cpp.lower$dbg_free$iter__1915000811__1915000815$fn__1915000816")

var Lit_81 *jrt.String = jrt.Intern("arbace.cpp.lower$dbg_free$iter__1915000811__1915000815$fn__1915000816$fn__1915000817")

var Lit_82 *jrt.String = jrt.Intern("dbg_")

var Lit_83 *jrt.String = jrt.Intern("arbace.cpp.lower$dbg_free$strip__1915000804$fn__1915000808")

var Lit_84 *jrt.String = jrt.Intern("arbace.cpp.lower$edge$iter__1915000318__1915000322")

var Lit_85 *jrt.String = jrt.Intern("arbace.cpp.lower$edge$iter__1915000318__1915000322$fn__1915000323")

var Lit_86 *jrt.String = jrt.Intern("arbace.cpp.lower$edge$iter__1915000318__1915000322$fn__1915000323$fn__1915000324")

var Lit_87 *jrt.String = jrt.Intern("arbace.cpp.lower$edge$iter__1915000318__1915000322$fn__1915000323$fn__1915000339")

var Lit_88 *jrt.String = jrt.Intern("a phi without the edge from ")

var Lit_89 *jrt.String = jrt.Intern("$p")

var Lit_90 *jrt.String = jrt.Intern("arbace.cpp.lower$edge$iter__1915000318__1915000322$fn__1915000323$fn__1915000324$fn__1915000329")

var Lit_91 *jrt.String = jrt.Intern("$%02x")

var Lit_92 *jrt.String = jrt.Intern("$_")

var Lit_93 *jrt.String = jrt.Intern("fcmp of ")

var Lit_94 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_95 *jrt.String = jrt.Intern("arbace.cpp.lower$fn_sig$fn__1915000246")

var Lit_96 *jrt.String = jrt.Intern("-")

var Lit_97 *jrt.String = jrt.Intern("the type ")

var Lit_98 *jrt.String = jrt.Intern("inf")

var Lit_99 *jrt.String = jrt.Intern("__builtin_inf")

var Lit_100 *jrt.String = jrt.Intern("qnan")

var Lit_101 *jrt.String = jrt.Intern("__builtin_nan")

var Lit_102 *jrt.String = jrt.Intern("snan")

var Lit_103 *jrt.String = jrt.Intern("__builtin_nans")

var Lit_104 *jrt.String = jrt.Intern("the NaN ")

var Lit_105 *jrt.String = jrt.Intern("f0x")

var Lit_106 *jrt.String = jrt.Intern("0x")

var Lit_107 *jrt.String = jrt.Intern("0xK")

var Lit_108 *jrt.String = jrt.Intern("arbace.cpp.lower$gep_expr$add_BANG___1915000123")

var Lit_109 *jrt.String = jrt.Intern("a variable struct index")

var Lit_110 *jrt.String = jrt.Intern("an index into ")

var Lit_111 *jrt.String = jrt.Intern("uses ")

var Lit_112 *jrt.String = jrt.Intern("unknown global ")

var Lit_113 *jrt.String = jrt.Intern("global name ")

var Lit_114 *jrt.String = jrt.Intern("arbace.cpp.lower$group_attrs$fn__1915000228")

var Lit_115 *jrt.String = jrt.Intern("arbace.cpp.lower$has_attr_QMARK_$fn__1915000224")

var Lit_116 *jrt.String = jrt.Intern("icmp of ")

var Lit_117 *jrt.String = jrt.Intern("arbace.cpp.lower$icmp_expr$u__1915000354")

var Lit_118 *jrt.String = jrt.Intern("arbace.cpp.lower$icmp_expr$s__1915000356")

var Lit_119 *jrt.String = jrt.Intern("an index of type ")

var Lit_120 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$fn__1915000558")

var Lit_121 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$set__1915000560")

var Lit_122 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$vec_QMARK___1915000566")

var Lit_123 *jrt.String = jrt.Intern(" of ")

var Lit_124 *jrt.String = jrt.Intern("a switch on i")

var Lit_125 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$fn__1915000572")

var Lit_126 *jrt.String = jrt.Intern("an atomic store of ")

var Lit_127 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$vec_QMARK___1915000589")

var Lit_128 *jrt.String = jrt.Intern("Windows EH's ")

var Lit_129 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$vec_QMARK___1915000597")

var Lit_130 *jrt.String = jrt.Intern("cmpxchg of ")

var Lit_131 *jrt.String = jrt.Intern("fneg of ")

var Lit_132 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$vec_QMARK___1915000623")

var Lit_133 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$vec_QMARK___1915000634")

var Lit_134 *jrt.String = jrt.Intern("struct.__va_list_tag")

var Lit_135 *jrt.String = jrt.Intern("$m")

var Lit_136 *jrt.String = jrt.Intern("an atomic load of ")

var Lit_137 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$vec_QMARK___1915000651")

var Lit_138 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$fn__1915000659")

var Lit_139 *jrt.String = jrt.Intern("cx$va_f")

var Lit_140 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$f__1915000668")

var Lit_141 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$f__1915000670")

var Lit_142 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$f__1915000672")

var Lit_143 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$f__1915000674")

var Lit_144 *jrt.String = jrt.Intern("atomicrmw ")

var Lit_145 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$fn__1915000688")

var Lit_146 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$fn__1915000702")

var Lit_147 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$vec_QMARK___1915000707")

var Lit_148 *jrt.String = jrt.Intern("select on a vector")

var Lit_149 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$vec_QMARK___1915000733")

var Lit_150 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$vec_QMARK___1915000738")

var Lit_151 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$fn__1915000743")

var Lit_152 *jrt.String = jrt.Intern("singlethread")

var Lit_153 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$vec_QMARK___1915000757")

var Lit_154 *jrt.String = jrt.Intern("callbr (asm goto) of ")

var Lit_155 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$vec_QMARK___1915000783")

var Lit_156 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$vec_QMARK___1915000788")

var Lit_157 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_$vec_QMARK___1915000793")

var Lit_158 *jrt.String = jrt.Intern("the instruction ")

var Lit_159 *jrt.String = jrt.Intern(".-f")

var Lit_160 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic$fn__1915000406")

var Lit_161 *jrt.String = jrt.Intern(".$1")

var Lit_162 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic$fn__1915000408")

var Lit_163 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic$fn__1915000408$fn__1915000409")

var Lit_164 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_$a__1915000266")

var Lit_165 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_$at__1915000268")

var Lit_166 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_$w__1915000270")

var Lit_167 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_$set_res__1915000272")

var Lit_168 *jrt.String = jrt.Intern("invariant.start")

var Lit_169 *jrt.String = jrt.Intern("va_copy")

var Lit_170 *jrt.String = jrt.Intern("va_start")

var Lit_171 *jrt.String = jrt.Intern("va_start without a named parameter")

var Lit_172 *jrt.String = jrt.Intern("va_end")

var Lit_173 *jrt.String = jrt.Intern("s")

var Lit_174 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_$v__1915000278")

var Lit_175 *jrt.String = jrt.Intern("_overflow")

var Lit_176 *jrt.String = jrt.Intern("add")

var Lit_177 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_$v__1915000283")

var Lit_178 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_$v__1915000285")

var Lit_179 *jrt.String = jrt.Intern("max")

var Lit_180 *jrt.String = jrt.Intern("ctpop")

var Lit_181 *jrt.String = jrt.Intern("cttz")

var Lit_182 *jrt.String = jrt.Intern("ctlz")

var Lit_183 *jrt.String = jrt.Intern("l")

var Lit_184 *jrt.String = jrt.Intern("__builtin_frexp")

var Lit_185 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_$limb__1915000288")

var Lit_186 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_$fn__1915000291")

var Lit_187 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_$fn__1915000293")

var Lit_188 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_$fn__1915000295")

var Lit_189 *jrt.String = jrt.Intern("__builtin_bswap")

var Lit_190 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_$term__1915000297")

var Lit_191 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_$v__1915000300")

var Lit_192 *jrt.String = jrt.Intern("fshl")

var Lit_193 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_$iter__1915000305__1915000309")

var Lit_194 *jrt.String = jrt.Intern("llvm.bswap.i128")

var Lit_195 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_$p2__1915000315")

var Lit_196 *jrt.String = jrt.Intern("__builtin_powi")

var Lit_197 *jrt.String = jrt.Intern("__builtin_f")

var Lit_198 *jrt.String = jrt.Intern("minimumnum")

var Lit_199 *jrt.String = jrt.Intern("min")

var Lit_200 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_$iter__1915000305__1915000309$fn__1915000310")

var Lit_201 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_$iter__1915000305__1915000309$fn__1915000310$fn__1915000311")

var Lit_202 *jrt.String = jrt.Intern("b$")

var Lit_203 *jrt.String = jrt.Intern("entry")

var Lit_204 *jrt.String = jrt.Intern("arbace.cpp.lower$landingpad_stmts$fn__1915000524")

var Lit_205 *jrt.String = jrt.Intern("arbace.cpp.lower$landingpad_stmts$fn__1915000524$fn__1915000533")

var Lit_206 *jrt.String = jrt.Intern("arbace.cpp.lower$landingpad_stmts$fn__1915000524$fn__1915000538")

var Lit_207 *jrt.String = jrt.Intern("__asm__(\"")

var Lit_208 *jrt.String = jrt.Intern("\")")

var Lit_209 *jrt.String = jrt.Intern("\\\\$1")

var Lit_210 *jrt.String = jrt.Intern("local name ")

var Lit_211 *jrt.String = jrt.Intern("l$")

var Lit_212 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$fn__1915000827")

var Lit_213 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$fn__1915000829")

var Lit_214 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$iter__1915000831__1915000835")

var Lit_215 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$fn__1915000847")

var Lit_216 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$fn__1915000856")

var Lit_217 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$fn__1915000896")

var Lit_218 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$iter__1915000952__1915000956")

var Lit_219 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$iter__1915000966__1915000970")

var Lit_220 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$iter__1915000976__1915000980")

var Lit_221 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$iter__1915000992__1915000998")

var Lit_222 *jrt.String = jrt.Intern("%")

var Lit_223 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$fn__1915000847$fn__1915000848")

var Lit_224 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$fn__1915000896$iter__1915000897__1915000901")

var Lit_225 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$fn__1915000896$iter__1915000897__1915000901$fn__1915000902")

var Lit_226 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$fn__1915000896$iter__1915000897__1915000901$fn__1915000902$fn__1915000903")

var Lit_227 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$fn__1915000896$iter__1915000897__1915000901$fn__1915000902$iter__1915000933__1915000937")

var Lit_228 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$fn__1915000896$iter__1915000897__1915000901$fn__1915000902$fn__1915000903$iter__1915000910__1915000914")

var Lit_229 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$fn__1915000896$iter__1915000897__1915000901$fn__1915000902$fn__1915000903$iter__1915000910__1915000914$fn__1915000915")

var Lit_230 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$fn__1915000896$iter__1915000897__1915000901$fn__1915000902$fn__1915000903$iter__1915000910__1915000914$fn__1915000915$fn__1915000916")

var Lit_231 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$fn__1915000896$iter__1915000897__1915000901$fn__1915000902$iter__1915000933__1915000937$fn__1915000938")

var Lit_232 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$fn__1915000896$iter__1915000897__1915000901$fn__1915000902$iter__1915000933__1915000937$fn__1915000938$fn__1915000939")

var Lit_233 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$iter__1915000831__1915000835$fn__1915000836")

var Lit_234 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$iter__1915000831__1915000835$fn__1915000836$fn__1915000837")

var Lit_235 *jrt.String = jrt.Intern("l$arg")

var Lit_236 *jrt.String = jrt.Intern("$v")

var Lit_237 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$iter__1915000952__1915000956$fn__1915000957")

var Lit_238 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$iter__1915000952__1915000956$fn__1915000957$fn__1915000958")

var Lit_239 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$iter__1915000966__1915000970$fn__1915000971")

var Lit_240 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$iter__1915000966__1915000970$fn__1915000971$fn__1915000972")

var Lit_241 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$iter__1915000976__1915000980$fn__1915000981")

var Lit_242 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$iter__1915000976__1915000980$fn__1915000981$fn__1915000982")

var Lit_243 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$iter__1915000992__1915000998$fn__1915000999")

var Lit_244 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$iter__1915000992__1915000998$fn__1915000999$iter__1915000994__1915001003")

var Lit_245 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$iter__1915000992__1915000998$fn__1915000999$iter__1915000994__1915001003$fn__1915001004")

var Lit_246 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define$iter__1915000992__1915000998$fn__1915000999$iter__1915000994__1915001003$fn__1915001004$fn__1915001005")

var Lit_247 *jrt.String = jrt.Intern("c.cpp.")

var Lit_248 *jrt.String = jrt.Intern("_")

var Lit_249 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001029__1915001033")

var Lit_250 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001039__1915001043")

var Lit_251 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$fn__1915001049")

var Lit_252 *jrt.String = jrt.Intern("the data layout ")

var Lit_253 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$fn__1915001051")

var Lit_254 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001053__1915001057")

var Lit_255 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$fn__1915001087")

var Lit_256 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001089__1915001093")

var Lit_257 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001123__1915001127")

var Lit_258 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$fn__1915001139")

var Lit_259 *jrt.String = jrt.Intern("module asm")

var Lit_260 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001141__1915001145")

var Lit_261 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001169__1915001173")

var Lit_262 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001179__1915001183")

var Lit_263 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001203__1915001207")

var Lit_264 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001231__1915001235")

var Lit_265 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001257__1915001261")

var Lit_266 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001273__1915001277")

var Lit_267 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001289__1915001293")

var Lit_268 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001311__1915001315")

var Lit_269 *jrt.String = jrt.Intern("main")

var Lit_270 *jrt.String = jrt.Intern("#ifndef cx$va_f0")

var Lit_271 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001337__1915001341")

var Lit_272 *jrt.String = jrt.Intern("#endif")

var Lit_273 *jrt.String = jrt.Intern("llvm.global_ctors")

var Lit_274 *jrt.String = jrt.Intern("llvm.global_dtors")

var Lit_275 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001029__1915001033$fn__1915001034")

var Lit_276 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001029__1915001033$fn__1915001034$fn__1915001035")

var Lit_277 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001039__1915001043$fn__1915001044")

var Lit_278 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001039__1915001043$fn__1915001044$fn__1915001045")

var Lit_279 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001053__1915001057$fn__1915001058")

var Lit_280 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001053__1915001057$fn__1915001058$fn__1915001059")

var Lit_281 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001089__1915001093$fn__1915001094")

var Lit_282 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001089__1915001093$fn__1915001094$fn__1915001095")

var Lit_283 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001123__1915001127$fn__1915001128")

var Lit_284 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001123__1915001127$fn__1915001128$fn__1915001129")

var Lit_285 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001141__1915001145$fn__1915001146")

var Lit_286 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001141__1915001145$fn__1915001146$fn__1915001147")

var Lit_287 *jrt.String = jrt.Intern("an alias of a variable or an expression")

var Lit_288 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001169__1915001173$fn__1915001174")

var Lit_289 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001169__1915001173$fn__1915001174$fn__1915001175")

var Lit_290 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001179__1915001183$fn__1915001184")

var Lit_291 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001179__1915001183$fn__1915001184$fn__1915001185")

var Lit_292 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001203__1915001207$fn__1915001208")

var Lit_293 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001203__1915001207$fn__1915001208$fn__1915001209")

var Lit_294 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001203__1915001207$fn__1915001208$fn__1915001226")

var Lit_295 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001203__1915001207$fn__1915001208$fn__1915001209$fn__1915001216")

var Lit_296 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001231__1915001235$fn__1915001236")

var Lit_297 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001231__1915001235$fn__1915001236$fn__1915001237")

var Lit_298 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001231__1915001235$fn__1915001236$fn__1915001253")

var Lit_299 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001231__1915001235$fn__1915001236$fn__1915001237$fn__1915001244")

var Lit_300 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001257__1915001261$fn__1915001262")

var Lit_301 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001257__1915001261$fn__1915001262$fn__1915001263")

var Lit_302 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001273__1915001277$fn__1915001278")

var Lit_303 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001273__1915001277$fn__1915001278$fn__1915001279")

var Lit_304 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001289__1915001293$fn__1915001294")

var Lit_305 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001289__1915001293$fn__1915001294$fn__1915001295")

var Lit_306 *jrt.String = jrt.Intern("cx$ctor$")

var Lit_307 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001311__1915001315$fn__1915001316")

var Lit_308 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001311__1915001315$fn__1915001316$fn__1915001317")

var Lit_309 *jrt.String = jrt.Intern("cx$dtor$")

var Lit_310 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001337__1915001341$fn__1915001342")

var Lit_311 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module$iter__1915001337__1915001341$fn__1915001342$fn__1915001343")

var Lit_312 *jrt.String = jrt.Intern("#define ")

var Lit_313 *jrt.String = jrt.Intern("!")

var Lit_314 *jrt.String = jrt.Intern("arbace.cpp.lower$opts$fn__1915000255")

var Lit_315 *jrt.String = jrt.Intern("arbace.cpp.lower$packed_vector_c_size_align$fn__1915000067")

var Lit_316 *jrt.String = jrt.Intern("arbace.cpp.lower$param_attr$fn__1915000220")

var Lit_317 *jrt.String = jrt.Intern("arbace.cpp.lower$reduce_stmts$fn__1915000387")

var Lit_318 *jrt.String = jrt.Intern("arbace.cpp.lower$reduce_stmts$sv__1915000389")

var Lit_319 *jrt.String = jrt.Intern("arbace.cpp.lower$reduce_stmts$step__1915000391")

var Lit_320 *jrt.String = jrt.Intern("arbace.cpp.lower$reduce_stmts$iter__1915000394__1915000398")

var Lit_321 *jrt.String = jrt.Intern("arbace.cpp.lower$reduce_stmts$iter__1915000394__1915000398$fn__1915000399")

var Lit_322 *jrt.String = jrt.Intern("arbace.cpp.lower$reduce_stmts$iter__1915000394__1915000398$fn__1915000399$fn__1915000400")

var Lit_323 *jrt.String = jrt.Intern("smax")

var Lit_324 *jrt.String = jrt.Intern("fmin")

var Lit_325 *jrt.String = jrt.Intern("fmax")

var Lit_326 *jrt.String = jrt.Intern("xor")

var Lit_327 *jrt.String = jrt.Intern("fadd")

var Lit_328 *jrt.String = jrt.Intern("fmul")

var Lit_329 *jrt.String = jrt.Intern("umin")

var Lit_330 *jrt.String = jrt.Intern("mul")

var Lit_331 *jrt.String = jrt.Intern("umax")

var Lit_332 *jrt.String = jrt.Intern("and")

var Lit_333 *jrt.String = jrt.Intern("or")

var Lit_334 *jrt.String = jrt.Intern("smin")

var Lit_335 *jrt.String = jrt.Intern("lower: ")

var Lit_336 *jrt.String = jrt.Intern("an opaque or unknown type used by value: ")

var Lit_337 *jrt.String = jrt.Intern("the result of ")

var Lit_338 *jrt.String = jrt.Intern("SHA-256")

var Lit_339 *jrt.String = jrt.Intern("UTF-8")

var Lit_340 *jrt.String = jrt.Intern("arbace.cpp.lower$sha256_hex$fn__1915000059")

var Lit_341 *jrt.String = jrt.Intern("%02x")

var Lit_342 *jrt.String = jrt.Intern("arbace.cpp.lower$shuffle_indices$iter__1915000365__1915000369")

var Lit_343 *jrt.String = jrt.Intern("arbace.cpp.lower$shuffle_indices$iter__1915000365__1915000369$fn__1915000370")

var Lit_344 *jrt.String = jrt.Intern("arbace.cpp.lower$shuffle_indices$iter__1915000365__1915000369$fn__1915000370$fn__1915000371")

var Lit_345 *jrt.String = jrt.Intern("bfloat")

var Lit_346 *jrt.String = jrt.Intern("the size of ")

var Lit_347 *jrt.String = jrt.Intern("arbace.cpp.lower$size_align$fn__1915000042")

var Lit_348 *jrt.String = jrt.Intern("arbace.cpp.lower$split_flags$fn__1915000131")

var Lit_349 *jrt.String = jrt.Intern("t$")

var Lit_350 *jrt.String = jrt.Intern("lt$")

var Lit_351 *jrt.String = jrt.Intern("a bit-packed vector inside ")

var Lit_352 *jrt.String = jrt.Intern("arbace.cpp.lower$struct_tag$fn__1915000074")

var Lit_353 *jrt.String = jrt.Intern("arbace.cpp.lower$struct_tag$fn__1915000076")

var Lit_354 *jrt.String = jrt.Intern("aggregate ")

var Lit_355 *jrt.String = jrt.Intern("f")

var Lit_356 *jrt.String = jrt.Intern("a zero of ")

var Lit_357 *jrt.String = jrt.Intern("a metadata value ")

var Lit_358 *jrt.String = jrt.Intern("an integer of ")

var Lit_359 *jrt.String = jrt.Intern("arbace.cpp.lower$value$fn__1915000101")

var Lit_360 *jrt.String = jrt.Intern("arbace.cpp.lower$value$fn__1915000104")

var Lit_361 *jrt.String = jrt.Intern("the value ")

var Lit_362 *jrt.String = jrt.Intern("arbace.cpp.lower$value_bits$iter__1915000149__1915000153")

var Lit_363 *jrt.String = jrt.Intern("arbace.cpp.lower$value_bits$iter__1915000149__1915000153$fn__1915000154")

var Lit_364 *jrt.String = jrt.Intern("arbace.cpp.lower$value_bits$iter__1915000149__1915000153$fn__1915000154$fn__1915000155")

var Lit_365 *jrt.String = jrt.Intern("a scalable vector ")

var Lit_366 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000416__1915000420")

var Lit_367 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000426__1915000430")

var Lit_368 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000439__1915000443")

var Lit_369 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000452__1915000456")

var Lit_370 *jrt.String = jrt.Intern(" between ")

var Lit_371 *jrt.String = jrt.Intern(" and ")

var Lit_372 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000465__1915000469")

var Lit_373 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000478__1915000482")

var Lit_374 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$fn__1915000494")

var Lit_375 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000416__1915000420$fn__1915000421")

var Lit_376 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000416__1915000420$fn__1915000421$fn__1915000422")

var Lit_377 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000426__1915000430$fn__1915000431")

var Lit_378 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000426__1915000430$fn__1915000431$fn__1915000432")

var Lit_379 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000439__1915000443$fn__1915000444")

var Lit_380 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000439__1915000443$fn__1915000444$fn__1915000445")

var Lit_381 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000452__1915000456$fn__1915000457")

var Lit_382 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000452__1915000456$fn__1915000457$fn__1915000458")

var Lit_383 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000465__1915000469$fn__1915000470")

var Lit_384 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000465__1915000469$fn__1915000470$fn__1915000471")

var Lit_385 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000478__1915000482$fn__1915000483")

var Lit_386 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts$iter__1915000478__1915000482$fn__1915000483$fn__1915000484")

var Lit_387 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn3,clsyn1,&yn3,msgkn4,linekn6,columnkn4,filekn7,dynamicyn1,fyn1,lyn1,pkn3,tagyn6,Stringyn16,java.lang.Stringyn1,gyn1,xyn1,tkn8,declaredyn2,tsyn6,packedyn4,longyn1,byn1,eyn20,java.math.BigIntegeryn1,nyn1,vyn3,srcyn9,base-expryn4,idxsyn2,xsyn2,opyn1,ayn2,t1yn2,t2yn1,kyn2,asyn2,psyn6,calleeyn10,call-attrsyn2,tiyn4,argsyn3,resyn2,rtyn2,tov11,arbace.core5,in-nsMyn16,arbace.cpp.lowerm2,R0,s868,The lowering of LLVM forms to C forms (doc/cpp/LLVM.md §8; doc/cpp/CPP-SURVEY.md §5.3, §5.4, \"As built: CX6\"):\n  one C function per define, a C variable per SSA value, phi as copies on the edges, blocks as labels and gotos,\n  allocas as aligned byte arrays, getelementptr as byte offsets computed from the data layout (x86-64 SysV), the\n  intrinsics by a table, aggregates as C structs of the IR's layout (each with a static assertion of its size),\n  exceptions by a pending flag (§5.4): a call that may unwind is followed by a test of `cx$pending`, an invoke jumps\n  to its landing pad, whose clauses are matched by the runtime (arbace/cpp/rt/eh.c.ae, C forms), x86_fp80 as C's\n  long double (C forms' `long-double`, CS35's class in ci). `lower-module` gives a unit's C forms; a construct the\n  lowering does not take is refused: (ex-info ... {:lower/refused class}).m2,R0,s868,The lowering of LLVM forms to C forms (doc/cpp/LLVM.md §8; doc/cpp/CPP-SURVEY.md §5.3, §5.4, \"As built: CX6\"):\n  one C function per define, a C variable per SSA value, phi as copies on the edges, blocks as labels and gotos,\n  allocas as aligned byte arrays, getelementptr as byte offsets computed from the data layout (x86-64 SysV), the\n  intrinsics by a table, aggregates as C structs of the IR's layout (each with a static assertion of its size),\n  exceptions by a pending flag (§5.4): a call that may unwind is followed by a test of `cx$pending`, an invoke jumps\n  to its landing pad, whose clauses are matched by the runtime (arbace/cpp/rt/eh.c.ae, C forms), x86_fp80 as C's\n  long double (C forms' `long-double`, CS35's class in ci). `lower-module` gives a unit's C forms; a construct the\n  lowering does not take is refused: (ex-info ... {:lower/refused class}).R1,v11,arbace.core20,*warn-on-reflection*v16,arbace.cpp.lower6,refusem10,R2,TR3,L1,V3,R4,R5,R6,R7,i17,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower7,*types*m8,R10,TR7,i22,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,*structs*m8,R10,TR7,i23,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,*globals*m8,R10,TR7,i24,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower13,*attr-groups*m8,R10,TR7,i25,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,*typeids*m8,R10,TR7,i26,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower4,*fn*m8,R10,TR7,i27,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower4,*ci*m8,R10,TR7,i37,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower12,*blockaddrs*m8,R10,TR7,i41,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower11,block-tokenm10,R2,TR3,L1,V2,R11,R12,R7,i42,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower12,va-list-argsm40,s7,vwscanfl1,s8,vwprintfl1,s8,vsprintfl2,s9,vsnprintfl3,s8,vfprintfl2,s8,vfwscanfl2,s5,vwarnl1,s9,vswprintfl3,s4,verrl2,s8,vdprintfl2,s8,vswscanfl2,s5,verrxl2,s9,vasprintfl2,s6,vwarnxl1,s7,vprintfl1,s7,vsscanfl2,s9,vfwprintfl2,s6,vscanfl1,s7,vfscanfl2,s7,vsyslogl2,m8,R7,i44,R8,i1,R9,s19,arbace/cpp/lower.aeR0,s115,libc's functions that take a va_list, by name: the index of that argument (C11 7.21.6, 7.29.2, POSIX, BSD's err.h).v16,arbace.cpp.lower11,va-overflowm12,R2,TR3,L1,V1,R13,R0,s91,The overflow_arg_area of the SysV va_list at p (its second pointer-sized field), an lvalue.R7,i48,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower3,escm10,R3,L1,MV1,Myn1,sm2,R14,R15,m2,R14,R16,R0,s98,A name's bytes as C identifier characters: letters, digits and _ kept, . as $_, anything else $XX.R7,i54,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,c-keywordsS48,s6,typeofs5,floats4,elses3,ints7,nullptrs8,restricts6,statics4,voids6,signeds4,longs7,alignass6,inlines6,returns3,asms5,unions6,sizeofs3,fors7,alignofs5,shorts5,falses4,mains2,ifs13,static_asserts4,autos4,bools4,chars6,switchs5,consts4,cases4,trues9,constexprs5,breaks8,volatiles8,registers7,typedefs8,continues2,dos8,unsigneds6,doubles5,whiles3,nils6,structs7,defaults12,thread_locals13,typeof_unquals4,gotos4,enums6,externm8,R2,TR7,i65,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,gname-strm10,R3,L1,MV1,R17,m2,R14,R16,R0,s28,A global form's name string.R7,i71,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower13,c-global-namem12,R2,TR3,L1,V1,Myn1,sm2,R14,R15,R0,s136,The C identifier of an LLVM global: the name itself when C takes it, else g$ and its escape (with an asm label for\n  the linker's name).R7,i79,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,lname-strm10,R2,TR3,L1,MV1,R18,m2,R14,R16,R7,i90,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,local-symm10,R2,TR3,L1,V1,R18,R7,i96,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower8,label-kwm10,R2,TR3,L1,V1,R18,R7,i97,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower15,runtime-renamesm10,s4,mains7,cx$mains14,pthread_creates17,cx$pthread_creates6,atexits9,cx$atexits13,at_quick_exits16,cx$at_quick_exits12,__cxa_atexits13,cx$cxa_atexitm10,R2,TR7,i99,R8,i1,R9,s19,arbace/cpp/lower.aeR0,s631,The names the lowering gives its own: main (called by a C main that checks for an uncaught exception, §8). Since CX7 the\n  Itanium ABI's entry points are libsupc++'s own, lowered with libstdc++ (bin/cppi runtime-build); only the unwinder and the\n  personality routine are the hand-written pending-flag layer, arbace/cpp/rt/eh.c.ae (CP86 (c)). Since CP120 (b) pthread_create\n  is the layer's cx$pthread_create, whose trampoline calls cx$uncaught when a thread's routine returns with the flag set; since\n  CP160 (b) so are atexit, at_quick_exit and __cxa_atexit (cx$atexit, cx$at_quick_exit, cx$cxa_atexit), as to exit-time handlers.v16,arbace.cpp.lower17,refused-externalsm8,R2,TR7,i107,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower15,expected-layoutm6,R7,i112,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower8,int-bitsm10,R2,TR3,L1,V1,R19,R7,i114,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower6,named?m10,R2,TR3,L1,V1,R19,R7,i116,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower12,resolve-typem10,R2,TR3,L1,V1,R19,R7,i118,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,size-alignm8,R20,TR7,i123,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower13,struct-layoutm12,R2,TR3,L1,V2,R21,R22,R0,s42,[offsets size align] of a struct's fields.R7,i125,R8,i1,R9,s19,arbace/cpp/lower.aem10,R3,L1,V1,R19,R0,s39,[alloc-size alignment] of an LLVM type.R7,i134,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower14,container-bitsm10,R2,TR3,L1,MV1,Myn1,nm2,R14,R23,m2,R14,R23,R7,i161,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower5,utypem10,R2,TR3,L1,V1,R24,R7,i162,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower5,stypem10,R2,TR3,L1,V1,R24,R7,i163,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,wide-bitsm10,R2,TR3,L1,MV1,Myn1,nm2,R14,R23,m2,R14,R23,R7,i164,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower5,ctypem8,R20,TR7,i166,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,sha256-hexm10,R2,TR3,L1,MV1,Myn1,sm2,R14,R15,m2,R14,R16,R7,i168,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower11,complex-ld?m8,R20,TR7,i172,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,slot-type?m12,R2,TR3,L1,V1,R19,R0,s243,An LLVM type whose C type's layout in ci is not the IR's (CS35: ci's long double is 8 bytes, the IR's x86_fp80 16, and\n  _Complex long double 16 against 32): as a member or an element of an aggregate it is held in a slot union (cppi-deferred).R7,i174,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,slot-unionm12,R2,TR3,L1,V1,R19,R0,s343,The slot union of an x86_fp80 (cx$f80) or of a _Complex long double (cx$c80): the value as member v, padded to the IR's\n  size and aligned to its alignment by a byte array, so a struct holding one has the IR's layout under gcc (where the union is\n  the type's own layout) and in ci (CS35) alike; defined once a unit, with its static assertion.R7,i180,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower5,mtypem12,R2,TR3,L1,V1,R19,R0,s111,The C type of an aggregate's member or element of LLVM type t: its slot union for a slot type, else its C type.R7,i197,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower8,slot-getm12,R2,TR3,L1,V2,R25,R19,R0,s89,A member's or element's place e of LLVM type t as its value's place (the slot union's v).R7,i202,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,slot-initm12,R2,TR3,L1,V2,R18,R19,R0,s79,An initializer of a member or element of LLVM type t (braced for a slot union).R7,i207,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower14,packed-vector?m8,R20,TR7,i211,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower26,packed-vector-c-size-alignm12,R2,TR3,L1,V1,R19,R0,s219,[size alignment] of a bit-packed vector's value (<N x i1>, <1 x i10>): the C struct of one array, an element in its\n  integer container (a byte for i1, two bytes for i10: size-align gives its size in memory, the bits').R7,i213,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,struct-tagm12,R2,TR3,L1,V1,R19,R0,s107,The C struct tag that stands for an aggregate LLVM type, its definition added (members first) on first use.R7,i220,R8,i1,R9,s19,arbace/cpp/lower.aem12,R2,TR3,L1,V1,R19,R0,s178,{ x86_fp80, x86_fp80 }: clang's _Complex long double, which the ABI returns in x87 registers (a C struct of two long\n  doubles would return in memory), so it is C's complex type.R7,i250,R8,i1,R9,s19,arbace/cpp/lower.aem10,R3,L1,V1,R19,R0,s32,The C type form of an LLVM type.R7,i255,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower11,float-type?m10,R2,TR3,L1,V1,R19,R7,i274,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,ptr-type?m10,R2,TR3,L1,V1,R19,R7,i275,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,aggregate?m10,R2,TR3,L1,V1,R19,R7,i276,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,vec-type?m10,R2,TR3,L1,V1,R19,R7,i282,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower5,vec-nm10,R2,TR3,L1,MV1,R19,m2,R14,R23,R7,i283,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower6,vec-etm10,R2,TR3,L1,V1,R19,R7,i284,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower3,bigm10,R2,TR3,L1,MV1,R18,m2,R14,R26,R7,i289,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower5,two64m8,R2,TR7,i290,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower7,int-litm10,R3,L1,V2,R27,Myn1,wm2,R14,R23,R0,s96,The C expression of the W-bit constant n (its unsigned value), at the container's unsigned type.R7,i292,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,fp80-valuem12,R2,TR3,L1,V1,Myn3,hexm2,R14,R15,R0,s59,An x86_fp80 constant's C expression from its 20 hex digits.R7,i306,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower6,fp-litm10,R3,L1,V2,Myn4,textm2,R14,R15,R19,R0,s61,A floating constant's C expression (`text`: LLVM's spelling).R7,i326,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower13,*local-types*m8,R10,TR7,i377,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower4,uvalm12,R2,TR3,L1,V2,R25,Myn1,wm2,R14,R23,R0,s45,An integer operand at its wide unsigned type.R7,i379,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower4,svalm12,R2,TR3,L1,V2,R25,Myn1,wm2,R14,R23,R0,s39,An integer operand as its signed value.R7,i384,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower4,maskm10,R2,TR3,L1,V2,R25,Myn1,wm2,R14,R23,R7,i394,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower11,store-bytesm12,R2,TR3,L1,V1,Myn1,wm2,R14,R23,R0,s209,An integer type's store size in bytes when it is smaller than its container's (i24: 3 of 4, i40: 5 of 8), else nil:\n  LLVM's load and store of the type read and write those bytes only (review 007's finding 4).R7,i400,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower5,valuem8,R20,TR7,i406,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower8,gep-exprm8,R20,TR7,i406,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,const-exprm8,R20,TR7,i406,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower11,splat-valuem8,R20,TR7,i406,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower8,md-head?m12,R2,TR3,L1,V1,R18,R0,s217,Whether x is metadata's symbol: `!N`, `!name`, or a node's head, `!` (a string or a tuple), `!DILocation`, `!DIExpression`\n  ... (the structured DI nodes since llvm-read, LLVM.md §4; `!DI` and the node's text before).R7,i408,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,global-refm12,R2,TR3,L1,V1,R17,R0,s42,The address of a global as a void pointer.R7,i414,R8,i1,R9,s19,arbace/cpp/lower.aem10,R3,L1,V2,R28,R19,R0,s44,The C expression of an LLVM value of type t.R7,i423,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower11,typed-valuem10,R2,TR3,L1,V1,V2,R19,R28,R7,i460,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,index-exprm12,R2,TR3,L1,V1,V2,R19,R28,R0,s65,A GEP index as a signed long expression, or a long when constant.R7,i465,R8,i1,R9,s19,arbace/cpp/lower.aem10,R3,L1,V3,R29,R30,R31,R0,s91,The address `base` advanced by the indices over the source type: a void pointer expression.R7,i475,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower11,split-flagsm10,R2,TR3,L1,V1,R32,R7,i502,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower5,binopm10,R3,L1,V4,R33,R19,R34,R24,R0,s79,A binary operator's C expression on operands a and b (C expressions) of type t.R7,i504,R8,i1,R9,s19,arbace/cpp/lower.aem10,R2,TR3,L1,V1,R19,R7,i525,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower12,packed-bytesm12,R2,TR3,L1,MV1,R19,m2,R14,R23,R0,s51,A bit-packed vector's bytes in memory: ceil(N*k/8).R7,i528,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,bits-typem10,R2,TR3,L1,V1,Myn1,nm2,R14,R23,R7,i532,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,value-bitsm12,R2,TR3,L1,V2,R19,R25,R0,s110,The bits of an integer or integer vector expression as an unsigned integer expression (element i at bits i*k).R7,i535,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,bits-valuem12,R2,TR3,L1,V2,R19,R18,R0,s66,An integer or integer vector of type t from the bits expression x.R7,i546,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,cast-exprm10,R2,TR3,L1,V4,R33,R35,R25,R36,R7,i558,R8,i1,R9,s19,arbace/cpp/lower.aem10,R3,L1,V2,R28,R19,R0,s37,A constant expression's C expression.R7,i592,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower15,long-string-minl4096,m8,R7,i613,R8,i1,R9,s19,arbace/cpp/lower.aeR0,s126,The length from which a c-string initializer is lowered as a string literal (cinit): only tzdb.cc's in the runtime reaches it.v16,arbace.cpp.lower5,cinitm10,R3,L1,V2,R28,R19,R0,s42,A global's initializer as a C initializer.R7,i617,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,param-attrm10,R2,TR3,L1,V2,R13,R37,R7,i639,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,has-attr?m10,R2,TR3,L1,V2,R38,R37,R7,i640,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower11,group-attrsm10,R2,TR3,L1,V1,R38,R7,i642,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower8,c-paramsm12,R2,TR3,L1,V1,R39,R0,s70,The C parameter types of an LLVM parameter list (byval as the struct).R7,i644,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower6,fn-sigm12,R2,TR3,L1,V1,R11,R0,s59,[ret-type param-types variadic byvals] of a declare/define.R7,i650,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower11,result-typem12,R2,TR3,L1,V1,R18,R0,s41,The LLVM type of an instruction's result.R7,i659,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower4,optsm10,R2,TR3,L1,V1,R18,R7,i689,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower11,may-unwind?m12,R2,TR3,L1,V2,R40,R41,R0,s80,Whether a call may unwind (§5.4): not when the call or its callee says nounwind.R7,i693,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower12,dummy-returnm10,R2,TR3,L1,V0,R7,i702,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower6,typeidm10,R2,TR3,L1,V1,R42,R7,i704,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower8,math-fnsm46,s5,floors5,floors4,ceils4,ceils3,fmas3,fmas8,copysigns8,copysigns3,pows3,pows3,logs3,logs3,sins3,sins4,fabss4,fabss3,exps3,exps9,nearbyints9,nearbyints9,roundevens9,roundevens5,log10s5,log10s4,sqrts4,sqrts3,tans3,tans3,coss3,coss5,truncs5,truncs4,exp2s4,exp2s5,ldexps5,ldexps5,rounds5,rounds6,minnums4,fmins4,log2s4,log2s4,rints4,rints6,maxnums4,fmaxm8,R2,TR7,i708,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,intrinsic*m12,R2,TR3,L1,V4,Myn2,nmm2,R14,R15,R43,R44,R45,R0,s76,The statements of an intrinsic call (`res`: its result's C variable or nil).R7,i713,R8,i1,R9,s19,arbace/cpp/lower.aev16,arbace.cpp.lower4,edgem12,R2,TR3,L1,V1,R46,R0,s87,The statements of a jump from the current block to `to`: the phi copies, then the goto.R7,i872,R8,i1,R9,s19,arbace/cpp/lower.ae")

var Lit_388 *jrt.String = jrt.Intern("arbace.cpp.lower$eval1915000004$loading__1927001464__auto____1915000005")

var Lit_389 *jrt.String = jrt.Intern("arbace.cpp.lower$eval1915000008$fn__1915000009")

var Lit_390 *jrt.String = jrt.Intern("arbace.cpp.lower$refuse")

var Lit_391 *jrt.String = jrt.Intern("arbace.cpp.lower$block_token")

var Lit_392 *jrt.String = jrt.Intern("arbace.cpp.lower$va_overflow")

var Lit_393 *jrt.String = jrt.Intern("arbace.cpp.lower$esc")

var Lit_394 *jrt.String = jrt.Intern("arbace.cpp.lower$gname_str")

var Lit_395 *jrt.String = jrt.Intern("arbace.cpp.lower$c_global_name")

var Lit_396 *jrt.String = jrt.Intern("arbace.cpp.lower$lname_str")

var Lit_397 *jrt.String = jrt.Intern("arbace.cpp.lower$local_sym")

var Lit_398 *jrt.String = jrt.Intern("arbace.cpp.lower$label_kw")

var Lit_399 *jrt.String = jrt.Intern("e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128")

var Lit_400 *jrt.String = jrt.Intern("arbace.cpp.lower$int_bits")

var Lit_401 *jrt.String = jrt.Intern("arbace.cpp.lower$named_QMARK_")

var Lit_402 *jrt.String = jrt.Intern("arbace.cpp.lower$resolve_type")

var Lit_403 *jrt.String = jrt.Intern("arbace.cpp.lower$struct_layout")

var Lit_404 *jrt.String = jrt.Intern("arbace.cpp.lower$size_align")

var Lit_405 *jrt.String = jrt.Intern("arbace.cpp.lower$container_bits")

var Lit_406 *jrt.String = jrt.Intern("arbace.cpp.lower$utype")

var Lit_407 *jrt.String = jrt.Intern("arbace.cpp.lower$stype")

var Lit_408 *jrt.String = jrt.Intern("arbace.cpp.lower$wide_bits")

var Lit_409 *jrt.String = jrt.Intern("arbace.cpp.lower$sha256_hex")

var Lit_410 *jrt.String = jrt.Intern("arbace.cpp.lower$slot_type_QMARK_")

var Lit_411 *jrt.String = jrt.Intern("arbace.cpp.lower$slot_union")

var Lit_412 *jrt.String = jrt.Intern("arbace.cpp.lower$mtype")

var Lit_413 *jrt.String = jrt.Intern("arbace.cpp.lower$slot_get")

var Lit_414 *jrt.String = jrt.Intern("arbace.cpp.lower$slot_init")

var Lit_415 *jrt.String = jrt.Intern("arbace.cpp.lower$packed_vector_c_size_align")

var Lit_416 *jrt.String = jrt.Intern("arbace.cpp.lower$struct_tag")

var Lit_417 *jrt.String = jrt.Intern("arbace.cpp.lower$complex_ld_QMARK_")

var Lit_418 *jrt.String = jrt.Intern("arbace.cpp.lower$ctype")

var Lit_419 *jrt.String = jrt.Intern("arbace.cpp.lower$float_type_QMARK_")

var Lit_420 *jrt.String = jrt.Intern("arbace.cpp.lower$ptr_type_QMARK_")

var Lit_421 *jrt.String = jrt.Intern("arbace.cpp.lower$aggregate_QMARK_")

var Lit_422 *jrt.String = jrt.Intern("arbace.cpp.lower$vec_type_QMARK_")

var Lit_423 *jrt.String = jrt.Intern("arbace.cpp.lower$vec_n")

var Lit_424 *jrt.String = jrt.Intern("arbace.cpp.lower$vec_et")

var Lit_425 *jrt.String = jrt.Intern("arbace.cpp.lower$big")

var Lit_426 *jrt.String = jrt.Intern("arbace.cpp.lower$int_lit")

var Lit_427 *jrt.String = jrt.Intern("arbace.cpp.lower$fp80_value")

var Lit_428 *jrt.String = jrt.Intern("arbace.cpp.lower$fp_lit")

var Lit_429 *jrt.String = jrt.Intern("arbace.cpp.lower$uval")

var Lit_430 *jrt.String = jrt.Intern("arbace.cpp.lower$sval")

var Lit_431 *jrt.String = jrt.Intern("arbace.cpp.lower$mask")

var Lit_432 *jrt.String = jrt.Intern("arbace.cpp.lower$store_bytes")

var Lit_433 *jrt.String = jrt.Intern("arbace.cpp.lower$md_head_QMARK_")

var Lit_434 *jrt.String = jrt.Intern("arbace.cpp.lower$global_ref")

var Lit_435 *jrt.String = jrt.Intern("arbace.cpp.lower$value")

var Lit_436 *jrt.String = jrt.Intern("arbace.cpp.lower$typed_value")

var Lit_437 *jrt.String = jrt.Intern("arbace.cpp.lower$index_expr")

var Lit_438 *jrt.String = jrt.Intern("arbace.cpp.lower$gep_expr")

var Lit_439 *jrt.String = jrt.Intern("arbace.cpp.lower$split_flags")

var Lit_440 *jrt.String = jrt.Intern("arbace.cpp.lower$binop")

var Lit_441 *jrt.String = jrt.Intern("arbace.cpp.lower$packed_vector_QMARK_")

var Lit_442 *jrt.String = jrt.Intern("arbace.cpp.lower$packed_bytes")

var Lit_443 *jrt.String = jrt.Intern("arbace.cpp.lower$bits_type")

var Lit_444 *jrt.String = jrt.Intern("arbace.cpp.lower$value_bits")

var Lit_445 *jrt.String = jrt.Intern("arbace.cpp.lower$bits_value")

var Lit_446 *jrt.String = jrt.Intern("arbace.cpp.lower$cast_expr")

var Lit_447 *jrt.String = jrt.Intern("arbace.cpp.lower$const_expr")

var Lit_448 *jrt.String = jrt.Intern("arbace.cpp.lower$cinit")

var Lit_449 *jrt.String = jrt.Intern("arbace.cpp.lower$param_attr")

var Lit_450 *jrt.String = jrt.Intern("arbace.cpp.lower$has_attr_QMARK_")

var Lit_451 *jrt.String = jrt.Intern("arbace.cpp.lower$group_attrs")

var Lit_452 *jrt.String = jrt.Intern("arbace.cpp.lower$c_params")

var Lit_453 *jrt.String = jrt.Intern("arbace.cpp.lower$fn_sig")

var Lit_454 *jrt.String = jrt.Intern("arbace.cpp.lower$result_type")

var Lit_455 *jrt.String = jrt.Intern("arbace.cpp.lower$opts")

var Lit_456 *jrt.String = jrt.Intern("arbace.cpp.lower$may_unwind_QMARK_")

var Lit_457 *jrt.String = jrt.Intern("arbace.cpp.lower$dummy_return")

var Lit_458 *jrt.String = jrt.Intern("arbace.cpp.lower$typeid")

var Lit_459 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic_STAR_")

var Lit_460 *jrt.String = jrt.Intern("arbace.cpp.lower$edge")

var Lit_461 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn1,eyn1,ikn3,dockn4,linekn6,columnkn4,fileyn1,tyn2,pryn2,vayn2,vbyn1,ayn1,byn1,vyn2,mvyn1,nkn3,tagyn6,Stringyn4,argsyn3,resyn2,rtyn1,hyn2,flyn1,xyn1,kyn2,styn2,iskn3,gcckn2,ciyn2,pvyn2,ctyn1,oyn1,fyn4,infoyn8,asm-nameyn1,&yn11,extra-attrsyn5,formsyn9,file-formyn16,java.lang.Stringyn2,llyn4,verbv16,arbace.cpp.lower4,lanem12,R0,TR1,L1,V2,R2,R3,R4,s50,The C lvalue of lane i of the vector expression e.R5,i890,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower5,lanesm10,R0,TR1,L1,V1,R8,R5,i894,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,icmp-exprm10,R1,L1,V4,R9,R8,R10,R11,R4,s105,An integer or pointer comparison's C expression on operands a and b (C expressions) of the scalar type t.R5,i896,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,fcmp-exprm10,R1,L1,V4,R9,R8,R12,R13,R4,s94,A floating comparison's C expression on operands a and b (C expressions) of the scalar type t.R5,i906,R6,i1,R7,s19,arbace/cpp/lower.aem10,R1,L1,V2,R14,R8,R4,s55,A splat constant `(splat [et v])` of the vector type t.R5,i918,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower15,shuffle-indicesm12,R0,TR1,L1,V2,R15,R16,R4,s109,The mask's lane indices (nil: an undefined lane, taken as lane 0) of a shufflevector mask value over n lanes.R5,i924,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower15,lane-intrinsicsS49,s5,floors4,ceils10,bitreverses3,fmas10,maximumnums5,bswaps4,scmps4,umaxs4,ssubs8,copysigns4,smaxs6,fptouis10,minimumnums2,iss4,umins4,ucmps3,pows3,logs5,ctpops3,sins4,smins4,fabss4,fshrs3,exps4,ctlzs9,nearbyints9,roundevens5,log10s7,ptrmasks4,sqrts3,tans3,coss5,truncs4,powis4,uadds4,sadds3,abss4,usubs4,exp2s5,ldexps4,cttzs6,fptosis4,fshls5,rounds6,minnums4,log2s7,fmuladds4,rints6,maxnumm8,R0,TR5,i932,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower12,reduce-stmtsm12,R0,TR1,L1,V3,Myn2,nmm2,R17,R18,R19,R20,R4,s58,llvm.vector.reduce.OP: the lanes folded in order into res.R5,i939,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,intrinsicm12,R0,TR1,L1,V4,Myn2,nmm2,R17,R18,R19,R20,R21,R4,s86,An intrinsic call's statements: the vector forms scalarized, the rest by `intrinsic*`.R5,i960,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower12,vector-stmtsm12,R0,TR1,L1,V4,R20,R22,R23,R19,R4,s94,The C statements of an instruction with vector operands (scalarized), or nil when it has none.R5,i975,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,call-stmtsm12,R0,TR1,L1,V2,R24,R20,R4,s35,A call's or an invoke's statements.R5,i1005,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower16,landingpad-stmtsm10,R0,TR1,L1,V2,R24,R20,R5,i1059,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower12,atomic-orderm10,R0,TR1,L1,V1,R25,R5,i1088,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,order-joinm12,R0,TR1,L1,V2,R12,R13,R4,s241,The weakest __ATOMIC_ order at least as strong as both a and b (report 043's F3): gcc's documentation says a compare-exchange's\n  failure order cannot be stronger than its success order, which LLVM allows; the success order becomes the join.R5,i1091,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,atomic-n?m12,R0,TR1,L1,V1,R8,R4,s158,Whether the _n builtins take a value of LLVM type t (an integer of 1, 2, 4, 8 or 16 bytes or a pointer); else the generic\n  builtins, through memory (floats).R5,i1097,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower8,va-fieldm12,R0,TR1,L1,V2,R26,R27,R4,s176,K when a GEP of source type st and indices is takes field K of x86-64's %struct.__va_list_tag (gp_offset, fp_offset,\n  overflow_arg_area, reg_save_area: indices 0 K), else nil.R5,i1103,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower15,va-field-macrosm4,R28,V4,V2,s15,cx$va_f0(ap,pl)s14,((void *)(ap))V2,s15,cx$va_f1(ap,pl)s28,((void *)((char *)(ap) + 4))V2,s15,cx$va_f2(ap,pl)s28,((void *)((char *)(ap) + 8))V2,s15,cx$va_f3(ap,pl)s29,((void *)((char *)(ap) + 16))R29,V4,V2,s15,cx$va_f0(ap,pl)s24,((void *)&cx$va_full[0])V2,s15,cx$va_f1(ap,pl)s24,((void *)&cx$va_full[1])V2,s15,cx$va_f2(ap,pl)s14,((void *)(pl))V2,s15,cx$va_f3(ap,pl)s19,((void *)&cx$va_rs)m8,R5,i1111,R6,i1,R7,s19,arbace/cpp/lower.aeR4,s850,x86-64's va_list fields as clang's inline va_arg reads them (cppi-deferred). Under gcc (the lowered C's own definitions, when\n  ci's are not given) each is the field's address. ci's va_list is one pointer to the next 8-byte slot of the variadic\n  arguments (doc/c/SPEC.md §7.9), what x86-64's overflow_arg_area is: in ci (arbace.cpp.run/opts) gp_offset and fp_offset read\n  48 and 176 (the registers used up: clang's code takes the overflow path, which reads the argument at overflow_arg_area and\n  advances it by the size rounded to 8, as ci's va_arg), overflow_arg_area is the place of the va_list's pointer (pl: the va_list's\n  storage, or for a va_list parameter, which ci passes as the pointer itself, the place it was loaded from) and reg_save_area a\n  pointer no path reads: the runtime layer's cx$va_full and cx$va_rs (arbace/cpp/rt/eh.c.ae).v16,arbace.cpp.lower10,atomic-intm12,R0,TR1,L1,V1,R8,R4,s489,The integer type of a float's or a double's bits (i32, i64), whose _n builtins the lowering writes for an atomic of that type\n  (cppi-deferred): the same lock-free operation gcc's generic builtins do on 4 and 8 bytes, and the one form ci's read takes\n  (arbace.cpp.run/ci-atomics: repr/c's <builtin> declares the generic __atomic_load, __atomic_store and __atomic_exchange\n  without parameters, so ci refused the calls, the class atomic-generic). Else nil (x86_fp80: the generic builtins).R5,i1124,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower12,atomic-placem12,R0,TR1,L1,V3,R30,R31,R32,R4,s83,The pointer operand cast to the C type's pointer, volatile when the instruction is.R5,i1132,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower11,inst-stmts*m12,R0,TR1,L1,V1,R24,R4,s95,An instruction's C statements (the scalar ones; `inst-stmts` takes the vector ones first, LL5).R5,i1137,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,inst-stmtsm12,R0,TR1,L1,V1,R24,R4,s30,An instruction's C statements.R5,i1333,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower8,dbg-freem12,R0,TR1,L1,V1,R13,R4,s231,A block without its debug records (#dbg_value ... #dbg_declare_value, LLVM.md §5) and its instructions without their\n  metadata attachments (`:md`, !dbg among them): what -g adds to -g0's IR at -O0, which C runs alike without (§7).R5,i1344,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower12,lower-definem12,R0,TR1,L1,V2,R33,R34,R4,s33,A define's C function definition.R5,i1353,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower12,linkage-metam12,R0,TR1,L1,V4,R32,R35,R36,V1,R37,R4,s71,The C name's metadata for a global's linkage, visibility and asm label.R5,i1403,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower12,lower-modulem10,R1,L1,V2,R38,Myn6,c-namem2,R17,R18,R4,s56,The C forms of a module's LLVM forms: [file-form forms].R5,i1415,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower12,c-forms-textm10,R1,L1,MV3,Myn2,nsm2,R17,R18,R39,R38,m2,R17,R40,R4,s85,A lowered unit's C forms as .ae text: its in-ns and c/file forms, then a form a line.R5,i1538,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower10,lower-filem10,R1,L1,V2,R41,Myn6,c-namem2,R17,R18,R4,s73,Lowers the IR at `ll`: {:c text :ae text} or {:refused class :message m}.R5,i1543,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower9,runtime-cm10,R1,L1,MV1,Myn4,pathm2,R17,R18,m2,R17,R40,R4,s63,The runtime's C text (arbace/cpp/rt/eh.c.ae printed by repr/c).R5,i1558,R6,i1,R7,s19,arbace/cpp/lower.aev16,arbace.cpp.lower5,-mainm10,R1,L1,V3,R42,R36,R19,R4,s222,bin/cppi lower FILE.ll [-o OUT.c] [--forms OUT.ae]: FILE's IR lowered to C forms and printed as C;\n  bin/cppi lower-rt RT.c.ae OUT.c: the runtime printed; bin/cppi lower-list LIST (NAME<tab>LL<tab>OUTDIR lines, 4 threads).R5,i1563,R6,i1,R7,s19,arbace/cpp/lower.ae")

var Lit_462 *jrt.String = jrt.Intern("arbace.cpp.lower$lane")

var Lit_463 *jrt.String = jrt.Intern("arbace.cpp.lower$lanes")

var Lit_464 *jrt.String = jrt.Intern("arbace.cpp.lower$icmp_expr")

var Lit_465 *jrt.String = jrt.Intern("arbace.cpp.lower$fcmp_expr")

var Lit_466 *jrt.String = jrt.Intern("arbace.cpp.lower$splat_value")

var Lit_467 *jrt.String = jrt.Intern("arbace.cpp.lower$shuffle_indices")

var Lit_468 *jrt.String = jrt.Intern("arbace.cpp.lower$reduce_stmts")

var Lit_469 *jrt.String = jrt.Intern("arbace.cpp.lower$intrinsic")

var Lit_470 *jrt.String = jrt.Intern("arbace.cpp.lower$vector_stmts")

var Lit_471 *jrt.String = jrt.Intern("arbace.cpp.lower$call_stmts")

var Lit_472 *jrt.String = jrt.Intern("arbace.cpp.lower$landingpad_stmts")

var Lit_473 *jrt.String = jrt.Intern("arbace.cpp.lower$atomic_order")

var Lit_474 *jrt.String = jrt.Intern("arbace.cpp.lower$order_join")

var Lit_475 *jrt.String = jrt.Intern("arbace.cpp.lower$atomic_n_QMARK_")

var Lit_476 *jrt.String = jrt.Intern("arbace.cpp.lower$va_field")

var Lit_477 *jrt.String = jrt.Intern("arbace.cpp.lower$atomic_int")

var Lit_478 *jrt.String = jrt.Intern("arbace.cpp.lower$atomic_place")

var Lit_479 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts_STAR_")

var Lit_480 *jrt.String = jrt.Intern("arbace.cpp.lower$inst_stmts")

var Lit_481 *jrt.String = jrt.Intern("arbace.cpp.lower$dbg_free")

var Lit_482 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_define")

var Lit_483 *jrt.String = jrt.Intern("arbace.cpp.lower$linkage_meta")

var Lit_484 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_module")

var Lit_485 *jrt.String = jrt.Intern("arbace.cpp.lower$c_forms_text")

var Lit_486 *jrt.String = jrt.Intern("arbace.cpp.lower$lower_file")

var Lit_487 *jrt.String = jrt.Intern("arbace.cpp.lower$runtime_c")

var Lit_488 *jrt.String = jrt.Intern("arbace.cpp.lower$_main")
