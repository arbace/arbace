//line j2g_strings.ae:1
package aot_arbace_go_check_env

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn21,arbace.go.check.typesyn1,tyn21,arbace.go.check.constyn1,cyn11,arbace.corekn3,dockn6,parentkn5,nameskn4,kindkn4,filekn4,linekn3,msgkn4,codekn4,declkn2,idkn4,nameks2,go3,endks2,go6,breaksys11,arbace.core3,letyn21,p__1719000036__auto__yn21,i__1719000037__auto__yn21,f__1719000038__auto__ys11,arbace.core2,fnyn2,ifys19,arbace.go.check.env7,line-ofys11,arbace.core3,nthys11,arbace.core7,bindingys19,arbace.go.check.env10,*child-at*kn7,generickn11,unsupportedkn16,unsupported-lineks19,arbace.go.check.env11,unsupportedkn4,seenkn8,verifiedkn18,AnnotationMismatchks15,arbace.go.check2,atkn5,x-poskn8,name-poskn4,typekn8,universekn7,spelledkn3,pkgkn10,underlyingkn9,interfacekn4,funckn6,stringkn3,allkn7,packagekn14,unsafe-pointerkn8,exportedkn7,builtinkn6,unsafev11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,v11,arbace.core5,referR7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn19,arbace.go.check.envm2,R8,s477,goi's checker: its state (doc/go/GOI-SPEC.md §3.3): objects, scopes, the universe, errors,\n  and the per-declaration records of the annotations verified (§3.6).\n\n  Objects are volatiles holding maps, so that they have identity (=, hash) and can be completed\n  as the checker resolves them: {:kind :var|:const|:type|:func|:pkg|:label|:builtin|:nil,\n  :name, :type, :pkg (the package path), :file, :line, ...}. A scope is {:parent :names\n  (a HashMap from name to object) :kind}.v11,arbace.core9,volatile!v11,arbace.core5,assocR9,R10,R11,v19,arbace.go.check.env8,*errors*v11,arbace.core3,notv11,arbace.core3,seqv19,arbace.go.check.env8,*errpos*R12,R13,R14,R15,R16,v19,arbace.go.check.env6,*decl*v19,arbace.go.check.env1,oR17,v19,arbace.go.check.env6,error!R18,v19,arbace.go.check.env8,*gofile*v11,arbace.core4,seq?v11,arbace.core7,vector?v11,arbace.core9,with-metav11,arbace.core3,vecv19,arbace.go.check.env8,end-linev19,arbace.go.check.env10,child-lineR19,l0,v19,arbace.go.check.env7,line-ofv11,arbace.core4,intov11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core4,restR20,v11,arbace.core9,contains?v11,arbace.core6,concatv11,arbace.core4,listR21,v11,arbace.core5,applyv11,arbace.core6,vectorR22,R23,R24,R25,R26,R27,R28,R29,R30,v19,arbace.go.check.env10,*child-at*v19,arbace.go.check.env6,*line*v19,arbace.go.check.env12,current-linev11,arbace.core6,formatR31,v19,arbace.go.check.env8,generic!R32,R33,R34,v11,arbace.core7,ex-datav19,arbace.go.check.env6,*seen*R35,v19,arbace.go.check.env9,verified!v11,arbace.core9,update-inR36,v11,arbace.core4,fnilv11,arbace.core3,incv19,arbace.go.check.env4,err!R37,R38,v19,arbace.go.check.env9,*answers*v19,arbace.go.check.env5,at-ofv11,arbace.core5,mergeR39,R40,v19,arbace.go.check.env10,scope-put!v19,arbace.go.check.env8,universev19,arbace.go.check.env3,objR41,R42,S2,s4,runes4,byteR43,v11,arbace.core7,keywordv21,arbace.go.check.types9,new-namedm4,R18,s5,errorR44,nv21,arbace.go.check.types12,update-info!R45,R46,R44,R47,V1,R48,m4,R18,s10,comparableR44,nv21,arbace.go.check.types9,make-tsetR49,v19,arbace.go.check.env5,scopeR50,m10,R11,R41,R18,s7,PointerR41,R51,R44,s6,unsafeR52,TV8,s6,Sizeofs7,Alignofs8,Offsetofs3,Adds5,Slices9,SliceDatas6,Strings10,StringDataR53,R54,v11,arbace.core4,next")

var Lit_1 *jrt.String = jrt.Intern("annotation %s on %s disagrees with goi's checker: forms say %s, the checker says %s")

var Lit_2 *jrt.String = jrt.Intern("arbace.go.check.env$child_line$iter__1719000023__1719000027")

var Lit_3 *jrt.String = jrt.Intern("arbace.go.check.env$child_line$fn__1719000033")

var Lit_4 *jrt.String = jrt.Intern("arbace.go.check.env$child_line$iter__1719000023__1719000027$fn__1719000028")

var Lit_5 *jrt.String = jrt.Intern("arbace.go.check.env$child_line$iter__1719000023__1719000027$fn__1719000028$fn__1719000029")

var Lit_6 *jrt.String = jrt.Intern("invalid operand")

var Lit_7 *jrt.String = jrt.Intern("invalid type")

var Lit_8 *jrt.String = jrt.Intern("Error")

var Lit_9 *jrt.String = jrt.Intern("Pointer")

var Lit_10 *jrt.String = jrt.Intern("unsafe")

var Lit_11 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn1,mkn4,linekn6,columnkn4,fileyn1,xyn1,kyn1,vyn6,parentyn4,kindyn1,skn3,tagyn6,Stringkn7,dynamicyn4,lineyn4,codeyn3,msgyn4,fileyn4,formkn8,declaredkn7,privateyn1,cyn1,lyn1,fyn1,iyn5,startyn1,&yn4,bodyyn3,fmtyn4,argsyn4,whatyn1,eyn1,ayn9,forms-sayyn12,checker-sayskn8,universeyn1,nyn2,kwkn4,boolkn4,int8kn5,int16kn5,int32kn5,int64kn3,intkn5,uint8kn6,uint16kn6,uint32kn6,uint64kn4,uintkn7,uintptrkn7,float32kn7,float64kn9,complex64kn10,complex128kn6,stringkn4,kindkn4,typekn4,namekn5,aliaskn9,interfacekn5,constkn12,untyped-boolkn3,valkn11,untyped-intkn4,iotakn3,nilkn11,untyped-nilkn7,builtinkn4,pathkn5,scopekn4,fakev11,arbace.core5,in-nsMyn19,arbace.go.check.envm2,R0,s477,goi's checker: its state (doc/go/GOI-SPEC.md §3.3): objects, scopes, the universe, errors,\n  and the per-declaration records of the annotations verified (§3.6).\n\n  Objects are volatiles holding maps, so that they have identity (=, hash) and can be completed\n  as the checker resolves them: {:kind :var|:const|:type|:func|:pkg|:label|:builtin|:nil,\n  :name, :type, :pkg (the package path), :file, :line, ...}. A scope is {:parent :names\n  (a HashMap from name to object) :kind}.m2,R0,s477,goi's checker: its state (doc/go/GOI-SPEC.md §3.3): objects, scopes, the universe, errors,\n  and the per-declaration records of the annotations verified (§3.6).\n\n  Objects are volatiles holding maps, so that they have identity (=, hash) and can be completed\n  as the checker resolves them: {:kind :var|:const|:type|:func|:pkg|:label|:builtin|:nil,\n  :name, :type, :pkg (the package path), :file, :line, ...}. A scope is {:parent :names\n  (a HashMap from name to object) :kind}.R1,v19,arbace.go.check.env3,objm8,R2,L1,V1,R3,R4,i15,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env1,om8,R2,L1,V2,R7,R8,R4,i16,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env5,oset!m8,R2,L1,V3,R7,R8,R9,R4,i17,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env4,obj?m8,R2,L1,V1,R7,R4,i18,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env5,scopem8,R2,L1,V2,R10,R11,R4,i22,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env12,scope-lookupm10,R2,L1,V2,R12,Myn1,nm2,R13,R14,R0,s53,The object named n in scope s or its parents, or nil.R4,i24,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env9,scope-getm8,R2,L1,V2,R12,Myn1,nm2,R13,R14,R4,i33,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env10,scope-put!m8,R2,L1,V3,R12,Myn1,nm2,R13,R14,R7,R4,i34,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env5,*pkg*m10,R15,TR4,i38,R5,i1,R6,s22,arbace/go/check/env.aeR0,s84,The package being checked: a volatile {:path :name :scope :files :config :lang ...}.v19,arbace.go.check.env8,*gofile*m10,R15,TR4,i42,R5,i1,R6,s22,arbace/go/check/env.aeR0,s54,The file being checked: {:name :scope :lang :imports}.v19,arbace.go.check.env6,*decl*m10,R15,TR4,i46,R5,i1,R6,s22,arbace/go/check/env.aeR0,s72,The package-level declaration being checked: its decl info (a volatile).v19,arbace.go.check.env9,*session*m10,R15,TR4,i50,R5,i1,R6,s22,arbace/go/check/env.aeR0,s65,The checking session: {:packages (an atom: path -> package) ...}.v19,arbace.go.check.env8,*errors*m10,R15,TR4,i56,R5,i1,R6,s22,arbace/go/check/env.aeR0,s42,A volatile vector of the package's errors.v19,arbace.go.check.env8,*errpos*m10,R15,TR4,i58,R5,i1,R6,s22,arbace/go/check/env.aeR0,s215,go/types' errpos: while a constant with an inherited initializer (an implicit repetition\n  in a group) is checked, the line of its name, where its errors are reported (the\n  expression's lines are its first spec's).v19,arbace.go.check.env6,error!m10,R2,L2,V3,R16,R17,R18,V4,R19,R16,R17,R18,R0,s81,Records an error at line (the current file's), go/types' code kw and message msg.R4,i64,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env7,line-ofm10,R2,L1,V1,R20,R0,s39,The :line of a form's metadata, or nil.R4,i80,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env6,*line*m10,R15,TR4,i86,R5,i1,R6,s22,arbace/go/check/env.aeR0,s52,The line of the innermost form with one, for errors.v19,arbace.go.check.env10,child-linem8,R21,TR4,i88,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env8,end-linem12,R22,TR2,L1,V2,R23,R24,R0,s136,The last Go line of child c, which begins on line l (doc/go/SPEC.md §10.1): a list's or a\n  vector's last child's, a function's :go/end.R4,i90,R5,i1,R6,s22,arbace/go/check/env.aem10,R2,L2,V2,R25,R26,V3,R25,R26,R27,R0,s321,The Go line of child i of list or vector f (doc/go/SPEC.md §10.1, mode :lines): its own\n  :line, else by f's :go/breaks (a literal that begins a Go line: the line after the one its\n  predecessor ends on, or the line recorded), else its predecessor's last line; nil when f has\n  no line. With start, f begins on that line.R4,i101,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env10,*child-at*m10,R15,TR4,i121,R5,i1,R6,s22,arbace/go/check/env.aeR0,s178,[parent i] while checking child i of form parent, a literal without a :line of its own: its\n  line is computed when an error needs it (child-line); nil inside a form with a line.v19,arbace.go.check.env15,with-child-linem10,R2,L1,V4,R10,R26,R28,R29,R0,s177,Checks body as child i of form parent: when the child has no :line (a literal), errors take\n  its line from parent's :go/breaks (child-line), computed only when one is reported.R4,i126,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env12,current-linem10,R2,L1,V0,R0,s80,The line errors take now: the literal's being checked (*child-at*), else *line*.R4,i134,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env4,err!m10,R2,L1,V5,R25,R17,R30,R28,R31,R0,s48,An error at form f's line (or the current line).R4,i139,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env8,generic!m10,R2,L1,V0,R0,s108,Marks the current declaration as using generics: it is counted apart and its errors are\n  not counted (S53).R4,i146,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env12,unsupported!m10,R2,L1,V1,R32,R0,s264,Marks the current declaration as using what GR2's checker does not check (generic code):\n  it is counted apart (S53), its errors not counted; checking goes on (its references, the\n  imports it uses, its dependencies are recorded), the operand invalid. Returns nil.R4,i152,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env12,unsupported?m8,R2,L1,V1,R33,R4,i162,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env6,*seen*m10,R15,TR4,i166,R5,i1,R6,s22,arbace/go/check/env.aeR0,s135,The package's annotated forms verified (an IdentityHashMap): a form checked twice (an\n  implicitly repeated constant init) counts once.v19,arbace.go.check.env9,verified!m10,R2,L2,V1,R8,V2,R8,R25,R0,s180,Counts an annotation of kind k (:val :tag :go/via :assign :conv :init-order) verified in the\n  current declaration, once per form (f, when given: a form checked twice counts once).R4,i171,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env17,annotation-error!m10,R2,L1,V5,R25,R34,R32,R35,R36,R0,s52,An annotation that disagrees with the checker (S16).R4,i184,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env9,*answers*m10,R15,TR4,i192,R5,i1,R6,s22,arbace/go/check/env.aeR0,s343,The resolve mode (raw forms, GP3's): the package's answers by position, a HashMap from a\n  form's key [file {field [line col]}] (its :arbace.go.check/at, the positions of the node it was\n  converted from) to a map of what the checker decided there (:mode :type :val, :obj, :sel,\n  :field, :inst, :def, :use, :implicit); nil when not resolving.v19,arbace.go.check.env5,at-ofm10,R2,L1,V1,R25,R0,s88,The key of form f's answers: its :arbace.go.check/at, [file {field [line col]}], or nil.R4,i199,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env7,answer!m10,R2,L2,V2,R25,R3,V3,R25,R8,R3,R0,s180,Records answers m (merged into those already there) for form f, or for the node of its\n  positions' field k ([file {k p}]): a qualified name's operand (:x-pos) or name (:name-pos).R4,i204,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env8,universeR37,m6,R4,i220,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env9,def-type!m10,R22,TR2,L1,V2,R38,R39,R4,i222,R5,i1,R6,s22,arbace/go/check/env.aev11,arbace.core3,seqV19,V2,s4,boolR40,V2,s4,int8R41,V2,s5,int16R42,V2,s5,int32R43,V2,s5,int64R44,V2,s3,intR45,V2,s5,uint8R46,V2,s6,uint16R47,V2,s6,uint32R48,V2,s6,uint64R49,V2,s4,uintR50,V2,s7,uintptrR51,V2,s7,float32R52,V2,s7,float64R53,V2,s9,complex64R54,V2,s10,complex128R55,V2,s6,stringR56,V2,s4,byteR46,V2,s4,runeR43,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv11,arbace.core10,chunk-restv11,arbace.core4,nextv19,arbace.go.check.env10,error-typem6,R4,i234,R5,i1,R6,s22,arbace/go/check/env.aeR57,R58,R59,R60,R61,v19,arbace.go.check.env15,comparable-typem6,R4,i243,R5,i1,R6,s22,arbace/go/check/env.aem10,R57,R62,R59,s4,trueR58,R63,R64,TR37,Tm10,R57,R62,R59,s5,falseR58,R63,R64,FR37,Tm12,R57,R62,R59,s4,iotaR58,R65,R64,l0,R66,TR37,Tm8,R57,R67,R59,s3,nilR58,R68,R37,Tv19,arbace.go.check.env13,builtin-namesV18,s6,appends3,caps5,clears5,closes7,complexs4,copys6,deletes4,imags3,lens4,makes3,maxs3,mins3,news5,panics5,prints7,printlns4,reals7,recoverm6,R4,i255,R5,i1,R6,s22,arbace/go/check/env.aeR69,v19,arbace.go.check.env12,unsafe-scopem6,R4,i264,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env14,unsafe-packagev11,arbace.core9,volatile!R70,R71,R72,m6,R4,i271,R5,i1,R6,s22,arbace/go/check/env.ae")

var Lit_12 *jrt.String = jrt.Intern("arbace.go.check.env$eval1719000004$loading__1927001464__auto____1719000005")

var Lit_13 *jrt.String = jrt.Intern("arbace.go.check.env$eval1719000008$fn__1719000009")

var Lit_14 *jrt.String = jrt.Intern("arbace.go.check.env$obj")

var Lit_15 *jrt.String = jrt.Intern("arbace.go.check.env$o")

var Lit_16 *jrt.String = jrt.Intern("arbace.go.check.env$oset_BANG_")

var Lit_17 *jrt.String = jrt.Intern("arbace.go.check.env$obj_QMARK_")

var Lit_18 *jrt.String = jrt.Intern("arbace.go.check.env$scope")

var Lit_19 *jrt.String = jrt.Intern("arbace.go.check.env$scope_lookup")

var Lit_20 *jrt.String = jrt.Intern("arbace.go.check.env$scope_get")

var Lit_21 *jrt.String = jrt.Intern("arbace.go.check.env$scope_put_BANG_")

var Lit_22 *jrt.String = jrt.Intern("arbace.go.check.env$error_BANG_")

var Lit_23 *jrt.String = jrt.Intern("arbace.go.check.env$line_of")

var Lit_24 *jrt.String = jrt.Intern("arbace.go.check.env$end_line")

var Lit_25 *jrt.String = jrt.Intern("arbace.go.check.env$child_line")

var Lit_26 *jrt.String = jrt.Intern("arbace.go.check.env$with_child_line")

var Lit_27 *jrt.String = jrt.Intern("arbace.go.check.env$current_line")

var Lit_28 *jrt.String = jrt.Intern("arbace.go.check.env$err_BANG_")

var Lit_29 *jrt.String = jrt.Intern("arbace.go.check.env$generic_BANG_")

var Lit_30 *jrt.String = jrt.Intern("arbace.go.check.env$unsupported_BANG_")

var Lit_31 *jrt.String = jrt.Intern("arbace.go.check.env$unsupported_QMARK_")

var Lit_32 *jrt.String = jrt.Intern("arbace.go.check.env$verified_BANG_")

var Lit_33 *jrt.String = jrt.Intern("arbace.go.check.env$annotation_error_BANG_")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.check.env$at_of")

var Lit_35 *jrt.String = jrt.Intern("arbace.go.check.env$answer_BANG_")

var Lit_36 *jrt.String = jrt.Intern("arbace.go.check.env$def_type_BANG_")

var Lit_37 *jrt.String = jrt.Intern("arbace.go.check.env$fn__1719000073")

var Lit_38 *jrt.String = jrt.Intern("error")

var Lit_39 *jrt.String = jrt.Intern("any")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.check.env$fn__1719000079")

var Lit_41 *jrt.String = jrt.Intern("comparable")

var Lit_42 *jrt.String = jrt.Intern("true")

var Lit_43 *jrt.String = jrt.Intern("false")

var Lit_44 *jrt.String = jrt.Intern("iota")

var Lit_45 *jrt.String = jrt.Intern("nil")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.check.env$fn__1719000097")
