//line j2g_strings.ae:1
package aot_arbace_go_check_env

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn21,arbace.go.check.typesyn1,tyn21,arbace.go.check.constyn1,cyn11,arbace.corekn3,dockn6,parentkn5,nameskn4,kindkn4,filekn4,linekn3,msgkn4,codekn4,declkn2,idkn4,namekn7,generickn11,unsupportedkn16,unsupported-lineks19,arbace.go.check.env11,unsupportedkn4,seenkn8,verifiedkn18,AnnotationMismatchkn4,typekn8,universekn3,pkgkn10,underlyingkn9,interfacekn4,funckn6,stringkn10,comparablekn7,packagekn14,unsafe-pointerkn8,exportedkn7,builtinkn6,unsafev11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,v11,arbace.core5,referR7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn19,arbace.go.check.envm2,R8,s477,goi's checker: its state (doc/go/GOI-SPEC.md §3.3): objects, scopes, the universe, errors,\n  and the per-declaration records of the annotations verified (§3.6).\n\n  Objects are volatiles holding maps, so that they have identity (=, hash) and can be completed\n  as the checker resolves them: {:kind :var|:const|:type|:func|:pkg|:label|:builtin|:nil,\n  :name, :type, :pkg (the package path), :file, :line, ...}. A scope is {:parent :names\n  (a HashMap from name to object) :kind}.v11,arbace.core9,volatile!v11,arbace.core5,assocR9,R10,R11,v19,arbace.go.check.env8,*errors*R12,R13,R14,R15,R16,v19,arbace.go.check.env6,*decl*v19,arbace.go.check.env1,oR17,v19,arbace.go.check.env6,error!R18,v19,arbace.go.check.env8,*gofile*v19,arbace.go.check.env7,line-ofv19,arbace.go.check.env6,*line*v11,arbace.core3,seqv11,arbace.core5,applyv11,arbace.core6,formatR19,v19,arbace.go.check.env8,generic!R20,R21,R22,v11,arbace.core7,ex-datav19,arbace.go.check.env6,*seen*R23,v11,arbace.core9,contains?v19,arbace.go.check.env9,verified!v11,arbace.core9,update-inR24,v11,arbace.core4,fnilv11,arbace.core3,incl0,v19,arbace.go.check.env4,err!R25,v19,arbace.go.check.env10,scope-put!v19,arbace.go.check.env8,universev19,arbace.go.check.env3,objR26,R27,v21,arbace.go.check.types9,new-namedm4,R18,s5,errorR28,nv21,arbace.go.check.types12,update-info!R29,R30,R28,R31,V1,R32,m4,R18,s10,comparableR28,nR33,v19,arbace.go.check.env5,scopeR34,m10,R11,R26,R18,s7,PointerR26,R35,R28,s6,unsafeR36,TV8,s6,Sizeofs7,Alignofs8,Offsetofs3,Adds5,Slices9,SliceDatas6,Strings10,StringDatav11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstR37,R38,v11,arbace.core10,chunk-restv11,arbace.core4,next")

var Lit_1 *jrt.String = jrt.Intern("annotation %s on %s disagrees with goi's checker: forms say %s, the checker says %s")

var Lit_2 *jrt.String = jrt.Intern("Error")

var Lit_3 *jrt.String = jrt.Intern("Pointer")

var Lit_4 *jrt.String = jrt.Intern("unsafe")

var Lit_5 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn1,mkn4,linekn6,columnkn4,fileyn1,xyn1,kyn1,vyn6,parentyn4,kindyn1,skn3,tagyn6,Stringkn7,dynamicyn4,lineyn4,codeyn3,msgyn4,fileyn4,formyn1,fyn3,fmtyn1,&yn4,argsyn4,whatyn1,eyn1,ayn9,forms-sayyn12,checker-sayskn8,universekn7,privateyn1,nyn2,kwkn4,boolkn4,int8kn5,int16kn5,int32kn5,int64kn3,intkn5,uint8kn6,uint16kn6,uint32kn6,uint64kn4,uintkn7,uintptrkn7,float32kn7,float64kn9,complex64kn10,complex128kn6,stringkn4,kindkn4,typekn4,namekn5,aliaskn9,interfacekn5,constkn12,untyped-boolkn3,valkn11,untyped-intkn4,iotakn3,nilkn11,untyped-nilkn7,builtinkn4,pathkn5,scopekn4,fakev11,arbace.core5,in-nsMyn19,arbace.go.check.envm2,R0,s477,goi's checker: its state (doc/go/GOI-SPEC.md §3.3): objects, scopes, the universe, errors,\n  and the per-declaration records of the annotations verified (§3.6).\n\n  Objects are volatiles holding maps, so that they have identity (=, hash) and can be completed\n  as the checker resolves them: {:kind :var|:const|:type|:func|:pkg|:label|:builtin|:nil,\n  :name, :type, :pkg (the package path), :file, :line, ...}. A scope is {:parent :names\n  (a HashMap from name to object) :kind}.m2,R0,s477,goi's checker: its state (doc/go/GOI-SPEC.md §3.3): objects, scopes, the universe, errors,\n  and the per-declaration records of the annotations verified (§3.6).\n\n  Objects are volatiles holding maps, so that they have identity (=, hash) and can be completed\n  as the checker resolves them: {:kind :var|:const|:type|:func|:pkg|:label|:builtin|:nil,\n  :name, :type, :pkg (the package path), :file, :line, ...}. A scope is {:parent :names\n  (a HashMap from name to object) :kind}.R1,v19,arbace.go.check.env3,objm8,R2,L1,V1,R3,R4,i15,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env1,om8,R2,L1,V2,R7,R8,R4,i16,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env5,oset!m8,R2,L1,V3,R7,R8,R9,R4,i17,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env4,obj?m8,R2,L1,V1,R7,R4,i18,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env5,scopem8,R2,L1,V2,R10,R11,R4,i22,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env12,scope-lookupm10,R2,L1,V2,R12,Myn1,nm2,R13,R14,R0,s53,The object named n in scope s or its parents, or nil.R4,i24,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env9,scope-getm8,R2,L1,V2,R12,Myn1,nm2,R13,R14,R4,i33,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env10,scope-put!m8,R2,L1,V3,R12,Myn1,nm2,R13,R14,R7,R4,i34,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env5,*pkg*m10,R15,TR4,i38,R5,i1,R6,s22,arbace/go/check/env.aeR0,s84,The package being checked: a volatile {:path :name :scope :files :config :lang ...}.v19,arbace.go.check.env8,*gofile*m10,R15,TR4,i42,R5,i1,R6,s22,arbace/go/check/env.aeR0,s54,The file being checked: {:name :scope :lang :imports}.v19,arbace.go.check.env6,*decl*m10,R15,TR4,i46,R5,i1,R6,s22,arbace/go/check/env.aeR0,s72,The package-level declaration being checked: its decl info (a volatile).v19,arbace.go.check.env9,*session*m10,R15,TR4,i50,R5,i1,R6,s22,arbace/go/check/env.aeR0,s65,The checking session: {:packages (an atom: path -> package) ...}.v19,arbace.go.check.env8,*errors*m10,R15,TR4,i56,R5,i1,R6,s22,arbace/go/check/env.aeR0,s42,A volatile vector of the package's errors.v19,arbace.go.check.env6,error!m10,R2,L2,V3,R16,R17,R18,V4,R19,R16,R17,R18,R0,s81,Records an error at line (the current file's), go/types' code kw and message msg.R4,i58,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env7,line-ofm10,R2,L1,V1,R20,R0,s39,The :line of a form's metadata, or nil.R4,i68,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env6,*line*m10,R15,TR4,i74,R5,i1,R6,s22,arbace/go/check/env.aeR0,s52,The line of the innermost form with one, for errors.v19,arbace.go.check.env4,err!m10,R2,L1,V5,R21,R17,R22,R23,R24,R0,s48,An error at form f's line (or the current line).R4,i76,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env8,generic!m10,R2,L1,V0,R0,s108,Marks the current declaration as using generics: it is counted apart and its errors are\n  not counted (S53).R4,i83,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env12,unsupported!m10,R2,L1,V1,R25,R0,s264,Marks the current declaration as using what GR2's checker does not check (generic code):\n  it is counted apart (S53), its errors not counted; checking goes on (its references, the\n  imports it uses, its dependencies are recorded), the operand invalid. Returns nil.R4,i89,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env12,unsupported?m8,R2,L1,V1,R26,R4,i99,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env6,*seen*m10,R15,TR4,i103,R5,i1,R6,s22,arbace/go/check/env.aeR0,s135,The package's annotated forms verified (an IdentityHashMap): a form checked twice (an\n  implicitly repeated constant init) counts once.v19,arbace.go.check.env9,verified!m10,R2,L2,V1,R8,V2,R8,R21,R0,s180,Counts an annotation of kind k (:val :tag :go/via :assign :conv :init-order) verified in the\n  current declaration, once per form (f, when given: a form checked twice counts once).R4,i108,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env17,annotation-error!m10,R2,L1,V5,R21,R27,R25,R28,R29,R0,s52,An annotation that disagrees with the checker (S16).R4,i121,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env8,universeR30,m6,R4,i129,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env9,def-type!m10,R31,TR2,L1,V2,R32,R33,R4,i131,R5,i1,R6,s22,arbace/go/check/env.aev11,arbace.core3,seqV19,V2,s4,boolR34,V2,s4,int8R35,V2,s5,int16R36,V2,s5,int32R37,V2,s5,int64R38,V2,s3,intR39,V2,s5,uint8R40,V2,s6,uint16R41,V2,s6,uint32R42,V2,s6,uint64R43,V2,s4,uintR44,V2,s7,uintptrR45,V2,s7,float32R46,V2,s7,float64R47,V2,s9,complex64R48,V2,s10,complex128R49,V2,s6,stringR50,V2,s4,byteR40,V2,s4,runeR37,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv11,arbace.core10,chunk-restv11,arbace.core4,nextv19,arbace.go.check.env10,error-typem6,R4,i140,R5,i1,R6,s22,arbace/go/check/env.aeR51,R52,R53,R54,R55,v19,arbace.go.check.env15,comparable-typem6,R4,i149,R5,i1,R6,s22,arbace/go/check/env.aem10,R51,R56,R53,s4,trueR52,R57,R58,TR30,Tm10,R51,R56,R53,s5,falseR52,R57,R58,FR30,Tm12,R51,R56,R53,s4,iotaR52,R59,R58,l0,R60,TR30,Tm8,R51,R61,R53,s3,nilR52,R62,R30,Tv19,arbace.go.check.env13,builtin-namesV18,s6,appends3,caps5,clears5,closes7,complexs4,copys6,deletes4,imags3,lens4,makes3,maxs3,mins3,news5,panics5,prints7,printlns4,reals7,recoverm6,R4,i161,R5,i1,R6,s22,arbace/go/check/env.aeR63,v19,arbace.go.check.env12,unsafe-scopem6,R4,i170,R5,i1,R6,s22,arbace/go/check/env.aev19,arbace.go.check.env14,unsafe-packagev11,arbace.core9,volatile!R64,R65,R66,m6,R4,i177,R5,i1,R6,s22,arbace/go/check/env.ae")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.check.env$eval1719000004$loading__1927001464__auto____1719000005")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.check.env$eval1719000008$fn__1719000009")

var Lit_8 *jrt.String = jrt.Intern("arbace.go.check.env$obj")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.check.env$o")

var Lit_10 *jrt.String = jrt.Intern("arbace.go.check.env$oset_BANG_")

var Lit_11 *jrt.String = jrt.Intern("arbace.go.check.env$obj_QMARK_")

var Lit_12 *jrt.String = jrt.Intern("arbace.go.check.env$scope")

var Lit_13 *jrt.String = jrt.Intern("arbace.go.check.env$scope_lookup")

var Lit_14 *jrt.String = jrt.Intern("arbace.go.check.env$scope_get")

var Lit_15 *jrt.String = jrt.Intern("arbace.go.check.env$scope_put_BANG_")

var Lit_16 *jrt.String = jrt.Intern("arbace.go.check.env$error_BANG_")

var Lit_17 *jrt.String = jrt.Intern("arbace.go.check.env$line_of")

var Lit_18 *jrt.String = jrt.Intern("arbace.go.check.env$err_BANG_")

var Lit_19 *jrt.String = jrt.Intern("arbace.go.check.env$generic_BANG_")

var Lit_20 *jrt.String = jrt.Intern("arbace.go.check.env$unsupported_BANG_")

var Lit_21 *jrt.String = jrt.Intern("arbace.go.check.env$unsupported_QMARK_")

var Lit_22 *jrt.String = jrt.Intern("arbace.go.check.env$verified_BANG_")

var Lit_23 *jrt.String = jrt.Intern("arbace.go.check.env$annotation_error_BANG_")

var Lit_24 *jrt.String = jrt.Intern("arbace.go.check.env$def_type_BANG_")

var Lit_25 *jrt.String = jrt.Intern("arbace.go.check.env$fn__1719000041")

var Lit_26 *jrt.String = jrt.Intern("error")

var Lit_27 *jrt.String = jrt.Intern("any")

var Lit_28 *jrt.String = jrt.Intern("arbace.go.check.env$fn__1719000047")

var Lit_29 *jrt.String = jrt.Intern("comparable")

var Lit_30 *jrt.String = jrt.Intern("true")

var Lit_31 *jrt.String = jrt.Intern("false")

var Lit_32 *jrt.String = jrt.Intern("iota")

var Lit_33 *jrt.String = jrt.Intern("nil")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.check.env$fn__1719000065")
