//line aot_arbace_go_check_env__init.ae:1
package aot_arbace_go_check_env

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_env__init_A_Unit0__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_check_env__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env__init_A_const_1) }
//line :1:1
func A_arbace_go_check_env__init_A_Unit1__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_check_env__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_2)) }
//line :1:1
func A_arbace_go_check_env__init_A_Unit2__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_go_check_env__init_A_Unit3__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_check_env__init_A_const_1)).Equals_O__Z(A_arbace_go_check_env__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_go_check_env_eval1719000008_fn__1719000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_go_check_env__init_A_Load__O() any { A_arbace_go_check_env__init_A_Init(); jrt.StartCheck(); A_arbace_go_check_env__init_A_Unit0__O(); A_arbace_go_check_env__init_A_Unit1__O(); A_arbace_go_check_env__init_A_Unit2__O(); A_arbace_go_check_env__init_A_Unit3__O(); A_arbace_go_check_env__init_A_Unit4__O(); A_arbace_go_check_env__init_A_Unit5__O(); A_arbace_go_check_env__init_A_Unit6__O(); A_arbace_go_check_env__init_A_Unit7__O(); A_arbace_go_check_env__init_A_Unit8__O(); A_arbace_go_check_env__init_A_Unit9__O(); A_arbace_go_check_env__init_A_Unit10__O(); A_arbace_go_check_env__init_A_Unit11__O(); A_arbace_go_check_env__init_A_Unit12__O(); A_arbace_go_check_env__init_A_Unit13__O(); A_arbace_go_check_env__init_A_Unit14__O(); A_arbace_go_check_env__init_A_Unit15__O(); A_arbace_go_check_env__init_A_Unit16__O(); A_arbace_go_check_env__init_A_Unit17__O(); A_arbace_go_check_env__init_A_Unit18__O(); A_arbace_go_check_env__init_A_Unit19__O(); A_arbace_go_check_env__init_A_Unit20__O(); A_arbace_go_check_env__init_A_Unit21__O(); A_arbace_go_check_env__init_A_Unit22__O(); A_arbace_go_check_env__init_A_Unit23__O(); A_arbace_go_check_env__init_A_Unit24__O(); A_arbace_go_check_env__init_A_Unit25__O(); A_arbace_go_check_env__init_A_Unit26__O(); A_arbace_go_check_env__init_A_Unit27__O(); A_arbace_go_check_env__init_A_Unit28__O(); A_arbace_go_check_env__init_A_Unit29__O(); A_arbace_go_check_env__init_A_Unit30__O(); A_arbace_go_check_env__init_A_Unit31__O(); A_arbace_go_check_env__init_A_Unit32__O(); A_arbace_go_check_env__init_A_Unit33__O(); A_arbace_go_check_env__init_A_Unit34__O(); A_arbace_go_check_env__init_A_Unit35__O(); A_arbace_go_check_env__init_A_Unit36__O(); A_arbace_go_check_env__init_A_Unit37__O(); A_arbace_go_check_env__init_A_Unit38__O(); A_arbace_go_check_env__init_A_Unit39__O(); A_arbace_go_check_env__init_A_Unit40__O(); A_arbace_go_check_env__init_A_Unit41__O(); A_arbace_go_check_env__init_A_Unit42__O(); A_arbace_go_check_env__init_A_Unit43__O(); A_arbace_go_check_env__init_A_Unit44__O(); A_arbace_go_check_env__init_A_Unit45__O(); A_arbace_go_check_env__init_A_Unit46__O(); A_arbace_go_check_env__init_A_Unit47__O(); A_arbace_go_check_env__init_A_Unit48__O(); A_arbace_go_check_env__init_A_Unit49__O(); A_arbace_go_check_env__init_A_Unit50__O(); A_arbace_go_check_env__init_A_Unit51__O(); A_arbace_go_check_env__init_A_Unit52__O(); A_arbace_go_check_env__init_A_Unit53__O(); A_arbace_go_check_env__init_A_Unit54__O(); A_arbace_go_check_env__init_A_Unit55__O(); return nil }









func A_arbace_go_check_env__init_A_Unit4__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_4; var tmp2 any = A_arbace_go_check_env_obj_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_env_obj_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_go_check_env_obj_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_5)); return A_arbace_go_check_env__init_A_const_4 }
func A_arbace_go_check_env__init_A_Unit5__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_6; var tmp2 any = A_arbace_go_check_env_o_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_go_check_env_o_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_go_check_env_o_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_7)); return A_arbace_go_check_env__init_A_const_6 }
func A_arbace_go_check_env__init_A_Unit6__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_8; var tmp2 any = A_arbace_go_check_env_oset_BANG__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_env_oset_BANG__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_go_check_env_oset_BANG__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_9)); return A_arbace_go_check_env__init_A_const_8 }
func A_arbace_go_check_env__init_A_Unit7__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_10; var tmp2 any = A_arbace_go_check_env_obj_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_go_check_env_obj_QMARK__A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_go_check_env_obj_QMARK__A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_11)); return A_arbace_go_check_env__init_A_const_10 }



func A_arbace_go_check_env__init_A_Unit8__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_12; var tmp2 any = A_arbace_go_check_env_scope_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_env_scope_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_go_check_env_scope_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_13)); return A_arbace_go_check_env__init_A_const_12 }

func A_arbace_go_check_env__init_A_Unit9__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_14; var tmp2 any = A_arbace_go_check_env_scope_lookup_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_go_check_env_scope_lookup_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_go_check_env_scope_lookup_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_15)); return A_arbace_go_check_env__init_A_const_14 }








func A_arbace_go_check_env__init_A_Unit10__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_16; var tmp2 any = A_arbace_go_check_env_scope_get_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_env_scope_get_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_go_check_env_scope_get_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_17)); return A_arbace_go_check_env__init_A_const_16 }
func A_arbace_go_check_env__init_A_Unit11__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_18; var tmp2 any = A_arbace_go_check_env_scope_put_BANG__A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_go_check_env_scope_put_BANG__A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_go_check_env_scope_put_BANG__A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_19)); return A_arbace_go_check_env__init_A_const_18 }



func A_arbace_go_check_env__init_A_Unit12__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); A_arbace_go_check_env__init_A_const_20.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_21)); return A_arbace_go_check_env__init_A_const_20.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit13__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); A_arbace_go_check_env__init_A_const_22.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_23)); return A_arbace_go_check_env__init_A_const_22.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit14__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); A_arbace_go_check_env__init_A_const_24.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_24; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_25)); return A_arbace_go_check_env__init_A_const_24.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit15__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); A_arbace_go_check_env__init_A_const_26.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_27)); return A_arbace_go_check_env__init_A_const_26.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check_env__init_A_Unit16__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); A_arbace_go_check_env__init_A_const_28.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_29)); return A_arbace_go_check_env__init_A_const_28.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check_env__init_A_Unit17__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); A_arbace_go_check_env__init_A_const_30.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_31)); return A_arbace_go_check_env__init_A_const_30.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check_env__init_A_Unit18__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_32; var tmp2 any = A_arbace_go_check_env_error_BANG__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_env_error_BANG__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_go_check_env_error_BANG__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_33)); return A_arbace_go_check_env__init_A_const_32 }















func A_arbace_go_check_env__init_A_Unit19__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(80, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_34; var tmp2 any = A_arbace_go_check_env_line_of_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_go_check_env_line_of_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_go_check_env_line_of_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_35)); return A_arbace_go_check_env__init_A_const_34 }





func A_arbace_go_check_env__init_A_Unit20__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(86, 1); A_arbace_go_check_env__init_A_const_36.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_36; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_37)); return A_arbace_go_check_env__init_A_const_36.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check_env__init_A_Unit21__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(88, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_39)); return A_arbace_go_check_env__init_A_const_38 }

func A_arbace_go_check_env__init_A_Unit22__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(90, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_40; var tmp2 any = A_arbace_go_check_env_end_line_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_env_end_line_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_go_check_env_end_line_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_41)); return A_arbace_go_check_env__init_A_const_40 }










func A_arbace_go_check_env__init_A_Unit23__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_38; var tmp2 any = A_arbace_go_check_env_child_line_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_go_check_env_child_line_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_go_check_env_child_line_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_42)); return A_arbace_go_check_env__init_A_const_38 }



















func A_arbace_go_check_env__init_A_Unit24__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(121, 1); A_arbace_go_check_env__init_A_const_43.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_44)); return A_arbace_go_check_env__init_A_const_43.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_env__init_A_Unit25__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_45; var tmp2 any = A_arbace_go_check_env_with_child_line_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_env_with_child_line_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, true); A_arbace_go_check_env_with_child_line_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_46)); return A_arbace_go_check_env__init_A_const_45 }
//line :126:1
func A_arbace_go_check_env__init_A_Unit26__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); A_arbace_go_check_env__init_A_const_45.SetMacro__V(); return nil }
//line :126:1
func A_arbace_go_check_env__init_A_Unit27__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); return A_arbace_go_check_env__init_A_const_45 }







func A_arbace_go_check_env__init_A_Unit28__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(134, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_47; var tmp2 any = A_arbace_go_check_env_current_line_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_go_check_env_current_line_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_go_check_env_current_line_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_48)); return A_arbace_go_check_env__init_A_const_47 }




func A_arbace_go_check_env__init_A_Unit29__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_49; var tmp2 any = A_arbace_go_check_env_err_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_check_env_err_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, true); A_arbace_go_check_env_err_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_50)); return A_arbace_go_check_env__init_A_const_49 }






func A_arbace_go_check_env__init_A_Unit30__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(146, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_51; var tmp2 any = A_arbace_go_check_env_generic_BANG__A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_go_check_env_generic_BANG__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_go_check_env_generic_BANG__A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_52)); return A_arbace_go_check_env__init_A_const_51 }





func A_arbace_go_check_env__init_A_Unit31__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(152, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_53; var tmp2 any = A_arbace_go_check_env_unsupported_BANG__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_check_env_unsupported_BANG__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_go_check_env_unsupported_BANG__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_54)); return A_arbace_go_check_env__init_A_const_53 }









func A_arbace_go_check_env__init_A_Unit32__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(162, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_55; var tmp2 any = A_arbace_go_check_env_unsupported_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_go_check_env_unsupported_QMARK__A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_go_check_env_unsupported_QMARK__A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_56)); return A_arbace_go_check_env__init_A_const_55 }



func A_arbace_go_check_env__init_A_Unit33__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(166, 1); A_arbace_go_check_env__init_A_const_57.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_57; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_58)); return A_arbace_go_check_env__init_A_const_57.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_env__init_A_Unit34__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(171, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_59; var tmp2 any = A_arbace_go_check_env_verified_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_check_env_verified_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_go_check_env_verified_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_60)); return A_arbace_go_check_env__init_A_const_59 }












func A_arbace_go_check_env__init_A_Unit35__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(184, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_61; var tmp2 any = A_arbace_go_check_env_annotation_error_BANG__A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_go_check_env_annotation_error_BANG__A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_check_env_annotation_error_BANG__A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_62)); return A_arbace_go_check_env__init_A_const_61 }







func A_arbace_go_check_env__init_A_Unit36__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(192, 1); A_arbace_go_check_env__init_A_const_63.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_63; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_64)); return A_arbace_go_check_env__init_A_const_63.SetDynamic_Z__Var(true).Ref() }






func A_arbace_go_check_env__init_A_Unit37__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(199, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_65; var tmp2 any = A_arbace_go_check_env_at_of_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_check_env_at_of_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_check_env_at_of_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_66)); return A_arbace_go_check_env__init_A_const_65 }




func A_arbace_go_check_env__init_A_Unit38__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(204, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_67; var tmp2 any = A_arbace_go_check_env_answer_BANG__A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_go_check_env_answer_BANG__A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_check_env_answer_BANG__A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_68)); return A_arbace_go_check_env__init_A_const_67 }













func A_arbace_go_check_env__init_A_Unit39__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(218, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_69; var tmp2 any = A_arbace_go_check_env_unanswer_BANG__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_check_env_unanswer_BANG__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_go_check_env_unanswer_BANG__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_70)); return A_arbace_go_check_env__init_A_const_69 }









func A_arbace_go_check_env__init_A_Unit40__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(228, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_71; var tmp2 any; var root_26 any = A_arbace_go_check_env__init_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, A_arbace_go_check_env_scope_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any; var arg_30 any = A_arbace_go_check_env__init_A_const_72; if linked_27 == nil { tmp2 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { tmp2 = linked_27.(*A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_check_env__init_A_const_71; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_73)); return A_arbace_go_check_env__init_A_const_71 }

func A_arbace_go_check_env__init_A_Unit41__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(230, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_74; var tmp2 any = A_arbace_go_check_env_def_type_BANG__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_env_def_type_BANG__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_go_check_env_def_type_BANG__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_75)); return A_arbace_go_check_env__init_A_const_74 }




func A_arbace_go_check_env__init_A_Unit42__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(235, 1); { var seq_1719000062__1 any; var root_32 any = A_arbace_go_check_env__init_A_const_76.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = A_arbace_go_check_env__init_A_const_77; if linked_33 == nil { seq_1719000062__1 = ifn_34.Invoke_O__O(arg_35) } else { seq_1719000062__1 = linked_33.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_32, arg_35) }; var chunk_1719000063__2 any; var count_1719000064__3 int64 = 0; var i_1719000065__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000065__4, count_1719000064__3) { var vec__1719000067__5 any = lang.Indexed_Cast(chunk_1719000063__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000065__4)); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000067__5, lang.RT_IntCast_J__I_NoInit(0), nil); var kw__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000067__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_52 any = A_arbace_go_check_env__init_A_const_74.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, A_arbace_go_check_env_def_type_BANG__A_fn_class); var ifn_54 lang.IFn




	if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = n__6; var arg_56 any = kw__7; if linked_53 == nil { ifn_54.Invoke_O_O__O(arg_55, arg_56) } else { linked_53.(*A_arbace_go_check_env_def_type_BANG__A).Invoke_O_O_O__O(root_52, arg_55, arg_56) }
//line :235:1
	seq_1719000062__1, chunk_1719000063__2, count_1719000064__3, i_1719000065__4 = seq_1719000062__1, chunk_1719000063__2, count_1719000064__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000065__4); continue L1



} else {
//line :235:1
	var temp__1927000414__auto____5 any; var root_36 any = A_arbace_go_check_env__init_A_const_76.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = seq_1719000062__1; if linked_37 == nil { temp__1927000414__auto____5 = ifn_38.Invoke_O__O(arg_39) } else { temp__1927000414__auto____5 = linked_37.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_36, arg_39) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1719000062__6 any = temp__1927000414__auto____5; var tmp1 any; var root_40 any = A_arbace_go_check_env__init_A_const_78.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = seq_1719000062__6; if linked_41 == nil { tmp1 = ifn_42.Invoke_O__O(arg_43) } else { tmp1 = linked_41.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_40, arg_43) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____7 any; var root_44 any = A_arbace_go_check_env__init_A_const_79.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = seq_1719000062__6; if linked_45 == nil { c__1927000678__auto____7 = ifn_46.Invoke_O__O(arg_47) } else { c__1927000678__auto____7 = linked_45.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_44, arg_47) }; var tmp2 any; var root_57 any = A_arbace_go_check_env__init_A_const_81.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = seq_1719000062__6; if linked_58 == nil { tmp2 = ifn_59.Invoke_O__O(arg_60) } else { tmp2 = linked_58.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_57, arg_60) }; seq_1719000062__1, chunk_1719000063__2, count_1719000064__3, i_1719000065__4 = tmp2, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1719000070__7 any; var root_48 any = A_arbace_go_check_env__init_A_const_80.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = seq_1719000062__6; if linked_49 == nil { vec__1719000070__7 = ifn_50.Invoke_O__O(arg_51) } else { vec__1719000070__7 = linked_49.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_48, arg_51) }; var n__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000070__7, lang.RT_IntCast_J__I_NoInit(0), nil); var kw__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000070__7, lang.RT_IntCast_J__I_NoInit(1), nil); var root_61 any = A_arbace_go_check_env__init_A_const_74.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, A_arbace_go_check_env_def_type_BANG__A_fn_class); var ifn_63 lang.IFn




		if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = n__8; var arg_65 any = kw__9; if linked_62 == nil { ifn_63.Invoke_O_O__O(arg_64, arg_65) } else { linked_62.(*A_arbace_go_check_env_def_type_BANG__A).Invoke_O_O_O__O(root_61, arg_64, arg_65) }
//line :235:1
		var tmp3 any; var root_66 any = A_arbace_go_check_env__init_A_const_82.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = seq_1719000062__6; if linked_67 == nil { tmp3 = ifn_68.Invoke_O__O(arg_69) } else { tmp3 = linked_67.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_66, arg_69) }; seq_1719000062__1, chunk_1719000063__2, count_1719000064__3, i_1719000065__4 = tmp3, nil, 0, 0; continue L1 } } else { return nil
		}
}
}
}
	panic("j2g: unreachable")
}
func A_arbace_go_check_env__init_A_Unit43__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(242, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_83; var tmp2 any = A_arbace_go_check_env_fn__1719000074_A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_go_check_env_fn__1719000074_A_fn_class; if
							fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_go_check_env_fn__1719000074_A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; /*line :242:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_84)); return A_arbace_go_check_env__init_A_const_83 }





func A_arbace_go_check_env__init_A_Unit44__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(248, 1); var root_71 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_75 any = Lit_39; var arg_76 any; var root_77 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, A_arbace_go_check_env_obj_A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_85; var tmp2 any = A_arbace_go_check_env__init_A_const_86; var tmp3 any = A_arbace_go_check_env__init_A_const_87; var tmp4 any = A_arbace_go_check_env__init_A_const_86; var arg_80 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_39, tmp4, A_arbace_go_check_env__init_A_const_83.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_72, jrt.Boolean_TRUE.Ref())); if linked_78 == nil { arg_76 = ifn_79.Invoke_O__O(arg_80) } else { arg_76 = linked_78.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_77, arg_80) }; if linked_72 == nil { return ifn_73.Invoke_O_O_O__O(arg_74, arg_75, arg_76) } else { return linked_72.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_71, arg_74, arg_75, arg_76) } }
func A_arbace_go_check_env__init_A_Unit45__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(249, 1); var root_81 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_85 any = Lit_40; var arg_86 any; var root_87 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, A_arbace_go_check_env_obj_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_85; var tmp2 any = A_arbace_go_check_env__init_A_const_86; var tmp3 any = A_arbace_go_check_env__init_A_const_87; var tmp4 any = A_arbace_go_check_env__init_A_const_86; var arg_90 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_40, tmp4, lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_env__init_A_const_89, lang.PersistentVector_EMPTY.Ref(), nil), A_arbace_go_check_env__init_A_const_88, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_env__init_A_const_72, jrt.Boolean_TRUE.Ref())); if linked_88 == nil { arg_86 = ifn_89.Invoke_O__O(arg_90) } else { arg_86 = linked_88.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_87, arg_90) }; if linked_82 == nil { return ifn_83.Invoke_O_O_O__O(arg_84, arg_85, arg_86) } else { return linked_82.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_81, arg_84, arg_85, arg_86) } }

func A_arbace_go_check_env__init_A_Unit46__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(251, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_90; var tmp2 any = A_arbace_go_check_env_fn__1719000080_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_go_check_env_fn__1719000080_A_fn_class; if
							fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_check_env_fn__1719000080_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; /*line :251:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_91)); return A_arbace_go_check_env__init_A_const_90 }




func A_arbace_go_check_env__init_A_Unit47__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); var root_92 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_96 any = Lit_42; var arg_97 any; var root_98 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, A_arbace_go_check_env_obj_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_85; var tmp2 any = A_arbace_go_check_env__init_A_const_86; var tmp3 any = A_arbace_go_check_env__init_A_const_87; var tmp4 any = A_arbace_go_check_env__init_A_const_86; var arg_101 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_42, tmp4, A_arbace_go_check_env__init_A_const_90.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_72, jrt.Boolean_TRUE.Ref())); if linked_99 == nil { arg_97 = ifn_100.Invoke_O__O(arg_101) } else { arg_97 = linked_99.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_98, arg_101) }; if linked_93 == nil { return ifn_94.Invoke_O_O_O__O(arg_95, arg_96, arg_97) } else { return linked_93.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_92, arg_95, arg_96, arg_97) } }

func A_arbace_go_check_env__init_A_Unit48__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(258, 1); var root_102 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_106 any = Lit_43; var arg_107 any; var root_108 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, A_arbace_go_check_env_obj_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = A_arbace_go_check_env__init_A_const_92; if linked_109 == nil { arg_107 = ifn_110.Invoke_O__O(arg_111) } else { arg_107 = linked_109.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_108, arg_111) }; if linked_103 == nil { return ifn_104.Invoke_O_O_O__O(arg_105, arg_106, arg_107) } else { return linked_103.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_102, arg_105, arg_106, arg_107) } }
func A_arbace_go_check_env__init_A_Unit49__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(259, 1); var root_112 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_116 any = Lit_44; var arg_117 any; var root_118 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, A_arbace_go_check_env_obj_A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = A_arbace_go_check_env__init_A_const_93; if linked_119 == nil { arg_117 = ifn_120.Invoke_O__O(arg_121) } else { arg_117 = linked_119.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_118, arg_121) }; if linked_113 == nil { return ifn_114.Invoke_O_O_O__O(arg_115, arg_116, arg_117) } else { return linked_113.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_112, arg_115, arg_116, arg_117) } }
func A_arbace_go_check_env__init_A_Unit50__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(260, 1); var root_122 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_126 any = Lit_45; var arg_127 any; var root_128 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, A_arbace_go_check_env_obj_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = A_arbace_go_check_env__init_A_const_94; if linked_129 == nil { arg_127 = ifn_130.Invoke_O__O(arg_131) } else { arg_127 = linked_129.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_128, arg_131) }; if linked_123 == nil { return ifn_124.Invoke_O_O_O__O(arg_125, arg_126, arg_127) } else { return linked_123.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_122, arg_125, arg_126, arg_127) } }
func A_arbace_go_check_env__init_A_Unit51__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(261, 1); var root_132 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_136 any = Lit_46; var arg_137 any; var root_138 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, A_arbace_go_check_env_obj_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = A_arbace_go_check_env__init_A_const_95; if linked_139 == nil { arg_137 = ifn_140.Invoke_O__O(arg_141) } else { arg_137 = linked_139.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_138, arg_141) }; if linked_133 == nil { return ifn_134.Invoke_O_O_O__O(arg_135, arg_136, arg_137) } else { return linked_133.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_132, arg_135, arg_136, arg_137) } }

func A_arbace_go_check_env__init_A_Unit52__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(263, 1); A_arbace_go_check_env__init_A_const_96.BindRoot_O__V(A_arbace_go_check_env__init_A_const_97); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_96; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_98)); return A_arbace_go_check_env__init_A_const_96 }



func A_arbace_go_check_env__init_A_Unit53__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(267, 1); { var seq_1719000092__1 any; var root_142 any = A_arbace_go_check_env__init_A_const_76.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = A_arbace_go_check_env__init_A_const_96.GetRawRoot__O(); if linked_143 == nil { seq_1719000092__1 = ifn_144.Invoke_O__O(arg_145) } else { seq_1719000092__1 = linked_143.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_142, arg_145) }; var chunk_1719000093__2 any; var count_1719000094__3 int64 = 0; var i_1719000095__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000095__4, count_1719000094__3) { var n__5 any = lang.Indexed_Cast(chunk_1719000093__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000095__4)); var root_162 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_164 lang.IFn
	if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_166 any = n__5; var arg_167 any; var root_168 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_go_check_env_obj_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env__init_A_const_85, A_arbace_go_check_env__init_A_const_99, A_arbace_go_check_env__init_A_const_87, n__5, A_arbace_go_check_env__init_A_const_72, jrt.Boolean_TRUE.Ref())); if linked_169 == nil { arg_167 = ifn_170.Invoke_O__O(arg_171) } else { arg_167 = linked_169.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_168, arg_171) }; if linked_163 == nil { ifn_164.Invoke_O_O_O__O(arg_165, arg_166, arg_167) } else { linked_163.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_162, arg_165, arg_166, arg_167) }
//line :267:1
	seq_1719000092__1, chunk_1719000093__2, count_1719000094__3, i_1719000095__4 = seq_1719000092__1, chunk_1719000093__2, count_1719000094__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000095__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_146 any = A_arbace_go_check_env__init_A_const_76.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = seq_1719000092__1; if linked_147 == nil { temp__1927000414__auto____5 = ifn_148.Invoke_O__O(arg_149) } else { temp__1927000414__auto____5 = linked_147.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_146, arg_149) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1719000092__6 any = temp__1927000414__auto____5; var tmp1 any; var root_150 any = A_arbace_go_check_env__init_A_const_78.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = seq_1719000092__6; if linked_151 == nil { tmp1 = ifn_152.Invoke_O__O(arg_153) } else { tmp1 = linked_151.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_150, arg_153) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____7 any; var root_154 any = A_arbace_go_check_env__init_A_const_79.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = seq_1719000092__6; if linked_155 == nil { c__1927000678__auto____7 = ifn_156.Invoke_O__O(arg_157) } else { c__1927000678__auto____7 = linked_155.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_154, arg_157) }; var tmp2 any; var root_172 any = A_arbace_go_check_env__init_A_const_81.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = seq_1719000092__6; if linked_173 == nil { tmp2 = ifn_174.Invoke_O__O(arg_175) } else { tmp2 = linked_173.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_172, arg_175) }; seq_1719000092__1, chunk_1719000093__2, count_1719000094__3, i_1719000095__4 = tmp2, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__7 any; var root_158 any = A_arbace_go_check_env__init_A_const_80.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = seq_1719000092__6; if linked_159 == nil { n__7 = ifn_160.Invoke_O__O(arg_161) } else { n__7 = linked_159.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_158, arg_161) }
		var root_176 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_180 any = n__7; var arg_181 any; var root_182 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, A_arbace_go_check_env_obj_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env__init_A_const_85, A_arbace_go_check_env__init_A_const_99, A_arbace_go_check_env__init_A_const_87, n__7, A_arbace_go_check_env__init_A_const_72, jrt.Boolean_TRUE.Ref())); if linked_183 == nil { arg_181 = ifn_184.Invoke_O__O(arg_185) } else { arg_181 = linked_183.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_182, arg_185) }; if linked_177 == nil { ifn_178.Invoke_O_O_O__O(arg_179, arg_180, arg_181) } else { linked_177.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_176, arg_179, arg_180, arg_181) }
//line :267:1
		var tmp3 any; var root_186 any = A_arbace_go_check_env__init_A_const_82.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = seq_1719000092__6; if linked_187 == nil { tmp3 = ifn_188.Invoke_O__O(arg_189) } else { tmp3 = linked_187.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_186, arg_189) }; seq_1719000092__1, chunk_1719000093__2, count_1719000094__3, i_1719000095__4 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } }
	panic("j2g: unreachable")
}


func A_arbace_go_check_env__init_A_Unit54__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(272, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_100; var tmp2 any = A_arbace_go_check_env_fn__1719000098_A_New(); var tmp3 *jrt.Class; var fncls__190 *jrt.Class = A_arbace_go_check_env_fn__1719000098_A_fn_class; if
							fncls__190 == nil { var fncls__190d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_go_check_env_fn__1719000098_A_fn_class = fncls__190d; tmp3 = fncls__190d } else { tmp3 = fncls__190 }; /*line :272:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_101)); return A_arbace_go_check_env__init_A_const_100 }






func A_arbace_go_check_env__init_A_Unit55__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(279, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_102; var tmp2 any; var root_191 any = A_arbace_go_check_env__init_A_const_103.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var tmp3 any = A_arbace_go_check_env__init_A_const_104; var tmp4 any = A_arbace_go_check_env__init_A_const_87; var tmp5 any = A_arbace_go_check_env__init_A_const_105; var arg_194 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, Lit_10, tmp4, Lit_10, tmp5, A_arbace_go_check_env__init_A_const_100.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_106, jrt.Boolean_TRUE.Ref())); if linked_192 == nil { tmp2 = ifn_193.Invoke_O__O(arg_194) } else { tmp2 = linked_192.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_191, arg_194) }; tmp1.BindRoot_O__V(tmp2); var tmp6 *lang.Var = A_arbace_go_check_env__init_A_const_102; tmp6.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_107)); return A_arbace_go_check_env__init_A_const_102 }



type A_arbace_go_check_env__init_A struct{ jrt.Object }

var A_arbace_go_check_env__init_A_const_pool *jrt.RefArray

var A_arbace_go_check_env__init_A_const_0 *lang.Var

var A_arbace_go_check_env__init_A_const_1 any

var A_arbace_go_check_env__init_A_const_2 any

var A_arbace_go_check_env__init_A_const_3 any

var A_arbace_go_check_env__init_A_const_4 *lang.Var

var A_arbace_go_check_env__init_A_const_5 any

var A_arbace_go_check_env__init_A_const_6 *lang.Var

var A_arbace_go_check_env__init_A_const_7 any

var A_arbace_go_check_env__init_A_const_8 *lang.Var

var A_arbace_go_check_env__init_A_const_9 any

var A_arbace_go_check_env__init_A_const_10 *lang.Var

var A_arbace_go_check_env__init_A_const_11 any

var A_arbace_go_check_env__init_A_const_12 *lang.Var

var A_arbace_go_check_env__init_A_const_13 any

var A_arbace_go_check_env__init_A_const_14 *lang.Var

var A_arbace_go_check_env__init_A_const_15 any

var A_arbace_go_check_env__init_A_const_16 *lang.Var

var A_arbace_go_check_env__init_A_const_17 any

var A_arbace_go_check_env__init_A_const_18 *lang.Var

var A_arbace_go_check_env__init_A_const_19 any

var A_arbace_go_check_env__init_A_const_20 *lang.Var

var A_arbace_go_check_env__init_A_const_21 any

var A_arbace_go_check_env__init_A_const_22 *lang.Var

var A_arbace_go_check_env__init_A_const_23 any

var A_arbace_go_check_env__init_A_const_24 *lang.Var

var A_arbace_go_check_env__init_A_const_25 any

var A_arbace_go_check_env__init_A_const_26 *lang.Var

var A_arbace_go_check_env__init_A_const_27 any

var A_arbace_go_check_env__init_A_const_28 *lang.Var

var A_arbace_go_check_env__init_A_const_29 any

var A_arbace_go_check_env__init_A_const_30 *lang.Var

var A_arbace_go_check_env__init_A_const_31 any

var A_arbace_go_check_env__init_A_const_32 *lang.Var

var A_arbace_go_check_env__init_A_const_33 any

var A_arbace_go_check_env__init_A_const_34 *lang.Var

var A_arbace_go_check_env__init_A_const_35 any

var A_arbace_go_check_env__init_A_const_36 *lang.Var

var A_arbace_go_check_env__init_A_const_37 any

var A_arbace_go_check_env__init_A_const_38 *lang.Var

var A_arbace_go_check_env__init_A_const_39 any

var A_arbace_go_check_env__init_A_const_40 *lang.Var

var A_arbace_go_check_env__init_A_const_41 any

var A_arbace_go_check_env__init_A_const_42 any

var A_arbace_go_check_env__init_A_const_43 *lang.Var

var A_arbace_go_check_env__init_A_const_44 any

var A_arbace_go_check_env__init_A_const_45 *lang.Var

var A_arbace_go_check_env__init_A_const_46 any

var A_arbace_go_check_env__init_A_const_47 *lang.Var

var A_arbace_go_check_env__init_A_const_48 any

var A_arbace_go_check_env__init_A_const_49 *lang.Var

var A_arbace_go_check_env__init_A_const_50 any

var A_arbace_go_check_env__init_A_const_51 *lang.Var

var A_arbace_go_check_env__init_A_const_52 any

var A_arbace_go_check_env__init_A_const_53 *lang.Var

var A_arbace_go_check_env__init_A_const_54 any

var A_arbace_go_check_env__init_A_const_55 *lang.Var

var A_arbace_go_check_env__init_A_const_56 any

var A_arbace_go_check_env__init_A_const_57 *lang.Var

var A_arbace_go_check_env__init_A_const_58 any

var A_arbace_go_check_env__init_A_const_59 *lang.Var

var A_arbace_go_check_env__init_A_const_60 any

var A_arbace_go_check_env__init_A_const_61 *lang.Var

var A_arbace_go_check_env__init_A_const_62 any

var A_arbace_go_check_env__init_A_const_63 *lang.Var

var A_arbace_go_check_env__init_A_const_64 any

var A_arbace_go_check_env__init_A_const_65 *lang.Var

var A_arbace_go_check_env__init_A_const_66 any

var A_arbace_go_check_env__init_A_const_67 *lang.Var

var A_arbace_go_check_env__init_A_const_68 any

var A_arbace_go_check_env__init_A_const_69 *lang.Var

var A_arbace_go_check_env__init_A_const_70 any

var A_arbace_go_check_env__init_A_const_71 *lang.Var

var A_arbace_go_check_env__init_A_const_72 *lang.Keyword

var A_arbace_go_check_env__init_A_const_73 any

var A_arbace_go_check_env__init_A_const_74 *lang.Var

var A_arbace_go_check_env__init_A_const_75 any

var A_arbace_go_check_env__init_A_const_76 *lang.Var

var A_arbace_go_check_env__init_A_const_77 any

var A_arbace_go_check_env__init_A_const_78 *lang.Var

var A_arbace_go_check_env__init_A_const_79 *lang.Var

var A_arbace_go_check_env__init_A_const_80 *lang.Var

var A_arbace_go_check_env__init_A_const_81 *lang.Var

var A_arbace_go_check_env__init_A_const_82 *lang.Var

var A_arbace_go_check_env__init_A_const_83 *lang.Var

var A_arbace_go_check_env__init_A_const_84 any

var A_arbace_go_check_env__init_A_const_85 *lang.Keyword

var A_arbace_go_check_env__init_A_const_86 *lang.Keyword

var A_arbace_go_check_env__init_A_const_87 *lang.Keyword

var A_arbace_go_check_env__init_A_const_88 *lang.Keyword

var A_arbace_go_check_env__init_A_const_89 *lang.Keyword

var A_arbace_go_check_env__init_A_const_90 *lang.Var

var A_arbace_go_check_env__init_A_const_91 any

var A_arbace_go_check_env__init_A_const_92 any

var A_arbace_go_check_env__init_A_const_93 any

var A_arbace_go_check_env__init_A_const_94 any

var A_arbace_go_check_env__init_A_const_95 any

var A_arbace_go_check_env__init_A_const_96 *lang.Var

var A_arbace_go_check_env__init_A_const_97 any

var A_arbace_go_check_env__init_A_const_98 any

var A_arbace_go_check_env__init_A_const_99 *lang.Keyword

var A_arbace_go_check_env__init_A_const_100 *lang.Var

var A_arbace_go_check_env__init_A_const_101 any

var A_arbace_go_check_env__init_A_const_102 *lang.Var

var A_arbace_go_check_env__init_A_const_103 *lang.Var

var A_arbace_go_check_env__init_A_const_104 *lang.Keyword

var A_arbace_go_check_env__init_A_const_105 *lang.Keyword

var A_arbace_go_check_env__init_A_const_106 *lang.Keyword

var A_arbace_go_check_env__init_A_const_107 any

var A_arbace_go_check_env__init_A_init jrt.ClassInit

func A_arbace_go_check_env__init_A_Init() { if !A_arbace_go_check_env__init_A_init.Done() { A_arbace_go_check_env__init_A_init.Run(A_arbace_go_check_env__init_A_clinit) } }

func A_arbace_go_check_env__init_A_clinit() { A_arbace_go_check_env__init_A_clinit_p0(); A_arbace_go_check_env__init_A_clinit_p1(); A_arbace_go_check_env__init_A_clinit_p2(); A_arbace_go_check_env__init_A_clinit_p3(); A_arbace_go_check_env__init_A_clinit_p4(); A_arbace_go_check_env__init_A_clinit_p5(); A_arbace_go_check_env__init_A_clinit_p6(); A_arbace_go_check_env__init_A_clinit_p7(); A_arbace_go_check_env__init_A_clinit_p8() }

func A_arbace_go_check_env__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_env__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_11, 182); A_arbace_go_check_env__init_A_const_0 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[74]); A_arbace_go_check_env__init_A_const_1 = A_arbace_go_check_env__init_A_const_pool.A[75]; A_arbace_go_check_env__init_A_const_2 = A_arbace_go_check_env__init_A_const_pool.A[76]; A_arbace_go_check_env__init_A_const_3 = A_arbace_go_check_env__init_A_const_pool.A[77]; A_arbace_go_check_env__init_A_const_4 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[78]); A_arbace_go_check_env__init_A_const_5 = A_arbace_go_check_env__init_A_const_pool.A[79]; A_arbace_go_check_env__init_A_const_6 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[80]); A_arbace_go_check_env__init_A_const_7 = A_arbace_go_check_env__init_A_const_pool.A[81]; A_arbace_go_check_env__init_A_const_8 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[82]); A_arbace_go_check_env__init_A_const_9 = A_arbace_go_check_env__init_A_const_pool.A[83]; A_arbace_go_check_env__init_A_const_10 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[84]); A_arbace_go_check_env__init_A_const_11 = A_arbace_go_check_env__init_A_const_pool.A[85]; A_arbace_go_check_env__init_A_const_12 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[86]) }

func A_arbace_go_check_env__init_A_clinit_p1() { A_arbace_go_check_env__init_A_const_13 = A_arbace_go_check_env__init_A_const_pool.A[87]; A_arbace_go_check_env__init_A_const_14 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[88]); A_arbace_go_check_env__init_A_const_15 = A_arbace_go_check_env__init_A_const_pool.A[89]; A_arbace_go_check_env__init_A_const_16 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[90]); A_arbace_go_check_env__init_A_const_17 = A_arbace_go_check_env__init_A_const_pool.A[91]; A_arbace_go_check_env__init_A_const_18 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[92]); A_arbace_go_check_env__init_A_const_19 = A_arbace_go_check_env__init_A_const_pool.A[93]; A_arbace_go_check_env__init_A_const_20 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[94]); A_arbace_go_check_env__init_A_const_21 = A_arbace_go_check_env__init_A_const_pool.A[95]; A_arbace_go_check_env__init_A_const_22 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[96]); A_arbace_go_check_env__init_A_const_23 = A_arbace_go_check_env__init_A_const_pool.A[97]; A_arbace_go_check_env__init_A_const_24 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[98]); A_arbace_go_check_env__init_A_const_25 = A_arbace_go_check_env__init_A_const_pool.A[99] }

func A_arbace_go_check_env__init_A_clinit_p2() { A_arbace_go_check_env__init_A_const_26 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[100]); A_arbace_go_check_env__init_A_const_27 = A_arbace_go_check_env__init_A_const_pool.A[101]; A_arbace_go_check_env__init_A_const_28 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[102]); A_arbace_go_check_env__init_A_const_29 = A_arbace_go_check_env__init_A_const_pool.A[103]; A_arbace_go_check_env__init_A_const_30 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[104]); A_arbace_go_check_env__init_A_const_31 = A_arbace_go_check_env__init_A_const_pool.A[105]; A_arbace_go_check_env__init_A_const_32 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[106]); A_arbace_go_check_env__init_A_const_33 = A_arbace_go_check_env__init_A_const_pool.A[107]; A_arbace_go_check_env__init_A_const_34 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[108]); A_arbace_go_check_env__init_A_const_35 = A_arbace_go_check_env__init_A_const_pool.A[109]; A_arbace_go_check_env__init_A_const_36 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[110]); A_arbace_go_check_env__init_A_const_37 = A_arbace_go_check_env__init_A_const_pool.A[111]; A_arbace_go_check_env__init_A_const_38 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[112]) }

func A_arbace_go_check_env__init_A_clinit_p3() { A_arbace_go_check_env__init_A_const_39 = A_arbace_go_check_env__init_A_const_pool.A[113]; A_arbace_go_check_env__init_A_const_40 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[114]); A_arbace_go_check_env__init_A_const_41 = A_arbace_go_check_env__init_A_const_pool.A[115]; A_arbace_go_check_env__init_A_const_42 = A_arbace_go_check_env__init_A_const_pool.A[116]; A_arbace_go_check_env__init_A_const_43 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[117]); A_arbace_go_check_env__init_A_const_44 = A_arbace_go_check_env__init_A_const_pool.A[118]; A_arbace_go_check_env__init_A_const_45 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[119]); A_arbace_go_check_env__init_A_const_46 = A_arbace_go_check_env__init_A_const_pool.A[120]; A_arbace_go_check_env__init_A_const_47 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[121]); A_arbace_go_check_env__init_A_const_48 = A_arbace_go_check_env__init_A_const_pool.A[122]; A_arbace_go_check_env__init_A_const_49 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[123]); A_arbace_go_check_env__init_A_const_50 = A_arbace_go_check_env__init_A_const_pool.A[124]; A_arbace_go_check_env__init_A_const_51 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[125]); A_arbace_go_check_env__init_A_const_52 = A_arbace_go_check_env__init_A_const_pool.A[126] }

func A_arbace_go_check_env__init_A_clinit_p4() { A_arbace_go_check_env__init_A_const_53 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[127]); A_arbace_go_check_env__init_A_const_54 = A_arbace_go_check_env__init_A_const_pool.A[128]; A_arbace_go_check_env__init_A_const_55 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[129]); A_arbace_go_check_env__init_A_const_56 = A_arbace_go_check_env__init_A_const_pool.A[130]; A_arbace_go_check_env__init_A_const_57 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[131]); A_arbace_go_check_env__init_A_const_58 = A_arbace_go_check_env__init_A_const_pool.A[132]; A_arbace_go_check_env__init_A_const_59 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[133]); A_arbace_go_check_env__init_A_const_60 = A_arbace_go_check_env__init_A_const_pool.A[134]; A_arbace_go_check_env__init_A_const_61 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[135]); A_arbace_go_check_env__init_A_const_62 = A_arbace_go_check_env__init_A_const_pool.A[136]; A_arbace_go_check_env__init_A_const_63 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[137]); A_arbace_go_check_env__init_A_const_64 = A_arbace_go_check_env__init_A_const_pool.A[138]; A_arbace_go_check_env__init_A_const_65 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[139]) }

func A_arbace_go_check_env__init_A_clinit_p5() { A_arbace_go_check_env__init_A_const_66 = A_arbace_go_check_env__init_A_const_pool.A[140]; A_arbace_go_check_env__init_A_const_67 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[141]); A_arbace_go_check_env__init_A_const_68 = A_arbace_go_check_env__init_A_const_pool.A[142]; A_arbace_go_check_env__init_A_const_69 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[143]); A_arbace_go_check_env__init_A_const_70 = A_arbace_go_check_env__init_A_const_pool.A[144]; A_arbace_go_check_env__init_A_const_71 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[145]); A_arbace_go_check_env__init_A_const_72 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[146]); A_arbace_go_check_env__init_A_const_73 = A_arbace_go_check_env__init_A_const_pool.A[147]; A_arbace_go_check_env__init_A_const_74 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[148]); A_arbace_go_check_env__init_A_const_75 = A_arbace_go_check_env__init_A_const_pool.A[149]; A_arbace_go_check_env__init_A_const_76 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[150]); A_arbace_go_check_env__init_A_const_77 = A_arbace_go_check_env__init_A_const_pool.A[151]; A_arbace_go_check_env__init_A_const_78 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[152]) }

func A_arbace_go_check_env__init_A_clinit_p6() { A_arbace_go_check_env__init_A_const_79 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[153]); A_arbace_go_check_env__init_A_const_80 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[154]); A_arbace_go_check_env__init_A_const_81 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[155]); A_arbace_go_check_env__init_A_const_82 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[156]); A_arbace_go_check_env__init_A_const_83 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[157]); A_arbace_go_check_env__init_A_const_84 = A_arbace_go_check_env__init_A_const_pool.A[158]; A_arbace_go_check_env__init_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[159]); A_arbace_go_check_env__init_A_const_86 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[160]); A_arbace_go_check_env__init_A_const_87 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[161]); A_arbace_go_check_env__init_A_const_88 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[162]); A_arbace_go_check_env__init_A_const_89 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[163]); A_arbace_go_check_env__init_A_const_90 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[164]) }

func A_arbace_go_check_env__init_A_clinit_p7() { A_arbace_go_check_env__init_A_const_91 = A_arbace_go_check_env__init_A_const_pool.A[165]; A_arbace_go_check_env__init_A_const_92 = A_arbace_go_check_env__init_A_const_pool.A[166]; A_arbace_go_check_env__init_A_const_93 = A_arbace_go_check_env__init_A_const_pool.A[167]; A_arbace_go_check_env__init_A_const_94 = A_arbace_go_check_env__init_A_const_pool.A[168]; A_arbace_go_check_env__init_A_const_95 = A_arbace_go_check_env__init_A_const_pool.A[169]; A_arbace_go_check_env__init_A_const_96 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[170]); A_arbace_go_check_env__init_A_const_97 = A_arbace_go_check_env__init_A_const_pool.A[171]; A_arbace_go_check_env__init_A_const_98 = A_arbace_go_check_env__init_A_const_pool.A[172]; A_arbace_go_check_env__init_A_const_99 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[173]); A_arbace_go_check_env__init_A_const_100 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[174]); A_arbace_go_check_env__init_A_const_101 = A_arbace_go_check_env__init_A_const_pool.A[175]; A_arbace_go_check_env__init_A_const_102 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[176]); A_arbace_go_check_env__init_A_const_103 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[177]); A_arbace_go_check_env__init_A_const_104 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[178]) }

func A_arbace_go_check_env__init_A_clinit_p8() { A_arbace_go_check_env__init_A_const_105 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[179]); A_arbace_go_check_env__init_A_const_106 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[180]); A_arbace_go_check_env__init_A_const_107 = A_arbace_go_check_env__init_A_const_pool.A[181] }

func A_arbace_go_check_env__init_A_New() *A_arbace_go_check_env__init_A { A_arbace_go_check_env__init_A_Init(); t := &A_arbace_go_check_env__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env__init_A) Ctor() {}

func (t *A_arbace_go_check_env__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env__init_A_class }

func (t *A_arbace_go_check_env__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env__init_A); return ok }

func A_arbace_go_check_env__init_A_Cast(x any) *A_arbace_go_check_env__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env__init_A_class)) }; return v }
