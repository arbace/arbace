//line aot_arbace_go_check_env__init.ae:1
package aot_arbace_go_check_env

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_env__init_A_Unit0__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_check_env__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env__init_A_const_1) }
//line :1:1
func A_arbace_go_check_env__init_A_Unit1__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_check_env__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_2)) }
//line :1:1
func A_arbace_go_check_env__init_A_Unit2__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, nil); A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_go_check_env__init_A_Unit3__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_check_env__init_A_const_1)).Equals_O__Z(A_arbace_go_check_env__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_go_check_env_eval1719000008_fn__1719000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, nil); A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_go_check_env__init_A_Load__O() any { A_arbace_go_check_env__init_A_Init(); jrt.StartCheck(); A_arbace_go_check_env__init_A_Unit0__O(); A_arbace_go_check_env__init_A_Unit1__O(); A_arbace_go_check_env__init_A_Unit2__O(); A_arbace_go_check_env__init_A_Unit3__O(); A_arbace_go_check_env__init_A_Unit4__O(); A_arbace_go_check_env__init_A_Unit5__O(); A_arbace_go_check_env__init_A_Unit6__O(); A_arbace_go_check_env__init_A_Unit7__O(); A_arbace_go_check_env__init_A_Unit8__O(); A_arbace_go_check_env__init_A_Unit9__O(); A_arbace_go_check_env__init_A_Unit10__O(); A_arbace_go_check_env__init_A_Unit11__O(); A_arbace_go_check_env__init_A_Unit12__O(); A_arbace_go_check_env__init_A_Unit13__O(); A_arbace_go_check_env__init_A_Unit14__O(); A_arbace_go_check_env__init_A_Unit15__O(); A_arbace_go_check_env__init_A_Unit16__O(); A_arbace_go_check_env__init_A_Unit17__O(); A_arbace_go_check_env__init_A_Unit18__O(); A_arbace_go_check_env__init_A_Unit19__O(); A_arbace_go_check_env__init_A_Unit20__O(); A_arbace_go_check_env__init_A_Unit21__O(); A_arbace_go_check_env__init_A_Unit22__O(); A_arbace_go_check_env__init_A_Unit23__O(); A_arbace_go_check_env__init_A_Unit24__O(); A_arbace_go_check_env__init_A_Unit25__O(); A_arbace_go_check_env__init_A_Unit26__O(); A_arbace_go_check_env__init_A_Unit27__O(); A_arbace_go_check_env__init_A_Unit28__O(); A_arbace_go_check_env__init_A_Unit29__O(); A_arbace_go_check_env__init_A_Unit30__O(); A_arbace_go_check_env__init_A_Unit31__O(); A_arbace_go_check_env__init_A_Unit32__O(); A_arbace_go_check_env__init_A_Unit33__O(); A_arbace_go_check_env__init_A_Unit34__O(); A_arbace_go_check_env__init_A_Unit35__O(); A_arbace_go_check_env__init_A_Unit36__O(); A_arbace_go_check_env__init_A_Unit37__O(); A_arbace_go_check_env__init_A_Unit38__O(); A_arbace_go_check_env__init_A_Unit39__O(); A_arbace_go_check_env__init_A_Unit40__O(); A_arbace_go_check_env__init_A_Unit41__O(); A_arbace_go_check_env__init_A_Unit42__O(); A_arbace_go_check_env__init_A_Unit43__O(); A_arbace_go_check_env__init_A_Unit44__O(); A_arbace_go_check_env__init_A_Unit45__O(); A_arbace_go_check_env__init_A_Unit46__O(); A_arbace_go_check_env__init_A_Unit47__O(); A_arbace_go_check_env__init_A_Unit48__O(); A_arbace_go_check_env__init_A_Unit49__O(); A_arbace_go_check_env__init_A_Unit50__O(); A_arbace_go_check_env__init_A_Unit51__O(); A_arbace_go_check_env__init_A_Unit52__O(); A_arbace_go_check_env__init_A_Unit53__O(); A_arbace_go_check_env__init_A_Unit54__O(); A_arbace_go_check_env__init_A_Unit55__O(); A_arbace_go_check_env__init_A_Unit56__O(); A_arbace_go_check_env__init_A_Unit57__O(); A_arbace_go_check_env__init_A_Unit58__O(); A_arbace_go_check_env__init_A_Unit59__O(); return nil }









func A_arbace_go_check_env__init_A_Unit4__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_go_check_env_obj_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_env_obj_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, nil); A_arbace_go_check_env_obj_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_5)); return A_arbace_go_check_env__init_A_const_4 }
func A_arbace_go_check_env__init_A_Unit5__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_go_check_env_o_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_env_o_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, nil); A_arbace_go_check_env_o_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_7)); return A_arbace_go_check_env__init_A_const_6 }
func A_arbace_go_check_env__init_A_Unit6__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_go_check_env_oset_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_env_oset_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, nil); A_arbace_go_check_env_oset_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_9)); return A_arbace_go_check_env__init_A_const_8 }
func A_arbace_go_check_env__init_A_Unit7__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_go_check_env_obj_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_env_obj_QMARK__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, nil); A_arbace_go_check_env_obj_QMARK__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_11)); return A_arbace_go_check_env__init_A_const_10 }



func A_arbace_go_check_env__init_A_Unit8__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_go_check_env_scope_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_env_scope_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, nil); A_arbace_go_check_env_scope_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_13)); return A_arbace_go_check_env__init_A_const_12 }

func A_arbace_go_check_env__init_A_Unit9__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_go_check_env_scope_lookup_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_env_scope_lookup_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_go_check_env_scope_lookup_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_15)); return A_arbace_go_check_env__init_A_const_14 }








func A_arbace_go_check_env__init_A_Unit10__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_go_check_env_scope_get_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_check_env_scope_get_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); A_arbace_go_check_env_scope_get_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_17)); return A_arbace_go_check_env__init_A_const_16 }
func A_arbace_go_check_env__init_A_Unit11__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_go_check_env_scope_put_BANG__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_check_env_scope_put_BANG__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, nil); A_arbace_go_check_env_scope_put_BANG__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_19)); return A_arbace_go_check_env__init_A_const_18 }



func A_arbace_go_check_env__init_A_Unit12__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); A_arbace_go_check_env__init_A_const_20.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_21)); return A_arbace_go_check_env__init_A_const_20.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit13__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); A_arbace_go_check_env__init_A_const_22.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_23)); return A_arbace_go_check_env__init_A_const_22.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit14__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); A_arbace_go_check_env__init_A_const_24.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_24; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_25)); return A_arbace_go_check_env__init_A_const_24.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit15__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); A_arbace_go_check_env__init_A_const_26.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_27)); return A_arbace_go_check_env__init_A_const_26.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check_env__init_A_Unit16__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); A_arbace_go_check_env__init_A_const_28.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_29)); return A_arbace_go_check_env__init_A_const_28.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check_env__init_A_Unit17__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); A_arbace_go_check_env__init_A_const_30.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_31)); return A_arbace_go_check_env__init_A_const_30.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check_env__init_A_Unit18__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); A_arbace_go_check_env__init_A_const_32.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_32; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_33)); return A_arbace_go_check_env__init_A_const_32.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit19__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(68, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_go_check_env_error_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_check_env_error_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, nil); A_arbace_go_check_env_error_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_35)); return A_arbace_go_check_env__init_A_const_34 }
















func A_arbace_go_check_env__init_A_Unit20__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(85, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_go_check_env_line_of_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_check_env_line_of_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, nil); A_arbace_go_check_env_line_of_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_37)); return A_arbace_go_check_env__init_A_const_36 }





func A_arbace_go_check_env__init_A_Unit21__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(91, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_go_check_env_col_of_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_check_env_col_of_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, nil); A_arbace_go_check_env_col_of_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_39)); return A_arbace_go_check_env__init_A_const_38 }









func A_arbace_go_check_env__init_A_Unit22__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); A_arbace_go_check_env__init_A_const_40.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_40; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_41)); return A_arbace_go_check_env__init_A_const_40.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check_env__init_A_Unit23__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(103, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_42; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_43)); return A_arbace_go_check_env__init_A_const_42 }

func A_arbace_go_check_env__init_A_Unit24__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(105, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_go_check_env_end_line_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_check_env_end_line_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, nil); A_arbace_go_check_env_end_line_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_45)); return A_arbace_go_check_env__init_A_const_44 }










func A_arbace_go_check_env__init_A_Unit25__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(116, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_go_check_env_child_line_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_check_env_child_line_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, nil); A_arbace_go_check_env_child_line_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_46)); return A_arbace_go_check_env__init_A_const_42 }



















func A_arbace_go_check_env__init_A_Unit26__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(136, 1); A_arbace_go_check_env__init_A_const_47.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_47; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_48)); return A_arbace_go_check_env__init_A_const_47.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_env__init_A_Unit27__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_49; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__32 any = A_arbace_go_check_env_with_child_line_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_env_with_child_line_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, true, nil); A_arbace_go_check_env_with_child_line_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__32, tmp3, nil, 4); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_50)); return A_arbace_go_check_env__init_A_const_49 }
//line :141:1
func A_arbace_go_check_env__init_A_Unit28__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); A_arbace_go_check_env__init_A_const_49.SetMacro__V(); return nil }
//line :141:1
func A_arbace_go_check_env__init_A_Unit29__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); return A_arbace_go_check_env__init_A_const_49 }







func A_arbace_go_check_env__init_A_Unit30__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(149, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_go_check_env_current_line_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_check_env_current_line_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, nil); A_arbace_go_check_env_current_line_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_52)); return A_arbace_go_check_env__init_A_const_51 }




func A_arbace_go_check_env__init_A_Unit31__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(154, 1); A_arbace_go_check_env__init_A_const_53.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_53; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_54)); return A_arbace_go_check_env__init_A_const_53.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check_env__init_A_Unit32__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(160, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_go_check_env_size_type_BANG__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_check_env_size_type_BANG__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); A_arbace_go_check_env_size_type_BANG__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_56)); return A_arbace_go_check_env__init_A_const_55 }






func A_arbace_go_check_env__init_A_Unit33__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(167, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_57; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__38 any = A_arbace_go_check_env_err_BANG__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_check_env_err_BANG__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, true, nil); A_arbace_go_check_env_err_BANG__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__38, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_58)); return A_arbace_go_check_env__init_A_const_57 }










func A_arbace_go_check_env__init_A_Unit34__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_go_check_env_generic_BANG__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_check_env_generic_BANG__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, nil); A_arbace_go_check_env_generic_BANG__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_60)); return A_arbace_go_check_env__init_A_const_59 }





func A_arbace_go_check_env__init_A_Unit35__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(184, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_go_check_env_unsupported_BANG__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_check_env_unsupported_BANG__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); A_arbace_go_check_env_unsupported_BANG__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_62)); return A_arbace_go_check_env__init_A_const_61 }









func A_arbace_go_check_env__init_A_Unit36__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(194, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_go_check_env_unsupported_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_check_env_unsupported_QMARK__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_go_check_env_unsupported_QMARK__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_64)); return A_arbace_go_check_env__init_A_const_63 }



func A_arbace_go_check_env__init_A_Unit37__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); A_arbace_go_check_env__init_A_const_65.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_65; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_66)); return A_arbace_go_check_env__init_A_const_65.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_env__init_A_Unit38__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(203, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_go_check_env_verified_BANG__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_check_env_verified_BANG__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, nil); A_arbace_go_check_env_verified_BANG__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_68)); return A_arbace_go_check_env__init_A_const_67 }












func A_arbace_go_check_env__init_A_Unit39__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(216, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_go_check_env_annotation_error_BANG__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_check_env_annotation_error_BANG__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); A_arbace_go_check_env_annotation_error_BANG__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_70)); return A_arbace_go_check_env__init_A_const_69 }







func A_arbace_go_check_env__init_A_Unit40__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(224, 1); A_arbace_go_check_env__init_A_const_71.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_71; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_72)); return A_arbace_go_check_env__init_A_const_71.SetDynamic_Z__Var(true).Ref() }






func A_arbace_go_check_env__init_A_Unit41__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(231, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_go_check_env_at_of_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_check_env_at_of_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, nil); A_arbace_go_check_env_at_of_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_74)); return A_arbace_go_check_env__init_A_const_73 }




func A_arbace_go_check_env__init_A_Unit42__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(236, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_go_check_env_answer_BANG__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_check_env_answer_BANG__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, nil); A_arbace_go_check_env_answer_BANG__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_76)); return A_arbace_go_check_env__init_A_const_75 }













func A_arbace_go_check_env__init_A_Unit43__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(250, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_77; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_go_check_env_unanswer_BANG__A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_check_env_unanswer_BANG__A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, nil); A_arbace_go_check_env_unanswer_BANG__A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_78)); return A_arbace_go_check_env__init_A_const_77 }









func A_arbace_go_check_env__init_A_Unit44__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(260, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_79; var tmp2 any; var root_55 any = A_arbace_go_check_env__init_A_const_12.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, A_arbace_go_check_env_scope_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any; var arg_59 any = A_arbace_go_check_env__init_A_const_80; if linked_56 == nil { tmp2 = ifn_57.Invoke_O_O__O(arg_58, arg_59) } else { tmp2 = linked_56.(*A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_55, arg_58, arg_59) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_check_env__init_A_const_79; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_81)); return A_arbace_go_check_env__init_A_const_79 }

func A_arbace_go_check_env__init_A_Unit45__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(262, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__61 any = A_arbace_go_check_env_def_type_BANG__A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_go_check_env_def_type_BANG__A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); A_arbace_go_check_env_def_type_BANG__A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__61, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_83)); return A_arbace_go_check_env__init_A_const_82 }




func A_arbace_go_check_env__init_A_Unit46__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(267, 1); { var seq_1719000065__1 any; var root_62 any = A_arbace_go_check_env__init_A_const_84.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = A_arbace_go_check_env__init_A_const_85; if linked_63 == nil { seq_1719000065__1 = ifn_64.Invoke_O__O(arg_65) } else { seq_1719000065__1 = linked_63.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_62, arg_65) }; var chunk_1719000066__2 any; var count_1719000067__3 int64 = 0; var i_1719000068__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000068__4, count_1719000067__3) { var vec__1719000070__5 any = lang.Indexed_Cast(chunk_1719000066__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000068__4)); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000070__5, lang.RT_IntCast_J__I_NoInit(0), nil); var kw__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000070__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_82 any = A_arbace_go_check_env__init_A_const_82.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, A_arbace_go_check_env_def_type_BANG__A_fn_class); var ifn_84 lang.IFn




	if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = n__6; var arg_86 any = kw__7; if linked_83 == nil { ifn_84.Invoke_O_O__O(arg_85, arg_86) } else { linked_83.(*A_arbace_go_check_env_def_type_BANG__A).Invoke_O_O_O__O(root_82, arg_85, arg_86) }
//line :267:1
	seq_1719000065__1, chunk_1719000066__2, count_1719000067__3, i_1719000068__4 = seq_1719000065__1, chunk_1719000066__2, count_1719000067__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000068__4); continue L1



} else {
//line :267:1
	var temp__1927000414__auto____5 any; var root_66 any = A_arbace_go_check_env__init_A_const_84.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = seq_1719000065__1; if linked_67 == nil { temp__1927000414__auto____5 = ifn_68.Invoke_O__O(arg_69) } else { temp__1927000414__auto____5 = linked_67.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_66, arg_69) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1719000065__6 any = temp__1927000414__auto____5; var tmp1 any; var root_70 any = A_arbace_go_check_env__init_A_const_86.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = seq_1719000065__6; if linked_71 == nil { tmp1 = ifn_72.Invoke_O__O(arg_73) } else { tmp1 = linked_71.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_70, arg_73) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____7 any; var root_74 any = A_arbace_go_check_env__init_A_const_87.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = seq_1719000065__6; if linked_75 == nil { c__1927000678__auto____7 = ifn_76.Invoke_O__O(arg_77) } else { c__1927000678__auto____7 = linked_75.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_74, arg_77) }; var tmp2 any; var root_87 any = A_arbace_go_check_env__init_A_const_89.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = seq_1719000065__6; if linked_88 == nil { tmp2 = ifn_89.Invoke_O__O(arg_90) } else { tmp2 = linked_88.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_87, arg_90) }; seq_1719000065__1, chunk_1719000066__2, count_1719000067__3, i_1719000068__4 = tmp2, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1719000073__7 any; var root_78 any = A_arbace_go_check_env__init_A_const_88.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = seq_1719000065__6; if linked_79 == nil { vec__1719000073__7 = ifn_80.Invoke_O__O(arg_81) } else { vec__1719000073__7 = linked_79.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_78, arg_81) }; var n__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000073__7, lang.RT_IntCast_J__I_NoInit(0), nil); var kw__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000073__7, lang.RT_IntCast_J__I_NoInit(1), nil); var root_91 any = A_arbace_go_check_env__init_A_const_82.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, A_arbace_go_check_env_def_type_BANG__A_fn_class); var ifn_93 lang.IFn




		if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = n__8; var arg_95 any = kw__9; if linked_92 == nil { ifn_93.Invoke_O_O__O(arg_94, arg_95) } else { linked_92.(*A_arbace_go_check_env_def_type_BANG__A).Invoke_O_O_O__O(root_91, arg_94, arg_95) }
//line :267:1
		var tmp3 any; var root_96 any = A_arbace_go_check_env__init_A_const_90.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = seq_1719000065__6; if linked_97 == nil { tmp3 = ifn_98.Invoke_O__O(arg_99) } else { tmp3 = linked_97.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_96, arg_99) }; seq_1719000065__1, chunk_1719000066__2, count_1719000067__3, i_1719000068__4 = tmp3, nil, 0, 0; continue L1 } } else { return nil
		}
}
}
}
	panic("j2g: unreachable")
}
func A_arbace_go_check_env__init_A_Unit47__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(274, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__101 any = A_arbace_go_check_env_fn__1719000077_A_New(); var tmp3 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_go_check_env_fn__1719000077_A_fn_class; if
							fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); A_arbace_go_check_env_fn__1719000077_A_fn_class = fncls__100d; tmp3 = fncls__100d } else { tmp3 = fncls__100 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__101, tmp3, nil); /*line :274:1*/tmp1.BindRoot_O__V(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_92)); return A_arbace_go_check_env__init_A_const_91 }





func A_arbace_go_check_env__init_A_Unit48__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(280, 1); var root_102 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = A_arbace_go_check_env__init_A_const_79.GetRawRoot__O(); var arg_106 any = Lit_41; var arg_107 any; var root_108 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, A_arbace_go_check_env_obj_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_93; var tmp2 any = A_arbace_go_check_env__init_A_const_94; var tmp3 any = A_arbace_go_check_env__init_A_const_95; var tmp4 any = A_arbace_go_check_env__init_A_const_94; var arg_111 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_41, tmp4, A_arbace_go_check_env__init_A_const_91.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_80, jrt.Boolean_TRUE.Ref())); if linked_109 == nil { arg_107 = ifn_110.Invoke_O__O(arg_111) } else { arg_107 = linked_109.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_108, arg_111) }; if linked_103 == nil { return ifn_104.Invoke_O_O_O__O(arg_105, arg_106, arg_107) } else { return linked_103.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_102, arg_105, arg_106, arg_107) } }
func A_arbace_go_check_env__init_A_Unit49__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(281, 1); var root_112 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = A_arbace_go_check_env__init_A_const_79.GetRawRoot__O(); var arg_116 any = Lit_42; var arg_117 any; var root_118 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, A_arbace_go_check_env_obj_A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_93; var tmp2 any = A_arbace_go_check_env__init_A_const_94; var tmp3 any = A_arbace_go_check_env__init_A_const_95; var tmp4 any = A_arbace_go_check_env__init_A_const_94; var arg_121 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_42, tmp4, lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_env__init_A_const_97, lang.PersistentVector_EMPTY.Ref(), nil), A_arbace_go_check_env__init_A_const_96, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_env__init_A_const_80, jrt.Boolean_TRUE.Ref())); if linked_119 == nil { arg_117 = ifn_120.Invoke_O__O(arg_121) } else { arg_117 = linked_119.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_118, arg_121) }; if linked_113 == nil { return ifn_114.Invoke_O_O_O__O(arg_115, arg_116, arg_117) } else { return linked_113.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_112, arg_115, arg_116, arg_117) } }

func A_arbace_go_check_env__init_A_Unit50__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(283, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_98; var tmp2 *lang.Compiler_AOTFn; var fnbody__123 any = A_arbace_go_check_env_fn__1719000083_A_New(); var tmp3 *jrt.Class; var fncls__122 *jrt.Class = A_arbace_go_check_env_fn__1719000083_A_fn_class; if
							fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, nil); A_arbace_go_check_env_fn__1719000083_A_fn_class = fncls__122d; tmp3 = fncls__122d } else { tmp3 = fncls__122 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__123, tmp3, nil); /*line :283:1*/tmp1.BindRoot_O__V(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_99)); return A_arbace_go_check_env__init_A_const_98 }




func A_arbace_go_check_env__init_A_Unit51__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); var root_124 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = A_arbace_go_check_env__init_A_const_79.GetRawRoot__O(); var arg_128 any = Lit_44; var arg_129 any; var root_130 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_go_check_env_obj_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_93; var tmp2 any = A_arbace_go_check_env__init_A_const_94; var tmp3 any = A_arbace_go_check_env__init_A_const_95; var tmp4 any = A_arbace_go_check_env__init_A_const_94; var arg_133 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_44, tmp4, A_arbace_go_check_env__init_A_const_98.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_80, jrt.Boolean_TRUE.Ref())); if linked_131 == nil { arg_129 = ifn_132.Invoke_O__O(arg_133) } else { arg_129 = linked_131.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_130, arg_133) }; if linked_125 == nil { return ifn_126.Invoke_O_O_O__O(arg_127, arg_128, arg_129) } else { return linked_125.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_124, arg_127, arg_128, arg_129) } }

func A_arbace_go_check_env__init_A_Unit52__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(290, 1); var root_134 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = A_arbace_go_check_env__init_A_const_79.GetRawRoot__O(); var arg_138 any = Lit_45; var arg_139 any; var root_140 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, A_arbace_go_check_env_obj_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = A_arbace_go_check_env__init_A_const_100; if linked_141 == nil { arg_139 = ifn_142.Invoke_O__O(arg_143) } else { arg_139 = linked_141.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_140, arg_143) }; if linked_135 == nil { return ifn_136.Invoke_O_O_O__O(arg_137, arg_138, arg_139) } else { return linked_135.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_134, arg_137, arg_138, arg_139) } }
func A_arbace_go_check_env__init_A_Unit53__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(291, 1); var root_144 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = A_arbace_go_check_env__init_A_const_79.GetRawRoot__O(); var arg_148 any = Lit_46; var arg_149 any; var root_150 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, A_arbace_go_check_env_obj_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = A_arbace_go_check_env__init_A_const_101; if linked_151 == nil { arg_149 = ifn_152.Invoke_O__O(arg_153) } else { arg_149 = linked_151.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_150, arg_153) }; if linked_145 == nil { return ifn_146.Invoke_O_O_O__O(arg_147, arg_148, arg_149) } else { return linked_145.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_144, arg_147, arg_148, arg_149) } }
func A_arbace_go_check_env__init_A_Unit54__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(292, 1); var root_154 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = A_arbace_go_check_env__init_A_const_79.GetRawRoot__O(); var arg_158 any = Lit_47; var arg_159 any; var root_160 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, A_arbace_go_check_env_obj_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = A_arbace_go_check_env__init_A_const_102; if linked_161 == nil { arg_159 = ifn_162.Invoke_O__O(arg_163) } else { arg_159 = linked_161.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_160, arg_163) }; if linked_155 == nil { return ifn_156.Invoke_O_O_O__O(arg_157, arg_158, arg_159) } else { return linked_155.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_154, arg_157, arg_158, arg_159) } }
func A_arbace_go_check_env__init_A_Unit55__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(293, 1); var root_164 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = A_arbace_go_check_env__init_A_const_79.GetRawRoot__O(); var arg_168 any = Lit_48; var arg_169 any; var root_170 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, A_arbace_go_check_env_obj_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = A_arbace_go_check_env__init_A_const_103; if linked_171 == nil { arg_169 = ifn_172.Invoke_O__O(arg_173) } else { arg_169 = linked_171.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_170, arg_173) }; if linked_165 == nil { return ifn_166.Invoke_O_O_O__O(arg_167, arg_168, arg_169) } else { return linked_165.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_164, arg_167, arg_168, arg_169) } }

func A_arbace_go_check_env__init_A_Unit56__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(295, 1); A_arbace_go_check_env__init_A_const_104.BindRoot_O__V(A_arbace_go_check_env__init_A_const_105); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_104; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_106)); return A_arbace_go_check_env__init_A_const_104 }



func A_arbace_go_check_env__init_A_Unit57__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(299, 1); { var seq_1719000095__1 any; var root_174 any = A_arbace_go_check_env__init_A_const_84.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = A_arbace_go_check_env__init_A_const_104.GetRawRoot__O(); if linked_175 == nil { seq_1719000095__1 = ifn_176.Invoke_O__O(arg_177) } else { seq_1719000095__1 = linked_175.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_174, arg_177) }; var chunk_1719000096__2 any; var count_1719000097__3 int64 = 0; var i_1719000098__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000098__4, count_1719000097__3) { var n__5 any = lang.Indexed_Cast(chunk_1719000096__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000098__4)); var root_194 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_196 lang.IFn
	if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = A_arbace_go_check_env__init_A_const_79.GetRawRoot__O(); var arg_198 any = n__5; var arg_199 any; var root_200 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, A_arbace_go_check_env_obj_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env__init_A_const_93, A_arbace_go_check_env__init_A_const_107, A_arbace_go_check_env__init_A_const_95, n__5, A_arbace_go_check_env__init_A_const_80, jrt.Boolean_TRUE.Ref())); if linked_201 == nil { arg_199 = ifn_202.Invoke_O__O(arg_203) } else { arg_199 = linked_201.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_200, arg_203) }; if linked_195 == nil { ifn_196.Invoke_O_O_O__O(arg_197, arg_198, arg_199) } else { linked_195.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_194, arg_197, arg_198, arg_199) }
//line :299:1
	seq_1719000095__1, chunk_1719000096__2, count_1719000097__3, i_1719000098__4 = seq_1719000095__1, chunk_1719000096__2, count_1719000097__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000098__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_178 any = A_arbace_go_check_env__init_A_const_84.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = seq_1719000095__1; if linked_179 == nil { temp__1927000414__auto____5 = ifn_180.Invoke_O__O(arg_181) } else { temp__1927000414__auto____5 = linked_179.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_178, arg_181) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1719000095__6 any = temp__1927000414__auto____5; var tmp1 any; var root_182 any = A_arbace_go_check_env__init_A_const_86.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = seq_1719000095__6; if linked_183 == nil { tmp1 = ifn_184.Invoke_O__O(arg_185) } else { tmp1 = linked_183.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_182, arg_185) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____7 any; var root_186 any = A_arbace_go_check_env__init_A_const_87.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = seq_1719000095__6; if linked_187 == nil { c__1927000678__auto____7 = ifn_188.Invoke_O__O(arg_189) } else { c__1927000678__auto____7 = linked_187.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_186, arg_189) }; var tmp2 any; var root_204 any = A_arbace_go_check_env__init_A_const_89.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = seq_1719000095__6; if linked_205 == nil { tmp2 = ifn_206.Invoke_O__O(arg_207) } else { tmp2 = linked_205.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_204, arg_207) }; seq_1719000095__1, chunk_1719000096__2, count_1719000097__3, i_1719000098__4 = tmp2, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__7 any; var root_190 any = A_arbace_go_check_env__init_A_const_88.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = seq_1719000095__6; if linked_191 == nil { n__7 = ifn_192.Invoke_O__O(arg_193) } else { n__7 = linked_191.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_190, arg_193) }
		var root_208 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = A_arbace_go_check_env__init_A_const_79.GetRawRoot__O(); var arg_212 any = n__7; var arg_213 any; var root_214 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, A_arbace_go_check_env_obj_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env__init_A_const_93, A_arbace_go_check_env__init_A_const_107, A_arbace_go_check_env__init_A_const_95, n__7, A_arbace_go_check_env__init_A_const_80, jrt.Boolean_TRUE.Ref())); if linked_215 == nil { arg_213 = ifn_216.Invoke_O__O(arg_217) } else { arg_213 = linked_215.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_214, arg_217) }; if linked_209 == nil { ifn_210.Invoke_O_O_O__O(arg_211, arg_212, arg_213) } else { linked_209.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_208, arg_211, arg_212, arg_213) }
//line :299:1
		var tmp3 any; var root_218 any = A_arbace_go_check_env__init_A_const_90.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = seq_1719000095__6; if linked_219 == nil { tmp3 = ifn_220.Invoke_O__O(arg_221) } else { tmp3 = linked_219.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_218, arg_221) }; seq_1719000095__1, chunk_1719000096__2, count_1719000097__3, i_1719000098__4 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } }
	panic("j2g: unreachable")
}


func A_arbace_go_check_env__init_A_Unit58__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(304, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_108; var tmp2 *lang.Compiler_AOTFn; var fnbody__223 any = A_arbace_go_check_env_fn__1719000101_A_New(); var tmp3 *jrt.Class; var fncls__222 *jrt.Class = A_arbace_go_check_env_fn__1719000101_A_fn_class; if
							fncls__222 == nil { var fncls__222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, nil); A_arbace_go_check_env_fn__1719000101_A_fn_class = fncls__222d; tmp3 = fncls__222d } else { tmp3 = fncls__222 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__223, tmp3, nil); /*line :304:1*/tmp1.BindRoot_O__V(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_109)); return A_arbace_go_check_env__init_A_const_108 }






func A_arbace_go_check_env__init_A_Unit59__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(311, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_110; var tmp2 any; var root_224 any = A_arbace_go_check_env__init_A_const_111.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var tmp3 any = A_arbace_go_check_env__init_A_const_112; var tmp4 any = A_arbace_go_check_env__init_A_const_95; var tmp5 any = A_arbace_go_check_env__init_A_const_113; var arg_227 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, Lit_10, tmp4, Lit_10, tmp5, A_arbace_go_check_env__init_A_const_108.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_114, jrt.Boolean_TRUE.Ref())); if linked_225 == nil { tmp2 = ifn_226.Invoke_O__O(arg_227) } else { tmp2 = linked_225.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_224, arg_227) }; tmp1.BindRoot_O__V(tmp2); var tmp6 *lang.Var = A_arbace_go_check_env__init_A_const_110; tmp6.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_115)); return A_arbace_go_check_env__init_A_const_110 }



type A_arbace_go_check_env__init_A struct{ jrt.Object }

var A_arbace_go_check_env__init_A_const_pool *jrt.RefArray

var A_arbace_go_check_env__init_A_const_0 *lang.Var

var A_arbace_go_check_env__init_A_const_1 any

var A_arbace_go_check_env__init_A_const_2 any

var A_arbace_go_check_env__init_A_const_3 any

var A_arbace_go_check_env__init_A_const_4 *lang.Var

var A_arbace_go_check_env__init_A_const_5 any

var A_arbace_go_check_env__init_A_const_6 *lang.Var

var A_arbace_go_check_env__init_A_const_7 any

var A_arbace_go_check_env__init_A_const_8 *lang.Var

var A_arbace_go_check_env__init_A_const_9 any

var A_arbace_go_check_env__init_A_const_10 *lang.Var

var A_arbace_go_check_env__init_A_const_11 any

var A_arbace_go_check_env__init_A_const_12 *lang.Var

var A_arbace_go_check_env__init_A_const_13 any

var A_arbace_go_check_env__init_A_const_14 *lang.Var

var A_arbace_go_check_env__init_A_const_15 any

var A_arbace_go_check_env__init_A_const_16 *lang.Var

var A_arbace_go_check_env__init_A_const_17 any

var A_arbace_go_check_env__init_A_const_18 *lang.Var

var A_arbace_go_check_env__init_A_const_19 any

var A_arbace_go_check_env__init_A_const_20 *lang.Var

var A_arbace_go_check_env__init_A_const_21 any

var A_arbace_go_check_env__init_A_const_22 *lang.Var

var A_arbace_go_check_env__init_A_const_23 any

var A_arbace_go_check_env__init_A_const_24 *lang.Var

var A_arbace_go_check_env__init_A_const_25 any

var A_arbace_go_check_env__init_A_const_26 *lang.Var

var A_arbace_go_check_env__init_A_const_27 any

var A_arbace_go_check_env__init_A_const_28 *lang.Var

var A_arbace_go_check_env__init_A_const_29 any

var A_arbace_go_check_env__init_A_const_30 *lang.Var

var A_arbace_go_check_env__init_A_const_31 any

var A_arbace_go_check_env__init_A_const_32 *lang.Var

var A_arbace_go_check_env__init_A_const_33 any

var A_arbace_go_check_env__init_A_const_34 *lang.Var

var A_arbace_go_check_env__init_A_const_35 any

var A_arbace_go_check_env__init_A_const_36 *lang.Var

var A_arbace_go_check_env__init_A_const_37 any

var A_arbace_go_check_env__init_A_const_38 *lang.Var

var A_arbace_go_check_env__init_A_const_39 any

var A_arbace_go_check_env__init_A_const_40 *lang.Var

var A_arbace_go_check_env__init_A_const_41 any

var A_arbace_go_check_env__init_A_const_42 *lang.Var

var A_arbace_go_check_env__init_A_const_43 any

var A_arbace_go_check_env__init_A_const_44 *lang.Var

var A_arbace_go_check_env__init_A_const_45 any

var A_arbace_go_check_env__init_A_const_46 any

var A_arbace_go_check_env__init_A_const_47 *lang.Var

var A_arbace_go_check_env__init_A_const_48 any

var A_arbace_go_check_env__init_A_const_49 *lang.Var

var A_arbace_go_check_env__init_A_const_50 any

var A_arbace_go_check_env__init_A_const_51 *lang.Var

var A_arbace_go_check_env__init_A_const_52 any

var A_arbace_go_check_env__init_A_const_53 *lang.Var

var A_arbace_go_check_env__init_A_const_54 any

var A_arbace_go_check_env__init_A_const_55 *lang.Var

var A_arbace_go_check_env__init_A_const_56 any

var A_arbace_go_check_env__init_A_const_57 *lang.Var

var A_arbace_go_check_env__init_A_const_58 any

var A_arbace_go_check_env__init_A_const_59 *lang.Var

var A_arbace_go_check_env__init_A_const_60 any

var A_arbace_go_check_env__init_A_const_61 *lang.Var

var A_arbace_go_check_env__init_A_const_62 any

var A_arbace_go_check_env__init_A_const_63 *lang.Var

var A_arbace_go_check_env__init_A_const_64 any

var A_arbace_go_check_env__init_A_const_65 *lang.Var

var A_arbace_go_check_env__init_A_const_66 any

var A_arbace_go_check_env__init_A_const_67 *lang.Var

var A_arbace_go_check_env__init_A_const_68 any

var A_arbace_go_check_env__init_A_const_69 *lang.Var

var A_arbace_go_check_env__init_A_const_70 any

var A_arbace_go_check_env__init_A_const_71 *lang.Var

var A_arbace_go_check_env__init_A_const_72 any

var A_arbace_go_check_env__init_A_const_73 *lang.Var

var A_arbace_go_check_env__init_A_const_74 any

var A_arbace_go_check_env__init_A_const_75 *lang.Var

var A_arbace_go_check_env__init_A_const_76 any

var A_arbace_go_check_env__init_A_const_77 *lang.Var

var A_arbace_go_check_env__init_A_const_78 any

var A_arbace_go_check_env__init_A_const_79 *lang.Var

var A_arbace_go_check_env__init_A_const_80 *lang.Keyword

var A_arbace_go_check_env__init_A_const_81 any

var A_arbace_go_check_env__init_A_const_82 *lang.Var

var A_arbace_go_check_env__init_A_const_83 any

var A_arbace_go_check_env__init_A_const_84 *lang.Var

var A_arbace_go_check_env__init_A_const_85 any

var A_arbace_go_check_env__init_A_const_86 *lang.Var

var A_arbace_go_check_env__init_A_const_87 *lang.Var

var A_arbace_go_check_env__init_A_const_88 *lang.Var

var A_arbace_go_check_env__init_A_const_89 *lang.Var

var A_arbace_go_check_env__init_A_const_90 *lang.Var

var A_arbace_go_check_env__init_A_const_91 *lang.Var

var A_arbace_go_check_env__init_A_const_92 any

var A_arbace_go_check_env__init_A_const_93 *lang.Keyword

var A_arbace_go_check_env__init_A_const_94 *lang.Keyword

var A_arbace_go_check_env__init_A_const_95 *lang.Keyword

var A_arbace_go_check_env__init_A_const_96 *lang.Keyword

var A_arbace_go_check_env__init_A_const_97 *lang.Keyword

var A_arbace_go_check_env__init_A_const_98 *lang.Var

var A_arbace_go_check_env__init_A_const_99 any

var A_arbace_go_check_env__init_A_const_100 any

var A_arbace_go_check_env__init_A_const_101 any

var A_arbace_go_check_env__init_A_const_102 any

var A_arbace_go_check_env__init_A_const_103 any

var A_arbace_go_check_env__init_A_const_104 *lang.Var

var A_arbace_go_check_env__init_A_const_105 any

var A_arbace_go_check_env__init_A_const_106 any

var A_arbace_go_check_env__init_A_const_107 *lang.Keyword

var A_arbace_go_check_env__init_A_const_108 *lang.Var

var A_arbace_go_check_env__init_A_const_109 any

var A_arbace_go_check_env__init_A_const_110 *lang.Var

var A_arbace_go_check_env__init_A_const_111 *lang.Var

var A_arbace_go_check_env__init_A_const_112 *lang.Keyword

var A_arbace_go_check_env__init_A_const_113 *lang.Keyword

var A_arbace_go_check_env__init_A_const_114 *lang.Keyword

var A_arbace_go_check_env__init_A_const_115 any

var A_arbace_go_check_env__init_A_init jrt.ClassInit

func A_arbace_go_check_env__init_A_Init() { if !A_arbace_go_check_env__init_A_init.Done() { A_arbace_go_check_env__init_A_init.Run(A_arbace_go_check_env__init_A_clinit) } }

func A_arbace_go_check_env__init_A_clinit() { A_arbace_go_check_env__init_A_clinit_p0(); A_arbace_go_check_env__init_A_clinit_p1(); A_arbace_go_check_env__init_A_clinit_p2(); A_arbace_go_check_env__init_A_clinit_p3(); A_arbace_go_check_env__init_A_clinit_p4(); A_arbace_go_check_env__init_A_clinit_p5(); A_arbace_go_check_env__init_A_clinit_p6(); A_arbace_go_check_env__init_A_clinit_p7(); A_arbace_go_check_env__init_A_clinit_p8() }

func A_arbace_go_check_env__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_env__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_11, 191); A_arbace_go_check_env__init_A_const_0 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[75]); A_arbace_go_check_env__init_A_const_1 = A_arbace_go_check_env__init_A_const_pool.A[76]; A_arbace_go_check_env__init_A_const_2 = A_arbace_go_check_env__init_A_const_pool.A[77]; A_arbace_go_check_env__init_A_const_3 = A_arbace_go_check_env__init_A_const_pool.A[78]; A_arbace_go_check_env__init_A_const_4 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[79]); A_arbace_go_check_env__init_A_const_5 = A_arbace_go_check_env__init_A_const_pool.A[80]; A_arbace_go_check_env__init_A_const_6 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[81]); A_arbace_go_check_env__init_A_const_7 = A_arbace_go_check_env__init_A_const_pool.A[82]; A_arbace_go_check_env__init_A_const_8 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[83]); A_arbace_go_check_env__init_A_const_9 = A_arbace_go_check_env__init_A_const_pool.A[84]; A_arbace_go_check_env__init_A_const_10 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[85]); A_arbace_go_check_env__init_A_const_11 = A_arbace_go_check_env__init_A_const_pool.A[86]; A_arbace_go_check_env__init_A_const_12 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[87]) }

func A_arbace_go_check_env__init_A_clinit_p1() { A_arbace_go_check_env__init_A_const_13 = A_arbace_go_check_env__init_A_const_pool.A[88]; A_arbace_go_check_env__init_A_const_14 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[89]); A_arbace_go_check_env__init_A_const_15 = A_arbace_go_check_env__init_A_const_pool.A[90]; A_arbace_go_check_env__init_A_const_16 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[91]); A_arbace_go_check_env__init_A_const_17 = A_arbace_go_check_env__init_A_const_pool.A[92]; A_arbace_go_check_env__init_A_const_18 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[93]); A_arbace_go_check_env__init_A_const_19 = A_arbace_go_check_env__init_A_const_pool.A[94]; A_arbace_go_check_env__init_A_const_20 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[95]); A_arbace_go_check_env__init_A_const_21 = A_arbace_go_check_env__init_A_const_pool.A[96]; A_arbace_go_check_env__init_A_const_22 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[97]); A_arbace_go_check_env__init_A_const_23 = A_arbace_go_check_env__init_A_const_pool.A[98]; A_arbace_go_check_env__init_A_const_24 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[99]); A_arbace_go_check_env__init_A_const_25 = A_arbace_go_check_env__init_A_const_pool.A[100] }

func A_arbace_go_check_env__init_A_clinit_p2() { A_arbace_go_check_env__init_A_const_26 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[101]); A_arbace_go_check_env__init_A_const_27 = A_arbace_go_check_env__init_A_const_pool.A[102]; A_arbace_go_check_env__init_A_const_28 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[103]); A_arbace_go_check_env__init_A_const_29 = A_arbace_go_check_env__init_A_const_pool.A[104]; A_arbace_go_check_env__init_A_const_30 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[105]); A_arbace_go_check_env__init_A_const_31 = A_arbace_go_check_env__init_A_const_pool.A[106]; A_arbace_go_check_env__init_A_const_32 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[107]); A_arbace_go_check_env__init_A_const_33 = A_arbace_go_check_env__init_A_const_pool.A[108]; A_arbace_go_check_env__init_A_const_34 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[109]); A_arbace_go_check_env__init_A_const_35 = A_arbace_go_check_env__init_A_const_pool.A[110]; A_arbace_go_check_env__init_A_const_36 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[111]); A_arbace_go_check_env__init_A_const_37 = A_arbace_go_check_env__init_A_const_pool.A[112]; A_arbace_go_check_env__init_A_const_38 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[113]) }

func A_arbace_go_check_env__init_A_clinit_p3() { A_arbace_go_check_env__init_A_const_39 = A_arbace_go_check_env__init_A_const_pool.A[114]; A_arbace_go_check_env__init_A_const_40 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[115]); A_arbace_go_check_env__init_A_const_41 = A_arbace_go_check_env__init_A_const_pool.A[116]; A_arbace_go_check_env__init_A_const_42 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[117]); A_arbace_go_check_env__init_A_const_43 = A_arbace_go_check_env__init_A_const_pool.A[118]; A_arbace_go_check_env__init_A_const_44 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[119]); A_arbace_go_check_env__init_A_const_45 = A_arbace_go_check_env__init_A_const_pool.A[120]; A_arbace_go_check_env__init_A_const_46 = A_arbace_go_check_env__init_A_const_pool.A[121]; A_arbace_go_check_env__init_A_const_47 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[122]); A_arbace_go_check_env__init_A_const_48 = A_arbace_go_check_env__init_A_const_pool.A[123]; A_arbace_go_check_env__init_A_const_49 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[124]); A_arbace_go_check_env__init_A_const_50 = A_arbace_go_check_env__init_A_const_pool.A[125]; A_arbace_go_check_env__init_A_const_51 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[126]); A_arbace_go_check_env__init_A_const_52 = A_arbace_go_check_env__init_A_const_pool.A[127] }

func A_arbace_go_check_env__init_A_clinit_p4() { A_arbace_go_check_env__init_A_const_53 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[128]); A_arbace_go_check_env__init_A_const_54 = A_arbace_go_check_env__init_A_const_pool.A[129]; A_arbace_go_check_env__init_A_const_55 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[130]); A_arbace_go_check_env__init_A_const_56 = A_arbace_go_check_env__init_A_const_pool.A[131]; A_arbace_go_check_env__init_A_const_57 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[132]); A_arbace_go_check_env__init_A_const_58 = A_arbace_go_check_env__init_A_const_pool.A[133]; A_arbace_go_check_env__init_A_const_59 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[134]); A_arbace_go_check_env__init_A_const_60 = A_arbace_go_check_env__init_A_const_pool.A[135]; A_arbace_go_check_env__init_A_const_61 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[136]); A_arbace_go_check_env__init_A_const_62 = A_arbace_go_check_env__init_A_const_pool.A[137]; A_arbace_go_check_env__init_A_const_63 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[138]); A_arbace_go_check_env__init_A_const_64 = A_arbace_go_check_env__init_A_const_pool.A[139]; A_arbace_go_check_env__init_A_const_65 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[140]) }

func A_arbace_go_check_env__init_A_clinit_p5() { A_arbace_go_check_env__init_A_const_66 = A_arbace_go_check_env__init_A_const_pool.A[141]; A_arbace_go_check_env__init_A_const_67 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[142]); A_arbace_go_check_env__init_A_const_68 = A_arbace_go_check_env__init_A_const_pool.A[143]; A_arbace_go_check_env__init_A_const_69 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[144]); A_arbace_go_check_env__init_A_const_70 = A_arbace_go_check_env__init_A_const_pool.A[145]; A_arbace_go_check_env__init_A_const_71 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[146]); A_arbace_go_check_env__init_A_const_72 = A_arbace_go_check_env__init_A_const_pool.A[147]; A_arbace_go_check_env__init_A_const_73 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[148]); A_arbace_go_check_env__init_A_const_74 = A_arbace_go_check_env__init_A_const_pool.A[149]; A_arbace_go_check_env__init_A_const_75 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[150]); A_arbace_go_check_env__init_A_const_76 = A_arbace_go_check_env__init_A_const_pool.A[151]; A_arbace_go_check_env__init_A_const_77 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[152]); A_arbace_go_check_env__init_A_const_78 = A_arbace_go_check_env__init_A_const_pool.A[153] }

func A_arbace_go_check_env__init_A_clinit_p6() { A_arbace_go_check_env__init_A_const_79 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[154]); A_arbace_go_check_env__init_A_const_80 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[155]); A_arbace_go_check_env__init_A_const_81 = A_arbace_go_check_env__init_A_const_pool.A[156]; A_arbace_go_check_env__init_A_const_82 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[157]); A_arbace_go_check_env__init_A_const_83 = A_arbace_go_check_env__init_A_const_pool.A[158]; A_arbace_go_check_env__init_A_const_84 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[159]); A_arbace_go_check_env__init_A_const_85 = A_arbace_go_check_env__init_A_const_pool.A[160]; A_arbace_go_check_env__init_A_const_86 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[161]); A_arbace_go_check_env__init_A_const_87 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[162]); A_arbace_go_check_env__init_A_const_88 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[163]); A_arbace_go_check_env__init_A_const_89 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[164]); A_arbace_go_check_env__init_A_const_90 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[165]) }

func A_arbace_go_check_env__init_A_clinit_p7() { A_arbace_go_check_env__init_A_const_91 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[166]); A_arbace_go_check_env__init_A_const_92 = A_arbace_go_check_env__init_A_const_pool.A[167]; A_arbace_go_check_env__init_A_const_93 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[168]); A_arbace_go_check_env__init_A_const_94 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[169]); A_arbace_go_check_env__init_A_const_95 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[170]); A_arbace_go_check_env__init_A_const_96 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[171]); A_arbace_go_check_env__init_A_const_97 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[172]); A_arbace_go_check_env__init_A_const_98 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[173]); A_arbace_go_check_env__init_A_const_99 = A_arbace_go_check_env__init_A_const_pool.A[174]; A_arbace_go_check_env__init_A_const_100 = A_arbace_go_check_env__init_A_const_pool.A[175]; A_arbace_go_check_env__init_A_const_101 = A_arbace_go_check_env__init_A_const_pool.A[176]; A_arbace_go_check_env__init_A_const_102 = A_arbace_go_check_env__init_A_const_pool.A[177]; A_arbace_go_check_env__init_A_const_103 = A_arbace_go_check_env__init_A_const_pool.A[178] }

func A_arbace_go_check_env__init_A_clinit_p8() { A_arbace_go_check_env__init_A_const_104 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[179]); A_arbace_go_check_env__init_A_const_105 = A_arbace_go_check_env__init_A_const_pool.A[180]; A_arbace_go_check_env__init_A_const_106 = A_arbace_go_check_env__init_A_const_pool.A[181]; A_arbace_go_check_env__init_A_const_107 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[182]); A_arbace_go_check_env__init_A_const_108 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[183]); A_arbace_go_check_env__init_A_const_109 = A_arbace_go_check_env__init_A_const_pool.A[184]; A_arbace_go_check_env__init_A_const_110 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[185]); A_arbace_go_check_env__init_A_const_111 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[186]); A_arbace_go_check_env__init_A_const_112 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[187]); A_arbace_go_check_env__init_A_const_113 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[188]); A_arbace_go_check_env__init_A_const_114 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[189]); A_arbace_go_check_env__init_A_const_115 = A_arbace_go_check_env__init_A_const_pool.A[190] }

func A_arbace_go_check_env__init_A_New() *A_arbace_go_check_env__init_A { A_arbace_go_check_env__init_A_Init(); t := &A_arbace_go_check_env__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env__init_A) Ctor() {}

func (t *A_arbace_go_check_env__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env__init_A_class }

func (t *A_arbace_go_check_env__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env__init_A); return ok }

func A_arbace_go_check_env__init_A_Cast(x any) *A_arbace_go_check_env__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env__init_A_class)) }; return v }
