//line aot_arbace_go_check_env__init.ae:1
package aot_arbace_go_check_env

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_env__init_A_Unit0__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_check_env__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env__init_A_const_1) }
//line :1:1
func A_arbace_go_check_env__init_A_Unit1__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_check_env__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_2)) }
//line :1:1
func A_arbace_go_check_env__init_A_Unit2__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_go_check_env__init_A_Unit3__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_check_env__init_A_const_1)).Equals_O__Z(A_arbace_go_check_env__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_go_check_env_eval1719000008_fn__1719000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_go_check_env__init_A_Load__O() any { A_arbace_go_check_env__init_A_Init(); jrt.StartCheck(); A_arbace_go_check_env__init_A_Unit0__O(); A_arbace_go_check_env__init_A_Unit1__O(); A_arbace_go_check_env__init_A_Unit2__O(); A_arbace_go_check_env__init_A_Unit3__O(); A_arbace_go_check_env__init_A_Unit4__O(); A_arbace_go_check_env__init_A_Unit5__O(); A_arbace_go_check_env__init_A_Unit6__O(); A_arbace_go_check_env__init_A_Unit7__O(); A_arbace_go_check_env__init_A_Unit8__O(); A_arbace_go_check_env__init_A_Unit9__O(); A_arbace_go_check_env__init_A_Unit10__O(); A_arbace_go_check_env__init_A_Unit11__O(); A_arbace_go_check_env__init_A_Unit12__O(); A_arbace_go_check_env__init_A_Unit13__O(); A_arbace_go_check_env__init_A_Unit14__O(); A_arbace_go_check_env__init_A_Unit15__O(); A_arbace_go_check_env__init_A_Unit16__O(); A_arbace_go_check_env__init_A_Unit17__O(); A_arbace_go_check_env__init_A_Unit18__O(); A_arbace_go_check_env__init_A_Unit19__O(); A_arbace_go_check_env__init_A_Unit20__O(); A_arbace_go_check_env__init_A_Unit21__O(); A_arbace_go_check_env__init_A_Unit22__O(); A_arbace_go_check_env__init_A_Unit23__O(); A_arbace_go_check_env__init_A_Unit24__O(); A_arbace_go_check_env__init_A_Unit25__O(); A_arbace_go_check_env__init_A_Unit26__O(); A_arbace_go_check_env__init_A_Unit27__O(); A_arbace_go_check_env__init_A_Unit28__O(); A_arbace_go_check_env__init_A_Unit29__O(); A_arbace_go_check_env__init_A_Unit30__O(); A_arbace_go_check_env__init_A_Unit31__O(); A_arbace_go_check_env__init_A_Unit32__O(); A_arbace_go_check_env__init_A_Unit33__O(); A_arbace_go_check_env__init_A_Unit34__O(); A_arbace_go_check_env__init_A_Unit35__O(); A_arbace_go_check_env__init_A_Unit36__O(); A_arbace_go_check_env__init_A_Unit37__O(); A_arbace_go_check_env__init_A_Unit38__O(); A_arbace_go_check_env__init_A_Unit39__O(); A_arbace_go_check_env__init_A_Unit40__O(); A_arbace_go_check_env__init_A_Unit41__O(); A_arbace_go_check_env__init_A_Unit42__O(); return nil }









func A_arbace_go_check_env__init_A_Unit4__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_4; var tmp2 any = A_arbace_go_check_env_obj_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_env_obj_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_go_check_env_obj_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_5)); return A_arbace_go_check_env__init_A_const_4 }
func A_arbace_go_check_env__init_A_Unit5__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_6; var tmp2 any = A_arbace_go_check_env_o_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_go_check_env_o_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_go_check_env_o_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_7)); return A_arbace_go_check_env__init_A_const_6 }
func A_arbace_go_check_env__init_A_Unit6__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_8; var tmp2 any = A_arbace_go_check_env_oset_BANG__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_env_oset_BANG__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_go_check_env_oset_BANG__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_9)); return A_arbace_go_check_env__init_A_const_8 }
func A_arbace_go_check_env__init_A_Unit7__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_10; var tmp2 any = A_arbace_go_check_env_obj_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_go_check_env_obj_QMARK__A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_go_check_env_obj_QMARK__A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_11)); return A_arbace_go_check_env__init_A_const_10 }



func A_arbace_go_check_env__init_A_Unit8__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_12; var tmp2 any = A_arbace_go_check_env_scope_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_env_scope_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_go_check_env_scope_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_13)); return A_arbace_go_check_env__init_A_const_12 }

func A_arbace_go_check_env__init_A_Unit9__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_14; var tmp2 any = A_arbace_go_check_env_scope_lookup_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_go_check_env_scope_lookup_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_check_env_scope_lookup_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_15)); return A_arbace_go_check_env__init_A_const_14 }








func A_arbace_go_check_env__init_A_Unit10__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_16; var tmp2 any = A_arbace_go_check_env_scope_get_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_env_scope_get_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_go_check_env_scope_get_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_17)); return A_arbace_go_check_env__init_A_const_16 }
func A_arbace_go_check_env__init_A_Unit11__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_18; var tmp2 any = A_arbace_go_check_env_scope_put_BANG__A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_go_check_env_scope_put_BANG__A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_go_check_env_scope_put_BANG__A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_19)); return A_arbace_go_check_env__init_A_const_18 }



func A_arbace_go_check_env__init_A_Unit12__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); A_arbace_go_check_env__init_A_const_20.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_21)); return A_arbace_go_check_env__init_A_const_20.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit13__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); A_arbace_go_check_env__init_A_const_22.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_23)); return A_arbace_go_check_env__init_A_const_22.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit14__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); A_arbace_go_check_env__init_A_const_24.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_24; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_25)); return A_arbace_go_check_env__init_A_const_24.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit15__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); A_arbace_go_check_env__init_A_const_26.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_27)); return A_arbace_go_check_env__init_A_const_26.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check_env__init_A_Unit16__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); A_arbace_go_check_env__init_A_const_28.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_29)); return A_arbace_go_check_env__init_A_const_28.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check_env__init_A_Unit17__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_30; var tmp2 any = A_arbace_go_check_env_error_BANG__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_env_error_BANG__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_go_check_env_error_BANG__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_31)); return A_arbace_go_check_env__init_A_const_30 }









func A_arbace_go_check_env__init_A_Unit18__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(68, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_32; var tmp2 any = A_arbace_go_check_env_line_of_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_go_check_env_line_of_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_go_check_env_line_of_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_33)); return A_arbace_go_check_env__init_A_const_32 }





func A_arbace_go_check_env__init_A_Unit19__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); A_arbace_go_check_env__init_A_const_34.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_34; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_35)); return A_arbace_go_check_env__init_A_const_34.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check_env__init_A_Unit20__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(76, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_36; var tmp2 any = A_arbace_go_check_env_err_BANG__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_env_err_BANG__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, true); A_arbace_go_check_env_err_BANG__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_37)); return A_arbace_go_check_env__init_A_const_36 }






func A_arbace_go_check_env__init_A_Unit21__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_38; var tmp2 any = A_arbace_go_check_env_generic_BANG__A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_go_check_env_generic_BANG__A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_go_check_env_generic_BANG__A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_39)); return A_arbace_go_check_env__init_A_const_38 }





func A_arbace_go_check_env__init_A_Unit22__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_40; var tmp2 any = A_arbace_go_check_env_unsupported_BANG__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_env_unsupported_BANG__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_go_check_env_unsupported_BANG__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_41)); return A_arbace_go_check_env__init_A_const_40 }









func A_arbace_go_check_env__init_A_Unit23__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(99, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_42; var tmp2 any = A_arbace_go_check_env_unsupported_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_go_check_env_unsupported_QMARK__A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_go_check_env_unsupported_QMARK__A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_43)); return A_arbace_go_check_env__init_A_const_42 }



func A_arbace_go_check_env__init_A_Unit24__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(103, 1); A_arbace_go_check_env__init_A_const_44.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_44; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_45)); return A_arbace_go_check_env__init_A_const_44.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_env__init_A_Unit25__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(108, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_46; var tmp2 any = A_arbace_go_check_env_verified_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_check_env_verified_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_go_check_env_verified_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_47)); return A_arbace_go_check_env__init_A_const_46 }












func A_arbace_go_check_env__init_A_Unit26__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(121, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_48; var tmp2 any = A_arbace_go_check_env_annotation_error_BANG__A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_go_check_env_annotation_error_BANG__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_go_check_env_annotation_error_BANG__A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_49)); return A_arbace_go_check_env__init_A_const_48 }







func A_arbace_go_check_env__init_A_Unit27__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(129, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_50; var tmp2 any; var root_19 any = A_arbace_go_check_env__init_A_const_12.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, A_arbace_go_check_env_scope_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any; var arg_23 any = A_arbace_go_check_env__init_A_const_51; if linked_20 == nil { tmp2 = ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { tmp2 = linked_20.(*A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_check_env__init_A_const_50; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_52)); return A_arbace_go_check_env__init_A_const_50 }

func A_arbace_go_check_env__init_A_Unit28__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(131, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_53; var tmp2 any = A_arbace_go_check_env_def_type_BANG__A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_go_check_env_def_type_BANG__A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_go_check_env_def_type_BANG__A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_54)); return A_arbace_go_check_env__init_A_const_53 }

func A_arbace_go_check_env__init_A_Unit29__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(133, 1); { var seq_1719000029__1 any; var root_25 any = A_arbace_go_check_env__init_A_const_55.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = A_arbace_go_check_env__init_A_const_56; if linked_26 == nil { seq_1719000029__1 = ifn_27.Invoke_O__O(arg_28) } else { seq_1719000029__1 = linked_26.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_25, arg_28) }; var chunk_1719000030__2 any; var count_1719000031__3 int64 = 0; var i_1719000032__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000032__4, count_1719000031__3) { var vec__1719000034__5 any = lang.Indexed_Cast(chunk_1719000030__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000032__4)); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000034__5, lang.RT_IntCast_J__I_NoInit(0), nil); var kw__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000034__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_45 any = A_arbace_go_check_env__init_A_const_53.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, A_arbace_go_check_env_def_type_BANG__A_fn_class); var ifn_47 lang.IFn




	if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = n__6; var arg_49 any = kw__7; if linked_46 == nil { ifn_47.Invoke_O_O__O(arg_48, arg_49) } else { linked_46.(*A_arbace_go_check_env_def_type_BANG__A).Invoke_O_O_O__O(root_45, arg_48, arg_49) }
//line :133:1
	seq_1719000029__1, chunk_1719000030__2, count_1719000031__3, i_1719000032__4 = seq_1719000029__1, chunk_1719000030__2, count_1719000031__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000032__4); continue L1



} else {
//line :133:1
	var temp__1927000414__auto____5 any; var root_29 any = A_arbace_go_check_env__init_A_const_55.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = seq_1719000029__1; if linked_30 == nil { temp__1927000414__auto____5 = ifn_31.Invoke_O__O(arg_32) } else { temp__1927000414__auto____5 = linked_30.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_29, arg_32) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1719000029__6 any = temp__1927000414__auto____5; var tmp1 any; var root_33 any = A_arbace_go_check_env__init_A_const_57.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = seq_1719000029__6; if linked_34 == nil { tmp1 = ifn_35.Invoke_O__O(arg_36) } else { tmp1 = linked_34.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_33, arg_36) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____7 any; var root_37 any = A_arbace_go_check_env__init_A_const_58.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = seq_1719000029__6; if linked_38 == nil { c__1927000678__auto____7 = ifn_39.Invoke_O__O(arg_40) } else { c__1927000678__auto____7 = linked_38.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_37, arg_40) }; var tmp2 any; var root_50 any = A_arbace_go_check_env__init_A_const_60.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = seq_1719000029__6; if linked_51 == nil { tmp2 = ifn_52.Invoke_O__O(arg_53) } else { tmp2 = linked_51.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_50, arg_53) }; seq_1719000029__1, chunk_1719000030__2, count_1719000031__3, i_1719000032__4 = tmp2, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1719000037__7 any; var root_41 any = A_arbace_go_check_env__init_A_const_59.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = seq_1719000029__6; if linked_42 == nil { vec__1719000037__7 = ifn_43.Invoke_O__O(arg_44) } else { vec__1719000037__7 = linked_42.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_41, arg_44) }; var n__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000037__7, lang.RT_IntCast_J__I_NoInit(0), nil); var kw__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000037__7, lang.RT_IntCast_J__I_NoInit(1), nil); var root_54 any = A_arbace_go_check_env__init_A_const_53.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, A_arbace_go_check_env_def_type_BANG__A_fn_class); var ifn_56 lang.IFn




		if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = n__8; var arg_58 any = kw__9; if linked_55 == nil { ifn_56.Invoke_O_O__O(arg_57, arg_58) } else { linked_55.(*A_arbace_go_check_env_def_type_BANG__A).Invoke_O_O_O__O(root_54, arg_57, arg_58) }
//line :133:1
		var tmp3 any; var root_59 any = A_arbace_go_check_env__init_A_const_61.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = seq_1719000029__6; if linked_60 == nil { tmp3 = ifn_61.Invoke_O__O(arg_62) } else { tmp3 = linked_60.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_59, arg_62) }; seq_1719000029__1, chunk_1719000030__2, count_1719000031__3, i_1719000032__4 = tmp3, nil, 0, 0; continue L1 } } else { return nil
		}
}
}
}
	panic("j2g: unreachable")
}
func A_arbace_go_check_env__init_A_Unit30__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(140, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_62; var tmp2 any = A_arbace_go_check_env_fn__1719000041_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_go_check_env_fn__1719000041_A_fn_class; if
							fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_go_check_env_fn__1719000041_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; /*line :140:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_63)); return A_arbace_go_check_env__init_A_const_62 }





func A_arbace_go_check_env__init_A_Unit31__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(146, 1); var root_64 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = A_arbace_go_check_env__init_A_const_50.GetRawRoot__O(); var arg_68 any = Lit_26; var arg_69 any; var root_70 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, A_arbace_go_check_env_obj_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_64; var tmp2 any = A_arbace_go_check_env__init_A_const_65; var tmp3 any = A_arbace_go_check_env__init_A_const_66; var tmp4 any = A_arbace_go_check_env__init_A_const_65; var arg_73 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_26, tmp4, A_arbace_go_check_env__init_A_const_62.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_51, jrt.Boolean_TRUE.Ref())); if linked_71 == nil { arg_69 = ifn_72.Invoke_O__O(arg_73) } else { arg_69 = linked_71.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_70, arg_73) }; if linked_65 == nil { return ifn_66.Invoke_O_O_O__O(arg_67, arg_68, arg_69) } else { return linked_65.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_64, arg_67, arg_68, arg_69) } }
func A_arbace_go_check_env__init_A_Unit32__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(147, 1); var root_74 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = A_arbace_go_check_env__init_A_const_50.GetRawRoot__O(); var arg_78 any = Lit_27; var arg_79 any; var root_80 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, A_arbace_go_check_env_obj_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_64; var tmp2 any = A_arbace_go_check_env__init_A_const_65; var tmp3 any = A_arbace_go_check_env__init_A_const_66; var tmp4 any = A_arbace_go_check_env__init_A_const_65; var arg_83 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_27, tmp4, lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_env__init_A_const_68, lang.PersistentVector_EMPTY.Ref(), nil), A_arbace_go_check_env__init_A_const_67, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_env__init_A_const_51, jrt.Boolean_TRUE.Ref())); if linked_81 == nil { arg_79 = ifn_82.Invoke_O__O(arg_83) } else { arg_79 = linked_81.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_80, arg_83) }; if linked_75 == nil { return ifn_76.Invoke_O_O_O__O(arg_77, arg_78, arg_79) } else { return linked_75.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_74, arg_77, arg_78, arg_79) } }

func A_arbace_go_check_env__init_A_Unit33__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(149, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_69; var tmp2 any = A_arbace_go_check_env_fn__1719000047_A_New(); var tmp3 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_go_check_env_fn__1719000047_A_fn_class; if
							fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_go_check_env_fn__1719000047_A_fn_class = fncls__84d; tmp3 = fncls__84d } else { tmp3 = fncls__84 }; /*line :149:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_70)); return A_arbace_go_check_env__init_A_const_69 }




func A_arbace_go_check_env__init_A_Unit34__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(154, 1); var root_85 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = A_arbace_go_check_env__init_A_const_50.GetRawRoot__O(); var arg_89 any = Lit_29; var arg_90 any; var root_91 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, A_arbace_go_check_env_obj_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_64; var tmp2 any = A_arbace_go_check_env__init_A_const_65; var tmp3 any = A_arbace_go_check_env__init_A_const_66; var tmp4 any = A_arbace_go_check_env__init_A_const_65; var arg_94 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_29, tmp4, A_arbace_go_check_env__init_A_const_69.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_51, jrt.Boolean_TRUE.Ref())); if linked_92 == nil { arg_90 = ifn_93.Invoke_O__O(arg_94) } else { arg_90 = linked_92.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_91, arg_94) }; if linked_86 == nil { return ifn_87.Invoke_O_O_O__O(arg_88, arg_89, arg_90) } else { return linked_86.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_85, arg_88, arg_89, arg_90) } }

func A_arbace_go_check_env__init_A_Unit35__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(156, 1); var root_95 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = A_arbace_go_check_env__init_A_const_50.GetRawRoot__O(); var arg_99 any = Lit_30; var arg_100 any; var root_101 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, A_arbace_go_check_env_obj_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = A_arbace_go_check_env__init_A_const_71; if linked_102 == nil { arg_100 = ifn_103.Invoke_O__O(arg_104) } else { arg_100 = linked_102.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_101, arg_104) }; if linked_96 == nil { return ifn_97.Invoke_O_O_O__O(arg_98, arg_99, arg_100) } else { return linked_96.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_95, arg_98, arg_99, arg_100) } }
func A_arbace_go_check_env__init_A_Unit36__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(157, 1); var root_105 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = A_arbace_go_check_env__init_A_const_50.GetRawRoot__O(); var arg_109 any = Lit_31; var arg_110 any; var root_111 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, A_arbace_go_check_env_obj_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = A_arbace_go_check_env__init_A_const_72; if linked_112 == nil { arg_110 = ifn_113.Invoke_O__O(arg_114) } else { arg_110 = linked_112.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_111, arg_114) }; if linked_106 == nil { return ifn_107.Invoke_O_O_O__O(arg_108, arg_109, arg_110) } else { return linked_106.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_105, arg_108, arg_109, arg_110) } }
func A_arbace_go_check_env__init_A_Unit37__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var root_115 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = A_arbace_go_check_env__init_A_const_50.GetRawRoot__O(); var arg_119 any = Lit_32; var arg_120 any; var root_121 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_go_check_env_obj_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = A_arbace_go_check_env__init_A_const_73; if linked_122 == nil { arg_120 = ifn_123.Invoke_O__O(arg_124) } else { arg_120 = linked_122.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_121, arg_124) }; if linked_116 == nil { return ifn_117.Invoke_O_O_O__O(arg_118, arg_119, arg_120) } else { return linked_116.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_115, arg_118, arg_119, arg_120) } }
func A_arbace_go_check_env__init_A_Unit38__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(159, 1); var root_125 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = A_arbace_go_check_env__init_A_const_50.GetRawRoot__O(); var arg_129 any = Lit_33; var arg_130 any; var root_131 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, A_arbace_go_check_env_obj_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = A_arbace_go_check_env__init_A_const_74; if linked_132 == nil { arg_130 = ifn_133.Invoke_O__O(arg_134) } else { arg_130 = linked_132.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_131, arg_134) }; if linked_126 == nil { return ifn_127.Invoke_O_O_O__O(arg_128, arg_129, arg_130) } else { return linked_126.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_125, arg_128, arg_129, arg_130) } }

func A_arbace_go_check_env__init_A_Unit39__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); A_arbace_go_check_env__init_A_const_75.BindRoot_O__V(A_arbace_go_check_env__init_A_const_76); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_75; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_77)); return A_arbace_go_check_env__init_A_const_75 }



func A_arbace_go_check_env__init_A_Unit40__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(165, 1); { var seq_1719000059__1 any; var root_135 any = A_arbace_go_check_env__init_A_const_55.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = A_arbace_go_check_env__init_A_const_75.GetRawRoot__O(); if linked_136 == nil { seq_1719000059__1 = ifn_137.Invoke_O__O(arg_138) } else { seq_1719000059__1 = linked_136.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_135, arg_138) }; var chunk_1719000060__2 any; var count_1719000061__3 int64 = 0; var i_1719000062__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000062__4, count_1719000061__3) { var n__5 any = lang.Indexed_Cast(chunk_1719000060__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000062__4)); var root_155 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_157 lang.IFn
	if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = A_arbace_go_check_env__init_A_const_50.GetRawRoot__O(); var arg_159 any = n__5; var arg_160 any; var root_161 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, A_arbace_go_check_env_obj_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env__init_A_const_64, A_arbace_go_check_env__init_A_const_78, A_arbace_go_check_env__init_A_const_66, n__5, A_arbace_go_check_env__init_A_const_51, jrt.Boolean_TRUE.Ref())); if linked_162 == nil { arg_160 = ifn_163.Invoke_O__O(arg_164) } else { arg_160 = linked_162.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_161, arg_164) }; if linked_156 == nil { ifn_157.Invoke_O_O_O__O(arg_158, arg_159, arg_160) } else { linked_156.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_155, arg_158, arg_159, arg_160) }
//line :165:1
	seq_1719000059__1, chunk_1719000060__2, count_1719000061__3, i_1719000062__4 = seq_1719000059__1, chunk_1719000060__2, count_1719000061__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000062__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_139 any = A_arbace_go_check_env__init_A_const_55.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = seq_1719000059__1; if linked_140 == nil { temp__1927000414__auto____5 = ifn_141.Invoke_O__O(arg_142) } else { temp__1927000414__auto____5 = linked_140.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_139, arg_142) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1719000059__6 any = temp__1927000414__auto____5; var tmp1 any; var root_143 any = A_arbace_go_check_env__init_A_const_57.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = seq_1719000059__6; if linked_144 == nil { tmp1 = ifn_145.Invoke_O__O(arg_146) } else { tmp1 = linked_144.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_143, arg_146) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____7 any; var root_147 any = A_arbace_go_check_env__init_A_const_58.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = seq_1719000059__6; if linked_148 == nil { c__1927000678__auto____7 = ifn_149.Invoke_O__O(arg_150) } else { c__1927000678__auto____7 = linked_148.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_147, arg_150) }; var tmp2 any; var root_165 any = A_arbace_go_check_env__init_A_const_60.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = seq_1719000059__6; if linked_166 == nil { tmp2 = ifn_167.Invoke_O__O(arg_168) } else { tmp2 = linked_166.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_165, arg_168) }; seq_1719000059__1, chunk_1719000060__2, count_1719000061__3, i_1719000062__4 = tmp2, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__7 any; var root_151 any = A_arbace_go_check_env__init_A_const_59.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = seq_1719000059__6; if linked_152 == nil { n__7 = ifn_153.Invoke_O__O(arg_154) } else { n__7 = linked_152.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_151, arg_154) }
		var root_169 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = A_arbace_go_check_env__init_A_const_50.GetRawRoot__O(); var arg_173 any = n__7; var arg_174 any; var root_175 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, A_arbace_go_check_env_obj_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env__init_A_const_64, A_arbace_go_check_env__init_A_const_78, A_arbace_go_check_env__init_A_const_66, n__7, A_arbace_go_check_env__init_A_const_51, jrt.Boolean_TRUE.Ref())); if linked_176 == nil { arg_174 = ifn_177.Invoke_O__O(arg_178) } else { arg_174 = linked_176.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_175, arg_178) }; if linked_170 == nil { ifn_171.Invoke_O_O_O__O(arg_172, arg_173, arg_174) } else { linked_170.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_169, arg_172, arg_173, arg_174) }
//line :165:1
		var tmp3 any; var root_179 any = A_arbace_go_check_env__init_A_const_61.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = seq_1719000059__6; if linked_180 == nil { tmp3 = ifn_181.Invoke_O__O(arg_182) } else { tmp3 = linked_180.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_179, arg_182) }; seq_1719000059__1, chunk_1719000060__2, count_1719000061__3, i_1719000062__4 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } }
	panic("j2g: unreachable")
}


func A_arbace_go_check_env__init_A_Unit41__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(170, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_79; var tmp2 any = A_arbace_go_check_env_fn__1719000065_A_New(); var tmp3 *jrt.Class; var fncls__183 *jrt.Class = A_arbace_go_check_env_fn__1719000065_A_fn_class; if
							fncls__183 == nil { var fncls__183d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_check_env_fn__1719000065_A_fn_class = fncls__183d; tmp3 = fncls__183d } else { tmp3 = fncls__183 }; /*line :170:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_80)); return A_arbace_go_check_env__init_A_const_79 }






func A_arbace_go_check_env__init_A_Unit42__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(177, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_81; var tmp2 any; var root_184 any = A_arbace_go_check_env__init_A_const_82.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var tmp3 any = A_arbace_go_check_env__init_A_const_83; var tmp4 any = A_arbace_go_check_env__init_A_const_66; var tmp5 any = A_arbace_go_check_env__init_A_const_84; var arg_187 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, Lit_4, tmp4, Lit_4, tmp5, A_arbace_go_check_env__init_A_const_79.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_85, jrt.Boolean_TRUE.Ref())); if linked_185 == nil { tmp2 = ifn_186.Invoke_O__O(arg_187) } else { tmp2 = linked_185.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_184, arg_187) }; tmp1.BindRoot_O__V(tmp2); var tmp6 *lang.Var = A_arbace_go_check_env__init_A_const_81; tmp6.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_86)); return A_arbace_go_check_env__init_A_const_81 }



type A_arbace_go_check_env__init_A struct{ jrt.Object }

var A_arbace_go_check_env__init_A_const_pool *jrt.RefArray

var A_arbace_go_check_env__init_A_const_0 *lang.Var

var A_arbace_go_check_env__init_A_const_1 any

var A_arbace_go_check_env__init_A_const_2 any

var A_arbace_go_check_env__init_A_const_3 any

var A_arbace_go_check_env__init_A_const_4 *lang.Var

var A_arbace_go_check_env__init_A_const_5 any

var A_arbace_go_check_env__init_A_const_6 *lang.Var

var A_arbace_go_check_env__init_A_const_7 any

var A_arbace_go_check_env__init_A_const_8 *lang.Var

var A_arbace_go_check_env__init_A_const_9 any

var A_arbace_go_check_env__init_A_const_10 *lang.Var

var A_arbace_go_check_env__init_A_const_11 any

var A_arbace_go_check_env__init_A_const_12 *lang.Var

var A_arbace_go_check_env__init_A_const_13 any

var A_arbace_go_check_env__init_A_const_14 *lang.Var

var A_arbace_go_check_env__init_A_const_15 any

var A_arbace_go_check_env__init_A_const_16 *lang.Var

var A_arbace_go_check_env__init_A_const_17 any

var A_arbace_go_check_env__init_A_const_18 *lang.Var

var A_arbace_go_check_env__init_A_const_19 any

var A_arbace_go_check_env__init_A_const_20 *lang.Var

var A_arbace_go_check_env__init_A_const_21 any

var A_arbace_go_check_env__init_A_const_22 *lang.Var

var A_arbace_go_check_env__init_A_const_23 any

var A_arbace_go_check_env__init_A_const_24 *lang.Var

var A_arbace_go_check_env__init_A_const_25 any

var A_arbace_go_check_env__init_A_const_26 *lang.Var

var A_arbace_go_check_env__init_A_const_27 any

var A_arbace_go_check_env__init_A_const_28 *lang.Var

var A_arbace_go_check_env__init_A_const_29 any

var A_arbace_go_check_env__init_A_const_30 *lang.Var

var A_arbace_go_check_env__init_A_const_31 any

var A_arbace_go_check_env__init_A_const_32 *lang.Var

var A_arbace_go_check_env__init_A_const_33 any

var A_arbace_go_check_env__init_A_const_34 *lang.Var

var A_arbace_go_check_env__init_A_const_35 any

var A_arbace_go_check_env__init_A_const_36 *lang.Var

var A_arbace_go_check_env__init_A_const_37 any

var A_arbace_go_check_env__init_A_const_38 *lang.Var

var A_arbace_go_check_env__init_A_const_39 any

var A_arbace_go_check_env__init_A_const_40 *lang.Var

var A_arbace_go_check_env__init_A_const_41 any

var A_arbace_go_check_env__init_A_const_42 *lang.Var

var A_arbace_go_check_env__init_A_const_43 any

var A_arbace_go_check_env__init_A_const_44 *lang.Var

var A_arbace_go_check_env__init_A_const_45 any

var A_arbace_go_check_env__init_A_const_46 *lang.Var

var A_arbace_go_check_env__init_A_const_47 any

var A_arbace_go_check_env__init_A_const_48 *lang.Var

var A_arbace_go_check_env__init_A_const_49 any

var A_arbace_go_check_env__init_A_const_50 *lang.Var

var A_arbace_go_check_env__init_A_const_51 *lang.Keyword

var A_arbace_go_check_env__init_A_const_52 any

var A_arbace_go_check_env__init_A_const_53 *lang.Var

var A_arbace_go_check_env__init_A_const_54 any

var A_arbace_go_check_env__init_A_const_55 *lang.Var

var A_arbace_go_check_env__init_A_const_56 any

var A_arbace_go_check_env__init_A_const_57 *lang.Var

var A_arbace_go_check_env__init_A_const_58 *lang.Var

var A_arbace_go_check_env__init_A_const_59 *lang.Var

var A_arbace_go_check_env__init_A_const_60 *lang.Var

var A_arbace_go_check_env__init_A_const_61 *lang.Var

var A_arbace_go_check_env__init_A_const_62 *lang.Var

var A_arbace_go_check_env__init_A_const_63 any

var A_arbace_go_check_env__init_A_const_64 *lang.Keyword

var A_arbace_go_check_env__init_A_const_65 *lang.Keyword

var A_arbace_go_check_env__init_A_const_66 *lang.Keyword

var A_arbace_go_check_env__init_A_const_67 *lang.Keyword

var A_arbace_go_check_env__init_A_const_68 *lang.Keyword

var A_arbace_go_check_env__init_A_const_69 *lang.Var

var A_arbace_go_check_env__init_A_const_70 any

var A_arbace_go_check_env__init_A_const_71 any

var A_arbace_go_check_env__init_A_const_72 any

var A_arbace_go_check_env__init_A_const_73 any

var A_arbace_go_check_env__init_A_const_74 any

var A_arbace_go_check_env__init_A_const_75 *lang.Var

var A_arbace_go_check_env__init_A_const_76 any

var A_arbace_go_check_env__init_A_const_77 any

var A_arbace_go_check_env__init_A_const_78 *lang.Keyword

var A_arbace_go_check_env__init_A_const_79 *lang.Var

var A_arbace_go_check_env__init_A_const_80 any

var A_arbace_go_check_env__init_A_const_81 *lang.Var

var A_arbace_go_check_env__init_A_const_82 *lang.Var

var A_arbace_go_check_env__init_A_const_83 *lang.Keyword

var A_arbace_go_check_env__init_A_const_84 *lang.Keyword

var A_arbace_go_check_env__init_A_const_85 *lang.Keyword

var A_arbace_go_check_env__init_A_const_86 any

var A_arbace_go_check_env__init_A_init jrt.ClassInit

func A_arbace_go_check_env__init_A_Init() { if !A_arbace_go_check_env__init_A_init.Done() { A_arbace_go_check_env__init_A_init.Run(A_arbace_go_check_env__init_A_clinit) } }

func A_arbace_go_check_env__init_A_clinit() { A_arbace_go_check_env__init_A_clinit_p0(); A_arbace_go_check_env__init_A_clinit_p1(); A_arbace_go_check_env__init_A_clinit_p2(); A_arbace_go_check_env__init_A_clinit_p3(); A_arbace_go_check_env__init_A_clinit_p4(); A_arbace_go_check_env__init_A_clinit_p5(); A_arbace_go_check_env__init_A_clinit_p6() }

func A_arbace_go_check_env__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_env__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_5, 154); A_arbace_go_check_env__init_A_const_0 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[67]); A_arbace_go_check_env__init_A_const_1 = A_arbace_go_check_env__init_A_const_pool.A[68]; A_arbace_go_check_env__init_A_const_2 = A_arbace_go_check_env__init_A_const_pool.A[69]; A_arbace_go_check_env__init_A_const_3 = A_arbace_go_check_env__init_A_const_pool.A[70]; A_arbace_go_check_env__init_A_const_4 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[71]); A_arbace_go_check_env__init_A_const_5 = A_arbace_go_check_env__init_A_const_pool.A[72]; A_arbace_go_check_env__init_A_const_6 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[73]); A_arbace_go_check_env__init_A_const_7 = A_arbace_go_check_env__init_A_const_pool.A[74]; A_arbace_go_check_env__init_A_const_8 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[75]); A_arbace_go_check_env__init_A_const_9 = A_arbace_go_check_env__init_A_const_pool.A[76]; A_arbace_go_check_env__init_A_const_10 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[77]); A_arbace_go_check_env__init_A_const_11 = A_arbace_go_check_env__init_A_const_pool.A[78]; A_arbace_go_check_env__init_A_const_12 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[79]) }

func A_arbace_go_check_env__init_A_clinit_p1() { A_arbace_go_check_env__init_A_const_13 = A_arbace_go_check_env__init_A_const_pool.A[80]; A_arbace_go_check_env__init_A_const_14 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[81]); A_arbace_go_check_env__init_A_const_15 = A_arbace_go_check_env__init_A_const_pool.A[82]; A_arbace_go_check_env__init_A_const_16 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[83]); A_arbace_go_check_env__init_A_const_17 = A_arbace_go_check_env__init_A_const_pool.A[84]; A_arbace_go_check_env__init_A_const_18 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[85]); A_arbace_go_check_env__init_A_const_19 = A_arbace_go_check_env__init_A_const_pool.A[86]; A_arbace_go_check_env__init_A_const_20 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[87]); A_arbace_go_check_env__init_A_const_21 = A_arbace_go_check_env__init_A_const_pool.A[88]; A_arbace_go_check_env__init_A_const_22 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[89]); A_arbace_go_check_env__init_A_const_23 = A_arbace_go_check_env__init_A_const_pool.A[90]; A_arbace_go_check_env__init_A_const_24 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[91]); A_arbace_go_check_env__init_A_const_25 = A_arbace_go_check_env__init_A_const_pool.A[92] }

func A_arbace_go_check_env__init_A_clinit_p2() { A_arbace_go_check_env__init_A_const_26 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[93]); A_arbace_go_check_env__init_A_const_27 = A_arbace_go_check_env__init_A_const_pool.A[94]; A_arbace_go_check_env__init_A_const_28 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[95]); A_arbace_go_check_env__init_A_const_29 = A_arbace_go_check_env__init_A_const_pool.A[96]; A_arbace_go_check_env__init_A_const_30 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[97]); A_arbace_go_check_env__init_A_const_31 = A_arbace_go_check_env__init_A_const_pool.A[98]; A_arbace_go_check_env__init_A_const_32 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[99]); A_arbace_go_check_env__init_A_const_33 = A_arbace_go_check_env__init_A_const_pool.A[100]; A_arbace_go_check_env__init_A_const_34 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[101]); A_arbace_go_check_env__init_A_const_35 = A_arbace_go_check_env__init_A_const_pool.A[102]; A_arbace_go_check_env__init_A_const_36 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[103]); A_arbace_go_check_env__init_A_const_37 = A_arbace_go_check_env__init_A_const_pool.A[104]; A_arbace_go_check_env__init_A_const_38 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[105]) }

func A_arbace_go_check_env__init_A_clinit_p3() { A_arbace_go_check_env__init_A_const_39 = A_arbace_go_check_env__init_A_const_pool.A[106]; A_arbace_go_check_env__init_A_const_40 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[107]); A_arbace_go_check_env__init_A_const_41 = A_arbace_go_check_env__init_A_const_pool.A[108]; A_arbace_go_check_env__init_A_const_42 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[109]); A_arbace_go_check_env__init_A_const_43 = A_arbace_go_check_env__init_A_const_pool.A[110]; A_arbace_go_check_env__init_A_const_44 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[111]); A_arbace_go_check_env__init_A_const_45 = A_arbace_go_check_env__init_A_const_pool.A[112]; A_arbace_go_check_env__init_A_const_46 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[113]); A_arbace_go_check_env__init_A_const_47 = A_arbace_go_check_env__init_A_const_pool.A[114]; A_arbace_go_check_env__init_A_const_48 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[115]); A_arbace_go_check_env__init_A_const_49 = A_arbace_go_check_env__init_A_const_pool.A[116]; A_arbace_go_check_env__init_A_const_50 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[117]); A_arbace_go_check_env__init_A_const_51 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[118]) }

func A_arbace_go_check_env__init_A_clinit_p4() { A_arbace_go_check_env__init_A_const_52 = A_arbace_go_check_env__init_A_const_pool.A[119]; A_arbace_go_check_env__init_A_const_53 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[120]); A_arbace_go_check_env__init_A_const_54 = A_arbace_go_check_env__init_A_const_pool.A[121]; A_arbace_go_check_env__init_A_const_55 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[122]); A_arbace_go_check_env__init_A_const_56 = A_arbace_go_check_env__init_A_const_pool.A[123]; A_arbace_go_check_env__init_A_const_57 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[124]); A_arbace_go_check_env__init_A_const_58 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[125]); A_arbace_go_check_env__init_A_const_59 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[126]); A_arbace_go_check_env__init_A_const_60 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[127]); A_arbace_go_check_env__init_A_const_61 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[128]); A_arbace_go_check_env__init_A_const_62 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[129]); A_arbace_go_check_env__init_A_const_63 = A_arbace_go_check_env__init_A_const_pool.A[130]; A_arbace_go_check_env__init_A_const_64 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[131]) }

func A_arbace_go_check_env__init_A_clinit_p5() { A_arbace_go_check_env__init_A_const_65 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[132]); A_arbace_go_check_env__init_A_const_66 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[133]); A_arbace_go_check_env__init_A_const_67 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[134]); A_arbace_go_check_env__init_A_const_68 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[135]); A_arbace_go_check_env__init_A_const_69 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[136]); A_arbace_go_check_env__init_A_const_70 = A_arbace_go_check_env__init_A_const_pool.A[137]; A_arbace_go_check_env__init_A_const_71 = A_arbace_go_check_env__init_A_const_pool.A[138]; A_arbace_go_check_env__init_A_const_72 = A_arbace_go_check_env__init_A_const_pool.A[139]; A_arbace_go_check_env__init_A_const_73 = A_arbace_go_check_env__init_A_const_pool.A[140]; A_arbace_go_check_env__init_A_const_74 = A_arbace_go_check_env__init_A_const_pool.A[141]; A_arbace_go_check_env__init_A_const_75 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[142]); A_arbace_go_check_env__init_A_const_76 = A_arbace_go_check_env__init_A_const_pool.A[143]; A_arbace_go_check_env__init_A_const_77 = A_arbace_go_check_env__init_A_const_pool.A[144] }

func A_arbace_go_check_env__init_A_clinit_p6() { A_arbace_go_check_env__init_A_const_78 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[145]); A_arbace_go_check_env__init_A_const_79 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[146]); A_arbace_go_check_env__init_A_const_80 = A_arbace_go_check_env__init_A_const_pool.A[147]; A_arbace_go_check_env__init_A_const_81 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[148]); A_arbace_go_check_env__init_A_const_82 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[149]); A_arbace_go_check_env__init_A_const_83 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[150]); A_arbace_go_check_env__init_A_const_84 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[151]); A_arbace_go_check_env__init_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[152]); A_arbace_go_check_env__init_A_const_86 = A_arbace_go_check_env__init_A_const_pool.A[153] }

func A_arbace_go_check_env__init_A_New() *A_arbace_go_check_env__init_A { A_arbace_go_check_env__init_A_Init(); t := &A_arbace_go_check_env__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env__init_A) Ctor() {}

func (t *A_arbace_go_check_env__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env__init_A_class }

func (t *A_arbace_go_check_env__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env__init_A); return ok }

func A_arbace_go_check_env__init_A_Cast(x any) *A_arbace_go_check_env__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env__init_A_class)) }; return v }
