//line aot_arbace_go_check_env__init.ae:1
package aot_arbace_go_check_env

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_env__init_A_Unit0__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_check_env__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env__init_A_const_1) }
//line :1:1
func A_arbace_go_check_env__init_A_Unit1__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_check_env__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_2)) }
//line :1:1
func A_arbace_go_check_env__init_A_Unit2__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, nil); A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_go_check_env__init_A_Unit3__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_check_env__init_A_const_1)).Equals_O__Z(A_arbace_go_check_env__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_go_check_env_eval1719000008_fn__1719000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, nil); A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_go_check_env__init_A_Load__O() any { A_arbace_go_check_env__init_A_Init(); jrt.StartCheck(); A_arbace_go_check_env__init_A_Unit0__O(); A_arbace_go_check_env__init_A_Unit1__O(); A_arbace_go_check_env__init_A_Unit2__O(); A_arbace_go_check_env__init_A_Unit3__O(); A_arbace_go_check_env__init_A_Unit4__O(); A_arbace_go_check_env__init_A_Unit5__O(); A_arbace_go_check_env__init_A_Unit6__O(); A_arbace_go_check_env__init_A_Unit7__O(); A_arbace_go_check_env__init_A_Unit8__O(); A_arbace_go_check_env__init_A_Unit9__O(); A_arbace_go_check_env__init_A_Unit10__O(); A_arbace_go_check_env__init_A_Unit11__O(); A_arbace_go_check_env__init_A_Unit12__O(); A_arbace_go_check_env__init_A_Unit13__O(); A_arbace_go_check_env__init_A_Unit14__O(); A_arbace_go_check_env__init_A_Unit15__O(); A_arbace_go_check_env__init_A_Unit16__O(); A_arbace_go_check_env__init_A_Unit17__O(); A_arbace_go_check_env__init_A_Unit18__O(); A_arbace_go_check_env__init_A_Unit19__O(); A_arbace_go_check_env__init_A_Unit20__O(); A_arbace_go_check_env__init_A_Unit21__O(); A_arbace_go_check_env__init_A_Unit22__O(); A_arbace_go_check_env__init_A_Unit23__O(); A_arbace_go_check_env__init_A_Unit24__O(); A_arbace_go_check_env__init_A_Unit25__O(); A_arbace_go_check_env__init_A_Unit26__O(); A_arbace_go_check_env__init_A_Unit27__O(); A_arbace_go_check_env__init_A_Unit28__O(); A_arbace_go_check_env__init_A_Unit29__O(); A_arbace_go_check_env__init_A_Unit30__O(); A_arbace_go_check_env__init_A_Unit31__O(); A_arbace_go_check_env__init_A_Unit32__O(); A_arbace_go_check_env__init_A_Unit33__O(); A_arbace_go_check_env__init_A_Unit34__O(); A_arbace_go_check_env__init_A_Unit35__O(); A_arbace_go_check_env__init_A_Unit36__O(); A_arbace_go_check_env__init_A_Unit37__O(); A_arbace_go_check_env__init_A_Unit38__O(); A_arbace_go_check_env__init_A_Unit39__O(); A_arbace_go_check_env__init_A_Unit40__O(); A_arbace_go_check_env__init_A_Unit41__O(); A_arbace_go_check_env__init_A_Unit42__O(); A_arbace_go_check_env__init_A_Unit43__O(); A_arbace_go_check_env__init_A_Unit44__O(); A_arbace_go_check_env__init_A_Unit45__O(); A_arbace_go_check_env__init_A_Unit46__O(); A_arbace_go_check_env__init_A_Unit47__O(); A_arbace_go_check_env__init_A_Unit48__O(); A_arbace_go_check_env__init_A_Unit49__O(); A_arbace_go_check_env__init_A_Unit50__O(); A_arbace_go_check_env__init_A_Unit51__O(); A_arbace_go_check_env__init_A_Unit52__O(); A_arbace_go_check_env__init_A_Unit53__O(); A_arbace_go_check_env__init_A_Unit54__O(); A_arbace_go_check_env__init_A_Unit55__O(); return nil }









func A_arbace_go_check_env__init_A_Unit4__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_go_check_env_obj_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_env_obj_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, nil); A_arbace_go_check_env_obj_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_5)); return A_arbace_go_check_env__init_A_const_4 }
func A_arbace_go_check_env__init_A_Unit5__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_go_check_env_o_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_env_o_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, nil); A_arbace_go_check_env_o_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_7)); return A_arbace_go_check_env__init_A_const_6 }
func A_arbace_go_check_env__init_A_Unit6__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_go_check_env_oset_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_env_oset_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, nil); A_arbace_go_check_env_oset_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_9)); return A_arbace_go_check_env__init_A_const_8 }
func A_arbace_go_check_env__init_A_Unit7__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_go_check_env_obj_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_env_obj_QMARK__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, nil); A_arbace_go_check_env_obj_QMARK__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_11)); return A_arbace_go_check_env__init_A_const_10 }



func A_arbace_go_check_env__init_A_Unit8__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_go_check_env_scope_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_env_scope_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, nil); A_arbace_go_check_env_scope_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_13)); return A_arbace_go_check_env__init_A_const_12 }

func A_arbace_go_check_env__init_A_Unit9__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_go_check_env_scope_lookup_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_env_scope_lookup_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_go_check_env_scope_lookup_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_15)); return A_arbace_go_check_env__init_A_const_14 }








func A_arbace_go_check_env__init_A_Unit10__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_go_check_env_scope_get_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_check_env_scope_get_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); A_arbace_go_check_env_scope_get_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_17)); return A_arbace_go_check_env__init_A_const_16 }
func A_arbace_go_check_env__init_A_Unit11__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_go_check_env_scope_put_BANG__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_check_env_scope_put_BANG__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, nil); A_arbace_go_check_env_scope_put_BANG__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_19)); return A_arbace_go_check_env__init_A_const_18 }



func A_arbace_go_check_env__init_A_Unit12__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); A_arbace_go_check_env__init_A_const_20.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_21)); return A_arbace_go_check_env__init_A_const_20.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit13__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); A_arbace_go_check_env__init_A_const_22.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_23)); return A_arbace_go_check_env__init_A_const_22.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit14__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); A_arbace_go_check_env__init_A_const_24.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_24; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_25)); return A_arbace_go_check_env__init_A_const_24.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit15__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); A_arbace_go_check_env__init_A_const_26.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_27)); return A_arbace_go_check_env__init_A_const_26.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check_env__init_A_Unit16__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); A_arbace_go_check_env__init_A_const_28.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_29)); return A_arbace_go_check_env__init_A_const_28.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check_env__init_A_Unit17__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); A_arbace_go_check_env__init_A_const_30.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_31)); return A_arbace_go_check_env__init_A_const_30.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check_env__init_A_Unit18__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_go_check_env_error_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_check_env_error_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, nil); A_arbace_go_check_env_error_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_33)); return A_arbace_go_check_env__init_A_const_32 }















func A_arbace_go_check_env__init_A_Unit19__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(80, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_go_check_env_line_of_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_check_env_line_of_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, nil); A_arbace_go_check_env_line_of_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_35)); return A_arbace_go_check_env__init_A_const_34 }





func A_arbace_go_check_env__init_A_Unit20__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(86, 1); A_arbace_go_check_env__init_A_const_36.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_36; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_37)); return A_arbace_go_check_env__init_A_const_36.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check_env__init_A_Unit21__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(88, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_39)); return A_arbace_go_check_env__init_A_const_38 }

func A_arbace_go_check_env__init_A_Unit22__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(90, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_go_check_env_end_line_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_check_env_end_line_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, nil); A_arbace_go_check_env_end_line_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_41)); return A_arbace_go_check_env__init_A_const_40 }










func A_arbace_go_check_env__init_A_Unit23__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_go_check_env_child_line_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_check_env_child_line_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, nil); A_arbace_go_check_env_child_line_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_42)); return A_arbace_go_check_env__init_A_const_38 }



















func A_arbace_go_check_env__init_A_Unit24__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(121, 1); A_arbace_go_check_env__init_A_const_43.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_44)); return A_arbace_go_check_env__init_A_const_43.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_env__init_A_Unit25__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_45; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__30 any = A_arbace_go_check_env_with_child_line_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_check_env_with_child_line_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, true, nil); A_arbace_go_check_env_with_child_line_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__30, tmp3, nil, 4); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_46)); return A_arbace_go_check_env__init_A_const_45 }
//line :126:1
func A_arbace_go_check_env__init_A_Unit26__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); A_arbace_go_check_env__init_A_const_45.SetMacro__V(); return nil }
//line :126:1
func A_arbace_go_check_env__init_A_Unit27__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); return A_arbace_go_check_env__init_A_const_45 }







func A_arbace_go_check_env__init_A_Unit28__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(134, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_go_check_env_current_line_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_env_current_line_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); A_arbace_go_check_env_current_line_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_48)); return A_arbace_go_check_env__init_A_const_47 }




func A_arbace_go_check_env__init_A_Unit29__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_49; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__34 any = A_arbace_go_check_env_err_BANG__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_check_env_err_BANG__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, true, nil); A_arbace_go_check_env_err_BANG__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__34, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_50)); return A_arbace_go_check_env__init_A_const_49 }






func A_arbace_go_check_env__init_A_Unit30__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(146, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_go_check_env_generic_BANG__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_check_env_generic_BANG__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); A_arbace_go_check_env_generic_BANG__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_52)); return A_arbace_go_check_env__init_A_const_51 }





func A_arbace_go_check_env__init_A_Unit31__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(152, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_go_check_env_unsupported_BANG__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_check_env_unsupported_BANG__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); A_arbace_go_check_env_unsupported_BANG__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_54)); return A_arbace_go_check_env__init_A_const_53 }









func A_arbace_go_check_env__init_A_Unit32__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(162, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_go_check_env_unsupported_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_check_env_unsupported_QMARK__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, nil); A_arbace_go_check_env_unsupported_QMARK__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_56)); return A_arbace_go_check_env__init_A_const_55 }



func A_arbace_go_check_env__init_A_Unit33__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(166, 1); A_arbace_go_check_env__init_A_const_57.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_57; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_58)); return A_arbace_go_check_env__init_A_const_57.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_env__init_A_Unit34__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(171, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_go_check_env_verified_BANG__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_check_env_verified_BANG__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); A_arbace_go_check_env_verified_BANG__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_60)); return A_arbace_go_check_env__init_A_const_59 }












func A_arbace_go_check_env__init_A_Unit35__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(184, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_go_check_env_annotation_error_BANG__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_check_env_annotation_error_BANG__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_go_check_env_annotation_error_BANG__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_62)); return A_arbace_go_check_env__init_A_const_61 }







func A_arbace_go_check_env__init_A_Unit36__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(192, 1); A_arbace_go_check_env__init_A_const_63.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_63; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_64)); return A_arbace_go_check_env__init_A_const_63.SetDynamic_Z__Var(true).Ref() }






func A_arbace_go_check_env__init_A_Unit37__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(199, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_go_check_env_at_of_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_check_env_at_of_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, nil); A_arbace_go_check_env_at_of_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_66)); return A_arbace_go_check_env__init_A_const_65 }




func A_arbace_go_check_env__init_A_Unit38__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(204, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_go_check_env_answer_BANG__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_check_env_answer_BANG__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); A_arbace_go_check_env_answer_BANG__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_68)); return A_arbace_go_check_env__init_A_const_67 }













func A_arbace_go_check_env__init_A_Unit39__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(218, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_go_check_env_unanswer_BANG__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_check_env_unanswer_BANG__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, nil); A_arbace_go_check_env_unanswer_BANG__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_70)); return A_arbace_go_check_env__init_A_const_69 }









func A_arbace_go_check_env__init_A_Unit40__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(228, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_71; var tmp2 any; var root_51 any = A_arbace_go_check_env__init_A_const_12.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, A_arbace_go_check_env_scope_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any; var arg_55 any = A_arbace_go_check_env__init_A_const_72; if linked_52 == nil { tmp2 = ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { tmp2 = linked_52.(*A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_51, arg_54, arg_55) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_check_env__init_A_const_71; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_73)); return A_arbace_go_check_env__init_A_const_71 }

func A_arbace_go_check_env__init_A_Unit41__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(230, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__57 any = A_arbace_go_check_env_def_type_BANG__A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_go_check_env_def_type_BANG__A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, nil); A_arbace_go_check_env_def_type_BANG__A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__57, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_75)); return A_arbace_go_check_env__init_A_const_74 }




func A_arbace_go_check_env__init_A_Unit42__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(235, 1); { var seq_1719000062__1 any; var root_58 any = A_arbace_go_check_env__init_A_const_76.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = A_arbace_go_check_env__init_A_const_77; if linked_59 == nil { seq_1719000062__1 = ifn_60.Invoke_O__O(arg_61) } else { seq_1719000062__1 = linked_59.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_58, arg_61) }; var chunk_1719000063__2 any; var count_1719000064__3 int64 = 0; var i_1719000065__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000065__4, count_1719000064__3) { var vec__1719000067__5 any = lang.Indexed_Cast(chunk_1719000063__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000065__4)); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000067__5, lang.RT_IntCast_J__I_NoInit(0), nil); var kw__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000067__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_78 any = A_arbace_go_check_env__init_A_const_74.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, A_arbace_go_check_env_def_type_BANG__A_fn_class); var ifn_80 lang.IFn




	if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = n__6; var arg_82 any = kw__7; if linked_79 == nil { ifn_80.Invoke_O_O__O(arg_81, arg_82) } else { linked_79.(*A_arbace_go_check_env_def_type_BANG__A).Invoke_O_O_O__O(root_78, arg_81, arg_82) }
//line :235:1
	seq_1719000062__1, chunk_1719000063__2, count_1719000064__3, i_1719000065__4 = seq_1719000062__1, chunk_1719000063__2, count_1719000064__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000065__4); continue L1



} else {
//line :235:1
	var temp__1927000414__auto____5 any; var root_62 any = A_arbace_go_check_env__init_A_const_76.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = seq_1719000062__1; if linked_63 == nil { temp__1927000414__auto____5 = ifn_64.Invoke_O__O(arg_65) } else { temp__1927000414__auto____5 = linked_63.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_62, arg_65) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1719000062__6 any = temp__1927000414__auto____5; var tmp1 any; var root_66 any = A_arbace_go_check_env__init_A_const_78.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = seq_1719000062__6; if linked_67 == nil { tmp1 = ifn_68.Invoke_O__O(arg_69) } else { tmp1 = linked_67.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_66, arg_69) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____7 any; var root_70 any = A_arbace_go_check_env__init_A_const_79.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = seq_1719000062__6; if linked_71 == nil { c__1927000678__auto____7 = ifn_72.Invoke_O__O(arg_73) } else { c__1927000678__auto____7 = linked_71.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_70, arg_73) }; var tmp2 any; var root_83 any = A_arbace_go_check_env__init_A_const_81.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = seq_1719000062__6; if linked_84 == nil { tmp2 = ifn_85.Invoke_O__O(arg_86) } else { tmp2 = linked_84.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_83, arg_86) }; seq_1719000062__1, chunk_1719000063__2, count_1719000064__3, i_1719000065__4 = tmp2, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1719000070__7 any; var root_74 any = A_arbace_go_check_env__init_A_const_80.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = seq_1719000062__6; if linked_75 == nil { vec__1719000070__7 = ifn_76.Invoke_O__O(arg_77) } else { vec__1719000070__7 = linked_75.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_74, arg_77) }; var n__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000070__7, lang.RT_IntCast_J__I_NoInit(0), nil); var kw__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000070__7, lang.RT_IntCast_J__I_NoInit(1), nil); var root_87 any = A_arbace_go_check_env__init_A_const_74.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, A_arbace_go_check_env_def_type_BANG__A_fn_class); var ifn_89 lang.IFn




		if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = n__8; var arg_91 any = kw__9; if linked_88 == nil { ifn_89.Invoke_O_O__O(arg_90, arg_91) } else { linked_88.(*A_arbace_go_check_env_def_type_BANG__A).Invoke_O_O_O__O(root_87, arg_90, arg_91) }
//line :235:1
		var tmp3 any; var root_92 any = A_arbace_go_check_env__init_A_const_82.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = seq_1719000062__6; if linked_93 == nil { tmp3 = ifn_94.Invoke_O__O(arg_95) } else { tmp3 = linked_93.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_92, arg_95) }; seq_1719000062__1, chunk_1719000063__2, count_1719000064__3, i_1719000065__4 = tmp3, nil, 0, 0; continue L1 } } else { return nil
		}
}
}
}
	panic("j2g: unreachable")
}
func A_arbace_go_check_env__init_A_Unit43__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(242, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__97 any = A_arbace_go_check_env_fn__1719000074_A_New(); var tmp3 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_go_check_env_fn__1719000074_A_fn_class; if
							fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, nil); A_arbace_go_check_env_fn__1719000074_A_fn_class = fncls__96d; tmp3 = fncls__96d } else { tmp3 = fncls__96 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__97, tmp3, nil); /*line :242:1*/tmp1.BindRoot_O__V(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_84)); return A_arbace_go_check_env__init_A_const_83 }





func A_arbace_go_check_env__init_A_Unit44__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(248, 1); var root_98 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_102 any = Lit_39; var arg_103 any; var root_104 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, A_arbace_go_check_env_obj_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_85; var tmp2 any = A_arbace_go_check_env__init_A_const_86; var tmp3 any = A_arbace_go_check_env__init_A_const_87; var tmp4 any = A_arbace_go_check_env__init_A_const_86; var arg_107 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_39, tmp4, A_arbace_go_check_env__init_A_const_83.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_72, jrt.Boolean_TRUE.Ref())); if linked_105 == nil { arg_103 = ifn_106.Invoke_O__O(arg_107) } else { arg_103 = linked_105.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_104, arg_107) }; if linked_99 == nil { return ifn_100.Invoke_O_O_O__O(arg_101, arg_102, arg_103) } else { return linked_99.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_98, arg_101, arg_102, arg_103) } }
func A_arbace_go_check_env__init_A_Unit45__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(249, 1); var root_108 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_112 any = Lit_40; var arg_113 any; var root_114 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, A_arbace_go_check_env_obj_A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_85; var tmp2 any = A_arbace_go_check_env__init_A_const_86; var tmp3 any = A_arbace_go_check_env__init_A_const_87; var tmp4 any = A_arbace_go_check_env__init_A_const_86; var arg_117 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_40, tmp4, lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_env__init_A_const_89, lang.PersistentVector_EMPTY.Ref(), nil), A_arbace_go_check_env__init_A_const_88, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_env__init_A_const_72, jrt.Boolean_TRUE.Ref())); if linked_115 == nil { arg_113 = ifn_116.Invoke_O__O(arg_117) } else { arg_113 = linked_115.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_114, arg_117) }; if linked_109 == nil { return ifn_110.Invoke_O_O_O__O(arg_111, arg_112, arg_113) } else { return linked_109.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_108, arg_111, arg_112, arg_113) } }

func A_arbace_go_check_env__init_A_Unit46__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(251, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_90; var tmp2 *lang.Compiler_AOTFn; var fnbody__119 any = A_arbace_go_check_env_fn__1719000080_A_New(); var tmp3 *jrt.Class; var fncls__118 *jrt.Class = A_arbace_go_check_env_fn__1719000080_A_fn_class; if
							fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, nil); A_arbace_go_check_env_fn__1719000080_A_fn_class = fncls__118d; tmp3 = fncls__118d } else { tmp3 = fncls__118 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__119, tmp3, nil); /*line :251:1*/tmp1.BindRoot_O__V(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_91)); return A_arbace_go_check_env__init_A_const_90 }




func A_arbace_go_check_env__init_A_Unit47__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); var root_120 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_124 any = Lit_42; var arg_125 any; var root_126 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, A_arbace_go_check_env_obj_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_85; var tmp2 any = A_arbace_go_check_env__init_A_const_86; var tmp3 any = A_arbace_go_check_env__init_A_const_87; var tmp4 any = A_arbace_go_check_env__init_A_const_86; var arg_129 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_42, tmp4, A_arbace_go_check_env__init_A_const_90.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_72, jrt.Boolean_TRUE.Ref())); if linked_127 == nil { arg_125 = ifn_128.Invoke_O__O(arg_129) } else { arg_125 = linked_127.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_126, arg_129) }; if linked_121 == nil { return ifn_122.Invoke_O_O_O__O(arg_123, arg_124, arg_125) } else { return linked_121.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_120, arg_123, arg_124, arg_125) } }

func A_arbace_go_check_env__init_A_Unit48__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(258, 1); var root_130 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_134 any = Lit_43; var arg_135 any; var root_136 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, A_arbace_go_check_env_obj_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = A_arbace_go_check_env__init_A_const_92; if linked_137 == nil { arg_135 = ifn_138.Invoke_O__O(arg_139) } else { arg_135 = linked_137.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_136, arg_139) }; if linked_131 == nil { return ifn_132.Invoke_O_O_O__O(arg_133, arg_134, arg_135) } else { return linked_131.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_130, arg_133, arg_134, arg_135) } }
func A_arbace_go_check_env__init_A_Unit49__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(259, 1); var root_140 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_144 any = Lit_44; var arg_145 any; var root_146 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, A_arbace_go_check_env_obj_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = A_arbace_go_check_env__init_A_const_93; if linked_147 == nil { arg_145 = ifn_148.Invoke_O__O(arg_149) } else { arg_145 = linked_147.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_146, arg_149) }; if linked_141 == nil { return ifn_142.Invoke_O_O_O__O(arg_143, arg_144, arg_145) } else { return linked_141.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_140, arg_143, arg_144, arg_145) } }
func A_arbace_go_check_env__init_A_Unit50__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(260, 1); var root_150 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_154 any = Lit_45; var arg_155 any; var root_156 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, A_arbace_go_check_env_obj_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = A_arbace_go_check_env__init_A_const_94; if linked_157 == nil { arg_155 = ifn_158.Invoke_O__O(arg_159) } else { arg_155 = linked_157.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_156, arg_159) }; if linked_151 == nil { return ifn_152.Invoke_O_O_O__O(arg_153, arg_154, arg_155) } else { return linked_151.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_150, arg_153, arg_154, arg_155) } }
func A_arbace_go_check_env__init_A_Unit51__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(261, 1); var root_160 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_164 any = Lit_46; var arg_165 any; var root_166 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, A_arbace_go_check_env_obj_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = A_arbace_go_check_env__init_A_const_95; if linked_167 == nil { arg_165 = ifn_168.Invoke_O__O(arg_169) } else { arg_165 = linked_167.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_166, arg_169) }; if linked_161 == nil { return ifn_162.Invoke_O_O_O__O(arg_163, arg_164, arg_165) } else { return linked_161.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_160, arg_163, arg_164, arg_165) } }

func A_arbace_go_check_env__init_A_Unit52__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(263, 1); A_arbace_go_check_env__init_A_const_96.BindRoot_O__V(A_arbace_go_check_env__init_A_const_97); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_96; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_98)); return A_arbace_go_check_env__init_A_const_96 }



func A_arbace_go_check_env__init_A_Unit53__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(267, 1); { var seq_1719000092__1 any; var root_170 any = A_arbace_go_check_env__init_A_const_76.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = A_arbace_go_check_env__init_A_const_96.GetRawRoot__O(); if linked_171 == nil { seq_1719000092__1 = ifn_172.Invoke_O__O(arg_173) } else { seq_1719000092__1 = linked_171.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_170, arg_173) }; var chunk_1719000093__2 any; var count_1719000094__3 int64 = 0; var i_1719000095__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000095__4, count_1719000094__3) { var n__5 any = lang.Indexed_Cast(chunk_1719000093__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000095__4)); var root_190 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_192 lang.IFn
	if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_194 any = n__5; var arg_195 any; var root_196 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, A_arbace_go_check_env_obj_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env__init_A_const_85, A_arbace_go_check_env__init_A_const_99, A_arbace_go_check_env__init_A_const_87, n__5, A_arbace_go_check_env__init_A_const_72, jrt.Boolean_TRUE.Ref())); if linked_197 == nil { arg_195 = ifn_198.Invoke_O__O(arg_199) } else { arg_195 = linked_197.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_196, arg_199) }; if linked_191 == nil { ifn_192.Invoke_O_O_O__O(arg_193, arg_194, arg_195) } else { linked_191.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_190, arg_193, arg_194, arg_195) }
//line :267:1
	seq_1719000092__1, chunk_1719000093__2, count_1719000094__3, i_1719000095__4 = seq_1719000092__1, chunk_1719000093__2, count_1719000094__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000095__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_174 any = A_arbace_go_check_env__init_A_const_76.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = seq_1719000092__1; if linked_175 == nil { temp__1927000414__auto____5 = ifn_176.Invoke_O__O(arg_177) } else { temp__1927000414__auto____5 = linked_175.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_174, arg_177) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1719000092__6 any = temp__1927000414__auto____5; var tmp1 any; var root_178 any = A_arbace_go_check_env__init_A_const_78.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = seq_1719000092__6; if linked_179 == nil { tmp1 = ifn_180.Invoke_O__O(arg_181) } else { tmp1 = linked_179.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_178, arg_181) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____7 any; var root_182 any = A_arbace_go_check_env__init_A_const_79.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = seq_1719000092__6; if linked_183 == nil { c__1927000678__auto____7 = ifn_184.Invoke_O__O(arg_185) } else { c__1927000678__auto____7 = linked_183.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_182, arg_185) }; var tmp2 any; var root_200 any = A_arbace_go_check_env__init_A_const_81.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = seq_1719000092__6; if linked_201 == nil { tmp2 = ifn_202.Invoke_O__O(arg_203) } else { tmp2 = linked_201.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_200, arg_203) }; seq_1719000092__1, chunk_1719000093__2, count_1719000094__3, i_1719000095__4 = tmp2, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__7 any; var root_186 any = A_arbace_go_check_env__init_A_const_80.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = seq_1719000092__6; if linked_187 == nil { n__7 = ifn_188.Invoke_O__O(arg_189) } else { n__7 = linked_187.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_186, arg_189) }
		var root_204 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var arg_208 any = n__7; var arg_209 any; var root_210 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, A_arbace_go_check_env_obj_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env__init_A_const_85, A_arbace_go_check_env__init_A_const_99, A_arbace_go_check_env__init_A_const_87, n__7, A_arbace_go_check_env__init_A_const_72, jrt.Boolean_TRUE.Ref())); if linked_211 == nil { arg_209 = ifn_212.Invoke_O__O(arg_213) } else { arg_209 = linked_211.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_210, arg_213) }; if linked_205 == nil { ifn_206.Invoke_O_O_O__O(arg_207, arg_208, arg_209) } else { linked_205.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_204, arg_207, arg_208, arg_209) }
//line :267:1
		var tmp3 any; var root_214 any = A_arbace_go_check_env__init_A_const_82.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = seq_1719000092__6; if linked_215 == nil { tmp3 = ifn_216.Invoke_O__O(arg_217) } else { tmp3 = linked_215.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_214, arg_217) }; seq_1719000092__1, chunk_1719000093__2, count_1719000094__3, i_1719000095__4 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } }
	panic("j2g: unreachable")
}


func A_arbace_go_check_env__init_A_Unit54__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(272, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_100; var tmp2 *lang.Compiler_AOTFn; var fnbody__219 any = A_arbace_go_check_env_fn__1719000098_A_New(); var tmp3 *jrt.Class; var fncls__218 *jrt.Class = A_arbace_go_check_env_fn__1719000098_A_fn_class; if
							fncls__218 == nil { var fncls__218d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, nil); A_arbace_go_check_env_fn__1719000098_A_fn_class = fncls__218d; tmp3 = fncls__218d } else { tmp3 = fncls__218 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__219, tmp3, nil); /*line :272:1*/tmp1.BindRoot_O__V(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_101)); return A_arbace_go_check_env__init_A_const_100 }






func A_arbace_go_check_env__init_A_Unit55__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(279, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_102; var tmp2 any; var root_220 any = A_arbace_go_check_env__init_A_const_103.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var tmp3 any = A_arbace_go_check_env__init_A_const_104; var tmp4 any = A_arbace_go_check_env__init_A_const_87; var tmp5 any = A_arbace_go_check_env__init_A_const_105; var arg_223 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, Lit_10, tmp4, Lit_10, tmp5, A_arbace_go_check_env__init_A_const_100.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_106, jrt.Boolean_TRUE.Ref())); if linked_221 == nil { tmp2 = ifn_222.Invoke_O__O(arg_223) } else { tmp2 = linked_221.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_220, arg_223) }; tmp1.BindRoot_O__V(tmp2); var tmp6 *lang.Var = A_arbace_go_check_env__init_A_const_102; tmp6.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_107)); return A_arbace_go_check_env__init_A_const_102 }



type A_arbace_go_check_env__init_A struct{ jrt.Object }

var A_arbace_go_check_env__init_A_const_pool *jrt.RefArray

var A_arbace_go_check_env__init_A_const_0 *lang.Var

var A_arbace_go_check_env__init_A_const_1 any

var A_arbace_go_check_env__init_A_const_2 any

var A_arbace_go_check_env__init_A_const_3 any

var A_arbace_go_check_env__init_A_const_4 *lang.Var

var A_arbace_go_check_env__init_A_const_5 any

var A_arbace_go_check_env__init_A_const_6 *lang.Var

var A_arbace_go_check_env__init_A_const_7 any

var A_arbace_go_check_env__init_A_const_8 *lang.Var

var A_arbace_go_check_env__init_A_const_9 any

var A_arbace_go_check_env__init_A_const_10 *lang.Var

var A_arbace_go_check_env__init_A_const_11 any

var A_arbace_go_check_env__init_A_const_12 *lang.Var

var A_arbace_go_check_env__init_A_const_13 any

var A_arbace_go_check_env__init_A_const_14 *lang.Var

var A_arbace_go_check_env__init_A_const_15 any

var A_arbace_go_check_env__init_A_const_16 *lang.Var

var A_arbace_go_check_env__init_A_const_17 any

var A_arbace_go_check_env__init_A_const_18 *lang.Var

var A_arbace_go_check_env__init_A_const_19 any

var A_arbace_go_check_env__init_A_const_20 *lang.Var

var A_arbace_go_check_env__init_A_const_21 any

var A_arbace_go_check_env__init_A_const_22 *lang.Var

var A_arbace_go_check_env__init_A_const_23 any

var A_arbace_go_check_env__init_A_const_24 *lang.Var

var A_arbace_go_check_env__init_A_const_25 any

var A_arbace_go_check_env__init_A_const_26 *lang.Var

var A_arbace_go_check_env__init_A_const_27 any

var A_arbace_go_check_env__init_A_const_28 *lang.Var

var A_arbace_go_check_env__init_A_const_29 any

var A_arbace_go_check_env__init_A_const_30 *lang.Var

var A_arbace_go_check_env__init_A_const_31 any

var A_arbace_go_check_env__init_A_const_32 *lang.Var

var A_arbace_go_check_env__init_A_const_33 any

var A_arbace_go_check_env__init_A_const_34 *lang.Var

var A_arbace_go_check_env__init_A_const_35 any

var A_arbace_go_check_env__init_A_const_36 *lang.Var

var A_arbace_go_check_env__init_A_const_37 any

var A_arbace_go_check_env__init_A_const_38 *lang.Var

var A_arbace_go_check_env__init_A_const_39 any

var A_arbace_go_check_env__init_A_const_40 *lang.Var

var A_arbace_go_check_env__init_A_const_41 any

var A_arbace_go_check_env__init_A_const_42 any

var A_arbace_go_check_env__init_A_const_43 *lang.Var

var A_arbace_go_check_env__init_A_const_44 any

var A_arbace_go_check_env__init_A_const_45 *lang.Var

var A_arbace_go_check_env__init_A_const_46 any

var A_arbace_go_check_env__init_A_const_47 *lang.Var

var A_arbace_go_check_env__init_A_const_48 any

var A_arbace_go_check_env__init_A_const_49 *lang.Var

var A_arbace_go_check_env__init_A_const_50 any

var A_arbace_go_check_env__init_A_const_51 *lang.Var

var A_arbace_go_check_env__init_A_const_52 any

var A_arbace_go_check_env__init_A_const_53 *lang.Var

var A_arbace_go_check_env__init_A_const_54 any

var A_arbace_go_check_env__init_A_const_55 *lang.Var

var A_arbace_go_check_env__init_A_const_56 any

var A_arbace_go_check_env__init_A_const_57 *lang.Var

var A_arbace_go_check_env__init_A_const_58 any

var A_arbace_go_check_env__init_A_const_59 *lang.Var

var A_arbace_go_check_env__init_A_const_60 any

var A_arbace_go_check_env__init_A_const_61 *lang.Var

var A_arbace_go_check_env__init_A_const_62 any

var A_arbace_go_check_env__init_A_const_63 *lang.Var

var A_arbace_go_check_env__init_A_const_64 any

var A_arbace_go_check_env__init_A_const_65 *lang.Var

var A_arbace_go_check_env__init_A_const_66 any

var A_arbace_go_check_env__init_A_const_67 *lang.Var

var A_arbace_go_check_env__init_A_const_68 any

var A_arbace_go_check_env__init_A_const_69 *lang.Var

var A_arbace_go_check_env__init_A_const_70 any

var A_arbace_go_check_env__init_A_const_71 *lang.Var

var A_arbace_go_check_env__init_A_const_72 *lang.Keyword

var A_arbace_go_check_env__init_A_const_73 any

var A_arbace_go_check_env__init_A_const_74 *lang.Var

var A_arbace_go_check_env__init_A_const_75 any

var A_arbace_go_check_env__init_A_const_76 *lang.Var

var A_arbace_go_check_env__init_A_const_77 any

var A_arbace_go_check_env__init_A_const_78 *lang.Var

var A_arbace_go_check_env__init_A_const_79 *lang.Var

var A_arbace_go_check_env__init_A_const_80 *lang.Var

var A_arbace_go_check_env__init_A_const_81 *lang.Var

var A_arbace_go_check_env__init_A_const_82 *lang.Var

var A_arbace_go_check_env__init_A_const_83 *lang.Var

var A_arbace_go_check_env__init_A_const_84 any

var A_arbace_go_check_env__init_A_const_85 *lang.Keyword

var A_arbace_go_check_env__init_A_const_86 *lang.Keyword

var A_arbace_go_check_env__init_A_const_87 *lang.Keyword

var A_arbace_go_check_env__init_A_const_88 *lang.Keyword

var A_arbace_go_check_env__init_A_const_89 *lang.Keyword

var A_arbace_go_check_env__init_A_const_90 *lang.Var

var A_arbace_go_check_env__init_A_const_91 any

var A_arbace_go_check_env__init_A_const_92 any

var A_arbace_go_check_env__init_A_const_93 any

var A_arbace_go_check_env__init_A_const_94 any

var A_arbace_go_check_env__init_A_const_95 any

var A_arbace_go_check_env__init_A_const_96 *lang.Var

var A_arbace_go_check_env__init_A_const_97 any

var A_arbace_go_check_env__init_A_const_98 any

var A_arbace_go_check_env__init_A_const_99 *lang.Keyword

var A_arbace_go_check_env__init_A_const_100 *lang.Var

var A_arbace_go_check_env__init_A_const_101 any

var A_arbace_go_check_env__init_A_const_102 *lang.Var

var A_arbace_go_check_env__init_A_const_103 *lang.Var

var A_arbace_go_check_env__init_A_const_104 *lang.Keyword

var A_arbace_go_check_env__init_A_const_105 *lang.Keyword

var A_arbace_go_check_env__init_A_const_106 *lang.Keyword

var A_arbace_go_check_env__init_A_const_107 any

var A_arbace_go_check_env__init_A_init jrt.ClassInit

func A_arbace_go_check_env__init_A_Init() { if !A_arbace_go_check_env__init_A_init.Done() { A_arbace_go_check_env__init_A_init.Run(A_arbace_go_check_env__init_A_clinit) } }

func A_arbace_go_check_env__init_A_clinit() { A_arbace_go_check_env__init_A_clinit_p0(); A_arbace_go_check_env__init_A_clinit_p1(); A_arbace_go_check_env__init_A_clinit_p2(); A_arbace_go_check_env__init_A_clinit_p3(); A_arbace_go_check_env__init_A_clinit_p4(); A_arbace_go_check_env__init_A_clinit_p5(); A_arbace_go_check_env__init_A_clinit_p6(); A_arbace_go_check_env__init_A_clinit_p7(); A_arbace_go_check_env__init_A_clinit_p8() }

func A_arbace_go_check_env__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_env__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_11, 182); A_arbace_go_check_env__init_A_const_0 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[74]); A_arbace_go_check_env__init_A_const_1 = A_arbace_go_check_env__init_A_const_pool.A[75]; A_arbace_go_check_env__init_A_const_2 = A_arbace_go_check_env__init_A_const_pool.A[76]; A_arbace_go_check_env__init_A_const_3 = A_arbace_go_check_env__init_A_const_pool.A[77]; A_arbace_go_check_env__init_A_const_4 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[78]); A_arbace_go_check_env__init_A_const_5 = A_arbace_go_check_env__init_A_const_pool.A[79]; A_arbace_go_check_env__init_A_const_6 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[80]); A_arbace_go_check_env__init_A_const_7 = A_arbace_go_check_env__init_A_const_pool.A[81]; A_arbace_go_check_env__init_A_const_8 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[82]); A_arbace_go_check_env__init_A_const_9 = A_arbace_go_check_env__init_A_const_pool.A[83]; A_arbace_go_check_env__init_A_const_10 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[84]); A_arbace_go_check_env__init_A_const_11 = A_arbace_go_check_env__init_A_const_pool.A[85]; A_arbace_go_check_env__init_A_const_12 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[86]) }

func A_arbace_go_check_env__init_A_clinit_p1() { A_arbace_go_check_env__init_A_const_13 = A_arbace_go_check_env__init_A_const_pool.A[87]; A_arbace_go_check_env__init_A_const_14 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[88]); A_arbace_go_check_env__init_A_const_15 = A_arbace_go_check_env__init_A_const_pool.A[89]; A_arbace_go_check_env__init_A_const_16 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[90]); A_arbace_go_check_env__init_A_const_17 = A_arbace_go_check_env__init_A_const_pool.A[91]; A_arbace_go_check_env__init_A_const_18 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[92]); A_arbace_go_check_env__init_A_const_19 = A_arbace_go_check_env__init_A_const_pool.A[93]; A_arbace_go_check_env__init_A_const_20 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[94]); A_arbace_go_check_env__init_A_const_21 = A_arbace_go_check_env__init_A_const_pool.A[95]; A_arbace_go_check_env__init_A_const_22 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[96]); A_arbace_go_check_env__init_A_const_23 = A_arbace_go_check_env__init_A_const_pool.A[97]; A_arbace_go_check_env__init_A_const_24 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[98]); A_arbace_go_check_env__init_A_const_25 = A_arbace_go_check_env__init_A_const_pool.A[99] }

func A_arbace_go_check_env__init_A_clinit_p2() { A_arbace_go_check_env__init_A_const_26 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[100]); A_arbace_go_check_env__init_A_const_27 = A_arbace_go_check_env__init_A_const_pool.A[101]; A_arbace_go_check_env__init_A_const_28 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[102]); A_arbace_go_check_env__init_A_const_29 = A_arbace_go_check_env__init_A_const_pool.A[103]; A_arbace_go_check_env__init_A_const_30 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[104]); A_arbace_go_check_env__init_A_const_31 = A_arbace_go_check_env__init_A_const_pool.A[105]; A_arbace_go_check_env__init_A_const_32 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[106]); A_arbace_go_check_env__init_A_const_33 = A_arbace_go_check_env__init_A_const_pool.A[107]; A_arbace_go_check_env__init_A_const_34 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[108]); A_arbace_go_check_env__init_A_const_35 = A_arbace_go_check_env__init_A_const_pool.A[109]; A_arbace_go_check_env__init_A_const_36 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[110]); A_arbace_go_check_env__init_A_const_37 = A_arbace_go_check_env__init_A_const_pool.A[111]; A_arbace_go_check_env__init_A_const_38 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[112]) }

func A_arbace_go_check_env__init_A_clinit_p3() { A_arbace_go_check_env__init_A_const_39 = A_arbace_go_check_env__init_A_const_pool.A[113]; A_arbace_go_check_env__init_A_const_40 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[114]); A_arbace_go_check_env__init_A_const_41 = A_arbace_go_check_env__init_A_const_pool.A[115]; A_arbace_go_check_env__init_A_const_42 = A_arbace_go_check_env__init_A_const_pool.A[116]; A_arbace_go_check_env__init_A_const_43 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[117]); A_arbace_go_check_env__init_A_const_44 = A_arbace_go_check_env__init_A_const_pool.A[118]; A_arbace_go_check_env__init_A_const_45 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[119]); A_arbace_go_check_env__init_A_const_46 = A_arbace_go_check_env__init_A_const_pool.A[120]; A_arbace_go_check_env__init_A_const_47 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[121]); A_arbace_go_check_env__init_A_const_48 = A_arbace_go_check_env__init_A_const_pool.A[122]; A_arbace_go_check_env__init_A_const_49 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[123]); A_arbace_go_check_env__init_A_const_50 = A_arbace_go_check_env__init_A_const_pool.A[124]; A_arbace_go_check_env__init_A_const_51 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[125]); A_arbace_go_check_env__init_A_const_52 = A_arbace_go_check_env__init_A_const_pool.A[126] }

func A_arbace_go_check_env__init_A_clinit_p4() { A_arbace_go_check_env__init_A_const_53 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[127]); A_arbace_go_check_env__init_A_const_54 = A_arbace_go_check_env__init_A_const_pool.A[128]; A_arbace_go_check_env__init_A_const_55 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[129]); A_arbace_go_check_env__init_A_const_56 = A_arbace_go_check_env__init_A_const_pool.A[130]; A_arbace_go_check_env__init_A_const_57 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[131]); A_arbace_go_check_env__init_A_const_58 = A_arbace_go_check_env__init_A_const_pool.A[132]; A_arbace_go_check_env__init_A_const_59 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[133]); A_arbace_go_check_env__init_A_const_60 = A_arbace_go_check_env__init_A_const_pool.A[134]; A_arbace_go_check_env__init_A_const_61 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[135]); A_arbace_go_check_env__init_A_const_62 = A_arbace_go_check_env__init_A_const_pool.A[136]; A_arbace_go_check_env__init_A_const_63 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[137]); A_arbace_go_check_env__init_A_const_64 = A_arbace_go_check_env__init_A_const_pool.A[138]; A_arbace_go_check_env__init_A_const_65 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[139]) }

func A_arbace_go_check_env__init_A_clinit_p5() { A_arbace_go_check_env__init_A_const_66 = A_arbace_go_check_env__init_A_const_pool.A[140]; A_arbace_go_check_env__init_A_const_67 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[141]); A_arbace_go_check_env__init_A_const_68 = A_arbace_go_check_env__init_A_const_pool.A[142]; A_arbace_go_check_env__init_A_const_69 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[143]); A_arbace_go_check_env__init_A_const_70 = A_arbace_go_check_env__init_A_const_pool.A[144]; A_arbace_go_check_env__init_A_const_71 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[145]); A_arbace_go_check_env__init_A_const_72 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[146]); A_arbace_go_check_env__init_A_const_73 = A_arbace_go_check_env__init_A_const_pool.A[147]; A_arbace_go_check_env__init_A_const_74 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[148]); A_arbace_go_check_env__init_A_const_75 = A_arbace_go_check_env__init_A_const_pool.A[149]; A_arbace_go_check_env__init_A_const_76 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[150]); A_arbace_go_check_env__init_A_const_77 = A_arbace_go_check_env__init_A_const_pool.A[151]; A_arbace_go_check_env__init_A_const_78 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[152]) }

func A_arbace_go_check_env__init_A_clinit_p6() { A_arbace_go_check_env__init_A_const_79 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[153]); A_arbace_go_check_env__init_A_const_80 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[154]); A_arbace_go_check_env__init_A_const_81 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[155]); A_arbace_go_check_env__init_A_const_82 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[156]); A_arbace_go_check_env__init_A_const_83 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[157]); A_arbace_go_check_env__init_A_const_84 = A_arbace_go_check_env__init_A_const_pool.A[158]; A_arbace_go_check_env__init_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[159]); A_arbace_go_check_env__init_A_const_86 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[160]); A_arbace_go_check_env__init_A_const_87 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[161]); A_arbace_go_check_env__init_A_const_88 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[162]); A_arbace_go_check_env__init_A_const_89 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[163]); A_arbace_go_check_env__init_A_const_90 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[164]) }

func A_arbace_go_check_env__init_A_clinit_p7() { A_arbace_go_check_env__init_A_const_91 = A_arbace_go_check_env__init_A_const_pool.A[165]; A_arbace_go_check_env__init_A_const_92 = A_arbace_go_check_env__init_A_const_pool.A[166]; A_arbace_go_check_env__init_A_const_93 = A_arbace_go_check_env__init_A_const_pool.A[167]; A_arbace_go_check_env__init_A_const_94 = A_arbace_go_check_env__init_A_const_pool.A[168]; A_arbace_go_check_env__init_A_const_95 = A_arbace_go_check_env__init_A_const_pool.A[169]; A_arbace_go_check_env__init_A_const_96 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[170]); A_arbace_go_check_env__init_A_const_97 = A_arbace_go_check_env__init_A_const_pool.A[171]; A_arbace_go_check_env__init_A_const_98 = A_arbace_go_check_env__init_A_const_pool.A[172]; A_arbace_go_check_env__init_A_const_99 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[173]); A_arbace_go_check_env__init_A_const_100 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[174]); A_arbace_go_check_env__init_A_const_101 = A_arbace_go_check_env__init_A_const_pool.A[175]; A_arbace_go_check_env__init_A_const_102 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[176]); A_arbace_go_check_env__init_A_const_103 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[177]); A_arbace_go_check_env__init_A_const_104 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[178]) }

func A_arbace_go_check_env__init_A_clinit_p8() { A_arbace_go_check_env__init_A_const_105 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[179]); A_arbace_go_check_env__init_A_const_106 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[180]); A_arbace_go_check_env__init_A_const_107 = A_arbace_go_check_env__init_A_const_pool.A[181] }

func A_arbace_go_check_env__init_A_New() *A_arbace_go_check_env__init_A { A_arbace_go_check_env__init_A_Init(); t := &A_arbace_go_check_env__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env__init_A) Ctor() {}

func (t *A_arbace_go_check_env__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env__init_A_class }

func (t *A_arbace_go_check_env__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env__init_A); return ok }

func A_arbace_go_check_env__init_A_Cast(x any) *A_arbace_go_check_env__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env__init_A_class)) }; return v }
