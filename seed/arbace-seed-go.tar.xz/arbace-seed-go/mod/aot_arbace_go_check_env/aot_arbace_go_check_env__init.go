//line aot_arbace_go_check_env__init.ae:1
package aot_arbace_go_check_env

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_env__init_A_Unit0__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_check_env__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env__init_A_const_1) }
//line :1:1
func A_arbace_go_check_env__init_A_Unit1__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_check_env__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_2)) }
//line :1:1
func A_arbace_go_check_env__init_A_Unit2__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_go_check_env__init_A_Unit3__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_check_env__init_A_const_1)).Equals_O__Z(A_arbace_go_check_env__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_go_check_env_eval1719000008_fn__1719000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_go_check_env__init_A_Load__O() any { A_arbace_go_check_env__init_A_Init(); jrt.StartCheck(); A_arbace_go_check_env__init_A_Unit0__O(); A_arbace_go_check_env__init_A_Unit1__O(); A_arbace_go_check_env__init_A_Unit2__O(); A_arbace_go_check_env__init_A_Unit3__O(); A_arbace_go_check_env__init_A_Unit4__O(); A_arbace_go_check_env__init_A_Unit5__O(); A_arbace_go_check_env__init_A_Unit6__O(); A_arbace_go_check_env__init_A_Unit7__O(); A_arbace_go_check_env__init_A_Unit8__O(); A_arbace_go_check_env__init_A_Unit9__O(); A_arbace_go_check_env__init_A_Unit10__O(); A_arbace_go_check_env__init_A_Unit11__O(); A_arbace_go_check_env__init_A_Unit12__O(); A_arbace_go_check_env__init_A_Unit13__O(); A_arbace_go_check_env__init_A_Unit14__O(); A_arbace_go_check_env__init_A_Unit15__O(); A_arbace_go_check_env__init_A_Unit16__O(); A_arbace_go_check_env__init_A_Unit17__O(); A_arbace_go_check_env__init_A_Unit18__O(); A_arbace_go_check_env__init_A_Unit19__O(); A_arbace_go_check_env__init_A_Unit20__O(); A_arbace_go_check_env__init_A_Unit21__O(); A_arbace_go_check_env__init_A_Unit22__O(); A_arbace_go_check_env__init_A_Unit23__O(); A_arbace_go_check_env__init_A_Unit24__O(); A_arbace_go_check_env__init_A_Unit25__O(); A_arbace_go_check_env__init_A_Unit26__O(); A_arbace_go_check_env__init_A_Unit27__O(); A_arbace_go_check_env__init_A_Unit28__O(); A_arbace_go_check_env__init_A_Unit29__O(); A_arbace_go_check_env__init_A_Unit30__O(); A_arbace_go_check_env__init_A_Unit31__O(); A_arbace_go_check_env__init_A_Unit32__O(); A_arbace_go_check_env__init_A_Unit33__O(); A_arbace_go_check_env__init_A_Unit34__O(); A_arbace_go_check_env__init_A_Unit35__O(); A_arbace_go_check_env__init_A_Unit36__O(); A_arbace_go_check_env__init_A_Unit37__O(); A_arbace_go_check_env__init_A_Unit38__O(); A_arbace_go_check_env__init_A_Unit39__O(); A_arbace_go_check_env__init_A_Unit40__O(); A_arbace_go_check_env__init_A_Unit41__O(); A_arbace_go_check_env__init_A_Unit42__O(); A_arbace_go_check_env__init_A_Unit43__O(); A_arbace_go_check_env__init_A_Unit44__O(); A_arbace_go_check_env__init_A_Unit45__O(); A_arbace_go_check_env__init_A_Unit46__O(); A_arbace_go_check_env__init_A_Unit47__O(); A_arbace_go_check_env__init_A_Unit48__O(); A_arbace_go_check_env__init_A_Unit49__O(); A_arbace_go_check_env__init_A_Unit50__O(); A_arbace_go_check_env__init_A_Unit51__O(); return nil }









func A_arbace_go_check_env__init_A_Unit4__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_4; var tmp2 any = A_arbace_go_check_env_obj_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_env_obj_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_go_check_env_obj_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_5)); return A_arbace_go_check_env__init_A_const_4 }
func A_arbace_go_check_env__init_A_Unit5__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_6; var tmp2 any = A_arbace_go_check_env_o_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_go_check_env_o_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_go_check_env_o_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_7)); return A_arbace_go_check_env__init_A_const_6 }
func A_arbace_go_check_env__init_A_Unit6__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_8; var tmp2 any = A_arbace_go_check_env_oset_BANG__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_env_oset_BANG__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_go_check_env_oset_BANG__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_9)); return A_arbace_go_check_env__init_A_const_8 }
func A_arbace_go_check_env__init_A_Unit7__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_10; var tmp2 any = A_arbace_go_check_env_obj_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_go_check_env_obj_QMARK__A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_go_check_env_obj_QMARK__A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_11)); return A_arbace_go_check_env__init_A_const_10 }



func A_arbace_go_check_env__init_A_Unit8__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_12; var tmp2 any = A_arbace_go_check_env_scope_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_env_scope_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_go_check_env_scope_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_13)); return A_arbace_go_check_env__init_A_const_12 }

func A_arbace_go_check_env__init_A_Unit9__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_14; var tmp2 any = A_arbace_go_check_env_scope_lookup_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_go_check_env_scope_lookup_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_go_check_env_scope_lookup_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_15)); return A_arbace_go_check_env__init_A_const_14 }








func A_arbace_go_check_env__init_A_Unit10__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_16; var tmp2 any = A_arbace_go_check_env_scope_get_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_env_scope_get_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_go_check_env_scope_get_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_17)); return A_arbace_go_check_env__init_A_const_16 }
func A_arbace_go_check_env__init_A_Unit11__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_18; var tmp2 any = A_arbace_go_check_env_scope_put_BANG__A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_go_check_env_scope_put_BANG__A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_go_check_env_scope_put_BANG__A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_19)); return A_arbace_go_check_env__init_A_const_18 }



func A_arbace_go_check_env__init_A_Unit12__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); A_arbace_go_check_env__init_A_const_20.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_21)); return A_arbace_go_check_env__init_A_const_20.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit13__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); A_arbace_go_check_env__init_A_const_22.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_23)); return A_arbace_go_check_env__init_A_const_22.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit14__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); A_arbace_go_check_env__init_A_const_24.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_24; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_25)); return A_arbace_go_check_env__init_A_const_24.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit15__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); A_arbace_go_check_env__init_A_const_26.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_27)); return A_arbace_go_check_env__init_A_const_26.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check_env__init_A_Unit16__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); A_arbace_go_check_env__init_A_const_28.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_29)); return A_arbace_go_check_env__init_A_const_28.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check_env__init_A_Unit17__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); A_arbace_go_check_env__init_A_const_30.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_31)); return A_arbace_go_check_env__init_A_const_30.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check_env__init_A_Unit18__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_32; var tmp2 any = A_arbace_go_check_env_error_BANG__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_env_error_BANG__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_go_check_env_error_BANG__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_33)); return A_arbace_go_check_env__init_A_const_32 }















func A_arbace_go_check_env__init_A_Unit19__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(80, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_34; var tmp2 any = A_arbace_go_check_env_line_of_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_go_check_env_line_of_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_go_check_env_line_of_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_35)); return A_arbace_go_check_env__init_A_const_34 }





func A_arbace_go_check_env__init_A_Unit20__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(86, 1); A_arbace_go_check_env__init_A_const_36.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_36; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_37)); return A_arbace_go_check_env__init_A_const_36.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check_env__init_A_Unit21__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(88, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_39)); return A_arbace_go_check_env__init_A_const_38 }

func A_arbace_go_check_env__init_A_Unit22__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(90, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_40; var tmp2 any = A_arbace_go_check_env_end_line_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_env_end_line_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_go_check_env_end_line_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_41)); return A_arbace_go_check_env__init_A_const_40 }










func A_arbace_go_check_env__init_A_Unit23__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_38; var tmp2 any = A_arbace_go_check_env_child_line_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_go_check_env_child_line_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_go_check_env_child_line_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_42)); return A_arbace_go_check_env__init_A_const_38 }



















func A_arbace_go_check_env__init_A_Unit24__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(121, 1); A_arbace_go_check_env__init_A_const_43.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_44)); return A_arbace_go_check_env__init_A_const_43.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_env__init_A_Unit25__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_45; var tmp2 any = A_arbace_go_check_env_with_child_line_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_env_with_child_line_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, true); A_arbace_go_check_env_with_child_line_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_46)); return A_arbace_go_check_env__init_A_const_45 }
//line :126:1
func A_arbace_go_check_env__init_A_Unit26__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); A_arbace_go_check_env__init_A_const_45.SetMacro__V(); return nil }
//line :126:1
func A_arbace_go_check_env__init_A_Unit27__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); return A_arbace_go_check_env__init_A_const_45 }







func A_arbace_go_check_env__init_A_Unit28__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(134, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_47; var tmp2 any = A_arbace_go_check_env_current_line_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_go_check_env_current_line_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_go_check_env_current_line_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_48)); return A_arbace_go_check_env__init_A_const_47 }




func A_arbace_go_check_env__init_A_Unit29__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_49; var tmp2 any = A_arbace_go_check_env_err_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_check_env_err_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, true); A_arbace_go_check_env_err_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_50)); return A_arbace_go_check_env__init_A_const_49 }






func A_arbace_go_check_env__init_A_Unit30__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(146, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_51; var tmp2 any = A_arbace_go_check_env_generic_BANG__A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_go_check_env_generic_BANG__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_go_check_env_generic_BANG__A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_52)); return A_arbace_go_check_env__init_A_const_51 }





func A_arbace_go_check_env__init_A_Unit31__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(152, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_53; var tmp2 any = A_arbace_go_check_env_unsupported_BANG__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_check_env_unsupported_BANG__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_go_check_env_unsupported_BANG__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_54)); return A_arbace_go_check_env__init_A_const_53 }









func A_arbace_go_check_env__init_A_Unit32__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(162, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_55; var tmp2 any = A_arbace_go_check_env_unsupported_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_go_check_env_unsupported_QMARK__A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_go_check_env_unsupported_QMARK__A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_56)); return A_arbace_go_check_env__init_A_const_55 }



func A_arbace_go_check_env__init_A_Unit33__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(166, 1); A_arbace_go_check_env__init_A_const_57.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_57; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_58)); return A_arbace_go_check_env__init_A_const_57.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_env__init_A_Unit34__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(171, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_59; var tmp2 any = A_arbace_go_check_env_verified_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_check_env_verified_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_go_check_env_verified_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_60)); return A_arbace_go_check_env__init_A_const_59 }












func A_arbace_go_check_env__init_A_Unit35__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(184, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_61; var tmp2 any = A_arbace_go_check_env_annotation_error_BANG__A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_go_check_env_annotation_error_BANG__A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_check_env_annotation_error_BANG__A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_62)); return A_arbace_go_check_env__init_A_const_61 }







func A_arbace_go_check_env__init_A_Unit36__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(192, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_63; var tmp2 any; var root_23 any = A_arbace_go_check_env__init_A_const_12.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, A_arbace_go_check_env_scope_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any; var arg_27 any = A_arbace_go_check_env__init_A_const_64; if linked_24 == nil { tmp2 = ifn_25.Invoke_O_O__O(arg_26, arg_27) } else { tmp2 = linked_24.(*A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_23, arg_26, arg_27) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_check_env__init_A_const_63; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_65)); return A_arbace_go_check_env__init_A_const_63 }

func A_arbace_go_check_env__init_A_Unit37__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(194, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_66; var tmp2 any = A_arbace_go_check_env_def_type_BANG__A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_go_check_env_def_type_BANG__A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_check_env_def_type_BANG__A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_67)); return A_arbace_go_check_env__init_A_const_66 }

func A_arbace_go_check_env__init_A_Unit38__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(196, 1); { var seq_1719000055__1 any; var root_29 any = A_arbace_go_check_env__init_A_const_68.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = A_arbace_go_check_env__init_A_const_69; if linked_30 == nil { seq_1719000055__1 = ifn_31.Invoke_O__O(arg_32) } else { seq_1719000055__1 = linked_30.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_29, arg_32) }; var chunk_1719000056__2 any; var count_1719000057__3 int64 = 0; var i_1719000058__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000058__4, count_1719000057__3) { var vec__1719000060__5 any = lang.Indexed_Cast(chunk_1719000056__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000058__4)); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000060__5, lang.RT_IntCast_J__I_NoInit(0), nil); var kw__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000060__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_49 any = A_arbace_go_check_env__init_A_const_66.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, A_arbace_go_check_env_def_type_BANG__A_fn_class); var ifn_51 lang.IFn




	if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = n__6; var arg_53 any = kw__7; if linked_50 == nil { ifn_51.Invoke_O_O__O(arg_52, arg_53) } else { linked_50.(*A_arbace_go_check_env_def_type_BANG__A).Invoke_O_O_O__O(root_49, arg_52, arg_53) }
//line :196:1
	seq_1719000055__1, chunk_1719000056__2, count_1719000057__3, i_1719000058__4 = seq_1719000055__1, chunk_1719000056__2, count_1719000057__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000058__4); continue L1



} else {
//line :196:1
	var temp__1927000414__auto____5 any; var root_33 any = A_arbace_go_check_env__init_A_const_68.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = seq_1719000055__1; if linked_34 == nil { temp__1927000414__auto____5 = ifn_35.Invoke_O__O(arg_36) } else { temp__1927000414__auto____5 = linked_34.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_33, arg_36) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1719000055__6 any = temp__1927000414__auto____5; var tmp1 any; var root_37 any = A_arbace_go_check_env__init_A_const_70.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = seq_1719000055__6; if linked_38 == nil { tmp1 = ifn_39.Invoke_O__O(arg_40) } else { tmp1 = linked_38.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_37, arg_40) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____7 any; var root_41 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = seq_1719000055__6; if linked_42 == nil { c__1927000678__auto____7 = ifn_43.Invoke_O__O(arg_44) } else { c__1927000678__auto____7 = linked_42.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_41, arg_44) }; var tmp2 any; var root_54 any = A_arbace_go_check_env__init_A_const_73.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = seq_1719000055__6; if linked_55 == nil { tmp2 = ifn_56.Invoke_O__O(arg_57) } else { tmp2 = linked_55.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_54, arg_57) }; seq_1719000055__1, chunk_1719000056__2, count_1719000057__3, i_1719000058__4 = tmp2, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1719000063__7 any; var root_45 any = A_arbace_go_check_env__init_A_const_72.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = seq_1719000055__6; if linked_46 == nil { vec__1719000063__7 = ifn_47.Invoke_O__O(arg_48) } else { vec__1719000063__7 = linked_46.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_45, arg_48) }; var n__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000063__7, lang.RT_IntCast_J__I_NoInit(0), nil); var kw__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000063__7, lang.RT_IntCast_J__I_NoInit(1), nil); var root_58 any = A_arbace_go_check_env__init_A_const_66.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, A_arbace_go_check_env_def_type_BANG__A_fn_class); var ifn_60 lang.IFn




		if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = n__8; var arg_62 any = kw__9; if linked_59 == nil { ifn_60.Invoke_O_O__O(arg_61, arg_62) } else { linked_59.(*A_arbace_go_check_env_def_type_BANG__A).Invoke_O_O_O__O(root_58, arg_61, arg_62) }
//line :196:1
		var tmp3 any; var root_63 any = A_arbace_go_check_env__init_A_const_74.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = seq_1719000055__6; if linked_64 == nil { tmp3 = ifn_65.Invoke_O__O(arg_66) } else { tmp3 = linked_64.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_63, arg_66) }; seq_1719000055__1, chunk_1719000056__2, count_1719000057__3, i_1719000058__4 = tmp3, nil, 0, 0; continue L1 } } else { return nil
		}
}
}
}
	panic("j2g: unreachable")
}
func A_arbace_go_check_env__init_A_Unit39__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(203, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_75; var tmp2 any = A_arbace_go_check_env_fn__1719000067_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_go_check_env_fn__1719000067_A_fn_class; if
							fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_check_env_fn__1719000067_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; /*line :203:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_76)); return A_arbace_go_check_env__init_A_const_75 }





func A_arbace_go_check_env__init_A_Unit40__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(209, 1); var root_68 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = A_arbace_go_check_env__init_A_const_63.GetRawRoot__O(); var arg_72 any = Lit_36; var arg_73 any; var root_74 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, A_arbace_go_check_env_obj_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_77; var tmp2 any = A_arbace_go_check_env__init_A_const_78; var tmp3 any = A_arbace_go_check_env__init_A_const_79; var tmp4 any = A_arbace_go_check_env__init_A_const_78; var arg_77 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_36, tmp4, A_arbace_go_check_env__init_A_const_75.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_64, jrt.Boolean_TRUE.Ref())); if linked_75 == nil { arg_73 = ifn_76.Invoke_O__O(arg_77) } else { arg_73 = linked_75.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_74, arg_77) }; if linked_69 == nil { return ifn_70.Invoke_O_O_O__O(arg_71, arg_72, arg_73) } else { return linked_69.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_68, arg_71, arg_72, arg_73) } }
func A_arbace_go_check_env__init_A_Unit41__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(210, 1); var root_78 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = A_arbace_go_check_env__init_A_const_63.GetRawRoot__O(); var arg_82 any = Lit_37; var arg_83 any; var root_84 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, A_arbace_go_check_env_obj_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_77; var tmp2 any = A_arbace_go_check_env__init_A_const_78; var tmp3 any = A_arbace_go_check_env__init_A_const_79; var tmp4 any = A_arbace_go_check_env__init_A_const_78; var arg_87 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_37, tmp4, lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_env__init_A_const_81, lang.PersistentVector_EMPTY.Ref(), nil), A_arbace_go_check_env__init_A_const_80, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_env__init_A_const_64, jrt.Boolean_TRUE.Ref())); if linked_85 == nil { arg_83 = ifn_86.Invoke_O__O(arg_87) } else { arg_83 = linked_85.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_84, arg_87) }; if linked_79 == nil { return ifn_80.Invoke_O_O_O__O(arg_81, arg_82, arg_83) } else { return linked_79.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_78, arg_81, arg_82, arg_83) } }

func A_arbace_go_check_env__init_A_Unit42__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(212, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_82; var tmp2 any = A_arbace_go_check_env_fn__1719000073_A_New(); var tmp3 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_go_check_env_fn__1719000073_A_fn_class; if
							fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_go_check_env_fn__1719000073_A_fn_class = fncls__88d; tmp3 = fncls__88d } else { tmp3 = fncls__88 }; /*line :212:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_83)); return A_arbace_go_check_env__init_A_const_82 }




func A_arbace_go_check_env__init_A_Unit43__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(217, 1); var root_89 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = A_arbace_go_check_env__init_A_const_63.GetRawRoot__O(); var arg_93 any = Lit_39; var arg_94 any; var root_95 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, A_arbace_go_check_env_obj_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_77; var tmp2 any = A_arbace_go_check_env__init_A_const_78; var tmp3 any = A_arbace_go_check_env__init_A_const_79; var tmp4 any = A_arbace_go_check_env__init_A_const_78; var arg_98 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_39, tmp4, A_arbace_go_check_env__init_A_const_82.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_64, jrt.Boolean_TRUE.Ref())); if linked_96 == nil { arg_94 = ifn_97.Invoke_O__O(arg_98) } else { arg_94 = linked_96.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_95, arg_98) }; if linked_90 == nil { return ifn_91.Invoke_O_O_O__O(arg_92, arg_93, arg_94) } else { return linked_90.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_89, arg_92, arg_93, arg_94) } }

func A_arbace_go_check_env__init_A_Unit44__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(219, 1); var root_99 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = A_arbace_go_check_env__init_A_const_63.GetRawRoot__O(); var arg_103 any = Lit_40; var arg_104 any; var root_105 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, A_arbace_go_check_env_obj_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = A_arbace_go_check_env__init_A_const_84; if linked_106 == nil { arg_104 = ifn_107.Invoke_O__O(arg_108) } else { arg_104 = linked_106.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_105, arg_108) }; if linked_100 == nil { return ifn_101.Invoke_O_O_O__O(arg_102, arg_103, arg_104) } else { return linked_100.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_99, arg_102, arg_103, arg_104) } }
func A_arbace_go_check_env__init_A_Unit45__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(220, 1); var root_109 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = A_arbace_go_check_env__init_A_const_63.GetRawRoot__O(); var arg_113 any = Lit_41; var arg_114 any; var root_115 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, A_arbace_go_check_env_obj_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = A_arbace_go_check_env__init_A_const_85; if linked_116 == nil { arg_114 = ifn_117.Invoke_O__O(arg_118) } else { arg_114 = linked_116.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_115, arg_118) }; if linked_110 == nil { return ifn_111.Invoke_O_O_O__O(arg_112, arg_113, arg_114) } else { return linked_110.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_109, arg_112, arg_113, arg_114) } }
func A_arbace_go_check_env__init_A_Unit46__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(221, 1); var root_119 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = A_arbace_go_check_env__init_A_const_63.GetRawRoot__O(); var arg_123 any = Lit_42; var arg_124 any; var root_125 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, A_arbace_go_check_env_obj_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = A_arbace_go_check_env__init_A_const_86; if linked_126 == nil { arg_124 = ifn_127.Invoke_O__O(arg_128) } else { arg_124 = linked_126.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_125, arg_128) }; if linked_120 == nil { return ifn_121.Invoke_O_O_O__O(arg_122, arg_123, arg_124) } else { return linked_120.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_119, arg_122, arg_123, arg_124) } }
func A_arbace_go_check_env__init_A_Unit47__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(222, 1); var root_129 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = A_arbace_go_check_env__init_A_const_63.GetRawRoot__O(); var arg_133 any = Lit_43; var arg_134 any; var root_135 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, A_arbace_go_check_env_obj_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = A_arbace_go_check_env__init_A_const_87; if linked_136 == nil { arg_134 = ifn_137.Invoke_O__O(arg_138) } else { arg_134 = linked_136.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_135, arg_138) }; if linked_130 == nil { return ifn_131.Invoke_O_O_O__O(arg_132, arg_133, arg_134) } else { return linked_130.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_129, arg_132, arg_133, arg_134) } }

func A_arbace_go_check_env__init_A_Unit48__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(224, 1); A_arbace_go_check_env__init_A_const_88.BindRoot_O__V(A_arbace_go_check_env__init_A_const_89); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_88; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_90)); return A_arbace_go_check_env__init_A_const_88 }



func A_arbace_go_check_env__init_A_Unit49__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(228, 1); { var seq_1719000085__1 any; var root_139 any = A_arbace_go_check_env__init_A_const_68.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = A_arbace_go_check_env__init_A_const_88.GetRawRoot__O(); if linked_140 == nil { seq_1719000085__1 = ifn_141.Invoke_O__O(arg_142) } else { seq_1719000085__1 = linked_140.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_139, arg_142) }; var chunk_1719000086__2 any; var count_1719000087__3 int64 = 0; var i_1719000088__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000088__4, count_1719000087__3) { var n__5 any = lang.Indexed_Cast(chunk_1719000086__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000088__4)); var root_159 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_161 lang.IFn
	if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = A_arbace_go_check_env__init_A_const_63.GetRawRoot__O(); var arg_163 any = n__5; var arg_164 any; var root_165 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, A_arbace_go_check_env_obj_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env__init_A_const_77, A_arbace_go_check_env__init_A_const_91, A_arbace_go_check_env__init_A_const_79, n__5, A_arbace_go_check_env__init_A_const_64, jrt.Boolean_TRUE.Ref())); if linked_166 == nil { arg_164 = ifn_167.Invoke_O__O(arg_168) } else { arg_164 = linked_166.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_165, arg_168) }; if linked_160 == nil { ifn_161.Invoke_O_O_O__O(arg_162, arg_163, arg_164) } else { linked_160.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_159, arg_162, arg_163, arg_164) }
//line :228:1
	seq_1719000085__1, chunk_1719000086__2, count_1719000087__3, i_1719000088__4 = seq_1719000085__1, chunk_1719000086__2, count_1719000087__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000088__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_143 any = A_arbace_go_check_env__init_A_const_68.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = seq_1719000085__1; if linked_144 == nil { temp__1927000414__auto____5 = ifn_145.Invoke_O__O(arg_146) } else { temp__1927000414__auto____5 = linked_144.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_143, arg_146) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1719000085__6 any = temp__1927000414__auto____5; var tmp1 any; var root_147 any = A_arbace_go_check_env__init_A_const_70.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = seq_1719000085__6; if linked_148 == nil { tmp1 = ifn_149.Invoke_O__O(arg_150) } else { tmp1 = linked_148.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_147, arg_150) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____7 any; var root_151 any = A_arbace_go_check_env__init_A_const_71.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = seq_1719000085__6; if linked_152 == nil { c__1927000678__auto____7 = ifn_153.Invoke_O__O(arg_154) } else { c__1927000678__auto____7 = linked_152.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_151, arg_154) }; var tmp2 any; var root_169 any = A_arbace_go_check_env__init_A_const_73.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = seq_1719000085__6; if linked_170 == nil { tmp2 = ifn_171.Invoke_O__O(arg_172) } else { tmp2 = linked_170.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_169, arg_172) }; seq_1719000085__1, chunk_1719000086__2, count_1719000087__3, i_1719000088__4 = tmp2, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__7 any; var root_155 any = A_arbace_go_check_env__init_A_const_72.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = seq_1719000085__6; if linked_156 == nil { n__7 = ifn_157.Invoke_O__O(arg_158) } else { n__7 = linked_156.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_155, arg_158) }
		var root_173 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = A_arbace_go_check_env__init_A_const_63.GetRawRoot__O(); var arg_177 any = n__7; var arg_178 any; var root_179 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, A_arbace_go_check_env_obj_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env__init_A_const_77, A_arbace_go_check_env__init_A_const_91, A_arbace_go_check_env__init_A_const_79, n__7, A_arbace_go_check_env__init_A_const_64, jrt.Boolean_TRUE.Ref())); if linked_180 == nil { arg_178 = ifn_181.Invoke_O__O(arg_182) } else { arg_178 = linked_180.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_179, arg_182) }; if linked_174 == nil { ifn_175.Invoke_O_O_O__O(arg_176, arg_177, arg_178) } else { linked_174.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_173, arg_176, arg_177, arg_178) }
//line :228:1
		var tmp3 any; var root_183 any = A_arbace_go_check_env__init_A_const_74.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = seq_1719000085__6; if linked_184 == nil { tmp3 = ifn_185.Invoke_O__O(arg_186) } else { tmp3 = linked_184.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_183, arg_186) }; seq_1719000085__1, chunk_1719000086__2, count_1719000087__3, i_1719000088__4 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } }
	panic("j2g: unreachable")
}


func A_arbace_go_check_env__init_A_Unit50__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(233, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_92; var tmp2 any = A_arbace_go_check_env_fn__1719000091_A_New(); var tmp3 *jrt.Class; var fncls__187 *jrt.Class = A_arbace_go_check_env_fn__1719000091_A_fn_class; if
							fncls__187 == nil { var fncls__187d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_check_env_fn__1719000091_A_fn_class = fncls__187d; tmp3 = fncls__187d } else { tmp3 = fncls__187 }; /*line :233:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_93)); return A_arbace_go_check_env__init_A_const_92 }






func A_arbace_go_check_env__init_A_Unit51__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(240, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_94; var tmp2 any; var root_188 any = A_arbace_go_check_env__init_A_const_95.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var tmp3 any = A_arbace_go_check_env__init_A_const_96; var tmp4 any = A_arbace_go_check_env__init_A_const_79; var tmp5 any = A_arbace_go_check_env__init_A_const_97; var arg_191 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, Lit_10, tmp4, Lit_10, tmp5, A_arbace_go_check_env__init_A_const_92.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_98, jrt.Boolean_TRUE.Ref())); if linked_189 == nil { tmp2 = ifn_190.Invoke_O__O(arg_191) } else { tmp2 = linked_189.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_188, arg_191) }; tmp1.BindRoot_O__V(tmp2); var tmp6 *lang.Var = A_arbace_go_check_env__init_A_const_94; tmp6.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_99)); return A_arbace_go_check_env__init_A_const_94 }



type A_arbace_go_check_env__init_A struct{ jrt.Object }

var A_arbace_go_check_env__init_A_const_pool *jrt.RefArray

var A_arbace_go_check_env__init_A_const_0 *lang.Var

var A_arbace_go_check_env__init_A_const_1 any

var A_arbace_go_check_env__init_A_const_2 any

var A_arbace_go_check_env__init_A_const_3 any

var A_arbace_go_check_env__init_A_const_4 *lang.Var

var A_arbace_go_check_env__init_A_const_5 any

var A_arbace_go_check_env__init_A_const_6 *lang.Var

var A_arbace_go_check_env__init_A_const_7 any

var A_arbace_go_check_env__init_A_const_8 *lang.Var

var A_arbace_go_check_env__init_A_const_9 any

var A_arbace_go_check_env__init_A_const_10 *lang.Var

var A_arbace_go_check_env__init_A_const_11 any

var A_arbace_go_check_env__init_A_const_12 *lang.Var

var A_arbace_go_check_env__init_A_const_13 any

var A_arbace_go_check_env__init_A_const_14 *lang.Var

var A_arbace_go_check_env__init_A_const_15 any

var A_arbace_go_check_env__init_A_const_16 *lang.Var

var A_arbace_go_check_env__init_A_const_17 any

var A_arbace_go_check_env__init_A_const_18 *lang.Var

var A_arbace_go_check_env__init_A_const_19 any

var A_arbace_go_check_env__init_A_const_20 *lang.Var

var A_arbace_go_check_env__init_A_const_21 any

var A_arbace_go_check_env__init_A_const_22 *lang.Var

var A_arbace_go_check_env__init_A_const_23 any

var A_arbace_go_check_env__init_A_const_24 *lang.Var

var A_arbace_go_check_env__init_A_const_25 any

var A_arbace_go_check_env__init_A_const_26 *lang.Var

var A_arbace_go_check_env__init_A_const_27 any

var A_arbace_go_check_env__init_A_const_28 *lang.Var

var A_arbace_go_check_env__init_A_const_29 any

var A_arbace_go_check_env__init_A_const_30 *lang.Var

var A_arbace_go_check_env__init_A_const_31 any

var A_arbace_go_check_env__init_A_const_32 *lang.Var

var A_arbace_go_check_env__init_A_const_33 any

var A_arbace_go_check_env__init_A_const_34 *lang.Var

var A_arbace_go_check_env__init_A_const_35 any

var A_arbace_go_check_env__init_A_const_36 *lang.Var

var A_arbace_go_check_env__init_A_const_37 any

var A_arbace_go_check_env__init_A_const_38 *lang.Var

var A_arbace_go_check_env__init_A_const_39 any

var A_arbace_go_check_env__init_A_const_40 *lang.Var

var A_arbace_go_check_env__init_A_const_41 any

var A_arbace_go_check_env__init_A_const_42 any

var A_arbace_go_check_env__init_A_const_43 *lang.Var

var A_arbace_go_check_env__init_A_const_44 any

var A_arbace_go_check_env__init_A_const_45 *lang.Var

var A_arbace_go_check_env__init_A_const_46 any

var A_arbace_go_check_env__init_A_const_47 *lang.Var

var A_arbace_go_check_env__init_A_const_48 any

var A_arbace_go_check_env__init_A_const_49 *lang.Var

var A_arbace_go_check_env__init_A_const_50 any

var A_arbace_go_check_env__init_A_const_51 *lang.Var

var A_arbace_go_check_env__init_A_const_52 any

var A_arbace_go_check_env__init_A_const_53 *lang.Var

var A_arbace_go_check_env__init_A_const_54 any

var A_arbace_go_check_env__init_A_const_55 *lang.Var

var A_arbace_go_check_env__init_A_const_56 any

var A_arbace_go_check_env__init_A_const_57 *lang.Var

var A_arbace_go_check_env__init_A_const_58 any

var A_arbace_go_check_env__init_A_const_59 *lang.Var

var A_arbace_go_check_env__init_A_const_60 any

var A_arbace_go_check_env__init_A_const_61 *lang.Var

var A_arbace_go_check_env__init_A_const_62 any

var A_arbace_go_check_env__init_A_const_63 *lang.Var

var A_arbace_go_check_env__init_A_const_64 *lang.Keyword

var A_arbace_go_check_env__init_A_const_65 any

var A_arbace_go_check_env__init_A_const_66 *lang.Var

var A_arbace_go_check_env__init_A_const_67 any

var A_arbace_go_check_env__init_A_const_68 *lang.Var

var A_arbace_go_check_env__init_A_const_69 any

var A_arbace_go_check_env__init_A_const_70 *lang.Var

var A_arbace_go_check_env__init_A_const_71 *lang.Var

var A_arbace_go_check_env__init_A_const_72 *lang.Var

var A_arbace_go_check_env__init_A_const_73 *lang.Var

var A_arbace_go_check_env__init_A_const_74 *lang.Var

var A_arbace_go_check_env__init_A_const_75 *lang.Var

var A_arbace_go_check_env__init_A_const_76 any

var A_arbace_go_check_env__init_A_const_77 *lang.Keyword

var A_arbace_go_check_env__init_A_const_78 *lang.Keyword

var A_arbace_go_check_env__init_A_const_79 *lang.Keyword

var A_arbace_go_check_env__init_A_const_80 *lang.Keyword

var A_arbace_go_check_env__init_A_const_81 *lang.Keyword

var A_arbace_go_check_env__init_A_const_82 *lang.Var

var A_arbace_go_check_env__init_A_const_83 any

var A_arbace_go_check_env__init_A_const_84 any

var A_arbace_go_check_env__init_A_const_85 any

var A_arbace_go_check_env__init_A_const_86 any

var A_arbace_go_check_env__init_A_const_87 any

var A_arbace_go_check_env__init_A_const_88 *lang.Var

var A_arbace_go_check_env__init_A_const_89 any

var A_arbace_go_check_env__init_A_const_90 any

var A_arbace_go_check_env__init_A_const_91 *lang.Keyword

var A_arbace_go_check_env__init_A_const_92 *lang.Var

var A_arbace_go_check_env__init_A_const_93 any

var A_arbace_go_check_env__init_A_const_94 *lang.Var

var A_arbace_go_check_env__init_A_const_95 *lang.Var

var A_arbace_go_check_env__init_A_const_96 *lang.Keyword

var A_arbace_go_check_env__init_A_const_97 *lang.Keyword

var A_arbace_go_check_env__init_A_const_98 *lang.Keyword

var A_arbace_go_check_env__init_A_const_99 any

var A_arbace_go_check_env__init_A_init jrt.ClassInit

func A_arbace_go_check_env__init_A_Init() { if !A_arbace_go_check_env__init_A_init.Done() { A_arbace_go_check_env__init_A_init.Run(A_arbace_go_check_env__init_A_clinit) } }

func A_arbace_go_check_env__init_A_clinit() { A_arbace_go_check_env__init_A_clinit_p0(); A_arbace_go_check_env__init_A_clinit_p1(); A_arbace_go_check_env__init_A_clinit_p2(); A_arbace_go_check_env__init_A_clinit_p3(); A_arbace_go_check_env__init_A_clinit_p4(); A_arbace_go_check_env__init_A_clinit_p5(); A_arbace_go_check_env__init_A_clinit_p6(); A_arbace_go_check_env__init_A_clinit_p7() }

func A_arbace_go_check_env__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_env__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_11, 173); A_arbace_go_check_env__init_A_const_0 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[73]); A_arbace_go_check_env__init_A_const_1 = A_arbace_go_check_env__init_A_const_pool.A[74]; A_arbace_go_check_env__init_A_const_2 = A_arbace_go_check_env__init_A_const_pool.A[75]; A_arbace_go_check_env__init_A_const_3 = A_arbace_go_check_env__init_A_const_pool.A[76]; A_arbace_go_check_env__init_A_const_4 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[77]); A_arbace_go_check_env__init_A_const_5 = A_arbace_go_check_env__init_A_const_pool.A[78]; A_arbace_go_check_env__init_A_const_6 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[79]); A_arbace_go_check_env__init_A_const_7 = A_arbace_go_check_env__init_A_const_pool.A[80]; A_arbace_go_check_env__init_A_const_8 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[81]); A_arbace_go_check_env__init_A_const_9 = A_arbace_go_check_env__init_A_const_pool.A[82]; A_arbace_go_check_env__init_A_const_10 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[83]); A_arbace_go_check_env__init_A_const_11 = A_arbace_go_check_env__init_A_const_pool.A[84]; A_arbace_go_check_env__init_A_const_12 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[85]) }

func A_arbace_go_check_env__init_A_clinit_p1() { A_arbace_go_check_env__init_A_const_13 = A_arbace_go_check_env__init_A_const_pool.A[86]; A_arbace_go_check_env__init_A_const_14 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[87]); A_arbace_go_check_env__init_A_const_15 = A_arbace_go_check_env__init_A_const_pool.A[88]; A_arbace_go_check_env__init_A_const_16 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[89]); A_arbace_go_check_env__init_A_const_17 = A_arbace_go_check_env__init_A_const_pool.A[90]; A_arbace_go_check_env__init_A_const_18 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[91]); A_arbace_go_check_env__init_A_const_19 = A_arbace_go_check_env__init_A_const_pool.A[92]; A_arbace_go_check_env__init_A_const_20 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[93]); A_arbace_go_check_env__init_A_const_21 = A_arbace_go_check_env__init_A_const_pool.A[94]; A_arbace_go_check_env__init_A_const_22 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[95]); A_arbace_go_check_env__init_A_const_23 = A_arbace_go_check_env__init_A_const_pool.A[96]; A_arbace_go_check_env__init_A_const_24 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[97]); A_arbace_go_check_env__init_A_const_25 = A_arbace_go_check_env__init_A_const_pool.A[98] }

func A_arbace_go_check_env__init_A_clinit_p2() { A_arbace_go_check_env__init_A_const_26 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[99]); A_arbace_go_check_env__init_A_const_27 = A_arbace_go_check_env__init_A_const_pool.A[100]; A_arbace_go_check_env__init_A_const_28 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[101]); A_arbace_go_check_env__init_A_const_29 = A_arbace_go_check_env__init_A_const_pool.A[102]; A_arbace_go_check_env__init_A_const_30 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[103]); A_arbace_go_check_env__init_A_const_31 = A_arbace_go_check_env__init_A_const_pool.A[104]; A_arbace_go_check_env__init_A_const_32 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[105]); A_arbace_go_check_env__init_A_const_33 = A_arbace_go_check_env__init_A_const_pool.A[106]; A_arbace_go_check_env__init_A_const_34 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[107]); A_arbace_go_check_env__init_A_const_35 = A_arbace_go_check_env__init_A_const_pool.A[108]; A_arbace_go_check_env__init_A_const_36 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[109]); A_arbace_go_check_env__init_A_const_37 = A_arbace_go_check_env__init_A_const_pool.A[110]; A_arbace_go_check_env__init_A_const_38 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[111]) }

func A_arbace_go_check_env__init_A_clinit_p3() { A_arbace_go_check_env__init_A_const_39 = A_arbace_go_check_env__init_A_const_pool.A[112]; A_arbace_go_check_env__init_A_const_40 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[113]); A_arbace_go_check_env__init_A_const_41 = A_arbace_go_check_env__init_A_const_pool.A[114]; A_arbace_go_check_env__init_A_const_42 = A_arbace_go_check_env__init_A_const_pool.A[115]; A_arbace_go_check_env__init_A_const_43 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[116]); A_arbace_go_check_env__init_A_const_44 = A_arbace_go_check_env__init_A_const_pool.A[117]; A_arbace_go_check_env__init_A_const_45 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[118]); A_arbace_go_check_env__init_A_const_46 = A_arbace_go_check_env__init_A_const_pool.A[119]; A_arbace_go_check_env__init_A_const_47 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[120]); A_arbace_go_check_env__init_A_const_48 = A_arbace_go_check_env__init_A_const_pool.A[121]; A_arbace_go_check_env__init_A_const_49 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[122]); A_arbace_go_check_env__init_A_const_50 = A_arbace_go_check_env__init_A_const_pool.A[123]; A_arbace_go_check_env__init_A_const_51 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[124]); A_arbace_go_check_env__init_A_const_52 = A_arbace_go_check_env__init_A_const_pool.A[125] }

func A_arbace_go_check_env__init_A_clinit_p4() { A_arbace_go_check_env__init_A_const_53 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[126]); A_arbace_go_check_env__init_A_const_54 = A_arbace_go_check_env__init_A_const_pool.A[127]; A_arbace_go_check_env__init_A_const_55 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[128]); A_arbace_go_check_env__init_A_const_56 = A_arbace_go_check_env__init_A_const_pool.A[129]; A_arbace_go_check_env__init_A_const_57 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[130]); A_arbace_go_check_env__init_A_const_58 = A_arbace_go_check_env__init_A_const_pool.A[131]; A_arbace_go_check_env__init_A_const_59 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[132]); A_arbace_go_check_env__init_A_const_60 = A_arbace_go_check_env__init_A_const_pool.A[133]; A_arbace_go_check_env__init_A_const_61 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[134]); A_arbace_go_check_env__init_A_const_62 = A_arbace_go_check_env__init_A_const_pool.A[135]; A_arbace_go_check_env__init_A_const_63 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[136]); A_arbace_go_check_env__init_A_const_64 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[137]); A_arbace_go_check_env__init_A_const_65 = A_arbace_go_check_env__init_A_const_pool.A[138] }

func A_arbace_go_check_env__init_A_clinit_p5() { A_arbace_go_check_env__init_A_const_66 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[139]); A_arbace_go_check_env__init_A_const_67 = A_arbace_go_check_env__init_A_const_pool.A[140]; A_arbace_go_check_env__init_A_const_68 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[141]); A_arbace_go_check_env__init_A_const_69 = A_arbace_go_check_env__init_A_const_pool.A[142]; A_arbace_go_check_env__init_A_const_70 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[143]); A_arbace_go_check_env__init_A_const_71 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[144]); A_arbace_go_check_env__init_A_const_72 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[145]); A_arbace_go_check_env__init_A_const_73 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[146]); A_arbace_go_check_env__init_A_const_74 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[147]); A_arbace_go_check_env__init_A_const_75 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[148]); A_arbace_go_check_env__init_A_const_76 = A_arbace_go_check_env__init_A_const_pool.A[149]; A_arbace_go_check_env__init_A_const_77 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[150]) }

func A_arbace_go_check_env__init_A_clinit_p6() { A_arbace_go_check_env__init_A_const_78 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[151]); A_arbace_go_check_env__init_A_const_79 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[152]); A_arbace_go_check_env__init_A_const_80 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[153]); A_arbace_go_check_env__init_A_const_81 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[154]); A_arbace_go_check_env__init_A_const_82 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[155]); A_arbace_go_check_env__init_A_const_83 = A_arbace_go_check_env__init_A_const_pool.A[156]; A_arbace_go_check_env__init_A_const_84 = A_arbace_go_check_env__init_A_const_pool.A[157]; A_arbace_go_check_env__init_A_const_85 = A_arbace_go_check_env__init_A_const_pool.A[158]; A_arbace_go_check_env__init_A_const_86 = A_arbace_go_check_env__init_A_const_pool.A[159]; A_arbace_go_check_env__init_A_const_87 = A_arbace_go_check_env__init_A_const_pool.A[160]; A_arbace_go_check_env__init_A_const_88 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[161]); A_arbace_go_check_env__init_A_const_89 = A_arbace_go_check_env__init_A_const_pool.A[162]; A_arbace_go_check_env__init_A_const_90 = A_arbace_go_check_env__init_A_const_pool.A[163] }

func A_arbace_go_check_env__init_A_clinit_p7() { A_arbace_go_check_env__init_A_const_91 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[164]); A_arbace_go_check_env__init_A_const_92 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[165]); A_arbace_go_check_env__init_A_const_93 = A_arbace_go_check_env__init_A_const_pool.A[166]; A_arbace_go_check_env__init_A_const_94 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[167]); A_arbace_go_check_env__init_A_const_95 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[168]); A_arbace_go_check_env__init_A_const_96 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[169]); A_arbace_go_check_env__init_A_const_97 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[170]); A_arbace_go_check_env__init_A_const_98 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[171]); A_arbace_go_check_env__init_A_const_99 = A_arbace_go_check_env__init_A_const_pool.A[172] }

func A_arbace_go_check_env__init_A_New() *A_arbace_go_check_env__init_A { A_arbace_go_check_env__init_A_Init(); t := &A_arbace_go_check_env__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env__init_A) Ctor() {}

func (t *A_arbace_go_check_env__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env__init_A_class }

func (t *A_arbace_go_check_env__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env__init_A); return ok }

func A_arbace_go_check_env__init_A_Cast(x any) *A_arbace_go_check_env__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env__init_A_class)) }; return v }
