//line aot_arbace_go_check_env__init.ae:1
package aot_arbace_go_check_env

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_env__init_A_Unit0__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_check_env__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env__init_A_const_1) }
//line :1:1
func A_arbace_go_check_env__init_A_Unit1__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_check_env__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_2)) }
//line :1:1
func A_arbace_go_check_env__init_A_Unit2__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_go_check_env__init_A_Unit3__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_check_env__init_A_const_1)).Equals_O__Z(A_arbace_go_check_env__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_go_check_env_eval1719000008_fn__1719000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_go_check_env__init_A_Load__O() any { A_arbace_go_check_env__init_A_Init(); jrt.StartCheck(); A_arbace_go_check_env__init_A_Unit0__O(); A_arbace_go_check_env__init_A_Unit1__O(); A_arbace_go_check_env__init_A_Unit2__O(); A_arbace_go_check_env__init_A_Unit3__O(); A_arbace_go_check_env__init_A_Unit4__O(); A_arbace_go_check_env__init_A_Unit5__O(); A_arbace_go_check_env__init_A_Unit6__O(); A_arbace_go_check_env__init_A_Unit7__O(); A_arbace_go_check_env__init_A_Unit8__O(); A_arbace_go_check_env__init_A_Unit9__O(); A_arbace_go_check_env__init_A_Unit10__O(); A_arbace_go_check_env__init_A_Unit11__O(); A_arbace_go_check_env__init_A_Unit12__O(); A_arbace_go_check_env__init_A_Unit13__O(); A_arbace_go_check_env__init_A_Unit14__O(); A_arbace_go_check_env__init_A_Unit15__O(); A_arbace_go_check_env__init_A_Unit16__O(); A_arbace_go_check_env__init_A_Unit17__O(); A_arbace_go_check_env__init_A_Unit18__O(); A_arbace_go_check_env__init_A_Unit19__O(); A_arbace_go_check_env__init_A_Unit20__O(); A_arbace_go_check_env__init_A_Unit21__O(); A_arbace_go_check_env__init_A_Unit22__O(); A_arbace_go_check_env__init_A_Unit23__O(); A_arbace_go_check_env__init_A_Unit24__O(); A_arbace_go_check_env__init_A_Unit25__O(); A_arbace_go_check_env__init_A_Unit26__O(); A_arbace_go_check_env__init_A_Unit27__O(); A_arbace_go_check_env__init_A_Unit28__O(); A_arbace_go_check_env__init_A_Unit29__O(); A_arbace_go_check_env__init_A_Unit30__O(); A_arbace_go_check_env__init_A_Unit31__O(); A_arbace_go_check_env__init_A_Unit32__O(); A_arbace_go_check_env__init_A_Unit33__O(); A_arbace_go_check_env__init_A_Unit34__O(); A_arbace_go_check_env__init_A_Unit35__O(); A_arbace_go_check_env__init_A_Unit36__O(); A_arbace_go_check_env__init_A_Unit37__O(); A_arbace_go_check_env__init_A_Unit38__O(); A_arbace_go_check_env__init_A_Unit39__O(); A_arbace_go_check_env__init_A_Unit40__O(); A_arbace_go_check_env__init_A_Unit41__O(); A_arbace_go_check_env__init_A_Unit42__O(); A_arbace_go_check_env__init_A_Unit43__O(); A_arbace_go_check_env__init_A_Unit44__O(); A_arbace_go_check_env__init_A_Unit45__O(); A_arbace_go_check_env__init_A_Unit46__O(); A_arbace_go_check_env__init_A_Unit47__O(); A_arbace_go_check_env__init_A_Unit48__O(); A_arbace_go_check_env__init_A_Unit49__O(); A_arbace_go_check_env__init_A_Unit50__O(); A_arbace_go_check_env__init_A_Unit51__O(); A_arbace_go_check_env__init_A_Unit52__O(); A_arbace_go_check_env__init_A_Unit53__O(); A_arbace_go_check_env__init_A_Unit54__O(); return nil }









func A_arbace_go_check_env__init_A_Unit4__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_4; var tmp2 any = A_arbace_go_check_env_obj_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_env_obj_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_go_check_env_obj_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_5)); return A_arbace_go_check_env__init_A_const_4 }
func A_arbace_go_check_env__init_A_Unit5__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_6; var tmp2 any = A_arbace_go_check_env_o_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_go_check_env_o_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_go_check_env_o_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_7)); return A_arbace_go_check_env__init_A_const_6 }
func A_arbace_go_check_env__init_A_Unit6__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_8; var tmp2 any = A_arbace_go_check_env_oset_BANG__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_env_oset_BANG__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_go_check_env_oset_BANG__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_9)); return A_arbace_go_check_env__init_A_const_8 }
func A_arbace_go_check_env__init_A_Unit7__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_10; var tmp2 any = A_arbace_go_check_env_obj_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_go_check_env_obj_QMARK__A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_go_check_env_obj_QMARK__A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_11)); return A_arbace_go_check_env__init_A_const_10 }



func A_arbace_go_check_env__init_A_Unit8__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_12; var tmp2 any = A_arbace_go_check_env_scope_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_env_scope_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_go_check_env_scope_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_13)); return A_arbace_go_check_env__init_A_const_12 }

func A_arbace_go_check_env__init_A_Unit9__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_14; var tmp2 any = A_arbace_go_check_env_scope_lookup_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_go_check_env_scope_lookup_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_go_check_env_scope_lookup_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_15)); return A_arbace_go_check_env__init_A_const_14 }








func A_arbace_go_check_env__init_A_Unit10__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_16; var tmp2 any = A_arbace_go_check_env_scope_get_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_env_scope_get_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_go_check_env_scope_get_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_17)); return A_arbace_go_check_env__init_A_const_16 }
func A_arbace_go_check_env__init_A_Unit11__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_18; var tmp2 any = A_arbace_go_check_env_scope_put_BANG__A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_go_check_env_scope_put_BANG__A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_go_check_env_scope_put_BANG__A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_19)); return A_arbace_go_check_env__init_A_const_18 }



func A_arbace_go_check_env__init_A_Unit12__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); A_arbace_go_check_env__init_A_const_20.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_21)); return A_arbace_go_check_env__init_A_const_20.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit13__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); A_arbace_go_check_env__init_A_const_22.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_23)); return A_arbace_go_check_env__init_A_const_22.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit14__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); A_arbace_go_check_env__init_A_const_24.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_24; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_25)); return A_arbace_go_check_env__init_A_const_24.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit15__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); A_arbace_go_check_env__init_A_const_26.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_27)); return A_arbace_go_check_env__init_A_const_26.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check_env__init_A_Unit16__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); A_arbace_go_check_env__init_A_const_28.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_29)); return A_arbace_go_check_env__init_A_const_28.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check_env__init_A_Unit17__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); A_arbace_go_check_env__init_A_const_30.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_31)); return A_arbace_go_check_env__init_A_const_30.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check_env__init_A_Unit18__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_32; var tmp2 any = A_arbace_go_check_env_error_BANG__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_env_error_BANG__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_go_check_env_error_BANG__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_33)); return A_arbace_go_check_env__init_A_const_32 }















func A_arbace_go_check_env__init_A_Unit19__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(80, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_34; var tmp2 any = A_arbace_go_check_env_line_of_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_go_check_env_line_of_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_go_check_env_line_of_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_35)); return A_arbace_go_check_env__init_A_const_34 }





func A_arbace_go_check_env__init_A_Unit20__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(86, 1); A_arbace_go_check_env__init_A_const_36.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_36; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_37)); return A_arbace_go_check_env__init_A_const_36.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check_env__init_A_Unit21__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(88, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_39)); return A_arbace_go_check_env__init_A_const_38 }

func A_arbace_go_check_env__init_A_Unit22__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(90, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_40; var tmp2 any = A_arbace_go_check_env_end_line_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_env_end_line_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_go_check_env_end_line_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_41)); return A_arbace_go_check_env__init_A_const_40 }










func A_arbace_go_check_env__init_A_Unit23__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_38; var tmp2 any = A_arbace_go_check_env_child_line_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_go_check_env_child_line_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_go_check_env_child_line_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_42)); return A_arbace_go_check_env__init_A_const_38 }



















func A_arbace_go_check_env__init_A_Unit24__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(121, 1); A_arbace_go_check_env__init_A_const_43.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_44)); return A_arbace_go_check_env__init_A_const_43.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_env__init_A_Unit25__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_45; var tmp2 any = A_arbace_go_check_env_with_child_line_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_env_with_child_line_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, true); A_arbace_go_check_env_with_child_line_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_46)); return A_arbace_go_check_env__init_A_const_45 }
//line :126:1
func A_arbace_go_check_env__init_A_Unit26__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); A_arbace_go_check_env__init_A_const_45.SetMacro__V(); return nil }
//line :126:1
func A_arbace_go_check_env__init_A_Unit27__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); return A_arbace_go_check_env__init_A_const_45 }







func A_arbace_go_check_env__init_A_Unit28__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(134, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_47; var tmp2 any = A_arbace_go_check_env_current_line_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_go_check_env_current_line_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_go_check_env_current_line_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_48)); return A_arbace_go_check_env__init_A_const_47 }




func A_arbace_go_check_env__init_A_Unit29__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_49; var tmp2 any = A_arbace_go_check_env_err_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_check_env_err_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, true); A_arbace_go_check_env_err_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_50)); return A_arbace_go_check_env__init_A_const_49 }






func A_arbace_go_check_env__init_A_Unit30__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(146, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_51; var tmp2 any = A_arbace_go_check_env_generic_BANG__A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_go_check_env_generic_BANG__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_go_check_env_generic_BANG__A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_52)); return A_arbace_go_check_env__init_A_const_51 }





func A_arbace_go_check_env__init_A_Unit31__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(152, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_53; var tmp2 any = A_arbace_go_check_env_unsupported_BANG__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_check_env_unsupported_BANG__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_go_check_env_unsupported_BANG__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_54)); return A_arbace_go_check_env__init_A_const_53 }









func A_arbace_go_check_env__init_A_Unit32__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(162, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_55; var tmp2 any = A_arbace_go_check_env_unsupported_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_go_check_env_unsupported_QMARK__A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_go_check_env_unsupported_QMARK__A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_56)); return A_arbace_go_check_env__init_A_const_55 }



func A_arbace_go_check_env__init_A_Unit33__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(166, 1); A_arbace_go_check_env__init_A_const_57.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_57; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_58)); return A_arbace_go_check_env__init_A_const_57.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_env__init_A_Unit34__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(171, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_59; var tmp2 any = A_arbace_go_check_env_verified_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_check_env_verified_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_go_check_env_verified_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_60)); return A_arbace_go_check_env__init_A_const_59 }












func A_arbace_go_check_env__init_A_Unit35__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(184, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_61; var tmp2 any = A_arbace_go_check_env_annotation_error_BANG__A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_go_check_env_annotation_error_BANG__A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_check_env_annotation_error_BANG__A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_62)); return A_arbace_go_check_env__init_A_const_61 }







func A_arbace_go_check_env__init_A_Unit36__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(192, 1); A_arbace_go_check_env__init_A_const_63.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_63; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_64)); return A_arbace_go_check_env__init_A_const_63.SetDynamic_Z__Var(true).Ref() }






func A_arbace_go_check_env__init_A_Unit37__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(199, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_65; var tmp2 any = A_arbace_go_check_env_at_of_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_check_env_at_of_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_check_env_at_of_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_66)); return A_arbace_go_check_env__init_A_const_65 }




func A_arbace_go_check_env__init_A_Unit38__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(204, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_67; var tmp2 any = A_arbace_go_check_env_answer_BANG__A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_go_check_env_answer_BANG__A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_check_env_answer_BANG__A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_68)); return A_arbace_go_check_env__init_A_const_67 }















func A_arbace_go_check_env__init_A_Unit39__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(220, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_69; var tmp2 any; var root_25 any = A_arbace_go_check_env__init_A_const_12.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, A_arbace_go_check_env_scope_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any; var arg_29 any = A_arbace_go_check_env__init_A_const_70; if linked_26 == nil { tmp2 = ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { tmp2 = linked_26.(*A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_check_env__init_A_const_69; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_71)); return A_arbace_go_check_env__init_A_const_69 }

func A_arbace_go_check_env__init_A_Unit40__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(222, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_72; var tmp2 any = A_arbace_go_check_env_def_type_BANG__A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_go_check_env_def_type_BANG__A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_go_check_env_def_type_BANG__A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_73)); return A_arbace_go_check_env__init_A_const_72 }




func A_arbace_go_check_env__init_A_Unit41__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(227, 1); { var seq_1719000061__1 any; var root_31 any = A_arbace_go_check_env__init_A_const_74.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = A_arbace_go_check_env__init_A_const_75; if linked_32 == nil { seq_1719000061__1 = ifn_33.Invoke_O__O(arg_34) } else { seq_1719000061__1 = linked_32.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_31, arg_34) }; var chunk_1719000062__2 any; var count_1719000063__3 int64 = 0; var i_1719000064__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000064__4, count_1719000063__3) { var vec__1719000066__5 any = lang.Indexed_Cast(chunk_1719000062__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000064__4)); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000066__5, lang.RT_IntCast_J__I_NoInit(0), nil); var kw__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000066__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_51 any = A_arbace_go_check_env__init_A_const_72.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, A_arbace_go_check_env_def_type_BANG__A_fn_class); var ifn_53 lang.IFn




	if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = n__6; var arg_55 any = kw__7; if linked_52 == nil { ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { linked_52.(*A_arbace_go_check_env_def_type_BANG__A).Invoke_O_O_O__O(root_51, arg_54, arg_55) }
//line :227:1
	seq_1719000061__1, chunk_1719000062__2, count_1719000063__3, i_1719000064__4 = seq_1719000061__1, chunk_1719000062__2, count_1719000063__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000064__4); continue L1



} else {
//line :227:1
	var temp__1927000414__auto____5 any; var root_35 any = A_arbace_go_check_env__init_A_const_74.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = seq_1719000061__1; if linked_36 == nil { temp__1927000414__auto____5 = ifn_37.Invoke_O__O(arg_38) } else { temp__1927000414__auto____5 = linked_36.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_35, arg_38) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1719000061__6 any = temp__1927000414__auto____5; var tmp1 any; var root_39 any = A_arbace_go_check_env__init_A_const_76.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = seq_1719000061__6; if linked_40 == nil { tmp1 = ifn_41.Invoke_O__O(arg_42) } else { tmp1 = linked_40.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_39, arg_42) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____7 any; var root_43 any = A_arbace_go_check_env__init_A_const_77.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = seq_1719000061__6; if linked_44 == nil { c__1927000678__auto____7 = ifn_45.Invoke_O__O(arg_46) } else { c__1927000678__auto____7 = linked_44.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_43, arg_46) }; var tmp2 any; var root_56 any = A_arbace_go_check_env__init_A_const_79.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = seq_1719000061__6; if linked_57 == nil { tmp2 = ifn_58.Invoke_O__O(arg_59) } else { tmp2 = linked_57.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_56, arg_59) }; seq_1719000061__1, chunk_1719000062__2, count_1719000063__3, i_1719000064__4 = tmp2, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1719000069__7 any; var root_47 any = A_arbace_go_check_env__init_A_const_78.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = seq_1719000061__6; if linked_48 == nil { vec__1719000069__7 = ifn_49.Invoke_O__O(arg_50) } else { vec__1719000069__7 = linked_48.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_47, arg_50) }; var n__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000069__7, lang.RT_IntCast_J__I_NoInit(0), nil); var kw__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000069__7, lang.RT_IntCast_J__I_NoInit(1), nil); var root_60 any = A_arbace_go_check_env__init_A_const_72.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, A_arbace_go_check_env_def_type_BANG__A_fn_class); var ifn_62 lang.IFn




		if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = n__8; var arg_64 any = kw__9; if linked_61 == nil { ifn_62.Invoke_O_O__O(arg_63, arg_64) } else { linked_61.(*A_arbace_go_check_env_def_type_BANG__A).Invoke_O_O_O__O(root_60, arg_63, arg_64) }
//line :227:1
		var tmp3 any; var root_65 any = A_arbace_go_check_env__init_A_const_80.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = seq_1719000061__6; if linked_66 == nil { tmp3 = ifn_67.Invoke_O__O(arg_68) } else { tmp3 = linked_66.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_65, arg_68) }; seq_1719000061__1, chunk_1719000062__2, count_1719000063__3, i_1719000064__4 = tmp3, nil, 0, 0; continue L1 } } else { return nil
		}
}
}
}
	panic("j2g: unreachable")
}
func A_arbace_go_check_env__init_A_Unit42__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(234, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_81; var tmp2 any = A_arbace_go_check_env_fn__1719000073_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_go_check_env_fn__1719000073_A_fn_class; if
							fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_go_check_env_fn__1719000073_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; /*line :234:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_82)); return A_arbace_go_check_env__init_A_const_81 }





func A_arbace_go_check_env__init_A_Unit43__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(240, 1); var root_70 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = A_arbace_go_check_env__init_A_const_69.GetRawRoot__O(); var arg_74 any = Lit_38; var arg_75 any; var root_76 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, A_arbace_go_check_env_obj_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_83; var tmp2 any = A_arbace_go_check_env__init_A_const_84; var tmp3 any = A_arbace_go_check_env__init_A_const_85; var tmp4 any = A_arbace_go_check_env__init_A_const_84; var arg_79 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_38, tmp4, A_arbace_go_check_env__init_A_const_81.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_70, jrt.Boolean_TRUE.Ref())); if linked_77 == nil { arg_75 = ifn_78.Invoke_O__O(arg_79) } else { arg_75 = linked_77.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_76, arg_79) }; if linked_71 == nil { return ifn_72.Invoke_O_O_O__O(arg_73, arg_74, arg_75) } else { return linked_71.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_70, arg_73, arg_74, arg_75) } }
func A_arbace_go_check_env__init_A_Unit44__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(241, 1); var root_80 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = A_arbace_go_check_env__init_A_const_69.GetRawRoot__O(); var arg_84 any = Lit_39; var arg_85 any; var root_86 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, A_arbace_go_check_env_obj_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_83; var tmp2 any = A_arbace_go_check_env__init_A_const_84; var tmp3 any = A_arbace_go_check_env__init_A_const_85; var tmp4 any = A_arbace_go_check_env__init_A_const_84; var arg_89 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_39, tmp4, lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_env__init_A_const_87, lang.PersistentVector_EMPTY.Ref(), nil), A_arbace_go_check_env__init_A_const_86, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_env__init_A_const_70, jrt.Boolean_TRUE.Ref())); if linked_87 == nil { arg_85 = ifn_88.Invoke_O__O(arg_89) } else { arg_85 = linked_87.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_86, arg_89) }; if linked_81 == nil { return ifn_82.Invoke_O_O_O__O(arg_83, arg_84, arg_85) } else { return linked_81.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_80, arg_83, arg_84, arg_85) } }

func A_arbace_go_check_env__init_A_Unit45__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(243, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_88; var tmp2 any = A_arbace_go_check_env_fn__1719000079_A_New(); var tmp3 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_go_check_env_fn__1719000079_A_fn_class; if
							fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_check_env_fn__1719000079_A_fn_class = fncls__90d; tmp3 = fncls__90d } else { tmp3 = fncls__90 }; /*line :243:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_89)); return A_arbace_go_check_env__init_A_const_88 }




func A_arbace_go_check_env__init_A_Unit46__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(248, 1); var root_91 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = A_arbace_go_check_env__init_A_const_69.GetRawRoot__O(); var arg_95 any = Lit_41; var arg_96 any; var root_97 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, A_arbace_go_check_env_obj_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_83; var tmp2 any = A_arbace_go_check_env__init_A_const_84; var tmp3 any = A_arbace_go_check_env__init_A_const_85; var tmp4 any = A_arbace_go_check_env__init_A_const_84; var arg_100 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_41, tmp4, A_arbace_go_check_env__init_A_const_88.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_70, jrt.Boolean_TRUE.Ref())); if linked_98 == nil { arg_96 = ifn_99.Invoke_O__O(arg_100) } else { arg_96 = linked_98.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_97, arg_100) }; if linked_92 == nil { return ifn_93.Invoke_O_O_O__O(arg_94, arg_95, arg_96) } else { return linked_92.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_91, arg_94, arg_95, arg_96) } }

func A_arbace_go_check_env__init_A_Unit47__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(250, 1); var root_101 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = A_arbace_go_check_env__init_A_const_69.GetRawRoot__O(); var arg_105 any = Lit_42; var arg_106 any; var root_107 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, A_arbace_go_check_env_obj_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = A_arbace_go_check_env__init_A_const_90; if linked_108 == nil { arg_106 = ifn_109.Invoke_O__O(arg_110) } else { arg_106 = linked_108.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_107, arg_110) }; if linked_102 == nil { return ifn_103.Invoke_O_O_O__O(arg_104, arg_105, arg_106) } else { return linked_102.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_101, arg_104, arg_105, arg_106) } }
func A_arbace_go_check_env__init_A_Unit48__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(251, 1); var root_111 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = A_arbace_go_check_env__init_A_const_69.GetRawRoot__O(); var arg_115 any = Lit_43; var arg_116 any; var root_117 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, A_arbace_go_check_env_obj_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = A_arbace_go_check_env__init_A_const_91; if linked_118 == nil { arg_116 = ifn_119.Invoke_O__O(arg_120) } else { arg_116 = linked_118.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_117, arg_120) }; if linked_112 == nil { return ifn_113.Invoke_O_O_O__O(arg_114, arg_115, arg_116) } else { return linked_112.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_111, arg_114, arg_115, arg_116) } }
func A_arbace_go_check_env__init_A_Unit49__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(252, 1); var root_121 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = A_arbace_go_check_env__init_A_const_69.GetRawRoot__O(); var arg_125 any = Lit_44; var arg_126 any; var root_127 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, A_arbace_go_check_env_obj_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = A_arbace_go_check_env__init_A_const_92; if linked_128 == nil { arg_126 = ifn_129.Invoke_O__O(arg_130) } else { arg_126 = linked_128.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_127, arg_130) }; if linked_122 == nil { return ifn_123.Invoke_O_O_O__O(arg_124, arg_125, arg_126) } else { return linked_122.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_121, arg_124, arg_125, arg_126) } }
func A_arbace_go_check_env__init_A_Unit50__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(253, 1); var root_131 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = A_arbace_go_check_env__init_A_const_69.GetRawRoot__O(); var arg_135 any = Lit_45; var arg_136 any; var root_137 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, A_arbace_go_check_env_obj_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = A_arbace_go_check_env__init_A_const_93; if linked_138 == nil { arg_136 = ifn_139.Invoke_O__O(arg_140) } else { arg_136 = linked_138.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_137, arg_140) }; if linked_132 == nil { return ifn_133.Invoke_O_O_O__O(arg_134, arg_135, arg_136) } else { return linked_132.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_131, arg_134, arg_135, arg_136) } }

func A_arbace_go_check_env__init_A_Unit51__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(255, 1); A_arbace_go_check_env__init_A_const_94.BindRoot_O__V(A_arbace_go_check_env__init_A_const_95); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_94; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_96)); return A_arbace_go_check_env__init_A_const_94 }



func A_arbace_go_check_env__init_A_Unit52__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(259, 1); { var seq_1719000091__1 any; var root_141 any = A_arbace_go_check_env__init_A_const_74.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = A_arbace_go_check_env__init_A_const_94.GetRawRoot__O(); if linked_142 == nil { seq_1719000091__1 = ifn_143.Invoke_O__O(arg_144) } else { seq_1719000091__1 = linked_142.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_141, arg_144) }; var chunk_1719000092__2 any; var count_1719000093__3 int64 = 0; var i_1719000094__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000094__4, count_1719000093__3) { var n__5 any = lang.Indexed_Cast(chunk_1719000092__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000094__4)); var root_161 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_163 lang.IFn
	if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = A_arbace_go_check_env__init_A_const_69.GetRawRoot__O(); var arg_165 any = n__5; var arg_166 any; var root_167 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, A_arbace_go_check_env_obj_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env__init_A_const_83, A_arbace_go_check_env__init_A_const_97, A_arbace_go_check_env__init_A_const_85, n__5, A_arbace_go_check_env__init_A_const_70, jrt.Boolean_TRUE.Ref())); if linked_168 == nil { arg_166 = ifn_169.Invoke_O__O(arg_170) } else { arg_166 = linked_168.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_167, arg_170) }; if linked_162 == nil { ifn_163.Invoke_O_O_O__O(arg_164, arg_165, arg_166) } else { linked_162.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_161, arg_164, arg_165, arg_166) }
//line :259:1
	seq_1719000091__1, chunk_1719000092__2, count_1719000093__3, i_1719000094__4 = seq_1719000091__1, chunk_1719000092__2, count_1719000093__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000094__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_145 any = A_arbace_go_check_env__init_A_const_74.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = seq_1719000091__1; if linked_146 == nil { temp__1927000414__auto____5 = ifn_147.Invoke_O__O(arg_148) } else { temp__1927000414__auto____5 = linked_146.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_145, arg_148) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1719000091__6 any = temp__1927000414__auto____5; var tmp1 any; var root_149 any = A_arbace_go_check_env__init_A_const_76.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = seq_1719000091__6; if linked_150 == nil { tmp1 = ifn_151.Invoke_O__O(arg_152) } else { tmp1 = linked_150.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_149, arg_152) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____7 any; var root_153 any = A_arbace_go_check_env__init_A_const_77.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = seq_1719000091__6; if linked_154 == nil { c__1927000678__auto____7 = ifn_155.Invoke_O__O(arg_156) } else { c__1927000678__auto____7 = linked_154.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_153, arg_156) }; var tmp2 any; var root_171 any = A_arbace_go_check_env__init_A_const_79.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = seq_1719000091__6; if linked_172 == nil { tmp2 = ifn_173.Invoke_O__O(arg_174) } else { tmp2 = linked_172.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_171, arg_174) }; seq_1719000091__1, chunk_1719000092__2, count_1719000093__3, i_1719000094__4 = tmp2, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__7 any; var root_157 any = A_arbace_go_check_env__init_A_const_78.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = seq_1719000091__6; if linked_158 == nil { n__7 = ifn_159.Invoke_O__O(arg_160) } else { n__7 = linked_158.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_157, arg_160) }
		var root_175 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = A_arbace_go_check_env__init_A_const_69.GetRawRoot__O(); var arg_179 any = n__7; var arg_180 any; var root_181 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, A_arbace_go_check_env_obj_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env__init_A_const_83, A_arbace_go_check_env__init_A_const_97, A_arbace_go_check_env__init_A_const_85, n__7, A_arbace_go_check_env__init_A_const_70, jrt.Boolean_TRUE.Ref())); if linked_182 == nil { arg_180 = ifn_183.Invoke_O__O(arg_184) } else { arg_180 = linked_182.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_181, arg_184) }; if linked_176 == nil { ifn_177.Invoke_O_O_O__O(arg_178, arg_179, arg_180) } else { linked_176.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_175, arg_178, arg_179, arg_180) }
//line :259:1
		var tmp3 any; var root_185 any = A_arbace_go_check_env__init_A_const_80.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = seq_1719000091__6; if linked_186 == nil { tmp3 = ifn_187.Invoke_O__O(arg_188) } else { tmp3 = linked_186.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_185, arg_188) }; seq_1719000091__1, chunk_1719000092__2, count_1719000093__3, i_1719000094__4 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } }
	panic("j2g: unreachable")
}


func A_arbace_go_check_env__init_A_Unit53__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(264, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_98; var tmp2 any = A_arbace_go_check_env_fn__1719000097_A_New(); var tmp3 *jrt.Class; var fncls__189 *jrt.Class = A_arbace_go_check_env_fn__1719000097_A_fn_class; if
							fncls__189 == nil { var fncls__189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_check_env_fn__1719000097_A_fn_class = fncls__189d; tmp3 = fncls__189d } else { tmp3 = fncls__189 }; /*line :264:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_99)); return A_arbace_go_check_env__init_A_const_98 }






func A_arbace_go_check_env__init_A_Unit54__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(271, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_100; var tmp2 any; var root_190 any = A_arbace_go_check_env__init_A_const_101.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var tmp3 any = A_arbace_go_check_env__init_A_const_102; var tmp4 any = A_arbace_go_check_env__init_A_const_85; var tmp5 any = A_arbace_go_check_env__init_A_const_103; var arg_193 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, Lit_10, tmp4, Lit_10, tmp5, A_arbace_go_check_env__init_A_const_98.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_104, jrt.Boolean_TRUE.Ref())); if linked_191 == nil { tmp2 = ifn_192.Invoke_O__O(arg_193) } else { tmp2 = linked_191.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_190, arg_193) }; tmp1.BindRoot_O__V(tmp2); var tmp6 *lang.Var = A_arbace_go_check_env__init_A_const_100; tmp6.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_105)); return A_arbace_go_check_env__init_A_const_100 }



type A_arbace_go_check_env__init_A struct{ jrt.Object }

var A_arbace_go_check_env__init_A_const_pool *jrt.RefArray

var A_arbace_go_check_env__init_A_const_0 *lang.Var

var A_arbace_go_check_env__init_A_const_1 any

var A_arbace_go_check_env__init_A_const_2 any

var A_arbace_go_check_env__init_A_const_3 any

var A_arbace_go_check_env__init_A_const_4 *lang.Var

var A_arbace_go_check_env__init_A_const_5 any

var A_arbace_go_check_env__init_A_const_6 *lang.Var

var A_arbace_go_check_env__init_A_const_7 any

var A_arbace_go_check_env__init_A_const_8 *lang.Var

var A_arbace_go_check_env__init_A_const_9 any

var A_arbace_go_check_env__init_A_const_10 *lang.Var

var A_arbace_go_check_env__init_A_const_11 any

var A_arbace_go_check_env__init_A_const_12 *lang.Var

var A_arbace_go_check_env__init_A_const_13 any

var A_arbace_go_check_env__init_A_const_14 *lang.Var

var A_arbace_go_check_env__init_A_const_15 any

var A_arbace_go_check_env__init_A_const_16 *lang.Var

var A_arbace_go_check_env__init_A_const_17 any

var A_arbace_go_check_env__init_A_const_18 *lang.Var

var A_arbace_go_check_env__init_A_const_19 any

var A_arbace_go_check_env__init_A_const_20 *lang.Var

var A_arbace_go_check_env__init_A_const_21 any

var A_arbace_go_check_env__init_A_const_22 *lang.Var

var A_arbace_go_check_env__init_A_const_23 any

var A_arbace_go_check_env__init_A_const_24 *lang.Var

var A_arbace_go_check_env__init_A_const_25 any

var A_arbace_go_check_env__init_A_const_26 *lang.Var

var A_arbace_go_check_env__init_A_const_27 any

var A_arbace_go_check_env__init_A_const_28 *lang.Var

var A_arbace_go_check_env__init_A_const_29 any

var A_arbace_go_check_env__init_A_const_30 *lang.Var

var A_arbace_go_check_env__init_A_const_31 any

var A_arbace_go_check_env__init_A_const_32 *lang.Var

var A_arbace_go_check_env__init_A_const_33 any

var A_arbace_go_check_env__init_A_const_34 *lang.Var

var A_arbace_go_check_env__init_A_const_35 any

var A_arbace_go_check_env__init_A_const_36 *lang.Var

var A_arbace_go_check_env__init_A_const_37 any

var A_arbace_go_check_env__init_A_const_38 *lang.Var

var A_arbace_go_check_env__init_A_const_39 any

var A_arbace_go_check_env__init_A_const_40 *lang.Var

var A_arbace_go_check_env__init_A_const_41 any

var A_arbace_go_check_env__init_A_const_42 any

var A_arbace_go_check_env__init_A_const_43 *lang.Var

var A_arbace_go_check_env__init_A_const_44 any

var A_arbace_go_check_env__init_A_const_45 *lang.Var

var A_arbace_go_check_env__init_A_const_46 any

var A_arbace_go_check_env__init_A_const_47 *lang.Var

var A_arbace_go_check_env__init_A_const_48 any

var A_arbace_go_check_env__init_A_const_49 *lang.Var

var A_arbace_go_check_env__init_A_const_50 any

var A_arbace_go_check_env__init_A_const_51 *lang.Var

var A_arbace_go_check_env__init_A_const_52 any

var A_arbace_go_check_env__init_A_const_53 *lang.Var

var A_arbace_go_check_env__init_A_const_54 any

var A_arbace_go_check_env__init_A_const_55 *lang.Var

var A_arbace_go_check_env__init_A_const_56 any

var A_arbace_go_check_env__init_A_const_57 *lang.Var

var A_arbace_go_check_env__init_A_const_58 any

var A_arbace_go_check_env__init_A_const_59 *lang.Var

var A_arbace_go_check_env__init_A_const_60 any

var A_arbace_go_check_env__init_A_const_61 *lang.Var

var A_arbace_go_check_env__init_A_const_62 any

var A_arbace_go_check_env__init_A_const_63 *lang.Var

var A_arbace_go_check_env__init_A_const_64 any

var A_arbace_go_check_env__init_A_const_65 *lang.Var

var A_arbace_go_check_env__init_A_const_66 any

var A_arbace_go_check_env__init_A_const_67 *lang.Var

var A_arbace_go_check_env__init_A_const_68 any

var A_arbace_go_check_env__init_A_const_69 *lang.Var

var A_arbace_go_check_env__init_A_const_70 *lang.Keyword

var A_arbace_go_check_env__init_A_const_71 any

var A_arbace_go_check_env__init_A_const_72 *lang.Var

var A_arbace_go_check_env__init_A_const_73 any

var A_arbace_go_check_env__init_A_const_74 *lang.Var

var A_arbace_go_check_env__init_A_const_75 any

var A_arbace_go_check_env__init_A_const_76 *lang.Var

var A_arbace_go_check_env__init_A_const_77 *lang.Var

var A_arbace_go_check_env__init_A_const_78 *lang.Var

var A_arbace_go_check_env__init_A_const_79 *lang.Var

var A_arbace_go_check_env__init_A_const_80 *lang.Var

var A_arbace_go_check_env__init_A_const_81 *lang.Var

var A_arbace_go_check_env__init_A_const_82 any

var A_arbace_go_check_env__init_A_const_83 *lang.Keyword

var A_arbace_go_check_env__init_A_const_84 *lang.Keyword

var A_arbace_go_check_env__init_A_const_85 *lang.Keyword

var A_arbace_go_check_env__init_A_const_86 *lang.Keyword

var A_arbace_go_check_env__init_A_const_87 *lang.Keyword

var A_arbace_go_check_env__init_A_const_88 *lang.Var

var A_arbace_go_check_env__init_A_const_89 any

var A_arbace_go_check_env__init_A_const_90 any

var A_arbace_go_check_env__init_A_const_91 any

var A_arbace_go_check_env__init_A_const_92 any

var A_arbace_go_check_env__init_A_const_93 any

var A_arbace_go_check_env__init_A_const_94 *lang.Var

var A_arbace_go_check_env__init_A_const_95 any

var A_arbace_go_check_env__init_A_const_96 any

var A_arbace_go_check_env__init_A_const_97 *lang.Keyword

var A_arbace_go_check_env__init_A_const_98 *lang.Var

var A_arbace_go_check_env__init_A_const_99 any

var A_arbace_go_check_env__init_A_const_100 *lang.Var

var A_arbace_go_check_env__init_A_const_101 *lang.Var

var A_arbace_go_check_env__init_A_const_102 *lang.Keyword

var A_arbace_go_check_env__init_A_const_103 *lang.Keyword

var A_arbace_go_check_env__init_A_const_104 *lang.Keyword

var A_arbace_go_check_env__init_A_const_105 any

var A_arbace_go_check_env__init_A_init jrt.ClassInit

func A_arbace_go_check_env__init_A_Init() { if !A_arbace_go_check_env__init_A_init.Done() { A_arbace_go_check_env__init_A_init.Run(A_arbace_go_check_env__init_A_clinit) } }

func A_arbace_go_check_env__init_A_clinit() { A_arbace_go_check_env__init_A_clinit_p0(); A_arbace_go_check_env__init_A_clinit_p1(); A_arbace_go_check_env__init_A_clinit_p2(); A_arbace_go_check_env__init_A_clinit_p3(); A_arbace_go_check_env__init_A_clinit_p4(); A_arbace_go_check_env__init_A_clinit_p5(); A_arbace_go_check_env__init_A_clinit_p6(); A_arbace_go_check_env__init_A_clinit_p7(); A_arbace_go_check_env__init_A_clinit_p8() }

func A_arbace_go_check_env__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_env__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_11, 179); A_arbace_go_check_env__init_A_const_0 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[73]); A_arbace_go_check_env__init_A_const_1 = A_arbace_go_check_env__init_A_const_pool.A[74]; A_arbace_go_check_env__init_A_const_2 = A_arbace_go_check_env__init_A_const_pool.A[75]; A_arbace_go_check_env__init_A_const_3 = A_arbace_go_check_env__init_A_const_pool.A[76]; A_arbace_go_check_env__init_A_const_4 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[77]); A_arbace_go_check_env__init_A_const_5 = A_arbace_go_check_env__init_A_const_pool.A[78]; A_arbace_go_check_env__init_A_const_6 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[79]); A_arbace_go_check_env__init_A_const_7 = A_arbace_go_check_env__init_A_const_pool.A[80]; A_arbace_go_check_env__init_A_const_8 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[81]); A_arbace_go_check_env__init_A_const_9 = A_arbace_go_check_env__init_A_const_pool.A[82]; A_arbace_go_check_env__init_A_const_10 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[83]); A_arbace_go_check_env__init_A_const_11 = A_arbace_go_check_env__init_A_const_pool.A[84]; A_arbace_go_check_env__init_A_const_12 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[85]) }

func A_arbace_go_check_env__init_A_clinit_p1() { A_arbace_go_check_env__init_A_const_13 = A_arbace_go_check_env__init_A_const_pool.A[86]; A_arbace_go_check_env__init_A_const_14 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[87]); A_arbace_go_check_env__init_A_const_15 = A_arbace_go_check_env__init_A_const_pool.A[88]; A_arbace_go_check_env__init_A_const_16 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[89]); A_arbace_go_check_env__init_A_const_17 = A_arbace_go_check_env__init_A_const_pool.A[90]; A_arbace_go_check_env__init_A_const_18 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[91]); A_arbace_go_check_env__init_A_const_19 = A_arbace_go_check_env__init_A_const_pool.A[92]; A_arbace_go_check_env__init_A_const_20 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[93]); A_arbace_go_check_env__init_A_const_21 = A_arbace_go_check_env__init_A_const_pool.A[94]; A_arbace_go_check_env__init_A_const_22 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[95]); A_arbace_go_check_env__init_A_const_23 = A_arbace_go_check_env__init_A_const_pool.A[96]; A_arbace_go_check_env__init_A_const_24 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[97]); A_arbace_go_check_env__init_A_const_25 = A_arbace_go_check_env__init_A_const_pool.A[98] }

func A_arbace_go_check_env__init_A_clinit_p2() { A_arbace_go_check_env__init_A_const_26 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[99]); A_arbace_go_check_env__init_A_const_27 = A_arbace_go_check_env__init_A_const_pool.A[100]; A_arbace_go_check_env__init_A_const_28 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[101]); A_arbace_go_check_env__init_A_const_29 = A_arbace_go_check_env__init_A_const_pool.A[102]; A_arbace_go_check_env__init_A_const_30 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[103]); A_arbace_go_check_env__init_A_const_31 = A_arbace_go_check_env__init_A_const_pool.A[104]; A_arbace_go_check_env__init_A_const_32 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[105]); A_arbace_go_check_env__init_A_const_33 = A_arbace_go_check_env__init_A_const_pool.A[106]; A_arbace_go_check_env__init_A_const_34 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[107]); A_arbace_go_check_env__init_A_const_35 = A_arbace_go_check_env__init_A_const_pool.A[108]; A_arbace_go_check_env__init_A_const_36 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[109]); A_arbace_go_check_env__init_A_const_37 = A_arbace_go_check_env__init_A_const_pool.A[110]; A_arbace_go_check_env__init_A_const_38 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[111]) }

func A_arbace_go_check_env__init_A_clinit_p3() { A_arbace_go_check_env__init_A_const_39 = A_arbace_go_check_env__init_A_const_pool.A[112]; A_arbace_go_check_env__init_A_const_40 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[113]); A_arbace_go_check_env__init_A_const_41 = A_arbace_go_check_env__init_A_const_pool.A[114]; A_arbace_go_check_env__init_A_const_42 = A_arbace_go_check_env__init_A_const_pool.A[115]; A_arbace_go_check_env__init_A_const_43 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[116]); A_arbace_go_check_env__init_A_const_44 = A_arbace_go_check_env__init_A_const_pool.A[117]; A_arbace_go_check_env__init_A_const_45 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[118]); A_arbace_go_check_env__init_A_const_46 = A_arbace_go_check_env__init_A_const_pool.A[119]; A_arbace_go_check_env__init_A_const_47 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[120]); A_arbace_go_check_env__init_A_const_48 = A_arbace_go_check_env__init_A_const_pool.A[121]; A_arbace_go_check_env__init_A_const_49 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[122]); A_arbace_go_check_env__init_A_const_50 = A_arbace_go_check_env__init_A_const_pool.A[123]; A_arbace_go_check_env__init_A_const_51 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[124]); A_arbace_go_check_env__init_A_const_52 = A_arbace_go_check_env__init_A_const_pool.A[125] }

func A_arbace_go_check_env__init_A_clinit_p4() { A_arbace_go_check_env__init_A_const_53 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[126]); A_arbace_go_check_env__init_A_const_54 = A_arbace_go_check_env__init_A_const_pool.A[127]; A_arbace_go_check_env__init_A_const_55 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[128]); A_arbace_go_check_env__init_A_const_56 = A_arbace_go_check_env__init_A_const_pool.A[129]; A_arbace_go_check_env__init_A_const_57 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[130]); A_arbace_go_check_env__init_A_const_58 = A_arbace_go_check_env__init_A_const_pool.A[131]; A_arbace_go_check_env__init_A_const_59 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[132]); A_arbace_go_check_env__init_A_const_60 = A_arbace_go_check_env__init_A_const_pool.A[133]; A_arbace_go_check_env__init_A_const_61 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[134]); A_arbace_go_check_env__init_A_const_62 = A_arbace_go_check_env__init_A_const_pool.A[135]; A_arbace_go_check_env__init_A_const_63 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[136]); A_arbace_go_check_env__init_A_const_64 = A_arbace_go_check_env__init_A_const_pool.A[137]; A_arbace_go_check_env__init_A_const_65 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[138]) }

func A_arbace_go_check_env__init_A_clinit_p5() { A_arbace_go_check_env__init_A_const_66 = A_arbace_go_check_env__init_A_const_pool.A[139]; A_arbace_go_check_env__init_A_const_67 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[140]); A_arbace_go_check_env__init_A_const_68 = A_arbace_go_check_env__init_A_const_pool.A[141]; A_arbace_go_check_env__init_A_const_69 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[142]); A_arbace_go_check_env__init_A_const_70 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[143]); A_arbace_go_check_env__init_A_const_71 = A_arbace_go_check_env__init_A_const_pool.A[144]; A_arbace_go_check_env__init_A_const_72 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[145]); A_arbace_go_check_env__init_A_const_73 = A_arbace_go_check_env__init_A_const_pool.A[146]; A_arbace_go_check_env__init_A_const_74 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[147]); A_arbace_go_check_env__init_A_const_75 = A_arbace_go_check_env__init_A_const_pool.A[148]; A_arbace_go_check_env__init_A_const_76 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[149]); A_arbace_go_check_env__init_A_const_77 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[150]); A_arbace_go_check_env__init_A_const_78 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[151]) }

func A_arbace_go_check_env__init_A_clinit_p6() { A_arbace_go_check_env__init_A_const_79 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[152]); A_arbace_go_check_env__init_A_const_80 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[153]); A_arbace_go_check_env__init_A_const_81 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[154]); A_arbace_go_check_env__init_A_const_82 = A_arbace_go_check_env__init_A_const_pool.A[155]; A_arbace_go_check_env__init_A_const_83 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[156]); A_arbace_go_check_env__init_A_const_84 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[157]); A_arbace_go_check_env__init_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[158]); A_arbace_go_check_env__init_A_const_86 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[159]); A_arbace_go_check_env__init_A_const_87 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[160]); A_arbace_go_check_env__init_A_const_88 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[161]); A_arbace_go_check_env__init_A_const_89 = A_arbace_go_check_env__init_A_const_pool.A[162]; A_arbace_go_check_env__init_A_const_90 = A_arbace_go_check_env__init_A_const_pool.A[163]; A_arbace_go_check_env__init_A_const_91 = A_arbace_go_check_env__init_A_const_pool.A[164] }

func A_arbace_go_check_env__init_A_clinit_p7() { A_arbace_go_check_env__init_A_const_92 = A_arbace_go_check_env__init_A_const_pool.A[165]; A_arbace_go_check_env__init_A_const_93 = A_arbace_go_check_env__init_A_const_pool.A[166]; A_arbace_go_check_env__init_A_const_94 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[167]); A_arbace_go_check_env__init_A_const_95 = A_arbace_go_check_env__init_A_const_pool.A[168]; A_arbace_go_check_env__init_A_const_96 = A_arbace_go_check_env__init_A_const_pool.A[169]; A_arbace_go_check_env__init_A_const_97 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[170]); A_arbace_go_check_env__init_A_const_98 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[171]); A_arbace_go_check_env__init_A_const_99 = A_arbace_go_check_env__init_A_const_pool.A[172]; A_arbace_go_check_env__init_A_const_100 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[173]); A_arbace_go_check_env__init_A_const_101 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[174]); A_arbace_go_check_env__init_A_const_102 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[175]); A_arbace_go_check_env__init_A_const_103 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[176]); A_arbace_go_check_env__init_A_const_104 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[177]) }

func A_arbace_go_check_env__init_A_clinit_p8() { A_arbace_go_check_env__init_A_const_105 = A_arbace_go_check_env__init_A_const_pool.A[178] }

func A_arbace_go_check_env__init_A_New() *A_arbace_go_check_env__init_A { A_arbace_go_check_env__init_A_Init(); t := &A_arbace_go_check_env__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env__init_A) Ctor() {}

func (t *A_arbace_go_check_env__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env__init_A_class }

func (t *A_arbace_go_check_env__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env__init_A); return ok }

func A_arbace_go_check_env__init_A_Cast(x any) *A_arbace_go_check_env__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env__init_A_class)) }; return v }
