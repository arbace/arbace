//line aot_arbace_go_check_env__init.ae:1
package aot_arbace_go_check_env

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_env__init_A_Unit0__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_check_env__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env__init_A_const_1) }
//line :1:1
func A_arbace_go_check_env__init_A_Unit1__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_check_env__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_2)) }
//line :1:1
func A_arbace_go_check_env__init_A_Unit2__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, nil); A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_go_check_env__init_A_Unit3__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_check_env__init_A_const_1)).Equals_O__Z(A_arbace_go_check_env__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_go_check_env_eval1719000008_fn__1719000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, nil); A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_go_check_env__init_A_Load__O() any { A_arbace_go_check_env__init_A_Init(); jrt.StartCheck(); A_arbace_go_check_env__init_A_Unit0__O(); A_arbace_go_check_env__init_A_Unit1__O(); A_arbace_go_check_env__init_A_Unit2__O(); A_arbace_go_check_env__init_A_Unit3__O(); A_arbace_go_check_env__init_A_Unit4__O(); A_arbace_go_check_env__init_A_Unit5__O(); A_arbace_go_check_env__init_A_Unit6__O(); A_arbace_go_check_env__init_A_Unit7__O(); A_arbace_go_check_env__init_A_Unit8__O(); A_arbace_go_check_env__init_A_Unit9__O(); A_arbace_go_check_env__init_A_Unit10__O(); A_arbace_go_check_env__init_A_Unit11__O(); A_arbace_go_check_env__init_A_Unit12__O(); A_arbace_go_check_env__init_A_Unit13__O(); A_arbace_go_check_env__init_A_Unit14__O(); A_arbace_go_check_env__init_A_Unit15__O(); A_arbace_go_check_env__init_A_Unit16__O(); A_arbace_go_check_env__init_A_Unit17__O(); A_arbace_go_check_env__init_A_Unit18__O(); A_arbace_go_check_env__init_A_Unit19__O(); A_arbace_go_check_env__init_A_Unit20__O(); A_arbace_go_check_env__init_A_Unit21__O(); A_arbace_go_check_env__init_A_Unit22__O(); A_arbace_go_check_env__init_A_Unit23__O(); A_arbace_go_check_env__init_A_Unit24__O(); A_arbace_go_check_env__init_A_Unit25__O(); A_arbace_go_check_env__init_A_Unit26__O(); A_arbace_go_check_env__init_A_Unit27__O(); A_arbace_go_check_env__init_A_Unit28__O(); A_arbace_go_check_env__init_A_Unit29__O(); A_arbace_go_check_env__init_A_Unit30__O(); A_arbace_go_check_env__init_A_Unit31__O(); A_arbace_go_check_env__init_A_Unit32__O(); A_arbace_go_check_env__init_A_Unit33__O(); A_arbace_go_check_env__init_A_Unit34__O(); A_arbace_go_check_env__init_A_Unit35__O(); A_arbace_go_check_env__init_A_Unit36__O(); A_arbace_go_check_env__init_A_Unit37__O(); A_arbace_go_check_env__init_A_Unit38__O(); A_arbace_go_check_env__init_A_Unit39__O(); A_arbace_go_check_env__init_A_Unit40__O(); A_arbace_go_check_env__init_A_Unit41__O(); A_arbace_go_check_env__init_A_Unit42__O(); A_arbace_go_check_env__init_A_Unit43__O(); A_arbace_go_check_env__init_A_Unit44__O(); A_arbace_go_check_env__init_A_Unit45__O(); A_arbace_go_check_env__init_A_Unit46__O(); A_arbace_go_check_env__init_A_Unit47__O(); A_arbace_go_check_env__init_A_Unit48__O(); A_arbace_go_check_env__init_A_Unit49__O(); A_arbace_go_check_env__init_A_Unit50__O(); A_arbace_go_check_env__init_A_Unit51__O(); A_arbace_go_check_env__init_A_Unit52__O(); A_arbace_go_check_env__init_A_Unit53__O(); A_arbace_go_check_env__init_A_Unit54__O(); A_arbace_go_check_env__init_A_Unit55__O(); A_arbace_go_check_env__init_A_Unit56__O(); A_arbace_go_check_env__init_A_Unit57__O(); return nil }









func A_arbace_go_check_env__init_A_Unit4__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_go_check_env_obj_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_env_obj_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, nil); A_arbace_go_check_env_obj_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_5)); return A_arbace_go_check_env__init_A_const_4 }
func A_arbace_go_check_env__init_A_Unit5__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_go_check_env_o_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_env_o_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, nil); A_arbace_go_check_env_o_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_7)); return A_arbace_go_check_env__init_A_const_6 }
func A_arbace_go_check_env__init_A_Unit6__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_go_check_env_oset_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_env_oset_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, nil); A_arbace_go_check_env_oset_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_9)); return A_arbace_go_check_env__init_A_const_8 }
func A_arbace_go_check_env__init_A_Unit7__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_go_check_env_obj_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_env_obj_QMARK__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, nil); A_arbace_go_check_env_obj_QMARK__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_11)); return A_arbace_go_check_env__init_A_const_10 }



func A_arbace_go_check_env__init_A_Unit8__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_go_check_env_scope_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_env_scope_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, nil); A_arbace_go_check_env_scope_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_13)); return A_arbace_go_check_env__init_A_const_12 }

func A_arbace_go_check_env__init_A_Unit9__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_go_check_env_scope_lookup_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_env_scope_lookup_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_go_check_env_scope_lookup_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_15)); return A_arbace_go_check_env__init_A_const_14 }








func A_arbace_go_check_env__init_A_Unit10__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_go_check_env_scope_get_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_check_env_scope_get_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); A_arbace_go_check_env_scope_get_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_17)); return A_arbace_go_check_env__init_A_const_16 }
func A_arbace_go_check_env__init_A_Unit11__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_go_check_env_scope_put_BANG__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_check_env_scope_put_BANG__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, nil); A_arbace_go_check_env_scope_put_BANG__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_19)); return A_arbace_go_check_env__init_A_const_18 }



func A_arbace_go_check_env__init_A_Unit12__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); A_arbace_go_check_env__init_A_const_20.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_21)); return A_arbace_go_check_env__init_A_const_20.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit13__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); A_arbace_go_check_env__init_A_const_22.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_23)); return A_arbace_go_check_env__init_A_const_22.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit14__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); A_arbace_go_check_env__init_A_const_24.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_24; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_25)); return A_arbace_go_check_env__init_A_const_24.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_check_env__init_A_Unit15__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); A_arbace_go_check_env__init_A_const_26.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_27)); return A_arbace_go_check_env__init_A_const_26.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check_env__init_A_Unit16__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); A_arbace_go_check_env__init_A_const_28.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_29)); return A_arbace_go_check_env__init_A_const_28.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check_env__init_A_Unit17__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); A_arbace_go_check_env__init_A_const_30.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_31)); return A_arbace_go_check_env__init_A_const_30.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check_env__init_A_Unit18__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_go_check_env_error_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_check_env_error_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, nil); A_arbace_go_check_env_error_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_33)); return A_arbace_go_check_env__init_A_const_32 }















func A_arbace_go_check_env__init_A_Unit19__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(80, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_go_check_env_line_of_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_check_env_line_of_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, nil); A_arbace_go_check_env_line_of_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_35)); return A_arbace_go_check_env__init_A_const_34 }





func A_arbace_go_check_env__init_A_Unit20__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(86, 1); A_arbace_go_check_env__init_A_const_36.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_36; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_37)); return A_arbace_go_check_env__init_A_const_36.SetDynamic_Z__Var(true).Ref() }

func A_arbace_go_check_env__init_A_Unit21__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(88, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_39)); return A_arbace_go_check_env__init_A_const_38 }

func A_arbace_go_check_env__init_A_Unit22__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(90, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_go_check_env_end_line_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_check_env_end_line_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, nil); A_arbace_go_check_env_end_line_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_41)); return A_arbace_go_check_env__init_A_const_40 }










func A_arbace_go_check_env__init_A_Unit23__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_go_check_env_child_line_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_check_env_child_line_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, nil); A_arbace_go_check_env_child_line_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_42)); return A_arbace_go_check_env__init_A_const_38 }



















func A_arbace_go_check_env__init_A_Unit24__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(121, 1); A_arbace_go_check_env__init_A_const_43.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_44)); return A_arbace_go_check_env__init_A_const_43.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_env__init_A_Unit25__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_45; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__30 any = A_arbace_go_check_env_with_child_line_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_check_env_with_child_line_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, true, nil); A_arbace_go_check_env_with_child_line_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__30, tmp3, nil, 4); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_46)); return A_arbace_go_check_env__init_A_const_45 }
//line :126:1
func A_arbace_go_check_env__init_A_Unit26__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); A_arbace_go_check_env__init_A_const_45.SetMacro__V(); return nil }
//line :126:1
func A_arbace_go_check_env__init_A_Unit27__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); return A_arbace_go_check_env__init_A_const_45 }







func A_arbace_go_check_env__init_A_Unit28__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(134, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_go_check_env_current_line_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_env_current_line_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); A_arbace_go_check_env_current_line_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_48)); return A_arbace_go_check_env__init_A_const_47 }




func A_arbace_go_check_env__init_A_Unit29__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); A_arbace_go_check_env__init_A_const_49.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_49; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_50)); return A_arbace_go_check_env__init_A_const_49.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_check_env__init_A_Unit30__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(145, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_go_check_env_size_type_BANG__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_check_env_size_type_BANG__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, nil); A_arbace_go_check_env_size_type_BANG__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_52)); return A_arbace_go_check_env__init_A_const_51 }






func A_arbace_go_check_env__init_A_Unit31__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(152, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_53; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__36 any = A_arbace_go_check_env_err_BANG__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_check_env_err_BANG__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, true, nil); A_arbace_go_check_env_err_BANG__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__36, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_54)); return A_arbace_go_check_env__init_A_const_53 }






func A_arbace_go_check_env__init_A_Unit32__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(159, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_go_check_env_generic_BANG__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_check_env_generic_BANG__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); A_arbace_go_check_env_generic_BANG__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_56)); return A_arbace_go_check_env__init_A_const_55 }





func A_arbace_go_check_env__init_A_Unit33__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(165, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_go_check_env_unsupported_BANG__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_check_env_unsupported_BANG__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, nil); A_arbace_go_check_env_unsupported_BANG__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_58)); return A_arbace_go_check_env__init_A_const_57 }









func A_arbace_go_check_env__init_A_Unit34__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(175, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_go_check_env_unsupported_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_check_env_unsupported_QMARK__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); A_arbace_go_check_env_unsupported_QMARK__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_60)); return A_arbace_go_check_env__init_A_const_59 }



func A_arbace_go_check_env__init_A_Unit35__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(179, 1); A_arbace_go_check_env__init_A_const_61.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_61; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_62)); return A_arbace_go_check_env__init_A_const_61.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_check_env__init_A_Unit36__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(184, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_go_check_env_verified_BANG__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_check_env_verified_BANG__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_go_check_env_verified_BANG__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_64)); return A_arbace_go_check_env__init_A_const_63 }












func A_arbace_go_check_env__init_A_Unit37__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(197, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_go_check_env_annotation_error_BANG__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_check_env_annotation_error_BANG__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, nil); A_arbace_go_check_env_annotation_error_BANG__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_66)); return A_arbace_go_check_env__init_A_const_65 }







func A_arbace_go_check_env__init_A_Unit38__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(205, 1); A_arbace_go_check_env__init_A_const_67.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_67; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_68)); return A_arbace_go_check_env__init_A_const_67.SetDynamic_Z__Var(true).Ref() }






func A_arbace_go_check_env__init_A_Unit39__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(212, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_go_check_env_at_of_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_check_env_at_of_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); A_arbace_go_check_env_at_of_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_70)); return A_arbace_go_check_env__init_A_const_69 }




func A_arbace_go_check_env__init_A_Unit40__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(217, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_go_check_env_answer_BANG__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_check_env_answer_BANG__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, nil); A_arbace_go_check_env_answer_BANG__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_72)); return A_arbace_go_check_env__init_A_const_71 }













func A_arbace_go_check_env__init_A_Unit41__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(231, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_go_check_env_unanswer_BANG__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_check_env_unanswer_BANG__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, nil); A_arbace_go_check_env_unanswer_BANG__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_74)); return A_arbace_go_check_env__init_A_const_73 }









func A_arbace_go_check_env__init_A_Unit42__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(241, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_75; var tmp2 any; var root_53 any = A_arbace_go_check_env__init_A_const_12.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, A_arbace_go_check_env_scope_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any; var arg_57 any = A_arbace_go_check_env__init_A_const_76; if linked_54 == nil { tmp2 = ifn_55.Invoke_O_O__O(arg_56, arg_57) } else { tmp2 = linked_54.(*A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_53, arg_56, arg_57) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_check_env__init_A_const_75; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_77)); return A_arbace_go_check_env__init_A_const_75 }

func A_arbace_go_check_env__init_A_Unit43__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(243, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__59 any = A_arbace_go_check_env_def_type_BANG__A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_go_check_env_def_type_BANG__A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, nil); A_arbace_go_check_env_def_type_BANG__A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__59, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_79)); return A_arbace_go_check_env__init_A_const_78 }




func A_arbace_go_check_env__init_A_Unit44__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(248, 1); { var seq_1719000063__1 any; var root_60 any = A_arbace_go_check_env__init_A_const_80.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = A_arbace_go_check_env__init_A_const_81; if linked_61 == nil { seq_1719000063__1 = ifn_62.Invoke_O__O(arg_63) } else { seq_1719000063__1 = linked_61.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_60, arg_63) }; var chunk_1719000064__2 any; var count_1719000065__3 int64 = 0; var i_1719000066__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000066__4, count_1719000065__3) { var vec__1719000068__5 any = lang.Indexed_Cast(chunk_1719000064__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000066__4)); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000068__5, lang.RT_IntCast_J__I_NoInit(0), nil); var kw__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000068__5, lang.RT_IntCast_J__I_NoInit(1), nil); var root_80 any = A_arbace_go_check_env__init_A_const_78.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, A_arbace_go_check_env_def_type_BANG__A_fn_class); var ifn_82 lang.IFn




	if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = n__6; var arg_84 any = kw__7; if linked_81 == nil { ifn_82.Invoke_O_O__O(arg_83, arg_84) } else { linked_81.(*A_arbace_go_check_env_def_type_BANG__A).Invoke_O_O_O__O(root_80, arg_83, arg_84) }
//line :248:1
	seq_1719000063__1, chunk_1719000064__2, count_1719000065__3, i_1719000066__4 = seq_1719000063__1, chunk_1719000064__2, count_1719000065__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000066__4); continue L1



} else {
//line :248:1
	var temp__1927000414__auto____5 any; var root_64 any = A_arbace_go_check_env__init_A_const_80.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = seq_1719000063__1; if linked_65 == nil { temp__1927000414__auto____5 = ifn_66.Invoke_O__O(arg_67) } else { temp__1927000414__auto____5 = linked_65.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_64, arg_67) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1719000063__6 any = temp__1927000414__auto____5; var tmp1 any; var root_68 any = A_arbace_go_check_env__init_A_const_82.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = seq_1719000063__6; if linked_69 == nil { tmp1 = ifn_70.Invoke_O__O(arg_71) } else { tmp1 = linked_69.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_68, arg_71) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____7 any; var root_72 any = A_arbace_go_check_env__init_A_const_83.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = seq_1719000063__6; if linked_73 == nil { c__1927000678__auto____7 = ifn_74.Invoke_O__O(arg_75) } else { c__1927000678__auto____7 = linked_73.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_72, arg_75) }; var tmp2 any; var root_85 any = A_arbace_go_check_env__init_A_const_85.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = seq_1719000063__6; if linked_86 == nil { tmp2 = ifn_87.Invoke_O__O(arg_88) } else { tmp2 = linked_86.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_85, arg_88) }; seq_1719000063__1, chunk_1719000064__2, count_1719000065__3, i_1719000066__4 = tmp2, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1719000071__7 any; var root_76 any = A_arbace_go_check_env__init_A_const_84.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = seq_1719000063__6; if linked_77 == nil { vec__1719000071__7 = ifn_78.Invoke_O__O(arg_79) } else { vec__1719000071__7 = linked_77.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_76, arg_79) }; var n__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000071__7, lang.RT_IntCast_J__I_NoInit(0), nil); var kw__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000071__7, lang.RT_IntCast_J__I_NoInit(1), nil); var root_89 any = A_arbace_go_check_env__init_A_const_78.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, A_arbace_go_check_env_def_type_BANG__A_fn_class); var ifn_91 lang.IFn




		if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = n__8; var arg_93 any = kw__9; if linked_90 == nil { ifn_91.Invoke_O_O__O(arg_92, arg_93) } else { linked_90.(*A_arbace_go_check_env_def_type_BANG__A).Invoke_O_O_O__O(root_89, arg_92, arg_93) }
//line :248:1
		var tmp3 any; var root_94 any = A_arbace_go_check_env__init_A_const_86.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = seq_1719000063__6; if linked_95 == nil { tmp3 = ifn_96.Invoke_O__O(arg_97) } else { tmp3 = linked_95.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_94, arg_97) }; seq_1719000063__1, chunk_1719000064__2, count_1719000065__3, i_1719000066__4 = tmp3, nil, 0, 0; continue L1 } } else { return nil
		}
}
}
}
	panic("j2g: unreachable")
}
func A_arbace_go_check_env__init_A_Unit45__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(255, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_87; var tmp2 *lang.Compiler_AOTFn; var fnbody__99 any = A_arbace_go_check_env_fn__1719000075_A_New(); var tmp3 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_go_check_env_fn__1719000075_A_fn_class; if
							fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); A_arbace_go_check_env_fn__1719000075_A_fn_class = fncls__98d; tmp3 = fncls__98d } else { tmp3 = fncls__98 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__99, tmp3, nil); /*line :255:1*/tmp1.BindRoot_O__V(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_88)); return A_arbace_go_check_env__init_A_const_87 }





func A_arbace_go_check_env__init_A_Unit46__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(261, 1); var root_100 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = A_arbace_go_check_env__init_A_const_75.GetRawRoot__O(); var arg_104 any = Lit_40; var arg_105 any; var root_106 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, A_arbace_go_check_env_obj_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_89; var tmp2 any = A_arbace_go_check_env__init_A_const_90; var tmp3 any = A_arbace_go_check_env__init_A_const_91; var tmp4 any = A_arbace_go_check_env__init_A_const_90; var arg_109 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_40, tmp4, A_arbace_go_check_env__init_A_const_87.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_76, jrt.Boolean_TRUE.Ref())); if linked_107 == nil { arg_105 = ifn_108.Invoke_O__O(arg_109) } else { arg_105 = linked_107.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_106, arg_109) }; if linked_101 == nil { return ifn_102.Invoke_O_O_O__O(arg_103, arg_104, arg_105) } else { return linked_101.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_100, arg_103, arg_104, arg_105) } }
func A_arbace_go_check_env__init_A_Unit47__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(262, 1); var root_110 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = A_arbace_go_check_env__init_A_const_75.GetRawRoot__O(); var arg_114 any = Lit_41; var arg_115 any; var root_116 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, A_arbace_go_check_env_obj_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_89; var tmp2 any = A_arbace_go_check_env__init_A_const_90; var tmp3 any = A_arbace_go_check_env__init_A_const_91; var tmp4 any = A_arbace_go_check_env__init_A_const_90; var arg_119 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_41, tmp4, lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_env__init_A_const_93, lang.PersistentVector_EMPTY.Ref(), nil), A_arbace_go_check_env__init_A_const_92, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_env__init_A_const_76, jrt.Boolean_TRUE.Ref())); if linked_117 == nil { arg_115 = ifn_118.Invoke_O__O(arg_119) } else { arg_115 = linked_117.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_116, arg_119) }; if linked_111 == nil { return ifn_112.Invoke_O_O_O__O(arg_113, arg_114, arg_115) } else { return linked_111.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_110, arg_113, arg_114, arg_115) } }

func A_arbace_go_check_env__init_A_Unit48__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(264, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_94; var tmp2 *lang.Compiler_AOTFn; var fnbody__121 any = A_arbace_go_check_env_fn__1719000081_A_New(); var tmp3 *jrt.Class; var fncls__120 *jrt.Class = A_arbace_go_check_env_fn__1719000081_A_fn_class; if
							fncls__120 == nil { var fncls__120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, nil); A_arbace_go_check_env_fn__1719000081_A_fn_class = fncls__120d; tmp3 = fncls__120d } else { tmp3 = fncls__120 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__121, tmp3, nil); /*line :264:1*/tmp1.BindRoot_O__V(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_95)); return A_arbace_go_check_env__init_A_const_94 }




func A_arbace_go_check_env__init_A_Unit49__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(269, 1); var root_122 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = A_arbace_go_check_env__init_A_const_75.GetRawRoot__O(); var arg_126 any = Lit_43; var arg_127 any; var root_128 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, A_arbace_go_check_env_obj_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var tmp1 any = A_arbace_go_check_env__init_A_const_89; var tmp2 any = A_arbace_go_check_env__init_A_const_90; var tmp3 any = A_arbace_go_check_env__init_A_const_91; var tmp4 any = A_arbace_go_check_env__init_A_const_90; var arg_131 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, Lit_43, tmp4, A_arbace_go_check_env__init_A_const_94.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_76, jrt.Boolean_TRUE.Ref())); if linked_129 == nil { arg_127 = ifn_130.Invoke_O__O(arg_131) } else { arg_127 = linked_129.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_128, arg_131) }; if linked_123 == nil { return ifn_124.Invoke_O_O_O__O(arg_125, arg_126, arg_127) } else { return linked_123.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_122, arg_125, arg_126, arg_127) } }

func A_arbace_go_check_env__init_A_Unit50__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(271, 1); var root_132 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = A_arbace_go_check_env__init_A_const_75.GetRawRoot__O(); var arg_136 any = Lit_44; var arg_137 any; var root_138 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, A_arbace_go_check_env_obj_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = A_arbace_go_check_env__init_A_const_96; if linked_139 == nil { arg_137 = ifn_140.Invoke_O__O(arg_141) } else { arg_137 = linked_139.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_138, arg_141) }; if linked_133 == nil { return ifn_134.Invoke_O_O_O__O(arg_135, arg_136, arg_137) } else { return linked_133.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_132, arg_135, arg_136, arg_137) } }
func A_arbace_go_check_env__init_A_Unit51__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(272, 1); var root_142 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = A_arbace_go_check_env__init_A_const_75.GetRawRoot__O(); var arg_146 any = Lit_45; var arg_147 any; var root_148 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, A_arbace_go_check_env_obj_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = A_arbace_go_check_env__init_A_const_97; if linked_149 == nil { arg_147 = ifn_150.Invoke_O__O(arg_151) } else { arg_147 = linked_149.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_148, arg_151) }; if linked_143 == nil { return ifn_144.Invoke_O_O_O__O(arg_145, arg_146, arg_147) } else { return linked_143.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_142, arg_145, arg_146, arg_147) } }
func A_arbace_go_check_env__init_A_Unit52__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(273, 1); var root_152 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = A_arbace_go_check_env__init_A_const_75.GetRawRoot__O(); var arg_156 any = Lit_46; var arg_157 any; var root_158 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, A_arbace_go_check_env_obj_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = A_arbace_go_check_env__init_A_const_98; if linked_159 == nil { arg_157 = ifn_160.Invoke_O__O(arg_161) } else { arg_157 = linked_159.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_158, arg_161) }; if linked_153 == nil { return ifn_154.Invoke_O_O_O__O(arg_155, arg_156, arg_157) } else { return linked_153.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_152, arg_155, arg_156, arg_157) } }
func A_arbace_go_check_env__init_A_Unit53__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(274, 1); var root_162 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = A_arbace_go_check_env__init_A_const_75.GetRawRoot__O(); var arg_166 any = Lit_47; var arg_167 any; var root_168 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_go_check_env_obj_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = A_arbace_go_check_env__init_A_const_99; if linked_169 == nil { arg_167 = ifn_170.Invoke_O__O(arg_171) } else { arg_167 = linked_169.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_168, arg_171) }; if linked_163 == nil { return ifn_164.Invoke_O_O_O__O(arg_165, arg_166, arg_167) } else { return linked_163.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_162, arg_165, arg_166, arg_167) } }

func A_arbace_go_check_env__init_A_Unit54__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(276, 1); A_arbace_go_check_env__init_A_const_100.BindRoot_O__V(A_arbace_go_check_env__init_A_const_101); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_100; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_102)); return A_arbace_go_check_env__init_A_const_100 }



func A_arbace_go_check_env__init_A_Unit55__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(280, 1); { var seq_1719000093__1 any; var root_172 any = A_arbace_go_check_env__init_A_const_80.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = A_arbace_go_check_env__init_A_const_100.GetRawRoot__O(); if linked_173 == nil { seq_1719000093__1 = ifn_174.Invoke_O__O(arg_175) } else { seq_1719000093__1 = linked_173.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_172, arg_175) }; var chunk_1719000094__2 any; var count_1719000095__3 int64 = 0; var i_1719000096__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000096__4, count_1719000095__3) { var n__5 any = lang.Indexed_Cast(chunk_1719000094__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000096__4)); var root_192 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_194 lang.IFn
	if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = A_arbace_go_check_env__init_A_const_75.GetRawRoot__O(); var arg_196 any = n__5; var arg_197 any; var root_198 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, A_arbace_go_check_env_obj_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env__init_A_const_89, A_arbace_go_check_env__init_A_const_103, A_arbace_go_check_env__init_A_const_91, n__5, A_arbace_go_check_env__init_A_const_76, jrt.Boolean_TRUE.Ref())); if linked_199 == nil { arg_197 = ifn_200.Invoke_O__O(arg_201) } else { arg_197 = linked_199.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_198, arg_201) }; if linked_193 == nil { ifn_194.Invoke_O_O_O__O(arg_195, arg_196, arg_197) } else { linked_193.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_192, arg_195, arg_196, arg_197) }
//line :280:1
	seq_1719000093__1, chunk_1719000094__2, count_1719000095__3, i_1719000096__4 = seq_1719000093__1, chunk_1719000094__2, count_1719000095__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000096__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_176 any = A_arbace_go_check_env__init_A_const_80.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = seq_1719000093__1; if linked_177 == nil { temp__1927000414__auto____5 = ifn_178.Invoke_O__O(arg_179) } else { temp__1927000414__auto____5 = linked_177.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_176, arg_179) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1719000093__6 any = temp__1927000414__auto____5; var tmp1 any; var root_180 any = A_arbace_go_check_env__init_A_const_82.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = seq_1719000093__6; if linked_181 == nil { tmp1 = ifn_182.Invoke_O__O(arg_183) } else { tmp1 = linked_181.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_180, arg_183) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____7 any; var root_184 any = A_arbace_go_check_env__init_A_const_83.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = seq_1719000093__6; if linked_185 == nil { c__1927000678__auto____7 = ifn_186.Invoke_O__O(arg_187) } else { c__1927000678__auto____7 = linked_185.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_184, arg_187) }; var tmp2 any; var root_202 any = A_arbace_go_check_env__init_A_const_85.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = seq_1719000093__6; if linked_203 == nil { tmp2 = ifn_204.Invoke_O__O(arg_205) } else { tmp2 = linked_203.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_202, arg_205) }; seq_1719000093__1, chunk_1719000094__2, count_1719000095__3, i_1719000096__4 = tmp2, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__7 any; var root_188 any = A_arbace_go_check_env__init_A_const_84.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = seq_1719000093__6; if linked_189 == nil { n__7 = ifn_190.Invoke_O__O(arg_191) } else { n__7 = linked_189.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_188, arg_191) }
		var root_206 any = A_arbace_go_check_env__init_A_const_18.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = A_arbace_go_check_env__init_A_const_75.GetRawRoot__O(); var arg_210 any = n__7; var arg_211 any; var root_212 any = A_arbace_go_check_env__init_A_const_4.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, A_arbace_go_check_env_obj_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env__init_A_const_89, A_arbace_go_check_env__init_A_const_103, A_arbace_go_check_env__init_A_const_91, n__7, A_arbace_go_check_env__init_A_const_76, jrt.Boolean_TRUE.Ref())); if linked_213 == nil { arg_211 = ifn_214.Invoke_O__O(arg_215) } else { arg_211 = linked_213.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_212, arg_215) }; if linked_207 == nil { ifn_208.Invoke_O_O_O__O(arg_209, arg_210, arg_211) } else { linked_207.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_206, arg_209, arg_210, arg_211) }
//line :280:1
		var tmp3 any; var root_216 any = A_arbace_go_check_env__init_A_const_86.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = seq_1719000093__6; if linked_217 == nil { tmp3 = ifn_218.Invoke_O__O(arg_219) } else { tmp3 = linked_217.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_216, arg_219) }; seq_1719000093__1, chunk_1719000094__2, count_1719000095__3, i_1719000096__4 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } }
	panic("j2g: unreachable")
}


func A_arbace_go_check_env__init_A_Unit56__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(285, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_104; var tmp2 *lang.Compiler_AOTFn; var fnbody__221 any = A_arbace_go_check_env_fn__1719000099_A_New(); var tmp3 *jrt.Class; var fncls__220 *jrt.Class = A_arbace_go_check_env_fn__1719000099_A_fn_class; if
							fncls__220 == nil { var fncls__220d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, nil); A_arbace_go_check_env_fn__1719000099_A_fn_class = fncls__220d; tmp3 = fncls__220d } else { tmp3 = fncls__220 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__221, tmp3, nil); /*line :285:1*/tmp1.BindRoot_O__V(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()); var tmp4 *lang.Var = A_arbace_go_check_env__init_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_105)); return A_arbace_go_check_env__init_A_const_104 }






func A_arbace_go_check_env__init_A_Unit57__O() any { A_arbace_go_check_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(292, 1); var tmp1 *lang.Var = A_arbace_go_check_env__init_A_const_106; var tmp2 any; var root_222 any = A_arbace_go_check_env__init_A_const_107.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var tmp3 any = A_arbace_go_check_env__init_A_const_108; var tmp4 any = A_arbace_go_check_env__init_A_const_91; var tmp5 any = A_arbace_go_check_env__init_A_const_109; var arg_225 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, Lit_10, tmp4, Lit_10, tmp5, A_arbace_go_check_env__init_A_const_104.GetRawRoot__O(), A_arbace_go_check_env__init_A_const_110, jrt.Boolean_TRUE.Ref())); if linked_223 == nil { tmp2 = ifn_224.Invoke_O__O(arg_225) } else { tmp2 = linked_223.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_222, arg_225) }; tmp1.BindRoot_O__V(tmp2); var tmp6 *lang.Var = A_arbace_go_check_env__init_A_const_106; tmp6.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_env__init_A_const_111)); return A_arbace_go_check_env__init_A_const_106 }



type A_arbace_go_check_env__init_A struct{ jrt.Object }

var A_arbace_go_check_env__init_A_const_pool *jrt.RefArray

var A_arbace_go_check_env__init_A_const_0 *lang.Var

var A_arbace_go_check_env__init_A_const_1 any

var A_arbace_go_check_env__init_A_const_2 any

var A_arbace_go_check_env__init_A_const_3 any

var A_arbace_go_check_env__init_A_const_4 *lang.Var

var A_arbace_go_check_env__init_A_const_5 any

var A_arbace_go_check_env__init_A_const_6 *lang.Var

var A_arbace_go_check_env__init_A_const_7 any

var A_arbace_go_check_env__init_A_const_8 *lang.Var

var A_arbace_go_check_env__init_A_const_9 any

var A_arbace_go_check_env__init_A_const_10 *lang.Var

var A_arbace_go_check_env__init_A_const_11 any

var A_arbace_go_check_env__init_A_const_12 *lang.Var

var A_arbace_go_check_env__init_A_const_13 any

var A_arbace_go_check_env__init_A_const_14 *lang.Var

var A_arbace_go_check_env__init_A_const_15 any

var A_arbace_go_check_env__init_A_const_16 *lang.Var

var A_arbace_go_check_env__init_A_const_17 any

var A_arbace_go_check_env__init_A_const_18 *lang.Var

var A_arbace_go_check_env__init_A_const_19 any

var A_arbace_go_check_env__init_A_const_20 *lang.Var

var A_arbace_go_check_env__init_A_const_21 any

var A_arbace_go_check_env__init_A_const_22 *lang.Var

var A_arbace_go_check_env__init_A_const_23 any

var A_arbace_go_check_env__init_A_const_24 *lang.Var

var A_arbace_go_check_env__init_A_const_25 any

var A_arbace_go_check_env__init_A_const_26 *lang.Var

var A_arbace_go_check_env__init_A_const_27 any

var A_arbace_go_check_env__init_A_const_28 *lang.Var

var A_arbace_go_check_env__init_A_const_29 any

var A_arbace_go_check_env__init_A_const_30 *lang.Var

var A_arbace_go_check_env__init_A_const_31 any

var A_arbace_go_check_env__init_A_const_32 *lang.Var

var A_arbace_go_check_env__init_A_const_33 any

var A_arbace_go_check_env__init_A_const_34 *lang.Var

var A_arbace_go_check_env__init_A_const_35 any

var A_arbace_go_check_env__init_A_const_36 *lang.Var

var A_arbace_go_check_env__init_A_const_37 any

var A_arbace_go_check_env__init_A_const_38 *lang.Var

var A_arbace_go_check_env__init_A_const_39 any

var A_arbace_go_check_env__init_A_const_40 *lang.Var

var A_arbace_go_check_env__init_A_const_41 any

var A_arbace_go_check_env__init_A_const_42 any

var A_arbace_go_check_env__init_A_const_43 *lang.Var

var A_arbace_go_check_env__init_A_const_44 any

var A_arbace_go_check_env__init_A_const_45 *lang.Var

var A_arbace_go_check_env__init_A_const_46 any

var A_arbace_go_check_env__init_A_const_47 *lang.Var

var A_arbace_go_check_env__init_A_const_48 any

var A_arbace_go_check_env__init_A_const_49 *lang.Var

var A_arbace_go_check_env__init_A_const_50 any

var A_arbace_go_check_env__init_A_const_51 *lang.Var

var A_arbace_go_check_env__init_A_const_52 any

var A_arbace_go_check_env__init_A_const_53 *lang.Var

var A_arbace_go_check_env__init_A_const_54 any

var A_arbace_go_check_env__init_A_const_55 *lang.Var

var A_arbace_go_check_env__init_A_const_56 any

var A_arbace_go_check_env__init_A_const_57 *lang.Var

var A_arbace_go_check_env__init_A_const_58 any

var A_arbace_go_check_env__init_A_const_59 *lang.Var

var A_arbace_go_check_env__init_A_const_60 any

var A_arbace_go_check_env__init_A_const_61 *lang.Var

var A_arbace_go_check_env__init_A_const_62 any

var A_arbace_go_check_env__init_A_const_63 *lang.Var

var A_arbace_go_check_env__init_A_const_64 any

var A_arbace_go_check_env__init_A_const_65 *lang.Var

var A_arbace_go_check_env__init_A_const_66 any

var A_arbace_go_check_env__init_A_const_67 *lang.Var

var A_arbace_go_check_env__init_A_const_68 any

var A_arbace_go_check_env__init_A_const_69 *lang.Var

var A_arbace_go_check_env__init_A_const_70 any

var A_arbace_go_check_env__init_A_const_71 *lang.Var

var A_arbace_go_check_env__init_A_const_72 any

var A_arbace_go_check_env__init_A_const_73 *lang.Var

var A_arbace_go_check_env__init_A_const_74 any

var A_arbace_go_check_env__init_A_const_75 *lang.Var

var A_arbace_go_check_env__init_A_const_76 *lang.Keyword

var A_arbace_go_check_env__init_A_const_77 any

var A_arbace_go_check_env__init_A_const_78 *lang.Var

var A_arbace_go_check_env__init_A_const_79 any

var A_arbace_go_check_env__init_A_const_80 *lang.Var

var A_arbace_go_check_env__init_A_const_81 any

var A_arbace_go_check_env__init_A_const_82 *lang.Var

var A_arbace_go_check_env__init_A_const_83 *lang.Var

var A_arbace_go_check_env__init_A_const_84 *lang.Var

var A_arbace_go_check_env__init_A_const_85 *lang.Var

var A_arbace_go_check_env__init_A_const_86 *lang.Var

var A_arbace_go_check_env__init_A_const_87 *lang.Var

var A_arbace_go_check_env__init_A_const_88 any

var A_arbace_go_check_env__init_A_const_89 *lang.Keyword

var A_arbace_go_check_env__init_A_const_90 *lang.Keyword

var A_arbace_go_check_env__init_A_const_91 *lang.Keyword

var A_arbace_go_check_env__init_A_const_92 *lang.Keyword

var A_arbace_go_check_env__init_A_const_93 *lang.Keyword

var A_arbace_go_check_env__init_A_const_94 *lang.Var

var A_arbace_go_check_env__init_A_const_95 any

var A_arbace_go_check_env__init_A_const_96 any

var A_arbace_go_check_env__init_A_const_97 any

var A_arbace_go_check_env__init_A_const_98 any

var A_arbace_go_check_env__init_A_const_99 any

var A_arbace_go_check_env__init_A_const_100 *lang.Var

var A_arbace_go_check_env__init_A_const_101 any

var A_arbace_go_check_env__init_A_const_102 any

var A_arbace_go_check_env__init_A_const_103 *lang.Keyword

var A_arbace_go_check_env__init_A_const_104 *lang.Var

var A_arbace_go_check_env__init_A_const_105 any

var A_arbace_go_check_env__init_A_const_106 *lang.Var

var A_arbace_go_check_env__init_A_const_107 *lang.Var

var A_arbace_go_check_env__init_A_const_108 *lang.Keyword

var A_arbace_go_check_env__init_A_const_109 *lang.Keyword

var A_arbace_go_check_env__init_A_const_110 *lang.Keyword

var A_arbace_go_check_env__init_A_const_111 any

var A_arbace_go_check_env__init_A_init jrt.ClassInit

func A_arbace_go_check_env__init_A_Init() { if !A_arbace_go_check_env__init_A_init.Done() { A_arbace_go_check_env__init_A_init.Run(A_arbace_go_check_env__init_A_clinit) } }

func A_arbace_go_check_env__init_A_clinit() { A_arbace_go_check_env__init_A_clinit_p0(); A_arbace_go_check_env__init_A_clinit_p1(); A_arbace_go_check_env__init_A_clinit_p2(); A_arbace_go_check_env__init_A_clinit_p3(); A_arbace_go_check_env__init_A_clinit_p4(); A_arbace_go_check_env__init_A_clinit_p5(); A_arbace_go_check_env__init_A_clinit_p6(); A_arbace_go_check_env__init_A_clinit_p7(); A_arbace_go_check_env__init_A_clinit_p8() }

func A_arbace_go_check_env__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_env__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_11, 187); A_arbace_go_check_env__init_A_const_0 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[75]); A_arbace_go_check_env__init_A_const_1 = A_arbace_go_check_env__init_A_const_pool.A[76]; A_arbace_go_check_env__init_A_const_2 = A_arbace_go_check_env__init_A_const_pool.A[77]; A_arbace_go_check_env__init_A_const_3 = A_arbace_go_check_env__init_A_const_pool.A[78]; A_arbace_go_check_env__init_A_const_4 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[79]); A_arbace_go_check_env__init_A_const_5 = A_arbace_go_check_env__init_A_const_pool.A[80]; A_arbace_go_check_env__init_A_const_6 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[81]); A_arbace_go_check_env__init_A_const_7 = A_arbace_go_check_env__init_A_const_pool.A[82]; A_arbace_go_check_env__init_A_const_8 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[83]); A_arbace_go_check_env__init_A_const_9 = A_arbace_go_check_env__init_A_const_pool.A[84]; A_arbace_go_check_env__init_A_const_10 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[85]); A_arbace_go_check_env__init_A_const_11 = A_arbace_go_check_env__init_A_const_pool.A[86]; A_arbace_go_check_env__init_A_const_12 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[87]) }

func A_arbace_go_check_env__init_A_clinit_p1() { A_arbace_go_check_env__init_A_const_13 = A_arbace_go_check_env__init_A_const_pool.A[88]; A_arbace_go_check_env__init_A_const_14 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[89]); A_arbace_go_check_env__init_A_const_15 = A_arbace_go_check_env__init_A_const_pool.A[90]; A_arbace_go_check_env__init_A_const_16 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[91]); A_arbace_go_check_env__init_A_const_17 = A_arbace_go_check_env__init_A_const_pool.A[92]; A_arbace_go_check_env__init_A_const_18 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[93]); A_arbace_go_check_env__init_A_const_19 = A_arbace_go_check_env__init_A_const_pool.A[94]; A_arbace_go_check_env__init_A_const_20 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[95]); A_arbace_go_check_env__init_A_const_21 = A_arbace_go_check_env__init_A_const_pool.A[96]; A_arbace_go_check_env__init_A_const_22 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[97]); A_arbace_go_check_env__init_A_const_23 = A_arbace_go_check_env__init_A_const_pool.A[98]; A_arbace_go_check_env__init_A_const_24 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[99]); A_arbace_go_check_env__init_A_const_25 = A_arbace_go_check_env__init_A_const_pool.A[100] }

func A_arbace_go_check_env__init_A_clinit_p2() { A_arbace_go_check_env__init_A_const_26 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[101]); A_arbace_go_check_env__init_A_const_27 = A_arbace_go_check_env__init_A_const_pool.A[102]; A_arbace_go_check_env__init_A_const_28 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[103]); A_arbace_go_check_env__init_A_const_29 = A_arbace_go_check_env__init_A_const_pool.A[104]; A_arbace_go_check_env__init_A_const_30 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[105]); A_arbace_go_check_env__init_A_const_31 = A_arbace_go_check_env__init_A_const_pool.A[106]; A_arbace_go_check_env__init_A_const_32 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[107]); A_arbace_go_check_env__init_A_const_33 = A_arbace_go_check_env__init_A_const_pool.A[108]; A_arbace_go_check_env__init_A_const_34 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[109]); A_arbace_go_check_env__init_A_const_35 = A_arbace_go_check_env__init_A_const_pool.A[110]; A_arbace_go_check_env__init_A_const_36 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[111]); A_arbace_go_check_env__init_A_const_37 = A_arbace_go_check_env__init_A_const_pool.A[112]; A_arbace_go_check_env__init_A_const_38 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[113]) }

func A_arbace_go_check_env__init_A_clinit_p3() { A_arbace_go_check_env__init_A_const_39 = A_arbace_go_check_env__init_A_const_pool.A[114]; A_arbace_go_check_env__init_A_const_40 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[115]); A_arbace_go_check_env__init_A_const_41 = A_arbace_go_check_env__init_A_const_pool.A[116]; A_arbace_go_check_env__init_A_const_42 = A_arbace_go_check_env__init_A_const_pool.A[117]; A_arbace_go_check_env__init_A_const_43 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[118]); A_arbace_go_check_env__init_A_const_44 = A_arbace_go_check_env__init_A_const_pool.A[119]; A_arbace_go_check_env__init_A_const_45 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[120]); A_arbace_go_check_env__init_A_const_46 = A_arbace_go_check_env__init_A_const_pool.A[121]; A_arbace_go_check_env__init_A_const_47 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[122]); A_arbace_go_check_env__init_A_const_48 = A_arbace_go_check_env__init_A_const_pool.A[123]; A_arbace_go_check_env__init_A_const_49 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[124]); A_arbace_go_check_env__init_A_const_50 = A_arbace_go_check_env__init_A_const_pool.A[125]; A_arbace_go_check_env__init_A_const_51 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[126]); A_arbace_go_check_env__init_A_const_52 = A_arbace_go_check_env__init_A_const_pool.A[127] }

func A_arbace_go_check_env__init_A_clinit_p4() { A_arbace_go_check_env__init_A_const_53 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[128]); A_arbace_go_check_env__init_A_const_54 = A_arbace_go_check_env__init_A_const_pool.A[129]; A_arbace_go_check_env__init_A_const_55 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[130]); A_arbace_go_check_env__init_A_const_56 = A_arbace_go_check_env__init_A_const_pool.A[131]; A_arbace_go_check_env__init_A_const_57 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[132]); A_arbace_go_check_env__init_A_const_58 = A_arbace_go_check_env__init_A_const_pool.A[133]; A_arbace_go_check_env__init_A_const_59 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[134]); A_arbace_go_check_env__init_A_const_60 = A_arbace_go_check_env__init_A_const_pool.A[135]; A_arbace_go_check_env__init_A_const_61 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[136]); A_arbace_go_check_env__init_A_const_62 = A_arbace_go_check_env__init_A_const_pool.A[137]; A_arbace_go_check_env__init_A_const_63 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[138]); A_arbace_go_check_env__init_A_const_64 = A_arbace_go_check_env__init_A_const_pool.A[139]; A_arbace_go_check_env__init_A_const_65 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[140]) }

func A_arbace_go_check_env__init_A_clinit_p5() { A_arbace_go_check_env__init_A_const_66 = A_arbace_go_check_env__init_A_const_pool.A[141]; A_arbace_go_check_env__init_A_const_67 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[142]); A_arbace_go_check_env__init_A_const_68 = A_arbace_go_check_env__init_A_const_pool.A[143]; A_arbace_go_check_env__init_A_const_69 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[144]); A_arbace_go_check_env__init_A_const_70 = A_arbace_go_check_env__init_A_const_pool.A[145]; A_arbace_go_check_env__init_A_const_71 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[146]); A_arbace_go_check_env__init_A_const_72 = A_arbace_go_check_env__init_A_const_pool.A[147]; A_arbace_go_check_env__init_A_const_73 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[148]); A_arbace_go_check_env__init_A_const_74 = A_arbace_go_check_env__init_A_const_pool.A[149]; A_arbace_go_check_env__init_A_const_75 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[150]); A_arbace_go_check_env__init_A_const_76 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[151]); A_arbace_go_check_env__init_A_const_77 = A_arbace_go_check_env__init_A_const_pool.A[152]; A_arbace_go_check_env__init_A_const_78 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[153]) }

func A_arbace_go_check_env__init_A_clinit_p6() { A_arbace_go_check_env__init_A_const_79 = A_arbace_go_check_env__init_A_const_pool.A[154]; A_arbace_go_check_env__init_A_const_80 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[155]); A_arbace_go_check_env__init_A_const_81 = A_arbace_go_check_env__init_A_const_pool.A[156]; A_arbace_go_check_env__init_A_const_82 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[157]); A_arbace_go_check_env__init_A_const_83 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[158]); A_arbace_go_check_env__init_A_const_84 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[159]); A_arbace_go_check_env__init_A_const_85 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[160]); A_arbace_go_check_env__init_A_const_86 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[161]); A_arbace_go_check_env__init_A_const_87 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[162]); A_arbace_go_check_env__init_A_const_88 = A_arbace_go_check_env__init_A_const_pool.A[163]; A_arbace_go_check_env__init_A_const_89 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[164]); A_arbace_go_check_env__init_A_const_90 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[165]) }

func A_arbace_go_check_env__init_A_clinit_p7() { A_arbace_go_check_env__init_A_const_91 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[166]); A_arbace_go_check_env__init_A_const_92 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[167]); A_arbace_go_check_env__init_A_const_93 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[168]); A_arbace_go_check_env__init_A_const_94 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[169]); A_arbace_go_check_env__init_A_const_95 = A_arbace_go_check_env__init_A_const_pool.A[170]; A_arbace_go_check_env__init_A_const_96 = A_arbace_go_check_env__init_A_const_pool.A[171]; A_arbace_go_check_env__init_A_const_97 = A_arbace_go_check_env__init_A_const_pool.A[172]; A_arbace_go_check_env__init_A_const_98 = A_arbace_go_check_env__init_A_const_pool.A[173]; A_arbace_go_check_env__init_A_const_99 = A_arbace_go_check_env__init_A_const_pool.A[174]; A_arbace_go_check_env__init_A_const_100 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[175]); A_arbace_go_check_env__init_A_const_101 = A_arbace_go_check_env__init_A_const_pool.A[176]; A_arbace_go_check_env__init_A_const_102 = A_arbace_go_check_env__init_A_const_pool.A[177]; A_arbace_go_check_env__init_A_const_103 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[178]) }

func A_arbace_go_check_env__init_A_clinit_p8() { A_arbace_go_check_env__init_A_const_104 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[179]); A_arbace_go_check_env__init_A_const_105 = A_arbace_go_check_env__init_A_const_pool.A[180]; A_arbace_go_check_env__init_A_const_106 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[181]); A_arbace_go_check_env__init_A_const_107 = lang.Var_Cast(A_arbace_go_check_env__init_A_const_pool.A[182]); A_arbace_go_check_env__init_A_const_108 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[183]); A_arbace_go_check_env__init_A_const_109 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[184]); A_arbace_go_check_env__init_A_const_110 = lang.Keyword_Cast(A_arbace_go_check_env__init_A_const_pool.A[185]); A_arbace_go_check_env__init_A_const_111 = A_arbace_go_check_env__init_A_const_pool.A[186] }

func A_arbace_go_check_env__init_A_New() *A_arbace_go_check_env__init_A { A_arbace_go_check_env__init_A_Init(); t := &A_arbace_go_check_env__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env__init_A) Ctor() {}

func (t *A_arbace_go_check_env__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env__init_A_class }

func (t *A_arbace_go_check_env__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env__init_A); return ok }

func A_arbace_go_check_env__init_A_Cast(x any) *A_arbace_go_check_env__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env__init_A_class)) }; return v }
