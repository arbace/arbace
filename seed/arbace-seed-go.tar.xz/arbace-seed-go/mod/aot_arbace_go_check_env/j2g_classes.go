//line j2g_classes.ae:1
package aot_arbace_go_check_env

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_go_check_env_annotation_error_BANG__A_class, Name: "arbace.go.check.env$annotation_error_BANG_", Modifiers: 25, Simple: "annotation_error_BANG_", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_annotation_error_BANG__A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF5_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_def_type_BANG__A_class, Name: "arbace.go.check.env$def_type_BANG_", Modifiers: 25, Simple: "def_type_BANG_", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_def_type_BANG__A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_err_BANG__A_class, Name: "arbace.go.check.env$err_BANG_", Modifiers: 25, Simple: "err_BANG_", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_err_BANG__A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_error_BANG__A_class, Name: "arbace.go.check.env$error_BANG_", Modifiers: 25, Simple: "error_BANG_", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class, &lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_class, Name: "arbace.go.check.env$eval1719000004$loading__1927001464__auto____1719000005", Modifiers: 25, Simple: "loading__1927001464__auto____1719000005", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A", Source: "env.ae", Declaring: &A_arbace_go_check_env_eval1719000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_eval1719000008_fn__1719000009_A_class, Name: "arbace.go.check.env$eval1719000008$fn__1719000009", Modifiers: 25, Simple: "fn__1719000009", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_eval1719000008_fn__1719000009_A", Source: "env.ae", Declaring: &A_arbace_go_check_env_eval1719000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_fn__1719000041_A_class, Name: "arbace.go.check.env$fn__1719000041", Modifiers: 25, Simple: "fn__1719000041", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_fn__1719000041_A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_fn__1719000047_A_class, Name: "arbace.go.check.env$fn__1719000047", Modifiers: 25, Simple: "fn__1719000047", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_fn__1719000047_A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_fn__1719000065_A_class, Name: "arbace.go.check.env$fn__1719000065", Modifiers: 25, Simple: "fn__1719000065", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_fn__1719000065_A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_generic_BANG__A_class, Name: "arbace.go.check.env$generic_BANG_", Modifiers: 25, Simple: "generic_BANG_", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_generic_BANG__A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_line_of_A_class, Name: "arbace.go.check.env$line_of", Modifiers: 25, Simple: "line_of", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_line_of_A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_o_A_class, Name: "arbace.go.check.env$o", Modifiers: 25, Simple: "o", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_o_A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_obj_A_class, Name: "arbace.go.check.env$obj", Modifiers: 25, Simple: "obj", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_obj_A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_obj_QMARK__A_class, Name: "arbace.go.check.env$obj_QMARK_", Modifiers: 25, Simple: "obj_QMARK_", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_obj_QMARK__A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_oset_BANG__A_class, Name: "arbace.go.check.env$oset_BANG_", Modifiers: 25, Simple: "oset_BANG_", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_oset_BANG__A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_scope_A_class, Name: "arbace.go.check.env$scope", Modifiers: 25, Simple: "scope", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_scope_A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_scope_get_A_class, Name: "arbace.go.check.env$scope_get", Modifiers: 25, Simple: "scope_get", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_scope_get_A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_scope_lookup_A_class, Name: "arbace.go.check.env$scope_lookup", Modifiers: 25, Simple: "scope_lookup", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_scope_lookup_A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_scope_put_BANG__A_class, Name: "arbace.go.check.env$scope_put_BANG_", Modifiers: 25, Simple: "scope_put_BANG_", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_scope_put_BANG__A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_unsupported_BANG__A_class, Name: "arbace.go.check.env$unsupported_BANG_", Modifiers: 25, Simple: "unsupported_BANG_", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_BANG__A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_unsupported_QMARK__A_class, Name: "arbace.go.check.env$unsupported_QMARK_", Modifiers: 25, Simple: "unsupported_QMARK_", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_unsupported_QMARK__A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_env_verified_BANG__A_class, Name: "arbace.go.check.env$verified_BANG_", Modifiers: 25, Simple: "verified_BANG_", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_verified_BANG__A", Source: "env.ae", Declaring: &A_arbace_go_check_env_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_go_check_env_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_check_env_A_New()}; return nil }

var A_arbace_go_check_env_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_check_env_A_new}

var A_arbace_go_check_env_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.check.env", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_A"})

func init() { i := A_arbace_go_check_env_A_class.Info(); i.IsInstance = A_arbace_go_check_env_A_InstanceOf; i.Init = A_arbace_go_check_env_A_Init; i.Table = A_arbace_go_check_env_A_members }

var A_arbace_go_check_env_annotation_error_BANG__A_class *jrt.Class

var A_arbace_go_check_env_def_type_BANG__A_class *jrt.Class

var A_arbace_go_check_env_err_BANG__A_class *jrt.Class

var A_arbace_go_check_env_error_BANG__A_class *jrt.Class

func A_arbace_go_check_env_eval1719000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_check_env_eval1719000004_A_New()}; return nil }

var A_arbace_go_check_env_eval1719000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_check_env_eval1719000004_A_new}

var A_arbace_go_check_env_eval1719000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.check.env$eval1719000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_check_env_A_class, Simple: "eval1719000004", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_eval1719000004_A"})

func init() { i := A_arbace_go_check_env_eval1719000004_A_class.Info(); i.IsInstance = A_arbace_go_check_env_eval1719000004_A_InstanceOf; i.Table = A_arbace_go_check_env_eval1719000004_A_members }

var A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_class *jrt.Class

func A_arbace_go_check_env_eval1719000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_check_env_eval1719000008_A_New()}; return nil }

var A_arbace_go_check_env_eval1719000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_check_env_eval1719000008_A_new}

var A_arbace_go_check_env_eval1719000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.check.env$eval1719000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_check_env_A_class, Simple: "eval1719000008", Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env_eval1719000008_A"})

func init() { i := A_arbace_go_check_env_eval1719000008_A_class.Info(); i.IsInstance = A_arbace_go_check_env_eval1719000008_A_InstanceOf; i.Table = A_arbace_go_check_env_eval1719000008_A_members }

var A_arbace_go_check_env_eval1719000008_fn__1719000009_A_class *jrt.Class

var A_arbace_go_check_env_fn__1719000041_A_class *jrt.Class

var A_arbace_go_check_env_fn__1719000047_A_class *jrt.Class

var A_arbace_go_check_env_fn__1719000065_A_class *jrt.Class

var A_arbace_go_check_env_generic_BANG__A_class *jrt.Class

var A_arbace_go_check_env_line_of_A_class *jrt.Class

var A_arbace_go_check_env_o_A_class *jrt.Class

var A_arbace_go_check_env_obj_A_class *jrt.Class

var A_arbace_go_check_env_obj_QMARK__A_class *jrt.Class

var A_arbace_go_check_env_oset_BANG__A_class *jrt.Class

var A_arbace_go_check_env_scope_A_class *jrt.Class

var A_arbace_go_check_env_scope_get_A_class *jrt.Class

var A_arbace_go_check_env_scope_lookup_A_class *jrt.Class

var A_arbace_go_check_env_scope_put_BANG__A_class *jrt.Class

var A_arbace_go_check_env_unsupported_BANG__A_class *jrt.Class

var A_arbace_go_check_env_unsupported_QMARK__A_class *jrt.Class

var A_arbace_go_check_env_verified_BANG__A_class *jrt.Class

func A_arbace_go_check_env__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_go_check_env__init_A_Load__O()}; return nil }

func A_arbace_go_check_env__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_check_env__init_A_New()}; return nil }

var A_arbace_go_check_env__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_go_check_env__init_A_invoke, New: A_arbace_go_check_env__init_A_new}

var A_arbace_go_check_env__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.check.env__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_check_env.A_arbace_go_check_env__init_A", Source: "env.ae"})

func init() { i := A_arbace_go_check_env__init_A_class.Info(); i.IsInstance = A_arbace_go_check_env__init_A_InstanceOf; i.Init = A_arbace_go_check_env__init_A_Init; i.Table = A_arbace_go_check_env__init_A_members }
