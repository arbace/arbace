//line aot_arbace_go_check_env.ae:1
package aot_arbace_go_check_env

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_types"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_New() *A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_env_A_const_4.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_5); tmp2 = lang.IFn_Cast(A_arbace_go_check_env_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_go_check_env_A_const_1, A_arbace_go_check_env_A_const_2, A_arbace_go_check_env_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_env_eval1719000008_fn__1719000009_A_New() *A_arbace_go_check_env_eval1719000008_fn__1719000009_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_eval1719000008_fn__1719000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_env_eval1719000008_fn__1719000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_env_eval1719000008_fn__1719000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_go_check_env_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_env_A_const_9.GetRawRoot__O(), A_arbace_go_check_env_A_const_10) }













func A_arbace_go_check_env_obj_A_New() *A_arbace_go_check_env_obj_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_obj_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_go_check_env_obj_A) Ctor() {}
//line :15:1
func (t *A_arbace_go_check_env_obj_A) Invoke_O_O__O(self, m__0 any) any { var root_21 any = A_arbace_go_check_env_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = m__0; if linked_22 == nil { return ifn_23.Invoke_O__O(arg_24) } else { return linked_22.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_21, arg_24) } }
func A_arbace_go_check_env_o_A_New() *A_arbace_go_check_env_o_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_o_A{}; t.Ctor(); return t }
//line :16:1
func (t *A_arbace_go_check_env_o_A) Ctor() {}
//line :16:1
func (t *A_arbace_go_check_env_o_A) Invoke_O_O_O__O(self, x__0, k__1 any) any { var tmp1 any; var root_25 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = x__0; if linked_26 == nil { tmp1 = ifn_27.Invoke_O__O(arg_28) } else { tmp1 = linked_26.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_25, arg_28) }; return lang.RT_Get_O_O__O_NoInit(tmp1, k__1) }
func A_arbace_go_check_env_oset_BANG__A_New() *A_arbace_go_check_env_oset_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_oset_BANG__A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_go_check_env_oset_BANG__A) Ctor() {}
//line :17:1
func (t *A_arbace_go_check_env_oset_BANG__A) Invoke_O_O_O_O__O(self, x__0, k__1, v__2 any) any { var tmp1 *lang.Volatile = lang.Volatile_Cast(x__0); var tmp2 any; var root_29 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = jrt.NN(lang.Volatile_Cast(x__0)).Deref__O(); var arg_33 any = k__1; var arg_34 any = v__2; if linked_30 == nil { tmp2 = ifn_31.Invoke_O_O_O__O(arg_32, arg_33, arg_34) } else { tmp2 = linked_30.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_29, arg_32, arg_33, arg_34) }; jrt.NN(tmp1).Reset_O__O(tmp2); return x__0 }
func A_arbace_go_check_env_obj_QMARK__A_New() *A_arbace_go_check_env_obj_QMARK__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_obj_QMARK__A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_go_check_env_obj_QMARK__A) Ctor() {}
//line :18:1
func (t *A_arbace_go_check_env_obj_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Volatile_InstanceOf(x__0)).Ref() }



func A_arbace_go_check_env_scope_A_New() *A_arbace_go_check_env_scope_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_scope_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_go_check_env_scope_A) Ctor() {}
//line :22:1
func (t *A_arbace_go_check_env_scope_A) Invoke_O_O_O__O(self, parent__0, kind__1 any) any { var tmp1 any = A_arbace_go_check_env_A_const_13; var tmp2 any = A_arbace_go_check_env_A_const_14; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, parent__0, tmp2, jrt.HashMap_New(), A_arbace_go_check_env_A_const_15, kind__1)) }

func A_arbace_go_check_env_scope_lookup_A_New() *A_arbace_go_check_env_scope_lookup_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_scope_lookup_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_env_scope_lookup_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_env_scope_lookup_A) Invoke_O_O_O__O(self, s__0, n__1 any) any { { var s__3 any = s__0; L1: for {



	if jrt.J2g_Truth(s__3) { var temp__1927000408__auto____4 any = jrt.HashMap_Cast(A_arbace_go_check_env_A_const_14.Invoke_O__O(s__3)).Get_O__O(n__1)
		if jrt.J2g_Truth(temp__1927000408__auto____4) { var x__5 any = temp__1927000408__auto____4; return x__5 } else {

			s__3 = A_arbace_go_check_env_A_const_13.Invoke_O__O(s__3); continue L1 } } else {
//line :28:1
				return nil } } }; /*line :24:1*/panic("j2g: unreachable") }








func A_arbace_go_check_env_scope_get_A_New() *A_arbace_go_check_env_scope_get_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_scope_get_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_go_check_env_scope_get_A) Ctor() {}
//line :33:1
func (t *A_arbace_go_check_env_scope_get_A) Invoke_O_O_O__O(self, s__0, n__1 any) any { return jrt.HashMap_Cast(A_arbace_go_check_env_A_const_14.Invoke_O__O(s__0)).Get_O__O(n__1) }
func A_arbace_go_check_env_scope_put_BANG__A_New() *A_arbace_go_check_env_scope_put_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_scope_put_BANG__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_go_check_env_scope_put_BANG__A) Ctor() {}
//line :34:1
func (t *A_arbace_go_check_env_scope_put_BANG__A) Invoke_O_O_O_O__O(self, s__0, n__1, x__2 any) any { return jrt.HashMap_Cast(A_arbace_go_check_env_A_const_14.Invoke_O__O(s__0)).Put_O_O__O(n__1, x__2) }





























func A_arbace_go_check_env_error_BANG__A_New() *A_arbace_go_check_env_error_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_error_BANG__A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_go_check_env_error_BANG__A) Ctor() {}
//line :64:1
func (t *A_arbace_go_check_env_error_BANG__A) Invoke_O_O_O_O_O__O(self, file__0, line__1, code__2, msg__3 any) any {



	var tmp1 any; var and__1927000168__auto____5 any = A_arbace_go_check_env_A_const_16.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____5) {


		var root_35 any = A_arbace_go_check_env_A_const_17.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any; var and__1927000168__auto____6 any; var root_39 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any; var root_43 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = A_arbace_go_check_env_A_const_16.Get__O(); if linked_44 == nil { arg_42 = ifn_45.Invoke_O__O(arg_46) } else { arg_42 = linked_44.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_43, arg_46) }; if linked_40 == nil { and__1927000168__auto____6 = ifn_41.Invoke_O__O(arg_42) } else { and__1927000168__auto____6 = linked_40.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_39, arg_42) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var m__7 any = msg__3; var or__1927000174__auto____8 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(m__7)).IndexOf_String__I(Lit_6)))

			if or__1927000174__auto____8 { arg_38 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { arg_38 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(m__7)).IndexOf_String__I(Lit_7)))).Ref() } } else {
//line :71:1
				arg_38 = and__1927000168__auto____6 }; if linked_36 == nil { tmp1 = ifn_37.Invoke_O__O(arg_38) } else { tmp1 = linked_36.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_35, arg_38) } } else {
//line :68:1
					tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var line__5 any; var or__1927000174__auto____5 any = A_arbace_go_check_env_A_const_19.Get__O()





						if jrt.J2g_Truth(or__1927000174__auto____5) { line__5 = or__1927000174__auto____5 } else { line__5 = line__1 }
//line :68:1
						var e__6 any; var tmp2 any = A_arbace_go_check_env_A_const_20; var tmp3 any = A_arbace_go_check_env_A_const_21; var tmp4 any = A_arbace_go_check_env_A_const_22; var tmp5 any = A_arbace_go_check_env_A_const_23; var tmp6 any = A_arbace_go_check_env_A_const_24; var tmp7 any







						if jrt.J2g_Truth(A_arbace_go_check_env_A_const_25.Get__O()) { var root_47 any = A_arbace_go_check_env_A_const_26.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, A_arbace_go_check_env_o_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = A_arbace_go_check_env_A_const_25.Get__O(); var arg_51 any = A_arbace_go_check_env_A_const_27; if linked_48 == nil { tmp7 = ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { tmp7 = linked_48.(*A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) } } else { tmp7 = nil }
//line :68:1
						e__6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, file__0, tmp3, line__5, tmp4, msg__3, tmp5, code__2, tmp6, tmp7))








						var tmp8 *lang.Volatile = lang.Volatile_Cast(A_arbace_go_check_env_A_const_16.Get__O()); var tmp9 any; var root_52 any = A_arbace_go_check_env_A_const_9.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_16.Get__O())).Deref__O(); var arg_56 any = e__6; if linked_53 == nil { tmp9 = ifn_54.Invoke_O_O__O(arg_55, arg_56) } else { tmp9 = linked_53.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_52, arg_55, arg_56) }; jrt.NN(tmp8).Reset_O__O(tmp9) }
//line :64:1
	return nil }
//line :64:1
func (t *A_arbace_go_check_env_error_BANG__A) Invoke_O_O_O_O__O(self, line__0, code__1, msg__2 any) any {

	var root_57 any = A_arbace_go_check_env_A_const_28.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_29; var arg_60 any = tmp1.Invoke_O__O(A_arbace_go_check_env_A_const_30.Get__O()); var arg_61 any = line__0; var arg_62 any = code__1; var arg_63 any = msg__2; if linked_58 == nil { return ifn_59.Invoke_O_O_O_O__O(arg_60, arg_61, arg_62, arg_63) } else { return linked_58.(*A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_57, arg_60, arg_61, arg_62, arg_63)
	}
}











func A_arbace_go_check_env_line_of_A_New() *A_arbace_go_check_env_line_of_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_line_of_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_go_check_env_line_of_A) Ctor() {}
//line :80:1
func (t *A_arbace_go_check_env_line_of_A) Invoke_O_O__O(self, form__0 any) any {


	if lang.IMeta_InstanceOf(form__0) {
		var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_21; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(form__0)) } else {
//line :83:1
			return nil
		}
}




func A_arbace_go_check_env_end_line_A_New() *A_arbace_go_check_env_end_line_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_end_line_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_go_check_env_end_line_A) Ctor() {}
//line :90:1
func (t *A_arbace_go_check_env_end_line_A) Invoke_O_O_O__O(self, c__0, l__1 any) any { var l__3 any; var tmp1 any; var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var root_64 any = A_arbace_go_check_env_A_const_31.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_66 lang.IFn; if



	linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = c__0; if linked_65 == nil { or__1927000174__auto____3 = ifn_66.Invoke_O__O(arg_67) } else { or__1927000174__auto____3 = linked_65.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_64, arg_67) }; if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else { var root_68 any = A_arbace_go_check_env_A_const_32.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = c__0; if linked_69 == nil { and__1927000168__auto____3 = ifn_70.Invoke_O__O(arg_71) } else { and__1927000168__auto____3 = linked_69.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_68, arg_71) } }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_72 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = c__0; if linked_73 == nil { tmp1 = ifn_74.Invoke_O__O(arg_75) } else { tmp1 = linked_73.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_72, arg_75) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var c__3 any; var tmp2 any; var root_76 any = A_arbace_go_check_env_A_const_32.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_78 lang.IFn
		if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = c__0; if linked_77 == nil { tmp2 = ifn_78.Invoke_O__O(arg_79) } else { tmp2 = linked_77.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_76, arg_79) }; if jrt.J2g_Truth(tmp2) { c__3 = c__0 } else { var root_80 any = A_arbace_go_check_env_A_const_33.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any; var root_85 any = A_arbace_go_check_env_A_const_34.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = c__0; if linked_86 == nil { arg_83 = ifn_87.Invoke_O__O(arg_88) } else { arg_83 = linked_86.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_85, arg_88) }; var arg_84 any = lang.RT_Meta_O__IPersistentMap_NoInit(c__0); if linked_81 == nil { c__3 = ifn_82.Invoke_O_O__O(arg_83, arg_84) } else { c__3 = linked_81.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_80, arg_83, arg_84) } }
//line :94:1
		var k__4 int64 = lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(c__3))); var root_89 any = A_arbace_go_check_env_A_const_35.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, A_arbace_go_check_env_end_line_A_fn_class); var ifn_91 lang.IFn


		if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = lang.RT_Nth_O_I__O_NoInit(c__3, lang.RT_IntCast_J__I_NoInit(k__4)); var arg_93 any; var root_94 any = A_arbace_go_check_env_A_const_36.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_94, A_arbace_go_check_env_child_line_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = c__3; var arg_98 int64 = k__4; var arg_99 any = l__1; if linked_95 == nil { arg_93 = ifn_96.Invoke_O_O_O__O(arg_97, jrt.Long_ValueOf_J__Long_NoInit(arg_98).Ref(), arg_99) } else { arg_93 = linked_95.(*A_arbace_go_check_env_child_line_A).InvokeSpec_O_O_J_O_O__O(root_94, arg_97, arg_98, nil, arg_99) }; if linked_90 == nil { l__3 = ifn_91.Invoke_O_O__O(arg_92, arg_93) } else { l__3 = linked_90.(*A_arbace_go_check_env_end_line_A).Invoke_O_O_O__O(root_89, arg_92, arg_93) } } else {
//line :94:1
			l__3 = l__1 }; var tmp3 any; var or__1927000174__auto____4 any; if




	lang.IMeta_InstanceOf(c__0) { var tmp4 *lang.Keyword = A_arbace_go_check_env_A_const_37; or__1927000174__auto____4 = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(c__0)) } else { or__1927000174__auto____4 = nil }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp3 = or__1927000174__auto____4 } else { tmp3 = A_arbace_go_check_env_A_const_38 }; return lang.Numbers_Max_O_O__O_NoInit(l__3, tmp3) }

func A_arbace_go_check_env_child_line_A_New() *A_arbace_go_check_env_child_line_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_child_line_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_check_env_child_line_A) Ctor() {}
//line :101:1
func (t *A_arbace_go_check_env_child_line_A) Invoke_O_O_O_O__O(self, f__0, i__1, start__2 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_O_J_O_O__O(self, f__0, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, start__2) } else {






	var tmp1 any; var and__1927000168__auto____4 any = start__2; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var or__1927000174__auto____5 any; var root_100 any = A_arbace_go_check_env_A_const_31.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = f__0; if linked_101 == nil { or__1927000174__auto____5 = ifn_102.Invoke_O__O(arg_103) } else { or__1927000174__auto____5 = linked_101.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_100, arg_103) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else { var root_104 any = A_arbace_go_check_env_A_const_32.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = f__0; if linked_105 == nil { and__1927000168__auto____5 = ifn_106.Invoke_O__O(arg_107) } else { and__1927000168__auto____5 = linked_105.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_104, arg_107) } }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp2 bool; var na_108 any = i__1; var na_109 int64 = int64(lang.RT_Count_O__I_NoInit(f__0)); if jrt.Long_InstanceOf(na_108) { var n0_110 int64 = jrt.NN(jrt.Long_Cast(na_108)).LongValue__J(); var n1_111 int64 = na_109; tmp2 = n0_110 < n1_111 } else { tmp2 = lang.Numbers_Lt_O_J__Z_NoInit(na_108, na_109) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref() } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { var m__4 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__0); var f__5 any; var tmp3 any; var root_113 any = A_arbace_go_check_env_A_const_32.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_115 lang.IFn

		if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = f__0; if linked_114 == nil { tmp3 = ifn_115.Invoke_O__O(arg_116) } else { tmp3 = linked_114.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_113, arg_116) }; if jrt.J2g_Truth(tmp3) { f__5 = f__0 } else { var root_117 any = A_arbace_go_check_env_A_const_34.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = f__0; if linked_118 == nil { f__5 = ifn_119.Invoke_O__O(arg_120) } else { f__5 = linked_118.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_117, arg_120) } }
//line :108:1
		var or__1927000174__auto____6 any; var root_121 any = A_arbace_go_check_env_A_const_39.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_go_check_env_line_of_A_fn_class); var ifn_123 lang.IFn


		if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(i__1)); if linked_122 == nil { or__1927000174__auto____6 = ifn_123.Invoke_O__O(arg_124) } else { or__1927000174__auto____6 = linked_122.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_121, arg_124) }; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { var bmap__7 any; var root_125 any = A_arbace_go_check_env_A_const_40.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_127 lang.IFn

			if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_129 any; var iter__1927001039__auto____7 any; var tmp4 any = A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A_New(); var tmp5 *jrt.Class; var fncls__196 *jrt.Class = A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A_fn_class; if fncls__196 == nil { var fncls__196d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A_fn_class = fncls__196d; tmp5 = fncls__196d } else { tmp5 = fncls__196 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); arg_129 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(A_arbace_go_check_env_A_const_51.Invoke_O__O(m__4)); if linked_126 == nil { bmap__7 = ifn_127.Invoke_O_O__O(arg_128, arg_129) } else { bmap__7 = linked_126.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_125, arg_128, arg_129) }
//line :111:1
			var j__8 any; var tmp6 any = A_arbace_go_check_env_child_line_fn__1719000033_A_New_O_O(f__5, i__1); var tmp7 *jrt.Class
			var fncls__205 /*line :111:1*/*jrt.Class = A_arbace_go_check_env_child_line_fn__1719000033_A_fn_class


			if fncls__205 == nil { var fncls__205d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_check_env_child_line_fn__1719000033_A_fn_class = fncls__205d; tmp7 = fncls__205d } else { tmp7 = fncls__205 }; j__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :111:1
			var k__9 any
			var na_206 any = j__8


			if jrt.Long_InstanceOf(na_206) { var n0_207 int64 = jrt.NN(jrt.Long_Cast(na_206)).LongValue__J(); if n0_207 == 9223372036854775807 { k__9 = lang.Numbers_Inc_O__Number_NoInit(na_206) } else { k__9 = jrt.Long_ValueOf_J__Long_NoInit(n0_207 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_206) { var n0_207_2 float64 = jrt.NN(jrt.Double_Cast(na_206)).DoubleValue__D(); k__9 = jrt.Double_ValueOf_D__Double_NoInit(n0_207_2 + 1.0).Ref() } else { k__9 = lang.Numbers_Inc_O__Number_NoInit(na_206) } }
//line :111:1
			var line__10 any; var or__1927000174__auto____10 any; var root_208 any = A_arbace_go_check_env_A_const_39.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, A_arbace_go_check_env_line_of_A_fn_class); var ifn_210 lang.IFn



			if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(j__8)); if linked_209 == nil { or__1927000174__auto____10 = ifn_210.Invoke_O__O(arg_211) } else { or__1927000174__auto____10 = linked_209.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_208, arg_211) }; if jrt.J2g_Truth(or__1927000174__auto____10) { line__10 = or__1927000174__auto____10 } else { line__10 = start__2 }
//line :111:1
		L1: for {




			var tmp8 bool; var na_212 any = k__9; var na_213 any = i__1; var tmp9 bool; var tmp10 bool; tmp10 = jrt.Long_InstanceOf(na_212); if tmp10 { tmp10 = jrt.Long_InstanceOf(na_213) }; tmp9 = tmp10; if tmp9 { var n0_214 int64 = jrt.NN(jrt.Long_Cast(na_212)).LongValue__J(); var n1_215 int64 = jrt.NN(jrt.Long_Cast(na_213)).LongValue__J(); tmp8 = n0_214 > n1_215 } else { var tmp11 bool; var tmp12 bool; tmp12 = jrt.Double_InstanceOf(na_212); if tmp12 { tmp12 = jrt.Double_InstanceOf(na_213) }; tmp11 = tmp12; if tmp11 { var n0_214_2 float64 = jrt.NN(jrt.Double_Cast(na_212)).DoubleValue__D(); var n1_215_2 float64 = jrt.NN(jrt.Double_Cast(na_213)).DoubleValue__D(); tmp8 = n1_215_2 < n0_214_2 } else { tmp8 = lang.Numbers_Gt_O_O__Z_NoInit(na_212, na_213) } }; if tmp8 { return line__10 } else { var pe__11 any; var root_217 any = A_arbace_go_check_env_A_const_35.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, A_arbace_go_check_env_end_line_A_fn_class); var ifn_219 lang.IFn

				if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any; var tmp13 jrt.Number_I; var na_222 any = k__9; if jrt.Long_InstanceOf(na_222) { var n0_223 int64 = jrt.NN(jrt.Long_Cast(na_222)).LongValue__J(); if n0_223 == -9223372036854775808 { tmp13 = lang.Numbers_Dec_O__Number_NoInit(na_222) } else { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_223 - 1)) } } else { if jrt.Double_InstanceOf(na_222) { var n0_223_2 float64 = jrt.NN(jrt.Double_Cast(na_222)).DoubleValue__D(); tmp13 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_223_2 - 1.0)) } else { tmp13 = lang.Numbers_Dec_O__Number_NoInit(na_222) } }; arg_220 = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(tmp13)); var arg_221 any = line__10; if linked_218 == nil { pe__11 = ifn_219.Invoke_O_O__O(arg_220, arg_221) } else { pe__11 = linked_218.(*A_arbace_go_check_env_end_line_A).Invoke_O_O_O__O(root_217, arg_220, arg_221) }
				var tmp14 jrt.Number_I; var na_224 any = k__9; if jrt.Long_InstanceOf(na_224) { var n0_225 int64 = jrt.NN(jrt.Long_Cast(na_224)).LongValue__J(); if n0_225 == 9223372036854775807 { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_224) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_225 + 1)) } } else { if jrt.Double_InstanceOf(na_224) { var n0_225_2 float64 = jrt.NN(jrt.Double_Cast(na_224)).DoubleValue__D(); tmp14 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_225_2 + 1.0)) } else { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_224) } }; var tmp15 any = tmp14; var tmp16 any; var tmp17 any; var root_226 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = bmap__7; var arg_230 any = k__9; if linked_227 == nil { tmp17 = ifn_228.Invoke_O_O__O(arg_229, arg_230) } else { tmp17 = linked_227.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_226, arg_229, arg_230) }; if jrt.J2g_Truth(tmp17) { var or__1927000174__auto____12 any = lang.RT_Get_O_O__O_NoInit(bmap__7, k__9); if jrt.J2g_Truth(or__1927000174__auto____12) { tmp16 = or__1927000174__auto____12 } else { var na_231 any = pe__11; if jrt.Long_InstanceOf(na_231) { var n0_232 int64 = jrt.NN(jrt.Long_Cast(na_231)).LongValue__J(); if n0_232 == 9223372036854775807 { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_231) } else { tmp16 = jrt.Long_ValueOf_J__Long_NoInit(n0_232 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_231) { var n0_232_2 float64 = jrt.NN(jrt.Double_Cast(na_231)).DoubleValue__D(); tmp16 = jrt.Double_ValueOf_D__Double_NoInit(n0_232_2 + 1.0).Ref() } else { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_231) } } } } else { tmp16 = pe__11 }; k__9, line__10 = tmp15, tmp16; continue L1 } } } } else {
//line :108:1
					return nil } }; /*line :101:1*/panic("j2g: unreachable") }
//line :101:1
func (t *A_arbace_go_check_env_child_line_A) InvokeSpec_O_O_J_O_O__O(self, f__0 any, i__1_l int64, i__1_b, start__2 any) any {






	{ var tmp1 any; var and__1927000168__auto____4 any = start__2; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var or__1927000174__auto____5 any; var root_233 any = A_arbace_go_check_env_A_const_31.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = f__0; if linked_234 == nil { or__1927000174__auto____5 = ifn_235.Invoke_O__O(arg_236) } else { or__1927000174__auto____5 = linked_234.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_233, arg_236) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else { var root_237 any = A_arbace_go_check_env_A_const_32.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = f__0; if linked_238 == nil { and__1927000168__auto____5 = ifn_239.Invoke_O__O(arg_240) } else { and__1927000168__auto____5 = linked_238.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_237, arg_240) } }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp2 bool; var na_241 int64 = int64(lang.RT_Count_O__I_NoInit(f__0)); var n0_242 int64 = i__1_l; var n1_243 int64 = na_241; tmp2 = n0_242 < n1_243; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref() } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { var m__4 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__0); var f__5 any; var tmp3 any; var root_245 any = A_arbace_go_check_env_A_const_32.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_247 lang.IFn

		if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = f__0; if linked_246 == nil { tmp3 = ifn_247.Invoke_O__O(arg_248) } else { tmp3 = linked_246.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_245, arg_248) }; if jrt.J2g_Truth(tmp3) { f__5 = f__0 } else { var root_249 any = A_arbace_go_check_env_A_const_34.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = f__0; if linked_250 == nil { f__5 = ifn_251.Invoke_O__O(arg_252) } else { f__5 = linked_250.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_249, arg_252) } }
//line :108:1
		var or__1927000174__auto____6 any; var root_253 any = A_arbace_go_check_env_A_const_39.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, A_arbace_go_check_env_line_of_A_fn_class); var ifn_255 lang.IFn


		if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any; var tmp4 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp4 = i__1_b } else { tmp4 = i__1_b }; arg_256 = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(tmp4)); if linked_254 == nil { or__1927000174__auto____6 = ifn_255.Invoke_O__O(arg_256) } else { or__1927000174__auto____6 = linked_254.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_253, arg_256) }; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { var bmap__7 any; var root_257 any = A_arbace_go_check_env_A_const_40.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_259 lang.IFn

			if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_261 any; var iter__1927001039__auto____7 any; var tmp5 any = A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A_New(); var tmp6 *jrt.Class; var fncls__262 *jrt.Class = A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A_fn_class; if fncls__262 == nil { var fncls__262d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A_fn_class = fncls__262d; tmp6 = fncls__262d } else { tmp6 = fncls__262 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); arg_261 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(A_arbace_go_check_env_A_const_51.Invoke_O__O(m__4)); if linked_258 == nil { bmap__7 = ifn_259.Invoke_O_O__O(arg_260, arg_261) } else { bmap__7 = linked_258.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_257, arg_260, arg_261) }
//line :111:1
			var j__8 any; var tmp7 any


			if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp7 = i__1_b } else { tmp7 = i__1_b }; var tmp8 any = A_arbace_go_check_env_child_line_fn__1719000033_A_New_O_O(f__5, tmp7); var tmp9 *jrt.Class; var fncls__263 *jrt.Class = A_arbace_go_check_env_child_line_fn__1719000033_A_fn_class; if fncls__263 == nil { var fncls__263d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_check_env_child_line_fn__1719000033_A_fn_class = fncls__263d; tmp9 = fncls__263d } else { tmp9 = fncls__263 }; j__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O()
//line :111:1
			var k__9 any
			var na_264 any = j__8


			if jrt.Long_InstanceOf(na_264) { var n0_265 int64 = jrt.NN(jrt.Long_Cast(na_264)).LongValue__J(); if n0_265 == 9223372036854775807 { k__9 = lang.Numbers_Inc_O__Number_NoInit(na_264) } else { k__9 = jrt.Long_ValueOf_J__Long_NoInit(n0_265 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_264) { var n0_265_2 float64 = jrt.NN(jrt.Double_Cast(na_264)).DoubleValue__D(); k__9 = jrt.Double_ValueOf_D__Double_NoInit(n0_265_2 + 1.0).Ref() } else { k__9 = lang.Numbers_Inc_O__Number_NoInit(na_264) } }
//line :111:1
			var line__10 any; var or__1927000174__auto____10 any; var root_266 any = A_arbace_go_check_env_A_const_39.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, A_arbace_go_check_env_line_of_A_fn_class); var ifn_268 lang.IFn



			if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(j__8)); if linked_267 == nil { or__1927000174__auto____10 = ifn_268.Invoke_O__O(arg_269) } else { or__1927000174__auto____10 = linked_267.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_266, arg_269) }; if jrt.J2g_Truth(or__1927000174__auto____10) { line__10 = or__1927000174__auto____10 } else { line__10 = start__2 }
//line :111:1
		L1: for {




			var tmp10 bool; var na_270 any = k__9; if jrt.Long_InstanceOf(na_270) { var n0_271 int64 = jrt.NN(jrt.Long_Cast(na_270)).LongValue__J(); var n1_272 int64 = i__1_l; tmp10 = n0_271 > n1_272 } else { var tmp11 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp11 = i__1_b } else { tmp11 = i__1_b }; tmp10 = lang.Numbers_Gt_O_O__Z_NoInit(na_270, tmp11) }; if tmp10 { return line__10 } else { var pe__11 any; var root_274 any = A_arbace_go_check_env_A_const_35.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, A_arbace_go_check_env_end_line_A_fn_class); var ifn_276 lang.IFn

				if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any; var tmp12 jrt.Number_I; var na_279 any = k__9; if jrt.Long_InstanceOf(na_279) { var n0_280 int64 = jrt.NN(jrt.Long_Cast(na_279)).LongValue__J(); if n0_280 == -9223372036854775808 { tmp12 = lang.Numbers_Dec_O__Number_NoInit(na_279) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_280 - 1)) } } else { if jrt.Double_InstanceOf(na_279) { var n0_280_2 float64 = jrt.NN(jrt.Double_Cast(na_279)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_280_2 - 1.0)) } else { tmp12 = lang.Numbers_Dec_O__Number_NoInit(na_279) } }; arg_277 = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(tmp12)); var arg_278 any = line__10; if linked_275 == nil { pe__11 = ifn_276.Invoke_O_O__O(arg_277, arg_278) } else { pe__11 = linked_275.(*A_arbace_go_check_env_end_line_A).Invoke_O_O_O__O(root_274, arg_277, arg_278) }
				var tmp13 jrt.Number_I; var na_281 any = k__9; if jrt.Long_InstanceOf(na_281) { var n0_282 int64 = jrt.NN(jrt.Long_Cast(na_281)).LongValue__J(); if n0_282 == 9223372036854775807 { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_281) } else { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_282 + 1)) } } else { if jrt.Double_InstanceOf(na_281) { var n0_282_2 float64 = jrt.NN(jrt.Double_Cast(na_281)).DoubleValue__D(); tmp13 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_282_2 + 1.0)) } else { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_281) } }; var tmp14 any = tmp13; var tmp15 any; var tmp16 any; var root_283 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = bmap__7; var arg_287 any = k__9; if linked_284 == nil { tmp16 = ifn_285.Invoke_O_O__O(arg_286, arg_287) } else { tmp16 = linked_284.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_283, arg_286, arg_287) }; if jrt.J2g_Truth(tmp16) { var or__1927000174__auto____12 any = lang.RT_Get_O_O__O_NoInit(bmap__7, k__9); if jrt.J2g_Truth(or__1927000174__auto____12) { tmp15 = or__1927000174__auto____12 } else { var na_288 any = pe__11; if jrt.Long_InstanceOf(na_288) { var n0_289 int64 = jrt.NN(jrt.Long_Cast(na_288)).LongValue__J(); if n0_289 == 9223372036854775807 { tmp15 = lang.Numbers_Inc_O__Number_NoInit(na_288) } else { tmp15 = jrt.Long_ValueOf_J__Long_NoInit(n0_289 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_288) { var n0_289_2 float64 = jrt.NN(jrt.Double_Cast(na_288)).DoubleValue__D(); tmp15 = jrt.Double_ValueOf_D__Double_NoInit(n0_289_2 + 1.0).Ref() } else { tmp15 = lang.Numbers_Inc_O__Number_NoInit(na_288) } } } } else { tmp15 = pe__11 }; k__9, line__10 = tmp14, tmp15; continue L1 } } } } else {
//line :108:1
					return nil } }
//line :101:1
	panic("j2g: unreachable") }
//line :101:1
func (t *A_arbace_go_check_env_child_line_A) Invoke_O_O_O__O(self, f__0, i__1 any) any {




	var root_290 any = A_arbace_go_check_env_A_const_36.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_290, A_arbace_go_check_env_child_line_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = f__0; var arg_294 any = i__1; var arg_295 any; var root_296 any = A_arbace_go_check_env_A_const_39.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, A_arbace_go_check_env_line_of_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = f__0; if linked_297 == nil { arg_295 = ifn_298.Invoke_O__O(arg_299) } else { arg_295 = linked_297.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_296, arg_299) }; if linked_291 == nil { return ifn_292.Invoke_O_O_O__O(arg_293, arg_294, arg_295) } else { if jrt.Long_InstanceOf(arg_294) { return linked_291.(*A_arbace_go_check_env_child_line_A).InvokeSpec_O_O_J_O_O__O(root_290, arg_293, jrt.NN(jrt.Long_Cast(arg_294)).LongValue__J(), arg_294, arg_295) } else { return linked_291.(*A_arbace_go_check_env_child_line_A).Invoke_O_O_O_O__O(root_290, arg_293, arg_294, arg_295)
	}
	}
}



func A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A_New() *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A) Ctor() {}
//line :113:1
func (t *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A) Invoke_O_O__O(self, s__1719000024__1 any) any { var tmp1 any = A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A_New_O_O(s__1719000024__1, self); var tmp2 *jrt.Class; var fncls__195 *jrt.Class = A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A_fn_class; if fncls__195 == nil { var fncls__195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A_fn_class = fncls__195d; tmp2 = fncls__195d } else { tmp2 = fncls__195 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :113:1
func A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A_New_O_O(p0, p1 any) *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A{}; t.Ctor_O_O(p0, p1); return t }
//line :113:1
func (t *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A) Ctor_O_O(c__s__1719000024, c__iter__1719000023 any) { t.F_s__1719000024 = c__s__1719000024; t.F_iter__1719000023 = c__iter__1719000023 }
//line :113:1
func (t *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A) Invoke_O__O(self any) any { { var s__1719000024__1 any; var t_ any = t.F_s__1719000024; t.F_s__1719000024 = nil; s__1719000024__1 = t_; for { var temp__1927000414__auto____2 any; var root_130 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = s__1719000024__1; if linked_131 == nil { temp__1927000414__auto____2 = ifn_132.Invoke_O__O(arg_133) } else { temp__1927000414__auto____2 = linked_131.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_130, arg_133) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1719000024__3 any = temp__1927000414__auto____2; var tmp1 any; var root_134 any = A_arbace_go_check_env_A_const_41.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = s__1719000024__3; if linked_135 == nil { tmp1 = ifn_136.Invoke_O__O(arg_137) } else { tmp1 = linked_135.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_134, arg_137) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_138 any = A_arbace_go_check_env_A_const_42.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = s__1719000024__3; if linked_139 == nil { c__1927001037__auto____4 = ifn_140.Invoke_O__O(arg_141) } else { c__1927001037__auto____4 = linked_139.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_138, arg_141) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1719000026__6 any; var root_142 any = A_arbace_go_check_env_A_const_43.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_143 == nil { b__1719000026__6 = ifn_144.Invoke_O__O(arg_145) } else { b__1719000026__6 = linked_143.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_142, arg_145) }; var tmp2 any = A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A_New_O_I_O(b__1719000026__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A_fn_class = fncls__155d; tmp3 = fncls__155d } else { tmp3 = fncls__155 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_156 any = A_arbace_go_check_env_A_const_45.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any; var root_161 any = A_arbace_go_check_env_A_const_46.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = b__1719000026__6; if linked_162 == nil { arg_159 = ifn_163.Invoke_O__O(arg_164) } else { arg_159 = linked_162.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_161, arg_164) }; var arg_160 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1719000023); var tmp5 any; var root_165 any = A_arbace_go_check_env_A_const_47.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = s__1719000024__3; if linked_166 == nil { tmp5 = ifn_167.Invoke_O__O(arg_168) } else { tmp5 = linked_166.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_165, arg_168) }; arg_160 = tmp4.Invoke_O__O(tmp5); if linked_157 == nil { return ifn_158.Invoke_O_O__O(arg_159, arg_160) } else { return linked_157.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_156, arg_159, arg_160) } } else { var root_169 any = A_arbace_go_check_env_A_const_45.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any; var root_174 any = A_arbace_go_check_env_A_const_46.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = b__1719000026__6; if linked_175 == nil { arg_172 = ifn_176.Invoke_O__O(arg_177) } else { arg_172 = linked_175.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_174, arg_177) }; var arg_173 any; if linked_170 == nil { return ifn_171.Invoke_O_O__O(arg_172, arg_173) } else { return linked_170.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_169, arg_172, arg_173) } } } else { var b__4 any; var root_178 any = A_arbace_go_check_env_A_const_48.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = s__1719000024__3; if linked_179 == nil { b__4 = ifn_180.Invoke_O__O(arg_181) } else { b__4 = linked_179.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_178, arg_181) }; var root_182 any = A_arbace_go_check_env_A_const_49.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any; var tmp6 any; var root_187 any = A_arbace_go_check_env_A_const_32.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = b__4; if linked_188 == nil { tmp6 = ifn_189.Invoke_O__O(arg_190) } else { tmp6 = linked_188.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_187, arg_190) }; if jrt.J2g_Truth(tmp6) { arg_185 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(b__4, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(b__4, lang.RT_IntCast_J__I_NoInit(1))) } else { arg_185 = lang.Tuple_Create_O_O__IPersistentVector(b__4, nil) }; var arg_186 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1719000023); var tmp8 any; var root_191 any = A_arbace_go_check_env_A_const_50.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = s__1719000024__3; if linked_192 == nil { tmp8 = ifn_193.Invoke_O__O(arg_194) } else { tmp8 = linked_192.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_191, arg_194) }; arg_186 = tmp7.Invoke_O__O(tmp8); if linked_183 == nil { return ifn_184.Invoke_O_O__O(arg_185, arg_186) } else { return linked_183.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_182, arg_185, arg_186) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :113:1
func A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :113:1
func (t *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A) Ctor_O_I_O(c__b__1719000026 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1719000026 = c__b__1719000026; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :113:1
func (t *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A) Invoke_O__O(self any) any { { var i__1719000025__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1719000025__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1719000025__1)); var root_146 any = A_arbace_go_check_env_A_const_44.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = t.F_b__1719000026; var arg_150 any; var tmp2 any; var root_151 any = A_arbace_go_check_env_A_const_32.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = b__2; if linked_152 == nil { tmp2 = ifn_153.Invoke_O__O(arg_154) } else { tmp2 = linked_152.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_151, arg_154) }; if jrt.J2g_Truth(tmp2) { arg_150 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(b__2, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(b__2, lang.RT_IntCast_J__I_NoInit(1))) } else { arg_150 = lang.Tuple_Create_O_O__IPersistentVector(b__2, nil) }; if linked_147 == nil { ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { linked_147.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) }; i__1719000025__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1719000025__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_env_child_line_fn__1719000033_A_New_O_O(p0, p1 any) *A_arbace_go_check_env_child_line_fn__1719000033_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_child_line_fn__1719000033_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_go_check_env_child_line_fn__1719000033_A) Ctor_O_O(c__f, c__i any) { t.F_f = c__f; t.F_i = c__i }
//line :114:1
func (t *A_arbace_go_check_env_child_line_fn__1719000033_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_i; t.F_i = nil; j__1 = t_; L1: for { var tmp1 any; var or__1927000174__auto____2 bool; var na_197 any = j__1; if jrt.Long_InstanceOf(na_197) { var n0_198 int64 = jrt.NN(jrt.Long_Cast(na_197)).LongValue__J(); or__1927000174__auto____2 = n0_198 == 0 } else { if jrt.Double_InstanceOf(na_197) { var n0_198_2 float64 = jrt.NN(jrt.Double_Cast(na_197)).DoubleValue__D(); or__1927000174__auto____2 = n0_198_2 == 0.0 } else { or__1927000174__auto____2 = lang.Numbers_IsZero_O__Z_NoInit(na_197) } }; if or__1927000174__auto____2 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var root_199 any = A_arbace_go_check_env_A_const_39.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, A_arbace_go_check_env_line_of_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var tmp2 any = t.F_f; var arg_202 any = lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(j__1)); if linked_200 == nil { tmp1 = ifn_201.Invoke_O__O(arg_202) } else { tmp1 = linked_200.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_199, arg_202) } }; if jrt.J2g_Truth(tmp1) { return j__1 } else { var tmp3 jrt.Number_I; var na_203 any = j__1; if jrt.Long_InstanceOf(na_203) { var n0_204 int64 = jrt.NN(jrt.Long_Cast(na_203)).LongValue__J(); if n0_204 == -9223372036854775808 { tmp3 = lang.Numbers_Dec_O__Number_NoInit(na_203) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_204 - 1)) } } else { if jrt.Double_InstanceOf(na_203) { var n0_204_2 float64 = jrt.NN(jrt.Double_Cast(na_203)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_204_2 - 1.0)) } else { tmp3 = lang.Numbers_Dec_O__Number_NoInit(na_203) } }; j__1 = tmp3; continue L1 } } }; panic("j2g: unreachable") }











func A_arbace_go_check_env_with_child_line_A_New() *A_arbace_go_check_env_with_child_line_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_with_child_line_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_go_check_env_with_child_line_A) Ctor() {}
//line :126:1
func (t *A_arbace_go_check_env_with_child_line_A) DoInvoke_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, parent__2, i__3, body__4 any) any { var root_300 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_53.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_55); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp4 any; var root_310 any = A_arbace_go_check_env_A_const_56.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = A_arbace_go_check_env_A_const_57.GetRawRoot__O(); var arg_314 any; var root_315 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_53.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_58); var tmp7 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(parent__2); var tmp8 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_59); var tmp9 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(i__3); var tmp10 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_60); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp12 any; var root_328 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_53.GetRawRoot__O()); var tmp14 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_61); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp16 any; var root_338 any = A_arbace_go_check_env_A_const_56.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = A_arbace_go_check_env_A_const_57.GetRawRoot__O(); var arg_342 any; var root_343 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any; var root_347 any = A_arbace_go_check_env_A_const_53.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; if linked_348 == nil { arg_346 = ifn_349.Invoke__O() } else { arg_346 = linked_348.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O__O(root_347) }; if linked_344 == nil { arg_342 = ifn_345.Invoke_O__O(arg_346) } else { arg_342 = linked_344.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_343, arg_346) }; if linked_339 == nil { tmp16 = ifn_340.Invoke_O_O__O(arg_341, arg_342) } else { tmp16 = linked_339.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_338, arg_341, arg_342) }; arg_331 = tmp13.Invoke_O_O_O__O(tmp14, tmp15.Invoke_O__O(tmp16), body__4); if linked_329 == nil { tmp12 = ifn_330.Invoke_O__O(arg_331) } else { tmp12 = linked_329.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_328, arg_331) }; arg_318 = tmp5.Invoke_O_O_O_O_O_O__O(tmp6, tmp7, tmp8, tmp9, tmp10, tmp11.Invoke_O__O(tmp12)); if linked_316 == nil { arg_314 = ifn_317.Invoke_O__O(arg_318) } else { arg_314 = linked_316.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_315, arg_318) }; if linked_311 == nil { tmp4 = ifn_312.Invoke_O_O__O(arg_313, arg_314) } else { tmp4 = linked_311.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_310, arg_313, arg_314) }; var tmp17 any = tmp3.Invoke_O__O(tmp4); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp19 any; var root_350 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_53.GetRawRoot__O()); var tmp21 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_62); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp23 any; var root_361 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_363 lang.IFn; if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any; var root_365 any = A_arbace_go_check_env_A_const_53.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_365, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_63); var arg_369 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp25 any; var root_370 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_53.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_64), lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_58), lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_59), lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(nil)); if linked_371 == nil { tmp25 = ifn_372.Invoke_O__O(arg_373) } else { tmp25 = linked_371.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_370, arg_373) }; arg_369 = tmp24.Invoke_O__O(tmp25); if linked_366 == nil { arg_364 = ifn_367.Invoke_O_O__O(arg_368, arg_369) } else { arg_364 = linked_366.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_365, arg_368, arg_369) }; if linked_362 == nil { tmp23 = ifn_363.Invoke_O__O(arg_364) } else { tmp23 = linked_362.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_361, arg_364) }; var tmp26 any = tmp22.Invoke_O__O(tmp23); var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp28 any; var root_381 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any; var root_385 any = A_arbace_go_check_env_A_const_53.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_60); if linked_386 == nil { arg_384 = ifn_387.Invoke_O__O(arg_388) } else { arg_384 = linked_386.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_385, arg_388) }; if linked_382 == nil { tmp28 = ifn_383.Invoke_O__O(arg_384) } else { tmp28 = linked_382.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_381, arg_384) }; var tmp29 any = tmp27.Invoke_O__O(tmp28); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp31 any; var root_389 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_53.GetRawRoot__O()); var tmp33 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_65); var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp35 any; var root_399 any = A_arbace_go_check_env_A_const_56.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = A_arbace_go_check_env_A_const_57.GetRawRoot__O(); var arg_403 any; var root_404 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any; var root_408 any = A_arbace_go_check_env_A_const_53.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_66); var arg_412 any; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp37 any; var root_413 any = A_arbace_go_check_env_A_const_56.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = A_arbace_go_check_env_A_const_57.GetRawRoot__O(); var arg_417 any; var root_418 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any; var root_422 any = A_arbace_go_check_env_A_const_53.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_58); var arg_426 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_59); if linked_423 == nil { arg_421 = ifn_424.Invoke_O_O__O(arg_425, arg_426) } else { arg_421 = linked_423.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_422, arg_425, arg_426) }; if linked_419 == nil { arg_417 = ifn_420.Invoke_O__O(arg_421) } else { arg_417 = linked_419.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_418, arg_421) }; if linked_414 == nil { tmp37 = ifn_415.Invoke_O_O__O(arg_416, arg_417) } else { tmp37 = linked_414.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_413, arg_416, arg_417) }; arg_412 = tmp36.Invoke_O__O(tmp37); if linked_409 == nil { arg_407 = ifn_410.Invoke_O_O__O(arg_411, arg_412) } else { arg_407 = linked_409.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_408, arg_411, arg_412) }; if linked_405 == nil { arg_403 = ifn_406.Invoke_O__O(arg_407) } else { arg_403 = linked_405.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_404, arg_407) }; if linked_400 == nil { tmp35 = ifn_401.Invoke_O_O__O(arg_402, arg_403) } else { tmp35 = linked_400.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_399, arg_402, arg_403) }; var tmp38 any = tmp34.Invoke_O__O(tmp35); var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp40 any; var root_427 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any; var root_431 any = A_arbace_go_check_env_A_const_53.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_433 lang.IFn; if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_60); if linked_432 == nil { arg_430 = ifn_433.Invoke_O__O(arg_434) } else { arg_430 = linked_432.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_431, arg_434) }; if linked_428 == nil { tmp40 = ifn_429.Invoke_O__O(arg_430) } else { tmp40 = linked_428.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_427, arg_430) }; arg_392 = tmp32.Invoke_O_O_O__O(tmp33, tmp38, tmp39.Invoke_O__O(tmp40)); if linked_390 == nil { tmp31 = ifn_391.Invoke_O__O(arg_392) } else { tmp31 = linked_390.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_389, arg_392) }; arg_353 = tmp20.Invoke_O_O_O_O__O(tmp21, tmp26, tmp29, tmp30.Invoke_O__O(tmp31)); if linked_351 == nil { tmp19 = ifn_352.Invoke_O__O(arg_353) } else { tmp19 = linked_351.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_350, arg_353) }; arg_303 = tmp1.Invoke_O_O_O__O(tmp2, tmp17, tmp18.Invoke_O__O(tmp19)); if linked_301 == nil { return ifn_302.Invoke_O__O(arg_303) } else { return linked_301.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_300, arg_303) } }







func A_arbace_go_check_env_current_line_A_New() *A_arbace_go_check_env_current_line_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_current_line_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_go_check_env_current_line_A) Ctor() {}
//line :134:1
func (t *A_arbace_go_check_env_current_line_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var temp__1927000414__auto____1 any = A_arbace_go_check_env_A_const_67.Get__O(); if


	jrt.J2g_Truth(temp__1927000414__auto____1) { var vec__1719000044__2 any = temp__1927000414__auto____1; var p__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000044__2, lang.RT_IntCast_J__I_NoInit(0), nil); var i__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000044__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_435 any = A_arbace_go_check_env_A_const_36.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, A_arbace_go_check_env_child_line_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = p__3; var arg_439 any = i__4; if linked_436 == nil { or__1927000174__auto____1 = ifn_437.Invoke_O_O__O(arg_438, arg_439) } else { or__1927000174__auto____1 = linked_436.(*A_arbace_go_check_env_child_line_A).Invoke_O_O_O__O(root_435, arg_438, arg_439) } } else { or__1927000174__auto____1 = nil }; if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { return A_arbace_go_check_env_A_const_68.Get__O() } }

func A_arbace_go_check_env_err_BANG__A_New() *A_arbace_go_check_env_err_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_err_BANG__A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_go_check_env_err_BANG__A) Ctor() {}
//line :139:1
func (t *A_arbace_go_check_env_err_BANG__A) DoInvoke_O_O_O_O_O__O(self, f__0, code__1, fmt__2, args__3 any) any {


	var root_440 any = A_arbace_go_check_env_A_const_28.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any; var or__1927000174__auto____5 any; var root_446 any = A_arbace_go_check_env_A_const_39.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, A_arbace_go_check_env_line_of_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = f__0; if linked_447 == nil { or__1927000174__auto____5 = ifn_448.Invoke_O__O(arg_449) } else { or__1927000174__auto____5 = linked_447.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_446, arg_449) }; if jrt.J2g_Truth(or__1927000174__auto____5) { arg_443 = or__1927000174__auto____5 } else { var root_450 any = A_arbace_go_check_env_A_const_69.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, A_arbace_go_check_env_current_line_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; if linked_451 == nil { arg_443 = ifn_452.Invoke__O() } else { arg_443 = linked_451.(*A_arbace_go_check_env_current_line_A).Invoke_O__O(root_450) } }; var arg_444 any = code__1; var arg_445 any; var tmp1 any; var root_453 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = args__3; if linked_454 == nil { tmp1 = ifn_455.Invoke_O__O(arg_456) } else { tmp1 = linked_454.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_453, arg_456) }; if jrt.J2g_Truth(tmp1) { var root_457 any = A_arbace_go_check_env_A_const_56.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = A_arbace_go_check_env_A_const_70.GetRawRoot__O(); var arg_461 any = fmt__2; var arg_462 any = args__3; if linked_458 == nil { arg_445 = ifn_459.Invoke_O_O_O__O(arg_460, arg_461, arg_462) } else { arg_445 = linked_458.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_457, arg_460, arg_461, arg_462) } } else { arg_445 = fmt__2 }; if linked_441 == nil { return ifn_442.Invoke_O_O_O__O(arg_443, arg_444, arg_445) } else { return linked_441.(*A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O__O(root_440, arg_443, arg_444, arg_445)
	}
}

func A_arbace_go_check_env_generic_BANG__A_New() *A_arbace_go_check_env_generic_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_generic_BANG__A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_go_check_env_generic_BANG__A) Ctor() {}
//line :146:1
func (t *A_arbace_go_check_env_generic_BANG__A) Invoke_O__O(self any) any {



	if jrt.J2g_Truth(A_arbace_go_check_env_A_const_25.Get__O()) { var tmp1 *lang.Volatile = lang.Volatile_Cast(A_arbace_go_check_env_A_const_25.Get__O()); var tmp2 any; var root_463 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_25.Get__O())).Deref__O(); var arg_467 any = A_arbace_go_check_env_A_const_71; var arg_468 any = jrt.Boolean_TRUE.Ref(); if linked_464 == nil { tmp2 = ifn_465.Invoke_O_O_O__O(arg_466, arg_467, arg_468) } else { tmp2 = linked_464.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_463, arg_466, arg_467, arg_468) }; return jrt.NN(tmp1).Reset_O__O(tmp2) } else { return nil
	} }
func A_arbace_go_check_env_unsupported_BANG__A_New() *A_arbace_go_check_env_unsupported_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_unsupported_BANG__A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_go_check_env_unsupported_BANG__A) Ctor() {}
//line :152:1
func (t *A_arbace_go_check_env_unsupported_BANG__A) Invoke_O_O__O(self, what__0 any) any {




	var root_469 any = A_arbace_go_check_env_A_const_72.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, A_arbace_go_check_env_generic_BANG__A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; if linked_470 == nil { ifn_471.Invoke__O() } else { linked_470.(*A_arbace_go_check_env_generic_BANG__A).Invoke_O__O(root_469) }
	var tmp1 any; var and__1927000168__auto____2 any = A_arbace_go_check_env_A_const_25.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Keyword = A_arbace_go_check_env_A_const_73; var tmp3 any; var root_472 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = A_arbace_go_check_env_A_const_25.Get__O(); if linked_473 == nil { tmp3 = ifn_474.Invoke_O__O(arg_475) } else { tmp3 = linked_473.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_472, arg_475) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2.Invoke_O__O(tmp3), nil)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_12.GetRawRoot__O()); var tmp5 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_25.Get__O())).Deref__O(); var tmp6 any = A_arbace_go_check_env_A_const_73; var tmp7 any = A_arbace_go_check_env_A_const_74; jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_25.Get__O())).Reset_O__O(tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, what__0, tmp7, A_arbace_go_check_env_A_const_68.Get__O())) }
//line :152:1
	return nil
}








func A_arbace_go_check_env_unsupported_QMARK__A_New() *A_arbace_go_check_env_unsupported_QMARK__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_unsupported_QMARK__A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_go_check_env_unsupported_QMARK__A) Ctor() {}
//line :162:1
func (t *A_arbace_go_check_env_unsupported_QMARK__A) Invoke_O_O__O(self, e__0 any) any { var and__1927000168__auto____2 bool = lang.ExceptionInfo_InstanceOf(e__0); if and__1927000168__auto____2 { var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_75; var tmp2 any; var root_484 any = A_arbace_go_check_env_A_const_76.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = e__0; if linked_485 == nil { tmp2 = ifn_486.Invoke_O__O(arg_487) } else { tmp2 = linked_485.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_484, arg_487) }; return tmp1.Invoke_O__O(tmp2) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }








func A_arbace_go_check_env_verified_BANG__A_New() *A_arbace_go_check_env_verified_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_verified_BANG__A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_go_check_env_verified_BANG__A) Ctor() {}
//line :171:1
func (t *A_arbace_go_check_env_verified_BANG__A) Invoke_O_O_O__O(self, k__0, f__1 any) any {




	if jrt.J2g_Truth(A_arbace_go_check_env_A_const_25.Get__O()) { var seen__3 any; var or__1927000174__auto____3 any = A_arbace_go_check_env_A_const_77.Get__O()
		if jrt.J2g_Truth(or__1927000174__auto____3) { seen__3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_78; var tmp2 any; var root_488 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = A_arbace_go_check_env_A_const_25.Get__O(); if linked_489 == nil { tmp2 = ifn_490.Invoke_O__O(arg_491) } else { tmp2 = linked_489.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_488, arg_491) }; or__1927000174__auto____4 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(or__1927000174__auto____4) { seen__3 = or__1927000174__auto____4 } else { var m__5 any = jrt.IdentityHashMap_New(); var tmp3 *lang.Volatile = lang.Volatile_Cast(A_arbace_go_check_env_A_const_25.Get__O()); var tmp4 any; var root_501 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_503 lang.IFn
			if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_25.Get__O())).Deref__O(); var arg_505 any = A_arbace_go_check_env_A_const_78; var arg_506 any = m__5; if linked_502 == nil { tmp4 = ifn_503.Invoke_O_O_O__O(arg_504, arg_505, arg_506) } else { tmp4 = linked_502.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_501, arg_504, arg_505, arg_506) }; jrt.NN(tmp3).Reset_O__O(tmp4)
//line :177:1
			seen__3 = m__5 } }
//line :176:1
		var ks__4 any = jrt.NN(jrt.IdentityHashMap_Cast(seen__3)).Get_O__O(f__1); var tmp5 any; var root_492 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_494 lang.IFn



		if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = ks__4; var arg_496 any = k__0; if linked_493 == nil { tmp5 = ifn_494.Invoke_O_O__O(arg_495, arg_496) } else { tmp5 = linked_493.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_492, arg_495, arg_496) }; if jrt.J2g_Truth(tmp5) { return nil } else {
			var tmp6 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(seen__3); var tmp7 any; var root_507 any = A_arbace_go_check_env_A_const_9.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any; var or__1927000174__auto____5 any = ks__4; if jrt.J2g_Truth(or__1927000174__auto____5) { arg_510 = or__1927000174__auto____5 } else { arg_510 = lang.PersistentHashSet_EMPTY.Ref() }; var arg_511 any = k__0; if linked_508 == nil { tmp7 = ifn_509.Invoke_O_O__O(arg_510, arg_511) } else { tmp7 = linked_508.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_507, arg_510, arg_511) }; jrt.NN(tmp6).Put_O_O__O(f__1, tmp7)
			var root_497 any = A_arbace_go_check_env_A_const_79.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = k__0; if linked_498 == nil { return ifn_499.Invoke_O__O(arg_500) } else { return linked_498.(*A_arbace_go_check_env_verified_BANG__A).Invoke_O_O__O(root_497, arg_500) } } } else {
//line :176:1
				return nil } }
//line :171:1
func (t *A_arbace_go_check_env_verified_BANG__A) Invoke_O_O__O(self, k__0 any) any {


	if jrt.J2g_Truth(A_arbace_go_check_env_A_const_25.Get__O()) { var tmp1 *lang.Volatile = lang.Volatile_Cast(A_arbace_go_check_env_A_const_25.Get__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_80.GetRawRoot__O()); var tmp3 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_25.Get__O())).Deref__O(); var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_env_A_const_81, k__0); var tmp5 any; var root_518 any = A_arbace_go_check_env_A_const_82.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = A_arbace_go_check_env_A_const_83.GetRawRoot__O(); var arg_522 any = A_arbace_go_check_env_A_const_38; if linked_519 == nil { tmp5 = ifn_520.Invoke_O_O__O(arg_521, arg_522) } else { tmp5 = linked_519.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_518, arg_521, arg_522) }; return jrt.NN(tmp1).Reset_O__O(tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5)) } else { return nil
	}
}







func A_arbace_go_check_env_annotation_error_BANG__A_New() *A_arbace_go_check_env_annotation_error_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_annotation_error_BANG__A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_go_check_env_annotation_error_BANG__A) Ctor() {}
//line :184:1
func (t *A_arbace_go_check_env_annotation_error_BANG__A) Invoke_O_O_O_O_O_O__O(self, f__0, a__1, what__2, forms_say__3, checker_says__4 any) any {


	return lang.IFn_Cast(A_arbace_go_check_env_A_const_84.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(f__0, A_arbace_go_check_env_A_const_85, Lit_1, a__1, what__2, forms_say__3, checker_says__4)
}










func A_arbace_go_check_env_at_of_A_New() *A_arbace_go_check_env_at_of_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_at_of_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_go_check_env_at_of_A) Ctor() {}
//line :199:1
func (t *A_arbace_go_check_env_at_of_A) Invoke_O_O__O(self, f__0 any) any {


	if lang.IMeta_InstanceOf(f__0) { var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_86; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)) } else { return nil
	} }
func A_arbace_go_check_env_answer_BANG__A_New() *A_arbace_go_check_env_answer_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_answer_BANG__A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_go_check_env_answer_BANG__A) Ctor() {}
//line :204:1
func (t *A_arbace_go_check_env_answer_BANG__A) Invoke_O_O_O_O__O(self, f__0, k__1, m__2 any) any { var temp__1927000414__auto____4 any = A_arbace_go_check_env_A_const_87.Get__O(); if







	jrt.J2g_Truth(temp__1927000414__auto____4) { var a__5 any = temp__1927000414__auto____4; var temp__1927000414__auto____6 any; var root_533 any = A_arbace_go_check_env_A_const_88.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, A_arbace_go_check_env_at_of_A_fn_class); var ifn_535 lang.IFn
		if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = f__0; if linked_534 == nil { temp__1927000414__auto____6 = ifn_535.Invoke_O__O(arg_536) } else { temp__1927000414__auto____6 = linked_534.(*A_arbace_go_check_env_at_of_A).Invoke_O_O__O(root_533, arg_536) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var vec__1719000055__7 any = temp__1927000414__auto____6; var file__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000055__7, lang.RT_IntCast_J__I_NoInit(0), nil); var pm__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000055__7, lang.RT_IntCast_J__I_NoInit(1), nil); var temp__1927000414__auto____10 any = lang.RT_Get_O_O__O_NoInit(pm__9, k__1)
			if jrt.J2g_Truth(temp__1927000414__auto____10) { var p__11 any = temp__1927000414__auto____10; var at__12 any; var tmp1 any
				if lang.Util_Equiv_O_O__Z_NoInit(k__1, A_arbace_go_check_env_A_const_90) { tmp1 = A_arbace_go_check_env_A_const_91 } else { tmp1 = k__1 }
//line :214:1
				at__12 = lang.Tuple_Create_O_O__IPersistentVector(file__8, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, p__11)))

				var tmp2 jrt.HashMap_I = jrt.HashMap_Cast(a__5); var tmp3 any; var root_537 any = A_arbace_go_check_env_A_const_89.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = jrt.HashMap_Cast(a__5).Get_O__O(at__12); var arg_541 any = m__2; if linked_538 == nil { tmp3 = ifn_539.Invoke_O_O__O(arg_540, arg_541) } else { tmp3 = linked_538.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_537, arg_540, arg_541) }; return tmp2.Put_O_O__O(at__12, tmp3) } else {
//line :214:1
					return nil } } else {
//line :213:1
						return nil } } else {
//line :212:1
							return nil } }
//line :204:1
func (t *A_arbace_go_check_env_answer_BANG__A) Invoke_O_O_O__O(self, f__0, m__1 any) any { var temp__1927000414__auto____3 any = A_arbace_go_check_env_A_const_87.Get__O(); if



	jrt.J2g_Truth(temp__1927000414__auto____3) { var a__4 any = temp__1927000414__auto____3; var temp__1927000414__auto____5 any; var root_542 any = A_arbace_go_check_env_A_const_88.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, A_arbace_go_check_env_at_of_A_fn_class); var ifn_544 lang.IFn
		if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = f__0; if linked_543 == nil { temp__1927000414__auto____5 = ifn_544.Invoke_O__O(arg_545) } else { temp__1927000414__auto____5 = linked_543.(*A_arbace_go_check_env_at_of_A).Invoke_O_O__O(root_542, arg_545) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var at__6 any = temp__1927000414__auto____5; var tmp1 jrt.HashMap_I = jrt.HashMap_Cast(a__4); var tmp2 any; var root_546 any = A_arbace_go_check_env_A_const_89.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_548 lang.IFn
			if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = jrt.HashMap_Cast(a__4).Get_O__O(at__6); var arg_550 any = m__1; if linked_547 == nil { tmp2 = ifn_548.Invoke_O_O__O(arg_549, arg_550) } else { tmp2 = linked_547.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_546, arg_549, arg_550) }; return tmp1.Put_O_O__O(at__6, tmp2) } else {
//line :209:1
				return nil } } else {
//line :208:1
					return nil } }









func A_arbace_go_check_env_unanswer_BANG__A_New() *A_arbace_go_check_env_unanswer_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_unanswer_BANG__A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_go_check_env_unanswer_BANG__A) Ctor() {}
//line :218:1
func (t *A_arbace_go_check_env_unanswer_BANG__A) Invoke_O_O_O__O(self, f__0, ks__1 any) any { var temp__1927000414__auto____3 any = A_arbace_go_check_env_A_const_87.Get__O(); if


	jrt.J2g_Truth(temp__1927000414__auto____3) { var a__4 any = temp__1927000414__auto____3; var temp__1927000414__auto____5 any; var root_551 any = A_arbace_go_check_env_A_const_88.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, A_arbace_go_check_env_at_of_A_fn_class); var ifn_553 lang.IFn
		if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = f__0; if linked_552 == nil { temp__1927000414__auto____5 = ifn_553.Invoke_O__O(arg_554) } else { temp__1927000414__auto____5 = linked_552.(*A_arbace_go_check_env_at_of_A).Invoke_O_O__O(root_551, arg_554) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var at__6 any = temp__1927000414__auto____5; var temp__1927000414__auto____7 any = jrt.HashMap_Cast(a__4).Get_O__O(at__6)
			if jrt.J2g_Truth(temp__1927000414__auto____7) { var m__8 any = temp__1927000414__auto____7; var tmp1 jrt.HashMap_I = jrt.HashMap_Cast(a__4); var tmp2 any; var root_555 any = A_arbace_go_check_env_A_const_56.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_557 lang.IFn
				if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = A_arbace_go_check_env_A_const_92.GetRawRoot__O(); var arg_559 any = m__8; var arg_560 any = ks__1; if linked_556 == nil { tmp2 = ifn_557.Invoke_O_O_O__O(arg_558, arg_559, arg_560) } else { tmp2 = linked_556.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_555, arg_558, arg_559, arg_560) }; return tmp1.Put_O_O__O(at__6, tmp2) } else {
//line :223:1
					return nil } } else {
//line :222:1
						return nil } } else {
//line :221:1
							return nil } }








func A_arbace_go_check_env_def_type_BANG__A_New() *A_arbace_go_check_env_def_type_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_def_type_BANG__A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_go_check_env_def_type_BANG__A) Ctor() {}
//line :230:1
func (t *A_arbace_go_check_env_def_type_BANG__A) Invoke_O_O_O__O(self, n__0, kw__1 any) any {
	var root_561 any = A_arbace_go_check_env_A_const_93.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = A_arbace_go_check_env_A_const_94.GetRawRoot__O(); var arg_565 any = n__0; var arg_566 any; var root_567 any = A_arbace_go_check_env_A_const_95.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, A_arbace_go_check_env_obj_A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any; var G__1719000060__3_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env_A_const_15, A_arbace_go_check_env_A_const_96, A_arbace_go_check_env_A_const_29, n__0, A_arbace_go_check_env_A_const_96, kw__1, A_arbace_go_check_env_A_const_97, jrt.Boolean_TRUE.Ref())); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_go_check_env_A_const_98).Invoke_O__O(n__0)) {

		var root_571 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = G__1719000060__3_; var arg_575 any = A_arbace_go_check_env_A_const_99; var arg_576 any; var root_577 any = A_arbace_go_check_env_A_const_100.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_579 lang.IFn; if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = n__0; if linked_578 == nil { arg_576 = ifn_579.Invoke_O__O(arg_580) } else { arg_576 = linked_578.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_577, arg_580) }; if linked_572 == nil { arg_570 = ifn_573.Invoke_O_O_O__O(arg_574, arg_575, arg_576) } else { arg_570 = linked_572.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_571, arg_574, arg_575, arg_576) } } else {
//line :231:1
			arg_570 = G__1719000060__3_ }; if linked_568 == nil { arg_566 = ifn_569.Invoke_O__O(arg_570) } else { arg_566 = linked_568.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_567, arg_570) }; if linked_562 == nil { return ifn_563.Invoke_O_O_O__O(arg_564, arg_565, arg_566) } else { return linked_562.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_561, arg_564, arg_565, arg_566)
			}
}









func A_arbace_go_check_env_fn__1719000074_A_New() *A_arbace_go_check_env_fn__1719000074_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_fn__1719000074_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_go_check_env_fn__1719000074_A) Ctor() {}
//line :243:1
func (t *A_arbace_go_check_env_fn__1719000074_A) Invoke_O__O(self any) any { var nt__1 any; var root_581 any = A_arbace_go_check_env_A_const_101.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_go_check_types.A_arbace_go_check_types_new_named_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = A_arbace_go_check_env_A_const_102; if linked_582 == nil { nt__1 = ifn_583.Invoke_O__O(arg_584) } else { nt__1 = linked_582.(*aot_arbace_go_check_types.A_arbace_go_check_types_new_named_A).Invoke_O_O__O(root_581, arg_584) }; var tmp1 lang.IFn =
										lang.IFn_Cast(A_arbace_go_check_env_A_const_103.GetRawRoot__O()); var tmp2 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var tmp3 any = A_arbace_go_check_env_A_const_104; var tmp4 any = A_arbace_go_check_env_A_const_105; var tmp5 any = A_arbace_go_check_env_A_const_29; var tmp6 any = A_arbace_go_check_env_A_const_106; var tmp7 any = A_arbace_go_check_env_A_const_96; tmp1.Invoke_O_O_O_O__O(nt__1, tmp2, tmp3, lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, Lit_8, tmp6, nil, tmp7, lang.Tuple_Create_O_O_O_O__IPersistentVector(A_arbace_go_check_env_A_const_107, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_env_A_const_108, jrt.Boolean_FALSE.Ref())))), nil)); return nt__1 }







func A_arbace_go_check_env_fn__1719000080_A_New() *A_arbace_go_check_env_fn__1719000080_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_fn__1719000080_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_go_check_env_fn__1719000080_A) Ctor() {}
//line :252:1
func (t *A_arbace_go_check_env_fn__1719000080_A) Invoke_O__O(self any) any { var nt__1 any; var root_592 any = A_arbace_go_check_env_A_const_101.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_go_check_types.A_arbace_go_check_types_new_named_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = A_arbace_go_check_env_A_const_109; if linked_593 == nil { nt__1 = ifn_594.Invoke_O__O(arg_595) } else { nt__1 = linked_593.(*aot_arbace_go_check_types.A_arbace_go_check_types_new_named_A).Invoke_O_O__O(root_592, arg_595) }; var tmp1 lang.IFn =
										lang.IFn_Cast(A_arbace_go_check_env_A_const_103.GetRawRoot__O()); var tmp2 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var tmp3 any = A_arbace_go_check_env_A_const_104; var tmp4 any = A_arbace_go_check_env_A_const_105; var tmp5 any = lang.PersistentVector_EMPTY.Ref(); var tmp6 any; var root_603 any = A_arbace_go_check_env_A_const_110.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_go_check_types.A_arbace_go_check_types_make_tset_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = A_arbace_go_check_env_A_const_111; var arg_607 any = jrt.Boolean_TRUE.Ref(); if linked_604 == nil { tmp6 = ifn_605.Invoke_O_O__O(arg_606, arg_607) } else { tmp6 = linked_604.(*aot_arbace_go_check_types.A_arbace_go_check_types_make_tset_A).Invoke_O_O_O__O(root_603, arg_606, arg_607) }; tmp1.Invoke_O_O_O_O__O(nt__1, tmp2, tmp3, lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, tmp5, tmp6)); return nt__1 }



















func A_arbace_go_check_env_fn__1719000098_A_New() *A_arbace_go_check_env_fn__1719000098_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_fn__1719000098_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_go_check_env_fn__1719000098_A) Ctor() {}
//line :273:1
func (t *A_arbace_go_check_env_fn__1719000098_A) Invoke_O__O(self any) any { var s__1 any; var root_608 any = A_arbace_go_check_env_A_const_112.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_608, A_arbace_go_check_env_scope_A_fn_class); var ifn_610 lang.IFn; if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any; var arg_612 any = A_arbace_go_check_env_A_const_113; if linked_609 == nil { s__1 = ifn_610.Invoke_O_O__O(arg_611, arg_612) } else { s__1 = linked_609.(*A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_608, arg_611, arg_612) }; var root_613 any =
										A_arbace_go_check_env_A_const_93.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_613, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_615 lang.IFn; if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any = s__1; var arg_617 any = Lit_9; var arg_618 any; var root_619 any = A_arbace_go_check_env_A_const_95.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, A_arbace_go_check_env_obj_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = A_arbace_go_check_env_A_const_114; if linked_620 == nil { arg_618 = ifn_621.Invoke_O__O(arg_622) } else { arg_618 = linked_620.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_619, arg_622) }; if linked_614 == nil { ifn_615.Invoke_O_O_O__O(arg_616, arg_617, arg_618) } else { linked_614.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_613, arg_616, arg_617, arg_618) }; var seq_1719000099__2 any; var root_623 any = /*line :273:1*/A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_625 lang.IFn; if

	linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = A_arbace_go_check_env_A_const_115; if linked_624 == nil { seq_1719000099__2 = ifn_625.Invoke_O__O(arg_626) } else { seq_1719000099__2 = linked_624.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_623, arg_626) }; var chunk_1719000100__3 any; var count_1719000101__4 int64 = 0; var i_1719000102__5 int64 = 0; L1:
//line :273:1
	for {

		if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000102__5, count_1719000101__4) { var n__6 any = lang.Indexed_Cast(chunk_1719000100__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000102__5)); var root_643 any = A_arbace_go_check_env_A_const_93.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_645 lang.IFn
			if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = s__1; var arg_647 any = n__6; var arg_648 any; var root_649 any = A_arbace_go_check_env_A_const_95.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, A_arbace_go_check_env_obj_A_fn_class); var ifn_651 lang.IFn; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env_A_const_15, A_arbace_go_check_env_A_const_116, A_arbace_go_check_env_A_const_29, n__6, A_arbace_go_check_env_A_const_117, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_env_A_const_106, Lit_10)); if linked_650 == nil { arg_648 = ifn_651.Invoke_O__O(arg_652) } else { arg_648 = linked_650.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_649, arg_652) }; if linked_644 == nil { ifn_645.Invoke_O_O_O__O(arg_646, arg_647, arg_648) } else { linked_644.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_643, arg_646, arg_647, arg_648) }
//line :275:1
			seq_1719000099__2, chunk_1719000100__3, count_1719000101__4, i_1719000102__5 = seq_1719000099__2, chunk_1719000100__3, count_1719000101__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000102__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_627 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_629 lang.IFn; if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = seq_1719000099__2; if linked_628 == nil { temp__1927000414__auto____6 = ifn_629.Invoke_O__O(arg_630) } else { temp__1927000414__auto____6 = linked_628.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_627, arg_630) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1719000099__7 any = temp__1927000414__auto____6; var tmp1 any; var root_631 any = A_arbace_go_check_env_A_const_41.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = seq_1719000099__7; if linked_632 == nil { tmp1 = ifn_633.Invoke_O__O(arg_634) } else { tmp1 = linked_632.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_631, arg_634) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____8 any; var root_635 any = A_arbace_go_check_env_A_const_42.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = seq_1719000099__7; if linked_636 == nil { c__1927000678__auto____8 = ifn_637.Invoke_O__O(arg_638) } else { c__1927000678__auto____8 = linked_636.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_635, arg_638) }; var tmp2 any; var root_653 any = A_arbace_go_check_env_A_const_47.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = seq_1719000099__7; if linked_654 == nil { tmp2 = ifn_655.Invoke_O__O(arg_656) } else { tmp2 = linked_654.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_653, arg_656) }; seq_1719000099__2, chunk_1719000100__3, count_1719000101__4, i_1719000102__5 = tmp2, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_639 any = A_arbace_go_check_env_A_const_48.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = seq_1719000099__7; if linked_640 == nil { n__8 = ifn_641.Invoke_O__O(arg_642) } else { n__8 = linked_640.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_639, arg_642) }
				var root_657 any = A_arbace_go_check_env_A_const_93.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = s__1; var arg_661 any = n__8; var arg_662 any; var root_663 any = A_arbace_go_check_env_A_const_95.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, A_arbace_go_check_env_obj_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env_A_const_15, A_arbace_go_check_env_A_const_116, A_arbace_go_check_env_A_const_29, n__8, A_arbace_go_check_env_A_const_117, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_env_A_const_106, Lit_10)); if linked_664 == nil { arg_662 = ifn_665.Invoke_O__O(arg_666) } else { arg_662 = linked_664.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_663, arg_666) }; if linked_658 == nil { ifn_659.Invoke_O_O_O__O(arg_660, arg_661, arg_662) } else { linked_658.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_657, arg_660, arg_661, arg_662) }
//line :275:1
				var tmp3 any; var root_667 any = A_arbace_go_check_env_A_const_118.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = seq_1719000099__7; if linked_668 == nil { tmp3 = ifn_669.Invoke_O__O(arg_670) } else { tmp3 = linked_668.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_667, arg_670) }; seq_1719000099__2, chunk_1719000100__3, count_1719000101__4, i_1719000102__5 = tmp3, nil, 0, 0; continue L1 } } }
//line :273:1
		break L1 }; return s__1 }







type A_arbace_go_check_env_A struct{ jrt.Object }

var A_arbace_go_check_env_A_const_pool *jrt.RefArray

var A_arbace_go_check_env_A_const_0 *lang.Var

var A_arbace_go_check_env_A_const_1 any

var A_arbace_go_check_env_A_const_2 any

var A_arbace_go_check_env_A_const_3 any

var A_arbace_go_check_env_A_const_4 *lang.Var

var A_arbace_go_check_env_A_const_5 any

var A_arbace_go_check_env_A_const_6 *lang.Var

var A_arbace_go_check_env_A_const_7 *lang.Var

var A_arbace_go_check_env_A_const_8 *lang.Var

var A_arbace_go_check_env_A_const_9 *lang.Var

var A_arbace_go_check_env_A_const_10 any

var A_arbace_go_check_env_A_const_11 *lang.Var

var A_arbace_go_check_env_A_const_12 *lang.Var

var A_arbace_go_check_env_A_const_13 *lang.Keyword

var A_arbace_go_check_env_A_const_14 *lang.Keyword

var A_arbace_go_check_env_A_const_15 *lang.Keyword

var A_arbace_go_check_env_A_const_16 *lang.Var

var A_arbace_go_check_env_A_const_17 *lang.Var

var A_arbace_go_check_env_A_const_18 *lang.Var

var A_arbace_go_check_env_A_const_19 *lang.Var

var A_arbace_go_check_env_A_const_20 *lang.Keyword

var A_arbace_go_check_env_A_const_21 *lang.Keyword

var A_arbace_go_check_env_A_const_22 *lang.Keyword

var A_arbace_go_check_env_A_const_23 *lang.Keyword

var A_arbace_go_check_env_A_const_24 *lang.Keyword

var A_arbace_go_check_env_A_const_25 *lang.Var

var A_arbace_go_check_env_A_const_26 *lang.Var

var A_arbace_go_check_env_A_const_27 *lang.Keyword

var A_arbace_go_check_env_A_const_28 *lang.Var

var A_arbace_go_check_env_A_const_29 *lang.Keyword

var A_arbace_go_check_env_A_const_30 *lang.Var

var A_arbace_go_check_env_A_const_31 *lang.Var

var A_arbace_go_check_env_A_const_32 *lang.Var

var A_arbace_go_check_env_A_const_33 *lang.Var

var A_arbace_go_check_env_A_const_34 *lang.Var

var A_arbace_go_check_env_A_const_35 *lang.Var

var A_arbace_go_check_env_A_const_36 *lang.Var

var A_arbace_go_check_env_A_const_37 *lang.Keyword

var A_arbace_go_check_env_A_const_38 any

var A_arbace_go_check_env_A_const_39 *lang.Var

var A_arbace_go_check_env_A_const_40 *lang.Var

var A_arbace_go_check_env_A_const_41 *lang.Var

var A_arbace_go_check_env_A_const_42 *lang.Var

var A_arbace_go_check_env_A_const_43 *lang.Var

var A_arbace_go_check_env_A_const_44 *lang.Var

var A_arbace_go_check_env_A_const_45 *lang.Var

var A_arbace_go_check_env_A_const_46 *lang.Var

var A_arbace_go_check_env_A_const_47 *lang.Var

var A_arbace_go_check_env_A_const_48 *lang.Var

var A_arbace_go_check_env_A_const_49 *lang.Var

var A_arbace_go_check_env_A_const_50 *lang.Var

var A_arbace_go_check_env_A_const_51 *lang.Keyword

var A_arbace_go_check_env_A_const_52 *lang.Var

var A_arbace_go_check_env_A_const_53 *lang.Var

var A_arbace_go_check_env_A_const_54 *lang.Var

var A_arbace_go_check_env_A_const_55 any

var A_arbace_go_check_env_A_const_56 *lang.Var

var A_arbace_go_check_env_A_const_57 *lang.Var

var A_arbace_go_check_env_A_const_58 any

var A_arbace_go_check_env_A_const_59 any

var A_arbace_go_check_env_A_const_60 any

var A_arbace_go_check_env_A_const_61 any

var A_arbace_go_check_env_A_const_62 any

var A_arbace_go_check_env_A_const_63 any

var A_arbace_go_check_env_A_const_64 any

var A_arbace_go_check_env_A_const_65 any

var A_arbace_go_check_env_A_const_66 any

var A_arbace_go_check_env_A_const_67 *lang.Var

var A_arbace_go_check_env_A_const_68 *lang.Var

var A_arbace_go_check_env_A_const_69 *lang.Var

var A_arbace_go_check_env_A_const_70 *lang.Var

var A_arbace_go_check_env_A_const_71 *lang.Keyword

var A_arbace_go_check_env_A_const_72 *lang.Var

var A_arbace_go_check_env_A_const_73 *lang.Keyword

var A_arbace_go_check_env_A_const_74 *lang.Keyword

var A_arbace_go_check_env_A_const_75 *lang.Keyword

var A_arbace_go_check_env_A_const_76 *lang.Var

var A_arbace_go_check_env_A_const_77 *lang.Var

var A_arbace_go_check_env_A_const_78 *lang.Keyword

var A_arbace_go_check_env_A_const_79 *lang.Var

var A_arbace_go_check_env_A_const_80 *lang.Var

var A_arbace_go_check_env_A_const_81 *lang.Keyword

var A_arbace_go_check_env_A_const_82 *lang.Var

var A_arbace_go_check_env_A_const_83 *lang.Var

var A_arbace_go_check_env_A_const_84 *lang.Var

var A_arbace_go_check_env_A_const_85 *lang.Keyword

var A_arbace_go_check_env_A_const_86 *lang.Keyword

var A_arbace_go_check_env_A_const_87 *lang.Var

var A_arbace_go_check_env_A_const_88 *lang.Var

var A_arbace_go_check_env_A_const_89 *lang.Var

var A_arbace_go_check_env_A_const_90 *lang.Keyword

var A_arbace_go_check_env_A_const_91 *lang.Keyword

var A_arbace_go_check_env_A_const_92 *lang.Var

var A_arbace_go_check_env_A_const_93 *lang.Var

var A_arbace_go_check_env_A_const_94 *lang.Var

var A_arbace_go_check_env_A_const_95 *lang.Var

var A_arbace_go_check_env_A_const_96 *lang.Keyword

var A_arbace_go_check_env_A_const_97 *lang.Keyword

var A_arbace_go_check_env_A_const_98 any

var A_arbace_go_check_env_A_const_99 *lang.Keyword

var A_arbace_go_check_env_A_const_100 *lang.Var

var A_arbace_go_check_env_A_const_101 *lang.Var

var A_arbace_go_check_env_A_const_102 any

var A_arbace_go_check_env_A_const_103 *lang.Var

var A_arbace_go_check_env_A_const_104 *lang.Keyword

var A_arbace_go_check_env_A_const_105 *lang.Keyword

var A_arbace_go_check_env_A_const_106 *lang.Keyword

var A_arbace_go_check_env_A_const_107 *lang.Keyword

var A_arbace_go_check_env_A_const_108 any

var A_arbace_go_check_env_A_const_109 any

var A_arbace_go_check_env_A_const_110 *lang.Var

var A_arbace_go_check_env_A_const_111 *lang.Keyword

var A_arbace_go_check_env_A_const_112 *lang.Var

var A_arbace_go_check_env_A_const_113 *lang.Keyword

var A_arbace_go_check_env_A_const_114 any

var A_arbace_go_check_env_A_const_115 any

var A_arbace_go_check_env_A_const_116 *lang.Keyword

var A_arbace_go_check_env_A_const_117 *lang.Keyword

var A_arbace_go_check_env_A_const_118 *lang.Var

var A_arbace_go_check_env_A_init jrt.ClassInit

func A_arbace_go_check_env_A_Init() { if !A_arbace_go_check_env_A_init.Done() { A_arbace_go_check_env_A_init.Run(A_arbace_go_check_env_A_clinit) } }

func A_arbace_go_check_env_A_clinit() { A_arbace_go_check_env_A_clinit_p0(); A_arbace_go_check_env_A_clinit_p1(); A_arbace_go_check_env_A_clinit_p2(); A_arbace_go_check_env_A_clinit_p3(); A_arbace_go_check_env_A_clinit_p4(); A_arbace_go_check_env_A_clinit_p5(); A_arbace_go_check_env_A_clinit_p6(); A_arbace_go_check_env_A_clinit_p7(); A_arbace_go_check_env_A_clinit_p8(); A_arbace_go_check_env_A_clinit_p9() }

func A_arbace_go_check_env_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_env_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 174); A_arbace_go_check_env_A_const_0 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[55]); A_arbace_go_check_env_A_const_1 = A_arbace_go_check_env_A_const_pool.A[56]; A_arbace_go_check_env_A_const_2 = A_arbace_go_check_env_A_const_pool.A[57]; A_arbace_go_check_env_A_const_3 = A_arbace_go_check_env_A_const_pool.A[58]; A_arbace_go_check_env_A_const_4 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[59]); A_arbace_go_check_env_A_const_5 = A_arbace_go_check_env_A_const_pool.A[60]; A_arbace_go_check_env_A_const_6 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[61]); A_arbace_go_check_env_A_const_7 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[62]); A_arbace_go_check_env_A_const_8 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[63]); A_arbace_go_check_env_A_const_9 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[64]); A_arbace_go_check_env_A_const_10 = A_arbace_go_check_env_A_const_pool.A[65]; A_arbace_go_check_env_A_const_11 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[66]) }

func A_arbace_go_check_env_A_clinit_p1() { A_arbace_go_check_env_A_const_12 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[67]); A_arbace_go_check_env_A_const_13 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[68]); A_arbace_go_check_env_A_const_14 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[69]); A_arbace_go_check_env_A_const_15 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[70]); A_arbace_go_check_env_A_const_16 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[71]); A_arbace_go_check_env_A_const_17 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[72]); A_arbace_go_check_env_A_const_18 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[73]); A_arbace_go_check_env_A_const_19 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[74]); A_arbace_go_check_env_A_const_20 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[75]); A_arbace_go_check_env_A_const_21 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[76]); A_arbace_go_check_env_A_const_22 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[77]); A_arbace_go_check_env_A_const_23 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[78]) }

func A_arbace_go_check_env_A_clinit_p2() { A_arbace_go_check_env_A_const_24 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[79]); A_arbace_go_check_env_A_const_25 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[80]); A_arbace_go_check_env_A_const_26 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[81]); A_arbace_go_check_env_A_const_27 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[82]); A_arbace_go_check_env_A_const_28 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[83]); A_arbace_go_check_env_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[84]); A_arbace_go_check_env_A_const_30 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[85]); A_arbace_go_check_env_A_const_31 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[86]); A_arbace_go_check_env_A_const_32 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[87]); A_arbace_go_check_env_A_const_33 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[88]); A_arbace_go_check_env_A_const_34 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[89]); A_arbace_go_check_env_A_const_35 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[90]) }

func A_arbace_go_check_env_A_clinit_p3() { A_arbace_go_check_env_A_const_36 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[91]); A_arbace_go_check_env_A_const_37 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[92]); A_arbace_go_check_env_A_const_38 = A_arbace_go_check_env_A_const_pool.A[93]; A_arbace_go_check_env_A_const_39 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[94]); A_arbace_go_check_env_A_const_40 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[95]); A_arbace_go_check_env_A_const_41 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[96]); A_arbace_go_check_env_A_const_42 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[97]); A_arbace_go_check_env_A_const_43 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[98]); A_arbace_go_check_env_A_const_44 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[99]); A_arbace_go_check_env_A_const_45 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[100]); A_arbace_go_check_env_A_const_46 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[101]); A_arbace_go_check_env_A_const_47 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[102]) }

func A_arbace_go_check_env_A_clinit_p4() { A_arbace_go_check_env_A_const_48 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[103]); A_arbace_go_check_env_A_const_49 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[104]); A_arbace_go_check_env_A_const_50 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[105]); A_arbace_go_check_env_A_const_51 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[106]); A_arbace_go_check_env_A_const_52 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[107]); A_arbace_go_check_env_A_const_53 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[108]); A_arbace_go_check_env_A_const_54 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[109]); A_arbace_go_check_env_A_const_55 = A_arbace_go_check_env_A_const_pool.A[110]; A_arbace_go_check_env_A_const_56 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[111]); A_arbace_go_check_env_A_const_57 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[112]); A_arbace_go_check_env_A_const_58 = A_arbace_go_check_env_A_const_pool.A[113]; A_arbace_go_check_env_A_const_59 = A_arbace_go_check_env_A_const_pool.A[114]; A_arbace_go_check_env_A_const_60 = A_arbace_go_check_env_A_const_pool.A[115] }

func A_arbace_go_check_env_A_clinit_p5() { A_arbace_go_check_env_A_const_61 = A_arbace_go_check_env_A_const_pool.A[116]; A_arbace_go_check_env_A_const_62 = A_arbace_go_check_env_A_const_pool.A[117]; A_arbace_go_check_env_A_const_63 = A_arbace_go_check_env_A_const_pool.A[118]; A_arbace_go_check_env_A_const_64 = A_arbace_go_check_env_A_const_pool.A[119]; A_arbace_go_check_env_A_const_65 = A_arbace_go_check_env_A_const_pool.A[120]; A_arbace_go_check_env_A_const_66 = A_arbace_go_check_env_A_const_pool.A[121]; A_arbace_go_check_env_A_const_67 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[122]); A_arbace_go_check_env_A_const_68 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[123]); A_arbace_go_check_env_A_const_69 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[124]); A_arbace_go_check_env_A_const_70 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[125]); A_arbace_go_check_env_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[126]); A_arbace_go_check_env_A_const_72 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[127]); A_arbace_go_check_env_A_const_73 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[128]) }

func A_arbace_go_check_env_A_clinit_p6() { A_arbace_go_check_env_A_const_74 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[129]); A_arbace_go_check_env_A_const_75 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[130]); A_arbace_go_check_env_A_const_76 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[131]); A_arbace_go_check_env_A_const_77 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[132]); A_arbace_go_check_env_A_const_78 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[133]); A_arbace_go_check_env_A_const_79 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[134]); A_arbace_go_check_env_A_const_80 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[135]); A_arbace_go_check_env_A_const_81 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[136]); A_arbace_go_check_env_A_const_82 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[137]); A_arbace_go_check_env_A_const_83 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[138]); A_arbace_go_check_env_A_const_84 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[139]); A_arbace_go_check_env_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[140]) }

func A_arbace_go_check_env_A_clinit_p7() { A_arbace_go_check_env_A_const_86 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[141]); A_arbace_go_check_env_A_const_87 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[142]); A_arbace_go_check_env_A_const_88 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[143]); A_arbace_go_check_env_A_const_89 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[144]); A_arbace_go_check_env_A_const_90 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[145]); A_arbace_go_check_env_A_const_91 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[146]); A_arbace_go_check_env_A_const_92 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[147]); A_arbace_go_check_env_A_const_93 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[148]); A_arbace_go_check_env_A_const_94 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[149]); A_arbace_go_check_env_A_const_95 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[150]); A_arbace_go_check_env_A_const_96 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[151]); A_arbace_go_check_env_A_const_97 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[152]) }

func A_arbace_go_check_env_A_clinit_p8() { A_arbace_go_check_env_A_const_98 = A_arbace_go_check_env_A_const_pool.A[153]; A_arbace_go_check_env_A_const_99 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[154]); A_arbace_go_check_env_A_const_100 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[155]); A_arbace_go_check_env_A_const_101 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[156]); A_arbace_go_check_env_A_const_102 = A_arbace_go_check_env_A_const_pool.A[157]; A_arbace_go_check_env_A_const_103 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[158]); A_arbace_go_check_env_A_const_104 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[159]); A_arbace_go_check_env_A_const_105 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[160]); A_arbace_go_check_env_A_const_106 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[161]); A_arbace_go_check_env_A_const_107 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[162]); A_arbace_go_check_env_A_const_108 = A_arbace_go_check_env_A_const_pool.A[163]; A_arbace_go_check_env_A_const_109 = A_arbace_go_check_env_A_const_pool.A[164]; A_arbace_go_check_env_A_const_110 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[165]) }

func A_arbace_go_check_env_A_clinit_p9() { A_arbace_go_check_env_A_const_111 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[166]); A_arbace_go_check_env_A_const_112 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[167]); A_arbace_go_check_env_A_const_113 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[168]); A_arbace_go_check_env_A_const_114 = A_arbace_go_check_env_A_const_pool.A[169]; A_arbace_go_check_env_A_const_115 = A_arbace_go_check_env_A_const_pool.A[170]; A_arbace_go_check_env_A_const_116 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[171]); A_arbace_go_check_env_A_const_117 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[172]); A_arbace_go_check_env_A_const_118 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[173]) }

func A_arbace_go_check_env_A_New() *A_arbace_go_check_env_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env_A) Ctor() {}

func (t *A_arbace_go_check_env_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env_A_class }

func (t *A_arbace_go_check_env_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env_A); return ok }

func A_arbace_go_check_env_A_Cast(x any) *A_arbace_go_check_env_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env_A_class)) }; return v }



type A_arbace_go_check_env_annotation_error_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_annotation_error_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_answer_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_answer_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_at_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_at_of_A_fn_class *jrt.Class



type A_arbace_go_check_env_child_line_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_child_line_A_fn_class *jrt.Class



type A_arbace_go_check_env_child_line_fn__1719000033_A struct{ j2g_header uint64; F_f, F_i any }

var A_arbace_go_check_env_child_line_fn__1719000033_A_fn_class *jrt.Class



type A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A_fn_class *jrt.Class



type A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A struct{ j2g_header uint64; F_s__1719000024, F_iter__1719000023 any }

var A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A_fn_class *jrt.Class



type A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A struct{ j2g_header uint64; F_b__1719000026 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A_fn_class *jrt.Class



type A_arbace_go_check_env_current_line_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_current_line_A_fn_class *jrt.Class



type A_arbace_go_check_env_def_type_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_def_type_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_end_line_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_end_line_A_fn_class *jrt.Class



type A_arbace_go_check_env_err_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_err_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_error_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_error_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_eval1719000004_A struct{ jrt.Object }

func A_arbace_go_check_env_eval1719000004_A_New() *A_arbace_go_check_env_eval1719000004_A { t := &A_arbace_go_check_env_eval1719000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env_eval1719000004_A) Ctor() {}

func (t *A_arbace_go_check_env_eval1719000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env_eval1719000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env_eval1719000004_A_class }

func (t *A_arbace_go_check_env_eval1719000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env_eval1719000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env_eval1719000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env_eval1719000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env_eval1719000004_A); return ok }

func A_arbace_go_check_env_eval1719000004_A_Cast(x any) *A_arbace_go_check_env_eval1719000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env_eval1719000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env_eval1719000004_A_class)) }; return v }



type A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class *jrt.Class



type A_arbace_go_check_env_eval1719000008_A struct{ jrt.Object }

func A_arbace_go_check_env_eval1719000008_A_New() *A_arbace_go_check_env_eval1719000008_A { t := &A_arbace_go_check_env_eval1719000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env_eval1719000008_A) Ctor() {}

func (t *A_arbace_go_check_env_eval1719000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env_eval1719000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env_eval1719000008_A_class }

func (t *A_arbace_go_check_env_eval1719000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env_eval1719000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env_eval1719000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env_eval1719000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env_eval1719000008_A); return ok }

func A_arbace_go_check_env_eval1719000008_A_Cast(x any) *A_arbace_go_check_env_eval1719000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env_eval1719000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env_eval1719000008_A_class)) }; return v }



type A_arbace_go_check_env_eval1719000008_fn__1719000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class *jrt.Class



type A_arbace_go_check_env_fn__1719000074_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_fn__1719000074_A_fn_class *jrt.Class



type A_arbace_go_check_env_fn__1719000080_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_fn__1719000080_A_fn_class *jrt.Class



type A_arbace_go_check_env_fn__1719000098_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_fn__1719000098_A_fn_class *jrt.Class



type A_arbace_go_check_env_generic_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_generic_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_line_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_line_of_A_fn_class *jrt.Class



type A_arbace_go_check_env_o_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_o_A_fn_class *jrt.Class



type A_arbace_go_check_env_obj_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_obj_A_fn_class *jrt.Class



type A_arbace_go_check_env_obj_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_obj_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_env_oset_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_oset_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_scope_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_scope_A_fn_class *jrt.Class



type A_arbace_go_check_env_scope_get_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_scope_get_A_fn_class *jrt.Class



type A_arbace_go_check_env_scope_lookup_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_scope_lookup_A_fn_class *jrt.Class



type A_arbace_go_check_env_scope_put_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_scope_put_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_unanswer_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_unanswer_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_unsupported_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_unsupported_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_unsupported_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_unsupported_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_env_verified_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_verified_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_with_child_line_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_with_child_line_A_fn_class *jrt.Class
