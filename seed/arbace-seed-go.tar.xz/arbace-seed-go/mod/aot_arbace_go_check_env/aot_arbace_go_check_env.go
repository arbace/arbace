//line aot_arbace_go_check_env.ae:1
package aot_arbace_go_check_env

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_types"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_New() *A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_env_A_const_4.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_5); tmp2 = lang.IFn_Cast(A_arbace_go_check_env_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_go_check_env_A_const_1, A_arbace_go_check_env_A_const_2, A_arbace_go_check_env_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_env_eval1719000008_fn__1719000009_A_New() *A_arbace_go_check_env_eval1719000008_fn__1719000009_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_eval1719000008_fn__1719000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_env_eval1719000008_fn__1719000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_env_eval1719000008_fn__1719000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_go_check_env_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_env_A_const_9.GetRawRoot__O(), A_arbace_go_check_env_A_const_10) }













func A_arbace_go_check_env_obj_A_New() *A_arbace_go_check_env_obj_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_obj_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_go_check_env_obj_A) Ctor() {}
//line :15:1
func (t *A_arbace_go_check_env_obj_A) Invoke_O_O__O(self, m__0 any) any { var root_21 any = A_arbace_go_check_env_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = m__0; if linked_22 == nil { return ifn_23.Invoke_O__O(arg_24) } else { return linked_22.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_21, arg_24) } }
func A_arbace_go_check_env_o_A_New() *A_arbace_go_check_env_o_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_o_A{}; t.Ctor(); return t }
//line :16:1
func (t *A_arbace_go_check_env_o_A) Ctor() {}
//line :16:1
func (t *A_arbace_go_check_env_o_A) Invoke_O_O_O__O(self, x__0, k__1 any) any { var tmp1 any; var root_25 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = x__0; if linked_26 == nil { tmp1 = ifn_27.Invoke_O__O(arg_28) } else { tmp1 = linked_26.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_25, arg_28) }; return lang.RT_Get_O_O__O_NoInit(tmp1, k__1) }
func A_arbace_go_check_env_oset_BANG__A_New() *A_arbace_go_check_env_oset_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_oset_BANG__A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_go_check_env_oset_BANG__A) Ctor() {}
//line :17:1
func (t *A_arbace_go_check_env_oset_BANG__A) Invoke_O_O_O_O__O(self, x__0, k__1, v__2 any) any { var tmp1 *lang.Volatile = lang.Volatile_Cast(x__0); var tmp2 any; var root_29 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = jrt.NN(lang.Volatile_Cast(x__0)).Deref__O(); var arg_33 any = k__1; var arg_34 any = v__2; if linked_30 == nil { tmp2 = ifn_31.Invoke_O_O_O__O(arg_32, arg_33, arg_34) } else { tmp2 = linked_30.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_29, arg_32, arg_33, arg_34) }; jrt.NN(tmp1).Reset_O__O(tmp2); return x__0 }
func A_arbace_go_check_env_obj_QMARK__A_New() *A_arbace_go_check_env_obj_QMARK__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_obj_QMARK__A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_go_check_env_obj_QMARK__A) Ctor() {}
//line :18:1
func (t *A_arbace_go_check_env_obj_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Volatile_InstanceOf(x__0)).Ref() }



func A_arbace_go_check_env_scope_A_New() *A_arbace_go_check_env_scope_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_scope_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_go_check_env_scope_A) Ctor() {}
//line :22:1
func (t *A_arbace_go_check_env_scope_A) Invoke_O_O_O__O(self, parent__0, kind__1 any) any { var tmp1 any = A_arbace_go_check_env_A_const_13; var tmp2 any = A_arbace_go_check_env_A_const_14; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, parent__0, tmp2, jrt.HashMap_New(), A_arbace_go_check_env_A_const_15, kind__1)) }

func A_arbace_go_check_env_scope_lookup_A_New() *A_arbace_go_check_env_scope_lookup_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_scope_lookup_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_env_scope_lookup_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_env_scope_lookup_A) Invoke_O_O_O__O(self, s__0, n__1 any) any { { var s__3 any = s__0; L1: for {



	if jrt.J2g_Truth(s__3) { var temp__1927000408__auto____4 any = jrt.HashMap_Cast(A_arbace_go_check_env_A_const_14.Invoke_O__O(s__3)).Get_O__O(n__1)
		if jrt.J2g_Truth(temp__1927000408__auto____4) { var x__5 any = temp__1927000408__auto____4; return x__5 } else {

			s__3 = A_arbace_go_check_env_A_const_13.Invoke_O__O(s__3); continue L1 } } else {
//line :28:1
				return nil } } }; /*line :24:1*/panic("j2g: unreachable") }








func A_arbace_go_check_env_scope_get_A_New() *A_arbace_go_check_env_scope_get_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_scope_get_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_go_check_env_scope_get_A) Ctor() {}
//line :33:1
func (t *A_arbace_go_check_env_scope_get_A) Invoke_O_O_O__O(self, s__0, n__1 any) any { return jrt.HashMap_Cast(A_arbace_go_check_env_A_const_14.Invoke_O__O(s__0)).Get_O__O(n__1) }
func A_arbace_go_check_env_scope_put_BANG__A_New() *A_arbace_go_check_env_scope_put_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_scope_put_BANG__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_go_check_env_scope_put_BANG__A) Ctor() {}
//line :34:1
func (t *A_arbace_go_check_env_scope_put_BANG__A) Invoke_O_O_O_O__O(self, s__0, n__1, x__2 any) any { return jrt.HashMap_Cast(A_arbace_go_check_env_A_const_14.Invoke_O__O(s__0)).Put_O_O__O(n__1, x__2) }

































func A_arbace_go_check_env_error_BANG__A_New() *A_arbace_go_check_env_error_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_error_BANG__A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_go_check_env_error_BANG__A) Ctor() {}
//line :68:1
func (t *A_arbace_go_check_env_error_BANG__A) Invoke_O_O_O_O_O__O(self, file__0, line__1, code__2, msg__3 any) any {



	var tmp1 any; var and__1927000168__auto____5 any = A_arbace_go_check_env_A_const_16.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____5) {


		var root_35 any = A_arbace_go_check_env_A_const_17.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any; var and__1927000168__auto____6 any; var root_39 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any; var root_43 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = A_arbace_go_check_env_A_const_16.Get__O(); if linked_44 == nil { arg_42 = ifn_45.Invoke_O__O(arg_46) } else { arg_42 = linked_44.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_43, arg_46) }; if linked_40 == nil { and__1927000168__auto____6 = ifn_41.Invoke_O__O(arg_42) } else { and__1927000168__auto____6 = linked_40.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_39, arg_42) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var m__7 any = msg__3; var or__1927000174__auto____8 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(m__7)).IndexOf_String__I(Lit_6)))

			if or__1927000174__auto____8 { arg_38 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { arg_38 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(m__7)).IndexOf_String__I(Lit_7)))).Ref() } } else {
//line :75:1
				arg_38 = and__1927000168__auto____6 }; if linked_36 == nil { tmp1 = ifn_37.Invoke_O__O(arg_38) } else { tmp1 = linked_36.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_35, arg_38) } } else {
//line :72:1
					tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var col__5 any





						if jrt.J2g_Truth(A_arbace_go_check_env_A_const_19.Get__O()) { col__5 = nil } else { col__5 = A_arbace_go_check_env_A_const_20.Get__O() }
//line :72:1
						var line__6 any; var or__1927000174__auto____6 any = A_arbace_go_check_env_A_const_19.Get__O()






						if jrt.J2g_Truth(or__1927000174__auto____6) { line__6 = or__1927000174__auto____6 } else { line__6 = line__1 }
//line :72:1
						var e__7 any; var tmp2 any = A_arbace_go_check_env_A_const_21; var tmp3 any = A_arbace_go_check_env_A_const_22; var tmp4 any = A_arbace_go_check_env_A_const_23; var tmp5 any = A_arbace_go_check_env_A_const_24; var tmp6 any = A_arbace_go_check_env_A_const_25; var tmp7 any = A_arbace_go_check_env_A_const_26; var tmp8 any








						if jrt.J2g_Truth(A_arbace_go_check_env_A_const_27.Get__O()) { var root_47 any = A_arbace_go_check_env_A_const_28.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, A_arbace_go_check_env_o_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = A_arbace_go_check_env_A_const_27.Get__O(); var arg_51 any = A_arbace_go_check_env_A_const_29; if linked_48 == nil { tmp8 = ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { tmp8 = linked_48.(*A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) } } else { tmp8 = nil }
//line :72:1
						e__7 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, file__0, tmp3, line__6, tmp4, col__5, tmp5, msg__3, tmp6, code__2, tmp7, tmp8))









						var tmp9 *lang.Volatile = lang.Volatile_Cast(A_arbace_go_check_env_A_const_16.Get__O()); var tmp10 any; var root_52 any = A_arbace_go_check_env_A_const_9.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_16.Get__O())).Deref__O(); var arg_56 any = e__7; if linked_53 == nil { tmp10 = ifn_54.Invoke_O_O__O(arg_55, arg_56) } else { tmp10 = linked_53.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_52, arg_55, arg_56) }; jrt.NN(tmp9).Reset_O__O(tmp10) }
//line :68:1
	return nil }
//line :68:1
func (t *A_arbace_go_check_env_error_BANG__A) Invoke_O_O_O_O__O(self, line__0, code__1, msg__2 any) any {

	var root_57 any = A_arbace_go_check_env_A_const_30.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_31; var arg_60 any = tmp1.Invoke_O__O(A_arbace_go_check_env_A_const_32.Get__O()); var arg_61 any = line__0; var arg_62 any = code__1; var arg_63 any = msg__2; if linked_58 == nil { return ifn_59.Invoke_O_O_O_O__O(arg_60, arg_61, arg_62, arg_63) } else { return linked_58.(*A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_57, arg_60, arg_61, arg_62, arg_63)
	}
}












func A_arbace_go_check_env_line_of_A_New() *A_arbace_go_check_env_line_of_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_line_of_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_go_check_env_line_of_A) Ctor() {}
//line :85:1
func (t *A_arbace_go_check_env_line_of_A) Invoke_O_O__O(self, form__0 any) any {


	if lang.IMeta_InstanceOf(form__0) {
		var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_22; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(form__0)) } else {
//line :88:1
			return nil
		}
}
func A_arbace_go_check_env_col_of_A_New() *A_arbace_go_check_env_col_of_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_col_of_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_go_check_env_col_of_A) Ctor() {}
//line :91:1
func (t *A_arbace_go_check_env_col_of_A) Invoke_O_O__O(self, form__0 any) any {



	if lang.IMeta_InstanceOf(form__0) { var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_33; var temp__1927000414__auto____2 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(form__0))
		if jrt.J2g_Truth(temp__1927000414__auto____2) { var p__3 any = temp__1927000414__auto____2; var tmp2 any; var root_64 any = A_arbace_go_check_env_A_const_34.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_66 lang.IFn
			if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = p__3; if linked_65 == nil { tmp2 = ifn_66.Invoke_O__O(arg_67) } else { tmp2 = linked_65.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_64, arg_67) }; if jrt.J2g_Truth(tmp2) { var or__1927000174__auto____4 any; var root_68 any = A_arbace_go_check_env_A_const_35.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_70 lang.IFn
				if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = A_arbace_go_check_env_A_const_36.Invoke_O__O(p__3); if linked_69 == nil { or__1927000174__auto____4 = ifn_70.Invoke_O__O(arg_71) } else { or__1927000174__auto____4 = linked_69.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_68, arg_71) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var G__1719000022__5_ any; var root_72 any = A_arbace_go_check_env_A_const_37.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_74 lang.IFn
					if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_38.GetRawRoot__O()).Invoke_O_O_O__O(p__3, A_arbace_go_check_env_A_const_39, A_arbace_go_check_env_A_const_40); if linked_73 == nil { G__1719000022__5_ = ifn_74.Invoke_O__O(arg_75) } else { G__1719000022__5_ = linked_73.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_72, arg_75) }
//line :98:1
					var G__1719000022__6_ any
					if lang.Util_Identical_O_O__Z_NoInit(G__1719000022__5_, nil) { G__1719000022__6_ = nil } else { var root_82 any = A_arbace_go_check_env_A_const_41.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = A_arbace_go_check_env_A_const_42.GetRawRoot__O(); var arg_86 any = G__1719000022__5_; if linked_83 == nil { G__1719000022__6_ = ifn_84.Invoke_O_O__O(arg_85, arg_86) } else { G__1719000022__6_ = linked_83.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_82, arg_85, arg_86) } }
//line :98:1
					var G__1719000022__7_ any
					if lang.Util_Identical_O_O__Z_NoInit(G__1719000022__6_, nil) { G__1719000022__7_ = nil } else { var root_87 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = G__1719000022__6_; if linked_88 == nil { G__1719000022__7_ = ifn_89.Invoke_O__O(arg_90) } else { G__1719000022__7_ = linked_88.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_87, arg_90) } }
//line :98:1
					var G__1719000022__8_ any
					if lang.Util_Identical_O_O__Z_NoInit(G__1719000022__7_, nil) { G__1719000022__8_ = nil } else { var root_91 any = A_arbace_go_check_env_A_const_43.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = G__1719000022__7_; if linked_92 == nil { G__1719000022__8_ = ifn_93.Invoke_O__O(arg_94) } else { G__1719000022__8_ = linked_92.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_91, arg_94) } }
//line :98:1
					var G__1719000022__9_ any
					if lang.Util_Identical_O_O__Z_NoInit(G__1719000022__8_, nil) { G__1719000022__9_ = nil } else { var root_95 any = A_arbace_go_check_env_A_const_44.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = G__1719000022__8_; if linked_96 == nil { G__1719000022__9_ = ifn_97.Invoke_O__O(arg_98) } else { G__1719000022__9_ = linked_96.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_95, arg_98) } }; if lang.Util_Identical_O_O__Z_NoInit(G__1719000022__9_, nil) { return nil } else { var root_99 any = A_arbace_go_check_env_A_const_35.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = G__1719000022__9_; if linked_100 == nil { return ifn_101.Invoke_O__O(arg_102) } else { return linked_100.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_99, arg_102) } } } } else {
//line :97:1
						return nil } } else {
//line :96:1
							return nil } } else {
//line :95:1
								return nil
							}
}







func A_arbace_go_check_env_end_line_A_New() *A_arbace_go_check_env_end_line_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_end_line_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_go_check_env_end_line_A) Ctor() {}
//line :105:1
func (t *A_arbace_go_check_env_end_line_A) Invoke_O_O_O__O(self, c__0, l__1 any) any { var l__3 any; var tmp1 any; var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var root_103 any = A_arbace_go_check_env_A_const_45.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_105 lang.IFn; if



	linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = c__0; if linked_104 == nil { or__1927000174__auto____3 = ifn_105.Invoke_O__O(arg_106) } else { or__1927000174__auto____3 = linked_104.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_103, arg_106) }; if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else { var root_107 any = A_arbace_go_check_env_A_const_42.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = c__0; if linked_108 == nil { and__1927000168__auto____3 = ifn_109.Invoke_O__O(arg_110) } else { and__1927000168__auto____3 = linked_108.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_107, arg_110) } }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_111 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = c__0; if linked_112 == nil { tmp1 = ifn_113.Invoke_O__O(arg_114) } else { tmp1 = linked_112.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_111, arg_114) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var c__3 any; var tmp2 any; var root_115 any = A_arbace_go_check_env_A_const_42.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_117 lang.IFn
		if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = c__0; if linked_116 == nil { tmp2 = ifn_117.Invoke_O__O(arg_118) } else { tmp2 = linked_116.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_115, arg_118) }; if jrt.J2g_Truth(tmp2) { c__3 = c__0 } else { var root_119 any = A_arbace_go_check_env_A_const_46.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any; var root_124 any = A_arbace_go_check_env_A_const_47.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = c__0; if linked_125 == nil { arg_122 = ifn_126.Invoke_O__O(arg_127) } else { arg_122 = linked_125.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_124, arg_127) }; var arg_123 any = lang.RT_Meta_O__IPersistentMap_NoInit(c__0); if linked_120 == nil { c__3 = ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { c__3 = linked_120.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_119, arg_122, arg_123) } }
//line :109:1
		var k__4 int64 = lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(c__3))); var root_128 any = A_arbace_go_check_env_A_const_48.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, A_arbace_go_check_env_end_line_A_fn_class); var ifn_130 lang.IFn


		if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = lang.RT_Nth_O_I__O_NoInit(c__3, lang.RT_IntCast_J__I_NoInit(k__4)); var arg_132 any; var root_133 any = A_arbace_go_check_env_A_const_49.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_133, A_arbace_go_check_env_child_line_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = c__3; var arg_137 int64 = k__4; var arg_138 any = l__1; if linked_134 == nil { arg_132 = ifn_135.Invoke_O_O_O__O(arg_136, jrt.Long_ValueOf_J__Long_NoInit(arg_137).Ref(), arg_138) } else { arg_132 = linked_134.(*A_arbace_go_check_env_child_line_A).InvokeSpec_O_O_J_O_O__O(root_133, arg_136, arg_137, nil, arg_138) }; if linked_129 == nil { l__3 = ifn_130.Invoke_O_O__O(arg_131, arg_132) } else { l__3 = linked_129.(*A_arbace_go_check_env_end_line_A).Invoke_O_O_O__O(root_128, arg_131, arg_132) } } else {
//line :109:1
			l__3 = l__1 }; var tmp3 any; var or__1927000174__auto____4 any; if




	lang.IMeta_InstanceOf(c__0) { var tmp4 *lang.Keyword = A_arbace_go_check_env_A_const_50; or__1927000174__auto____4 = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(c__0)) } else { or__1927000174__auto____4 = nil }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp3 = or__1927000174__auto____4 } else { tmp3 = A_arbace_go_check_env_A_const_51 }; return lang.Numbers_Max_O_O__O_NoInit(l__3, tmp3) }

func A_arbace_go_check_env_child_line_A_New() *A_arbace_go_check_env_child_line_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_child_line_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_go_check_env_child_line_A) Ctor() {}
//line :116:1
func (t *A_arbace_go_check_env_child_line_A) Invoke_O_O_O_O__O(self, f__0, i__1, start__2 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_O_J_O_O__O(self, f__0, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, start__2) } else {






	var tmp1 any; var and__1927000168__auto____4 any = start__2; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var or__1927000174__auto____5 any; var root_139 any = A_arbace_go_check_env_A_const_45.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = f__0; if linked_140 == nil { or__1927000174__auto____5 = ifn_141.Invoke_O__O(arg_142) } else { or__1927000174__auto____5 = linked_140.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_139, arg_142) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else { var root_143 any = A_arbace_go_check_env_A_const_42.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = f__0; if linked_144 == nil { and__1927000168__auto____5 = ifn_145.Invoke_O__O(arg_146) } else { and__1927000168__auto____5 = linked_144.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_143, arg_146) } }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp2 bool; var na_147 any = i__1; var na_148 int64 = int64(lang.RT_Count_O__I_NoInit(f__0)); if jrt.Long_InstanceOf(na_147) { var n0_149 int64 = jrt.NN(jrt.Long_Cast(na_147)).LongValue__J(); var n1_150 int64 = na_148; tmp2 = n0_149 < n1_150 } else { tmp2 = lang.Numbers_Lt_O_J__Z_NoInit(na_147, na_148) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref() } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { var m__4 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__0); var f__5 any; var tmp3 any; var root_152 any = A_arbace_go_check_env_A_const_42.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_154 lang.IFn

		if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = f__0; if linked_153 == nil { tmp3 = ifn_154.Invoke_O__O(arg_155) } else { tmp3 = linked_153.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_152, arg_155) }; if jrt.J2g_Truth(tmp3) { f__5 = f__0 } else { var root_156 any = A_arbace_go_check_env_A_const_47.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = f__0; if linked_157 == nil { f__5 = ifn_158.Invoke_O__O(arg_159) } else { f__5 = linked_157.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_156, arg_159) } }
//line :123:1
		var or__1927000174__auto____6 any; var root_160 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, A_arbace_go_check_env_line_of_A_fn_class); var ifn_162 lang.IFn


		if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(i__1)); if linked_161 == nil { or__1927000174__auto____6 = ifn_162.Invoke_O__O(arg_163) } else { or__1927000174__auto____6 = linked_161.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_160, arg_163) }; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { var bmap__7 any; var root_164 any = A_arbace_go_check_env_A_const_53.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_166 lang.IFn

			if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_168 any; var iter__1927001039__auto____7 any; var fnbody__238 any = A_arbace_go_check_env_child_line_iter__1719000025__1719000029_A_New(); var tmp4 *jrt.Class; var fncls__237 *jrt.Class = A_arbace_go_check_env_child_line_iter__1719000025__1719000029_A_fn_class; if fncls__237 == nil { var fncls__237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); A_arbace_go_check_env_child_line_iter__1719000025__1719000029_A_fn_class = fncls__237d; tmp4 = fncls__237d } else { tmp4 = fncls__237 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__238, tmp4, nil); arg_168 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(A_arbace_go_check_env_A_const_63.Invoke_O__O(m__4)); if linked_165 == nil { bmap__7 = ifn_166.Invoke_O_O__O(arg_167, arg_168) } else { bmap__7 = linked_165.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_164, arg_167, arg_168) }
//line :126:1
			var j__8 any; var tmp5 *lang.Compiler_AOTFn; var fnbody__248 any = A_arbace_go_check_env_child_line_fn__1719000035_A_New_O_O(f__5, i__1); var tmp6 *jrt.Class
			var fncls__247 /*line :126:1*/*jrt.Class = A_arbace_go_check_env_child_line_fn__1719000035_A_fn_class


			if fncls__247 == nil { var fncls__247d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__248); A_arbace_go_check_env_child_line_fn__1719000035_A_fn_class = fncls__247d; tmp6 = fncls__247d } else { tmp6 = fncls__247 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__248, tmp6, nil); j__8 = Up_Compiler_AOTFn_IFn(tmp5).Invoke__O()
//line :126:1
			var k__9 any
			var na_249 any = j__8


			if jrt.Long_InstanceOf(na_249) { var n0_250 int64 = jrt.NN(jrt.Long_Cast(na_249)).LongValue__J(); if n0_250 == 9223372036854775807 { k__9 = lang.Numbers_Inc_O__Number_NoInit(na_249) } else { k__9 = jrt.Long_ValueOf_J__Long_NoInit(n0_250 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_249) { var n0_250_2 float64 = jrt.NN(jrt.Double_Cast(na_249)).DoubleValue__D(); k__9 = jrt.Double_ValueOf_D__Double_NoInit(n0_250_2 + 1.0).Ref() } else { k__9 = lang.Numbers_Inc_O__Number_NoInit(na_249) } }
//line :126:1
			var line__10 any; var or__1927000174__auto____10 any; var root_251 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, A_arbace_go_check_env_line_of_A_fn_class); var ifn_253 lang.IFn



			if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(j__8)); if linked_252 == nil { or__1927000174__auto____10 = ifn_253.Invoke_O__O(arg_254) } else { or__1927000174__auto____10 = linked_252.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_251, arg_254) }; if jrt.J2g_Truth(or__1927000174__auto____10) { line__10 = or__1927000174__auto____10 } else { line__10 = start__2 }
//line :126:1
		L1: for {




			var tmp7 bool; var na_255 any = k__9; var na_256 any = i__1; var tmp8 bool; var tmp9 bool; tmp9 = jrt.Long_InstanceOf(na_255); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_256) }; tmp8 = tmp9; if tmp8 { var n0_257 int64 = jrt.NN(jrt.Long_Cast(na_255)).LongValue__J(); var n1_258 int64 = jrt.NN(jrt.Long_Cast(na_256)).LongValue__J(); tmp7 = n0_257 > n1_258 } else { var tmp10 bool; var tmp11 bool; tmp11 = jrt.Double_InstanceOf(na_255); if tmp11 { tmp11 = jrt.Double_InstanceOf(na_256) }; tmp10 = tmp11; if tmp10 { var n0_257_2 float64 = jrt.NN(jrt.Double_Cast(na_255)).DoubleValue__D(); var n1_258_2 float64 = jrt.NN(jrt.Double_Cast(na_256)).DoubleValue__D(); tmp7 = n1_258_2 < n0_257_2 } else { tmp7 = lang.Numbers_Gt_O_O__Z_NoInit(na_255, na_256) } }; if tmp7 { return line__10 } else { var pe__11 any; var root_260 any = A_arbace_go_check_env_A_const_48.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, A_arbace_go_check_env_end_line_A_fn_class); var ifn_262 lang.IFn

				if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any; var tmp12 jrt.Number_I; var na_265 any = k__9; if jrt.Long_InstanceOf(na_265) { var n0_266 int64 = jrt.NN(jrt.Long_Cast(na_265)).LongValue__J(); if n0_266 == -9223372036854775808 { tmp12 = lang.Numbers_Dec_O__Number_NoInit(na_265) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_266 - 1)) } } else { if jrt.Double_InstanceOf(na_265) { var n0_266_2 float64 = jrt.NN(jrt.Double_Cast(na_265)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_266_2 - 1.0)) } else { tmp12 = lang.Numbers_Dec_O__Number_NoInit(na_265) } }; arg_263 = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(tmp12)); var arg_264 any = line__10; if linked_261 == nil { pe__11 = ifn_262.Invoke_O_O__O(arg_263, arg_264) } else { pe__11 = linked_261.(*A_arbace_go_check_env_end_line_A).Invoke_O_O_O__O(root_260, arg_263, arg_264) }
				var tmp13 jrt.Number_I; var na_267 any = k__9; if jrt.Long_InstanceOf(na_267) { var n0_268 int64 = jrt.NN(jrt.Long_Cast(na_267)).LongValue__J(); if n0_268 == 9223372036854775807 { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_267) } else { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_268 + 1)) } } else { if jrt.Double_InstanceOf(na_267) { var n0_268_2 float64 = jrt.NN(jrt.Double_Cast(na_267)).DoubleValue__D(); tmp13 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_268_2 + 1.0)) } else { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_267) } }; var tmp14 any = tmp13; var tmp15 any; var tmp16 any; var root_269 any = A_arbace_go_check_env_A_const_64.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = bmap__7; var arg_273 any = k__9; if linked_270 == nil { tmp16 = ifn_271.Invoke_O_O__O(arg_272, arg_273) } else { tmp16 = linked_270.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_269, arg_272, arg_273) }; if jrt.J2g_Truth(tmp16) { var or__1927000174__auto____12 any = lang.RT_Get_O_O__O_NoInit(bmap__7, k__9); if jrt.J2g_Truth(or__1927000174__auto____12) { tmp15 = or__1927000174__auto____12 } else { var na_274 any = pe__11; if jrt.Long_InstanceOf(na_274) { var n0_275 int64 = jrt.NN(jrt.Long_Cast(na_274)).LongValue__J(); if n0_275 == 9223372036854775807 { tmp15 = lang.Numbers_Inc_O__Number_NoInit(na_274) } else { tmp15 = jrt.Long_ValueOf_J__Long_NoInit(n0_275 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_274) { var n0_275_2 float64 = jrt.NN(jrt.Double_Cast(na_274)).DoubleValue__D(); tmp15 = jrt.Double_ValueOf_D__Double_NoInit(n0_275_2 + 1.0).Ref() } else { tmp15 = lang.Numbers_Inc_O__Number_NoInit(na_274) } } } } else { tmp15 = pe__11 }; k__9, line__10 = tmp14, tmp15; continue L1 } } } } else {
//line :123:1
					return nil } }; /*line :116:1*/panic("j2g: unreachable") }
//line :116:1
func (t *A_arbace_go_check_env_child_line_A) InvokeSpec_O_O_J_O_O__O(self, f__0 any, i__1_l int64, i__1_b, start__2 any) any {






	{ var tmp1 any; var and__1927000168__auto____4 any = start__2; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var or__1927000174__auto____5 any; var root_276 any = A_arbace_go_check_env_A_const_45.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_278 lang.IFn; if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = f__0; if linked_277 == nil { or__1927000174__auto____5 = ifn_278.Invoke_O__O(arg_279) } else { or__1927000174__auto____5 = linked_277.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_276, arg_279) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else { var root_280 any = A_arbace_go_check_env_A_const_42.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = f__0; if linked_281 == nil { and__1927000168__auto____5 = ifn_282.Invoke_O__O(arg_283) } else { and__1927000168__auto____5 = linked_281.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_280, arg_283) } }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp2 bool; var na_284 int64 = int64(lang.RT_Count_O__I_NoInit(f__0)); var n0_285 int64 = i__1_l; var n1_286 int64 = na_284; tmp2 = n0_285 < n1_286; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref() } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { var m__4 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__0); var f__5 any; var tmp3 any; var root_288 any = A_arbace_go_check_env_A_const_42.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_290 lang.IFn

		if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = f__0; if linked_289 == nil { tmp3 = ifn_290.Invoke_O__O(arg_291) } else { tmp3 = linked_289.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_288, arg_291) }; if jrt.J2g_Truth(tmp3) { f__5 = f__0 } else { var root_292 any = A_arbace_go_check_env_A_const_47.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = f__0; if linked_293 == nil { f__5 = ifn_294.Invoke_O__O(arg_295) } else { f__5 = linked_293.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_292, arg_295) } }
//line :123:1
		var or__1927000174__auto____6 any; var root_296 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, A_arbace_go_check_env_line_of_A_fn_class); var ifn_298 lang.IFn


		if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any; var tmp4 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp4 = i__1_b } else { tmp4 = i__1_b }; arg_299 = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(tmp4)); if linked_297 == nil { or__1927000174__auto____6 = ifn_298.Invoke_O__O(arg_299) } else { or__1927000174__auto____6 = linked_297.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_296, arg_299) }; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { var bmap__7 any; var root_300 any = A_arbace_go_check_env_A_const_53.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_302 lang.IFn

			if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_304 any; var iter__1927001039__auto____7 any; var fnbody__306 any = A_arbace_go_check_env_child_line_iter__1719000025__1719000029_A_New(); var tmp5 *jrt.Class; var fncls__305 *jrt.Class = A_arbace_go_check_env_child_line_iter__1719000025__1719000029_A_fn_class; if fncls__305 == nil { var fncls__305d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); A_arbace_go_check_env_child_line_iter__1719000025__1719000029_A_fn_class = fncls__305d; tmp5 = fncls__305d } else { tmp5 = fncls__305 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__306, tmp5, nil); arg_304 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(A_arbace_go_check_env_A_const_63.Invoke_O__O(m__4)); if linked_301 == nil { bmap__7 = ifn_302.Invoke_O_O__O(arg_303, arg_304) } else { bmap__7 = linked_301.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_300, arg_303, arg_304) }
//line :126:1
			var j__8 any; var tmp6 *lang.Compiler_AOTFn; var fnbody__308 any; var tmp7 any


			if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp7 = i__1_b } else { tmp7 = i__1_b }; fnbody__308 = A_arbace_go_check_env_child_line_fn__1719000035_A_New_O_O(f__5, tmp7); var tmp8 *jrt.Class; var fncls__307 *jrt.Class = A_arbace_go_check_env_child_line_fn__1719000035_A_fn_class; if fncls__307 == nil { var fncls__307d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__308); A_arbace_go_check_env_child_line_fn__1719000035_A_fn_class = fncls__307d; tmp8 = fncls__307d } else { tmp8 = fncls__307 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__308, tmp8, nil); j__8 = Up_Compiler_AOTFn_IFn(tmp6).Invoke__O()
//line :126:1
			var k__9 any
			var na_309 any = j__8


			if jrt.Long_InstanceOf(na_309) { var n0_310 int64 = jrt.NN(jrt.Long_Cast(na_309)).LongValue__J(); if n0_310 == 9223372036854775807 { k__9 = lang.Numbers_Inc_O__Number_NoInit(na_309) } else { k__9 = jrt.Long_ValueOf_J__Long_NoInit(n0_310 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_309) { var n0_310_2 float64 = jrt.NN(jrt.Double_Cast(na_309)).DoubleValue__D(); k__9 = jrt.Double_ValueOf_D__Double_NoInit(n0_310_2 + 1.0).Ref() } else { k__9 = lang.Numbers_Inc_O__Number_NoInit(na_309) } }
//line :126:1
			var line__10 any; var or__1927000174__auto____10 any; var root_311 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, A_arbace_go_check_env_line_of_A_fn_class); var ifn_313 lang.IFn



			if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(j__8)); if linked_312 == nil { or__1927000174__auto____10 = ifn_313.Invoke_O__O(arg_314) } else { or__1927000174__auto____10 = linked_312.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_311, arg_314) }; if jrt.J2g_Truth(or__1927000174__auto____10) { line__10 = or__1927000174__auto____10 } else { line__10 = start__2 }
//line :126:1
		L1: for {




			var tmp9 bool; var na_315 any = k__9; if jrt.Long_InstanceOf(na_315) { var n0_316 int64 = jrt.NN(jrt.Long_Cast(na_315)).LongValue__J(); var n1_317 int64 = i__1_l; tmp9 = n0_316 > n1_317 } else { var tmp10 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp10 = i__1_b } else { tmp10 = i__1_b }; tmp9 = lang.Numbers_Gt_O_O__Z_NoInit(na_315, tmp10) }; if tmp9 { return line__10 } else { var pe__11 any; var root_319 any = A_arbace_go_check_env_A_const_48.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, A_arbace_go_check_env_end_line_A_fn_class); var ifn_321 lang.IFn

				if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any; var tmp11 jrt.Number_I; var na_324 any = k__9; if jrt.Long_InstanceOf(na_324) { var n0_325 int64 = jrt.NN(jrt.Long_Cast(na_324)).LongValue__J(); if n0_325 == -9223372036854775808 { tmp11 = lang.Numbers_Dec_O__Number_NoInit(na_324) } else { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_325 - 1)) } } else { if jrt.Double_InstanceOf(na_324) { var n0_325_2 float64 = jrt.NN(jrt.Double_Cast(na_324)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_325_2 - 1.0)) } else { tmp11 = lang.Numbers_Dec_O__Number_NoInit(na_324) } }; arg_322 = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(tmp11)); var arg_323 any = line__10; if linked_320 == nil { pe__11 = ifn_321.Invoke_O_O__O(arg_322, arg_323) } else { pe__11 = linked_320.(*A_arbace_go_check_env_end_line_A).Invoke_O_O_O__O(root_319, arg_322, arg_323) }
				var tmp12 jrt.Number_I; var na_326 any = k__9; if jrt.Long_InstanceOf(na_326) { var n0_327 int64 = jrt.NN(jrt.Long_Cast(na_326)).LongValue__J(); if n0_327 == 9223372036854775807 { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_326) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_327 + 1)) } } else { if jrt.Double_InstanceOf(na_326) { var n0_327_2 float64 = jrt.NN(jrt.Double_Cast(na_326)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_327_2 + 1.0)) } else { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_326) } }; var tmp13 any = tmp12; var tmp14 any; var tmp15 any; var root_328 any = A_arbace_go_check_env_A_const_64.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = bmap__7; var arg_332 any = k__9; if linked_329 == nil { tmp15 = ifn_330.Invoke_O_O__O(arg_331, arg_332) } else { tmp15 = linked_329.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_328, arg_331, arg_332) }; if jrt.J2g_Truth(tmp15) { var or__1927000174__auto____12 any = lang.RT_Get_O_O__O_NoInit(bmap__7, k__9); if jrt.J2g_Truth(or__1927000174__auto____12) { tmp14 = or__1927000174__auto____12 } else { var na_333 any = pe__11; if jrt.Long_InstanceOf(na_333) { var n0_334 int64 = jrt.NN(jrt.Long_Cast(na_333)).LongValue__J(); if n0_334 == 9223372036854775807 { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_333) } else { tmp14 = jrt.Long_ValueOf_J__Long_NoInit(n0_334 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_333) { var n0_334_2 float64 = jrt.NN(jrt.Double_Cast(na_333)).DoubleValue__D(); tmp14 = jrt.Double_ValueOf_D__Double_NoInit(n0_334_2 + 1.0).Ref() } else { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_333) } } } } else { tmp14 = pe__11 }; k__9, line__10 = tmp13, tmp14; continue L1 } } } } else {
//line :123:1
					return nil } }
//line :116:1
	panic("j2g: unreachable") }
//line :116:1
func (t *A_arbace_go_check_env_child_line_A) Invoke_O_O_O__O(self, f__0, i__1 any) any {




	var root_335 any = A_arbace_go_check_env_A_const_49.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_335, A_arbace_go_check_env_child_line_A_fn_class); var ifn_337 lang.IFn; if linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any = f__0; var arg_339 any = i__1; var arg_340 any; var root_341 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, A_arbace_go_check_env_line_of_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = f__0; if linked_342 == nil { arg_340 = ifn_343.Invoke_O__O(arg_344) } else { arg_340 = linked_342.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_341, arg_344) }; if linked_336 == nil { return ifn_337.Invoke_O_O_O__O(arg_338, arg_339, arg_340) } else { if jrt.Long_InstanceOf(arg_339) { return linked_336.(*A_arbace_go_check_env_child_line_A).InvokeSpec_O_O_J_O_O__O(root_335, arg_338, jrt.NN(jrt.Long_Cast(arg_339)).LongValue__J(), arg_339, arg_340) } else { return linked_336.(*A_arbace_go_check_env_child_line_A).Invoke_O_O_O_O__O(root_335, arg_338, arg_339, arg_340)
	}
	}
}



func A_arbace_go_check_env_child_line_iter__1719000025__1719000029_A_New() *A_arbace_go_check_env_child_line_iter__1719000025__1719000029_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_child_line_iter__1719000025__1719000029_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_go_check_env_child_line_iter__1719000025__1719000029_A) Ctor() {}
//line :128:1
func (t *A_arbace_go_check_env_child_line_iter__1719000025__1719000029_A) Invoke_O_O__O(self, s__1719000026__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__236 any = A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_A_New_O_O(s__1719000026__1, self); var tmp2 *jrt.Class; var fncls__235 *jrt.Class = A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_A_fn_class; if fncls__235 == nil { var fncls__235d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__236); A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_A_fn_class = fncls__235d; tmp2 = fncls__235d } else { tmp2 = fncls__235 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__236, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :128:1
func A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_A_New_O_O(p0, p1 any) *A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_A{}; t.Ctor_O_O(p0, p1); return t }
//line :128:1
func (t *A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_A) Ctor_O_O(c__s__1719000026, c__iter__1719000025 any) { t.F_s__1719000026 = c__s__1719000026; t.F_iter__1719000025 = c__iter__1719000025 }
//line :128:1
func (t *A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_A) Invoke_O__O(self any) any { { var s__1719000026__1 any; var t_ any = t.F_s__1719000026; t.F_s__1719000026 = nil; s__1719000026__1 = t_; for { var temp__1927000414__auto____2 any; var root_169 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = s__1719000026__1; if linked_170 == nil { temp__1927000414__auto____2 = ifn_171.Invoke_O__O(arg_172) } else { temp__1927000414__auto____2 = linked_170.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_169, arg_172) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1719000026__3 any = temp__1927000414__auto____2; var tmp1 any; var root_173 any = A_arbace_go_check_env_A_const_54.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = s__1719000026__3; if linked_174 == nil { tmp1 = ifn_175.Invoke_O__O(arg_176) } else { tmp1 = linked_174.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_173, arg_176) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_177 any = A_arbace_go_check_env_A_const_55.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = s__1719000026__3; if linked_178 == nil { c__1927001037__auto____4 = ifn_179.Invoke_O__O(arg_180) } else { c__1927001037__auto____4 = linked_178.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_177, arg_180) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1719000028__6 any; var root_181 any = A_arbace_go_check_env_A_const_56.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_182 == nil { b__1719000028__6 = ifn_183.Invoke_O__O(arg_184) } else { b__1719000028__6 = linked_182.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_181, arg_184) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__195 any = A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_fn__1719000031_A_New_O_I_O(b__1719000028__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__194 *jrt.Class = A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_fn__1719000031_A_fn_class; if fncls__194 == nil { var fncls__194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__195); A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_fn__1719000031_A_fn_class = fncls__194d; tmp3 = fncls__194d } else { tmp3 = fncls__194 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__195, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_196 any = A_arbace_go_check_env_A_const_58.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any; var root_201 any = A_arbace_go_check_env_A_const_59.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = b__1719000028__6; if linked_202 == nil { arg_199 = ifn_203.Invoke_O__O(arg_204) } else { arg_199 = linked_202.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_201, arg_204) }; var arg_200 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1719000025); var tmp5 any; var root_205 any = A_arbace_go_check_env_A_const_60.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = s__1719000026__3; if linked_206 == nil { tmp5 = ifn_207.Invoke_O__O(arg_208) } else { tmp5 = linked_206.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_205, arg_208) }; arg_200 = tmp4.Invoke_O__O(tmp5); if linked_197 == nil { return ifn_198.Invoke_O_O__O(arg_199, arg_200) } else { return linked_197.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_196, arg_199, arg_200) } } else { var root_209 any = A_arbace_go_check_env_A_const_58.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any; var root_214 any = A_arbace_go_check_env_A_const_59.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = b__1719000028__6; if linked_215 == nil { arg_212 = ifn_216.Invoke_O__O(arg_217) } else { arg_212 = linked_215.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_214, arg_217) }; var arg_213 any; if linked_210 == nil { return ifn_211.Invoke_O_O__O(arg_212, arg_213) } else { return linked_210.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_209, arg_212, arg_213) } } } else { var b__4 any; var root_218 any = A_arbace_go_check_env_A_const_44.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = s__1719000026__3; if linked_219 == nil { b__4 = ifn_220.Invoke_O__O(arg_221) } else { b__4 = linked_219.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_218, arg_221) }; var root_222 any = A_arbace_go_check_env_A_const_61.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any; var tmp6 any; var root_227 any = A_arbace_go_check_env_A_const_42.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = b__4; if linked_228 == nil { tmp6 = ifn_229.Invoke_O__O(arg_230) } else { tmp6 = linked_228.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_227, arg_230) }; if jrt.J2g_Truth(tmp6) { arg_225 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(b__4, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(b__4, lang.RT_IntCast_J__I_NoInit(1))) } else { arg_225 = lang.Tuple_Create_O_O__IPersistentVector(b__4, nil) }; var arg_226 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1719000025); var tmp8 any; var root_231 any = A_arbace_go_check_env_A_const_62.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = s__1719000026__3; if linked_232 == nil { tmp8 = ifn_233.Invoke_O__O(arg_234) } else { tmp8 = linked_232.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_231, arg_234) }; arg_226 = tmp7.Invoke_O__O(tmp8); if linked_223 == nil { return ifn_224.Invoke_O_O__O(arg_225, arg_226) } else { return linked_223.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_222, arg_225, arg_226) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :128:1
func A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_fn__1719000031_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_fn__1719000031_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_fn__1719000031_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :128:1
func (t *A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_fn__1719000031_A) Ctor_O_I_O(c__b__1719000028 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1719000028 = c__b__1719000028; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :128:1
func (t *A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_fn__1719000031_A) Invoke_O__O(self any) any { { var i__1719000027__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1719000027__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1719000027__1)); var root_185 any = A_arbace_go_check_env_A_const_57.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = t.F_b__1719000028; var arg_189 any; var tmp2 any; var root_190 any = A_arbace_go_check_env_A_const_42.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = b__2; if linked_191 == nil { tmp2 = ifn_192.Invoke_O__O(arg_193) } else { tmp2 = linked_191.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_190, arg_193) }; if jrt.J2g_Truth(tmp2) { arg_189 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(b__2, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(b__2, lang.RT_IntCast_J__I_NoInit(1))) } else { arg_189 = lang.Tuple_Create_O_O__IPersistentVector(b__2, nil) }; if linked_186 == nil { ifn_187.Invoke_O_O__O(arg_188, arg_189) } else { linked_186.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_185, arg_188, arg_189) }; i__1719000027__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1719000027__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_env_child_line_fn__1719000035_A_New_O_O(p0, p1 any) *A_arbace_go_check_env_child_line_fn__1719000035_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_child_line_fn__1719000035_A{}; t.Ctor_O_O(p0, p1); return t }
//line :129:1
func (t *A_arbace_go_check_env_child_line_fn__1719000035_A) Ctor_O_O(c__f, c__i any) { t.F_f = c__f; t.F_i = c__i }
//line :129:1
func (t *A_arbace_go_check_env_child_line_fn__1719000035_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_i; t.F_i = nil; j__1 = t_; L1: for { var tmp1 any; var or__1927000174__auto____2 bool; var na_239 any = j__1; if jrt.Long_InstanceOf(na_239) { var n0_240 int64 = jrt.NN(jrt.Long_Cast(na_239)).LongValue__J(); or__1927000174__auto____2 = n0_240 == 0 } else { if jrt.Double_InstanceOf(na_239) { var n0_240_2 float64 = jrt.NN(jrt.Double_Cast(na_239)).DoubleValue__D(); or__1927000174__auto____2 = n0_240_2 == 0.0 } else { or__1927000174__auto____2 = lang.Numbers_IsZero_O__Z_NoInit(na_239) } }; if or__1927000174__auto____2 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var root_241 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, A_arbace_go_check_env_line_of_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var tmp2 any = t.F_f; var arg_244 any = lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(j__1)); if linked_242 == nil { tmp1 = ifn_243.Invoke_O__O(arg_244) } else { tmp1 = linked_242.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_241, arg_244) } }; if jrt.J2g_Truth(tmp1) { return j__1 } else { var tmp3 jrt.Number_I; var na_245 any = j__1; if jrt.Long_InstanceOf(na_245) { var n0_246 int64 = jrt.NN(jrt.Long_Cast(na_245)).LongValue__J(); if n0_246 == -9223372036854775808 { tmp3 = lang.Numbers_Dec_O__Number_NoInit(na_245) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_246 - 1)) } } else { if jrt.Double_InstanceOf(na_245) { var n0_246_2 float64 = jrt.NN(jrt.Double_Cast(na_245)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_246_2 - 1.0)) } else { tmp3 = lang.Numbers_Dec_O__Number_NoInit(na_245) } }; j__1 = tmp3; continue L1 } } }; panic("j2g: unreachable") }











func A_arbace_go_check_env_with_child_line_A_New() *A_arbace_go_check_env_with_child_line_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_with_child_line_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_go_check_env_with_child_line_A) Ctor() {}
//line :141:1
func (t *A_arbace_go_check_env_with_child_line_A) DoInvoke_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, parent__2, i__3, body__4 any) any { var root_345 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_65.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_67); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()); var tmp4 any; var root_355 any = A_arbace_go_check_env_A_const_68.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = A_arbace_go_check_env_A_const_69.GetRawRoot__O(); var arg_359 any; var root_360 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_65.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_70); var tmp7 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(parent__2); var tmp8 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_71); var tmp9 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(i__3); var tmp10 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_72); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()); var tmp12 any; var root_373 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_373, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_375 lang.IFn; if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_65.GetRawRoot__O()); var tmp14 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_73); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()); var tmp16 any; var root_383 any = A_arbace_go_check_env_A_const_68.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = A_arbace_go_check_env_A_const_69.GetRawRoot__O(); var arg_387 any; var root_388 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any; var root_392 any = A_arbace_go_check_env_A_const_65.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; if linked_393 == nil { arg_391 = ifn_394.Invoke__O() } else { arg_391 = linked_393.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O__O(root_392) }; if linked_389 == nil { arg_387 = ifn_390.Invoke_O__O(arg_391) } else { arg_387 = linked_389.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_388, arg_391) }; if linked_384 == nil { tmp16 = ifn_385.Invoke_O_O__O(arg_386, arg_387) } else { tmp16 = linked_384.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_383, arg_386, arg_387) }; arg_376 = tmp13.Invoke_O_O_O__O(tmp14, tmp15.Invoke_O__O(tmp16), body__4); if linked_374 == nil { tmp12 = ifn_375.Invoke_O__O(arg_376) } else { tmp12 = linked_374.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_373, arg_376) }; arg_363 = tmp5.Invoke_O_O_O_O_O_O__O(tmp6, tmp7, tmp8, tmp9, tmp10, tmp11.Invoke_O__O(tmp12)); if linked_361 == nil { arg_359 = ifn_362.Invoke_O__O(arg_363) } else { arg_359 = linked_361.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_360, arg_363) }; if linked_356 == nil { tmp4 = ifn_357.Invoke_O_O__O(arg_358, arg_359) } else { tmp4 = linked_356.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_355, arg_358, arg_359) }; var tmp17 any = tmp3.Invoke_O__O(tmp4); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()); var tmp19 any; var root_395 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_65.GetRawRoot__O()); var tmp21 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_74); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()); var tmp23 any; var root_406 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any; var root_410 any = A_arbace_go_check_env_A_const_65.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_75); var arg_414 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()); var tmp25 any; var root_415 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_65.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_76), lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_70), lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_71), lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(nil)); if linked_416 == nil { tmp25 = ifn_417.Invoke_O__O(arg_418) } else { tmp25 = linked_416.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_415, arg_418) }; arg_414 = tmp24.Invoke_O__O(tmp25); if linked_411 == nil { arg_409 = ifn_412.Invoke_O_O__O(arg_413, arg_414) } else { arg_409 = linked_411.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_410, arg_413, arg_414) }; if linked_407 == nil { tmp23 = ifn_408.Invoke_O__O(arg_409) } else { tmp23 = linked_407.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_406, arg_409) }; var tmp26 any = tmp22.Invoke_O__O(tmp23); var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()); var tmp28 any; var root_426 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any; var root_430 any = A_arbace_go_check_env_A_const_65.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_72); if linked_431 == nil { arg_429 = ifn_432.Invoke_O__O(arg_433) } else { arg_429 = linked_431.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_430, arg_433) }; if linked_427 == nil { tmp28 = ifn_428.Invoke_O__O(arg_429) } else { tmp28 = linked_427.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_426, arg_429) }; var tmp29 any = tmp27.Invoke_O__O(tmp28); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()); var tmp31 any; var root_434 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_65.GetRawRoot__O()); var tmp33 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_77); var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()); var tmp35 any; var root_444 any = A_arbace_go_check_env_A_const_68.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = A_arbace_go_check_env_A_const_69.GetRawRoot__O(); var arg_448 any; var root_449 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any; var root_453 any = A_arbace_go_check_env_A_const_65.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_78); var arg_457 any; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()); var tmp37 any; var root_458 any = A_arbace_go_check_env_A_const_68.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = A_arbace_go_check_env_A_const_69.GetRawRoot__O(); var arg_462 any; var root_463 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any; var root_467 any = A_arbace_go_check_env_A_const_65.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_70); var arg_471 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_71); if linked_468 == nil { arg_466 = ifn_469.Invoke_O_O__O(arg_470, arg_471) } else { arg_466 = linked_468.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_467, arg_470, arg_471) }; if linked_464 == nil { arg_462 = ifn_465.Invoke_O__O(arg_466) } else { arg_462 = linked_464.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_463, arg_466) }; if linked_459 == nil { tmp37 = ifn_460.Invoke_O_O__O(arg_461, arg_462) } else { tmp37 = linked_459.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_458, arg_461, arg_462) }; arg_457 = tmp36.Invoke_O__O(tmp37); if linked_454 == nil { arg_452 = ifn_455.Invoke_O_O__O(arg_456, arg_457) } else { arg_452 = linked_454.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_453, arg_456, arg_457) }; if linked_450 == nil { arg_448 = ifn_451.Invoke_O__O(arg_452) } else { arg_448 = linked_450.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_449, arg_452) }; if linked_445 == nil { tmp35 = ifn_446.Invoke_O_O__O(arg_447, arg_448) } else { tmp35 = linked_445.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_444, arg_447, arg_448) }; var tmp38 any = tmp34.Invoke_O__O(tmp35); var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()); var tmp40 any; var root_472 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any; var root_476 any = A_arbace_go_check_env_A_const_65.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_72); if linked_477 == nil { arg_475 = ifn_478.Invoke_O__O(arg_479) } else { arg_475 = linked_477.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_476, arg_479) }; if linked_473 == nil { tmp40 = ifn_474.Invoke_O__O(arg_475) } else { tmp40 = linked_473.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_472, arg_475) }; arg_437 = tmp32.Invoke_O_O_O__O(tmp33, tmp38, tmp39.Invoke_O__O(tmp40)); if linked_435 == nil { tmp31 = ifn_436.Invoke_O__O(arg_437) } else { tmp31 = linked_435.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_434, arg_437) }; arg_398 = tmp20.Invoke_O_O_O_O__O(tmp21, tmp26, tmp29, tmp30.Invoke_O__O(tmp31)); if linked_396 == nil { tmp19 = ifn_397.Invoke_O__O(arg_398) } else { tmp19 = linked_396.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_395, arg_398) }; arg_348 = tmp1.Invoke_O_O_O__O(tmp2, tmp17, tmp18.Invoke_O__O(tmp19)); if linked_346 == nil { return ifn_347.Invoke_O__O(arg_348) } else { return linked_346.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_345, arg_348) } }







func A_arbace_go_check_env_current_line_A_New() *A_arbace_go_check_env_current_line_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_current_line_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_go_check_env_current_line_A) Ctor() {}
//line :149:1
func (t *A_arbace_go_check_env_current_line_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var temp__1927000414__auto____1 any = A_arbace_go_check_env_A_const_79.Get__O(); if


	jrt.J2g_Truth(temp__1927000414__auto____1) { var vec__1719000046__2 any = temp__1927000414__auto____1; var p__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000046__2, lang.RT_IntCast_J__I_NoInit(0), nil); var i__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000046__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_480 any = A_arbace_go_check_env_A_const_49.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, A_arbace_go_check_env_child_line_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = p__3; var arg_484 any = i__4; if linked_481 == nil { or__1927000174__auto____1 = ifn_482.Invoke_O_O__O(arg_483, arg_484) } else { or__1927000174__auto____1 = linked_481.(*A_arbace_go_check_env_child_line_A).Invoke_O_O_O__O(root_480, arg_483, arg_484) } } else { or__1927000174__auto____1 = nil }; if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { return A_arbace_go_check_env_A_const_80.Get__O() } }







func A_arbace_go_check_env_size_type_BANG__A_New() *A_arbace_go_check_env_size_type_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_size_type_BANG__A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_go_check_env_size_type_BANG__A) Ctor() {}
//line :160:1
func (t *A_arbace_go_check_env_size_type_BANG__A) Invoke_O_O_O__O(self, f__0, t__1 any) any {


	var tmp1 any; var and__1927000168__auto____3 any = A_arbace_go_check_env_A_const_81.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____3) { var root_485 any = A_arbace_go_check_env_A_const_42.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = t__1; if linked_486 == nil { tmp1 = ifn_487.Invoke_O__O(arg_488) } else { tmp1 = linked_486.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_485, arg_488) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var root_489 any = A_arbace_go_check_env_A_const_82.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = A_arbace_go_check_env_A_const_81.Get__O(); var arg_493 any = A_arbace_go_check_env_A_const_9.GetRawRoot__O(); var arg_494 any; var tmp2 *lang.Keyword = A_arbace_go_check_env_A_const_31; var tmp3 any = tmp2.Invoke_O__O(A_arbace_go_check_env_A_const_32.Get__O()); var tmp4 any; var or__1927000174__auto____3 any; var root_495 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, A_arbace_go_check_env_line_of_A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = f__0; if linked_496 == nil { or__1927000174__auto____3 = ifn_497.Invoke_O__O(arg_498) } else { or__1927000174__auto____3 = linked_496.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_495, arg_498) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp4 = or__1927000174__auto____3 } else { var root_499 any = A_arbace_go_check_env_A_const_83.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, A_arbace_go_check_env_current_line_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; if linked_500 == nil { tmp4 = ifn_501.Invoke__O() } else { tmp4 = linked_500.(*A_arbace_go_check_env_current_line_A).Invoke_O__O(root_499) } }; arg_494 = lang.Tuple_Create_O_O_O_O__IPersistentVector(f__0, t__1, tmp3, tmp4); if linked_490 == nil { ifn_491.Invoke_O_O_O__O(arg_492, arg_493, arg_494) } else { linked_490.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_489, arg_492, arg_493, arg_494) } }
//line :160:1
	return t__1
}





func A_arbace_go_check_env_err_BANG__A_New() *A_arbace_go_check_env_err_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_err_BANG__A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_go_check_env_err_BANG__A) Ctor() {}
//line :167:1
func (t *A_arbace_go_check_env_err_BANG__A) DoInvoke_O_O_O_O_O__O(self, f__0, code__1, fmt__2, args__3 any) any { var l__5 any; var root_502 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, A_arbace_go_check_env_line_of_A_fn_class); var ifn_504 lang.IFn; if


	linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = f__0; if linked_503 == nil { l__5 = ifn_504.Invoke_O__O(arg_505) } else { l__5 = linked_503.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_502, arg_505) }; var msg__6 any; var tmp1 any; var root_506 any = /*line :167:1*/A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_508 lang.IFn; if



	linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = args__3; if linked_507 == nil { tmp1 = ifn_508.Invoke_O__O(arg_509) } else { tmp1 = linked_507.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_506, arg_509) }; if jrt.J2g_Truth(tmp1) { var root_510 any = A_arbace_go_check_env_A_const_68.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = A_arbace_go_check_env_A_const_84.GetRawRoot__O(); var arg_514 any = fmt__2; var arg_515 any = args__3; if linked_511 == nil { msg__6 = ifn_512.Invoke_O_O_O__O(arg_513, arg_514, arg_515) } else { msg__6 = linked_511.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_510, arg_513, arg_514, arg_515) } } else { msg__6 = fmt__2 }; var temp__1927000408__auto____7 any; if
	jrt.J2g_Truth(l__5) { var root_516 any = A_arbace_go_check_env_A_const_85.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, A_arbace_go_check_env_col_of_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = f__0; if linked_517 == nil { temp__1927000408__auto____7 = ifn_518.Invoke_O__O(arg_519) } else { temp__1927000408__auto____7 = linked_517.(*A_arbace_go_check_env_col_of_A).Invoke_O_O__O(root_516, arg_519) } } else { temp__1927000408__auto____7 = nil }; if jrt.J2g_Truth(temp__1927000408__auto____7) { var c__8 any = temp__1927000408__auto____7; var root_538 any = A_arbace_go_check_env_A_const_87.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_540 lang.IFn
		if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_88.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_check_env_A_const_20, c__8); if linked_539 == nil { ifn_540.Invoke_O__O(arg_541) } else { linked_539.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_538, arg_541) }
//line :172:1
		var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
			{ var root_520 any = A_arbace_go_check_env_A_const_30.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = l__5; var arg_524 any = code__1; var arg_525 any = msg__6; if linked_521 == nil { tmp2 = ifn_522.Invoke_O_O_O__O(arg_523, arg_524, arg_525) } else { tmp2 = linked_521.(*A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O__O(root_520, arg_523, arg_524, arg_525) } }
//line :172:1
			return nil }(); var root_526 any = A_arbace_go_check_env_A_const_86.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_526, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_528 lang.IFn
		if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; if linked_527 == nil { ifn_528.Invoke__O() } else { linked_527.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_526) }
//line :172:1
		if tmp3 != nil { panic(tmp3) }; return tmp2 } else {

			var root_529 any = A_arbace_go_check_env_A_const_30.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any; var or__1927000174__auto____8 any = l__5; if jrt.J2g_Truth(or__1927000174__auto____8) { arg_532 = or__1927000174__auto____8 } else { var root_535 any = A_arbace_go_check_env_A_const_83.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, A_arbace_go_check_env_current_line_A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; if linked_536 == nil { arg_532 = ifn_537.Invoke__O() } else { arg_532 = linked_536.(*A_arbace_go_check_env_current_line_A).Invoke_O__O(root_535) } }; var arg_533 any = code__1; var arg_534 any = msg__6; if linked_530 == nil { return ifn_531.Invoke_O_O_O__O(arg_532, arg_533, arg_534) } else { return linked_530.(*A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O__O(root_529, arg_532, arg_533, arg_534) } } }



func A_arbace_go_check_env_generic_BANG__A_New() *A_arbace_go_check_env_generic_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_generic_BANG__A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_go_check_env_generic_BANG__A) Ctor() {}
//line :178:1
func (t *A_arbace_go_check_env_generic_BANG__A) Invoke_O__O(self any) any {



	if jrt.J2g_Truth(A_arbace_go_check_env_A_const_27.Get__O()) { var tmp1 *lang.Volatile = lang.Volatile_Cast(A_arbace_go_check_env_A_const_27.Get__O()); var tmp2 any; var root_547 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_27.Get__O())).Deref__O(); var arg_551 any = A_arbace_go_check_env_A_const_89; var arg_552 any = jrt.Boolean_TRUE.Ref(); if linked_548 == nil { tmp2 = ifn_549.Invoke_O_O_O__O(arg_550, arg_551, arg_552) } else { tmp2 = linked_548.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_547, arg_550, arg_551, arg_552) }; return jrt.NN(tmp1).Reset_O__O(tmp2) } else { return nil
	} }
func A_arbace_go_check_env_unsupported_BANG__A_New() *A_arbace_go_check_env_unsupported_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_unsupported_BANG__A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_go_check_env_unsupported_BANG__A) Ctor() {}
//line :184:1
func (t *A_arbace_go_check_env_unsupported_BANG__A) Invoke_O_O__O(self, what__0 any) any {




	var root_553 any = A_arbace_go_check_env_A_const_90.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, A_arbace_go_check_env_generic_BANG__A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; if linked_554 == nil { ifn_555.Invoke__O() } else { linked_554.(*A_arbace_go_check_env_generic_BANG__A).Invoke_O__O(root_553) }
	var tmp1 any; var and__1927000168__auto____2 any = A_arbace_go_check_env_A_const_27.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Keyword = A_arbace_go_check_env_A_const_91; var tmp3 any; var root_556 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = A_arbace_go_check_env_A_const_27.Get__O(); if linked_557 == nil { tmp3 = ifn_558.Invoke_O__O(arg_559) } else { tmp3 = linked_557.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_556, arg_559) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2.Invoke_O__O(tmp3), nil)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_12.GetRawRoot__O()); var tmp5 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_27.Get__O())).Deref__O(); var tmp6 any = A_arbace_go_check_env_A_const_91; var tmp7 any = A_arbace_go_check_env_A_const_92; jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_27.Get__O())).Reset_O__O(tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, what__0, tmp7, A_arbace_go_check_env_A_const_80.Get__O())) }
//line :184:1
	return nil
}








func A_arbace_go_check_env_unsupported_QMARK__A_New() *A_arbace_go_check_env_unsupported_QMARK__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_unsupported_QMARK__A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_go_check_env_unsupported_QMARK__A) Ctor() {}
//line :194:1
func (t *A_arbace_go_check_env_unsupported_QMARK__A) Invoke_O_O__O(self, e__0 any) any { var and__1927000168__auto____2 bool = lang.ExceptionInfo_InstanceOf(e__0); if and__1927000168__auto____2 { var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_93; var tmp2 any; var root_568 any = A_arbace_go_check_env_A_const_94.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = e__0; if linked_569 == nil { tmp2 = ifn_570.Invoke_O__O(arg_571) } else { tmp2 = linked_569.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_568, arg_571) }; return tmp1.Invoke_O__O(tmp2) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }








func A_arbace_go_check_env_verified_BANG__A_New() *A_arbace_go_check_env_verified_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_verified_BANG__A{}; t.Ctor(); return t }
//line :203:1
func (t *A_arbace_go_check_env_verified_BANG__A) Ctor() {}
//line :203:1
func (t *A_arbace_go_check_env_verified_BANG__A) Invoke_O_O_O__O(self, k__0, f__1 any) any {




	if jrt.J2g_Truth(A_arbace_go_check_env_A_const_27.Get__O()) { var seen__3 any; var or__1927000174__auto____3 any = A_arbace_go_check_env_A_const_95.Get__O()
		if jrt.J2g_Truth(or__1927000174__auto____3) { seen__3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_96; var tmp2 any; var root_572 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = A_arbace_go_check_env_A_const_27.Get__O(); if linked_573 == nil { tmp2 = ifn_574.Invoke_O__O(arg_575) } else { tmp2 = linked_573.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_572, arg_575) }; or__1927000174__auto____4 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(or__1927000174__auto____4) { seen__3 = or__1927000174__auto____4 } else { var m__5 any = jrt.IdentityHashMap_New(); var tmp3 *lang.Volatile = lang.Volatile_Cast(A_arbace_go_check_env_A_const_27.Get__O()); var tmp4 any; var root_585 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_585, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_587 lang.IFn
			if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_27.Get__O())).Deref__O(); var arg_589 any = A_arbace_go_check_env_A_const_96; var arg_590 any = m__5; if linked_586 == nil { tmp4 = ifn_587.Invoke_O_O_O__O(arg_588, arg_589, arg_590) } else { tmp4 = linked_586.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_585, arg_588, arg_589, arg_590) }; jrt.NN(tmp3).Reset_O__O(tmp4)
//line :209:1
			seen__3 = m__5 } }
//line :208:1
		var ks__4 any = jrt.IdentityHashMap_Cast(seen__3).Get_O__O(f__1); var tmp5 any; var root_576 any = A_arbace_go_check_env_A_const_64.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_578 lang.IFn



		if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = ks__4; var arg_580 any = k__0; if linked_577 == nil { tmp5 = ifn_578.Invoke_O_O__O(arg_579, arg_580) } else { tmp5 = linked_577.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_576, arg_579, arg_580) }; if jrt.J2g_Truth(tmp5) { return nil } else {
			var tmp6 jrt.IdentityHashMap_I = jrt.IdentityHashMap_Cast(seen__3); var tmp7 any; var root_591 any = A_arbace_go_check_env_A_const_9.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_593 lang.IFn; if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any; var or__1927000174__auto____5 any = ks__4; if jrt.J2g_Truth(or__1927000174__auto____5) { arg_594 = or__1927000174__auto____5 } else { arg_594 = lang.PersistentHashSet_EMPTY.Ref() }; var arg_595 any = k__0; if linked_592 == nil { tmp7 = ifn_593.Invoke_O_O__O(arg_594, arg_595) } else { tmp7 = linked_592.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_591, arg_594, arg_595) }; tmp6.Put_O_O__O(f__1, tmp7)
			var root_581 any = A_arbace_go_check_env_A_const_97.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = k__0; if linked_582 == nil { return ifn_583.Invoke_O__O(arg_584) } else { return linked_582.(*A_arbace_go_check_env_verified_BANG__A).Invoke_O_O__O(root_581, arg_584) } } } else {
//line :208:1
				return nil } }
//line :203:1
func (t *A_arbace_go_check_env_verified_BANG__A) Invoke_O_O__O(self, k__0 any) any {


	if jrt.J2g_Truth(A_arbace_go_check_env_A_const_27.Get__O()) { var tmp1 *lang.Volatile = lang.Volatile_Cast(A_arbace_go_check_env_A_const_27.Get__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_98.GetRawRoot__O()); var tmp3 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_27.Get__O())).Deref__O(); var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_env_A_const_99, k__0); var tmp5 any; var root_602 any = A_arbace_go_check_env_A_const_100.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = A_arbace_go_check_env_A_const_101.GetRawRoot__O(); var arg_606 any = A_arbace_go_check_env_A_const_51; if linked_603 == nil { tmp5 = ifn_604.Invoke_O_O__O(arg_605, arg_606) } else { tmp5 = linked_603.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_602, arg_605, arg_606) }; return jrt.NN(tmp1).Reset_O__O(tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5)) } else { return nil
	}
}







func A_arbace_go_check_env_annotation_error_BANG__A_New() *A_arbace_go_check_env_annotation_error_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_annotation_error_BANG__A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_go_check_env_annotation_error_BANG__A) Ctor() {}
//line :216:1
func (t *A_arbace_go_check_env_annotation_error_BANG__A) Invoke_O_O_O_O_O_O__O(self, f__0, a__1, what__2, forms_say__3, checker_says__4 any) any {


	return lang.IFn_Cast(A_arbace_go_check_env_A_const_102.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(f__0, A_arbace_go_check_env_A_const_103, Lit_1, a__1, what__2, forms_say__3, checker_says__4)
}










func A_arbace_go_check_env_at_of_A_New() *A_arbace_go_check_env_at_of_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_at_of_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_go_check_env_at_of_A) Ctor() {}
//line :231:1
func (t *A_arbace_go_check_env_at_of_A) Invoke_O_O__O(self, f__0 any) any {


	if lang.IMeta_InstanceOf(f__0) { var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_104; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)) } else { return nil
	} }
func A_arbace_go_check_env_answer_BANG__A_New() *A_arbace_go_check_env_answer_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_answer_BANG__A{}; t.Ctor(); return t }
//line :236:1
func (t *A_arbace_go_check_env_answer_BANG__A) Ctor() {}
//line :236:1
func (t *A_arbace_go_check_env_answer_BANG__A) Invoke_O_O_O_O__O(self, f__0, k__1, m__2 any) any { var temp__1927000414__auto____4 any = A_arbace_go_check_env_A_const_105.Get__O(); if







	jrt.J2g_Truth(temp__1927000414__auto____4) { var a__5 any = temp__1927000414__auto____4; var temp__1927000414__auto____6 any; var root_617 any = A_arbace_go_check_env_A_const_106.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, A_arbace_go_check_env_at_of_A_fn_class); var ifn_619 lang.IFn
		if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = f__0; if linked_618 == nil { temp__1927000414__auto____6 = ifn_619.Invoke_O__O(arg_620) } else { temp__1927000414__auto____6 = linked_618.(*A_arbace_go_check_env_at_of_A).Invoke_O_O__O(root_617, arg_620) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var vec__1719000058__7 any = temp__1927000414__auto____6; var file__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000058__7, lang.RT_IntCast_J__I_NoInit(0), nil); var pm__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000058__7, lang.RT_IntCast_J__I_NoInit(1), nil); var temp__1927000414__auto____10 any = lang.RT_Get_O_O__O_NoInit(pm__9, k__1)
			if jrt.J2g_Truth(temp__1927000414__auto____10) { var p__11 any = temp__1927000414__auto____10; var at__12 any; var tmp1 any
				if lang.Util_Equiv_O_O__Z_NoInit(k__1, A_arbace_go_check_env_A_const_108) { tmp1 = A_arbace_go_check_env_A_const_36 } else { tmp1 = k__1 }
//line :246:1
				at__12 = lang.Tuple_Create_O_O__IPersistentVector(file__8, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, p__11)))

				var tmp2 jrt.HashMap_I = jrt.HashMap_Cast(a__5); var tmp3 any; var root_621 any = A_arbace_go_check_env_A_const_107.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = jrt.HashMap_Cast(a__5).Get_O__O(at__12); var arg_625 any = m__2; if linked_622 == nil { tmp3 = ifn_623.Invoke_O_O__O(arg_624, arg_625) } else { tmp3 = linked_622.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_621, arg_624, arg_625) }; return tmp2.Put_O_O__O(at__12, tmp3) } else {
//line :246:1
					return nil } } else {
//line :245:1
						return nil } } else {
//line :244:1
							return nil } }
//line :236:1
func (t *A_arbace_go_check_env_answer_BANG__A) Invoke_O_O_O__O(self, f__0, m__1 any) any { var temp__1927000414__auto____3 any = A_arbace_go_check_env_A_const_105.Get__O(); if



	jrt.J2g_Truth(temp__1927000414__auto____3) { var a__4 any = temp__1927000414__auto____3; var temp__1927000414__auto____5 any; var root_626 any = A_arbace_go_check_env_A_const_106.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, A_arbace_go_check_env_at_of_A_fn_class); var ifn_628 lang.IFn
		if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = f__0; if linked_627 == nil { temp__1927000414__auto____5 = ifn_628.Invoke_O__O(arg_629) } else { temp__1927000414__auto____5 = linked_627.(*A_arbace_go_check_env_at_of_A).Invoke_O_O__O(root_626, arg_629) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var at__6 any = temp__1927000414__auto____5; var tmp1 jrt.HashMap_I = jrt.HashMap_Cast(a__4); var tmp2 any; var root_630 any = A_arbace_go_check_env_A_const_107.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_632 lang.IFn
			if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = jrt.HashMap_Cast(a__4).Get_O__O(at__6); var arg_634 any = m__1; if linked_631 == nil { tmp2 = ifn_632.Invoke_O_O__O(arg_633, arg_634) } else { tmp2 = linked_631.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_630, arg_633, arg_634) }; return tmp1.Put_O_O__O(at__6, tmp2) } else {
//line :241:1
				return nil } } else {
//line :240:1
					return nil } }









func A_arbace_go_check_env_unanswer_BANG__A_New() *A_arbace_go_check_env_unanswer_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_unanswer_BANG__A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_go_check_env_unanswer_BANG__A) Ctor() {}
//line :250:1
func (t *A_arbace_go_check_env_unanswer_BANG__A) Invoke_O_O_O__O(self, f__0, ks__1 any) any { var temp__1927000414__auto____3 any = A_arbace_go_check_env_A_const_105.Get__O(); if


	jrt.J2g_Truth(temp__1927000414__auto____3) { var a__4 any = temp__1927000414__auto____3; var temp__1927000414__auto____5 any; var root_635 any = A_arbace_go_check_env_A_const_106.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, A_arbace_go_check_env_at_of_A_fn_class); var ifn_637 lang.IFn
		if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = f__0; if linked_636 == nil { temp__1927000414__auto____5 = ifn_637.Invoke_O__O(arg_638) } else { temp__1927000414__auto____5 = linked_636.(*A_arbace_go_check_env_at_of_A).Invoke_O_O__O(root_635, arg_638) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var at__6 any = temp__1927000414__auto____5; var temp__1927000414__auto____7 any = jrt.HashMap_Cast(a__4).Get_O__O(at__6)
			if jrt.J2g_Truth(temp__1927000414__auto____7) { var m__8 any = temp__1927000414__auto____7; var tmp1 jrt.HashMap_I = jrt.HashMap_Cast(a__4); var tmp2 any; var root_639 any = A_arbace_go_check_env_A_const_68.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_641 lang.IFn
				if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = A_arbace_go_check_env_A_const_38.GetRawRoot__O(); var arg_643 any = m__8; var arg_644 any = ks__1; if linked_640 == nil { tmp2 = ifn_641.Invoke_O_O_O__O(arg_642, arg_643, arg_644) } else { tmp2 = linked_640.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_639, arg_642, arg_643, arg_644) }; return tmp1.Put_O_O__O(at__6, tmp2) } else {
//line :255:1
					return nil } } else {
//line :254:1
						return nil } } else {
//line :253:1
							return nil } }








func A_arbace_go_check_env_def_type_BANG__A_New() *A_arbace_go_check_env_def_type_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_def_type_BANG__A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_go_check_env_def_type_BANG__A) Ctor() {}
//line :262:1
func (t *A_arbace_go_check_env_def_type_BANG__A) Invoke_O_O_O__O(self, n__0, kw__1 any) any {
	var root_645 any = A_arbace_go_check_env_A_const_109.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = A_arbace_go_check_env_A_const_110.GetRawRoot__O(); var arg_649 any = n__0; var arg_650 any; var root_651 any = A_arbace_go_check_env_A_const_111.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, A_arbace_go_check_env_obj_A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any; var G__1719000063__3_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env_A_const_15, A_arbace_go_check_env_A_const_112, A_arbace_go_check_env_A_const_31, n__0, A_arbace_go_check_env_A_const_112, kw__1, A_arbace_go_check_env_A_const_113, jrt.Boolean_TRUE.Ref())); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_go_check_env_A_const_114).Invoke_O__O(n__0)) {

		var root_655 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = G__1719000063__3_; var arg_659 any = A_arbace_go_check_env_A_const_115; var arg_660 any; var root_661 any = A_arbace_go_check_env_A_const_116.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = n__0; if linked_662 == nil { arg_660 = ifn_663.Invoke_O__O(arg_664) } else { arg_660 = linked_662.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_661, arg_664) }; if linked_656 == nil { arg_654 = ifn_657.Invoke_O_O_O__O(arg_658, arg_659, arg_660) } else { arg_654 = linked_656.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_655, arg_658, arg_659, arg_660) } } else {
//line :263:1
			arg_654 = G__1719000063__3_ }; if linked_652 == nil { arg_650 = ifn_653.Invoke_O__O(arg_654) } else { arg_650 = linked_652.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_651, arg_654) }; if linked_646 == nil { return ifn_647.Invoke_O_O_O__O(arg_648, arg_649, arg_650) } else { return linked_646.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_645, arg_648, arg_649, arg_650)
			}
}









func A_arbace_go_check_env_fn__1719000077_A_New() *A_arbace_go_check_env_fn__1719000077_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_fn__1719000077_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_go_check_env_fn__1719000077_A) Ctor() {}
//line :275:1
func (t *A_arbace_go_check_env_fn__1719000077_A) Invoke_O__O(self any) any { var nt__1 any; var root_665 any = A_arbace_go_check_env_A_const_117.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_go_check_types.A_arbace_go_check_types_new_named_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = A_arbace_go_check_env_A_const_118; if linked_666 == nil { nt__1 = ifn_667.Invoke_O__O(arg_668) } else { nt__1 = linked_666.(*aot_arbace_go_check_types.A_arbace_go_check_types_new_named_A).Invoke_O_O__O(root_665, arg_668) }; var tmp1 lang.IFn =
										lang.IFn_Cast(A_arbace_go_check_env_A_const_119.GetRawRoot__O()); var tmp2 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var tmp3 any = A_arbace_go_check_env_A_const_120; var tmp4 any = A_arbace_go_check_env_A_const_121; var tmp5 any = A_arbace_go_check_env_A_const_31; var tmp6 any = A_arbace_go_check_env_A_const_122; var tmp7 any = A_arbace_go_check_env_A_const_112; tmp1.Invoke_O_O_O_O__O(nt__1, tmp2, tmp3, lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, Lit_8, tmp6, nil, tmp7, lang.Tuple_Create_O_O_O_O__IPersistentVector(A_arbace_go_check_env_A_const_123, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_env_A_const_124, jrt.Boolean_FALSE.Ref())))), nil)); return nt__1 }







func A_arbace_go_check_env_fn__1719000083_A_New() *A_arbace_go_check_env_fn__1719000083_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_fn__1719000083_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_go_check_env_fn__1719000083_A) Ctor() {}
//line :284:1
func (t *A_arbace_go_check_env_fn__1719000083_A) Invoke_O__O(self any) any { var nt__1 any; var root_676 any = A_arbace_go_check_env_A_const_117.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_go_check_types.A_arbace_go_check_types_new_named_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = A_arbace_go_check_env_A_const_125; if linked_677 == nil { nt__1 = ifn_678.Invoke_O__O(arg_679) } else { nt__1 = linked_677.(*aot_arbace_go_check_types.A_arbace_go_check_types_new_named_A).Invoke_O_O__O(root_676, arg_679) }; var tmp1 lang.IFn =
										lang.IFn_Cast(A_arbace_go_check_env_A_const_119.GetRawRoot__O()); var tmp2 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var tmp3 any = A_arbace_go_check_env_A_const_120; var tmp4 any = A_arbace_go_check_env_A_const_121; var tmp5 any = lang.PersistentVector_EMPTY.Ref(); var tmp6 any; var root_687 any = A_arbace_go_check_env_A_const_126.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, aot_arbace_go_check_types.A_arbace_go_check_types_make_tset_A_fn_class); var ifn_689 lang.IFn; if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = A_arbace_go_check_env_A_const_127; var arg_691 any = jrt.Boolean_TRUE.Ref(); if linked_688 == nil { tmp6 = ifn_689.Invoke_O_O__O(arg_690, arg_691) } else { tmp6 = linked_688.(*aot_arbace_go_check_types.A_arbace_go_check_types_make_tset_A).Invoke_O_O_O__O(root_687, arg_690, arg_691) }; tmp1.Invoke_O_O_O_O__O(nt__1, tmp2, tmp3, lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, tmp5, tmp6)); return nt__1 }



















func A_arbace_go_check_env_fn__1719000101_A_New() *A_arbace_go_check_env_fn__1719000101_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_fn__1719000101_A{}; t.Ctor(); return t }
//line :305:1
func (t *A_arbace_go_check_env_fn__1719000101_A) Ctor() {}
//line :305:1
func (t *A_arbace_go_check_env_fn__1719000101_A) Invoke_O__O(self any) any { var s__1 any; var root_692 any = A_arbace_go_check_env_A_const_128.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, A_arbace_go_check_env_scope_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any; var arg_696 any = A_arbace_go_check_env_A_const_129; if linked_693 == nil { s__1 = ifn_694.Invoke_O_O__O(arg_695, arg_696) } else { s__1 = linked_693.(*A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_692, arg_695, arg_696) }; var root_697 any =
										A_arbace_go_check_env_A_const_109.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = s__1; var arg_701 any = Lit_9; var arg_702 any; var root_703 any = A_arbace_go_check_env_A_const_111.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, A_arbace_go_check_env_obj_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = A_arbace_go_check_env_A_const_130; if linked_704 == nil { arg_702 = ifn_705.Invoke_O__O(arg_706) } else { arg_702 = linked_704.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_703, arg_706) }; if linked_698 == nil { ifn_699.Invoke_O_O_O__O(arg_700, arg_701, arg_702) } else { linked_698.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_697, arg_700, arg_701, arg_702) }; var seq_1719000102__2 any; var root_707 any = /*line :305:1*/A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_709 lang.IFn; if

	linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = A_arbace_go_check_env_A_const_131; if linked_708 == nil { seq_1719000102__2 = ifn_709.Invoke_O__O(arg_710) } else { seq_1719000102__2 = linked_708.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_707, arg_710) }; var chunk_1719000103__3 any; var count_1719000104__4 int64 = 0; var i_1719000105__5 int64 = 0; L1:
//line :305:1
	for {

		if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000105__5, count_1719000104__4) { var n__6 any = lang.Indexed_Cast(chunk_1719000103__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000105__5)); var root_727 any = A_arbace_go_check_env_A_const_109.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_729 lang.IFn
			if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = s__1; var arg_731 any = n__6; var arg_732 any; var root_733 any = A_arbace_go_check_env_A_const_111.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, A_arbace_go_check_env_obj_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env_A_const_15, A_arbace_go_check_env_A_const_132, A_arbace_go_check_env_A_const_31, n__6, A_arbace_go_check_env_A_const_133, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_env_A_const_122, Lit_10)); if linked_734 == nil { arg_732 = ifn_735.Invoke_O__O(arg_736) } else { arg_732 = linked_734.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_733, arg_736) }; if linked_728 == nil { ifn_729.Invoke_O_O_O__O(arg_730, arg_731, arg_732) } else { linked_728.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_727, arg_730, arg_731, arg_732) }
//line :307:1
			seq_1719000102__2, chunk_1719000103__3, count_1719000104__4, i_1719000105__5 = seq_1719000102__2, chunk_1719000103__3, count_1719000104__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000105__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_711 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = seq_1719000102__2; if linked_712 == nil { temp__1927000414__auto____6 = ifn_713.Invoke_O__O(arg_714) } else { temp__1927000414__auto____6 = linked_712.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_711, arg_714) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1719000102__7 any = temp__1927000414__auto____6; var tmp1 any; var root_715 any = A_arbace_go_check_env_A_const_54.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = seq_1719000102__7; if linked_716 == nil { tmp1 = ifn_717.Invoke_O__O(arg_718) } else { tmp1 = linked_716.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_715, arg_718) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____8 any; var root_719 any = A_arbace_go_check_env_A_const_55.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = seq_1719000102__7; if linked_720 == nil { c__1927000678__auto____8 = ifn_721.Invoke_O__O(arg_722) } else { c__1927000678__auto____8 = linked_720.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_719, arg_722) }; var tmp2 any; var root_737 any = A_arbace_go_check_env_A_const_60.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = seq_1719000102__7; if linked_738 == nil { tmp2 = ifn_739.Invoke_O__O(arg_740) } else { tmp2 = linked_738.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_737, arg_740) }; seq_1719000102__2, chunk_1719000103__3, count_1719000104__4, i_1719000105__5 = tmp2, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_723 any = A_arbace_go_check_env_A_const_44.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = seq_1719000102__7; if linked_724 == nil { n__8 = ifn_725.Invoke_O__O(arg_726) } else { n__8 = linked_724.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_723, arg_726) }
				var root_741 any = A_arbace_go_check_env_A_const_109.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = s__1; var arg_745 any = n__8; var arg_746 any; var root_747 any = A_arbace_go_check_env_A_const_111.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, A_arbace_go_check_env_obj_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env_A_const_15, A_arbace_go_check_env_A_const_132, A_arbace_go_check_env_A_const_31, n__8, A_arbace_go_check_env_A_const_133, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_env_A_const_122, Lit_10)); if linked_748 == nil { arg_746 = ifn_749.Invoke_O__O(arg_750) } else { arg_746 = linked_748.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_747, arg_750) }; if linked_742 == nil { ifn_743.Invoke_O_O_O__O(arg_744, arg_745, arg_746) } else { linked_742.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_741, arg_744, arg_745, arg_746) }
//line :307:1
				var tmp3 any; var root_751 any = A_arbace_go_check_env_A_const_134.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = seq_1719000102__7; if linked_752 == nil { tmp3 = ifn_753.Invoke_O__O(arg_754) } else { tmp3 = linked_752.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_751, arg_754) }; seq_1719000102__2, chunk_1719000103__3, count_1719000104__4, i_1719000105__5 = tmp3, nil, 0, 0; continue L1 } } }
//line :305:1
		break L1 }; return s__1 }







type A_arbace_go_check_env_A struct{ jrt.Object }

var A_arbace_go_check_env_A_const_pool *jrt.RefArray

var A_arbace_go_check_env_A_const_0 *lang.Var

var A_arbace_go_check_env_A_const_1 any

var A_arbace_go_check_env_A_const_2 any

var A_arbace_go_check_env_A_const_3 any

var A_arbace_go_check_env_A_const_4 *lang.Var

var A_arbace_go_check_env_A_const_5 any

var A_arbace_go_check_env_A_const_6 *lang.Var

var A_arbace_go_check_env_A_const_7 *lang.Var

var A_arbace_go_check_env_A_const_8 *lang.Var

var A_arbace_go_check_env_A_const_9 *lang.Var

var A_arbace_go_check_env_A_const_10 any

var A_arbace_go_check_env_A_const_11 *lang.Var

var A_arbace_go_check_env_A_const_12 *lang.Var

var A_arbace_go_check_env_A_const_13 *lang.Keyword

var A_arbace_go_check_env_A_const_14 *lang.Keyword

var A_arbace_go_check_env_A_const_15 *lang.Keyword

var A_arbace_go_check_env_A_const_16 *lang.Var

var A_arbace_go_check_env_A_const_17 *lang.Var

var A_arbace_go_check_env_A_const_18 *lang.Var

var A_arbace_go_check_env_A_const_19 *lang.Var

var A_arbace_go_check_env_A_const_20 *lang.Var

var A_arbace_go_check_env_A_const_21 *lang.Keyword

var A_arbace_go_check_env_A_const_22 *lang.Keyword

var A_arbace_go_check_env_A_const_23 *lang.Keyword

var A_arbace_go_check_env_A_const_24 *lang.Keyword

var A_arbace_go_check_env_A_const_25 *lang.Keyword

var A_arbace_go_check_env_A_const_26 *lang.Keyword

var A_arbace_go_check_env_A_const_27 *lang.Var

var A_arbace_go_check_env_A_const_28 *lang.Var

var A_arbace_go_check_env_A_const_29 *lang.Keyword

var A_arbace_go_check_env_A_const_30 *lang.Var

var A_arbace_go_check_env_A_const_31 *lang.Keyword

var A_arbace_go_check_env_A_const_32 *lang.Var

var A_arbace_go_check_env_A_const_33 *lang.Keyword

var A_arbace_go_check_env_A_const_34 *lang.Var

var A_arbace_go_check_env_A_const_35 *lang.Var

var A_arbace_go_check_env_A_const_36 *lang.Keyword

var A_arbace_go_check_env_A_const_37 *lang.Var

var A_arbace_go_check_env_A_const_38 *lang.Var

var A_arbace_go_check_env_A_const_39 *lang.Keyword

var A_arbace_go_check_env_A_const_40 *lang.Keyword

var A_arbace_go_check_env_A_const_41 *lang.Var

var A_arbace_go_check_env_A_const_42 *lang.Var

var A_arbace_go_check_env_A_const_43 *lang.Var

var A_arbace_go_check_env_A_const_44 *lang.Var

var A_arbace_go_check_env_A_const_45 *lang.Var

var A_arbace_go_check_env_A_const_46 *lang.Var

var A_arbace_go_check_env_A_const_47 *lang.Var

var A_arbace_go_check_env_A_const_48 *lang.Var

var A_arbace_go_check_env_A_const_49 *lang.Var

var A_arbace_go_check_env_A_const_50 *lang.Keyword

var A_arbace_go_check_env_A_const_51 any

var A_arbace_go_check_env_A_const_52 *lang.Var

var A_arbace_go_check_env_A_const_53 *lang.Var

var A_arbace_go_check_env_A_const_54 *lang.Var

var A_arbace_go_check_env_A_const_55 *lang.Var

var A_arbace_go_check_env_A_const_56 *lang.Var

var A_arbace_go_check_env_A_const_57 *lang.Var

var A_arbace_go_check_env_A_const_58 *lang.Var

var A_arbace_go_check_env_A_const_59 *lang.Var

var A_arbace_go_check_env_A_const_60 *lang.Var

var A_arbace_go_check_env_A_const_61 *lang.Var

var A_arbace_go_check_env_A_const_62 *lang.Var

var A_arbace_go_check_env_A_const_63 *lang.Keyword

var A_arbace_go_check_env_A_const_64 *lang.Var

var A_arbace_go_check_env_A_const_65 *lang.Var

var A_arbace_go_check_env_A_const_66 *lang.Var

var A_arbace_go_check_env_A_const_67 any

var A_arbace_go_check_env_A_const_68 *lang.Var

var A_arbace_go_check_env_A_const_69 *lang.Var

var A_arbace_go_check_env_A_const_70 any

var A_arbace_go_check_env_A_const_71 any

var A_arbace_go_check_env_A_const_72 any

var A_arbace_go_check_env_A_const_73 any

var A_arbace_go_check_env_A_const_74 any

var A_arbace_go_check_env_A_const_75 any

var A_arbace_go_check_env_A_const_76 any

var A_arbace_go_check_env_A_const_77 any

var A_arbace_go_check_env_A_const_78 any

var A_arbace_go_check_env_A_const_79 *lang.Var

var A_arbace_go_check_env_A_const_80 *lang.Var

var A_arbace_go_check_env_A_const_81 *lang.Var

var A_arbace_go_check_env_A_const_82 *lang.Var

var A_arbace_go_check_env_A_const_83 *lang.Var

var A_arbace_go_check_env_A_const_84 *lang.Var

var A_arbace_go_check_env_A_const_85 *lang.Var

var A_arbace_go_check_env_A_const_86 *lang.Var

var A_arbace_go_check_env_A_const_87 *lang.Var

var A_arbace_go_check_env_A_const_88 *lang.Var

var A_arbace_go_check_env_A_const_89 *lang.Keyword

var A_arbace_go_check_env_A_const_90 *lang.Var

var A_arbace_go_check_env_A_const_91 *lang.Keyword

var A_arbace_go_check_env_A_const_92 *lang.Keyword

var A_arbace_go_check_env_A_const_93 *lang.Keyword

var A_arbace_go_check_env_A_const_94 *lang.Var

var A_arbace_go_check_env_A_const_95 *lang.Var

var A_arbace_go_check_env_A_const_96 *lang.Keyword

var A_arbace_go_check_env_A_const_97 *lang.Var

var A_arbace_go_check_env_A_const_98 *lang.Var

var A_arbace_go_check_env_A_const_99 *lang.Keyword

var A_arbace_go_check_env_A_const_100 *lang.Var

var A_arbace_go_check_env_A_const_101 *lang.Var

var A_arbace_go_check_env_A_const_102 *lang.Var

var A_arbace_go_check_env_A_const_103 *lang.Keyword

var A_arbace_go_check_env_A_const_104 *lang.Keyword

var A_arbace_go_check_env_A_const_105 *lang.Var

var A_arbace_go_check_env_A_const_106 *lang.Var

var A_arbace_go_check_env_A_const_107 *lang.Var

var A_arbace_go_check_env_A_const_108 *lang.Keyword

var A_arbace_go_check_env_A_const_109 *lang.Var

var A_arbace_go_check_env_A_const_110 *lang.Var

var A_arbace_go_check_env_A_const_111 *lang.Var

var A_arbace_go_check_env_A_const_112 *lang.Keyword

var A_arbace_go_check_env_A_const_113 *lang.Keyword

var A_arbace_go_check_env_A_const_114 any

var A_arbace_go_check_env_A_const_115 *lang.Keyword

var A_arbace_go_check_env_A_const_116 *lang.Var

var A_arbace_go_check_env_A_const_117 *lang.Var

var A_arbace_go_check_env_A_const_118 any

var A_arbace_go_check_env_A_const_119 *lang.Var

var A_arbace_go_check_env_A_const_120 *lang.Keyword

var A_arbace_go_check_env_A_const_121 *lang.Keyword

var A_arbace_go_check_env_A_const_122 *lang.Keyword

var A_arbace_go_check_env_A_const_123 *lang.Keyword

var A_arbace_go_check_env_A_const_124 any

var A_arbace_go_check_env_A_const_125 any

var A_arbace_go_check_env_A_const_126 *lang.Var

var A_arbace_go_check_env_A_const_127 *lang.Keyword

var A_arbace_go_check_env_A_const_128 *lang.Var

var A_arbace_go_check_env_A_const_129 *lang.Keyword

var A_arbace_go_check_env_A_const_130 any

var A_arbace_go_check_env_A_const_131 any

var A_arbace_go_check_env_A_const_132 *lang.Keyword

var A_arbace_go_check_env_A_const_133 *lang.Keyword

var A_arbace_go_check_env_A_const_134 *lang.Var

var A_arbace_go_check_env_A_init jrt.ClassInit

func A_arbace_go_check_env_A_Init() { if !A_arbace_go_check_env_A_init.Done() { A_arbace_go_check_env_A_init.Run(A_arbace_go_check_env_A_clinit) } }

func A_arbace_go_check_env_A_clinit() { A_arbace_go_check_env_A_clinit_p0(); A_arbace_go_check_env_A_clinit_p1(); A_arbace_go_check_env_A_clinit_p2(); A_arbace_go_check_env_A_clinit_p3(); A_arbace_go_check_env_A_clinit_p4(); A_arbace_go_check_env_A_clinit_p5(); A_arbace_go_check_env_A_clinit_p6(); A_arbace_go_check_env_A_clinit_p7(); A_arbace_go_check_env_A_clinit_p8(); A_arbace_go_check_env_A_clinit_p9(); A_arbace_go_check_env_A_clinit_p10() }

func A_arbace_go_check_env_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_env_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 193); A_arbace_go_check_env_A_const_0 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[58]); A_arbace_go_check_env_A_const_1 = A_arbace_go_check_env_A_const_pool.A[59]; A_arbace_go_check_env_A_const_2 = A_arbace_go_check_env_A_const_pool.A[60]; A_arbace_go_check_env_A_const_3 = A_arbace_go_check_env_A_const_pool.A[61]; A_arbace_go_check_env_A_const_4 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[62]); A_arbace_go_check_env_A_const_5 = A_arbace_go_check_env_A_const_pool.A[63]; A_arbace_go_check_env_A_const_6 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[64]); A_arbace_go_check_env_A_const_7 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[65]); A_arbace_go_check_env_A_const_8 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[66]); A_arbace_go_check_env_A_const_9 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[67]); A_arbace_go_check_env_A_const_10 = A_arbace_go_check_env_A_const_pool.A[68]; A_arbace_go_check_env_A_const_11 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[69]) }

func A_arbace_go_check_env_A_clinit_p1() { A_arbace_go_check_env_A_const_12 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[70]); A_arbace_go_check_env_A_const_13 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[71]); A_arbace_go_check_env_A_const_14 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[72]); A_arbace_go_check_env_A_const_15 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[73]); A_arbace_go_check_env_A_const_16 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[74]); A_arbace_go_check_env_A_const_17 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[75]); A_arbace_go_check_env_A_const_18 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[76]); A_arbace_go_check_env_A_const_19 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[77]); A_arbace_go_check_env_A_const_20 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[78]); A_arbace_go_check_env_A_const_21 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[79]); A_arbace_go_check_env_A_const_22 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[80]); A_arbace_go_check_env_A_const_23 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[81]) }

func A_arbace_go_check_env_A_clinit_p2() { A_arbace_go_check_env_A_const_24 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[82]); A_arbace_go_check_env_A_const_25 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[83]); A_arbace_go_check_env_A_const_26 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[84]); A_arbace_go_check_env_A_const_27 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[85]); A_arbace_go_check_env_A_const_28 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[86]); A_arbace_go_check_env_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[87]); A_arbace_go_check_env_A_const_30 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[88]); A_arbace_go_check_env_A_const_31 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[89]); A_arbace_go_check_env_A_const_32 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[90]); A_arbace_go_check_env_A_const_33 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[91]); A_arbace_go_check_env_A_const_34 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[92]); A_arbace_go_check_env_A_const_35 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[93]) }

func A_arbace_go_check_env_A_clinit_p3() { A_arbace_go_check_env_A_const_36 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[94]); A_arbace_go_check_env_A_const_37 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[95]); A_arbace_go_check_env_A_const_38 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[96]); A_arbace_go_check_env_A_const_39 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[97]); A_arbace_go_check_env_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[98]); A_arbace_go_check_env_A_const_41 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[99]); A_arbace_go_check_env_A_const_42 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[100]); A_arbace_go_check_env_A_const_43 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[101]); A_arbace_go_check_env_A_const_44 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[102]); A_arbace_go_check_env_A_const_45 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[103]); A_arbace_go_check_env_A_const_46 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[104]); A_arbace_go_check_env_A_const_47 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[105]) }

func A_arbace_go_check_env_A_clinit_p4() { A_arbace_go_check_env_A_const_48 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[106]); A_arbace_go_check_env_A_const_49 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[107]); A_arbace_go_check_env_A_const_50 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[108]); A_arbace_go_check_env_A_const_51 = A_arbace_go_check_env_A_const_pool.A[109]; A_arbace_go_check_env_A_const_52 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[110]); A_arbace_go_check_env_A_const_53 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[111]); A_arbace_go_check_env_A_const_54 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[112]); A_arbace_go_check_env_A_const_55 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[113]); A_arbace_go_check_env_A_const_56 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[114]); A_arbace_go_check_env_A_const_57 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[115]); A_arbace_go_check_env_A_const_58 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[116]); A_arbace_go_check_env_A_const_59 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[117]) }

func A_arbace_go_check_env_A_clinit_p5() { A_arbace_go_check_env_A_const_60 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[118]); A_arbace_go_check_env_A_const_61 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[119]); A_arbace_go_check_env_A_const_62 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[120]); A_arbace_go_check_env_A_const_63 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[121]); A_arbace_go_check_env_A_const_64 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[122]); A_arbace_go_check_env_A_const_65 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[123]); A_arbace_go_check_env_A_const_66 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[124]); A_arbace_go_check_env_A_const_67 = A_arbace_go_check_env_A_const_pool.A[125]; A_arbace_go_check_env_A_const_68 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[126]); A_arbace_go_check_env_A_const_69 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[127]); A_arbace_go_check_env_A_const_70 = A_arbace_go_check_env_A_const_pool.A[128]; A_arbace_go_check_env_A_const_71 = A_arbace_go_check_env_A_const_pool.A[129]; A_arbace_go_check_env_A_const_72 = A_arbace_go_check_env_A_const_pool.A[130] }

func A_arbace_go_check_env_A_clinit_p6() { A_arbace_go_check_env_A_const_73 = A_arbace_go_check_env_A_const_pool.A[131]; A_arbace_go_check_env_A_const_74 = A_arbace_go_check_env_A_const_pool.A[132]; A_arbace_go_check_env_A_const_75 = A_arbace_go_check_env_A_const_pool.A[133]; A_arbace_go_check_env_A_const_76 = A_arbace_go_check_env_A_const_pool.A[134]; A_arbace_go_check_env_A_const_77 = A_arbace_go_check_env_A_const_pool.A[135]; A_arbace_go_check_env_A_const_78 = A_arbace_go_check_env_A_const_pool.A[136]; A_arbace_go_check_env_A_const_79 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[137]); A_arbace_go_check_env_A_const_80 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[138]); A_arbace_go_check_env_A_const_81 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[139]); A_arbace_go_check_env_A_const_82 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[140]); A_arbace_go_check_env_A_const_83 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[141]); A_arbace_go_check_env_A_const_84 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[142]); A_arbace_go_check_env_A_const_85 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[143]) }

func A_arbace_go_check_env_A_clinit_p7() { A_arbace_go_check_env_A_const_86 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[144]); A_arbace_go_check_env_A_const_87 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[145]); A_arbace_go_check_env_A_const_88 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[146]); A_arbace_go_check_env_A_const_89 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[147]); A_arbace_go_check_env_A_const_90 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[148]); A_arbace_go_check_env_A_const_91 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[149]); A_arbace_go_check_env_A_const_92 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[150]); A_arbace_go_check_env_A_const_93 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[151]); A_arbace_go_check_env_A_const_94 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[152]); A_arbace_go_check_env_A_const_95 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[153]); A_arbace_go_check_env_A_const_96 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[154]); A_arbace_go_check_env_A_const_97 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[155]) }

func A_arbace_go_check_env_A_clinit_p8() { A_arbace_go_check_env_A_const_98 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[156]); A_arbace_go_check_env_A_const_99 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[157]); A_arbace_go_check_env_A_const_100 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[158]); A_arbace_go_check_env_A_const_101 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[159]); A_arbace_go_check_env_A_const_102 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[160]); A_arbace_go_check_env_A_const_103 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[161]); A_arbace_go_check_env_A_const_104 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[162]); A_arbace_go_check_env_A_const_105 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[163]); A_arbace_go_check_env_A_const_106 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[164]); A_arbace_go_check_env_A_const_107 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[165]); A_arbace_go_check_env_A_const_108 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[166]); A_arbace_go_check_env_A_const_109 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[167]) }

func A_arbace_go_check_env_A_clinit_p9() { A_arbace_go_check_env_A_const_110 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[168]); A_arbace_go_check_env_A_const_111 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[169]); A_arbace_go_check_env_A_const_112 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[170]); A_arbace_go_check_env_A_const_113 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[171]); A_arbace_go_check_env_A_const_114 = A_arbace_go_check_env_A_const_pool.A[172]; A_arbace_go_check_env_A_const_115 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[173]); A_arbace_go_check_env_A_const_116 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[174]); A_arbace_go_check_env_A_const_117 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[175]); A_arbace_go_check_env_A_const_118 = A_arbace_go_check_env_A_const_pool.A[176]; A_arbace_go_check_env_A_const_119 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[177]); A_arbace_go_check_env_A_const_120 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[178]); A_arbace_go_check_env_A_const_121 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[179]) }

func A_arbace_go_check_env_A_clinit_p10() { A_arbace_go_check_env_A_const_122 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[180]); A_arbace_go_check_env_A_const_123 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[181]); A_arbace_go_check_env_A_const_124 = A_arbace_go_check_env_A_const_pool.A[182]; A_arbace_go_check_env_A_const_125 = A_arbace_go_check_env_A_const_pool.A[183]; A_arbace_go_check_env_A_const_126 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[184]); A_arbace_go_check_env_A_const_127 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[185]); A_arbace_go_check_env_A_const_128 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[186]); A_arbace_go_check_env_A_const_129 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[187]); A_arbace_go_check_env_A_const_130 = A_arbace_go_check_env_A_const_pool.A[188]; A_arbace_go_check_env_A_const_131 = A_arbace_go_check_env_A_const_pool.A[189]; A_arbace_go_check_env_A_const_132 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[190]); A_arbace_go_check_env_A_const_133 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[191]); A_arbace_go_check_env_A_const_134 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[192]) }

func A_arbace_go_check_env_A_New() *A_arbace_go_check_env_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env_A) Ctor() {}

func (t *A_arbace_go_check_env_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env_A_class }

func (t *A_arbace_go_check_env_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env_A); return ok }

func A_arbace_go_check_env_A_Cast(x any) *A_arbace_go_check_env_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env_A_class)) }; return v }



type A_arbace_go_check_env_annotation_error_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_annotation_error_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_answer_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_answer_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_at_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_at_of_A_fn_class *jrt.Class



type A_arbace_go_check_env_child_line_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_child_line_A_fn_class *jrt.Class



type A_arbace_go_check_env_child_line_fn__1719000035_A struct{ j2g_header uint64; F_f, F_i any }

var A_arbace_go_check_env_child_line_fn__1719000035_A_fn_class *jrt.Class



type A_arbace_go_check_env_child_line_iter__1719000025__1719000029_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_child_line_iter__1719000025__1719000029_A_fn_class *jrt.Class



type A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_A struct{ j2g_header uint64; F_s__1719000026, F_iter__1719000025 any }

var A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_A_fn_class *jrt.Class



type A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_fn__1719000031_A struct{ j2g_header uint64; F_b__1719000028 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_env_child_line_iter__1719000025__1719000029_fn__1719000030_fn__1719000031_A_fn_class *jrt.Class



type A_arbace_go_check_env_col_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_col_of_A_fn_class *jrt.Class



type A_arbace_go_check_env_current_line_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_current_line_A_fn_class *jrt.Class



type A_arbace_go_check_env_def_type_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_def_type_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_end_line_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_end_line_A_fn_class *jrt.Class



type A_arbace_go_check_env_err_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_err_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_error_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_error_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_eval1719000004_A struct{ jrt.Object }

func A_arbace_go_check_env_eval1719000004_A_New() *A_arbace_go_check_env_eval1719000004_A { t := &A_arbace_go_check_env_eval1719000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env_eval1719000004_A) Ctor() {}

func (t *A_arbace_go_check_env_eval1719000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env_eval1719000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env_eval1719000004_A_class }

func (t *A_arbace_go_check_env_eval1719000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env_eval1719000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env_eval1719000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env_eval1719000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env_eval1719000004_A); return ok }

func A_arbace_go_check_env_eval1719000004_A_Cast(x any) *A_arbace_go_check_env_eval1719000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env_eval1719000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env_eval1719000004_A_class)) }; return v }



type A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class *jrt.Class



type A_arbace_go_check_env_eval1719000008_A struct{ jrt.Object }

func A_arbace_go_check_env_eval1719000008_A_New() *A_arbace_go_check_env_eval1719000008_A { t := &A_arbace_go_check_env_eval1719000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env_eval1719000008_A) Ctor() {}

func (t *A_arbace_go_check_env_eval1719000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env_eval1719000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env_eval1719000008_A_class }

func (t *A_arbace_go_check_env_eval1719000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env_eval1719000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env_eval1719000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env_eval1719000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env_eval1719000008_A); return ok }

func A_arbace_go_check_env_eval1719000008_A_Cast(x any) *A_arbace_go_check_env_eval1719000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env_eval1719000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env_eval1719000008_A_class)) }; return v }



type A_arbace_go_check_env_eval1719000008_fn__1719000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class *jrt.Class



type A_arbace_go_check_env_fn__1719000077_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_fn__1719000077_A_fn_class *jrt.Class



type A_arbace_go_check_env_fn__1719000083_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_fn__1719000083_A_fn_class *jrt.Class



type A_arbace_go_check_env_fn__1719000101_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_fn__1719000101_A_fn_class *jrt.Class



type A_arbace_go_check_env_generic_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_generic_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_line_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_line_of_A_fn_class *jrt.Class



type A_arbace_go_check_env_o_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_o_A_fn_class *jrt.Class



type A_arbace_go_check_env_obj_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_obj_A_fn_class *jrt.Class



type A_arbace_go_check_env_obj_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_obj_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_env_oset_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_oset_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_scope_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_scope_A_fn_class *jrt.Class



type A_arbace_go_check_env_scope_get_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_scope_get_A_fn_class *jrt.Class



type A_arbace_go_check_env_scope_lookup_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_scope_lookup_A_fn_class *jrt.Class



type A_arbace_go_check_env_scope_put_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_scope_put_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_size_type_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_size_type_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_unanswer_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_unanswer_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_unsupported_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_unsupported_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_unsupported_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_unsupported_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_env_verified_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_verified_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_with_child_line_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_with_child_line_A_fn_class *jrt.Class
