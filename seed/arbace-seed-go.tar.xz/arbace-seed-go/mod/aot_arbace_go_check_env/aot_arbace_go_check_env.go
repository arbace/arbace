//line aot_arbace_go_check_env.ae:1
package aot_arbace_go_check_env

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_types"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_New() *A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_env_A_const_4.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_5); tmp2 = lang.IFn_Cast(A_arbace_go_check_env_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_go_check_env_A_const_1, A_arbace_go_check_env_A_const_2, A_arbace_go_check_env_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_env_eval1719000008_fn__1719000009_A_New() *A_arbace_go_check_env_eval1719000008_fn__1719000009_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_eval1719000008_fn__1719000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_env_eval1719000008_fn__1719000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_env_eval1719000008_fn__1719000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_go_check_env_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_env_A_const_9.GetRawRoot__O(), A_arbace_go_check_env_A_const_10) }













func A_arbace_go_check_env_obj_A_New() *A_arbace_go_check_env_obj_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_obj_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_go_check_env_obj_A) Ctor() {}
//line :15:1
func (t *A_arbace_go_check_env_obj_A) Invoke_O_O__O(self, m__0 any) any { var root_21 any = A_arbace_go_check_env_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = m__0; if linked_22 == nil { return ifn_23.Invoke_O__O(arg_24) } else { return linked_22.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_21, arg_24) } }
func A_arbace_go_check_env_o_A_New() *A_arbace_go_check_env_o_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_o_A{}; t.Ctor(); return t }
//line :16:1
func (t *A_arbace_go_check_env_o_A) Ctor() {}
//line :16:1
func (t *A_arbace_go_check_env_o_A) Invoke_O_O_O__O(self, x__0, k__1 any) any { var tmp1 any; var root_25 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = x__0; if linked_26 == nil { tmp1 = ifn_27.Invoke_O__O(arg_28) } else { tmp1 = linked_26.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_25, arg_28) }; return lang.RT_Get_O_O__O_NoInit(tmp1, k__1) }
func A_arbace_go_check_env_oset_BANG__A_New() *A_arbace_go_check_env_oset_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_oset_BANG__A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_go_check_env_oset_BANG__A) Ctor() {}
//line :17:1
func (t *A_arbace_go_check_env_oset_BANG__A) Invoke_O_O_O_O__O(self, x__0, k__1, v__2 any) any { var tmp1 *lang.Volatile = lang.Volatile_Cast(x__0); var tmp2 any; var root_29 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = jrt.NN(lang.Volatile_Cast(x__0)).Deref__O(); var arg_33 any = k__1; var arg_34 any = v__2; if linked_30 == nil { tmp2 = ifn_31.Invoke_O_O_O__O(arg_32, arg_33, arg_34) } else { tmp2 = linked_30.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_29, arg_32, arg_33, arg_34) }; jrt.NN(tmp1).Reset_O__O(tmp2); return x__0 }
func A_arbace_go_check_env_obj_QMARK__A_New() *A_arbace_go_check_env_obj_QMARK__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_obj_QMARK__A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_go_check_env_obj_QMARK__A) Ctor() {}
//line :18:1
func (t *A_arbace_go_check_env_obj_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Volatile_InstanceOf(x__0)).Ref() }



func A_arbace_go_check_env_scope_A_New() *A_arbace_go_check_env_scope_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_scope_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_go_check_env_scope_A) Ctor() {}
//line :22:1
func (t *A_arbace_go_check_env_scope_A) Invoke_O_O_O__O(self, parent__0, kind__1 any) any { var tmp1 any = A_arbace_go_check_env_A_const_13; var tmp2 any = A_arbace_go_check_env_A_const_14; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, parent__0, tmp2, jrt.HashMap_New(), A_arbace_go_check_env_A_const_15, kind__1)) }

func A_arbace_go_check_env_scope_lookup_A_New() *A_arbace_go_check_env_scope_lookup_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_scope_lookup_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_env_scope_lookup_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_env_scope_lookup_A) Invoke_O_O_O__O(self, s__0, n__1 any) any { { var s__3 any = s__0; L1: for {



	if jrt.J2g_Truth(s__3) { var temp__1927000408__auto____4 any = jrt.HashMap_Cast(A_arbace_go_check_env_A_const_14.Invoke_O__O(s__3)).Get_O__O(n__1)
		if jrt.J2g_Truth(temp__1927000408__auto____4) { var x__5 any = temp__1927000408__auto____4; return x__5 } else {

			s__3 = A_arbace_go_check_env_A_const_13.Invoke_O__O(s__3); continue L1 } } else {
//line :28:1
				return nil } } }; /*line :24:1*/panic("j2g: unreachable") }








func A_arbace_go_check_env_scope_get_A_New() *A_arbace_go_check_env_scope_get_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_scope_get_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_go_check_env_scope_get_A) Ctor() {}
//line :33:1
func (t *A_arbace_go_check_env_scope_get_A) Invoke_O_O_O__O(self, s__0, n__1 any) any { return jrt.HashMap_Cast(A_arbace_go_check_env_A_const_14.Invoke_O__O(s__0)).Get_O__O(n__1) }
func A_arbace_go_check_env_scope_put_BANG__A_New() *A_arbace_go_check_env_scope_put_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_scope_put_BANG__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_go_check_env_scope_put_BANG__A) Ctor() {}
//line :34:1
func (t *A_arbace_go_check_env_scope_put_BANG__A) Invoke_O_O_O_O__O(self, s__0, n__1, x__2 any) any { return jrt.HashMap_Cast(A_arbace_go_check_env_A_const_14.Invoke_O__O(s__0)).Put_O_O__O(n__1, x__2) }





























func A_arbace_go_check_env_error_BANG__A_New() *A_arbace_go_check_env_error_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_error_BANG__A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_go_check_env_error_BANG__A) Ctor() {}
//line :64:1
func (t *A_arbace_go_check_env_error_BANG__A) Invoke_O_O_O_O_O__O(self, file__0, line__1, code__2, msg__3 any) any {



	var tmp1 any; var and__1927000168__auto____5 any = A_arbace_go_check_env_A_const_16.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____5) {


		var root_35 any = A_arbace_go_check_env_A_const_17.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any; var and__1927000168__auto____6 any; var root_39 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any; var root_43 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = A_arbace_go_check_env_A_const_16.Get__O(); if linked_44 == nil { arg_42 = ifn_45.Invoke_O__O(arg_46) } else { arg_42 = linked_44.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_43, arg_46) }; if linked_40 == nil { and__1927000168__auto____6 = ifn_41.Invoke_O__O(arg_42) } else { and__1927000168__auto____6 = linked_40.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_39, arg_42) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var m__7 any = msg__3; var or__1927000174__auto____8 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(m__7)).IndexOf_String__I(Lit_6)))

			if or__1927000174__auto____8 { arg_38 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { arg_38 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.String_Cast(m__7)).IndexOf_String__I(Lit_7)))).Ref() } } else {
//line :71:1
				arg_38 = and__1927000168__auto____6 }; if linked_36 == nil { tmp1 = ifn_37.Invoke_O__O(arg_38) } else { tmp1 = linked_36.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_35, arg_38) } } else {
//line :68:1
					tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var line__5 any; var or__1927000174__auto____5 any = A_arbace_go_check_env_A_const_19.Get__O()





						if jrt.J2g_Truth(or__1927000174__auto____5) { line__5 = or__1927000174__auto____5 } else { line__5 = line__1 }
//line :68:1
						var e__6 any; var tmp2 any = A_arbace_go_check_env_A_const_20; var tmp3 any = A_arbace_go_check_env_A_const_21; var tmp4 any = A_arbace_go_check_env_A_const_22; var tmp5 any = A_arbace_go_check_env_A_const_23; var tmp6 any = A_arbace_go_check_env_A_const_24; var tmp7 any







						if jrt.J2g_Truth(A_arbace_go_check_env_A_const_25.Get__O()) { var root_47 any = A_arbace_go_check_env_A_const_26.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, A_arbace_go_check_env_o_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = A_arbace_go_check_env_A_const_25.Get__O(); var arg_51 any = A_arbace_go_check_env_A_const_27; if linked_48 == nil { tmp7 = ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { tmp7 = linked_48.(*A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) } } else { tmp7 = nil }
//line :68:1
						e__6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, file__0, tmp3, line__5, tmp4, msg__3, tmp5, code__2, tmp6, tmp7))








						var tmp8 *lang.Volatile = lang.Volatile_Cast(A_arbace_go_check_env_A_const_16.Get__O()); var tmp9 any; var root_52 any = A_arbace_go_check_env_A_const_9.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_16.Get__O())).Deref__O(); var arg_56 any = e__6; if linked_53 == nil { tmp9 = ifn_54.Invoke_O_O__O(arg_55, arg_56) } else { tmp9 = linked_53.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_52, arg_55, arg_56) }; jrt.NN(tmp8).Reset_O__O(tmp9) }
//line :64:1
	return nil }
//line :64:1
func (t *A_arbace_go_check_env_error_BANG__A) Invoke_O_O_O_O__O(self, line__0, code__1, msg__2 any) any {

	var root_57 any = A_arbace_go_check_env_A_const_28.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_29; var arg_60 any = tmp1.Invoke_O__O(A_arbace_go_check_env_A_const_30.Get__O()); var arg_61 any = line__0; var arg_62 any = code__1; var arg_63 any = msg__2; if linked_58 == nil { return ifn_59.Invoke_O_O_O_O__O(arg_60, arg_61, arg_62, arg_63) } else { return linked_58.(*A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_57, arg_60, arg_61, arg_62, arg_63)
	}
}











func A_arbace_go_check_env_line_of_A_New() *A_arbace_go_check_env_line_of_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_line_of_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_go_check_env_line_of_A) Ctor() {}
//line :80:1
func (t *A_arbace_go_check_env_line_of_A) Invoke_O_O__O(self, form__0 any) any {


	if lang.IMeta_InstanceOf(form__0) {
		var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_21; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(form__0)) } else {
//line :83:1
			return nil
		}
}




func A_arbace_go_check_env_end_line_A_New() *A_arbace_go_check_env_end_line_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_end_line_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_go_check_env_end_line_A) Ctor() {}
//line :90:1
func (t *A_arbace_go_check_env_end_line_A) Invoke_O_O_O__O(self, c__0, l__1 any) any { var l__3 any; var tmp1 any; var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var root_64 any = A_arbace_go_check_env_A_const_31.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_66 lang.IFn; if



	linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = c__0; if linked_65 == nil { or__1927000174__auto____3 = ifn_66.Invoke_O__O(arg_67) } else { or__1927000174__auto____3 = linked_65.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_64, arg_67) }; if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else { var root_68 any = A_arbace_go_check_env_A_const_32.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = c__0; if linked_69 == nil { and__1927000168__auto____3 = ifn_70.Invoke_O__O(arg_71) } else { and__1927000168__auto____3 = linked_69.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_68, arg_71) } }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_72 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = c__0; if linked_73 == nil { tmp1 = ifn_74.Invoke_O__O(arg_75) } else { tmp1 = linked_73.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_72, arg_75) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var c__3 any; var tmp2 any; var root_76 any = A_arbace_go_check_env_A_const_32.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_78 lang.IFn
		if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = c__0; if linked_77 == nil { tmp2 = ifn_78.Invoke_O__O(arg_79) } else { tmp2 = linked_77.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_76, arg_79) }; if jrt.J2g_Truth(tmp2) { c__3 = c__0 } else { var root_80 any = A_arbace_go_check_env_A_const_33.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any; var root_85 any = A_arbace_go_check_env_A_const_34.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = c__0; if linked_86 == nil { arg_83 = ifn_87.Invoke_O__O(arg_88) } else { arg_83 = linked_86.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_85, arg_88) }; var arg_84 any = lang.RT_Meta_O__IPersistentMap_NoInit(c__0); if linked_81 == nil { c__3 = ifn_82.Invoke_O_O__O(arg_83, arg_84) } else { c__3 = linked_81.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_80, arg_83, arg_84) } }
//line :94:1
		var k__4 int64 = lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(c__3))); var root_89 any = A_arbace_go_check_env_A_const_35.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, A_arbace_go_check_env_end_line_A_fn_class); var ifn_91 lang.IFn


		if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = lang.RT_Nth_O_I__O_NoInit(c__3, lang.RT_IntCast_J__I_NoInit(k__4)); var arg_93 any; var root_94 any = A_arbace_go_check_env_A_const_36.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_94, A_arbace_go_check_env_child_line_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = c__3; var arg_98 int64 = k__4; var arg_99 any = l__1; if linked_95 == nil { arg_93 = ifn_96.Invoke_O_O_O__O(arg_97, jrt.Long_ValueOf_J__Long_NoInit(arg_98).Ref(), arg_99) } else { arg_93 = linked_95.(*A_arbace_go_check_env_child_line_A).InvokeSpec_O_O_J_O_O__O(root_94, arg_97, arg_98, nil, arg_99) }; if linked_90 == nil { l__3 = ifn_91.Invoke_O_O__O(arg_92, arg_93) } else { l__3 = linked_90.(*A_arbace_go_check_env_end_line_A).Invoke_O_O_O__O(root_89, arg_92, arg_93) } } else {
//line :94:1
			l__3 = l__1 }; var tmp3 any; var or__1927000174__auto____4 any; if




	lang.IMeta_InstanceOf(c__0) { var tmp4 *lang.Keyword = A_arbace_go_check_env_A_const_37; or__1927000174__auto____4 = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(c__0)) } else { or__1927000174__auto____4 = nil }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp3 = or__1927000174__auto____4 } else { tmp3 = A_arbace_go_check_env_A_const_38 }; return lang.Numbers_Max_O_O__O_NoInit(l__3, tmp3) }

func A_arbace_go_check_env_child_line_A_New() *A_arbace_go_check_env_child_line_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_child_line_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_check_env_child_line_A) Ctor() {}
//line :101:1
func (t *A_arbace_go_check_env_child_line_A) Invoke_O_O_O_O__O(self, f__0, i__1, start__2 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_O_J_O_O__O(self, f__0, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, start__2) } else {






	var tmp1 any; var and__1927000168__auto____4 any = start__2; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var or__1927000174__auto____5 any; var root_100 any = A_arbace_go_check_env_A_const_31.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = f__0; if linked_101 == nil { or__1927000174__auto____5 = ifn_102.Invoke_O__O(arg_103) } else { or__1927000174__auto____5 = linked_101.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_100, arg_103) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else { var root_104 any = A_arbace_go_check_env_A_const_32.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = f__0; if linked_105 == nil { and__1927000168__auto____5 = ifn_106.Invoke_O__O(arg_107) } else { and__1927000168__auto____5 = linked_105.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_104, arg_107) } }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp2 bool; var na_108 any = i__1; var na_109 int64 = int64(lang.RT_Count_O__I_NoInit(f__0)); if jrt.Long_InstanceOf(na_108) { var n0_110 int64 = jrt.NN(jrt.Long_Cast(na_108)).LongValue__J(); var n1_111 int64 = na_109; tmp2 = n0_110 < n1_111 } else { tmp2 = lang.Numbers_Lt_O_J__Z_NoInit(na_108, na_109) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref() } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { var m__4 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__0); var f__5 any; var tmp3 any; var root_113 any = A_arbace_go_check_env_A_const_32.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_115 lang.IFn

		if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = f__0; if linked_114 == nil { tmp3 = ifn_115.Invoke_O__O(arg_116) } else { tmp3 = linked_114.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_113, arg_116) }; if jrt.J2g_Truth(tmp3) { f__5 = f__0 } else { var root_117 any = A_arbace_go_check_env_A_const_34.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = f__0; if linked_118 == nil { f__5 = ifn_119.Invoke_O__O(arg_120) } else { f__5 = linked_118.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_117, arg_120) } }
//line :108:1
		var or__1927000174__auto____6 any; var root_121 any = A_arbace_go_check_env_A_const_39.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_go_check_env_line_of_A_fn_class); var ifn_123 lang.IFn


		if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(i__1)); if linked_122 == nil { or__1927000174__auto____6 = ifn_123.Invoke_O__O(arg_124) } else { or__1927000174__auto____6 = linked_122.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_121, arg_124) }; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { var bmap__7 any; var root_125 any = A_arbace_go_check_env_A_const_40.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_127 lang.IFn

			if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_129 any; var iter__1927001039__auto____7 any; var fnbody__199 any = A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A_New(); var tmp4 *jrt.Class; var fncls__198 *jrt.Class = A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A_fn_class; if fncls__198 == nil { var fncls__198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A_fn_class = fncls__198d; tmp4 = fncls__198d } else { tmp4 = fncls__198 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__199, tmp4, nil); arg_129 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(A_arbace_go_check_env_A_const_51.Invoke_O__O(m__4)); if linked_126 == nil { bmap__7 = ifn_127.Invoke_O_O__O(arg_128, arg_129) } else { bmap__7 = linked_126.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_125, arg_128, arg_129) }
//line :111:1
			var j__8 any; var tmp5 *lang.Compiler_AOTFn; var fnbody__209 any = A_arbace_go_check_env_child_line_fn__1719000033_A_New_O_O(f__5, i__1); var tmp6 *jrt.Class
			var fncls__208 /*line :111:1*/*jrt.Class = A_arbace_go_check_env_child_line_fn__1719000033_A_fn_class


			if fncls__208 == nil { var fncls__208d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__209); A_arbace_go_check_env_child_line_fn__1719000033_A_fn_class = fncls__208d; tmp6 = fncls__208d } else { tmp6 = fncls__208 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__209, tmp6, nil); j__8 = Up_Compiler_AOTFn_IFn(tmp5).Invoke__O()
//line :111:1
			var k__9 any
			var na_210 any = j__8


			if jrt.Long_InstanceOf(na_210) { var n0_211 int64 = jrt.NN(jrt.Long_Cast(na_210)).LongValue__J(); if n0_211 == 9223372036854775807 { k__9 = lang.Numbers_Inc_O__Number_NoInit(na_210) } else { k__9 = jrt.Long_ValueOf_J__Long_NoInit(n0_211 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_210) { var n0_211_2 float64 = jrt.NN(jrt.Double_Cast(na_210)).DoubleValue__D(); k__9 = jrt.Double_ValueOf_D__Double_NoInit(n0_211_2 + 1.0).Ref() } else { k__9 = lang.Numbers_Inc_O__Number_NoInit(na_210) } }
//line :111:1
			var line__10 any; var or__1927000174__auto____10 any; var root_212 any = A_arbace_go_check_env_A_const_39.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, A_arbace_go_check_env_line_of_A_fn_class); var ifn_214 lang.IFn



			if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(j__8)); if linked_213 == nil { or__1927000174__auto____10 = ifn_214.Invoke_O__O(arg_215) } else { or__1927000174__auto____10 = linked_213.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_212, arg_215) }; if jrt.J2g_Truth(or__1927000174__auto____10) { line__10 = or__1927000174__auto____10 } else { line__10 = start__2 }
//line :111:1
		L1: for {




			var tmp7 bool; var na_216 any = k__9; var na_217 any = i__1; var tmp8 bool; var tmp9 bool; tmp9 = jrt.Long_InstanceOf(na_216); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_217) }; tmp8 = tmp9; if tmp8 { var n0_218 int64 = jrt.NN(jrt.Long_Cast(na_216)).LongValue__J(); var n1_219 int64 = jrt.NN(jrt.Long_Cast(na_217)).LongValue__J(); tmp7 = n0_218 > n1_219 } else { var tmp10 bool; var tmp11 bool; tmp11 = jrt.Double_InstanceOf(na_216); if tmp11 { tmp11 = jrt.Double_InstanceOf(na_217) }; tmp10 = tmp11; if tmp10 { var n0_218_2 float64 = jrt.NN(jrt.Double_Cast(na_216)).DoubleValue__D(); var n1_219_2 float64 = jrt.NN(jrt.Double_Cast(na_217)).DoubleValue__D(); tmp7 = n1_219_2 < n0_218_2 } else { tmp7 = lang.Numbers_Gt_O_O__Z_NoInit(na_216, na_217) } }; if tmp7 { return line__10 } else { var pe__11 any; var root_221 any = A_arbace_go_check_env_A_const_35.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, A_arbace_go_check_env_end_line_A_fn_class); var ifn_223 lang.IFn

				if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any; var tmp12 jrt.Number_I; var na_226 any = k__9; if jrt.Long_InstanceOf(na_226) { var n0_227 int64 = jrt.NN(jrt.Long_Cast(na_226)).LongValue__J(); if n0_227 == -9223372036854775808 { tmp12 = lang.Numbers_Dec_O__Number_NoInit(na_226) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_227 - 1)) } } else { if jrt.Double_InstanceOf(na_226) { var n0_227_2 float64 = jrt.NN(jrt.Double_Cast(na_226)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_227_2 - 1.0)) } else { tmp12 = lang.Numbers_Dec_O__Number_NoInit(na_226) } }; arg_224 = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(tmp12)); var arg_225 any = line__10; if linked_222 == nil { pe__11 = ifn_223.Invoke_O_O__O(arg_224, arg_225) } else { pe__11 = linked_222.(*A_arbace_go_check_env_end_line_A).Invoke_O_O_O__O(root_221, arg_224, arg_225) }
				var tmp13 jrt.Number_I; var na_228 any = k__9; if jrt.Long_InstanceOf(na_228) { var n0_229 int64 = jrt.NN(jrt.Long_Cast(na_228)).LongValue__J(); if n0_229 == 9223372036854775807 { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_228) } else { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_229 + 1)) } } else { if jrt.Double_InstanceOf(na_228) { var n0_229_2 float64 = jrt.NN(jrt.Double_Cast(na_228)).DoubleValue__D(); tmp13 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_229_2 + 1.0)) } else { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_228) } }; var tmp14 any = tmp13; var tmp15 any; var tmp16 any; var root_230 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = bmap__7; var arg_234 any = k__9; if linked_231 == nil { tmp16 = ifn_232.Invoke_O_O__O(arg_233, arg_234) } else { tmp16 = linked_231.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_230, arg_233, arg_234) }; if jrt.J2g_Truth(tmp16) { var or__1927000174__auto____12 any = lang.RT_Get_O_O__O_NoInit(bmap__7, k__9); if jrt.J2g_Truth(or__1927000174__auto____12) { tmp15 = or__1927000174__auto____12 } else { var na_235 any = pe__11; if jrt.Long_InstanceOf(na_235) { var n0_236 int64 = jrt.NN(jrt.Long_Cast(na_235)).LongValue__J(); if n0_236 == 9223372036854775807 { tmp15 = lang.Numbers_Inc_O__Number_NoInit(na_235) } else { tmp15 = jrt.Long_ValueOf_J__Long_NoInit(n0_236 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_235) { var n0_236_2 float64 = jrt.NN(jrt.Double_Cast(na_235)).DoubleValue__D(); tmp15 = jrt.Double_ValueOf_D__Double_NoInit(n0_236_2 + 1.0).Ref() } else { tmp15 = lang.Numbers_Inc_O__Number_NoInit(na_235) } } } } else { tmp15 = pe__11 }; k__9, line__10 = tmp14, tmp15; continue L1 } } } } else {
//line :108:1
					return nil } }; /*line :101:1*/panic("j2g: unreachable") }
//line :101:1
func (t *A_arbace_go_check_env_child_line_A) InvokeSpec_O_O_J_O_O__O(self, f__0 any, i__1_l int64, i__1_b, start__2 any) any {






	{ var tmp1 any; var and__1927000168__auto____4 any = start__2; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var or__1927000174__auto____5 any; var root_237 any = A_arbace_go_check_env_A_const_31.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = f__0; if linked_238 == nil { or__1927000174__auto____5 = ifn_239.Invoke_O__O(arg_240) } else { or__1927000174__auto____5 = linked_238.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_237, arg_240) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else { var root_241 any = A_arbace_go_check_env_A_const_32.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = f__0; if linked_242 == nil { and__1927000168__auto____5 = ifn_243.Invoke_O__O(arg_244) } else { and__1927000168__auto____5 = linked_242.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_241, arg_244) } }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp2 bool; var na_245 int64 = int64(lang.RT_Count_O__I_NoInit(f__0)); var n0_246 int64 = i__1_l; var n1_247 int64 = na_245; tmp2 = n0_246 < n1_247; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref() } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { var m__4 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__0); var f__5 any; var tmp3 any; var root_249 any = A_arbace_go_check_env_A_const_32.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_251 lang.IFn

		if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = f__0; if linked_250 == nil { tmp3 = ifn_251.Invoke_O__O(arg_252) } else { tmp3 = linked_250.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_249, arg_252) }; if jrt.J2g_Truth(tmp3) { f__5 = f__0 } else { var root_253 any = A_arbace_go_check_env_A_const_34.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = f__0; if linked_254 == nil { f__5 = ifn_255.Invoke_O__O(arg_256) } else { f__5 = linked_254.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_253, arg_256) } }
//line :108:1
		var or__1927000174__auto____6 any; var root_257 any = A_arbace_go_check_env_A_const_39.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, A_arbace_go_check_env_line_of_A_fn_class); var ifn_259 lang.IFn


		if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any; var tmp4 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp4 = i__1_b } else { tmp4 = i__1_b }; arg_260 = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(tmp4)); if linked_258 == nil { or__1927000174__auto____6 = ifn_259.Invoke_O__O(arg_260) } else { or__1927000174__auto____6 = linked_258.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_257, arg_260) }; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { var bmap__7 any; var root_261 any = A_arbace_go_check_env_A_const_40.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_263 lang.IFn

			if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_265 any; var iter__1927001039__auto____7 any; var fnbody__267 any = A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A_New(); var tmp5 *jrt.Class; var fncls__266 *jrt.Class = A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A_fn_class; if fncls__266 == nil { var fncls__266d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A_fn_class = fncls__266d; tmp5 = fncls__266d } else { tmp5 = fncls__266 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__267, tmp5, nil); arg_265 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(A_arbace_go_check_env_A_const_51.Invoke_O__O(m__4)); if linked_262 == nil { bmap__7 = ifn_263.Invoke_O_O__O(arg_264, arg_265) } else { bmap__7 = linked_262.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_261, arg_264, arg_265) }
//line :111:1
			var j__8 any; var tmp6 *lang.Compiler_AOTFn; var fnbody__269 any; var tmp7 any


			if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp7 = i__1_b } else { tmp7 = i__1_b }; fnbody__269 = A_arbace_go_check_env_child_line_fn__1719000033_A_New_O_O(f__5, tmp7); var tmp8 *jrt.Class; var fncls__268 *jrt.Class = A_arbace_go_check_env_child_line_fn__1719000033_A_fn_class; if fncls__268 == nil { var fncls__268d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__269); A_arbace_go_check_env_child_line_fn__1719000033_A_fn_class = fncls__268d; tmp8 = fncls__268d } else { tmp8 = fncls__268 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__269, tmp8, nil); j__8 = Up_Compiler_AOTFn_IFn(tmp6).Invoke__O()
//line :111:1
			var k__9 any
			var na_270 any = j__8


			if jrt.Long_InstanceOf(na_270) { var n0_271 int64 = jrt.NN(jrt.Long_Cast(na_270)).LongValue__J(); if n0_271 == 9223372036854775807 { k__9 = lang.Numbers_Inc_O__Number_NoInit(na_270) } else { k__9 = jrt.Long_ValueOf_J__Long_NoInit(n0_271 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_270) { var n0_271_2 float64 = jrt.NN(jrt.Double_Cast(na_270)).DoubleValue__D(); k__9 = jrt.Double_ValueOf_D__Double_NoInit(n0_271_2 + 1.0).Ref() } else { k__9 = lang.Numbers_Inc_O__Number_NoInit(na_270) } }
//line :111:1
			var line__10 any; var or__1927000174__auto____10 any; var root_272 any = A_arbace_go_check_env_A_const_39.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, A_arbace_go_check_env_line_of_A_fn_class); var ifn_274 lang.IFn



			if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(j__8)); if linked_273 == nil { or__1927000174__auto____10 = ifn_274.Invoke_O__O(arg_275) } else { or__1927000174__auto____10 = linked_273.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_272, arg_275) }; if jrt.J2g_Truth(or__1927000174__auto____10) { line__10 = or__1927000174__auto____10 } else { line__10 = start__2 }
//line :111:1
		L1: for {




			var tmp9 bool; var na_276 any = k__9; if jrt.Long_InstanceOf(na_276) { var n0_277 int64 = jrt.NN(jrt.Long_Cast(na_276)).LongValue__J(); var n1_278 int64 = i__1_l; tmp9 = n0_277 > n1_278 } else { var tmp10 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); tmp10 = i__1_b } else { tmp10 = i__1_b }; tmp9 = lang.Numbers_Gt_O_O__Z_NoInit(na_276, tmp10) }; if tmp9 { return line__10 } else { var pe__11 any; var root_280 any = A_arbace_go_check_env_A_const_35.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, A_arbace_go_check_env_end_line_A_fn_class); var ifn_282 lang.IFn

				if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any; var tmp11 jrt.Number_I; var na_285 any = k__9; if jrt.Long_InstanceOf(na_285) { var n0_286 int64 = jrt.NN(jrt.Long_Cast(na_285)).LongValue__J(); if n0_286 == -9223372036854775808 { tmp11 = lang.Numbers_Dec_O__Number_NoInit(na_285) } else { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_286 - 1)) } } else { if jrt.Double_InstanceOf(na_285) { var n0_286_2 float64 = jrt.NN(jrt.Double_Cast(na_285)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_286_2 - 1.0)) } else { tmp11 = lang.Numbers_Dec_O__Number_NoInit(na_285) } }; arg_283 = lang.RT_Nth_O_I__O_NoInit(f__5, lang.RT_IntCast_O__I_NoInit(tmp11)); var arg_284 any = line__10; if linked_281 == nil { pe__11 = ifn_282.Invoke_O_O__O(arg_283, arg_284) } else { pe__11 = linked_281.(*A_arbace_go_check_env_end_line_A).Invoke_O_O_O__O(root_280, arg_283, arg_284) }
				var tmp12 jrt.Number_I; var na_287 any = k__9; if jrt.Long_InstanceOf(na_287) { var n0_288 int64 = jrt.NN(jrt.Long_Cast(na_287)).LongValue__J(); if n0_288 == 9223372036854775807 { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_287) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_288 + 1)) } } else { if jrt.Double_InstanceOf(na_287) { var n0_288_2 float64 = jrt.NN(jrt.Double_Cast(na_287)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_288_2 + 1.0)) } else { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_287) } }; var tmp13 any = tmp12; var tmp14 any; var tmp15 any; var root_289 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = bmap__7; var arg_293 any = k__9; if linked_290 == nil { tmp15 = ifn_291.Invoke_O_O__O(arg_292, arg_293) } else { tmp15 = linked_290.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_289, arg_292, arg_293) }; if jrt.J2g_Truth(tmp15) { var or__1927000174__auto____12 any = lang.RT_Get_O_O__O_NoInit(bmap__7, k__9); if jrt.J2g_Truth(or__1927000174__auto____12) { tmp14 = or__1927000174__auto____12 } else { var na_294 any = pe__11; if jrt.Long_InstanceOf(na_294) { var n0_295 int64 = jrt.NN(jrt.Long_Cast(na_294)).LongValue__J(); if n0_295 == 9223372036854775807 { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_294) } else { tmp14 = jrt.Long_ValueOf_J__Long_NoInit(n0_295 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_294) { var n0_295_2 float64 = jrt.NN(jrt.Double_Cast(na_294)).DoubleValue__D(); tmp14 = jrt.Double_ValueOf_D__Double_NoInit(n0_295_2 + 1.0).Ref() } else { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_294) } } } } else { tmp14 = pe__11 }; k__9, line__10 = tmp13, tmp14; continue L1 } } } } else {
//line :108:1
					return nil } }
//line :101:1
	panic("j2g: unreachable") }
//line :101:1
func (t *A_arbace_go_check_env_child_line_A) Invoke_O_O_O__O(self, f__0, i__1 any) any {




	var root_296 any = A_arbace_go_check_env_A_const_36.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_296, A_arbace_go_check_env_child_line_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = f__0; var arg_300 any = i__1; var arg_301 any; var root_302 any = A_arbace_go_check_env_A_const_39.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, A_arbace_go_check_env_line_of_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = f__0; if linked_303 == nil { arg_301 = ifn_304.Invoke_O__O(arg_305) } else { arg_301 = linked_303.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_302, arg_305) }; if linked_297 == nil { return ifn_298.Invoke_O_O_O__O(arg_299, arg_300, arg_301) } else { if jrt.Long_InstanceOf(arg_300) { return linked_297.(*A_arbace_go_check_env_child_line_A).InvokeSpec_O_O_J_O_O__O(root_296, arg_299, jrt.NN(jrt.Long_Cast(arg_300)).LongValue__J(), arg_300, arg_301) } else { return linked_297.(*A_arbace_go_check_env_child_line_A).Invoke_O_O_O_O__O(root_296, arg_299, arg_300, arg_301)
	}
	}
}



func A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A_New() *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A) Ctor() {}
//line :113:1
func (t *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A) Invoke_O_O__O(self, s__1719000024__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__197 any = A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A_New_O_O(s__1719000024__1, self); var tmp2 *jrt.Class; var fncls__196 *jrt.Class = A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A_fn_class; if fncls__196 == nil { var fncls__196d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__197); A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A_fn_class = fncls__196d; tmp2 = fncls__196d } else { tmp2 = fncls__196 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__197, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :113:1
func A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A_New_O_O(p0, p1 any) *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A{}; t.Ctor_O_O(p0, p1); return t }
//line :113:1
func (t *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A) Ctor_O_O(c__s__1719000024, c__iter__1719000023 any) { t.F_s__1719000024 = c__s__1719000024; t.F_iter__1719000023 = c__iter__1719000023 }
//line :113:1
func (t *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A) Invoke_O__O(self any) any { { var s__1719000024__1 any; var t_ any = t.F_s__1719000024; t.F_s__1719000024 = nil; s__1719000024__1 = t_; for { var temp__1927000414__auto____2 any; var root_130 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = s__1719000024__1; if linked_131 == nil { temp__1927000414__auto____2 = ifn_132.Invoke_O__O(arg_133) } else { temp__1927000414__auto____2 = linked_131.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_130, arg_133) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1719000024__3 any = temp__1927000414__auto____2; var tmp1 any; var root_134 any = A_arbace_go_check_env_A_const_41.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = s__1719000024__3; if linked_135 == nil { tmp1 = ifn_136.Invoke_O__O(arg_137) } else { tmp1 = linked_135.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_134, arg_137) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_138 any = A_arbace_go_check_env_A_const_42.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = s__1719000024__3; if linked_139 == nil { c__1927001037__auto____4 = ifn_140.Invoke_O__O(arg_141) } else { c__1927001037__auto____4 = linked_139.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_138, arg_141) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1719000026__6 any; var root_142 any = A_arbace_go_check_env_A_const_43.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_143 == nil { b__1719000026__6 = ifn_144.Invoke_O__O(arg_145) } else { b__1719000026__6 = linked_143.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_142, arg_145) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__156 any = A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A_New_O_I_O(b__1719000026__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__156); A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A_fn_class = fncls__155d; tmp3 = fncls__155d } else { tmp3 = fncls__155 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__156, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_157 any = A_arbace_go_check_env_A_const_45.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any; var root_162 any = A_arbace_go_check_env_A_const_46.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = b__1719000026__6; if linked_163 == nil { arg_160 = ifn_164.Invoke_O__O(arg_165) } else { arg_160 = linked_163.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_162, arg_165) }; var arg_161 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1719000023); var tmp5 any; var root_166 any = A_arbace_go_check_env_A_const_47.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = s__1719000024__3; if linked_167 == nil { tmp5 = ifn_168.Invoke_O__O(arg_169) } else { tmp5 = linked_167.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_166, arg_169) }; arg_161 = tmp4.Invoke_O__O(tmp5); if linked_158 == nil { return ifn_159.Invoke_O_O__O(arg_160, arg_161) } else { return linked_158.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_157, arg_160, arg_161) } } else { var root_170 any = A_arbace_go_check_env_A_const_45.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any; var root_175 any = A_arbace_go_check_env_A_const_46.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = b__1719000026__6; if linked_176 == nil { arg_173 = ifn_177.Invoke_O__O(arg_178) } else { arg_173 = linked_176.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_175, arg_178) }; var arg_174 any; if linked_171 == nil { return ifn_172.Invoke_O_O__O(arg_173, arg_174) } else { return linked_171.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_170, arg_173, arg_174) } } } else { var b__4 any; var root_179 any = A_arbace_go_check_env_A_const_48.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = s__1719000024__3; if linked_180 == nil { b__4 = ifn_181.Invoke_O__O(arg_182) } else { b__4 = linked_180.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_179, arg_182) }; var root_183 any = A_arbace_go_check_env_A_const_49.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any; var tmp6 any; var root_188 any = A_arbace_go_check_env_A_const_32.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = b__4; if linked_189 == nil { tmp6 = ifn_190.Invoke_O__O(arg_191) } else { tmp6 = linked_189.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_188, arg_191) }; if jrt.J2g_Truth(tmp6) { arg_186 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(b__4, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(b__4, lang.RT_IntCast_J__I_NoInit(1))) } else { arg_186 = lang.Tuple_Create_O_O__IPersistentVector(b__4, nil) }; var arg_187 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1719000023); var tmp8 any; var root_192 any = A_arbace_go_check_env_A_const_50.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = s__1719000024__3; if linked_193 == nil { tmp8 = ifn_194.Invoke_O__O(arg_195) } else { tmp8 = linked_193.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_192, arg_195) }; arg_187 = tmp7.Invoke_O__O(tmp8); if linked_184 == nil { return ifn_185.Invoke_O_O__O(arg_186, arg_187) } else { return linked_184.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_183, arg_186, arg_187) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :113:1
func A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :113:1
func (t *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A) Ctor_O_I_O(c__b__1719000026 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1719000026 = c__b__1719000026; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :113:1
func (t *A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A) Invoke_O__O(self any) any { { var i__1719000025__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1719000025__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1719000025__1)); var root_146 any = A_arbace_go_check_env_A_const_44.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = t.F_b__1719000026; var arg_150 any; var tmp2 any; var root_151 any = A_arbace_go_check_env_A_const_32.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = b__2; if linked_152 == nil { tmp2 = ifn_153.Invoke_O__O(arg_154) } else { tmp2 = linked_152.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_151, arg_154) }; if jrt.J2g_Truth(tmp2) { arg_150 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(b__2, lang.RT_IntCast_J__I_NoInit(0)), lang.RT_Nth_O_I__O_NoInit(b__2, lang.RT_IntCast_J__I_NoInit(1))) } else { arg_150 = lang.Tuple_Create_O_O__IPersistentVector(b__2, nil) }; if linked_147 == nil { ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { linked_147.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) }; i__1719000025__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1719000025__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_check_env_child_line_fn__1719000033_A_New_O_O(p0, p1 any) *A_arbace_go_check_env_child_line_fn__1719000033_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_child_line_fn__1719000033_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_go_check_env_child_line_fn__1719000033_A) Ctor_O_O(c__f, c__i any) { t.F_f = c__f; t.F_i = c__i }
//line :114:1
func (t *A_arbace_go_check_env_child_line_fn__1719000033_A) Invoke_O__O(self any) any { { var j__1 any; var t_ any = t.F_i; t.F_i = nil; j__1 = t_; L1: for { var tmp1 any; var or__1927000174__auto____2 bool; var na_200 any = j__1; if jrt.Long_InstanceOf(na_200) { var n0_201 int64 = jrt.NN(jrt.Long_Cast(na_200)).LongValue__J(); or__1927000174__auto____2 = n0_201 == 0 } else { if jrt.Double_InstanceOf(na_200) { var n0_201_2 float64 = jrt.NN(jrt.Double_Cast(na_200)).DoubleValue__D(); or__1927000174__auto____2 = n0_201_2 == 0.0 } else { or__1927000174__auto____2 = lang.Numbers_IsZero_O__Z_NoInit(na_200) } }; if or__1927000174__auto____2 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var root_202 any = A_arbace_go_check_env_A_const_39.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, A_arbace_go_check_env_line_of_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var tmp2 any = t.F_f; var arg_205 any = lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(j__1)); if linked_203 == nil { tmp1 = ifn_204.Invoke_O__O(arg_205) } else { tmp1 = linked_203.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_202, arg_205) } }; if jrt.J2g_Truth(tmp1) { return j__1 } else { var tmp3 jrt.Number_I; var na_206 any = j__1; if jrt.Long_InstanceOf(na_206) { var n0_207 int64 = jrt.NN(jrt.Long_Cast(na_206)).LongValue__J(); if n0_207 == -9223372036854775808 { tmp3 = lang.Numbers_Dec_O__Number_NoInit(na_206) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_207 - 1)) } } else { if jrt.Double_InstanceOf(na_206) { var n0_207_2 float64 = jrt.NN(jrt.Double_Cast(na_206)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_207_2 - 1.0)) } else { tmp3 = lang.Numbers_Dec_O__Number_NoInit(na_206) } }; j__1 = tmp3; continue L1 } } }; panic("j2g: unreachable") }











func A_arbace_go_check_env_with_child_line_A_New() *A_arbace_go_check_env_with_child_line_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_with_child_line_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_go_check_env_with_child_line_A) Ctor() {}
//line :126:1
func (t *A_arbace_go_check_env_with_child_line_A) DoInvoke_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, parent__2, i__3, body__4 any) any { var root_306 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_53.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_55); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp4 any; var root_316 any = A_arbace_go_check_env_A_const_56.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = A_arbace_go_check_env_A_const_57.GetRawRoot__O(); var arg_320 any; var root_321 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_53.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_58); var tmp7 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(parent__2); var tmp8 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_59); var tmp9 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(i__3); var tmp10 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_60); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp12 any; var root_334 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_53.GetRawRoot__O()); var tmp14 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_61); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp16 any; var root_344 any = A_arbace_go_check_env_A_const_56.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = A_arbace_go_check_env_A_const_57.GetRawRoot__O(); var arg_348 any; var root_349 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any; var root_353 any = A_arbace_go_check_env_A_const_53.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; if linked_354 == nil { arg_352 = ifn_355.Invoke__O() } else { arg_352 = linked_354.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O__O(root_353) }; if linked_350 == nil { arg_348 = ifn_351.Invoke_O__O(arg_352) } else { arg_348 = linked_350.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_349, arg_352) }; if linked_345 == nil { tmp16 = ifn_346.Invoke_O_O__O(arg_347, arg_348) } else { tmp16 = linked_345.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_344, arg_347, arg_348) }; arg_337 = tmp13.Invoke_O_O_O__O(tmp14, tmp15.Invoke_O__O(tmp16), body__4); if linked_335 == nil { tmp12 = ifn_336.Invoke_O__O(arg_337) } else { tmp12 = linked_335.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_334, arg_337) }; arg_324 = tmp5.Invoke_O_O_O_O_O_O__O(tmp6, tmp7, tmp8, tmp9, tmp10, tmp11.Invoke_O__O(tmp12)); if linked_322 == nil { arg_320 = ifn_323.Invoke_O__O(arg_324) } else { arg_320 = linked_322.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_321, arg_324) }; if linked_317 == nil { tmp4 = ifn_318.Invoke_O_O__O(arg_319, arg_320) } else { tmp4 = linked_317.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_316, arg_319, arg_320) }; var tmp17 any = tmp3.Invoke_O__O(tmp4); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp19 any; var root_356 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_53.GetRawRoot__O()); var tmp21 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_62); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp23 any; var root_367 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any; var root_371 any = A_arbace_go_check_env_A_const_53.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_63); var arg_375 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp25 any; var root_376 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_53.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_64), lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_58), lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_59), lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(nil)); if linked_377 == nil { tmp25 = ifn_378.Invoke_O__O(arg_379) } else { tmp25 = linked_377.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_376, arg_379) }; arg_375 = tmp24.Invoke_O__O(tmp25); if linked_372 == nil { arg_370 = ifn_373.Invoke_O_O__O(arg_374, arg_375) } else { arg_370 = linked_372.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_371, arg_374, arg_375) }; if linked_368 == nil { tmp23 = ifn_369.Invoke_O__O(arg_370) } else { tmp23 = linked_368.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_367, arg_370) }; var tmp26 any = tmp22.Invoke_O__O(tmp23); var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp28 any; var root_387 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any; var root_391 any = A_arbace_go_check_env_A_const_53.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_60); if linked_392 == nil { arg_390 = ifn_393.Invoke_O__O(arg_394) } else { arg_390 = linked_392.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_391, arg_394) }; if linked_388 == nil { tmp28 = ifn_389.Invoke_O__O(arg_390) } else { tmp28 = linked_388.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_387, arg_390) }; var tmp29 any = tmp27.Invoke_O__O(tmp28); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp31 any; var root_395 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_53.GetRawRoot__O()); var tmp33 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_65); var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp35 any; var root_405 any = A_arbace_go_check_env_A_const_56.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = A_arbace_go_check_env_A_const_57.GetRawRoot__O(); var arg_409 any; var root_410 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any; var root_414 any = A_arbace_go_check_env_A_const_53.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_414, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_416 lang.IFn; if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_66); var arg_418 any; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp37 any; var root_419 any = A_arbace_go_check_env_A_const_56.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = A_arbace_go_check_env_A_const_57.GetRawRoot__O(); var arg_423 any; var root_424 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any; var root_428 any = A_arbace_go_check_env_A_const_53.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_58); var arg_432 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_59); if linked_429 == nil { arg_427 = ifn_430.Invoke_O_O__O(arg_431, arg_432) } else { arg_427 = linked_429.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_428, arg_431, arg_432) }; if linked_425 == nil { arg_423 = ifn_426.Invoke_O__O(arg_427) } else { arg_423 = linked_425.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_424, arg_427) }; if linked_420 == nil { tmp37 = ifn_421.Invoke_O_O__O(arg_422, arg_423) } else { tmp37 = linked_420.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_419, arg_422, arg_423) }; arg_418 = tmp36.Invoke_O__O(tmp37); if linked_415 == nil { arg_413 = ifn_416.Invoke_O_O__O(arg_417, arg_418) } else { arg_413 = linked_415.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_414, arg_417, arg_418) }; if linked_411 == nil { arg_409 = ifn_412.Invoke_O__O(arg_413) } else { arg_409 = linked_411.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_410, arg_413) }; if linked_406 == nil { tmp35 = ifn_407.Invoke_O_O__O(arg_408, arg_409) } else { tmp35 = linked_406.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_405, arg_408, arg_409) }; var tmp38 any = tmp34.Invoke_O__O(tmp35); var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()); var tmp40 any; var root_433 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any; var root_437 any = A_arbace_go_check_env_A_const_53.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = lang.IFn_Cast(A_arbace_go_check_env_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_60); if linked_438 == nil { arg_436 = ifn_439.Invoke_O__O(arg_440) } else { arg_436 = linked_438.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_437, arg_440) }; if linked_434 == nil { tmp40 = ifn_435.Invoke_O__O(arg_436) } else { tmp40 = linked_434.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_433, arg_436) }; arg_398 = tmp32.Invoke_O_O_O__O(tmp33, tmp38, tmp39.Invoke_O__O(tmp40)); if linked_396 == nil { tmp31 = ifn_397.Invoke_O__O(arg_398) } else { tmp31 = linked_396.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_395, arg_398) }; arg_359 = tmp20.Invoke_O_O_O_O__O(tmp21, tmp26, tmp29, tmp30.Invoke_O__O(tmp31)); if linked_357 == nil { tmp19 = ifn_358.Invoke_O__O(arg_359) } else { tmp19 = linked_357.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_356, arg_359) }; arg_309 = tmp1.Invoke_O_O_O__O(tmp2, tmp17, tmp18.Invoke_O__O(tmp19)); if linked_307 == nil { return ifn_308.Invoke_O__O(arg_309) } else { return linked_307.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_306, arg_309) } }







func A_arbace_go_check_env_current_line_A_New() *A_arbace_go_check_env_current_line_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_current_line_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_go_check_env_current_line_A) Ctor() {}
//line :134:1
func (t *A_arbace_go_check_env_current_line_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var temp__1927000414__auto____1 any = A_arbace_go_check_env_A_const_67.Get__O(); if


	jrt.J2g_Truth(temp__1927000414__auto____1) { var vec__1719000044__2 any = temp__1927000414__auto____1; var p__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000044__2, lang.RT_IntCast_J__I_NoInit(0), nil); var i__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000044__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_441 any = A_arbace_go_check_env_A_const_36.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, A_arbace_go_check_env_child_line_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = p__3; var arg_445 any = i__4; if linked_442 == nil { or__1927000174__auto____1 = ifn_443.Invoke_O_O__O(arg_444, arg_445) } else { or__1927000174__auto____1 = linked_442.(*A_arbace_go_check_env_child_line_A).Invoke_O_O_O__O(root_441, arg_444, arg_445) } } else { or__1927000174__auto____1 = nil }; if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { return A_arbace_go_check_env_A_const_68.Get__O() } }

func A_arbace_go_check_env_err_BANG__A_New() *A_arbace_go_check_env_err_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_err_BANG__A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_go_check_env_err_BANG__A) Ctor() {}
//line :139:1
func (t *A_arbace_go_check_env_err_BANG__A) DoInvoke_O_O_O_O_O__O(self, f__0, code__1, fmt__2, args__3 any) any {


	var root_446 any = A_arbace_go_check_env_A_const_28.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any; var or__1927000174__auto____5 any; var root_452 any = A_arbace_go_check_env_A_const_39.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, A_arbace_go_check_env_line_of_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = f__0; if linked_453 == nil { or__1927000174__auto____5 = ifn_454.Invoke_O__O(arg_455) } else { or__1927000174__auto____5 = linked_453.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_452, arg_455) }; if jrt.J2g_Truth(or__1927000174__auto____5) { arg_449 = or__1927000174__auto____5 } else { var root_456 any = A_arbace_go_check_env_A_const_69.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, A_arbace_go_check_env_current_line_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; if linked_457 == nil { arg_449 = ifn_458.Invoke__O() } else { arg_449 = linked_457.(*A_arbace_go_check_env_current_line_A).Invoke_O__O(root_456) } }; var arg_450 any = code__1; var arg_451 any; var tmp1 any; var root_459 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_461 lang.IFn; if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = args__3; if linked_460 == nil { tmp1 = ifn_461.Invoke_O__O(arg_462) } else { tmp1 = linked_460.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_459, arg_462) }; if jrt.J2g_Truth(tmp1) { var root_463 any = A_arbace_go_check_env_A_const_56.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = A_arbace_go_check_env_A_const_70.GetRawRoot__O(); var arg_467 any = fmt__2; var arg_468 any = args__3; if linked_464 == nil { arg_451 = ifn_465.Invoke_O_O_O__O(arg_466, arg_467, arg_468) } else { arg_451 = linked_464.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_463, arg_466, arg_467, arg_468) } } else { arg_451 = fmt__2 }; if linked_447 == nil { return ifn_448.Invoke_O_O_O__O(arg_449, arg_450, arg_451) } else { return linked_447.(*A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O__O(root_446, arg_449, arg_450, arg_451)
	}
}

func A_arbace_go_check_env_generic_BANG__A_New() *A_arbace_go_check_env_generic_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_generic_BANG__A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_go_check_env_generic_BANG__A) Ctor() {}
//line :146:1
func (t *A_arbace_go_check_env_generic_BANG__A) Invoke_O__O(self any) any {



	if jrt.J2g_Truth(A_arbace_go_check_env_A_const_25.Get__O()) { var tmp1 *lang.Volatile = lang.Volatile_Cast(A_arbace_go_check_env_A_const_25.Get__O()); var tmp2 any; var root_469 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_25.Get__O())).Deref__O(); var arg_473 any = A_arbace_go_check_env_A_const_71; var arg_474 any = jrt.Boolean_TRUE.Ref(); if linked_470 == nil { tmp2 = ifn_471.Invoke_O_O_O__O(arg_472, arg_473, arg_474) } else { tmp2 = linked_470.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_469, arg_472, arg_473, arg_474) }; return jrt.NN(tmp1).Reset_O__O(tmp2) } else { return nil
	} }
func A_arbace_go_check_env_unsupported_BANG__A_New() *A_arbace_go_check_env_unsupported_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_unsupported_BANG__A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_go_check_env_unsupported_BANG__A) Ctor() {}
//line :152:1
func (t *A_arbace_go_check_env_unsupported_BANG__A) Invoke_O_O__O(self, what__0 any) any {




	var root_475 any = A_arbace_go_check_env_A_const_72.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, A_arbace_go_check_env_generic_BANG__A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; if linked_476 == nil { ifn_477.Invoke__O() } else { linked_476.(*A_arbace_go_check_env_generic_BANG__A).Invoke_O__O(root_475) }
	var tmp1 any; var and__1927000168__auto____2 any = A_arbace_go_check_env_A_const_25.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Keyword = A_arbace_go_check_env_A_const_73; var tmp3 any; var root_478 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = A_arbace_go_check_env_A_const_25.Get__O(); if linked_479 == nil { tmp3 = ifn_480.Invoke_O__O(arg_481) } else { tmp3 = linked_479.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_478, arg_481) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2.Invoke_O__O(tmp3), nil)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_12.GetRawRoot__O()); var tmp5 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_25.Get__O())).Deref__O(); var tmp6 any = A_arbace_go_check_env_A_const_73; var tmp7 any = A_arbace_go_check_env_A_const_74; jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_25.Get__O())).Reset_O__O(tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, what__0, tmp7, A_arbace_go_check_env_A_const_68.Get__O())) }
//line :152:1
	return nil
}








func A_arbace_go_check_env_unsupported_QMARK__A_New() *A_arbace_go_check_env_unsupported_QMARK__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_unsupported_QMARK__A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_go_check_env_unsupported_QMARK__A) Ctor() {}
//line :162:1
func (t *A_arbace_go_check_env_unsupported_QMARK__A) Invoke_O_O__O(self, e__0 any) any { var and__1927000168__auto____2 bool = lang.ExceptionInfo_InstanceOf(e__0); if and__1927000168__auto____2 { var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_75; var tmp2 any; var root_490 any = A_arbace_go_check_env_A_const_76.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = e__0; if linked_491 == nil { tmp2 = ifn_492.Invoke_O__O(arg_493) } else { tmp2 = linked_491.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_490, arg_493) }; return tmp1.Invoke_O__O(tmp2) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }








func A_arbace_go_check_env_verified_BANG__A_New() *A_arbace_go_check_env_verified_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_verified_BANG__A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_go_check_env_verified_BANG__A) Ctor() {}
//line :171:1
func (t *A_arbace_go_check_env_verified_BANG__A) Invoke_O_O_O__O(self, k__0, f__1 any) any {




	if jrt.J2g_Truth(A_arbace_go_check_env_A_const_25.Get__O()) { var seen__3 any; var or__1927000174__auto____3 any = A_arbace_go_check_env_A_const_77.Get__O()
		if jrt.J2g_Truth(or__1927000174__auto____3) { seen__3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_78; var tmp2 any; var root_494 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = A_arbace_go_check_env_A_const_25.Get__O(); if linked_495 == nil { tmp2 = ifn_496.Invoke_O__O(arg_497) } else { tmp2 = linked_495.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_494, arg_497) }; or__1927000174__auto____4 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(or__1927000174__auto____4) { seen__3 = or__1927000174__auto____4 } else { var m__5 any = jrt.IdentityHashMap_New(); var tmp3 *lang.Volatile = lang.Volatile_Cast(A_arbace_go_check_env_A_const_25.Get__O()); var tmp4 any; var root_507 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_509 lang.IFn
			if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_25.Get__O())).Deref__O(); var arg_511 any = A_arbace_go_check_env_A_const_78; var arg_512 any = m__5; if linked_508 == nil { tmp4 = ifn_509.Invoke_O_O_O__O(arg_510, arg_511, arg_512) } else { tmp4 = linked_508.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_507, arg_510, arg_511, arg_512) }; jrt.NN(tmp3).Reset_O__O(tmp4)
//line :177:1
			seen__3 = m__5 } }
//line :176:1
		var ks__4 any = jrt.IdentityHashMap_Cast(seen__3).Get_O__O(f__1); var tmp5 any; var root_498 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_500 lang.IFn



		if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = ks__4; var arg_502 any = k__0; if linked_499 == nil { tmp5 = ifn_500.Invoke_O_O__O(arg_501, arg_502) } else { tmp5 = linked_499.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_498, arg_501, arg_502) }; if jrt.J2g_Truth(tmp5) { return nil } else {
			var tmp6 jrt.IdentityHashMap_I = jrt.IdentityHashMap_Cast(seen__3); var tmp7 any; var root_513 any = A_arbace_go_check_env_A_const_9.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_513, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_515 lang.IFn; if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any; var or__1927000174__auto____5 any = ks__4; if jrt.J2g_Truth(or__1927000174__auto____5) { arg_516 = or__1927000174__auto____5 } else { arg_516 = lang.PersistentHashSet_EMPTY.Ref() }; var arg_517 any = k__0; if linked_514 == nil { tmp7 = ifn_515.Invoke_O_O__O(arg_516, arg_517) } else { tmp7 = linked_514.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_513, arg_516, arg_517) }; tmp6.Put_O_O__O(f__1, tmp7)
			var root_503 any = A_arbace_go_check_env_A_const_79.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = k__0; if linked_504 == nil { return ifn_505.Invoke_O__O(arg_506) } else { return linked_504.(*A_arbace_go_check_env_verified_BANG__A).Invoke_O_O__O(root_503, arg_506) } } } else {
//line :176:1
				return nil } }
//line :171:1
func (t *A_arbace_go_check_env_verified_BANG__A) Invoke_O_O__O(self, k__0 any) any {


	if jrt.J2g_Truth(A_arbace_go_check_env_A_const_25.Get__O()) { var tmp1 *lang.Volatile = lang.Volatile_Cast(A_arbace_go_check_env_A_const_25.Get__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_80.GetRawRoot__O()); var tmp3 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_25.Get__O())).Deref__O(); var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_env_A_const_81, k__0); var tmp5 any; var root_524 any = A_arbace_go_check_env_A_const_82.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = A_arbace_go_check_env_A_const_83.GetRawRoot__O(); var arg_528 any = A_arbace_go_check_env_A_const_38; if linked_525 == nil { tmp5 = ifn_526.Invoke_O_O__O(arg_527, arg_528) } else { tmp5 = linked_525.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_524, arg_527, arg_528) }; return jrt.NN(tmp1).Reset_O__O(tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5)) } else { return nil
	}
}







func A_arbace_go_check_env_annotation_error_BANG__A_New() *A_arbace_go_check_env_annotation_error_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_annotation_error_BANG__A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_go_check_env_annotation_error_BANG__A) Ctor() {}
//line :184:1
func (t *A_arbace_go_check_env_annotation_error_BANG__A) Invoke_O_O_O_O_O_O__O(self, f__0, a__1, what__2, forms_say__3, checker_says__4 any) any {


	return lang.IFn_Cast(A_arbace_go_check_env_A_const_84.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(f__0, A_arbace_go_check_env_A_const_85, Lit_1, a__1, what__2, forms_say__3, checker_says__4)
}










func A_arbace_go_check_env_at_of_A_New() *A_arbace_go_check_env_at_of_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_at_of_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_go_check_env_at_of_A) Ctor() {}
//line :199:1
func (t *A_arbace_go_check_env_at_of_A) Invoke_O_O__O(self, f__0 any) any {


	if lang.IMeta_InstanceOf(f__0) { var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_86; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__0)) } else { return nil
	} }
func A_arbace_go_check_env_answer_BANG__A_New() *A_arbace_go_check_env_answer_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_answer_BANG__A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_go_check_env_answer_BANG__A) Ctor() {}
//line :204:1
func (t *A_arbace_go_check_env_answer_BANG__A) Invoke_O_O_O_O__O(self, f__0, k__1, m__2 any) any { var temp__1927000414__auto____4 any = A_arbace_go_check_env_A_const_87.Get__O(); if







	jrt.J2g_Truth(temp__1927000414__auto____4) { var a__5 any = temp__1927000414__auto____4; var temp__1927000414__auto____6 any; var root_539 any = A_arbace_go_check_env_A_const_88.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, A_arbace_go_check_env_at_of_A_fn_class); var ifn_541 lang.IFn
		if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = f__0; if linked_540 == nil { temp__1927000414__auto____6 = ifn_541.Invoke_O__O(arg_542) } else { temp__1927000414__auto____6 = linked_540.(*A_arbace_go_check_env_at_of_A).Invoke_O_O__O(root_539, arg_542) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var vec__1719000055__7 any = temp__1927000414__auto____6; var file__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000055__7, lang.RT_IntCast_J__I_NoInit(0), nil); var pm__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1719000055__7, lang.RT_IntCast_J__I_NoInit(1), nil); var temp__1927000414__auto____10 any = lang.RT_Get_O_O__O_NoInit(pm__9, k__1)
			if jrt.J2g_Truth(temp__1927000414__auto____10) { var p__11 any = temp__1927000414__auto____10; var at__12 any; var tmp1 any
				if lang.Util_Equiv_O_O__Z_NoInit(k__1, A_arbace_go_check_env_A_const_90) { tmp1 = A_arbace_go_check_env_A_const_91 } else { tmp1 = k__1 }
//line :214:1
				at__12 = lang.Tuple_Create_O_O__IPersistentVector(file__8, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, p__11)))

				var tmp2 jrt.HashMap_I = jrt.HashMap_Cast(a__5); var tmp3 any; var root_543 any = A_arbace_go_check_env_A_const_89.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = jrt.HashMap_Cast(a__5).Get_O__O(at__12); var arg_547 any = m__2; if linked_544 == nil { tmp3 = ifn_545.Invoke_O_O__O(arg_546, arg_547) } else { tmp3 = linked_544.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_543, arg_546, arg_547) }; return tmp2.Put_O_O__O(at__12, tmp3) } else {
//line :214:1
					return nil } } else {
//line :213:1
						return nil } } else {
//line :212:1
							return nil } }
//line :204:1
func (t *A_arbace_go_check_env_answer_BANG__A) Invoke_O_O_O__O(self, f__0, m__1 any) any { var temp__1927000414__auto____3 any = A_arbace_go_check_env_A_const_87.Get__O(); if



	jrt.J2g_Truth(temp__1927000414__auto____3) { var a__4 any = temp__1927000414__auto____3; var temp__1927000414__auto____5 any; var root_548 any = A_arbace_go_check_env_A_const_88.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, A_arbace_go_check_env_at_of_A_fn_class); var ifn_550 lang.IFn
		if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = f__0; if linked_549 == nil { temp__1927000414__auto____5 = ifn_550.Invoke_O__O(arg_551) } else { temp__1927000414__auto____5 = linked_549.(*A_arbace_go_check_env_at_of_A).Invoke_O_O__O(root_548, arg_551) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var at__6 any = temp__1927000414__auto____5; var tmp1 jrt.HashMap_I = jrt.HashMap_Cast(a__4); var tmp2 any; var root_552 any = A_arbace_go_check_env_A_const_89.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_554 lang.IFn
			if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = jrt.HashMap_Cast(a__4).Get_O__O(at__6); var arg_556 any = m__1; if linked_553 == nil { tmp2 = ifn_554.Invoke_O_O__O(arg_555, arg_556) } else { tmp2 = linked_553.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_552, arg_555, arg_556) }; return tmp1.Put_O_O__O(at__6, tmp2) } else {
//line :209:1
				return nil } } else {
//line :208:1
					return nil } }









func A_arbace_go_check_env_unanswer_BANG__A_New() *A_arbace_go_check_env_unanswer_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_unanswer_BANG__A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_go_check_env_unanswer_BANG__A) Ctor() {}
//line :218:1
func (t *A_arbace_go_check_env_unanswer_BANG__A) Invoke_O_O_O__O(self, f__0, ks__1 any) any { var temp__1927000414__auto____3 any = A_arbace_go_check_env_A_const_87.Get__O(); if


	jrt.J2g_Truth(temp__1927000414__auto____3) { var a__4 any = temp__1927000414__auto____3; var temp__1927000414__auto____5 any; var root_557 any = A_arbace_go_check_env_A_const_88.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, A_arbace_go_check_env_at_of_A_fn_class); var ifn_559 lang.IFn
		if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = f__0; if linked_558 == nil { temp__1927000414__auto____5 = ifn_559.Invoke_O__O(arg_560) } else { temp__1927000414__auto____5 = linked_558.(*A_arbace_go_check_env_at_of_A).Invoke_O_O__O(root_557, arg_560) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var at__6 any = temp__1927000414__auto____5; var temp__1927000414__auto____7 any = jrt.HashMap_Cast(a__4).Get_O__O(at__6)
			if jrt.J2g_Truth(temp__1927000414__auto____7) { var m__8 any = temp__1927000414__auto____7; var tmp1 jrt.HashMap_I = jrt.HashMap_Cast(a__4); var tmp2 any; var root_561 any = A_arbace_go_check_env_A_const_56.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_563 lang.IFn
				if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = A_arbace_go_check_env_A_const_92.GetRawRoot__O(); var arg_565 any = m__8; var arg_566 any = ks__1; if linked_562 == nil { tmp2 = ifn_563.Invoke_O_O_O__O(arg_564, arg_565, arg_566) } else { tmp2 = linked_562.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_561, arg_564, arg_565, arg_566) }; return tmp1.Put_O_O__O(at__6, tmp2) } else {
//line :223:1
					return nil } } else {
//line :222:1
						return nil } } else {
//line :221:1
							return nil } }








func A_arbace_go_check_env_def_type_BANG__A_New() *A_arbace_go_check_env_def_type_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_def_type_BANG__A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_go_check_env_def_type_BANG__A) Ctor() {}
//line :230:1
func (t *A_arbace_go_check_env_def_type_BANG__A) Invoke_O_O_O__O(self, n__0, kw__1 any) any {
	var root_567 any = A_arbace_go_check_env_A_const_93.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = A_arbace_go_check_env_A_const_94.GetRawRoot__O(); var arg_571 any = n__0; var arg_572 any; var root_573 any = A_arbace_go_check_env_A_const_95.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, A_arbace_go_check_env_obj_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any; var G__1719000060__3_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env_A_const_15, A_arbace_go_check_env_A_const_96, A_arbace_go_check_env_A_const_29, n__0, A_arbace_go_check_env_A_const_96, kw__1, A_arbace_go_check_env_A_const_97, jrt.Boolean_TRUE.Ref())); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_go_check_env_A_const_98).Invoke_O__O(n__0)) {

		var root_577 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_579 lang.IFn; if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = G__1719000060__3_; var arg_581 any = A_arbace_go_check_env_A_const_99; var arg_582 any; var root_583 any = A_arbace_go_check_env_A_const_100.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = n__0; if linked_584 == nil { arg_582 = ifn_585.Invoke_O__O(arg_586) } else { arg_582 = linked_584.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_583, arg_586) }; if linked_578 == nil { arg_576 = ifn_579.Invoke_O_O_O__O(arg_580, arg_581, arg_582) } else { arg_576 = linked_578.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_577, arg_580, arg_581, arg_582) } } else {
//line :231:1
			arg_576 = G__1719000060__3_ }; if linked_574 == nil { arg_572 = ifn_575.Invoke_O__O(arg_576) } else { arg_572 = linked_574.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_573, arg_576) }; if linked_568 == nil { return ifn_569.Invoke_O_O_O__O(arg_570, arg_571, arg_572) } else { return linked_568.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_567, arg_570, arg_571, arg_572)
			}
}









func A_arbace_go_check_env_fn__1719000074_A_New() *A_arbace_go_check_env_fn__1719000074_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_fn__1719000074_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_go_check_env_fn__1719000074_A) Ctor() {}
//line :243:1
func (t *A_arbace_go_check_env_fn__1719000074_A) Invoke_O__O(self any) any { var nt__1 any; var root_587 any = A_arbace_go_check_env_A_const_101.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_go_check_types.A_arbace_go_check_types_new_named_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = A_arbace_go_check_env_A_const_102; if linked_588 == nil { nt__1 = ifn_589.Invoke_O__O(arg_590) } else { nt__1 = linked_588.(*aot_arbace_go_check_types.A_arbace_go_check_types_new_named_A).Invoke_O_O__O(root_587, arg_590) }; var tmp1 lang.IFn =
										lang.IFn_Cast(A_arbace_go_check_env_A_const_103.GetRawRoot__O()); var tmp2 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var tmp3 any = A_arbace_go_check_env_A_const_104; var tmp4 any = A_arbace_go_check_env_A_const_105; var tmp5 any = A_arbace_go_check_env_A_const_29; var tmp6 any = A_arbace_go_check_env_A_const_106; var tmp7 any = A_arbace_go_check_env_A_const_96; tmp1.Invoke_O_O_O_O__O(nt__1, tmp2, tmp3, lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, Lit_8, tmp6, nil, tmp7, lang.Tuple_Create_O_O_O_O__IPersistentVector(A_arbace_go_check_env_A_const_107, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_env_A_const_108, jrt.Boolean_FALSE.Ref())))), nil)); return nt__1 }







func A_arbace_go_check_env_fn__1719000080_A_New() *A_arbace_go_check_env_fn__1719000080_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_fn__1719000080_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_go_check_env_fn__1719000080_A) Ctor() {}
//line :252:1
func (t *A_arbace_go_check_env_fn__1719000080_A) Invoke_O__O(self any) any { var nt__1 any; var root_598 any = A_arbace_go_check_env_A_const_101.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_go_check_types.A_arbace_go_check_types_new_named_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = A_arbace_go_check_env_A_const_109; if linked_599 == nil { nt__1 = ifn_600.Invoke_O__O(arg_601) } else { nt__1 = linked_599.(*aot_arbace_go_check_types.A_arbace_go_check_types_new_named_A).Invoke_O_O__O(root_598, arg_601) }; var tmp1 lang.IFn =
										lang.IFn_Cast(A_arbace_go_check_env_A_const_103.GetRawRoot__O()); var tmp2 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var tmp3 any = A_arbace_go_check_env_A_const_104; var tmp4 any = A_arbace_go_check_env_A_const_105; var tmp5 any = lang.PersistentVector_EMPTY.Ref(); var tmp6 any; var root_609 any = A_arbace_go_check_env_A_const_110.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_go_check_types.A_arbace_go_check_types_make_tset_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = A_arbace_go_check_env_A_const_111; var arg_613 any = jrt.Boolean_TRUE.Ref(); if linked_610 == nil { tmp6 = ifn_611.Invoke_O_O__O(arg_612, arg_613) } else { tmp6 = linked_610.(*aot_arbace_go_check_types.A_arbace_go_check_types_make_tset_A).Invoke_O_O_O__O(root_609, arg_612, arg_613) }; tmp1.Invoke_O_O_O_O__O(nt__1, tmp2, tmp3, lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, tmp5, tmp6)); return nt__1 }



















func A_arbace_go_check_env_fn__1719000098_A_New() *A_arbace_go_check_env_fn__1719000098_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_fn__1719000098_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_go_check_env_fn__1719000098_A) Ctor() {}
//line :273:1
func (t *A_arbace_go_check_env_fn__1719000098_A) Invoke_O__O(self any) any { var s__1 any; var root_614 any = A_arbace_go_check_env_A_const_112.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, A_arbace_go_check_env_scope_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any; var arg_618 any = A_arbace_go_check_env_A_const_113; if linked_615 == nil { s__1 = ifn_616.Invoke_O_O__O(arg_617, arg_618) } else { s__1 = linked_615.(*A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_614, arg_617, arg_618) }; var root_619 any =
										A_arbace_go_check_env_A_const_93.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = s__1; var arg_623 any = Lit_9; var arg_624 any; var root_625 any = A_arbace_go_check_env_A_const_95.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, A_arbace_go_check_env_obj_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = A_arbace_go_check_env_A_const_114; if linked_626 == nil { arg_624 = ifn_627.Invoke_O__O(arg_628) } else { arg_624 = linked_626.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_625, arg_628) }; if linked_620 == nil { ifn_621.Invoke_O_O_O__O(arg_622, arg_623, arg_624) } else { linked_620.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_619, arg_622, arg_623, arg_624) }; var seq_1719000099__2 any; var root_629 any = /*line :273:1*/A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_631 lang.IFn; if

	linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = A_arbace_go_check_env_A_const_115; if linked_630 == nil { seq_1719000099__2 = ifn_631.Invoke_O__O(arg_632) } else { seq_1719000099__2 = linked_630.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_629, arg_632) }; var chunk_1719000100__3 any; var count_1719000101__4 int64 = 0; var i_1719000102__5 int64 = 0; L1:
//line :273:1
	for {

		if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000102__5, count_1719000101__4) { var n__6 any = lang.Indexed_Cast(chunk_1719000100__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000102__5)); var root_649 any = A_arbace_go_check_env_A_const_93.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_651 lang.IFn
			if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = s__1; var arg_653 any = n__6; var arg_654 any; var root_655 any = A_arbace_go_check_env_A_const_95.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, A_arbace_go_check_env_obj_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env_A_const_15, A_arbace_go_check_env_A_const_116, A_arbace_go_check_env_A_const_29, n__6, A_arbace_go_check_env_A_const_117, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_env_A_const_106, Lit_10)); if linked_656 == nil { arg_654 = ifn_657.Invoke_O__O(arg_658) } else { arg_654 = linked_656.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_655, arg_658) }; if linked_650 == nil { ifn_651.Invoke_O_O_O__O(arg_652, arg_653, arg_654) } else { linked_650.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_649, arg_652, arg_653, arg_654) }
//line :275:1
			seq_1719000099__2, chunk_1719000100__3, count_1719000101__4, i_1719000102__5 = seq_1719000099__2, chunk_1719000100__3, count_1719000101__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000102__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_633 any = A_arbace_go_check_env_A_const_18.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = seq_1719000099__2; if linked_634 == nil { temp__1927000414__auto____6 = ifn_635.Invoke_O__O(arg_636) } else { temp__1927000414__auto____6 = linked_634.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_633, arg_636) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1719000099__7 any = temp__1927000414__auto____6; var tmp1 any; var root_637 any = A_arbace_go_check_env_A_const_41.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = seq_1719000099__7; if linked_638 == nil { tmp1 = ifn_639.Invoke_O__O(arg_640) } else { tmp1 = linked_638.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_637, arg_640) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____8 any; var root_641 any = A_arbace_go_check_env_A_const_42.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_641, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_643 lang.IFn; if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = seq_1719000099__7; if linked_642 == nil { c__1927000678__auto____8 = ifn_643.Invoke_O__O(arg_644) } else { c__1927000678__auto____8 = linked_642.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_641, arg_644) }; var tmp2 any; var root_659 any = A_arbace_go_check_env_A_const_47.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = seq_1719000099__7; if linked_660 == nil { tmp2 = ifn_661.Invoke_O__O(arg_662) } else { tmp2 = linked_660.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_659, arg_662) }; seq_1719000099__2, chunk_1719000100__3, count_1719000101__4, i_1719000102__5 = tmp2, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_645 any = A_arbace_go_check_env_A_const_48.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = seq_1719000099__7; if linked_646 == nil { n__8 = ifn_647.Invoke_O__O(arg_648) } else { n__8 = linked_646.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_645, arg_648) }
				var root_663 any = A_arbace_go_check_env_A_const_93.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = s__1; var arg_667 any = n__8; var arg_668 any; var root_669 any = A_arbace_go_check_env_A_const_95.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, A_arbace_go_check_env_obj_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env_A_const_15, A_arbace_go_check_env_A_const_116, A_arbace_go_check_env_A_const_29, n__8, A_arbace_go_check_env_A_const_117, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_env_A_const_106, Lit_10)); if linked_670 == nil { arg_668 = ifn_671.Invoke_O__O(arg_672) } else { arg_668 = linked_670.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_669, arg_672) }; if linked_664 == nil { ifn_665.Invoke_O_O_O__O(arg_666, arg_667, arg_668) } else { linked_664.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_663, arg_666, arg_667, arg_668) }
//line :275:1
				var tmp3 any; var root_673 any = A_arbace_go_check_env_A_const_118.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_673, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_675 lang.IFn; if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any = seq_1719000099__7; if linked_674 == nil { tmp3 = ifn_675.Invoke_O__O(arg_676) } else { tmp3 = linked_674.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_673, arg_676) }; seq_1719000099__2, chunk_1719000100__3, count_1719000101__4, i_1719000102__5 = tmp3, nil, 0, 0; continue L1 } } }
//line :273:1
		break L1 }; return s__1 }







type A_arbace_go_check_env_A struct{ jrt.Object }

var A_arbace_go_check_env_A_const_pool *jrt.RefArray

var A_arbace_go_check_env_A_const_0 *lang.Var

var A_arbace_go_check_env_A_const_1 any

var A_arbace_go_check_env_A_const_2 any

var A_arbace_go_check_env_A_const_3 any

var A_arbace_go_check_env_A_const_4 *lang.Var

var A_arbace_go_check_env_A_const_5 any

var A_arbace_go_check_env_A_const_6 *lang.Var

var A_arbace_go_check_env_A_const_7 *lang.Var

var A_arbace_go_check_env_A_const_8 *lang.Var

var A_arbace_go_check_env_A_const_9 *lang.Var

var A_arbace_go_check_env_A_const_10 any

var A_arbace_go_check_env_A_const_11 *lang.Var

var A_arbace_go_check_env_A_const_12 *lang.Var

var A_arbace_go_check_env_A_const_13 *lang.Keyword

var A_arbace_go_check_env_A_const_14 *lang.Keyword

var A_arbace_go_check_env_A_const_15 *lang.Keyword

var A_arbace_go_check_env_A_const_16 *lang.Var

var A_arbace_go_check_env_A_const_17 *lang.Var

var A_arbace_go_check_env_A_const_18 *lang.Var

var A_arbace_go_check_env_A_const_19 *lang.Var

var A_arbace_go_check_env_A_const_20 *lang.Keyword

var A_arbace_go_check_env_A_const_21 *lang.Keyword

var A_arbace_go_check_env_A_const_22 *lang.Keyword

var A_arbace_go_check_env_A_const_23 *lang.Keyword

var A_arbace_go_check_env_A_const_24 *lang.Keyword

var A_arbace_go_check_env_A_const_25 *lang.Var

var A_arbace_go_check_env_A_const_26 *lang.Var

var A_arbace_go_check_env_A_const_27 *lang.Keyword

var A_arbace_go_check_env_A_const_28 *lang.Var

var A_arbace_go_check_env_A_const_29 *lang.Keyword

var A_arbace_go_check_env_A_const_30 *lang.Var

var A_arbace_go_check_env_A_const_31 *lang.Var

var A_arbace_go_check_env_A_const_32 *lang.Var

var A_arbace_go_check_env_A_const_33 *lang.Var

var A_arbace_go_check_env_A_const_34 *lang.Var

var A_arbace_go_check_env_A_const_35 *lang.Var

var A_arbace_go_check_env_A_const_36 *lang.Var

var A_arbace_go_check_env_A_const_37 *lang.Keyword

var A_arbace_go_check_env_A_const_38 any

var A_arbace_go_check_env_A_const_39 *lang.Var

var A_arbace_go_check_env_A_const_40 *lang.Var

var A_arbace_go_check_env_A_const_41 *lang.Var

var A_arbace_go_check_env_A_const_42 *lang.Var

var A_arbace_go_check_env_A_const_43 *lang.Var

var A_arbace_go_check_env_A_const_44 *lang.Var

var A_arbace_go_check_env_A_const_45 *lang.Var

var A_arbace_go_check_env_A_const_46 *lang.Var

var A_arbace_go_check_env_A_const_47 *lang.Var

var A_arbace_go_check_env_A_const_48 *lang.Var

var A_arbace_go_check_env_A_const_49 *lang.Var

var A_arbace_go_check_env_A_const_50 *lang.Var

var A_arbace_go_check_env_A_const_51 *lang.Keyword

var A_arbace_go_check_env_A_const_52 *lang.Var

var A_arbace_go_check_env_A_const_53 *lang.Var

var A_arbace_go_check_env_A_const_54 *lang.Var

var A_arbace_go_check_env_A_const_55 any

var A_arbace_go_check_env_A_const_56 *lang.Var

var A_arbace_go_check_env_A_const_57 *lang.Var

var A_arbace_go_check_env_A_const_58 any

var A_arbace_go_check_env_A_const_59 any

var A_arbace_go_check_env_A_const_60 any

var A_arbace_go_check_env_A_const_61 any

var A_arbace_go_check_env_A_const_62 any

var A_arbace_go_check_env_A_const_63 any

var A_arbace_go_check_env_A_const_64 any

var A_arbace_go_check_env_A_const_65 any

var A_arbace_go_check_env_A_const_66 any

var A_arbace_go_check_env_A_const_67 *lang.Var

var A_arbace_go_check_env_A_const_68 *lang.Var

var A_arbace_go_check_env_A_const_69 *lang.Var

var A_arbace_go_check_env_A_const_70 *lang.Var

var A_arbace_go_check_env_A_const_71 *lang.Keyword

var A_arbace_go_check_env_A_const_72 *lang.Var

var A_arbace_go_check_env_A_const_73 *lang.Keyword

var A_arbace_go_check_env_A_const_74 *lang.Keyword

var A_arbace_go_check_env_A_const_75 *lang.Keyword

var A_arbace_go_check_env_A_const_76 *lang.Var

var A_arbace_go_check_env_A_const_77 *lang.Var

var A_arbace_go_check_env_A_const_78 *lang.Keyword

var A_arbace_go_check_env_A_const_79 *lang.Var

var A_arbace_go_check_env_A_const_80 *lang.Var

var A_arbace_go_check_env_A_const_81 *lang.Keyword

var A_arbace_go_check_env_A_const_82 *lang.Var

var A_arbace_go_check_env_A_const_83 *lang.Var

var A_arbace_go_check_env_A_const_84 *lang.Var

var A_arbace_go_check_env_A_const_85 *lang.Keyword

var A_arbace_go_check_env_A_const_86 *lang.Keyword

var A_arbace_go_check_env_A_const_87 *lang.Var

var A_arbace_go_check_env_A_const_88 *lang.Var

var A_arbace_go_check_env_A_const_89 *lang.Var

var A_arbace_go_check_env_A_const_90 *lang.Keyword

var A_arbace_go_check_env_A_const_91 *lang.Keyword

var A_arbace_go_check_env_A_const_92 *lang.Var

var A_arbace_go_check_env_A_const_93 *lang.Var

var A_arbace_go_check_env_A_const_94 *lang.Var

var A_arbace_go_check_env_A_const_95 *lang.Var

var A_arbace_go_check_env_A_const_96 *lang.Keyword

var A_arbace_go_check_env_A_const_97 *lang.Keyword

var A_arbace_go_check_env_A_const_98 any

var A_arbace_go_check_env_A_const_99 *lang.Keyword

var A_arbace_go_check_env_A_const_100 *lang.Var

var A_arbace_go_check_env_A_const_101 *lang.Var

var A_arbace_go_check_env_A_const_102 any

var A_arbace_go_check_env_A_const_103 *lang.Var

var A_arbace_go_check_env_A_const_104 *lang.Keyword

var A_arbace_go_check_env_A_const_105 *lang.Keyword

var A_arbace_go_check_env_A_const_106 *lang.Keyword

var A_arbace_go_check_env_A_const_107 *lang.Keyword

var A_arbace_go_check_env_A_const_108 any

var A_arbace_go_check_env_A_const_109 any

var A_arbace_go_check_env_A_const_110 *lang.Var

var A_arbace_go_check_env_A_const_111 *lang.Keyword

var A_arbace_go_check_env_A_const_112 *lang.Var

var A_arbace_go_check_env_A_const_113 *lang.Keyword

var A_arbace_go_check_env_A_const_114 any

var A_arbace_go_check_env_A_const_115 any

var A_arbace_go_check_env_A_const_116 *lang.Keyword

var A_arbace_go_check_env_A_const_117 *lang.Keyword

var A_arbace_go_check_env_A_const_118 *lang.Var

var A_arbace_go_check_env_A_init jrt.ClassInit

func A_arbace_go_check_env_A_Init() { if !A_arbace_go_check_env_A_init.Done() { A_arbace_go_check_env_A_init.Run(A_arbace_go_check_env_A_clinit) } }

func A_arbace_go_check_env_A_clinit() { A_arbace_go_check_env_A_clinit_p0(); A_arbace_go_check_env_A_clinit_p1(); A_arbace_go_check_env_A_clinit_p2(); A_arbace_go_check_env_A_clinit_p3(); A_arbace_go_check_env_A_clinit_p4(); A_arbace_go_check_env_A_clinit_p5(); A_arbace_go_check_env_A_clinit_p6(); A_arbace_go_check_env_A_clinit_p7(); A_arbace_go_check_env_A_clinit_p8(); A_arbace_go_check_env_A_clinit_p9() }

func A_arbace_go_check_env_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_env_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 174); A_arbace_go_check_env_A_const_0 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[55]); A_arbace_go_check_env_A_const_1 = A_arbace_go_check_env_A_const_pool.A[56]; A_arbace_go_check_env_A_const_2 = A_arbace_go_check_env_A_const_pool.A[57]; A_arbace_go_check_env_A_const_3 = A_arbace_go_check_env_A_const_pool.A[58]; A_arbace_go_check_env_A_const_4 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[59]); A_arbace_go_check_env_A_const_5 = A_arbace_go_check_env_A_const_pool.A[60]; A_arbace_go_check_env_A_const_6 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[61]); A_arbace_go_check_env_A_const_7 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[62]); A_arbace_go_check_env_A_const_8 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[63]); A_arbace_go_check_env_A_const_9 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[64]); A_arbace_go_check_env_A_const_10 = A_arbace_go_check_env_A_const_pool.A[65]; A_arbace_go_check_env_A_const_11 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[66]) }

func A_arbace_go_check_env_A_clinit_p1() { A_arbace_go_check_env_A_const_12 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[67]); A_arbace_go_check_env_A_const_13 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[68]); A_arbace_go_check_env_A_const_14 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[69]); A_arbace_go_check_env_A_const_15 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[70]); A_arbace_go_check_env_A_const_16 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[71]); A_arbace_go_check_env_A_const_17 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[72]); A_arbace_go_check_env_A_const_18 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[73]); A_arbace_go_check_env_A_const_19 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[74]); A_arbace_go_check_env_A_const_20 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[75]); A_arbace_go_check_env_A_const_21 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[76]); A_arbace_go_check_env_A_const_22 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[77]); A_arbace_go_check_env_A_const_23 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[78]) }

func A_arbace_go_check_env_A_clinit_p2() { A_arbace_go_check_env_A_const_24 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[79]); A_arbace_go_check_env_A_const_25 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[80]); A_arbace_go_check_env_A_const_26 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[81]); A_arbace_go_check_env_A_const_27 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[82]); A_arbace_go_check_env_A_const_28 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[83]); A_arbace_go_check_env_A_const_29 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[84]); A_arbace_go_check_env_A_const_30 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[85]); A_arbace_go_check_env_A_const_31 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[86]); A_arbace_go_check_env_A_const_32 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[87]); A_arbace_go_check_env_A_const_33 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[88]); A_arbace_go_check_env_A_const_34 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[89]); A_arbace_go_check_env_A_const_35 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[90]) }

func A_arbace_go_check_env_A_clinit_p3() { A_arbace_go_check_env_A_const_36 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[91]); A_arbace_go_check_env_A_const_37 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[92]); A_arbace_go_check_env_A_const_38 = A_arbace_go_check_env_A_const_pool.A[93]; A_arbace_go_check_env_A_const_39 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[94]); A_arbace_go_check_env_A_const_40 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[95]); A_arbace_go_check_env_A_const_41 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[96]); A_arbace_go_check_env_A_const_42 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[97]); A_arbace_go_check_env_A_const_43 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[98]); A_arbace_go_check_env_A_const_44 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[99]); A_arbace_go_check_env_A_const_45 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[100]); A_arbace_go_check_env_A_const_46 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[101]); A_arbace_go_check_env_A_const_47 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[102]) }

func A_arbace_go_check_env_A_clinit_p4() { A_arbace_go_check_env_A_const_48 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[103]); A_arbace_go_check_env_A_const_49 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[104]); A_arbace_go_check_env_A_const_50 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[105]); A_arbace_go_check_env_A_const_51 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[106]); A_arbace_go_check_env_A_const_52 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[107]); A_arbace_go_check_env_A_const_53 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[108]); A_arbace_go_check_env_A_const_54 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[109]); A_arbace_go_check_env_A_const_55 = A_arbace_go_check_env_A_const_pool.A[110]; A_arbace_go_check_env_A_const_56 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[111]); A_arbace_go_check_env_A_const_57 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[112]); A_arbace_go_check_env_A_const_58 = A_arbace_go_check_env_A_const_pool.A[113]; A_arbace_go_check_env_A_const_59 = A_arbace_go_check_env_A_const_pool.A[114]; A_arbace_go_check_env_A_const_60 = A_arbace_go_check_env_A_const_pool.A[115] }

func A_arbace_go_check_env_A_clinit_p5() { A_arbace_go_check_env_A_const_61 = A_arbace_go_check_env_A_const_pool.A[116]; A_arbace_go_check_env_A_const_62 = A_arbace_go_check_env_A_const_pool.A[117]; A_arbace_go_check_env_A_const_63 = A_arbace_go_check_env_A_const_pool.A[118]; A_arbace_go_check_env_A_const_64 = A_arbace_go_check_env_A_const_pool.A[119]; A_arbace_go_check_env_A_const_65 = A_arbace_go_check_env_A_const_pool.A[120]; A_arbace_go_check_env_A_const_66 = A_arbace_go_check_env_A_const_pool.A[121]; A_arbace_go_check_env_A_const_67 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[122]); A_arbace_go_check_env_A_const_68 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[123]); A_arbace_go_check_env_A_const_69 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[124]); A_arbace_go_check_env_A_const_70 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[125]); A_arbace_go_check_env_A_const_71 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[126]); A_arbace_go_check_env_A_const_72 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[127]); A_arbace_go_check_env_A_const_73 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[128]) }

func A_arbace_go_check_env_A_clinit_p6() { A_arbace_go_check_env_A_const_74 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[129]); A_arbace_go_check_env_A_const_75 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[130]); A_arbace_go_check_env_A_const_76 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[131]); A_arbace_go_check_env_A_const_77 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[132]); A_arbace_go_check_env_A_const_78 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[133]); A_arbace_go_check_env_A_const_79 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[134]); A_arbace_go_check_env_A_const_80 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[135]); A_arbace_go_check_env_A_const_81 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[136]); A_arbace_go_check_env_A_const_82 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[137]); A_arbace_go_check_env_A_const_83 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[138]); A_arbace_go_check_env_A_const_84 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[139]); A_arbace_go_check_env_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[140]) }

func A_arbace_go_check_env_A_clinit_p7() { A_arbace_go_check_env_A_const_86 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[141]); A_arbace_go_check_env_A_const_87 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[142]); A_arbace_go_check_env_A_const_88 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[143]); A_arbace_go_check_env_A_const_89 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[144]); A_arbace_go_check_env_A_const_90 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[145]); A_arbace_go_check_env_A_const_91 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[146]); A_arbace_go_check_env_A_const_92 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[147]); A_arbace_go_check_env_A_const_93 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[148]); A_arbace_go_check_env_A_const_94 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[149]); A_arbace_go_check_env_A_const_95 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[150]); A_arbace_go_check_env_A_const_96 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[151]); A_arbace_go_check_env_A_const_97 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[152]) }

func A_arbace_go_check_env_A_clinit_p8() { A_arbace_go_check_env_A_const_98 = A_arbace_go_check_env_A_const_pool.A[153]; A_arbace_go_check_env_A_const_99 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[154]); A_arbace_go_check_env_A_const_100 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[155]); A_arbace_go_check_env_A_const_101 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[156]); A_arbace_go_check_env_A_const_102 = A_arbace_go_check_env_A_const_pool.A[157]; A_arbace_go_check_env_A_const_103 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[158]); A_arbace_go_check_env_A_const_104 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[159]); A_arbace_go_check_env_A_const_105 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[160]); A_arbace_go_check_env_A_const_106 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[161]); A_arbace_go_check_env_A_const_107 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[162]); A_arbace_go_check_env_A_const_108 = A_arbace_go_check_env_A_const_pool.A[163]; A_arbace_go_check_env_A_const_109 = A_arbace_go_check_env_A_const_pool.A[164]; A_arbace_go_check_env_A_const_110 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[165]) }

func A_arbace_go_check_env_A_clinit_p9() { A_arbace_go_check_env_A_const_111 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[166]); A_arbace_go_check_env_A_const_112 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[167]); A_arbace_go_check_env_A_const_113 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[168]); A_arbace_go_check_env_A_const_114 = A_arbace_go_check_env_A_const_pool.A[169]; A_arbace_go_check_env_A_const_115 = A_arbace_go_check_env_A_const_pool.A[170]; A_arbace_go_check_env_A_const_116 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[171]); A_arbace_go_check_env_A_const_117 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[172]); A_arbace_go_check_env_A_const_118 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[173]) }

func A_arbace_go_check_env_A_New() *A_arbace_go_check_env_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env_A) Ctor() {}

func (t *A_arbace_go_check_env_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env_A_class }

func (t *A_arbace_go_check_env_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env_A); return ok }

func A_arbace_go_check_env_A_Cast(x any) *A_arbace_go_check_env_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env_A_class)) }; return v }



type A_arbace_go_check_env_annotation_error_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_annotation_error_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_answer_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_answer_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_at_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_at_of_A_fn_class *jrt.Class



type A_arbace_go_check_env_child_line_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_child_line_A_fn_class *jrt.Class



type A_arbace_go_check_env_child_line_fn__1719000033_A struct{ j2g_header uint64; F_f, F_i any }

var A_arbace_go_check_env_child_line_fn__1719000033_A_fn_class *jrt.Class



type A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_child_line_iter__1719000023__1719000027_A_fn_class *jrt.Class



type A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A struct{ j2g_header uint64; F_s__1719000024, F_iter__1719000023 any }

var A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_A_fn_class *jrt.Class



type A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A struct{ j2g_header uint64; F_b__1719000026 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_env_child_line_iter__1719000023__1719000027_fn__1719000028_fn__1719000029_A_fn_class *jrt.Class



type A_arbace_go_check_env_current_line_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_current_line_A_fn_class *jrt.Class



type A_arbace_go_check_env_def_type_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_def_type_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_end_line_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_end_line_A_fn_class *jrt.Class



type A_arbace_go_check_env_err_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_err_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_error_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_error_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_eval1719000004_A struct{ jrt.Object }

func A_arbace_go_check_env_eval1719000004_A_New() *A_arbace_go_check_env_eval1719000004_A { t := &A_arbace_go_check_env_eval1719000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env_eval1719000004_A) Ctor() {}

func (t *A_arbace_go_check_env_eval1719000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env_eval1719000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env_eval1719000004_A_class }

func (t *A_arbace_go_check_env_eval1719000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env_eval1719000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env_eval1719000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env_eval1719000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env_eval1719000004_A); return ok }

func A_arbace_go_check_env_eval1719000004_A_Cast(x any) *A_arbace_go_check_env_eval1719000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env_eval1719000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env_eval1719000004_A_class)) }; return v }



type A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class *jrt.Class



type A_arbace_go_check_env_eval1719000008_A struct{ jrt.Object }

func A_arbace_go_check_env_eval1719000008_A_New() *A_arbace_go_check_env_eval1719000008_A { t := &A_arbace_go_check_env_eval1719000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env_eval1719000008_A) Ctor() {}

func (t *A_arbace_go_check_env_eval1719000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env_eval1719000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env_eval1719000008_A_class }

func (t *A_arbace_go_check_env_eval1719000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env_eval1719000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env_eval1719000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env_eval1719000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env_eval1719000008_A); return ok }

func A_arbace_go_check_env_eval1719000008_A_Cast(x any) *A_arbace_go_check_env_eval1719000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env_eval1719000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env_eval1719000008_A_class)) }; return v }



type A_arbace_go_check_env_eval1719000008_fn__1719000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class *jrt.Class



type A_arbace_go_check_env_fn__1719000074_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_fn__1719000074_A_fn_class *jrt.Class



type A_arbace_go_check_env_fn__1719000080_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_fn__1719000080_A_fn_class *jrt.Class



type A_arbace_go_check_env_fn__1719000098_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_fn__1719000098_A_fn_class *jrt.Class



type A_arbace_go_check_env_generic_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_generic_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_line_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_line_of_A_fn_class *jrt.Class



type A_arbace_go_check_env_o_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_o_A_fn_class *jrt.Class



type A_arbace_go_check_env_obj_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_obj_A_fn_class *jrt.Class



type A_arbace_go_check_env_obj_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_obj_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_env_oset_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_oset_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_scope_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_scope_A_fn_class *jrt.Class



type A_arbace_go_check_env_scope_get_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_scope_get_A_fn_class *jrt.Class



type A_arbace_go_check_env_scope_lookup_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_scope_lookup_A_fn_class *jrt.Class



type A_arbace_go_check_env_scope_put_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_scope_put_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_unanswer_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_unanswer_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_unsupported_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_unsupported_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_unsupported_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_unsupported_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_env_verified_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_verified_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_with_child_line_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_with_child_line_A_fn_class *jrt.Class
