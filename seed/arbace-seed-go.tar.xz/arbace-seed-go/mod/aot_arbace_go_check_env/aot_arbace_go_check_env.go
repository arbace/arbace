//line aot_arbace_go_check_env.ae:1
package aot_arbace_go_check_env

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_types"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_New() *A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_env_A_const_4.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_env_A_const_5); tmp2 = lang.IFn_Cast(A_arbace_go_check_env_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_go_check_env_A_const_1, A_arbace_go_check_env_A_const_2, A_arbace_go_check_env_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_env_eval1719000008_fn__1719000009_A_New() *A_arbace_go_check_env_eval1719000008_fn__1719000009_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_eval1719000008_fn__1719000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_env_eval1719000008_fn__1719000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_env_eval1719000008_fn__1719000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_go_check_env_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_env_A_const_9.GetRawRoot__O(), A_arbace_go_check_env_A_const_10) }













func A_arbace_go_check_env_obj_A_New() *A_arbace_go_check_env_obj_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_obj_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_go_check_env_obj_A) Ctor() {}
//line :15:1
func (t *A_arbace_go_check_env_obj_A) Invoke_O_O__O(self, m__0 any) any { var root_21 any = A_arbace_go_check_env_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = m__0; if linked_22 == nil { return ifn_23.Invoke_O__O(arg_24) } else { return linked_22.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_21, arg_24) } }
func A_arbace_go_check_env_o_A_New() *A_arbace_go_check_env_o_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_o_A{}; t.Ctor(); return t }
//line :16:1
func (t *A_arbace_go_check_env_o_A) Ctor() {}
//line :16:1
func (t *A_arbace_go_check_env_o_A) Invoke_O_O_O__O(self, x__0, k__1 any) any { var tmp1 any; var root_25 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = x__0; if linked_26 == nil { tmp1 = ifn_27.Invoke_O__O(arg_28) } else { tmp1 = linked_26.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_25, arg_28) }; return lang.RT_Get_O_O__O_NoInit(tmp1, k__1) }
func A_arbace_go_check_env_oset_BANG__A_New() *A_arbace_go_check_env_oset_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_oset_BANG__A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_go_check_env_oset_BANG__A) Ctor() {}
//line :17:1
func (t *A_arbace_go_check_env_oset_BANG__A) Invoke_O_O_O_O__O(self, x__0, k__1, v__2 any) any { var tmp1 *lang.Volatile = lang.Volatile_Cast(x__0); var tmp2 any; var root_29 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = jrt.NN(lang.Volatile_Cast(x__0)).Deref__O(); var arg_33 any = k__1; var arg_34 any = v__2; if linked_30 == nil { tmp2 = ifn_31.Invoke_O_O_O__O(arg_32, arg_33, arg_34) } else { tmp2 = linked_30.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_29, arg_32, arg_33, arg_34) }; jrt.NN(tmp1).Reset_O__O(tmp2); return x__0 }
func A_arbace_go_check_env_obj_QMARK__A_New() *A_arbace_go_check_env_obj_QMARK__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_obj_QMARK__A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_go_check_env_obj_QMARK__A) Ctor() {}
//line :18:1
func (t *A_arbace_go_check_env_obj_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Volatile_InstanceOf(x__0)).Ref() }



func A_arbace_go_check_env_scope_A_New() *A_arbace_go_check_env_scope_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_scope_A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_go_check_env_scope_A) Ctor() {}
//line :22:1
func (t *A_arbace_go_check_env_scope_A) Invoke_O_O_O__O(self, parent__0, kind__1 any) any { var tmp1 any = A_arbace_go_check_env_A_const_13; var tmp2 any = A_arbace_go_check_env_A_const_14; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, parent__0, tmp2, jrt.HashMap_New(), A_arbace_go_check_env_A_const_15, kind__1)) }

func A_arbace_go_check_env_scope_lookup_A_New() *A_arbace_go_check_env_scope_lookup_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_scope_lookup_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_go_check_env_scope_lookup_A) Ctor() {}
//line :24:1
func (t *A_arbace_go_check_env_scope_lookup_A) Invoke_O_O_O__O(self, s__0, n__1 any) any { { var s__3 any = s__0; L1: for {



	if jrt.J2g_Truth(s__3) { var temp__1927000408__auto____4 any = jrt.HashMap_Cast(A_arbace_go_check_env_A_const_14.Invoke_O__O(s__3)).Get_O__O(n__1)
		if jrt.J2g_Truth(temp__1927000408__auto____4) { var x__5 any = temp__1927000408__auto____4; return x__5 } else {

			s__3 = A_arbace_go_check_env_A_const_13.Invoke_O__O(s__3); continue L1 } } else {
//line :28:1
				return nil } } }; /*line :24:1*/panic("j2g: unreachable") }








func A_arbace_go_check_env_scope_get_A_New() *A_arbace_go_check_env_scope_get_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_scope_get_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_go_check_env_scope_get_A) Ctor() {}
//line :33:1
func (t *A_arbace_go_check_env_scope_get_A) Invoke_O_O_O__O(self, s__0, n__1 any) any { return jrt.HashMap_Cast(A_arbace_go_check_env_A_const_14.Invoke_O__O(s__0)).Get_O__O(n__1) }
func A_arbace_go_check_env_scope_put_BANG__A_New() *A_arbace_go_check_env_scope_put_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_scope_put_BANG__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_go_check_env_scope_put_BANG__A) Ctor() {}
//line :34:1
func (t *A_arbace_go_check_env_scope_put_BANG__A) Invoke_O_O_O_O__O(self, s__0, n__1, x__2 any) any { return jrt.HashMap_Cast(A_arbace_go_check_env_A_const_14.Invoke_O__O(s__0)).Put_O_O__O(n__1, x__2) }























func A_arbace_go_check_env_error_BANG__A_New() *A_arbace_go_check_env_error_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_error_BANG__A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_go_check_env_error_BANG__A) Ctor() {}
//line :58:1
func (t *A_arbace_go_check_env_error_BANG__A) Invoke_O_O_O_O_O__O(self, file__0, line__1, code__2, msg__3 any) any {



	if jrt.J2g_Truth(A_arbace_go_check_env_A_const_16.Get__O()) { var e__5 any; var tmp1 any = A_arbace_go_check_env_A_const_17; var tmp2 any = A_arbace_go_check_env_A_const_18; var tmp3 any = A_arbace_go_check_env_A_const_19; var tmp4 any = A_arbace_go_check_env_A_const_20; var tmp5 any = A_arbace_go_check_env_A_const_21; var tmp6 any

		if jrt.J2g_Truth(A_arbace_go_check_env_A_const_22.Get__O()) { var root_35 any = A_arbace_go_check_env_A_const_23.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, A_arbace_go_check_env_o_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = A_arbace_go_check_env_A_const_22.Get__O(); var arg_39 any = A_arbace_go_check_env_A_const_24; if linked_36 == nil { tmp6 = ifn_37.Invoke_O_O__O(arg_38, arg_39) } else { tmp6 = linked_36.(*A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_35, arg_38, arg_39) } } else { tmp6 = nil }
//line :62:1
		e__5 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, file__0, tmp2, line__1, tmp3, msg__3, tmp4, code__2, tmp5, tmp6))


		var tmp7 *lang.Volatile = lang.Volatile_Cast(A_arbace_go_check_env_A_const_16.Get__O()); var tmp8 any; var root_40 any = A_arbace_go_check_env_A_const_9.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_16.Get__O())).Deref__O(); var arg_44 any = e__5; if linked_41 == nil { tmp8 = ifn_42.Invoke_O_O__O(arg_43, arg_44) } else { tmp8 = linked_41.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_40, arg_43, arg_44) }; jrt.NN(tmp7).Reset_O__O(tmp8) }
//line :58:1
	return nil }
//line :58:1
func (t *A_arbace_go_check_env_error_BANG__A) Invoke_O_O_O_O__O(self, line__0, code__1, msg__2 any) any {

	var root_45 any = A_arbace_go_check_env_A_const_25.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_26; var arg_48 any = tmp1.Invoke_O__O(A_arbace_go_check_env_A_const_27.Get__O()); var arg_49 any = line__0; var arg_50 any = code__1; var arg_51 any = msg__2; if linked_46 == nil { return ifn_47.Invoke_O_O_O_O__O(arg_48, arg_49, arg_50, arg_51) } else { return linked_46.(*A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_45, arg_48, arg_49, arg_50, arg_51)
	}
}





func A_arbace_go_check_env_line_of_A_New() *A_arbace_go_check_env_line_of_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_line_of_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_go_check_env_line_of_A) Ctor() {}
//line :68:1
func (t *A_arbace_go_check_env_line_of_A) Invoke_O_O__O(self, form__0 any) any {


	if lang.IMeta_InstanceOf(form__0) {
		var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_18; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(form__0)) } else {
//line :71:1
			return nil
		}
}


func A_arbace_go_check_env_err_BANG__A_New() *A_arbace_go_check_env_err_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_err_BANG__A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_go_check_env_err_BANG__A) Ctor() {}
//line :76:1
func (t *A_arbace_go_check_env_err_BANG__A) DoInvoke_O_O_O_O_O__O(self, f__0, code__1, fmt__2, args__3 any) any {


	var root_52 any = A_arbace_go_check_env_A_const_25.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any; var or__1927000174__auto____5 any; var root_58 any = A_arbace_go_check_env_A_const_28.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, A_arbace_go_check_env_line_of_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = f__0; if linked_59 == nil { or__1927000174__auto____5 = ifn_60.Invoke_O__O(arg_61) } else { or__1927000174__auto____5 = linked_59.(*A_arbace_go_check_env_line_of_A).Invoke_O_O__O(root_58, arg_61) }; if jrt.J2g_Truth(or__1927000174__auto____5) { arg_55 = or__1927000174__auto____5 } else { arg_55 = A_arbace_go_check_env_A_const_29.Get__O() }; var arg_56 any = code__1; var arg_57 any; var tmp1 any; var root_62 any = A_arbace_go_check_env_A_const_30.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = args__3; if linked_63 == nil { tmp1 = ifn_64.Invoke_O__O(arg_65) } else { tmp1 = linked_63.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_62, arg_65) }; if jrt.J2g_Truth(tmp1) { var root_66 any = A_arbace_go_check_env_A_const_31.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = A_arbace_go_check_env_A_const_32.GetRawRoot__O(); var arg_70 any = fmt__2; var arg_71 any = args__3; if linked_67 == nil { arg_57 = ifn_68.Invoke_O_O_O__O(arg_69, arg_70, arg_71) } else { arg_57 = linked_67.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_66, arg_69, arg_70, arg_71) } } else { arg_57 = fmt__2 }; if linked_53 == nil { return ifn_54.Invoke_O_O_O__O(arg_55, arg_56, arg_57) } else { return linked_53.(*A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O__O(root_52, arg_55, arg_56, arg_57)
	}
}

func A_arbace_go_check_env_generic_BANG__A_New() *A_arbace_go_check_env_generic_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_generic_BANG__A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_go_check_env_generic_BANG__A) Ctor() {}
//line :83:1
func (t *A_arbace_go_check_env_generic_BANG__A) Invoke_O__O(self any) any {



	if jrt.J2g_Truth(A_arbace_go_check_env_A_const_22.Get__O()) { var tmp1 *lang.Volatile = lang.Volatile_Cast(A_arbace_go_check_env_A_const_22.Get__O()); var tmp2 any; var root_72 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_22.Get__O())).Deref__O(); var arg_76 any = A_arbace_go_check_env_A_const_33; var arg_77 any = jrt.Boolean_TRUE.Ref(); if linked_73 == nil { tmp2 = ifn_74.Invoke_O_O_O__O(arg_75, arg_76, arg_77) } else { tmp2 = linked_73.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_72, arg_75, arg_76, arg_77) }; return jrt.NN(tmp1).Reset_O__O(tmp2) } else { return nil
	} }
func A_arbace_go_check_env_unsupported_BANG__A_New() *A_arbace_go_check_env_unsupported_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_unsupported_BANG__A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_go_check_env_unsupported_BANG__A) Ctor() {}
//line :89:1
func (t *A_arbace_go_check_env_unsupported_BANG__A) Invoke_O_O__O(self, what__0 any) any {




	var root_78 any = A_arbace_go_check_env_A_const_34.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, A_arbace_go_check_env_generic_BANG__A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; if linked_79 == nil { ifn_80.Invoke__O() } else { linked_79.(*A_arbace_go_check_env_generic_BANG__A).Invoke_O__O(root_78) }
	var tmp1 any; var and__1927000168__auto____2 any = A_arbace_go_check_env_A_const_22.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Keyword = A_arbace_go_check_env_A_const_35; var tmp3 any; var root_81 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = A_arbace_go_check_env_A_const_22.Get__O(); if linked_82 == nil { tmp3 = ifn_83.Invoke_O__O(arg_84) } else { tmp3 = linked_82.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_81, arg_84) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp2.Invoke_O__O(tmp3), nil)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_12.GetRawRoot__O()); var tmp5 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_22.Get__O())).Deref__O(); var tmp6 any = A_arbace_go_check_env_A_const_35; var tmp7 any = A_arbace_go_check_env_A_const_36; jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_22.Get__O())).Reset_O__O(tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, what__0, tmp7, A_arbace_go_check_env_A_const_29.Get__O())) }
//line :89:1
	return nil
}








func A_arbace_go_check_env_unsupported_QMARK__A_New() *A_arbace_go_check_env_unsupported_QMARK__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_unsupported_QMARK__A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_go_check_env_unsupported_QMARK__A) Ctor() {}
//line :99:1
func (t *A_arbace_go_check_env_unsupported_QMARK__A) Invoke_O_O__O(self, e__0 any) any { var and__1927000168__auto____2 bool = lang.ExceptionInfo_InstanceOf(e__0); if and__1927000168__auto____2 { var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_37; var tmp2 any; var root_93 any = A_arbace_go_check_env_A_const_38.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = e__0; if linked_94 == nil { tmp2 = ifn_95.Invoke_O__O(arg_96) } else { tmp2 = linked_94.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_93, arg_96) }; return tmp1.Invoke_O__O(tmp2) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }








func A_arbace_go_check_env_verified_BANG__A_New() *A_arbace_go_check_env_verified_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_verified_BANG__A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_go_check_env_verified_BANG__A) Ctor() {}
//line :108:1
func (t *A_arbace_go_check_env_verified_BANG__A) Invoke_O_O_O__O(self, k__0, f__1 any) any {




	if jrt.J2g_Truth(A_arbace_go_check_env_A_const_22.Get__O()) { var seen__3 any; var or__1927000174__auto____3 any = A_arbace_go_check_env_A_const_39.Get__O()
		if jrt.J2g_Truth(or__1927000174__auto____3) { seen__3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var tmp1 *lang.Keyword = A_arbace_go_check_env_A_const_40; var tmp2 any; var root_97 any = A_arbace_go_check_env_A_const_7.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = A_arbace_go_check_env_A_const_22.Get__O(); if linked_98 == nil { tmp2 = ifn_99.Invoke_O__O(arg_100) } else { tmp2 = linked_98.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_97, arg_100) }; or__1927000174__auto____4 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(or__1927000174__auto____4) { seen__3 = or__1927000174__auto____4 } else { var m__5 any = jrt.IdentityHashMap_New(); var tmp3 *lang.Volatile = lang.Volatile_Cast(A_arbace_go_check_env_A_const_22.Get__O()); var tmp4 any; var root_110 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_112 lang.IFn
			if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_22.Get__O())).Deref__O(); var arg_114 any = A_arbace_go_check_env_A_const_40; var arg_115 any = m__5; if linked_111 == nil { tmp4 = ifn_112.Invoke_O_O_O__O(arg_113, arg_114, arg_115) } else { tmp4 = linked_111.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_110, arg_113, arg_114, arg_115) }; jrt.NN(tmp3).Reset_O__O(tmp4)
//line :114:1
			seen__3 = m__5 } }
//line :113:1
		var ks__4 any = jrt.NN(jrt.IdentityHashMap_Cast(seen__3)).Get_O__O(f__1); var tmp5 any; var root_101 any = A_arbace_go_check_env_A_const_41.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_103 lang.IFn



		if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = ks__4; var arg_105 any = k__0; if linked_102 == nil { tmp5 = ifn_103.Invoke_O_O__O(arg_104, arg_105) } else { tmp5 = linked_102.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_101, arg_104, arg_105) }; if jrt.J2g_Truth(tmp5) { return nil } else {
			var tmp6 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(seen__3); var tmp7 any; var root_116 any = A_arbace_go_check_env_A_const_9.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any; var or__1927000174__auto____5 any = ks__4; if jrt.J2g_Truth(or__1927000174__auto____5) { arg_119 = or__1927000174__auto____5 } else { arg_119 = lang.PersistentHashSet_EMPTY.Ref() }; var arg_120 any = k__0; if linked_117 == nil { tmp7 = ifn_118.Invoke_O_O__O(arg_119, arg_120) } else { tmp7 = linked_117.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_116, arg_119, arg_120) }; jrt.NN(tmp6).Put_O_O__O(f__1, tmp7)
			var root_106 any = A_arbace_go_check_env_A_const_42.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, A_arbace_go_check_env_verified_BANG__A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = k__0; if linked_107 == nil { return ifn_108.Invoke_O__O(arg_109) } else { return linked_107.(*A_arbace_go_check_env_verified_BANG__A).Invoke_O_O__O(root_106, arg_109) } } } else {
//line :113:1
				return nil } }
//line :108:1
func (t *A_arbace_go_check_env_verified_BANG__A) Invoke_O_O__O(self, k__0 any) any {


	if jrt.J2g_Truth(A_arbace_go_check_env_A_const_22.Get__O()) { var tmp1 *lang.Volatile = lang.Volatile_Cast(A_arbace_go_check_env_A_const_22.Get__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_check_env_A_const_43.GetRawRoot__O()); var tmp3 any = jrt.NN(lang.Volatile_Cast(A_arbace_go_check_env_A_const_22.Get__O())).Deref__O(); var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_env_A_const_44, k__0); var tmp5 any; var root_127 any = A_arbace_go_check_env_A_const_45.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = A_arbace_go_check_env_A_const_46.GetRawRoot__O(); var arg_131 any = A_arbace_go_check_env_A_const_47; if linked_128 == nil { tmp5 = ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { tmp5 = linked_128.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_127, arg_130, arg_131) }; return jrt.NN(tmp1).Reset_O__O(tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5)) } else { return nil
	}
}







func A_arbace_go_check_env_annotation_error_BANG__A_New() *A_arbace_go_check_env_annotation_error_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_annotation_error_BANG__A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_go_check_env_annotation_error_BANG__A) Ctor() {}
//line :121:1
func (t *A_arbace_go_check_env_annotation_error_BANG__A) Invoke_O_O_O_O_O_O__O(self, f__0, a__1, what__2, forms_say__3, checker_says__4 any) any {


	return lang.IFn_Cast(A_arbace_go_check_env_A_const_48.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(f__0, A_arbace_go_check_env_A_const_49, Lit_1, a__1, what__2, forms_say__3, checker_says__4)
}





func A_arbace_go_check_env_def_type_BANG__A_New() *A_arbace_go_check_env_def_type_BANG__A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_def_type_BANG__A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_go_check_env_def_type_BANG__A) Ctor() {}
//line :131:1
func (t *A_arbace_go_check_env_def_type_BANG__A) Invoke_O_O_O__O(self, n__0, kw__1 any) any { var root_142 any = A_arbace_go_check_env_A_const_50.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = A_arbace_go_check_env_A_const_51.GetRawRoot__O(); var arg_146 any = n__0; var arg_147 any; var root_148 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, A_arbace_go_check_env_obj_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env_A_const_15, A_arbace_go_check_env_A_const_53, A_arbace_go_check_env_A_const_26, n__0, A_arbace_go_check_env_A_const_53, kw__1, A_arbace_go_check_env_A_const_54, jrt.Boolean_TRUE.Ref())); if linked_149 == nil { arg_147 = ifn_150.Invoke_O__O(arg_151) } else { arg_147 = linked_149.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_148, arg_151) }; if linked_143 == nil { return ifn_144.Invoke_O_O_O__O(arg_145, arg_146, arg_147) } else { return linked_143.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_142, arg_145, arg_146, arg_147) } }









func A_arbace_go_check_env_fn__1719000041_A_New() *A_arbace_go_check_env_fn__1719000041_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_fn__1719000041_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_go_check_env_fn__1719000041_A) Ctor() {}
//line :141:1
func (t *A_arbace_go_check_env_fn__1719000041_A) Invoke_O__O(self any) any { var nt__1 any; var root_152 any = A_arbace_go_check_env_A_const_55.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_go_check_types.A_arbace_go_check_types_new_named_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = A_arbace_go_check_env_A_const_56; if linked_153 == nil { nt__1 = ifn_154.Invoke_O__O(arg_155) } else { nt__1 = linked_153.(*aot_arbace_go_check_types.A_arbace_go_check_types_new_named_A).Invoke_O_O__O(root_152, arg_155) }; var tmp1 lang.IFn =
										lang.IFn_Cast(A_arbace_go_check_env_A_const_57.GetRawRoot__O()); var tmp2 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var tmp3 any = A_arbace_go_check_env_A_const_58; var tmp4 any = A_arbace_go_check_env_A_const_59; var tmp5 any = A_arbace_go_check_env_A_const_26; var tmp6 any = A_arbace_go_check_env_A_const_60; var tmp7 any = A_arbace_go_check_env_A_const_53; tmp1.Invoke_O_O_O_O__O(nt__1, tmp2, tmp3, lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, Lit_2, tmp6, nil, tmp7, lang.Tuple_Create_O_O_O_O__IPersistentVector(A_arbace_go_check_env_A_const_61, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_check_env_A_const_62, jrt.Boolean_FALSE.Ref())))), nil)); return nt__1 }







func A_arbace_go_check_env_fn__1719000047_A_New() *A_arbace_go_check_env_fn__1719000047_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_fn__1719000047_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_go_check_env_fn__1719000047_A) Ctor() {}
//line :150:1
func (t *A_arbace_go_check_env_fn__1719000047_A) Invoke_O__O(self any) any { var nt__1 any; var root_163 any = A_arbace_go_check_env_A_const_55.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_go_check_types.A_arbace_go_check_types_new_named_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = A_arbace_go_check_env_A_const_63; if linked_164 == nil { nt__1 = ifn_165.Invoke_O__O(arg_166) } else { nt__1 = linked_164.(*aot_arbace_go_check_types.A_arbace_go_check_types_new_named_A).Invoke_O_O__O(root_163, arg_166) }; var tmp1 lang.IFn =
										lang.IFn_Cast(A_arbace_go_check_env_A_const_57.GetRawRoot__O()); var tmp2 any = A_arbace_go_check_env_A_const_12.GetRawRoot__O(); var tmp3 any = A_arbace_go_check_env_A_const_58; var tmp4 any = A_arbace_go_check_env_A_const_59; var tmp5 any = lang.PersistentVector_EMPTY.Ref(); var tmp6 any; var root_174 any = A_arbace_go_check_env_A_const_64.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_go_check_types.A_arbace_go_check_types_make_tset_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = A_arbace_go_check_env_A_const_65; var arg_178 any = jrt.Boolean_TRUE.Ref(); if linked_175 == nil { tmp6 = ifn_176.Invoke_O_O__O(arg_177, arg_178) } else { tmp6 = linked_175.(*aot_arbace_go_check_types.A_arbace_go_check_types_make_tset_A).Invoke_O_O_O__O(root_174, arg_177, arg_178) }; tmp1.Invoke_O_O_O_O__O(nt__1, tmp2, tmp3, lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, tmp5, tmp6)); return nt__1 }



















func A_arbace_go_check_env_fn__1719000065_A_New() *A_arbace_go_check_env_fn__1719000065_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_fn__1719000065_A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_go_check_env_fn__1719000065_A) Ctor() {}
//line :171:1
func (t *A_arbace_go_check_env_fn__1719000065_A) Invoke_O__O(self any) any { var s__1 any; var root_179 any = A_arbace_go_check_env_A_const_66.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, A_arbace_go_check_env_scope_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any; var arg_183 any = A_arbace_go_check_env_A_const_67; if linked_180 == nil { s__1 = ifn_181.Invoke_O_O__O(arg_182, arg_183) } else { s__1 = linked_180.(*A_arbace_go_check_env_scope_A).Invoke_O_O_O__O(root_179, arg_182, arg_183) }; var root_184 any =
										A_arbace_go_check_env_A_const_50.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = s__1; var arg_188 any = Lit_3; var arg_189 any; var root_190 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, A_arbace_go_check_env_obj_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = A_arbace_go_check_env_A_const_68; if linked_191 == nil { arg_189 = ifn_192.Invoke_O__O(arg_193) } else { arg_189 = linked_191.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_190, arg_193) }; if linked_185 == nil { ifn_186.Invoke_O_O_O__O(arg_187, arg_188, arg_189) } else { linked_185.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_184, arg_187, arg_188, arg_189) }; var seq_1719000066__2 any; var root_194 any = /*line :171:1*/A_arbace_go_check_env_A_const_30.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_196 lang.IFn; if

	linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = A_arbace_go_check_env_A_const_69; if linked_195 == nil { seq_1719000066__2 = ifn_196.Invoke_O__O(arg_197) } else { seq_1719000066__2 = linked_195.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_194, arg_197) }; var chunk_1719000067__3 any; var count_1719000068__4 int64 = 0; var i_1719000069__5 int64 = 0; L1:
//line :171:1
	for {

		if lang.Numbers_Lt_J_J__Z_NoInit(i_1719000069__5, count_1719000068__4) { var n__6 any = lang.Indexed_Cast(chunk_1719000067__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1719000069__5)); var root_214 any = A_arbace_go_check_env_A_const_50.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_216 lang.IFn
			if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = s__1; var arg_218 any = n__6; var arg_219 any; var root_220 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, A_arbace_go_check_env_obj_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env_A_const_15, A_arbace_go_check_env_A_const_73, A_arbace_go_check_env_A_const_26, n__6, A_arbace_go_check_env_A_const_74, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_env_A_const_60, Lit_4)); if linked_221 == nil { arg_219 = ifn_222.Invoke_O__O(arg_223) } else { arg_219 = linked_221.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_220, arg_223) }; if linked_215 == nil { ifn_216.Invoke_O_O_O__O(arg_217, arg_218, arg_219) } else { linked_215.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_214, arg_217, arg_218, arg_219) }
//line :173:1
			seq_1719000066__2, chunk_1719000067__3, count_1719000068__4, i_1719000069__5 = seq_1719000066__2, chunk_1719000067__3, count_1719000068__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1719000069__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_198 any = A_arbace_go_check_env_A_const_30.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = seq_1719000066__2; if linked_199 == nil { temp__1927000414__auto____6 = ifn_200.Invoke_O__O(arg_201) } else { temp__1927000414__auto____6 = linked_199.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_198, arg_201) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1719000066__7 any = temp__1927000414__auto____6; var tmp1 any; var root_202 any = A_arbace_go_check_env_A_const_70.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = seq_1719000066__7; if linked_203 == nil { tmp1 = ifn_204.Invoke_O__O(arg_205) } else { tmp1 = linked_203.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_202, arg_205) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____8 any; var root_206 any = A_arbace_go_check_env_A_const_71.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = seq_1719000066__7; if linked_207 == nil { c__1927000678__auto____8 = ifn_208.Invoke_O__O(arg_209) } else { c__1927000678__auto____8 = linked_207.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_206, arg_209) }; var tmp2 any; var root_224 any = A_arbace_go_check_env_A_const_75.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = seq_1719000066__7; if linked_225 == nil { tmp2 = ifn_226.Invoke_O__O(arg_227) } else { tmp2 = linked_225.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_224, arg_227) }; seq_1719000066__2, chunk_1719000067__3, count_1719000068__4, i_1719000069__5 = tmp2, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var n__8 any; var root_210 any = A_arbace_go_check_env_A_const_72.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = seq_1719000066__7; if linked_211 == nil { n__8 = ifn_212.Invoke_O__O(arg_213) } else { n__8 = linked_211.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_210, arg_213) }
				var root_228 any = A_arbace_go_check_env_A_const_50.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, A_arbace_go_check_env_scope_put_BANG__A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = s__1; var arg_232 any = n__8; var arg_233 any; var root_234 any = A_arbace_go_check_env_A_const_52.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, A_arbace_go_check_env_obj_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_env_A_const_15, A_arbace_go_check_env_A_const_73, A_arbace_go_check_env_A_const_26, n__8, A_arbace_go_check_env_A_const_74, jrt.Boolean_TRUE.Ref(), A_arbace_go_check_env_A_const_60, Lit_4)); if linked_235 == nil { arg_233 = ifn_236.Invoke_O__O(arg_237) } else { arg_233 = linked_235.(*A_arbace_go_check_env_obj_A).Invoke_O_O__O(root_234, arg_237) }; if linked_229 == nil { ifn_230.Invoke_O_O_O__O(arg_231, arg_232, arg_233) } else { linked_229.(*A_arbace_go_check_env_scope_put_BANG__A).Invoke_O_O_O_O__O(root_228, arg_231, arg_232, arg_233) }
//line :173:1
				var tmp3 any; var root_238 any = A_arbace_go_check_env_A_const_76.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = seq_1719000066__7; if linked_239 == nil { tmp3 = ifn_240.Invoke_O__O(arg_241) } else { tmp3 = linked_239.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_238, arg_241) }; seq_1719000066__2, chunk_1719000067__3, count_1719000068__4, i_1719000069__5 = tmp3, nil, 0, 0; continue L1 } } }
//line :171:1
		break L1 }; return s__1 }







type A_arbace_go_check_env_A struct{ jrt.Object }

var A_arbace_go_check_env_A_const_pool *jrt.RefArray

var A_arbace_go_check_env_A_const_0 *lang.Var

var A_arbace_go_check_env_A_const_1 any

var A_arbace_go_check_env_A_const_2 any

var A_arbace_go_check_env_A_const_3 any

var A_arbace_go_check_env_A_const_4 *lang.Var

var A_arbace_go_check_env_A_const_5 any

var A_arbace_go_check_env_A_const_6 *lang.Var

var A_arbace_go_check_env_A_const_7 *lang.Var

var A_arbace_go_check_env_A_const_8 *lang.Var

var A_arbace_go_check_env_A_const_9 *lang.Var

var A_arbace_go_check_env_A_const_10 any

var A_arbace_go_check_env_A_const_11 *lang.Var

var A_arbace_go_check_env_A_const_12 *lang.Var

var A_arbace_go_check_env_A_const_13 *lang.Keyword

var A_arbace_go_check_env_A_const_14 *lang.Keyword

var A_arbace_go_check_env_A_const_15 *lang.Keyword

var A_arbace_go_check_env_A_const_16 *lang.Var

var A_arbace_go_check_env_A_const_17 *lang.Keyword

var A_arbace_go_check_env_A_const_18 *lang.Keyword

var A_arbace_go_check_env_A_const_19 *lang.Keyword

var A_arbace_go_check_env_A_const_20 *lang.Keyword

var A_arbace_go_check_env_A_const_21 *lang.Keyword

var A_arbace_go_check_env_A_const_22 *lang.Var

var A_arbace_go_check_env_A_const_23 *lang.Var

var A_arbace_go_check_env_A_const_24 *lang.Keyword

var A_arbace_go_check_env_A_const_25 *lang.Var

var A_arbace_go_check_env_A_const_26 *lang.Keyword

var A_arbace_go_check_env_A_const_27 *lang.Var

var A_arbace_go_check_env_A_const_28 *lang.Var

var A_arbace_go_check_env_A_const_29 *lang.Var

var A_arbace_go_check_env_A_const_30 *lang.Var

var A_arbace_go_check_env_A_const_31 *lang.Var

var A_arbace_go_check_env_A_const_32 *lang.Var

var A_arbace_go_check_env_A_const_33 *lang.Keyword

var A_arbace_go_check_env_A_const_34 *lang.Var

var A_arbace_go_check_env_A_const_35 *lang.Keyword

var A_arbace_go_check_env_A_const_36 *lang.Keyword

var A_arbace_go_check_env_A_const_37 *lang.Keyword

var A_arbace_go_check_env_A_const_38 *lang.Var

var A_arbace_go_check_env_A_const_39 *lang.Var

var A_arbace_go_check_env_A_const_40 *lang.Keyword

var A_arbace_go_check_env_A_const_41 *lang.Var

var A_arbace_go_check_env_A_const_42 *lang.Var

var A_arbace_go_check_env_A_const_43 *lang.Var

var A_arbace_go_check_env_A_const_44 *lang.Keyword

var A_arbace_go_check_env_A_const_45 *lang.Var

var A_arbace_go_check_env_A_const_46 *lang.Var

var A_arbace_go_check_env_A_const_47 any

var A_arbace_go_check_env_A_const_48 *lang.Var

var A_arbace_go_check_env_A_const_49 *lang.Keyword

var A_arbace_go_check_env_A_const_50 *lang.Var

var A_arbace_go_check_env_A_const_51 *lang.Var

var A_arbace_go_check_env_A_const_52 *lang.Var

var A_arbace_go_check_env_A_const_53 *lang.Keyword

var A_arbace_go_check_env_A_const_54 *lang.Keyword

var A_arbace_go_check_env_A_const_55 *lang.Var

var A_arbace_go_check_env_A_const_56 any

var A_arbace_go_check_env_A_const_57 *lang.Var

var A_arbace_go_check_env_A_const_58 *lang.Keyword

var A_arbace_go_check_env_A_const_59 *lang.Keyword

var A_arbace_go_check_env_A_const_60 *lang.Keyword

var A_arbace_go_check_env_A_const_61 *lang.Keyword

var A_arbace_go_check_env_A_const_62 any

var A_arbace_go_check_env_A_const_63 any

var A_arbace_go_check_env_A_const_64 *lang.Var

var A_arbace_go_check_env_A_const_65 *lang.Keyword

var A_arbace_go_check_env_A_const_66 *lang.Var

var A_arbace_go_check_env_A_const_67 *lang.Keyword

var A_arbace_go_check_env_A_const_68 any

var A_arbace_go_check_env_A_const_69 any

var A_arbace_go_check_env_A_const_70 *lang.Var

var A_arbace_go_check_env_A_const_71 *lang.Var

var A_arbace_go_check_env_A_const_72 *lang.Var

var A_arbace_go_check_env_A_const_73 *lang.Keyword

var A_arbace_go_check_env_A_const_74 *lang.Keyword

var A_arbace_go_check_env_A_const_75 *lang.Var

var A_arbace_go_check_env_A_const_76 *lang.Var

var A_arbace_go_check_env_A_init jrt.ClassInit

func A_arbace_go_check_env_A_Init() { if !A_arbace_go_check_env_A_init.Done() { A_arbace_go_check_env_A_init.Run(A_arbace_go_check_env_A_clinit) } }

func A_arbace_go_check_env_A_clinit() { A_arbace_go_check_env_A_clinit_p0(); A_arbace_go_check_env_A_clinit_p1(); A_arbace_go_check_env_A_clinit_p2(); A_arbace_go_check_env_A_clinit_p3(); A_arbace_go_check_env_A_clinit_p4(); A_arbace_go_check_env_A_clinit_p5(); A_arbace_go_check_env_A_clinit_p6() }

func A_arbace_go_check_env_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_env_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 116); A_arbace_go_check_env_A_const_0 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[39]); A_arbace_go_check_env_A_const_1 = A_arbace_go_check_env_A_const_pool.A[40]; A_arbace_go_check_env_A_const_2 = A_arbace_go_check_env_A_const_pool.A[41]; A_arbace_go_check_env_A_const_3 = A_arbace_go_check_env_A_const_pool.A[42]; A_arbace_go_check_env_A_const_4 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[43]); A_arbace_go_check_env_A_const_5 = A_arbace_go_check_env_A_const_pool.A[44]; A_arbace_go_check_env_A_const_6 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[45]); A_arbace_go_check_env_A_const_7 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[46]); A_arbace_go_check_env_A_const_8 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[47]); A_arbace_go_check_env_A_const_9 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[48]); A_arbace_go_check_env_A_const_10 = A_arbace_go_check_env_A_const_pool.A[49]; A_arbace_go_check_env_A_const_11 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[50]) }

func A_arbace_go_check_env_A_clinit_p1() { A_arbace_go_check_env_A_const_12 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[51]); A_arbace_go_check_env_A_const_13 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[52]); A_arbace_go_check_env_A_const_14 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[53]); A_arbace_go_check_env_A_const_15 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[54]); A_arbace_go_check_env_A_const_16 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[55]); A_arbace_go_check_env_A_const_17 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[56]); A_arbace_go_check_env_A_const_18 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[57]); A_arbace_go_check_env_A_const_19 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[58]); A_arbace_go_check_env_A_const_20 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[59]); A_arbace_go_check_env_A_const_21 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[60]); A_arbace_go_check_env_A_const_22 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[61]); A_arbace_go_check_env_A_const_23 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[62]) }

func A_arbace_go_check_env_A_clinit_p2() { A_arbace_go_check_env_A_const_24 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[63]); A_arbace_go_check_env_A_const_25 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[64]); A_arbace_go_check_env_A_const_26 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[65]); A_arbace_go_check_env_A_const_27 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[66]); A_arbace_go_check_env_A_const_28 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[67]); A_arbace_go_check_env_A_const_29 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[68]); A_arbace_go_check_env_A_const_30 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[69]); A_arbace_go_check_env_A_const_31 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[70]); A_arbace_go_check_env_A_const_32 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[71]); A_arbace_go_check_env_A_const_33 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[72]); A_arbace_go_check_env_A_const_34 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[73]); A_arbace_go_check_env_A_const_35 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[74]) }

func A_arbace_go_check_env_A_clinit_p3() { A_arbace_go_check_env_A_const_36 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[75]); A_arbace_go_check_env_A_const_37 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[76]); A_arbace_go_check_env_A_const_38 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[77]); A_arbace_go_check_env_A_const_39 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[78]); A_arbace_go_check_env_A_const_40 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[79]); A_arbace_go_check_env_A_const_41 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[80]); A_arbace_go_check_env_A_const_42 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[81]); A_arbace_go_check_env_A_const_43 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[82]); A_arbace_go_check_env_A_const_44 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[83]); A_arbace_go_check_env_A_const_45 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[84]); A_arbace_go_check_env_A_const_46 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[85]); A_arbace_go_check_env_A_const_47 = A_arbace_go_check_env_A_const_pool.A[86] }

func A_arbace_go_check_env_A_clinit_p4() { A_arbace_go_check_env_A_const_48 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[87]); A_arbace_go_check_env_A_const_49 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[88]); A_arbace_go_check_env_A_const_50 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[89]); A_arbace_go_check_env_A_const_51 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[90]); A_arbace_go_check_env_A_const_52 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[91]); A_arbace_go_check_env_A_const_53 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[92]); A_arbace_go_check_env_A_const_54 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[93]); A_arbace_go_check_env_A_const_55 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[94]); A_arbace_go_check_env_A_const_56 = A_arbace_go_check_env_A_const_pool.A[95]; A_arbace_go_check_env_A_const_57 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[96]); A_arbace_go_check_env_A_const_58 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[97]); A_arbace_go_check_env_A_const_59 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[98]) }

func A_arbace_go_check_env_A_clinit_p5() { A_arbace_go_check_env_A_const_60 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[99]); A_arbace_go_check_env_A_const_61 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[100]); A_arbace_go_check_env_A_const_62 = A_arbace_go_check_env_A_const_pool.A[101]; A_arbace_go_check_env_A_const_63 = A_arbace_go_check_env_A_const_pool.A[102]; A_arbace_go_check_env_A_const_64 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[103]); A_arbace_go_check_env_A_const_65 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[104]); A_arbace_go_check_env_A_const_66 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[105]); A_arbace_go_check_env_A_const_67 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[106]); A_arbace_go_check_env_A_const_68 = A_arbace_go_check_env_A_const_pool.A[107]; A_arbace_go_check_env_A_const_69 = A_arbace_go_check_env_A_const_pool.A[108]; A_arbace_go_check_env_A_const_70 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[109]); A_arbace_go_check_env_A_const_71 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[110]); A_arbace_go_check_env_A_const_72 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[111]) }

func A_arbace_go_check_env_A_clinit_p6() { A_arbace_go_check_env_A_const_73 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[112]); A_arbace_go_check_env_A_const_74 = lang.Keyword_Cast(A_arbace_go_check_env_A_const_pool.A[113]); A_arbace_go_check_env_A_const_75 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[114]); A_arbace_go_check_env_A_const_76 = lang.Var_Cast(A_arbace_go_check_env_A_const_pool.A[115]) }

func A_arbace_go_check_env_A_New() *A_arbace_go_check_env_A { A_arbace_go_check_env_A_Init(); t := &A_arbace_go_check_env_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env_A) Ctor() {}

func (t *A_arbace_go_check_env_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env_A_class }

func (t *A_arbace_go_check_env_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env_A); return ok }

func A_arbace_go_check_env_A_Cast(x any) *A_arbace_go_check_env_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env_A_class)) }; return v }



type A_arbace_go_check_env_annotation_error_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_annotation_error_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_def_type_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_def_type_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_err_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_err_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_error_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_error_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_eval1719000004_A struct{ jrt.Object }

func A_arbace_go_check_env_eval1719000004_A_New() *A_arbace_go_check_env_eval1719000004_A { t := &A_arbace_go_check_env_eval1719000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env_eval1719000004_A) Ctor() {}

func (t *A_arbace_go_check_env_eval1719000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env_eval1719000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env_eval1719000004_A_class }

func (t *A_arbace_go_check_env_eval1719000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env_eval1719000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env_eval1719000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env_eval1719000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env_eval1719000004_A); return ok }

func A_arbace_go_check_env_eval1719000004_A_Cast(x any) *A_arbace_go_check_env_eval1719000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env_eval1719000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env_eval1719000004_A_class)) }; return v }



type A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_eval1719000004_loading__1927001464__auto____1719000005_A_fn_class *jrt.Class



type A_arbace_go_check_env_eval1719000008_A struct{ jrt.Object }

func A_arbace_go_check_env_eval1719000008_A_New() *A_arbace_go_check_env_eval1719000008_A { t := &A_arbace_go_check_env_eval1719000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_env_eval1719000008_A) Ctor() {}

func (t *A_arbace_go_check_env_eval1719000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_env_eval1719000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_env_eval1719000008_A_class }

func (t *A_arbace_go_check_env_eval1719000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_env_eval1719000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_env_eval1719000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_env_eval1719000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_env_eval1719000008_A); return ok }

func A_arbace_go_check_env_eval1719000008_A_Cast(x any) *A_arbace_go_check_env_eval1719000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_env_eval1719000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_env_eval1719000008_A_class)) }; return v }



type A_arbace_go_check_env_eval1719000008_fn__1719000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_eval1719000008_fn__1719000009_A_fn_class *jrt.Class



type A_arbace_go_check_env_fn__1719000041_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_fn__1719000041_A_fn_class *jrt.Class



type A_arbace_go_check_env_fn__1719000047_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_fn__1719000047_A_fn_class *jrt.Class



type A_arbace_go_check_env_fn__1719000065_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_fn__1719000065_A_fn_class *jrt.Class



type A_arbace_go_check_env_generic_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_generic_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_line_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_line_of_A_fn_class *jrt.Class



type A_arbace_go_check_env_o_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_o_A_fn_class *jrt.Class



type A_arbace_go_check_env_obj_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_obj_A_fn_class *jrt.Class



type A_arbace_go_check_env_obj_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_obj_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_env_oset_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_oset_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_scope_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_scope_A_fn_class *jrt.Class



type A_arbace_go_check_env_scope_get_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_scope_get_A_fn_class *jrt.Class



type A_arbace_go_check_env_scope_lookup_A struct{ j2g_header uint64 }

var A_arbace_go_check_env_scope_lookup_A_fn_class *jrt.Class



type A_arbace_go_check_env_scope_put_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_scope_put_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_unsupported_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_unsupported_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_env_unsupported_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_unsupported_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_env_verified_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_env_verified_BANG__A_fn_class *jrt.Class
