//line aot_arbace_go_embed.ae:1
package aot_arbace_go_embed

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_embed_eval1220000004_loading__1927001464__auto____1220000005_A_New() *A_arbace_go_embed_eval1220000004_loading__1927001464__auto____1220000005_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_eval1220000004_loading__1927001464__auto____1220000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_embed_eval1220000004_loading__1927001464__auto____1220000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_embed_eval1220000004_loading__1927001464__auto____1220000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_embed_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_embed_A_const_1); lang.IFn_Cast(A_arbace_go_embed_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_go_embed_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_embed_eval1220000008_fn__1220000009_A_New() *A_arbace_go_embed_eval1220000008_fn__1220000009_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_eval1220000008_fn__1220000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_embed_eval1220000008_fn__1220000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_embed_eval1220000008_fn__1220000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_embed_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_go_embed_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_go_embed_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_embed_A_const_7.GetRawRoot__O(), A_arbace_go_embed_A_const_8) }















func A_arbace_go_embed_space_QMARK__A_New() *A_arbace_go_embed_space_QMARK__A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_space_QMARK__A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_go_embed_space_QMARK__A) Ctor() {}
//line :17:1
func (t *A_arbace_go_embed_space_QMARK__A) Invoke_O_O__O(self, c__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsWhitespace_C__Z_NoInit(lang.RT_CharCast_O__C_NoInit(c__0))).Ref() }

func A_arbace_go_embed_unquote_go_A_New() *A_arbace_go_embed_unquote_go_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_unquote_go_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_go_embed_unquote_go_A) Ctor() {}
//line :19:1
func (t *A_arbace_go_embed_unquote_go_A) Invoke_O_O__O(self, q__0 any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var s__4 any; var root_19 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_21 lang.IFn



	if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = q__0; var arg_23 any = A_arbace_go_embed_A_const_10; var arg_24 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(q__0)))).Ref(); if linked_20 == nil { s__4 = ifn_21.Invoke_O_O_O__O(arg_22, arg_23, arg_24) } else { s__4 = linked_20.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_19, arg_22, arg_23, arg_24) }
//line :19:1
	var sb__5 any = jrt.StringBuilder_New(); var i__6 int64 = 0; L1: for {






		if lang.Numbers_Gte_J_J__Z_NoInit(i__6, int64(lang.RT_Count_O__I_NoInit(s__4))) {
			var root_25 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = sb__5; if linked_26 == nil { tmp1 = ifn_27.Invoke_O__O(arg_28) } else { tmp1 = linked_26.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_25, arg_28) } } else {
//line :26:1
				var c__7 uint16 = jrt.NN(jrt.String_Cast(s__4)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__6))


				if lang.Util_Equiv_C_C__Z_NoInit(c__7, jrt.NN(jrt.Character_Cast(A_arbace_go_embed_A_const_12)).CharValue__C()) { tmp1 = nil } else { var tmp2 any; var root_29 any = A_arbace_go_embed_A_const_13.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_31 lang.IFn

					if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = jrt.Character_ValueOf_C__Character_NoInit(c__7).Ref(); var arg_33 any = A_arbace_go_embed_A_const_14; if linked_30 == nil { tmp2 = ifn_31.Invoke_O_O__O(arg_32, arg_33) } else { tmp2 = linked_30.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_29, arg_32, arg_33) }
//line :29:1
					if jrt.J2g_Truth(tmp2) {

						jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_C__StringBuilder(c__7); i__6 = lang.Numbers_Inc_J__J_NoInit(i__6); continue L1 } else {
//line :29:1
							if A_arbace_go_embed_A_const_15 != nil { var e__8 uint16 = jrt.NN(jrt.String_Cast(s__4)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(i__6)))
								var G__1220000013__9_ uint16 = e__8



							L2: switch { default: switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref()) { case 34: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_12) {



								jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_C__StringBuilder(e__8); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
								break L2 }; case 39: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_16) {



									jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_C__StringBuilder(e__8); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
									break L2 }; case 92: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_14) {



										jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_C__StringBuilder(e__8); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
										break L2 }; case 97: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_17) {




											jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_C__StringBuilder(lang.RT_CharCast_J__C_NoInit(7)); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
											break L2 }; case 98: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_18) {





												jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_C__StringBuilder(lang.RT_CharCast_J__C_NoInit(8)); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
												break L2 }; case 102: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_19) {






													jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_C__StringBuilder(lang.RT_CharCast_J__C_NoInit(12)); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
													break L2 }; case 110: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_20) {
														jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_O__StringBuilder(A_arbace_go_embed_A_const_22); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
														break L2 }; case 114: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_21) {


															jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_O__StringBuilder(A_arbace_go_embed_A_const_24); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
															break L2 }; case 116: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_23) {

																jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_O__StringBuilder(A_arbace_go_embed_A_const_26); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
																break L2 }; case 117: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_25) {









																	var tmp3 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__5); var tmp4 any; var root_35 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = s__4; var arg_39 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__6, 2)).Ref(); var arg_40 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__6, 6)).Ref(); if linked_36 == nil { tmp4 = ifn_37.Invoke_O_O_O__O(arg_38, arg_39, arg_40) } else { tmp4 = linked_36.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_35, arg_38, arg_39, arg_40) }; jrt.NN(tmp3).Append_C__StringBuilder(lang.RT_CharCast_J__C_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp4), lang.RT_IntCast_J__I_NoInit(16)))); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 6); continue L1
//line :34:1
																	break L2 }; case 118: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_27) {







																		jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_C__StringBuilder(lang.RT_CharCast_J__C_NoInit(11)); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
																		break L2 }; case 120: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_28) {








																			var tmp5 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__5); var tmp6 any; var root_41 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = s__4; var arg_45 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__6, 2)).Ref(); var arg_46 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__6, 4)).Ref(); if linked_42 == nil { tmp6 = ifn_43.Invoke_O_O_O__O(arg_44, arg_45, arg_46) } else { tmp6 = linked_42.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_41, arg_44, arg_45, arg_46) }; jrt.NN(tmp5).Append_C__StringBuilder(lang.RT_CharCast_J__C_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp6), lang.RT_IntCast_J__I_NoInit(16)))); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 4); continue L1
//line :34:1
																			break L2 }; default:}; tmp1 = nil} } else {
//line :29:1
																				tmp1 = nil } } } }
//line :19:1
		break L1 } }; return nil }(); if tmp7 != nil { if jrt.Exception_InstanceOf(tmp7) { var ___4 jrt.Exception_I = jrt.Exception_Cast(tmp7); _ = ___4; tmp1 = nil } else { panic(tmp7) } }; return tmp1 }




























func A_arbace_go_embed_parse_patterns_A_New() *A_arbace_go_embed_parse_patterns_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_parse_patterns_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_go_embed_parse_patterns_A) Ctor() {}
//line :48:1
func (t *A_arbace_go_embed_parse_patterns_A) Invoke_O_O__O(self, args__0 any) any { { var args__2 any; var root_47 any = A_arbace_go_embed_A_const_29.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_49 lang.IFn



	if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = args__0; if linked_48 == nil { args__2 = ifn_49.Invoke_O__O(arg_50) } else { args__2 = linked_48.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_47, arg_50) }
//line :48:1
	var acc__3 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




		if lang.Util_Equiv_O_O__Z_NoInit(Lit_37, args__2) { return lang.Tuple_Create_O_O__IPersistentVector(acc__3, nil) } else { var c__4 uint16 = jrt.NN(jrt.String_Cast(args__2)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)); var vec__1220000016__5 any
			var G__1220000019__5_ uint16 = c__4


		L2: switch { default: switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000019__5_).Ref()) { case 34: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000019__5_).Ref(), A_arbace_go_embed_A_const_12) { var end__6 any; var tmp1 any = A_arbace_go_embed_parse_patterns_fn__1220000020_A_New_O(args__2); var tmp2 *jrt.Class
			var fncls__52 /*line :57:1*/*jrt.Class = A_arbace_go_embed_parse_patterns_fn__1220000020_A_fn_class




			if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_go_embed_parse_patterns_fn__1220000020_A_fn_class = fncls__52d; tmp2 = fncls__52d } else { tmp2 = fncls__52 }; end__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()





			if lang.Util_Identical_O_O__Z_NoInit(end__6, nil) { vec__1220000016__5 = lang.Tuple_Create_O_O_O__IPersistentVector(nil, nil, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil), jrt.RefArrayOf(jrt.Object_class, nil, args__2)).Ref()) } else { var temp__1927000408__auto____7 any; var root_53 any = A_arbace_go_embed_A_const_30.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, A_arbace_go_embed_unquote_go_A_fn_class); var ifn_55 lang.IFn

				if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any; var root_57 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = args__2; var arg_61 any = A_arbace_go_embed_A_const_31; var arg_62 any; var na_63 any = end__6; if jrt.Long_InstanceOf(na_63) { var n0_64 int64 = jrt.NN(jrt.Long_Cast(na_63)).LongValue__J(); if n0_64 == 9223372036854775807 { arg_62 = lang.Numbers_Inc_O__Number_NoInit(na_63) } else { arg_62 = jrt.Long_ValueOf_J__Long_NoInit(n0_64 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_63) { var n0_64_2 float64 = jrt.NN(jrt.Double_Cast(na_63)).DoubleValue__D(); arg_62 = jrt.Double_ValueOf_D__Double_NoInit(n0_64_2 + 1.0).Ref() } else { arg_62 = lang.Numbers_Inc_O__Number_NoInit(na_63) } }; if linked_58 == nil { arg_56 = ifn_59.Invoke_O_O_O__O(arg_60, arg_61, arg_62) } else { arg_56 = linked_58.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_57, arg_60, arg_61, arg_62) }; if linked_54 == nil { temp__1927000408__auto____7 = ifn_55.Invoke_O__O(arg_56) } else { temp__1927000408__auto____7 = linked_54.(*A_arbace_go_embed_unquote_go_A).Invoke_O_O__O(root_53, arg_56) }; if jrt.J2g_Truth(temp__1927000408__auto____7) { var q__8 any = temp__1927000408__auto____7; var tmp3 any; var root_98 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_100 lang.IFn
					if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = args__2; var arg_102 any; var na_103 any = end__6; if jrt.Long_InstanceOf(na_103) { var n0_104 int64 = jrt.NN(jrt.Long_Cast(na_103)).LongValue__J(); if n0_104 == 9223372036854775807 { arg_102 = lang.Numbers_Inc_O__Number_NoInit(na_103) } else { arg_102 = jrt.Long_ValueOf_J__Long_NoInit(n0_104 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_103) { var n0_104_2 float64 = jrt.NN(jrt.Double_Cast(na_103)).DoubleValue__D(); arg_102 = jrt.Double_ValueOf_D__Double_NoInit(n0_104_2 + 1.0).Ref() } else { arg_102 = lang.Numbers_Inc_O__Number_NoInit(na_103) } }; if linked_99 == nil { tmp3 = ifn_100.Invoke_O_O__O(arg_101, arg_102) } else { tmp3 = linked_99.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_98, arg_101, arg_102) }
//line :70:1
					vec__1220000016__5 = lang.Tuple_Create_O_O_O__IPersistentVector(q__8, tmp3, nil) } else { var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_51, nil); var tmp5 any; var root_105 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_107 lang.IFn

						if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = args__2; var arg_109 any = A_arbace_go_embed_A_const_31; var arg_110 any; var na_111 any = end__6; if jrt.Long_InstanceOf(na_111) { var n0_112 int64 = jrt.NN(jrt.Long_Cast(na_111)).LongValue__J(); if n0_112 == 9223372036854775807 { arg_110 = lang.Numbers_Inc_O__Number_NoInit(na_111) } else { arg_110 = jrt.Long_ValueOf_J__Long_NoInit(n0_112 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_111) { var n0_112_2 float64 = jrt.NN(jrt.Double_Cast(na_111)).DoubleValue__D(); arg_110 = jrt.Double_ValueOf_D__Double_NoInit(n0_112_2 + 1.0).Ref() } else { arg_110 = lang.Numbers_Inc_O__Number_NoInit(na_111) } }; if linked_106 == nil { tmp5 = ifn_107.Invoke_O_O_O__O(arg_108, arg_109, arg_110) } else { tmp5 = linked_106.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_105, arg_108, arg_109, arg_110) }
//line :70:1
						vec__1220000016__5 = lang.Tuple_Create_O_O_O__IPersistentVector(nil, nil, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref()) } }
//line :57:1
			break L2 }; case 96: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000019__5_).Ref(), A_arbace_go_embed_A_const_32) { var i__6 any; var root_65 any = A_arbace_go_embed_A_const_33.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_65, aot_arbace_string.A_arbace_string_index_of_A_fn_class); var ifn_67 lang.IFn
				if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = args__2; var arg_69 any = Lit_52; if linked_66 == nil { i__6 = ifn_67.Invoke_O_O_O__O(arg_68, arg_69, A_arbace_go_embed_A_const_10) } else { i__6 = linked_66.(*aot_arbace_string.A_arbace_string_index_of_A).InvokePrim_O_O_O_J__O(root_65, arg_68, arg_69, 1) }
				if lang.Util_Identical_O_O__Z_NoInit(i__6, nil) { vec__1220000016__5 = lang.Tuple_Create_O_O_O__IPersistentVector(nil, nil, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil), jrt.RefArrayOf(jrt.Object_class, nil, args__2)).Ref()) } else { var tmp6 any; var root_113 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_115 lang.IFn

					if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = args__2; var arg_117 any = A_arbace_go_embed_A_const_10; var arg_118 any = i__6; if linked_114 == nil { tmp6 = ifn_115.Invoke_O_O_O__O(arg_116, arg_117, arg_118) } else { tmp6 = linked_114.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_113, arg_116, arg_117, arg_118) }
//line :59:1
					var tmp7 any = tmp6; var tmp8 any; var root_119 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_121 lang.IFn

					if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = args__2; var arg_123 any; var na_124 any = i__6; if jrt.Long_InstanceOf(na_124) { var n0_125 int64 = jrt.NN(jrt.Long_Cast(na_124)).LongValue__J(); if n0_125 == 9223372036854775807 { arg_123 = lang.Numbers_Inc_O__Number_NoInit(na_124) } else { arg_123 = jrt.Long_ValueOf_J__Long_NoInit(n0_125 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_124) { var n0_125_2 float64 = jrt.NN(jrt.Double_Cast(na_124)).DoubleValue__D(); arg_123 = jrt.Double_ValueOf_D__Double_NoInit(n0_125_2 + 1.0).Ref() } else { arg_123 = lang.Numbers_Inc_O__Number_NoInit(na_124) } }; if linked_120 == nil { tmp8 = ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { tmp8 = linked_120.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_119, arg_122, arg_123) }
//line :59:1
					vec__1220000016__5 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp7, tmp8, nil) }
//line :57:1
				break L2 }; default:}; var i__6_2 any; var or__1927000174__auto____6 any; var root_71 any = A_arbace_go_embed_A_const_34.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_73 lang.IFn















			if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any; var tmp9 any = A_arbace_go_embed_parse_patterns_fn__1220000022_A_New_O(args__2); var tmp10 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_go_embed_parse_patterns_fn__1220000022_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_go_embed_parse_patterns_fn__1220000022_A_fn_class = fncls__80d; tmp10 = fncls__80d } else { tmp10 = fncls__80 }; arg_74 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_75 any; var root_81 any = A_arbace_go_embed_A_const_36.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(args__2)).Ref(); if linked_82 == nil { arg_75 = ifn_83.Invoke_O__O(arg_84) } else { arg_75 = linked_82.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_81, arg_84) }; if linked_72 == nil { or__1927000174__auto____6 = ifn_73.Invoke_O_O__O(arg_74, arg_75) } else { or__1927000174__auto____6 = linked_72.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_71, arg_74, arg_75) }; if jrt.J2g_Truth(or__1927000174__auto____6) { i__6_2 = or__1927000174__auto____6 } else { i__6_2 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(args__2)).Ref() }
//line :57:1
			var tmp11 any; var root_126 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_128 lang.IFn
















			if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = args__2; var arg_130 any = A_arbace_go_embed_A_const_31; var arg_131 any = i__6_2; if linked_127 == nil { tmp11 = ifn_128.Invoke_O_O_O__O(arg_129, arg_130, arg_131) } else { tmp11 = linked_127.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_126, arg_129, arg_130, arg_131) }
//line :57:1
			var tmp12 any = tmp11; var tmp13 any; var root_132 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_134 lang.IFn
















			if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = args__2; var arg_136 any = i__6_2; if linked_133 == nil { tmp13 = ifn_134.Invoke_O_O__O(arg_135, arg_136) } else { tmp13 = linked_133.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_132, arg_135, arg_136) }
//line :57:1
			vec__1220000016__5 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp12, tmp13, nil)}
//line :53:1
			var path__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000016__5, lang.RT_IntCast_J__I_NoInit(0), nil); var rest__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000016__5, lang.RT_IntCast_J__I_NoInit(1), nil); var err__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000016__5, lang.RT_IntCast_J__I_NoInit(2), nil)





















			if jrt.J2g_Truth(err__8) { return lang.Tuple_Create_O_O__IPersistentVector(nil, err__8) } else { var tmp14 any; var and__1927000168__auto____9 any; var root_85 any = A_arbace_go_embed_A_const_13.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_87 lang.IFn

				if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = Lit_37; var arg_89 any = rest__7; if linked_86 == nil { and__1927000168__auto____9 = ifn_87.Invoke_O_O__O(arg_88, arg_89) } else { and__1927000168__auto____9 = linked_86.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_85, arg_88, arg_89) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var root_90 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any; var root_94 any = A_arbace_go_embed_A_const_35.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, A_arbace_go_embed_space_QMARK__A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(rest__7)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0))).Ref(); if linked_95 == nil { arg_93 = ifn_96.Invoke_O__O(arg_97) } else { arg_93 = linked_95.(*A_arbace_go_embed_space_QMARK__A).Invoke_O_O__O(root_94, arg_97) }; if linked_91 == nil { tmp14 = ifn_92.Invoke_O__O(arg_93) } else { tmp14 = linked_91.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_90, arg_93) } } else { tmp14 = and__1927000168__auto____9 }
//line :75:1
				if jrt.J2g_Truth(tmp14) { return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil), jrt.RefArrayOf(jrt.Object_class, nil, rest__7)).Ref()) } else { if A_arbace_go_embed_A_const_15 != nil {



					var tmp15 any; var root_137 any = A_arbace_go_embed_A_const_29.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = rest__7; if linked_138 == nil { tmp15 = ifn_139.Invoke_O__O(arg_140) } else { tmp15 = linked_138.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_137, arg_140) }; var tmp16 any = tmp15; var tmp17 any; var root_141 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = acc__3; var arg_145 any = path__6; if linked_142 == nil { tmp17 = ifn_143.Invoke_O_O__O(arg_144, arg_145) } else { tmp17 = linked_142.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_141, arg_144, arg_145) }; args__2, acc__3 = tmp16, tmp17; continue L1 } else {
//line :75:1
						return nil } } } } } }; /*line :48:1*/panic("j2g: unreachable") }













func A_arbace_go_embed_parse_patterns_fn__1220000020_A_New_O(p0 any) *A_arbace_go_embed_parse_patterns_fn__1220000020_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_parse_patterns_fn__1220000020_A{}; t.Ctor_O(p0); return t }
//line :62:1
func (t *A_arbace_go_embed_parse_patterns_fn__1220000020_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :62:1
func (t *A_arbace_go_embed_parse_patterns_fn__1220000020_A) Invoke_O__O(self any) any { { var i__1 int64 = 1; L1: for {
											if lang.Numbers_Gte_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_args))) { return nil } else { var tmp1 *jrt.String = jrt.String_Cast(t.F_args); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_go_embed_A_const_14)).CharValue__C(), jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__1))) {

		i__1 = lang.Numbers_Add_J_J__J_NoInit(i__1, 2); continue L1 } else {
//line :63:1
			var tmp2 *jrt.String = jrt.String_Cast(t.F_args); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_go_embed_A_const_12)).CharValue__C(), jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__1))) { return jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref() } else { if A_arbace_go_embed_A_const_15 != nil {



				i__1 = lang.Numbers_Inc_J__J_NoInit(i__1); continue L1 } else {
//line :63:1
					return nil } } } } } }; /*line :62:1*/panic("j2g: unreachable") }










func A_arbace_go_embed_parse_patterns_fn__1220000022_A_New_O(p0 any) *A_arbace_go_embed_parse_patterns_fn__1220000022_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_parse_patterns_fn__1220000022_A{}; t.Ctor_O(p0); return t }
//line :73:1
func (t *A_arbace_go_embed_parse_patterns_fn__1220000022_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :73:1
func (t *A_arbace_go_embed_parse_patterns_fn__1220000022_A) Invoke_O_O__O(self, p1__1220000015_SHARP___1 any) any { var tmp1 any; var root_76 any = A_arbace_go_embed_A_const_35.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, A_arbace_go_embed_space_QMARK__A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var tmp2 *jrt.String = jrt.String_Cast(t.F_args); var arg_79 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(p1__1220000015_SHARP___1))).Ref(); if linked_77 == nil { tmp1 = ifn_78.Invoke_O__O(arg_79) } else { tmp1 = linked_77.(*A_arbace_go_embed_space_QMARK__A).Invoke_O_O__O(root_76, arg_79) }; if jrt.J2g_Truth(tmp1) { return p1__1220000015_SHARP___1 } else { return nil } }







func A_arbace_go_embed_directive_patterns_A_New() *A_arbace_go_embed_directive_patterns_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_directive_patterns_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_go_embed_directive_patterns_A) Ctor() {}
//line :81:1
func (t *A_arbace_go_embed_directive_patterns_A) Invoke_O_O__O(self, v__0 any) any { var texts__2 any; var tmp1 any; var root_146 any = A_arbace_go_embed_A_const_38.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_148 lang.IFn; if



	linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = v__0; if linked_147 == nil { tmp1 = ifn_148.Invoke_O__O(arg_149) } else { tmp1 = linked_147.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_146, arg_149) }; if jrt.J2g_Truth(tmp1) { texts__2 = v__0 } else { texts__2 = lang.Tuple_Create_O__IPersistentVector(v__0) }; var root_150 any =
	A_arbace_go_embed_A_const_39.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any; var tmp2 any = A_arbace_go_embed_directive_patterns_fn__1220000026_A_New(); var tmp3 *jrt.Class; var fncls__181 *jrt.Class = A_arbace_go_embed_directive_patterns_fn__1220000026_A_fn_class; if fncls__181 == nil { var fncls__181d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_go_embed_directive_patterns_fn__1220000026_A_fn_class = fncls__181d; tmp3 = fncls__181d } else { tmp3 = fncls__181 }; arg_153 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_154 any = lang.Tuple_Create_O_O__IPersistentVector(lang.PersistentVector_EMPTY.Ref(), nil); var arg_155 any = texts__2; if linked_151 == nil { return ifn_152.Invoke_O_O_O__O(arg_153, arg_154, arg_155) } else { return linked_151.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_150, arg_153, arg_154, arg_155) } }
//line :86:1
func A_arbace_go_embed_directive_patterns_fn__1220000026_A_New() *A_arbace_go_embed_directive_patterns_fn__1220000026_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_directive_patterns_fn__1220000026_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_go_embed_directive_patterns_fn__1220000026_A) Ctor() {}
//line :86:1
func (t *A_arbace_go_embed_directive_patterns_fn__1220000026_A) Invoke_O_O_O__O(self, p__1220000025__1, t__2 any) any { var vec__1220000027__3 any = p__1220000025__1; var acc__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000027__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000027__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__1220000030__6 any; var root_156 any = A_arbace_go_embed_A_const_40.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, A_arbace_go_embed_parse_patterns_A_fn_class); var ifn_158 lang.IFn; _ = ___5; if
															linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any; var root_160 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = t__2; if linked_161 == nil { arg_159 = ifn_162.Invoke_O__O(arg_163) } else { arg_159 = linked_161.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_160, arg_163) }; if linked_157 == nil { vec__1220000030__6 = ifn_158.Invoke_O__O(arg_159) } else { vec__1220000030__6 = linked_157.(*A_arbace_go_embed_parse_patterns_A).Invoke_O_O__O(root_156, arg_159) }; var ps__7 any = /*line :86:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1220000030__6, lang.RT_IntCast_J__I_NoInit(0), nil); var err__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000030__6, lang.RT_IntCast_J__I_NoInit(1), nil); if

	jrt.J2g_Truth(err__8) {
		var root_164 any = A_arbace_go_embed_A_const_41.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = lang.Tuple_Create_O_O__IPersistentVector(nil, err__8); if linked_165 == nil { return ifn_166.Invoke_O__O(arg_167) } else { return linked_165.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_164, arg_167) } } else {
//line :88:1
			var tmp1 any; var root_168 any = A_arbace_go_embed_A_const_42.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_170 lang.IFn

			if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = ps__7; if linked_169 == nil { tmp1 = ifn_170.Invoke_O__O(arg_171) } else { tmp1 = linked_169.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_168, arg_171) }
//line :88:1
			if jrt.J2g_Truth(tmp1) {

				var root_172 any = A_arbace_go_embed_A_const_41.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = A_arbace_go_embed_A_const_43; if linked_173 == nil { return ifn_174.Invoke_O__O(arg_175) } else { return linked_173.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_172, arg_175) } } else {
//line :88:1
					if A_arbace_go_embed_A_const_15 != nil { var tmp2 any; var root_176 any = A_arbace_go_embed_A_const_44.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_178 lang.IFn


						if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = acc__4; var arg_180 any = ps__7; if linked_177 == nil { tmp2 = ifn_178.Invoke_O_O__O(arg_179, arg_180) } else { tmp2 = linked_177.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_176, arg_179, arg_180) }
//line :88:1
						return lang.Tuple_Create_O_O__IPersistentVector(tmp2, nil) } else { return nil } } } }







func A_arbace_go_embed_glob_regex_A_New() *A_arbace_go_embed_glob_regex_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_regex_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_go_embed_glob_regex_A) Ctor() {}
//line :96:1
func (t *A_arbace_go_embed_glob_regex_A) Invoke_O_O__O(self, p__0 any) any { { var sb__2 any = jrt.StringBuilder_New(); var n__3 int32 = lang.RT_Count_O__I_NoInit(p__0); var i__4 any = lang.RT_Box_J__Number_NoInit(0); L1: for {





	var tmp1 bool; var na_182 any = i__4; var na_183 int64 = int64(n__3); if jrt.Long_InstanceOf(na_182) { var n0_184 int64 = jrt.NN(jrt.Long_Cast(na_182)).LongValue__J(); var n1_185 int64 = na_183; tmp1 = n0_184 >= n1_185 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_182, na_183) }; if tmp1 { var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var root_187 any = A_arbace_go_embed_A_const_45.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_re_pattern_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any; var root_191 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = sb__2; if linked_192 == nil { arg_190 = ifn_193.Invoke_O__O(arg_194) } else { arg_190 = linked_192.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_191, arg_194) }; if linked_188 == nil { tmp2 = ifn_189.Invoke_O__O(arg_190) } else { tmp2 = linked_188.(*aot_arbace_core.A_arbace_core_re_pattern_A).Invoke_O_O__O(root_187, arg_190) } }
//line :102:1
		return nil }(); if tmp3 != nil { if jrt.Exception_InstanceOf(tmp3) { var ___7 jrt.Exception_I = jrt.Exception_Cast(tmp3); _ = ___7; tmp2 = nil } else { panic(tmp3) } }; return tmp2 } else { var c__7 uint16 = jrt.NN(jrt.String_Cast(p__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__4))
			var G__1220000040__8_ uint16 = c__7

			switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000040__8_).Ref()) { case 42: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000040__8_).Ref(), A_arbace_go_embed_A_const_46) {
				jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_42); var tmp4 jrt.Number_I; var na_279 any = i__4; if jrt.Long_InstanceOf(na_279) { var n0_280 int64 = jrt.NN(jrt.Long_Cast(na_279)).LongValue__J(); if n0_280 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_279) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_280 + 1)) } } else { if jrt.Double_InstanceOf(na_279) { var n0_280_2 float64 = jrt.NN(jrt.Double_Cast(na_279)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_280_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_279) } }; i__4 = tmp4; continue L1 }
//line :105:1
			case 63: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000040__8_).Ref(), A_arbace_go_embed_A_const_47) {

				jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_43); var tmp5 jrt.Number_I; var na_281 any = i__4; if jrt.Long_InstanceOf(na_281) { var n0_282 int64 = jrt.NN(jrt.Long_Cast(na_281)).LongValue__J(); if n0_282 == 9223372036854775807 { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_281) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_282 + 1)) } } else { if jrt.Double_InstanceOf(na_281) { var n0_282_2 float64 = jrt.NN(jrt.Double_Cast(na_281)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_282_2 + 1.0)) } else { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_281) } }; i__4 = tmp5; continue L1 }
//line :105:1
			case 91: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000040__8_).Ref(), A_arbace_go_embed_A_const_48) { var end__9 any; var tmp6 any = A_arbace_go_embed_glob_regex_fn__1220000041_A_New_O_I_O(i__4, n__3, p__0); var tmp7 *jrt.Class
				var fncls__228 /*line :105:1*/*jrt.Class = A_arbace_go_embed_glob_regex_fn__1220000041_A_fn_class





				if fncls__228 == nil { var fncls__228d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_embed_glob_regex_fn__1220000041_A_fn_class = fncls__228d; tmp7 = fncls__228d } else { tmp7 = fncls__228 }; end__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()





				if lang.Util_Identical_O_O__Z_NoInit(end__9, nil) { return nil } else { var body__10 any; var root_229 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_231 lang.IFn

					if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = p__0; var arg_233 any; var na_235 any = i__4; if jrt.Long_InstanceOf(na_235) { var n0_236 int64 = jrt.NN(jrt.Long_Cast(na_235)).LongValue__J(); if n0_236 == 9223372036854775807 { arg_233 = lang.Numbers_Inc_O__Number_NoInit(na_235) } else { arg_233 = jrt.Long_ValueOf_J__Long_NoInit(n0_236 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_235) { var n0_236_2 float64 = jrt.NN(jrt.Double_Cast(na_235)).DoubleValue__D(); arg_233 = jrt.Double_ValueOf_D__Double_NoInit(n0_236_2 + 1.0).Ref() } else { arg_233 = lang.Numbers_Inc_O__Number_NoInit(na_235) } }; var arg_234 any = end__9; if linked_230 == nil { body__10 = ifn_231.Invoke_O_O_O__O(arg_232, arg_233, arg_234) } else { body__10 = linked_230.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_229, arg_232, arg_233, arg_234) }
//line :117:1
					var neg__11 any; var root_237 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_239 lang.IFn


					if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = body__10; var arg_241 any = Lit_45; if linked_238 == nil { neg__11 = ifn_239.Invoke_O_O__O(arg_240, arg_241) } else { neg__11 = linked_238.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_237, arg_240, arg_241) }
//line :117:1
					var body__12 any



					if jrt.J2g_Truth(neg__11) { var root_242 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = body__10; var arg_246 any = A_arbace_go_embed_A_const_10; if linked_243 == nil { body__12 = ifn_244.Invoke_O_O__O(arg_245, arg_246) } else { body__12 = linked_243.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_242, arg_245, arg_246) } } else { body__12 = body__10 }
//line :117:1
					var cls__13 any; var root_247 any = A_arbace_go_embed_A_const_52.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_249 lang.IFn




					if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any; var root_251 any = A_arbace_go_embed_A_const_53.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any; var tmp8 any = A_arbace_go_embed_glob_regex_fn__1220000043_A_New(); var tmp9 *jrt.Class; var fncls__265 *jrt.Class = A_arbace_go_embed_glob_regex_fn__1220000043_A_fn_class; if fncls__265 == nil { var fncls__265d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_embed_glob_regex_fn__1220000043_A_fn_class = fncls__265d; tmp9 = fncls__265d } else { tmp9 = fncls__265 }; arg_254 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_255 any; var root_266 any = A_arbace_go_embed_A_const_56.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_268 lang.IFn
					if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = body__12; var arg_270 any = Lit_47; var arg_271 any = Lit_37; if linked_267 == nil { arg_255 = ifn_268.Invoke_O_O_O__O(arg_269, arg_270, arg_271) } else { arg_255 = linked_267.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_266, arg_269, arg_270, arg_271) }
//line :122:1
					if linked_252 == nil { arg_250 = ifn_253.Invoke_O_O__O(arg_254, arg_255) } else { arg_250 = linked_252.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_251, arg_254, arg_255) }; if linked_248 == nil { cls__13 = ifn_249.Invoke_O__O(arg_250) } else { cls__13 = linked_248.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_247, arg_250)
					}
					var tmp10 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_48, nil, nil, nil, Lit_49); var tmp12 *jrt.String; if jrt.J2g_Truth(neg__11) { tmp12 = Lit_45 } else { tmp12 = nil }; var tmp13 any = tmp12.Ref(); var tmp14 *jrt.String; if jrt.J2g_Truth(neg__11) { tmp14 = Lit_26 } else { tmp14 = nil }; jrt.NN(tmp10).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp13, cls__13, tmp14.Ref(), nil)))
					var tmp15 jrt.Number_I; var na_283 any = end__9; if jrt.Long_InstanceOf(na_283) { var n0_284 int64 = jrt.NN(jrt.Long_Cast(na_283)).LongValue__J(); if n0_284 == 9223372036854775807 { tmp15 = lang.Numbers_Inc_O__Number_NoInit(na_283) } else { tmp15 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_284 + 1)) } } else { if jrt.Double_InstanceOf(na_283) { var n0_284_2 float64 = jrt.NN(jrt.Double_Cast(na_283)).DoubleValue__D(); tmp15 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_284_2 + 1.0)) } else { tmp15 = lang.Numbers_Inc_O__Number_NoInit(na_283) } }; i__4 = tmp15; continue L1 } }
//line :105:1
			case 92: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000040__8_).Ref(), A_arbace_go_embed_A_const_14) {


				var tmp16 bool; var na_272 any; var na_274 any = i__4; if jrt.Long_InstanceOf(na_274) { var n0_275 int64 = jrt.NN(jrt.Long_Cast(na_274)).LongValue__J(); if n0_275 == 9223372036854775807 { na_272 = lang.Numbers_Inc_O__Number_NoInit(na_274) } else { na_272 = jrt.Long_ValueOf_J__Long_NoInit(n0_275 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_274) { var n0_275_2 float64 = jrt.NN(jrt.Double_Cast(na_274)).DoubleValue__D(); na_272 = jrt.Double_ValueOf_D__Double_NoInit(n0_275_2 + 1.0).Ref() } else { na_272 = lang.Numbers_Inc_O__Number_NoInit(na_274) } }; var na_273 int64 = int64(n__3); if jrt.Long_InstanceOf(na_272) { var n0_276 int64 = jrt.NN(jrt.Long_Cast(na_272)).LongValue__J(); var n1_277 int64 = na_273; tmp16 = n0_276 < n1_277 } else { tmp16 = lang.Numbers_Lt_O_J__Z_NoInit(na_272, na_273) }; if tmp16 {
					var tmp17 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp18 any; var root_285 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any; var tmp19 *jrt.String = jrt.String_Cast(p__0); var tmp20 jrt.Number_I; var na_289 any = i__4; if jrt.Long_InstanceOf(na_289) { var n0_290 int64 = jrt.NN(jrt.Long_Cast(na_289)).LongValue__J(); if n0_290 == 9223372036854775807 { tmp20 = lang.Numbers_Inc_O__Number_NoInit(na_289) } else { tmp20 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_290 + 1)) } } else { if jrt.Double_InstanceOf(na_289) { var n0_290_2 float64 = jrt.NN(jrt.Double_Cast(na_289)).DoubleValue__D(); tmp20 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_290_2 + 1.0)) } else { tmp20 = lang.Numbers_Inc_O__Number_NoInit(na_289) } }; arg_288 = jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(tmp19).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(tmp20))).Ref(); if linked_286 == nil { tmp18 = ifn_287.Invoke_O__O(arg_288) } else { tmp18 = linked_286.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_285, arg_288) }; jrt.NN(tmp17).Append_String__StringBuilder(jrt.Pattern_Quote_String__String_NoInit(jrt.String_Cast(tmp18))); var tmp21 jrt.Number_I; var na_291 any = i__4; var na_292 int64 = 2; if jrt.Long_InstanceOf(na_291) { var n0_293 int64 = jrt.NN(jrt.Long_Cast(na_291)).LongValue__J(); var n1_294 int64 = na_292; var nr_295 int64 = n0_293 + n1_294; if (n0_293^nr_295)&(n1_294^nr_295) >= 0 { tmp21 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_295)) } else { tmp21 = lang.Numbers_Add_O_J__Number_NoInit(na_291, na_292) } } else { tmp21 = lang.Numbers_Add_O_J__Number_NoInit(na_291, na_292) }; i__4 = tmp21; continue L1 } else {
//line :108:1
						return nil } }
//line :105:1
			default:
			}



















			var tmp22 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp23 any; var root_296 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = jrt.Character_ValueOf_C__Character_NoInit(c__7).Ref(); if linked_297 == nil { tmp23 = ifn_298.Invoke_O__O(arg_299) } else { tmp23 = linked_297.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_296, arg_299) }; jrt.NN(tmp22).Append_String__StringBuilder(jrt.Pattern_Quote_String__String_NoInit(jrt.String_Cast(tmp23))); var tmp24 jrt.Number_I; var na_300 any = i__4; if jrt.Long_InstanceOf(na_300) { var n0_301 int64 = jrt.NN(jrt.Long_Cast(na_300)).LongValue__J(); if n0_301 == 9223372036854775807 { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_300) } else { tmp24 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_301 + 1)) } } else { if jrt.Double_InstanceOf(na_300) { var n0_301_2 float64 = jrt.NN(jrt.Double_Cast(na_300)).DoubleValue__D(); tmp24 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_301_2 + 1.0)) } else { tmp24 = lang.Numbers_Inc_O__Number_NoInit(na_300) } }; i__4 = tmp24; continue L1 } } }; /*line :96:1*/panic("j2g: unreachable") }














func A_arbace_go_embed_glob_regex_fn__1220000041_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_embed_glob_regex_fn__1220000041_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_regex_fn__1220000041_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :111:1
func (t *A_arbace_go_embed_glob_regex_fn__1220000041_A) Ctor_O_I_O(c__i any, c__n int32, c__p any) { t.F_i = c__i; t.F_n = c__n; t.F_p = c__p }
//line :111:1
func (t *A_arbace_go_embed_glob_regex_fn__1220000041_A) Invoke_O__O(self any) any { { var j__1 any; var na_196 any = t.F_i; if jrt.Long_InstanceOf(na_196) { var n0_197 int64 = jrt.NN(jrt.Long_Cast(na_196)).LongValue__J(); if n0_197 == 9223372036854775807 { j__1 = lang.Numbers_Inc_O__Number_NoInit(na_196) } else { j__1 = jrt.Long_ValueOf_J__Long_NoInit(n0_197 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_196) { var n0_197_2 float64 = jrt.NN(jrt.Double_Cast(na_196)).DoubleValue__D(); j__1 = jrt.Double_ValueOf_D__Double_NoInit(n0_197_2 + 1.0).Ref() } else { j__1 = lang.Numbers_Inc_O__Number_NoInit(na_196) } }; L1: for {
											var tmp1 bool; var na_198 any = j__1; var na_199 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_198) { var n0_200 int64 = jrt.NN(jrt.Long_Cast(na_198)).LongValue__J(); var n1_201 int64 = na_199; tmp1 = n0_200 >= n1_201 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_198, na_199) }; if tmp1 { return nil } else { var tmp2 *jrt.String = jrt.String_Cast(t.F_p); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_go_embed_A_const_14)).CharValue__C(), jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))) {
												var tmp3 jrt.Number_I; var na_221 any = j__1; var na_222 int64 = 2; if jrt.Long_InstanceOf(na_221) { var n0_223 int64 = jrt.NN(jrt.Long_Cast(na_221)).LongValue__J(); var n1_224 int64 = na_222; var nr_225 int64 = n0_223 + n1_224; if (n0_223^nr_225)&(n1_224^nr_225) >= 0 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_225)) } else { tmp3 = lang.Numbers_Add_O_J__Number_NoInit(na_221, na_222) } } else { tmp3 = lang.Numbers_Add_O_J__Number_NoInit(na_221, na_222) }; j__1 = tmp3; continue L1 } else {
//line :112:1
			var tmp4 any; var tmp5 *jrt.String = jrt.String_Cast(t.F_p); var and__1927000168__auto____2 bool = lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_go_embed_A_const_49)).CharValue__C(), jrt.NN(tmp5).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1)))

			if and__1927000168__auto____2 { var and__1927000168__auto____3 bool; var na_203 any = j__1; var na_204 any; var na_205 any = t.F_i; if jrt.Long_InstanceOf(na_205) { var n0_206 int64 = jrt.NN(jrt.Long_Cast(na_205)).LongValue__J(); if n0_206 == 9223372036854775807 { na_204 = lang.Numbers_Inc_O__Number_NoInit(na_205) } else { na_204 = jrt.Long_ValueOf_J__Long_NoInit(n0_206 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_205) { var n0_206_2 float64 = jrt.NN(jrt.Double_Cast(na_205)).DoubleValue__D(); na_204 = jrt.Double_ValueOf_D__Double_NoInit(n0_206_2 + 1.0).Ref() } else { na_204 = lang.Numbers_Inc_O__Number_NoInit(na_205) } }; var tmp6 bool; var tmp7 bool; tmp7 = jrt.Long_InstanceOf(na_203); if tmp7 { tmp7 = jrt.Long_InstanceOf(na_204) }; tmp6 = tmp7; if tmp6 { var n0_207 int64 = jrt.NN(jrt.Long_Cast(na_203)).LongValue__J(); var n1_208 int64 = jrt.NN(jrt.Long_Cast(na_204)).LongValue__J(); and__1927000168__auto____3 = n0_207 > n1_208 } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_203); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_204) }; tmp8 = tmp9; if tmp8 { var n0_207_2 float64 = jrt.NN(jrt.Double_Cast(na_203)).DoubleValue__D(); var n1_208_2 float64 = jrt.NN(jrt.Double_Cast(na_204)).DoubleValue__D(); and__1927000168__auto____3 = n1_208_2 < n0_207_2 } else { and__1927000168__auto____3 = lang.Numbers_Gt_O_O__Z_NoInit(na_203, na_204) } }; if and__1927000168__auto____3 {
				var root_210 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any; var and__1927000168__auto____4 bool; var tmp10 jrt.Number_I; var na_214 any = t.F_i; var na_215 int64 = 2; if jrt.Long_InstanceOf(na_214) { var n0_216 int64 = jrt.NN(jrt.Long_Cast(na_214)).LongValue__J(); var n1_217 int64 = na_215; var nr_218 int64 = n0_216 + n1_217; if (n0_216^nr_218)&(n1_217^nr_218) >= 0 { tmp10 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_218)) } else { tmp10 = lang.Numbers_Add_O_J__Number_NoInit(na_214, na_215) } } else { tmp10 = lang.Numbers_Add_O_J__Number_NoInit(na_214, na_215) }; and__1927000168__auto____4 = lang.Util_Equiv_O_O__Z_NoInit(j__1, tmp10); if and__1927000168__auto____4 { var tmp11 uint16 = jrt.NN(jrt.Character_Cast(A_arbace_go_embed_A_const_50)).CharValue__C(); var tmp12 *jrt.String = jrt.String_Cast(t.F_p); var tmp13 jrt.Number_I; var na_219 any = t.F_i; if jrt.Long_InstanceOf(na_219) { var n0_220 int64 = jrt.NN(jrt.Long_Cast(na_219)).LongValue__J(); if n0_220 == 9223372036854775807 { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_219) } else { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_220 + 1)) } } else { if jrt.Double_InstanceOf(na_219) { var n0_220_2 float64 = jrt.NN(jrt.Double_Cast(na_219)).DoubleValue__D(); tmp13 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_220_2 + 1.0)) } else { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_219) } }; arg_213 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_C_C__Z_NoInit(tmp11, jrt.NN(tmp12).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(tmp13)))).Ref() } else { arg_213 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if linked_211 == nil { tmp4 = ifn_212.Invoke_O__O(arg_213) } else { tmp4 = linked_211.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_210, arg_213) } } else {
//line :114:1
					tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }
//line :112:1
			if jrt.J2g_Truth(tmp4) { return j__1 } else { if A_arbace_go_embed_A_const_15 != nil {



				var tmp14 jrt.Number_I; var na_226 any = j__1; if jrt.Long_InstanceOf(na_226) { var n0_227 int64 = jrt.NN(jrt.Long_Cast(na_226)).LongValue__J(); if n0_227 == 9223372036854775807 { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_226) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_227 + 1)) } } else { if jrt.Double_InstanceOf(na_226) { var n0_227_2 float64 = jrt.NN(jrt.Double_Cast(na_226)).DoubleValue__D(); tmp14 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_227_2 + 1.0)) } else { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_226) } }; j__1 = tmp14; continue L1 } else {
//line :112:1
					return nil } } } } } }; /*line :111:1*/panic("j2g: unreachable") }










func A_arbace_go_embed_glob_regex_fn__1220000043_A_New() *A_arbace_go_embed_glob_regex_fn__1220000043_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_regex_fn__1220000043_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_go_embed_glob_regex_fn__1220000043_A) Ctor() {}
//line :122:1
func (t *A_arbace_go_embed_glob_regex_fn__1220000043_A) Invoke_O_O__O(self, ch__1 any) any { var tmp1 any; var root_256 any = A_arbace_go_embed_A_const_54.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = A_arbace_go_embed_A_const_55; var arg_260 any = ch__1; if linked_257 == nil { tmp1 = ifn_258.Invoke_O_O__O(arg_259, arg_260) } else { tmp1 = linked_257.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_256, arg_259, arg_260) }; if jrt.J2g_Truth(tmp1) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, nil, ch__1)).Ref() } else { var root_261 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = ch__1; if linked_262 == nil { return ifn_263.Invoke_O__O(arg_264) } else { return linked_262.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_261, arg_264) } } }





func A_arbace_go_embed_valid_path_QMARK__A_New() *A_arbace_go_embed_valid_path_QMARK__A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_valid_path_QMARK__A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_go_embed_valid_path_QMARK__A) Ctor() {}
//line :128:1
func (t *A_arbace_go_embed_valid_path_QMARK__A) Invoke_O_O__O(self, p__0 any) any { var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(p__0, Lit_2); if or__1927000174__auto____2 {


	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else {
		var root_302 any = A_arbace_go_embed_A_const_57.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any; var tmp1 any = A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A_New(); var tmp2 *jrt.Class; var fncls__316 *jrt.Class = A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A_fn_class; if fncls__316 == nil { var fncls__316d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A_fn_class = fncls__316d; tmp2 = fncls__316d } else { tmp2 = fncls__316 }; arg_305 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_306 any; var root_317 any = A_arbace_go_embed_A_const_59.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = p__0; var arg_321 any = A_arbace_go_embed_A_const_60; var arg_322 any = A_arbace_go_embed_A_const_61; if linked_318 == nil { arg_306 = ifn_319.Invoke_O_O_O__O(arg_320, arg_321, arg_322) } else { arg_306 = linked_318.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_317, arg_320, arg_321, arg_322) }; if linked_303 == nil { return ifn_304.Invoke_O_O__O(arg_305, arg_306) } else { return linked_303.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_302, arg_305, arg_306) } } }
//line :132:1
func A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A_New() *A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A) Ctor() {}
//line :132:1
func (t *A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A) Invoke_O_O__O(self, p1__1220000046_SHARP___1 any) any { var root_307 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any; var root_311 any = A_arbace_go_embed_A_const_54.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any = A_arbace_go_embed_A_const_58; var arg_315 any = p1__1220000046_SHARP___1; if linked_312 == nil { arg_310 = ifn_313.Invoke_O_O__O(arg_314, arg_315) } else { arg_310 = linked_312.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_311, arg_314, arg_315) }; if linked_308 == nil { return ifn_309.Invoke_O__O(arg_310) } else { return linked_308.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_307, arg_310) } }





func A_arbace_go_embed_bad_name_QMARK__A_New() *A_arbace_go_embed_bad_name_QMARK__A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_bad_name_QMARK__A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_go_embed_bad_name_QMARK__A) Ctor() {}
//line :138:1
func (t *A_arbace_go_embed_bad_name_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; var root_323 any = A_arbace_go_embed_A_const_54.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_325 lang.IFn; if



	linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = A_arbace_go_embed_A_const_62; var arg_327 any = n__0; if linked_324 == nil { or__1927000174__auto____2 = ifn_325.Invoke_O_O__O(arg_326, arg_327) } else { or__1927000174__auto____2 = linked_324.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_323, arg_326, arg_327) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_328 any = A_arbace_go_embed_A_const_34.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_330 lang.IFn
		if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any; var tmp1 any = A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A_New(); var tmp2 *jrt.Class; var fncls__346 *jrt.Class = A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A_fn_class; if fncls__346 == nil { var fncls__346d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A_fn_class = fncls__346d; tmp2 = fncls__346d } else { tmp2 = fncls__346 }; arg_331 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_332 any = n__0; if linked_329 == nil { or__1927000174__auto____3 = ifn_330.Invoke_O_O__O(arg_331, arg_332) } else { or__1927000174__auto____3 = linked_329.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_328, arg_331, arg_332) }
//line :142:1
		if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_347 any = A_arbace_go_embed_A_const_54.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_349 lang.IFn

			if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = A_arbace_go_embed_A_const_64.GetRawRoot__O(); var arg_351 any; var root_352 any = A_arbace_go_embed_A_const_65.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, aot_arbace_string.A_arbace_string_upper_case_A_fn_class); var ifn_354 lang.IFn; if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any; var root_356 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any; var root_360 any = A_arbace_go_embed_A_const_59.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = n__0; var arg_364 any = A_arbace_go_embed_A_const_67; var arg_365 any = A_arbace_go_embed_A_const_68; if linked_361 == nil { arg_359 = ifn_362.Invoke_O_O_O__O(arg_363, arg_364, arg_365) } else { arg_359 = linked_361.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_360, arg_363, arg_364, arg_365) }; if linked_357 == nil { arg_355 = ifn_358.Invoke_O__O(arg_359) } else { arg_355 = linked_357.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_356, arg_359) }; if linked_353 == nil { arg_351 = ifn_354.Invoke_O__O(arg_355) } else { arg_351 = linked_353.(*aot_arbace_string.A_arbace_string_upper_case_A).Invoke_O_O__O(root_352, arg_355) }; if linked_348 == nil { or__1927000174__auto____4 = ifn_349.Invoke_O_O__O(arg_350, arg_351) } else { or__1927000174__auto____4 = linked_348.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_347, arg_350, arg_351) }
//line :142:1
			if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {


				var root_366 any = A_arbace_go_embed_A_const_69.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = n__0; var arg_370 any = Lit_2; if linked_367 == nil { return ifn_368.Invoke_O_O__O(arg_369, arg_370) } else { return linked_367.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_366, arg_369, arg_370) } } } } }
//line :143:1
func A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A_New() *A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A) Ctor() {}
//line :143:1
func (t *A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A) Invoke_O_O__O(self, c__1 any) any { var root_333 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any; var or__1927000174__auto____2 bool = jrt.Character_IsLetterOrDigit_C__Z_NoInit(lang.RT_CharCast_O__C_NoInit(c__1)); if or__1927000174__auto____2 { arg_336 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var root_337 any = A_arbace_go_embed_A_const_63.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = Lit_3; var arg_341 any; var root_342 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = c__1; if linked_343 == nil { arg_341 = ifn_344.Invoke_O__O(arg_345) } else { arg_341 = linked_343.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_342, arg_345) }; if linked_338 == nil { arg_336 = ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { arg_336 = linked_338.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_337, arg_340, arg_341) } }; if linked_334 == nil { return ifn_335.Invoke_O__O(arg_336) } else { return linked_334.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_333, arg_336) } }



func A_arbace_go_embed_sorted_children_A_New() *A_arbace_go_embed_sorted_children_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_sorted_children_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_go_embed_sorted_children_A) Ctor() {}
//line :147:1
func (t *A_arbace_go_embed_sorted_children_A) Invoke_O_O__O(self, d__0 any) any {
	var root_371 any = A_arbace_go_embed_A_const_70.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any; var tmp1 any = A_arbace_go_embed_sorted_children_fn__1220000054_A_New(); var tmp2 *jrt.Class; var fncls__376 *jrt.Class = A_arbace_go_embed_sorted_children_fn__1220000054_A_fn_class; if fncls__376 == nil { var fncls__376d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_go_embed_sorted_children_fn__1220000054_A_fn_class = fncls__376d; tmp2 = fncls__376d } else { tmp2 = fncls__376 }; arg_374 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_375 any; var root_377 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_377, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_379 lang.IFn; if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; var arg_380 any = jrt.NN(jrt.File_Cast(d__0)).ListFiles__File1().Ref(); if linked_378 == nil { arg_375 = ifn_379.Invoke_O__O(arg_380) } else { arg_375 = linked_378.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_377, arg_380) }; if linked_372 == nil { return ifn_373.Invoke_O_O__O(arg_374, arg_375) } else { return linked_372.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_371, arg_374, arg_375) } }
//line :148:1
func A_arbace_go_embed_sorted_children_fn__1220000054_A_New() *A_arbace_go_embed_sorted_children_fn__1220000054_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_sorted_children_fn__1220000054_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_go_embed_sorted_children_fn__1220000054_A) Ctor() {}
//line :148:1
func (t *A_arbace_go_embed_sorted_children_fn__1220000054_A) Invoke_O_O__O(self, p1__1220000053_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1220000053_SHARP___1)).GetName__String().Ref() }

func A_arbace_go_embed_glob_A_New() *A_arbace_go_embed_glob_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_go_embed_glob_A) Ctor() {}
//line :150:1
func (t *A_arbace_go_embed_glob_A) Invoke_O_O_O__O(self, dir__0, glob__1 any) any { var segs__3 any; var root_381 any = A_arbace_go_embed_A_const_59.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_383 lang.IFn; if



	linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = glob__1; var arg_385 any = A_arbace_go_embed_A_const_72; if linked_382 == nil { segs__3 = ifn_383.Invoke_O_O__O(arg_384, arg_385) } else { segs__3 = linked_382.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_381, arg_384, arg_385) }; var rxs__4 any; var root_386 any = /*line :150:1*/A_arbace_go_embed_A_const_53.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_388 lang.IFn; if




	linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any; var tmp1 any = A_arbace_go_embed_glob_fn__1220000059_A_New(); var tmp2 *jrt.Class; var fncls__400 *jrt.Class = A_arbace_go_embed_glob_fn__1220000059_A_fn_class; if fncls__400 == nil { var fncls__400d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_go_embed_glob_fn__1220000059_A_fn_class = fncls__400d; tmp2 = fncls__400d } else { tmp2 = fncls__400 }; arg_389 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_390 any = segs__3; if linked_387 == nil { rxs__4 = ifn_388.Invoke_O_O__O(arg_389, arg_390) } else { rxs__4 = linked_387.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_386, arg_389, arg_390) }; var tmp3 any; var root_401 any =
	A_arbace_go_embed_A_const_34.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any; var tmp4 any = A_arbace_go_embed_glob_fn__1220000062_A_New(); var tmp5 *jrt.Class; var fncls__411 *jrt.Class = A_arbace_go_embed_glob_fn__1220000062_A_fn_class; if fncls__411 == nil { var fncls__411d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_embed_glob_fn__1220000062_A_fn_class = fncls__411d; tmp5 = fncls__411d } else { tmp5 = fncls__411 }; arg_404 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_405 any; var root_412 any = A_arbace_go_embed_A_const_53.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = A_arbace_go_embed_A_const_77.GetRawRoot__O(); var arg_416 any = segs__3; var arg_417 any = rxs__4; if linked_413 == nil { arg_405 = ifn_414.Invoke_O_O_O__O(arg_415, arg_416, arg_417) } else { arg_405 = linked_413.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_412, arg_415, arg_416, arg_417) }; if linked_402 == nil { tmp3 = ifn_403.Invoke_O_O__O(arg_404, arg_405) } else { tmp3 = linked_402.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_401, arg_404, arg_405) }; if jrt.J2g_Truth(tmp3) { return nil } else {
		var root_418 any = A_arbace_go_embed_A_const_39.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any; var tmp6 any = A_arbace_go_embed_glob_fn__1220000068_A_New_O(dir__0); var tmp7 *jrt.Class; var fncls__533 *jrt.Class = A_arbace_go_embed_glob_fn__1220000068_A_fn_class; if fncls__533 == nil { var fncls__533d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_embed_glob_fn__1220000068_A_fn_class = fncls__533d; tmp7 = fncls__533d } else { tmp7 = fncls__533 }; arg_421 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_422 any = A_arbace_go_embed_A_const_92; var arg_423 any; var root_534 any = A_arbace_go_embed_A_const_53.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_536 lang.IFn







		if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = A_arbace_go_embed_A_const_77.GetRawRoot__O(); var arg_538 any = segs__3; var arg_539 any = rxs__4; if linked_535 == nil { arg_423 = ifn_536.Invoke_O_O_O__O(arg_537, arg_538, arg_539) } else { arg_423 = linked_535.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_534, arg_537, arg_538, arg_539) }
//line :157:1
		if linked_419 == nil { return ifn_420.Invoke_O_O_O__O(arg_421, arg_422, arg_423) } else { return linked_419.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_418, arg_421, arg_422, arg_423) } } }
//line :155:1
func A_arbace_go_embed_glob_fn__1220000059_A_New() *A_arbace_go_embed_glob_fn__1220000059_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000059_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_go_embed_glob_fn__1220000059_A) Ctor() {}
//line :155:1
func (t *A_arbace_go_embed_glob_fn__1220000059_A) Invoke_O_O__O(self, p1__1220000057_SHARP___1 any) any { var tmp1 any; var root_391 any = A_arbace_go_embed_A_const_73.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = A_arbace_go_embed_A_const_74; var arg_395 any = p1__1220000057_SHARP___1; if linked_392 == nil { tmp1 = ifn_393.Invoke_O_O__O(arg_394, arg_395) } else { tmp1 = linked_392.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_391, arg_394, arg_395) }; if jrt.J2g_Truth(tmp1) { var root_396 any = A_arbace_go_embed_A_const_75.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, A_arbace_go_embed_glob_regex_A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = p1__1220000057_SHARP___1; if linked_397 == nil { return ifn_398.Invoke_O__O(arg_399) } else { return linked_397.(*A_arbace_go_embed_glob_regex_A).Invoke_O_O__O(root_396, arg_399) } } else { return nil } }
func A_arbace_go_embed_glob_fn__1220000062_A_New() *A_arbace_go_embed_glob_fn__1220000062_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000062_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_go_embed_glob_fn__1220000062_A) Ctor() {}
//line :156:1
func (t *A_arbace_go_embed_glob_fn__1220000062_A) Invoke_O_O__O(self, p__1220000061__1 any) any { var vec__1220000063__2 any = p__1220000061__1; var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000063__2, lang.RT_IntCast_J__I_NoInit(0), nil); var rx__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000063__2, lang.RT_IntCast_J__I_NoInit(1), nil); var and__1927000168__auto____5 any; var root_406 any = A_arbace_go_embed_A_const_73.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = A_arbace_go_embed_A_const_76; var arg_410 any = s__3; if linked_407 == nil { and__1927000168__auto____5 = ifn_408.Invoke_O_O__O(arg_409, arg_410) } else { and__1927000168__auto____5 = linked_407.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_406, arg_409, arg_410) }; if jrt.J2g_Truth(and__1927000168__auto____5) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(rx__4, nil)).Ref() } else { return and__1927000168__auto____5 } }
func A_arbace_go_embed_glob_fn__1220000068_A_New_O(p0 any) *A_arbace_go_embed_glob_fn__1220000068_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000068_A{}; t.Ctor_O(p0); return t }
//line :157:1
func (t *A_arbace_go_embed_glob_fn__1220000068_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :157:1
func (t *A_arbace_go_embed_glob_fn__1220000068_A) Invoke_O_O_O__O(self, paths__1, p__1220000067__2 any) any { var vec__1220000069__3 any = p__1220000067__2; var s__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000069__3, lang.RT_IntCast_J__I_NoInit(0), nil); var rx__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000069__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_424 any = A_arbace_go_embed_A_const_78.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_426 lang.IFn; if
														linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any; var iter__1927001039__auto____6 any; var tmp1 any = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A_New_O_O_O(rx__5, t.F_dir, s__4); var tmp2 *jrt.Class; var fncls__532 *jrt.Class = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A_fn_class; if fncls__532 == nil { var fncls__532d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A_fn_class = fncls__532d; tmp2 = fncls__532d } else { tmp2 = fncls__532 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_427 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(paths__1); if linked_425 == nil { return ifn_426.Invoke_O__O(arg_427) } else { return linked_425.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_424, arg_427) } }
//line :158:1
func A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A) Ctor_O_O_O(c__rx, c__dir, c__s any) { t.F_rx = c__rx; t.F_dir = c__dir; t.F_s = c__s }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A) Invoke_O_O__O(self, s__1220000073__1 any) any { var tmp1 any = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A_New_O_O_O_O_O(t.F_rx, t.F_dir, s__1220000073__1, t.F_s, self); var tmp2 *jrt.Class; var fncls__531 *jrt.Class = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A_fn_class; if fncls__531 == nil { var fncls__531d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A_fn_class = fncls__531d; tmp2 = fncls__531d } else { tmp2 = fncls__531 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :158:1
func A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A) Ctor_O_O_O_O_O(c__rx, c__dir, c__s__1220000073, c__s, c__iter__1220000072 any) { t.F_rx = c__rx; t.F_dir = c__dir; t.F_s__1220000073 = c__s__1220000073; t.F_s = c__s; t.F_iter__1220000072 = c__iter__1220000072 }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A) Invoke_O__O(self any) any { { var s__1220000073__1 any; var t_ any = t.F_s__1220000073; t.F_s__1220000073 = nil; s__1220000073__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_428 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = s__1220000073__1; if linked_429 == nil { temp__1927000414__auto____2 = ifn_430.Invoke_O__O(arg_431) } else { temp__1927000414__auto____2 = linked_429.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_428, arg_431) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var p__4 any; var root_432 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = xs__1927001018__auto____3; if linked_433 == nil { p__4 = ifn_434.Invoke_O__O(arg_435) } else { p__4 = linked_433.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_432, arg_435) }; var f__5 any
															if lang.Util_Equiv_O_O__Z_NoInit(p__4, Lit_37) { f__5 = t.F_dir } else { var tmp1 *jrt.File = jrt.File_Cast(t.F_dir); f__5 = jrt.File_New_File_String(tmp1, jrt.String_Cast(p__4)) }
//line :158:1
	if jrt.NN(jrt.File_Cast(f__5)).IsDirectory__Z() { var iterys__1927001035__auto____6 any; var tmp2 any = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A_New_O(p__4); var tmp3 *jrt.Class; var fncls__494 *jrt.Class = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A_fn_class; if fncls__494 == nil { var fncls__494d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A_fn_class = fncls__494d; tmp3 = fncls__494d } else { tmp3 = fncls__494 }; iterys__1927001035__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var fs__1927001036__auto____7 any; var root_495 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____6); var tmp5 any


		if jrt.J2g_Truth(t.F_rx) {
			var root_499 any = A_arbace_go_embed_A_const_88.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any; var tmp6 any = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A_New_O(t.F_rx); var tmp7 *jrt.Class; var fncls__509 *jrt.Class = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A_fn_class; if fncls__509 == nil { var fncls__509d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A_fn_class = fncls__509d; tmp7 = fncls__509d } else { tmp7 = fncls__509 }; arg_502 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_503 any; var root_510 any = A_arbace_go_embed_A_const_90.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, A_arbace_go_embed_sorted_children_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = f__5; if linked_511 == nil { arg_503 = ifn_512.Invoke_O__O(arg_513) } else { arg_503 = linked_511.(*A_arbace_go_embed_sorted_children_A).Invoke_O_O__O(root_510, arg_513) }; if linked_500 == nil { tmp5 = ifn_501.Invoke_O_O__O(arg_502, arg_503) } else { tmp5 = linked_500.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_499, arg_502, arg_503) } } else {
//line :161:1
				var c__7 any = jrt.File_New_File_String(jrt.File_Cast(f__5), jrt.String_Cast(t.F_s))

				if jrt.NN(jrt.File_Cast(c__7)).Exists__Z() { tmp5 = lang.Tuple_Create_O__IPersistentVector(c__7) } else { tmp5 = nil } }
//line :158:1
		arg_498 = tmp4.Invoke_O__O(tmp5); if linked_496 == nil { fs__1927001036__auto____7 = ifn_497.Invoke_O__O(arg_498) } else { fs__1927001036__auto____7 = linked_496.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_495, arg_498) }; if jrt.J2g_Truth(fs__1927001036__auto____7) { var root_514 any = A_arbace_go_embed_A_const_91.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = fs__1927001036__auto____7; var arg_518 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1220000072); var tmp9 any; var root_519 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = s__1220000073__1; if linked_520 == nil { tmp9 = ifn_521.Invoke_O__O(arg_522) } else { tmp9 = linked_520.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_519, arg_522) }; arg_518 = tmp8.Invoke_O__O(tmp9); if linked_515 == nil { return ifn_516.Invoke_O_O__O(arg_517, arg_518) } else { return linked_515.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_514, arg_517, arg_518) } } else { var tmp10 any; var root_523 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = s__1220000073__1; if linked_524 == nil { tmp10 = ifn_525.Invoke_O__O(arg_526) } else { tmp10 = linked_524.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_523, arg_526) }; s__1220000073__1 = tmp10; continue L1 } } else { var tmp11 any; var root_527 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any = s__1220000073__1; if linked_528 == nil { tmp11 = ifn_529.Invoke_O__O(arg_530) } else { tmp11 = linked_528.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_527, arg_530) }; s__1220000073__1 = tmp11; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :158:1
func A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A_New_O(p0 any) *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A{}; t.Ctor_O(p0); return t }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A) Ctor_O(c__p any) { t.F_p = c__p }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A) Invoke_O_O__O(self, s__1220000075__1 any) any { var tmp1 any = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A_New_O_O_O(t.F_p, s__1220000075__1, self); var tmp2 *jrt.Class; var fncls__493 *jrt.Class = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A_fn_class; if fncls__493 == nil { var fncls__493d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A_fn_class = fncls__493d; tmp2 = fncls__493d } else { tmp2 = fncls__493 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :158:1
func A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A) Ctor_O_O_O(c__p, c__s__1220000075, c__iter__1220000074 any) { t.F_p = c__p; t.F_s__1220000075 = c__s__1220000075; t.F_iter__1220000074 = c__iter__1220000074 }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A) Invoke_O__O(self any) any { { var s__1220000075__1 any; var t_ any = t.F_s__1220000075; t.F_s__1220000075 = nil; s__1220000075__1 = t_; for { var temp__1927000414__auto____2 any; var root_436 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = s__1220000075__1; if linked_437 == nil { temp__1927000414__auto____2 = ifn_438.Invoke_O__O(arg_439) } else { temp__1927000414__auto____2 = linked_437.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_436, arg_439) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1220000075__3 any = temp__1927000414__auto____2; var tmp1 any; var root_440 any = A_arbace_go_embed_A_const_79.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = s__1220000075__3; if linked_441 == nil { tmp1 = ifn_442.Invoke_O__O(arg_443) } else { tmp1 = linked_441.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_440, arg_443) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_444 any = A_arbace_go_embed_A_const_80.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = s__1220000075__3; if linked_445 == nil { c__1927001037__auto____4 = ifn_446.Invoke_O__O(arg_447) } else { c__1927001037__auto____4 = linked_445.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_444, arg_447) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1220000077__6 any; var root_448 any = A_arbace_go_embed_A_const_81.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_449 == nil { b__1220000077__6 = ifn_450.Invoke_O__O(arg_451) } else { b__1220000077__6 = linked_449.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_448, arg_451) }; var tmp2 any = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A_New_O_O_I_O(t.F_p, b__1220000077__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__457 *jrt.Class = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A_fn_class; if fncls__457 == nil { var fncls__457d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A_fn_class = fncls__457d; tmp3 = fncls__457d } else { tmp3 = fncls__457 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_458 any = A_arbace_go_embed_A_const_83.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any; var root_463 any = A_arbace_go_embed_A_const_84.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = b__1220000077__6; if linked_464 == nil { arg_461 = ifn_465.Invoke_O__O(arg_466) } else { arg_461 = linked_464.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_463, arg_466) }; var arg_462 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1220000074); var tmp5 any; var root_467 any = A_arbace_go_embed_A_const_85.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = s__1220000075__3; if linked_468 == nil { tmp5 = ifn_469.Invoke_O__O(arg_470) } else { tmp5 = linked_468.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_467, arg_470) }; arg_462 = tmp4.Invoke_O__O(tmp5); if linked_459 == nil { return ifn_460.Invoke_O_O__O(arg_461, arg_462) } else { return linked_459.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_458, arg_461, arg_462) } } else { var root_471 any = A_arbace_go_embed_A_const_83.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any; var root_476 any = A_arbace_go_embed_A_const_84.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any = b__1220000077__6; if linked_477 == nil { arg_474 = ifn_478.Invoke_O__O(arg_479) } else { arg_474 = linked_477.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_476, arg_479) }; var arg_475 any; if linked_472 == nil { return ifn_473.Invoke_O_O__O(arg_474, arg_475) } else { return linked_472.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_471, arg_474, arg_475) } } } else { var c__4 any; var root_480 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = s__1220000075__3; if linked_481 == nil { c__4 = ifn_482.Invoke_O__O(arg_483) } else { c__4 = linked_481.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_480, arg_483) }; var root_484 any = A_arbace_go_embed_A_const_86.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any





	if lang.Util_Equiv_O_O__Z_NoInit(t.F_p, Lit_37) { arg_487 = jrt.NN(jrt.File_Cast(c__4)).GetName__String().Ref() } else { var tmp6 any = t.F_p; arg_487 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, tmp6, nil, jrt.NN(jrt.File_Cast(c__4)).GetName__String().Ref())).Ref() }
//line :158:1
	var arg_488 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1220000074); var tmp8 any; var root_489 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = s__1220000075__3; if linked_490 == nil { tmp8 = ifn_491.Invoke_O__O(arg_492) } else { tmp8 = linked_490.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_489, arg_492) }; arg_488 = tmp7.Invoke_O__O(tmp8); if linked_485 == nil { return ifn_486.Invoke_O_O__O(arg_487, arg_488) } else { return linked_485.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_484, arg_487, arg_488) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :158:1
func A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A) Ctor_O_O_I_O(c__p, c__b__1220000077 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_p = c__p; t.F_b__1220000077 = c__b__1220000077; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A) Invoke_O__O(self any) any { { var i__1220000076__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1220000076__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1220000076__1)); var root_452 any = A_arbace_go_embed_A_const_82.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = t.F_b__1220000077; var arg_456 any





	if lang.Util_Equiv_O_O__Z_NoInit(t.F_p, Lit_37) { arg_456 = jrt.NN(jrt.File_Cast(c__2)).GetName__String().Ref() } else { var tmp2 any = t.F_p; arg_456 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, tmp2, nil, jrt.NN(jrt.File_Cast(c__2)).GetName__String().Ref())).Ref() }
//line :158:1
	if linked_453 == nil { ifn_454.Invoke_O_O__O(arg_455, arg_456) } else { linked_453.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_452, arg_455, arg_456) }; i__1220000076__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1220000076__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A_New_O(p0 any) *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A{}; t.Ctor_O(p0); return t }
//line :162:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A) Ctor_O(c__rx any) { t.F_rx = c__rx }
//line :162:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A) Invoke_O_O__O(self, p1__1220000058_SHARP___1 any) any { var root_504 any = A_arbace_go_embed_A_const_89.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = t.F_rx; var arg_508 any = jrt.NN(jrt.File_Cast(p1__1220000058_SHARP___1)).GetName__String().Ref(); if linked_505 == nil { return ifn_506.Invoke_O_O__O(arg_507, arg_508) } else { return linked_505.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_504, arg_507, arg_508) } }




func A_arbace_go_embed_embed_error_A_New() *A_arbace_go_embed_embed_error_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_embed_error_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_go_embed_embed_error_A) Ctor() {}
//line :167:1
func (t *A_arbace_go_embed_embed_error_A) Invoke_O_O_O__O(self, pattern__0, msg__1 any) any { var tmp1 any; var root_540 any = A_arbace_go_embed_A_const_93.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_542 lang.IFn; if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, pattern__0, nil, msg__1)).Ref(); var arg_544 any = A_arbace_go_embed_A_const_94; if linked_541 == nil { tmp1 = ifn_542.Invoke_O_O__O(arg_543, arg_544) } else { tmp1 = linked_541.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_540, arg_543, arg_544) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }

func A_arbace_go_embed_resolve_pattern_A_New() *A_arbace_go_embed_resolve_pattern_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_resolve_pattern_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_go_embed_resolve_pattern_A) Ctor() {}
//line :169:1
func (t *A_arbace_go_embed_resolve_pattern_A) Invoke_O_O_O__O(self, dir__0, pattern__1 any) any { var vec__1220000093__3 any; var tmp1 any; var root_545 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_547 lang.IFn; if



	linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = pattern__1; var arg_549 any = Lit_54; if linked_546 == nil { tmp1 = ifn_547.Invoke_O_O__O(arg_548, arg_549) } else { tmp1 = linked_546.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_545, arg_548, arg_549) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = jrt.Boolean_TRUE.Ref(); var tmp3 any; var root_603 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = pattern__1; var arg_607 any = A_arbace_go_embed_A_const_101; if linked_604 == nil { tmp3 = ifn_605.Invoke_O_O__O(arg_606, arg_607) } else { tmp3 = linked_604.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_603, arg_606, arg_607) }; vec__1220000093__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) } else { vec__1220000093__3 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Boolean_FALSE.Ref(), pattern__1) }; var all__4 any = /*line :169:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1220000093__3, lang.RT_IntCast_J__I_NoInit(0), nil); var glob_p__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000093__3, lang.RT_IntCast_J__I_NoInit(1), nil); var ___6 any; var tmp4 any; var or__1927000174__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(glob_p__5, Lit_2); _ = ___6; if or__1927000174__auto____6 {




		tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 any; var root_550 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any; var root_554 any = A_arbace_go_embed_A_const_95.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, A_arbace_go_embed_valid_path_QMARK__A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any = glob_p__5; if linked_555 == nil { arg_553 = ifn_556.Invoke_O__O(arg_557) } else { arg_553 = linked_555.(*A_arbace_go_embed_valid_path_QMARK__A).Invoke_O_O__O(root_554, arg_557) }; if linked_551 == nil { or__1927000174__auto____7 = ifn_552.Invoke_O__O(arg_553) } else { or__1927000174__auto____7 = linked_551.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_550, arg_553) }; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp4 = or__1927000174__auto____7 } else { var or__1927000174__auto____8 any; var root_558 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_560 lang.IFn; if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = glob_p__5; var arg_562 any = Lit_26; if linked_559 == nil { or__1927000174__auto____8 = ifn_560.Invoke_O_O__O(arg_561, arg_562) } else { or__1927000174__auto____8 = linked_559.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_558, arg_561, arg_562) }; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp4 = or__1927000174__auto____8 } else { var or__1927000174__auto____9 any; var root_563 any = A_arbace_go_embed_A_const_69.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = glob_p__5; var arg_567 any = Lit_26; if linked_564 == nil { or__1927000174__auto____9 = ifn_565.Invoke_O_O__O(arg_566, arg_567) } else { or__1927000174__auto____9 = linked_564.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_563, arg_566, arg_567) }; if jrt.J2g_Truth(or__1927000174__auto____9) { tmp4 = or__1927000174__auto____9 } else {
			tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_37, glob_p__5)).Ref() } } } }; if /*line :174:1*/ jrt.J2g_Truth(tmp4) {

				var root_568 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, A_arbace_go_embed_embed_error_A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = pattern__1; var arg_572 any = Lit_55; if linked_569 == nil { ___6 = ifn_570.Invoke_O_O__O(arg_571, arg_572) } else { ___6 = linked_569.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_568, arg_571, arg_572) } } else {
//line :174:1
					___6 = nil }; var matches__7 any; var root_573 any = /*line :169:1*/A_arbace_go_embed_A_const_97.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, A_arbace_go_embed_glob_A_fn_class); var ifn_575 lang.IFn; if







	linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = dir__0; var arg_577 any = glob_p__5; if linked_574 == nil { matches__7 = ifn_575.Invoke_O_O__O(arg_576, arg_577) } else { matches__7 = linked_574.(*A_arbace_go_embed_glob_A).Invoke_O_O_O__O(root_573, arg_576, arg_577) }; var ___8 any; _ = ___8; if
	lang.Util_Identical_O_O__Z_NoInit(matches__7, nil) { var root_578 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, A_arbace_go_embed_embed_error_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any = pattern__1; var arg_582 any = Lit_55; if linked_579 == nil { ___8 = ifn_580.Invoke_O_O__O(arg_581, arg_582) } else { ___8 = linked_579.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_578, arg_581, arg_582) } } else { ___8 = nil }; var list__9 any; var root_583 any = /*line :169:1*/A_arbace_go_embed_A_const_98.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_585 lang.IFn; if









	linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = lang.PersistentVector_EMPTY.Ref(); if linked_584 == nil { list__9 = ifn_585.Invoke_O__O(arg_586) } else { list__9 = linked_584.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_583, arg_586) }; var seq_1220000096__10 any; var root_608 any = /*line :169:1*/A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_608, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_610 lang.IFn; if










	linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any = matches__7; if linked_609 == nil { seq_1220000096__10 = ifn_610.Invoke_O__O(arg_611) } else { seq_1220000096__10 = linked_609.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_608, arg_611) }; var chunk_1220000097__11 any; var count_1220000098__12 int64 = 0; var i_1220000099__13 int64 = 0; L1:
//line :169:1
	for {










		if lang.Numbers_Lt_J_J__Z_NoInit(i_1220000099__13, count_1220000098__12) { var rel__14 any = lang.Indexed_Cast(chunk_1220000097__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1220000099__13)); var f__15 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), jrt.String_Cast(rel__14)); var what__16 any

			if jrt.NN(jrt.File_Cast(f__15)).IsDirectory__Z() { what__16 = Lit_56 } else { what__16 = Lit_57 }
//line :180:1
			var segs__17 any; var root_666 any = A_arbace_go_embed_A_const_59.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_668 lang.IFn



			if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any = rel__14; var arg_670 any = A_arbace_go_embed_A_const_102; if linked_667 == nil { segs__17 = ifn_668.Invoke_O_O__O(arg_669, arg_670) } else { segs__17 = linked_667.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_666, arg_669, arg_670) }
//line :180:1
			var acc__18 any = lang.PersistentVector_EMPTY.Ref(); L2: for {




				var tmp5 any; var root_671 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = segs__17; if linked_672 == nil { tmp5 = ifn_673.Invoke_O__O(arg_674) } else { tmp5 = linked_672.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_671, arg_674) }; if jrt.J2g_Truth(tmp5) { var d__19 any; var root_675 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_677 lang.IFn
					if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = acc__18; var arg_679 any; var root_680 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any = segs__17; if linked_681 == nil { arg_679 = ifn_682.Invoke_O__O(arg_683) } else { arg_679 = linked_681.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_680, arg_683) }; if linked_676 == nil { d__19 = ifn_677.Invoke_O_O__O(arg_678, arg_679) } else { d__19 = linked_676.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_675, arg_678, arg_679) }
//line :185:1
					var dp__20 any; var root_684 any = A_arbace_go_embed_A_const_52.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_686 lang.IFn

					if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = Lit_26; var arg_688 any = d__19; if linked_685 == nil { dp__20 = ifn_686.Invoke_O_O__O(arg_687, arg_688) } else { dp__20 = linked_685.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_684, arg_687, arg_688) }
//line :185:1
					var df__21 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), jrt.String_Cast(dp__20))



					if jrt.File_New_File_String(jrt.File_Cast(df__21), Lit_58).IsFile__Z() {
						var root_689 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, A_arbace_go_embed_embed_error_A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any = pattern__1; var arg_693 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_60, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, what__16, nil, rel__14, nil)).Ref(); if linked_690 == nil { ifn_691.Invoke_O_O__O(arg_692, arg_693) } else { linked_690.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_689, arg_692, arg_693) } }
					var tmp6 any; var root_694 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any; var root_698 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = segs__17; if linked_699 == nil { arg_697 = ifn_700.Invoke_O__O(arg_701) } else { arg_697 = linked_699.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_698, arg_701) }; if linked_695 == nil { tmp6 = ifn_696.Invoke_O__O(arg_697) } else { tmp6 = linked_695.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_694, arg_697) }; if jrt.J2g_Truth(tmp6) {
						var root_702 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, A_arbace_go_embed_embed_error_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = pattern__1; var arg_706 any; if lang.Util_Equiv_O_O__Z_NoInit(dp__20, rel__14) {
							var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_60, nil, Lit_62, nil); var tmp8 any; var root_707 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = segs__17; if linked_708 == nil { tmp8 = ifn_709.Invoke_O__O(arg_710) } else { tmp8 = linked_708.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_707, arg_710) }; arg_706 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, what__16, nil, rel__14, nil, tmp8)).Ref() } else {
								var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_60, nil, Lit_63, nil); var tmp10 any; var root_711 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = segs__17; if linked_712 == nil { tmp10 = ifn_713.Invoke_O__O(arg_714) } else { tmp10 = linked_712.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_711, arg_714) }; arg_706 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, what__16, nil, rel__14, nil, tmp10)).Ref() }
//line :192:1
						if linked_703 == nil { ifn_704.Invoke_O_O__O(arg_705, arg_706) } else { linked_703.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_702, arg_705, arg_706)
						}
					}
					var tmp11 any; var root_715 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = segs__17; if linked_716 == nil { tmp11 = ifn_717.Invoke_O__O(arg_718) } else { tmp11 = linked_716.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_715, arg_718) }; segs__17, acc__18 = tmp11, d__19; continue L2 }
//line :180:1
				break L2
			}














			if jrt.NN(jrt.File_Cast(f__15)).IsFile__Z() {
				var tmp12 *lang.Volatile = lang.Volatile_Cast(list__9); var tmp13 any; var root_641 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_641, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_643 lang.IFn; if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = jrt.NN(lang.Volatile_Cast(list__9)).Deref__O(); var arg_645 any = rel__14; if linked_642 == nil { tmp13 = ifn_643.Invoke_O_O__O(arg_644, arg_645) } else { tmp13 = linked_642.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_641, arg_644, arg_645) }; jrt.NN(tmp12).Reset_O__O(tmp13) } else {
//line :196:1
					if jrt.NN(jrt.File_Cast(f__15)).IsDirectory__Z() { var n__17 any; var root_646 any = A_arbace_go_embed_A_const_98.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_648 lang.IFn


						if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = A_arbace_go_embed_A_const_31; if linked_647 == nil { n__17 = ifn_648.Invoke_O__O(arg_649) } else { n__17 = linked_647.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_646, arg_649) }
//line :196:1
						var body_walk__18 *A_arbace_go_embed_resolve_pattern_walk__1220000100_A = A_arbace_go_embed_resolve_pattern_walk__1220000100_A_New_O_O_O_O(pattern__1, list__9, all__4, n__17); var walk__18 any; var tmp14 *jrt.Class; var fncls__847 *jrt.Class = A_arbace_go_embed_resolve_pattern_walk__1220000100_A_fn_class; if fncls__847 == nil { var fncls__847d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_go_embed_resolve_pattern_walk__1220000100_A_fn_class = fncls__847d; tmp14 = fncls__847d } else { tmp14 = fncls__847 }; walk__18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__18), tmp14, nil)












						lang.IFn_Cast(walk__18).Invoke_O_O__O(f__15, rel__14)
						var tmp15 bool; var na_650 any; var root_651 any = A_arbace_go_embed_A_const_5.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = n__17; if linked_652 == nil { na_650 = ifn_653.Invoke_O__O(arg_654) } else { na_650 = linked_652.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_651, arg_654) }; if jrt.Long_InstanceOf(na_650) { var n0_655 int64 = jrt.NN(jrt.Long_Cast(na_650)).LongValue__J(); tmp15 = n0_655 == 0 } else { if jrt.Double_InstanceOf(na_650) { var n0_655_2 float64 = jrt.NN(jrt.Double_Cast(na_650)).DoubleValue__D(); tmp15 = n0_655_2 == 0.0 } else { tmp15 = lang.Numbers_IsZero_O__Z_NoInit(na_650) } }; if tmp15 {
							var root_656 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, A_arbace_go_embed_embed_error_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = pattern__1; var arg_660 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_65, nil, Lit_66), jrt.RefArrayOf(jrt.Object_class, nil, rel__14, nil)).Ref(); if linked_657 == nil { ifn_658.Invoke_O_O__O(arg_659, arg_660) } else { linked_657.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_656, arg_659, arg_660) } } } else {
//line :196:1
								if A_arbace_go_embed_A_const_15 != nil {















									var root_661 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, A_arbace_go_embed_embed_error_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = pattern__1; var arg_665 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__14)).Ref(); if linked_662 == nil { ifn_663.Invoke_O_O__O(arg_664, arg_665) } else { linked_662.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_661, arg_664, arg_665) } } } }
//line :180:1
			seq_1220000096__10, chunk_1220000097__11, count_1220000098__12, i_1220000099__13 = seq_1220000096__10, chunk_1220000097__11, count_1220000098__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1220000099__13); continue L1 } else { var temp__1927000414__auto____14 any; var root_612 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = seq_1220000096__10; if linked_613 == nil { temp__1927000414__auto____14 = ifn_614.Invoke_O__O(arg_615) } else { temp__1927000414__auto____14 = linked_613.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_612, arg_615) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_1220000096__15 any = temp__1927000414__auto____14; var tmp16 any; var root_616 any = A_arbace_go_embed_A_const_79.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any = seq_1220000096__15; if linked_617 == nil { tmp16 = ifn_618.Invoke_O__O(arg_619) } else { tmp16 = linked_617.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_616, arg_619) }; if jrt.J2g_Truth(tmp16) { var c__1927000678__auto____16 any; var root_620 any = A_arbace_go_embed_A_const_80.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any = seq_1220000096__15; if linked_621 == nil { c__1927000678__auto____16 = ifn_622.Invoke_O__O(arg_623) } else { c__1927000678__auto____16 = linked_621.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_620, arg_623) }; var tmp17 any; var root_848 any = A_arbace_go_embed_A_const_85.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = seq_1220000096__15; if linked_849 == nil { tmp17 = ifn_850.Invoke_O__O(arg_851) } else { tmp17 = linked_849.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_848, arg_851) }; seq_1220000096__10, chunk_1220000097__11, count_1220000098__12, i_1220000099__13 = tmp17, c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var rel__16 any; var root_624 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = seq_1220000096__15; if linked_625 == nil { rel__16 = ifn_626.Invoke_O__O(arg_627) } else { rel__16 = linked_625.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_624, arg_627) }; var f__17 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), jrt.String_Cast(rel__16)); var what__18 any

				if jrt.NN(jrt.File_Cast(f__17)).IsDirectory__Z() { what__18 = Lit_56 } else { what__18 = Lit_57 }
//line :180:1
				var segs__19 any; var root_877 any = A_arbace_go_embed_A_const_59.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_879 lang.IFn



				if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = rel__16; var arg_881 any = A_arbace_go_embed_A_const_102; if linked_878 == nil { segs__19 = ifn_879.Invoke_O_O__O(arg_880, arg_881) } else { segs__19 = linked_878.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_877, arg_880, arg_881) }
//line :180:1
				var acc__20 any = lang.PersistentVector_EMPTY.Ref(); L3: for {




					var tmp18 any; var root_882 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_884 lang.IFn; if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any = segs__19; if linked_883 == nil { tmp18 = ifn_884.Invoke_O__O(arg_885) } else { tmp18 = linked_883.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_882, arg_885) }; if jrt.J2g_Truth(tmp18) { var d__21 any; var root_886 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_888 lang.IFn
						if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = acc__20; var arg_890 any; var root_891 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_893 lang.IFn; if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = segs__19; if linked_892 == nil { arg_890 = ifn_893.Invoke_O__O(arg_894) } else { arg_890 = linked_892.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_891, arg_894) }; if linked_887 == nil { d__21 = ifn_888.Invoke_O_O__O(arg_889, arg_890) } else { d__21 = linked_887.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_886, arg_889, arg_890) }
//line :185:1
						var dp__22 any; var root_895 any = A_arbace_go_embed_A_const_52.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_897 lang.IFn

						if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = Lit_26; var arg_899 any = d__21; if linked_896 == nil { dp__22 = ifn_897.Invoke_O_O__O(arg_898, arg_899) } else { dp__22 = linked_896.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_895, arg_898, arg_899) }
//line :185:1
						var df__23 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), jrt.String_Cast(dp__22))



						if jrt.File_New_File_String(jrt.File_Cast(df__23), Lit_58).IsFile__Z() {
							var root_900 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, A_arbace_go_embed_embed_error_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any = pattern__1; var arg_904 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_60, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, what__18, nil, rel__16, nil)).Ref(); if linked_901 == nil { ifn_902.Invoke_O_O__O(arg_903, arg_904) } else { linked_901.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_900, arg_903, arg_904) } }
						var tmp19 any; var root_905 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_907 lang.IFn; if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any; var root_909 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = segs__19; if linked_910 == nil { arg_908 = ifn_911.Invoke_O__O(arg_912) } else { arg_908 = linked_910.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_909, arg_912) }; if linked_906 == nil { tmp19 = ifn_907.Invoke_O__O(arg_908) } else { tmp19 = linked_906.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_905, arg_908) }; if jrt.J2g_Truth(tmp19) {
							var root_913 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, A_arbace_go_embed_embed_error_A_fn_class); var ifn_915 lang.IFn; if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = pattern__1; var arg_917 any; if lang.Util_Equiv_O_O__Z_NoInit(dp__22, rel__16) {
								var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_60, nil, Lit_62, nil); var tmp21 any; var root_918 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = segs__19; if linked_919 == nil { tmp21 = ifn_920.Invoke_O__O(arg_921) } else { tmp21 = linked_919.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_918, arg_921) }; arg_917 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, what__18, nil, rel__16, nil, tmp21)).Ref() } else {
									var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_60, nil, Lit_63, nil); var tmp23 any; var root_922 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = segs__19; if linked_923 == nil { tmp23 = ifn_924.Invoke_O__O(arg_925) } else { tmp23 = linked_923.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_922, arg_925) }; arg_917 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, what__18, nil, rel__16, nil, tmp23)).Ref() }
//line :192:1
							if linked_914 == nil { ifn_915.Invoke_O_O__O(arg_916, arg_917) } else { linked_914.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_913, arg_916, arg_917)
							}
						}
						var tmp24 any; var root_926 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = segs__19; if linked_927 == nil { tmp24 = ifn_928.Invoke_O__O(arg_929) } else { tmp24 = linked_927.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_926, arg_929) }; segs__19, acc__20 = tmp24, d__21; continue L3 }
//line :180:1
					break L3
				}














				if jrt.NN(jrt.File_Cast(f__17)).IsFile__Z() {
					var tmp25 *lang.Volatile = lang.Volatile_Cast(list__9); var tmp26 any; var root_852 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = jrt.NN(lang.Volatile_Cast(list__9)).Deref__O(); var arg_856 any = rel__16; if linked_853 == nil { tmp26 = ifn_854.Invoke_O_O__O(arg_855, arg_856) } else { tmp26 = linked_853.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_852, arg_855, arg_856) }; jrt.NN(tmp25).Reset_O__O(tmp26) } else {
//line :196:1
						if jrt.NN(jrt.File_Cast(f__17)).IsDirectory__Z() { var n__19 any; var root_857 any = A_arbace_go_embed_A_const_98.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_859 lang.IFn


							if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = A_arbace_go_embed_A_const_31; if linked_858 == nil { n__19 = ifn_859.Invoke_O__O(arg_860) } else { n__19 = linked_858.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_857, arg_860) }
//line :196:1
							var body_walk__20 *A_arbace_go_embed_resolve_pattern_walk__1220000106_A = A_arbace_go_embed_resolve_pattern_walk__1220000106_A_New_O_O_O_O(pattern__1, list__9, n__19, all__4); var walk__20 any; var tmp27 *jrt.Class; var fncls__1058 *jrt.Class = A_arbace_go_embed_resolve_pattern_walk__1220000106_A_fn_class; if fncls__1058 == nil { var fncls__1058d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_go_embed_resolve_pattern_walk__1220000106_A_fn_class = fncls__1058d; tmp27 = fncls__1058d } else { tmp27 = fncls__1058 }; walk__20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__20), tmp27, nil)












							lang.IFn_Cast(walk__20).Invoke_O_O__O(f__17, rel__16)
							var tmp28 bool; var na_861 any; var root_862 any = A_arbace_go_embed_A_const_5.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_862, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_864 lang.IFn; if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any = n__19; if linked_863 == nil { na_861 = ifn_864.Invoke_O__O(arg_865) } else { na_861 = linked_863.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_862, arg_865) }; if jrt.Long_InstanceOf(na_861) { var n0_866 int64 = jrt.NN(jrt.Long_Cast(na_861)).LongValue__J(); tmp28 = n0_866 == 0 } else { if jrt.Double_InstanceOf(na_861) { var n0_866_2 float64 = jrt.NN(jrt.Double_Cast(na_861)).DoubleValue__D(); tmp28 = n0_866_2 == 0.0 } else { tmp28 = lang.Numbers_IsZero_O__Z_NoInit(na_861) } }; if tmp28 {
								var root_867 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, A_arbace_go_embed_embed_error_A_fn_class); var ifn_869 lang.IFn; if linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any = pattern__1; var arg_871 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_65, nil, Lit_66), jrt.RefArrayOf(jrt.Object_class, nil, rel__16, nil)).Ref(); if linked_868 == nil { ifn_869.Invoke_O_O__O(arg_870, arg_871) } else { linked_868.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_867, arg_870, arg_871) } } } else {
//line :196:1
									if A_arbace_go_embed_A_const_15 != nil {















										var root_872 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_872, A_arbace_go_embed_embed_error_A_fn_class); var ifn_874 lang.IFn; if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any = pattern__1; var arg_876 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__16)).Ref(); if linked_873 == nil { ifn_874.Invoke_O_O__O(arg_875, arg_876) } else { linked_873.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_872, arg_875, arg_876) } } } }
//line :180:1
				var tmp29 any; var root_1059 any = A_arbace_go_embed_A_const_104.GetRawRoot__O(); var linked_1060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1059, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1061 lang.IFn; if linked_1060 == nil { ifn_1061 = lang.IFn_Cast(root_1059) } else { ifn_1061 = nil }; var arg_1062 any = seq_1220000096__15; if linked_1060 == nil { tmp29 = ifn_1061.Invoke_O__O(arg_1062) } else { tmp29 = linked_1060.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1059, arg_1062) }; seq_1220000096__10, chunk_1220000097__11, count_1220000098__12, i_1220000099__13 = tmp29, nil, 0, 0; continue L1 } } }
//line :169:1
		break L1 }; var tmp30 any; var root_628 any =











































	A_arbace_go_embed_A_const_42.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_630 lang.IFn; if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any; var root_632 any = A_arbace_go_embed_A_const_5.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_634 lang.IFn; if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = list__9; if linked_633 == nil { arg_631 = ifn_634.Invoke_O__O(arg_635) } else { arg_631 = linked_633.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_632, arg_635) }; if linked_629 == nil { tmp30 = ifn_630.Invoke_O__O(arg_631) } else { tmp30 = linked_629.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_628, arg_631) }; if jrt.J2g_Truth(tmp30) { var root_636 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, A_arbace_go_embed_embed_error_A_fn_class); var ifn_638 lang.IFn; if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any = pattern__1; var arg_640 any = Lit_69; if linked_637 == nil { ifn_638.Invoke_O_O__O(arg_639, arg_640) } else { linked_637.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_636, arg_639, arg_640) } }; var root_587 any =
	A_arbace_go_embed_A_const_78.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any; var root_591 any = A_arbace_go_embed_A_const_99.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_593 lang.IFn; if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any; var root_595 any = A_arbace_go_embed_A_const_100.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any; var root_599 any = A_arbace_go_embed_A_const_5.GetRawRoot__O(); var linked_600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_599, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_601 lang.IFn; if linked_600 == nil { ifn_601 = lang.IFn_Cast(root_599) } else { ifn_601 = nil }; var arg_602 any = list__9; if linked_600 == nil { arg_598 = ifn_601.Invoke_O__O(arg_602) } else { arg_598 = linked_600.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_599, arg_602) }; if linked_596 == nil { arg_594 = ifn_597.Invoke_O__O(arg_598) } else { arg_594 = linked_596.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_595, arg_598) }; if linked_592 == nil { arg_590 = ifn_593.Invoke_O__O(arg_594) } else { arg_590 = linked_592.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_591, arg_594) }; if linked_588 == nil { return ifn_589.Invoke_O__O(arg_590) } else { return linked_588.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_587, arg_590) } }
//line :200:1
func A_arbace_go_embed_resolve_pattern_walk__1220000100_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_embed_resolve_pattern_walk__1220000100_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_resolve_pattern_walk__1220000100_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :200:1
func (t *A_arbace_go_embed_resolve_pattern_walk__1220000100_A) Ctor_O_O_O_O(c__pattern, c__list, c__all, c__n any) { t.F_pattern = c__pattern; t.F_list = c__list; t.F_all = c__all; t.F_n = c__n }
//line :200:1
func (t *A_arbace_go_embed_resolve_pattern_walk__1220000100_A) Invoke_O_O_O__O(self, d__1, drel__2 any) any { { var seq_1220000101__3 any; var root_719 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_721 lang.IFn
														if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any; var root_723 any = A_arbace_go_embed_A_const_90.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, A_arbace_go_embed_sorted_children_A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = d__1; if linked_724 == nil { arg_722 = ifn_725.Invoke_O__O(arg_726) } else { arg_722 = linked_724.(*A_arbace_go_embed_sorted_children_A).Invoke_O_O__O(root_723, arg_726) }; if linked_720 == nil { seq_1220000101__3 = ifn_721.Invoke_O__O(arg_722) } else { seq_1220000101__3 = linked_720.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_719, arg_722) }
//line :200:1
	var chunk_1220000102__4 any; var count_1220000103__5 int64 = 0; var i_1220000104__6 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1220000104__6, count_1220000103__5) { var c__7 any = lang.Indexed_Cast(chunk_1220000102__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1220000104__6)); var nm__8 any = jrt.NN(jrt.File_Cast(c__7)).GetName__String().Ref(); var crel__9 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, drel__2, nil, nm__8)).Ref(); var tmp1 any; var or__1927000174__auto____10 any; var root_743 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_745 lang.IFn


			if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = nm__8; if linked_744 == nil { or__1927000174__auto____10 = ifn_745.Invoke_O__O(arg_746) } else { or__1927000174__auto____10 = linked_744.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_743, arg_746) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp1 = or__1927000174__auto____10 } else { var and__1927000168__auto____11 any; var root_747 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = t.F_all; if linked_748 == nil { and__1927000168__auto____11 = ifn_749.Invoke_O__O(arg_750) } else { and__1927000168__auto____11 = linked_748.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_747, arg_750) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var root_751 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = nm__8; var arg_755 any = Lit_2; if linked_752 == nil { or__1927000174__auto____12 = ifn_753.Invoke_O_O__O(arg_754, arg_755) } else { or__1927000174__auto____12 = linked_752.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_751, arg_754, arg_755) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp1 = or__1927000174__auto____12 } else { var root_756 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = nm__8; var arg_760 any = Lit_70; if linked_757 == nil { tmp1 = ifn_758.Invoke_O_O__O(arg_759, arg_760) } else { tmp1 = linked_757.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_756, arg_759, arg_760) } } } else { tmp1 = and__1927000168__auto____11 } }
//line :203:1
			if jrt.J2g_Truth(tmp1) {

				var tmp2 any; var and__1927000168__auto____10 bool = jrt.NN(jrt.File_Cast(c__7)).IsFile__Z(); if and__1927000168__auto____10 { var and__1927000168__auto____11_2 any; var root_761 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = nm__8; if linked_762 == nil { and__1927000168__auto____11_2 = ifn_763.Invoke_O__O(arg_764) } else { and__1927000168__auto____11_2 = linked_762.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_761, arg_764) }; if jrt.J2g_Truth(and__1927000168__auto____11_2) { var root_765 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any; var or__1927000174__auto____12_2 any; var root_769 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_769, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_771 lang.IFn; if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = nm__8; var arg_773 any = Lit_2; if linked_770 == nil { or__1927000174__auto____12_2 = ifn_771.Invoke_O_O__O(arg_772, arg_773) } else { or__1927000174__auto____12_2 = linked_770.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_769, arg_772, arg_773) }; if jrt.J2g_Truth(or__1927000174__auto____12_2) { arg_768 = or__1927000174__auto____12_2 } else { var root_774 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = nm__8; var arg_778 any = Lit_70; if linked_775 == nil { arg_768 = ifn_776.Invoke_O_O__O(arg_777, arg_778) } else { arg_768 = linked_775.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_774, arg_777, arg_778) } }; if linked_766 == nil { tmp2 = ifn_767.Invoke_O__O(arg_768) } else { tmp2 = linked_766.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_765, arg_768) } } else { tmp2 = and__1927000168__auto____11_2 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }; if jrt.J2g_Truth(tmp2) {
					var root_779 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, A_arbace_go_embed_embed_error_A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = t.F_pattern; var arg_783 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_71, nil, Lit_62, nil), jrt.RefArrayOf(jrt.Object_class, nil, crel__9, nil, nm__8)).Ref(); if linked_780 == nil { ifn_781.Invoke_O_O__O(arg_782, arg_783) } else { linked_780.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_779, arg_782, arg_783) } } } else {
//line :203:1
						if jrt.NN(jrt.File_Cast(c__7)).IsDirectory__Z() {



							if jrt.File_New_File_String(jrt.File_Cast(c__7), Lit_58).IsFile__Z() { } else { lang.IFn_Cast(self).Invoke_O_O__O(c__7, crel__9) } } else {
//line :203:1
								if jrt.NN(jrt.File_Cast(c__7)).IsFile__Z() {




									var tmp3 *lang.Volatile = lang.Volatile_Cast(t.F_n); var tmp4 jrt.Number_I; var na_789 any = jrt.NN(lang.Volatile_Cast(t.F_n)).Deref__O(); if jrt.Long_InstanceOf(na_789) { var n0_790 int64 = jrt.NN(jrt.Long_Cast(na_789)).LongValue__J(); if n0_790 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_789) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_790 + 1)) } } else { if jrt.Double_InstanceOf(na_789) { var n0_790_2 float64 = jrt.NN(jrt.Double_Cast(na_789)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_790_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_789) } }; jrt.NN(tmp3).Reset_O__O(tmp4); var tmp5 *lang.Volatile = lang.Volatile_Cast(t.F_list); var tmp6 any; var root_784 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_784, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_786 lang.IFn; if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any = jrt.NN(lang.Volatile_Cast(t.F_list)).Deref__O(); var arg_788 any = crel__9; if linked_785 == nil { tmp6 = ifn_786.Invoke_O_O__O(arg_787, arg_788) } else { tmp6 = linked_785.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_784, arg_787, arg_788) }; jrt.NN(tmp5).Reset_O__O(tmp6) } } }
//line :201:1
			seq_1220000101__3, chunk_1220000102__4, count_1220000103__5, i_1220000104__6 = seq_1220000101__3, chunk_1220000102__4, count_1220000103__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1220000104__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_727 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = seq_1220000101__3; if linked_728 == nil { temp__1927000414__auto____7 = ifn_729.Invoke_O__O(arg_730) } else { temp__1927000414__auto____7 = linked_728.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_727, arg_730) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1220000101__8 any = temp__1927000414__auto____7; var tmp7 any; var root_731 any = A_arbace_go_embed_A_const_79.GetRawRoot__O(); var linked_732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_731, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_733 lang.IFn; if linked_732 == nil { ifn_733 = lang.IFn_Cast(root_731) } else { ifn_733 = nil }; var arg_734 any = seq_1220000101__8; if linked_732 == nil { tmp7 = ifn_733.Invoke_O__O(arg_734) } else { tmp7 = linked_732.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_731, arg_734) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____9 any; var root_735 any = A_arbace_go_embed_A_const_80.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_737 lang.IFn; if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = seq_1220000101__8; if linked_736 == nil { c__1927000678__auto____9 = ifn_737.Invoke_O__O(arg_738) } else { c__1927000678__auto____9 = linked_736.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_735, arg_738) }; var tmp8 any; var root_791 any = A_arbace_go_embed_A_const_85.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = seq_1220000101__8; if linked_792 == nil { tmp8 = ifn_793.Invoke_O__O(arg_794) } else { tmp8 = linked_792.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_791, arg_794) }; seq_1220000101__3, chunk_1220000102__4, count_1220000103__5, i_1220000104__6 = tmp8, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var c__9 any; var root_739 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_741 lang.IFn; if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any = seq_1220000101__8; if linked_740 == nil { c__9 = ifn_741.Invoke_O__O(arg_742) } else { c__9 = linked_740.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_739, arg_742) }; var nm__10 any = jrt.NN(jrt.File_Cast(c__9)).GetName__String().Ref(); var crel__11 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, drel__2, nil, nm__10)).Ref(); var tmp9 any; var or__1927000174__auto____12_3 any; var root_795 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_797 lang.IFn


				if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = nm__10; if linked_796 == nil { or__1927000174__auto____12_3 = ifn_797.Invoke_O__O(arg_798) } else { or__1927000174__auto____12_3 = linked_796.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_795, arg_798) }; if jrt.J2g_Truth(or__1927000174__auto____12_3) { tmp9 = or__1927000174__auto____12_3 } else { var and__1927000168__auto____13 any; var root_799 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = t.F_all; if linked_800 == nil { and__1927000168__auto____13 = ifn_801.Invoke_O__O(arg_802) } else { and__1927000168__auto____13 = linked_800.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_799, arg_802) }; if jrt.J2g_Truth(and__1927000168__auto____13) { var or__1927000174__auto____14 any; var root_803 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = nm__10; var arg_807 any = Lit_2; if linked_804 == nil { or__1927000174__auto____14 = ifn_805.Invoke_O_O__O(arg_806, arg_807) } else { or__1927000174__auto____14 = linked_804.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_803, arg_806, arg_807) }; if jrt.J2g_Truth(or__1927000174__auto____14) { tmp9 = or__1927000174__auto____14 } else { var root_808 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = nm__10; var arg_812 any = Lit_70; if linked_809 == nil { tmp9 = ifn_810.Invoke_O_O__O(arg_811, arg_812) } else { tmp9 = linked_809.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_808, arg_811, arg_812) } } } else { tmp9 = and__1927000168__auto____13 } }
//line :203:1
				if jrt.J2g_Truth(tmp9) {

					var tmp10 any; var and__1927000168__auto____12 bool = jrt.NN(jrt.File_Cast(c__9)).IsFile__Z(); if and__1927000168__auto____12 { var and__1927000168__auto____13_2 any; var root_813 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_815 lang.IFn; if linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = nm__10; if linked_814 == nil { and__1927000168__auto____13_2 = ifn_815.Invoke_O__O(arg_816) } else { and__1927000168__auto____13_2 = linked_814.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_813, arg_816) }; if jrt.J2g_Truth(and__1927000168__auto____13_2) { var root_817 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any; var or__1927000174__auto____14_2 any; var root_821 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_823 lang.IFn; if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = nm__10; var arg_825 any = Lit_2; if linked_822 == nil { or__1927000174__auto____14_2 = ifn_823.Invoke_O_O__O(arg_824, arg_825) } else { or__1927000174__auto____14_2 = linked_822.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_821, arg_824, arg_825) }; if jrt.J2g_Truth(or__1927000174__auto____14_2) { arg_820 = or__1927000174__auto____14_2 } else { var root_826 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_828 lang.IFn; if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any = nm__10; var arg_830 any = Lit_70; if linked_827 == nil { arg_820 = ifn_828.Invoke_O_O__O(arg_829, arg_830) } else { arg_820 = linked_827.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_826, arg_829, arg_830) } }; if linked_818 == nil { tmp10 = ifn_819.Invoke_O__O(arg_820) } else { tmp10 = linked_818.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_817, arg_820) } } else { tmp10 = and__1927000168__auto____13_2 } } else { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____12).Ref() }; if jrt.J2g_Truth(tmp10) {
						var root_831 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, A_arbace_go_embed_embed_error_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = t.F_pattern; var arg_835 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_71, nil, Lit_62, nil), jrt.RefArrayOf(jrt.Object_class, nil, crel__11, nil, nm__10)).Ref(); if linked_832 == nil { ifn_833.Invoke_O_O__O(arg_834, arg_835) } else { linked_832.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_831, arg_834, arg_835) } } } else {
//line :203:1
							if jrt.NN(jrt.File_Cast(c__9)).IsDirectory__Z() {



								if jrt.File_New_File_String(jrt.File_Cast(c__9), Lit_58).IsFile__Z() { } else { lang.IFn_Cast(self).Invoke_O_O__O(c__9, crel__11) } } else {
//line :203:1
									if jrt.NN(jrt.File_Cast(c__9)).IsFile__Z() {




										var tmp11 *lang.Volatile = lang.Volatile_Cast(t.F_n); var tmp12 jrt.Number_I; var na_841 any = jrt.NN(lang.Volatile_Cast(t.F_n)).Deref__O(); if jrt.Long_InstanceOf(na_841) { var n0_842 int64 = jrt.NN(jrt.Long_Cast(na_841)).LongValue__J(); if n0_842 == 9223372036854775807 { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_841) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_842 + 1)) } } else { if jrt.Double_InstanceOf(na_841) { var n0_842_2 float64 = jrt.NN(jrt.Double_Cast(na_841)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_842_2 + 1.0)) } else { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_841) } }; jrt.NN(tmp11).Reset_O__O(tmp12); var tmp13 *lang.Volatile = lang.Volatile_Cast(t.F_list); var tmp14 any; var root_836 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_836, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = jrt.NN(lang.Volatile_Cast(t.F_list)).Deref__O(); var arg_840 any = crel__11; if linked_837 == nil { tmp14 = ifn_838.Invoke_O_O__O(arg_839, arg_840) } else { tmp14 = linked_837.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_836, arg_839, arg_840) }; jrt.NN(tmp13).Reset_O__O(tmp14) } } }
//line :201:1
				var tmp15 any; var root_843 any = A_arbace_go_embed_A_const_104.GetRawRoot__O(); var linked_844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_843, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_845 lang.IFn; if linked_844 == nil { ifn_845 = lang.IFn_Cast(root_843) } else { ifn_845 = nil }; var arg_846 any = seq_1220000101__8; if linked_844 == nil { tmp15 = ifn_845.Invoke_O__O(arg_846) } else { tmp15 = linked_844.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_843, arg_846) }; seq_1220000101__3, chunk_1220000102__4, count_1220000103__5, i_1220000104__6 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :200:1*/panic("j2g: unreachable") }
//line :200:1
func A_arbace_go_embed_resolve_pattern_walk__1220000106_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_embed_resolve_pattern_walk__1220000106_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_resolve_pattern_walk__1220000106_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :200:1
func (t *A_arbace_go_embed_resolve_pattern_walk__1220000106_A) Ctor_O_O_O_O(c__pattern, c__list, c__n, c__all any) { t.F_pattern = c__pattern; t.F_list = c__list; t.F_n = c__n; t.F_all = c__all }
//line :200:1
func (t *A_arbace_go_embed_resolve_pattern_walk__1220000106_A) Invoke_O_O_O__O(self, d__1, drel__2 any) any { { var seq_1220000107__3 any; var root_930 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_932 lang.IFn
														if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any; var root_934 any = A_arbace_go_embed_A_const_90.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, A_arbace_go_embed_sorted_children_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = d__1; if linked_935 == nil { arg_933 = ifn_936.Invoke_O__O(arg_937) } else { arg_933 = linked_935.(*A_arbace_go_embed_sorted_children_A).Invoke_O_O__O(root_934, arg_937) }; if linked_931 == nil { seq_1220000107__3 = ifn_932.Invoke_O__O(arg_933) } else { seq_1220000107__3 = linked_931.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_930, arg_933) }
//line :200:1
	var chunk_1220000108__4 any; var count_1220000109__5 int64 = 0; var i_1220000110__6 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1220000110__6, count_1220000109__5) { var c__7 any = lang.Indexed_Cast(chunk_1220000108__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1220000110__6)); var nm__8 any = jrt.NN(jrt.File_Cast(c__7)).GetName__String().Ref(); var crel__9 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, drel__2, nil, nm__8)).Ref(); var tmp1 any; var or__1927000174__auto____10 any; var root_954 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_956 lang.IFn


			if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = nm__8; if linked_955 == nil { or__1927000174__auto____10 = ifn_956.Invoke_O__O(arg_957) } else { or__1927000174__auto____10 = linked_955.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_954, arg_957) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp1 = or__1927000174__auto____10 } else { var and__1927000168__auto____11 any; var root_958 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = t.F_all; if linked_959 == nil { and__1927000168__auto____11 = ifn_960.Invoke_O__O(arg_961) } else { and__1927000168__auto____11 = linked_959.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_958, arg_961) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var root_962 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = nm__8; var arg_966 any = Lit_2; if linked_963 == nil { or__1927000174__auto____12 = ifn_964.Invoke_O_O__O(arg_965, arg_966) } else { or__1927000174__auto____12 = linked_963.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_962, arg_965, arg_966) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp1 = or__1927000174__auto____12 } else { var root_967 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = nm__8; var arg_971 any = Lit_70; if linked_968 == nil { tmp1 = ifn_969.Invoke_O_O__O(arg_970, arg_971) } else { tmp1 = linked_968.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_967, arg_970, arg_971) } } } else { tmp1 = and__1927000168__auto____11 } }
//line :203:1
			if jrt.J2g_Truth(tmp1) {

				var tmp2 any; var and__1927000168__auto____10 bool = jrt.NN(jrt.File_Cast(c__7)).IsFile__Z(); if and__1927000168__auto____10 { var and__1927000168__auto____11_2 any; var root_972 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_974 lang.IFn; if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any = nm__8; if linked_973 == nil { and__1927000168__auto____11_2 = ifn_974.Invoke_O__O(arg_975) } else { and__1927000168__auto____11_2 = linked_973.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_972, arg_975) }; if jrt.J2g_Truth(and__1927000168__auto____11_2) { var root_976 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any; var or__1927000174__auto____12_2 any; var root_980 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = nm__8; var arg_984 any = Lit_2; if linked_981 == nil { or__1927000174__auto____12_2 = ifn_982.Invoke_O_O__O(arg_983, arg_984) } else { or__1927000174__auto____12_2 = linked_981.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_980, arg_983, arg_984) }; if jrt.J2g_Truth(or__1927000174__auto____12_2) { arg_979 = or__1927000174__auto____12_2 } else { var root_985 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = nm__8; var arg_989 any = Lit_70; if linked_986 == nil { arg_979 = ifn_987.Invoke_O_O__O(arg_988, arg_989) } else { arg_979 = linked_986.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_985, arg_988, arg_989) } }; if linked_977 == nil { tmp2 = ifn_978.Invoke_O__O(arg_979) } else { tmp2 = linked_977.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_976, arg_979) } } else { tmp2 = and__1927000168__auto____11_2 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }; if jrt.J2g_Truth(tmp2) {
					var root_990 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, A_arbace_go_embed_embed_error_A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any = t.F_pattern; var arg_994 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_71, nil, Lit_62, nil), jrt.RefArrayOf(jrt.Object_class, nil, crel__9, nil, nm__8)).Ref(); if linked_991 == nil { ifn_992.Invoke_O_O__O(arg_993, arg_994) } else { linked_991.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_990, arg_993, arg_994) } } } else {
//line :203:1
						if jrt.NN(jrt.File_Cast(c__7)).IsDirectory__Z() {



							if jrt.File_New_File_String(jrt.File_Cast(c__7), Lit_58).IsFile__Z() { } else { lang.IFn_Cast(self).Invoke_O_O__O(c__7, crel__9) } } else {
//line :203:1
								if jrt.NN(jrt.File_Cast(c__7)).IsFile__Z() {




									var tmp3 *lang.Volatile = lang.Volatile_Cast(t.F_n); var tmp4 jrt.Number_I; var na_1000 any = jrt.NN(lang.Volatile_Cast(t.F_n)).Deref__O(); if jrt.Long_InstanceOf(na_1000) { var n0_1001 int64 = jrt.NN(jrt.Long_Cast(na_1000)).LongValue__J(); if n0_1001 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_1000) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1001 + 1)) } } else { if jrt.Double_InstanceOf(na_1000) { var n0_1001_2 float64 = jrt.NN(jrt.Double_Cast(na_1000)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1001_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_1000) } }; jrt.NN(tmp3).Reset_O__O(tmp4); var tmp5 *lang.Volatile = lang.Volatile_Cast(t.F_list); var tmp6 any; var root_995 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_996 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_995, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_997 lang.IFn; if linked_996 == nil { ifn_997 = lang.IFn_Cast(root_995) } else { ifn_997 = nil }; var arg_998 any = jrt.NN(lang.Volatile_Cast(t.F_list)).Deref__O(); var arg_999 any = crel__9; if linked_996 == nil { tmp6 = ifn_997.Invoke_O_O__O(arg_998, arg_999) } else { tmp6 = linked_996.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_995, arg_998, arg_999) }; jrt.NN(tmp5).Reset_O__O(tmp6) } } }
//line :201:1
			seq_1220000107__3, chunk_1220000108__4, count_1220000109__5, i_1220000110__6 = seq_1220000107__3, chunk_1220000108__4, count_1220000109__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1220000110__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_938 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = seq_1220000107__3; if linked_939 == nil { temp__1927000414__auto____7 = ifn_940.Invoke_O__O(arg_941) } else { temp__1927000414__auto____7 = linked_939.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_938, arg_941) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1220000107__8 any = temp__1927000414__auto____7; var tmp7 any; var root_942 any = A_arbace_go_embed_A_const_79.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_944 lang.IFn; if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = seq_1220000107__8; if linked_943 == nil { tmp7 = ifn_944.Invoke_O__O(arg_945) } else { tmp7 = linked_943.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_942, arg_945) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____9 any; var root_946 any = A_arbace_go_embed_A_const_80.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = seq_1220000107__8; if linked_947 == nil { c__1927000678__auto____9 = ifn_948.Invoke_O__O(arg_949) } else { c__1927000678__auto____9 = linked_947.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_946, arg_949) }; var tmp8 any; var root_1002 any = A_arbace_go_embed_A_const_85.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = seq_1220000107__8; if linked_1003 == nil { tmp8 = ifn_1004.Invoke_O__O(arg_1005) } else { tmp8 = linked_1003.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1002, arg_1005) }; seq_1220000107__3, chunk_1220000108__4, count_1220000109__5, i_1220000110__6 = tmp8, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var c__9 any; var root_950 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = seq_1220000107__8; if linked_951 == nil { c__9 = ifn_952.Invoke_O__O(arg_953) } else { c__9 = linked_951.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_950, arg_953) }; var nm__10 any = jrt.NN(jrt.File_Cast(c__9)).GetName__String().Ref(); var crel__11 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, drel__2, nil, nm__10)).Ref(); var tmp9 any; var or__1927000174__auto____12_3 any; var root_1006 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_1008 lang.IFn


				if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = nm__10; if linked_1007 == nil { or__1927000174__auto____12_3 = ifn_1008.Invoke_O__O(arg_1009) } else { or__1927000174__auto____12_3 = linked_1007.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_1006, arg_1009) }; if jrt.J2g_Truth(or__1927000174__auto____12_3) { tmp9 = or__1927000174__auto____12_3 } else { var and__1927000168__auto____13 any; var root_1010 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1012 lang.IFn; if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; var arg_1013 any = t.F_all; if linked_1011 == nil { and__1927000168__auto____13 = ifn_1012.Invoke_O__O(arg_1013) } else { and__1927000168__auto____13 = linked_1011.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1010, arg_1013) }; if jrt.J2g_Truth(and__1927000168__auto____13) { var or__1927000174__auto____14 any; var root_1014 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1016 lang.IFn; if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = nm__10; var arg_1018 any = Lit_2; if linked_1015 == nil { or__1927000174__auto____14 = ifn_1016.Invoke_O_O__O(arg_1017, arg_1018) } else { or__1927000174__auto____14 = linked_1015.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1014, arg_1017, arg_1018) }; if jrt.J2g_Truth(or__1927000174__auto____14) { tmp9 = or__1927000174__auto____14 } else { var root_1019 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1021 lang.IFn; if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any = nm__10; var arg_1023 any = Lit_70; if linked_1020 == nil { tmp9 = ifn_1021.Invoke_O_O__O(arg_1022, arg_1023) } else { tmp9 = linked_1020.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1019, arg_1022, arg_1023) } } } else { tmp9 = and__1927000168__auto____13 } }
//line :203:1
				if jrt.J2g_Truth(tmp9) {

					var tmp10 any; var and__1927000168__auto____12 bool = jrt.NN(jrt.File_Cast(c__9)).IsFile__Z(); if and__1927000168__auto____12 { var and__1927000168__auto____13_2 any; var root_1024 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_1026 lang.IFn; if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = nm__10; if linked_1025 == nil { and__1927000168__auto____13_2 = ifn_1026.Invoke_O__O(arg_1027) } else { and__1927000168__auto____13_2 = linked_1025.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_1024, arg_1027) }; if jrt.J2g_Truth(and__1927000168__auto____13_2) { var root_1028 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1030 lang.IFn; if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any; var or__1927000174__auto____14_2 any; var root_1032 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = nm__10; var arg_1036 any = Lit_2; if linked_1033 == nil { or__1927000174__auto____14_2 = ifn_1034.Invoke_O_O__O(arg_1035, arg_1036) } else { or__1927000174__auto____14_2 = linked_1033.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1032, arg_1035, arg_1036) }; if jrt.J2g_Truth(or__1927000174__auto____14_2) { arg_1031 = or__1927000174__auto____14_2 } else { var root_1037 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = nm__10; var arg_1041 any = Lit_70; if linked_1038 == nil { arg_1031 = ifn_1039.Invoke_O_O__O(arg_1040, arg_1041) } else { arg_1031 = linked_1038.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1037, arg_1040, arg_1041) } }; if linked_1029 == nil { tmp10 = ifn_1030.Invoke_O__O(arg_1031) } else { tmp10 = linked_1029.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1028, arg_1031) } } else { tmp10 = and__1927000168__auto____13_2 } } else { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____12).Ref() }; if jrt.J2g_Truth(tmp10) {
						var root_1042 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, A_arbace_go_embed_embed_error_A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = t.F_pattern; var arg_1046 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_71, nil, Lit_62, nil), jrt.RefArrayOf(jrt.Object_class, nil, crel__11, nil, nm__10)).Ref(); if linked_1043 == nil { ifn_1044.Invoke_O_O__O(arg_1045, arg_1046) } else { linked_1043.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_1042, arg_1045, arg_1046) } } } else {
//line :203:1
							if jrt.NN(jrt.File_Cast(c__9)).IsDirectory__Z() {



								if jrt.File_New_File_String(jrt.File_Cast(c__9), Lit_58).IsFile__Z() { } else { lang.IFn_Cast(self).Invoke_O_O__O(c__9, crel__11) } } else {
//line :203:1
									if jrt.NN(jrt.File_Cast(c__9)).IsFile__Z() {




										var tmp11 *lang.Volatile = lang.Volatile_Cast(t.F_n); var tmp12 jrt.Number_I; var na_1052 any = jrt.NN(lang.Volatile_Cast(t.F_n)).Deref__O(); if jrt.Long_InstanceOf(na_1052) { var n0_1053 int64 = jrt.NN(jrt.Long_Cast(na_1052)).LongValue__J(); if n0_1053 == 9223372036854775807 { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_1052) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1053 + 1)) } } else { if jrt.Double_InstanceOf(na_1052) { var n0_1053_2 float64 = jrt.NN(jrt.Double_Cast(na_1052)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1053_2 + 1.0)) } else { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_1052) } }; jrt.NN(tmp11).Reset_O__O(tmp12); var tmp13 *lang.Volatile = lang.Volatile_Cast(t.F_list); var tmp14 any; var root_1047 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = jrt.NN(lang.Volatile_Cast(t.F_list)).Deref__O(); var arg_1051 any = crel__11; if linked_1048 == nil { tmp14 = ifn_1049.Invoke_O_O__O(arg_1050, arg_1051) } else { tmp14 = linked_1048.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1047, arg_1050, arg_1051) }; jrt.NN(tmp13).Reset_O__O(tmp14) } } }
//line :201:1
				var tmp15 any; var root_1054 any = A_arbace_go_embed_A_const_104.GetRawRoot__O(); var linked_1055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1054, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1056 lang.IFn; if linked_1055 == nil { ifn_1056 = lang.IFn_Cast(root_1054) } else { ifn_1056 = nil }; var arg_1057 any = seq_1220000107__8; if linked_1055 == nil { tmp15 = ifn_1056.Invoke_O__O(arg_1057) } else { tmp15 = linked_1055.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1054, arg_1057) }; seq_1220000107__3, chunk_1220000108__4, count_1220000109__5, i_1220000110__6 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :200:1*/panic("j2g: unreachable") }

















func A_arbace_go_embed_name_split_A_New() *A_arbace_go_embed_name_split_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_name_split_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_go_embed_name_split_A) Ctor() {}
//line :218:1
func (t *A_arbace_go_embed_name_split_A) Invoke_O_O__O(self, n__0 any) any { var n__2 any; var tmp1 any; var root_1063 any = A_arbace_go_embed_A_const_69.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1065 lang.IFn; if
										linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any = n__0; var arg_1067 any = Lit_26; if linked_1064 == nil { tmp1 = ifn_1065.Invoke_O_O__O(arg_1066, arg_1067) } else { tmp1 = linked_1064.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1063, arg_1066, arg_1067) }; if jrt.J2g_Truth(tmp1) { var root_1068 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_1069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1068, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1070 lang.IFn; if linked_1069 == nil { ifn_1070 = lang.IFn_Cast(root_1068) } else { ifn_1070 = nil }; var arg_1071 any = n__0; var arg_1072 any = A_arbace_go_embed_A_const_31; var arg_1073 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(n__0)))).Ref(); if linked_1069 == nil { n__2 = ifn_1070.Invoke_O_O_O__O(arg_1071, arg_1072, arg_1073) } else { n__2 = linked_1069.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1068, arg_1071, arg_1072, arg_1073) } } else { n__2 = n__0 }; var i__3 any; var root_1074 any = /*line :218:1*/A_arbace_go_embed_A_const_105.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, aot_arbace_string.A_arbace_string_last_index_of_A_fn_class); var ifn_1076 lang.IFn; if

	linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = n__2; var arg_1078 any = Lit_26; if linked_1075 == nil { i__3 = ifn_1076.Invoke_O_O__O(arg_1077, arg_1078) } else { i__3 = linked_1075.(*aot_arbace_string.A_arbace_string_last_index_of_A).Invoke_O_O_O__O(root_1074, arg_1077, arg_1078) }; if
	lang.Util_Identical_O_O__Z_NoInit(i__3, nil) { return lang.Tuple_Create_O_O__IPersistentVector(Lit_2, n__2) } else { var tmp2 any; var root_1079 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any = n__2; var arg_1083 any = A_arbace_go_embed_A_const_31; var arg_1084 any = i__3; if linked_1080 == nil { tmp2 = ifn_1081.Invoke_O_O_O__O(arg_1082, arg_1083, arg_1084) } else { tmp2 = linked_1080.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1079, arg_1082, arg_1083, arg_1084) }; var tmp3 any = tmp2; var tmp4 any; var root_1085 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any = n__2; var arg_1089 any; var na_1090 any = i__3; if jrt.Long_InstanceOf(na_1090) { var n0_1091 int64 = jrt.NN(jrt.Long_Cast(na_1090)).LongValue__J(); if n0_1091 == 9223372036854775807 { arg_1089 = lang.Numbers_Inc_O__Number_NoInit(na_1090) } else { arg_1089 = jrt.Long_ValueOf_J__Long_NoInit(n0_1091 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1090) { var n0_1091_2 float64 = jrt.NN(jrt.Double_Cast(na_1090)).DoubleValue__D(); arg_1089 = jrt.Double_ValueOf_D__Double_NoInit(n0_1091_2 + 1.0).Ref() } else { arg_1089 = lang.Numbers_Inc_O__Number_NoInit(na_1090) } }; if linked_1086 == nil { tmp4 = ifn_1087.Invoke_O_O__O(arg_1088, arg_1089) } else { tmp4 = linked_1086.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1085, arg_1088, arg_1089) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } }

func A_arbace_go_embed_file_less_A_New() *A_arbace_go_embed_file_less_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_file_less_A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_go_embed_file_less_A) Ctor() {}
//line :223:1
func (t *A_arbace_go_embed_file_less_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var vec__1220000114__3 any; var root_1092 any = A_arbace_go_embed_A_const_106.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, A_arbace_go_embed_name_split_A_fn_class); var ifn_1094 lang.IFn; if


	linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = x__0; if linked_1093 == nil { vec__1220000114__3 = ifn_1094.Invoke_O__O(arg_1095) } else { vec__1220000114__3 = linked_1093.(*A_arbace_go_embed_name_split_A).Invoke_O_O__O(root_1092, arg_1095) }; var xd__4 any = /*line :223:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1220000114__3, lang.RT_IntCast_J__I_NoInit(0), nil); var xe__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000114__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__1220000117__6 any; var root_1096 any = A_arbace_go_embed_A_const_106.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, A_arbace_go_embed_name_split_A_fn_class); var ifn_1098 lang.IFn; if


	linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = y__1; if linked_1097 == nil { vec__1220000117__6 = ifn_1098.Invoke_O__O(arg_1099) } else { vec__1220000117__6 = linked_1097.(*A_arbace_go_embed_name_split_A).Invoke_O_O__O(root_1096, arg_1099) }; var yd__7 any = /*line :223:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1220000117__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ye__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000117__6, lang.RT_IntCast_J__I_NoInit(1), nil); var or__1927000174__auto____9 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(lang.Util_Compare_O_O__I_NoInit(xd__4, yd__7))); if or__1927000174__auto____9 {



		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else { var and__1927000168__auto____10 bool = lang.Util_Equiv_O_O__Z_NoInit(xd__4, yd__7); if and__1927000168__auto____10 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsNeg_J__Z_NoInit(int64(lang.Util_Compare_O_O__I_NoInit(xe__5, ye__8)))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() } } }

func A_arbace_go_embed_sha256_hex_A_New() *A_arbace_go_embed_sha256_hex_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_sha256_hex_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_go_embed_sha256_hex_A) Ctor() {}
//line :229:1
func (t *A_arbace_go_embed_sha256_hex_A) Invoke_O_O__O(self, bs__0 any) any { var md__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_72); var root_1100 any = A_arbace_go_embed_A_const_107.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1100, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1102 lang.IFn; if

	linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var arg_1104 any; var root_1105 any = A_arbace_go_embed_A_const_53.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1105, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1107 lang.IFn; if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any; var tmp1 any = A_arbace_go_embed_sha256_hex_fn__1220000122_A_New(); var tmp2 *jrt.Class; var fncls__1120 *jrt.Class = A_arbace_go_embed_sha256_hex_fn__1220000122_A_fn_class; if fncls__1120 == nil { var fncls__1120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_go_embed_sha256_hex_fn__1220000122_A_fn_class = fncls__1120d; tmp2 = fncls__1120d } else { tmp2 = fncls__1120 }; arg_1108 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1109 any = jrt.MessageDigest_Cast(md__2).Digest_B1__B1(jrt.ByteArray_Cast(bs__0)).Ref(); if linked_1106 == nil { arg_1104 = ifn_1107.Invoke_O_O__O(arg_1108, arg_1109) } else { arg_1104 = linked_1106.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1105, arg_1108, arg_1109) }; if linked_1101 == nil { return ifn_1102.Invoke_O_O__O(arg_1103, arg_1104) } else { return linked_1101.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1100, arg_1103, arg_1104) } }
//line :231:1
func A_arbace_go_embed_sha256_hex_fn__1220000122_A_New() *A_arbace_go_embed_sha256_hex_fn__1220000122_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_sha256_hex_fn__1220000122_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_go_embed_sha256_hex_fn__1220000122_A) Ctor() {}
//line :231:1
func (t *A_arbace_go_embed_sha256_hex_fn__1220000122_A) Invoke_O_O__O(self, p1__1220000121_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_embed_A_const_108.GetRawRoot__O()); var tmp2 int64; var na_1115 any = p1__1220000121_SHARP___1; var na_1116 int64 = 255; if jrt.Long_InstanceOf(na_1115) { var n0_1117 int64 = jrt.NN(jrt.Long_Cast(na_1115)).LongValue__J(); var n1_1118 int64 = na_1116; tmp2 = n0_1117 & n1_1118 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1115, na_1116) }; return tmp1.Invoke_O_O__O(Lit_74, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_go_embed_files_A_New() *A_arbace_go_embed_files_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_go_embed_files_A) Ctor() {}
//line :233:1
func (t *A_arbace_go_embed_files_A) Invoke_O_O_O_O_O_O__O(self, dir__0, patterns__1, kind__2, hashes__3, type_text__4 any) any { var names__6 any; var root_1121 any = A_arbace_go_embed_A_const_100.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1123 lang.IFn; if





	linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_embed_A_const_109.GetRawRoot__O()); var tmp2 any = A_arbace_go_embed_files_fn__1220000128_A_New_O(dir__0); var tmp3 *jrt.Class; var fncls__1135 *jrt.Class = A_arbace_go_embed_files_fn__1220000128_A_fn_class; if fncls__1135 == nil { var fncls__1135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_go_embed_files_fn__1220000128_A_fn_class = fncls__1135d; tmp3 = fncls__1135d } else { tmp3 = fncls__1135 }; arg_1124 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), patterns__1); if linked_1122 == nil { names__6 = ifn_1123.Invoke_O__O(arg_1124) } else { names__6 = linked_1122.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1121, arg_1124) }; var names__7 any; if
	lang.Util_Equiv_O_O__Z_NoInit(kind__2, A_arbace_go_embed_A_const_111) {
		var root_1136 any = A_arbace_go_embed_A_const_100.GetRawRoot__O(); var linked_1137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1136, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1138 lang.IFn; if linked_1137 == nil { ifn_1138 = lang.IFn_Cast(root_1136) } else { ifn_1138 = nil }; var arg_1139 any; var root_1140 any = A_arbace_go_embed_A_const_91.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1140, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1142 lang.IFn; if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var arg_1143 any = names__6; var arg_1144 any; var iter__1927001039__auto____7 any; var tmp4 any = A_arbace_go_embed_files_iter__1220000130__1220000136_A_New(); var tmp5 *jrt.Class; var fncls__1259 *jrt.Class = A_arbace_go_embed_files_iter__1220000130__1220000136_A_fn_class; if fncls__1259 == nil { var fncls__1259d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_go_embed_files_iter__1220000130__1220000136_A_fn_class = fncls__1259d; tmp5 = fncls__1259d } else { tmp5 = fncls__1259 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); arg_1144 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(names__6); if linked_1141 == nil { arg_1139 = ifn_1142.Invoke_O_O__O(arg_1143, arg_1144) } else { arg_1139 = linked_1141.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1140, arg_1143, arg_1144) }; if linked_1137 == nil { names__7 = ifn_1138.Invoke_O__O(arg_1139) } else { names__7 = linked_1137.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1136, arg_1139) } } else {
//line :240:1
			names__7 = names__6 }; var names__8 any; var root_1260 any = /*line :233:1*/A_arbace_go_embed_A_const_99.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1262 lang.IFn; if











	linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any; var root_1265 any = A_arbace_go_embed_A_const_114.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, aot_arbace_core.A_arbace_core_comparator_A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = A_arbace_go_embed_A_const_115.GetRawRoot__O(); if linked_1266 == nil { arg_1263 = ifn_1267.Invoke_O__O(arg_1268) } else { arg_1263 = linked_1266.(*aot_arbace_core.A_arbace_core_comparator_A).Invoke_O_O__O(root_1265, arg_1268) }; var arg_1264 any = names__7; if linked_1261 == nil { names__8 = ifn_1262.Invoke_O_O__O(arg_1263, arg_1264) } else { names__8 = linked_1261.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O_O__O(root_1260, arg_1263, arg_1264) }; var tmp6 any; var and__1927000168__auto____9 any; var root_1386 any =
	A_arbace_go_embed_A_const_13.GetRawRoot__O(); var linked_1387 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1386, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1388 lang.IFn; if linked_1387 == nil { ifn_1388 = lang.IFn_Cast(root_1386) } else { ifn_1388 = nil }; var arg_1389 any = kind__2; var arg_1390 any = A_arbace_go_embed_A_const_111; if linked_1387 == nil { and__1927000168__auto____9 = ifn_1388.Invoke_O_O__O(arg_1389, arg_1390) } else { and__1927000168__auto____9 = linked_1387.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1386, arg_1389, arg_1390) }; if jrt.J2g_Truth(and__1927000168__auto____9) { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(names__8)), 1)).Ref() } else { tmp6 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_1391 any = A_arbace_go_embed_A_const_93.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1393 lang.IFn
		if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, type_text__4)).Ref(); var arg_1395 any = A_arbace_go_embed_A_const_119; if linked_1392 == nil { tmp7 = ifn_1393.Invoke_O_O__O(arg_1394, arg_1395) } else { tmp7 = linked_1392.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1391, arg_1394, arg_1395) }
//line :246:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp7))) }; var root_1269 any =

	A_arbace_go_embed_A_const_78.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any; var iter__1927001039__auto____9 any; var tmp8 any = A_arbace_go_embed_files_iter__1220000150__1220000154_A_New_O_O(dir__0, hashes__3); var tmp9 *jrt.Class; var fncls__1385 *jrt.Class = A_arbace_go_embed_files_iter__1220000150__1220000154_A_fn_class; if fncls__1385 == nil { var fncls__1385d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_go_embed_files_iter__1220000150__1220000154_A_fn_class = fncls__1385d; tmp9 = fncls__1385d } else { tmp9 = fncls__1385 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); arg_1272 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(names__8); if linked_1270 == nil { return ifn_1271.Invoke_O__O(arg_1272) } else { return linked_1270.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1269, arg_1272) } }
//line :239:1
func A_arbace_go_embed_files_fn__1220000128_A_New_O(p0 any) *A_arbace_go_embed_files_fn__1220000128_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_fn__1220000128_A{}; t.Ctor_O(p0); return t }
//line :239:1
func (t *A_arbace_go_embed_files_fn__1220000128_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :239:1
func (t *A_arbace_go_embed_files_fn__1220000128_A) Invoke_O_O__O(self, p1__1220000125_SHARP___1 any) any { var root_1130 any = A_arbace_go_embed_A_const_110.GetRawRoot__O(); var linked_1131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1130, A_arbace_go_embed_resolve_pattern_A_fn_class); var ifn_1132 lang.IFn; if linked_1131 == nil { ifn_1132 = lang.IFn_Cast(root_1130) } else { ifn_1132 = nil }; var arg_1133 any = t.F_dir; var arg_1134 any = p1__1220000125_SHARP___1; if linked_1131 == nil { return ifn_1132.Invoke_O_O__O(arg_1133, arg_1134) } else { return linked_1131.(*A_arbace_go_embed_resolve_pattern_A).Invoke_O_O_O__O(root_1130, arg_1133, arg_1134) } }

func A_arbace_go_embed_files_iter__1220000130__1220000136_A_New() *A_arbace_go_embed_files_iter__1220000130__1220000136_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000130__1220000136_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_A) Ctor() {}
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_A) Invoke_O_O__O(self, s__1220000131__1 any) any { var tmp1 any = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A_New_O_O(s__1220000131__1, self); var tmp2 *jrt.Class; var fncls__1258 *jrt.Class = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A_fn_class; if fncls__1258 == nil { var fncls__1258d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A_fn_class = fncls__1258d; tmp2 = fncls__1258d } else { tmp2 = fncls__1258 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :241:1
func A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A_New_O_O(p0, p1 any) *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A{}; t.Ctor_O_O(p0, p1); return t }
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A) Ctor_O_O(c__s__1220000131, c__iter__1220000130 any) { t.F_s__1220000131 = c__s__1220000131; t.F_iter__1220000130 = c__iter__1220000130 }
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A) Invoke_O__O(self any) any { { var s__1220000131__1 any; var t_ any = t.F_s__1220000131; t.F_s__1220000131 = nil; s__1220000131__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1145 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_1146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1145, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1147 lang.IFn; if linked_1146 == nil { ifn_1147 = lang.IFn_Cast(root_1145) } else { ifn_1147 = nil }; var arg_1148 any = s__1220000131__1; if linked_1146 == nil { temp__1927000414__auto____2 = ifn_1147.Invoke_O__O(arg_1148) } else { temp__1927000414__auto____2 = linked_1146.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1145, arg_1148) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_1149 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1151 lang.IFn; if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = xs__1927001018__auto____3; if linked_1150 == nil { n__4 = ifn_1151.Invoke_O__O(arg_1152) } else { n__4 = linked_1150.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1149, arg_1152) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A_New(); var tmp2 *jrt.Class; var fncls__1211 *jrt.Class = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A_fn_class; if fncls__1211 == nil { var fncls__1211d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A_fn_class = fncls__1211d; tmp2 = fncls__1211d } else { tmp2 = fncls__1211 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_1212 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1212, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1214 lang.IFn; if linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; var arg_1215 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_1216 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_1217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1216, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1218 lang.IFn
														if linked_1217 == nil { ifn_1218 = lang.IFn_Cast(root_1216) } else { ifn_1218 = nil }; var arg_1219 any; var root_1220 any = A_arbace_go_embed_A_const_112.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1220, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any; var tmp5 any = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A_New(); var tmp6 *jrt.Class; var fncls__1230 *jrt.Class = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A_fn_class; if fncls__1230 == nil { var fncls__1230d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A_fn_class = fncls__1230d; tmp6 = fncls__1230d } else { tmp6 = fncls__1230 }; arg_1223 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1224 any; var root_1231 any = A_arbace_go_embed_A_const_113.GetRawRoot__O(); var linked_1232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1231, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_1233 lang.IFn; if linked_1232 == nil { ifn_1233 = lang.IFn_Cast(root_1231) } else { ifn_1233 = nil }; var arg_1234 any; var tmp7 any = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A_New(); var tmp8 *jrt.Class; var fncls__1244 *jrt.Class = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A_fn_class; if fncls__1244 == nil { var fncls__1244d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A_fn_class = fncls__1244d; tmp8 = fncls__1244d } else { tmp8 = fncls__1244 }; arg_1234 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_1235 any = n__4; if linked_1232 == nil { arg_1224 = ifn_1233.Invoke_O_O__O(arg_1234, arg_1235) } else { arg_1224 = linked_1232.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_1231, arg_1234, arg_1235) }; if linked_1221 == nil { arg_1219 = ifn_1222.Invoke_O_O__O(arg_1223, arg_1224) } else { arg_1219 = linked_1221.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1220, arg_1223, arg_1224) }; if linked_1217 == nil { tmp4 = ifn_1218.Invoke_O__O(arg_1219) } else { tmp4 = linked_1217.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1216, arg_1219) }
//line :241:1
	arg_1215 = tmp3.Invoke_O__O(tmp4); if linked_1213 == nil { fs__1927001036__auto____6 = ifn_1214.Invoke_O__O(arg_1215) } else { fs__1927001036__auto____6 = linked_1213.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1212, arg_1215) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1245 any = A_arbace_go_embed_A_const_91.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1245, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1247 lang.IFn; if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any = fs__1927001036__auto____6; var arg_1249 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1220000130); var tmp10 any; var root_1250 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1250, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1252 lang.IFn; if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = s__1220000131__1; if linked_1251 == nil { tmp10 = ifn_1252.Invoke_O__O(arg_1253) } else { tmp10 = linked_1251.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1250, arg_1253) }; arg_1249 = tmp9.Invoke_O__O(tmp10); if linked_1246 == nil { return ifn_1247.Invoke_O_O__O(arg_1248, arg_1249) } else { return linked_1246.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1245, arg_1248, arg_1249) } } else { var tmp11 any; var root_1254 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_1255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1254, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1256 lang.IFn; if linked_1255 == nil { ifn_1256 = lang.IFn_Cast(root_1254) } else { ifn_1256 = nil }; var arg_1257 any = s__1220000131__1; if linked_1255 == nil { tmp11 = ifn_1256.Invoke_O__O(arg_1257) } else { tmp11 = linked_1255.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1254, arg_1257) }; s__1220000131__1 = tmp11; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :241:1
func A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A_New() *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A) Ctor() {}
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A) Invoke_O_O__O(self, s__1220000133__1 any) any { var tmp1 any = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A_New_O_O(s__1220000133__1, self); var tmp2 *jrt.Class; var fncls__1210 *jrt.Class = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A_fn_class; if fncls__1210 == nil { var fncls__1210d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A_fn_class = fncls__1210d; tmp2 = fncls__1210d } else { tmp2 = fncls__1210 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :241:1
func A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A_New_O_O(p0, p1 any) *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A{}; t.Ctor_O_O(p0, p1); return t }
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A) Ctor_O_O(c__s__1220000133, c__iter__1220000132 any) { t.F_s__1220000133 = c__s__1220000133; t.F_iter__1220000132 = c__iter__1220000132 }
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A) Invoke_O__O(self any) any { { var s__1220000133__1 any; var t_ any = t.F_s__1220000133; t.F_s__1220000133 = nil; s__1220000133__1 = t_; for { var temp__1927000414__auto____2 any; var root_1153 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_1154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1153, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1155 lang.IFn; if linked_1154 == nil { ifn_1155 = lang.IFn_Cast(root_1153) } else { ifn_1155 = nil }; var arg_1156 any = s__1220000133__1; if linked_1154 == nil { temp__1927000414__auto____2 = ifn_1155.Invoke_O__O(arg_1156) } else { temp__1927000414__auto____2 = linked_1154.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1153, arg_1156) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1220000133__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1157 any = A_arbace_go_embed_A_const_79.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any = s__1220000133__3; if linked_1158 == nil { tmp1 = ifn_1159.Invoke_O__O(arg_1160) } else { tmp1 = linked_1158.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1157, arg_1160) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1161 any = A_arbace_go_embed_A_const_80.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = s__1220000133__3; if linked_1162 == nil { c__1927001037__auto____4 = ifn_1163.Invoke_O__O(arg_1164) } else { c__1927001037__auto____4 = linked_1162.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1161, arg_1164) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1220000135__6 any; var root_1165 any = A_arbace_go_embed_A_const_81.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1167 lang.IFn; if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1166 == nil { b__1220000135__6 = ifn_1167.Invoke_O__O(arg_1168) } else { b__1220000135__6 = linked_1166.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1165, arg_1168) }; var tmp2 any = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A_New_I_O_O(size__1927001038__auto____5, b__1220000135__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1174 *jrt.Class = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A_fn_class; if fncls__1174 == nil { var fncls__1174d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A_fn_class = fncls__1174d; tmp3 = fncls__1174d } else { tmp3 = fncls__1174 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1175 any = A_arbace_go_embed_A_const_83.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1177 lang.IFn; if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any; var root_1180 any = A_arbace_go_embed_A_const_84.GetRawRoot__O(); var linked_1181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1180, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1182 lang.IFn; if linked_1181 == nil { ifn_1182 = lang.IFn_Cast(root_1180) } else { ifn_1182 = nil }; var arg_1183 any = b__1220000135__6; if linked_1181 == nil { arg_1178 = ifn_1182.Invoke_O__O(arg_1183) } else { arg_1178 = linked_1181.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1180, arg_1183) }; var arg_1179 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1220000132); var tmp5 any; var root_1184 any = A_arbace_go_embed_A_const_85.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1184, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1186 lang.IFn; if linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var arg_1187 any = s__1220000133__3; if linked_1185 == nil { tmp5 = ifn_1186.Invoke_O__O(arg_1187) } else { tmp5 = linked_1185.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1184, arg_1187) }; arg_1179 = tmp4.Invoke_O__O(tmp5); if linked_1176 == nil { return ifn_1177.Invoke_O_O__O(arg_1178, arg_1179) } else { return linked_1176.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1175, arg_1178, arg_1179) } } else { var root_1188 any = A_arbace_go_embed_A_const_83.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1190 lang.IFn; if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any; var root_1193 any = A_arbace_go_embed_A_const_84.GetRawRoot__O(); var linked_1194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1193, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1195 lang.IFn; if linked_1194 == nil { ifn_1195 = lang.IFn_Cast(root_1193) } else { ifn_1195 = nil }; var arg_1196 any = b__1220000135__6; if linked_1194 == nil { arg_1191 = ifn_1195.Invoke_O__O(arg_1196) } else { arg_1191 = linked_1194.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1193, arg_1196) }; var arg_1192 any; if linked_1189 == nil { return ifn_1190.Invoke_O_O__O(arg_1191, arg_1192) } else { return linked_1189.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1188, arg_1191, arg_1192) } } } else { var d__4 any; var root_1197 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1199 lang.IFn; if linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any = s__1220000133__3; if linked_1198 == nil { d__4 = ifn_1199.Invoke_O__O(arg_1200) } else { d__4 = linked_1198.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1197, arg_1200) }; var root_1201 any = A_arbace_go_embed_A_const_86.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1201, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1203 lang.IFn; if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26), jrt.RefArrayOf(jrt.Object_class, d__4, nil)).Ref(); var arg_1205 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1220000132); var tmp7 any; var root_1206 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1208 lang.IFn; if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any = s__1220000133__3; if linked_1207 == nil { tmp7 = ifn_1208.Invoke_O__O(arg_1209) } else { tmp7 = linked_1207.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1206, arg_1209) }; arg_1205 = tmp6.Invoke_O__O(tmp7); if linked_1202 == nil { return ifn_1203.Invoke_O_O__O(arg_1204, arg_1205) } else { return linked_1202.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1201, arg_1204, arg_1205) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :241:1
func A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1220000135, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1220000135 = c__b__1220000135; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A) Invoke_O__O(self any) any { { var i__1220000134__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1220000134__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1220000134__1)); var root_1169 any = A_arbace_go_embed_A_const_82.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = t.F_b__1220000135; var arg_1173 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26), jrt.RefArrayOf(jrt.Object_class, d__2, nil)).Ref(); if linked_1170 == nil { ifn_1171.Invoke_O_O__O(arg_1172, arg_1173) } else { linked_1170.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1169, arg_1172, arg_1173) }; i__1220000134__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1220000134__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A_New() *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A) Ctor() {}
//line :242:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A) Invoke_O_O__O(self, p1__1220000126_SHARP___1 any) any { var root_1225 any = A_arbace_go_embed_A_const_13.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1225, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1227 lang.IFn; if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = Lit_2; var arg_1229 any = p1__1220000126_SHARP___1; if linked_1226 == nil { return ifn_1227.Invoke_O_O__O(arg_1228, arg_1229) } else { return linked_1226.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1225, arg_1228, arg_1229) } }
//line :242:1
func A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A_New() *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A) Ctor() {}
//line :242:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A) Invoke_O_O__O(self, p1__1220000127_SHARP___1 any) any { var root_1236 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any; var root_1240 any = A_arbace_go_embed_A_const_106.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, A_arbace_go_embed_name_split_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = p1__1220000127_SHARP___1; if linked_1241 == nil { arg_1239 = ifn_1242.Invoke_O__O(arg_1243) } else { arg_1239 = linked_1241.(*A_arbace_go_embed_name_split_A).Invoke_O_O__O(root_1240, arg_1243) }; if linked_1237 == nil { return ifn_1238.Invoke_O__O(arg_1239) } else { return linked_1237.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1236, arg_1239) } }





func A_arbace_go_embed_files_iter__1220000150__1220000154_A_New_O_O(p0, p1 any) *A_arbace_go_embed_files_iter__1220000150__1220000154_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000150__1220000154_A{}; t.Ctor_O_O(p0, p1); return t }
//line :248:1
func (t *A_arbace_go_embed_files_iter__1220000150__1220000154_A) Ctor_O_O(c__dir, c__hashes any) { t.F_dir = c__dir; t.F_hashes = c__hashes }
//line :248:1
func (t *A_arbace_go_embed_files_iter__1220000150__1220000154_A) Invoke_O_O__O(self, s__1220000151__1 any) any { var tmp1 any = A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A_New_O_O_O_O(t.F_dir, s__1220000151__1, self, t.F_hashes); var tmp2 *jrt.Class; var fncls__1384 *jrt.Class = A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A_fn_class; if fncls__1384 == nil { var fncls__1384d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A_fn_class = fncls__1384d; tmp2 = fncls__1384d } else { tmp2 = fncls__1384 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :248:1
func A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :248:1
func (t *A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A) Ctor_O_O_O_O(c__dir, c__s__1220000151, c__iter__1220000150, c__hashes any) { t.F_dir = c__dir; t.F_s__1220000151 = c__s__1220000151; t.F_iter__1220000150 = c__iter__1220000150; t.F_hashes = c__hashes }
//line :248:1
func (t *A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A) Invoke_O__O(self any) any { { var s__1220000151__1 any; var t_ any = t.F_s__1220000151; t.F_s__1220000151 = nil; s__1220000151__1 = t_; for { var temp__1927000414__auto____2 any; var root_1273 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1275 lang.IFn; if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = s__1220000151__1; if linked_1274 == nil { temp__1927000414__auto____2 = ifn_1275.Invoke_O__O(arg_1276) } else { temp__1927000414__auto____2 = linked_1274.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1273, arg_1276) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1220000151__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1277 any = A_arbace_go_embed_A_const_79.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = s__1220000151__3; if linked_1278 == nil { tmp1 = ifn_1279.Invoke_O__O(arg_1280) } else { tmp1 = linked_1278.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1277, arg_1280) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1281 any = A_arbace_go_embed_A_const_80.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1281, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1283 lang.IFn; if linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = s__1220000151__3; if linked_1282 == nil { c__1927001037__auto____4 = ifn_1283.Invoke_O__O(arg_1284) } else { c__1927001037__auto____4 = linked_1282.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1281, arg_1284) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1220000153__6 any; var root_1285 any = A_arbace_go_embed_A_const_81.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1287 lang.IFn; if linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1286 == nil { b__1220000153__6 = ifn_1287.Invoke_O__O(arg_1288) } else { b__1220000153__6 = linked_1286.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1285, arg_1288) }; var tmp2 any = A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A_New_O_O_O_I_O(t.F_dir, t.F_hashes, b__1220000153__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1321 *jrt.Class = A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A_fn_class; if fncls__1321 == nil { var fncls__1321d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A_fn_class = fncls__1321d; tmp3 = fncls__1321d } else { tmp3 = fncls__1321 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1322 any = A_arbace_go_embed_A_const_83.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1322, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1324 lang.IFn; if linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any; var root_1327 any = A_arbace_go_embed_A_const_84.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1327, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1329 lang.IFn; if linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; var arg_1330 any = b__1220000153__6; if linked_1328 == nil { arg_1325 = ifn_1329.Invoke_O__O(arg_1330) } else { arg_1325 = linked_1328.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1327, arg_1330) }; var arg_1326 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1220000150); var tmp5 any; var root_1331 any = A_arbace_go_embed_A_const_85.GetRawRoot__O(); var linked_1332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1331, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1333 lang.IFn; if linked_1332 == nil { ifn_1333 = lang.IFn_Cast(root_1331) } else { ifn_1333 = nil }; var arg_1334 any = s__1220000151__3; if linked_1332 == nil { tmp5 = ifn_1333.Invoke_O__O(arg_1334) } else { tmp5 = linked_1332.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1331, arg_1334) }; arg_1326 = tmp4.Invoke_O__O(tmp5); if linked_1323 == nil { return ifn_1324.Invoke_O_O__O(arg_1325, arg_1326) } else { return linked_1323.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1322, arg_1325, arg_1326) } } else { var root_1335 any = A_arbace_go_embed_A_const_83.GetRawRoot__O(); var linked_1336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1335, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1337 lang.IFn; if linked_1336 == nil { ifn_1337 = lang.IFn_Cast(root_1335) } else { ifn_1337 = nil }; var arg_1338 any; var root_1340 any = A_arbace_go_embed_A_const_84.GetRawRoot__O(); var linked_1341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1340, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1342 lang.IFn; if linked_1341 == nil { ifn_1342 = lang.IFn_Cast(root_1340) } else { ifn_1342 = nil }; var arg_1343 any = b__1220000153__6; if linked_1341 == nil { arg_1338 = ifn_1342.Invoke_O__O(arg_1343) } else { arg_1338 = linked_1341.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1340, arg_1343) }; var arg_1339 any; if linked_1336 == nil { return ifn_1337.Invoke_O_O__O(arg_1338, arg_1339) } else { return linked_1336.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1335, arg_1338, arg_1339) } } } else { var n__4 any; var root_1344 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_1345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1344, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1346 lang.IFn; if linked_1345 == nil { ifn_1346 = lang.IFn_Cast(root_1344) } else { ifn_1346 = nil }; var arg_1347 any = s__1220000151__3; if linked_1345 == nil { n__4 = ifn_1346.Invoke_O__O(arg_1347) } else { n__4 = linked_1345.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1344, arg_1347) }; var root_1348 any = A_arbace_go_embed_A_const_86.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any; var tmp6 any; var root_1353 any = A_arbace_go_embed_A_const_69.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1355 lang.IFn
														if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any = n__4; var arg_1357 any = Lit_26; if linked_1354 == nil { tmp6 = ifn_1355.Invoke_O_O__O(arg_1356, arg_1357) } else { tmp6 = linked_1354.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1353, arg_1356, arg_1357) }; if jrt.J2g_Truth(tmp6) { arg_1351 = lang.Tuple_Create_O_O__IPersistentVector(n__4, nil) } else { var tmp7 *jrt.File = jrt.File_Cast(t.F_dir); var bs__5 any = jrt.Files_ReadAllBytes_Path__B1(jrt.File_New_File_String(tmp7, jrt.String_Cast(n__4)).ToPath__Path()).Ref(); var h__6 any = lang.RT_Get_O_O__O_NoInit(t.F_hashes, n__4); var tmp8 any
															var and__1927000168__auto____7 any = h__6


		if jrt.J2g_Truth(and__1927000168__auto____7) { var root_1358 any = A_arbace_go_embed_A_const_13.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any; var root_1363 any = A_arbace_go_embed_A_const_116.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1363, A_arbace_go_embed_sha256_hex_A_fn_class); var ifn_1365 lang.IFn; if linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any = bs__5; if linked_1364 == nil { arg_1361 = ifn_1365.Invoke_O__O(arg_1366) } else { arg_1361 = linked_1364.(*A_arbace_go_embed_sha256_hex_A).Invoke_O_O__O(root_1363, arg_1366) }; var arg_1362 any; var root_1367 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_1368 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1367, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1369 lang.IFn; if linked_1368 == nil { ifn_1369 = lang.IFn_Cast(root_1367) } else { ifn_1369 = nil }; var arg_1370 any = h__6; if linked_1368 == nil { arg_1362 = ifn_1369.Invoke_O__O(arg_1370) } else { arg_1362 = linked_1368.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1367, arg_1370) }; if linked_1359 == nil { tmp8 = ifn_1360.Invoke_O_O__O(arg_1361, arg_1362) } else { tmp8 = linked_1359.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1358, arg_1361, arg_1362) } } else { tmp8 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_1371 any = A_arbace_go_embed_A_const_93.GetRawRoot__O(); var linked_1372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1371, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1373 lang.IFn
			if linked_1372 == nil { ifn_1373 = lang.IFn_Cast(root_1371) } else { ifn_1373 = nil }; var arg_1374 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_29, nil, Lit_30, nil, Lit_31, nil); var tmp11 any; var root_1376 any = A_arbace_go_embed_A_const_116.GetRawRoot__O(); var linked_1377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1376, A_arbace_go_embed_sha256_hex_A_fn_class); var ifn_1378 lang.IFn; if linked_1377 == nil { ifn_1378 = lang.IFn_Cast(root_1376) } else { ifn_1378 = nil }; var arg_1379 any = bs__5; if linked_1377 == nil { tmp11 = ifn_1378.Invoke_O__O(arg_1379) } else { tmp11 = linked_1377.(*A_arbace_go_embed_sha256_hex_A).Invoke_O_O__O(root_1376, arg_1379) }; arg_1374 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, n__4, nil, tmp11, nil, h__6)).Ref(); var arg_1375 any = A_arbace_go_embed_A_const_118; if linked_1372 == nil { tmp9 = ifn_1373.Invoke_O_O__O(arg_1374, arg_1375) } else { tmp9 = linked_1372.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1371, arg_1374, arg_1375) }
//line :253:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp9))) }
//line :249:1
		arg_1351 = lang.Tuple_Create_O_O__IPersistentVector(n__4, bs__5) }
//line :248:1
	var arg_1352 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1220000150); var tmp13 any; var root_1380 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1380, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1382 lang.IFn; if linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any = s__1220000151__3; if linked_1381 == nil { tmp13 = ifn_1382.Invoke_O__O(arg_1383) } else { tmp13 = linked_1381.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1380, arg_1383) }; arg_1352 = tmp12.Invoke_O__O(tmp13); if linked_1349 == nil { return ifn_1350.Invoke_O_O__O(arg_1351, arg_1352) } else { return linked_1349.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1348, arg_1351, arg_1352) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :248:1
func A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :248:1
func (t *A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A) Ctor_O_O_O_I_O(c__dir, c__hashes, c__b__1220000153 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_dir = c__dir; t.F_hashes = c__hashes; t.F_b__1220000153 = c__b__1220000153; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :248:1
func (t *A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A) Invoke_O__O(self any) any { { var i__1220000152__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1220000152__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1220000152__1)); var root_1289 any = A_arbace_go_embed_A_const_82.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = t.F_b__1220000153; var arg_1293 any; var tmp2 any; var root_1294 any = A_arbace_go_embed_A_const_69.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1294, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1296 lang.IFn
																if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any = n__2; var arg_1298 any = Lit_26; if linked_1295 == nil { tmp2 = ifn_1296.Invoke_O_O__O(arg_1297, arg_1298) } else { tmp2 = linked_1295.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1294, arg_1297, arg_1298) }; if jrt.J2g_Truth(tmp2) { arg_1293 = lang.Tuple_Create_O_O__IPersistentVector(n__2, nil) } else { var tmp3 *jrt.File = jrt.File_Cast(t.F_dir); var bs__3 any = jrt.Files_ReadAllBytes_Path__B1(jrt.File_New_File_String(tmp3, jrt.String_Cast(n__2)).ToPath__Path()).Ref(); var h__4 any = lang.RT_Get_O_O__O_NoInit(t.F_hashes, n__2); var tmp4 any
																	var and__1927000168__auto____5 any = h__4


		if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1299 any = A_arbace_go_embed_A_const_13.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1299, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any; var root_1304 any = A_arbace_go_embed_A_const_116.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1304, A_arbace_go_embed_sha256_hex_A_fn_class); var ifn_1306 lang.IFn; if linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any = bs__3; if linked_1305 == nil { arg_1302 = ifn_1306.Invoke_O__O(arg_1307) } else { arg_1302 = linked_1305.(*A_arbace_go_embed_sha256_hex_A).Invoke_O_O__O(root_1304, arg_1307) }; var arg_1303 any; var root_1308 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1308, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1310 lang.IFn; if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any = h__4; if linked_1309 == nil { arg_1303 = ifn_1310.Invoke_O__O(arg_1311) } else { arg_1303 = linked_1309.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1308, arg_1311) }; if linked_1300 == nil { tmp4 = ifn_1301.Invoke_O_O__O(arg_1302, arg_1303) } else { tmp4 = linked_1300.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1299, arg_1302, arg_1303) } } else { tmp4 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_1312 any = A_arbace_go_embed_A_const_93.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1314 lang.IFn
			if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_29, nil, Lit_30, nil, Lit_31, nil); var tmp7 any; var root_1317 any = A_arbace_go_embed_A_const_116.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1317, A_arbace_go_embed_sha256_hex_A_fn_class); var ifn_1319 lang.IFn; if linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any = bs__3; if linked_1318 == nil { tmp7 = ifn_1319.Invoke_O__O(arg_1320) } else { tmp7 = linked_1318.(*A_arbace_go_embed_sha256_hex_A).Invoke_O_O__O(root_1317, arg_1320) }; arg_1315 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, n__2, nil, tmp7, nil, h__4)).Ref(); var arg_1316 any = A_arbace_go_embed_A_const_117; if linked_1313 == nil { tmp5 = ifn_1314.Invoke_O_O__O(arg_1315, arg_1316) } else { tmp5 = linked_1313.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1312, arg_1315, arg_1316) }
//line :253:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp5))) }
//line :249:1
		arg_1293 = lang.Tuple_Create_O_O__IPersistentVector(n__2, bs__3) }
//line :248:1
	if linked_1290 == nil { ifn_1291.Invoke_O_O__O(arg_1292, arg_1293) } else { linked_1290.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1289, arg_1292, arg_1293) }; i__1220000152__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1220000152__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_go_embed_check_decl_A_New() *A_arbace_go_embed_check_decl_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_check_decl_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_go_embed_check_decl_A) Ctor() {}
//line :257:1
func (t *A_arbace_go_embed_check_decl_A) Invoke_O_O__O(self, p__1220000161__0 any) any { var map__1220000162__2 any = p__1220000161__0; var map__1220000162__3 any; if lang.ISeq_InstanceOf(map__1220000162__2) { var tmp1 any; var root_1396 any = A_arbace_go_embed_A_const_104.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = map__1220000162__2; if linked_1397 == nil { tmp1 = ifn_1398.Invoke_O__O(arg_1399) } else { tmp1 = linked_1397.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1396, arg_1399) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1400 any = A_arbace_go_embed_A_const_120.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any = map__1220000162__2; if linked_1401 == nil { tmp2 = ifn_1402.Invoke_O__O(arg_1403) } else { tmp2 = linked_1401.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1400, arg_1403) }; map__1220000162__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1404 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1404, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1406 lang.IFn; if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = map__1220000162__2; if linked_1405 == nil { tmp3 = ifn_1406.Invoke_O__O(arg_1407) } else { tmp3 = linked_1405.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1404, arg_1407) }; if jrt.J2g_Truth(tmp3) { var root_1408 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = map__1220000162__2; if linked_1409 == nil { map__1220000162__3 = ifn_1410.Invoke_O__O(arg_1411) } else { map__1220000162__3 = linked_1409.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1408, arg_1411) } } else { map__1220000162__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1220000162__3 = map__1220000162__2 }; var embed_imported_QMARK___4 any = lang.RT_Get_O_O__O_NoInit(map__1220000162__3, A_arbace_go_embed_A_const_121); var names__5 any = lang.RT_Get_O_O__O_NoInit(map__1220000162__3, A_arbace_go_embed_A_const_122); var init_QMARK___6 any = lang.RT_Get_O_O__O_NoInit(map__1220000162__3, A_arbace_go_embed_A_const_123); var typed_QMARK___7 any = lang.RT_Get_O_O__O_NoInit(map__1220000162__3, A_arbace_go_embed_A_const_124); var minor__8 any = lang.RT_Get_O_O__O_NoInit(map__1220000162__3, A_arbace_go_embed_A_const_125); var lang__9 any = lang.RT_Get_O_O__O_NoInit(map__1220000162__3, A_arbace_go_embed_A_const_126); var tmp4 any; var root_1412 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1414 lang.IFn; if





	linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = embed_imported_QMARK___4; if linked_1413 == nil { tmp4 = ifn_1414.Invoke_O__O(arg_1415) } else { tmp4 = linked_1413.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1412, arg_1415) }; if /*line :262:1*/ jrt.J2g_Truth(tmp4) { return Lit_4 } else { var tmp5 bool
		var na_1416 any = names__5; var na_1417 int64 = 1
		if jrt.Long_InstanceOf(na_1416) { var n0_1418 int64 = jrt.NN(jrt.Long_Cast(na_1416)).LongValue__J(); var n1_1419 int64 = na_1417; tmp5 = n0_1418 > n1_1419 } else { tmp5 = lang.Numbers_Gt_O_J__Z_NoInit(na_1416, na_1417) }
//line :262:1
		if tmp5 { return Lit_5 } else { if jrt.J2g_Truth(init_QMARK___6) { return Lit_6 } else { var tmp6 any; var root_1421 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_1422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1421, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1423 lang.IFn



			if linked_1422 == nil { ifn_1423 = lang.IFn_Cast(root_1421) } else { ifn_1423 = nil }; var arg_1424 any = typed_QMARK___7; if linked_1422 == nil { tmp6 = ifn_1423.Invoke_O__O(arg_1424) } else { tmp6 = linked_1422.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1421, arg_1424) }
//line :262:1
			if jrt.J2g_Truth(tmp6) { return Lit_7 } else { var tmp7 any
				var and__1927000168__auto____10 any = minor__8



				if jrt.J2g_Truth(and__1927000168__auto____10) { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Lt_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(minor__8), 16)).Ref() } else { tmp7 = and__1927000168__auto____10 }
//line :262:1
				if jrt.J2g_Truth(tmp7) {




					return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_8, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, nil, lang__9, nil)).Ref() } else {
//line :262:1
						if A_arbace_go_embed_A_const_15 != nil { return nil } else { return nil } } } } } } }

























































































type A_arbace_go_embed_A struct{ jrt.Object }

var A_arbace_go_embed_A_const_pool *jrt.RefArray

var A_arbace_go_embed_A_const_0 *lang.Var

var A_arbace_go_embed_A_const_1 any

var A_arbace_go_embed_A_const_2 *lang.Var

var A_arbace_go_embed_A_const_3 any

var A_arbace_go_embed_A_const_4 *lang.Var

var A_arbace_go_embed_A_const_5 *lang.Var

var A_arbace_go_embed_A_const_6 *lang.Var

var A_arbace_go_embed_A_const_7 *lang.Var

var A_arbace_go_embed_A_const_8 any

var A_arbace_go_embed_A_const_9 *lang.Var

var A_arbace_go_embed_A_const_10 any

var A_arbace_go_embed_A_const_11 *lang.Var

var A_arbace_go_embed_A_const_12 any

var A_arbace_go_embed_A_const_13 *lang.Var

var A_arbace_go_embed_A_const_14 any

var A_arbace_go_embed_A_const_15 *lang.Keyword

var A_arbace_go_embed_A_const_16 any

var A_arbace_go_embed_A_const_17 any

var A_arbace_go_embed_A_const_18 any

var A_arbace_go_embed_A_const_19 any

var A_arbace_go_embed_A_const_20 any

var A_arbace_go_embed_A_const_21 any

var A_arbace_go_embed_A_const_22 any

var A_arbace_go_embed_A_const_23 any

var A_arbace_go_embed_A_const_24 any

var A_arbace_go_embed_A_const_25 any

var A_arbace_go_embed_A_const_26 any

var A_arbace_go_embed_A_const_27 any

var A_arbace_go_embed_A_const_28 any

var A_arbace_go_embed_A_const_29 *lang.Var

var A_arbace_go_embed_A_const_30 *lang.Var

var A_arbace_go_embed_A_const_31 any

var A_arbace_go_embed_A_const_32 any

var A_arbace_go_embed_A_const_33 *lang.Var

var A_arbace_go_embed_A_const_34 *lang.Var

var A_arbace_go_embed_A_const_35 *lang.Var

var A_arbace_go_embed_A_const_36 *lang.Var

var A_arbace_go_embed_A_const_37 *lang.Var

var A_arbace_go_embed_A_const_38 *lang.Var

var A_arbace_go_embed_A_const_39 *lang.Var

var A_arbace_go_embed_A_const_40 *lang.Var

var A_arbace_go_embed_A_const_41 *lang.Var

var A_arbace_go_embed_A_const_42 *lang.Var

var A_arbace_go_embed_A_const_43 any

var A_arbace_go_embed_A_const_44 *lang.Var

var A_arbace_go_embed_A_const_45 *lang.Var

var A_arbace_go_embed_A_const_46 any

var A_arbace_go_embed_A_const_47 any

var A_arbace_go_embed_A_const_48 any

var A_arbace_go_embed_A_const_49 any

var A_arbace_go_embed_A_const_50 any

var A_arbace_go_embed_A_const_51 *lang.Var

var A_arbace_go_embed_A_const_52 *lang.Var

var A_arbace_go_embed_A_const_53 *lang.Var

var A_arbace_go_embed_A_const_54 *lang.Var

var A_arbace_go_embed_A_const_55 any

var A_arbace_go_embed_A_const_56 *lang.Var

var A_arbace_go_embed_A_const_57 *lang.Var

var A_arbace_go_embed_A_const_58 any

var A_arbace_go_embed_A_const_59 *lang.Var

var A_arbace_go_embed_A_const_60 any

var A_arbace_go_embed_A_const_61 any

var A_arbace_go_embed_A_const_62 any

var A_arbace_go_embed_A_const_63 *lang.Var

var A_arbace_go_embed_A_const_64 *lang.Var

var A_arbace_go_embed_A_const_65 *lang.Var

var A_arbace_go_embed_A_const_66 *lang.Var

var A_arbace_go_embed_A_const_67 any

var A_arbace_go_embed_A_const_68 any

var A_arbace_go_embed_A_const_69 *lang.Var

var A_arbace_go_embed_A_const_70 *lang.Var

var A_arbace_go_embed_A_const_71 *lang.Var

var A_arbace_go_embed_A_const_72 any

var A_arbace_go_embed_A_const_73 *lang.Var

var A_arbace_go_embed_A_const_74 any

var A_arbace_go_embed_A_const_75 *lang.Var

var A_arbace_go_embed_A_const_76 any

var A_arbace_go_embed_A_const_77 *lang.Var

var A_arbace_go_embed_A_const_78 *lang.Var

var A_arbace_go_embed_A_const_79 *lang.Var

var A_arbace_go_embed_A_const_80 *lang.Var

var A_arbace_go_embed_A_const_81 *lang.Var

var A_arbace_go_embed_A_const_82 *lang.Var

var A_arbace_go_embed_A_const_83 *lang.Var

var A_arbace_go_embed_A_const_84 *lang.Var

var A_arbace_go_embed_A_const_85 *lang.Var

var A_arbace_go_embed_A_const_86 *lang.Var

var A_arbace_go_embed_A_const_87 *lang.Var

var A_arbace_go_embed_A_const_88 *lang.Var

var A_arbace_go_embed_A_const_89 *lang.Var

var A_arbace_go_embed_A_const_90 *lang.Var

var A_arbace_go_embed_A_const_91 *lang.Var

var A_arbace_go_embed_A_const_92 any

var A_arbace_go_embed_A_const_93 *lang.Var

var A_arbace_go_embed_A_const_94 any

var A_arbace_go_embed_A_const_95 *lang.Var

var A_arbace_go_embed_A_const_96 *lang.Var

var A_arbace_go_embed_A_const_97 *lang.Var

var A_arbace_go_embed_A_const_98 *lang.Var

var A_arbace_go_embed_A_const_99 *lang.Var

var A_arbace_go_embed_A_const_100 *lang.Var

var A_arbace_go_embed_A_const_101 any

var A_arbace_go_embed_A_const_102 any

var A_arbace_go_embed_A_const_103 *lang.Var

var A_arbace_go_embed_A_const_104 *lang.Var

var A_arbace_go_embed_A_const_105 *lang.Var

var A_arbace_go_embed_A_const_106 *lang.Var

var A_arbace_go_embed_A_const_107 *lang.Var

var A_arbace_go_embed_A_const_108 *lang.Var

var A_arbace_go_embed_A_const_109 *lang.Var

var A_arbace_go_embed_A_const_110 *lang.Var

var A_arbace_go_embed_A_const_111 *lang.Keyword

var A_arbace_go_embed_A_const_112 *lang.Var

var A_arbace_go_embed_A_const_113 *lang.Var

var A_arbace_go_embed_A_const_114 *lang.Var

var A_arbace_go_embed_A_const_115 *lang.Var

var A_arbace_go_embed_A_const_116 *lang.Var

var A_arbace_go_embed_A_const_117 any

var A_arbace_go_embed_A_const_118 any

var A_arbace_go_embed_A_const_119 any

var A_arbace_go_embed_A_const_120 *lang.Var

var A_arbace_go_embed_A_const_121 *lang.Keyword

var A_arbace_go_embed_A_const_122 *lang.Keyword

var A_arbace_go_embed_A_const_123 *lang.Keyword

var A_arbace_go_embed_A_const_124 *lang.Keyword

var A_arbace_go_embed_A_const_125 *lang.Keyword

var A_arbace_go_embed_A_const_126 *lang.Keyword

var A_arbace_go_embed_A_init jrt.ClassInit

func A_arbace_go_embed_A_Init() { if !A_arbace_go_embed_A_init.Done() { A_arbace_go_embed_A_init.Run(A_arbace_go_embed_A_clinit) } }

func A_arbace_go_embed_A_clinit() { A_arbace_go_embed_A_clinit_p0(); A_arbace_go_embed_A_clinit_p1(); A_arbace_go_embed_A_clinit_p2(); A_arbace_go_embed_A_clinit_p3(); A_arbace_go_embed_A_clinit_p4(); A_arbace_go_embed_A_clinit_p5(); A_arbace_go_embed_A_clinit_p6(); A_arbace_go_embed_A_clinit_p7(); A_arbace_go_embed_A_clinit_p8(); A_arbace_go_embed_A_clinit_p9() }

func A_arbace_go_embed_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_embed_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 141); A_arbace_go_embed_A_const_0 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[14]); A_arbace_go_embed_A_const_1 = A_arbace_go_embed_A_const_pool.A[15]; A_arbace_go_embed_A_const_2 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[16]); A_arbace_go_embed_A_const_3 = A_arbace_go_embed_A_const_pool.A[17]; A_arbace_go_embed_A_const_4 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[18]); A_arbace_go_embed_A_const_5 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[19]); A_arbace_go_embed_A_const_6 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[20]); A_arbace_go_embed_A_const_7 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[21]); A_arbace_go_embed_A_const_8 = A_arbace_go_embed_A_const_pool.A[22]; A_arbace_go_embed_A_const_9 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[23]); A_arbace_go_embed_A_const_10 = A_arbace_go_embed_A_const_pool.A[24]; A_arbace_go_embed_A_const_11 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[25]) }

func A_arbace_go_embed_A_clinit_p1() { A_arbace_go_embed_A_const_12 = A_arbace_go_embed_A_const_pool.A[26]; A_arbace_go_embed_A_const_13 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[27]); A_arbace_go_embed_A_const_14 = A_arbace_go_embed_A_const_pool.A[28]; A_arbace_go_embed_A_const_15 = lang.Keyword_Cast(A_arbace_go_embed_A_const_pool.A[29]); A_arbace_go_embed_A_const_16 = A_arbace_go_embed_A_const_pool.A[30]; A_arbace_go_embed_A_const_17 = A_arbace_go_embed_A_const_pool.A[31]; A_arbace_go_embed_A_const_18 = A_arbace_go_embed_A_const_pool.A[32]; A_arbace_go_embed_A_const_19 = A_arbace_go_embed_A_const_pool.A[33]; A_arbace_go_embed_A_const_20 = A_arbace_go_embed_A_const_pool.A[34]; A_arbace_go_embed_A_const_21 = A_arbace_go_embed_A_const_pool.A[35]; A_arbace_go_embed_A_const_22 = A_arbace_go_embed_A_const_pool.A[36]; A_arbace_go_embed_A_const_23 = A_arbace_go_embed_A_const_pool.A[37]; A_arbace_go_embed_A_const_24 = A_arbace_go_embed_A_const_pool.A[38]; A_arbace_go_embed_A_const_25 = A_arbace_go_embed_A_const_pool.A[39]; A_arbace_go_embed_A_const_26 = A_arbace_go_embed_A_const_pool.A[40] }

func A_arbace_go_embed_A_clinit_p2() { A_arbace_go_embed_A_const_27 = A_arbace_go_embed_A_const_pool.A[41]; A_arbace_go_embed_A_const_28 = A_arbace_go_embed_A_const_pool.A[42]; A_arbace_go_embed_A_const_29 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[43]); A_arbace_go_embed_A_const_30 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[44]); A_arbace_go_embed_A_const_31 = A_arbace_go_embed_A_const_pool.A[45]; A_arbace_go_embed_A_const_32 = A_arbace_go_embed_A_const_pool.A[46]; A_arbace_go_embed_A_const_33 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[47]); A_arbace_go_embed_A_const_34 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[48]); A_arbace_go_embed_A_const_35 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[49]); A_arbace_go_embed_A_const_36 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[50]); A_arbace_go_embed_A_const_37 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[51]); A_arbace_go_embed_A_const_38 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[52]); A_arbace_go_embed_A_const_39 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[53]) }

func A_arbace_go_embed_A_clinit_p3() { A_arbace_go_embed_A_const_40 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[54]); A_arbace_go_embed_A_const_41 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[55]); A_arbace_go_embed_A_const_42 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[56]); A_arbace_go_embed_A_const_43 = A_arbace_go_embed_A_const_pool.A[57]; A_arbace_go_embed_A_const_44 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[58]); A_arbace_go_embed_A_const_45 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[59]); A_arbace_go_embed_A_const_46 = A_arbace_go_embed_A_const_pool.A[60]; A_arbace_go_embed_A_const_47 = A_arbace_go_embed_A_const_pool.A[61]; A_arbace_go_embed_A_const_48 = A_arbace_go_embed_A_const_pool.A[62]; A_arbace_go_embed_A_const_49 = A_arbace_go_embed_A_const_pool.A[63]; A_arbace_go_embed_A_const_50 = A_arbace_go_embed_A_const_pool.A[64]; A_arbace_go_embed_A_const_51 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[65]); A_arbace_go_embed_A_const_52 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[66]) }

func A_arbace_go_embed_A_clinit_p4() { A_arbace_go_embed_A_const_53 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[67]); A_arbace_go_embed_A_const_54 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[68]); A_arbace_go_embed_A_const_55 = A_arbace_go_embed_A_const_pool.A[69]; A_arbace_go_embed_A_const_56 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[70]); A_arbace_go_embed_A_const_57 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[71]); A_arbace_go_embed_A_const_58 = A_arbace_go_embed_A_const_pool.A[72]; A_arbace_go_embed_A_const_59 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[73]); A_arbace_go_embed_A_const_60 = A_arbace_go_embed_A_const_pool.A[74]; A_arbace_go_embed_A_const_61 = A_arbace_go_embed_A_const_pool.A[75]; A_arbace_go_embed_A_const_62 = A_arbace_go_embed_A_const_pool.A[76]; A_arbace_go_embed_A_const_63 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[77]); A_arbace_go_embed_A_const_64 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[78]); A_arbace_go_embed_A_const_65 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[79]) }

func A_arbace_go_embed_A_clinit_p5() { A_arbace_go_embed_A_const_66 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[80]); A_arbace_go_embed_A_const_67 = A_arbace_go_embed_A_const_pool.A[81]; A_arbace_go_embed_A_const_68 = A_arbace_go_embed_A_const_pool.A[82]; A_arbace_go_embed_A_const_69 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[83]); A_arbace_go_embed_A_const_70 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[84]); A_arbace_go_embed_A_const_71 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[85]); A_arbace_go_embed_A_const_72 = A_arbace_go_embed_A_const_pool.A[86]; A_arbace_go_embed_A_const_73 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[87]); A_arbace_go_embed_A_const_74 = A_arbace_go_embed_A_const_pool.A[88]; A_arbace_go_embed_A_const_75 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[89]); A_arbace_go_embed_A_const_76 = A_arbace_go_embed_A_const_pool.A[90]; A_arbace_go_embed_A_const_77 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[91]); A_arbace_go_embed_A_const_78 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[92]) }

func A_arbace_go_embed_A_clinit_p6() { A_arbace_go_embed_A_const_79 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[93]); A_arbace_go_embed_A_const_80 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[94]); A_arbace_go_embed_A_const_81 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[95]); A_arbace_go_embed_A_const_82 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[96]); A_arbace_go_embed_A_const_83 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[97]); A_arbace_go_embed_A_const_84 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[98]); A_arbace_go_embed_A_const_85 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[99]); A_arbace_go_embed_A_const_86 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[100]); A_arbace_go_embed_A_const_87 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[101]); A_arbace_go_embed_A_const_88 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[102]); A_arbace_go_embed_A_const_89 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[103]); A_arbace_go_embed_A_const_90 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[104]) }

func A_arbace_go_embed_A_clinit_p7() { A_arbace_go_embed_A_const_91 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[105]); A_arbace_go_embed_A_const_92 = A_arbace_go_embed_A_const_pool.A[106]; A_arbace_go_embed_A_const_93 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[107]); A_arbace_go_embed_A_const_94 = A_arbace_go_embed_A_const_pool.A[108]; A_arbace_go_embed_A_const_95 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[109]); A_arbace_go_embed_A_const_96 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[110]); A_arbace_go_embed_A_const_97 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[111]); A_arbace_go_embed_A_const_98 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[112]); A_arbace_go_embed_A_const_99 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[113]); A_arbace_go_embed_A_const_100 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[114]); A_arbace_go_embed_A_const_101 = A_arbace_go_embed_A_const_pool.A[115]; A_arbace_go_embed_A_const_102 = A_arbace_go_embed_A_const_pool.A[116]; A_arbace_go_embed_A_const_103 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[117]) }

func A_arbace_go_embed_A_clinit_p8() { A_arbace_go_embed_A_const_104 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[118]); A_arbace_go_embed_A_const_105 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[119]); A_arbace_go_embed_A_const_106 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[120]); A_arbace_go_embed_A_const_107 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[121]); A_arbace_go_embed_A_const_108 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[122]); A_arbace_go_embed_A_const_109 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[123]); A_arbace_go_embed_A_const_110 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[124]); A_arbace_go_embed_A_const_111 = lang.Keyword_Cast(A_arbace_go_embed_A_const_pool.A[125]); A_arbace_go_embed_A_const_112 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[126]); A_arbace_go_embed_A_const_113 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[127]); A_arbace_go_embed_A_const_114 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[128]); A_arbace_go_embed_A_const_115 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[129]) }

func A_arbace_go_embed_A_clinit_p9() { A_arbace_go_embed_A_const_116 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[130]); A_arbace_go_embed_A_const_117 = A_arbace_go_embed_A_const_pool.A[131]; A_arbace_go_embed_A_const_118 = A_arbace_go_embed_A_const_pool.A[132]; A_arbace_go_embed_A_const_119 = A_arbace_go_embed_A_const_pool.A[133]; A_arbace_go_embed_A_const_120 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[134]); A_arbace_go_embed_A_const_121 = lang.Keyword_Cast(A_arbace_go_embed_A_const_pool.A[135]); A_arbace_go_embed_A_const_122 = lang.Keyword_Cast(A_arbace_go_embed_A_const_pool.A[136]); A_arbace_go_embed_A_const_123 = lang.Keyword_Cast(A_arbace_go_embed_A_const_pool.A[137]); A_arbace_go_embed_A_const_124 = lang.Keyword_Cast(A_arbace_go_embed_A_const_pool.A[138]); A_arbace_go_embed_A_const_125 = lang.Keyword_Cast(A_arbace_go_embed_A_const_pool.A[139]); A_arbace_go_embed_A_const_126 = lang.Keyword_Cast(A_arbace_go_embed_A_const_pool.A[140]) }

func A_arbace_go_embed_A_New() *A_arbace_go_embed_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_A{}; t.Ctor(); return t }

func (t *A_arbace_go_embed_A) Ctor() {}

func (t *A_arbace_go_embed_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_embed_A) GetClass__Class() *jrt.Class { return A_arbace_go_embed_A_class }

func (t *A_arbace_go_embed_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_embed_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_embed_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_embed_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_embed_A); return ok }

func A_arbace_go_embed_A_Cast(x any) *A_arbace_go_embed_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_embed_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_embed_A_class)) }; return v }



type A_arbace_go_embed_bad_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_embed_bad_name_QMARK__A_fn_class *jrt.Class



type A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A struct{ j2g_header uint64 }

var A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A_fn_class *jrt.Class



type A_arbace_go_embed_check_decl_A struct{ j2g_header uint64 }

var A_arbace_go_embed_check_decl_A_fn_class *jrt.Class



type A_arbace_go_embed_directive_patterns_A struct{ j2g_header uint64 }

var A_arbace_go_embed_directive_patterns_A_fn_class *jrt.Class



type A_arbace_go_embed_directive_patterns_fn__1220000026_A struct{ j2g_header uint64 }

var A_arbace_go_embed_directive_patterns_fn__1220000026_A_fn_class *jrt.Class



type A_arbace_go_embed_embed_error_A struct{ j2g_header uint64 }

var A_arbace_go_embed_embed_error_A_fn_class *jrt.Class



type A_arbace_go_embed_eval1220000004_A struct{ jrt.Object }

func A_arbace_go_embed_eval1220000004_A_New() *A_arbace_go_embed_eval1220000004_A { t := &A_arbace_go_embed_eval1220000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_embed_eval1220000004_A) Ctor() {}

func (t *A_arbace_go_embed_eval1220000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_embed_eval1220000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_embed_eval1220000004_A_class }

func (t *A_arbace_go_embed_eval1220000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_embed_eval1220000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_embed_eval1220000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_embed_eval1220000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_embed_eval1220000004_A); return ok }

func A_arbace_go_embed_eval1220000004_A_Cast(x any) *A_arbace_go_embed_eval1220000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_embed_eval1220000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_embed_eval1220000004_A_class)) }; return v }



type A_arbace_go_embed_eval1220000004_loading__1927001464__auto____1220000005_A struct{ j2g_header uint64 }

var A_arbace_go_embed_eval1220000004_loading__1927001464__auto____1220000005_A_fn_class *jrt.Class



type A_arbace_go_embed_eval1220000008_A struct{ jrt.Object }

func A_arbace_go_embed_eval1220000008_A_New() *A_arbace_go_embed_eval1220000008_A { t := &A_arbace_go_embed_eval1220000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_embed_eval1220000008_A) Ctor() {}

func (t *A_arbace_go_embed_eval1220000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_embed_eval1220000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_embed_eval1220000008_A_class }

func (t *A_arbace_go_embed_eval1220000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_embed_eval1220000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_embed_eval1220000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_embed_eval1220000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_embed_eval1220000008_A); return ok }

func A_arbace_go_embed_eval1220000008_A_Cast(x any) *A_arbace_go_embed_eval1220000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_embed_eval1220000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_embed_eval1220000008_A_class)) }; return v }



type A_arbace_go_embed_eval1220000008_fn__1220000009_A struct{ j2g_header uint64 }

var A_arbace_go_embed_eval1220000008_fn__1220000009_A_fn_class *jrt.Class



type A_arbace_go_embed_file_less_A struct{ j2g_header uint64 }

var A_arbace_go_embed_file_less_A_fn_class *jrt.Class



type A_arbace_go_embed_files_A struct{ j2g_header uint64 }

var A_arbace_go_embed_files_A_fn_class *jrt.Class



type A_arbace_go_embed_files_fn__1220000128_A struct{ j2g_header uint64; F_dir any }

var A_arbace_go_embed_files_fn__1220000128_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000130__1220000136_A struct{ j2g_header uint64 }

var A_arbace_go_embed_files_iter__1220000130__1220000136_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A struct{ j2g_header uint64; F_s__1220000131, F_iter__1220000130 any }

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A struct{ j2g_header uint64 }

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A struct{ j2g_header uint64 }

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A struct{ j2g_header uint64 }

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A struct{ j2g_header uint64; F_s__1220000133, F_iter__1220000132 any }

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1220000135, F_c__1927001037__auto__ any }

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000150__1220000154_A struct{ j2g_header uint64; F_dir, F_hashes any }

var A_arbace_go_embed_files_iter__1220000150__1220000154_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A struct{ j2g_header uint64; F_dir, F_s__1220000151, F_iter__1220000150, F_hashes any }

var A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A struct{ j2g_header uint64; F_dir, F_hashes, F_b__1220000153 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_A struct{ j2g_header uint64 }

var A_arbace_go_embed_glob_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000059_A struct{ j2g_header uint64 }

var A_arbace_go_embed_glob_fn__1220000059_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000062_A struct{ j2g_header uint64 }

var A_arbace_go_embed_glob_fn__1220000062_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000068_A struct{ j2g_header uint64; F_dir any }

var A_arbace_go_embed_glob_fn__1220000068_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A struct{ j2g_header uint64; F_rx, F_dir, F_s any }

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A struct{ j2g_header uint64; F_rx, F_dir, F_s__1220000073, F_s, F_iter__1220000072 any }

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A struct{ j2g_header uint64; F_rx any }

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A struct{ j2g_header uint64; F_p any }

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A struct{ j2g_header uint64; F_p, F_s__1220000075, F_iter__1220000074 any }

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A struct{ j2g_header uint64; F_p, F_b__1220000077 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_regex_A struct{ j2g_header uint64 }

var A_arbace_go_embed_glob_regex_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_regex_fn__1220000041_A struct{ j2g_header uint64; F_i any; F_n int32; F_p any }

var A_arbace_go_embed_glob_regex_fn__1220000041_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_regex_fn__1220000043_A struct{ j2g_header uint64 }

var A_arbace_go_embed_glob_regex_fn__1220000043_A_fn_class *jrt.Class



type A_arbace_go_embed_name_split_A struct{ j2g_header uint64 }

var A_arbace_go_embed_name_split_A_fn_class *jrt.Class



type A_arbace_go_embed_parse_patterns_A struct{ j2g_header uint64 }

var A_arbace_go_embed_parse_patterns_A_fn_class *jrt.Class



type A_arbace_go_embed_parse_patterns_fn__1220000020_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_embed_parse_patterns_fn__1220000020_A_fn_class *jrt.Class



type A_arbace_go_embed_parse_patterns_fn__1220000022_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_embed_parse_patterns_fn__1220000022_A_fn_class *jrt.Class



type A_arbace_go_embed_resolve_pattern_A struct{ j2g_header uint64 }

var A_arbace_go_embed_resolve_pattern_A_fn_class *jrt.Class



type A_arbace_go_embed_resolve_pattern_walk__1220000100_A struct{ j2g_header uint64; F_pattern, F_list, F_all, F_n any }

var A_arbace_go_embed_resolve_pattern_walk__1220000100_A_fn_class *jrt.Class



type A_arbace_go_embed_resolve_pattern_walk__1220000106_A struct{ j2g_header uint64; F_pattern, F_list, F_n, F_all any }

var A_arbace_go_embed_resolve_pattern_walk__1220000106_A_fn_class *jrt.Class



type A_arbace_go_embed_sha256_hex_A struct{ j2g_header uint64 }

var A_arbace_go_embed_sha256_hex_A_fn_class *jrt.Class



type A_arbace_go_embed_sha256_hex_fn__1220000122_A struct{ j2g_header uint64 }

var A_arbace_go_embed_sha256_hex_fn__1220000122_A_fn_class *jrt.Class



type A_arbace_go_embed_sorted_children_A struct{ j2g_header uint64 }

var A_arbace_go_embed_sorted_children_A_fn_class *jrt.Class



type A_arbace_go_embed_sorted_children_fn__1220000054_A struct{ j2g_header uint64 }

var A_arbace_go_embed_sorted_children_fn__1220000054_A_fn_class *jrt.Class



type A_arbace_go_embed_space_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_embed_space_QMARK__A_fn_class *jrt.Class



type A_arbace_go_embed_unquote_go_A struct{ j2g_header uint64 }

var A_arbace_go_embed_unquote_go_A_fn_class *jrt.Class



type A_arbace_go_embed_valid_path_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_embed_valid_path_QMARK__A_fn_class *jrt.Class



type A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A struct{ j2g_header uint64 }

var A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A_fn_class *jrt.Class
