//line aot_arbace_go_embed.ae:1
package aot_arbace_go_embed

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_embed_eval1220000004_loading__1927001464__auto____1220000005_A_New() *A_arbace_go_embed_eval1220000004_loading__1927001464__auto____1220000005_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_eval1220000004_loading__1927001464__auto____1220000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_embed_eval1220000004_loading__1927001464__auto____1220000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_embed_eval1220000004_loading__1927001464__auto____1220000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_embed_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_embed_A_const_1); lang.IFn_Cast(A_arbace_go_embed_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_go_embed_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_embed_eval1220000008_fn__1220000009_A_New() *A_arbace_go_embed_eval1220000008_fn__1220000009_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_eval1220000008_fn__1220000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_embed_eval1220000008_fn__1220000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_embed_eval1220000008_fn__1220000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_embed_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_go_embed_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_go_embed_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_embed_A_const_7.GetRawRoot__O(), A_arbace_go_embed_A_const_8) }















func A_arbace_go_embed_space_QMARK__A_New() *A_arbace_go_embed_space_QMARK__A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_space_QMARK__A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_go_embed_space_QMARK__A) Ctor() {}
//line :17:1
func (t *A_arbace_go_embed_space_QMARK__A) Invoke_O_O__O(self, c__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Character_IsWhitespace_C__Z_NoInit(lang.RT_CharCast_O__C_NoInit(c__0))).Ref() }

func A_arbace_go_embed_unquote_go_A_New() *A_arbace_go_embed_unquote_go_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_unquote_go_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_go_embed_unquote_go_A) Ctor() {}
//line :19:1
func (t *A_arbace_go_embed_unquote_go_A) Invoke_O_O__O(self, q__0 any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var s__4 any; var root_19 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_21 lang.IFn



	if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = q__0; var arg_23 any = A_arbace_go_embed_A_const_10; var arg_24 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(q__0)))).Ref(); if linked_20 == nil { s__4 = ifn_21.Invoke_O_O_O__O(arg_22, arg_23, arg_24) } else { s__4 = linked_20.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_19, arg_22, arg_23, arg_24) }
//line :19:1
	var sb__5 any = jrt.StringBuilder_New(); var i__6 int64 = 0; L1: for {






		if lang.Numbers_Gte_J_J__Z_NoInit(i__6, int64(lang.RT_Count_O__I_NoInit(s__4))) {
			var root_25 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = sb__5; if linked_26 == nil { tmp1 = ifn_27.Invoke_O__O(arg_28) } else { tmp1 = linked_26.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_25, arg_28) } } else {
//line :26:1
				var c__7 uint16 = jrt.NN(jrt.String_Cast(s__4)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__6))


				if lang.Util_Equiv_C_C__Z_NoInit(c__7, jrt.NN(jrt.Character_Cast(A_arbace_go_embed_A_const_12)).CharValue__C()) { tmp1 = nil } else { var tmp2 any; var root_29 any = A_arbace_go_embed_A_const_13.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_31 lang.IFn

					if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = jrt.Character_ValueOf_C__Character_NoInit(c__7).Ref(); var arg_33 any = A_arbace_go_embed_A_const_14; if linked_30 == nil { tmp2 = ifn_31.Invoke_O_O__O(arg_32, arg_33) } else { tmp2 = linked_30.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_29, arg_32, arg_33) }
//line :29:1
					if jrt.J2g_Truth(tmp2) {

						jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_C__StringBuilder(c__7); i__6 = lang.Numbers_Inc_J__J_NoInit(i__6); continue L1 } else {
//line :29:1
							if A_arbace_go_embed_A_const_15 != nil { var e__8 uint16 = jrt.NN(jrt.String_Cast(s__4)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Inc_J__J_NoInit(i__6)))
								var G__1220000013__9_ uint16 = e__8



							L2: switch { default: switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref()) { case 34: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_12) {



								jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_C__StringBuilder(e__8); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
								break L2 }; case 39: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_16) {



									jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_C__StringBuilder(e__8); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
									break L2 }; case 92: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_14) {



										jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_C__StringBuilder(e__8); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
										break L2 }; case 97: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_17) {




											jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_C__StringBuilder(lang.RT_CharCast_J__C_NoInit(7)); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
											break L2 }; case 98: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_18) {





												jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_C__StringBuilder(lang.RT_CharCast_J__C_NoInit(8)); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
												break L2 }; case 102: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_19) {






													jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_C__StringBuilder(lang.RT_CharCast_J__C_NoInit(12)); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
													break L2 }; case 110: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_20) {
														jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_O__StringBuilder(A_arbace_go_embed_A_const_22); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
														break L2 }; case 114: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_21) {


															jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_O__StringBuilder(A_arbace_go_embed_A_const_24); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
															break L2 }; case 116: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_23) {

																jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_O__StringBuilder(A_arbace_go_embed_A_const_26); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
																break L2 }; case 117: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_25) {









																	var tmp3 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__5); var tmp4 any; var root_35 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = s__4; var arg_39 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__6, 2)).Ref(); var arg_40 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__6, 6)).Ref(); if linked_36 == nil { tmp4 = ifn_37.Invoke_O_O_O__O(arg_38, arg_39, arg_40) } else { tmp4 = linked_36.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_35, arg_38, arg_39, arg_40) }; jrt.NN(tmp3).Append_C__StringBuilder(lang.RT_CharCast_J__C_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp4), lang.RT_IntCast_J__I_NoInit(16)))); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 6); continue L1
//line :34:1
																	break L2 }; case 118: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_27) {







																		jrt.NN(jrt.StringBuilder_Cast(sb__5)).Append_C__StringBuilder(lang.RT_CharCast_J__C_NoInit(11)); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 2); continue L1
//line :34:1
																		break L2 }; case 120: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000013__9_).Ref(), A_arbace_go_embed_A_const_28) {








																			var tmp5 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__5); var tmp6 any; var root_41 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = s__4; var arg_45 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__6, 2)).Ref(); var arg_46 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__6, 4)).Ref(); if linked_42 == nil { tmp6 = ifn_43.Invoke_O_O_O__O(arg_44, arg_45, arg_46) } else { tmp6 = linked_42.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_41, arg_44, arg_45, arg_46) }; jrt.NN(tmp5).Append_C__StringBuilder(lang.RT_CharCast_J__C_NoInit(jrt.Long_ParseLong_String_I__J_NoInit(jrt.String_Cast(tmp6), lang.RT_IntCast_J__I_NoInit(16)))); i__6 = lang.Numbers_Add_J_J__J_NoInit(i__6, 4); continue L1
//line :34:1
																			break L2 }; default:}; tmp1 = nil} } else {
//line :29:1
																				tmp1 = nil } } } }
//line :19:1
		break L1 } }; return nil }(); if tmp7 != nil { if jrt.Exception_InstanceOf(tmp7) { var ___4 jrt.Exception_I = jrt.Exception_Cast(tmp7); _ = ___4; tmp1 = nil } else { panic(tmp7) } }; return tmp1 }




























func A_arbace_go_embed_parse_patterns_A_New() *A_arbace_go_embed_parse_patterns_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_parse_patterns_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_go_embed_parse_patterns_A) Ctor() {}
//line :48:1
func (t *A_arbace_go_embed_parse_patterns_A) Invoke_O_O__O(self, args__0 any) any { { var args__2 any; var root_47 any = A_arbace_go_embed_A_const_29.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_49 lang.IFn



	if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = args__0; if linked_48 == nil { args__2 = ifn_49.Invoke_O__O(arg_50) } else { args__2 = linked_48.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_47, arg_50) }
//line :48:1
	var acc__3 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




		if lang.Util_Equiv_O_O__Z_NoInit(Lit_37, args__2) { return lang.Tuple_Create_O_O__IPersistentVector(acc__3, nil) } else { var c__4 uint16 = jrt.NN(jrt.String_Cast(args__2)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)); var vec__1220000016__5 any
			var G__1220000019__5_ uint16 = c__4


		L2: switch { default: switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000019__5_).Ref()) { case 34: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000019__5_).Ref(), A_arbace_go_embed_A_const_12) { var end__6 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__53 any = A_arbace_go_embed_parse_patterns_fn__1220000020_A_New_O(args__2); var tmp2 *jrt.Class
			var fncls__52 /*line :57:1*/*jrt.Class = A_arbace_go_embed_parse_patterns_fn__1220000020_A_fn_class




			if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__53); A_arbace_go_embed_parse_patterns_fn__1220000020_A_fn_class = fncls__52d; tmp2 = fncls__52d } else { tmp2 = fncls__52 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__53, tmp2, nil); end__6 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()





			if lang.Util_Identical_O_O__Z_NoInit(end__6, nil) { vec__1220000016__5 = lang.Tuple_Create_O_O_O__IPersistentVector(nil, nil, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil), jrt.RefArrayOf(jrt.Object_class, nil, args__2)).Ref()) } else { var temp__1927000408__auto____7 any; var root_54 any = A_arbace_go_embed_A_const_30.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, A_arbace_go_embed_unquote_go_A_fn_class); var ifn_56 lang.IFn

				if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any; var root_58 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = args__2; var arg_62 any = A_arbace_go_embed_A_const_31; var arg_63 any; var na_64 any = end__6; if jrt.Long_InstanceOf(na_64) { var n0_65 int64 = jrt.NN(jrt.Long_Cast(na_64)).LongValue__J(); if n0_65 == 9223372036854775807 { arg_63 = lang.Numbers_Inc_O__Number_NoInit(na_64) } else { arg_63 = jrt.Long_ValueOf_J__Long_NoInit(n0_65 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_64) { var n0_65_2 float64 = jrt.NN(jrt.Double_Cast(na_64)).DoubleValue__D(); arg_63 = jrt.Double_ValueOf_D__Double_NoInit(n0_65_2 + 1.0).Ref() } else { arg_63 = lang.Numbers_Inc_O__Number_NoInit(na_64) } }; if linked_59 == nil { arg_57 = ifn_60.Invoke_O_O_O__O(arg_61, arg_62, arg_63) } else { arg_57 = linked_59.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_58, arg_61, arg_62, arg_63) }; if linked_55 == nil { temp__1927000408__auto____7 = ifn_56.Invoke_O__O(arg_57) } else { temp__1927000408__auto____7 = linked_55.(*A_arbace_go_embed_unquote_go_A).Invoke_O_O__O(root_54, arg_57) }; if jrt.J2g_Truth(temp__1927000408__auto____7) { var q__8 any = temp__1927000408__auto____7; var tmp3 any; var root_100 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_102 lang.IFn
					if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = args__2; var arg_104 any; var na_105 any = end__6; if jrt.Long_InstanceOf(na_105) { var n0_106 int64 = jrt.NN(jrt.Long_Cast(na_105)).LongValue__J(); if n0_106 == 9223372036854775807 { arg_104 = lang.Numbers_Inc_O__Number_NoInit(na_105) } else { arg_104 = jrt.Long_ValueOf_J__Long_NoInit(n0_106 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_105) { var n0_106_2 float64 = jrt.NN(jrt.Double_Cast(na_105)).DoubleValue__D(); arg_104 = jrt.Double_ValueOf_D__Double_NoInit(n0_106_2 + 1.0).Ref() } else { arg_104 = lang.Numbers_Inc_O__Number_NoInit(na_105) } }; if linked_101 == nil { tmp3 = ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { tmp3 = linked_101.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_100, arg_103, arg_104) }
//line :70:1
					vec__1220000016__5 = lang.Tuple_Create_O_O_O__IPersistentVector(q__8, tmp3, nil) } else { var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_51, nil); var tmp5 any; var root_107 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_109 lang.IFn

						if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = args__2; var arg_111 any = A_arbace_go_embed_A_const_31; var arg_112 any; var na_113 any = end__6; if jrt.Long_InstanceOf(na_113) { var n0_114 int64 = jrt.NN(jrt.Long_Cast(na_113)).LongValue__J(); if n0_114 == 9223372036854775807 { arg_112 = lang.Numbers_Inc_O__Number_NoInit(na_113) } else { arg_112 = jrt.Long_ValueOf_J__Long_NoInit(n0_114 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_113) { var n0_114_2 float64 = jrt.NN(jrt.Double_Cast(na_113)).DoubleValue__D(); arg_112 = jrt.Double_ValueOf_D__Double_NoInit(n0_114_2 + 1.0).Ref() } else { arg_112 = lang.Numbers_Inc_O__Number_NoInit(na_113) } }; if linked_108 == nil { tmp5 = ifn_109.Invoke_O_O_O__O(arg_110, arg_111, arg_112) } else { tmp5 = linked_108.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_107, arg_110, arg_111, arg_112) }
//line :70:1
						vec__1220000016__5 = lang.Tuple_Create_O_O_O__IPersistentVector(nil, nil, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref()) } }
//line :57:1
			break L2 }; case 96: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000019__5_).Ref(), A_arbace_go_embed_A_const_32) { var i__6 any; var root_66 any = A_arbace_go_embed_A_const_33.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_66, aot_arbace_string.A_arbace_string_index_of_A_fn_class); var ifn_68 lang.IFn
				if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = args__2; var arg_70 any = Lit_52; if linked_67 == nil { i__6 = ifn_68.Invoke_O_O_O__O(arg_69, arg_70, A_arbace_go_embed_A_const_10) } else { i__6 = linked_67.(*aot_arbace_string.A_arbace_string_index_of_A).InvokePrim_O_O_O_J__O(root_66, arg_69, arg_70, 1) }
				if lang.Util_Identical_O_O__Z_NoInit(i__6, nil) { vec__1220000016__5 = lang.Tuple_Create_O_O_O__IPersistentVector(nil, nil, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil), jrt.RefArrayOf(jrt.Object_class, nil, args__2)).Ref()) } else { var tmp6 any; var root_115 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_117 lang.IFn

					if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = args__2; var arg_119 any = A_arbace_go_embed_A_const_10; var arg_120 any = i__6; if linked_116 == nil { tmp6 = ifn_117.Invoke_O_O_O__O(arg_118, arg_119, arg_120) } else { tmp6 = linked_116.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_115, arg_118, arg_119, arg_120) }
//line :59:1
					var tmp7 any = tmp6; var tmp8 any; var root_121 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_123 lang.IFn

					if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = args__2; var arg_125 any; var na_126 any = i__6; if jrt.Long_InstanceOf(na_126) { var n0_127 int64 = jrt.NN(jrt.Long_Cast(na_126)).LongValue__J(); if n0_127 == 9223372036854775807 { arg_125 = lang.Numbers_Inc_O__Number_NoInit(na_126) } else { arg_125 = jrt.Long_ValueOf_J__Long_NoInit(n0_127 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_126) { var n0_127_2 float64 = jrt.NN(jrt.Double_Cast(na_126)).DoubleValue__D(); arg_125 = jrt.Double_ValueOf_D__Double_NoInit(n0_127_2 + 1.0).Ref() } else { arg_125 = lang.Numbers_Inc_O__Number_NoInit(na_126) } }; if linked_122 == nil { tmp8 = ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { tmp8 = linked_122.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_121, arg_124, arg_125) }
//line :59:1
					vec__1220000016__5 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp7, tmp8, nil) }
//line :57:1
				break L2 }; default:}; var i__6_2 any; var or__1927000174__auto____6 any; var root_72 any = A_arbace_go_embed_A_const_34.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_74 lang.IFn















			if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any; var fnbody__82 any = A_arbace_go_embed_parse_patterns_fn__1220000022_A_New_O(args__2); var tmp9 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_go_embed_parse_patterns_fn__1220000022_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, fnbody__82); A_arbace_go_embed_parse_patterns_fn__1220000022_A_fn_class = fncls__81d; tmp9 = fncls__81d } else { tmp9 = fncls__81 }; arg_75 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp9, nil); var arg_76 any; var root_83 any = A_arbace_go_embed_A_const_36.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(args__2)).Ref(); if linked_84 == nil { arg_76 = ifn_85.Invoke_O__O(arg_86) } else { arg_76 = linked_84.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_83, arg_86) }; if linked_73 == nil { or__1927000174__auto____6 = ifn_74.Invoke_O_O__O(arg_75, arg_76) } else { or__1927000174__auto____6 = linked_73.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_72, arg_75, arg_76) }; if jrt.J2g_Truth(or__1927000174__auto____6) { i__6_2 = or__1927000174__auto____6 } else { i__6_2 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(args__2)).Ref() }
//line :57:1
			var tmp10 any; var root_128 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_130 lang.IFn
















			if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = args__2; var arg_132 any = A_arbace_go_embed_A_const_31; var arg_133 any = i__6_2; if linked_129 == nil { tmp10 = ifn_130.Invoke_O_O_O__O(arg_131, arg_132, arg_133) } else { tmp10 = linked_129.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_128, arg_131, arg_132, arg_133) }
//line :57:1
			var tmp11 any = tmp10; var tmp12 any; var root_134 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_136 lang.IFn
















			if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = args__2; var arg_138 any = i__6_2; if linked_135 == nil { tmp12 = ifn_136.Invoke_O_O__O(arg_137, arg_138) } else { tmp12 = linked_135.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_134, arg_137, arg_138) }
//line :57:1
			vec__1220000016__5 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp11, tmp12, nil)}
//line :53:1
			var path__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000016__5, lang.RT_IntCast_J__I_NoInit(0), nil); var rest__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000016__5, lang.RT_IntCast_J__I_NoInit(1), nil); var err__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000016__5, lang.RT_IntCast_J__I_NoInit(2), nil)





















			if jrt.J2g_Truth(err__8) { return lang.Tuple_Create_O_O__IPersistentVector(nil, err__8) } else { var tmp13 any; var and__1927000168__auto____9 any; var root_87 any = A_arbace_go_embed_A_const_13.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_89 lang.IFn

				if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = Lit_37; var arg_91 any = rest__7; if linked_88 == nil { and__1927000168__auto____9 = ifn_89.Invoke_O_O__O(arg_90, arg_91) } else { and__1927000168__auto____9 = linked_88.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_87, arg_90, arg_91) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var root_92 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any; var root_96 any = A_arbace_go_embed_A_const_35.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, A_arbace_go_embed_space_QMARK__A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(jrt.String_Cast(rest__7)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0))).Ref(); if linked_97 == nil { arg_95 = ifn_98.Invoke_O__O(arg_99) } else { arg_95 = linked_97.(*A_arbace_go_embed_space_QMARK__A).Invoke_O_O__O(root_96, arg_99) }; if linked_93 == nil { tmp13 = ifn_94.Invoke_O__O(arg_95) } else { tmp13 = linked_93.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_92, arg_95) } } else { tmp13 = and__1927000168__auto____9 }
//line :75:1
				if jrt.J2g_Truth(tmp13) { return lang.Tuple_Create_O_O__IPersistentVector(nil, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil), jrt.RefArrayOf(jrt.Object_class, nil, rest__7)).Ref()) } else { if A_arbace_go_embed_A_const_15 != nil {



					var tmp14 any; var root_139 any = A_arbace_go_embed_A_const_29.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = rest__7; if linked_140 == nil { tmp14 = ifn_141.Invoke_O__O(arg_142) } else { tmp14 = linked_140.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_139, arg_142) }; var tmp15 any = tmp14; var tmp16 any; var root_143 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = acc__3; var arg_147 any = path__6; if linked_144 == nil { tmp16 = ifn_145.Invoke_O_O__O(arg_146, arg_147) } else { tmp16 = linked_144.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_143, arg_146, arg_147) }; args__2, acc__3 = tmp15, tmp16; continue L1 } else {
//line :75:1
						return nil } } } } } }; /*line :48:1*/panic("j2g: unreachable") }













func A_arbace_go_embed_parse_patterns_fn__1220000020_A_New_O(p0 any) *A_arbace_go_embed_parse_patterns_fn__1220000020_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_parse_patterns_fn__1220000020_A{}; t.Ctor_O(p0); return t }
//line :62:1
func (t *A_arbace_go_embed_parse_patterns_fn__1220000020_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :62:1
func (t *A_arbace_go_embed_parse_patterns_fn__1220000020_A) Invoke_O__O(self any) any { { var i__1 int64 = 1; L1: for {
											if lang.Numbers_Gte_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_args))) { return nil } else { var tmp1 *jrt.String = jrt.String_Cast(t.F_args); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_go_embed_A_const_14)).CharValue__C(), jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__1))) {

		i__1 = lang.Numbers_Add_J_J__J_NoInit(i__1, 2); continue L1 } else {
//line :63:1
			var tmp2 *jrt.String = jrt.String_Cast(t.F_args); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_go_embed_A_const_12)).CharValue__C(), jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__1))) { return jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref() } else { if A_arbace_go_embed_A_const_15 != nil {



				i__1 = lang.Numbers_Inc_J__J_NoInit(i__1); continue L1 } else {
//line :63:1
					return nil } } } } } }; /*line :62:1*/panic("j2g: unreachable") }










func A_arbace_go_embed_parse_patterns_fn__1220000022_A_New_O(p0 any) *A_arbace_go_embed_parse_patterns_fn__1220000022_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_parse_patterns_fn__1220000022_A{}; t.Ctor_O(p0); return t }
//line :73:1
func (t *A_arbace_go_embed_parse_patterns_fn__1220000022_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :73:1
func (t *A_arbace_go_embed_parse_patterns_fn__1220000022_A) Invoke_O_O__O(self, p1__1220000015_SHARP___1 any) any { var tmp1 any; var root_77 any = A_arbace_go_embed_A_const_35.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, A_arbace_go_embed_space_QMARK__A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var tmp2 *jrt.String = jrt.String_Cast(t.F_args); var arg_80 any = jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(p1__1220000015_SHARP___1))).Ref(); if linked_78 == nil { tmp1 = ifn_79.Invoke_O__O(arg_80) } else { tmp1 = linked_78.(*A_arbace_go_embed_space_QMARK__A).Invoke_O_O__O(root_77, arg_80) }; if jrt.J2g_Truth(tmp1) { return p1__1220000015_SHARP___1 } else { return nil } }







func A_arbace_go_embed_directive_patterns_A_New() *A_arbace_go_embed_directive_patterns_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_directive_patterns_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_go_embed_directive_patterns_A) Ctor() {}
//line :81:1
func (t *A_arbace_go_embed_directive_patterns_A) Invoke_O_O__O(self, v__0 any) any { var texts__2 any; var tmp1 any; var root_148 any = A_arbace_go_embed_A_const_38.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_150 lang.IFn; if



	linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = v__0; if linked_149 == nil { tmp1 = ifn_150.Invoke_O__O(arg_151) } else { tmp1 = linked_149.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_148, arg_151) }; if jrt.J2g_Truth(tmp1) { texts__2 = v__0 } else { texts__2 = lang.Tuple_Create_O__IPersistentVector(v__0) }; var root_152 any =
	A_arbace_go_embed_A_const_39.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any; var fnbody__184 any = A_arbace_go_embed_directive_patterns_fn__1220000026_A_New(); var tmp2 *jrt.Class; var fncls__183 *jrt.Class = A_arbace_go_embed_directive_patterns_fn__1220000026_A_fn_class; if fncls__183 == nil { var fncls__183d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, nil); A_arbace_go_embed_directive_patterns_fn__1220000026_A_fn_class = fncls__183d; tmp2 = fncls__183d } else { tmp2 = fncls__183 }; arg_155 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__184, tmp2, nil); var arg_156 any = lang.Tuple_Create_O_O__IPersistentVector(lang.PersistentVector_EMPTY.Ref(), nil); var arg_157 any = texts__2; if linked_153 == nil { return ifn_154.Invoke_O_O_O__O(arg_155, arg_156, arg_157) } else { return linked_153.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_152, arg_155, arg_156, arg_157) } }
//line :86:1
func A_arbace_go_embed_directive_patterns_fn__1220000026_A_New() *A_arbace_go_embed_directive_patterns_fn__1220000026_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_directive_patterns_fn__1220000026_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_go_embed_directive_patterns_fn__1220000026_A) Ctor() {}
//line :86:1
func (t *A_arbace_go_embed_directive_patterns_fn__1220000026_A) Invoke_O_O_O__O(self, p__1220000025__1, t__2 any) any { var vec__1220000027__3 any = p__1220000025__1; var acc__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000027__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000027__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__1220000030__6 any; var root_158 any = A_arbace_go_embed_A_const_40.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, A_arbace_go_embed_parse_patterns_A_fn_class); var ifn_160 lang.IFn; _ = ___5; if
															linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any; var root_162 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = t__2; if linked_163 == nil { arg_161 = ifn_164.Invoke_O__O(arg_165) } else { arg_161 = linked_163.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_162, arg_165) }; if linked_159 == nil { vec__1220000030__6 = ifn_160.Invoke_O__O(arg_161) } else { vec__1220000030__6 = linked_159.(*A_arbace_go_embed_parse_patterns_A).Invoke_O_O__O(root_158, arg_161) }; var ps__7 any = /*line :86:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1220000030__6, lang.RT_IntCast_J__I_NoInit(0), nil); var err__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000030__6, lang.RT_IntCast_J__I_NoInit(1), nil); if

	jrt.J2g_Truth(err__8) {
		var root_166 any = A_arbace_go_embed_A_const_41.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = lang.Tuple_Create_O_O__IPersistentVector(nil, err__8); if linked_167 == nil { return ifn_168.Invoke_O__O(arg_169) } else { return linked_167.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_166, arg_169) } } else {
//line :88:1
			var tmp1 any; var root_170 any = A_arbace_go_embed_A_const_42.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_172 lang.IFn

			if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = ps__7; if linked_171 == nil { tmp1 = ifn_172.Invoke_O__O(arg_173) } else { tmp1 = linked_171.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_170, arg_173) }
//line :88:1
			if jrt.J2g_Truth(tmp1) {

				var root_174 any = A_arbace_go_embed_A_const_41.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_reduced_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = A_arbace_go_embed_A_const_43; if linked_175 == nil { return ifn_176.Invoke_O__O(arg_177) } else { return linked_175.(*aot_arbace_core.A_arbace_core_reduced_A).Invoke_O_O__O(root_174, arg_177) } } else {
//line :88:1
					if A_arbace_go_embed_A_const_15 != nil { var tmp2 any; var root_178 any = A_arbace_go_embed_A_const_44.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_180 lang.IFn


						if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = acc__4; var arg_182 any = ps__7; if linked_179 == nil { tmp2 = ifn_180.Invoke_O_O__O(arg_181, arg_182) } else { tmp2 = linked_179.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_178, arg_181, arg_182) }
//line :88:1
						return lang.Tuple_Create_O_O__IPersistentVector(tmp2, nil) } else { return nil } } } }







func A_arbace_go_embed_glob_regex_A_New() *A_arbace_go_embed_glob_regex_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_regex_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_go_embed_glob_regex_A) Ctor() {}
//line :96:1
func (t *A_arbace_go_embed_glob_regex_A) Invoke_O_O__O(self, p__0 any) any { { var sb__2 any = jrt.StringBuilder_New(); var n__3 int32 = lang.RT_Count_O__I_NoInit(p__0); var i__4 any = lang.RT_Box_J__Number_NoInit(0); L1: for {





	var tmp1 bool; var na_185 any = i__4; var na_186 int64 = int64(n__3); if jrt.Long_InstanceOf(na_185) { var n0_187 int64 = jrt.NN(jrt.Long_Cast(na_185)).LongValue__J(); var n1_188 int64 = na_186; tmp1 = n0_187 >= n1_188 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_185, na_186) }; if tmp1 { var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var root_190 any = A_arbace_go_embed_A_const_45.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_re_pattern_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any; var root_194 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = sb__2; if linked_195 == nil { arg_193 = ifn_196.Invoke_O__O(arg_197) } else { arg_193 = linked_195.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_194, arg_197) }; if linked_191 == nil { tmp2 = ifn_192.Invoke_O__O(arg_193) } else { tmp2 = linked_191.(*aot_arbace_core.A_arbace_core_re_pattern_A).Invoke_O_O__O(root_190, arg_193) } }
//line :102:1
		return nil }(); if tmp3 != nil { if jrt.Exception_InstanceOf(tmp3) { var ___7 jrt.Exception_I = jrt.Exception_Cast(tmp3); _ = ___7; tmp2 = nil } else { panic(tmp3) } }; return tmp2 } else { var c__7 uint16 = jrt.NN(jrt.String_Cast(p__0)).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(i__4))
			var G__1220000040__8_ uint16 = c__7

			switch lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000040__8_).Ref()) { case 42: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000040__8_).Ref(), A_arbace_go_embed_A_const_46) {
				jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_42); var tmp4 jrt.Number_I; var na_284 any = i__4; if jrt.Long_InstanceOf(na_284) { var n0_285 int64 = jrt.NN(jrt.Long_Cast(na_284)).LongValue__J(); if n0_285 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_284) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_285 + 1)) } } else { if jrt.Double_InstanceOf(na_284) { var n0_285_2 float64 = jrt.NN(jrt.Double_Cast(na_284)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_285_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_284) } }; i__4 = tmp4; continue L1 }
//line :105:1
			case 63: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000040__8_).Ref(), A_arbace_go_embed_A_const_47) {

				jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_43); var tmp5 jrt.Number_I; var na_286 any = i__4; if jrt.Long_InstanceOf(na_286) { var n0_287 int64 = jrt.NN(jrt.Long_Cast(na_286)).LongValue__J(); if n0_287 == 9223372036854775807 { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_286) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_287 + 1)) } } else { if jrt.Double_InstanceOf(na_286) { var n0_287_2 float64 = jrt.NN(jrt.Double_Cast(na_286)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_287_2 + 1.0)) } else { tmp5 = lang.Numbers_Inc_O__Number_NoInit(na_286) } }; i__4 = tmp5; continue L1 }
//line :105:1
			case 91: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000040__8_).Ref(), A_arbace_go_embed_A_const_48) { var end__9 any; var tmp6 *lang.Compiler_AOTFn; var fnbody__232 any = A_arbace_go_embed_glob_regex_fn__1220000041_A_New_O_I_O(i__4, n__3, p__0); var tmp7 *jrt.Class
				var fncls__231 /*line :105:1*/*jrt.Class = A_arbace_go_embed_glob_regex_fn__1220000041_A_fn_class





				if fncls__231 == nil { var fncls__231d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, fnbody__232); A_arbace_go_embed_glob_regex_fn__1220000041_A_fn_class = fncls__231d; tmp7 = fncls__231d } else { tmp7 = fncls__231 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__232, tmp7, nil); end__9 = Up_Compiler_AOTFn_IFn(tmp6).Invoke__O()





				if lang.Util_Identical_O_O__Z_NoInit(end__9, nil) { return nil } else { var body__10 any; var root_233 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_235 lang.IFn

					if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = p__0; var arg_237 any; var na_239 any = i__4; if jrt.Long_InstanceOf(na_239) { var n0_240 int64 = jrt.NN(jrt.Long_Cast(na_239)).LongValue__J(); if n0_240 == 9223372036854775807 { arg_237 = lang.Numbers_Inc_O__Number_NoInit(na_239) } else { arg_237 = jrt.Long_ValueOf_J__Long_NoInit(n0_240 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_239) { var n0_240_2 float64 = jrt.NN(jrt.Double_Cast(na_239)).DoubleValue__D(); arg_237 = jrt.Double_ValueOf_D__Double_NoInit(n0_240_2 + 1.0).Ref() } else { arg_237 = lang.Numbers_Inc_O__Number_NoInit(na_239) } }; var arg_238 any = end__9; if linked_234 == nil { body__10 = ifn_235.Invoke_O_O_O__O(arg_236, arg_237, arg_238) } else { body__10 = linked_234.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_233, arg_236, arg_237, arg_238) }
//line :117:1
					var neg__11 any; var root_241 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_243 lang.IFn


					if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = body__10; var arg_245 any = Lit_45; if linked_242 == nil { neg__11 = ifn_243.Invoke_O_O__O(arg_244, arg_245) } else { neg__11 = linked_242.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_241, arg_244, arg_245) }
//line :117:1
					var body__12 any



					if jrt.J2g_Truth(neg__11) { var root_246 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = body__10; var arg_250 any = A_arbace_go_embed_A_const_10; if linked_247 == nil { body__12 = ifn_248.Invoke_O_O__O(arg_249, arg_250) } else { body__12 = linked_247.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_246, arg_249, arg_250) } } else { body__12 = body__10 }
//line :117:1
					var cls__13 any; var root_251 any = A_arbace_go_embed_A_const_52.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_253 lang.IFn




					if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any; var root_255 any = A_arbace_go_embed_A_const_53.GetRawRoot__O(); var linked_256 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_255, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_257 lang.IFn; if linked_256 == nil { ifn_257 = lang.IFn_Cast(root_255) } else { ifn_257 = nil }; var arg_258 any; var fnbody__270 any = A_arbace_go_embed_glob_regex_fn__1220000043_A_New(); var tmp8 *jrt.Class; var fncls__269 *jrt.Class = A_arbace_go_embed_glob_regex_fn__1220000043_A_fn_class; if fncls__269 == nil { var fncls__269d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, nil); A_arbace_go_embed_glob_regex_fn__1220000043_A_fn_class = fncls__269d; tmp8 = fncls__269d } else { tmp8 = fncls__269 }; arg_258 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__270, tmp8, nil); var arg_259 any; var root_271 any = A_arbace_go_embed_A_const_56.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_273 lang.IFn
					if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = body__12; var arg_275 any = Lit_47; var arg_276 any = Lit_37; if linked_272 == nil { arg_259 = ifn_273.Invoke_O_O_O__O(arg_274, arg_275, arg_276) } else { arg_259 = linked_272.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_271, arg_274, arg_275, arg_276) }
//line :122:1
					if linked_256 == nil { arg_254 = ifn_257.Invoke_O_O__O(arg_258, arg_259) } else { arg_254 = linked_256.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_255, arg_258, arg_259) }; if linked_252 == nil { cls__13 = ifn_253.Invoke_O__O(arg_254) } else { cls__13 = linked_252.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_251, arg_254)
					}
					var tmp9 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_48, nil, nil, nil, Lit_49); var tmp11 *jrt.String; if jrt.J2g_Truth(neg__11) { tmp11 = Lit_45 } else { tmp11 = nil }; var tmp12 any = tmp11.Ref(); var tmp13 *jrt.String; if jrt.J2g_Truth(neg__11) { tmp13 = Lit_26 } else { tmp13 = nil }; jrt.NN(tmp9).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, cls__13, tmp13.Ref(), nil)))
					var tmp14 jrt.Number_I; var na_288 any = end__9; if jrt.Long_InstanceOf(na_288) { var n0_289 int64 = jrt.NN(jrt.Long_Cast(na_288)).LongValue__J(); if n0_289 == 9223372036854775807 { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_288) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_289 + 1)) } } else { if jrt.Double_InstanceOf(na_288) { var n0_289_2 float64 = jrt.NN(jrt.Double_Cast(na_288)).DoubleValue__D(); tmp14 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_289_2 + 1.0)) } else { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_288) } }; i__4 = tmp14; continue L1 } }
//line :105:1
			case 92: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1220000040__8_).Ref(), A_arbace_go_embed_A_const_14) {


				var tmp15 bool; var na_277 any; var na_279 any = i__4; if jrt.Long_InstanceOf(na_279) { var n0_280 int64 = jrt.NN(jrt.Long_Cast(na_279)).LongValue__J(); if n0_280 == 9223372036854775807 { na_277 = lang.Numbers_Inc_O__Number_NoInit(na_279) } else { na_277 = jrt.Long_ValueOf_J__Long_NoInit(n0_280 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_279) { var n0_280_2 float64 = jrt.NN(jrt.Double_Cast(na_279)).DoubleValue__D(); na_277 = jrt.Double_ValueOf_D__Double_NoInit(n0_280_2 + 1.0).Ref() } else { na_277 = lang.Numbers_Inc_O__Number_NoInit(na_279) } }; var na_278 int64 = int64(n__3); if jrt.Long_InstanceOf(na_277) { var n0_281 int64 = jrt.NN(jrt.Long_Cast(na_277)).LongValue__J(); var n1_282 int64 = na_278; tmp15 = n0_281 < n1_282 } else { tmp15 = lang.Numbers_Lt_O_J__Z_NoInit(na_277, na_278) }; if tmp15 {
					var tmp16 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp17 any; var root_290 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any; var tmp18 *jrt.String = jrt.String_Cast(p__0); var tmp19 jrt.Number_I; var na_294 any = i__4; if jrt.Long_InstanceOf(na_294) { var n0_295 int64 = jrt.NN(jrt.Long_Cast(na_294)).LongValue__J(); if n0_295 == 9223372036854775807 { tmp19 = lang.Numbers_Inc_O__Number_NoInit(na_294) } else { tmp19 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_295 + 1)) } } else { if jrt.Double_InstanceOf(na_294) { var n0_295_2 float64 = jrt.NN(jrt.Double_Cast(na_294)).DoubleValue__D(); tmp19 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_295_2 + 1.0)) } else { tmp19 = lang.Numbers_Inc_O__Number_NoInit(na_294) } }; arg_293 = jrt.Character_ValueOf_C__Character_NoInit(jrt.NN(tmp18).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(tmp19))).Ref(); if linked_291 == nil { tmp17 = ifn_292.Invoke_O__O(arg_293) } else { tmp17 = linked_291.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_290, arg_293) }; jrt.NN(tmp16).Append_String__StringBuilder(jrt.Pattern_Quote_String__String_NoInit(jrt.String_Cast(tmp17))); var tmp20 jrt.Number_I; var na_296 any = i__4; var na_297 int64 = 2; if jrt.Long_InstanceOf(na_296) { var n0_298 int64 = jrt.NN(jrt.Long_Cast(na_296)).LongValue__J(); var n1_299 int64 = na_297; var nr_300 int64 = n0_298 + n1_299; if (n0_298^nr_300)&(n1_299^nr_300) >= 0 { tmp20 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_300)) } else { tmp20 = lang.Numbers_Add_O_J__Number_NoInit(na_296, na_297) } } else { tmp20 = lang.Numbers_Add_O_J__Number_NoInit(na_296, na_297) }; i__4 = tmp20; continue L1 } else {
//line :108:1
						return nil } }
//line :105:1
			default:
			}



















			var tmp21 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp22 any; var root_301 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = jrt.Character_ValueOf_C__Character_NoInit(c__7).Ref(); if linked_302 == nil { tmp22 = ifn_303.Invoke_O__O(arg_304) } else { tmp22 = linked_302.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_301, arg_304) }; jrt.NN(tmp21).Append_String__StringBuilder(jrt.Pattern_Quote_String__String_NoInit(jrt.String_Cast(tmp22))); var tmp23 jrt.Number_I; var na_305 any = i__4; if jrt.Long_InstanceOf(na_305) { var n0_306 int64 = jrt.NN(jrt.Long_Cast(na_305)).LongValue__J(); if n0_306 == 9223372036854775807 { tmp23 = lang.Numbers_Inc_O__Number_NoInit(na_305) } else { tmp23 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_306 + 1)) } } else { if jrt.Double_InstanceOf(na_305) { var n0_306_2 float64 = jrt.NN(jrt.Double_Cast(na_305)).DoubleValue__D(); tmp23 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_306_2 + 1.0)) } else { tmp23 = lang.Numbers_Inc_O__Number_NoInit(na_305) } }; i__4 = tmp23; continue L1 } } }; /*line :96:1*/panic("j2g: unreachable") }














func A_arbace_go_embed_glob_regex_fn__1220000041_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_embed_glob_regex_fn__1220000041_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_regex_fn__1220000041_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :111:1
func (t *A_arbace_go_embed_glob_regex_fn__1220000041_A) Ctor_O_I_O(c__i any, c__n int32, c__p any) { t.F_i = c__i; t.F_n = c__n; t.F_p = c__p }
//line :111:1
func (t *A_arbace_go_embed_glob_regex_fn__1220000041_A) Invoke_O__O(self any) any { { var j__1 any; var na_199 any = t.F_i; if jrt.Long_InstanceOf(na_199) { var n0_200 int64 = jrt.NN(jrt.Long_Cast(na_199)).LongValue__J(); if n0_200 == 9223372036854775807 { j__1 = lang.Numbers_Inc_O__Number_NoInit(na_199) } else { j__1 = jrt.Long_ValueOf_J__Long_NoInit(n0_200 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_199) { var n0_200_2 float64 = jrt.NN(jrt.Double_Cast(na_199)).DoubleValue__D(); j__1 = jrt.Double_ValueOf_D__Double_NoInit(n0_200_2 + 1.0).Ref() } else { j__1 = lang.Numbers_Inc_O__Number_NoInit(na_199) } }; L1: for {
											var tmp1 bool; var na_201 any = j__1; var na_202 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_201) { var n0_203 int64 = jrt.NN(jrt.Long_Cast(na_201)).LongValue__J(); var n1_204 int64 = na_202; tmp1 = n0_203 >= n1_204 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_201, na_202) }; if tmp1 { return nil } else { var tmp2 *jrt.String = jrt.String_Cast(t.F_p); if lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_go_embed_A_const_14)).CharValue__C(), jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1))) {
												var tmp3 jrt.Number_I; var na_224 any = j__1; var na_225 int64 = 2; if jrt.Long_InstanceOf(na_224) { var n0_226 int64 = jrt.NN(jrt.Long_Cast(na_224)).LongValue__J(); var n1_227 int64 = na_225; var nr_228 int64 = n0_226 + n1_227; if (n0_226^nr_228)&(n1_227^nr_228) >= 0 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_228)) } else { tmp3 = lang.Numbers_Add_O_J__Number_NoInit(na_224, na_225) } } else { tmp3 = lang.Numbers_Add_O_J__Number_NoInit(na_224, na_225) }; j__1 = tmp3; continue L1 } else {
//line :112:1
			var tmp4 any; var tmp5 *jrt.String = jrt.String_Cast(t.F_p); var and__1927000168__auto____2 bool = lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(jrt.Character_Cast(A_arbace_go_embed_A_const_49)).CharValue__C(), jrt.NN(tmp5).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(j__1)))

			if and__1927000168__auto____2 { var and__1927000168__auto____3 bool; var na_206 any = j__1; var na_207 any; var na_208 any = t.F_i; if jrt.Long_InstanceOf(na_208) { var n0_209 int64 = jrt.NN(jrt.Long_Cast(na_208)).LongValue__J(); if n0_209 == 9223372036854775807 { na_207 = lang.Numbers_Inc_O__Number_NoInit(na_208) } else { na_207 = jrt.Long_ValueOf_J__Long_NoInit(n0_209 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_208) { var n0_209_2 float64 = jrt.NN(jrt.Double_Cast(na_208)).DoubleValue__D(); na_207 = jrt.Double_ValueOf_D__Double_NoInit(n0_209_2 + 1.0).Ref() } else { na_207 = lang.Numbers_Inc_O__Number_NoInit(na_208) } }; var tmp6 bool; var tmp7 bool; tmp7 = jrt.Long_InstanceOf(na_206); if tmp7 { tmp7 = jrt.Long_InstanceOf(na_207) }; tmp6 = tmp7; if tmp6 { var n0_210 int64 = jrt.NN(jrt.Long_Cast(na_206)).LongValue__J(); var n1_211 int64 = jrt.NN(jrt.Long_Cast(na_207)).LongValue__J(); and__1927000168__auto____3 = n0_210 > n1_211 } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_206); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_207) }; tmp8 = tmp9; if tmp8 { var n0_210_2 float64 = jrt.NN(jrt.Double_Cast(na_206)).DoubleValue__D(); var n1_211_2 float64 = jrt.NN(jrt.Double_Cast(na_207)).DoubleValue__D(); and__1927000168__auto____3 = n1_211_2 < n0_210_2 } else { and__1927000168__auto____3 = lang.Numbers_Gt_O_O__Z_NoInit(na_206, na_207) } }; if and__1927000168__auto____3 {
				var root_213 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any; var and__1927000168__auto____4 bool; var tmp10 jrt.Number_I; var na_217 any = t.F_i; var na_218 int64 = 2; if jrt.Long_InstanceOf(na_217) { var n0_219 int64 = jrt.NN(jrt.Long_Cast(na_217)).LongValue__J(); var n1_220 int64 = na_218; var nr_221 int64 = n0_219 + n1_220; if (n0_219^nr_221)&(n1_220^nr_221) >= 0 { tmp10 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_221)) } else { tmp10 = lang.Numbers_Add_O_J__Number_NoInit(na_217, na_218) } } else { tmp10 = lang.Numbers_Add_O_J__Number_NoInit(na_217, na_218) }; and__1927000168__auto____4 = lang.Util_Equiv_O_O__Z_NoInit(j__1, tmp10); if and__1927000168__auto____4 { var tmp11 uint16 = jrt.NN(jrt.Character_Cast(A_arbace_go_embed_A_const_50)).CharValue__C(); var tmp12 *jrt.String = jrt.String_Cast(t.F_p); var tmp13 jrt.Number_I; var na_222 any = t.F_i; if jrt.Long_InstanceOf(na_222) { var n0_223 int64 = jrt.NN(jrt.Long_Cast(na_222)).LongValue__J(); if n0_223 == 9223372036854775807 { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_222) } else { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_223 + 1)) } } else { if jrt.Double_InstanceOf(na_222) { var n0_223_2 float64 = jrt.NN(jrt.Double_Cast(na_222)).DoubleValue__D(); tmp13 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_223_2 + 1.0)) } else { tmp13 = lang.Numbers_Inc_O__Number_NoInit(na_222) } }; arg_216 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_C_C__Z_NoInit(tmp11, jrt.NN(tmp12).CharAt_I__C(lang.RT_IntCast_O__I_NoInit(tmp13)))).Ref() } else { arg_216 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if linked_214 == nil { tmp4 = ifn_215.Invoke_O__O(arg_216) } else { tmp4 = linked_214.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_213, arg_216) } } else {
//line :114:1
					tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }
//line :112:1
			if jrt.J2g_Truth(tmp4) { return j__1 } else { if A_arbace_go_embed_A_const_15 != nil {



				var tmp14 jrt.Number_I; var na_229 any = j__1; if jrt.Long_InstanceOf(na_229) { var n0_230 int64 = jrt.NN(jrt.Long_Cast(na_229)).LongValue__J(); if n0_230 == 9223372036854775807 { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_229) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_230 + 1)) } } else { if jrt.Double_InstanceOf(na_229) { var n0_230_2 float64 = jrt.NN(jrt.Double_Cast(na_229)).DoubleValue__D(); tmp14 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_230_2 + 1.0)) } else { tmp14 = lang.Numbers_Inc_O__Number_NoInit(na_229) } }; j__1 = tmp14; continue L1 } else {
//line :112:1
					return nil } } } } } }; /*line :111:1*/panic("j2g: unreachable") }










func A_arbace_go_embed_glob_regex_fn__1220000043_A_New() *A_arbace_go_embed_glob_regex_fn__1220000043_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_regex_fn__1220000043_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_go_embed_glob_regex_fn__1220000043_A) Ctor() {}
//line :122:1
func (t *A_arbace_go_embed_glob_regex_fn__1220000043_A) Invoke_O_O__O(self, ch__1 any) any { var tmp1 any; var root_260 any = A_arbace_go_embed_A_const_54.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = A_arbace_go_embed_A_const_55; var arg_264 any = ch__1; if linked_261 == nil { tmp1 = ifn_262.Invoke_O_O__O(arg_263, arg_264) } else { tmp1 = linked_261.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_260, arg_263, arg_264) }; if jrt.J2g_Truth(tmp1) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, nil, ch__1)).Ref() } else { var root_265 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = ch__1; if linked_266 == nil { return ifn_267.Invoke_O__O(arg_268) } else { return linked_266.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_265, arg_268) } } }





func A_arbace_go_embed_valid_path_QMARK__A_New() *A_arbace_go_embed_valid_path_QMARK__A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_valid_path_QMARK__A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_go_embed_valid_path_QMARK__A) Ctor() {}
//line :128:1
func (t *A_arbace_go_embed_valid_path_QMARK__A) Invoke_O_O__O(self, p__0 any) any { var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(p__0, Lit_2); if or__1927000174__auto____2 {


	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else {
		var root_307 any = A_arbace_go_embed_A_const_57.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any; var fnbody__322 any = A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A_New(); var tmp1 *jrt.Class; var fncls__321 *jrt.Class = A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A_fn_class; if fncls__321 == nil { var fncls__321d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, nil); A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A_fn_class = fncls__321d; tmp1 = fncls__321d } else { tmp1 = fncls__321 }; arg_310 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__322, tmp1, nil); var arg_311 any; var root_323 any = A_arbace_go_embed_A_const_59.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = p__0; var arg_327 any = A_arbace_go_embed_A_const_60; var arg_328 any = A_arbace_go_embed_A_const_61; if linked_324 == nil { arg_311 = ifn_325.Invoke_O_O_O__O(arg_326, arg_327, arg_328) } else { arg_311 = linked_324.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_323, arg_326, arg_327, arg_328) }; if linked_308 == nil { return ifn_309.Invoke_O_O__O(arg_310, arg_311) } else { return linked_308.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_307, arg_310, arg_311) } } }
//line :132:1
func A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A_New() *A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A) Ctor() {}
//line :132:1
func (t *A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A) Invoke_O_O__O(self, p1__1220000046_SHARP___1 any) any { var root_312 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any; var root_316 any = A_arbace_go_embed_A_const_54.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = A_arbace_go_embed_A_const_58; var arg_320 any = p1__1220000046_SHARP___1; if linked_317 == nil { arg_315 = ifn_318.Invoke_O_O__O(arg_319, arg_320) } else { arg_315 = linked_317.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_316, arg_319, arg_320) }; if linked_313 == nil { return ifn_314.Invoke_O__O(arg_315) } else { return linked_313.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_312, arg_315) } }





func A_arbace_go_embed_bad_name_QMARK__A_New() *A_arbace_go_embed_bad_name_QMARK__A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_bad_name_QMARK__A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_go_embed_bad_name_QMARK__A) Ctor() {}
//line :138:1
func (t *A_arbace_go_embed_bad_name_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; var root_329 any = A_arbace_go_embed_A_const_54.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_331 lang.IFn; if



	linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = A_arbace_go_embed_A_const_62; var arg_333 any = n__0; if linked_330 == nil { or__1927000174__auto____2 = ifn_331.Invoke_O_O__O(arg_332, arg_333) } else { or__1927000174__auto____2 = linked_330.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_329, arg_332, arg_333) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_334 any = A_arbace_go_embed_A_const_34.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_336 lang.IFn
		if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any; var fnbody__353 any = A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A_New(); var tmp1 *jrt.Class; var fncls__352 *jrt.Class = A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A_fn_class; if fncls__352 == nil { var fncls__352d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, nil); A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A_fn_class = fncls__352d; tmp1 = fncls__352d } else { tmp1 = fncls__352 }; arg_337 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__353, tmp1, nil); var arg_338 any = n__0; if linked_335 == nil { or__1927000174__auto____3 = ifn_336.Invoke_O_O__O(arg_337, arg_338) } else { or__1927000174__auto____3 = linked_335.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_334, arg_337, arg_338) }
//line :142:1
		if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_354 any = A_arbace_go_embed_A_const_54.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_356 lang.IFn

			if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = A_arbace_go_embed_A_const_64.GetRawRoot__O(); var arg_358 any; var root_359 any = A_arbace_go_embed_A_const_65.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_string.A_arbace_string_upper_case_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any; var root_363 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any; var root_367 any = A_arbace_go_embed_A_const_59.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = n__0; var arg_371 any = A_arbace_go_embed_A_const_67; var arg_372 any = A_arbace_go_embed_A_const_68; if linked_368 == nil { arg_366 = ifn_369.Invoke_O_O_O__O(arg_370, arg_371, arg_372) } else { arg_366 = linked_368.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_367, arg_370, arg_371, arg_372) }; if linked_364 == nil { arg_362 = ifn_365.Invoke_O__O(arg_366) } else { arg_362 = linked_364.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_363, arg_366) }; if linked_360 == nil { arg_358 = ifn_361.Invoke_O__O(arg_362) } else { arg_358 = linked_360.(*aot_arbace_string.A_arbace_string_upper_case_A).Invoke_O_O__O(root_359, arg_362) }; if linked_355 == nil { or__1927000174__auto____4 = ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { or__1927000174__auto____4 = linked_355.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_354, arg_357, arg_358) }
//line :142:1
			if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {


				var root_373 any = A_arbace_go_embed_A_const_69.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_373, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_375 lang.IFn; if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any = n__0; var arg_377 any = Lit_2; if linked_374 == nil { return ifn_375.Invoke_O_O__O(arg_376, arg_377) } else { return linked_374.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_373, arg_376, arg_377) } } } } }
//line :143:1
func A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A_New() *A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A) Ctor() {}
//line :143:1
func (t *A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A) Invoke_O_O__O(self, c__1 any) any { var root_339 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any; var or__1927000174__auto____2 bool = jrt.Character_IsLetterOrDigit_C__Z_NoInit(lang.RT_CharCast_O__C_NoInit(c__1)); if or__1927000174__auto____2 { arg_342 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var root_343 any = A_arbace_go_embed_A_const_63.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = Lit_3; var arg_347 any; var root_348 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = c__1; if linked_349 == nil { arg_347 = ifn_350.Invoke_O__O(arg_351) } else { arg_347 = linked_349.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_348, arg_351) }; if linked_344 == nil { arg_342 = ifn_345.Invoke_O_O__O(arg_346, arg_347) } else { arg_342 = linked_344.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_343, arg_346, arg_347) } }; if linked_340 == nil { return ifn_341.Invoke_O__O(arg_342) } else { return linked_340.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_339, arg_342) } }



func A_arbace_go_embed_sorted_children_A_New() *A_arbace_go_embed_sorted_children_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_sorted_children_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_go_embed_sorted_children_A) Ctor() {}
//line :147:1
func (t *A_arbace_go_embed_sorted_children_A) Invoke_O_O__O(self, d__0 any) any {
	var root_378 any = A_arbace_go_embed_A_const_70.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any; var fnbody__384 any = A_arbace_go_embed_sorted_children_fn__1220000054_A_New(); var tmp1 *jrt.Class; var fncls__383 *jrt.Class = A_arbace_go_embed_sorted_children_fn__1220000054_A_fn_class; if fncls__383 == nil { var fncls__383d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, nil); A_arbace_go_embed_sorted_children_fn__1220000054_A_fn_class = fncls__383d; tmp1 = fncls__383d } else { tmp1 = fncls__383 }; arg_381 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__384, tmp1, nil); var arg_382 any; var root_385 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = jrt.File_Cast(d__0).ListFiles__File1().Ref(); if linked_386 == nil { arg_382 = ifn_387.Invoke_O__O(arg_388) } else { arg_382 = linked_386.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_385, arg_388) }; if linked_379 == nil { return ifn_380.Invoke_O_O__O(arg_381, arg_382) } else { return linked_379.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_378, arg_381, arg_382) } }
//line :148:1
func A_arbace_go_embed_sorted_children_fn__1220000054_A_New() *A_arbace_go_embed_sorted_children_fn__1220000054_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_sorted_children_fn__1220000054_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_go_embed_sorted_children_fn__1220000054_A) Ctor() {}
//line :148:1
func (t *A_arbace_go_embed_sorted_children_fn__1220000054_A) Invoke_O_O__O(self, p1__1220000053_SHARP___1 any) any { return jrt.File_Cast(p1__1220000053_SHARP___1).GetName__String().Ref() }

func A_arbace_go_embed_glob_A_New() *A_arbace_go_embed_glob_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_go_embed_glob_A) Ctor() {}
//line :150:1
func (t *A_arbace_go_embed_glob_A) Invoke_O_O_O__O(self, dir__0, glob__1 any) any { var segs__3 any; var root_389 any = A_arbace_go_embed_A_const_59.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_391 lang.IFn; if



	linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = glob__1; var arg_393 any = A_arbace_go_embed_A_const_72; if linked_390 == nil { segs__3 = ifn_391.Invoke_O_O__O(arg_392, arg_393) } else { segs__3 = linked_390.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_389, arg_392, arg_393) }; var rxs__4 any; var root_394 any = /*line :150:1*/A_arbace_go_embed_A_const_53.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_396 lang.IFn; if




	linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any; var fnbody__409 any = A_arbace_go_embed_glob_fn__1220000059_A_New(); var tmp1 *jrt.Class; var fncls__408 *jrt.Class = A_arbace_go_embed_glob_fn__1220000059_A_fn_class; if fncls__408 == nil { var fncls__408d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); A_arbace_go_embed_glob_fn__1220000059_A_fn_class = fncls__408d; tmp1 = fncls__408d } else { tmp1 = fncls__408 }; arg_397 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__409, tmp1, nil); var arg_398 any = segs__3; if linked_395 == nil { rxs__4 = ifn_396.Invoke_O_O__O(arg_397, arg_398) } else { rxs__4 = linked_395.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_394, arg_397, arg_398) }; var tmp2 any; var root_410 any =
	A_arbace_go_embed_A_const_34.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any; var fnbody__421 any = A_arbace_go_embed_glob_fn__1220000062_A_New(); var tmp3 *jrt.Class; var fncls__420 *jrt.Class = A_arbace_go_embed_glob_fn__1220000062_A_fn_class; if fncls__420 == nil { var fncls__420d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_go_embed_glob_fn__1220000062_A_fn_class = fncls__420d; tmp3 = fncls__420d } else { tmp3 = fncls__420 }; arg_413 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__421, tmp3, nil); var arg_414 any; var root_422 any = A_arbace_go_embed_A_const_53.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = A_arbace_go_embed_A_const_77.GetRawRoot__O(); var arg_426 any = segs__3; var arg_427 any = rxs__4; if linked_423 == nil { arg_414 = ifn_424.Invoke_O_O_O__O(arg_425, arg_426, arg_427) } else { arg_414 = linked_423.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_422, arg_425, arg_426, arg_427) }; if linked_411 == nil { tmp2 = ifn_412.Invoke_O_O__O(arg_413, arg_414) } else { tmp2 = linked_411.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_410, arg_413, arg_414) }; if jrt.J2g_Truth(tmp2) { return nil } else {
		var root_428 any = A_arbace_go_embed_A_const_39.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any; var fnbody__550 any = A_arbace_go_embed_glob_fn__1220000068_A_New_O(dir__0); var tmp4 *jrt.Class; var fncls__549 *jrt.Class = A_arbace_go_embed_glob_fn__1220000068_A_fn_class; if fncls__549 == nil { var fncls__549d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__550); A_arbace_go_embed_glob_fn__1220000068_A_fn_class = fncls__549d; tmp4 = fncls__549d } else { tmp4 = fncls__549 }; arg_431 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__550, tmp4, nil); var arg_432 any = A_arbace_go_embed_A_const_92; var arg_433 any; var root_551 any = A_arbace_go_embed_A_const_53.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_553 lang.IFn







		if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = A_arbace_go_embed_A_const_77.GetRawRoot__O(); var arg_555 any = segs__3; var arg_556 any = rxs__4; if linked_552 == nil { arg_433 = ifn_553.Invoke_O_O_O__O(arg_554, arg_555, arg_556) } else { arg_433 = linked_552.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_551, arg_554, arg_555, arg_556) }
//line :157:1
		if linked_429 == nil { return ifn_430.Invoke_O_O_O__O(arg_431, arg_432, arg_433) } else { return linked_429.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_428, arg_431, arg_432, arg_433) } } }
//line :155:1
func A_arbace_go_embed_glob_fn__1220000059_A_New() *A_arbace_go_embed_glob_fn__1220000059_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000059_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_go_embed_glob_fn__1220000059_A) Ctor() {}
//line :155:1
func (t *A_arbace_go_embed_glob_fn__1220000059_A) Invoke_O_O__O(self, p1__1220000057_SHARP___1 any) any { var tmp1 any; var root_399 any = A_arbace_go_embed_A_const_73.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = A_arbace_go_embed_A_const_74; var arg_403 any = p1__1220000057_SHARP___1; if linked_400 == nil { tmp1 = ifn_401.Invoke_O_O__O(arg_402, arg_403) } else { tmp1 = linked_400.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_399, arg_402, arg_403) }; if jrt.J2g_Truth(tmp1) { var root_404 any = A_arbace_go_embed_A_const_75.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, A_arbace_go_embed_glob_regex_A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = p1__1220000057_SHARP___1; if linked_405 == nil { return ifn_406.Invoke_O__O(arg_407) } else { return linked_405.(*A_arbace_go_embed_glob_regex_A).Invoke_O_O__O(root_404, arg_407) } } else { return nil } }
func A_arbace_go_embed_glob_fn__1220000062_A_New() *A_arbace_go_embed_glob_fn__1220000062_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000062_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_go_embed_glob_fn__1220000062_A) Ctor() {}
//line :156:1
func (t *A_arbace_go_embed_glob_fn__1220000062_A) Invoke_O_O__O(self, p__1220000061__1 any) any { var vec__1220000063__2 any = p__1220000061__1; var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000063__2, lang.RT_IntCast_J__I_NoInit(0), nil); var rx__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000063__2, lang.RT_IntCast_J__I_NoInit(1), nil); var and__1927000168__auto____5 any; var root_415 any = A_arbace_go_embed_A_const_73.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = A_arbace_go_embed_A_const_76; var arg_419 any = s__3; if linked_416 == nil { and__1927000168__auto____5 = ifn_417.Invoke_O_O__O(arg_418, arg_419) } else { and__1927000168__auto____5 = linked_416.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_415, arg_418, arg_419) }; if jrt.J2g_Truth(and__1927000168__auto____5) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(rx__4, nil)).Ref() } else { return and__1927000168__auto____5 } }
func A_arbace_go_embed_glob_fn__1220000068_A_New_O(p0 any) *A_arbace_go_embed_glob_fn__1220000068_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000068_A{}; t.Ctor_O(p0); return t }
//line :157:1
func (t *A_arbace_go_embed_glob_fn__1220000068_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :157:1
func (t *A_arbace_go_embed_glob_fn__1220000068_A) Invoke_O_O_O__O(self, paths__1, p__1220000067__2 any) any { var vec__1220000069__3 any = p__1220000067__2; var s__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000069__3, lang.RT_IntCast_J__I_NoInit(0), nil); var rx__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000069__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_434 any = A_arbace_go_embed_A_const_78.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_436 lang.IFn; if
														linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any; var iter__1927001039__auto____6 any; var fnbody__548 any = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A_New_O_O_O(rx__5, t.F_dir, s__4); var tmp1 *jrt.Class; var fncls__547 *jrt.Class = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A_fn_class; if fncls__547 == nil { var fncls__547d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__548); A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A_fn_class = fncls__547d; tmp1 = fncls__547d } else { tmp1 = fncls__547 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__548, tmp1, nil); arg_437 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(paths__1); if linked_435 == nil { return ifn_436.Invoke_O__O(arg_437) } else { return linked_435.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_434, arg_437) } }
//line :158:1
func A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A) Ctor_O_O_O(c__rx, c__dir, c__s any) { t.F_rx = c__rx; t.F_dir = c__dir; t.F_s = c__s }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A) Invoke_O_O__O(self, s__1220000073__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__546 any = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A_New_O_O_O_O_O(t.F_rx, t.F_dir, s__1220000073__1, t.F_s, self); var tmp2 *jrt.Class; var fncls__545 *jrt.Class = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A_fn_class; if fncls__545 == nil { var fncls__545d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__546); A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A_fn_class = fncls__545d; tmp2 = fncls__545d } else { tmp2 = fncls__545 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__546, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :158:1
func A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A) Ctor_O_O_O_O_O(c__rx, c__dir, c__s__1220000073, c__s, c__iter__1220000072 any) { t.F_rx = c__rx; t.F_dir = c__dir; t.F_s__1220000073 = c__s__1220000073; t.F_s = c__s; t.F_iter__1220000072 = c__iter__1220000072 }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A) Invoke_O__O(self any) any { { var s__1220000073__1 any; var t_ any = t.F_s__1220000073; t.F_s__1220000073 = nil; s__1220000073__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_438 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = s__1220000073__1; if linked_439 == nil { temp__1927000414__auto____2 = ifn_440.Invoke_O__O(arg_441) } else { temp__1927000414__auto____2 = linked_439.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_438, arg_441) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var p__4 any; var root_442 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = xs__1927001018__auto____3; if linked_443 == nil { p__4 = ifn_444.Invoke_O__O(arg_445) } else { p__4 = linked_443.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_442, arg_445) }; var f__5 any
															if lang.Util_Equiv_O_O__Z_NoInit(p__4, Lit_37) { f__5 = t.F_dir } else { var tmp1 jrt.File_I = jrt.File_Cast(t.F_dir); f__5 = jrt.File_New_File_String(tmp1, jrt.String_Cast(p__4)) }
//line :158:1
	if jrt.File_Cast(f__5).IsDirectory__Z() { var iterys__1927001035__auto____6 any; var fnbody__507 any = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A_New_O(p__4); var tmp2 *jrt.Class; var fncls__506 *jrt.Class = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A_fn_class; if fncls__506 == nil { var fncls__506d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, fnbody__507); A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A_fn_class = fncls__506d; tmp2 = fncls__506d } else { tmp2 = fncls__506 }; iterys__1927001035__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__507, tmp2, nil); var fs__1927001036__auto____7 any; var root_508 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____6); var tmp4 any


		if jrt.J2g_Truth(t.F_rx) {
			var root_512 any = A_arbace_go_embed_A_const_88.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any; var fnbody__523 any = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A_New_O(t.F_rx); var tmp5 *jrt.Class; var fncls__522 *jrt.Class = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A_fn_class; if fncls__522 == nil { var fncls__522d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, fnbody__523); A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A_fn_class = fncls__522d; tmp5 = fncls__522d } else { tmp5 = fncls__522 }; arg_515 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__523, tmp5, nil); var arg_516 any; var root_524 any = A_arbace_go_embed_A_const_90.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, A_arbace_go_embed_sorted_children_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = f__5; if linked_525 == nil { arg_516 = ifn_526.Invoke_O__O(arg_527) } else { arg_516 = linked_525.(*A_arbace_go_embed_sorted_children_A).Invoke_O_O__O(root_524, arg_527) }; if linked_513 == nil { tmp4 = ifn_514.Invoke_O_O__O(arg_515, arg_516) } else { tmp4 = linked_513.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_512, arg_515, arg_516) } } else {
//line :161:1
				var c__7 any = jrt.File_New_File_String(jrt.File_Cast(f__5), jrt.String_Cast(t.F_s))

				if jrt.File_Cast(c__7).Exists__Z() { tmp4 = lang.Tuple_Create_O__IPersistentVector(c__7) } else { tmp4 = nil } }
//line :158:1
		arg_511 = tmp3.Invoke_O__O(tmp4); if linked_509 == nil { fs__1927001036__auto____7 = ifn_510.Invoke_O__O(arg_511) } else { fs__1927001036__auto____7 = linked_509.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_508, arg_511) }; if jrt.J2g_Truth(fs__1927001036__auto____7) { var root_528 any = A_arbace_go_embed_A_const_91.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = fs__1927001036__auto____7; var arg_532 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1220000072); var tmp7 any; var root_533 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = s__1220000073__1; if linked_534 == nil { tmp7 = ifn_535.Invoke_O__O(arg_536) } else { tmp7 = linked_534.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_533, arg_536) }; arg_532 = tmp6.Invoke_O__O(tmp7); if linked_529 == nil { return ifn_530.Invoke_O_O__O(arg_531, arg_532) } else { return linked_529.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_528, arg_531, arg_532) } } else { var tmp8 any; var root_537 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = s__1220000073__1; if linked_538 == nil { tmp8 = ifn_539.Invoke_O__O(arg_540) } else { tmp8 = linked_538.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_537, arg_540) }; s__1220000073__1 = tmp8; continue L1 } } else { var tmp9 any; var root_541 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = s__1220000073__1; if linked_542 == nil { tmp9 = ifn_543.Invoke_O__O(arg_544) } else { tmp9 = linked_542.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_541, arg_544) }; s__1220000073__1 = tmp9; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :158:1
func A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A_New_O(p0 any) *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A{}; t.Ctor_O(p0); return t }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A) Ctor_O(c__p any) { t.F_p = c__p }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A) Invoke_O_O__O(self, s__1220000075__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__505 any = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A_New_O_O_O(t.F_p, s__1220000075__1, self); var tmp2 *jrt.Class; var fncls__504 *jrt.Class = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A_fn_class; if fncls__504 == nil { var fncls__504d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__505); A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A_fn_class = fncls__504d; tmp2 = fncls__504d } else { tmp2 = fncls__504 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__505, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :158:1
func A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A) Ctor_O_O_O(c__p, c__s__1220000075, c__iter__1220000074 any) { t.F_p = c__p; t.F_s__1220000075 = c__s__1220000075; t.F_iter__1220000074 = c__iter__1220000074 }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A) Invoke_O__O(self any) any { { var s__1220000075__1 any; var t_ any = t.F_s__1220000075; t.F_s__1220000075 = nil; s__1220000075__1 = t_; for { var temp__1927000414__auto____2 any; var root_446 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = s__1220000075__1; if linked_447 == nil { temp__1927000414__auto____2 = ifn_448.Invoke_O__O(arg_449) } else { temp__1927000414__auto____2 = linked_447.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_446, arg_449) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1220000075__3 any = temp__1927000414__auto____2; var tmp1 any; var root_450 any = A_arbace_go_embed_A_const_79.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = s__1220000075__3; if linked_451 == nil { tmp1 = ifn_452.Invoke_O__O(arg_453) } else { tmp1 = linked_451.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_450, arg_453) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_454 any = A_arbace_go_embed_A_const_80.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = s__1220000075__3; if linked_455 == nil { c__1927001037__auto____4 = ifn_456.Invoke_O__O(arg_457) } else { c__1927001037__auto____4 = linked_455.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_454, arg_457) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1220000077__6 any; var root_458 any = A_arbace_go_embed_A_const_81.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_459 == nil { b__1220000077__6 = ifn_460.Invoke_O__O(arg_461) } else { b__1220000077__6 = linked_459.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_458, arg_461) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__468 any = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A_New_O_O_I_O(t.F_p, b__1220000077__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__467 *jrt.Class = A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A_fn_class; if fncls__467 == nil { var fncls__467d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__468); A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A_fn_class = fncls__467d; tmp3 = fncls__467d } else { tmp3 = fncls__467 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__468, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_469 any = A_arbace_go_embed_A_const_83.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any; var root_474 any = A_arbace_go_embed_A_const_84.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = b__1220000077__6; if linked_475 == nil { arg_472 = ifn_476.Invoke_O__O(arg_477) } else { arg_472 = linked_475.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_474, arg_477) }; var arg_473 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1220000074); var tmp5 any; var root_478 any = A_arbace_go_embed_A_const_85.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = s__1220000075__3; if linked_479 == nil { tmp5 = ifn_480.Invoke_O__O(arg_481) } else { tmp5 = linked_479.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_478, arg_481) }; arg_473 = tmp4.Invoke_O__O(tmp5); if linked_470 == nil { return ifn_471.Invoke_O_O__O(arg_472, arg_473) } else { return linked_470.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_469, arg_472, arg_473) } } else { var root_482 any = A_arbace_go_embed_A_const_83.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any; var root_487 any = A_arbace_go_embed_A_const_84.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = b__1220000077__6; if linked_488 == nil { arg_485 = ifn_489.Invoke_O__O(arg_490) } else { arg_485 = linked_488.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_487, arg_490) }; var arg_486 any; if linked_483 == nil { return ifn_484.Invoke_O_O__O(arg_485, arg_486) } else { return linked_483.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_482, arg_485, arg_486) } } } else { var c__4 any; var root_491 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = s__1220000075__3; if linked_492 == nil { c__4 = ifn_493.Invoke_O__O(arg_494) } else { c__4 = linked_492.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_491, arg_494) }; var root_495 any = A_arbace_go_embed_A_const_86.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any





	if lang.Util_Equiv_O_O__Z_NoInit(t.F_p, Lit_37) { arg_498 = jrt.File_Cast(c__4).GetName__String().Ref() } else { var tmp6 any = t.F_p; arg_498 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, tmp6, nil, jrt.File_Cast(c__4).GetName__String().Ref())).Ref() }
//line :158:1
	var arg_499 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1220000074); var tmp8 any; var root_500 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = s__1220000075__3; if linked_501 == nil { tmp8 = ifn_502.Invoke_O__O(arg_503) } else { tmp8 = linked_501.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_500, arg_503) }; arg_499 = tmp7.Invoke_O__O(tmp8); if linked_496 == nil { return ifn_497.Invoke_O_O__O(arg_498, arg_499) } else { return linked_496.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_495, arg_498, arg_499) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :158:1
func A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A) Ctor_O_O_I_O(c__p, c__b__1220000077 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_p = c__p; t.F_b__1220000077 = c__b__1220000077; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :158:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A) Invoke_O__O(self any) any { { var i__1220000076__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1220000076__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1220000076__1)); var root_462 any = A_arbace_go_embed_A_const_82.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = t.F_b__1220000077; var arg_466 any





	if lang.Util_Equiv_O_O__Z_NoInit(t.F_p, Lit_37) { arg_466 = jrt.File_Cast(c__2).GetName__String().Ref() } else { var tmp2 any = t.F_p; arg_466 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, tmp2, nil, jrt.File_Cast(c__2).GetName__String().Ref())).Ref() }
//line :158:1
	if linked_463 == nil { ifn_464.Invoke_O_O__O(arg_465, arg_466) } else { linked_463.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_462, arg_465, arg_466) }; i__1220000076__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1220000076__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A_New_O(p0 any) *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A{}; t.Ctor_O(p0); return t }
//line :162:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A) Ctor_O(c__rx any) { t.F_rx = c__rx }
//line :162:1
func (t *A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A) Invoke_O_O__O(self, p1__1220000058_SHARP___1 any) any { var root_517 any = A_arbace_go_embed_A_const_89.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = t.F_rx; var arg_521 any = jrt.File_Cast(p1__1220000058_SHARP___1).GetName__String().Ref(); if linked_518 == nil { return ifn_519.Invoke_O_O__O(arg_520, arg_521) } else { return linked_518.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_517, arg_520, arg_521) } }




func A_arbace_go_embed_embed_error_A_New() *A_arbace_go_embed_embed_error_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_embed_error_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_go_embed_embed_error_A) Ctor() {}
//line :167:1
func (t *A_arbace_go_embed_embed_error_A) Invoke_O_O_O__O(self, pattern__0, msg__1 any) any { var tmp1 any; var root_557 any = A_arbace_go_embed_A_const_93.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, pattern__0, nil, msg__1)).Ref(); var arg_561 any = A_arbace_go_embed_A_const_94; if linked_558 == nil { tmp1 = ifn_559.Invoke_O_O__O(arg_560, arg_561) } else { tmp1 = linked_558.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_557, arg_560, arg_561) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }

func A_arbace_go_embed_resolve_pattern_A_New() *A_arbace_go_embed_resolve_pattern_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_resolve_pattern_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_go_embed_resolve_pattern_A) Ctor() {}
//line :169:1
func (t *A_arbace_go_embed_resolve_pattern_A) Invoke_O_O_O__O(self, dir__0, pattern__1 any) any { var vec__1220000093__3 any; var tmp1 any; var root_562 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_564 lang.IFn; if



	linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = pattern__1; var arg_566 any = Lit_54; if linked_563 == nil { tmp1 = ifn_564.Invoke_O_O__O(arg_565, arg_566) } else { tmp1 = linked_563.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_562, arg_565, arg_566) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = jrt.Boolean_TRUE.Ref(); var tmp3 any; var root_620 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any = pattern__1; var arg_624 any = A_arbace_go_embed_A_const_101; if linked_621 == nil { tmp3 = ifn_622.Invoke_O_O__O(arg_623, arg_624) } else { tmp3 = linked_621.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_620, arg_623, arg_624) }; vec__1220000093__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) } else { vec__1220000093__3 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Boolean_FALSE.Ref(), pattern__1) }; var all__4 any = /*line :169:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1220000093__3, lang.RT_IntCast_J__I_NoInit(0), nil); var glob_p__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000093__3, lang.RT_IntCast_J__I_NoInit(1), nil); var ___6 any; var tmp4 any; var or__1927000174__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(glob_p__5, Lit_2); _ = ___6; if or__1927000174__auto____6 {




		tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 any; var root_567 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any; var root_571 any = A_arbace_go_embed_A_const_95.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, A_arbace_go_embed_valid_path_QMARK__A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = glob_p__5; if linked_572 == nil { arg_570 = ifn_573.Invoke_O__O(arg_574) } else { arg_570 = linked_572.(*A_arbace_go_embed_valid_path_QMARK__A).Invoke_O_O__O(root_571, arg_574) }; if linked_568 == nil { or__1927000174__auto____7 = ifn_569.Invoke_O__O(arg_570) } else { or__1927000174__auto____7 = linked_568.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_567, arg_570) }; if jrt.J2g_Truth(or__1927000174__auto____7) { tmp4 = or__1927000174__auto____7 } else { var or__1927000174__auto____8 any; var root_575 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = glob_p__5; var arg_579 any = Lit_26; if linked_576 == nil { or__1927000174__auto____8 = ifn_577.Invoke_O_O__O(arg_578, arg_579) } else { or__1927000174__auto____8 = linked_576.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_575, arg_578, arg_579) }; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp4 = or__1927000174__auto____8 } else { var or__1927000174__auto____9 any; var root_580 any = A_arbace_go_embed_A_const_69.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = glob_p__5; var arg_584 any = Lit_26; if linked_581 == nil { or__1927000174__auto____9 = ifn_582.Invoke_O_O__O(arg_583, arg_584) } else { or__1927000174__auto____9 = linked_581.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_580, arg_583, arg_584) }; if jrt.J2g_Truth(or__1927000174__auto____9) { tmp4 = or__1927000174__auto____9 } else {
			tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_37, glob_p__5)).Ref() } } } }; if /*line :174:1*/ jrt.J2g_Truth(tmp4) {

				var root_585 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, A_arbace_go_embed_embed_error_A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = pattern__1; var arg_589 any = Lit_55; if linked_586 == nil { ___6 = ifn_587.Invoke_O_O__O(arg_588, arg_589) } else { ___6 = linked_586.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_585, arg_588, arg_589) } } else {
//line :174:1
					___6 = nil }; var matches__7 any; var root_590 any = /*line :169:1*/A_arbace_go_embed_A_const_97.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, A_arbace_go_embed_glob_A_fn_class); var ifn_592 lang.IFn; if







	linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = dir__0; var arg_594 any = glob_p__5; if linked_591 == nil { matches__7 = ifn_592.Invoke_O_O__O(arg_593, arg_594) } else { matches__7 = linked_591.(*A_arbace_go_embed_glob_A).Invoke_O_O_O__O(root_590, arg_593, arg_594) }; var ___8 any; _ = ___8; if
	lang.Util_Identical_O_O__Z_NoInit(matches__7, nil) { var root_595 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, A_arbace_go_embed_embed_error_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = pattern__1; var arg_599 any = Lit_55; if linked_596 == nil { ___8 = ifn_597.Invoke_O_O__O(arg_598, arg_599) } else { ___8 = linked_596.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_595, arg_598, arg_599) } } else { ___8 = nil }; var list__9 any; var root_600 any = /*line :169:1*/A_arbace_go_embed_A_const_98.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_602 lang.IFn; if









	linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = lang.PersistentVector_EMPTY.Ref(); if linked_601 == nil { list__9 = ifn_602.Invoke_O__O(arg_603) } else { list__9 = linked_601.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_600, arg_603) }; var seq_1220000096__10 any; var root_625 any = /*line :169:1*/A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_627 lang.IFn; if










	linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = matches__7; if linked_626 == nil { seq_1220000096__10 = ifn_627.Invoke_O__O(arg_628) } else { seq_1220000096__10 = linked_626.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_625, arg_628) }; var chunk_1220000097__11 any; var count_1220000098__12 int64 = 0; var i_1220000099__13 int64 = 0; L1:
//line :169:1
	for {










		if lang.Numbers_Lt_J_J__Z_NoInit(i_1220000099__13, count_1220000098__12) { var rel__14 any = lang.Indexed_Cast(chunk_1220000097__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1220000099__13)); var f__15 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), jrt.String_Cast(rel__14)); var what__16 any

			if jrt.File_Cast(f__15).IsDirectory__Z() { what__16 = Lit_56 } else { what__16 = Lit_57 }
//line :180:1
			var segs__17 any; var root_683 any = A_arbace_go_embed_A_const_59.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_685 lang.IFn



			if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = rel__14; var arg_687 any = A_arbace_go_embed_A_const_102; if linked_684 == nil { segs__17 = ifn_685.Invoke_O_O__O(arg_686, arg_687) } else { segs__17 = linked_684.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_683, arg_686, arg_687) }
//line :180:1
			var acc__18 any = lang.PersistentVector_EMPTY.Ref(); L2: for {




				var tmp5 any; var root_688 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = segs__17; if linked_689 == nil { tmp5 = ifn_690.Invoke_O__O(arg_691) } else { tmp5 = linked_689.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_688, arg_691) }; if jrt.J2g_Truth(tmp5) { var d__19 any; var root_692 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_694 lang.IFn
					if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = acc__18; var arg_696 any; var root_697 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = segs__17; if linked_698 == nil { arg_696 = ifn_699.Invoke_O__O(arg_700) } else { arg_696 = linked_698.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_697, arg_700) }; if linked_693 == nil { d__19 = ifn_694.Invoke_O_O__O(arg_695, arg_696) } else { d__19 = linked_693.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_692, arg_695, arg_696) }
//line :185:1
					var dp__20 any; var root_701 any = A_arbace_go_embed_A_const_52.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_703 lang.IFn

					if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = Lit_26; var arg_705 any = d__19; if linked_702 == nil { dp__20 = ifn_703.Invoke_O_O__O(arg_704, arg_705) } else { dp__20 = linked_702.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_701, arg_704, arg_705) }
//line :185:1
					var df__21 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), jrt.String_Cast(dp__20))



					if jrt.File_New_File_String(jrt.File_Cast(df__21), Lit_58).IsFile__Z() {
						var root_706 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, A_arbace_go_embed_embed_error_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = pattern__1; var arg_710 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_60, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, what__16, nil, rel__14, nil)).Ref(); if linked_707 == nil { ifn_708.Invoke_O_O__O(arg_709, arg_710) } else { linked_707.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_706, arg_709, arg_710) } }
					var tmp6 any; var root_711 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any; var root_715 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = segs__17; if linked_716 == nil { arg_714 = ifn_717.Invoke_O__O(arg_718) } else { arg_714 = linked_716.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_715, arg_718) }; if linked_712 == nil { tmp6 = ifn_713.Invoke_O__O(arg_714) } else { tmp6 = linked_712.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_711, arg_714) }; if jrt.J2g_Truth(tmp6) {
						var root_719 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, A_arbace_go_embed_embed_error_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = pattern__1; var arg_723 any; if lang.Util_Equiv_O_O__Z_NoInit(dp__20, rel__14) {
							var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_60, nil, Lit_62, nil); var tmp8 any; var root_724 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_726 lang.IFn; if linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = segs__17; if linked_725 == nil { tmp8 = ifn_726.Invoke_O__O(arg_727) } else { tmp8 = linked_725.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_724, arg_727) }; arg_723 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, what__16, nil, rel__14, nil, tmp8)).Ref() } else {
								var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_60, nil, Lit_63, nil); var tmp10 any; var root_728 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = segs__17; if linked_729 == nil { tmp10 = ifn_730.Invoke_O__O(arg_731) } else { tmp10 = linked_729.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_728, arg_731) }; arg_723 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, what__16, nil, rel__14, nil, tmp10)).Ref() }
//line :192:1
						if linked_720 == nil { ifn_721.Invoke_O_O__O(arg_722, arg_723) } else { linked_720.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_719, arg_722, arg_723)
						}
					}
					var tmp11 any; var root_732 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = segs__17; if linked_733 == nil { tmp11 = ifn_734.Invoke_O__O(arg_735) } else { tmp11 = linked_733.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_732, arg_735) }; segs__17, acc__18 = tmp11, d__19; continue L2 }
//line :180:1
				break L2
			}














			if jrt.File_Cast(f__15).IsFile__Z() {
				var tmp12 *lang.Volatile = lang.Volatile_Cast(list__9); var tmp13 any; var root_658 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = jrt.NN(lang.Volatile_Cast(list__9)).Deref__O(); var arg_662 any = rel__14; if linked_659 == nil { tmp13 = ifn_660.Invoke_O_O__O(arg_661, arg_662) } else { tmp13 = linked_659.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_658, arg_661, arg_662) }; jrt.NN(tmp12).Reset_O__O(tmp13) } else {
//line :196:1
					if jrt.File_Cast(f__15).IsDirectory__Z() { var n__17 any; var root_663 any = A_arbace_go_embed_A_const_98.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_665 lang.IFn


						if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = A_arbace_go_embed_A_const_31; if linked_664 == nil { n__17 = ifn_665.Invoke_O__O(arg_666) } else { n__17 = linked_664.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_663, arg_666) }
//line :196:1
						var body_walk__18 *A_arbace_go_embed_resolve_pattern_walk__1220000100_A = A_arbace_go_embed_resolve_pattern_walk__1220000100_A_New_O_O_O_O(pattern__1, list__9, all__4, n__17); var walk__18 any; var fnbody__865 any = any(body_walk__18); var tmp14 *jrt.Class; var fncls__864 *jrt.Class = A_arbace_go_embed_resolve_pattern_walk__1220000100_A_fn_class; if fncls__864 == nil { var fncls__864d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, fnbody__865); A_arbace_go_embed_resolve_pattern_walk__1220000100_A_fn_class = fncls__864d; tmp14 = fncls__864d } else { tmp14 = fncls__864 }; walk__18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__865, tmp14, nil)












						lang.IFn_Cast(walk__18).Invoke_O_O__O(f__15, rel__14)
						var tmp15 bool; var na_667 any; var root_668 any = A_arbace_go_embed_A_const_5.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_670 lang.IFn; if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = n__17; if linked_669 == nil { na_667 = ifn_670.Invoke_O__O(arg_671) } else { na_667 = linked_669.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_668, arg_671) }; if jrt.Long_InstanceOf(na_667) { var n0_672 int64 = jrt.NN(jrt.Long_Cast(na_667)).LongValue__J(); tmp15 = n0_672 == 0 } else { if jrt.Double_InstanceOf(na_667) { var n0_672_2 float64 = jrt.NN(jrt.Double_Cast(na_667)).DoubleValue__D(); tmp15 = n0_672_2 == 0.0 } else { tmp15 = lang.Numbers_IsZero_O__Z_NoInit(na_667) } }; if tmp15 {
							var root_673 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_673, A_arbace_go_embed_embed_error_A_fn_class); var ifn_675 lang.IFn; if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any = pattern__1; var arg_677 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_65, nil, Lit_66), jrt.RefArrayOf(jrt.Object_class, nil, rel__14, nil)).Ref(); if linked_674 == nil { ifn_675.Invoke_O_O__O(arg_676, arg_677) } else { linked_674.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_673, arg_676, arg_677) } } } else {
//line :196:1
								if A_arbace_go_embed_A_const_15 != nil {















									var root_678 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, A_arbace_go_embed_embed_error_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = pattern__1; var arg_682 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__14)).Ref(); if linked_679 == nil { ifn_680.Invoke_O_O__O(arg_681, arg_682) } else { linked_679.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_678, arg_681, arg_682) } } } }
//line :180:1
			seq_1220000096__10, chunk_1220000097__11, count_1220000098__12, i_1220000099__13 = seq_1220000096__10, chunk_1220000097__11, count_1220000098__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1220000099__13); continue L1 } else { var temp__1927000414__auto____14 any; var root_629 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = seq_1220000096__10; if linked_630 == nil { temp__1927000414__auto____14 = ifn_631.Invoke_O__O(arg_632) } else { temp__1927000414__auto____14 = linked_630.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_629, arg_632) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_1220000096__15 any = temp__1927000414__auto____14; var tmp16 any; var root_633 any = A_arbace_go_embed_A_const_79.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = seq_1220000096__15; if linked_634 == nil { tmp16 = ifn_635.Invoke_O__O(arg_636) } else { tmp16 = linked_634.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_633, arg_636) }; if jrt.J2g_Truth(tmp16) { var c__1927000678__auto____16 any; var root_637 any = A_arbace_go_embed_A_const_80.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = seq_1220000096__15; if linked_638 == nil { c__1927000678__auto____16 = ifn_639.Invoke_O__O(arg_640) } else { c__1927000678__auto____16 = linked_638.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_637, arg_640) }; var tmp17 any; var root_866 any = A_arbace_go_embed_A_const_85.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = seq_1220000096__15; if linked_867 == nil { tmp17 = ifn_868.Invoke_O__O(arg_869) } else { tmp17 = linked_867.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_866, arg_869) }; seq_1220000096__10, chunk_1220000097__11, count_1220000098__12, i_1220000099__13 = tmp17, c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var rel__16 any; var root_641 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_641, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_643 lang.IFn; if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = seq_1220000096__15; if linked_642 == nil { rel__16 = ifn_643.Invoke_O__O(arg_644) } else { rel__16 = linked_642.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_641, arg_644) }; var f__17 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), jrt.String_Cast(rel__16)); var what__18 any

				if jrt.File_Cast(f__17).IsDirectory__Z() { what__18 = Lit_56 } else { what__18 = Lit_57 }
//line :180:1
				var segs__19 any; var root_895 any = A_arbace_go_embed_A_const_59.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_897 lang.IFn



				if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = rel__16; var arg_899 any = A_arbace_go_embed_A_const_102; if linked_896 == nil { segs__19 = ifn_897.Invoke_O_O__O(arg_898, arg_899) } else { segs__19 = linked_896.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_895, arg_898, arg_899) }
//line :180:1
				var acc__20 any = lang.PersistentVector_EMPTY.Ref(); L3: for {




					var tmp18 any; var root_900 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any = segs__19; if linked_901 == nil { tmp18 = ifn_902.Invoke_O__O(arg_903) } else { tmp18 = linked_901.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_900, arg_903) }; if jrt.J2g_Truth(tmp18) { var d__21 any; var root_904 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_906 lang.IFn
						if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = acc__20; var arg_908 any; var root_909 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = segs__19; if linked_910 == nil { arg_908 = ifn_911.Invoke_O__O(arg_912) } else { arg_908 = linked_910.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_909, arg_912) }; if linked_905 == nil { d__21 = ifn_906.Invoke_O_O__O(arg_907, arg_908) } else { d__21 = linked_905.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_904, arg_907, arg_908) }
//line :185:1
						var dp__22 any; var root_913 any = A_arbace_go_embed_A_const_52.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_915 lang.IFn

						if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = Lit_26; var arg_917 any = d__21; if linked_914 == nil { dp__22 = ifn_915.Invoke_O_O__O(arg_916, arg_917) } else { dp__22 = linked_914.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_913, arg_916, arg_917) }
//line :185:1
						var df__23 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), jrt.String_Cast(dp__22))



						if jrt.File_New_File_String(jrt.File_Cast(df__23), Lit_58).IsFile__Z() {
							var root_918 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, A_arbace_go_embed_embed_error_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = pattern__1; var arg_922 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_60, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, what__18, nil, rel__16, nil)).Ref(); if linked_919 == nil { ifn_920.Invoke_O_O__O(arg_921, arg_922) } else { linked_919.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_918, arg_921, arg_922) } }
						var tmp19 any; var root_923 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any; var root_927 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_929 lang.IFn; if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = segs__19; if linked_928 == nil { arg_926 = ifn_929.Invoke_O__O(arg_930) } else { arg_926 = linked_928.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_927, arg_930) }; if linked_924 == nil { tmp19 = ifn_925.Invoke_O__O(arg_926) } else { tmp19 = linked_924.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_923, arg_926) }; if jrt.J2g_Truth(tmp19) {
							var root_931 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_931, A_arbace_go_embed_embed_error_A_fn_class); var ifn_933 lang.IFn; if linked_932 == nil { ifn_933 = lang.IFn_Cast(root_931) } else { ifn_933 = nil }; var arg_934 any = pattern__1; var arg_935 any; if lang.Util_Equiv_O_O__Z_NoInit(dp__22, rel__16) {
								var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_60, nil, Lit_62, nil); var tmp21 any; var root_936 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = segs__19; if linked_937 == nil { tmp21 = ifn_938.Invoke_O__O(arg_939) } else { tmp21 = linked_937.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_936, arg_939) }; arg_935 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, what__18, nil, rel__16, nil, tmp21)).Ref() } else {
									var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_60, nil, Lit_63, nil); var tmp23 any; var root_940 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_942 lang.IFn; if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = segs__19; if linked_941 == nil { tmp23 = ifn_942.Invoke_O__O(arg_943) } else { tmp23 = linked_941.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_940, arg_943) }; arg_935 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, what__18, nil, rel__16, nil, tmp23)).Ref() }
//line :192:1
							if linked_932 == nil { ifn_933.Invoke_O_O__O(arg_934, arg_935) } else { linked_932.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_931, arg_934, arg_935)
							}
						}
						var tmp24 any; var root_944 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_946 lang.IFn; if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = segs__19; if linked_945 == nil { tmp24 = ifn_946.Invoke_O__O(arg_947) } else { tmp24 = linked_945.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_944, arg_947) }; segs__19, acc__20 = tmp24, d__21; continue L3 }
//line :180:1
					break L3
				}














				if jrt.File_Cast(f__17).IsFile__Z() {
					var tmp25 *lang.Volatile = lang.Volatile_Cast(list__9); var tmp26 any; var root_870 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = jrt.NN(lang.Volatile_Cast(list__9)).Deref__O(); var arg_874 any = rel__16; if linked_871 == nil { tmp26 = ifn_872.Invoke_O_O__O(arg_873, arg_874) } else { tmp26 = linked_871.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_870, arg_873, arg_874) }; jrt.NN(tmp25).Reset_O__O(tmp26) } else {
//line :196:1
						if jrt.File_Cast(f__17).IsDirectory__Z() { var n__19 any; var root_875 any = A_arbace_go_embed_A_const_98.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_877 lang.IFn


							if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = A_arbace_go_embed_A_const_31; if linked_876 == nil { n__19 = ifn_877.Invoke_O__O(arg_878) } else { n__19 = linked_876.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_875, arg_878) }
//line :196:1
							var body_walk__20 *A_arbace_go_embed_resolve_pattern_walk__1220000106_A = A_arbace_go_embed_resolve_pattern_walk__1220000106_A_New_O_O_O_O(pattern__1, list__9, n__19, all__4); var walk__20 any; var fnbody__1077 any = any(body_walk__20); var tmp27 *jrt.Class; var fncls__1076 *jrt.Class = A_arbace_go_embed_resolve_pattern_walk__1220000106_A_fn_class; if fncls__1076 == nil { var fncls__1076d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, fnbody__1077); A_arbace_go_embed_resolve_pattern_walk__1220000106_A_fn_class = fncls__1076d; tmp27 = fncls__1076d } else { tmp27 = fncls__1076 }; walk__20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1077, tmp27, nil)












							lang.IFn_Cast(walk__20).Invoke_O_O__O(f__17, rel__16)
							var tmp28 bool; var na_879 any; var root_880 any = A_arbace_go_embed_A_const_5.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = n__19; if linked_881 == nil { na_879 = ifn_882.Invoke_O__O(arg_883) } else { na_879 = linked_881.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_880, arg_883) }; if jrt.Long_InstanceOf(na_879) { var n0_884 int64 = jrt.NN(jrt.Long_Cast(na_879)).LongValue__J(); tmp28 = n0_884 == 0 } else { if jrt.Double_InstanceOf(na_879) { var n0_884_2 float64 = jrt.NN(jrt.Double_Cast(na_879)).DoubleValue__D(); tmp28 = n0_884_2 == 0.0 } else { tmp28 = lang.Numbers_IsZero_O__Z_NoInit(na_879) } }; if tmp28 {
								var root_885 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, A_arbace_go_embed_embed_error_A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = pattern__1; var arg_889 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_65, nil, Lit_66), jrt.RefArrayOf(jrt.Object_class, nil, rel__16, nil)).Ref(); if linked_886 == nil { ifn_887.Invoke_O_O__O(arg_888, arg_889) } else { linked_886.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_885, arg_888, arg_889) } } } else {
//line :196:1
									if A_arbace_go_embed_A_const_15 != nil {















										var root_890 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, A_arbace_go_embed_embed_error_A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = pattern__1; var arg_894 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__16)).Ref(); if linked_891 == nil { ifn_892.Invoke_O_O__O(arg_893, arg_894) } else { linked_891.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_890, arg_893, arg_894) } } } }
//line :180:1
				var tmp29 any; var root_1078 any = A_arbace_go_embed_A_const_104.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1078, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1080 lang.IFn; if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = seq_1220000096__15; if linked_1079 == nil { tmp29 = ifn_1080.Invoke_O__O(arg_1081) } else { tmp29 = linked_1079.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1078, arg_1081) }; seq_1220000096__10, chunk_1220000097__11, count_1220000098__12, i_1220000099__13 = tmp29, nil, 0, 0; continue L1 } } }
//line :169:1
		break L1 }; var tmp30 any; var root_645 any =











































	A_arbace_go_embed_A_const_42.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any; var root_649 any = A_arbace_go_embed_A_const_5.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_651 lang.IFn; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = list__9; if linked_650 == nil { arg_648 = ifn_651.Invoke_O__O(arg_652) } else { arg_648 = linked_650.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_649, arg_652) }; if linked_646 == nil { tmp30 = ifn_647.Invoke_O__O(arg_648) } else { tmp30 = linked_646.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_645, arg_648) }; if jrt.J2g_Truth(tmp30) { var root_653 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, A_arbace_go_embed_embed_error_A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = pattern__1; var arg_657 any = Lit_69; if linked_654 == nil { ifn_655.Invoke_O_O__O(arg_656, arg_657) } else { linked_654.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_653, arg_656, arg_657) } }; var root_604 any =
	A_arbace_go_embed_A_const_78.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_604, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_606 lang.IFn; if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any; var root_608 any = A_arbace_go_embed_A_const_99.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_608, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_610 lang.IFn; if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any; var root_612 any = A_arbace_go_embed_A_const_100.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any; var root_616 any = A_arbace_go_embed_A_const_5.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any = list__9; if linked_617 == nil { arg_615 = ifn_618.Invoke_O__O(arg_619) } else { arg_615 = linked_617.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_616, arg_619) }; if linked_613 == nil { arg_611 = ifn_614.Invoke_O__O(arg_615) } else { arg_611 = linked_613.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_612, arg_615) }; if linked_609 == nil { arg_607 = ifn_610.Invoke_O__O(arg_611) } else { arg_607 = linked_609.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_608, arg_611) }; if linked_605 == nil { return ifn_606.Invoke_O__O(arg_607) } else { return linked_605.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_604, arg_607) } }
//line :200:1
func A_arbace_go_embed_resolve_pattern_walk__1220000100_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_embed_resolve_pattern_walk__1220000100_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_resolve_pattern_walk__1220000100_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :200:1
func (t *A_arbace_go_embed_resolve_pattern_walk__1220000100_A) Ctor_O_O_O_O(c__pattern, c__list, c__all, c__n any) { t.F_pattern = c__pattern; t.F_list = c__list; t.F_all = c__all; t.F_n = c__n }
//line :200:1
func (t *A_arbace_go_embed_resolve_pattern_walk__1220000100_A) Invoke_O_O_O__O(self, d__1, drel__2 any) any { { var seq_1220000101__3 any; var root_736 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_738 lang.IFn
														if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any; var root_740 any = A_arbace_go_embed_A_const_90.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, A_arbace_go_embed_sorted_children_A_fn_class); var ifn_742 lang.IFn; if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any = d__1; if linked_741 == nil { arg_739 = ifn_742.Invoke_O__O(arg_743) } else { arg_739 = linked_741.(*A_arbace_go_embed_sorted_children_A).Invoke_O_O__O(root_740, arg_743) }; if linked_737 == nil { seq_1220000101__3 = ifn_738.Invoke_O__O(arg_739) } else { seq_1220000101__3 = linked_737.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_736, arg_739) }
//line :200:1
	var chunk_1220000102__4 any; var count_1220000103__5 int64 = 0; var i_1220000104__6 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1220000104__6, count_1220000103__5) { var c__7 any = lang.Indexed_Cast(chunk_1220000102__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1220000104__6)); var nm__8 any = jrt.File_Cast(c__7).GetName__String().Ref(); var crel__9 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, drel__2, nil, nm__8)).Ref(); var tmp1 any; var or__1927000174__auto____10 any; var root_760 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_762 lang.IFn


			if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = nm__8; if linked_761 == nil { or__1927000174__auto____10 = ifn_762.Invoke_O__O(arg_763) } else { or__1927000174__auto____10 = linked_761.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_760, arg_763) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp1 = or__1927000174__auto____10 } else { var and__1927000168__auto____11 any; var root_764 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = t.F_all; if linked_765 == nil { and__1927000168__auto____11 = ifn_766.Invoke_O__O(arg_767) } else { and__1927000168__auto____11 = linked_765.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_764, arg_767) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var root_768 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = nm__8; var arg_772 any = Lit_2; if linked_769 == nil { or__1927000174__auto____12 = ifn_770.Invoke_O_O__O(arg_771, arg_772) } else { or__1927000174__auto____12 = linked_769.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_768, arg_771, arg_772) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp1 = or__1927000174__auto____12 } else { var root_773 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = nm__8; var arg_777 any = Lit_70; if linked_774 == nil { tmp1 = ifn_775.Invoke_O_O__O(arg_776, arg_777) } else { tmp1 = linked_774.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_773, arg_776, arg_777) } } } else { tmp1 = and__1927000168__auto____11 } }
//line :203:1
			if jrt.J2g_Truth(tmp1) {

				var tmp2 any; var and__1927000168__auto____10 bool = jrt.File_Cast(c__7).IsFile__Z(); if and__1927000168__auto____10 { var and__1927000168__auto____11_2 any; var root_778 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = nm__8; if linked_779 == nil { and__1927000168__auto____11_2 = ifn_780.Invoke_O__O(arg_781) } else { and__1927000168__auto____11_2 = linked_779.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_778, arg_781) }; if jrt.J2g_Truth(and__1927000168__auto____11_2) { var root_782 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_784 lang.IFn; if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any; var or__1927000174__auto____12_2 any; var root_786 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any = nm__8; var arg_790 any = Lit_2; if linked_787 == nil { or__1927000174__auto____12_2 = ifn_788.Invoke_O_O__O(arg_789, arg_790) } else { or__1927000174__auto____12_2 = linked_787.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_786, arg_789, arg_790) }; if jrt.J2g_Truth(or__1927000174__auto____12_2) { arg_785 = or__1927000174__auto____12_2 } else { var root_791 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = nm__8; var arg_795 any = Lit_70; if linked_792 == nil { arg_785 = ifn_793.Invoke_O_O__O(arg_794, arg_795) } else { arg_785 = linked_792.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_791, arg_794, arg_795) } }; if linked_783 == nil { tmp2 = ifn_784.Invoke_O__O(arg_785) } else { tmp2 = linked_783.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_782, arg_785) } } else { tmp2 = and__1927000168__auto____11_2 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }; if jrt.J2g_Truth(tmp2) {
					var root_796 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, A_arbace_go_embed_embed_error_A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = t.F_pattern; var arg_800 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_71, nil, Lit_62, nil), jrt.RefArrayOf(jrt.Object_class, nil, crel__9, nil, nm__8)).Ref(); if linked_797 == nil { ifn_798.Invoke_O_O__O(arg_799, arg_800) } else { linked_797.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_796, arg_799, arg_800) } } } else {
//line :203:1
						if jrt.File_Cast(c__7).IsDirectory__Z() {



							if jrt.File_New_File_String(jrt.File_Cast(c__7), Lit_58).IsFile__Z() { } else { lang.IFn_Cast(self).Invoke_O_O__O(c__7, crel__9) } } else {
//line :203:1
								if jrt.File_Cast(c__7).IsFile__Z() {




									var tmp3 *lang.Volatile = lang.Volatile_Cast(t.F_n); var tmp4 jrt.Number_I; var na_806 any = jrt.NN(lang.Volatile_Cast(t.F_n)).Deref__O(); if jrt.Long_InstanceOf(na_806) { var n0_807 int64 = jrt.NN(jrt.Long_Cast(na_806)).LongValue__J(); if n0_807 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_806) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_807 + 1)) } } else { if jrt.Double_InstanceOf(na_806) { var n0_807_2 float64 = jrt.NN(jrt.Double_Cast(na_806)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_807_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_806) } }; jrt.NN(tmp3).Reset_O__O(tmp4); var tmp5 *lang.Volatile = lang.Volatile_Cast(t.F_list); var tmp6 any; var root_801 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_801, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_803 lang.IFn; if linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; var arg_804 any = jrt.NN(lang.Volatile_Cast(t.F_list)).Deref__O(); var arg_805 any = crel__9; if linked_802 == nil { tmp6 = ifn_803.Invoke_O_O__O(arg_804, arg_805) } else { tmp6 = linked_802.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_801, arg_804, arg_805) }; jrt.NN(tmp5).Reset_O__O(tmp6) } } }
//line :201:1
			seq_1220000101__3, chunk_1220000102__4, count_1220000103__5, i_1220000104__6 = seq_1220000101__3, chunk_1220000102__4, count_1220000103__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1220000104__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_744 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_744, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_746 lang.IFn; if linked_745 == nil { ifn_746 = lang.IFn_Cast(root_744) } else { ifn_746 = nil }; var arg_747 any = seq_1220000101__3; if linked_745 == nil { temp__1927000414__auto____7 = ifn_746.Invoke_O__O(arg_747) } else { temp__1927000414__auto____7 = linked_745.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_744, arg_747) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1220000101__8 any = temp__1927000414__auto____7; var tmp7 any; var root_748 any = A_arbace_go_embed_A_const_79.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = seq_1220000101__8; if linked_749 == nil { tmp7 = ifn_750.Invoke_O__O(arg_751) } else { tmp7 = linked_749.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_748, arg_751) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____9 any; var root_752 any = A_arbace_go_embed_A_const_80.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = seq_1220000101__8; if linked_753 == nil { c__1927000678__auto____9 = ifn_754.Invoke_O__O(arg_755) } else { c__1927000678__auto____9 = linked_753.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_752, arg_755) }; var tmp8 any; var root_808 any = A_arbace_go_embed_A_const_85.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = seq_1220000101__8; if linked_809 == nil { tmp8 = ifn_810.Invoke_O__O(arg_811) } else { tmp8 = linked_809.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_808, arg_811) }; seq_1220000101__3, chunk_1220000102__4, count_1220000103__5, i_1220000104__6 = tmp8, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var c__9 any; var root_756 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = seq_1220000101__8; if linked_757 == nil { c__9 = ifn_758.Invoke_O__O(arg_759) } else { c__9 = linked_757.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_756, arg_759) }; var nm__10 any = jrt.File_Cast(c__9).GetName__String().Ref(); var crel__11 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, drel__2, nil, nm__10)).Ref(); var tmp9 any; var or__1927000174__auto____12_3 any; var root_812 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_814 lang.IFn


				if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = nm__10; if linked_813 == nil { or__1927000174__auto____12_3 = ifn_814.Invoke_O__O(arg_815) } else { or__1927000174__auto____12_3 = linked_813.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_812, arg_815) }; if jrt.J2g_Truth(or__1927000174__auto____12_3) { tmp9 = or__1927000174__auto____12_3 } else { var and__1927000168__auto____13 any; var root_816 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = t.F_all; if linked_817 == nil { and__1927000168__auto____13 = ifn_818.Invoke_O__O(arg_819) } else { and__1927000168__auto____13 = linked_817.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_816, arg_819) }; if jrt.J2g_Truth(and__1927000168__auto____13) { var or__1927000174__auto____14 any; var root_820 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_822 lang.IFn; if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any = nm__10; var arg_824 any = Lit_2; if linked_821 == nil { or__1927000174__auto____14 = ifn_822.Invoke_O_O__O(arg_823, arg_824) } else { or__1927000174__auto____14 = linked_821.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_820, arg_823, arg_824) }; if jrt.J2g_Truth(or__1927000174__auto____14) { tmp9 = or__1927000174__auto____14 } else { var root_825 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_827 lang.IFn; if linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = nm__10; var arg_829 any = Lit_70; if linked_826 == nil { tmp9 = ifn_827.Invoke_O_O__O(arg_828, arg_829) } else { tmp9 = linked_826.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_825, arg_828, arg_829) } } } else { tmp9 = and__1927000168__auto____13 } }
//line :203:1
				if jrt.J2g_Truth(tmp9) {

					var tmp10 any; var and__1927000168__auto____12 bool = jrt.File_Cast(c__9).IsFile__Z(); if and__1927000168__auto____12 { var and__1927000168__auto____13_2 any; var root_830 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_830, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_832 lang.IFn; if linked_831 == nil { ifn_832 = lang.IFn_Cast(root_830) } else { ifn_832 = nil }; var arg_833 any = nm__10; if linked_831 == nil { and__1927000168__auto____13_2 = ifn_832.Invoke_O__O(arg_833) } else { and__1927000168__auto____13_2 = linked_831.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_830, arg_833) }; if jrt.J2g_Truth(and__1927000168__auto____13_2) { var root_834 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_834, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_836 lang.IFn; if linked_835 == nil { ifn_836 = lang.IFn_Cast(root_834) } else { ifn_836 = nil }; var arg_837 any; var or__1927000174__auto____14_2 any; var root_838 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_840 lang.IFn; if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any = nm__10; var arg_842 any = Lit_2; if linked_839 == nil { or__1927000174__auto____14_2 = ifn_840.Invoke_O_O__O(arg_841, arg_842) } else { or__1927000174__auto____14_2 = linked_839.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_838, arg_841, arg_842) }; if jrt.J2g_Truth(or__1927000174__auto____14_2) { arg_837 = or__1927000174__auto____14_2 } else { var root_843 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_843, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_845 lang.IFn; if linked_844 == nil { ifn_845 = lang.IFn_Cast(root_843) } else { ifn_845 = nil }; var arg_846 any = nm__10; var arg_847 any = Lit_70; if linked_844 == nil { arg_837 = ifn_845.Invoke_O_O__O(arg_846, arg_847) } else { arg_837 = linked_844.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_843, arg_846, arg_847) } }; if linked_835 == nil { tmp10 = ifn_836.Invoke_O__O(arg_837) } else { tmp10 = linked_835.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_834, arg_837) } } else { tmp10 = and__1927000168__auto____13_2 } } else { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____12).Ref() }; if jrt.J2g_Truth(tmp10) {
						var root_848 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, A_arbace_go_embed_embed_error_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = t.F_pattern; var arg_852 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_71, nil, Lit_62, nil), jrt.RefArrayOf(jrt.Object_class, nil, crel__11, nil, nm__10)).Ref(); if linked_849 == nil { ifn_850.Invoke_O_O__O(arg_851, arg_852) } else { linked_849.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_848, arg_851, arg_852) } } } else {
//line :203:1
							if jrt.File_Cast(c__9).IsDirectory__Z() {



								if jrt.File_New_File_String(jrt.File_Cast(c__9), Lit_58).IsFile__Z() { } else { lang.IFn_Cast(self).Invoke_O_O__O(c__9, crel__11) } } else {
//line :203:1
									if jrt.File_Cast(c__9).IsFile__Z() {




										var tmp11 *lang.Volatile = lang.Volatile_Cast(t.F_n); var tmp12 jrt.Number_I; var na_858 any = jrt.NN(lang.Volatile_Cast(t.F_n)).Deref__O(); if jrt.Long_InstanceOf(na_858) { var n0_859 int64 = jrt.NN(jrt.Long_Cast(na_858)).LongValue__J(); if n0_859 == 9223372036854775807 { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_858) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_859 + 1)) } } else { if jrt.Double_InstanceOf(na_858) { var n0_859_2 float64 = jrt.NN(jrt.Double_Cast(na_858)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_859_2 + 1.0)) } else { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_858) } }; jrt.NN(tmp11).Reset_O__O(tmp12); var tmp13 *lang.Volatile = lang.Volatile_Cast(t.F_list); var tmp14 any; var root_853 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_853, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = jrt.NN(lang.Volatile_Cast(t.F_list)).Deref__O(); var arg_857 any = crel__11; if linked_854 == nil { tmp14 = ifn_855.Invoke_O_O__O(arg_856, arg_857) } else { tmp14 = linked_854.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_853, arg_856, arg_857) }; jrt.NN(tmp13).Reset_O__O(tmp14) } } }
//line :201:1
				var tmp15 any; var root_860 any = A_arbace_go_embed_A_const_104.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = seq_1220000101__8; if linked_861 == nil { tmp15 = ifn_862.Invoke_O__O(arg_863) } else { tmp15 = linked_861.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_860, arg_863) }; seq_1220000101__3, chunk_1220000102__4, count_1220000103__5, i_1220000104__6 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :200:1*/panic("j2g: unreachable") }
//line :200:1
func A_arbace_go_embed_resolve_pattern_walk__1220000106_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_embed_resolve_pattern_walk__1220000106_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_resolve_pattern_walk__1220000106_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :200:1
func (t *A_arbace_go_embed_resolve_pattern_walk__1220000106_A) Ctor_O_O_O_O(c__pattern, c__list, c__n, c__all any) { t.F_pattern = c__pattern; t.F_list = c__list; t.F_n = c__n; t.F_all = c__all }
//line :200:1
func (t *A_arbace_go_embed_resolve_pattern_walk__1220000106_A) Invoke_O_O_O__O(self, d__1, drel__2 any) any { { var seq_1220000107__3 any; var root_948 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_950 lang.IFn
														if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any; var root_952 any = A_arbace_go_embed_A_const_90.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, A_arbace_go_embed_sorted_children_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = d__1; if linked_953 == nil { arg_951 = ifn_954.Invoke_O__O(arg_955) } else { arg_951 = linked_953.(*A_arbace_go_embed_sorted_children_A).Invoke_O_O__O(root_952, arg_955) }; if linked_949 == nil { seq_1220000107__3 = ifn_950.Invoke_O__O(arg_951) } else { seq_1220000107__3 = linked_949.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_948, arg_951) }
//line :200:1
	var chunk_1220000108__4 any; var count_1220000109__5 int64 = 0; var i_1220000110__6 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1220000110__6, count_1220000109__5) { var c__7 any = lang.Indexed_Cast(chunk_1220000108__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1220000110__6)); var nm__8 any = jrt.File_Cast(c__7).GetName__String().Ref(); var crel__9 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, drel__2, nil, nm__8)).Ref(); var tmp1 any; var or__1927000174__auto____10 any; var root_972 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_974 lang.IFn


			if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any = nm__8; if linked_973 == nil { or__1927000174__auto____10 = ifn_974.Invoke_O__O(arg_975) } else { or__1927000174__auto____10 = linked_973.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_972, arg_975) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp1 = or__1927000174__auto____10 } else { var and__1927000168__auto____11 any; var root_976 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = t.F_all; if linked_977 == nil { and__1927000168__auto____11 = ifn_978.Invoke_O__O(arg_979) } else { and__1927000168__auto____11 = linked_977.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_976, arg_979) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var root_980 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = nm__8; var arg_984 any = Lit_2; if linked_981 == nil { or__1927000174__auto____12 = ifn_982.Invoke_O_O__O(arg_983, arg_984) } else { or__1927000174__auto____12 = linked_981.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_980, arg_983, arg_984) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp1 = or__1927000174__auto____12 } else { var root_985 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = nm__8; var arg_989 any = Lit_70; if linked_986 == nil { tmp1 = ifn_987.Invoke_O_O__O(arg_988, arg_989) } else { tmp1 = linked_986.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_985, arg_988, arg_989) } } } else { tmp1 = and__1927000168__auto____11 } }
//line :203:1
			if jrt.J2g_Truth(tmp1) {

				var tmp2 any; var and__1927000168__auto____10 bool = jrt.File_Cast(c__7).IsFile__Z(); if and__1927000168__auto____10 { var and__1927000168__auto____11_2 any; var root_990 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any = nm__8; if linked_991 == nil { and__1927000168__auto____11_2 = ifn_992.Invoke_O__O(arg_993) } else { and__1927000168__auto____11_2 = linked_991.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_990, arg_993) }; if jrt.J2g_Truth(and__1927000168__auto____11_2) { var root_994 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any; var or__1927000174__auto____12_2 any; var root_998 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = nm__8; var arg_1002 any = Lit_2; if linked_999 == nil { or__1927000174__auto____12_2 = ifn_1000.Invoke_O_O__O(arg_1001, arg_1002) } else { or__1927000174__auto____12_2 = linked_999.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_998, arg_1001, arg_1002) }; if jrt.J2g_Truth(or__1927000174__auto____12_2) { arg_997 = or__1927000174__auto____12_2 } else { var root_1003 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_1004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1003, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1005 lang.IFn; if linked_1004 == nil { ifn_1005 = lang.IFn_Cast(root_1003) } else { ifn_1005 = nil }; var arg_1006 any = nm__8; var arg_1007 any = Lit_70; if linked_1004 == nil { arg_997 = ifn_1005.Invoke_O_O__O(arg_1006, arg_1007) } else { arg_997 = linked_1004.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1003, arg_1006, arg_1007) } }; if linked_995 == nil { tmp2 = ifn_996.Invoke_O__O(arg_997) } else { tmp2 = linked_995.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_994, arg_997) } } else { tmp2 = and__1927000168__auto____11_2 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }; if jrt.J2g_Truth(tmp2) {
					var root_1008 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1008, A_arbace_go_embed_embed_error_A_fn_class); var ifn_1010 lang.IFn; if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any = t.F_pattern; var arg_1012 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_71, nil, Lit_62, nil), jrt.RefArrayOf(jrt.Object_class, nil, crel__9, nil, nm__8)).Ref(); if linked_1009 == nil { ifn_1010.Invoke_O_O__O(arg_1011, arg_1012) } else { linked_1009.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_1008, arg_1011, arg_1012) } } } else {
//line :203:1
						if jrt.File_Cast(c__7).IsDirectory__Z() {



							if jrt.File_New_File_String(jrt.File_Cast(c__7), Lit_58).IsFile__Z() { } else { lang.IFn_Cast(self).Invoke_O_O__O(c__7, crel__9) } } else {
//line :203:1
								if jrt.File_Cast(c__7).IsFile__Z() {




									var tmp3 *lang.Volatile = lang.Volatile_Cast(t.F_n); var tmp4 jrt.Number_I; var na_1018 any = jrt.NN(lang.Volatile_Cast(t.F_n)).Deref__O(); if jrt.Long_InstanceOf(na_1018) { var n0_1019 int64 = jrt.NN(jrt.Long_Cast(na_1018)).LongValue__J(); if n0_1019 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_1018) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1019 + 1)) } } else { if jrt.Double_InstanceOf(na_1018) { var n0_1019_2 float64 = jrt.NN(jrt.Double_Cast(na_1018)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1019_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_1018) } }; jrt.NN(tmp3).Reset_O__O(tmp4); var tmp5 *lang.Volatile = lang.Volatile_Cast(t.F_list); var tmp6 any; var root_1013 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any = jrt.NN(lang.Volatile_Cast(t.F_list)).Deref__O(); var arg_1017 any = crel__9; if linked_1014 == nil { tmp6 = ifn_1015.Invoke_O_O__O(arg_1016, arg_1017) } else { tmp6 = linked_1014.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1013, arg_1016, arg_1017) }; jrt.NN(tmp5).Reset_O__O(tmp6) } } }
//line :201:1
			seq_1220000107__3, chunk_1220000108__4, count_1220000109__5, i_1220000110__6 = seq_1220000107__3, chunk_1220000108__4, count_1220000109__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1220000110__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_956 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = seq_1220000107__3; if linked_957 == nil { temp__1927000414__auto____7 = ifn_958.Invoke_O__O(arg_959) } else { temp__1927000414__auto____7 = linked_957.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_956, arg_959) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1220000107__8 any = temp__1927000414__auto____7; var tmp7 any; var root_960 any = A_arbace_go_embed_A_const_79.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_962 lang.IFn; if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any = seq_1220000107__8; if linked_961 == nil { tmp7 = ifn_962.Invoke_O__O(arg_963) } else { tmp7 = linked_961.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_960, arg_963) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____9 any; var root_964 any = A_arbace_go_embed_A_const_80.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_966 lang.IFn; if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any = seq_1220000107__8; if linked_965 == nil { c__1927000678__auto____9 = ifn_966.Invoke_O__O(arg_967) } else { c__1927000678__auto____9 = linked_965.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_964, arg_967) }; var tmp8 any; var root_1020 any = A_arbace_go_embed_A_const_85.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = seq_1220000107__8; if linked_1021 == nil { tmp8 = ifn_1022.Invoke_O__O(arg_1023) } else { tmp8 = linked_1021.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1020, arg_1023) }; seq_1220000107__3, chunk_1220000108__4, count_1220000109__5, i_1220000110__6 = tmp8, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var c__9 any; var root_968 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_968, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = seq_1220000107__8; if linked_969 == nil { c__9 = ifn_970.Invoke_O__O(arg_971) } else { c__9 = linked_969.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_968, arg_971) }; var nm__10 any = jrt.File_Cast(c__9).GetName__String().Ref(); var crel__11 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, drel__2, nil, nm__10)).Ref(); var tmp9 any; var or__1927000174__auto____12_3 any; var root_1024 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_1026 lang.IFn


				if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = nm__10; if linked_1025 == nil { or__1927000174__auto____12_3 = ifn_1026.Invoke_O__O(arg_1027) } else { or__1927000174__auto____12_3 = linked_1025.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_1024, arg_1027) }; if jrt.J2g_Truth(or__1927000174__auto____12_3) { tmp9 = or__1927000174__auto____12_3 } else { var and__1927000168__auto____13 any; var root_1028 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1030 lang.IFn; if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = t.F_all; if linked_1029 == nil { and__1927000168__auto____13 = ifn_1030.Invoke_O__O(arg_1031) } else { and__1927000168__auto____13 = linked_1029.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1028, arg_1031) }; if jrt.J2g_Truth(and__1927000168__auto____13) { var or__1927000174__auto____14 any; var root_1032 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = nm__10; var arg_1036 any = Lit_2; if linked_1033 == nil { or__1927000174__auto____14 = ifn_1034.Invoke_O_O__O(arg_1035, arg_1036) } else { or__1927000174__auto____14 = linked_1033.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1032, arg_1035, arg_1036) }; if jrt.J2g_Truth(or__1927000174__auto____14) { tmp9 = or__1927000174__auto____14 } else { var root_1037 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = nm__10; var arg_1041 any = Lit_70; if linked_1038 == nil { tmp9 = ifn_1039.Invoke_O_O__O(arg_1040, arg_1041) } else { tmp9 = linked_1038.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1037, arg_1040, arg_1041) } } } else { tmp9 = and__1927000168__auto____13 } }
//line :203:1
				if jrt.J2g_Truth(tmp9) {

					var tmp10 any; var and__1927000168__auto____12 bool = jrt.File_Cast(c__9).IsFile__Z(); if and__1927000168__auto____12 { var and__1927000168__auto____13_2 any; var root_1042 any = A_arbace_go_embed_A_const_103.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, A_arbace_go_embed_bad_name_QMARK__A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = nm__10; if linked_1043 == nil { and__1927000168__auto____13_2 = ifn_1044.Invoke_O__O(arg_1045) } else { and__1927000168__auto____13_2 = linked_1043.(*A_arbace_go_embed_bad_name_QMARK__A).Invoke_O_O__O(root_1042, arg_1045) }; if jrt.J2g_Truth(and__1927000168__auto____13_2) { var root_1046 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any; var or__1927000174__auto____14_2 any; var root_1050 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1050, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = nm__10; var arg_1054 any = Lit_2; if linked_1051 == nil { or__1927000174__auto____14_2 = ifn_1052.Invoke_O_O__O(arg_1053, arg_1054) } else { or__1927000174__auto____14_2 = linked_1051.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1050, arg_1053, arg_1054) }; if jrt.J2g_Truth(or__1927000174__auto____14_2) { arg_1049 = or__1927000174__auto____14_2 } else { var root_1055 any = A_arbace_go_embed_A_const_51.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1055, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1057 lang.IFn; if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = nm__10; var arg_1059 any = Lit_70; if linked_1056 == nil { arg_1049 = ifn_1057.Invoke_O_O__O(arg_1058, arg_1059) } else { arg_1049 = linked_1056.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1055, arg_1058, arg_1059) } }; if linked_1047 == nil { tmp10 = ifn_1048.Invoke_O__O(arg_1049) } else { tmp10 = linked_1047.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1046, arg_1049) } } else { tmp10 = and__1927000168__auto____13_2 } } else { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____12).Ref() }; if jrt.J2g_Truth(tmp10) {
						var root_1060 any = A_arbace_go_embed_A_const_96.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1060, A_arbace_go_embed_embed_error_A_fn_class); var ifn_1062 lang.IFn; if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 any = t.F_pattern; var arg_1064 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_71, nil, Lit_62, nil), jrt.RefArrayOf(jrt.Object_class, nil, crel__11, nil, nm__10)).Ref(); if linked_1061 == nil { ifn_1062.Invoke_O_O__O(arg_1063, arg_1064) } else { linked_1061.(*A_arbace_go_embed_embed_error_A).Invoke_O_O_O__O(root_1060, arg_1063, arg_1064) } } } else {
//line :203:1
							if jrt.File_Cast(c__9).IsDirectory__Z() {



								if jrt.File_New_File_String(jrt.File_Cast(c__9), Lit_58).IsFile__Z() { } else { lang.IFn_Cast(self).Invoke_O_O__O(c__9, crel__11) } } else {
//line :203:1
									if jrt.File_Cast(c__9).IsFile__Z() {




										var tmp11 *lang.Volatile = lang.Volatile_Cast(t.F_n); var tmp12 jrt.Number_I; var na_1070 any = jrt.NN(lang.Volatile_Cast(t.F_n)).Deref__O(); if jrt.Long_InstanceOf(na_1070) { var n0_1071 int64 = jrt.NN(jrt.Long_Cast(na_1070)).LongValue__J(); if n0_1071 == 9223372036854775807 { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_1070) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1071 + 1)) } } else { if jrt.Double_InstanceOf(na_1070) { var n0_1071_2 float64 = jrt.NN(jrt.Double_Cast(na_1070)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1071_2 + 1.0)) } else { tmp12 = lang.Numbers_Inc_O__Number_NoInit(na_1070) } }; jrt.NN(tmp11).Reset_O__O(tmp12); var tmp13 *lang.Volatile = lang.Volatile_Cast(t.F_list); var tmp14 any; var root_1065 any = A_arbace_go_embed_A_const_7.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = jrt.NN(lang.Volatile_Cast(t.F_list)).Deref__O(); var arg_1069 any = crel__11; if linked_1066 == nil { tmp14 = ifn_1067.Invoke_O_O__O(arg_1068, arg_1069) } else { tmp14 = linked_1066.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1065, arg_1068, arg_1069) }; jrt.NN(tmp13).Reset_O__O(tmp14) } } }
//line :201:1
				var tmp15 any; var root_1072 any = A_arbace_go_embed_A_const_104.GetRawRoot__O(); var linked_1073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1072, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1074 lang.IFn; if linked_1073 == nil { ifn_1074 = lang.IFn_Cast(root_1072) } else { ifn_1074 = nil }; var arg_1075 any = seq_1220000107__8; if linked_1073 == nil { tmp15 = ifn_1074.Invoke_O__O(arg_1075) } else { tmp15 = linked_1073.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1072, arg_1075) }; seq_1220000107__3, chunk_1220000108__4, count_1220000109__5, i_1220000110__6 = tmp15, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :200:1*/panic("j2g: unreachable") }

















func A_arbace_go_embed_name_split_A_New() *A_arbace_go_embed_name_split_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_name_split_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_go_embed_name_split_A) Ctor() {}
//line :218:1
func (t *A_arbace_go_embed_name_split_A) Invoke_O_O__O(self, n__0 any) any { var n__2 any; var tmp1 any; var root_1082 any = A_arbace_go_embed_A_const_69.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1082, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1084 lang.IFn; if
										linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any = n__0; var arg_1086 any = Lit_26; if linked_1083 == nil { tmp1 = ifn_1084.Invoke_O_O__O(arg_1085, arg_1086) } else { tmp1 = linked_1083.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1082, arg_1085, arg_1086) }; if jrt.J2g_Truth(tmp1) { var root_1087 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = n__0; var arg_1091 any = A_arbace_go_embed_A_const_31; var arg_1092 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(n__0)))).Ref(); if linked_1088 == nil { n__2 = ifn_1089.Invoke_O_O_O__O(arg_1090, arg_1091, arg_1092) } else { n__2 = linked_1088.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1087, arg_1090, arg_1091, arg_1092) } } else { n__2 = n__0 }; var i__3 any; var root_1093 any = /*line :218:1*/A_arbace_go_embed_A_const_105.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_string.A_arbace_string_last_index_of_A_fn_class); var ifn_1095 lang.IFn; if

	linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = n__2; var arg_1097 any = Lit_26; if linked_1094 == nil { i__3 = ifn_1095.Invoke_O_O__O(arg_1096, arg_1097) } else { i__3 = linked_1094.(*aot_arbace_string.A_arbace_string_last_index_of_A).Invoke_O_O_O__O(root_1093, arg_1096, arg_1097) }; if
	lang.Util_Identical_O_O__Z_NoInit(i__3, nil) { return lang.Tuple_Create_O_O__IPersistentVector(Lit_2, n__2) } else { var tmp2 any; var root_1098 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_1099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1098, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1100 lang.IFn; if linked_1099 == nil { ifn_1100 = lang.IFn_Cast(root_1098) } else { ifn_1100 = nil }; var arg_1101 any = n__2; var arg_1102 any = A_arbace_go_embed_A_const_31; var arg_1103 any = i__3; if linked_1099 == nil { tmp2 = ifn_1100.Invoke_O_O_O__O(arg_1101, arg_1102, arg_1103) } else { tmp2 = linked_1099.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1098, arg_1101, arg_1102, arg_1103) }; var tmp3 any = tmp2; var tmp4 any; var root_1104 any = A_arbace_go_embed_A_const_9.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1106 lang.IFn; if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = n__2; var arg_1108 any; var na_1109 any = i__3; if jrt.Long_InstanceOf(na_1109) { var n0_1110 int64 = jrt.NN(jrt.Long_Cast(na_1109)).LongValue__J(); if n0_1110 == 9223372036854775807 { arg_1108 = lang.Numbers_Inc_O__Number_NoInit(na_1109) } else { arg_1108 = jrt.Long_ValueOf_J__Long_NoInit(n0_1110 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1109) { var n0_1110_2 float64 = jrt.NN(jrt.Double_Cast(na_1109)).DoubleValue__D(); arg_1108 = jrt.Double_ValueOf_D__Double_NoInit(n0_1110_2 + 1.0).Ref() } else { arg_1108 = lang.Numbers_Inc_O__Number_NoInit(na_1109) } }; if linked_1105 == nil { tmp4 = ifn_1106.Invoke_O_O__O(arg_1107, arg_1108) } else { tmp4 = linked_1105.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1104, arg_1107, arg_1108) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } }

func A_arbace_go_embed_file_less_A_New() *A_arbace_go_embed_file_less_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_file_less_A{}; t.Ctor(); return t }
//line :223:1
func (t *A_arbace_go_embed_file_less_A) Ctor() {}
//line :223:1
func (t *A_arbace_go_embed_file_less_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var vec__1220000114__3 any; var root_1111 any = A_arbace_go_embed_A_const_106.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, A_arbace_go_embed_name_split_A_fn_class); var ifn_1113 lang.IFn; if


	linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = x__0; if linked_1112 == nil { vec__1220000114__3 = ifn_1113.Invoke_O__O(arg_1114) } else { vec__1220000114__3 = linked_1112.(*A_arbace_go_embed_name_split_A).Invoke_O_O__O(root_1111, arg_1114) }; var xd__4 any = /*line :223:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1220000114__3, lang.RT_IntCast_J__I_NoInit(0), nil); var xe__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000114__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__1220000117__6 any; var root_1115 any = A_arbace_go_embed_A_const_106.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, A_arbace_go_embed_name_split_A_fn_class); var ifn_1117 lang.IFn; if


	linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any = y__1; if linked_1116 == nil { vec__1220000117__6 = ifn_1117.Invoke_O__O(arg_1118) } else { vec__1220000117__6 = linked_1116.(*A_arbace_go_embed_name_split_A).Invoke_O_O__O(root_1115, arg_1118) }; var yd__7 any = /*line :223:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1220000117__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ye__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1220000117__6, lang.RT_IntCast_J__I_NoInit(1), nil); var or__1927000174__auto____9 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(lang.Util_Compare_O_O__I_NoInit(xd__4, yd__7))); if or__1927000174__auto____9 {



		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else { var and__1927000168__auto____10 bool = lang.Util_Equiv_O_O__Z_NoInit(xd__4, yd__7); if and__1927000168__auto____10 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsNeg_J__Z_NoInit(int64(lang.Util_Compare_O_O__I_NoInit(xe__5, ye__8)))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() } } }

func A_arbace_go_embed_sha256_hex_A_New() *A_arbace_go_embed_sha256_hex_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_sha256_hex_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_go_embed_sha256_hex_A) Ctor() {}
//line :229:1
func (t *A_arbace_go_embed_sha256_hex_A) Invoke_O_O__O(self, bs__0 any) any { var md__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_72); var root_1119 any = A_arbace_go_embed_A_const_107.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1119, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1121 lang.IFn; if

	linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var arg_1123 any; var root_1124 any = A_arbace_go_embed_A_const_53.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1124, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1126 lang.IFn; if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any; var fnbody__1140 any = A_arbace_go_embed_sha256_hex_fn__1220000122_A_New(); var tmp1 *jrt.Class; var fncls__1139 *jrt.Class = A_arbace_go_embed_sha256_hex_fn__1220000122_A_fn_class; if fncls__1139 == nil { var fncls__1139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, nil); A_arbace_go_embed_sha256_hex_fn__1220000122_A_fn_class = fncls__1139d; tmp1 = fncls__1139d } else { tmp1 = fncls__1139 }; arg_1127 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1140, tmp1, nil); var arg_1128 any = jrt.MessageDigest_Cast(md__2).Digest_B1__B1(jrt.ByteArray_Cast(bs__0)).Ref(); if linked_1125 == nil { arg_1123 = ifn_1126.Invoke_O_O__O(arg_1127, arg_1128) } else { arg_1123 = linked_1125.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1124, arg_1127, arg_1128) }; if linked_1120 == nil { return ifn_1121.Invoke_O_O__O(arg_1122, arg_1123) } else { return linked_1120.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1119, arg_1122, arg_1123) } }
//line :231:1
func A_arbace_go_embed_sha256_hex_fn__1220000122_A_New() *A_arbace_go_embed_sha256_hex_fn__1220000122_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_sha256_hex_fn__1220000122_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_go_embed_sha256_hex_fn__1220000122_A) Ctor() {}
//line :231:1
func (t *A_arbace_go_embed_sha256_hex_fn__1220000122_A) Invoke_O_O__O(self, p1__1220000121_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_embed_A_const_108.GetRawRoot__O()); var tmp2 int64; var na_1134 any = p1__1220000121_SHARP___1; var na_1135 int64 = 255; if jrt.Long_InstanceOf(na_1134) { var n0_1136 int64 = jrt.NN(jrt.Long_Cast(na_1134)).LongValue__J(); var n1_1137 int64 = na_1135; tmp2 = n0_1136 & n1_1137 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1134, na_1135) }; return tmp1.Invoke_O_O__O(Lit_74, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_go_embed_files_A_New() *A_arbace_go_embed_files_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_go_embed_files_A) Ctor() {}
//line :233:1
func (t *A_arbace_go_embed_files_A) Invoke_O_O_O_O_O_O__O(self, dir__0, patterns__1, kind__2, hashes__3, type_text__4 any) any { var names__6 any; var root_1141 any = A_arbace_go_embed_A_const_100.GetRawRoot__O(); var linked_1142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1141, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1143 lang.IFn; if





	linked_1142 == nil { ifn_1143 = lang.IFn_Cast(root_1141) } else { ifn_1143 = nil }; var arg_1144 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_embed_A_const_109.GetRawRoot__O()); var tmp2 *lang.Compiler_AOTFn; var fnbody__1156 any = A_arbace_go_embed_files_fn__1220000128_A_New_O(dir__0); var tmp3 *jrt.Class; var fncls__1155 *jrt.Class = A_arbace_go_embed_files_fn__1220000128_A_fn_class; if fncls__1155 == nil { var fncls__1155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__1156); A_arbace_go_embed_files_fn__1220000128_A_fn_class = fncls__1155d; tmp3 = fncls__1155d } else { tmp3 = fncls__1155 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1156, tmp3, nil); arg_1144 = tmp1.Invoke_O_O__O(tmp2.Ref(), patterns__1); if linked_1142 == nil { names__6 = ifn_1143.Invoke_O__O(arg_1144) } else { names__6 = linked_1142.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1141, arg_1144) }; var names__7 any; if
	lang.Util_Equiv_O_O__Z_NoInit(kind__2, A_arbace_go_embed_A_const_111) {
		var root_1157 any = A_arbace_go_embed_A_const_100.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any; var root_1161 any = A_arbace_go_embed_A_const_91.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1161, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = names__6; var arg_1165 any; var iter__1927001039__auto____7 any; var fnbody__1287 any = A_arbace_go_embed_files_iter__1220000130__1220000136_A_New(); var tmp4 *jrt.Class; var fncls__1286 *jrt.Class = A_arbace_go_embed_files_iter__1220000130__1220000136_A_fn_class; if fncls__1286 == nil { var fncls__1286d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, nil); A_arbace_go_embed_files_iter__1220000130__1220000136_A_fn_class = fncls__1286d; tmp4 = fncls__1286d } else { tmp4 = fncls__1286 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1287, tmp4, nil); arg_1165 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(names__6); if linked_1162 == nil { arg_1160 = ifn_1163.Invoke_O_O__O(arg_1164, arg_1165) } else { arg_1160 = linked_1162.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1161, arg_1164, arg_1165) }; if linked_1158 == nil { names__7 = ifn_1159.Invoke_O__O(arg_1160) } else { names__7 = linked_1158.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1157, arg_1160) } } else {
//line :240:1
			names__7 = names__6 }; var names__8 any; var root_1288 any = /*line :233:1*/A_arbace_go_embed_A_const_99.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1288, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1290 lang.IFn; if











	linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any; var root_1293 any = A_arbace_go_embed_A_const_114.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_comparator_A_fn_class); var ifn_1295 lang.IFn; if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = A_arbace_go_embed_A_const_115.GetRawRoot__O(); if linked_1294 == nil { arg_1291 = ifn_1295.Invoke_O__O(arg_1296) } else { arg_1291 = linked_1294.(*aot_arbace_core.A_arbace_core_comparator_A).Invoke_O_O__O(root_1293, arg_1296) }; var arg_1292 any = names__7; if linked_1289 == nil { names__8 = ifn_1290.Invoke_O_O__O(arg_1291, arg_1292) } else { names__8 = linked_1289.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O_O__O(root_1288, arg_1291, arg_1292) }; var tmp5 any; var and__1927000168__auto____9 any; var root_1417 any =
	A_arbace_go_embed_A_const_13.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any = kind__2; var arg_1421 any = A_arbace_go_embed_A_const_111; if linked_1418 == nil { and__1927000168__auto____9 = ifn_1419.Invoke_O_O__O(arg_1420, arg_1421) } else { and__1927000168__auto____9 = linked_1418.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1417, arg_1420, arg_1421) }; if jrt.J2g_Truth(and__1927000168__auto____9) { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(names__8)), 1)).Ref() } else { tmp5 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp5) { var tmp6 any; var root_1422 any = A_arbace_go_embed_A_const_93.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1424 lang.IFn
		if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, type_text__4)).Ref(); var arg_1426 any = A_arbace_go_embed_A_const_119; if linked_1423 == nil { tmp6 = ifn_1424.Invoke_O_O__O(arg_1425, arg_1426) } else { tmp6 = linked_1423.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1422, arg_1425, arg_1426) }
//line :246:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp6))) }; var root_1297 any =

	A_arbace_go_embed_A_const_78.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1297, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1299 lang.IFn; if linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any; var iter__1927001039__auto____9 any; var fnbody__1416 any = A_arbace_go_embed_files_iter__1220000150__1220000154_A_New_O_O(dir__0, hashes__3); var tmp7 *jrt.Class; var fncls__1415 *jrt.Class = A_arbace_go_embed_files_iter__1220000150__1220000154_A_fn_class; if fncls__1415 == nil { var fncls__1415d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, fnbody__1416); A_arbace_go_embed_files_iter__1220000150__1220000154_A_fn_class = fncls__1415d; tmp7 = fncls__1415d } else { tmp7 = fncls__1415 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1416, tmp7, nil); arg_1300 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(names__8); if linked_1298 == nil { return ifn_1299.Invoke_O__O(arg_1300) } else { return linked_1298.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1297, arg_1300) } }
//line :239:1
func A_arbace_go_embed_files_fn__1220000128_A_New_O(p0 any) *A_arbace_go_embed_files_fn__1220000128_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_fn__1220000128_A{}; t.Ctor_O(p0); return t }
//line :239:1
func (t *A_arbace_go_embed_files_fn__1220000128_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :239:1
func (t *A_arbace_go_embed_files_fn__1220000128_A) Invoke_O_O__O(self, p1__1220000125_SHARP___1 any) any { var root_1150 any = A_arbace_go_embed_A_const_110.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, A_arbace_go_embed_resolve_pattern_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any = t.F_dir; var arg_1154 any = p1__1220000125_SHARP___1; if linked_1151 == nil { return ifn_1152.Invoke_O_O__O(arg_1153, arg_1154) } else { return linked_1151.(*A_arbace_go_embed_resolve_pattern_A).Invoke_O_O_O__O(root_1150, arg_1153, arg_1154) } }

func A_arbace_go_embed_files_iter__1220000130__1220000136_A_New() *A_arbace_go_embed_files_iter__1220000130__1220000136_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000130__1220000136_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_A) Ctor() {}
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_A) Invoke_O_O__O(self, s__1220000131__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1285 any = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A_New_O_O(s__1220000131__1, self); var tmp2 *jrt.Class; var fncls__1284 *jrt.Class = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A_fn_class; if fncls__1284 == nil { var fncls__1284d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__1285); A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A_fn_class = fncls__1284d; tmp2 = fncls__1284d } else { tmp2 = fncls__1284 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1285, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :241:1
func A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A_New_O_O(p0, p1 any) *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A{}; t.Ctor_O_O(p0, p1); return t }
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A) Ctor_O_O(c__s__1220000131, c__iter__1220000130 any) { t.F_s__1220000131 = c__s__1220000131; t.F_iter__1220000130 = c__iter__1220000130 }
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A) Invoke_O__O(self any) any { { var s__1220000131__1 any; var t_ any = t.F_s__1220000131; t.F_s__1220000131 = nil; s__1220000131__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1166 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = s__1220000131__1; if linked_1167 == nil { temp__1927000414__auto____2 = ifn_1168.Invoke_O__O(arg_1169) } else { temp__1927000414__auto____2 = linked_1167.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1166, arg_1169) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_1170 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1172 lang.IFn; if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any = xs__1927001018__auto____3; if linked_1171 == nil { n__4 = ifn_1172.Invoke_O__O(arg_1173) } else { n__4 = linked_1171.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1170, arg_1173) }; var iterys__1927001035__auto____5 any; var fnbody__1235 any = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A_New(); var tmp1 *jrt.Class; var fncls__1234 *jrt.Class = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A_fn_class; if fncls__1234 == nil { var fncls__1234d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, nil); A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A_fn_class = fncls__1234d; tmp1 = fncls__1234d } else { tmp1 = fncls__1234 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1235, tmp1, nil); var fs__1927001036__auto____6 any; var root_1236 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_1240 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1242 lang.IFn
														if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any; var root_1244 any = A_arbace_go_embed_A_const_112.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1246 lang.IFn; if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any; var fnbody__1255 any = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A_New(); var tmp4 *jrt.Class; var fncls__1254 *jrt.Class = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A_fn_class; if fncls__1254 == nil { var fncls__1254d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, nil); A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A_fn_class = fncls__1254d; tmp4 = fncls__1254d } else { tmp4 = fncls__1254 }; arg_1247 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1255, tmp4, nil); var arg_1248 any; var root_1256 any = A_arbace_go_embed_A_const_113.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_1258 lang.IFn; if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any; var fnbody__1270 any = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A_New(); var tmp5 *jrt.Class; var fncls__1269 *jrt.Class = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A_fn_class; if fncls__1269 == nil { var fncls__1269d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, nil); A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A_fn_class = fncls__1269d; tmp5 = fncls__1269d } else { tmp5 = fncls__1269 }; arg_1259 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1270, tmp5, nil); var arg_1260 any = n__4; if linked_1257 == nil { arg_1248 = ifn_1258.Invoke_O_O__O(arg_1259, arg_1260) } else { arg_1248 = linked_1257.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_1256, arg_1259, arg_1260) }; if linked_1245 == nil { arg_1243 = ifn_1246.Invoke_O_O__O(arg_1247, arg_1248) } else { arg_1243 = linked_1245.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1244, arg_1247, arg_1248) }; if linked_1241 == nil { tmp3 = ifn_1242.Invoke_O__O(arg_1243) } else { tmp3 = linked_1241.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1240, arg_1243) }
//line :241:1
	arg_1239 = tmp2.Invoke_O__O(tmp3); if linked_1237 == nil { fs__1927001036__auto____6 = ifn_1238.Invoke_O__O(arg_1239) } else { fs__1927001036__auto____6 = linked_1237.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1236, arg_1239) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1271 any = A_arbace_go_embed_A_const_91.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = fs__1927001036__auto____6; var arg_1275 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1220000130); var tmp7 any; var root_1276 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_1277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1276, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1278 lang.IFn; if linked_1277 == nil { ifn_1278 = lang.IFn_Cast(root_1276) } else { ifn_1278 = nil }; var arg_1279 any = s__1220000131__1; if linked_1277 == nil { tmp7 = ifn_1278.Invoke_O__O(arg_1279) } else { tmp7 = linked_1277.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1276, arg_1279) }; arg_1275 = tmp6.Invoke_O__O(tmp7); if linked_1272 == nil { return ifn_1273.Invoke_O_O__O(arg_1274, arg_1275) } else { return linked_1272.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1271, arg_1274, arg_1275) } } else { var tmp8 any; var root_1280 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any = s__1220000131__1; if linked_1281 == nil { tmp8 = ifn_1282.Invoke_O__O(arg_1283) } else { tmp8 = linked_1281.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1280, arg_1283) }; s__1220000131__1 = tmp8; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :241:1
func A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A_New() *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A) Ctor() {}
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A) Invoke_O_O__O(self, s__1220000133__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1233 any = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A_New_O_O(s__1220000133__1, self); var tmp2 *jrt.Class; var fncls__1232 *jrt.Class = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A_fn_class; if fncls__1232 == nil { var fncls__1232d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__1233); A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A_fn_class = fncls__1232d; tmp2 = fncls__1232d } else { tmp2 = fncls__1232 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1233, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :241:1
func A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A_New_O_O(p0, p1 any) *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A{}; t.Ctor_O_O(p0, p1); return t }
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A) Ctor_O_O(c__s__1220000133, c__iter__1220000132 any) { t.F_s__1220000133 = c__s__1220000133; t.F_iter__1220000132 = c__iter__1220000132 }
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A) Invoke_O__O(self any) any { { var s__1220000133__1 any; var t_ any = t.F_s__1220000133; t.F_s__1220000133 = nil; s__1220000133__1 = t_; for { var temp__1927000414__auto____2 any; var root_1174 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1176 lang.IFn; if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any = s__1220000133__1; if linked_1175 == nil { temp__1927000414__auto____2 = ifn_1176.Invoke_O__O(arg_1177) } else { temp__1927000414__auto____2 = linked_1175.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1174, arg_1177) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1220000133__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1178 any = A_arbace_go_embed_A_const_79.GetRawRoot__O(); var linked_1179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1178, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1180 lang.IFn; if linked_1179 == nil { ifn_1180 = lang.IFn_Cast(root_1178) } else { ifn_1180 = nil }; var arg_1181 any = s__1220000133__3; if linked_1179 == nil { tmp1 = ifn_1180.Invoke_O__O(arg_1181) } else { tmp1 = linked_1179.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1178, arg_1181) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1182 any = A_arbace_go_embed_A_const_80.GetRawRoot__O(); var linked_1183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1182, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1184 lang.IFn; if linked_1183 == nil { ifn_1184 = lang.IFn_Cast(root_1182) } else { ifn_1184 = nil }; var arg_1185 any = s__1220000133__3; if linked_1183 == nil { c__1927001037__auto____4 = ifn_1184.Invoke_O__O(arg_1185) } else { c__1927001037__auto____4 = linked_1183.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1182, arg_1185) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1220000135__6 any; var root_1186 any = A_arbace_go_embed_A_const_81.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1188 lang.IFn; if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1187 == nil { b__1220000135__6 = ifn_1188.Invoke_O__O(arg_1189) } else { b__1220000135__6 = linked_1187.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1186, arg_1189) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1196 any = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A_New_I_O_O(size__1927001038__auto____5, b__1220000135__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1195 *jrt.Class = A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A_fn_class; if fncls__1195 == nil { var fncls__1195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, fnbody__1196); A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A_fn_class = fncls__1195d; tmp3 = fncls__1195d } else { tmp3 = fncls__1195 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1196, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1197 any = A_arbace_go_embed_A_const_83.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1199 lang.IFn; if linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any; var root_1202 any = A_arbace_go_embed_A_const_84.GetRawRoot__O(); var linked_1203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1202, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1204 lang.IFn; if linked_1203 == nil { ifn_1204 = lang.IFn_Cast(root_1202) } else { ifn_1204 = nil }; var arg_1205 any = b__1220000135__6; if linked_1203 == nil { arg_1200 = ifn_1204.Invoke_O__O(arg_1205) } else { arg_1200 = linked_1203.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1202, arg_1205) }; var arg_1201 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1220000132); var tmp5 any; var root_1206 any = A_arbace_go_embed_A_const_85.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1208 lang.IFn; if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any = s__1220000133__3; if linked_1207 == nil { tmp5 = ifn_1208.Invoke_O__O(arg_1209) } else { tmp5 = linked_1207.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1206, arg_1209) }; arg_1201 = tmp4.Invoke_O__O(tmp5); if linked_1198 == nil { return ifn_1199.Invoke_O_O__O(arg_1200, arg_1201) } else { return linked_1198.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1197, arg_1200, arg_1201) } } else { var root_1210 any = A_arbace_go_embed_A_const_83.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any; var root_1215 any = A_arbace_go_embed_A_const_84.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any = b__1220000135__6; if linked_1216 == nil { arg_1213 = ifn_1217.Invoke_O__O(arg_1218) } else { arg_1213 = linked_1216.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1215, arg_1218) }; var arg_1214 any; if linked_1211 == nil { return ifn_1212.Invoke_O_O__O(arg_1213, arg_1214) } else { return linked_1211.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1210, arg_1213, arg_1214) } } } else { var d__4 any; var root_1219 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = s__1220000133__3; if linked_1220 == nil { d__4 = ifn_1221.Invoke_O__O(arg_1222) } else { d__4 = linked_1220.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1219, arg_1222) }; var root_1223 any = A_arbace_go_embed_A_const_86.GetRawRoot__O(); var linked_1224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1223, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1225 lang.IFn; if linked_1224 == nil { ifn_1225 = lang.IFn_Cast(root_1223) } else { ifn_1225 = nil }; var arg_1226 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26), jrt.RefArrayOf(jrt.Object_class, d__4, nil)).Ref(); var arg_1227 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1220000132); var tmp7 any; var root_1228 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_1229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1228, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1230 lang.IFn; if linked_1229 == nil { ifn_1230 = lang.IFn_Cast(root_1228) } else { ifn_1230 = nil }; var arg_1231 any = s__1220000133__3; if linked_1229 == nil { tmp7 = ifn_1230.Invoke_O__O(arg_1231) } else { tmp7 = linked_1229.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1228, arg_1231) }; arg_1227 = tmp6.Invoke_O__O(tmp7); if linked_1224 == nil { return ifn_1225.Invoke_O_O__O(arg_1226, arg_1227) } else { return linked_1224.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1223, arg_1226, arg_1227) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :241:1
func A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1220000135, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1220000135 = c__b__1220000135; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :241:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A) Invoke_O__O(self any) any { { var i__1220000134__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1220000134__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1220000134__1)); var root_1190 any = A_arbace_go_embed_A_const_82.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = t.F_b__1220000135; var arg_1194 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26), jrt.RefArrayOf(jrt.Object_class, d__2, nil)).Ref(); if linked_1191 == nil { ifn_1192.Invoke_O_O__O(arg_1193, arg_1194) } else { linked_1191.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1190, arg_1193, arg_1194) }; i__1220000134__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1220000134__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A_New() *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A) Ctor() {}
//line :242:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A) Invoke_O_O__O(self, p1__1220000126_SHARP___1 any) any { var root_1249 any = A_arbace_go_embed_A_const_13.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1249, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1251 lang.IFn; if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any = Lit_2; var arg_1253 any = p1__1220000126_SHARP___1; if linked_1250 == nil { return ifn_1251.Invoke_O_O__O(arg_1252, arg_1253) } else { return linked_1250.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1249, arg_1252, arg_1253) } }
//line :242:1
func A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A_New() *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A) Ctor() {}
//line :242:1
func (t *A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A) Invoke_O_O__O(self, p1__1220000127_SHARP___1 any) any { var root_1261 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1263 lang.IFn; if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any; var root_1265 any = A_arbace_go_embed_A_const_106.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, A_arbace_go_embed_name_split_A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = p1__1220000127_SHARP___1; if linked_1266 == nil { arg_1264 = ifn_1267.Invoke_O__O(arg_1268) } else { arg_1264 = linked_1266.(*A_arbace_go_embed_name_split_A).Invoke_O_O__O(root_1265, arg_1268) }; if linked_1262 == nil { return ifn_1263.Invoke_O__O(arg_1264) } else { return linked_1262.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1261, arg_1264) } }





func A_arbace_go_embed_files_iter__1220000150__1220000154_A_New_O_O(p0, p1 any) *A_arbace_go_embed_files_iter__1220000150__1220000154_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000150__1220000154_A{}; t.Ctor_O_O(p0, p1); return t }
//line :248:1
func (t *A_arbace_go_embed_files_iter__1220000150__1220000154_A) Ctor_O_O(c__dir, c__hashes any) { t.F_dir = c__dir; t.F_hashes = c__hashes }
//line :248:1
func (t *A_arbace_go_embed_files_iter__1220000150__1220000154_A) Invoke_O_O__O(self, s__1220000151__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1414 any = A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A_New_O_O_O_O(t.F_dir, s__1220000151__1, self, t.F_hashes); var tmp2 *jrt.Class; var fncls__1413 *jrt.Class = A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A_fn_class; if fncls__1413 == nil { var fncls__1413d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__1414); A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A_fn_class = fncls__1413d; tmp2 = fncls__1413d } else { tmp2 = fncls__1413 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1414, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :248:1
func A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :248:1
func (t *A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A) Ctor_O_O_O_O(c__dir, c__s__1220000151, c__iter__1220000150, c__hashes any) { t.F_dir = c__dir; t.F_s__1220000151 = c__s__1220000151; t.F_iter__1220000150 = c__iter__1220000150; t.F_hashes = c__hashes }
//line :248:1
func (t *A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A) Invoke_O__O(self any) any { { var s__1220000151__1 any; var t_ any = t.F_s__1220000151; t.F_s__1220000151 = nil; s__1220000151__1 = t_; for { var temp__1927000414__auto____2 any; var root_1301 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = s__1220000151__1; if linked_1302 == nil { temp__1927000414__auto____2 = ifn_1303.Invoke_O__O(arg_1304) } else { temp__1927000414__auto____2 = linked_1302.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1301, arg_1304) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1220000151__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1305 any = A_arbace_go_embed_A_const_79.GetRawRoot__O(); var linked_1306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1305, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1307 lang.IFn; if linked_1306 == nil { ifn_1307 = lang.IFn_Cast(root_1305) } else { ifn_1307 = nil }; var arg_1308 any = s__1220000151__3; if linked_1306 == nil { tmp1 = ifn_1307.Invoke_O__O(arg_1308) } else { tmp1 = linked_1306.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1305, arg_1308) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1309 any = A_arbace_go_embed_A_const_80.GetRawRoot__O(); var linked_1310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1309, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1311 lang.IFn; if linked_1310 == nil { ifn_1311 = lang.IFn_Cast(root_1309) } else { ifn_1311 = nil }; var arg_1312 any = s__1220000151__3; if linked_1310 == nil { c__1927001037__auto____4 = ifn_1311.Invoke_O__O(arg_1312) } else { c__1927001037__auto____4 = linked_1310.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1309, arg_1312) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1220000153__6 any; var root_1313 any = A_arbace_go_embed_A_const_81.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1313, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1315 lang.IFn; if linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1314 == nil { b__1220000153__6 = ifn_1315.Invoke_O__O(arg_1316) } else { b__1220000153__6 = linked_1314.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1313, arg_1316) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1350 any = A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A_New_O_O_O_I_O(t.F_dir, t.F_hashes, b__1220000153__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1349 *jrt.Class = A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A_fn_class; if fncls__1349 == nil { var fncls__1349d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, fnbody__1350); A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A_fn_class = fncls__1349d; tmp3 = fncls__1349d } else { tmp3 = fncls__1349 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1350, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1351 any = A_arbace_go_embed_A_const_83.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1351, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1353 lang.IFn; if linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any; var root_1356 any = A_arbace_go_embed_A_const_84.GetRawRoot__O(); var linked_1357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1356, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1358 lang.IFn; if linked_1357 == nil { ifn_1358 = lang.IFn_Cast(root_1356) } else { ifn_1358 = nil }; var arg_1359 any = b__1220000153__6; if linked_1357 == nil { arg_1354 = ifn_1358.Invoke_O__O(arg_1359) } else { arg_1354 = linked_1357.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1356, arg_1359) }; var arg_1355 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1220000150); var tmp5 any; var root_1360 any = A_arbace_go_embed_A_const_85.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1360, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1362 lang.IFn; if linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; var arg_1363 any = s__1220000151__3; if linked_1361 == nil { tmp5 = ifn_1362.Invoke_O__O(arg_1363) } else { tmp5 = linked_1361.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1360, arg_1363) }; arg_1355 = tmp4.Invoke_O__O(tmp5); if linked_1352 == nil { return ifn_1353.Invoke_O_O__O(arg_1354, arg_1355) } else { return linked_1352.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1351, arg_1354, arg_1355) } } else { var root_1364 any = A_arbace_go_embed_A_const_83.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any; var root_1369 any = A_arbace_go_embed_A_const_84.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1371 lang.IFn; if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var arg_1372 any = b__1220000153__6; if linked_1370 == nil { arg_1367 = ifn_1371.Invoke_O__O(arg_1372) } else { arg_1367 = linked_1370.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1369, arg_1372) }; var arg_1368 any; if linked_1365 == nil { return ifn_1366.Invoke_O_O__O(arg_1367, arg_1368) } else { return linked_1365.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1364, arg_1367, arg_1368) } } } else { var n__4 any; var root_1373 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any = s__1220000151__3; if linked_1374 == nil { n__4 = ifn_1375.Invoke_O__O(arg_1376) } else { n__4 = linked_1374.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1373, arg_1376) }; var root_1377 any = A_arbace_go_embed_A_const_86.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any; var tmp6 any; var root_1382 any = A_arbace_go_embed_A_const_69.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1384 lang.IFn
														if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = n__4; var arg_1386 any = Lit_26; if linked_1383 == nil { tmp6 = ifn_1384.Invoke_O_O__O(arg_1385, arg_1386) } else { tmp6 = linked_1383.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1382, arg_1385, arg_1386) }; if jrt.J2g_Truth(tmp6) { arg_1380 = lang.Tuple_Create_O_O__IPersistentVector(n__4, nil) } else { var tmp7 jrt.File_I = jrt.File_Cast(t.F_dir); var bs__5 any = jrt.Files_ReadAllBytes_Path__B1(jrt.File_New_File_String(tmp7, jrt.String_Cast(n__4)).ToPath__Path()).Ref(); var h__6 any = lang.RT_Get_O_O__O_NoInit(t.F_hashes, n__4); var tmp8 any
															var and__1927000168__auto____7 any = h__6


		if jrt.J2g_Truth(and__1927000168__auto____7) { var root_1387 any = A_arbace_go_embed_A_const_13.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any; var root_1392 any = A_arbace_go_embed_A_const_116.GetRawRoot__O(); var linked_1393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1392, A_arbace_go_embed_sha256_hex_A_fn_class); var ifn_1394 lang.IFn; if linked_1393 == nil { ifn_1394 = lang.IFn_Cast(root_1392) } else { ifn_1394 = nil }; var arg_1395 any = bs__5; if linked_1393 == nil { arg_1390 = ifn_1394.Invoke_O__O(arg_1395) } else { arg_1390 = linked_1393.(*A_arbace_go_embed_sha256_hex_A).Invoke_O_O__O(root_1392, arg_1395) }; var arg_1391 any; var root_1396 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1396, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = h__6; if linked_1397 == nil { arg_1391 = ifn_1398.Invoke_O__O(arg_1399) } else { arg_1391 = linked_1397.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1396, arg_1399) }; if linked_1388 == nil { tmp8 = ifn_1389.Invoke_O_O__O(arg_1390, arg_1391) } else { tmp8 = linked_1388.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1387, arg_1390, arg_1391) } } else { tmp8 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_1400 any = A_arbace_go_embed_A_const_93.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1402 lang.IFn
			if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_29, nil, Lit_30, nil, Lit_31, nil); var tmp11 any; var root_1405 any = A_arbace_go_embed_A_const_116.GetRawRoot__O(); var linked_1406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1405, A_arbace_go_embed_sha256_hex_A_fn_class); var ifn_1407 lang.IFn; if linked_1406 == nil { ifn_1407 = lang.IFn_Cast(root_1405) } else { ifn_1407 = nil }; var arg_1408 any = bs__5; if linked_1406 == nil { tmp11 = ifn_1407.Invoke_O__O(arg_1408) } else { tmp11 = linked_1406.(*A_arbace_go_embed_sha256_hex_A).Invoke_O_O__O(root_1405, arg_1408) }; arg_1403 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, n__4, nil, tmp11, nil, h__6)).Ref(); var arg_1404 any = A_arbace_go_embed_A_const_118; if linked_1401 == nil { tmp9 = ifn_1402.Invoke_O_O__O(arg_1403, arg_1404) } else { tmp9 = linked_1401.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1400, arg_1403, arg_1404) }
//line :253:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp9))) }
//line :249:1
		arg_1380 = lang.Tuple_Create_O_O__IPersistentVector(n__4, bs__5) }
//line :248:1
	var arg_1381 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1220000150); var tmp13 any; var root_1409 any = A_arbace_go_embed_A_const_87.GetRawRoot__O(); var linked_1410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1409, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1411 lang.IFn; if linked_1410 == nil { ifn_1411 = lang.IFn_Cast(root_1409) } else { ifn_1411 = nil }; var arg_1412 any = s__1220000151__3; if linked_1410 == nil { tmp13 = ifn_1411.Invoke_O__O(arg_1412) } else { tmp13 = linked_1410.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1409, arg_1412) }; arg_1381 = tmp12.Invoke_O__O(tmp13); if linked_1378 == nil { return ifn_1379.Invoke_O_O__O(arg_1380, arg_1381) } else { return linked_1378.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1377, arg_1380, arg_1381) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :248:1
func A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :248:1
func (t *A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A) Ctor_O_O_O_I_O(c__dir, c__hashes, c__b__1220000153 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_dir = c__dir; t.F_hashes = c__hashes; t.F_b__1220000153 = c__b__1220000153; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :248:1
func (t *A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A) Invoke_O__O(self any) any { { var i__1220000152__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1220000152__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1220000152__1)); var root_1317 any = A_arbace_go_embed_A_const_82.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1317, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1319 lang.IFn; if linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any = t.F_b__1220000153; var arg_1321 any; var tmp2 any; var root_1322 any = A_arbace_go_embed_A_const_69.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1322, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1324 lang.IFn
																if linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any = n__2; var arg_1326 any = Lit_26; if linked_1323 == nil { tmp2 = ifn_1324.Invoke_O_O__O(arg_1325, arg_1326) } else { tmp2 = linked_1323.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1322, arg_1325, arg_1326) }; if jrt.J2g_Truth(tmp2) { arg_1321 = lang.Tuple_Create_O_O__IPersistentVector(n__2, nil) } else { var tmp3 jrt.File_I = jrt.File_Cast(t.F_dir); var bs__3 any = jrt.Files_ReadAllBytes_Path__B1(jrt.File_New_File_String(tmp3, jrt.String_Cast(n__2)).ToPath__Path()).Ref(); var h__4 any = lang.RT_Get_O_O__O_NoInit(t.F_hashes, n__2); var tmp4 any
																	var and__1927000168__auto____5 any = h__4


		if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1327 any = A_arbace_go_embed_A_const_13.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1327, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1329 lang.IFn; if linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; var arg_1330 any; var root_1332 any = A_arbace_go_embed_A_const_116.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, A_arbace_go_embed_sha256_hex_A_fn_class); var ifn_1334 lang.IFn; if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any = bs__3; if linked_1333 == nil { arg_1330 = ifn_1334.Invoke_O__O(arg_1335) } else { arg_1330 = linked_1333.(*A_arbace_go_embed_sha256_hex_A).Invoke_O_O__O(root_1332, arg_1335) }; var arg_1331 any; var root_1336 any = A_arbace_go_embed_A_const_11.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1336, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1338 lang.IFn; if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any = h__4; if linked_1337 == nil { arg_1331 = ifn_1338.Invoke_O__O(arg_1339) } else { arg_1331 = linked_1337.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1336, arg_1339) }; if linked_1328 == nil { tmp4 = ifn_1329.Invoke_O_O__O(arg_1330, arg_1331) } else { tmp4 = linked_1328.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1327, arg_1330, arg_1331) } } else { tmp4 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_1340 any = A_arbace_go_embed_A_const_93.GetRawRoot__O(); var linked_1341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1340, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1342 lang.IFn
			if linked_1341 == nil { ifn_1342 = lang.IFn_Cast(root_1340) } else { ifn_1342 = nil }; var arg_1343 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_29, nil, Lit_30, nil, Lit_31, nil); var tmp7 any; var root_1345 any = A_arbace_go_embed_A_const_116.GetRawRoot__O(); var linked_1346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1345, A_arbace_go_embed_sha256_hex_A_fn_class); var ifn_1347 lang.IFn; if linked_1346 == nil { ifn_1347 = lang.IFn_Cast(root_1345) } else { ifn_1347 = nil }; var arg_1348 any = bs__3; if linked_1346 == nil { tmp7 = ifn_1347.Invoke_O__O(arg_1348) } else { tmp7 = linked_1346.(*A_arbace_go_embed_sha256_hex_A).Invoke_O_O__O(root_1345, arg_1348) }; arg_1343 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, n__2, nil, tmp7, nil, h__4)).Ref(); var arg_1344 any = A_arbace_go_embed_A_const_117; if linked_1341 == nil { tmp5 = ifn_1342.Invoke_O_O__O(arg_1343, arg_1344) } else { tmp5 = linked_1341.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1340, arg_1343, arg_1344) }
//line :253:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp5))) }
//line :249:1
		arg_1321 = lang.Tuple_Create_O_O__IPersistentVector(n__2, bs__3) }
//line :248:1
	if linked_1318 == nil { ifn_1319.Invoke_O_O__O(arg_1320, arg_1321) } else { linked_1318.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1317, arg_1320, arg_1321) }; i__1220000152__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1220000152__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_go_embed_check_decl_A_New() *A_arbace_go_embed_check_decl_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_check_decl_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_go_embed_check_decl_A) Ctor() {}
//line :257:1
func (t *A_arbace_go_embed_check_decl_A) Invoke_O_O__O(self, p__1220000161__0 any) any { var map__1220000162__2 any = p__1220000161__0; var map__1220000162__3 any; if lang.ISeq_InstanceOf(map__1220000162__2) { var tmp1 any; var root_1427 any = A_arbace_go_embed_A_const_104.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1429 lang.IFn; if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = map__1220000162__2; if linked_1428 == nil { tmp1 = ifn_1429.Invoke_O__O(arg_1430) } else { tmp1 = linked_1428.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1427, arg_1430) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1431 any = A_arbace_go_embed_A_const_120.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any = map__1220000162__2; if linked_1432 == nil { tmp2 = ifn_1433.Invoke_O__O(arg_1434) } else { tmp2 = linked_1432.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1431, arg_1434) }; map__1220000162__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1435 any = A_arbace_go_embed_A_const_71.GetRawRoot__O(); var linked_1436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1435, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1437 lang.IFn; if linked_1436 == nil { ifn_1437 = lang.IFn_Cast(root_1435) } else { ifn_1437 = nil }; var arg_1438 any = map__1220000162__2; if linked_1436 == nil { tmp3 = ifn_1437.Invoke_O__O(arg_1438) } else { tmp3 = linked_1436.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1435, arg_1438) }; if jrt.J2g_Truth(tmp3) { var root_1439 any = A_arbace_go_embed_A_const_66.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1441 lang.IFn; if linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any = map__1220000162__2; if linked_1440 == nil { map__1220000162__3 = ifn_1441.Invoke_O__O(arg_1442) } else { map__1220000162__3 = linked_1440.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1439, arg_1442) } } else { map__1220000162__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1220000162__3 = map__1220000162__2 }; var embed_imported_QMARK___4 any = lang.RT_Get_O_O__O_NoInit(map__1220000162__3, A_arbace_go_embed_A_const_121); var names__5 any = lang.RT_Get_O_O__O_NoInit(map__1220000162__3, A_arbace_go_embed_A_const_122); var init_QMARK___6 any = lang.RT_Get_O_O__O_NoInit(map__1220000162__3, A_arbace_go_embed_A_const_123); var typed_QMARK___7 any = lang.RT_Get_O_O__O_NoInit(map__1220000162__3, A_arbace_go_embed_A_const_124); var minor__8 any = lang.RT_Get_O_O__O_NoInit(map__1220000162__3, A_arbace_go_embed_A_const_125); var lang__9 any = lang.RT_Get_O_O__O_NoInit(map__1220000162__3, A_arbace_go_embed_A_const_126); var tmp4 any; var root_1443 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1445 lang.IFn; if





	linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any = embed_imported_QMARK___4; if linked_1444 == nil { tmp4 = ifn_1445.Invoke_O__O(arg_1446) } else { tmp4 = linked_1444.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1443, arg_1446) }; if /*line :262:1*/ jrt.J2g_Truth(tmp4) { return Lit_4 } else { var tmp5 bool
		var na_1447 any = names__5; var na_1448 int64 = 1
		if jrt.Long_InstanceOf(na_1447) { var n0_1449 int64 = jrt.NN(jrt.Long_Cast(na_1447)).LongValue__J(); var n1_1450 int64 = na_1448; tmp5 = n0_1449 > n1_1450 } else { tmp5 = lang.Numbers_Gt_O_J__Z_NoInit(na_1447, na_1448) }
//line :262:1
		if tmp5 { return Lit_5 } else { if jrt.J2g_Truth(init_QMARK___6) { return Lit_6 } else { var tmp6 any; var root_1452 any = A_arbace_go_embed_A_const_37.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1454 lang.IFn



			if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any = typed_QMARK___7; if linked_1453 == nil { tmp6 = ifn_1454.Invoke_O__O(arg_1455) } else { tmp6 = linked_1453.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1452, arg_1455) }
//line :262:1
			if jrt.J2g_Truth(tmp6) { return Lit_7 } else { var tmp7 any
				var and__1927000168__auto____10 any = minor__8



				if jrt.J2g_Truth(and__1927000168__auto____10) { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Lt_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(minor__8), 16)).Ref() } else { tmp7 = and__1927000168__auto____10 }
//line :262:1
				if jrt.J2g_Truth(tmp7) {




					return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_8, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, nil, lang__9, nil)).Ref() } else {
//line :262:1
						if A_arbace_go_embed_A_const_15 != nil { return nil } else { return nil } } } } } } }

























































































type A_arbace_go_embed_A struct{ jrt.Object }

var A_arbace_go_embed_A_const_pool *jrt.RefArray

var A_arbace_go_embed_A_const_0 *lang.Var

var A_arbace_go_embed_A_const_1 any

var A_arbace_go_embed_A_const_2 *lang.Var

var A_arbace_go_embed_A_const_3 any

var A_arbace_go_embed_A_const_4 *lang.Var

var A_arbace_go_embed_A_const_5 *lang.Var

var A_arbace_go_embed_A_const_6 *lang.Var

var A_arbace_go_embed_A_const_7 *lang.Var

var A_arbace_go_embed_A_const_8 any

var A_arbace_go_embed_A_const_9 *lang.Var

var A_arbace_go_embed_A_const_10 any

var A_arbace_go_embed_A_const_11 *lang.Var

var A_arbace_go_embed_A_const_12 any

var A_arbace_go_embed_A_const_13 *lang.Var

var A_arbace_go_embed_A_const_14 any

var A_arbace_go_embed_A_const_15 *lang.Keyword

var A_arbace_go_embed_A_const_16 any

var A_arbace_go_embed_A_const_17 any

var A_arbace_go_embed_A_const_18 any

var A_arbace_go_embed_A_const_19 any

var A_arbace_go_embed_A_const_20 any

var A_arbace_go_embed_A_const_21 any

var A_arbace_go_embed_A_const_22 any

var A_arbace_go_embed_A_const_23 any

var A_arbace_go_embed_A_const_24 any

var A_arbace_go_embed_A_const_25 any

var A_arbace_go_embed_A_const_26 any

var A_arbace_go_embed_A_const_27 any

var A_arbace_go_embed_A_const_28 any

var A_arbace_go_embed_A_const_29 *lang.Var

var A_arbace_go_embed_A_const_30 *lang.Var

var A_arbace_go_embed_A_const_31 any

var A_arbace_go_embed_A_const_32 any

var A_arbace_go_embed_A_const_33 *lang.Var

var A_arbace_go_embed_A_const_34 *lang.Var

var A_arbace_go_embed_A_const_35 *lang.Var

var A_arbace_go_embed_A_const_36 *lang.Var

var A_arbace_go_embed_A_const_37 *lang.Var

var A_arbace_go_embed_A_const_38 *lang.Var

var A_arbace_go_embed_A_const_39 *lang.Var

var A_arbace_go_embed_A_const_40 *lang.Var

var A_arbace_go_embed_A_const_41 *lang.Var

var A_arbace_go_embed_A_const_42 *lang.Var

var A_arbace_go_embed_A_const_43 any

var A_arbace_go_embed_A_const_44 *lang.Var

var A_arbace_go_embed_A_const_45 *lang.Var

var A_arbace_go_embed_A_const_46 any

var A_arbace_go_embed_A_const_47 any

var A_arbace_go_embed_A_const_48 any

var A_arbace_go_embed_A_const_49 any

var A_arbace_go_embed_A_const_50 any

var A_arbace_go_embed_A_const_51 *lang.Var

var A_arbace_go_embed_A_const_52 *lang.Var

var A_arbace_go_embed_A_const_53 *lang.Var

var A_arbace_go_embed_A_const_54 *lang.Var

var A_arbace_go_embed_A_const_55 any

var A_arbace_go_embed_A_const_56 *lang.Var

var A_arbace_go_embed_A_const_57 *lang.Var

var A_arbace_go_embed_A_const_58 any

var A_arbace_go_embed_A_const_59 *lang.Var

var A_arbace_go_embed_A_const_60 any

var A_arbace_go_embed_A_const_61 any

var A_arbace_go_embed_A_const_62 any

var A_arbace_go_embed_A_const_63 *lang.Var

var A_arbace_go_embed_A_const_64 *lang.Var

var A_arbace_go_embed_A_const_65 *lang.Var

var A_arbace_go_embed_A_const_66 *lang.Var

var A_arbace_go_embed_A_const_67 any

var A_arbace_go_embed_A_const_68 any

var A_arbace_go_embed_A_const_69 *lang.Var

var A_arbace_go_embed_A_const_70 *lang.Var

var A_arbace_go_embed_A_const_71 *lang.Var

var A_arbace_go_embed_A_const_72 any

var A_arbace_go_embed_A_const_73 *lang.Var

var A_arbace_go_embed_A_const_74 any

var A_arbace_go_embed_A_const_75 *lang.Var

var A_arbace_go_embed_A_const_76 any

var A_arbace_go_embed_A_const_77 *lang.Var

var A_arbace_go_embed_A_const_78 *lang.Var

var A_arbace_go_embed_A_const_79 *lang.Var

var A_arbace_go_embed_A_const_80 *lang.Var

var A_arbace_go_embed_A_const_81 *lang.Var

var A_arbace_go_embed_A_const_82 *lang.Var

var A_arbace_go_embed_A_const_83 *lang.Var

var A_arbace_go_embed_A_const_84 *lang.Var

var A_arbace_go_embed_A_const_85 *lang.Var

var A_arbace_go_embed_A_const_86 *lang.Var

var A_arbace_go_embed_A_const_87 *lang.Var

var A_arbace_go_embed_A_const_88 *lang.Var

var A_arbace_go_embed_A_const_89 *lang.Var

var A_arbace_go_embed_A_const_90 *lang.Var

var A_arbace_go_embed_A_const_91 *lang.Var

var A_arbace_go_embed_A_const_92 any

var A_arbace_go_embed_A_const_93 *lang.Var

var A_arbace_go_embed_A_const_94 any

var A_arbace_go_embed_A_const_95 *lang.Var

var A_arbace_go_embed_A_const_96 *lang.Var

var A_arbace_go_embed_A_const_97 *lang.Var

var A_arbace_go_embed_A_const_98 *lang.Var

var A_arbace_go_embed_A_const_99 *lang.Var

var A_arbace_go_embed_A_const_100 *lang.Var

var A_arbace_go_embed_A_const_101 any

var A_arbace_go_embed_A_const_102 any

var A_arbace_go_embed_A_const_103 *lang.Var

var A_arbace_go_embed_A_const_104 *lang.Var

var A_arbace_go_embed_A_const_105 *lang.Var

var A_arbace_go_embed_A_const_106 *lang.Var

var A_arbace_go_embed_A_const_107 *lang.Var

var A_arbace_go_embed_A_const_108 *lang.Var

var A_arbace_go_embed_A_const_109 *lang.Var

var A_arbace_go_embed_A_const_110 *lang.Var

var A_arbace_go_embed_A_const_111 *lang.Keyword

var A_arbace_go_embed_A_const_112 *lang.Var

var A_arbace_go_embed_A_const_113 *lang.Var

var A_arbace_go_embed_A_const_114 *lang.Var

var A_arbace_go_embed_A_const_115 *lang.Var

var A_arbace_go_embed_A_const_116 *lang.Var

var A_arbace_go_embed_A_const_117 any

var A_arbace_go_embed_A_const_118 any

var A_arbace_go_embed_A_const_119 any

var A_arbace_go_embed_A_const_120 *lang.Var

var A_arbace_go_embed_A_const_121 *lang.Keyword

var A_arbace_go_embed_A_const_122 *lang.Keyword

var A_arbace_go_embed_A_const_123 *lang.Keyword

var A_arbace_go_embed_A_const_124 *lang.Keyword

var A_arbace_go_embed_A_const_125 *lang.Keyword

var A_arbace_go_embed_A_const_126 *lang.Keyword

var A_arbace_go_embed_A_init jrt.ClassInit

func A_arbace_go_embed_A_Init() { if !A_arbace_go_embed_A_init.Done() { A_arbace_go_embed_A_init.Run(A_arbace_go_embed_A_clinit) } }

func A_arbace_go_embed_A_clinit() { A_arbace_go_embed_A_clinit_p0(); A_arbace_go_embed_A_clinit_p1(); A_arbace_go_embed_A_clinit_p2(); A_arbace_go_embed_A_clinit_p3(); A_arbace_go_embed_A_clinit_p4(); A_arbace_go_embed_A_clinit_p5(); A_arbace_go_embed_A_clinit_p6(); A_arbace_go_embed_A_clinit_p7(); A_arbace_go_embed_A_clinit_p8(); A_arbace_go_embed_A_clinit_p9() }

func A_arbace_go_embed_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_embed_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 141); A_arbace_go_embed_A_const_0 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[14]); A_arbace_go_embed_A_const_1 = A_arbace_go_embed_A_const_pool.A[15]; A_arbace_go_embed_A_const_2 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[16]); A_arbace_go_embed_A_const_3 = A_arbace_go_embed_A_const_pool.A[17]; A_arbace_go_embed_A_const_4 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[18]); A_arbace_go_embed_A_const_5 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[19]); A_arbace_go_embed_A_const_6 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[20]); A_arbace_go_embed_A_const_7 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[21]); A_arbace_go_embed_A_const_8 = A_arbace_go_embed_A_const_pool.A[22]; A_arbace_go_embed_A_const_9 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[23]); A_arbace_go_embed_A_const_10 = A_arbace_go_embed_A_const_pool.A[24]; A_arbace_go_embed_A_const_11 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[25]) }

func A_arbace_go_embed_A_clinit_p1() { A_arbace_go_embed_A_const_12 = A_arbace_go_embed_A_const_pool.A[26]; A_arbace_go_embed_A_const_13 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[27]); A_arbace_go_embed_A_const_14 = A_arbace_go_embed_A_const_pool.A[28]; A_arbace_go_embed_A_const_15 = lang.Keyword_Cast(A_arbace_go_embed_A_const_pool.A[29]); A_arbace_go_embed_A_const_16 = A_arbace_go_embed_A_const_pool.A[30]; A_arbace_go_embed_A_const_17 = A_arbace_go_embed_A_const_pool.A[31]; A_arbace_go_embed_A_const_18 = A_arbace_go_embed_A_const_pool.A[32]; A_arbace_go_embed_A_const_19 = A_arbace_go_embed_A_const_pool.A[33]; A_arbace_go_embed_A_const_20 = A_arbace_go_embed_A_const_pool.A[34]; A_arbace_go_embed_A_const_21 = A_arbace_go_embed_A_const_pool.A[35]; A_arbace_go_embed_A_const_22 = A_arbace_go_embed_A_const_pool.A[36]; A_arbace_go_embed_A_const_23 = A_arbace_go_embed_A_const_pool.A[37]; A_arbace_go_embed_A_const_24 = A_arbace_go_embed_A_const_pool.A[38]; A_arbace_go_embed_A_const_25 = A_arbace_go_embed_A_const_pool.A[39]; A_arbace_go_embed_A_const_26 = A_arbace_go_embed_A_const_pool.A[40] }

func A_arbace_go_embed_A_clinit_p2() { A_arbace_go_embed_A_const_27 = A_arbace_go_embed_A_const_pool.A[41]; A_arbace_go_embed_A_const_28 = A_arbace_go_embed_A_const_pool.A[42]; A_arbace_go_embed_A_const_29 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[43]); A_arbace_go_embed_A_const_30 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[44]); A_arbace_go_embed_A_const_31 = A_arbace_go_embed_A_const_pool.A[45]; A_arbace_go_embed_A_const_32 = A_arbace_go_embed_A_const_pool.A[46]; A_arbace_go_embed_A_const_33 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[47]); A_arbace_go_embed_A_const_34 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[48]); A_arbace_go_embed_A_const_35 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[49]); A_arbace_go_embed_A_const_36 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[50]); A_arbace_go_embed_A_const_37 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[51]); A_arbace_go_embed_A_const_38 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[52]); A_arbace_go_embed_A_const_39 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[53]) }

func A_arbace_go_embed_A_clinit_p3() { A_arbace_go_embed_A_const_40 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[54]); A_arbace_go_embed_A_const_41 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[55]); A_arbace_go_embed_A_const_42 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[56]); A_arbace_go_embed_A_const_43 = A_arbace_go_embed_A_const_pool.A[57]; A_arbace_go_embed_A_const_44 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[58]); A_arbace_go_embed_A_const_45 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[59]); A_arbace_go_embed_A_const_46 = A_arbace_go_embed_A_const_pool.A[60]; A_arbace_go_embed_A_const_47 = A_arbace_go_embed_A_const_pool.A[61]; A_arbace_go_embed_A_const_48 = A_arbace_go_embed_A_const_pool.A[62]; A_arbace_go_embed_A_const_49 = A_arbace_go_embed_A_const_pool.A[63]; A_arbace_go_embed_A_const_50 = A_arbace_go_embed_A_const_pool.A[64]; A_arbace_go_embed_A_const_51 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[65]); A_arbace_go_embed_A_const_52 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[66]) }

func A_arbace_go_embed_A_clinit_p4() { A_arbace_go_embed_A_const_53 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[67]); A_arbace_go_embed_A_const_54 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[68]); A_arbace_go_embed_A_const_55 = A_arbace_go_embed_A_const_pool.A[69]; A_arbace_go_embed_A_const_56 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[70]); A_arbace_go_embed_A_const_57 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[71]); A_arbace_go_embed_A_const_58 = A_arbace_go_embed_A_const_pool.A[72]; A_arbace_go_embed_A_const_59 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[73]); A_arbace_go_embed_A_const_60 = A_arbace_go_embed_A_const_pool.A[74]; A_arbace_go_embed_A_const_61 = A_arbace_go_embed_A_const_pool.A[75]; A_arbace_go_embed_A_const_62 = A_arbace_go_embed_A_const_pool.A[76]; A_arbace_go_embed_A_const_63 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[77]); A_arbace_go_embed_A_const_64 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[78]); A_arbace_go_embed_A_const_65 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[79]) }

func A_arbace_go_embed_A_clinit_p5() { A_arbace_go_embed_A_const_66 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[80]); A_arbace_go_embed_A_const_67 = A_arbace_go_embed_A_const_pool.A[81]; A_arbace_go_embed_A_const_68 = A_arbace_go_embed_A_const_pool.A[82]; A_arbace_go_embed_A_const_69 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[83]); A_arbace_go_embed_A_const_70 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[84]); A_arbace_go_embed_A_const_71 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[85]); A_arbace_go_embed_A_const_72 = A_arbace_go_embed_A_const_pool.A[86]; A_arbace_go_embed_A_const_73 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[87]); A_arbace_go_embed_A_const_74 = A_arbace_go_embed_A_const_pool.A[88]; A_arbace_go_embed_A_const_75 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[89]); A_arbace_go_embed_A_const_76 = A_arbace_go_embed_A_const_pool.A[90]; A_arbace_go_embed_A_const_77 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[91]); A_arbace_go_embed_A_const_78 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[92]) }

func A_arbace_go_embed_A_clinit_p6() { A_arbace_go_embed_A_const_79 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[93]); A_arbace_go_embed_A_const_80 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[94]); A_arbace_go_embed_A_const_81 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[95]); A_arbace_go_embed_A_const_82 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[96]); A_arbace_go_embed_A_const_83 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[97]); A_arbace_go_embed_A_const_84 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[98]); A_arbace_go_embed_A_const_85 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[99]); A_arbace_go_embed_A_const_86 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[100]); A_arbace_go_embed_A_const_87 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[101]); A_arbace_go_embed_A_const_88 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[102]); A_arbace_go_embed_A_const_89 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[103]); A_arbace_go_embed_A_const_90 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[104]) }

func A_arbace_go_embed_A_clinit_p7() { A_arbace_go_embed_A_const_91 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[105]); A_arbace_go_embed_A_const_92 = A_arbace_go_embed_A_const_pool.A[106]; A_arbace_go_embed_A_const_93 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[107]); A_arbace_go_embed_A_const_94 = A_arbace_go_embed_A_const_pool.A[108]; A_arbace_go_embed_A_const_95 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[109]); A_arbace_go_embed_A_const_96 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[110]); A_arbace_go_embed_A_const_97 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[111]); A_arbace_go_embed_A_const_98 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[112]); A_arbace_go_embed_A_const_99 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[113]); A_arbace_go_embed_A_const_100 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[114]); A_arbace_go_embed_A_const_101 = A_arbace_go_embed_A_const_pool.A[115]; A_arbace_go_embed_A_const_102 = A_arbace_go_embed_A_const_pool.A[116]; A_arbace_go_embed_A_const_103 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[117]) }

func A_arbace_go_embed_A_clinit_p8() { A_arbace_go_embed_A_const_104 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[118]); A_arbace_go_embed_A_const_105 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[119]); A_arbace_go_embed_A_const_106 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[120]); A_arbace_go_embed_A_const_107 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[121]); A_arbace_go_embed_A_const_108 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[122]); A_arbace_go_embed_A_const_109 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[123]); A_arbace_go_embed_A_const_110 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[124]); A_arbace_go_embed_A_const_111 = lang.Keyword_Cast(A_arbace_go_embed_A_const_pool.A[125]); A_arbace_go_embed_A_const_112 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[126]); A_arbace_go_embed_A_const_113 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[127]); A_arbace_go_embed_A_const_114 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[128]); A_arbace_go_embed_A_const_115 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[129]) }

func A_arbace_go_embed_A_clinit_p9() { A_arbace_go_embed_A_const_116 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[130]); A_arbace_go_embed_A_const_117 = A_arbace_go_embed_A_const_pool.A[131]; A_arbace_go_embed_A_const_118 = A_arbace_go_embed_A_const_pool.A[132]; A_arbace_go_embed_A_const_119 = A_arbace_go_embed_A_const_pool.A[133]; A_arbace_go_embed_A_const_120 = lang.Var_Cast(A_arbace_go_embed_A_const_pool.A[134]); A_arbace_go_embed_A_const_121 = lang.Keyword_Cast(A_arbace_go_embed_A_const_pool.A[135]); A_arbace_go_embed_A_const_122 = lang.Keyword_Cast(A_arbace_go_embed_A_const_pool.A[136]); A_arbace_go_embed_A_const_123 = lang.Keyword_Cast(A_arbace_go_embed_A_const_pool.A[137]); A_arbace_go_embed_A_const_124 = lang.Keyword_Cast(A_arbace_go_embed_A_const_pool.A[138]); A_arbace_go_embed_A_const_125 = lang.Keyword_Cast(A_arbace_go_embed_A_const_pool.A[139]); A_arbace_go_embed_A_const_126 = lang.Keyword_Cast(A_arbace_go_embed_A_const_pool.A[140]) }

func A_arbace_go_embed_A_New() *A_arbace_go_embed_A { A_arbace_go_embed_A_Init(); t := &A_arbace_go_embed_A{}; t.Ctor(); return t }

func (t *A_arbace_go_embed_A) Ctor() {}

func (t *A_arbace_go_embed_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_embed_A) GetClass__Class() *jrt.Class { return A_arbace_go_embed_A_class }

func (t *A_arbace_go_embed_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_embed_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_embed_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_embed_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_embed_A); return ok }

func A_arbace_go_embed_A_Cast(x any) *A_arbace_go_embed_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_embed_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_embed_A_class)) }; return v }



type A_arbace_go_embed_bad_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_embed_bad_name_QMARK__A_fn_class *jrt.Class



type A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A struct{ j2g_header uint64 }

var A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A_fn_class *jrt.Class



type A_arbace_go_embed_check_decl_A struct{ j2g_header uint64 }

var A_arbace_go_embed_check_decl_A_fn_class *jrt.Class



type A_arbace_go_embed_directive_patterns_A struct{ j2g_header uint64 }

var A_arbace_go_embed_directive_patterns_A_fn_class *jrt.Class



type A_arbace_go_embed_directive_patterns_fn__1220000026_A struct{ j2g_header uint64 }

var A_arbace_go_embed_directive_patterns_fn__1220000026_A_fn_class *jrt.Class



type A_arbace_go_embed_embed_error_A struct{ j2g_header uint64 }

var A_arbace_go_embed_embed_error_A_fn_class *jrt.Class



type A_arbace_go_embed_eval1220000004_A struct{ jrt.Object }

func A_arbace_go_embed_eval1220000004_A_New() *A_arbace_go_embed_eval1220000004_A { t := &A_arbace_go_embed_eval1220000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_embed_eval1220000004_A) Ctor() {}

func (t *A_arbace_go_embed_eval1220000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_embed_eval1220000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_embed_eval1220000004_A_class }

func (t *A_arbace_go_embed_eval1220000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_embed_eval1220000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_embed_eval1220000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_embed_eval1220000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_embed_eval1220000004_A); return ok }

func A_arbace_go_embed_eval1220000004_A_Cast(x any) *A_arbace_go_embed_eval1220000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_embed_eval1220000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_embed_eval1220000004_A_class)) }; return v }



type A_arbace_go_embed_eval1220000004_loading__1927001464__auto____1220000005_A struct{ j2g_header uint64 }

var A_arbace_go_embed_eval1220000004_loading__1927001464__auto____1220000005_A_fn_class *jrt.Class



type A_arbace_go_embed_eval1220000008_A struct{ jrt.Object }

func A_arbace_go_embed_eval1220000008_A_New() *A_arbace_go_embed_eval1220000008_A { t := &A_arbace_go_embed_eval1220000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_embed_eval1220000008_A) Ctor() {}

func (t *A_arbace_go_embed_eval1220000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_embed_eval1220000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_embed_eval1220000008_A_class }

func (t *A_arbace_go_embed_eval1220000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_embed_eval1220000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_embed_eval1220000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_embed_eval1220000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_embed_eval1220000008_A); return ok }

func A_arbace_go_embed_eval1220000008_A_Cast(x any) *A_arbace_go_embed_eval1220000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_embed_eval1220000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_embed_eval1220000008_A_class)) }; return v }



type A_arbace_go_embed_eval1220000008_fn__1220000009_A struct{ j2g_header uint64 }

var A_arbace_go_embed_eval1220000008_fn__1220000009_A_fn_class *jrt.Class



type A_arbace_go_embed_file_less_A struct{ j2g_header uint64 }

var A_arbace_go_embed_file_less_A_fn_class *jrt.Class



type A_arbace_go_embed_files_A struct{ j2g_header uint64 }

var A_arbace_go_embed_files_A_fn_class *jrt.Class



type A_arbace_go_embed_files_fn__1220000128_A struct{ j2g_header uint64; F_dir any }

var A_arbace_go_embed_files_fn__1220000128_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000130__1220000136_A struct{ j2g_header uint64 }

var A_arbace_go_embed_files_iter__1220000130__1220000136_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A struct{ j2g_header uint64; F_s__1220000131, F_iter__1220000130 any }

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A struct{ j2g_header uint64 }

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A struct{ j2g_header uint64 }

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A struct{ j2g_header uint64 }

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A struct{ j2g_header uint64; F_s__1220000133, F_iter__1220000132 any }

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1220000135, F_c__1927001037__auto__ any }

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000150__1220000154_A struct{ j2g_header uint64; F_dir, F_hashes any }

var A_arbace_go_embed_files_iter__1220000150__1220000154_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A struct{ j2g_header uint64; F_dir, F_s__1220000151, F_iter__1220000150, F_hashes any }

var A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A_fn_class *jrt.Class



type A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A struct{ j2g_header uint64; F_dir, F_hashes, F_b__1220000153 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_A struct{ j2g_header uint64 }

var A_arbace_go_embed_glob_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000059_A struct{ j2g_header uint64 }

var A_arbace_go_embed_glob_fn__1220000059_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000062_A struct{ j2g_header uint64 }

var A_arbace_go_embed_glob_fn__1220000062_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000068_A struct{ j2g_header uint64; F_dir any }

var A_arbace_go_embed_glob_fn__1220000068_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A struct{ j2g_header uint64; F_rx, F_dir, F_s any }

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A struct{ j2g_header uint64; F_rx, F_dir, F_s__1220000073, F_s, F_iter__1220000072 any }

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A struct{ j2g_header uint64; F_rx any }

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A struct{ j2g_header uint64; F_p any }

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A struct{ j2g_header uint64; F_p, F_s__1220000075, F_iter__1220000074 any }

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A struct{ j2g_header uint64; F_p, F_b__1220000077 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_regex_A struct{ j2g_header uint64 }

var A_arbace_go_embed_glob_regex_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_regex_fn__1220000041_A struct{ j2g_header uint64; F_i any; F_n int32; F_p any }

var A_arbace_go_embed_glob_regex_fn__1220000041_A_fn_class *jrt.Class



type A_arbace_go_embed_glob_regex_fn__1220000043_A struct{ j2g_header uint64 }

var A_arbace_go_embed_glob_regex_fn__1220000043_A_fn_class *jrt.Class



type A_arbace_go_embed_name_split_A struct{ j2g_header uint64 }

var A_arbace_go_embed_name_split_A_fn_class *jrt.Class



type A_arbace_go_embed_parse_patterns_A struct{ j2g_header uint64 }

var A_arbace_go_embed_parse_patterns_A_fn_class *jrt.Class



type A_arbace_go_embed_parse_patterns_fn__1220000020_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_embed_parse_patterns_fn__1220000020_A_fn_class *jrt.Class



type A_arbace_go_embed_parse_patterns_fn__1220000022_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_embed_parse_patterns_fn__1220000022_A_fn_class *jrt.Class



type A_arbace_go_embed_resolve_pattern_A struct{ j2g_header uint64 }

var A_arbace_go_embed_resolve_pattern_A_fn_class *jrt.Class



type A_arbace_go_embed_resolve_pattern_walk__1220000100_A struct{ j2g_header uint64; F_pattern, F_list, F_all, F_n any }

var A_arbace_go_embed_resolve_pattern_walk__1220000100_A_fn_class *jrt.Class



type A_arbace_go_embed_resolve_pattern_walk__1220000106_A struct{ j2g_header uint64; F_pattern, F_list, F_n, F_all any }

var A_arbace_go_embed_resolve_pattern_walk__1220000106_A_fn_class *jrt.Class



type A_arbace_go_embed_sha256_hex_A struct{ j2g_header uint64 }

var A_arbace_go_embed_sha256_hex_A_fn_class *jrt.Class



type A_arbace_go_embed_sha256_hex_fn__1220000122_A struct{ j2g_header uint64 }

var A_arbace_go_embed_sha256_hex_fn__1220000122_A_fn_class *jrt.Class



type A_arbace_go_embed_sorted_children_A struct{ j2g_header uint64 }

var A_arbace_go_embed_sorted_children_A_fn_class *jrt.Class



type A_arbace_go_embed_sorted_children_fn__1220000054_A struct{ j2g_header uint64 }

var A_arbace_go_embed_sorted_children_fn__1220000054_A_fn_class *jrt.Class



type A_arbace_go_embed_space_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_embed_space_QMARK__A_fn_class *jrt.Class



type A_arbace_go_embed_unquote_go_A struct{ j2g_header uint64 }

var A_arbace_go_embed_unquote_go_A_fn_class *jrt.Class



type A_arbace_go_embed_valid_path_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_embed_valid_path_QMARK__A_fn_class *jrt.Class



type A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A struct{ j2g_header uint64 }

var A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A_fn_class *jrt.Class
