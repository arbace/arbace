//line j2g_classes.ae:1
package aot_arbace_go_embed

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_go_embed_bad_name_QMARK__A_class, Name: "arbace.go.embed$bad_name_QMARK_", Modifiers: 25, Simple: "bad_name_QMARK_", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_bad_name_QMARK__A", Source: "embed.ae", Declaring: &A_arbace_go_embed_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A_class, Name: "arbace.go.embed$bad_name_QMARK_$fn__1220000050", Modifiers: 25, Simple: "fn__1220000050", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_bad_name_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_check_decl_A_class, Name: "arbace.go.embed$check_decl", Modifiers: 25, Simple: "check_decl", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_check_decl_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_directive_patterns_A_class, Name: "arbace.go.embed$directive_patterns", Modifiers: 25, Simple: "directive_patterns", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_directive_patterns_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_directive_patterns_fn__1220000026_A_class, Name: "arbace.go.embed$directive_patterns$fn__1220000026", Modifiers: 25, Simple: "fn__1220000026", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_directive_patterns_fn__1220000026_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_directive_patterns_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_embed_error_A_class, Name: "arbace.go.embed$embed_error", Modifiers: 25, Simple: "embed_error", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_embed_error_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_eval1220000004_loading__1927001464__auto____1220000005_A_class, Name: "arbace.go.embed$eval1220000004$loading__1927001464__auto____1220000005", Modifiers: 25, Simple: "loading__1927001464__auto____1220000005", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_eval1220000004_loading__1927001464__auto____1220000005_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_eval1220000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_eval1220000008_fn__1220000009_A_class, Name: "arbace.go.embed$eval1220000008$fn__1220000009", Modifiers: 25, Simple: "fn__1220000009", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_eval1220000008_fn__1220000009_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_eval1220000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_file_less_A_class, Name: "arbace.go.embed$file_less", Modifiers: 25, Simple: "file_less", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_file_less_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_files_A_class, Name: "arbace.go.embed$files", Modifiers: 25, Simple: "files", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_files_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF5_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_files_fn__1220000128_A_class, Name: "arbace.go.embed$files$fn__1220000128", Modifiers: 25, Simple: "fn__1220000128", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_files_fn__1220000128_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_files_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_files_iter__1220000130__1220000136_A_class, Name: "arbace.go.embed$files$iter__1220000130__1220000136", Modifiers: 25, Simple: "iter__1220000130__1220000136", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_files_iter__1220000130__1220000136_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_files_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A_class, Name: "arbace.go.embed$files$iter__1220000130__1220000136$fn__1220000137", Modifiers: 25, Simple: "fn__1220000137", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_files_iter__1220000130__1220000136_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A_class, Name: "arbace.go.embed$files$iter__1220000130__1220000136$fn__1220000137$fn__1220000144", Modifiers: 25, Simple: "fn__1220000144", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A_class, Name: "arbace.go.embed$files$iter__1220000130__1220000136$fn__1220000137$fn__1220000146", Modifiers: 25, Simple: "fn__1220000146", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A_class, Name: "arbace.go.embed$files$iter__1220000130__1220000136$fn__1220000137$iter__1220000132__1220000138", Modifiers: 25, Simple: "iter__1220000132__1220000138", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A_class, Name: "arbace.go.embed$files$iter__1220000130__1220000136$fn__1220000137$iter__1220000132__1220000138$fn__1220000139", Modifiers: 25, Simple: "fn__1220000139", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A_class, Name: "arbace.go.embed$files$iter__1220000130__1220000136$fn__1220000137$iter__1220000132__1220000138$fn__1220000139$fn__1220000140", Modifiers: 25, Simple: "fn__1220000140", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_files_iter__1220000150__1220000154_A_class, Name: "arbace.go.embed$files$iter__1220000150__1220000154", Modifiers: 25, Simple: "iter__1220000150__1220000154", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_files_iter__1220000150__1220000154_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_files_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A_class, Name: "arbace.go.embed$files$iter__1220000150__1220000154$fn__1220000155", Modifiers: 25, Simple: "fn__1220000155", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_files_iter__1220000150__1220000154_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A_class, Name: "arbace.go.embed$files$iter__1220000150__1220000154$fn__1220000155$fn__1220000156", Modifiers: 25, Simple: "fn__1220000156", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_glob_A_class, Name: "arbace.go.embed$glob", Modifiers: 25, Simple: "glob", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_glob_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_glob_fn__1220000059_A_class, Name: "arbace.go.embed$glob$fn__1220000059", Modifiers: 25, Simple: "fn__1220000059", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_glob_fn__1220000059_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_glob_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_glob_fn__1220000062_A_class, Name: "arbace.go.embed$glob$fn__1220000062", Modifiers: 25, Simple: "fn__1220000062", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_glob_fn__1220000062_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_glob_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_glob_fn__1220000068_A_class, Name: "arbace.go.embed$glob$fn__1220000068", Modifiers: 25, Simple: "fn__1220000068", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_glob_fn__1220000068_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_glob_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A_class, Name: "arbace.go.embed$glob$fn__1220000068$iter__1220000072__1220000078", Modifiers: 25, Simple: "iter__1220000072__1220000078", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_glob_fn__1220000068_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A_class, Name: "arbace.go.embed$glob$fn__1220000068$iter__1220000072__1220000078$fn__1220000079", Modifiers: 25, Simple: "fn__1220000079", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A_class, Name: "arbace.go.embed$glob$fn__1220000068$iter__1220000072__1220000078$fn__1220000079$fn__1220000086", Modifiers: 25, Simple: "fn__1220000086", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A_class, Name: "arbace.go.embed$glob$fn__1220000068$iter__1220000072__1220000078$fn__1220000079$iter__1220000074__1220000080", Modifiers: 25, Simple: "iter__1220000074__1220000080", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A_class, Name: "arbace.go.embed$glob$fn__1220000068$iter__1220000072__1220000078$fn__1220000079$iter__1220000074__1220000080$fn__1220000081", Modifiers: 25, Simple: "fn__1220000081", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A_class, Name: "arbace.go.embed$glob$fn__1220000068$iter__1220000072__1220000078$fn__1220000079$iter__1220000074__1220000080$fn__1220000081$fn__1220000082", Modifiers: 25, Simple: "fn__1220000082", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_glob_regex_A_class, Name: "arbace.go.embed$glob_regex", Modifiers: 25, Simple: "glob_regex", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_glob_regex_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_glob_regex_fn__1220000041_A_class, Name: "arbace.go.embed$glob_regex$fn__1220000041", Modifiers: 25, Simple: "fn__1220000041", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_glob_regex_fn__1220000041_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_glob_regex_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_glob_regex_fn__1220000043_A_class, Name: "arbace.go.embed$glob_regex$fn__1220000043", Modifiers: 25, Simple: "fn__1220000043", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_glob_regex_fn__1220000043_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_glob_regex_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_name_split_A_class, Name: "arbace.go.embed$name_split", Modifiers: 25, Simple: "name_split", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_name_split_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_parse_patterns_A_class, Name: "arbace.go.embed$parse_patterns", Modifiers: 25, Simple: "parse_patterns", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_parse_patterns_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_parse_patterns_fn__1220000020_A_class, Name: "arbace.go.embed$parse_patterns$fn__1220000020", Modifiers: 25, Simple: "fn__1220000020", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_parse_patterns_fn__1220000020_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_parse_patterns_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_parse_patterns_fn__1220000022_A_class, Name: "arbace.go.embed$parse_patterns$fn__1220000022", Modifiers: 25, Simple: "fn__1220000022", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_parse_patterns_fn__1220000022_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_parse_patterns_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_resolve_pattern_A_class, Name: "arbace.go.embed$resolve_pattern", Modifiers: 25, Simple: "resolve_pattern", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_resolve_pattern_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_resolve_pattern_walk__1220000100_A_class, Name: "arbace.go.embed$resolve_pattern$walk__1220000100", Modifiers: 25, Simple: "walk__1220000100", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_resolve_pattern_walk__1220000100_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_resolve_pattern_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_resolve_pattern_walk__1220000106_A_class, Name: "arbace.go.embed$resolve_pattern$walk__1220000106", Modifiers: 25, Simple: "walk__1220000106", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_resolve_pattern_walk__1220000106_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_resolve_pattern_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_sha256_hex_A_class, Name: "arbace.go.embed$sha256_hex", Modifiers: 25, Simple: "sha256_hex", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_sha256_hex_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_sha256_hex_fn__1220000122_A_class, Name: "arbace.go.embed$sha256_hex$fn__1220000122", Modifiers: 25, Simple: "fn__1220000122", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_sha256_hex_fn__1220000122_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_sha256_hex_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_sorted_children_A_class, Name: "arbace.go.embed$sorted_children", Modifiers: 25, Simple: "sorted_children", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_sorted_children_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_sorted_children_fn__1220000054_A_class, Name: "arbace.go.embed$sorted_children$fn__1220000054", Modifiers: 25, Simple: "fn__1220000054", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_sorted_children_fn__1220000054_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_sorted_children_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_space_QMARK__A_class, Name: "arbace.go.embed$space_QMARK_", Modifiers: 25, Simple: "space_QMARK_", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_space_QMARK__A", Source: "embed.ae", Declaring: &A_arbace_go_embed_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_unquote_go_A_class, Name: "arbace.go.embed$unquote_go", Modifiers: 25, Simple: "unquote_go", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_unquote_go_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_valid_path_QMARK__A_class, Name: "arbace.go.embed$valid_path_QMARK_", Modifiers: 25, Simple: "valid_path_QMARK_", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_valid_path_QMARK__A", Source: "embed.ae", Declaring: &A_arbace_go_embed_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A_class, Name: "arbace.go.embed$valid_path_QMARK_$fn__1220000047", Modifiers: 25, Simple: "fn__1220000047", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A", Source: "embed.ae", Declaring: &A_arbace_go_embed_valid_path_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_go_embed_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_embed_A_New()}; return nil }

var A_arbace_go_embed_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_embed_A_new}

var A_arbace_go_embed_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.embed", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_A"})

func init() { i := A_arbace_go_embed_A_class.Info(); i.IsInstance = A_arbace_go_embed_A_InstanceOf; i.Init = A_arbace_go_embed_A_Init; i.Table = A_arbace_go_embed_A_members }

var A_arbace_go_embed_bad_name_QMARK__A_class *jrt.Class

var A_arbace_go_embed_bad_name_QMARK__fn__1220000050_A_class *jrt.Class

var A_arbace_go_embed_check_decl_A_class *jrt.Class

var A_arbace_go_embed_directive_patterns_A_class *jrt.Class

var A_arbace_go_embed_directive_patterns_fn__1220000026_A_class *jrt.Class

var A_arbace_go_embed_embed_error_A_class *jrt.Class

func A_arbace_go_embed_eval1220000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_embed_eval1220000004_A_New()}; return nil }

var A_arbace_go_embed_eval1220000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_embed_eval1220000004_A_new}

var A_arbace_go_embed_eval1220000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.embed$eval1220000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_embed_A_class, Simple: "eval1220000004", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_eval1220000004_A"})

func init() { i := A_arbace_go_embed_eval1220000004_A_class.Info(); i.IsInstance = A_arbace_go_embed_eval1220000004_A_InstanceOf; i.Table = A_arbace_go_embed_eval1220000004_A_members }

var A_arbace_go_embed_eval1220000004_loading__1927001464__auto____1220000005_A_class *jrt.Class

func A_arbace_go_embed_eval1220000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_embed_eval1220000008_A_New()}; return nil }

var A_arbace_go_embed_eval1220000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_embed_eval1220000008_A_new}

var A_arbace_go_embed_eval1220000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.embed$eval1220000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_embed_A_class, Simple: "eval1220000008", Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed_eval1220000008_A"})

func init() { i := A_arbace_go_embed_eval1220000008_A_class.Info(); i.IsInstance = A_arbace_go_embed_eval1220000008_A_InstanceOf; i.Table = A_arbace_go_embed_eval1220000008_A_members }

var A_arbace_go_embed_eval1220000008_fn__1220000009_A_class *jrt.Class

var A_arbace_go_embed_file_less_A_class *jrt.Class

var A_arbace_go_embed_files_A_class *jrt.Class

var A_arbace_go_embed_files_fn__1220000128_A_class *jrt.Class

var A_arbace_go_embed_files_iter__1220000130__1220000136_A_class *jrt.Class

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_A_class *jrt.Class

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000144_A_class *jrt.Class

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_fn__1220000146_A_class *jrt.Class

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_A_class *jrt.Class

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_A_class *jrt.Class

var A_arbace_go_embed_files_iter__1220000130__1220000136_fn__1220000137_iter__1220000132__1220000138_fn__1220000139_fn__1220000140_A_class *jrt.Class

var A_arbace_go_embed_files_iter__1220000150__1220000154_A_class *jrt.Class

var A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_A_class *jrt.Class

var A_arbace_go_embed_files_iter__1220000150__1220000154_fn__1220000155_fn__1220000156_A_class *jrt.Class

var A_arbace_go_embed_glob_A_class *jrt.Class

var A_arbace_go_embed_glob_fn__1220000059_A_class *jrt.Class

var A_arbace_go_embed_glob_fn__1220000062_A_class *jrt.Class

var A_arbace_go_embed_glob_fn__1220000068_A_class *jrt.Class

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_A_class *jrt.Class

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_A_class *jrt.Class

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_fn__1220000086_A_class *jrt.Class

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_A_class *jrt.Class

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_A_class *jrt.Class

var A_arbace_go_embed_glob_fn__1220000068_iter__1220000072__1220000078_fn__1220000079_iter__1220000074__1220000080_fn__1220000081_fn__1220000082_A_class *jrt.Class

var A_arbace_go_embed_glob_regex_A_class *jrt.Class

var A_arbace_go_embed_glob_regex_fn__1220000041_A_class *jrt.Class

var A_arbace_go_embed_glob_regex_fn__1220000043_A_class *jrt.Class

var A_arbace_go_embed_name_split_A_class *jrt.Class

var A_arbace_go_embed_parse_patterns_A_class *jrt.Class

var A_arbace_go_embed_parse_patterns_fn__1220000020_A_class *jrt.Class

var A_arbace_go_embed_parse_patterns_fn__1220000022_A_class *jrt.Class

var A_arbace_go_embed_resolve_pattern_A_class *jrt.Class

var A_arbace_go_embed_resolve_pattern_walk__1220000100_A_class *jrt.Class

var A_arbace_go_embed_resolve_pattern_walk__1220000106_A_class *jrt.Class

var A_arbace_go_embed_sha256_hex_A_class *jrt.Class

var A_arbace_go_embed_sha256_hex_fn__1220000122_A_class *jrt.Class

var A_arbace_go_embed_sorted_children_A_class *jrt.Class

var A_arbace_go_embed_sorted_children_fn__1220000054_A_class *jrt.Class

var A_arbace_go_embed_space_QMARK__A_class *jrt.Class

var A_arbace_go_embed_unquote_go_A_class *jrt.Class

var A_arbace_go_embed_valid_path_QMARK__A_class *jrt.Class

var A_arbace_go_embed_valid_path_QMARK__fn__1220000047_A_class *jrt.Class

func A_arbace_go_embed__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_go_embed__init_A_Load__O()}; return nil }

func A_arbace_go_embed__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_embed__init_A_New()}; return nil }

var A_arbace_go_embed__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_go_embed__init_A_invoke, New: A_arbace_go_embed__init_A_new}

var A_arbace_go_embed__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.embed__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_embed.A_arbace_go_embed__init_A", Source: "embed.ae"})

func init() { i := A_arbace_go_embed__init_A_class.Info(); i.IsInstance = A_arbace_go_embed__init_A_InstanceOf; i.Init = A_arbace_go_embed__init_A_Init; i.Table = A_arbace_go_embed__init_A_members }
