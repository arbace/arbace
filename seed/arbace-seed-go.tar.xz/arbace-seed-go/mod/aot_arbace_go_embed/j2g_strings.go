//line j2g_strings.ae:1
package aot_arbace_go_embed

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,strkn3,dockn4,elseks15,arbace.go.embed5,errorkn2,fskn15,embed-imported?kn5,nameskn5,init?kn6,typed?kn5,minorkn4,langv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.go.embedm2,R4,s746,goi's go:embed (doc/go/GOI-SPEC.md \"As built: GS14\", GS14 (a)): the files a //go:embed\n  variable embeds, read from its package's forms directory when the package loads (SPEC.md §9.6,\n  amendment B2: the package file's path without .ae), as the go command and gc find them: the\n  directive's patterns (gc's noder, parseGoEmbed), each matched against the directory as the go\n  command matches it (cmd/go/internal/load, resolveEmbed: path.Match's globs, a directory's files\n  below it but hidden ones, unless all:), the variable's files gathered as gc's embedFileList\n  gathers them (an embed.FS's directories too, sorted by directory, then name), with gc's and the\n  go command's errors. The value itself is the builder's (arbace.go.repl/define!).v11,arbace.core4,subsl1,v11,arbace.core3,strc34,v11,arbace.core4,not=c92,R5,c39,c97,c98,c102,c110,c114,c10,c116,c13,c117,c9,c118,c120,v13,arbace.string4,trimv15,arbace.go.embed10,unquote-gol0,c96,v13,arbace.string8,index-ofv11,arbace.core4,somev15,arbace.go.embed6,space?v11,arbace.core5,rangev11,arbace.core3,notv11,arbace.core7,vector?v11,arbace.core6,reducev15,arbace.go.embed14,parse-patternsv11,arbace.core7,reducedv11,arbace.core6,empty?V2,ns28,usage: //go:embed pattern...v11,arbace.core4,intov11,arbace.core10,re-patternc42,c63,c91,c93,c94,v13,arbace.string12,starts-with?v13,arbace.string4,joinv11,arbace.core3,mapv11,arbace.core9,contains?S5,c38,c91,c92,c93,c94,v13,arbace.string7,replacev11,arbace.core6,every?S3,s0,s2,..s1,.v13,arbace.string5,splitp1,/l-1,S5,s0,s4,.svns3,.hgs4,.bzrs4,.gitv13,arbace.string9,includes?v15,arbace.go.embed8,reservedv13,arbace.string10,upper-casev11,arbace.core5,firstp2,\\.l2,v13,arbace.string10,ends-with?v11,arbace.core7,sort-byv11,arbace.core3,seqp1,/v11,arbace.core7,re-findp8,[*?\\[\\\\]v15,arbace.go.embed10,glob-regexp8,[*?\\[\\\\]v11,arbace.core6,vectorv11,arbace.core3,vecv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core6,filterv11,arbace.core10,re-matchesv15,arbace.go.embed15,sorted-childrenv11,arbace.core6,concatV1,s0,v11,arbace.core7,ex-infom2,R6,Tv15,arbace.go.embed11,valid-path?v15,arbace.go.embed11,embed-errorv15,arbace.go.embed4,globv11,arbace.core9,volatile!v11,arbace.core4,sortv11,arbace.core8,distinctl4,p1,/v15,arbace.go.embed9,bad-name?v11,arbace.core4,nextv13,arbace.string13,last-index-ofv15,arbace.go.embed10,name-splitv11,arbace.core5,applyv11,arbace.core6,formatv11,arbace.core6,mapcatv15,arbace.go.embed15,resolve-patternR7,v11,arbace.core10,take-whilev11,arbace.core7,iteratev11,arbace.core10,comparatorv15,arbace.go.embed9,file-lessv15,arbace.go.embed10,sha256-hexm2,R6,Tm2,R6,Tm2,R6,Tv11,arbace.core8,to-arrayR8,R9,R10,R11,R12,R13,")

var Lit_1 *jrt.String = jrt.Intern("arbace.go.embed$bad_name_QMARK_$fn__1220000050")

var Lit_2 *jrt.String = jrt.Intern(".")

var Lit_3 *jrt.String = jrt.Intern("!#$%&()+,-.=@[]^_{}~ ")

var Lit_4 *jrt.String = jrt.Intern("go:embed requires import \"embed\" (or import _ \"embed\", if package is not used)")

var Lit_5 *jrt.String = jrt.Intern("go:embed cannot apply to multiple vars")

var Lit_6 *jrt.String = jrt.Intern("go:embed cannot apply to var with initializer")

var Lit_7 *jrt.String = jrt.Intern("go:embed cannot apply to var without type")

var Lit_8 *jrt.String = jrt.Intern("go:embed requires go1.16 or later (-lang was set to ")

var Lit_9 *jrt.String = jrt.Intern("; check go.mod)")

var Lit_10 *jrt.String = jrt.Intern("arbace.go.embed$directive_patterns$fn__1220000026")

var Lit_11 *jrt.String = jrt.Intern("pattern ")

var Lit_12 *jrt.String = jrt.Intern(": ")

var Lit_13 *jrt.String = jrt.Intern("java.io.File")

var Lit_14 *jrt.String = jrt.Intern("java.nio.file.Files")

var Lit_15 *jrt.String = jrt.Intern("java.security.MessageDigest")

var Lit_16 *jrt.String = jrt.Intern("arbace.go.embed$files$fn__1220000128")

var Lit_17 *jrt.String = jrt.Intern("arbace.go.embed$files$iter__1220000130__1220000136")

var Lit_18 *jrt.String = jrt.Intern("invalid go:embed: multiple files for type ")

var Lit_19 *jrt.String = jrt.Intern("arbace.go.embed$files$iter__1220000150__1220000154")

var Lit_20 *jrt.String = jrt.Intern("arbace.go.embed$files$iter__1220000130__1220000136$fn__1220000137")

var Lit_21 *jrt.String = jrt.Intern("arbace.go.embed$files$iter__1220000130__1220000136$fn__1220000137$iter__1220000132__1220000138")

var Lit_22 *jrt.String = jrt.Intern("arbace.go.embed$files$iter__1220000130__1220000136$fn__1220000137$fn__1220000144")

var Lit_23 *jrt.String = jrt.Intern("arbace.go.embed$files$iter__1220000130__1220000136$fn__1220000137$fn__1220000146")

var Lit_24 *jrt.String = jrt.Intern("arbace.go.embed$files$iter__1220000130__1220000136$fn__1220000137$iter__1220000132__1220000138$fn__1220000139")

var Lit_25 *jrt.String = jrt.Intern("arbace.go.embed$files$iter__1220000130__1220000136$fn__1220000137$iter__1220000132__1220000138$fn__1220000139$fn__1220000140")

var Lit_26 *jrt.String = jrt.Intern("/")

var Lit_27 *jrt.String = jrt.Intern("arbace.go.embed$files$iter__1220000150__1220000154$fn__1220000155")

var Lit_28 *jrt.String = jrt.Intern("arbace.go.embed$files$iter__1220000150__1220000154$fn__1220000155$fn__1220000156")

var Lit_29 *jrt.String = jrt.Intern("embedded file ")

var Lit_30 *jrt.String = jrt.Intern(": sha256 ")

var Lit_31 *jrt.String = jrt.Intern(", the forms say ")

var Lit_32 *jrt.String = jrt.Intern("arbace.go.embed$glob$fn__1220000059")

var Lit_33 *jrt.String = jrt.Intern("arbace.go.embed$glob$fn__1220000062")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.embed$glob$fn__1220000068")

var Lit_35 *jrt.String = jrt.Intern("arbace.go.embed$glob$fn__1220000068$iter__1220000072__1220000078")

var Lit_36 *jrt.String = jrt.Intern("arbace.go.embed$glob$fn__1220000068$iter__1220000072__1220000078$fn__1220000079")

var Lit_37 *jrt.String = jrt.Intern("")

var Lit_38 *jrt.String = jrt.Intern("arbace.go.embed$glob$fn__1220000068$iter__1220000072__1220000078$fn__1220000079$iter__1220000074__1220000080")

var Lit_39 *jrt.String = jrt.Intern("arbace.go.embed$glob$fn__1220000068$iter__1220000072__1220000078$fn__1220000079$fn__1220000086")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.embed$glob$fn__1220000068$iter__1220000072__1220000078$fn__1220000079$iter__1220000074__1220000080$fn__1220000081")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.embed$glob$fn__1220000068$iter__1220000072__1220000078$fn__1220000079$iter__1220000074__1220000080$fn__1220000081$fn__1220000082")

var Lit_42 *jrt.String = jrt.Intern("[^/]*")

var Lit_43 *jrt.String = jrt.Intern("[^/]")

var Lit_44 *jrt.String = jrt.Intern("arbace.go.embed$glob_regex$fn__1220000041")

var Lit_45 *jrt.String = jrt.Intern("^")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.embed$glob_regex$fn__1220000043")

var Lit_47 *jrt.String = jrt.Intern("\\")

var Lit_48 *jrt.String = jrt.Intern("[")

var Lit_49 *jrt.String = jrt.Intern("]")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.embed$parse_patterns$fn__1220000020")

var Lit_51 *jrt.String = jrt.Intern("invalid quoted string in //go:embed: ")

var Lit_52 *jrt.String = jrt.Intern("`")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.embed$parse_patterns$fn__1220000022")

var Lit_54 *jrt.String = jrt.Intern("all:")

var Lit_55 *jrt.String = jrt.Intern("invalid pattern syntax")

var Lit_56 *jrt.String = jrt.Intern("directory")

var Lit_57 *jrt.String = jrt.Intern("file")

var Lit_58 *jrt.String = jrt.Intern("go.mod")

var Lit_59 *jrt.String = jrt.Intern("cannot embed ")

var Lit_60 *jrt.String = jrt.Intern(" ")

var Lit_61 *jrt.String = jrt.Intern(": in different module")

var Lit_62 *jrt.String = jrt.Intern(": invalid name ")

var Lit_63 *jrt.String = jrt.Intern(": in invalid directory ")

var Lit_64 *jrt.String = jrt.Intern("arbace.go.embed$resolve_pattern$walk__1220000100")

var Lit_65 *jrt.String = jrt.Intern("cannot embed directory ")

var Lit_66 *jrt.String = jrt.Intern(": contains no embeddable files")

var Lit_67 *jrt.String = jrt.Intern("cannot embed irregular file ")

var Lit_68 *jrt.String = jrt.Intern("arbace.go.embed$resolve_pattern$walk__1220000106")

var Lit_69 *jrt.String = jrt.Intern("no matching files found")

var Lit_70 *jrt.String = jrt.Intern("_")

var Lit_71 *jrt.String = jrt.Intern("cannot embed file ")

var Lit_72 *jrt.String = jrt.Intern("SHA-256")

var Lit_73 *jrt.String = jrt.Intern("arbace.go.embed$sha256_hex$fn__1220000122")

var Lit_74 *jrt.String = jrt.Intern("%02x")

var Lit_75 *jrt.String = jrt.Intern("arbace.go.embed$sorted_children$fn__1220000054")

var Lit_76 *jrt.String = jrt.Intern("arbace.go.embed$valid_path_QMARK_$fn__1220000047")

var Lit_77 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn1,ckn4,linekn6,columnkn4,filekn3,tagyn6,Stringyn1,vyn4,Fileyn7,patternyn3,msgyn1,xyn1,yyn5,bytesyn8,patternsyn4,kindyn6,hashesyn9,type-textkn4,keysyn15,embed-imported?yn5,namesyn5,init?yn6,typed?yn5,minoryn4,langv11,arbace.core5,in-nsMyn15,arbace.go.embedm2,R0,s746,goi's go:embed (doc/go/GOI-SPEC.md \"As built: GS14\", GS14 (a)): the files a //go:embed\n  variable embeds, read from its package's forms directory when the package loads (SPEC.md §9.6,\n  amendment B2: the package file's path without .ae), as the go command and gc find them: the\n  directive's patterns (gc's noder, parseGoEmbed), each matched against the directory as the go\n  command matches it (cmd/go/internal/load, resolveEmbed: path.Match's globs, a directory's files\n  below it but hidden ones, unless all:), the variable's files gathered as gc's embedFileList\n  gathers them (an embed.FS's directories too, sorted by directory, then name), with gc's and the\n  go command's errors. The value itself is the builder's (arbace.go.repl/define!).m2,R0,s746,goi's go:embed (doc/go/GOI-SPEC.md \"As built: GS14\", GS14 (a)): the files a //go:embed\n  variable embeds, read from its package's forms directory when the package loads (SPEC.md §9.6,\n  amendment B2: the package file's path without .ae), as the go command and gc find them: the\n  directive's patterns (gc's noder, parseGoEmbed), each matched against the directory as the go\n  command matches it (cmd/go/internal/load, resolveEmbed: path.Match's globs, a directory's files\n  below it but hidden ones, unless all:), the variable's files gathered as gc's embedFileList\n  gathers them (an embed.FS's directories too, sorted by directory, then name), with gc's and the\n  go command's errors. The value itself is the builder's (arbace.go.repl/define!).R1,v15,arbace.go.embed6,space?m10,R2,TR3,L1,V1,R4,R5,i17,R6,i1,R7,s18,arbace/go/embed.aev15,arbace.go.embed10,unquote-gom12,R2,TR3,L1,V1,Myn1,qm2,R8,R9,R0,s90,Go's strconv.Unquote of a double-quoted string q (its escapes), or nil when it is not one.R5,i19,R6,i1,R7,s18,arbace/go/embed.aev15,arbace.go.embed14,parse-patternsm10,R3,L1,V1,Myn4,argsm2,R8,R9,R0,s113,The patterns of a //go:embed directive's text after go:embed: [patterns nil], or [nil message]\n  (gc's messages).R5,i48,R6,i1,R7,s18,arbace/go/embed.aev15,arbace.go.embed18,directive-patternsm10,R3,L1,V1,R10,R0,s99,The patterns of a variable's :go/embed (one directive's text, or a vector of them), or a\n  message.R5,i81,R6,i1,R7,s18,arbace/go/embed.aev15,arbace.go.embed10,glob-regexm12,R2,TR3,L1,V1,Myn1,pm2,R8,R9,R0,s90,A segment of a path.Match pattern as a regex, or nil when it is malformed (ErrBadPattern).R5,i96,R6,i1,R7,s18,arbace/go/embed.aev15,arbace.go.embed11,valid-path?m12,R2,TR3,L1,V1,Myn1,pm2,R8,R9,R0,s64,io/fs's ValidPath: slash-separated elements, none empty, . or ..R5,i128,R6,i1,R7,s18,arbace/go/embed.aev15,arbace.go.embed8,reservedS22,s3,AUXs3,CONs4,COM9s4,COM6s3,PRNs4,COM3s4,LPT9s3,NULs4,COM1s4,LPT2s4,COM2s4,COM4s4,LPT4s4,COM8s4,LPT5s4,LPT6s4,LPT8s4,COM7s4,LPT1s4,COM5s4,LPT7s4,LPT3m8,R2,TR5,i134,R6,i1,R7,s18,arbace/go/embed.aev15,arbace.go.embed9,bad-name?m12,R2,TR3,L1,V1,Myn1,nm2,R8,R9,R0,s178,cmd/go's isBadEmbedName: a name a module cannot hold (golang.org/x/mod's CheckFilePath's\n  element rules: its characters, Windows' reserved names) or a version control directory.R5,i138,R6,i1,R7,s18,arbace/go/embed.aev15,arbace.go.embed15,sorted-childrenm10,R2,TR3,L1,V1,Myn1,dm2,R8,R11,R5,i147,R6,i1,R7,s18,arbace/go/embed.aev15,arbace.go.embed4,globm12,R2,TR3,L1,V2,Myn3,dirm2,R8,R11,Myn4,globm2,R8,R9,R0,s180,The files and directories of dir matching glob (its segments path.Match's), as their paths\n  relative to dir, sorted as filepath.Glob gives them; nil when the pattern is malformed.R5,i150,R6,i1,R7,s18,arbace/go/embed.aev15,arbace.go.embed11,embed-errorm10,R2,TR3,L1,V2,R12,R13,R5,i167,R6,i1,R7,s18,arbace/go/embed.aev15,arbace.go.embed15,resolve-patternm10,R3,L1,V2,Myn3,dirm2,R8,R11,Myn7,patternm2,R8,R9,R0,s134,The files pattern names in the forms directory dir, sorted (cmd/go's resolveEmbed), or an\n  error (ex-info, the go command's message).R5,i169,R6,i1,R7,s18,arbace/go/embed.aev15,arbace.go.embed10,name-splitm10,R2,TR3,L1,V1,Myn1,nm2,R8,R9,R5,i218,R6,i1,R7,s18,arbace/go/embed.aev15,arbace.go.embed9,file-lessm12,R2,TR3,L1,V2,R14,R15,R0,s47,gc's embedFileLess: by directory, then by name.R5,i223,R6,i1,R7,s18,arbace/go/embed.aev15,arbace.go.embed10,sha256-hexm10,R2,TR3,L1,V1,Myn2,bsm2,R8,R16,R5,i229,R6,i1,R7,s18,arbace/go/embed.aev15,arbace.go.embed5,filesm10,R3,L1,V5,Myn3,dirm2,R8,R11,R17,R18,R19,R20,R0,s317,The files of a variable embedding patterns from forms directory dir, kind :fs (with their\n  directories, a final slash) or :string, :bytes (one): [[name bytes-or-nil] ...] in gc's\n  order. hashes: the package's :embed-files, path -> SHA-256 (nil: unchecked). Throws an\n  ex-info with the go command's or gc's message.R5,i233,R6,i1,R7,s18,arbace/go/embed.aev15,arbace.go.embed10,check-declm10,R3,L1,V1,m2,R21,V6,R22,R23,R24,R25,R26,R27,R0,s280,gc's checkEmbed (noder.go) of a package-level variable declaration embedding: the message of\n  its first violation, or nil. names: its variables' count; init?: whether it has an initializer;\n  typed?: a type; embed-imported?: its file imports embed; minor: its language version's.R5,i257,R6,i1,R7,s18,arbace/go/embed.ae")

var Lit_78 *jrt.String = jrt.Intern("arbace.go.embed$eval1220000004$loading__1927001464__auto____1220000005")

var Lit_79 *jrt.String = jrt.Intern("arbace.go.embed$eval1220000008$fn__1220000009")

var Lit_80 *jrt.String = jrt.Intern("arbace.go.embed$space_QMARK_")

var Lit_81 *jrt.String = jrt.Intern("arbace.go.embed$unquote_go")

var Lit_82 *jrt.String = jrt.Intern("arbace.go.embed$parse_patterns")

var Lit_83 *jrt.String = jrt.Intern("arbace.go.embed$directive_patterns")

var Lit_84 *jrt.String = jrt.Intern("arbace.go.embed$glob_regex")

var Lit_85 *jrt.String = jrt.Intern("arbace.go.embed$valid_path_QMARK_")

var Lit_86 *jrt.String = jrt.Intern("arbace.go.embed$bad_name_QMARK_")

var Lit_87 *jrt.String = jrt.Intern("arbace.go.embed$sorted_children")

var Lit_88 *jrt.String = jrt.Intern("arbace.go.embed$glob")

var Lit_89 *jrt.String = jrt.Intern("arbace.go.embed$embed_error")

var Lit_90 *jrt.String = jrt.Intern("arbace.go.embed$resolve_pattern")

var Lit_91 *jrt.String = jrt.Intern("arbace.go.embed$name_split")

var Lit_92 *jrt.String = jrt.Intern("arbace.go.embed$file_less")

var Lit_93 *jrt.String = jrt.Intern("arbace.go.embed$sha256_hex")

var Lit_94 *jrt.String = jrt.Intern("arbace.go.embed$files")

var Lit_95 *jrt.String = jrt.Intern("arbace.go.embed$check_decl")
