//line j2g_strings.ae:1
package aot_arbace_box_convert

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn10,arbace.boxkn2,asyn3,boxyn16,arbace.box.buildyn5,buildyn13,arbace.stringyn3,strkn3,docks18,arbace.box.convert5,errorkn4,elsekn4,keptkn7,droppedkn6,otherskn6,embedskn4,pathkn4,filekn8,packageskn6,sharedkn8,per-archkn4,archkn3,badkn3,dirkn3,refkn4,treekn4,hostkn3,logkn3,runkn5,cachekn3,pinkn6,digestkn4,jobskn3,outkn6,resultkn5,imagekn4,argskn3,envkn5,treeskn3,cwdkn3,ramkn4,cpuskn7,consolekn6,serialkn10,read-amd64kn10,read-arm64kn11,forms-amd64kn11,forms-arm64kn3,srckn4,textkn6,gorootkn8,expectedkn5,equalv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn18,arbace.box.convertm2,R8,s3145,tamago/goroot converted in the box, as bin/tamago-vendor convert converts it on the host.\n\n    (steps src text opts)   the conversion of the GOROOT text tree text (TamaGo's VERSION and\n                            src/ but src/cmd, a hash or a ref) with the sources of tree src (a\n                            hash or a ref: arbace/, go/ and the forms of go/parser's packages\n                            under tamago/goroot, which the reader's forms check compares the\n                            compiled parser with): a map of every step's result, :goroot the\n                            converted tree (bin/tamago-vendor convert's OUT/goroot), :expected\n                            src's tamago/goroot, :equal whether they are the same tree\n\n  The steps, each an action (arbace.box.build/action: a spawned guest of Arbace's image, its\n  result in the action cache):\n    read ARCH   std for tamago/ARCH, by arbace.repr.go.annotate -main read (bin/repr-go read\n                --corpus ARCH's native read): the forms (/o/std), the summary in the helper's\n                format (/o/std.tsv) and the report (/o/std.report.edn); amd64 and arm64 at once\n    goroot      the two conversions assembled (each package's other and embedded files copied\n                from GOROOT/src, the packages left out dropped, the headers their assembly\n                includes from outside them), merged into one tree (the files both convert alike\n                once, the others under arch/ARCH/go) and GOROOT/src's module files added, by\n                (goroot ...) below: bin/tamago-vendor's assemble, headers and merge_trees\n\n  opts: :host (Arbace's image, a hash or a ref; by default arbace.<the guest's arch>), :jobs\n  (the reader's threads in each read, by default 8), :cpus (each read's vCPUs, by default twice\n  :jobs: GPS54), :packages (import paths or patterns read instead of std: their forms only, no\n  tree assembled; by default [\"std\"]),\n  :ram (each read's guest, by default 16 GiB), :serial (the two reads one after the other), :pin\n  (the SHA-256 of GOROOT/src but src/cmd as bin/tamago-vendor pins it: checked first), :run,\n  :log, :cache (arbace.box.build's).\n\n  Natively (or in a guest whose trees are mounted), the file steps of bin/tamago-vendor:\n\n    (assemble forms orig dst ok prefix)   assemble's: FORMS/go into DST/go, packages kept and\n                                          their files copied from ORIG\n    (headers src dst)                     headers'\n    (merge-trees a b dst)                 merge_trees'\n    (goroot src reads out)                bin/tamago-vendor convert's goroot part: reads {ARCH\n                                          DIR} (each DIR/std, DIR/std.tsv) into OUT/goroot\n    (src-digest dir)                      the digest bin/tamago-vendor pins (sha256sum of the\n                                          sorted files of dir but cmd/, then of that)\n\n    arbace -m arbace.box.convert goroot SRC OUT ARCH=DIR...   (goroot ...) in a guest; also the\n      verbs assemble FORMS ORIG DST [OK-FILE [PREFIX]], headers SRC DST, merge A B DST (the file\n      steps, bin/tamago-vendor's since GP8) and digest DIRv11,arbace.core7,ex-infov11,arbace.core5,assocR9,v11,arbace.core5,flushv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*v11,arbace.core5,applyv11,arbace.core7,printlnv11,arbace.core6,reducev11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv18,arbace.box.convert11,delete-treev11,arbace.core10,chunk-restv11,arbace.core4,nextv11,arbace.core10,make-arrayC24,java.nio.file.OpenOptionl0,v18,arbace.box.convert9,copy-treev18,arbace.box.convert9,copy-filev11,arbace.core6,mapcatv11,arbace.core6,empty?v11,arbace.core4,sortv11,arbace.core4,consv18,arbace.box.convert10,dirs-underv11,arbace.core3,strv11,arbace.core4,not=v11,arbace.core4,peekv11,arbace.core3,popR10,v13,arbace.string5,splitp1,/v13,arbace.string4,joinv11,arbace.core4,subsv13,arbace.string9,includes?v18,arbace.box.convert12,package-markv11,arbace.core3,mapv11,arbace.core6,secondv11,arbace.core6,re-seqp12,\\\"([^\\\"]+)\\\"v11,arbace.core7,re-findv11,arbace.core10,re-patternv11,arbace.core3,vecv18,arbace.box.convert6,quotedp23,\\n\\(load \\\"([^\\\"]+)\\\"\\)p22,\\n  :path \\\"([^\\\"]+)\\\"v18,arbace.box.convert4,filev11,arbace.core4,atomm8,R11,l0,R12,l0,R13,l0,R14,l0,v18,arbace.box.convert11,files-underv13,arbace.string10,ends-with?v18,arbace.box.convert9,read-textv18,arbace.box.convert13,package-file?v11,arbace.core7,sort-byv11,arbace.core8,to-arrayR11,R12,R13,R14,v18,arbace.box.convert4,notev11,arbace.core6,formatv18,arbace.box.convert7,path-ofp23,\\n  :files \\[([^\\]]*)\\]v13,arbace.string6,blank?v11,arbace.core3,notv11,arbace.core9,contains?v11,arbace.core5,swap!v11,arbace.core6,updatev11,arbace.core3,incv13,arbace.string12,starts-with?p32,(?d)\\n  :embed-files \\[(.*?)\\]\\np32,\\[\\\"([^\\\"]+)\\\" \\\"([0-9a-f]+)\\\"\\]v18,arbace.box.convert8,loads-ofv18,arbace.box.convert7,list-ofv18,arbace.box.convert10,sha256-hexv18,arbace.box.convert4,failR15,R16,v11,arbace.core4,intov11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,restv11,arbace.core6,concatv11,arbace.core10,sorted-setp27,(?md)^#include \\\"([^\\\"]+)\\\"v18,arbace.box.convert5,cleanv18,arbace.box.convert7,dirnamev11,arbace.core6,removev11,arbace.core4,nil?v11,arbace.core8,distinctv11,arbace.core4,lastp1,/v11,arbace.core10,re-matcherp41,\\n\\(go/package [^\\n]*\\n  :path \\\"[^\\\"]+\\\"v11,arbace.core7,filtervp42,^  :(config|init-order|files|other-files) p2,\\nl-1,v11,arbace.core3,setm6,R17,l0,R18,l0,R19,l0,v18,arbace.box.convert10,write-textV2,s2,gos4,archR17,R18,R19,v18,arbace.box.convert13,merge-packagev18,arbace.box.convert6,archesv18,arbace.box.convert11,merge-treesV3,s6,go.mods6,go.sums18,vendor/modules.txtv11,arbace.core6,filterR20,v13,arbace.string11,split-linesR21,v18,arbace.box.convert8,left-outp2,\\tv18,arbace.box.convert7,headersv18,arbace.box.convert8,assemblel2,R22,v18,arbace.box.convert10,tree-filesv10,arbace.box4,treev11,arbace.core7,string?v11,arbace.core10,re-matchesp12,[0-9a-f]{64}v10,arbace.box3,refR23,v11,arbace.core6,pr-strv10,arbace.box8,tree-getv18,arbace.box.convert6,dir-atR24,v10,arbace.box8,put-treep1,/V4,s3,asts6,parsers7,scanners5,tokenv18,arbace.box.convert7,hash-ofR25,v18,arbace.box.convert7,arch-ofR26,v11,arbace.core11,select-keysV3,R27,R26,R28,v16,arbace.box.build6,actionv18,arbace.box.convert7,dir-at!v18,arbace.box.convert11,tree-digestR29,R30,R31,V1,s3,stdv18,arbace.box.convert12,select-pathsV2,s6,arbaces2,gov18,arbace.box.convert12,parser-formsR32,R33,R34,R35,R36,R37,R38,R39,R40,v18,arbace.box.convert3,GiBv10,arbace.box8,put-filev18,arbace.box.convert9,spec-textv10,arbace.box3,getR41,p29,^std: |^the dumper|^convertedR42,v11,arbace.core11,future-callR43,R44,R45,R46,V1,s3,stdv11,arbace.core5,mergeR47,R48,R49,R50,R51,l8,V1,s3,stdV6,s6,arbaces2,-ms18,arbace.box.converts6,goroots6,/g/srcs2,/oV1,s14,ARBACE_PATH=/sV1,s6,arbacel1,v10,arbace.box4,ref!p3,\\s+v18,arbace.box.convert10,src-digestv18,arbace.box.convert6,gorootv18,arbace.box.convert5,main*v11,arbace.core15,shutdown-agents")

var Lit_1 *jrt.String = jrt.Intern("os.arch")

var Lit_2 *jrt.String = jrt.Intern("arm64")

var Lit_3 *jrt.String = jrt.Intern("aarch64")

var Lit_4 *jrt.String = jrt.Intern("amd64")

var Lit_5 *jrt.String = jrt.Intern("go")

var Lit_6 *jrt.String = jrt.Intern("/")

var Lit_7 *jrt.String = jrt.Intern(".ae")

var Lit_8 *jrt.String = jrt.Intern("other-files")

var Lit_9 *jrt.String = jrt.Intern("embedded file ")

var Lit_10 *jrt.String = jrt.Intern(" of ")

var Lit_11 *jrt.String = jrt.Intern(": not the hash the forms record")

var Lit_12 *jrt.String = jrt.Intern("arbace.box.convert$assemble$fn__961000114")

var Lit_13 *jrt.String = jrt.Intern("arbace.box.convert$assemble$fn__961000116")

var Lit_14 *jrt.String = jrt.Intern("%s: %d packages (%d left out), %d other files, %d embedded files")

var Lit_15 *jrt.String = jrt.Intern("arbace.box.convert$clean$fn__961000043")

var Lit_16 *jrt.String = jrt.Intern(".")

var Lit_17 *jrt.String = jrt.Intern("")

var Lit_18 *jrt.String = jrt.Intern("..")

var Lit_19 *jrt.String = jrt.Intern(": no directory ")

var Lit_20 *jrt.String = jrt.Intern("arbace.box.convert$dirs_under$fn__961000035")

var Lit_21 *jrt.String = jrt.Intern("java.io.File")

var Lit_22 *jrt.String = jrt.Intern("java.nio.charset.StandardCharsets")

var Lit_23 *jrt.String = jrt.Intern("java.nio.file.Files")

var Lit_24 *jrt.String = jrt.Intern("java.security.MessageDigest")

var Lit_25 *jrt.String = jrt.Intern("arbace.box.convert: ")

var Lit_26 *jrt.String = jrt.Intern("arbace.box.convert$file$fn__961000014")

var Lit_27 *jrt.String = jrt.Intern("arbace.box.convert$files_under$walk__961000030")

var Lit_28 *jrt.String = jrt.Intern("arbace.box.convert$files_under$walk__961000030$fn__961000031")

var Lit_29 *jrt.String = jrt.Intern("arbace.box.convert$fn__961000329$iter__961000323__961000330")

var Lit_30 *jrt.String = jrt.Intern("arbace.box.convert$fn__961000329$iter__961000323__961000330$fn__961000331")

var Lit_31 *jrt.String = jrt.Intern("arbace.box.convert$fn__961000329$iter__961000323__961000330$fn__961000331$iter__961000325__961000332")

var Lit_32 *jrt.String = jrt.Intern("arbace.box.convert$fn__961000329$iter__961000323__961000330$fn__961000331$iter__961000325__961000332$fn__961000333")

var Lit_33 *jrt.String = jrt.Intern("arbace.box.convert$fn__961000329$iter__961000323__961000330$fn__961000331$iter__961000325__961000332$fn__961000333$fn__961000334")

var Lit_34 *jrt.String = jrt.Intern("tamago/goroot/go/go/")

var Lit_35 *jrt.String = jrt.Intern("/work")

var Lit_36 *jrt.String = jrt.Intern("/goroot")

var Lit_37 *jrt.String = jrt.Intern("no read for ")

var Lit_38 *jrt.String = jrt.Intern("std.tsv")

var Lit_39 *jrt.String = jrt.Intern("arbace.box.convert$goroot$fn__961000227")

var Lit_40 *jrt.String = jrt.Intern("std ")

var Lit_41 *jrt.String = jrt.Intern(": packages failed to read without errors: ")

var Lit_42 *jrt.String = jrt.Intern("arbace.box.convert$goroot$fn__961000229")

var Lit_43 *jrt.String = jrt.Intern("/arch-")

var Lit_44 *jrt.String = jrt.Intern("/std")

var Lit_45 *jrt.String = jrt.Intern("arbace.box.convert$goroot$fn__961000231")

var Lit_46 *jrt.String = jrt.Intern("arbace.box.convert$goroot$fn__961000233")

var Lit_47 *jrt.String = jrt.Intern("src")

var Lit_48 *jrt.String = jrt.Intern("vendor")

var Lit_49 *jrt.String = jrt.Intern("/arch-amd64/goroot")

var Lit_50 *jrt.String = jrt.Intern("/arch-arm64/goroot")

var Lit_51 *jrt.String = jrt.Intern("arch-")

var Lit_52 *jrt.String = jrt.Intern("goroot")

var Lit_53 *jrt.String = jrt.Intern("converted into %s: %d forms files, %d files")

var Lit_54 *jrt.String = jrt.Intern("arbace.box.convert$goroot$fn__961000243")

var Lit_55 *jrt.String = jrt.Intern("ok\t")

var Lit_56 *jrt.String = jrt.Intern("no ref ")

var Lit_57 *jrt.String = jrt.Intern(" (")

var Lit_58 *jrt.String = jrt.Intern(")")

var Lit_59 *jrt.String = jrt.Intern("not a hash or a ref: ")

var Lit_60 *jrt.String = jrt.Intern("arbace.box.convert$headers$iter__961000121__961000125")

var Lit_61 *jrt.String = jrt.Intern("arbace.box.convert$headers$iter__961000131__961000137")

var Lit_62 *jrt.String = jrt.Intern("%s/src: %d headers included from outside the packages: %s")

var Lit_63 *jrt.String = jrt.Intern(" ")

var Lit_64 *jrt.String = jrt.Intern("arbace.box.convert$headers$fn__961000157")

var Lit_65 *jrt.String = jrt.Intern("arbace.box.convert$headers$iter__961000121__961000125$fn__961000126")

var Lit_66 *jrt.String = jrt.Intern("arbace.box.convert$headers$iter__961000121__961000125$fn__961000126$fn__961000127")

var Lit_67 *jrt.String = jrt.Intern("arbace.box.convert$headers$iter__961000131__961000137$fn__961000138")

var Lit_68 *jrt.String = jrt.Intern("arbace.box.convert$headers$iter__961000131__961000137$fn__961000138$iter__961000133__961000142")

var Lit_69 *jrt.String = jrt.Intern("arbace.box.convert$headers$iter__961000131__961000137$fn__961000138$iter__961000133__961000142$fn__961000143")

var Lit_70 *jrt.String = jrt.Intern("arbace.box.convert$headers$iter__961000131__961000137$fn__961000138$iter__961000133__961000142$fn__961000143$fn__961000144")

var Lit_71 *jrt.String = jrt.Intern(".s")

var Lit_72 *jrt.String = jrt.Intern(".h")

var Lit_73 *jrt.String = jrt.Intern("\n  :")

var Lit_74 *jrt.String = jrt.Intern(" \\[([^\\]]*)\\]")

var Lit_75 *jrt.String = jrt.Intern("assemble")

var Lit_76 *jrt.String = jrt.Intern("digest")

var Lit_77 *jrt.String = jrt.Intern("headers")

var Lit_78 *jrt.String = jrt.Intern("merge")

var Lit_79 *jrt.String = jrt.Intern("arbace.box.convert$main_STAR_$iter__961000435__961000439")

var Lit_80 *jrt.String = jrt.Intern("usage: goroot SRC OUT ARCH=DIR... | assemble FORMS ORIG DST [OK-FILE [PREFIX]] | headers SRC DST")

var Lit_81 *jrt.String = jrt.Intern(" | merge A B DST | digest DIR, not ")

var Lit_82 *jrt.String = jrt.Intern("arbace.box.convert$main_STAR_$iter__961000435__961000439$fn__961000440")

var Lit_83 *jrt.String = jrt.Intern("arbace.box.convert$main_STAR_$iter__961000435__961000439$fn__961000440$fn__961000441")

var Lit_84 *jrt.String = jrt.Intern("=")

var Lit_85 *jrt.String = jrt.Intern("arbace.box.convert$merge_package$fn__961000174")

var Lit_86 *jrt.String = jrt.Intern("arbace.box.convert$merge_package$fn__961000176")

var Lit_87 *jrt.String = jrt.Intern("arbace.box.convert$merge_package$fn__961000178")

var Lit_88 *jrt.String = jrt.Intern("arbace.box.convert$merge_package$iter__961000180__961000184")

var Lit_89 *jrt.String = jrt.Intern("merge: ")

var Lit_90 *jrt.String = jrt.Intern(": the package files differ beyond their files and configuration")

var Lit_91 *jrt.String = jrt.Intern(": unexpected package file")

var Lit_92 *jrt.String = jrt.Intern("\n  :files [")

var Lit_93 *jrt.String = jrt.Intern("]")

var Lit_94 *jrt.String = jrt.Intern("\n\n")

var Lit_95 *jrt.String = jrt.Intern("arbace.box.convert$merge_package$fn__961000194")

var Lit_96 *jrt.String = jrt.Intern("\n  :other-files [")

var Lit_97 *jrt.String = jrt.Intern("arbace.box.convert$merge_package$fn__961000196")

var Lit_98 *jrt.String = jrt.Intern("arbace.box.convert$merge_package$fn__961000198")

var Lit_99 *jrt.String = jrt.Intern("arbace.box.convert$merge_package$fn__961000200")

var Lit_100 *jrt.String = jrt.Intern("files")

var Lit_101 *jrt.String = jrt.Intern(".go")

var Lit_102 *jrt.String = jrt.Intern("\"")

var Lit_103 *jrt.String = jrt.Intern("\n")

var Lit_104 *jrt.String = jrt.Intern("(load \"")

var Lit_105 *jrt.String = jrt.Intern("\")\n")

var Lit_106 *jrt.String = jrt.Intern("arbace.box.convert$merge_package$iter__961000180__961000184$fn__961000185")

var Lit_107 *jrt.String = jrt.Intern("arbace.box.convert$merge_package$iter__961000180__961000184$fn__961000185$fn__961000186")

var Lit_108 *jrt.String = jrt.Intern("\n\n(load ")

var Lit_109 *jrt.String = jrt.Intern("arbace.box.convert$merge_package$iter__961000180__961000184$fn__961000185$fn__961000190")

var Lit_110 *jrt.String = jrt.Intern("arbace.box.convert$merge_package$iter__961000180__961000184$fn__961000185$fn__961000186$fn__961000187")

var Lit_111 *jrt.String = jrt.Intern("  :")

var Lit_112 *jrt.String = jrt.Intern("arbace.box.convert$merge_trees$put__961000207")

var Lit_113 *jrt.String = jrt.Intern("arch/amd64/go")

var Lit_114 *jrt.String = jrt.Intern("arch/arm64/go")

var Lit_115 *jrt.String = jrt.Intern(" differs by architecture")

var Lit_116 *jrt.String = jrt.Intern("%s: %d package files merged, %d files once, %d per architecture (arch/ARCH/go)")

var Lit_117 *jrt.String = jrt.Intern("arbace.box.convert$select_paths$fn__961000311")

var Lit_118 *jrt.String = jrt.Intern("no ")

var Lit_119 *jrt.String = jrt.Intern(" in the sources")

var Lit_120 *jrt.String = jrt.Intern("arbace.box.convert$select_paths$fn__961000311$put_at__961000313")

var Lit_121 *jrt.String = jrt.Intern("SHA-256")

var Lit_122 *jrt.String = jrt.Intern("{:name \"std\"\n :loads [{:goroot \"/g\" :goos \"tamago\" :goarch \"")

var Lit_123 *jrt.String = jrt.Intern("\" :mode :packages :cwd \"/\" :args [")

var Lit_124 *jrt.String = jrt.Intern("]}]}\n")

var Lit_125 *jrt.String = jrt.Intern("arbace.box.convert$spec_text$fn__961000344")

var Lit_126 *jrt.String = jrt.Intern("arbace.box.convert$src_digest$iter__961000248__961000252")

var Lit_127 *jrt.String = jrt.Intern("arbace.box.convert$src_digest$fn__961000258")

var Lit_128 *jrt.String = jrt.Intern("arbace.box.convert$src_digest$fn__961000260")

var Lit_129 *jrt.String = jrt.Intern("./")

var Lit_130 *jrt.String = jrt.Intern("cmd/")

var Lit_131 *jrt.String = jrt.Intern("arbace.box.convert$src_digest$iter__961000248__961000252$fn__961000253")

var Lit_132 *jrt.String = jrt.Intern("arbace.box.convert$src_digest$iter__961000248__961000252$fn__961000253$fn__961000254")

var Lit_133 *jrt.String = jrt.Intern("  ")

var Lit_134 *jrt.String = jrt.Intern("the sources")

var Lit_135 *jrt.String = jrt.Intern("GOROOT's text")

var Lit_136 *jrt.String = jrt.Intern("arbace.")

var Lit_137 *jrt.String = jrt.Intern("Arbace's image")

var Lit_138 *jrt.String = jrt.Intern("arbace.box.convert$steps$run__961000347")

var Lit_139 *jrt.String = jrt.Intern("arbace.box.convert$steps$secs__961000349")

var Lit_140 *jrt.String = jrt.Intern("GOROOT/src is not the pinned tree (digest ")

var Lit_141 *jrt.String = jrt.Intern(", pinned ")

var Lit_142 *jrt.String = jrt.Intern("convert: GOROOT/src ")

var Lit_143 *jrt.String = jrt.Intern(", digest ")

var Lit_144 *jrt.String = jrt.Intern(" (the pin)")

var Lit_145 *jrt.String = jrt.Intern("std")

var Lit_146 *jrt.String = jrt.Intern(" packages")

var Lit_147 *jrt.String = jrt.Intern("arbace.box.convert$steps$read_arch__961000351")

var Lit_148 *jrt.String = jrt.Intern("arbace.box.convert$steps$iter__961000357__961000361")

var Lit_149 *jrt.String = jrt.Intern("arbace.box.convert$steps$iter__961000367__961000371")

var Lit_150 *jrt.String = jrt.Intern("arbace.box.convert$steps$iter__961000381__961000385")

var Lit_151 *jrt.String = jrt.Intern("convert: ")

var Lit_152 *jrt.String = jrt.Intern(" read for both architectures in ")

var Lit_153 *jrt.String = jrt.Intern("assemble and merge tamago/goroot")

var Lit_154 *jrt.String = jrt.Intern("arbace.box.convert$steps$iter__961000397__961000401")

var Lit_155 *jrt.String = jrt.Intern("/s")

var Lit_156 *jrt.String = jrt.Intern("/g")

var Lit_157 *jrt.String = jrt.Intern("arbace.box.convert$steps$iter__961000407__961000411")

var Lit_158 *jrt.String = jrt.Intern("/o")

var Lit_159 *jrt.String = jrt.Intern("goroot: no output tree")

var Lit_160 *jrt.String = jrt.Intern("convert: assembled and merged: %s (%.1f s; %s)")

var Lit_161 *jrt.String = jrt.Intern("tamago/goroot")

var Lit_162 *jrt.String = jrt.Intern("convert: tamago/goroot converted in ")

var Lit_163 *jrt.String = jrt.Intern(": ")

var Lit_164 *jrt.String = jrt.Intern(" (the sources hold no tamago/goroot)")

var Lit_165 *jrt.String = jrt.Intern(" = the sources' tamago/goroot, byte for byte")

var Lit_166 *jrt.String = jrt.Intern(" DIFFERS from the sources' tamago/goroot ")

var Lit_167 *jrt.String = jrt.Intern("arbace.box.convert$steps$iter__961000357__961000361$fn__961000362")

var Lit_168 *jrt.String = jrt.Intern("arbace.box.convert$steps$iter__961000357__961000361$fn__961000362$fn__961000363")

var Lit_169 *jrt.String = jrt.Intern("arbace.box.convert$steps$iter__961000367__961000371$fn__961000372")

var Lit_170 *jrt.String = jrt.Intern("arbace.box.convert$steps$iter__961000367__961000371$fn__961000372$fn__961000373")

var Lit_171 *jrt.String = jrt.Intern("arbace.box.convert$steps$iter__961000367__961000371$fn__961000372$fn__961000377")

var Lit_172 *jrt.String = jrt.Intern("arbace.box.convert$steps$iter__961000367__961000371$fn__961000372$fn__961000373$fn__961000374")

var Lit_173 *jrt.String = jrt.Intern("arbace.box.convert$steps$iter__961000381__961000385$fn__961000386")

var Lit_174 *jrt.String = jrt.Intern("arbace.box.convert$steps$iter__961000381__961000385$fn__961000386$fn__961000387")

var Lit_175 *jrt.String = jrt.Intern("arbace.box.convert$steps$iter__961000397__961000401$fn__961000402")

var Lit_176 *jrt.String = jrt.Intern("arbace.box.convert$steps$iter__961000397__961000401$fn__961000402$fn__961000403")

var Lit_177 *jrt.String = jrt.Intern("=/r/")

var Lit_178 *jrt.String = jrt.Intern("arbace.box.convert$steps$iter__961000407__961000411$fn__961000412")

var Lit_179 *jrt.String = jrt.Intern("arbace.box.convert$steps$iter__961000407__961000411$fn__961000412$fn__961000413")

var Lit_180 *jrt.String = jrt.Intern("/r/")

var Lit_181 *jrt.String = jrt.Intern("read ")

var Lit_182 *jrt.String = jrt.Intern(" for tamago/")

var Lit_183 *jrt.String = jrt.Intern("arbace")

var Lit_184 *jrt.String = jrt.Intern("-m")

var Lit_185 *jrt.String = jrt.Intern("arbace.repr.go.annotate")

var Lit_186 *jrt.String = jrt.Intern("read")

var Lit_187 *jrt.String = jrt.Intern("--jobs")

var Lit_188 *jrt.String = jrt.Intern("--out")

var Lit_189 *jrt.String = jrt.Intern("/o/std")

var Lit_190 *jrt.String = jrt.Intern("--quiet")

var Lit_191 *jrt.String = jrt.Intern("--report")

var Lit_192 *jrt.String = jrt.Intern("/o/std.report.edn")

var Lit_193 *jrt.String = jrt.Intern("--tsv")

var Lit_194 *jrt.String = jrt.Intern("/o/std.tsv")

var Lit_195 *jrt.String = jrt.Intern("/c/spec.edn")

var Lit_196 *jrt.String = jrt.Intern("ARBACE_PATH=/s")

var Lit_197 *jrt.String = jrt.Intern("GOGC=200")

var Lit_198 *jrt.String = jrt.Intern("GOMEMLIMIT=")

var Lit_199 *jrt.String = jrt.Intern("MiB")

var Lit_200 *jrt.String = jrt.Intern("/c")

var Lit_201 *jrt.String = jrt.Intern("spec.edn")

var Lit_202 *jrt.String = jrt.Intern(": no output tree")

var Lit_203 *jrt.String = jrt.Intern("convert: read %s for tamago/%s: %s, the forms %s (%.1f s; %s)")

var Lit_204 *jrt.String = jrt.Intern("%.1f s")

var Lit_205 *jrt.String = jrt.Intern("arbace.box.convert$tree_digest$iter__961000274__961000278")

var Lit_206 *jrt.String = jrt.Intern("arbace.box.convert$tree_digest$fn__961000297")

var Lit_207 *jrt.String = jrt.Intern("arbace.box.convert$tree_digest$fn__961000302")

var Lit_208 *jrt.String = jrt.Intern("arbace.box.convert$tree_digest$iter__961000274__961000278$fn__961000279")

var Lit_209 *jrt.String = jrt.Intern("arbace.box.convert$tree_digest$iter__961000274__961000278$fn__961000279$fn__961000280")

var Lit_210 *jrt.String = jrt.Intern("arbace.box.convert$tree_files$fn__961000264")

var Lit_211 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn3,msgyn4,datayn1,&yn2,xskn3,tagyn6,Stringyn4,moreyn12,java.io.Fileyn4,Fileyn16,java.lang.Stringyn5,bytesyn2,okyn6,prefixyn3,relyn2,sayn2,sbyn5,readsyn1,hyn1,xyn4,whatyn1,tyn1,pyn2,psyn4,archyn8,packagesyn3,srcyn4,textyn4,optsyn3,cmdyn4,argsv11,arbace.core5,in-nsMyn18,arbace.box.convertm2,R0,s3145,tamago/goroot converted in the box, as bin/tamago-vendor convert converts it on the host.\n\n    (steps src text opts)   the conversion of the GOROOT text tree text (TamaGo's VERSION and\n                            src/ but src/cmd, a hash or a ref) with the sources of tree src (a\n                            hash or a ref: arbace/, go/ and the forms of go/parser's packages\n                            under tamago/goroot, which the reader's forms check compares the\n                            compiled parser with): a map of every step's result, :goroot the\n                            converted tree (bin/tamago-vendor convert's OUT/goroot), :expected\n                            src's tamago/goroot, :equal whether they are the same tree\n\n  The steps, each an action (arbace.box.build/action: a spawned guest of Arbace's image, its\n  result in the action cache):\n    read ARCH   std for tamago/ARCH, by arbace.repr.go.annotate -main read (bin/repr-go read\n                --corpus ARCH's native read): the forms (/o/std), the summary in the helper's\n                format (/o/std.tsv) and the report (/o/std.report.edn); amd64 and arm64 at once\n    goroot      the two conversions assembled (each package's other and embedded files copied\n                from GOROOT/src, the packages left out dropped, the headers their assembly\n                includes from outside them), merged into one tree (the files both convert alike\n                once, the others under arch/ARCH/go) and GOROOT/src's module files added, by\n                (goroot ...) below: bin/tamago-vendor's assemble, headers and merge_trees\n\n  opts: :host (Arbace's image, a hash or a ref; by default arbace.<the guest's arch>), :jobs\n  (the reader's threads in each read, by default 8), :cpus (each read's vCPUs, by default twice\n  :jobs: GPS54), :packages (import paths or patterns read instead of std: their forms only, no\n  tree assembled; by default [\"std\"]),\n  :ram (each read's guest, by default 16 GiB), :serial (the two reads one after the other), :pin\n  (the SHA-256 of GOROOT/src but src/cmd as bin/tamago-vendor pins it: checked first), :run,\n  :log, :cache (arbace.box.build's).\n\n  Natively (or in a guest whose trees are mounted), the file steps of bin/tamago-vendor:\n\n    (assemble forms orig dst ok prefix)   assemble's: FORMS/go into DST/go, packages kept and\n                                          their files copied from ORIG\n    (headers src dst)                     headers'\n    (merge-trees a b dst)                 merge_trees'\n    (goroot src reads out)                bin/tamago-vendor convert's goroot part: reads {ARCH\n                                          DIR} (each DIR/std, DIR/std.tsv) into OUT/goroot\n    (src-digest dir)                      the digest bin/tamago-vendor pins (sha256sum of the\n                                          sorted files of dir but cmd/, then of that)\n\n    arbace -m arbace.box.convert goroot SRC OUT ARCH=DIR...   (goroot ...) in a guest; also the\n      verbs assemble FORMS ORIG DST [OK-FILE [PREFIX]], headers SRC DST, merge A B DST (the file\n      steps, bin/tamago-vendor's since GP8) and digest DIRm2,R0,s3145,tamago/goroot converted in the box, as bin/tamago-vendor convert converts it on the host.\n\n    (steps src text opts)   the conversion of the GOROOT text tree text (TamaGo's VERSION and\n                            src/ but src/cmd, a hash or a ref) with the sources of tree src (a\n                            hash or a ref: arbace/, go/ and the forms of go/parser's packages\n                            under tamago/goroot, which the reader's forms check compares the\n                            compiled parser with): a map of every step's result, :goroot the\n                            converted tree (bin/tamago-vendor convert's OUT/goroot), :expected\n                            src's tamago/goroot, :equal whether they are the same tree\n\n  The steps, each an action (arbace.box.build/action: a spawned guest of Arbace's image, its\n  result in the action cache):\n    read ARCH   std for tamago/ARCH, by arbace.repr.go.annotate -main read (bin/repr-go read\n                --corpus ARCH's native read): the forms (/o/std), the summary in the helper's\n                format (/o/std.tsv) and the report (/o/std.report.edn); amd64 and arm64 at once\n    goroot      the two conversions assembled (each package's other and embedded files copied\n                from GOROOT/src, the packages left out dropped, the headers their assembly\n                includes from outside them), merged into one tree (the files both convert alike\n                once, the others under arch/ARCH/go) and GOROOT/src's module files added, by\n                (goroot ...) below: bin/tamago-vendor's assemble, headers and merge_trees\n\n  opts: :host (Arbace's image, a hash or a ref; by default arbace.<the guest's arch>), :jobs\n  (the reader's threads in each read, by default 8), :cpus (each read's vCPUs, by default twice\n  :jobs: GPS54), :packages (import paths or patterns read instead of std: their forms only, no\n  tree assembled; by default [\"std\"]),\n  :ram (each read's guest, by default 16 GiB), :serial (the two reads one after the other), :pin\n  (the SHA-256 of GOROOT/src but src/cmd as bin/tamago-vendor pins it: checked first), :run,\n  :log, :cache (arbace.box.build's).\n\n  Natively (or in a guest whose trees are mounted), the file steps of bin/tamago-vendor:\n\n    (assemble forms orig dst ok prefix)   assemble's: FORMS/go into DST/go, packages kept and\n                                          their files copied from ORIG\n    (headers src dst)                     headers'\n    (merge-trees a b dst)                 merge_trees'\n    (goroot src reads out)                bin/tamago-vendor convert's goroot part: reads {ARCH\n                                          DIR} (each DIR/std, DIR/std.tsv) into OUT/goroot\n    (src-digest dir)                      the digest bin/tamago-vendor pins (sha256sum of the\n                                          sorted files of dir but cmd/, then of that)\n\n    arbace -m arbace.box.convert goroot SRC OUT ARCH=DIR...   (goroot ...) in a guest; also the\n      verbs assemble FORMS ORIG DST [OK-FILE [PREFIX]], headers SRC DST, merge A B DST (the file\n      steps, bin/tamago-vendor's since GP8) and digest DIRR1,v18,arbace.box.convert3,GiBm8,R2,TR3,i58,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert4,failm10,R2,TR6,L1,V2,R7,R8,R3,i60,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert4,notem10,R2,TR6,L1,V2,R9,R10,R3,i63,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert4,filem10,R2,TR6,L1,MV3,Myn1,pm2,R11,R12,R9,R13,m2,R11,R14,R3,i69,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert11,delete-treem10,R2,TR6,L1,V1,Myn1,fm2,R11,R15,R3,i71,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert9,copy-filem12,R2,TR6,L1,V2,Myn1,fm2,R11,R15,Myn1,tm2,R11,R15,R0,s83,f's bytes into t, its directory made (shutil.copyfile: the contents, not the mode).R3,i76,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert9,copy-treem12,R2,TR6,L1,V2,Myn1,sm2,R11,R15,Myn1,dm2,R11,R15,R0,s46,Directory s copied into d (made), recursively.R3,i82,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert9,read-textm10,R2,TR6,L1,MV1,Myn1,fm2,R11,R15,m2,R11,R16,R3,i90,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert10,write-textm10,R2,TR6,L1,V2,Myn1,fm2,R11,R15,Myn1,sm2,R11,R12,R3,i92,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert11,files-underm12,R2,TR6,L1,V1,Myn1,dm2,R11,R15,R0,s76,The files under directory d, recursively: their paths relative to d, sorted.R3,i96,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert10,dirs-underm12,R2,TR6,L1,V1,Myn1,dm2,R11,R15,R0,s51,Directory d and the directories under it, as Files.R3,i106,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert10,sha256-hexm10,R2,TR6,L1,MV1,Myn1,bm2,R11,R17,m2,R11,R16,R3,i111,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert5,cleanm12,R2,TR6,L1,MV1,Myn1,pm2,R11,R12,m2,R11,R16,R0,s48,os.path.normpath of a relative /-separated path.R3,i120,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert7,dirnamem10,R2,TR6,L1,MV1,Myn1,pm2,R11,R12,m2,R11,R16,R3,i130,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert12,package-markm8,R2,TR3,i136,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert13,package-file?m10,R2,TR6,L1,V1,Myn1,sm2,R11,R12,R3,i138,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert6,quotedm10,R2,TR6,L1,V1,Myn1,sm2,R11,R12,R3,i140,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert7,list-ofm12,R2,TR6,L1,V2,Myn1,sm2,R11,R12,Myn1,km2,R11,R12,R0,s67,The strings of the package file's vector :key, [] when it has none.R3,i142,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert8,loads-ofm10,R2,TR6,L1,V1,Myn1,sm2,R11,R12,R3,i147,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert7,path-ofm10,R2,TR6,L1,V1,Myn1,sm2,R11,R12,R3,i149,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert8,assemblem10,R6,L1,V5,Myn5,formsm2,R11,R12,Myn4,origm2,R11,R12,Myn3,dstm2,R11,R12,R18,R19,R0,s470,bin/tamago-vendor's assemble: the converter's tree forms/go into dst/go, without the package\n  files whose :files is empty or whose path is not in ok (a set of import paths; nil: all) and\n  the files they load; each kept package's :other-files and :embed-files copied from orig (its\n  directory there: the import path, prefix and a / stripped when it begins so) into its forms\n  directory, the embedded files checked against their hashes. Directories left empty removed.R3,i154,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert7,headersm10,R6,L1,V2,Myn3,srcm2,R11,R12,Myn3,dstm2,R11,R12,R0,s249,bin/tamago-vendor's headers: the headers that the packages' assembly under dst/go includes\n  from outside their own files, copied from src (GOROOT/src) to dst/src at their paths, followed\n  through the headers they include. The paths copied, sorted.R3,i197,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert13,merge-packagem12,R2,TR6,L1,V3,R20,R21,R22,R0,s79,bin/tamago-vendor's merge_pkg: the package files sa and sb (either nil) as one.R3,i233,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert11,merge-treesm10,R6,L1,V3,Myn1,am2,R11,R12,Myn1,bm2,R11,R12,Myn3,dstm2,R11,R12,R0,s406,bin/tamago-vendor's merge_trees: the two architectures' assembled trees a/go (amd64's) and\n  b/go (arm64's) as one, dst/go: a file both convert alike once, a file one architecture only\n  builds as it is, the package files merged (merge-package), the files both build whose forms\n  differ (by the configuration's facts) each architecture's under dst/arch/ARCH/go; other files\n  once (they must be the same).R3,i260,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert8,left-outS2,s31,encoding/json/internal/jsontests26,internal/trace/traceviewerm8,R3,i291,R4,i1,R5,s21,arbace/box/convert.aeR0,s179,The two std packages bin/tamago-vendor leaves out: they embed third-party data, and only cmd/\n  or tests import them (internal/trace/traceviewer, encoding/json/internal/jsontest).v18,arbace.box.convert6,archesV2,s5,amd64s5,arm64m6,R3,i296,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert6,gorootm10,R6,L1,V3,Myn3,srcm2,R11,R12,R23,Myn3,outm2,R11,R12,R0,s360,bin/tamago-vendor convert's goroot part: the reads {ARCH DIR} (each the native read of std for\n  tamago/ARCH: DIR/std, its forms, and DIR/std.tsv, its summary) assembled against src\n  (GOROOT/src) in out/work, merged into out/goroot with GOROOT/src's module files and the headers\n  from outside the packages in out/goroot/src. The work directory removed after.R3,i298,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert10,src-digestm10,R6,L1,V1,Myn3,dirm2,R11,R12,R0,s164,bin/tamago-vendor's src_digest of directory dir (GOROOT/src): the SHA-256 of sha256sum's lines\n  (\"HASH  ./PATH\") of its files but those under cmd/, sorted by path.R3,i329,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert10,tree-filesm12,R2,TR6,L1,V2,R24,Myn6,prefixm2,R11,R12,R0,s59,The files of tree h: [[path entry] ...], paths /-separated.R3,i340,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert11,tree-digestm10,R6,L1,V1,R24,R0,s89,src-digest of the tree h (GOROOT/src) from the store: the files' hashes are their blobs'.R3,i348,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert7,hash-ofm10,R2,TR6,L1,V2,R25,R26,R3,i359,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert6,dir-atm10,R2,TR6,L1,V2,R27,Myn1,pm2,R11,R12,R3,i364,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert7,dir-at!m10,R2,TR6,L1,V3,R27,R28,R26,R3,i367,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert12,select-pathsm12,R2,TR6,L1,V2,R27,R29,R0,s90,The tree of t's entries at paths ps (\"a/b\", directories or files), their directories made.R3,i370,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert12,parser-formsv11,arbace.core3,vecm8,R3,i383,R4,i1,R5,s21,arbace/box/convert.aeR0,s213,The forms the reader's forms check reads (arbace.repr.go.parse/forms-check: go/parser's\n  packages' declarations counted, the dumper's files generated from go/ast's): the four packages\n  under tamago/goroot/go/go.v18,arbace.box.convert7,arch-ofm10,R2,TR6,L1,V0,R3,i391,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert9,spec-textm10,R2,TR6,L1,V2,R30,R31,R3,i394,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert5,stepsm10,R6,L1,V3,R32,R33,R34,R0,s119,The conversion of GOROOT text tree text with the sources src (see the namespace's doc): a map\n  of every step's result.R3,i398,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert5,main*m10,R6,L1,V2,R9,V3,R35,R9,R36,R0,s72,The verbs of -main (bin/tamago-vendor's file steps run them by -e): nil.R3,i468,R4,i1,R5,s21,arbace/box/convert.aev18,arbace.box.convert5,-mainm8,R6,L1,V2,R9,R36,R3,i485,R4,i1,R5,s21,arbace/box/convert.ae")

var Lit_212 *jrt.String = jrt.Intern("arbace.box.convert$eval961000004$loading__1927001464__auto____961000005")

var Lit_213 *jrt.String = jrt.Intern("arbace.box.convert$eval961000008$fn__961000009")

var Lit_214 *jrt.String = jrt.Intern("arbace.box.convert$fail")

var Lit_215 *jrt.String = jrt.Intern("arbace.box.convert$note")

var Lit_216 *jrt.String = jrt.Intern("arbace.box.convert$file")

var Lit_217 *jrt.String = jrt.Intern("arbace.box.convert$delete_tree")

var Lit_218 *jrt.String = jrt.Intern("arbace.box.convert$copy_file")

var Lit_219 *jrt.String = jrt.Intern("arbace.box.convert$copy_tree")

var Lit_220 *jrt.String = jrt.Intern("arbace.box.convert$read_text")

var Lit_221 *jrt.String = jrt.Intern("arbace.box.convert$write_text")

var Lit_222 *jrt.String = jrt.Intern("arbace.box.convert$files_under")

var Lit_223 *jrt.String = jrt.Intern("arbace.box.convert$dirs_under")

var Lit_224 *jrt.String = jrt.Intern("arbace.box.convert$sha256_hex")

var Lit_225 *jrt.String = jrt.Intern("arbace.box.convert$clean")

var Lit_226 *jrt.String = jrt.Intern("arbace.box.convert$dirname")

var Lit_227 *jrt.String = jrt.Intern("\n(go/package ")

var Lit_228 *jrt.String = jrt.Intern("arbace.box.convert$package_file_QMARK_")

var Lit_229 *jrt.String = jrt.Intern("arbace.box.convert$quoted")

var Lit_230 *jrt.String = jrt.Intern("arbace.box.convert$list_of")

var Lit_231 *jrt.String = jrt.Intern("arbace.box.convert$loads_of")

var Lit_232 *jrt.String = jrt.Intern("arbace.box.convert$path_of")

var Lit_233 *jrt.String = jrt.Intern("arbace.box.convert$assemble")

var Lit_234 *jrt.String = jrt.Intern("arbace.box.convert$headers")

var Lit_235 *jrt.String = jrt.Intern("arbace.box.convert$merge_package")

var Lit_236 *jrt.String = jrt.Intern("arbace.box.convert$merge_trees")

var Lit_237 *jrt.String = jrt.Intern("arbace.box.convert$goroot")

var Lit_238 *jrt.String = jrt.Intern("arbace.box.convert$src_digest")

var Lit_239 *jrt.String = jrt.Intern("arbace.box.convert$tree_files")

var Lit_240 *jrt.String = jrt.Intern("arbace.box.convert$tree_digest")

var Lit_241 *jrt.String = jrt.Intern("arbace.box.convert$hash_of")

var Lit_242 *jrt.String = jrt.Intern("arbace.box.convert$dir_at")

var Lit_243 *jrt.String = jrt.Intern("arbace.box.convert$dir_at_BANG_")

var Lit_244 *jrt.String = jrt.Intern("arbace.box.convert$select_paths")

var Lit_245 *jrt.String = jrt.Intern("arbace.box.convert$fn__961000329")

var Lit_246 *jrt.String = jrt.Intern("arbace.box.convert$arch_of")

var Lit_247 *jrt.String = jrt.Intern("arbace.box.convert$spec_text")

var Lit_248 *jrt.String = jrt.Intern("arbace.box.convert$steps")

var Lit_249 *jrt.String = jrt.Intern("arbace.box.convert$main_STAR_")

var Lit_250 *jrt.String = jrt.Intern("arbace.box.convert$_main")
