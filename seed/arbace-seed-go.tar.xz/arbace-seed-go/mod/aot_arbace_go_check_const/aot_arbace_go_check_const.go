//line aot_arbace_go_check_const.ae:1
package aot_arbace_go_check_const

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A_New() *A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_go_check_const_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_const_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_const_eval161000008_fn__161000009_A_New() *A_arbace_go_check_const_eval161000008_fn__161000009_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_eval161000008_fn__161000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_const_eval161000008_fn__161000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_const_eval161000008_fn__161000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_const_A_const_2.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_go_check_const_A_const_3.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_go_check_const_A_const_4; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_const_A_const_5.GetRawRoot__O(), A_arbace_go_check_const_A_const_6) }


















func A_arbace_go_check_const_bi_A_New() *A_arbace_go_check_const_bi_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bi_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_go_check_const_bi_A) Ctor() {}
//line :20:1
func (t *A_arbace_go_check_const_bi_A) Invoke_O_O__O(self, x__0 any) any {


	if jrt.BigInteger_InstanceOf(x__0) { return x__0 } else { var tmp1 bool; var or__1927000174__auto____2 bool = jrt.Long_InstanceOf(x__0)

		if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = jrt.Integer_InstanceOf(x__0); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 bool = jrt.Short_InstanceOf(x__0); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = jrt.Byte_InstanceOf(x__0) } } }
//line :23:1
		if tmp1 {

			return jrt.BigInteger_ValueOf_J__BigInteger(lang.RT_LongCast_O__J_NoInit(x__0)) } else {
//line :23:1
				if lang.BigInt_InstanceOf(x__0) {


					var root_15 any = A_arbace_go_check_const_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = x__0; if linked_16 == nil { return ifn_17.Invoke_O__O(arg_18) } else { return linked_16.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_15, arg_18) } } else {
//line :23:1
						if A_arbace_go_check_const_A_const_8 != nil { var tmp2 any; var root_19 any = A_arbace_go_check_const_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_21 lang.IFn



							if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil, Lit_2, nil); var tmp4 any = lang.IFn_Cast(A_arbace_go_check_const_A_const_10.GetRawRoot__O()).Invoke_O__O(x__0); var tmp5 any; var root_28 any = A_arbace_go_check_const_A_const_11.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = x__0; if linked_29 == nil { tmp5 = ifn_30.Invoke_O__O(arg_31) } else { tmp5 = linked_29.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_28, arg_31) }; arg_22 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp5)).Ref(); var arg_23 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_const_A_const_12, x__0)); if linked_20 == nil { tmp2 = ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { tmp2 = linked_20.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) }
//line :23:1
							panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) } else { return nil
							}
					}
			}
	}
}
func A_arbace_go_check_const_norm_int_A_New() *A_arbace_go_check_const_norm_int_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_norm_int_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_go_check_const_norm_int_A) Ctor() {}
//line :29:1
func (t *A_arbace_go_check_const_norm_int_A) Invoke_O_O__O(self, b__0 any) any {


	if lang.Numbers_Lt_J_J__Z_NoInit(int64(jrt.BigInteger_Cast(b__0).BitLength__I()), 64) { return jrt.Long_ValueOf_J__Long_NoInit(jrt.BigInteger_Cast(b__0).LongValue__J()).Ref() } else { var root_32 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = b__0; if linked_33 == nil { return ifn_34.Invoke_O__O(arg_35) } else { return linked_33.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_32, arg_35)
	} } }
func A_arbace_go_check_const_bit_len_A_New() *A_arbace_go_check_const_bit_len_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bit_len_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_go_check_const_bit_len_A) Ctor() {}
//line :34:1
func (t *A_arbace_go_check_const_bit_len_A) InvokePrim_O_O__J(self, x__0 any) int64 {


	var tmp1 any; var root_36 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, A_arbace_go_check_const_bi_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = x__0; if linked_37 == nil { tmp1 = ifn_38.Invoke_O__O(arg_39) } else { tmp1 = linked_37.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_36, arg_39) }; return lang.RT_LongCast_I__J_NoInit(jrt.BigInteger_Cast(tmp1).Abs__BigInteger().BitLength__I()) }
//line :34:1
func (t *A_arbace_go_check_const_bit_len_A) Invoke_O_O__O(self, x__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, x__0)).Ref() }






func A_arbace_go_check_const_pow2_A_New() *A_arbace_go_check_const_pow2_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_pow2_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_go_check_const_pow2_A) Ctor() {}
//line :41:1
func (t *A_arbace_go_check_const_pow2_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 jrt.BigInteger_I; jrt.BigInteger_Init(); tmp1 = jrt.BigInteger_ONE; var tmp2 jrt.BigInteger_I = tmp1; return tmp2.ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(n__0)) }






func A_arbace_go_check_const_bf_QMARK__A_New() *A_arbace_go_check_const_bf_QMARK__A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_QMARK__A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_go_check_const_bf_QMARK__A) Ctor() {}
//line :48:1
func (t *A_arbace_go_check_const_bf_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any; var root_40 any = A_arbace_go_check_const_A_const_15.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = x__0; if linked_41 == nil { and__1927000168__auto____2 = ifn_42.Invoke_O__O(arg_43) } else { and__1927000168__auto____2 = linked_41.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_40, arg_43) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_const_A_const_16; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_go_check_const_round_int_A_New() *A_arbace_go_check_const_round_int_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_round_int_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_go_check_const_round_int_A) Ctor() {}
//line :50:1
func (t *A_arbace_go_check_const_round_int_A) Invoke_O_O_O_O__O(self, m__0, sticky__1, p__2 any) any { var n__4 int32 = jrt.BigInteger_Cast(m__0).Abs__BigInteger().BitLength__I(); var tmp1 bool; var na_44 int64 = int64(n__4); var na_45 any = p__2; if




	jrt.Long_InstanceOf(na_45) { var n0_46 int64 = na_44; var n1_47 int64 = jrt.NN(jrt.Long_Cast(na_45)).LongValue__J(); tmp1 = n0_46 <= n1_47 } else { tmp1 = lang.Numbers_Lte_J_O__Z_NoInit(na_44, na_45) }; if tmp1 { return lang.Tuple_Create_O_O__IPersistentVector(m__0, A_arbace_go_check_const_A_const_17) } else { var sh__5 any; var na_49 int64 = int64(n__4)
		var na_50 any = p__2
		if jrt.Long_InstanceOf(na_50) { var n0_51 int64 = na_49; var n1_52 int64 = jrt.NN(jrt.Long_Cast(na_50)).LongValue__J(); var nr_53 int64 = n0_51 - n1_52; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_52 == -9223372036854775808); if tmp3 { tmp3 = (n0_51^n1_52)&(n0_51^nr_53) >= 0 }; tmp2 = tmp3; if tmp2 { sh__5 = jrt.Long_ValueOf_J__Long_NoInit(nr_53).Ref() } else { sh__5 = lang.Numbers_Minus_J_O__Number_NoInit(na_49, na_50) } } else { sh__5 = lang.Numbers_Minus_J_O__Number_NoInit(na_49, na_50) }
//line :55:1
		var neg__6 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.BigInteger_Cast(m__0).Signum__I())); var a__7 any = jrt.BigInteger_Cast(m__0).Abs__BigInteger(); var q__8 any = jrt.BigInteger_Cast(a__7).ShiftRight_I__BigInteger(lang.RT_IntCast_O__I_NoInit(sh__5)); var half_bit__9 bool; var tmp4 jrt.BigInteger_I = jrt.BigInteger_Cast(a__7); var tmp5 jrt.Number_I
		var na_54 any = sh__5




		if jrt.Long_InstanceOf(na_54) { var n0_55 int64 = jrt.NN(jrt.Long_Cast(na_54)).LongValue__J(); if n0_55 == -9223372036854775808 { tmp5 = lang.Numbers_Dec_O__Number_NoInit(na_54) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_55 - 1)) } } else { if jrt.Double_InstanceOf(na_54) { var n0_55_2 float64 = jrt.NN(jrt.Double_Cast(na_54)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_55_2 - 1.0)) } else { tmp5 = lang.Numbers_Dec_O__Number_NoInit(na_54) } }; half_bit__9 = tmp4.TestBit_I__Z(lang.RT_IntCast_O__I_NoInit(tmp5))
//line :55:1
		var below__10 any
		var or__1927000174__auto____10 any = sticky__1





		if jrt.J2g_Truth(or__1927000174__auto____10) { below__10 = or__1927000174__auto____10 } else { var and__1927000168__auto____11 bool; var na_56 any = sh__5; var na_57 int64 = 1; if jrt.Long_InstanceOf(na_56) { var n0_58 int64 = jrt.NN(jrt.Long_Cast(na_56)).LongValue__J(); var n1_59 int64 = na_57; and__1927000168__auto____11 = n0_58 > n1_59 } else { and__1927000168__auto____11 = lang.Numbers_Gt_O_J__Z_NoInit(na_56, na_57) }; if and__1927000168__auto____11 { var tmp6 bool; var na_61 int64 = int64(jrt.BigInteger_Cast(a__7).GetLowestSetBit__I()); var na_62 any; var na_63 any = sh__5; if jrt.Long_InstanceOf(na_63) { var n0_64 int64 = jrt.NN(jrt.Long_Cast(na_63)).LongValue__J(); if n0_64 == -9223372036854775808 { na_62 = lang.Numbers_Dec_O__Number_NoInit(na_63) } else { na_62 = jrt.Long_ValueOf_J__Long_NoInit(n0_64 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_63) { var n0_64_2 float64 = jrt.NN(jrt.Double_Cast(na_63)).DoubleValue__D(); na_62 = jrt.Double_ValueOf_D__Double_NoInit(n0_64_2 - 1.0).Ref() } else { na_62 = lang.Numbers_Dec_O__Number_NoInit(na_63) } }; if jrt.Long_InstanceOf(na_62) { var n0_65 int64 = na_61; var n1_66 int64 = jrt.NN(jrt.Long_Cast(na_62)).LongValue__J(); tmp6 = n0_65 < n1_66 } else { tmp6 = lang.Numbers_Lt_J_O__Z_NoInit(na_61, na_62) }; below__10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp6).Ref() } else { below__10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } }
//line :55:1
		var up__11 any
		var and__1927000168__auto____11_2 bool = half_bit__9






		if and__1927000168__auto____11_2 { var or__1927000174__auto____12 any = below__10; if jrt.J2g_Truth(or__1927000174__auto____12) { up__11 = or__1927000174__auto____12 } else { up__11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.BigInteger_Cast(q__8).TestBit_I__Z(lang.RT_IntCast_J__I_NoInit(0))).Ref() } } else { up__11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11_2).Ref() }
//line :55:1
		var q__12 any








		if jrt.J2g_Truth(up__11) { var tmp7 jrt.BigInteger_I = jrt.BigInteger_Cast(q__8); var tmp8 jrt.BigInteger_I; jrt.BigInteger_Init(); tmp8 = jrt.BigInteger_ONE; q__12 = tmp7.Add_BigInteger__BigInteger(tmp8) } else { q__12 = q__8 }
//line :55:1
		var vec__161000017__13 any; var tmp9 bool; var na_68 int64 = int64(jrt.BigInteger_Cast(q__12).BitLength__I())
		var na_69 any = p__2








		if jrt.Long_InstanceOf(na_69) { var n0_70 int64 = na_68; var n1_71 int64 = jrt.NN(jrt.Long_Cast(na_69)).LongValue__J(); tmp9 = n0_70 > n1_71 } else { tmp9 = lang.Numbers_Gt_J_O__Z_NoInit(na_68, na_69) }; if tmp9 { var tmp10 any = jrt.BigInteger_Cast(q__12).ShiftRight_I__BigInteger(lang.RT_IntCast_J__I_NoInit(1)); var tmp11 jrt.Number_I; var na_73 any = sh__5; if jrt.Long_InstanceOf(na_73) { var n0_74 int64 = jrt.NN(jrt.Long_Cast(na_73)).LongValue__J(); if n0_74 == 9223372036854775807 { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_73) } else { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_74 + 1)) } } else { if jrt.Double_InstanceOf(na_73) { var n0_74_2 float64 = jrt.NN(jrt.Double_Cast(na_73)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_74_2 + 1.0)) } else { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_73) } }; vec__161000017__13 = lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11) } else { vec__161000017__13 = lang.Tuple_Create_O_O__IPersistentVector(q__12, sh__5) }
//line :55:1
		var q__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000017__13, lang.RT_IntCast_J__I_NoInit(0), nil); var sh__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000017__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp12 any










		if neg__6 { tmp12 = lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(q__14, Lit_4, false) } else { tmp12 = q__14 }
//line :55:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp12, sh__15) } }

















func A_arbace_go_check_const_bf_norm_A_New() *A_arbace_go_check_const_bf_norm_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_norm_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_go_check_const_bf_norm_A) Ctor() {}
//line :73:1
func (t *A_arbace_go_check_const_bf_norm_A) Invoke_O_O_O_O__O(self, m__0, e__1, sticky__2 any) any {





	if lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.BigInteger_Cast(m__0).Signum__I())) { return A_arbace_go_check_const_A_const_17 } else { var vec__161000021__4 any; var root_75 any = A_arbace_go_check_const_A_const_18.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, A_arbace_go_check_const_round_int_A_fn_class); var ifn_77 lang.IFn

		if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = m__0; var arg_79 any = sticky__2; var arg_80 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O(); if linked_76 == nil { vec__161000021__4 = ifn_77.Invoke_O_O_O__O(arg_78, arg_79, arg_80) } else { vec__161000021__4 = linked_76.(*A_arbace_go_check_const_round_int_A).Invoke_O_O_O_O__O(root_75, arg_78, arg_79, arg_80) }
//line :79:1
		var m__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000021__4, lang.RT_IntCast_J__I_NoInit(0), nil); var sh__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000021__4, lang.RT_IntCast_J__I_NoInit(1), nil); var e__7 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e__1), lang.RT_LongCast_O__J_NoInit(sh__6)); var z__8 int32 = jrt.BigInteger_Cast(m__5).GetLowestSetBit__I(); var x__9 int64 = lang.Numbers_Add_J_J__J_NoInit(e__7, int64(jrt.BigInteger_Cast(m__5).Abs__BigInteger().BitLength__I())); var tmp1 bool; var na_81 int64 = x__9; var na_82 any = A_arbace_go_check_const_A_const_20.GetRawRoot__O()






		if jrt.Long_InstanceOf(na_82) { var n0_83 int64 = na_81; var n1_84 int64 = jrt.NN(jrt.Long_Cast(na_82)).LongValue__J(); tmp1 = n0_83 < n1_84 } else { tmp1 = lang.Numbers_Lt_J_O__Z_NoInit(na_81, na_82) }
//line :85:1
		if tmp1 { return A_arbace_go_check_const_A_const_17 } else { var tmp2 bool; var na_86 int64 = x__9; var na_87 any = A_arbace_go_check_const_A_const_21.GetRawRoot__O()

			if jrt.Long_InstanceOf(na_87) { var n0_88 int64 = na_86; var n1_89 int64 = jrt.NN(jrt.Long_Cast(na_87)).LongValue__J(); tmp2 = n0_88 > n1_89 } else { tmp2 = lang.Numbers_Gt_J_O__Z_NoInit(na_86, na_87) }
//line :85:1
			if tmp2 { return A_arbace_go_check_const_A_const_22 } else { if A_arbace_go_check_const_A_const_8 != nil { var tmp3 any = A_arbace_go_check_const_A_const_16; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp3, jrt.BigInteger_Cast(m__5).ShiftRight_I__BigInteger(lang.RT_IntCast_I__I_NoInit(z__8)), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(e__7, int64(z__8))).Ref()) } else { return nil } } } } }
//line :73:1
func (t *A_arbace_go_check_const_bf_norm_A) Invoke_O_O_O__O(self, m__0, e__1 any) any {



	var root_91 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = m__0; var arg_95 any = e__1; var arg_96 any = jrt.Boolean_FALSE.Ref(); if linked_92 == nil { return ifn_93.Invoke_O_O_O__O(arg_94, arg_95, arg_96) } else { return linked_92.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O_O__O(root_91, arg_94, arg_95, arg_96)
	}
}










func A_arbace_go_check_const_rat_num_den_A_New() *A_arbace_go_check_const_rat_num_den_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_rat_num_den_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_go_check_const_rat_num_den_A) Ctor() {}
//line :90:1
func (t *A_arbace_go_check_const_rat_num_den_A) Invoke_O_O__O(self, r__0 any) any {
	var tmp1 any; var root_97 any = A_arbace_go_check_const_A_const_24.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = r__0; if linked_98 == nil { tmp1 = ifn_99.Invoke_O__O(arg_100) } else { tmp1 = linked_98.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_97, arg_100) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_101 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, A_arbace_go_check_const_bi_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any; var root_105 any = A_arbace_go_check_const_A_const_25.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_numerator_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = r__0; if linked_106 == nil { arg_104 = ifn_107.Invoke_O__O(arg_108) } else { arg_104 = linked_106.(*aot_arbace_core.A_arbace_core_numerator_A).Invoke_O_O__O(root_105, arg_108) }; if linked_102 == nil { tmp2 = ifn_103.Invoke_O__O(arg_104) } else { tmp2 = linked_102.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_101, arg_104) }; var tmp3 any = tmp2; var tmp4 any; var root_109 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, A_arbace_go_check_const_bi_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any; var root_113 any = A_arbace_go_check_const_A_const_26.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_denominator_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = r__0; if linked_114 == nil { arg_112 = ifn_115.Invoke_O__O(arg_116) } else { arg_112 = linked_114.(*aot_arbace_core.A_arbace_core_denominator_A).Invoke_O_O__O(root_113, arg_116) }; if linked_110 == nil { tmp4 = ifn_111.Invoke_O__O(arg_112) } else { tmp4 = linked_110.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_109, arg_112) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { var tmp5 any; var root_117 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, A_arbace_go_check_const_bi_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = r__0; if linked_118 == nil { tmp5 = ifn_119.Invoke_O__O(arg_120) } else { tmp5 = linked_118.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_117, arg_120) }; var tmp6 any = tmp5; var tmp7 jrt.BigInteger_I; jrt.BigInteger_Init(); tmp7 = jrt.BigInteger_ONE; return lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7)
	} }
func A_arbace_go_check_const_rat__GT_bf_A_New() *A_arbace_go_check_const_rat__GT_bf_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_rat__GT_bf_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_go_check_const_rat__GT_bf_A) Ctor() {}
//line :93:1
func (t *A_arbace_go_check_const_rat__GT_bf_A) Invoke_O_O__O(self, r__0 any) any { var vec__161000026__2 any; var root_121 any = A_arbace_go_check_const_A_const_27.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_go_check_const_rat_num_den_A_fn_class); var ifn_123 lang.IFn; if


	linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = r__0; if linked_122 == nil { vec__161000026__2 = ifn_123.Invoke_O__O(arg_124) } else { vec__161000026__2 = linked_122.(*A_arbace_go_check_const_rat_num_den_A).Invoke_O_O__O(root_121, arg_124) }; var p__3 any = /*line :93:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__161000026__2, lang.RT_IntCast_J__I_NoInit(0), nil); var q__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000026__2, lang.RT_IntCast_J__I_NoInit(1), nil); if



	lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.BigInteger_Cast(p__3).Signum__I())) { return A_arbace_go_check_const_A_const_17 } else { var k__5 any; var na_125 any; var na_127 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O()
		var na_128 int64 = 2
		if jrt.Long_InstanceOf(na_127) { var n0_129 int64 = jrt.NN(jrt.Long_Cast(na_127)).LongValue__J(); var n1_130 int64 = na_128; var nr_131 int64 = n0_129 + n1_130; if (n0_129^nr_131)&(n1_130^nr_131) >= 0 { na_125 = jrt.Long_ValueOf_J__Long_NoInit(nr_131).Ref() } else { na_125 = lang.Numbers_Add_O_J__Number_NoInit(na_127, na_128) } } else { na_125 = lang.Numbers_Add_O_J__Number_NoInit(na_127, na_128) }; var na_126 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.BigInteger_Cast(q__4).BitLength__I()), int64(jrt.BigInteger_Cast(p__3).Abs__BigInteger().BitLength__I())); if jrt.Long_InstanceOf(na_125) { var n0_132 int64 = jrt.NN(jrt.Long_Cast(na_125)).LongValue__J(); var n1_133 int64 = na_126; var nr_134 int64 = n0_132 + n1_133; if (n0_132^nr_134)&(n1_133^nr_134) >= 0 { k__5 = jrt.Long_ValueOf_J__Long_NoInit(nr_134).Ref() } else { k__5 = lang.Numbers_Add_O_J__Number_NoInit(na_125, na_126) } } else { k__5 = lang.Numbers_Add_O_J__Number_NoInit(na_125, na_126) }
//line :97:1
		var k__6 any = lang.Numbers_Max_O_J__O_NoInit(k__5, 0); var dr__7 any = jrt.BigInteger_Cast(p__3).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(k__6)).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(q__4)).Ref(); var root_135 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_137 lang.IFn




		if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(dr__7), lang.RT_IntCast_J__I_NoInit(0)); var arg_139 any; var na_141 any = k__6; if jrt.Long_InstanceOf(na_141) { var n0_142 int64 = jrt.NN(jrt.Long_Cast(na_141)).LongValue__J(); if n0_142 == -9223372036854775808 { arg_139 = lang.Numbers_Minus_O__Number_NoInit(na_141) } else { arg_139 = jrt.Long_ValueOf_J__Long_NoInit(-n0_142).Ref() } } else { if jrt.Double_InstanceOf(na_141) { var n0_142_2 float64 = jrt.NN(jrt.Double_Cast(na_141)).DoubleValue__D(); arg_139 = jrt.Double_ValueOf_D__Double_NoInit(-n0_142_2).Ref() } else { arg_139 = lang.Numbers_Minus_O__Number_NoInit(na_141) } }; var arg_140 any; var root_143 any = A_arbace_go_check_const_A_const_28.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.BigInteger_Cast(lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(dr__7), lang.RT_IntCast_J__I_NoInit(1))).Signum__I()))).Ref(); if linked_144 == nil { arg_140 = ifn_145.Invoke_O__O(arg_146) } else { arg_140 = linked_144.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_143, arg_146) }; if linked_136 == nil { return ifn_137.Invoke_O_O_O__O(arg_138, arg_139, arg_140) } else { return linked_136.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O_O__O(root_135, arg_138, arg_139, arg_140) } } }

func A_arbace_go_check_const_bf__GT_rat_A_New() *A_arbace_go_check_const_bf__GT_rat_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf__GT_rat_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_go_check_const_bf__GT_rat_A) Ctor() {}
//line :104:1
func (t *A_arbace_go_check_const_bf__GT_rat_A) Invoke_O_O__O(self, p__161000030__0 any) any { var vec__161000031__2 any = p__161000030__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000031__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000031__2, lang.RT_IntCast_J__I_NoInit(1), nil); var e__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000031__2, lang.RT_IntCast_J__I_NoInit(2), nil); var e__6 int64 = lang.RT_LongCast_O__J_NoInit(e__5); _ = ___3; if



	lang.Numbers_IsNeg_J__Z_NoInit(e__6) {
		var tmp1 any; var root_147 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = m__4; if linked_148 == nil { tmp1 = ifn_149.Invoke_O__O(arg_150) } else { tmp1 = linked_148.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_147, arg_150) }; var tmp2 any = tmp1; var tmp3 any; var root_151 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any; var root_155 any = A_arbace_go_check_const_A_const_29.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, A_arbace_go_check_const_pow2_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(e__6)).Ref(); if linked_156 == nil { arg_154 = ifn_157.Invoke_O__O(arg_158) } else { arg_154 = linked_156.(*A_arbace_go_check_const_pow2_A).Invoke_O_O__O(root_155, arg_158) }; if linked_152 == nil { tmp3 = ifn_153.Invoke_O__O(arg_154) } else { tmp3 = linked_152.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_151, arg_154) }; return lang.Numbers_Divide_O_O__Number_NoInit(tmp2, tmp3) } else {
			var root_159 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = jrt.BigInteger_Cast(m__4).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(e__6)); if linked_160 == nil { return ifn_161.Invoke_O__O(arg_162) } else { return linked_160.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_159, arg_162) } } }

func A_arbace_go_check_const_small_int_QMARK__A_New() *A_arbace_go_check_const_small_int_QMARK__A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_small_int_QMARK__A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_go_check_const_small_int_QMARK__A) Ctor() {}
//line :112:1
func (t *A_arbace_go_check_const_small_int_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var tmp1 bool; var na_163 int64; var root_165 any = A_arbace_go_check_const_A_const_30.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_165, A_arbace_go_check_const_bit_len_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = x__0; if linked_166 == nil { na_163 = lang.RT_LongCast_O__J_NoInit(ifn_167.Invoke_O__O(arg_168)) } else { na_163 = linked_166.(*A_arbace_go_check_const_bit_len_A).InvokePrim_O_O__J(root_165, arg_168) }; var na_164 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); if jrt.Long_InstanceOf(na_164) { var n0_169 int64 = na_163; var n1_170 int64 = jrt.NN(jrt.Long_Cast(na_164)).LongValue__J(); tmp1 = n0_169 < n1_170 } else { tmp1 = lang.Numbers_Lt_J_O__Z_NoInit(na_163, na_164) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref() }

func A_arbace_go_check_const_make_rat_A_New() *A_arbace_go_check_const_make_rat_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_make_rat_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_go_check_const_make_rat_A) Ctor() {}
//line :114:1
func (t *A_arbace_go_check_const_make_rat_A) Invoke_O_O__O(self, r__0 any) any {


	var tmp1 any; var root_172 any = A_arbace_go_check_const_A_const_24.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = r__0; if linked_173 == nil { tmp1 = ifn_174.Invoke_O__O(arg_175) } else { tmp1 = linked_173.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_172, arg_175) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var and__1927000168__auto____2 any; var root_176 any = A_arbace_go_check_const_A_const_32.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, A_arbace_go_check_const_small_int_QMARK__A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any; var root_180 any = A_arbace_go_check_const_A_const_25.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_numerator_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = r__0; if linked_181 == nil { arg_179 = ifn_182.Invoke_O__O(arg_183) } else { arg_179 = linked_181.(*aot_arbace_core.A_arbace_core_numerator_A).Invoke_O_O__O(root_180, arg_183) }; if linked_177 == nil { and__1927000168__auto____2 = ifn_178.Invoke_O__O(arg_179) } else { and__1927000168__auto____2 = linked_177.(*A_arbace_go_check_const_small_int_QMARK__A).Invoke_O_O__O(root_176, arg_179) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_184 any = A_arbace_go_check_const_A_const_32.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, A_arbace_go_check_const_small_int_QMARK__A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any; var root_188 any = A_arbace_go_check_const_A_const_26.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_denominator_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = r__0; if linked_189 == nil { arg_187 = ifn_190.Invoke_O__O(arg_191) } else { arg_187 = linked_189.(*aot_arbace_core.A_arbace_core_denominator_A).Invoke_O_O__O(root_188, arg_191) }; if linked_185 == nil { tmp2 = ifn_186.Invoke_O__O(arg_187) } else { tmp2 = linked_185.(*A_arbace_go_check_const_small_int_QMARK__A).Invoke_O_O__O(root_184, arg_187) } } else { tmp2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp2) { return r__0 } else { var root_192 any = A_arbace_go_check_const_A_const_33.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, A_arbace_go_check_const_rat__GT_bf_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = r__0; if linked_193 == nil { return ifn_194.Invoke_O__O(arg_195) } else { return linked_193.(*A_arbace_go_check_const_rat__GT_bf_A).Invoke_O_O__O(root_192, arg_195) } } } else {
			var tmp3 any; var root_196 any = A_arbace_go_check_const_A_const_32.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, A_arbace_go_check_const_small_int_QMARK__A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = r__0; if linked_197 == nil { tmp3 = ifn_198.Invoke_O__O(arg_199) } else { tmp3 = linked_197.(*A_arbace_go_check_const_small_int_QMARK__A).Invoke_O_O__O(root_196, arg_199) }; if jrt.J2g_Truth(tmp3) { return r__0 } else { var root_200 any = A_arbace_go_check_const_A_const_33.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, A_arbace_go_check_const_rat__GT_bf_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = r__0; if linked_201 == nil { return ifn_202.Invoke_O__O(arg_203) } else { return linked_201.(*A_arbace_go_check_const_rat__GT_bf_A).Invoke_O_O__O(root_200, arg_203)
			} } } }
func A_arbace_go_check_const_bf_exp_A_New() *A_arbace_go_check_const_bf_exp_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_exp_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_go_check_const_bf_exp_A) Ctor() {}
//line :121:1
func (t *A_arbace_go_check_const_bf_exp_A) InvokePrim_O_O__J(self, p__161000037__0 any) int64 { var vec__161000038__2 any = p__161000037__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000038__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000038__2, lang.RT_IntCast_J__I_NoInit(1), nil); var e__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000038__2, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___3; return /*line :124:1*/ lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e__5), int64(jrt.BigInteger_Cast(m__4).Abs__BigInteger().BitLength__I())) }
//line :121:1
func (t *A_arbace_go_check_const_bf_exp_A) Invoke_O_O__O(self, p__161000037__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, p__161000037__0)).Ref() }




func A_arbace_go_check_const_to_bf_A_New() *A_arbace_go_check_const_to_bf_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_to_bf_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_go_check_const_to_bf_A) Ctor() {}
//line :126:1
func (t *A_arbace_go_check_const_to_bf_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_204 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = x__0; if linked_205 == nil { tmp1 = ifn_206.Invoke_O__O(arg_207) } else { tmp1 = linked_205.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_204, arg_207) }; if jrt.J2g_Truth(tmp1) { return x__0 } else { var root_208 any = A_arbace_go_check_const_A_const_33.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, A_arbace_go_check_const_rat__GT_bf_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = x__0; if linked_209 == nil { return ifn_210.Invoke_O__O(arg_211) } else { return linked_209.(*A_arbace_go_check_const_rat__GT_bf_A).Invoke_O_O__O(root_208, arg_211) } } }

func A_arbace_go_check_const_bf_sign_A_New() *A_arbace_go_check_const_bf_sign_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_sign_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_go_check_const_bf_sign_A) Ctor() {}
//line :128:1
func (t *A_arbace_go_check_const_bf_sign_A) InvokePrim_O_O__J(self, x__0 any) int64 { var tmp1 any; var root_212 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = x__0; if linked_213 == nil { tmp1 = ifn_214.Invoke_O__O(arg_215) } else { tmp1 = linked_213.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_212, arg_215) }; if jrt.J2g_Truth(tmp1) { return lang.RT_LongCast_I__J_NoInit(jrt.BigInteger_Cast(lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(1))).Signum__I()) } else { return lang.RT_LongCast_I__J_NoInit(lang.Util_Compare_O_O__I_NoInit(x__0, A_arbace_go_check_const_A_const_17)) } }
//line :128:1
func (t *A_arbace_go_check_const_bf_sign_A) Invoke_O_O__O(self, x__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, x__0)).Ref() }

func A_arbace_go_check_const_bf_add_A_New() *A_arbace_go_check_const_bf_add_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_add_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_go_check_const_bf_add_A) Ctor() {}
//line :130:1
func (t *A_arbace_go_check_const_bf_add_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	if lang.Util_Equiv_J_O__Z_NoInit(0, x__0) {
		var root_216 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = y__1; if linked_217 == nil { return ifn_218.Invoke_O__O(arg_219) } else { return linked_217.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_216, arg_219) } } else {
//line :131:1
			if lang.Util_Equiv_J_O__Z_NoInit(0, y__1) {

				var root_220 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = x__0; if linked_221 == nil { return ifn_222.Invoke_O__O(arg_223) } else { return linked_221.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_220, arg_223) } } else {
//line :131:1
					if A_arbace_go_check_const_A_const_8 != nil { var vec__161000044__3 any; var root_224 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_226 lang.IFn



						if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = x__0; if linked_225 == nil { vec__161000044__3 = ifn_226.Invoke_O__O(arg_227) } else { vec__161000044__3 = linked_225.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_224, arg_227) }
//line :131:1
						var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000044__3, lang.RT_IntCast_J__I_NoInit(0), nil); var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000044__3, lang.RT_IntCast_J__I_NoInit(1), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000044__3, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__161000047__7 any; var root_228 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_230 lang.IFn; _ = ___4



						if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = y__1; if linked_229 == nil { vec__161000047__7 = ifn_230.Invoke_O__O(arg_231) } else { vec__161000047__7 = linked_229.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_228, arg_231) }
//line :131:1
						var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000047__7, lang.RT_IntCast_J__I_NoInit(0), nil); var m2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000047__7, lang.RT_IntCast_J__I_NoInit(1), nil); var e2__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000047__7, lang.RT_IntCast_J__I_NoInit(2), nil); var e1__11 int64 = lang.RT_LongCast_O__J_NoInit(e1__6); var e2__12 int64 = lang.RT_LongCast_O__J_NoInit(e2__10); var vec__161000050__13 any; _ = ___8





						if lang.Numbers_Gte_J_J__Z_NoInit(lang.Numbers_Add_J_J__J_NoInit(e1__11, int64(jrt.BigInteger_Cast(m1__5).Abs__BigInteger().BitLength__I())), lang.Numbers_Add_J_J__J_NoInit(e2__12, int64(jrt.BigInteger_Cast(m2__9).Abs__BigInteger().BitLength__I()))) { vec__161000050__13 = lang.Tuple_Create_O_O_O_O__IPersistentVector(m1__5, jrt.Long_ValueOf_J__Long_NoInit(e1__11).Ref(), m2__9, jrt.Long_ValueOf_J__Long_NoInit(e2__12).Ref()) } else { vec__161000050__13 = lang.Tuple_Create_O_O_O_O__IPersistentVector(m2__9, jrt.Long_ValueOf_J__Long_NoInit(e2__12).Ref(), m1__5, jrt.Long_ValueOf_J__Long_NoInit(e1__11).Ref()) }
//line :131:1
						var hi_m__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000050__13, lang.RT_IntCast_J__I_NoInit(0), nil); var hi_e__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000050__13, lang.RT_IntCast_J__I_NoInit(1), nil); var lo_m__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000050__13, lang.RT_IntCast_J__I_NoInit(2), nil); var lo_e__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000050__13, lang.RT_IntCast_J__I_NoInit(3), nil); var hi_m__18 any = hi_m__14; var lo_m__19 any = lo_m__16; var hi_top__20 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(hi_e__15), int64(jrt.BigInteger_Cast(hi_m__18).Abs__BigInteger().BitLength__I())); var lo_top__21 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(lo_e__17), int64(jrt.BigInteger_Cast(lo_m__19).Abs__BigInteger().BitLength__I())); var tmp1 bool; var na_232 int64 = lang.Numbers_Minus_J_J__J_NoInit(hi_top__20, lo_top__21); var na_233 any; var na_234 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O()
						var na_235 int64 = 8









						if jrt.Long_InstanceOf(na_234) { var n0_236 int64 = jrt.NN(jrt.Long_Cast(na_234)).LongValue__J(); var n1_237 int64 = na_235; var nr_238 int64 = n0_236 + n1_237; if (n0_236^nr_238)&(n1_237^nr_238) >= 0 { na_233 = jrt.Long_ValueOf_J__Long_NoInit(nr_238).Ref() } else { na_233 = lang.Numbers_Add_O_J__Number_NoInit(na_234, na_235) } } else { na_233 = lang.Numbers_Add_O_J__Number_NoInit(na_234, na_235) }; if jrt.Long_InstanceOf(na_233) { var n0_239 int64 = na_232; var n1_240 int64 = jrt.NN(jrt.Long_Cast(na_233)).LongValue__J(); tmp1 = n0_239 > n1_240 } else { tmp1 = lang.Numbers_Gt_J_O__Z_NoInit(na_232, na_233) }; if tmp1 {

							var root_242 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = hi_m__18; var arg_246 any = hi_e__15; if linked_243 == nil { return ifn_244.Invoke_O_O__O(arg_245, arg_246) } else { return linked_243.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O__O(root_242, arg_245, arg_246) } } else {
//line :142:1
								var e__22 int64 = lang.Numbers_Min_J_J__J_NoInit(e1__11, e2__12); var s__23 any = jrt.BigInteger_Cast(m1__5).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(e1__11, e__22))).Add_BigInteger__BigInteger(jrt.BigInteger_Cast(m2__9).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(e2__12, e__22)))); var root_247 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_249 lang.IFn




								if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = s__23; var arg_251 any = jrt.Long_ValueOf_J__Long_NoInit(e__22).Ref(); if linked_248 == nil { return ifn_249.Invoke_O_O__O(arg_250, arg_251) } else { return linked_248.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O__O(root_247, arg_250, arg_251) } } } else {
//line :131:1
									return nil
								}
				}
		}
}













func A_arbace_go_check_const_bf_neg_A_New() *A_arbace_go_check_const_bf_neg_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_neg_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_go_check_const_bf_neg_A) Ctor() {}
//line :149:1
func (t *A_arbace_go_check_const_bf_neg_A) Invoke_O_O__O(self, x__0 any) any { if jrt.Long_InstanceOf(x__0) { return t.InvokeSpec_O_J_O__O(self, jrt.NN(jrt.Long_Cast(x__0)).LongValue__J(), x__0) } else { var tmp1 any; var root_252 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = x__0; if linked_253 == nil { tmp1 = ifn_254.Invoke_O__O(arg_255) } else { tmp1 = linked_253.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_252, arg_255) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_go_check_const_A_const_16; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, jrt.BigInteger_Cast(lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(1))).Negate__BigInteger(), lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(2))) } else { var na_256 any = x__0; if jrt.Long_InstanceOf(na_256) { var n0_257 int64 = jrt.NN(jrt.Long_Cast(na_256)).LongValue__J(); if n0_257 == -9223372036854775808 { return lang.Numbers_Minus_O__Number_NoInit(na_256) } else { return jrt.Long_ValueOf_J__Long_NoInit(-n0_257).Ref() } } else { if jrt.Double_InstanceOf(na_256) { var n0_257_2 float64 = jrt.NN(jrt.Double_Cast(na_256)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(-n0_257_2).Ref() } else { return lang.Numbers_Minus_O__Number_NoInit(na_256) } } } } }
//line :149:1
func (t *A_arbace_go_check_const_bf_neg_A) InvokeSpec_O_J_O__O(self any, x__0_l int64, x__0_b any) any { var tmp1 any; var root_258 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_261 = x__0_b } else { arg_261 = x__0_b }; if linked_259 == nil { tmp1 = ifn_260.Invoke_O__O(arg_261) } else { tmp1 = linked_259.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_258, arg_261) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_go_check_const_A_const_16; var tmp3 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp3 = x__0_b } else { tmp3 = x__0_b }; var tmp4 any = jrt.BigInteger_Cast(lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(1))).Negate__BigInteger(); var tmp5 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp5 = x__0_b } else { tmp5 = x__0_b }; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp4, lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(2))) } else { var n0_262 int64 = x__0_l; if n0_262 == -9223372036854775808 { var tmp6 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp6 = x__0_b } else { tmp6 = x__0_b }; return lang.Numbers_Minus_O__Number_NoInit(tmp6) } else { return jrt.Long_ValueOf_J__Long_NoInit(-n0_262).Ref() } } }

func A_arbace_go_check_const_bf_mul_A_New() *A_arbace_go_check_const_bf_mul_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_mul_A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_go_check_const_bf_mul_A) Ctor() {}
//line :151:1
func (t *A_arbace_go_check_const_bf_mul_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_J_O__Z_NoInit(0, x__0); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_J_O__Z_NoInit(0, y__1) }; if tmp1 { return A_arbace_go_check_const_A_const_17 } else { var vec__161000055__3 any; var root_263 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_265 lang.IFn

		if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = x__0; if linked_264 == nil { vec__161000055__3 = ifn_265.Invoke_O__O(arg_266) } else { vec__161000055__3 = linked_264.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_263, arg_266) }
//line :152:1
		var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000055__3, lang.RT_IntCast_J__I_NoInit(0), nil); var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000055__3, lang.RT_IntCast_J__I_NoInit(1), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000055__3, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__161000058__7 any; var root_267 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_269 lang.IFn; _ = ___4

		if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = y__1; if linked_268 == nil { vec__161000058__7 = ifn_269.Invoke_O__O(arg_270) } else { vec__161000058__7 = linked_268.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_267, arg_270) }
//line :152:1
		var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000058__7, lang.RT_IntCast_J__I_NoInit(0), nil); var m2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000058__7, lang.RT_IntCast_J__I_NoInit(1), nil); var e2__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000058__7, lang.RT_IntCast_J__I_NoInit(2), nil); var root_271 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_273 lang.IFn; _ = ___8


		if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = jrt.BigInteger_Cast(m1__5).Multiply_BigInteger__BigInteger(jrt.BigInteger_Cast(m2__9)); var arg_275 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e1__6), lang.RT_LongCast_O__J_NoInit(e2__10))).Ref(); if linked_272 == nil { return ifn_273.Invoke_O_O__O(arg_274, arg_275) } else { return linked_272.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O__O(root_271, arg_274, arg_275)
		} } }
func A_arbace_go_check_const_bf_quo_A_New() *A_arbace_go_check_const_bf_quo_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_quo_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_const_bf_quo_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_const_bf_quo_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	if lang.Util_Equiv_J_O__Z_NoInit(0, x__0) { return A_arbace_go_check_const_A_const_17 } else { var vec__161000062__3 any; var root_276 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_278 lang.IFn

		if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = x__0; if linked_277 == nil { vec__161000062__3 = ifn_278.Invoke_O__O(arg_279) } else { vec__161000062__3 = linked_277.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_276, arg_279) }
//line :158:1
		var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000062__3, lang.RT_IntCast_J__I_NoInit(0), nil); var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000062__3, lang.RT_IntCast_J__I_NoInit(1), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000062__3, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__161000065__7 any; var root_280 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_282 lang.IFn; _ = ___4

		if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = y__1; if linked_281 == nil { vec__161000065__7 = ifn_282.Invoke_O__O(arg_283) } else { vec__161000065__7 = linked_281.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_280, arg_283) }
//line :158:1
		var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000065__7, lang.RT_IntCast_J__I_NoInit(0), nil); var m2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000065__7, lang.RT_IntCast_J__I_NoInit(1), nil); var e2__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000065__7, lang.RT_IntCast_J__I_NoInit(2), nil); var k__11 any; var tmp1 jrt.Number_I; var na_284 any; var na_286 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O(); var na_287 int64 = 2; _ = ___8


		if jrt.Long_InstanceOf(na_286) { var n0_288 int64 = jrt.NN(jrt.Long_Cast(na_286)).LongValue__J(); var n1_289 int64 = na_287; var nr_290 int64 = n0_288 + n1_289; if (n0_288^nr_290)&(n1_289^nr_290) >= 0 { na_284 = jrt.Long_ValueOf_J__Long_NoInit(nr_290).Ref() } else { na_284 = lang.Numbers_Add_O_J__Number_NoInit(na_286, na_287) } } else { na_284 = lang.Numbers_Add_O_J__Number_NoInit(na_286, na_287) }; var na_285 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.BigInteger_Cast(m2__9).Abs__BigInteger().BitLength__I()), int64(jrt.BigInteger_Cast(m1__5).Abs__BigInteger().BitLength__I())); if jrt.Long_InstanceOf(na_284) { var n0_291 int64 = jrt.NN(jrt.Long_Cast(na_284)).LongValue__J(); var n1_292 int64 = na_285; var nr_293 int64 = n0_291 + n1_292; if (n0_291^nr_293)&(n1_292^nr_293) >= 0 { tmp1 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_293)) } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_284, na_285) } } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_284, na_285) }; k__11 = lang.Numbers_Max_J_O__O_NoInit(0, tmp1)
//line :158:1
		var dr__12 any = jrt.BigInteger_Cast(m1__5).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(k__11)).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(m2__9)).Ref(); var root_294 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_296 lang.IFn




		if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(dr__12), lang.RT_IntCast_J__I_NoInit(0)); var arg_298 any; var na_300 int64 = lang.Numbers_Minus_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e1__6), lang.RT_LongCast_O__J_NoInit(e2__10)); var na_301 any = k__11; if jrt.Long_InstanceOf(na_301) { var n0_302 int64 = na_300; var n1_303 int64 = jrt.NN(jrt.Long_Cast(na_301)).LongValue__J(); var nr_304 int64 = n0_302 - n1_303; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_303 == -9223372036854775808); if tmp3 { tmp3 = (n0_302^n1_303)&(n0_302^nr_304) >= 0 }; tmp2 = tmp3; if tmp2 { arg_298 = jrt.Long_ValueOf_J__Long_NoInit(nr_304).Ref() } else { arg_298 = lang.Numbers_Minus_J_O__Number_NoInit(na_300, na_301) } } else { arg_298 = lang.Numbers_Minus_J_O__Number_NoInit(na_300, na_301) }; var arg_299 any; var root_305 any = A_arbace_go_check_const_A_const_28.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.BigInteger_Cast(lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(dr__12), lang.RT_IntCast_J__I_NoInit(1))).Signum__I()))).Ref(); if linked_306 == nil { arg_299 = ifn_307.Invoke_O__O(arg_308) } else { arg_299 = linked_306.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_305, arg_308) }; if linked_295 == nil { return ifn_296.Invoke_O_O_O__O(arg_297, arg_298, arg_299) } else { return linked_295.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O_O__O(root_294, arg_297, arg_298, arg_299)
		} } }
func A_arbace_go_check_const_bf_cmp_A_New() *A_arbace_go_check_const_bf_cmp_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_cmp_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_go_check_const_bf_cmp_A) Ctor() {}
//line :165:1
func (t *A_arbace_go_check_const_bf_cmp_A) InvokePrim_O_O_O__J(self, x__0, y__1 any) int64 {


	var tmp1 any; var root_309 any = A_arbace_go_check_const_A_const_36.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_309, A_arbace_go_check_const_bf_sign_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any; var root_313 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, A_arbace_go_check_const_bf_add_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = x__0; var arg_317 any; var root_318 any = A_arbace_go_check_const_A_const_38.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_318, A_arbace_go_check_const_bf_neg_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = y__1; if linked_319 == nil { arg_317 = ifn_320.Invoke_O__O(arg_321) } else { if jrt.Long_InstanceOf(arg_321) { arg_317 = linked_319.(*A_arbace_go_check_const_bf_neg_A).InvokeSpec_O_J_O__O(root_318, jrt.NN(jrt.Long_Cast(arg_321)).LongValue__J(), arg_321) } else { arg_317 = linked_319.(*A_arbace_go_check_const_bf_neg_A).Invoke_O_O__O(root_318, arg_321) } }; if linked_314 == nil { arg_312 = ifn_315.Invoke_O_O__O(arg_316, arg_317) } else { arg_312 = linked_314.(*A_arbace_go_check_const_bf_add_A).Invoke_O_O_O__O(root_313, arg_316, arg_317) }; if linked_310 == nil { tmp1 = ifn_311.Invoke_O__O(arg_312) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_310.(*A_arbace_go_check_const_bf_sign_A).InvokePrim_O_O__J(root_309, arg_312)).Ref() }; return jrt.Number_Cast(tmp1).LongValue__J() }
//line :165:1
func (t *A_arbace_go_check_const_bf_cmp_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O_O__J(self, x__0, y__1)).Ref() }






func A_arbace_go_check_const_float_val_A_New() *A_arbace_go_check_const_float_val_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_float_val_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_go_check_const_float_val_A) Ctor() {}
//line :172:1
func (t *A_arbace_go_check_const_float_val_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var root_322 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_324 lang.IFn
	if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = x__0; if linked_323 == nil { tmp1 = ifn_324.Invoke_O__O(arg_325) } else { tmp1 = linked_323.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_322, arg_325) }
//line :175:1
	if jrt.J2g_Truth(tmp1) { return x__0 } else { var tmp2 any; var root_326 any = A_arbace_go_check_const_A_const_39.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_328 lang.IFn

		if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = x__0; if linked_327 == nil { tmp2 = ifn_328.Invoke_O__O(arg_329) } else { tmp2 = linked_327.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_326, arg_329) }
//line :175:1
		if jrt.J2g_Truth(tmp2) {

			var root_330 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = x__0; if linked_331 == nil { return ifn_332.Invoke_O__O(arg_333) } else { return linked_331.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_330, arg_333) } } else {
//line :175:1
				if A_arbace_go_check_const_A_const_8 != nil { return x__0 } else { return nil
				}
			}
	}
}

func A_arbace_go_check_const_fadd_A_New() *A_arbace_go_check_const_fadd_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fadd_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_go_check_const_fadd_A) Ctor() {}
//line :181:1
func (t *A_arbace_go_check_const_fadd_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(x__0); if tmp2 { tmp2 = jrt.Long_InstanceOf(y__1) }; tmp1 = tmp2; if tmp1 { return t.InvokeSpec_O_J_O_J_O__O(self, jrt.NN(jrt.Long_Cast(x__0)).LongValue__J(), x__0, jrt.NN(jrt.Long_Cast(y__1)).LongValue__J(), y__1) } else { var tmp3 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, x__0); if or__1927000174__auto____3 { tmp3 = or__1927000174__auto____3 } else { tmp3 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, y__1) }; if tmp3 { return A_arbace_go_check_const_A_const_22 } else { var tmp4 any; var or__1927000174__auto____3_2 any; var root_334 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = x__0; if linked_335 == nil { or__1927000174__auto____3_2 = ifn_336.Invoke_O__O(arg_337) } else { or__1927000174__auto____3_2 = linked_335.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_334, arg_337) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp4 = or__1927000174__auto____3_2 } else { var root_338 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = y__1; if linked_339 == nil { tmp4 = ifn_340.Invoke_O__O(arg_341) } else { tmp4 = linked_339.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_338, arg_341) } }; if jrt.J2g_Truth(tmp4) { var root_342 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, A_arbace_go_check_const_bf_add_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = x__0; var arg_346 any = y__1; if linked_343 == nil { return ifn_344.Invoke_O_O__O(arg_345, arg_346) } else { return linked_343.(*A_arbace_go_check_const_bf_add_A).Invoke_O_O_O__O(root_342, arg_345, arg_346) } } else { if A_arbace_go_check_const_A_const_8 != nil { var root_347 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any; var na_351 any = x__0; var na_352 any = y__1; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_351); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_352) }; tmp5 = tmp6; if tmp5 { var n0_353 int64 = jrt.NN(jrt.Long_Cast(na_351)).LongValue__J(); var n1_354 int64 = jrt.NN(jrt.Long_Cast(na_352)).LongValue__J(); var nr_355 int64 = n0_353 + n1_354; if (n0_353^nr_355)&(n1_354^nr_355) >= 0 { arg_350 = jrt.Long_ValueOf_J__Long_NoInit(nr_355).Ref() } else { arg_350 = lang.Numbers_Add_O_O__Number_NoInit(na_351, na_352) } } else { var tmp7 bool; var tmp8 bool; tmp8 = jrt.Double_InstanceOf(na_351); if tmp8 { tmp8 = jrt.Double_InstanceOf(na_352) }; tmp7 = tmp8; if tmp7 { var n0_353_2 float64 = jrt.NN(jrt.Double_Cast(na_351)).DoubleValue__D(); var n1_354_2 float64 = jrt.NN(jrt.Double_Cast(na_352)).DoubleValue__D(); arg_350 = jrt.Double_ValueOf_D__Double_NoInit(n0_353_2 + n1_354_2).Ref() } else { arg_350 = lang.Numbers_Add_O_O__Number_NoInit(na_351, na_352) } }; if linked_348 == nil { return ifn_349.Invoke_O__O(arg_350) } else { return linked_348.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_347, arg_350) } } else { return nil } } } } }
//line :181:1
func (t *A_arbace_go_check_const_fadd_A) InvokeSpec_O_J_O_J_O__O(self any, x__0_l int64, x__0_b any, y__1_l int64, y__1_b any) any { var tmp1 bool; var or__1927000174__auto____3 bool; var tmp2 any = A_arbace_go_check_const_A_const_22; var tmp3 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp3 = x__0_b } else { tmp3 = x__0_b }; or__1927000174__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { var tmp4 any = A_arbace_go_check_const_A_const_22; var tmp5 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp5 = y__1_b } else { tmp5 = y__1_b }; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5) }; if tmp1 { return A_arbace_go_check_const_A_const_22 } else { var tmp6 any; var or__1927000174__auto____3_2 any; var root_356 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_359 = x__0_b } else { arg_359 = x__0_b }; if linked_357 == nil { or__1927000174__auto____3_2 = ifn_358.Invoke_O__O(arg_359) } else { or__1927000174__auto____3_2 = linked_357.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_356, arg_359) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp6 = or__1927000174__auto____3_2 } else { var root_360 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); arg_363 = y__1_b } else { arg_363 = y__1_b }; if linked_361 == nil { tmp6 = ifn_362.Invoke_O__O(arg_363) } else { tmp6 = linked_361.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_360, arg_363) } }; if jrt.J2g_Truth(tmp6) { var root_364 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, A_arbace_go_check_const_bf_add_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_367 = x__0_b } else { arg_367 = x__0_b }; var arg_368 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); arg_368 = y__1_b } else { arg_368 = y__1_b }; if linked_365 == nil { return ifn_366.Invoke_O_O__O(arg_367, arg_368) } else { return linked_365.(*A_arbace_go_check_const_bf_add_A).Invoke_O_O_O__O(root_364, arg_367, arg_368) } } else { if A_arbace_go_check_const_A_const_8 != nil { var root_369 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any; var n0_373 int64 = x__0_l; var n1_374 int64 = y__1_l; var nr_375 int64 = n0_373 + n1_374; if (n0_373^nr_375)&(n1_374^nr_375) >= 0 { arg_372 = jrt.Long_ValueOf_J__Long_NoInit(nr_375).Ref() } else { var tmp7 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp7 = x__0_b } else { tmp7 = x__0_b }; var tmp8 any = tmp7; var tmp9 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp9 = y__1_b } else { tmp9 = y__1_b }; arg_372 = lang.Numbers_Add_O_O__Number_NoInit(tmp8, tmp9) }; if linked_370 == nil { return ifn_371.Invoke_O__O(arg_372) } else { return linked_370.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_369, arg_372) } } else { return nil } } } }
func A_arbace_go_check_const_fsub_A_New() *A_arbace_go_check_const_fsub_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fsub_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_go_check_const_fsub_A) Ctor() {}
//line :182:1
func (t *A_arbace_go_check_const_fsub_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(x__0); if tmp2 { tmp2 = jrt.Long_InstanceOf(y__1) }; tmp1 = tmp2; if tmp1 { return t.InvokeSpec_O_J_O_J_O__O(self, jrt.NN(jrt.Long_Cast(x__0)).LongValue__J(), x__0, jrt.NN(jrt.Long_Cast(y__1)).LongValue__J(), y__1) } else { var tmp3 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, x__0); if or__1927000174__auto____3 { tmp3 = or__1927000174__auto____3 } else { tmp3 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, y__1) }; if tmp3 { return A_arbace_go_check_const_A_const_22 } else { var tmp4 any; var or__1927000174__auto____3_2 any; var root_376 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = x__0; if linked_377 == nil { or__1927000174__auto____3_2 = ifn_378.Invoke_O__O(arg_379) } else { or__1927000174__auto____3_2 = linked_377.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_376, arg_379) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp4 = or__1927000174__auto____3_2 } else { var root_380 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = y__1; if linked_381 == nil { tmp4 = ifn_382.Invoke_O__O(arg_383) } else { tmp4 = linked_381.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_380, arg_383) } }; if jrt.J2g_Truth(tmp4) { var root_384 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, A_arbace_go_check_const_bf_add_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = x__0; var arg_388 any; var root_389 any = A_arbace_go_check_const_A_const_38.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_389, A_arbace_go_check_const_bf_neg_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = y__1; if linked_390 == nil { arg_388 = ifn_391.Invoke_O__O(arg_392) } else { if jrt.Long_InstanceOf(arg_392) { arg_388 = linked_390.(*A_arbace_go_check_const_bf_neg_A).InvokeSpec_O_J_O__O(root_389, jrt.NN(jrt.Long_Cast(arg_392)).LongValue__J(), arg_392) } else { arg_388 = linked_390.(*A_arbace_go_check_const_bf_neg_A).Invoke_O_O__O(root_389, arg_392) } }; if linked_385 == nil { return ifn_386.Invoke_O_O__O(arg_387, arg_388) } else { return linked_385.(*A_arbace_go_check_const_bf_add_A).Invoke_O_O_O__O(root_384, arg_387, arg_388) } } else { if A_arbace_go_check_const_A_const_8 != nil { var root_393 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any; var na_397 any = x__0; var na_398 any = y__1; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_397); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_398) }; tmp5 = tmp6; if tmp5 { var n0_399 int64 = jrt.NN(jrt.Long_Cast(na_397)).LongValue__J(); var n1_400 int64 = jrt.NN(jrt.Long_Cast(na_398)).LongValue__J(); var nr_401 int64 = n0_399 - n1_400; var tmp7 bool; var tmp8 bool; tmp8 = !(n1_400 == -9223372036854775808); if tmp8 { tmp8 = (n0_399^n1_400)&(n0_399^nr_401) >= 0 }; tmp7 = tmp8; if tmp7 { arg_396 = jrt.Long_ValueOf_J__Long_NoInit(nr_401).Ref() } else { arg_396 = lang.Numbers_Minus_O_O__Number_NoInit(na_397, na_398) } } else { var tmp9 bool; var tmp10 bool; tmp10 = jrt.Double_InstanceOf(na_397); if tmp10 { tmp10 = jrt.Double_InstanceOf(na_398) }; tmp9 = tmp10; if tmp9 { var n0_399_2 float64 = jrt.NN(jrt.Double_Cast(na_397)).DoubleValue__D(); var n1_400_2 float64 = jrt.NN(jrt.Double_Cast(na_398)).DoubleValue__D(); arg_396 = jrt.Double_ValueOf_D__Double_NoInit(n0_399_2 + -n1_400_2).Ref() } else { arg_396 = lang.Numbers_Minus_O_O__Number_NoInit(na_397, na_398) } }; if linked_394 == nil { return ifn_395.Invoke_O__O(arg_396) } else { return linked_394.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_393, arg_396) } } else { return nil } } } } }
//line :182:1
func (t *A_arbace_go_check_const_fsub_A) InvokeSpec_O_J_O_J_O__O(self any, x__0_l int64, x__0_b any, y__1_l int64, y__1_b any) any { var tmp1 bool; var or__1927000174__auto____3 bool; var tmp2 any = A_arbace_go_check_const_A_const_22; var tmp3 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp3 = x__0_b } else { tmp3 = x__0_b }; or__1927000174__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { var tmp4 any = A_arbace_go_check_const_A_const_22; var tmp5 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp5 = y__1_b } else { tmp5 = y__1_b }; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5) }; if tmp1 { return A_arbace_go_check_const_A_const_22 } else { var tmp6 any; var or__1927000174__auto____3_2 any; var root_402 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_405 = x__0_b } else { arg_405 = x__0_b }; if linked_403 == nil { or__1927000174__auto____3_2 = ifn_404.Invoke_O__O(arg_405) } else { or__1927000174__auto____3_2 = linked_403.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_402, arg_405) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp6 = or__1927000174__auto____3_2 } else { var root_406 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); arg_409 = y__1_b } else { arg_409 = y__1_b }; if linked_407 == nil { tmp6 = ifn_408.Invoke_O__O(arg_409) } else { tmp6 = linked_407.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_406, arg_409) } }; if jrt.J2g_Truth(tmp6) { var root_410 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, A_arbace_go_check_const_bf_add_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_413 = x__0_b } else { arg_413 = x__0_b }; var arg_414 any; var root_415 any = A_arbace_go_check_const_A_const_38.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_415, A_arbace_go_check_const_bf_neg_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; if linked_416 == nil { var tmp7 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp7 = y__1_b } else { tmp7 = y__1_b }; arg_414 = ifn_417.Invoke_O__O(tmp7) } else { arg_414 = linked_416.(*A_arbace_go_check_const_bf_neg_A).InvokeSpec_O_J_O__O(root_415, y__1_l, y__1_b) }; if linked_411 == nil { return ifn_412.Invoke_O_O__O(arg_413, arg_414) } else { return linked_411.(*A_arbace_go_check_const_bf_add_A).Invoke_O_O_O__O(root_410, arg_413, arg_414) } } else { if A_arbace_go_check_const_A_const_8 != nil { var root_419 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any; var n0_423 int64 = x__0_l; var n1_424 int64 = y__1_l; var nr_425 int64 = n0_423 - n1_424; var tmp8 bool; var tmp9 bool; tmp9 = !(n1_424 == -9223372036854775808); if tmp9 { tmp9 = (n0_423^n1_424)&(n0_423^nr_425) >= 0 }; tmp8 = tmp9; if tmp8 { arg_422 = jrt.Long_ValueOf_J__Long_NoInit(nr_425).Ref() } else { var tmp10 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp10 = x__0_b } else { tmp10 = x__0_b }; var tmp11 any = tmp10; var tmp12 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp12 = y__1_b } else { tmp12 = y__1_b }; arg_422 = lang.Numbers_Minus_O_O__Number_NoInit(tmp11, tmp12) }; if linked_420 == nil { return ifn_421.Invoke_O__O(arg_422) } else { return linked_420.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_419, arg_422) } } else { return nil } } } }
func A_arbace_go_check_const_fmul_A_New() *A_arbace_go_check_const_fmul_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fmul_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_go_check_const_fmul_A) Ctor() {}
//line :183:1
func (t *A_arbace_go_check_const_fmul_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(x__0); if tmp2 { tmp2 = jrt.Long_InstanceOf(y__1) }; tmp1 = tmp2; if tmp1 { return t.InvokeSpec_O_J_O_J_O__O(self, jrt.NN(jrt.Long_Cast(x__0)).LongValue__J(), x__0, jrt.NN(jrt.Long_Cast(y__1)).LongValue__J(), y__1) } else { var tmp3 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, x__0); if or__1927000174__auto____3 { tmp3 = or__1927000174__auto____3 } else { tmp3 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, y__1) }; if tmp3 { return A_arbace_go_check_const_A_const_22 } else { var tmp4 any; var or__1927000174__auto____3_2 any; var root_426 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = x__0; if linked_427 == nil { or__1927000174__auto____3_2 = ifn_428.Invoke_O__O(arg_429) } else { or__1927000174__auto____3_2 = linked_427.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_426, arg_429) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp4 = or__1927000174__auto____3_2 } else { var root_430 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = y__1; if linked_431 == nil { tmp4 = ifn_432.Invoke_O__O(arg_433) } else { tmp4 = linked_431.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_430, arg_433) } }; if jrt.J2g_Truth(tmp4) { var root_434 any = A_arbace_go_check_const_A_const_41.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, A_arbace_go_check_const_bf_mul_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = x__0; var arg_438 any = y__1; if linked_435 == nil { return ifn_436.Invoke_O_O__O(arg_437, arg_438) } else { return linked_435.(*A_arbace_go_check_const_bf_mul_A).Invoke_O_O_O__O(root_434, arg_437, arg_438) } } else { if A_arbace_go_check_const_A_const_8 != nil { var root_439 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any; var na_443 any = x__0; var na_444 any = y__1; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_443); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_444) }; tmp5 = tmp6; if tmp5 { var n0_445 int64 = jrt.NN(jrt.Long_Cast(na_443)).LongValue__J(); var n1_446 int64 = jrt.NN(jrt.Long_Cast(na_444)).LongValue__J(); var nr_447 int64 = n0_445 * n1_446; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; tmp10 = n0_445 == -9223372036854775808; if tmp10 { tmp10 = n1_446 < 0 }; tmp9 = tmp10; tmp8 = !tmp9; if tmp8 { var tmp11 bool; tmp11 = n1_446 == 0; if !tmp11 { tmp11 = nr_447/n1_446 == n0_445 }; tmp8 = tmp11 }; tmp7 = tmp8; if tmp7 { arg_442 = jrt.Long_ValueOf_J__Long_NoInit(nr_447).Ref() } else { arg_442 = lang.Numbers_Multiply_O_O__Number_NoInit(na_443, na_444) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_443); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_444) }; tmp12 = tmp13; if tmp12 { var n0_445_2 float64 = jrt.NN(jrt.Double_Cast(na_443)).DoubleValue__D(); var n1_446_2 float64 = jrt.NN(jrt.Double_Cast(na_444)).DoubleValue__D(); arg_442 = jrt.Double_ValueOf_D__Double_NoInit(float64(n0_445_2 * n1_446_2)).Ref() } else { arg_442 = lang.Numbers_Multiply_O_O__Number_NoInit(na_443, na_444) } }; if linked_440 == nil { return ifn_441.Invoke_O__O(arg_442) } else { return linked_440.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_439, arg_442) } } else { return nil } } } } }
//line :183:1
func (t *A_arbace_go_check_const_fmul_A) InvokeSpec_O_J_O_J_O__O(self any, x__0_l int64, x__0_b any, y__1_l int64, y__1_b any) any { var tmp1 bool; var or__1927000174__auto____3 bool; var tmp2 any = A_arbace_go_check_const_A_const_22; var tmp3 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp3 = x__0_b } else { tmp3 = x__0_b }; or__1927000174__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { var tmp4 any = A_arbace_go_check_const_A_const_22; var tmp5 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp5 = y__1_b } else { tmp5 = y__1_b }; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5) }; if tmp1 { return A_arbace_go_check_const_A_const_22 } else { var tmp6 any; var or__1927000174__auto____3_2 any; var root_448 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_451 = x__0_b } else { arg_451 = x__0_b }; if linked_449 == nil { or__1927000174__auto____3_2 = ifn_450.Invoke_O__O(arg_451) } else { or__1927000174__auto____3_2 = linked_449.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_448, arg_451) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp6 = or__1927000174__auto____3_2 } else { var root_452 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); arg_455 = y__1_b } else { arg_455 = y__1_b }; if linked_453 == nil { tmp6 = ifn_454.Invoke_O__O(arg_455) } else { tmp6 = linked_453.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_452, arg_455) } }; if jrt.J2g_Truth(tmp6) { var root_456 any = A_arbace_go_check_const_A_const_41.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, A_arbace_go_check_const_bf_mul_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_459 = x__0_b } else { arg_459 = x__0_b }; var arg_460 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); arg_460 = y__1_b } else { arg_460 = y__1_b }; if linked_457 == nil { return ifn_458.Invoke_O_O__O(arg_459, arg_460) } else { return linked_457.(*A_arbace_go_check_const_bf_mul_A).Invoke_O_O_O__O(root_456, arg_459, arg_460) } } else { if A_arbace_go_check_const_A_const_8 != nil { var root_461 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_463 lang.IFn; if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any; var n0_465 int64 = x__0_l; var n1_466 int64 = y__1_l; var nr_467 int64 = n0_465 * n1_466; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; tmp10 = n0_465 == -9223372036854775808; if tmp10 { tmp10 = n1_466 < 0 }; tmp9 = tmp10; tmp8 = !tmp9; if tmp8 { var tmp11 bool; tmp11 = n1_466 == 0; if !tmp11 { tmp11 = nr_467/n1_466 == n0_465 }; tmp8 = tmp11 }; tmp7 = tmp8; if tmp7 { arg_464 = jrt.Long_ValueOf_J__Long_NoInit(nr_467).Ref() } else { var tmp12 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp12 = x__0_b } else { tmp12 = x__0_b }; var tmp13 any = tmp12; var tmp14 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp14 = y__1_b } else { tmp14 = y__1_b }; arg_464 = lang.Numbers_Multiply_O_O__Number_NoInit(tmp13, tmp14) }; if linked_462 == nil { return ifn_463.Invoke_O__O(arg_464) } else { return linked_462.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_461, arg_464) } } else { return nil } } } }
func A_arbace_go_check_const_fquo_A_New() *A_arbace_go_check_const_fquo_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fquo_A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_go_check_const_fquo_A) Ctor() {}
//line :184:1
func (t *A_arbace_go_check_const_fquo_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, x__0); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, y__1) }; if tmp1 { return A_arbace_go_check_const_A_const_22 } else { var tmp2 any; var or__1927000174__auto____3_2 any; var root_468 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_470 lang.IFn; if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = x__0; if linked_469 == nil { or__1927000174__auto____3_2 = ifn_470.Invoke_O__O(arg_471) } else { or__1927000174__auto____3_2 = linked_469.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_468, arg_471) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp2 = or__1927000174__auto____3_2 } else { var root_472 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = y__1; if linked_473 == nil { tmp2 = ifn_474.Invoke_O__O(arg_475) } else { tmp2 = linked_473.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_472, arg_475) } }; if jrt.J2g_Truth(tmp2) { var root_476 any = A_arbace_go_check_const_A_const_42.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, A_arbace_go_check_const_bf_quo_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any = x__0; var arg_480 any = y__1; if linked_477 == nil { return ifn_478.Invoke_O_O__O(arg_479, arg_480) } else { return linked_477.(*A_arbace_go_check_const_bf_quo_A).Invoke_O_O_O__O(root_476, arg_479, arg_480) } } else { if A_arbace_go_check_const_A_const_8 != nil { var root_481 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = lang.Numbers_Divide_O_O__Number_NoInit(x__0, y__1); if linked_482 == nil { return ifn_483.Invoke_O__O(arg_484) } else { return linked_482.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_481, arg_484) } } else { return nil } } } }
func A_arbace_go_check_const_fneg_A_New() *A_arbace_go_check_const_fneg_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fneg_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_go_check_const_fneg_A) Ctor() {}
//line :185:1
func (t *A_arbace_go_check_const_fneg_A) Invoke_O_O__O(self, x__0 any) any { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, x__0) { return A_arbace_go_check_const_A_const_22 } else { var root_485 any = A_arbace_go_check_const_A_const_38.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_485, A_arbace_go_check_const_bf_neg_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = x__0; if linked_486 == nil { return ifn_487.Invoke_O__O(arg_488) } else { if jrt.Long_InstanceOf(arg_488) { return linked_486.(*A_arbace_go_check_const_bf_neg_A).InvokeSpec_O_J_O__O(root_485, jrt.NN(jrt.Long_Cast(arg_488)).LongValue__J(), arg_488) } else { return linked_486.(*A_arbace_go_check_const_bf_neg_A).Invoke_O_O__O(root_485, arg_488) } } } }
func A_arbace_go_check_const_fsign_A_New() *A_arbace_go_check_const_fsign_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fsign_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_go_check_const_fsign_A) Ctor() {}
//line :186:1
func (t *A_arbace_go_check_const_fsign_A) InvokePrim_O_O__J(self, x__0 any) int64 { var tmp1 any; var root_489 any = A_arbace_go_check_const_A_const_36.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_489, A_arbace_go_check_const_bf_sign_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = x__0; if linked_490 == nil { tmp1 = ifn_491.Invoke_O__O(arg_492) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_490.(*A_arbace_go_check_const_bf_sign_A).InvokePrim_O_O__J(root_489, arg_492)).Ref() }; return jrt.Number_Cast(tmp1).LongValue__J() }
//line :186:1
func (t *A_arbace_go_check_const_fsign_A) Invoke_O_O__O(self, x__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, x__0)).Ref() }
func A_arbace_go_check_const_fcmp_A_New() *A_arbace_go_check_const_fcmp_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fcmp_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_go_check_const_fcmp_A) Ctor() {}
//line :187:1
func (t *A_arbace_go_check_const_fcmp_A) InvokePrim_O_O_O__J(self, x__0, y__1 any) int64 { var tmp1 any; var tmp2 any; var or__1927000174__auto____3 any; var root_493 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = x__0; if linked_494 == nil { or__1927000174__auto____3 = ifn_495.Invoke_O__O(arg_496) } else { or__1927000174__auto____3 = linked_494.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_493, arg_496) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_497 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = y__1; if linked_498 == nil { tmp2 = ifn_499.Invoke_O__O(arg_500) } else { tmp2 = linked_498.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_497, arg_500) } }; if jrt.J2g_Truth(tmp2) { var root_501 any = A_arbace_go_check_const_A_const_43.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_501, A_arbace_go_check_const_bf_cmp_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = x__0; var arg_505 any = y__1; if linked_502 == nil { tmp1 = ifn_503.Invoke_O_O__O(arg_504, arg_505) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_502.(*A_arbace_go_check_const_bf_cmp_A).InvokePrim_O_O_O__J(root_501, arg_504, arg_505)).Ref() } } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.Util_Compare_O_O__I_NoInit(x__0, y__1))).Ref() }; return jrt.Number_Cast(tmp1).LongValue__J() }
//line :187:1
func (t *A_arbace_go_check_const_fcmp_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O_O__J(self, x__0, y__1)).Ref() }
func A_arbace_go_check_const_fzero_QMARK__A_New() *A_arbace_go_check_const_fzero_QMARK__A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fzero_QMARK__A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_go_check_const_fzero_QMARK__A) Ctor() {}
//line :188:1
func (t *A_arbace_go_check_const_fzero_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var tmp1 int64; var root_506 any = A_arbace_go_check_const_A_const_44.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_506, A_arbace_go_check_const_fsign_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = x__0; if linked_507 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_508.Invoke_O__O(arg_509)) } else { tmp1 = linked_507.(*A_arbace_go_check_const_fsign_A).InvokePrim_O_O__J(root_506, arg_509) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref() }

func A_arbace_go_check_const_int_val_A_New() *A_arbace_go_check_const_int_val_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_int_val_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_go_check_const_int_val_A) Ctor() {}
//line :190:1
func (t *A_arbace_go_check_const_int_val_A) Invoke_O_O__O(self, x__0 any) any {




	var tmp1 any; var root_510 any = A_arbace_go_check_const_A_const_39.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_512 lang.IFn
	if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = x__0; if linked_511 == nil { tmp1 = ifn_512.Invoke_O__O(arg_513) } else { tmp1 = linked_511.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_510, arg_513) }
//line :195:1
	if jrt.J2g_Truth(tmp1) { return x__0 } else { var tmp2 any; var root_514 any = A_arbace_go_check_const_A_const_24.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_516 lang.IFn

		if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = x__0; if linked_515 == nil { tmp2 = ifn_516.Invoke_O__O(arg_517) } else { tmp2 = linked_515.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_514, arg_517) }
//line :195:1
		if jrt.J2g_Truth(tmp2) { return nil } else { var tmp3 any; var root_518 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_520 lang.IFn


			if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = x__0; if linked_519 == nil { tmp3 = ifn_520.Invoke_O__O(arg_521) } else { tmp3 = linked_519.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_518, arg_521) }
//line :195:1
			if jrt.J2g_Truth(tmp3) { var e__2 any; var root_522 any = A_arbace_go_check_const_A_const_45.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_522, A_arbace_go_check_const_bf_exp_A_fn_class); var ifn_524 lang.IFn



				if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = x__0; if linked_523 == nil { e__2 = ifn_524.Invoke_O__O(arg_525) } else { e__2 = jrt.Long_ValueOf_J__Long_NoInit(linked_523.(*A_arbace_go_check_const_bf_exp_A).InvokePrim_O_O__J(root_522, arg_525)).Ref() }
				var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_const_A_const_46.GetRawRoot__O()); var tmp5 jrt.Number_I; var na_532 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); if jrt.Long_InstanceOf(na_532) { var n0_533 int64 = jrt.NN(jrt.Long_Cast(na_532)).LongValue__J(); if n0_533 == -9223372036854775808 { tmp5 = lang.Numbers_Minus_O__Number_NoInit(na_532) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(-n0_533)) } } else { if jrt.Double_InstanceOf(na_532) { var n0_533_2 float64 = jrt.NN(jrt.Double_Cast(na_532)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(-n0_533_2)) } else { tmp5 = lang.Numbers_Minus_O__Number_NoInit(na_532) } }; if jrt.J2g_Truth(tmp4.Invoke_O_O_O__O(tmp5, e__2, A_arbace_go_check_const_A_const_31.GetRawRoot__O())) { var vec__161000079__3 any = x__0; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000079__3, lang.RT_IntCast_J__I_NoInit(0), nil); var m__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000079__3, lang.RT_IntCast_J__I_NoInit(1), nil); var ee__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000079__3, lang.RT_IntCast_J__I_NoInit(2), nil); var ee__7 int64 = lang.RT_LongCast_O__J_NoInit(ee__6); _ = ___4


					if lang.Numbers_Gte_J_J__Z_NoInit(ee__7, 0) {
						var root_534 any = A_arbace_go_check_const_A_const_47.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, A_arbace_go_check_const_norm_int_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = jrt.BigInteger_Cast(m__5).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(ee__7)); if linked_535 == nil { return ifn_536.Invoke_O__O(arg_537) } else { return linked_535.(*A_arbace_go_check_const_norm_int_A).Invoke_O_O__O(root_534, arg_537) } } else {
//line :203:1
							var p__8 any; var na_538 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O()
							var na_539 int64 = 4

							if jrt.Long_InstanceOf(na_538) { var n0_540 int64 = jrt.NN(jrt.Long_Cast(na_538)).LongValue__J(); var n1_541 int64 = na_539; var nr_542 int64 = n0_540 - n1_541; var tmp6 bool; var tmp7 bool; tmp7 = !(n1_541 == -9223372036854775808); if tmp7 { tmp7 = (n0_540^n1_541)&(n0_540^nr_542) >= 0 }; tmp6 = tmp7; if tmp6 { p__8 = jrt.Long_ValueOf_J__Long_NoInit(nr_542).Ref() } else { p__8 = lang.Numbers_Minus_O_J__Number_NoInit(na_538, na_539) } } else { p__8 = lang.Numbers_Minus_O_J__Number_NoInit(na_538, na_539) }
//line :203:1
							var n__9 int32 = jrt.BigInteger_Cast(m__5).Abs__BigInteger().BitLength__I(); var try_round__10 any; var fnbody__568 any = A_arbace_go_check_const_int_val_try_round__161000082_A_New_I_O_O_J(n__9, m__5, p__8, ee__7); var tmp8 *jrt.Class
							var fncls__567 /*line :203:1*/*jrt.Class = A_arbace_go_check_const_int_val_try_round__161000082_A_fn_class




							if fncls__567 == nil { var fncls__567d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__568); A_arbace_go_check_const_int_val_try_round__161000082_A_fn_class = fncls__567d; tmp8 = fncls__567d } else { tmp8 = fncls__567 }; try_round__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__568, tmp8, nil)
//line :203:1
							var or__1927000174__auto____11 any = lang.IFn_Cast(try_round__10).Invoke_O__O(jrt.Boolean_FALSE.Ref())















							if jrt.J2g_Truth(or__1927000174__auto____11) { return or__1927000174__auto____11 } else { return lang.IFn_Cast(try_round__10).Invoke_O__O(jrt.Boolean_TRUE.Ref()) } } } else {
//line :200:1
								return nil } } else {
//line :195:1
									if A_arbace_go_check_const_A_const_8 != nil { return nil } else { return nil
									}
								}
		}
	}
}







func A_arbace_go_check_const_int_val_try_round__161000082_A_New_I_O_O_J(p0 int32, p1, p2 any, p3 int64) *A_arbace_go_check_const_int_val_try_round__161000082_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_int_val_try_round__161000082_A{}; t.Ctor_I_O_O_J(p0, p1, p2, p3); return t }
//line :208:1
func (t *A_arbace_go_check_const_int_val_try_round__161000082_A) Ctor_I_O_O_J(c__n int32, c__m, c__p any, c__ee int64) { t.F_n = c__n; t.F_m = c__m; t.F_p = c__p; t.F_ee = c__ee }
//line :208:1
func (t *A_arbace_go_check_const_int_val_try_round__161000082_A) Invoke_O_O__O(self, up_QMARK___1 any) any {
	var tmp1 bool; var na_543 int64 = int64(t.F_n); var na_544 any = t.F_p; if jrt.Long_InstanceOf(na_544) { var n0_545 int64 = na_543; var n1_546 int64 = jrt.NN(jrt.Long_Cast(na_544)).LongValue__J(); tmp1 = n0_545 <= n1_546 } else { tmp1 = lang.Numbers_Lte_J_O__Z_NoInit(na_543, na_544) }; if tmp1 { return nil } else { var sh__2 any; var na_548 int64 = int64(t.F_n); var na_549 any = t.F_p

		if jrt.Long_InstanceOf(na_549) { var n0_550 int64 = na_548; var n1_551 int64 = jrt.NN(jrt.Long_Cast(na_549)).LongValue__J(); var nr_552 int64 = n0_550 - n1_551; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_551 == -9223372036854775808); if tmp3 { tmp3 = (n0_550^n1_551)&(n0_550^nr_552) >= 0 }; tmp2 = tmp3; if tmp2 { sh__2 = jrt.Long_ValueOf_J__Long_NoInit(nr_552).Ref() } else { sh__2 = lang.Numbers_Minus_J_O__Number_NoInit(na_548, na_549) } } else { sh__2 = lang.Numbers_Minus_J_O__Number_NoInit(na_548, na_549) }
//line :209:1
		var a__3 any = jrt.BigInteger_Cast(t.F_m).Abs__BigInteger(); var q__4 any = jrt.BigInteger_Cast(a__3).ShiftRight_I__BigInteger(lang.RT_IntCast_O__I_NoInit(sh__2)); var q__5 any




		if jrt.J2g_Truth(up_QMARK___1) { var tmp4 jrt.BigInteger_I = jrt.BigInteger_Cast(q__4); var tmp5 jrt.BigInteger_I; jrt.BigInteger_Init(); tmp5 = jrt.BigInteger_ONE; q__5 = tmp4.Add_BigInteger__BigInteger(tmp5) } else { q__5 = q__4 }
//line :209:1
		var ve__6 any; var na_553 int64 = t.F_ee
		var na_554 any = sh__2




		if jrt.Long_InstanceOf(na_554) { var n0_555 int64 = na_553; var n1_556 int64 = jrt.NN(jrt.Long_Cast(na_554)).LongValue__J(); var nr_557 int64 = n0_555 + n1_556; if (n0_555^nr_557)&(n1_556^nr_557) >= 0 { ve__6 = jrt.Long_ValueOf_J__Long_NoInit(nr_557).Ref() } else { ve__6 = lang.Numbers_Add_J_O__Number_NoInit(na_553, na_554) } } else { ve__6 = lang.Numbers_Add_J_O__Number_NoInit(na_553, na_554) }
		var tmp6 bool; var na_558 any = ve__6; var na_559 int64 = 0; if jrt.Long_InstanceOf(na_558) { var n0_560 int64 = jrt.NN(jrt.Long_Cast(na_558)).LongValue__J(); var n1_561 int64 = na_559; tmp6 = n0_560 >= n1_561 } else { tmp6 = lang.Numbers_Gte_O_J__Z_NoInit(na_558, na_559) }; if tmp6 { var v__7 any = jrt.BigInteger_Cast(q__5).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(ve__6)); var root_563 any = A_arbace_go_check_const_A_const_47.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, A_arbace_go_check_const_norm_int_A_fn_class); var ifn_565 lang.IFn

			if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any; if lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.BigInteger_Cast(t.F_m).Signum__I())) { arg_566 = jrt.BigInteger_Cast(v__7).Negate__BigInteger() } else { arg_566 = v__7 }; if linked_564 == nil { return ifn_565.Invoke_O__O(arg_566) } else { return linked_564.(*A_arbace_go_check_const_norm_int_A).Invoke_O_O__O(root_563, arg_566) } } else {
//line :216:1
				return nil
			}
	}
}




func A_arbace_go_check_const_round_binary_A_New() *A_arbace_go_check_const_round_binary_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_round_binary_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_go_check_const_round_binary_A) Ctor() {}
//line :224:1
func (t *A_arbace_go_check_const_round_binary_A) Invoke_O_O_O_O_O__O(self, x__0, mbits__1, emin__2, emax__3 any) any { var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(mbits__1); if tmp2 { tmp2 = jrt.Long_InstanceOf(emax__3) }; tmp1 = tmp2; if tmp1 { return t.InvokeSpec_O_O_J_O_O_J_O__O(self, x__0, jrt.NN(jrt.Long_Cast(mbits__1)).LongValue__J(), mbits__1, emin__2, jrt.NN(jrt.Long_Cast(emax__3)).LongValue__J(), emax__3) } else { var r__5 any; var tmp3 any; var root_569 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_571 lang.IFn




	if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = x__0; if linked_570 == nil { tmp3 = ifn_571.Invoke_O__O(arg_572) } else { tmp3 = linked_570.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_569, arg_572) }; if jrt.J2g_Truth(tmp3) { var root_573 any = A_arbace_go_check_const_A_const_48.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, A_arbace_go_check_const_bf__GT_rat_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = x__0; if linked_574 == nil { r__5 = ifn_575.Invoke_O__O(arg_576) } else { r__5 = linked_574.(*A_arbace_go_check_const_bf__GT_rat_A).Invoke_O_O__O(root_573, arg_576) } } else { r__5 = x__0 }
//line :224:1
	var vec__161000085__6 any; var root_577 any = A_arbace_go_check_const_A_const_27.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, A_arbace_go_check_const_rat_num_den_A_fn_class); var ifn_579 lang.IFn





	if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = r__5; if linked_578 == nil { vec__161000085__6 = ifn_579.Invoke_O__O(arg_580) } else { vec__161000085__6 = linked_578.(*A_arbace_go_check_const_rat_num_den_A).Invoke_O_O__O(root_577, arg_580) }
//line :224:1
	var p__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000085__6, lang.RT_IntCast_J__I_NoInit(0), nil); var q__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000085__6, lang.RT_IntCast_J__I_NoInit(1), nil)






	if lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.BigInteger_Cast(p__7).Signum__I())) { return A_arbace_go_check_const_A_const_17 } else { var neg__9 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.BigInteger_Cast(p__7).Signum__I())); var p__10 any = jrt.BigInteger_Cast(p__7).Abs__BigInteger(); var e0__11 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.BigInteger_Cast(p__10).BitLength__I()), int64(jrt.BigInteger_Cast(q__8).BitLength__I())); var e__12 int64





		if lang.Numbers_Gte_J_J__Z_NoInit(e0__11, 0) {
			if lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.BigInteger_Cast(p__10).CompareTo_BigInteger__I(jrt.BigInteger_Cast(q__8).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(e0__11))))) { e__12 = lang.Numbers_Dec_J__J_NoInit(e0__11) } else { e__12 = e0__11 } } else {
				if lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.BigInteger_Cast(p__10).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J__J_NoInit(e0__11))).CompareTo_BigInteger__I(jrt.BigInteger_Cast(q__8)))) { e__12 = lang.Numbers_Dec_J__J_NoInit(e0__11) } else { e__12 = e0__11 } }
//line :231:1
		var qe__13 any; var na_581 any = lang.Numbers_Max_J_O__O_NoInit(e__12, emin__2); var na_582 any
		var na_583 any = mbits__1








		if jrt.Long_InstanceOf(na_583) { var n0_584 int64 = jrt.NN(jrt.Long_Cast(na_583)).LongValue__J(); if n0_584 == -9223372036854775808 { na_582 = lang.Numbers_Dec_O__Number_NoInit(na_583) } else { na_582 = jrt.Long_ValueOf_J__Long_NoInit(n0_584 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_583) { var n0_584_2 float64 = jrt.NN(jrt.Double_Cast(na_583)).DoubleValue__D(); na_582 = jrt.Double_ValueOf_D__Double_NoInit(n0_584_2 - 1.0).Ref() } else { na_582 = lang.Numbers_Dec_O__Number_NoInit(na_583) } }; var tmp4 bool; var tmp5 bool; tmp5 = jrt.Long_InstanceOf(na_581); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_582) }; tmp4 = tmp5; if tmp4 { var n0_585 int64 = jrt.NN(jrt.Long_Cast(na_581)).LongValue__J(); var n1_586 int64 = jrt.NN(jrt.Long_Cast(na_582)).LongValue__J(); var nr_587 int64 = n0_585 - n1_586; var tmp6 bool; var tmp7 bool; tmp7 = !(n1_586 == -9223372036854775808); if tmp7 { tmp7 = (n0_585^n1_586)&(n0_585^nr_587) >= 0 }; tmp6 = tmp7; if tmp6 { qe__13 = jrt.Long_ValueOf_J__Long_NoInit(nr_587).Ref() } else { qe__13 = lang.Numbers_Minus_O_O__Number_NoInit(na_581, na_582) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_581); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_582) }; tmp8 = tmp9; if tmp8 { var n0_585_2 float64 = jrt.NN(jrt.Double_Cast(na_581)).DoubleValue__D(); var n1_586_2 float64 = jrt.NN(jrt.Double_Cast(na_582)).DoubleValue__D(); qe__13 = jrt.Double_ValueOf_D__Double_NoInit(n0_585_2 + -n1_586_2).Ref() } else { qe__13 = lang.Numbers_Minus_O_O__Number_NoInit(na_581, na_582) } }
//line :231:1
		var vec__161000088__14 any; var tmp10 bool
		var na_588 any = qe__13










		if jrt.Long_InstanceOf(na_588) { var n0_589 int64 = jrt.NN(jrt.Long_Cast(na_588)).LongValue__J(); tmp10 = n0_589 < 0 } else { if jrt.Double_InstanceOf(na_588) { var n0_589_2 float64 = jrt.NN(jrt.Double_Cast(na_588)).DoubleValue__D(); tmp10 = n0_589_2 < 0.0 } else { tmp10 = lang.Numbers_IsNeg_O__Z_NoInit(na_588) } }; if tmp10 { var tmp11 jrt.BigInteger_I = jrt.BigInteger_Cast(p__10); var tmp12 jrt.Number_I; var na_639 any = qe__13; if jrt.Long_InstanceOf(na_639) { var n0_640 int64 = jrt.NN(jrt.Long_Cast(na_639)).LongValue__J(); if n0_640 == -9223372036854775808 { tmp12 = lang.Numbers_Minus_O__Number_NoInit(na_639) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(-n0_640)) } } else { if jrt.Double_InstanceOf(na_639) { var n0_640_2 float64 = jrt.NN(jrt.Double_Cast(na_639)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(-n0_640_2)) } else { tmp12 = lang.Numbers_Minus_O__Number_NoInit(na_639) } }; vec__161000088__14 = lang.Tuple_Create_O_O__IPersistentVector(tmp11.ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(tmp12)), q__8) } else { vec__161000088__14 = lang.Tuple_Create_O_O__IPersistentVector(p__10, jrt.BigInteger_Cast(q__8).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(qe__13))) }
//line :231:1
		var num__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000088__14, lang.RT_IntCast_J__I_NoInit(0), nil); var den__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000088__14, lang.RT_IntCast_J__I_NoInit(1), nil); var dr__17 any = jrt.BigInteger_Cast(num__15).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(den__16)).Ref(); var m__18 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(dr__17), lang.RT_IntCast_J__I_NoInit(0)); var rm__19 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(dr__17), lang.RT_IntCast_J__I_NoInit(1)); var c__20 int32 = jrt.BigInteger_Cast(rm__19).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(1)).CompareTo_BigInteger__I(jrt.BigInteger_Cast(den__16)); var m__21 any; var tmp13 bool; var or__1927000174__auto____21 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(c__20))















		if or__1927000174__auto____21 { tmp13 = or__1927000174__auto____21 } else { var and__1927000168__auto____22 bool = lang.Numbers_IsZero_J__Z_NoInit(int64(c__20)); if and__1927000168__auto____22 { tmp13 = jrt.BigInteger_Cast(m__18).TestBit_I__Z(lang.RT_IntCast_J__I_NoInit(0)) } else { tmp13 = and__1927000168__auto____22 } }; if tmp13 { var tmp14 jrt.BigInteger_I = jrt.BigInteger_Cast(m__18); var tmp15 jrt.BigInteger_I; jrt.BigInteger_Init(); tmp15 = jrt.BigInteger_ONE; m__21 = tmp14.Add_BigInteger__BigInteger(tmp15) } else { m__21 = m__18 }
//line :231:1
		var top__22 any; var na_590 any; var na_592 any = qe__13; var na_593 int64 = int64(jrt.BigInteger_Cast(m__21).BitLength__I())

















		if jrt.Long_InstanceOf(na_592) { var n0_594 int64 = jrt.NN(jrt.Long_Cast(na_592)).LongValue__J(); var n1_595 int64 = na_593; var nr_596 int64 = n0_594 + n1_595; if (n0_594^nr_596)&(n1_595^nr_596) >= 0 { na_590 = jrt.Long_ValueOf_J__Long_NoInit(nr_596).Ref() } else { na_590 = lang.Numbers_Add_O_J__Number_NoInit(na_592, na_593) } } else { na_590 = lang.Numbers_Add_O_J__Number_NoInit(na_592, na_593) }; var na_591 int64 = -1; if jrt.Long_InstanceOf(na_590) { var n0_597 int64 = jrt.NN(jrt.Long_Cast(na_590)).LongValue__J(); var n1_598 int64 = na_591; var nr_599 int64 = n0_597 + n1_598; if (n0_597^nr_599)&(n1_598^nr_599) >= 0 { top__22 = jrt.Long_ValueOf_J__Long_NoInit(nr_599).Ref() } else { top__22 = lang.Numbers_Add_O_J__Number_NoInit(na_590, na_591) } } else { top__22 = lang.Numbers_Add_O_J__Number_NoInit(na_590, na_591) }
		var tmp16 bool; var na_600 any = top__22; var na_601 any = emax__3; var tmp17 bool; var tmp18 bool; tmp18 = jrt.Long_InstanceOf(na_600); if tmp18 { tmp18 = jrt.Long_InstanceOf(na_601) }; tmp17 = tmp18; if tmp17 { var n0_602 int64 = jrt.NN(jrt.Long_Cast(na_600)).LongValue__J(); var n1_603 int64 = jrt.NN(jrt.Long_Cast(na_601)).LongValue__J(); tmp16 = n0_602 > n1_603 } else { var tmp19 bool; var tmp20 bool; tmp20 = jrt.Double_InstanceOf(na_600); if tmp20 { tmp20 = jrt.Double_InstanceOf(na_601) }; tmp19 = tmp20; if tmp19 { var n0_602_2 float64 = jrt.NN(jrt.Double_Cast(na_600)).DoubleValue__D(); var n1_603_2 float64 = jrt.NN(jrt.Double_Cast(na_601)).DoubleValue__D(); tmp16 = n1_603_2 < n0_602_2 } else { tmp16 = lang.Numbers_Gt_O_O__Z_NoInit(na_600, na_601) } }; if tmp16 { return nil } else { var v__23 any; var tmp21 bool
			var na_605 any = qe__13
			if jrt.Long_InstanceOf(na_605) { var n0_606 int64 = jrt.NN(jrt.Long_Cast(na_605)).LongValue__J(); tmp21 = n0_606 < 0 } else { if jrt.Double_InstanceOf(na_605) { var n0_606_2 float64 = jrt.NN(jrt.Double_Cast(na_605)).DoubleValue__D(); tmp21 = n0_606_2 < 0.0 } else { tmp21 = lang.Numbers_IsNeg_O__Z_NoInit(na_605) } }; if tmp21 {
				var tmp22 any; var root_607 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = m__21; if linked_608 == nil { tmp22 = ifn_609.Invoke_O__O(arg_610) } else { tmp22 = linked_608.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_607, arg_610) }; var tmp23 any = tmp22; var tmp24 any; var root_611 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any; var root_615 any = A_arbace_go_check_const_A_const_29.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, A_arbace_go_check_const_pow2_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any; var na_619 any = qe__13; if jrt.Long_InstanceOf(na_619) { var n0_620 int64 = jrt.NN(jrt.Long_Cast(na_619)).LongValue__J(); if n0_620 == -9223372036854775808 { arg_618 = lang.Numbers_Minus_O__Number_NoInit(na_619) } else { arg_618 = jrt.Long_ValueOf_J__Long_NoInit(-n0_620).Ref() } } else { if jrt.Double_InstanceOf(na_619) { var n0_620_2 float64 = jrt.NN(jrt.Double_Cast(na_619)).DoubleValue__D(); arg_618 = jrt.Double_ValueOf_D__Double_NoInit(-n0_620_2).Ref() } else { arg_618 = lang.Numbers_Minus_O__Number_NoInit(na_619) } }; if linked_616 == nil { arg_614 = ifn_617.Invoke_O__O(arg_618) } else { arg_614 = linked_616.(*A_arbace_go_check_const_pow2_A).Invoke_O_O__O(root_615, arg_618) }; if linked_612 == nil { tmp24 = ifn_613.Invoke_O__O(arg_614) } else { tmp24 = linked_612.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_611, arg_614) }; v__23 = lang.Numbers_Divide_O_O__Number_NoInit(tmp23, tmp24) } else {
					var root_621 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = jrt.BigInteger_Cast(m__21).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(qe__13)); if linked_622 == nil { v__23 = ifn_623.Invoke_O__O(arg_624) } else { v__23 = linked_622.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_621, arg_624) } }
//line :250:1
			var v__24 any; var tmp25 any; var root_625 any = A_arbace_go_check_const_A_const_24.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_627 lang.IFn




			if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = v__23; if linked_626 == nil { tmp25 = ifn_627.Invoke_O__O(arg_628) } else { tmp25 = linked_626.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_625, arg_628) }; if jrt.J2g_Truth(tmp25) { v__24 = v__23 } else { var root_629 any = A_arbace_go_check_const_A_const_47.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, A_arbace_go_check_const_norm_int_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any; var root_633 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, A_arbace_go_check_const_bi_A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = v__23; if linked_634 == nil { arg_632 = ifn_635.Invoke_O__O(arg_636) } else { arg_632 = linked_634.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_633, arg_636) }; if linked_630 == nil { v__24 = ifn_631.Invoke_O__O(arg_632) } else { v__24 = linked_630.(*A_arbace_go_check_const_norm_int_A).Invoke_O_O__O(root_629, arg_632) } }
			if neg__9 { var na_637 any = v__24; if jrt.Long_InstanceOf(na_637) { var n0_638 int64 = jrt.NN(jrt.Long_Cast(na_637)).LongValue__J(); if n0_638 == -9223372036854775808 { return lang.Numbers_Minus_O__Number_NoInit(na_637) } else { return jrt.Long_ValueOf_J__Long_NoInit(-n0_638).Ref() } } else { if jrt.Double_InstanceOf(na_637) { var n0_638_2 float64 = jrt.NN(jrt.Double_Cast(na_637)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(-n0_638_2).Ref() } else { return lang.Numbers_Minus_O__Number_NoInit(na_637) } } } else { return v__24 } } } } }
//line :224:1
func (t *A_arbace_go_check_const_round_binary_A) InvokeSpec_O_O_J_O_O_J_O__O(self, x__0 any, mbits__1_l int64, mbits__1_b, emin__2 any, emax__3_l int64, emax__3_b any) any { var r__5 any; var tmp1 any; var root_641 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_641, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_643 lang.IFn; if




	linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = x__0; if linked_642 == nil { tmp1 = ifn_643.Invoke_O__O(arg_644) } else { tmp1 = linked_642.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_641, arg_644) }; if jrt.J2g_Truth(tmp1) { var root_645 any = A_arbace_go_check_const_A_const_48.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, A_arbace_go_check_const_bf__GT_rat_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = x__0; if linked_646 == nil { r__5 = ifn_647.Invoke_O__O(arg_648) } else { r__5 = linked_646.(*A_arbace_go_check_const_bf__GT_rat_A).Invoke_O_O__O(root_645, arg_648) } } else { r__5 = x__0 }; var vec__161000085__6 any; var root_649 any = /*line :224:1*/A_arbace_go_check_const_A_const_27.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, A_arbace_go_check_const_rat_num_den_A_fn_class); var ifn_651 lang.IFn; if





	linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = r__5; if linked_650 == nil { vec__161000085__6 = ifn_651.Invoke_O__O(arg_652) } else { vec__161000085__6 = linked_650.(*A_arbace_go_check_const_rat_num_den_A).Invoke_O_O__O(root_649, arg_652) }; var p__7 any = /*line :224:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__161000085__6, lang.RT_IntCast_J__I_NoInit(0), nil); var q__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000085__6, lang.RT_IntCast_J__I_NoInit(1), nil); if






	lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.BigInteger_Cast(p__7).Signum__I())) { return A_arbace_go_check_const_A_const_17 } else { var neg__9 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.BigInteger_Cast(p__7).Signum__I())); var p__10 any = jrt.BigInteger_Cast(p__7).Abs__BigInteger(); var e0__11 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.BigInteger_Cast(p__10).BitLength__I()), int64(jrt.BigInteger_Cast(q__8).BitLength__I())); var e__12 int64





		if lang.Numbers_Gte_J_J__Z_NoInit(e0__11, 0) {
			if lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.BigInteger_Cast(p__10).CompareTo_BigInteger__I(jrt.BigInteger_Cast(q__8).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(e0__11))))) { e__12 = lang.Numbers_Dec_J__J_NoInit(e0__11) } else { e__12 = e0__11 } } else {
				if lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.BigInteger_Cast(p__10).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J__J_NoInit(e0__11))).CompareTo_BigInteger__I(jrt.BigInteger_Cast(q__8)))) { e__12 = lang.Numbers_Dec_J__J_NoInit(e0__11) } else { e__12 = e0__11 } }
//line :231:1
		var qe__13 any; var na_653 any = lang.Numbers_Max_J_O__O_NoInit(e__12, emin__2); var na_654 any
		var n0_655 int64 = mbits__1_l








		if n0_655 == -9223372036854775808 { var tmp2 any; if mbits__1_b == nil { mbits__1_b = jrt.Long_ValueOf_J__Long_NoInit(mbits__1_l).Ref(); tmp2 = mbits__1_b } else { tmp2 = mbits__1_b }; na_654 = lang.Numbers_Dec_O__Number_NoInit(tmp2) } else { na_654 = jrt.Long_ValueOf_J__Long_NoInit(n0_655 - 1).Ref() }; var tmp3 bool; var tmp4 bool; tmp4 = jrt.Long_InstanceOf(na_653); if tmp4 { tmp4 = jrt.Long_InstanceOf(na_654) }; tmp3 = tmp4; if tmp3 { var n0_656 int64 = jrt.NN(jrt.Long_Cast(na_653)).LongValue__J(); var n1_657 int64 = jrt.NN(jrt.Long_Cast(na_654)).LongValue__J(); var nr_658 int64 = n0_656 - n1_657; var tmp5 bool; var tmp6 bool; tmp6 = !(n1_657 == -9223372036854775808); if tmp6 { tmp6 = (n0_656^n1_657)&(n0_656^nr_658) >= 0 }; tmp5 = tmp6; if tmp5 { qe__13 = jrt.Long_ValueOf_J__Long_NoInit(nr_658).Ref() } else { qe__13 = lang.Numbers_Minus_O_O__Number_NoInit(na_653, na_654) } } else { var tmp7 bool; var tmp8 bool; tmp8 = jrt.Double_InstanceOf(na_653); if tmp8 { tmp8 = jrt.Double_InstanceOf(na_654) }; tmp7 = tmp8; if tmp7 { var n0_656_2 float64 = jrt.NN(jrt.Double_Cast(na_653)).DoubleValue__D(); var n1_657_2 float64 = jrt.NN(jrt.Double_Cast(na_654)).DoubleValue__D(); qe__13 = jrt.Double_ValueOf_D__Double_NoInit(n0_656_2 + -n1_657_2).Ref() } else { qe__13 = lang.Numbers_Minus_O_O__Number_NoInit(na_653, na_654) } }
//line :231:1
		var vec__161000088__14 any; var tmp9 bool
		var na_659 any = qe__13










		if jrt.Long_InstanceOf(na_659) { var n0_660 int64 = jrt.NN(jrt.Long_Cast(na_659)).LongValue__J(); tmp9 = n0_660 < 0 } else { if jrt.Double_InstanceOf(na_659) { var n0_660_2 float64 = jrt.NN(jrt.Double_Cast(na_659)).DoubleValue__D(); tmp9 = n0_660_2 < 0.0 } else { tmp9 = lang.Numbers_IsNeg_O__Z_NoInit(na_659) } }; if tmp9 { var tmp10 jrt.BigInteger_I = jrt.BigInteger_Cast(p__10); var tmp11 jrt.Number_I; var na_709 any = qe__13; if jrt.Long_InstanceOf(na_709) { var n0_710 int64 = jrt.NN(jrt.Long_Cast(na_709)).LongValue__J(); if n0_710 == -9223372036854775808 { tmp11 = lang.Numbers_Minus_O__Number_NoInit(na_709) } else { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(-n0_710)) } } else { if jrt.Double_InstanceOf(na_709) { var n0_710_2 float64 = jrt.NN(jrt.Double_Cast(na_709)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(-n0_710_2)) } else { tmp11 = lang.Numbers_Minus_O__Number_NoInit(na_709) } }; vec__161000088__14 = lang.Tuple_Create_O_O__IPersistentVector(tmp10.ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(tmp11)), q__8) } else { vec__161000088__14 = lang.Tuple_Create_O_O__IPersistentVector(p__10, jrt.BigInteger_Cast(q__8).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(qe__13))) }
//line :231:1
		var num__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000088__14, lang.RT_IntCast_J__I_NoInit(0), nil); var den__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000088__14, lang.RT_IntCast_J__I_NoInit(1), nil); var dr__17 any = jrt.BigInteger_Cast(num__15).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(den__16)).Ref(); var m__18 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(dr__17), lang.RT_IntCast_J__I_NoInit(0)); var rm__19 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(dr__17), lang.RT_IntCast_J__I_NoInit(1)); var c__20 int32 = jrt.BigInteger_Cast(rm__19).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(1)).CompareTo_BigInteger__I(jrt.BigInteger_Cast(den__16)); var m__21 any; var tmp12 bool; var or__1927000174__auto____21 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(c__20))















		if or__1927000174__auto____21 { tmp12 = or__1927000174__auto____21 } else { var and__1927000168__auto____22 bool = lang.Numbers_IsZero_J__Z_NoInit(int64(c__20)); if and__1927000168__auto____22 { tmp12 = jrt.BigInteger_Cast(m__18).TestBit_I__Z(lang.RT_IntCast_J__I_NoInit(0)) } else { tmp12 = and__1927000168__auto____22 } }; if tmp12 { var tmp13 jrt.BigInteger_I = jrt.BigInteger_Cast(m__18); var tmp14 jrt.BigInteger_I; jrt.BigInteger_Init(); tmp14 = jrt.BigInteger_ONE; m__21 = tmp13.Add_BigInteger__BigInteger(tmp14) } else { m__21 = m__18 }
//line :231:1
		var top__22 any; var na_661 any; var na_663 any = qe__13; var na_664 int64 = int64(jrt.BigInteger_Cast(m__21).BitLength__I())

















		if jrt.Long_InstanceOf(na_663) { var n0_665 int64 = jrt.NN(jrt.Long_Cast(na_663)).LongValue__J(); var n1_666 int64 = na_664; var nr_667 int64 = n0_665 + n1_666; if (n0_665^nr_667)&(n1_666^nr_667) >= 0 { na_661 = jrt.Long_ValueOf_J__Long_NoInit(nr_667).Ref() } else { na_661 = lang.Numbers_Add_O_J__Number_NoInit(na_663, na_664) } } else { na_661 = lang.Numbers_Add_O_J__Number_NoInit(na_663, na_664) }; var na_662 int64 = -1; if jrt.Long_InstanceOf(na_661) { var n0_668 int64 = jrt.NN(jrt.Long_Cast(na_661)).LongValue__J(); var n1_669 int64 = na_662; var nr_670 int64 = n0_668 + n1_669; if (n0_668^nr_670)&(n1_669^nr_670) >= 0 { top__22 = jrt.Long_ValueOf_J__Long_NoInit(nr_670).Ref() } else { top__22 = lang.Numbers_Add_O_J__Number_NoInit(na_661, na_662) } } else { top__22 = lang.Numbers_Add_O_J__Number_NoInit(na_661, na_662) }
		var tmp15 bool; var na_671 any = top__22; if jrt.Long_InstanceOf(na_671) { var n0_672 int64 = jrt.NN(jrt.Long_Cast(na_671)).LongValue__J(); var n1_673 int64 = emax__3_l; tmp15 = n0_672 > n1_673 } else { var tmp16 any; if emax__3_b == nil { emax__3_b = jrt.Long_ValueOf_J__Long_NoInit(emax__3_l).Ref(); tmp16 = emax__3_b } else { tmp16 = emax__3_b }; tmp15 = lang.Numbers_Gt_O_O__Z_NoInit(na_671, tmp16) }; if tmp15 { return nil } else { var v__23 any; var tmp17 bool
			var na_675 any = qe__13
			if jrt.Long_InstanceOf(na_675) { var n0_676 int64 = jrt.NN(jrt.Long_Cast(na_675)).LongValue__J(); tmp17 = n0_676 < 0 } else { if jrt.Double_InstanceOf(na_675) { var n0_676_2 float64 = jrt.NN(jrt.Double_Cast(na_675)).DoubleValue__D(); tmp17 = n0_676_2 < 0.0 } else { tmp17 = lang.Numbers_IsNeg_O__Z_NoInit(na_675) } }; if tmp17 {
				var tmp18 any; var root_677 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any = m__21; if linked_678 == nil { tmp18 = ifn_679.Invoke_O__O(arg_680) } else { tmp18 = linked_678.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_677, arg_680) }; var tmp19 any = tmp18; var tmp20 any; var root_681 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_681, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_683 lang.IFn; if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any; var root_685 any = A_arbace_go_check_const_A_const_29.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, A_arbace_go_check_const_pow2_A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any; var na_689 any = qe__13; if jrt.Long_InstanceOf(na_689) { var n0_690 int64 = jrt.NN(jrt.Long_Cast(na_689)).LongValue__J(); if n0_690 == -9223372036854775808 { arg_688 = lang.Numbers_Minus_O__Number_NoInit(na_689) } else { arg_688 = jrt.Long_ValueOf_J__Long_NoInit(-n0_690).Ref() } } else { if jrt.Double_InstanceOf(na_689) { var n0_690_2 float64 = jrt.NN(jrt.Double_Cast(na_689)).DoubleValue__D(); arg_688 = jrt.Double_ValueOf_D__Double_NoInit(-n0_690_2).Ref() } else { arg_688 = lang.Numbers_Minus_O__Number_NoInit(na_689) } }; if linked_686 == nil { arg_684 = ifn_687.Invoke_O__O(arg_688) } else { arg_684 = linked_686.(*A_arbace_go_check_const_pow2_A).Invoke_O_O__O(root_685, arg_688) }; if linked_682 == nil { tmp20 = ifn_683.Invoke_O__O(arg_684) } else { tmp20 = linked_682.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_681, arg_684) }; v__23 = lang.Numbers_Divide_O_O__Number_NoInit(tmp19, tmp20) } else {
					var root_691 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = jrt.BigInteger_Cast(m__21).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(qe__13)); if linked_692 == nil { v__23 = ifn_693.Invoke_O__O(arg_694) } else { v__23 = linked_692.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_691, arg_694) } }
//line :250:1
			var v__24 any; var tmp21 any; var root_695 any = A_arbace_go_check_const_A_const_24.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_697 lang.IFn




			if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = v__23; if linked_696 == nil { tmp21 = ifn_697.Invoke_O__O(arg_698) } else { tmp21 = linked_696.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_695, arg_698) }; if jrt.J2g_Truth(tmp21) { v__24 = v__23 } else { var root_699 any = A_arbace_go_check_const_A_const_47.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, A_arbace_go_check_const_norm_int_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any; var root_703 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, A_arbace_go_check_const_bi_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = v__23; if linked_704 == nil { arg_702 = ifn_705.Invoke_O__O(arg_706) } else { arg_702 = linked_704.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_703, arg_706) }; if linked_700 == nil { v__24 = ifn_701.Invoke_O__O(arg_702) } else { v__24 = linked_700.(*A_arbace_go_check_const_norm_int_A).Invoke_O_O__O(root_699, arg_702) } }
			if neg__9 { var na_707 any = v__24; if jrt.Long_InstanceOf(na_707) { var n0_708 int64 = jrt.NN(jrt.Long_Cast(na_707)).LongValue__J(); if n0_708 == -9223372036854775808 { return lang.Numbers_Minus_O__Number_NoInit(na_707) } else { return jrt.Long_ValueOf_J__Long_NoInit(-n0_708).Ref() } } else { if jrt.Double_InstanceOf(na_707) { var n0_708_2 float64 = jrt.NN(jrt.Double_Cast(na_707)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(-n0_708_2).Ref() } else { return lang.Numbers_Minus_O__Number_NoInit(na_707) } } } else { return v__24 } } } }

func A_arbace_go_check_const_round64_A_New() *A_arbace_go_check_const_round64_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_round64_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_go_check_const_round64_A) Ctor() {}
//line :258:1
func (t *A_arbace_go_check_const_round64_A) Invoke_O_O__O(self, x__0 any) any { var root_711 any = A_arbace_go_check_const_A_const_49.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_711, A_arbace_go_check_const_round_binary_A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = x__0; var arg_716 any = A_arbace_go_check_const_A_const_51; if linked_712 == nil { return ifn_713.Invoke_O_O_O_O__O(arg_714, A_arbace_go_check_const_A_const_50, arg_716, A_arbace_go_check_const_A_const_52) } else { return linked_712.(*A_arbace_go_check_const_round_binary_A).InvokeSpec_O_O_J_O_O_J_O__O(root_711, arg_714, 53, A_arbace_go_check_const_A_const_50, arg_716, 1023, A_arbace_go_check_const_A_const_52) } }
func A_arbace_go_check_const_round32_A_New() *A_arbace_go_check_const_round32_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_round32_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_go_check_const_round32_A) Ctor() {}
//line :259:1
func (t *A_arbace_go_check_const_round32_A) Invoke_O_O__O(self, x__0 any) any { var root_718 any = A_arbace_go_check_const_A_const_49.GetRawRoot__O(); var linked_719 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_718, A_arbace_go_check_const_round_binary_A_fn_class); var ifn_720 lang.IFn; if linked_719 == nil { ifn_720 = lang.IFn_Cast(root_718) } else { ifn_720 = nil }; var arg_721 any = x__0; var arg_723 any = A_arbace_go_check_const_A_const_54; if linked_719 == nil { return ifn_720.Invoke_O_O_O_O__O(arg_721, A_arbace_go_check_const_A_const_53, arg_723, A_arbace_go_check_const_A_const_55) } else { return linked_719.(*A_arbace_go_check_const_round_binary_A).InvokeSpec_O_O_J_O_O_J_O__O(root_718, arg_721, 24, A_arbace_go_check_const_A_const_53, arg_723, 127, A_arbace_go_check_const_A_const_55) } }

func A_arbace_go_check_const_exact_of_double_A_New() *A_arbace_go_check_const_exact_of_double_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_exact_of_double_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_go_check_const_exact_of_double_A) Ctor() {}
//line :261:1
func (t *A_arbace_go_check_const_exact_of_double_A) InvokePrim_O_D__O(self any, d__0 float64) any {


	if lang.Numbers_IsZero_D__Z_NoInit(d__0) { return A_arbace_go_check_const_A_const_17 } else { var bits__2 int64 = jrt.Double_DoubleToRawLongBits_D__J_NoInit(d__0); var neg__3 bool = lang.Numbers_IsNeg_J__Z_NoInit(bits__2); var ex__4 int64 = lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(bits__2, 52), 2047); var frac__5 int64 = lang.Numbers_And_J_J__J_NoInit(bits__2, 4503599627370495); var vec__161000094__6 any





		if lang.Numbers_IsZero_J__Z_NoInit(ex__4) { vec__161000094__6 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(frac__5).Ref(), A_arbace_go_check_const_A_const_56) } else { vec__161000094__6 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(frac__5, lang.Numbers_ShiftLeft_J_J__J_NoInit(1, 52))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(ex__4, 1075)).Ref()) }
//line :264:1
		var m__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000094__6, lang.RT_IntCast_J__I_NoInit(0), nil); var e__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000094__6, lang.RT_IntCast_J__I_NoInit(1), nil); var v__9 any; var tmp1 bool
		var na_725 any = e__8





		if jrt.Long_InstanceOf(na_725) { var n0_726 int64 = jrt.NN(jrt.Long_Cast(na_725)).LongValue__J(); tmp1 = n0_726 < 0 } else { if jrt.Double_InstanceOf(na_725) { var n0_726_2 float64 = jrt.NN(jrt.Double_Cast(na_725)).DoubleValue__D(); tmp1 = n0_726_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_725) } }; if tmp1 { var tmp2 any; var root_727 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = m__7; if linked_728 == nil { tmp2 = ifn_729.Invoke_O__O(arg_730) } else { tmp2 = linked_728.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_727, arg_730) }; var tmp3 any = tmp2; var tmp4 any; var root_731 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_731, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_733 lang.IFn; if linked_732 == nil { ifn_733 = lang.IFn_Cast(root_731) } else { ifn_733 = nil }; var arg_734 any; var root_735 any = A_arbace_go_check_const_A_const_29.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, A_arbace_go_check_const_pow2_A_fn_class); var ifn_737 lang.IFn; if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any; var na_739 any = e__8; if jrt.Long_InstanceOf(na_739) { var n0_740 int64 = jrt.NN(jrt.Long_Cast(na_739)).LongValue__J(); if n0_740 == -9223372036854775808 { arg_738 = lang.Numbers_Minus_O__Number_NoInit(na_739) } else { arg_738 = jrt.Long_ValueOf_J__Long_NoInit(-n0_740).Ref() } } else { if jrt.Double_InstanceOf(na_739) { var n0_740_2 float64 = jrt.NN(jrt.Double_Cast(na_739)).DoubleValue__D(); arg_738 = jrt.Double_ValueOf_D__Double_NoInit(-n0_740_2).Ref() } else { arg_738 = lang.Numbers_Minus_O__Number_NoInit(na_739) } }; if linked_736 == nil { arg_734 = ifn_737.Invoke_O__O(arg_738) } else { arg_734 = linked_736.(*A_arbace_go_check_const_pow2_A).Invoke_O_O__O(root_735, arg_738) }; if linked_732 == nil { tmp4 = ifn_733.Invoke_O__O(arg_734) } else { tmp4 = linked_732.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_731, arg_734) }; v__9 = lang.Numbers_Divide_O_O__Number_NoInit(tmp3, tmp4) } else { var root_741 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any; var tmp5 any; var root_745 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, A_arbace_go_check_const_bi_A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any = m__7; if linked_746 == nil { tmp5 = ifn_747.Invoke_O__O(arg_748) } else { tmp5 = linked_746.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_745, arg_748) }; arg_744 = jrt.BigInteger_Cast(tmp5).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(e__8)); if linked_742 == nil { v__9 = ifn_743.Invoke_O__O(arg_744) } else { v__9 = linked_742.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_741, arg_744) } }
//line :264:1
		var v__10 any; var tmp6 any; var root_749 any = A_arbace_go_check_const_A_const_24.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_751 lang.IFn







		if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = v__9; if linked_750 == nil { tmp6 = ifn_751.Invoke_O__O(arg_752) } else { tmp6 = linked_750.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_749, arg_752) }; if jrt.J2g_Truth(tmp6) { v__10 = v__9 } else { var root_753 any = A_arbace_go_check_const_A_const_47.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, A_arbace_go_check_const_norm_int_A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any; var root_757 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, A_arbace_go_check_const_bi_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = v__9; if linked_758 == nil { arg_756 = ifn_759.Invoke_O__O(arg_760) } else { arg_756 = linked_758.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_757, arg_760) }; if linked_754 == nil { v__10 = ifn_755.Invoke_O__O(arg_756) } else { v__10 = linked_754.(*A_arbace_go_check_const_norm_int_A).Invoke_O_O__O(root_753, arg_756) } }
		if neg__3 { var na_761 any = v__10; if jrt.Long_InstanceOf(na_761) { var n0_762 int64 = jrt.NN(jrt.Long_Cast(na_761)).LongValue__J(); if n0_762 == -9223372036854775808 { return lang.Numbers_Minus_O__Number_NoInit(na_761) } else { return jrt.Long_ValueOf_J__Long_NoInit(-n0_762).Ref() } } else { if jrt.Double_InstanceOf(na_761) { var n0_762_2 float64 = jrt.NN(jrt.Double_Cast(na_761)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(-n0_762_2).Ref() } else { return lang.Numbers_Minus_O__Number_NoInit(na_761) } } } else { return v__10 } } }
//line :261:1
func (t *A_arbace_go_check_const_exact_of_double_A) Invoke_O_O__O(self, p_d__0 any) any { return t.InvokePrim_O_D__O(self, lang.RT_DoubleCast_O__D_NoInit(p_d__0)) }













func A_arbace_go_check_const_to_double_A_New() *A_arbace_go_check_const_to_double_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_to_double_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_go_check_const_to_double_A) Ctor() {}
//line :275:1
func (t *A_arbace_go_check_const_to_double_A) InvokePrim_O_O__D(self, x__0 any) float64 { var tmp1 any; var r__2 any; var root_763 any = A_arbace_go_check_const_A_const_57.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, A_arbace_go_check_const_round64_A_fn_class); var ifn_765 lang.IFn; if


	linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = x__0; if linked_764 == nil { r__2 = ifn_765.Invoke_O__O(arg_766) } else { r__2 = linked_764.(*A_arbace_go_check_const_round64_A).Invoke_O_O__O(root_763, arg_766) }; if
	lang.Util_Identical_O_O__Z_NoInit(r__2, nil) {
		var tmp2 int64; var root_767 any = A_arbace_go_check_const_A_const_44.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_767, A_arbace_go_check_const_fsign_A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = x__0; if linked_768 == nil { tmp2 = lang.RT_LongCast_O__J_NoInit(ifn_769.Invoke_O__O(arg_770)) } else { tmp2 = linked_768.(*A_arbace_go_check_const_fsign_A).InvokePrim_O_O__J(root_767, arg_770) }; if lang.Numbers_IsPos_J__Z_NoInit(tmp2) { tmp1 = jrt.Double_ValueOf_D__Double_NoInit(jrt.PosInf64).Ref() } else { tmp1 = jrt.Double_ValueOf_D__Double_NoInit(jrt.NegInf64).Ref() } } else {
//line :279:1
			var tmp3 any; var root_771 any = A_arbace_go_check_const_A_const_24.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_773 lang.IFn

			if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = r__2; if linked_772 == nil { tmp3 = ifn_773.Invoke_O__O(arg_774) } else { tmp3 = linked_772.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_771, arg_774) }
//line :279:1
			if jrt.J2g_Truth(tmp3) {

				var tmp4 any; var root_796 any = A_arbace_go_check_const_A_const_60.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_check_const_A_const_61.GetRawRoot__O()); var tmp6 any = A_arbace_go_check_const_A_const_62; var arg_799 any = tmp5.Invoke_O_O__O(tmp6, jrt.MathContext_New_I(lang.RT_IntCast_J__I_NoInit(40))); if linked_797 == nil { ifn_798.Invoke_O__O(arg_799) } else { linked_797.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_796, arg_799) }; var tmp7 *lang.Compiler_AOTFn; var fnbody__795 any = A_arbace_go_check_const_to_double_fn__161000098_A_New_O(r__2); var tmp8 *jrt.Class; var fncls__794 *jrt.Class = A_arbace_go_check_const_to_double_fn__161000098_A_fn_class; if fncls__794 == nil { var fncls__794d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__795); A_arbace_go_check_const_to_double_fn__161000098_A_fn_class = fncls__794d; tmp8 = fncls__794d } else { tmp8 = fncls__794 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__795, tmp8, nil); tmp4 = Up_Compiler_AOTFn_IFn(tmp7).Invoke__O(); tmp1 = lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(tmp4, Lit_6, false) } else {
//line :279:1
					if A_arbace_go_check_const_A_const_8 != nil {


						tmp1 = jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(r__2)).Ref() } else {
//line :279:1
							tmp1 = nil } } }; return /*line :275:1*/ jrt.Number_Cast(tmp1).DoubleValue__D() }
//line :275:1
func (t *A_arbace_go_check_const_to_double_A) Invoke_O_O__O(self, x__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_O__D(self, x__0)).Ref() }





func A_arbace_go_check_const_to_double_fn__161000098_A_New_O(p0 any) *A_arbace_go_check_const_to_double_fn__161000098_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_to_double_fn__161000098_A{}; t.Ctor_O(p0); return t }
//line :281:1
func (t *A_arbace_go_check_const_to_double_fn__161000098_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :281:1
func (t *A_arbace_go_check_const_to_double_fn__161000098_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var root_775 any = A_arbace_go_check_const_A_const_58.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_bigdec_A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any; var root_779 any = A_arbace_go_check_const_A_const_25.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_numerator_A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = t.F_r; if linked_780 == nil { arg_778 = ifn_781.Invoke_O__O(arg_782) } else { arg_778 = linked_780.(*aot_arbace_core.A_arbace_core_numerator_A).Invoke_O_O__O(root_779, arg_782) }; if linked_776 == nil { tmp2 = ifn_777.Invoke_O__O(arg_778) } else { tmp2 = linked_776.(*aot_arbace_core.A_arbace_core_bigdec_A).Invoke_O_O__O(root_775, arg_778) }; var tmp3 any = tmp2; var tmp4 any; var root_783 any = A_arbace_go_check_const_A_const_58.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_core.A_arbace_core_bigdec_A_fn_class); var ifn_785 lang.IFn; if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any; var root_787 any = A_arbace_go_check_const_A_const_26.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_core.A_arbace_core_denominator_A_fn_class); var ifn_789 lang.IFn; if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any; var t_ any = t.F_r; t.F_r = nil; arg_790 = t_; if linked_788 == nil { arg_786 = ifn_789.Invoke_O__O(arg_790) } else { arg_786 = linked_788.(*aot_arbace_core.A_arbace_core_denominator_A).Invoke_O_O__O(root_787, arg_790) }; if linked_784 == nil { tmp4 = ifn_785.Invoke_O__O(arg_786) } else { tmp4 = linked_784.(*aot_arbace_core.A_arbace_core_bigdec_A).Invoke_O_O__O(root_783, arg_786) }; tmp1 = lang.Numbers_Divide_O_O__Number_NoInit(tmp3, tmp4) }; return nil }(); var root_791 any = A_arbace_go_check_const_A_const_59.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; if linked_792 == nil { ifn_793.Invoke__O() } else { linked_792.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_791) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }




func A_arbace_go_check_const_latin1_A_New() *A_arbace_go_check_const_latin1_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_latin1_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_go_check_const_latin1_A) Ctor() {}
//line :286:1
func (t *A_arbace_go_check_const_latin1_A) Invoke_O_O__O(self, bs__0 any) any { return jrt.String_New_B1_Charset(jrt.ByteArray_Cast(bs__0), jrt.StandardCharsets_ISO_8859_1) }




func A_arbace_go_check_const_utf8_value_A_New() *A_arbace_go_check_const_utf8_value_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_utf8_value_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_go_check_const_utf8_value_A) Ctor() {}
//line :291:1
func (t *A_arbace_go_check_const_utf8_value_A) Invoke_O_O__O(self, s__0 any) any {


	var root_805 any = A_arbace_go_check_const_A_const_63.GetRawRoot__O(); var linked_806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_805, A_arbace_go_check_const_latin1_A_fn_class); var ifn_807 lang.IFn; if linked_806 == nil { ifn_807 = lang.IFn_Cast(root_805) } else { ifn_807 = nil }; var arg_808 any = jrt.NN(jrt.String_Cast(s__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref(); if linked_806 == nil { return ifn_807.Invoke_O__O(arg_808) } else { return linked_806.(*A_arbace_go_check_const_latin1_A).Invoke_O_O__O(root_805, arg_808)
	} }
func A_arbace_go_check_const_value_bytes_A_New() *A_arbace_go_check_const_value_bytes_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_value_bytes_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_go_check_const_value_bytes_A) Ctor() {}
//line :296:1
func (t *A_arbace_go_check_const_value_bytes_A) Invoke_O_O__O(self, v__0 any) any { return jrt.NN(jrt.String_Cast(v__0)).GetBytes_Charset__B1(jrt.StandardCharsets_ISO_8859_1).Ref() }

func A_arbace_go_check_const_value_text_A_New() *A_arbace_go_check_const_value_text_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_value_text_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_go_check_const_value_text_A) Ctor() {}
//line :298:1
func (t *A_arbace_go_check_const_value_text_A) Invoke_O_O__O(self, v__0 any) any { var tmp1 any; var root_809 any = A_arbace_go_check_const_A_const_64.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, A_arbace_go_check_const_value_bytes_A_fn_class); var ifn_811 lang.IFn; if


	linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = v__0; if linked_810 == nil { tmp1 = ifn_811.Invoke_O__O(arg_812) } else { tmp1 = linked_810.(*A_arbace_go_check_const_value_bytes_A).Invoke_O_O__O(root_809, arg_812) }; return /*line :298:1*/ jrt.String_New_B1_Charset(jrt.ByteArray_Cast(tmp1), jrt.StandardCharsets_UTF_8) }




func A_arbace_go_check_const_rune_string_A_New() *A_arbace_go_check_const_rune_string_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_rune_string_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_go_check_const_rune_string_A) Ctor() {}
//line :303:1
func (t *A_arbace_go_check_const_rune_string_A) Invoke_O_O__O(self, r__0 any) any { var r__2 int64; var tmp1 any; var and__1927000168__auto____2 bool = jrt.Long_InstanceOf(r__0); if and__1927000168__auto____2 {


	var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_check_const_A_const_65.GetRawRoot__O()); var tmp3 any = A_arbace_go_check_const_A_const_17; var and__1927000168__auto____3 any = tmp2.Invoke_O_O_O__O(tmp3, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(r__0)).Ref(), A_arbace_go_check_const_A_const_66); if jrt.J2g_Truth(and__1927000168__auto____3) { var root_819 any = A_arbace_go_check_const_A_const_28.GetRawRoot__O(); var linked_820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_819, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_821 lang.IFn; if linked_820 == nil { ifn_821 = lang.IFn_Cast(root_819) } else { ifn_821 = nil }; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_const_A_const_65.GetRawRoot__O()); var tmp5 any = A_arbace_go_check_const_A_const_67; var arg_822 any = tmp4.Invoke_O_O_O__O(tmp5, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(r__0)).Ref(), A_arbace_go_check_const_A_const_68); if linked_820 == nil { tmp1 = ifn_821.Invoke_O__O(arg_822) } else { tmp1 = linked_820.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_819, arg_822) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) {
		r__2 = lang.RT_LongCast_O__J_NoInit(r__0) } else {
//line :306:1
			r__2 = 65533 }; var root_829 any =

	A_arbace_go_check_const_A_const_69.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, A_arbace_go_check_const_utf8_value_A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = jrt.String_New_C1(jrt.Character_ToChars_I__C1_NoInit(lang.RT_IntCast_J__I_NoInit(r__2))); if linked_830 == nil { return ifn_831.Invoke_O__O(arg_832) } else { return linked_830.(*A_arbace_go_check_const_utf8_value_A).Invoke_O_O__O(root_829, arg_832) } }

func A_arbace_go_check_const_rnd_A_New() *A_arbace_go_check_const_rnd_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_rnd_A{}; t.Ctor(); return t }
//line :310:1
func (t *A_arbace_go_check_const_rnd_A) Ctor() {}
//line :310:1
func (t *A_arbace_go_check_const_rnd_A) Invoke_O_O_O_O_O__O(self, m__0, e__1, p__2, sticky__3 any) any { var vec__161000106__5 any; var root_833 any = A_arbace_go_check_const_A_const_18.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, A_arbace_go_check_const_round_int_A_fn_class); var ifn_835 lang.IFn; if


	linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = m__0; var arg_837 any = sticky__3; var arg_838 any = p__2; if linked_834 == nil { vec__161000106__5 = ifn_835.Invoke_O_O_O__O(arg_836, arg_837, arg_838) } else { vec__161000106__5 = linked_834.(*A_arbace_go_check_const_round_int_A).Invoke_O_O_O_O__O(root_833, arg_836, arg_837, arg_838) }; var m2__6 any = /*line :310:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__161000106__5, lang.RT_IntCast_J__I_NoInit(0), nil); var sh__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000106__5, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(m2__6, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e__1), lang.RT_LongCast_O__J_NoInit(sh__7))).Ref()) }




func A_arbace_go_check_const_pmul_A_New() *A_arbace_go_check_const_pmul_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_pmul_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_go_check_const_pmul_A) Ctor() {}
//line :315:1
func (t *A_arbace_go_check_const_pmul_A) Invoke_O_O_O_O__O(self, p__161000110__0, p__161000111__1, p__2 any) any { var vec__161000112__4 any = p__161000110__0; var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000112__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000112__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__161000115__7 any = p__161000111__1; var m2__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000115__7, lang.RT_IntCast_J__I_NoInit(0), nil); var e2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000115__7, lang.RT_IntCast_J__I_NoInit(1), nil); var root_839 any = A_arbace_go_check_const_A_const_70.GetRawRoot__O(); var linked_840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_839, A_arbace_go_check_const_rnd_A_fn_class); var ifn_841 lang.IFn; if linked_840 == nil { ifn_841 = lang.IFn_Cast(root_839) } else { ifn_841 = nil }; var arg_842 any = jrt.BigInteger_Cast(m1__5).Multiply_BigInteger__BigInteger(jrt.BigInteger_Cast(m2__8)); var arg_843 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e1__6), lang.RT_LongCast_O__J_NoInit(e2__9))).Ref(); var arg_844 any = p__2; var arg_845 any = jrt.Boolean_FALSE.Ref(); if linked_840 == nil { return ifn_841.Invoke_O_O_O_O__O(arg_842, arg_843, arg_844, arg_845) } else { return linked_840.(*A_arbace_go_check_const_rnd_A).Invoke_O_O_O_O_O__O(root_839, arg_842, arg_843, arg_844, arg_845) } }

func A_arbace_go_check_const_pquo_A_New() *A_arbace_go_check_const_pquo_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_pquo_A{}; t.Ctor(); return t }
//line :317:1
func (t *A_arbace_go_check_const_pquo_A) Ctor() {}
//line :317:1
func (t *A_arbace_go_check_const_pquo_A) Invoke_O_O_O_O__O(self, p__161000119__0, p__161000120__1, p__2 any) any { if jrt.Long_InstanceOf(p__2) { return t.InvokeSpec_O_O_O_J_O__O(self, p__161000119__0, p__161000120__1, jrt.NN(jrt.Long_Cast(p__2)).LongValue__J(), p__2) } else { var vec__161000121__4 any = p__161000119__0; var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000121__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000121__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__161000124__7 any = p__161000120__1; var m2__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000124__7, lang.RT_IntCast_J__I_NoInit(0), nil); var e2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000124__7, lang.RT_IntCast_J__I_NoInit(1), nil); var k__10 any; var tmp1 jrt.Number_I; var na_846 any; var na_848 any = p__2; var na_849 int64 = 2
															if jrt.Long_InstanceOf(na_848) { var n0_850 int64 = jrt.NN(jrt.Long_Cast(na_848)).LongValue__J(); var n1_851 int64 = na_849; var nr_852 int64 = n0_850 + n1_851; if (n0_850^nr_852)&(n1_851^nr_852) >= 0 { na_846 = jrt.Long_ValueOf_J__Long_NoInit(nr_852).Ref() } else { na_846 = lang.Numbers_Add_O_J__Number_NoInit(na_848, na_849) } } else { na_846 = lang.Numbers_Add_O_J__Number_NoInit(na_848, na_849) }; var na_847 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.BigInteger_Cast(m2__8).Abs__BigInteger().BitLength__I()), int64(jrt.BigInteger_Cast(m1__5).Abs__BigInteger().BitLength__I())); if jrt.Long_InstanceOf(na_846) { var n0_853 int64 = jrt.NN(jrt.Long_Cast(na_846)).LongValue__J(); var n1_854 int64 = na_847; var nr_855 int64 = n0_853 + n1_854; if (n0_853^nr_855)&(n1_854^nr_855) >= 0 { tmp1 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_855)) } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_846, na_847) } } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_846, na_847) }; k__10 = lang.Numbers_Max_J_O__O_NoInit(0, tmp1)
//line :317:1
	var dr__11 any = jrt.BigInteger_Cast(m1__5).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(k__10)).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(m2__8)).Ref(); var root_856 any = A_arbace_go_check_const_A_const_70.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, A_arbace_go_check_const_rnd_A_fn_class); var ifn_858 lang.IFn


	if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(dr__11), lang.RT_IntCast_J__I_NoInit(0)); var arg_860 any; var na_863 int64 = lang.Numbers_Minus_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e1__6), lang.RT_LongCast_O__J_NoInit(e2__9)); var na_864 any = k__10; if jrt.Long_InstanceOf(na_864) { var n0_865 int64 = na_863; var n1_866 int64 = jrt.NN(jrt.Long_Cast(na_864)).LongValue__J(); var nr_867 int64 = n0_865 - n1_866; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_866 == -9223372036854775808); if tmp3 { tmp3 = (n0_865^n1_866)&(n0_865^nr_867) >= 0 }; tmp2 = tmp3; if tmp2 { arg_860 = jrt.Long_ValueOf_J__Long_NoInit(nr_867).Ref() } else { arg_860 = lang.Numbers_Minus_J_O__Number_NoInit(na_863, na_864) } } else { arg_860 = lang.Numbers_Minus_J_O__Number_NoInit(na_863, na_864) }; var arg_861 any = p__2; var arg_862 any; var root_868 any = A_arbace_go_check_const_A_const_28.GetRawRoot__O(); var linked_869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_868, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_870 lang.IFn; if linked_869 == nil { ifn_870 = lang.IFn_Cast(root_868) } else { ifn_870 = nil }; var arg_871 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.BigInteger_Cast(lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(dr__11), lang.RT_IntCast_J__I_NoInit(1))).Signum__I()))).Ref(); if linked_869 == nil { arg_862 = ifn_870.Invoke_O__O(arg_871) } else { arg_862 = linked_869.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_868, arg_871) }; if linked_857 == nil { return ifn_858.Invoke_O_O_O_O__O(arg_859, arg_860, arg_861, arg_862) } else { return linked_857.(*A_arbace_go_check_const_rnd_A).Invoke_O_O_O_O_O__O(root_856, arg_859, arg_860, arg_861, arg_862) } } }
//line :317:1
func (t *A_arbace_go_check_const_pquo_A) InvokeSpec_O_O_O_J_O__O(self, p__161000119__0, p__161000120__1 any, p__2_l int64, p__2_b any) any { var vec__161000121__4 any = p__161000119__0; var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000121__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000121__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__161000124__7 any = p__161000120__1; var m2__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000124__7, lang.RT_IntCast_J__I_NoInit(0), nil); var e2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000124__7, lang.RT_IntCast_J__I_NoInit(1), nil); var k__10 any; var tmp1 jrt.Number_I; var na_872 any; var na_874 int64 = 2; var n0_875 int64 = p__2_l; var n1_876 int64 = na_874; var nr_877 int64 = n0_875 + n1_876; if
																		(n0_875^nr_877)&(n1_876^nr_877) >= 0 { na_872 = jrt.Long_ValueOf_J__Long_NoInit(nr_877).Ref() } else { var tmp2 any; if p__2_b == nil { p__2_b = jrt.Long_ValueOf_J__Long_NoInit(p__2_l).Ref(); tmp2 = p__2_b } else { tmp2 = p__2_b }; na_872 = lang.Numbers_Add_O_J__Number_NoInit(tmp2, na_874) }; var na_873 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.BigInteger_Cast(m2__8).Abs__BigInteger().BitLength__I()), int64(jrt.BigInteger_Cast(m1__5).Abs__BigInteger().BitLength__I())); if jrt.Long_InstanceOf(na_872) { var n0_878 int64 = jrt.NN(jrt.Long_Cast(na_872)).LongValue__J(); var n1_879 int64 = na_873; var nr_880 int64 = n0_878 + n1_879; if (n0_878^nr_880)&(n1_879^nr_880) >= 0 { tmp1 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_880)) } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_872, na_873) } } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_872, na_873) }; k__10 = lang.Numbers_Max_J_O__O_NoInit(0, tmp1); var dr__11 any = /*line :317:1*/jrt.BigInteger_Cast(m1__5).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(k__10)).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(m2__8)).Ref(); var root_881 any = A_arbace_go_check_const_A_const_70.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, A_arbace_go_check_const_rnd_A_fn_class); var ifn_883 lang.IFn; if


	linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(dr__11), lang.RT_IntCast_J__I_NoInit(0)); var arg_885 any; var na_888 int64 = lang.Numbers_Minus_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e1__6), lang.RT_LongCast_O__J_NoInit(e2__9)); var na_889 any = k__10; if jrt.Long_InstanceOf(na_889) { var n0_890 int64 = na_888; var n1_891 int64 = jrt.NN(jrt.Long_Cast(na_889)).LongValue__J(); var nr_892 int64 = n0_890 - n1_891; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_891 == -9223372036854775808); if tmp4 { tmp4 = (n0_890^n1_891)&(n0_890^nr_892) >= 0 }; tmp3 = tmp4; if tmp3 { arg_885 = jrt.Long_ValueOf_J__Long_NoInit(nr_892).Ref() } else { arg_885 = lang.Numbers_Minus_J_O__Number_NoInit(na_888, na_889) } } else { arg_885 = lang.Numbers_Minus_J_O__Number_NoInit(na_888, na_889) }; var arg_886 any; if p__2_b == nil { p__2_b = jrt.Long_ValueOf_J__Long_NoInit(p__2_l).Ref(); arg_886 = p__2_b } else { arg_886 = p__2_b }; var arg_887 any; var root_893 any = A_arbace_go_check_const_A_const_28.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.BigInteger_Cast(lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(dr__11), lang.RT_IntCast_J__I_NoInit(1))).Signum__I()))).Ref(); if linked_894 == nil { arg_887 = ifn_895.Invoke_O__O(arg_896) } else { arg_887 = linked_894.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_893, arg_896) }; if linked_882 == nil { return ifn_883.Invoke_O_O_O_O__O(arg_884, arg_885, arg_886, arg_887) } else { return linked_882.(*A_arbace_go_check_const_rnd_A).Invoke_O_O_O_O_O__O(root_881, arg_884, arg_885, arg_886, arg_887) } }



func A_arbace_go_check_const_pow5_A_New() *A_arbace_go_check_const_pow5_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_pow5_A{}; t.Ctor(); return t }
//line :324:1
func (t *A_arbace_go_check_const_pow5_A) Ctor() {}
//line :324:1
func (t *A_arbace_go_check_const_pow5_A) Invoke_O_O_O__O(self, n__0, prec__1 any) any { { var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(n__0); if tmp2 { tmp2 = jrt.Long_InstanceOf(prec__1) }; tmp1 = tmp2; if tmp1 { return t.InvokeSpec_O_J_O_J_O__O(self, jrt.NN(jrt.Long_Cast(n__0)).LongValue__J(), n__0, jrt.NN(jrt.Long_Cast(prec__1)).LongValue__J(), prec__1) } else {


	var tmp3 bool; var na_897 any = n__0; var na_898 int64 = 27; if jrt.Long_InstanceOf(na_897) { var n0_899 int64 = jrt.NN(jrt.Long_Cast(na_897)).LongValue__J(); var n1_900 int64 = na_898; tmp3 = n0_899 <= n1_900 } else { tmp3 = lang.Numbers_Lte_O_J__Z_NoInit(na_897, na_898) }; if tmp3 { return lang.Tuple_Create_O_O__IPersistentVector(jrt.BigInteger_ValueOf_J__BigInteger(5).Pow_I__BigInteger(lang.RT_IntCast_O__I_NoInit(n__0)), A_arbace_go_check_const_A_const_17) } else { var z__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_const_A_const_71.GetRawRoot__O(), A_arbace_go_check_const_A_const_17); var f__4 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.BigInteger_ValueOf_J__BigInteger(5), A_arbace_go_check_const_A_const_17); var n__5 any
		var na_902 any = n__0; var na_903 int64 = 27
		if jrt.Long_InstanceOf(na_902) { var n0_904 int64 = jrt.NN(jrt.Long_Cast(na_902)).LongValue__J(); var n1_905 int64 = na_903; var nr_906 int64 = n0_904 - n1_905; var tmp4 bool; var tmp5 bool; tmp5 = !(n1_905 == -9223372036854775808); if tmp5 { tmp5 = (n0_904^n1_905)&(n0_904^nr_906) >= 0 }; tmp4 = tmp5; if tmp4 { n__5 = jrt.Long_ValueOf_J__Long_NoInit(nr_906).Ref() } else { n__5 = lang.Numbers_Minus_O_J__Number_NoInit(na_902, na_903) } } else { n__5 = lang.Numbers_Minus_O_J__Number_NoInit(na_902, na_903) }
//line :327:1
	L1: for {


		var tmp6 bool; var na_907 any = n__5; if jrt.Long_InstanceOf(na_907) { var n0_908 int64 = jrt.NN(jrt.Long_Cast(na_907)).LongValue__J(); tmp6 = n0_908 == 0 } else { if jrt.Double_InstanceOf(na_907) { var n0_908_2 float64 = jrt.NN(jrt.Double_Cast(na_907)).DoubleValue__D(); tmp6 = n0_908_2 == 0.0 } else { tmp6 = lang.Numbers_IsZero_O__Z_NoInit(na_907) } }; if tmp6 { return z__3 } else {

			var tmp7 any; var tmp8 any; var root_909 any = A_arbace_go_check_const_A_const_72.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_odd_QMARK__A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = n__5; if linked_910 == nil { tmp8 = ifn_911.Invoke_O__O(arg_912) } else { tmp8 = linked_910.(*aot_arbace_core.A_arbace_core_odd_QMARK__A).Invoke_O_O__O(root_909, arg_912) }; if jrt.J2g_Truth(tmp8) { var root_913 any = A_arbace_go_check_const_A_const_73.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, A_arbace_go_check_const_pmul_A_fn_class); var ifn_915 lang.IFn; if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = z__3; var arg_917 any = f__4; var arg_918 any = prec__1; if linked_914 == nil { tmp7 = ifn_915.Invoke_O_O_O__O(arg_916, arg_917, arg_918) } else { tmp7 = linked_914.(*A_arbace_go_check_const_pmul_A).Invoke_O_O_O_O__O(root_913, arg_916, arg_917, arg_918) } } else { tmp7 = z__3 }; var tmp9 any = tmp7; var tmp10 any; var root_919 any = A_arbace_go_check_const_A_const_73.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, A_arbace_go_check_const_pmul_A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = f__4; var arg_923 any = f__4; var arg_924 any; var na_925 any = prec__1; var na_926 int64 = 64; if jrt.Long_InstanceOf(na_925) { var n0_927 int64 = jrt.NN(jrt.Long_Cast(na_925)).LongValue__J(); var n1_928 int64 = na_926; var nr_929 int64 = n0_927 + n1_928; if (n0_927^nr_929)&(n1_928^nr_929) >= 0 { arg_924 = jrt.Long_ValueOf_J__Long_NoInit(nr_929).Ref() } else { arg_924 = lang.Numbers_Add_O_J__Number_NoInit(na_925, na_926) } } else { arg_924 = lang.Numbers_Add_O_J__Number_NoInit(na_925, na_926) }; if linked_920 == nil { tmp10 = ifn_921.Invoke_O_O_O__O(arg_922, arg_923, arg_924) } else { tmp10 = linked_920.(*A_arbace_go_check_const_pmul_A).Invoke_O_O_O_O__O(root_919, arg_922, arg_923, arg_924) }; var tmp11 any = tmp10; var tmp12 jrt.Number_I; var na_930 any = n__5; var na_931 int64 = 2; if jrt.Long_InstanceOf(na_930) { var n0_932 int64 = jrt.NN(jrt.Long_Cast(na_930)).LongValue__J(); var n1_933 int64 = na_931; if n1_933 == 0 { tmp12 = lang.Numbers_Quotient_O_J__Number_NoInit(na_930, na_931) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_932 / n1_933)) } } else { tmp12 = lang.Numbers_Quotient_O_J__Number_NoInit(na_930, na_931) }; z__3, f__4, n__5 = tmp9, tmp11, tmp12; continue L1 } } } } }; /*line :324:1*/panic("j2g: unreachable") }
//line :324:1
func (t *A_arbace_go_check_const_pow5_A) InvokeSpec_O_J_O_J_O__O(self any, n__0_l int64, n__0_b any, prec__1_l int64, prec__1_b any) any {


	{ var tmp1 bool; var na_935 int64 = 27; var n0_936 int64 = n__0_l; var n1_937 int64 = na_935; tmp1 = n0_936 <= n1_937; if tmp1 { var tmp2 jrt.BigInteger_I = jrt.BigInteger_ValueOf_J__BigInteger(5); var tmp3 any
		if n__0_b == nil { n__0_b = jrt.Long_ValueOf_J__Long_NoInit(n__0_l).Ref(); tmp3 = n__0_b } else { tmp3 = n__0_b }
//line :327:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp2.Pow_I__BigInteger(lang.RT_IntCast_O__I_NoInit(tmp3)), A_arbace_go_check_const_A_const_17) } else { var z__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_const_A_const_71.GetRawRoot__O(), A_arbace_go_check_const_A_const_17); var f__4 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.BigInteger_ValueOf_J__BigInteger(5), A_arbace_go_check_const_A_const_17); var n__5 any; var na_939 int64 = 27; var n0_940 int64 = n__0_l; var n1_941 int64 = na_939; var nr_942 int64 = n0_940 - n1_941; var tmp4 bool; var tmp5 bool

			tmp5 = !(n1_941 == -9223372036854775808); if tmp5 { tmp5 = (n0_940^n1_941)&(n0_940^nr_942) >= 0 }; tmp4 = tmp5; if tmp4 { n__5 = jrt.Long_ValueOf_J__Long_NoInit(nr_942).Ref() } else { var tmp6 any; if n__0_b == nil { n__0_b = jrt.Long_ValueOf_J__Long_NoInit(n__0_l).Ref(); tmp6 = n__0_b } else { tmp6 = n__0_b }; n__5 = lang.Numbers_Minus_O_J__Number_NoInit(tmp6, na_939) }
//line :327:1
		L1: for {


			var tmp7 bool; var na_943 any = n__5; if jrt.Long_InstanceOf(na_943) { var n0_944 int64 = jrt.NN(jrt.Long_Cast(na_943)).LongValue__J(); tmp7 = n0_944 == 0 } else { if jrt.Double_InstanceOf(na_943) { var n0_944_2 float64 = jrt.NN(jrt.Double_Cast(na_943)).DoubleValue__D(); tmp7 = n0_944_2 == 0.0 } else { tmp7 = lang.Numbers_IsZero_O__Z_NoInit(na_943) } }; if tmp7 { return z__3 } else {

				var tmp8 any; var tmp9 any; var root_945 any = A_arbace_go_check_const_A_const_72.GetRawRoot__O(); var linked_946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_945, aot_arbace_core.A_arbace_core_odd_QMARK__A_fn_class); var ifn_947 lang.IFn; if linked_946 == nil { ifn_947 = lang.IFn_Cast(root_945) } else { ifn_947 = nil }; var arg_948 any = n__5; if linked_946 == nil { tmp9 = ifn_947.Invoke_O__O(arg_948) } else { tmp9 = linked_946.(*aot_arbace_core.A_arbace_core_odd_QMARK__A).Invoke_O_O__O(root_945, arg_948) }; if jrt.J2g_Truth(tmp9) { var root_949 any = A_arbace_go_check_const_A_const_73.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_949, A_arbace_go_check_const_pmul_A_fn_class); var ifn_951 lang.IFn; if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_952 any = z__3; var arg_953 any = f__4; var arg_954 any; if prec__1_b == nil { prec__1_b = jrt.Long_ValueOf_J__Long_NoInit(prec__1_l).Ref(); arg_954 = prec__1_b } else { arg_954 = prec__1_b }; if linked_950 == nil { tmp8 = ifn_951.Invoke_O_O_O__O(arg_952, arg_953, arg_954) } else { tmp8 = linked_950.(*A_arbace_go_check_const_pmul_A).Invoke_O_O_O_O__O(root_949, arg_952, arg_953, arg_954) } } else { tmp8 = z__3 }; var tmp10 any = tmp8; var tmp11 any; var root_955 any = A_arbace_go_check_const_A_const_73.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_955, A_arbace_go_check_const_pmul_A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = f__4; var arg_959 any = f__4; var arg_960 any; var na_961 int64 = 64; var n0_962 int64 = prec__1_l; var n1_963 int64 = na_961; var nr_964 int64 = n0_962 + n1_963; if (n0_962^nr_964)&(n1_963^nr_964) >= 0 { arg_960 = jrt.Long_ValueOf_J__Long_NoInit(nr_964).Ref() } else { var tmp12 any; if prec__1_b == nil { prec__1_b = jrt.Long_ValueOf_J__Long_NoInit(prec__1_l).Ref(); tmp12 = prec__1_b } else { tmp12 = prec__1_b }; arg_960 = lang.Numbers_Add_O_J__Number_NoInit(tmp12, na_961) }; if linked_956 == nil { tmp11 = ifn_957.Invoke_O_O_O__O(arg_958, arg_959, arg_960) } else { tmp11 = linked_956.(*A_arbace_go_check_const_pmul_A).Invoke_O_O_O_O__O(root_955, arg_958, arg_959, arg_960) }; var tmp13 any = tmp11; var tmp14 jrt.Number_I; var na_965 any = n__5; var na_966 int64 = 2; if jrt.Long_InstanceOf(na_965) { var n0_967 int64 = jrt.NN(jrt.Long_Cast(na_965)).LongValue__J(); var n1_968 int64 = na_966; if n1_968 == 0 { tmp14 = lang.Numbers_Quotient_O_J__Number_NoInit(na_965, na_966) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_967 / n1_968)) } } else { tmp14 = lang.Numbers_Quotient_O_J__Number_NoInit(na_965, na_966) }; z__3, f__4, n__5 = tmp10, tmp13, tmp14; continue L1 } } } }
//line :324:1
	panic("j2g: unreachable")
}








func A_arbace_go_check_const_big_float_decimal_A_New() *A_arbace_go_check_const_big_float_decimal_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_big_float_decimal_A{}; t.Ctor(); return t }
//line :334:1
func (t *A_arbace_go_check_const_big_float_decimal_A) Ctor() {}
//line :334:1
func (t *A_arbace_go_check_const_big_float_decimal_A) Invoke_O_O_O__O(self, d__0, k__1 any) any { var p__3 any; var root_970 any = A_arbace_go_check_const_A_const_74.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_970, A_arbace_go_check_const_pow5_A_fn_class); var ifn_972 lang.IFn; if



	linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 int64 = jrt.Math_Abs_J__J(lang.RT_LongCast_O__J_NoInit(k__1)); var arg_974 any; var na_975 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O(); var na_976 int64 = 64; if jrt.Long_InstanceOf(na_975) { var n0_977 int64 = jrt.NN(jrt.Long_Cast(na_975)).LongValue__J(); var n1_978 int64 = na_976; var nr_979 int64 = n0_977 + n1_978; if (n0_977^nr_979)&(n1_978^nr_979) >= 0 { arg_974 = jrt.Long_ValueOf_J__Long_NoInit(nr_979).Ref() } else { arg_974 = lang.Numbers_Add_O_J__Number_NoInit(na_975, na_976) } } else { arg_974 = lang.Numbers_Add_O_J__Number_NoInit(na_975, na_976) }; if linked_971 == nil { p__3 = ifn_972.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_973).Ref(), arg_974) } else { if jrt.Long_InstanceOf(arg_974) { p__3 = linked_971.(*A_arbace_go_check_const_pow5_A).InvokeSpec_O_J_O_J_O__O(root_970, arg_973, nil, jrt.NN(jrt.Long_Cast(arg_974)).LongValue__J(), arg_974) } else { p__3 = linked_971.(*A_arbace_go_check_const_pow5_A).Invoke_O_O_O__O(root_970, jrt.Long_ValueOf_J__Long_NoInit(arg_973).Ref(), arg_974) } }; var vec__161000129__4 any; var tmp1 bool; var na_980 any = k__1; if
	jrt.Long_InstanceOf(na_980) { var n0_981 int64 = jrt.NN(jrt.Long_Cast(na_980)).LongValue__J(); tmp1 = n0_981 < 0 } else { if jrt.Double_InstanceOf(na_980) { var n0_981_2 float64 = jrt.NN(jrt.Double_Cast(na_980)).DoubleValue__D(); tmp1 = n0_981_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_980) } }; if tmp1 { var root_982 any = A_arbace_go_check_const_A_const_75.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_982, A_arbace_go_check_const_pquo_A_fn_class); var ifn_984 lang.IFn; if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = lang.Tuple_Create_O_O__IPersistentVector(d__0, k__1); var arg_986 any = p__3; var arg_987 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O(); if linked_983 == nil { vec__161000129__4 = ifn_984.Invoke_O_O_O__O(arg_985, arg_986, arg_987) } else { if jrt.Long_InstanceOf(arg_987) { vec__161000129__4 = linked_983.(*A_arbace_go_check_const_pquo_A).InvokeSpec_O_O_O_J_O__O(root_982, arg_985, arg_986, jrt.NN(jrt.Long_Cast(arg_987)).LongValue__J(), arg_987) } else { vec__161000129__4 = linked_983.(*A_arbace_go_check_const_pquo_A).Invoke_O_O_O_O__O(root_982, arg_985, arg_986, arg_987) } } } else { var root_988 any = A_arbace_go_check_const_A_const_73.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, A_arbace_go_check_const_pmul_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = lang.Tuple_Create_O_O__IPersistentVector(d__0, k__1); var arg_992 any = p__3; var arg_993 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O(); if linked_989 == nil { vec__161000129__4 = ifn_990.Invoke_O_O_O__O(arg_991, arg_992, arg_993) } else { vec__161000129__4 = linked_989.(*A_arbace_go_check_const_pmul_A).Invoke_O_O_O_O__O(root_988, arg_991, arg_992, arg_993) } }; var m__5 any = /*line :334:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__161000129__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000129__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_994 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_996 lang.IFn; if





	linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = m__5; var arg_998 any = e__6; if linked_995 == nil { return ifn_996.Invoke_O_O__O(arg_997, arg_998) } else { return linked_995.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O__O(root_994, arg_997, arg_998) } }

func A_arbace_go_check_const_decimal_exact_A_New() *A_arbace_go_check_const_decimal_exact_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_decimal_exact_A{}; t.Ctor(); return t }
//line :342:1
func (t *A_arbace_go_check_const_decimal_exact_A) Ctor() {}
//line :342:1
func (t *A_arbace_go_check_const_decimal_exact_A) Invoke_O_O__O(self, d__0 any) any { var unscaled__2 any = jrt.NN(jrt.BigDecimal_Cast(d__0)).UnscaledValue__BigInteger(); var scale__3 int32 = jrt.NN(jrt.BigDecimal_Cast(d__0)).Scale__I(); var mag__4 float64 = lang.Numbers_Minus_D__D_NoInit(lang.Numbers_Multiply_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.BigDecimal_Cast(d__0)).Precision__I()), int64(scale__3)), 3.3219280948873626)); var tmp1 float64 = jrt.Math_Abs_D__D(lang.RT_DoubleCast_D__D_NoInit(mag__4)); var tmp2 jrt.Number_I; var na_999 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var na_1000 int64 = 64; if







	jrt.Long_InstanceOf(na_999) { var n0_1001 int64 = jrt.NN(jrt.Long_Cast(na_999)).LongValue__J(); var n1_1002 int64 = na_1000; var nr_1003 int64 = n0_1001 + n1_1002; if (n0_1001^nr_1003)&(n1_1002^nr_1003) >= 0 { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1003)) } else { tmp2 = lang.Numbers_Add_O_J__Number_NoInit(na_999, na_1000) } } else { tmp2 = lang.Numbers_Add_O_J__Number_NoInit(na_999, na_1000) }; if lang.Numbers_Gt_D_O__Z_NoInit(tmp1, tmp2) {
		if lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.BigInteger_Cast(unscaled__2).Signum__I())) { return A_arbace_go_check_const_A_const_17 } else {

			var root_1004 any = A_arbace_go_check_const_A_const_76.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, A_arbace_go_check_const_big_float_decimal_A_fn_class); var ifn_1006 lang.IFn; if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any = unscaled__2; var arg_1008 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(int64(scale__3))).Ref(); if linked_1005 == nil { return ifn_1006.Invoke_O_O__O(arg_1007, arg_1008) } else { return linked_1005.(*A_arbace_go_check_const_big_float_decimal_A).Invoke_O_O_O__O(root_1004, arg_1007, arg_1008) } } } else {
				var root_1009 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any; var root_1013 any = A_arbace_go_check_const_A_const_77.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_rationalize_A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any = d__0; if linked_1014 == nil { arg_1012 = ifn_1015.Invoke_O__O(arg_1016) } else { arg_1012 = linked_1014.(*aot_arbace_core.A_arbace_core_rationalize_A).Invoke_O_O__O(root_1013, arg_1016) }; if linked_1010 == nil { return ifn_1011.Invoke_O__O(arg_1012) } else { return linked_1010.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_1009, arg_1012) } } }

func A_arbace_go_check_const_double_literal_A_New() *A_arbace_go_check_const_double_literal_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_double_literal_A{}; t.Ctor(); return t }
//line :356:1
func (t *A_arbace_go_check_const_double_literal_A) Ctor() {}
//line :356:1
func (t *A_arbace_go_check_const_double_literal_A) InvokePrim_O_D__O(self any, d__0 float64) any {


	var root_1017 any = A_arbace_go_check_const_A_const_78.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1017, A_arbace_go_check_const_decimal_exact_A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any = jrt.BigDecimal_New_String(jrt.Double_ToString_D__String_NoInit(d__0)); if linked_1018 == nil { return ifn_1019.Invoke_O__O(arg_1020) } else { return linked_1018.(*A_arbace_go_check_const_decimal_exact_A).Invoke_O_O__O(root_1017, arg_1020) } }
//line :356:1
func (t *A_arbace_go_check_const_double_literal_A) Invoke_O_O__O(self, p_d__0 any) any { return t.InvokePrim_O_D__O(self, lang.RT_DoubleCast_O__D_NoInit(p_d__0)) }




func A_arbace_go_check_const_binary_float_A_New() *A_arbace_go_check_const_binary_float_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_binary_float_A{}; t.Ctor(); return t }
//line :361:1
func (t *A_arbace_go_check_const_binary_float_A) Ctor() {}
//line :361:1
func (t *A_arbace_go_check_const_binary_float_A) Invoke_O_O_O__O(self, m__0, e__1 any) any {


	var root_1021 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1021, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_1023 lang.IFn; if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any; var root_1026 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, A_arbace_go_check_const_bi_A_fn_class); var ifn_1028 lang.IFn; if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = m__0; if linked_1027 == nil { arg_1024 = ifn_1028.Invoke_O__O(arg_1029) } else { arg_1024 = linked_1027.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_1026, arg_1029) }; var arg_1025 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(e__1)).Ref(); if linked_1022 == nil { return ifn_1023.Invoke_O_O__O(arg_1024, arg_1025) } else { return linked_1022.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O__O(root_1021, arg_1024, arg_1025)
	}
}

func A_arbace_go_check_const_complex_QMARK__A_New() *A_arbace_go_check_const_complex_QMARK__A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_complex_QMARK__A{}; t.Ctor(); return t }
//line :368:1
func (t *A_arbace_go_check_const_complex_QMARK__A) Ctor() {}
//line :368:1
func (t *A_arbace_go_check_const_complex_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any; var root_1030 any = A_arbace_go_check_const_A_const_15.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1030, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1032 lang.IFn; if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any = x__0; if linked_1031 == nil { and__1927000168__auto____2 = ifn_1032.Invoke_O__O(arg_1033) } else { and__1927000168__auto____2 = linked_1031.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1030, arg_1033) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_const_A_const_79; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_const_cplx_A_New() *A_arbace_go_check_const_cplx_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_cplx_A{}; t.Ctor(); return t }
//line :369:1
func (t *A_arbace_go_check_const_cplx_A) Ctor() {}
//line :369:1
func (t *A_arbace_go_check_const_cplx_A) Invoke_O_O_O__O(self, re__0, im__1 any) any { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_const_A_const_79, re__0, im__1) }
func A_arbace_go_check_const_re_part_A_New() *A_arbace_go_check_const_re_part_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_re_part_A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_go_check_const_re_part_A) Ctor() {}
//line :370:1
func (t *A_arbace_go_check_const_re_part_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_1034 any = A_arbace_go_check_const_A_const_80.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, A_arbace_go_check_const_complex_QMARK__A_fn_class); var ifn_1036 lang.IFn; if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = x__0; if linked_1035 == nil { tmp1 = ifn_1036.Invoke_O__O(arg_1037) } else { tmp1 = linked_1035.(*A_arbace_go_check_const_complex_QMARK__A).Invoke_O_O__O(root_1034, arg_1037) }; if jrt.J2g_Truth(tmp1) { return lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(1)) } else { return x__0 } }
func A_arbace_go_check_const_im_part_A_New() *A_arbace_go_check_const_im_part_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_im_part_A{}; t.Ctor(); return t }
//line :371:1
func (t *A_arbace_go_check_const_im_part_A) Ctor() {}
//line :371:1
func (t *A_arbace_go_check_const_im_part_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_1038 any = A_arbace_go_check_const_A_const_80.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, A_arbace_go_check_const_complex_QMARK__A_fn_class); var ifn_1040 lang.IFn; if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any = x__0; if linked_1039 == nil { tmp1 = ifn_1040.Invoke_O__O(arg_1041) } else { tmp1 = linked_1039.(*A_arbace_go_check_const_complex_QMARK__A).Invoke_O_O__O(root_1038, arg_1041) }; if jrt.J2g_Truth(tmp1) { return lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(2)) } else { return A_arbace_go_check_const_A_const_17 } }
func A_arbace_go_check_const_complex_val_A_New() *A_arbace_go_check_const_complex_val_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_complex_val_A{}; t.Ctor(); return t }
//line :372:1
func (t *A_arbace_go_check_const_complex_val_A) Ctor() {}
//line :372:1
func (t *A_arbace_go_check_const_complex_val_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_1042 any = A_arbace_go_check_const_A_const_80.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, A_arbace_go_check_const_complex_QMARK__A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = x__0; if linked_1043 == nil { tmp1 = ifn_1044.Invoke_O__O(arg_1045) } else { tmp1 = linked_1043.(*A_arbace_go_check_const_complex_QMARK__A).Invoke_O_O__O(root_1042, arg_1045) }; if jrt.J2g_Truth(tmp1) { return x__0 } else { var tmp2 any = A_arbace_go_check_const_A_const_79; var tmp3 any; var root_1046 any = A_arbace_go_check_const_A_const_81.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, A_arbace_go_check_const_float_val_A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = x__0; if linked_1047 == nil { tmp3 = ifn_1048.Invoke_O__O(arg_1049) } else { tmp3 = linked_1047.(*A_arbace_go_check_const_float_val_A).Invoke_O_O__O(root_1046, arg_1049) }; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp3, A_arbace_go_check_const_A_const_17) } }









































type A_arbace_go_check_const_A struct{ jrt.Object }

var A_arbace_go_check_const_A_const_pool *jrt.RefArray

var A_arbace_go_check_const_A_const_0 *lang.Var

var A_arbace_go_check_const_A_const_1 any

var A_arbace_go_check_const_A_const_2 *lang.Var

var A_arbace_go_check_const_A_const_3 *lang.Var

var A_arbace_go_check_const_A_const_4 *lang.Var

var A_arbace_go_check_const_A_const_5 *lang.Var

var A_arbace_go_check_const_A_const_6 any

var A_arbace_go_check_const_A_const_7 *lang.Var

var A_arbace_go_check_const_A_const_8 *lang.Keyword

var A_arbace_go_check_const_A_const_9 *lang.Var

var A_arbace_go_check_const_A_const_10 *lang.Var

var A_arbace_go_check_const_A_const_11 *lang.Var

var A_arbace_go_check_const_A_const_12 *lang.Keyword

var A_arbace_go_check_const_A_const_13 *lang.Var

var A_arbace_go_check_const_A_const_14 *lang.Var

var A_arbace_go_check_const_A_const_15 *lang.Var

var A_arbace_go_check_const_A_const_16 *lang.Keyword

var A_arbace_go_check_const_A_const_17 any

var A_arbace_go_check_const_A_const_18 *lang.Var

var A_arbace_go_check_const_A_const_19 *lang.Var

var A_arbace_go_check_const_A_const_20 *lang.Var

var A_arbace_go_check_const_A_const_21 *lang.Var

var A_arbace_go_check_const_A_const_22 *lang.Keyword

var A_arbace_go_check_const_A_const_23 *lang.Var

var A_arbace_go_check_const_A_const_24 *lang.Var

var A_arbace_go_check_const_A_const_25 *lang.Var

var A_arbace_go_check_const_A_const_26 *lang.Var

var A_arbace_go_check_const_A_const_27 *lang.Var

var A_arbace_go_check_const_A_const_28 *lang.Var

var A_arbace_go_check_const_A_const_29 *lang.Var

var A_arbace_go_check_const_A_const_30 *lang.Var

var A_arbace_go_check_const_A_const_31 *lang.Var

var A_arbace_go_check_const_A_const_32 *lang.Var

var A_arbace_go_check_const_A_const_33 *lang.Var

var A_arbace_go_check_const_A_const_34 *lang.Var

var A_arbace_go_check_const_A_const_35 *lang.Var

var A_arbace_go_check_const_A_const_36 *lang.Var

var A_arbace_go_check_const_A_const_37 *lang.Var

var A_arbace_go_check_const_A_const_38 *lang.Var

var A_arbace_go_check_const_A_const_39 *lang.Var

var A_arbace_go_check_const_A_const_40 *lang.Var

var A_arbace_go_check_const_A_const_41 *lang.Var

var A_arbace_go_check_const_A_const_42 *lang.Var

var A_arbace_go_check_const_A_const_43 *lang.Var

var A_arbace_go_check_const_A_const_44 *lang.Var

var A_arbace_go_check_const_A_const_45 *lang.Var

var A_arbace_go_check_const_A_const_46 *lang.Var

var A_arbace_go_check_const_A_const_47 *lang.Var

var A_arbace_go_check_const_A_const_48 *lang.Var

var A_arbace_go_check_const_A_const_49 *lang.Var

var A_arbace_go_check_const_A_const_50 any

var A_arbace_go_check_const_A_const_51 any

var A_arbace_go_check_const_A_const_52 any

var A_arbace_go_check_const_A_const_53 any

var A_arbace_go_check_const_A_const_54 any

var A_arbace_go_check_const_A_const_55 any

var A_arbace_go_check_const_A_const_56 any

var A_arbace_go_check_const_A_const_57 *lang.Var

var A_arbace_go_check_const_A_const_58 *lang.Var

var A_arbace_go_check_const_A_const_59 *lang.Var

var A_arbace_go_check_const_A_const_60 *lang.Var

var A_arbace_go_check_const_A_const_61 *lang.Var

var A_arbace_go_check_const_A_const_62 *lang.Var

var A_arbace_go_check_const_A_const_63 *lang.Var

var A_arbace_go_check_const_A_const_64 *lang.Var

var A_arbace_go_check_const_A_const_65 *lang.Var

var A_arbace_go_check_const_A_const_66 any

var A_arbace_go_check_const_A_const_67 any

var A_arbace_go_check_const_A_const_68 any

var A_arbace_go_check_const_A_const_69 *lang.Var

var A_arbace_go_check_const_A_const_70 *lang.Var

var A_arbace_go_check_const_A_const_71 *lang.Var

var A_arbace_go_check_const_A_const_72 *lang.Var

var A_arbace_go_check_const_A_const_73 *lang.Var

var A_arbace_go_check_const_A_const_74 *lang.Var

var A_arbace_go_check_const_A_const_75 *lang.Var

var A_arbace_go_check_const_A_const_76 *lang.Var

var A_arbace_go_check_const_A_const_77 *lang.Var

var A_arbace_go_check_const_A_const_78 *lang.Var

var A_arbace_go_check_const_A_const_79 *lang.Keyword

var A_arbace_go_check_const_A_const_80 *lang.Var

var A_arbace_go_check_const_A_const_81 *lang.Var

var A_arbace_go_check_const_A_init jrt.ClassInit

func A_arbace_go_check_const_A_Init() { if !A_arbace_go_check_const_A_init.Done() { A_arbace_go_check_const_A_init.Run(A_arbace_go_check_const_A_clinit) } }

func A_arbace_go_check_const_A_clinit() { A_arbace_go_check_const_A_clinit_p0(); A_arbace_go_check_const_A_clinit_p1(); A_arbace_go_check_const_A_clinit_p2(); A_arbace_go_check_const_A_clinit_p3(); A_arbace_go_check_const_A_clinit_p4(); A_arbace_go_check_const_A_clinit_p5(); A_arbace_go_check_const_A_clinit_p6() }

func A_arbace_go_check_const_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_const_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 89); A_arbace_go_check_const_A_const_0 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[7]); A_arbace_go_check_const_A_const_1 = A_arbace_go_check_const_A_const_pool.A[8]; A_arbace_go_check_const_A_const_2 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[9]); A_arbace_go_check_const_A_const_3 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[10]); A_arbace_go_check_const_A_const_4 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[11]); A_arbace_go_check_const_A_const_5 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[12]); A_arbace_go_check_const_A_const_6 = A_arbace_go_check_const_A_const_pool.A[13]; A_arbace_go_check_const_A_const_7 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[14]); A_arbace_go_check_const_A_const_8 = lang.Keyword_Cast(A_arbace_go_check_const_A_const_pool.A[15]); A_arbace_go_check_const_A_const_9 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[16]); A_arbace_go_check_const_A_const_10 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[17]) }

func A_arbace_go_check_const_A_clinit_p1() { A_arbace_go_check_const_A_const_11 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[18]); A_arbace_go_check_const_A_const_12 = lang.Keyword_Cast(A_arbace_go_check_const_A_const_pool.A[19]); A_arbace_go_check_const_A_const_13 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[20]); A_arbace_go_check_const_A_const_14 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[21]); A_arbace_go_check_const_A_const_15 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[22]); A_arbace_go_check_const_A_const_16 = lang.Keyword_Cast(A_arbace_go_check_const_A_const_pool.A[23]); A_arbace_go_check_const_A_const_17 = A_arbace_go_check_const_A_const_pool.A[24]; A_arbace_go_check_const_A_const_18 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[25]); A_arbace_go_check_const_A_const_19 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[26]); A_arbace_go_check_const_A_const_20 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[27]); A_arbace_go_check_const_A_const_21 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[28]); A_arbace_go_check_const_A_const_22 = lang.Keyword_Cast(A_arbace_go_check_const_A_const_pool.A[29]) }

func A_arbace_go_check_const_A_clinit_p2() { A_arbace_go_check_const_A_const_23 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[30]); A_arbace_go_check_const_A_const_24 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[31]); A_arbace_go_check_const_A_const_25 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[32]); A_arbace_go_check_const_A_const_26 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[33]); A_arbace_go_check_const_A_const_27 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[34]); A_arbace_go_check_const_A_const_28 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[35]); A_arbace_go_check_const_A_const_29 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[36]); A_arbace_go_check_const_A_const_30 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[37]); A_arbace_go_check_const_A_const_31 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[38]); A_arbace_go_check_const_A_const_32 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[39]); A_arbace_go_check_const_A_const_33 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[40]); A_arbace_go_check_const_A_const_34 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[41]) }

func A_arbace_go_check_const_A_clinit_p3() { A_arbace_go_check_const_A_const_35 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[42]); A_arbace_go_check_const_A_const_36 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[43]); A_arbace_go_check_const_A_const_37 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[44]); A_arbace_go_check_const_A_const_38 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[45]); A_arbace_go_check_const_A_const_39 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[46]); A_arbace_go_check_const_A_const_40 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[47]); A_arbace_go_check_const_A_const_41 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[48]); A_arbace_go_check_const_A_const_42 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[49]); A_arbace_go_check_const_A_const_43 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[50]); A_arbace_go_check_const_A_const_44 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[51]); A_arbace_go_check_const_A_const_45 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[52]); A_arbace_go_check_const_A_const_46 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[53]) }

func A_arbace_go_check_const_A_clinit_p4() { A_arbace_go_check_const_A_const_47 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[54]); A_arbace_go_check_const_A_const_48 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[55]); A_arbace_go_check_const_A_const_49 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[56]); A_arbace_go_check_const_A_const_50 = A_arbace_go_check_const_A_const_pool.A[57]; A_arbace_go_check_const_A_const_51 = A_arbace_go_check_const_A_const_pool.A[58]; A_arbace_go_check_const_A_const_52 = A_arbace_go_check_const_A_const_pool.A[59]; A_arbace_go_check_const_A_const_53 = A_arbace_go_check_const_A_const_pool.A[60]; A_arbace_go_check_const_A_const_54 = A_arbace_go_check_const_A_const_pool.A[61]; A_arbace_go_check_const_A_const_55 = A_arbace_go_check_const_A_const_pool.A[62]; A_arbace_go_check_const_A_const_56 = A_arbace_go_check_const_A_const_pool.A[63]; A_arbace_go_check_const_A_const_57 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[64]); A_arbace_go_check_const_A_const_58 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[65]); A_arbace_go_check_const_A_const_59 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[66]) }

func A_arbace_go_check_const_A_clinit_p5() { A_arbace_go_check_const_A_const_60 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[67]); A_arbace_go_check_const_A_const_61 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[68]); A_arbace_go_check_const_A_const_62 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[69]); A_arbace_go_check_const_A_const_63 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[70]); A_arbace_go_check_const_A_const_64 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[71]); A_arbace_go_check_const_A_const_65 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[72]); A_arbace_go_check_const_A_const_66 = A_arbace_go_check_const_A_const_pool.A[73]; A_arbace_go_check_const_A_const_67 = A_arbace_go_check_const_A_const_pool.A[74]; A_arbace_go_check_const_A_const_68 = A_arbace_go_check_const_A_const_pool.A[75]; A_arbace_go_check_const_A_const_69 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[76]); A_arbace_go_check_const_A_const_70 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[77]); A_arbace_go_check_const_A_const_71 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[78]) }

func A_arbace_go_check_const_A_clinit_p6() { A_arbace_go_check_const_A_const_72 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[79]); A_arbace_go_check_const_A_const_73 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[80]); A_arbace_go_check_const_A_const_74 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[81]); A_arbace_go_check_const_A_const_75 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[82]); A_arbace_go_check_const_A_const_76 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[83]); A_arbace_go_check_const_A_const_77 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[84]); A_arbace_go_check_const_A_const_78 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[85]); A_arbace_go_check_const_A_const_79 = lang.Keyword_Cast(A_arbace_go_check_const_A_const_pool.A[86]); A_arbace_go_check_const_A_const_80 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[87]); A_arbace_go_check_const_A_const_81 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[88]) }

func A_arbace_go_check_const_A_New() *A_arbace_go_check_const_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_const_A) Ctor() {}

func (t *A_arbace_go_check_const_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_const_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_const_A_class }

func (t *A_arbace_go_check_const_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_const_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_const_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_const_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_const_A); return ok }

func A_arbace_go_check_const_A_Cast(x any) *A_arbace_go_check_const_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_const_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_const_A_class)) }; return v }



type A_arbace_go_check_const_bf_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_const_bf__GT_rat_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf__GT_rat_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_add_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_add_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_cmp_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_cmp_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_exp_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_exp_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_mul_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_mul_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_neg_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_neg_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_norm_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_norm_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_quo_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_quo_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_sign_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_sign_A_fn_class *jrt.Class



type A_arbace_go_check_const_bi_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bi_A_fn_class *jrt.Class



type A_arbace_go_check_const_big_float_decimal_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_big_float_decimal_A_fn_class *jrt.Class



type A_arbace_go_check_const_binary_float_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_binary_float_A_fn_class *jrt.Class



type A_arbace_go_check_const_bit_len_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bit_len_A_fn_class *jrt.Class



type A_arbace_go_check_const_complex_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_const_complex_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_const_complex_val_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_complex_val_A_fn_class *jrt.Class



type A_arbace_go_check_const_cplx_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_cplx_A_fn_class *jrt.Class



type A_arbace_go_check_const_decimal_exact_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_decimal_exact_A_fn_class *jrt.Class



type A_arbace_go_check_const_double_literal_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_double_literal_A_fn_class *jrt.Class



type A_arbace_go_check_const_eval161000004_A struct{ jrt.Object }

func A_arbace_go_check_const_eval161000004_A_New() *A_arbace_go_check_const_eval161000004_A { t := &A_arbace_go_check_const_eval161000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_const_eval161000004_A) Ctor() {}

func (t *A_arbace_go_check_const_eval161000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_const_eval161000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_const_eval161000004_A_class }

func (t *A_arbace_go_check_const_eval161000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_const_eval161000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_const_eval161000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_const_eval161000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_const_eval161000004_A); return ok }

func A_arbace_go_check_const_eval161000004_A_Cast(x any) *A_arbace_go_check_const_eval161000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_const_eval161000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_const_eval161000004_A_class)) }; return v }



type A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A_fn_class *jrt.Class



type A_arbace_go_check_const_eval161000008_A struct{ jrt.Object }

func A_arbace_go_check_const_eval161000008_A_New() *A_arbace_go_check_const_eval161000008_A { t := &A_arbace_go_check_const_eval161000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_const_eval161000008_A) Ctor() {}

func (t *A_arbace_go_check_const_eval161000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_const_eval161000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_const_eval161000008_A_class }

func (t *A_arbace_go_check_const_eval161000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_const_eval161000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_const_eval161000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_const_eval161000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_const_eval161000008_A); return ok }

func A_arbace_go_check_const_eval161000008_A_Cast(x any) *A_arbace_go_check_const_eval161000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_const_eval161000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_const_eval161000008_A_class)) }; return v }



type A_arbace_go_check_const_eval161000008_fn__161000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_eval161000008_fn__161000009_A_fn_class *jrt.Class



type A_arbace_go_check_const_exact_of_double_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_exact_of_double_A_fn_class *jrt.Class



type A_arbace_go_check_const_fadd_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fadd_A_fn_class *jrt.Class



type A_arbace_go_check_const_fcmp_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fcmp_A_fn_class *jrt.Class



type A_arbace_go_check_const_float_val_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_float_val_A_fn_class *jrt.Class



type A_arbace_go_check_const_fmul_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fmul_A_fn_class *jrt.Class



type A_arbace_go_check_const_fneg_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fneg_A_fn_class *jrt.Class



type A_arbace_go_check_const_fquo_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fquo_A_fn_class *jrt.Class



type A_arbace_go_check_const_fsign_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fsign_A_fn_class *jrt.Class



type A_arbace_go_check_const_fsub_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fsub_A_fn_class *jrt.Class



type A_arbace_go_check_const_fzero_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fzero_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_const_im_part_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_im_part_A_fn_class *jrt.Class



type A_arbace_go_check_const_int_val_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_int_val_A_fn_class *jrt.Class



type A_arbace_go_check_const_int_val_try_round__161000082_A struct{ j2g_header uint64; F_n int32; F_m, F_p any; F_ee int64 }

var A_arbace_go_check_const_int_val_try_round__161000082_A_fn_class *jrt.Class



type A_arbace_go_check_const_latin1_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_latin1_A_fn_class *jrt.Class



type A_arbace_go_check_const_make_rat_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_make_rat_A_fn_class *jrt.Class



type A_arbace_go_check_const_norm_int_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_norm_int_A_fn_class *jrt.Class



type A_arbace_go_check_const_pmul_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_pmul_A_fn_class *jrt.Class



type A_arbace_go_check_const_pow2_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_pow2_A_fn_class *jrt.Class



type A_arbace_go_check_const_pow5_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_pow5_A_fn_class *jrt.Class



type A_arbace_go_check_const_pquo_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_pquo_A_fn_class *jrt.Class



type A_arbace_go_check_const_rat__GT_bf_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_rat__GT_bf_A_fn_class *jrt.Class



type A_arbace_go_check_const_rat_num_den_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_rat_num_den_A_fn_class *jrt.Class



type A_arbace_go_check_const_re_part_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_re_part_A_fn_class *jrt.Class



type A_arbace_go_check_const_rnd_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_rnd_A_fn_class *jrt.Class



type A_arbace_go_check_const_round32_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_round32_A_fn_class *jrt.Class



type A_arbace_go_check_const_round64_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_round64_A_fn_class *jrt.Class



type A_arbace_go_check_const_round_binary_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_round_binary_A_fn_class *jrt.Class



type A_arbace_go_check_const_round_int_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_round_int_A_fn_class *jrt.Class



type A_arbace_go_check_const_rune_string_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_rune_string_A_fn_class *jrt.Class



type A_arbace_go_check_const_small_int_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_const_small_int_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_const_to_bf_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_to_bf_A_fn_class *jrt.Class



type A_arbace_go_check_const_to_double_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_to_double_A_fn_class *jrt.Class



type A_arbace_go_check_const_to_double_fn__161000098_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_const_to_double_fn__161000098_A_fn_class *jrt.Class



type A_arbace_go_check_const_utf8_value_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_utf8_value_A_fn_class *jrt.Class



type A_arbace_go_check_const_value_bytes_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_value_bytes_A_fn_class *jrt.Class



type A_arbace_go_check_const_value_text_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_value_text_A_fn_class *jrt.Class
