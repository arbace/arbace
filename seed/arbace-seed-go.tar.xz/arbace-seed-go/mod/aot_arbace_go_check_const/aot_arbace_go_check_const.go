//line aot_arbace_go_check_const.ae:1
package aot_arbace_go_check_const

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A_New() *A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_go_check_const_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_const_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_const_eval161000008_fn__161000009_A_New() *A_arbace_go_check_const_eval161000008_fn__161000009_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_eval161000008_fn__161000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_const_eval161000008_fn__161000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_const_eval161000008_fn__161000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_const_A_const_2.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_go_check_const_A_const_3.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_go_check_const_A_const_4; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_const_A_const_5.GetRawRoot__O(), A_arbace_go_check_const_A_const_6) }


















func A_arbace_go_check_const_bi_A_New() *A_arbace_go_check_const_bi_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bi_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_go_check_const_bi_A) Ctor() {}
//line :20:1
func (t *A_arbace_go_check_const_bi_A) Invoke_O_O__O(self, x__0 any) any {


	if jrt.BigInteger_InstanceOf(x__0) { return x__0 } else { var tmp1 bool; var or__1927000174__auto____2 bool = jrt.Long_InstanceOf(x__0)

		if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = jrt.Integer_InstanceOf(x__0); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 bool = jrt.Short_InstanceOf(x__0); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = jrt.Byte_InstanceOf(x__0) } } }
//line :23:1
		if tmp1 {

			return jrt.BigInteger_ValueOf_J__BigInteger(lang.RT_LongCast_O__J_NoInit(x__0)).Ref() } else {
//line :23:1
				if lang.BigInt_InstanceOf(x__0) {


					var root_15 any = A_arbace_go_check_const_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = x__0; if linked_16 == nil { return ifn_17.Invoke_O__O(arg_18) } else { return linked_16.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_15, arg_18) } } else {
//line :23:1
						if A_arbace_go_check_const_A_const_8 != nil { var tmp2 any; var root_19 any = A_arbace_go_check_const_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_21 lang.IFn



							if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil, Lit_2, nil); var tmp4 any = lang.IFn_Cast(A_arbace_go_check_const_A_const_10.GetRawRoot__O()).Invoke_O__O(x__0); var tmp5 any; var root_28 any = A_arbace_go_check_const_A_const_11.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = x__0; if linked_29 == nil { tmp5 = ifn_30.Invoke_O__O(arg_31) } else { tmp5 = linked_29.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_28, arg_31) }; arg_22 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp5)).Ref(); var arg_23 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_const_A_const_12, x__0)); if linked_20 == nil { tmp2 = ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { tmp2 = linked_20.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) }
//line :23:1
							panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) } else { return nil
							}
					}
			}
	}
}
func A_arbace_go_check_const_norm_int_A_New() *A_arbace_go_check_const_norm_int_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_norm_int_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_go_check_const_norm_int_A) Ctor() {}
//line :29:1
func (t *A_arbace_go_check_const_norm_int_A) Invoke_O_O__O(self, b__0 any) any {


	if lang.Numbers_Lt_J_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(b__0)).BitLength__I()), 64) { return jrt.Long_ValueOf_J__Long_NoInit(jrt.NN(jrt.BigInteger_Cast(b__0)).LongValue__J()).Ref() } else { var root_32 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = b__0; if linked_33 == nil { return ifn_34.Invoke_O__O(arg_35) } else { return linked_33.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_32, arg_35)
	} } }
func A_arbace_go_check_const_bit_len_A_New() *A_arbace_go_check_const_bit_len_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bit_len_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_go_check_const_bit_len_A) Ctor() {}
//line :34:1
func (t *A_arbace_go_check_const_bit_len_A) InvokePrim_O_O__J(self, x__0 any) int64 {


	var tmp1 any; var root_36 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, A_arbace_go_check_const_bi_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = x__0; if linked_37 == nil { tmp1 = ifn_38.Invoke_O__O(arg_39) } else { tmp1 = linked_37.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_36, arg_39) }; return lang.RT_LongCast_I__J_NoInit(jrt.NN(jrt.NN(jrt.BigInteger_Cast(tmp1)).Abs__BigInteger()).BitLength__I()) }
//line :34:1
func (t *A_arbace_go_check_const_bit_len_A) Invoke_O_O__O(self, x__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, x__0)).Ref() }






func A_arbace_go_check_const_pow2_A_New() *A_arbace_go_check_const_pow2_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_pow2_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_go_check_const_pow2_A) Ctor() {}
//line :41:1
func (t *A_arbace_go_check_const_pow2_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *jrt.BigInteger; jrt.BigInteger_Init(); tmp1 = jrt.BigInteger_ONE; var tmp2 *jrt.BigInteger = tmp1; return jrt.NN(tmp2).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(n__0)).Ref() }






func A_arbace_go_check_const_bf_QMARK__A_New() *A_arbace_go_check_const_bf_QMARK__A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_QMARK__A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_go_check_const_bf_QMARK__A) Ctor() {}
//line :48:1
func (t *A_arbace_go_check_const_bf_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any; var root_40 any = A_arbace_go_check_const_A_const_15.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = x__0; if linked_41 == nil { and__1927000168__auto____2 = ifn_42.Invoke_O__O(arg_43) } else { and__1927000168__auto____2 = linked_41.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_40, arg_43) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_const_A_const_16; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_go_check_const_round_int_A_New() *A_arbace_go_check_const_round_int_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_round_int_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_go_check_const_round_int_A) Ctor() {}
//line :50:1
func (t *A_arbace_go_check_const_round_int_A) Invoke_O_O_O_O__O(self, m__0, sticky__1, p__2 any) any { var n__4 int32 = jrt.NN(jrt.NN(jrt.BigInteger_Cast(m__0)).Abs__BigInteger()).BitLength__I(); var tmp1 bool; var na_44 int64 = int64(n__4); var na_45 any = p__2; if




	jrt.Long_InstanceOf(na_45) { var n0_46 int64 = na_44; var n1_47 int64 = jrt.NN(jrt.Long_Cast(na_45)).LongValue__J(); tmp1 = n0_46 <= n1_47 } else { tmp1 = lang.Numbers_Lte_J_O__Z_NoInit(na_44, na_45) }; if tmp1 { return lang.Tuple_Create_O_O__IPersistentVector(m__0, A_arbace_go_check_const_A_const_17) } else { var sh__5 any; var na_49 int64 = int64(n__4)
		var na_50 any = p__2
		if jrt.Long_InstanceOf(na_50) { var n0_51 int64 = na_49; var n1_52 int64 = jrt.NN(jrt.Long_Cast(na_50)).LongValue__J(); var nr_53 int64 = n0_51 - n1_52; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_52 == -9223372036854775808); if tmp3 { tmp3 = (n0_51^n1_52)&(n0_51^nr_53) >= 0 }; tmp2 = tmp3; if tmp2 { sh__5 = jrt.Long_ValueOf_J__Long_NoInit(nr_53).Ref() } else { sh__5 = lang.Numbers_Minus_J_O__Number_NoInit(na_49, na_50) } } else { sh__5 = lang.Numbers_Minus_J_O__Number_NoInit(na_49, na_50) }
//line :55:1
		var neg__6 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(m__0)).Signum__I())); var a__7 any = jrt.NN(jrt.BigInteger_Cast(m__0)).Abs__BigInteger().Ref(); var q__8 any = jrt.NN(jrt.BigInteger_Cast(a__7)).ShiftRight_I__BigInteger(lang.RT_IntCast_O__I_NoInit(sh__5)).Ref(); var half_bit__9 bool; var tmp4 *jrt.BigInteger = jrt.BigInteger_Cast(a__7); var tmp5 jrt.Number_I
		var na_54 any = sh__5




		if jrt.Long_InstanceOf(na_54) { var n0_55 int64 = jrt.NN(jrt.Long_Cast(na_54)).LongValue__J(); if n0_55 == -9223372036854775808 { tmp5 = lang.Numbers_Dec_O__Number_NoInit(na_54) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_55 - 1)) } } else { if jrt.Double_InstanceOf(na_54) { var n0_55_2 float64 = jrt.NN(jrt.Double_Cast(na_54)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_55_2 - 1.0)) } else { tmp5 = lang.Numbers_Dec_O__Number_NoInit(na_54) } }; half_bit__9 = jrt.NN(tmp4).TestBit_I__Z(lang.RT_IntCast_O__I_NoInit(tmp5))
//line :55:1
		var below__10 any
		var or__1927000174__auto____10 any = sticky__1





		if jrt.J2g_Truth(or__1927000174__auto____10) { below__10 = or__1927000174__auto____10 } else { var and__1927000168__auto____11 bool; var na_56 any = sh__5; var na_57 int64 = 1; if jrt.Long_InstanceOf(na_56) { var n0_58 int64 = jrt.NN(jrt.Long_Cast(na_56)).LongValue__J(); var n1_59 int64 = na_57; and__1927000168__auto____11 = n0_58 > n1_59 } else { and__1927000168__auto____11 = lang.Numbers_Gt_O_J__Z_NoInit(na_56, na_57) }; if and__1927000168__auto____11 { var tmp6 bool; var na_61 int64 = int64(jrt.NN(jrt.BigInteger_Cast(a__7)).GetLowestSetBit__I()); var na_62 any; var na_63 any = sh__5; if jrt.Long_InstanceOf(na_63) { var n0_64 int64 = jrt.NN(jrt.Long_Cast(na_63)).LongValue__J(); if n0_64 == -9223372036854775808 { na_62 = lang.Numbers_Dec_O__Number_NoInit(na_63) } else { na_62 = jrt.Long_ValueOf_J__Long_NoInit(n0_64 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_63) { var n0_64_2 float64 = jrt.NN(jrt.Double_Cast(na_63)).DoubleValue__D(); na_62 = jrt.Double_ValueOf_D__Double_NoInit(n0_64_2 - 1.0).Ref() } else { na_62 = lang.Numbers_Dec_O__Number_NoInit(na_63) } }; if jrt.Long_InstanceOf(na_62) { var n0_65 int64 = na_61; var n1_66 int64 = jrt.NN(jrt.Long_Cast(na_62)).LongValue__J(); tmp6 = n0_65 < n1_66 } else { tmp6 = lang.Numbers_Lt_J_O__Z_NoInit(na_61, na_62) }; below__10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp6).Ref() } else { below__10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } }
//line :55:1
		var up__11 any
		var and__1927000168__auto____11_2 bool = half_bit__9






		if and__1927000168__auto____11_2 { var or__1927000174__auto____12 any = below__10; if jrt.J2g_Truth(or__1927000174__auto____12) { up__11 = or__1927000174__auto____12 } else { up__11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.BigInteger_Cast(q__8)).TestBit_I__Z(lang.RT_IntCast_J__I_NoInit(0))).Ref() } } else { up__11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11_2).Ref() }
//line :55:1
		var q__12 any








		if jrt.J2g_Truth(up__11) { var tmp7 *jrt.BigInteger = jrt.BigInteger_Cast(q__8); var tmp8 *jrt.BigInteger; jrt.BigInteger_Init(); tmp8 = jrt.BigInteger_ONE; q__12 = jrt.NN(tmp7).Add_BigInteger__BigInteger(tmp8).Ref() } else { q__12 = q__8 }
//line :55:1
		var vec__161000017__13 any; var tmp9 bool; var na_68 int64 = int64(jrt.NN(jrt.BigInteger_Cast(q__12)).BitLength__I())
		var na_69 any = p__2








		if jrt.Long_InstanceOf(na_69) { var n0_70 int64 = na_68; var n1_71 int64 = jrt.NN(jrt.Long_Cast(na_69)).LongValue__J(); tmp9 = n0_70 > n1_71 } else { tmp9 = lang.Numbers_Gt_J_O__Z_NoInit(na_68, na_69) }; if tmp9 { var tmp10 any = jrt.NN(jrt.BigInteger_Cast(q__12)).ShiftRight_I__BigInteger(lang.RT_IntCast_J__I_NoInit(1)).Ref(); var tmp11 jrt.Number_I; var na_73 any = sh__5; if jrt.Long_InstanceOf(na_73) { var n0_74 int64 = jrt.NN(jrt.Long_Cast(na_73)).LongValue__J(); if n0_74 == 9223372036854775807 { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_73) } else { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_74 + 1)) } } else { if jrt.Double_InstanceOf(na_73) { var n0_74_2 float64 = jrt.NN(jrt.Double_Cast(na_73)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_74_2 + 1.0)) } else { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_73) } }; vec__161000017__13 = lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11) } else { vec__161000017__13 = lang.Tuple_Create_O_O__IPersistentVector(q__12, sh__5) }
//line :55:1
		var q__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000017__13, lang.RT_IntCast_J__I_NoInit(0), nil); var sh__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000017__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp12 any










		if neg__6 { tmp12 = lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(q__14, Lit_4, false) } else { tmp12 = q__14 }
//line :55:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp12, sh__15) } }

















func A_arbace_go_check_const_bf_norm_A_New() *A_arbace_go_check_const_bf_norm_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_norm_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_go_check_const_bf_norm_A) Ctor() {}
//line :73:1
func (t *A_arbace_go_check_const_bf_norm_A) Invoke_O_O_O_O__O(self, m__0, e__1, sticky__2 any) any {





	if lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(m__0)).Signum__I())) { return A_arbace_go_check_const_A_const_17 } else { var vec__161000021__4 any; var root_75 any = A_arbace_go_check_const_A_const_18.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, A_arbace_go_check_const_round_int_A_fn_class); var ifn_77 lang.IFn

		if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = m__0; var arg_79 any = sticky__2; var arg_80 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O(); if linked_76 == nil { vec__161000021__4 = ifn_77.Invoke_O_O_O__O(arg_78, arg_79, arg_80) } else { vec__161000021__4 = linked_76.(*A_arbace_go_check_const_round_int_A).Invoke_O_O_O_O__O(root_75, arg_78, arg_79, arg_80) }
//line :79:1
		var m__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000021__4, lang.RT_IntCast_J__I_NoInit(0), nil); var sh__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000021__4, lang.RT_IntCast_J__I_NoInit(1), nil); var e__7 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e__1), lang.RT_LongCast_O__J_NoInit(sh__6)); var z__8 int32 = jrt.NN(jrt.BigInteger_Cast(m__5)).GetLowestSetBit__I(); var x__9 int64 = lang.Numbers_Add_J_J__J_NoInit(e__7, int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m__5)).Abs__BigInteger()).BitLength__I())); var tmp1 bool; var na_81 int64 = x__9; var na_82 any = A_arbace_go_check_const_A_const_20.GetRawRoot__O()






		if jrt.Long_InstanceOf(na_82) { var n0_83 int64 = na_81; var n1_84 int64 = jrt.NN(jrt.Long_Cast(na_82)).LongValue__J(); tmp1 = n0_83 < n1_84 } else { tmp1 = lang.Numbers_Lt_J_O__Z_NoInit(na_81, na_82) }
//line :85:1
		if tmp1 { return A_arbace_go_check_const_A_const_17 } else { var tmp2 bool; var na_86 int64 = x__9; var na_87 any = A_arbace_go_check_const_A_const_21.GetRawRoot__O()

			if jrt.Long_InstanceOf(na_87) { var n0_88 int64 = na_86; var n1_89 int64 = jrt.NN(jrt.Long_Cast(na_87)).LongValue__J(); tmp2 = n0_88 > n1_89 } else { tmp2 = lang.Numbers_Gt_J_O__Z_NoInit(na_86, na_87) }
//line :85:1
			if tmp2 { return A_arbace_go_check_const_A_const_22 } else { if A_arbace_go_check_const_A_const_8 != nil { var tmp3 any = A_arbace_go_check_const_A_const_16; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp3, jrt.NN(jrt.BigInteger_Cast(m__5)).ShiftRight_I__BigInteger(lang.RT_IntCast_I__I_NoInit(z__8)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(e__7, int64(z__8))).Ref()) } else { return nil } } } } }
//line :73:1
func (t *A_arbace_go_check_const_bf_norm_A) Invoke_O_O_O__O(self, m__0, e__1 any) any {



	var root_91 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = m__0; var arg_95 any = e__1; var arg_96 any = jrt.Boolean_FALSE.Ref(); if linked_92 == nil { return ifn_93.Invoke_O_O_O__O(arg_94, arg_95, arg_96) } else { return linked_92.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O_O__O(root_91, arg_94, arg_95, arg_96)
	}
}










func A_arbace_go_check_const_rat_num_den_A_New() *A_arbace_go_check_const_rat_num_den_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_rat_num_den_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_go_check_const_rat_num_den_A) Ctor() {}
//line :90:1
func (t *A_arbace_go_check_const_rat_num_den_A) Invoke_O_O__O(self, r__0 any) any {
	var tmp1 any; var root_97 any = A_arbace_go_check_const_A_const_24.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = r__0; if linked_98 == nil { tmp1 = ifn_99.Invoke_O__O(arg_100) } else { tmp1 = linked_98.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_97, arg_100) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_101 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, A_arbace_go_check_const_bi_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any; var root_105 any = A_arbace_go_check_const_A_const_25.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_numerator_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = r__0; if linked_106 == nil { arg_104 = ifn_107.Invoke_O__O(arg_108) } else { arg_104 = linked_106.(*aot_arbace_core.A_arbace_core_numerator_A).Invoke_O_O__O(root_105, arg_108) }; if linked_102 == nil { tmp2 = ifn_103.Invoke_O__O(arg_104) } else { tmp2 = linked_102.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_101, arg_104) }; var tmp3 any = tmp2; var tmp4 any; var root_109 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, A_arbace_go_check_const_bi_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any; var root_113 any = A_arbace_go_check_const_A_const_26.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_denominator_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = r__0; if linked_114 == nil { arg_112 = ifn_115.Invoke_O__O(arg_116) } else { arg_112 = linked_114.(*aot_arbace_core.A_arbace_core_denominator_A).Invoke_O_O__O(root_113, arg_116) }; if linked_110 == nil { tmp4 = ifn_111.Invoke_O__O(arg_112) } else { tmp4 = linked_110.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_109, arg_112) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { var tmp5 any; var root_117 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, A_arbace_go_check_const_bi_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = r__0; if linked_118 == nil { tmp5 = ifn_119.Invoke_O__O(arg_120) } else { tmp5 = linked_118.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_117, arg_120) }; var tmp6 any = tmp5; var tmp7 *jrt.BigInteger; jrt.BigInteger_Init(); tmp7 = jrt.BigInteger_ONE; return lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7.Ref())
	} }
func A_arbace_go_check_const_rat__GT_bf_A_New() *A_arbace_go_check_const_rat__GT_bf_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_rat__GT_bf_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_go_check_const_rat__GT_bf_A) Ctor() {}
//line :93:1
func (t *A_arbace_go_check_const_rat__GT_bf_A) Invoke_O_O__O(self, r__0 any) any { var vec__161000026__2 any; var root_121 any = A_arbace_go_check_const_A_const_27.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_go_check_const_rat_num_den_A_fn_class); var ifn_123 lang.IFn; if


	linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = r__0; if linked_122 == nil { vec__161000026__2 = ifn_123.Invoke_O__O(arg_124) } else { vec__161000026__2 = linked_122.(*A_arbace_go_check_const_rat_num_den_A).Invoke_O_O__O(root_121, arg_124) }; var p__3 any = /*line :93:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__161000026__2, lang.RT_IntCast_J__I_NoInit(0), nil); var q__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000026__2, lang.RT_IntCast_J__I_NoInit(1), nil); if



	lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__3)).Signum__I())) { return A_arbace_go_check_const_A_const_17 } else { var k__5 any; var na_125 any; var na_127 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O()
		var na_128 int64 = 2
		if jrt.Long_InstanceOf(na_127) { var n0_129 int64 = jrt.NN(jrt.Long_Cast(na_127)).LongValue__J(); var n1_130 int64 = na_128; var nr_131 int64 = n0_129 + n1_130; if (n0_129^nr_131)&(n1_130^nr_131) >= 0 { na_125 = jrt.Long_ValueOf_J__Long_NoInit(nr_131).Ref() } else { na_125 = lang.Numbers_Add_O_J__Number_NoInit(na_127, na_128) } } else { na_125 = lang.Numbers_Add_O_J__Number_NoInit(na_127, na_128) }; var na_126 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(q__4)).BitLength__I()), int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(p__3)).Abs__BigInteger()).BitLength__I())); if jrt.Long_InstanceOf(na_125) { var n0_132 int64 = jrt.NN(jrt.Long_Cast(na_125)).LongValue__J(); var n1_133 int64 = na_126; var nr_134 int64 = n0_132 + n1_133; if (n0_132^nr_134)&(n1_133^nr_134) >= 0 { k__5 = jrt.Long_ValueOf_J__Long_NoInit(nr_134).Ref() } else { k__5 = lang.Numbers_Add_O_J__Number_NoInit(na_125, na_126) } } else { k__5 = lang.Numbers_Add_O_J__Number_NoInit(na_125, na_126) }
//line :97:1
		var k__6 any = lang.Numbers_Max_O_J__O_NoInit(k__5, 0); var dr__7 any = jrt.NN(jrt.NN(jrt.BigInteger_Cast(p__3)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(k__6))).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(q__4)).Ref(); var root_135 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_137 lang.IFn




		if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__7, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)); var arg_139 any; var na_141 any = k__6; if jrt.Long_InstanceOf(na_141) { var n0_142 int64 = jrt.NN(jrt.Long_Cast(na_141)).LongValue__J(); if n0_142 == -9223372036854775808 { arg_139 = lang.Numbers_Minus_O__Number_NoInit(na_141) } else { arg_139 = jrt.Long_ValueOf_J__Long_NoInit(-n0_142).Ref() } } else { if jrt.Double_InstanceOf(na_141) { var n0_142_2 float64 = jrt.NN(jrt.Double_Cast(na_141)).DoubleValue__D(); arg_139 = jrt.Double_ValueOf_D__Double_NoInit(-n0_142_2).Ref() } else { arg_139 = lang.Numbers_Minus_O__Number_NoInit(na_141) } }; var arg_140 any; var root_143 any = A_arbace_go_check_const_A_const_28.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__7, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)))).Signum__I()))).Ref(); if linked_144 == nil { arg_140 = ifn_145.Invoke_O__O(arg_146) } else { arg_140 = linked_144.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_143, arg_146) }; if linked_136 == nil { return ifn_137.Invoke_O_O_O__O(arg_138, arg_139, arg_140) } else { return linked_136.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O_O__O(root_135, arg_138, arg_139, arg_140) } } }

func A_arbace_go_check_const_bf__GT_rat_A_New() *A_arbace_go_check_const_bf__GT_rat_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf__GT_rat_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_go_check_const_bf__GT_rat_A) Ctor() {}
//line :104:1
func (t *A_arbace_go_check_const_bf__GT_rat_A) Invoke_O_O__O(self, p__161000030__0 any) any { var vec__161000031__2 any = p__161000030__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000031__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000031__2, lang.RT_IntCast_J__I_NoInit(1), nil); var e__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000031__2, lang.RT_IntCast_J__I_NoInit(2), nil); var e__6 int64 = lang.RT_LongCast_O__J_NoInit(e__5); _ = ___3; if



	lang.Numbers_IsNeg_J__Z_NoInit(e__6) {
		var tmp1 any; var root_147 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = m__4; if linked_148 == nil { tmp1 = ifn_149.Invoke_O__O(arg_150) } else { tmp1 = linked_148.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_147, arg_150) }; var tmp2 any = tmp1; var tmp3 any; var root_151 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any; var root_155 any = A_arbace_go_check_const_A_const_29.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, A_arbace_go_check_const_pow2_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(e__6)).Ref(); if linked_156 == nil { arg_154 = ifn_157.Invoke_O__O(arg_158) } else { arg_154 = linked_156.(*A_arbace_go_check_const_pow2_A).Invoke_O_O__O(root_155, arg_158) }; if linked_152 == nil { tmp3 = ifn_153.Invoke_O__O(arg_154) } else { tmp3 = linked_152.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_151, arg_154) }; return lang.Numbers_Divide_O_O__Number_NoInit(tmp2, tmp3) } else {
			var root_159 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = jrt.NN(jrt.BigInteger_Cast(m__4)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(e__6)).Ref(); if linked_160 == nil { return ifn_161.Invoke_O__O(arg_162) } else { return linked_160.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_159, arg_162) } } }

func A_arbace_go_check_const_small_int_QMARK__A_New() *A_arbace_go_check_const_small_int_QMARK__A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_small_int_QMARK__A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_go_check_const_small_int_QMARK__A) Ctor() {}
//line :112:1
func (t *A_arbace_go_check_const_small_int_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var tmp1 bool; var na_163 int64; var root_165 any = A_arbace_go_check_const_A_const_30.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_165, A_arbace_go_check_const_bit_len_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = x__0; if linked_166 == nil { na_163 = lang.RT_LongCast_O__J_NoInit(ifn_167.Invoke_O__O(arg_168)) } else { na_163 = linked_166.(*A_arbace_go_check_const_bit_len_A).InvokePrim_O_O__J(root_165, arg_168) }; var na_164 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); if jrt.Long_InstanceOf(na_164) { var n0_169 int64 = na_163; var n1_170 int64 = jrt.NN(jrt.Long_Cast(na_164)).LongValue__J(); tmp1 = n0_169 < n1_170 } else { tmp1 = lang.Numbers_Lt_J_O__Z_NoInit(na_163, na_164) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref() }

func A_arbace_go_check_const_make_rat_A_New() *A_arbace_go_check_const_make_rat_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_make_rat_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_go_check_const_make_rat_A) Ctor() {}
//line :114:1
func (t *A_arbace_go_check_const_make_rat_A) Invoke_O_O__O(self, r__0 any) any {


	var tmp1 any; var root_172 any = A_arbace_go_check_const_A_const_24.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = r__0; if linked_173 == nil { tmp1 = ifn_174.Invoke_O__O(arg_175) } else { tmp1 = linked_173.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_172, arg_175) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var and__1927000168__auto____2 any; var root_176 any = A_arbace_go_check_const_A_const_32.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, A_arbace_go_check_const_small_int_QMARK__A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any; var root_180 any = A_arbace_go_check_const_A_const_25.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_numerator_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = r__0; if linked_181 == nil { arg_179 = ifn_182.Invoke_O__O(arg_183) } else { arg_179 = linked_181.(*aot_arbace_core.A_arbace_core_numerator_A).Invoke_O_O__O(root_180, arg_183) }; if linked_177 == nil { and__1927000168__auto____2 = ifn_178.Invoke_O__O(arg_179) } else { and__1927000168__auto____2 = linked_177.(*A_arbace_go_check_const_small_int_QMARK__A).Invoke_O_O__O(root_176, arg_179) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_184 any = A_arbace_go_check_const_A_const_32.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, A_arbace_go_check_const_small_int_QMARK__A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any; var root_188 any = A_arbace_go_check_const_A_const_26.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_denominator_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = r__0; if linked_189 == nil { arg_187 = ifn_190.Invoke_O__O(arg_191) } else { arg_187 = linked_189.(*aot_arbace_core.A_arbace_core_denominator_A).Invoke_O_O__O(root_188, arg_191) }; if linked_185 == nil { tmp2 = ifn_186.Invoke_O__O(arg_187) } else { tmp2 = linked_185.(*A_arbace_go_check_const_small_int_QMARK__A).Invoke_O_O__O(root_184, arg_187) } } else { tmp2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp2) { return r__0 } else { var root_192 any = A_arbace_go_check_const_A_const_33.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, A_arbace_go_check_const_rat__GT_bf_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = r__0; if linked_193 == nil { return ifn_194.Invoke_O__O(arg_195) } else { return linked_193.(*A_arbace_go_check_const_rat__GT_bf_A).Invoke_O_O__O(root_192, arg_195) } } } else {
			var tmp3 any; var root_196 any = A_arbace_go_check_const_A_const_32.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, A_arbace_go_check_const_small_int_QMARK__A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = r__0; if linked_197 == nil { tmp3 = ifn_198.Invoke_O__O(arg_199) } else { tmp3 = linked_197.(*A_arbace_go_check_const_small_int_QMARK__A).Invoke_O_O__O(root_196, arg_199) }; if jrt.J2g_Truth(tmp3) { return r__0 } else { var root_200 any = A_arbace_go_check_const_A_const_33.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, A_arbace_go_check_const_rat__GT_bf_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = r__0; if linked_201 == nil { return ifn_202.Invoke_O__O(arg_203) } else { return linked_201.(*A_arbace_go_check_const_rat__GT_bf_A).Invoke_O_O__O(root_200, arg_203)
			} } } }
func A_arbace_go_check_const_bf_exp_A_New() *A_arbace_go_check_const_bf_exp_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_exp_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_go_check_const_bf_exp_A) Ctor() {}
//line :121:1
func (t *A_arbace_go_check_const_bf_exp_A) InvokePrim_O_O__J(self, p__161000037__0 any) int64 { var vec__161000038__2 any = p__161000037__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000038__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000038__2, lang.RT_IntCast_J__I_NoInit(1), nil); var e__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000038__2, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___3; return /*line :124:1*/ lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e__5), int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m__4)).Abs__BigInteger()).BitLength__I())) }
//line :121:1
func (t *A_arbace_go_check_const_bf_exp_A) Invoke_O_O__O(self, p__161000037__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, p__161000037__0)).Ref() }




func A_arbace_go_check_const_to_bf_A_New() *A_arbace_go_check_const_to_bf_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_to_bf_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_go_check_const_to_bf_A) Ctor() {}
//line :126:1
func (t *A_arbace_go_check_const_to_bf_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_204 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = x__0; if linked_205 == nil { tmp1 = ifn_206.Invoke_O__O(arg_207) } else { tmp1 = linked_205.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_204, arg_207) }; if jrt.J2g_Truth(tmp1) { return x__0 } else { var root_208 any = A_arbace_go_check_const_A_const_33.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, A_arbace_go_check_const_rat__GT_bf_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = x__0; if linked_209 == nil { return ifn_210.Invoke_O__O(arg_211) } else { return linked_209.(*A_arbace_go_check_const_rat__GT_bf_A).Invoke_O_O__O(root_208, arg_211) } } }

func A_arbace_go_check_const_bf_sign_A_New() *A_arbace_go_check_const_bf_sign_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_sign_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_go_check_const_bf_sign_A) Ctor() {}
//line :128:1
func (t *A_arbace_go_check_const_bf_sign_A) InvokePrim_O_O__J(self, x__0 any) int64 { var tmp1 any; var root_212 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = x__0; if linked_213 == nil { tmp1 = ifn_214.Invoke_O__O(arg_215) } else { tmp1 = linked_213.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_212, arg_215) }; if jrt.J2g_Truth(tmp1) { return lang.RT_LongCast_I__J_NoInit(jrt.NN(jrt.BigInteger_Cast(lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(1)))).Signum__I()) } else { return lang.RT_LongCast_I__J_NoInit(lang.Util_Compare_O_O__I_NoInit(x__0, A_arbace_go_check_const_A_const_17)) } }
//line :128:1
func (t *A_arbace_go_check_const_bf_sign_A) Invoke_O_O__O(self, x__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, x__0)).Ref() }

func A_arbace_go_check_const_bf_add_A_New() *A_arbace_go_check_const_bf_add_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_add_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_go_check_const_bf_add_A) Ctor() {}
//line :130:1
func (t *A_arbace_go_check_const_bf_add_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	if lang.Util_Equiv_J_O__Z_NoInit(0, x__0) {
		var root_216 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = y__1; if linked_217 == nil { return ifn_218.Invoke_O__O(arg_219) } else { return linked_217.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_216, arg_219) } } else {
//line :131:1
			if lang.Util_Equiv_J_O__Z_NoInit(0, y__1) {

				var root_220 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = x__0; if linked_221 == nil { return ifn_222.Invoke_O__O(arg_223) } else { return linked_221.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_220, arg_223) } } else {
//line :131:1
					if A_arbace_go_check_const_A_const_8 != nil { var vec__161000044__3 any; var root_224 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_226 lang.IFn



						if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = x__0; if linked_225 == nil { vec__161000044__3 = ifn_226.Invoke_O__O(arg_227) } else { vec__161000044__3 = linked_225.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_224, arg_227) }
//line :131:1
						var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000044__3, lang.RT_IntCast_J__I_NoInit(0), nil); var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000044__3, lang.RT_IntCast_J__I_NoInit(1), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000044__3, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__161000047__7 any; var root_228 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_230 lang.IFn; _ = ___4



						if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = y__1; if linked_229 == nil { vec__161000047__7 = ifn_230.Invoke_O__O(arg_231) } else { vec__161000047__7 = linked_229.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_228, arg_231) }
//line :131:1
						var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000047__7, lang.RT_IntCast_J__I_NoInit(0), nil); var m2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000047__7, lang.RT_IntCast_J__I_NoInit(1), nil); var e2__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000047__7, lang.RT_IntCast_J__I_NoInit(2), nil); var e1__11 int64 = lang.RT_LongCast_O__J_NoInit(e1__6); var e2__12 int64 = lang.RT_LongCast_O__J_NoInit(e2__10); var vec__161000050__13 any; _ = ___8





						if lang.Numbers_Gte_J_J__Z_NoInit(lang.Numbers_Add_J_J__J_NoInit(e1__11, int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m1__5)).Abs__BigInteger()).BitLength__I())), lang.Numbers_Add_J_J__J_NoInit(e2__12, int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m2__9)).Abs__BigInteger()).BitLength__I()))) { vec__161000050__13 = lang.Tuple_Create_O_O_O_O__IPersistentVector(m1__5, jrt.Long_ValueOf_J__Long_NoInit(e1__11).Ref(), m2__9, jrt.Long_ValueOf_J__Long_NoInit(e2__12).Ref()) } else { vec__161000050__13 = lang.Tuple_Create_O_O_O_O__IPersistentVector(m2__9, jrt.Long_ValueOf_J__Long_NoInit(e2__12).Ref(), m1__5, jrt.Long_ValueOf_J__Long_NoInit(e1__11).Ref()) }
//line :131:1
						var hi_m__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000050__13, lang.RT_IntCast_J__I_NoInit(0), nil); var hi_e__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000050__13, lang.RT_IntCast_J__I_NoInit(1), nil); var lo_m__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000050__13, lang.RT_IntCast_J__I_NoInit(2), nil); var lo_e__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000050__13, lang.RT_IntCast_J__I_NoInit(3), nil); var hi_m__18 any = hi_m__14; var lo_m__19 any = lo_m__16; var hi_top__20 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(hi_e__15), int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(hi_m__18)).Abs__BigInteger()).BitLength__I())); var lo_top__21 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(lo_e__17), int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(lo_m__19)).Abs__BigInteger()).BitLength__I())); var tmp1 bool; var na_232 int64 = lang.Numbers_Minus_J_J__J_NoInit(hi_top__20, lo_top__21); var na_233 any; var na_234 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O()
						var na_235 int64 = 8









						if jrt.Long_InstanceOf(na_234) { var n0_236 int64 = jrt.NN(jrt.Long_Cast(na_234)).LongValue__J(); var n1_237 int64 = na_235; var nr_238 int64 = n0_236 + n1_237; if (n0_236^nr_238)&(n1_237^nr_238) >= 0 { na_233 = jrt.Long_ValueOf_J__Long_NoInit(nr_238).Ref() } else { na_233 = lang.Numbers_Add_O_J__Number_NoInit(na_234, na_235) } } else { na_233 = lang.Numbers_Add_O_J__Number_NoInit(na_234, na_235) }; if jrt.Long_InstanceOf(na_233) { var n0_239 int64 = na_232; var n1_240 int64 = jrt.NN(jrt.Long_Cast(na_233)).LongValue__J(); tmp1 = n0_239 > n1_240 } else { tmp1 = lang.Numbers_Gt_J_O__Z_NoInit(na_232, na_233) }; if tmp1 {

							var root_242 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = hi_m__18; var arg_246 any = hi_e__15; if linked_243 == nil { return ifn_244.Invoke_O_O__O(arg_245, arg_246) } else { return linked_243.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O__O(root_242, arg_245, arg_246) } } else {
//line :142:1
								var e__22 int64 = lang.Numbers_Min_J_J__J_NoInit(e1__11, e2__12); var s__23 any = jrt.NN(jrt.NN(jrt.BigInteger_Cast(m1__5)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(e1__11, e__22)))).Add_BigInteger__BigInteger(jrt.NN(jrt.BigInteger_Cast(m2__9)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(e2__12, e__22)))).Ref(); var root_247 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_249 lang.IFn




								if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = s__23; var arg_251 any = jrt.Long_ValueOf_J__Long_NoInit(e__22).Ref(); if linked_248 == nil { return ifn_249.Invoke_O_O__O(arg_250, arg_251) } else { return linked_248.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O__O(root_247, arg_250, arg_251) } } } else {
//line :131:1
									return nil
								}
				}
		}
}













func A_arbace_go_check_const_bf_neg_A_New() *A_arbace_go_check_const_bf_neg_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_neg_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_go_check_const_bf_neg_A) Ctor() {}
//line :149:1
func (t *A_arbace_go_check_const_bf_neg_A) Invoke_O_O__O(self, x__0 any) any { if jrt.Long_InstanceOf(x__0) { return t.InvokeSpec_O_J_O__O(self, jrt.NN(jrt.Long_Cast(x__0)).LongValue__J(), x__0) } else { var tmp1 any; var root_252 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = x__0; if linked_253 == nil { tmp1 = ifn_254.Invoke_O__O(arg_255) } else { tmp1 = linked_253.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_252, arg_255) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_go_check_const_A_const_16; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, jrt.NN(jrt.BigInteger_Cast(lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(1)))).Negate__BigInteger().Ref(), lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(2))) } else { var na_256 any = x__0; if jrt.Long_InstanceOf(na_256) { var n0_257 int64 = jrt.NN(jrt.Long_Cast(na_256)).LongValue__J(); if n0_257 == -9223372036854775808 { return lang.Numbers_Minus_O__Number_NoInit(na_256) } else { return jrt.Long_ValueOf_J__Long_NoInit(-n0_257).Ref() } } else { if jrt.Double_InstanceOf(na_256) { var n0_257_2 float64 = jrt.NN(jrt.Double_Cast(na_256)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(-n0_257_2).Ref() } else { return lang.Numbers_Minus_O__Number_NoInit(na_256) } } } } }
//line :149:1
func (t *A_arbace_go_check_const_bf_neg_A) InvokeSpec_O_J_O__O(self any, x__0_l int64, x__0_b any) any { var tmp1 any; var root_258 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_261 = x__0_b } else { arg_261 = x__0_b }; if linked_259 == nil { tmp1 = ifn_260.Invoke_O__O(arg_261) } else { tmp1 = linked_259.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_258, arg_261) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_go_check_const_A_const_16; var tmp3 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp3 = x__0_b } else { tmp3 = x__0_b }; var tmp4 any = jrt.NN(jrt.BigInteger_Cast(lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(1)))).Negate__BigInteger().Ref(); var tmp5 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp5 = x__0_b } else { tmp5 = x__0_b }; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp4, lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(2))) } else { var n0_262 int64 = x__0_l; if n0_262 == -9223372036854775808 { var tmp6 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp6 = x__0_b } else { tmp6 = x__0_b }; return lang.Numbers_Minus_O__Number_NoInit(tmp6) } else { return jrt.Long_ValueOf_J__Long_NoInit(-n0_262).Ref() } } }

func A_arbace_go_check_const_bf_mul_A_New() *A_arbace_go_check_const_bf_mul_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_mul_A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_go_check_const_bf_mul_A) Ctor() {}
//line :151:1
func (t *A_arbace_go_check_const_bf_mul_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_J_O__Z_NoInit(0, x__0); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_J_O__Z_NoInit(0, y__1) }; if tmp1 { return A_arbace_go_check_const_A_const_17 } else { var vec__161000055__3 any; var root_263 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_265 lang.IFn

		if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = x__0; if linked_264 == nil { vec__161000055__3 = ifn_265.Invoke_O__O(arg_266) } else { vec__161000055__3 = linked_264.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_263, arg_266) }
//line :152:1
		var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000055__3, lang.RT_IntCast_J__I_NoInit(0), nil); var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000055__3, lang.RT_IntCast_J__I_NoInit(1), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000055__3, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__161000058__7 any; var root_267 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_269 lang.IFn; _ = ___4

		if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = y__1; if linked_268 == nil { vec__161000058__7 = ifn_269.Invoke_O__O(arg_270) } else { vec__161000058__7 = linked_268.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_267, arg_270) }
//line :152:1
		var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000058__7, lang.RT_IntCast_J__I_NoInit(0), nil); var m2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000058__7, lang.RT_IntCast_J__I_NoInit(1), nil); var e2__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000058__7, lang.RT_IntCast_J__I_NoInit(2), nil); var root_271 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_273 lang.IFn; _ = ___8


		if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = jrt.NN(jrt.BigInteger_Cast(m1__5)).Multiply_BigInteger__BigInteger(jrt.BigInteger_Cast(m2__9)).Ref(); var arg_275 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e1__6), lang.RT_LongCast_O__J_NoInit(e2__10))).Ref(); if linked_272 == nil { return ifn_273.Invoke_O_O__O(arg_274, arg_275) } else { return linked_272.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O__O(root_271, arg_274, arg_275)
		} } }
func A_arbace_go_check_const_bf_quo_A_New() *A_arbace_go_check_const_bf_quo_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_quo_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_const_bf_quo_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_const_bf_quo_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	if lang.Util_Equiv_J_O__Z_NoInit(0, x__0) { return A_arbace_go_check_const_A_const_17 } else { var vec__161000062__3 any; var root_276 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_278 lang.IFn

		if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = x__0; if linked_277 == nil { vec__161000062__3 = ifn_278.Invoke_O__O(arg_279) } else { vec__161000062__3 = linked_277.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_276, arg_279) }
//line :158:1
		var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000062__3, lang.RT_IntCast_J__I_NoInit(0), nil); var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000062__3, lang.RT_IntCast_J__I_NoInit(1), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000062__3, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__161000065__7 any; var root_280 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_282 lang.IFn; _ = ___4

		if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = y__1; if linked_281 == nil { vec__161000065__7 = ifn_282.Invoke_O__O(arg_283) } else { vec__161000065__7 = linked_281.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_280, arg_283) }
//line :158:1
		var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000065__7, lang.RT_IntCast_J__I_NoInit(0), nil); var m2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000065__7, lang.RT_IntCast_J__I_NoInit(1), nil); var e2__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000065__7, lang.RT_IntCast_J__I_NoInit(2), nil); var k__11 any; var tmp1 jrt.Number_I; var na_284 any; var na_286 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O(); var na_287 int64 = 2; _ = ___8


		if jrt.Long_InstanceOf(na_286) { var n0_288 int64 = jrt.NN(jrt.Long_Cast(na_286)).LongValue__J(); var n1_289 int64 = na_287; var nr_290 int64 = n0_288 + n1_289; if (n0_288^nr_290)&(n1_289^nr_290) >= 0 { na_284 = jrt.Long_ValueOf_J__Long_NoInit(nr_290).Ref() } else { na_284 = lang.Numbers_Add_O_J__Number_NoInit(na_286, na_287) } } else { na_284 = lang.Numbers_Add_O_J__Number_NoInit(na_286, na_287) }; var na_285 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m2__9)).Abs__BigInteger()).BitLength__I()), int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m1__5)).Abs__BigInteger()).BitLength__I())); if jrt.Long_InstanceOf(na_284) { var n0_291 int64 = jrt.NN(jrt.Long_Cast(na_284)).LongValue__J(); var n1_292 int64 = na_285; var nr_293 int64 = n0_291 + n1_292; if (n0_291^nr_293)&(n1_292^nr_293) >= 0 { tmp1 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_293)) } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_284, na_285) } } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_284, na_285) }; k__11 = lang.Numbers_Max_J_O__O_NoInit(0, tmp1)
//line :158:1
		var dr__12 any = jrt.NN(jrt.NN(jrt.BigInteger_Cast(m1__5)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(k__11))).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(m2__9)).Ref(); var root_294 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_296 lang.IFn




		if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__12, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)); var arg_298 any; var na_300 int64 = lang.Numbers_Minus_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e1__6), lang.RT_LongCast_O__J_NoInit(e2__10)); var na_301 any = k__11; if jrt.Long_InstanceOf(na_301) { var n0_302 int64 = na_300; var n1_303 int64 = jrt.NN(jrt.Long_Cast(na_301)).LongValue__J(); var nr_304 int64 = n0_302 - n1_303; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_303 == -9223372036854775808); if tmp3 { tmp3 = (n0_302^n1_303)&(n0_302^nr_304) >= 0 }; tmp2 = tmp3; if tmp2 { arg_298 = jrt.Long_ValueOf_J__Long_NoInit(nr_304).Ref() } else { arg_298 = lang.Numbers_Minus_J_O__Number_NoInit(na_300, na_301) } } else { arg_298 = lang.Numbers_Minus_J_O__Number_NoInit(na_300, na_301) }; var arg_299 any; var root_305 any = A_arbace_go_check_const_A_const_28.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__12, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)))).Signum__I()))).Ref(); if linked_306 == nil { arg_299 = ifn_307.Invoke_O__O(arg_308) } else { arg_299 = linked_306.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_305, arg_308) }; if linked_295 == nil { return ifn_296.Invoke_O_O_O__O(arg_297, arg_298, arg_299) } else { return linked_295.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O_O__O(root_294, arg_297, arg_298, arg_299)
		} } }
func A_arbace_go_check_const_bf_cmp_A_New() *A_arbace_go_check_const_bf_cmp_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_cmp_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_go_check_const_bf_cmp_A) Ctor() {}
//line :165:1
func (t *A_arbace_go_check_const_bf_cmp_A) InvokePrim_O_O_O__J(self, x__0, y__1 any) int64 { var tmp1 any; var root_309 any = A_arbace_go_check_const_A_const_36.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_309, A_arbace_go_check_const_bf_sign_A_fn_class); var ifn_311 lang.IFn; if


	linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any; var root_313 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, A_arbace_go_check_const_bf_add_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = x__0; var arg_317 any; var root_318 any = A_arbace_go_check_const_A_const_38.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_318, A_arbace_go_check_const_bf_neg_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = y__1; if linked_319 == nil { arg_317 = ifn_320.Invoke_O__O(arg_321) } else { if jrt.Long_InstanceOf(arg_321) { arg_317 = linked_319.(*A_arbace_go_check_const_bf_neg_A).InvokeSpec_O_J_O__O(root_318, jrt.NN(jrt.Long_Cast(arg_321)).LongValue__J(), arg_321) } else { arg_317 = linked_319.(*A_arbace_go_check_const_bf_neg_A).Invoke_O_O__O(root_318, arg_321) } }; if linked_314 == nil { arg_312 = ifn_315.Invoke_O_O__O(arg_316, arg_317) } else { arg_312 = linked_314.(*A_arbace_go_check_const_bf_add_A).Invoke_O_O_O__O(root_313, arg_316, arg_317) }; if linked_310 == nil { tmp1 = ifn_311.Invoke_O__O(arg_312) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_310.(*A_arbace_go_check_const_bf_sign_A).InvokePrim_O_O__J(root_309, arg_312)).Ref() }; return /*line :165:1*/ jrt.Number_Cast(tmp1).LongValue__J() }
//line :165:1
func (t *A_arbace_go_check_const_bf_cmp_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O_O__J(self, x__0, y__1)).Ref() }






func A_arbace_go_check_const_float_val_A_New() *A_arbace_go_check_const_float_val_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_float_val_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_go_check_const_float_val_A) Ctor() {}
//line :172:1
func (t *A_arbace_go_check_const_float_val_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var root_322 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_324 lang.IFn
	if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = x__0; if linked_323 == nil { tmp1 = ifn_324.Invoke_O__O(arg_325) } else { tmp1 = linked_323.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_322, arg_325) }
//line :175:1
	if jrt.J2g_Truth(tmp1) { return x__0 } else { var tmp2 any; var root_326 any = A_arbace_go_check_const_A_const_39.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_328 lang.IFn

		if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = x__0; if linked_327 == nil { tmp2 = ifn_328.Invoke_O__O(arg_329) } else { tmp2 = linked_327.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_326, arg_329) }
//line :175:1
		if jrt.J2g_Truth(tmp2) {

			var root_330 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = x__0; if linked_331 == nil { return ifn_332.Invoke_O__O(arg_333) } else { return linked_331.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_330, arg_333) } } else {
//line :175:1
				if A_arbace_go_check_const_A_const_8 != nil { return x__0 } else { return nil
				}
			}
	}
}

func A_arbace_go_check_const_fadd_A_New() *A_arbace_go_check_const_fadd_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fadd_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_go_check_const_fadd_A) Ctor() {}
//line :181:1
func (t *A_arbace_go_check_const_fadd_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(x__0); if tmp2 { tmp2 = jrt.Long_InstanceOf(y__1) }; tmp1 = tmp2; if tmp1 { return t.InvokeSpec_O_J_O_J_O__O(self, jrt.NN(jrt.Long_Cast(x__0)).LongValue__J(), x__0, jrt.NN(jrt.Long_Cast(y__1)).LongValue__J(), y__1) } else { var tmp3 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, x__0); if or__1927000174__auto____3 { tmp3 = or__1927000174__auto____3 } else { tmp3 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, y__1) }; if tmp3 { return A_arbace_go_check_const_A_const_22 } else { var tmp4 any; var or__1927000174__auto____3_2 any; var root_334 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = x__0; if linked_335 == nil { or__1927000174__auto____3_2 = ifn_336.Invoke_O__O(arg_337) } else { or__1927000174__auto____3_2 = linked_335.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_334, arg_337) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp4 = or__1927000174__auto____3_2 } else { var root_338 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = y__1; if linked_339 == nil { tmp4 = ifn_340.Invoke_O__O(arg_341) } else { tmp4 = linked_339.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_338, arg_341) } }; if jrt.J2g_Truth(tmp4) { var root_342 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, A_arbace_go_check_const_bf_add_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = x__0; var arg_346 any = y__1; if linked_343 == nil { return ifn_344.Invoke_O_O__O(arg_345, arg_346) } else { return linked_343.(*A_arbace_go_check_const_bf_add_A).Invoke_O_O_O__O(root_342, arg_345, arg_346) } } else { if A_arbace_go_check_const_A_const_8 != nil { var root_347 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any; var na_351 any = x__0; var na_352 any = y__1; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_351); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_352) }; tmp5 = tmp6; if tmp5 { var n0_353 int64 = jrt.NN(jrt.Long_Cast(na_351)).LongValue__J(); var n1_354 int64 = jrt.NN(jrt.Long_Cast(na_352)).LongValue__J(); var nr_355 int64 = n0_353 + n1_354; if (n0_353^nr_355)&(n1_354^nr_355) >= 0 { arg_350 = jrt.Long_ValueOf_J__Long_NoInit(nr_355).Ref() } else { arg_350 = lang.Numbers_Add_O_O__Number_NoInit(na_351, na_352) } } else { var tmp7 bool; var tmp8 bool; tmp8 = jrt.Double_InstanceOf(na_351); if tmp8 { tmp8 = jrt.Double_InstanceOf(na_352) }; tmp7 = tmp8; if tmp7 { var n0_353_2 float64 = jrt.NN(jrt.Double_Cast(na_351)).DoubleValue__D(); var n1_354_2 float64 = jrt.NN(jrt.Double_Cast(na_352)).DoubleValue__D(); arg_350 = jrt.Double_ValueOf_D__Double_NoInit(n0_353_2 + n1_354_2).Ref() } else { arg_350 = lang.Numbers_Add_O_O__Number_NoInit(na_351, na_352) } }; if linked_348 == nil { return ifn_349.Invoke_O__O(arg_350) } else { return linked_348.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_347, arg_350) } } else { return nil } } } } }
//line :181:1
func (t *A_arbace_go_check_const_fadd_A) InvokeSpec_O_J_O_J_O__O(self any, x__0_l int64, x__0_b any, y__1_l int64, y__1_b any) any { var tmp1 bool; var or__1927000174__auto____3 bool; var tmp2 any = A_arbace_go_check_const_A_const_22; var tmp3 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp3 = x__0_b } else { tmp3 = x__0_b }; or__1927000174__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { var tmp4 any = A_arbace_go_check_const_A_const_22; var tmp5 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp5 = y__1_b } else { tmp5 = y__1_b }; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5) }; if tmp1 { return A_arbace_go_check_const_A_const_22 } else { var tmp6 any; var or__1927000174__auto____3_2 any; var root_356 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_359 = x__0_b } else { arg_359 = x__0_b }; if linked_357 == nil { or__1927000174__auto____3_2 = ifn_358.Invoke_O__O(arg_359) } else { or__1927000174__auto____3_2 = linked_357.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_356, arg_359) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp6 = or__1927000174__auto____3_2 } else { var root_360 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); arg_363 = y__1_b } else { arg_363 = y__1_b }; if linked_361 == nil { tmp6 = ifn_362.Invoke_O__O(arg_363) } else { tmp6 = linked_361.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_360, arg_363) } }; if jrt.J2g_Truth(tmp6) { var root_364 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, A_arbace_go_check_const_bf_add_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_367 = x__0_b } else { arg_367 = x__0_b }; var arg_368 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); arg_368 = y__1_b } else { arg_368 = y__1_b }; if linked_365 == nil { return ifn_366.Invoke_O_O__O(arg_367, arg_368) } else { return linked_365.(*A_arbace_go_check_const_bf_add_A).Invoke_O_O_O__O(root_364, arg_367, arg_368) } } else { if A_arbace_go_check_const_A_const_8 != nil { var root_369 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any; var n0_373 int64 = x__0_l; var n1_374 int64 = y__1_l; var nr_375 int64 = n0_373 + n1_374; if (n0_373^nr_375)&(n1_374^nr_375) >= 0 { arg_372 = jrt.Long_ValueOf_J__Long_NoInit(nr_375).Ref() } else { var tmp7 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp7 = x__0_b } else { tmp7 = x__0_b }; var tmp8 any = tmp7; var tmp9 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp9 = y__1_b } else { tmp9 = y__1_b }; arg_372 = lang.Numbers_Add_O_O__Number_NoInit(tmp8, tmp9) }; if linked_370 == nil { return ifn_371.Invoke_O__O(arg_372) } else { return linked_370.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_369, arg_372) } } else { return nil } } } }
func A_arbace_go_check_const_fsub_A_New() *A_arbace_go_check_const_fsub_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fsub_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_go_check_const_fsub_A) Ctor() {}
//line :182:1
func (t *A_arbace_go_check_const_fsub_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(x__0); if tmp2 { tmp2 = jrt.Long_InstanceOf(y__1) }; tmp1 = tmp2; if tmp1 { return t.InvokeSpec_O_J_O_J_O__O(self, jrt.NN(jrt.Long_Cast(x__0)).LongValue__J(), x__0, jrt.NN(jrt.Long_Cast(y__1)).LongValue__J(), y__1) } else { var tmp3 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, x__0); if or__1927000174__auto____3 { tmp3 = or__1927000174__auto____3 } else { tmp3 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, y__1) }; if tmp3 { return A_arbace_go_check_const_A_const_22 } else { var tmp4 any; var or__1927000174__auto____3_2 any; var root_376 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = x__0; if linked_377 == nil { or__1927000174__auto____3_2 = ifn_378.Invoke_O__O(arg_379) } else { or__1927000174__auto____3_2 = linked_377.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_376, arg_379) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp4 = or__1927000174__auto____3_2 } else { var root_380 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = y__1; if linked_381 == nil { tmp4 = ifn_382.Invoke_O__O(arg_383) } else { tmp4 = linked_381.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_380, arg_383) } }; if jrt.J2g_Truth(tmp4) { var root_384 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, A_arbace_go_check_const_bf_add_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = x__0; var arg_388 any; var root_389 any = A_arbace_go_check_const_A_const_38.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_389, A_arbace_go_check_const_bf_neg_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = y__1; if linked_390 == nil { arg_388 = ifn_391.Invoke_O__O(arg_392) } else { if jrt.Long_InstanceOf(arg_392) { arg_388 = linked_390.(*A_arbace_go_check_const_bf_neg_A).InvokeSpec_O_J_O__O(root_389, jrt.NN(jrt.Long_Cast(arg_392)).LongValue__J(), arg_392) } else { arg_388 = linked_390.(*A_arbace_go_check_const_bf_neg_A).Invoke_O_O__O(root_389, arg_392) } }; if linked_385 == nil { return ifn_386.Invoke_O_O__O(arg_387, arg_388) } else { return linked_385.(*A_arbace_go_check_const_bf_add_A).Invoke_O_O_O__O(root_384, arg_387, arg_388) } } else { if A_arbace_go_check_const_A_const_8 != nil { var root_393 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any; var na_397 any = x__0; var na_398 any = y__1; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_397); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_398) }; tmp5 = tmp6; if tmp5 { var n0_399 int64 = jrt.NN(jrt.Long_Cast(na_397)).LongValue__J(); var n1_400 int64 = jrt.NN(jrt.Long_Cast(na_398)).LongValue__J(); var nr_401 int64 = n0_399 - n1_400; var tmp7 bool; var tmp8 bool; tmp8 = !(n1_400 == -9223372036854775808); if tmp8 { tmp8 = (n0_399^n1_400)&(n0_399^nr_401) >= 0 }; tmp7 = tmp8; if tmp7 { arg_396 = jrt.Long_ValueOf_J__Long_NoInit(nr_401).Ref() } else { arg_396 = lang.Numbers_Minus_O_O__Number_NoInit(na_397, na_398) } } else { var tmp9 bool; var tmp10 bool; tmp10 = jrt.Double_InstanceOf(na_397); if tmp10 { tmp10 = jrt.Double_InstanceOf(na_398) }; tmp9 = tmp10; if tmp9 { var n0_399_2 float64 = jrt.NN(jrt.Double_Cast(na_397)).DoubleValue__D(); var n1_400_2 float64 = jrt.NN(jrt.Double_Cast(na_398)).DoubleValue__D(); arg_396 = jrt.Double_ValueOf_D__Double_NoInit(n0_399_2 + -n1_400_2).Ref() } else { arg_396 = lang.Numbers_Minus_O_O__Number_NoInit(na_397, na_398) } }; if linked_394 == nil { return ifn_395.Invoke_O__O(arg_396) } else { return linked_394.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_393, arg_396) } } else { return nil } } } } }
//line :182:1
func (t *A_arbace_go_check_const_fsub_A) InvokeSpec_O_J_O_J_O__O(self any, x__0_l int64, x__0_b any, y__1_l int64, y__1_b any) any { var tmp1 bool; var or__1927000174__auto____3 bool; var tmp2 any = A_arbace_go_check_const_A_const_22; var tmp3 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp3 = x__0_b } else { tmp3 = x__0_b }; or__1927000174__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { var tmp4 any = A_arbace_go_check_const_A_const_22; var tmp5 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp5 = y__1_b } else { tmp5 = y__1_b }; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5) }; if tmp1 { return A_arbace_go_check_const_A_const_22 } else { var tmp6 any; var or__1927000174__auto____3_2 any; var root_402 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_405 = x__0_b } else { arg_405 = x__0_b }; if linked_403 == nil { or__1927000174__auto____3_2 = ifn_404.Invoke_O__O(arg_405) } else { or__1927000174__auto____3_2 = linked_403.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_402, arg_405) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp6 = or__1927000174__auto____3_2 } else { var root_406 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); arg_409 = y__1_b } else { arg_409 = y__1_b }; if linked_407 == nil { tmp6 = ifn_408.Invoke_O__O(arg_409) } else { tmp6 = linked_407.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_406, arg_409) } }; if jrt.J2g_Truth(tmp6) { var root_410 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, A_arbace_go_check_const_bf_add_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_413 = x__0_b } else { arg_413 = x__0_b }; var arg_414 any; var root_415 any = A_arbace_go_check_const_A_const_38.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_415, A_arbace_go_check_const_bf_neg_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; if linked_416 == nil { var tmp7 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp7 = y__1_b } else { tmp7 = y__1_b }; arg_414 = ifn_417.Invoke_O__O(tmp7) } else { arg_414 = linked_416.(*A_arbace_go_check_const_bf_neg_A).InvokeSpec_O_J_O__O(root_415, y__1_l, y__1_b) }; if linked_411 == nil { return ifn_412.Invoke_O_O__O(arg_413, arg_414) } else { return linked_411.(*A_arbace_go_check_const_bf_add_A).Invoke_O_O_O__O(root_410, arg_413, arg_414) } } else { if A_arbace_go_check_const_A_const_8 != nil { var root_419 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any; var n0_423 int64 = x__0_l; var n1_424 int64 = y__1_l; var nr_425 int64 = n0_423 - n1_424; var tmp8 bool; var tmp9 bool; tmp9 = !(n1_424 == -9223372036854775808); if tmp9 { tmp9 = (n0_423^n1_424)&(n0_423^nr_425) >= 0 }; tmp8 = tmp9; if tmp8 { arg_422 = jrt.Long_ValueOf_J__Long_NoInit(nr_425).Ref() } else { var tmp10 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp10 = x__0_b } else { tmp10 = x__0_b }; var tmp11 any = tmp10; var tmp12 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp12 = y__1_b } else { tmp12 = y__1_b }; arg_422 = lang.Numbers_Minus_O_O__Number_NoInit(tmp11, tmp12) }; if linked_420 == nil { return ifn_421.Invoke_O__O(arg_422) } else { return linked_420.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_419, arg_422) } } else { return nil } } } }
func A_arbace_go_check_const_fmul_A_New() *A_arbace_go_check_const_fmul_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fmul_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_go_check_const_fmul_A) Ctor() {}
//line :183:1
func (t *A_arbace_go_check_const_fmul_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(x__0); if tmp2 { tmp2 = jrt.Long_InstanceOf(y__1) }; tmp1 = tmp2; if tmp1 { return t.InvokeSpec_O_J_O_J_O__O(self, jrt.NN(jrt.Long_Cast(x__0)).LongValue__J(), x__0, jrt.NN(jrt.Long_Cast(y__1)).LongValue__J(), y__1) } else { var tmp3 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, x__0); if or__1927000174__auto____3 { tmp3 = or__1927000174__auto____3 } else { tmp3 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, y__1) }; if tmp3 { return A_arbace_go_check_const_A_const_22 } else { var tmp4 any; var or__1927000174__auto____3_2 any; var root_426 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = x__0; if linked_427 == nil { or__1927000174__auto____3_2 = ifn_428.Invoke_O__O(arg_429) } else { or__1927000174__auto____3_2 = linked_427.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_426, arg_429) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp4 = or__1927000174__auto____3_2 } else { var root_430 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = y__1; if linked_431 == nil { tmp4 = ifn_432.Invoke_O__O(arg_433) } else { tmp4 = linked_431.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_430, arg_433) } }; if jrt.J2g_Truth(tmp4) { var root_434 any = A_arbace_go_check_const_A_const_41.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, A_arbace_go_check_const_bf_mul_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = x__0; var arg_438 any = y__1; if linked_435 == nil { return ifn_436.Invoke_O_O__O(arg_437, arg_438) } else { return linked_435.(*A_arbace_go_check_const_bf_mul_A).Invoke_O_O_O__O(root_434, arg_437, arg_438) } } else { if A_arbace_go_check_const_A_const_8 != nil { var root_439 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any; var na_443 any = x__0; var na_444 any = y__1; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_443); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_444) }; tmp5 = tmp6; if tmp5 { var n0_445 int64 = jrt.NN(jrt.Long_Cast(na_443)).LongValue__J(); var n1_446 int64 = jrt.NN(jrt.Long_Cast(na_444)).LongValue__J(); var nr_447 int64 = n0_445 * n1_446; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; tmp10 = n0_445 == -9223372036854775808; if tmp10 { tmp10 = n1_446 < 0 }; tmp9 = tmp10; tmp8 = !tmp9; if tmp8 { var tmp11 bool; tmp11 = n1_446 == 0; if !tmp11 { tmp11 = nr_447/n1_446 == n0_445 }; tmp8 = tmp11 }; tmp7 = tmp8; if tmp7 { arg_442 = jrt.Long_ValueOf_J__Long_NoInit(nr_447).Ref() } else { arg_442 = lang.Numbers_Multiply_O_O__Number_NoInit(na_443, na_444) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_443); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_444) }; tmp12 = tmp13; if tmp12 { var n0_445_2 float64 = jrt.NN(jrt.Double_Cast(na_443)).DoubleValue__D(); var n1_446_2 float64 = jrt.NN(jrt.Double_Cast(na_444)).DoubleValue__D(); arg_442 = jrt.Double_ValueOf_D__Double_NoInit(float64(n0_445_2 * n1_446_2)).Ref() } else { arg_442 = lang.Numbers_Multiply_O_O__Number_NoInit(na_443, na_444) } }; if linked_440 == nil { return ifn_441.Invoke_O__O(arg_442) } else { return linked_440.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_439, arg_442) } } else { return nil } } } } }
//line :183:1
func (t *A_arbace_go_check_const_fmul_A) InvokeSpec_O_J_O_J_O__O(self any, x__0_l int64, x__0_b any, y__1_l int64, y__1_b any) any { var tmp1 bool; var or__1927000174__auto____3 bool; var tmp2 any = A_arbace_go_check_const_A_const_22; var tmp3 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp3 = x__0_b } else { tmp3 = x__0_b }; or__1927000174__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { var tmp4 any = A_arbace_go_check_const_A_const_22; var tmp5 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp5 = y__1_b } else { tmp5 = y__1_b }; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5) }; if tmp1 { return A_arbace_go_check_const_A_const_22 } else { var tmp6 any; var or__1927000174__auto____3_2 any; var root_448 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_451 = x__0_b } else { arg_451 = x__0_b }; if linked_449 == nil { or__1927000174__auto____3_2 = ifn_450.Invoke_O__O(arg_451) } else { or__1927000174__auto____3_2 = linked_449.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_448, arg_451) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp6 = or__1927000174__auto____3_2 } else { var root_452 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); arg_455 = y__1_b } else { arg_455 = y__1_b }; if linked_453 == nil { tmp6 = ifn_454.Invoke_O__O(arg_455) } else { tmp6 = linked_453.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_452, arg_455) } }; if jrt.J2g_Truth(tmp6) { var root_456 any = A_arbace_go_check_const_A_const_41.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, A_arbace_go_check_const_bf_mul_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_459 = x__0_b } else { arg_459 = x__0_b }; var arg_460 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); arg_460 = y__1_b } else { arg_460 = y__1_b }; if linked_457 == nil { return ifn_458.Invoke_O_O__O(arg_459, arg_460) } else { return linked_457.(*A_arbace_go_check_const_bf_mul_A).Invoke_O_O_O__O(root_456, arg_459, arg_460) } } else { if A_arbace_go_check_const_A_const_8 != nil { var root_461 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_463 lang.IFn; if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any; var n0_465 int64 = x__0_l; var n1_466 int64 = y__1_l; var nr_467 int64 = n0_465 * n1_466; var tmp7 bool; var tmp8 bool; var tmp9 bool; var tmp10 bool; tmp10 = n0_465 == -9223372036854775808; if tmp10 { tmp10 = n1_466 < 0 }; tmp9 = tmp10; tmp8 = !tmp9; if tmp8 { var tmp11 bool; tmp11 = n1_466 == 0; if !tmp11 { tmp11 = nr_467/n1_466 == n0_465 }; tmp8 = tmp11 }; tmp7 = tmp8; if tmp7 { arg_464 = jrt.Long_ValueOf_J__Long_NoInit(nr_467).Ref() } else { var tmp12 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp12 = x__0_b } else { tmp12 = x__0_b }; var tmp13 any = tmp12; var tmp14 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp14 = y__1_b } else { tmp14 = y__1_b }; arg_464 = lang.Numbers_Multiply_O_O__Number_NoInit(tmp13, tmp14) }; if linked_462 == nil { return ifn_463.Invoke_O__O(arg_464) } else { return linked_462.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_461, arg_464) } } else { return nil } } } }
func A_arbace_go_check_const_fquo_A_New() *A_arbace_go_check_const_fquo_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fquo_A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_go_check_const_fquo_A) Ctor() {}
//line :184:1
func (t *A_arbace_go_check_const_fquo_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, x__0); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, y__1) }; if tmp1 { return A_arbace_go_check_const_A_const_22 } else { var tmp2 any; var or__1927000174__auto____3_2 any; var root_468 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_470 lang.IFn; if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = x__0; if linked_469 == nil { or__1927000174__auto____3_2 = ifn_470.Invoke_O__O(arg_471) } else { or__1927000174__auto____3_2 = linked_469.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_468, arg_471) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp2 = or__1927000174__auto____3_2 } else { var root_472 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = y__1; if linked_473 == nil { tmp2 = ifn_474.Invoke_O__O(arg_475) } else { tmp2 = linked_473.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_472, arg_475) } }; if jrt.J2g_Truth(tmp2) { var root_476 any = A_arbace_go_check_const_A_const_42.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, A_arbace_go_check_const_bf_quo_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any = x__0; var arg_480 any = y__1; if linked_477 == nil { return ifn_478.Invoke_O_O__O(arg_479, arg_480) } else { return linked_477.(*A_arbace_go_check_const_bf_quo_A).Invoke_O_O_O__O(root_476, arg_479, arg_480) } } else { if A_arbace_go_check_const_A_const_8 != nil { var root_481 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = lang.Numbers_Divide_O_O__Number_NoInit(x__0, y__1); if linked_482 == nil { return ifn_483.Invoke_O__O(arg_484) } else { return linked_482.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_481, arg_484) } } else { return nil } } } }
func A_arbace_go_check_const_fneg_A_New() *A_arbace_go_check_const_fneg_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fneg_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_go_check_const_fneg_A) Ctor() {}
//line :185:1
func (t *A_arbace_go_check_const_fneg_A) Invoke_O_O__O(self, x__0 any) any { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_check_const_A_const_22, x__0) { return A_arbace_go_check_const_A_const_22 } else { var root_485 any = A_arbace_go_check_const_A_const_38.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_485, A_arbace_go_check_const_bf_neg_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = x__0; if linked_486 == nil { return ifn_487.Invoke_O__O(arg_488) } else { if jrt.Long_InstanceOf(arg_488) { return linked_486.(*A_arbace_go_check_const_bf_neg_A).InvokeSpec_O_J_O__O(root_485, jrt.NN(jrt.Long_Cast(arg_488)).LongValue__J(), arg_488) } else { return linked_486.(*A_arbace_go_check_const_bf_neg_A).Invoke_O_O__O(root_485, arg_488) } } } }
func A_arbace_go_check_const_fsign_A_New() *A_arbace_go_check_const_fsign_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fsign_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_go_check_const_fsign_A) Ctor() {}
//line :186:1
func (t *A_arbace_go_check_const_fsign_A) InvokePrim_O_O__J(self, x__0 any) int64 { var tmp1 any; var root_489 any = A_arbace_go_check_const_A_const_36.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_489, A_arbace_go_check_const_bf_sign_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = x__0; if linked_490 == nil { tmp1 = ifn_491.Invoke_O__O(arg_492) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_490.(*A_arbace_go_check_const_bf_sign_A).InvokePrim_O_O__J(root_489, arg_492)).Ref() }; return jrt.Number_Cast(tmp1).LongValue__J() }
//line :186:1
func (t *A_arbace_go_check_const_fsign_A) Invoke_O_O__O(self, x__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, x__0)).Ref() }
func A_arbace_go_check_const_fcmp_A_New() *A_arbace_go_check_const_fcmp_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fcmp_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_go_check_const_fcmp_A) Ctor() {}
//line :187:1
func (t *A_arbace_go_check_const_fcmp_A) InvokePrim_O_O_O__J(self, x__0, y__1 any) int64 { var tmp1 any; var tmp2 any; var or__1927000174__auto____3 any; var root_493 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = x__0; if linked_494 == nil { or__1927000174__auto____3 = ifn_495.Invoke_O__O(arg_496) } else { or__1927000174__auto____3 = linked_494.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_493, arg_496) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_497 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = y__1; if linked_498 == nil { tmp2 = ifn_499.Invoke_O__O(arg_500) } else { tmp2 = linked_498.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_497, arg_500) } }; if jrt.J2g_Truth(tmp2) { var root_501 any = A_arbace_go_check_const_A_const_43.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_501, A_arbace_go_check_const_bf_cmp_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = x__0; var arg_505 any = y__1; if linked_502 == nil { tmp1 = ifn_503.Invoke_O_O__O(arg_504, arg_505) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_502.(*A_arbace_go_check_const_bf_cmp_A).InvokePrim_O_O_O__J(root_501, arg_504, arg_505)).Ref() } } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.Util_Compare_O_O__I_NoInit(x__0, y__1))).Ref() }; return jrt.Number_Cast(tmp1).LongValue__J() }
//line :187:1
func (t *A_arbace_go_check_const_fcmp_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O_O__J(self, x__0, y__1)).Ref() }
func A_arbace_go_check_const_fzero_QMARK__A_New() *A_arbace_go_check_const_fzero_QMARK__A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fzero_QMARK__A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_go_check_const_fzero_QMARK__A) Ctor() {}
//line :188:1
func (t *A_arbace_go_check_const_fzero_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var tmp1 int64; var root_506 any = A_arbace_go_check_const_A_const_44.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_506, A_arbace_go_check_const_fsign_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = x__0; if linked_507 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_508.Invoke_O__O(arg_509)) } else { tmp1 = linked_507.(*A_arbace_go_check_const_fsign_A).InvokePrim_O_O__J(root_506, arg_509) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref() }

func A_arbace_go_check_const_int_val_A_New() *A_arbace_go_check_const_int_val_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_int_val_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_go_check_const_int_val_A) Ctor() {}
//line :190:1
func (t *A_arbace_go_check_const_int_val_A) Invoke_O_O__O(self, x__0 any) any {




	var tmp1 any; var root_510 any = A_arbace_go_check_const_A_const_39.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_512 lang.IFn
	if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = x__0; if linked_511 == nil { tmp1 = ifn_512.Invoke_O__O(arg_513) } else { tmp1 = linked_511.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_510, arg_513) }
//line :195:1
	if jrt.J2g_Truth(tmp1) { return x__0 } else { var tmp2 any; var root_514 any = A_arbace_go_check_const_A_const_24.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_516 lang.IFn

		if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = x__0; if linked_515 == nil { tmp2 = ifn_516.Invoke_O__O(arg_517) } else { tmp2 = linked_515.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_514, arg_517) }
//line :195:1
		if jrt.J2g_Truth(tmp2) { return nil } else { var tmp3 any; var root_518 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_520 lang.IFn


			if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = x__0; if linked_519 == nil { tmp3 = ifn_520.Invoke_O__O(arg_521) } else { tmp3 = linked_519.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_518, arg_521) }
//line :195:1
			if jrt.J2g_Truth(tmp3) { var e__2 any; var root_522 any = A_arbace_go_check_const_A_const_45.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_522, A_arbace_go_check_const_bf_exp_A_fn_class); var ifn_524 lang.IFn



				if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = x__0; if linked_523 == nil { e__2 = ifn_524.Invoke_O__O(arg_525) } else { e__2 = jrt.Long_ValueOf_J__Long_NoInit(linked_523.(*A_arbace_go_check_const_bf_exp_A).InvokePrim_O_O__J(root_522, arg_525)).Ref() }
				var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_const_A_const_46.GetRawRoot__O()); var tmp5 jrt.Number_I; var na_532 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); if jrt.Long_InstanceOf(na_532) { var n0_533 int64 = jrt.NN(jrt.Long_Cast(na_532)).LongValue__J(); if n0_533 == -9223372036854775808 { tmp5 = lang.Numbers_Minus_O__Number_NoInit(na_532) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(-n0_533)) } } else { if jrt.Double_InstanceOf(na_532) { var n0_533_2 float64 = jrt.NN(jrt.Double_Cast(na_532)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(-n0_533_2)) } else { tmp5 = lang.Numbers_Minus_O__Number_NoInit(na_532) } }; if jrt.J2g_Truth(tmp4.Invoke_O_O_O__O(tmp5, e__2, A_arbace_go_check_const_A_const_31.GetRawRoot__O())) { var vec__161000079__3 any = x__0; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000079__3, lang.RT_IntCast_J__I_NoInit(0), nil); var m__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000079__3, lang.RT_IntCast_J__I_NoInit(1), nil); var ee__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000079__3, lang.RT_IntCast_J__I_NoInit(2), nil); var ee__7 int64 = lang.RT_LongCast_O__J_NoInit(ee__6); _ = ___4


					if lang.Numbers_Gte_J_J__Z_NoInit(ee__7, 0) {
						var root_534 any = A_arbace_go_check_const_A_const_47.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, A_arbace_go_check_const_norm_int_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = jrt.NN(jrt.BigInteger_Cast(m__5)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(ee__7)).Ref(); if linked_535 == nil { return ifn_536.Invoke_O__O(arg_537) } else { return linked_535.(*A_arbace_go_check_const_norm_int_A).Invoke_O_O__O(root_534, arg_537) } } else {
//line :203:1
							var p__8 any; var na_538 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O()
							var na_539 int64 = 4

							if jrt.Long_InstanceOf(na_538) { var n0_540 int64 = jrt.NN(jrt.Long_Cast(na_538)).LongValue__J(); var n1_541 int64 = na_539; var nr_542 int64 = n0_540 - n1_541; var tmp6 bool; var tmp7 bool; tmp7 = !(n1_541 == -9223372036854775808); if tmp7 { tmp7 = (n0_540^n1_541)&(n0_540^nr_542) >= 0 }; tmp6 = tmp7; if tmp6 { p__8 = jrt.Long_ValueOf_J__Long_NoInit(nr_542).Ref() } else { p__8 = lang.Numbers_Minus_O_J__Number_NoInit(na_538, na_539) } } else { p__8 = lang.Numbers_Minus_O_J__Number_NoInit(na_538, na_539) }
//line :203:1
							var n__9 int32 = jrt.NN(jrt.NN(jrt.BigInteger_Cast(m__5)).Abs__BigInteger()).BitLength__I(); var try_round__10 any; var tmp8 any = A_arbace_go_check_const_int_val_try_round__161000082_A_New_I_O_O_J(n__9, m__5, p__8, ee__7); var tmp9 *jrt.Class
							var fncls__567 /*line :203:1*/*jrt.Class = A_arbace_go_check_const_int_val_try_round__161000082_A_fn_class




							if fncls__567 == nil { var fncls__567d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_check_const_int_val_try_round__161000082_A_fn_class = fncls__567d; tmp9 = fncls__567d } else { tmp9 = fncls__567 }; try_round__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)
//line :203:1
							var or__1927000174__auto____11 any = lang.IFn_Cast(try_round__10).Invoke_O__O(jrt.Boolean_FALSE.Ref())















							if jrt.J2g_Truth(or__1927000174__auto____11) { return or__1927000174__auto____11 } else { return lang.IFn_Cast(try_round__10).Invoke_O__O(jrt.Boolean_TRUE.Ref()) } } } else {
//line :200:1
								return nil } } else {
//line :195:1
									if A_arbace_go_check_const_A_const_8 != nil { return nil } else { return nil
									}
								}
		}
	}
}







func A_arbace_go_check_const_int_val_try_round__161000082_A_New_I_O_O_J(p0 int32, p1, p2 any, p3 int64) *A_arbace_go_check_const_int_val_try_round__161000082_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_int_val_try_round__161000082_A{}; t.Ctor_I_O_O_J(p0, p1, p2, p3); return t }
//line :208:1
func (t *A_arbace_go_check_const_int_val_try_round__161000082_A) Ctor_I_O_O_J(c__n int32, c__m, c__p any, c__ee int64) { t.F_n = c__n; t.F_m = c__m; t.F_p = c__p; t.F_ee = c__ee }
//line :208:1
func (t *A_arbace_go_check_const_int_val_try_round__161000082_A) Invoke_O_O__O(self, up_QMARK___1 any) any {
	var tmp1 bool; var na_543 int64 = int64(t.F_n); var na_544 any = t.F_p; if jrt.Long_InstanceOf(na_544) { var n0_545 int64 = na_543; var n1_546 int64 = jrt.NN(jrt.Long_Cast(na_544)).LongValue__J(); tmp1 = n0_545 <= n1_546 } else { tmp1 = lang.Numbers_Lte_J_O__Z_NoInit(na_543, na_544) }; if tmp1 { return nil } else { var sh__2 any; var na_548 int64 = int64(t.F_n); var na_549 any = t.F_p

		if jrt.Long_InstanceOf(na_549) { var n0_550 int64 = na_548; var n1_551 int64 = jrt.NN(jrt.Long_Cast(na_549)).LongValue__J(); var nr_552 int64 = n0_550 - n1_551; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_551 == -9223372036854775808); if tmp3 { tmp3 = (n0_550^n1_551)&(n0_550^nr_552) >= 0 }; tmp2 = tmp3; if tmp2 { sh__2 = jrt.Long_ValueOf_J__Long_NoInit(nr_552).Ref() } else { sh__2 = lang.Numbers_Minus_J_O__Number_NoInit(na_548, na_549) } } else { sh__2 = lang.Numbers_Minus_J_O__Number_NoInit(na_548, na_549) }
//line :209:1
		var a__3 any = jrt.NN(jrt.BigInteger_Cast(t.F_m)).Abs__BigInteger().Ref(); var q__4 any = jrt.NN(jrt.BigInteger_Cast(a__3)).ShiftRight_I__BigInteger(lang.RT_IntCast_O__I_NoInit(sh__2)).Ref(); var q__5 any




		if jrt.J2g_Truth(up_QMARK___1) { var tmp4 *jrt.BigInteger = jrt.BigInteger_Cast(q__4); var tmp5 *jrt.BigInteger; jrt.BigInteger_Init(); tmp5 = jrt.BigInteger_ONE; q__5 = jrt.NN(tmp4).Add_BigInteger__BigInteger(tmp5).Ref() } else { q__5 = q__4 }
//line :209:1
		var ve__6 any; var na_553 int64 = t.F_ee
		var na_554 any = sh__2




		if jrt.Long_InstanceOf(na_554) { var n0_555 int64 = na_553; var n1_556 int64 = jrt.NN(jrt.Long_Cast(na_554)).LongValue__J(); var nr_557 int64 = n0_555 + n1_556; if (n0_555^nr_557)&(n1_556^nr_557) >= 0 { ve__6 = jrt.Long_ValueOf_J__Long_NoInit(nr_557).Ref() } else { ve__6 = lang.Numbers_Add_J_O__Number_NoInit(na_553, na_554) } } else { ve__6 = lang.Numbers_Add_J_O__Number_NoInit(na_553, na_554) }
		var tmp6 bool; var na_558 any = ve__6; var na_559 int64 = 0; if jrt.Long_InstanceOf(na_558) { var n0_560 int64 = jrt.NN(jrt.Long_Cast(na_558)).LongValue__J(); var n1_561 int64 = na_559; tmp6 = n0_560 >= n1_561 } else { tmp6 = lang.Numbers_Gte_O_J__Z_NoInit(na_558, na_559) }; if tmp6 { var v__7 any = jrt.NN(jrt.BigInteger_Cast(q__5)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(ve__6)).Ref(); var root_563 any = A_arbace_go_check_const_A_const_47.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, A_arbace_go_check_const_norm_int_A_fn_class); var ifn_565 lang.IFn

			if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any; if lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(t.F_m)).Signum__I())) { arg_566 = jrt.NN(jrt.BigInteger_Cast(v__7)).Negate__BigInteger().Ref() } else { arg_566 = v__7 }; if linked_564 == nil { return ifn_565.Invoke_O__O(arg_566) } else { return linked_564.(*A_arbace_go_check_const_norm_int_A).Invoke_O_O__O(root_563, arg_566) } } else {
//line :216:1
				return nil
			}
	}
}




func A_arbace_go_check_const_round_binary_A_New() *A_arbace_go_check_const_round_binary_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_round_binary_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_go_check_const_round_binary_A) Ctor() {}
//line :224:1
func (t *A_arbace_go_check_const_round_binary_A) Invoke_O_O_O_O_O__O(self, x__0, mbits__1, emin__2, emax__3 any) any { var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(mbits__1); if tmp2 { tmp2 = jrt.Long_InstanceOf(emax__3) }; tmp1 = tmp2; if tmp1 { return t.InvokeSpec_O_O_J_O_O_J_O__O(self, x__0, jrt.NN(jrt.Long_Cast(mbits__1)).LongValue__J(), mbits__1, emin__2, jrt.NN(jrt.Long_Cast(emax__3)).LongValue__J(), emax__3) } else { var r__5 any; var tmp3 any; var root_568 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_570 lang.IFn




	if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = x__0; if linked_569 == nil { tmp3 = ifn_570.Invoke_O__O(arg_571) } else { tmp3 = linked_569.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_568, arg_571) }; if jrt.J2g_Truth(tmp3) { var root_572 any = A_arbace_go_check_const_A_const_48.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, A_arbace_go_check_const_bf__GT_rat_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = x__0; if linked_573 == nil { r__5 = ifn_574.Invoke_O__O(arg_575) } else { r__5 = linked_573.(*A_arbace_go_check_const_bf__GT_rat_A).Invoke_O_O__O(root_572, arg_575) } } else { r__5 = x__0 }
//line :224:1
	var vec__161000085__6 any; var root_576 any = A_arbace_go_check_const_A_const_27.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, A_arbace_go_check_const_rat_num_den_A_fn_class); var ifn_578 lang.IFn





	if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = r__5; if linked_577 == nil { vec__161000085__6 = ifn_578.Invoke_O__O(arg_579) } else { vec__161000085__6 = linked_577.(*A_arbace_go_check_const_rat_num_den_A).Invoke_O_O__O(root_576, arg_579) }
//line :224:1
	var p__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000085__6, lang.RT_IntCast_J__I_NoInit(0), nil); var q__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000085__6, lang.RT_IntCast_J__I_NoInit(1), nil)






	if lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__7)).Signum__I())) { return A_arbace_go_check_const_A_const_17 } else { var neg__9 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__7)).Signum__I())); var p__10 any = jrt.NN(jrt.BigInteger_Cast(p__7)).Abs__BigInteger().Ref(); var e0__11 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__10)).BitLength__I()), int64(jrt.NN(jrt.BigInteger_Cast(q__8)).BitLength__I())); var e__12 int64





		if lang.Numbers_Gte_J_J__Z_NoInit(e0__11, 0) {
			if lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__10)).CompareTo_BigInteger__I(jrt.NN(jrt.BigInteger_Cast(q__8)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(e0__11))))) { e__12 = lang.Numbers_Dec_J__J_NoInit(e0__11) } else { e__12 = e0__11 } } else {
				if lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(p__10)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J__J_NoInit(e0__11)))).CompareTo_BigInteger__I(jrt.BigInteger_Cast(q__8)))) { e__12 = lang.Numbers_Dec_J__J_NoInit(e0__11) } else { e__12 = e0__11 } }
//line :231:1
		var qe__13 any; var na_580 any = lang.Numbers_Max_J_O__O_NoInit(e__12, emin__2); var na_581 any
		var na_582 any = mbits__1








		if jrt.Long_InstanceOf(na_582) { var n0_583 int64 = jrt.NN(jrt.Long_Cast(na_582)).LongValue__J(); if n0_583 == -9223372036854775808 { na_581 = lang.Numbers_Dec_O__Number_NoInit(na_582) } else { na_581 = jrt.Long_ValueOf_J__Long_NoInit(n0_583 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_582) { var n0_583_2 float64 = jrt.NN(jrt.Double_Cast(na_582)).DoubleValue__D(); na_581 = jrt.Double_ValueOf_D__Double_NoInit(n0_583_2 - 1.0).Ref() } else { na_581 = lang.Numbers_Dec_O__Number_NoInit(na_582) } }; var tmp4 bool; var tmp5 bool; tmp5 = jrt.Long_InstanceOf(na_580); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_581) }; tmp4 = tmp5; if tmp4 { var n0_584 int64 = jrt.NN(jrt.Long_Cast(na_580)).LongValue__J(); var n1_585 int64 = jrt.NN(jrt.Long_Cast(na_581)).LongValue__J(); var nr_586 int64 = n0_584 - n1_585; var tmp6 bool; var tmp7 bool; tmp7 = !(n1_585 == -9223372036854775808); if tmp7 { tmp7 = (n0_584^n1_585)&(n0_584^nr_586) >= 0 }; tmp6 = tmp7; if tmp6 { qe__13 = jrt.Long_ValueOf_J__Long_NoInit(nr_586).Ref() } else { qe__13 = lang.Numbers_Minus_O_O__Number_NoInit(na_580, na_581) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_580); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_581) }; tmp8 = tmp9; if tmp8 { var n0_584_2 float64 = jrt.NN(jrt.Double_Cast(na_580)).DoubleValue__D(); var n1_585_2 float64 = jrt.NN(jrt.Double_Cast(na_581)).DoubleValue__D(); qe__13 = jrt.Double_ValueOf_D__Double_NoInit(n0_584_2 + -n1_585_2).Ref() } else { qe__13 = lang.Numbers_Minus_O_O__Number_NoInit(na_580, na_581) } }
//line :231:1
		var vec__161000088__14 any; var tmp10 bool
		var na_587 any = qe__13










		if jrt.Long_InstanceOf(na_587) { var n0_588 int64 = jrt.NN(jrt.Long_Cast(na_587)).LongValue__J(); tmp10 = n0_588 < 0 } else { if jrt.Double_InstanceOf(na_587) { var n0_588_2 float64 = jrt.NN(jrt.Double_Cast(na_587)).DoubleValue__D(); tmp10 = n0_588_2 < 0.0 } else { tmp10 = lang.Numbers_IsNeg_O__Z_NoInit(na_587) } }; if tmp10 { var tmp11 *jrt.BigInteger = jrt.BigInteger_Cast(p__10); var tmp12 jrt.Number_I; var na_638 any = qe__13; if jrt.Long_InstanceOf(na_638) { var n0_639 int64 = jrt.NN(jrt.Long_Cast(na_638)).LongValue__J(); if n0_639 == -9223372036854775808 { tmp12 = lang.Numbers_Minus_O__Number_NoInit(na_638) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(-n0_639)) } } else { if jrt.Double_InstanceOf(na_638) { var n0_639_2 float64 = jrt.NN(jrt.Double_Cast(na_638)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(-n0_639_2)) } else { tmp12 = lang.Numbers_Minus_O__Number_NoInit(na_638) } }; vec__161000088__14 = lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(tmp11).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(tmp12)).Ref(), q__8) } else { vec__161000088__14 = lang.Tuple_Create_O_O__IPersistentVector(p__10, jrt.NN(jrt.BigInteger_Cast(q__8)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(qe__13)).Ref()) }
//line :231:1
		var num__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000088__14, lang.RT_IntCast_J__I_NoInit(0), nil); var den__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000088__14, lang.RT_IntCast_J__I_NoInit(1), nil); var dr__17 any = jrt.NN(jrt.BigInteger_Cast(num__15)).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(den__16)).Ref(); var m__18 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__17, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)); var rm__19 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__17, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)); var c__20 int32 = jrt.NN(jrt.NN(jrt.BigInteger_Cast(rm__19)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(1))).CompareTo_BigInteger__I(jrt.BigInteger_Cast(den__16)); var m__21 any; var tmp13 bool; var or__1927000174__auto____21 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(c__20))















		if or__1927000174__auto____21 { tmp13 = or__1927000174__auto____21 } else { var and__1927000168__auto____22 bool = lang.Numbers_IsZero_J__Z_NoInit(int64(c__20)); if and__1927000168__auto____22 { tmp13 = jrt.NN(jrt.BigInteger_Cast(m__18)).TestBit_I__Z(lang.RT_IntCast_J__I_NoInit(0)) } else { tmp13 = and__1927000168__auto____22 } }; if tmp13 { var tmp14 *jrt.BigInteger = jrt.BigInteger_Cast(m__18); var tmp15 *jrt.BigInteger; jrt.BigInteger_Init(); tmp15 = jrt.BigInteger_ONE; m__21 = jrt.NN(tmp14).Add_BigInteger__BigInteger(tmp15).Ref() } else { m__21 = m__18 }
//line :231:1
		var top__22 any; var na_589 any; var na_591 any = qe__13; var na_592 int64 = int64(jrt.NN(jrt.BigInteger_Cast(m__21)).BitLength__I())

















		if jrt.Long_InstanceOf(na_591) { var n0_593 int64 = jrt.NN(jrt.Long_Cast(na_591)).LongValue__J(); var n1_594 int64 = na_592; var nr_595 int64 = n0_593 + n1_594; if (n0_593^nr_595)&(n1_594^nr_595) >= 0 { na_589 = jrt.Long_ValueOf_J__Long_NoInit(nr_595).Ref() } else { na_589 = lang.Numbers_Add_O_J__Number_NoInit(na_591, na_592) } } else { na_589 = lang.Numbers_Add_O_J__Number_NoInit(na_591, na_592) }; var na_590 int64 = -1; if jrt.Long_InstanceOf(na_589) { var n0_596 int64 = jrt.NN(jrt.Long_Cast(na_589)).LongValue__J(); var n1_597 int64 = na_590; var nr_598 int64 = n0_596 + n1_597; if (n0_596^nr_598)&(n1_597^nr_598) >= 0 { top__22 = jrt.Long_ValueOf_J__Long_NoInit(nr_598).Ref() } else { top__22 = lang.Numbers_Add_O_J__Number_NoInit(na_589, na_590) } } else { top__22 = lang.Numbers_Add_O_J__Number_NoInit(na_589, na_590) }
		var tmp16 bool; var na_599 any = top__22; var na_600 any = emax__3; var tmp17 bool; var tmp18 bool; tmp18 = jrt.Long_InstanceOf(na_599); if tmp18 { tmp18 = jrt.Long_InstanceOf(na_600) }; tmp17 = tmp18; if tmp17 { var n0_601 int64 = jrt.NN(jrt.Long_Cast(na_599)).LongValue__J(); var n1_602 int64 = jrt.NN(jrt.Long_Cast(na_600)).LongValue__J(); tmp16 = n0_601 > n1_602 } else { var tmp19 bool; var tmp20 bool; tmp20 = jrt.Double_InstanceOf(na_599); if tmp20 { tmp20 = jrt.Double_InstanceOf(na_600) }; tmp19 = tmp20; if tmp19 { var n0_601_2 float64 = jrt.NN(jrt.Double_Cast(na_599)).DoubleValue__D(); var n1_602_2 float64 = jrt.NN(jrt.Double_Cast(na_600)).DoubleValue__D(); tmp16 = n1_602_2 < n0_601_2 } else { tmp16 = lang.Numbers_Gt_O_O__Z_NoInit(na_599, na_600) } }; if tmp16 { return nil } else { var v__23 any; var tmp21 bool
			var na_604 any = qe__13
			if jrt.Long_InstanceOf(na_604) { var n0_605 int64 = jrt.NN(jrt.Long_Cast(na_604)).LongValue__J(); tmp21 = n0_605 < 0 } else { if jrt.Double_InstanceOf(na_604) { var n0_605_2 float64 = jrt.NN(jrt.Double_Cast(na_604)).DoubleValue__D(); tmp21 = n0_605_2 < 0.0 } else { tmp21 = lang.Numbers_IsNeg_O__Z_NoInit(na_604) } }; if tmp21 {
				var tmp22 any; var root_606 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = m__21; if linked_607 == nil { tmp22 = ifn_608.Invoke_O__O(arg_609) } else { tmp22 = linked_607.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_606, arg_609) }; var tmp23 any = tmp22; var tmp24 any; var root_610 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any; var root_614 any = A_arbace_go_check_const_A_const_29.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, A_arbace_go_check_const_pow2_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any; var na_618 any = qe__13; if jrt.Long_InstanceOf(na_618) { var n0_619 int64 = jrt.NN(jrt.Long_Cast(na_618)).LongValue__J(); if n0_619 == -9223372036854775808 { arg_617 = lang.Numbers_Minus_O__Number_NoInit(na_618) } else { arg_617 = jrt.Long_ValueOf_J__Long_NoInit(-n0_619).Ref() } } else { if jrt.Double_InstanceOf(na_618) { var n0_619_2 float64 = jrt.NN(jrt.Double_Cast(na_618)).DoubleValue__D(); arg_617 = jrt.Double_ValueOf_D__Double_NoInit(-n0_619_2).Ref() } else { arg_617 = lang.Numbers_Minus_O__Number_NoInit(na_618) } }; if linked_615 == nil { arg_613 = ifn_616.Invoke_O__O(arg_617) } else { arg_613 = linked_615.(*A_arbace_go_check_const_pow2_A).Invoke_O_O__O(root_614, arg_617) }; if linked_611 == nil { tmp24 = ifn_612.Invoke_O__O(arg_613) } else { tmp24 = linked_611.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_610, arg_613) }; v__23 = lang.Numbers_Divide_O_O__Number_NoInit(tmp23, tmp24) } else {
					var root_620 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any = jrt.NN(jrt.BigInteger_Cast(m__21)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(qe__13)).Ref(); if linked_621 == nil { v__23 = ifn_622.Invoke_O__O(arg_623) } else { v__23 = linked_621.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_620, arg_623) } }
//line :250:1
			var v__24 any; var tmp25 any; var root_624 any = A_arbace_go_check_const_A_const_24.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_626 lang.IFn




			if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = v__23; if linked_625 == nil { tmp25 = ifn_626.Invoke_O__O(arg_627) } else { tmp25 = linked_625.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_624, arg_627) }; if jrt.J2g_Truth(tmp25) { v__24 = v__23 } else { var root_628 any = A_arbace_go_check_const_A_const_47.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, A_arbace_go_check_const_norm_int_A_fn_class); var ifn_630 lang.IFn; if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any; var root_632 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, A_arbace_go_check_const_bi_A_fn_class); var ifn_634 lang.IFn; if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = v__23; if linked_633 == nil { arg_631 = ifn_634.Invoke_O__O(arg_635) } else { arg_631 = linked_633.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_632, arg_635) }; if linked_629 == nil { v__24 = ifn_630.Invoke_O__O(arg_631) } else { v__24 = linked_629.(*A_arbace_go_check_const_norm_int_A).Invoke_O_O__O(root_628, arg_631) } }
			if neg__9 { var na_636 any = v__24; if jrt.Long_InstanceOf(na_636) { var n0_637 int64 = jrt.NN(jrt.Long_Cast(na_636)).LongValue__J(); if n0_637 == -9223372036854775808 { return lang.Numbers_Minus_O__Number_NoInit(na_636) } else { return jrt.Long_ValueOf_J__Long_NoInit(-n0_637).Ref() } } else { if jrt.Double_InstanceOf(na_636) { var n0_637_2 float64 = jrt.NN(jrt.Double_Cast(na_636)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(-n0_637_2).Ref() } else { return lang.Numbers_Minus_O__Number_NoInit(na_636) } } } else { return v__24 } } } } }
//line :224:1
func (t *A_arbace_go_check_const_round_binary_A) InvokeSpec_O_O_J_O_O_J_O__O(self, x__0 any, mbits__1_l int64, mbits__1_b, emin__2 any, emax__3_l int64, emax__3_b any) any { var r__5 any; var tmp1 any; var root_640 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_642 lang.IFn; if




	linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = x__0; if linked_641 == nil { tmp1 = ifn_642.Invoke_O__O(arg_643) } else { tmp1 = linked_641.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_640, arg_643) }; if jrt.J2g_Truth(tmp1) { var root_644 any = A_arbace_go_check_const_A_const_48.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, A_arbace_go_check_const_bf__GT_rat_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = x__0; if linked_645 == nil { r__5 = ifn_646.Invoke_O__O(arg_647) } else { r__5 = linked_645.(*A_arbace_go_check_const_bf__GT_rat_A).Invoke_O_O__O(root_644, arg_647) } } else { r__5 = x__0 }; var vec__161000085__6 any; var root_648 any = /*line :224:1*/A_arbace_go_check_const_A_const_27.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, A_arbace_go_check_const_rat_num_den_A_fn_class); var ifn_650 lang.IFn; if





	linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = r__5; if linked_649 == nil { vec__161000085__6 = ifn_650.Invoke_O__O(arg_651) } else { vec__161000085__6 = linked_649.(*A_arbace_go_check_const_rat_num_den_A).Invoke_O_O__O(root_648, arg_651) }; var p__7 any = /*line :224:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__161000085__6, lang.RT_IntCast_J__I_NoInit(0), nil); var q__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000085__6, lang.RT_IntCast_J__I_NoInit(1), nil); if






	lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__7)).Signum__I())) { return A_arbace_go_check_const_A_const_17 } else { var neg__9 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__7)).Signum__I())); var p__10 any = jrt.NN(jrt.BigInteger_Cast(p__7)).Abs__BigInteger().Ref(); var e0__11 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__10)).BitLength__I()), int64(jrt.NN(jrt.BigInteger_Cast(q__8)).BitLength__I())); var e__12 int64





		if lang.Numbers_Gte_J_J__Z_NoInit(e0__11, 0) {
			if lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__10)).CompareTo_BigInteger__I(jrt.NN(jrt.BigInteger_Cast(q__8)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(e0__11))))) { e__12 = lang.Numbers_Dec_J__J_NoInit(e0__11) } else { e__12 = e0__11 } } else {
				if lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(p__10)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J__J_NoInit(e0__11)))).CompareTo_BigInteger__I(jrt.BigInteger_Cast(q__8)))) { e__12 = lang.Numbers_Dec_J__J_NoInit(e0__11) } else { e__12 = e0__11 } }
//line :231:1
		var qe__13 any; var na_652 any = lang.Numbers_Max_J_O__O_NoInit(e__12, emin__2); var na_653 any
		var n0_654 int64 = mbits__1_l








		if n0_654 == -9223372036854775808 { var tmp2 any; if mbits__1_b == nil { mbits__1_b = jrt.Long_ValueOf_J__Long_NoInit(mbits__1_l).Ref(); tmp2 = mbits__1_b } else { tmp2 = mbits__1_b }; na_653 = lang.Numbers_Dec_O__Number_NoInit(tmp2) } else { na_653 = jrt.Long_ValueOf_J__Long_NoInit(n0_654 - 1).Ref() }; var tmp3 bool; var tmp4 bool; tmp4 = jrt.Long_InstanceOf(na_652); if tmp4 { tmp4 = jrt.Long_InstanceOf(na_653) }; tmp3 = tmp4; if tmp3 { var n0_655 int64 = jrt.NN(jrt.Long_Cast(na_652)).LongValue__J(); var n1_656 int64 = jrt.NN(jrt.Long_Cast(na_653)).LongValue__J(); var nr_657 int64 = n0_655 - n1_656; var tmp5 bool; var tmp6 bool; tmp6 = !(n1_656 == -9223372036854775808); if tmp6 { tmp6 = (n0_655^n1_656)&(n0_655^nr_657) >= 0 }; tmp5 = tmp6; if tmp5 { qe__13 = jrt.Long_ValueOf_J__Long_NoInit(nr_657).Ref() } else { qe__13 = lang.Numbers_Minus_O_O__Number_NoInit(na_652, na_653) } } else { var tmp7 bool; var tmp8 bool; tmp8 = jrt.Double_InstanceOf(na_652); if tmp8 { tmp8 = jrt.Double_InstanceOf(na_653) }; tmp7 = tmp8; if tmp7 { var n0_655_2 float64 = jrt.NN(jrt.Double_Cast(na_652)).DoubleValue__D(); var n1_656_2 float64 = jrt.NN(jrt.Double_Cast(na_653)).DoubleValue__D(); qe__13 = jrt.Double_ValueOf_D__Double_NoInit(n0_655_2 + -n1_656_2).Ref() } else { qe__13 = lang.Numbers_Minus_O_O__Number_NoInit(na_652, na_653) } }
//line :231:1
		var vec__161000088__14 any; var tmp9 bool
		var na_658 any = qe__13










		if jrt.Long_InstanceOf(na_658) { var n0_659 int64 = jrt.NN(jrt.Long_Cast(na_658)).LongValue__J(); tmp9 = n0_659 < 0 } else { if jrt.Double_InstanceOf(na_658) { var n0_659_2 float64 = jrt.NN(jrt.Double_Cast(na_658)).DoubleValue__D(); tmp9 = n0_659_2 < 0.0 } else { tmp9 = lang.Numbers_IsNeg_O__Z_NoInit(na_658) } }; if tmp9 { var tmp10 *jrt.BigInteger = jrt.BigInteger_Cast(p__10); var tmp11 jrt.Number_I; var na_708 any = qe__13; if jrt.Long_InstanceOf(na_708) { var n0_709 int64 = jrt.NN(jrt.Long_Cast(na_708)).LongValue__J(); if n0_709 == -9223372036854775808 { tmp11 = lang.Numbers_Minus_O__Number_NoInit(na_708) } else { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(-n0_709)) } } else { if jrt.Double_InstanceOf(na_708) { var n0_709_2 float64 = jrt.NN(jrt.Double_Cast(na_708)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(-n0_709_2)) } else { tmp11 = lang.Numbers_Minus_O__Number_NoInit(na_708) } }; vec__161000088__14 = lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(tmp10).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(tmp11)).Ref(), q__8) } else { vec__161000088__14 = lang.Tuple_Create_O_O__IPersistentVector(p__10, jrt.NN(jrt.BigInteger_Cast(q__8)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(qe__13)).Ref()) }
//line :231:1
		var num__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000088__14, lang.RT_IntCast_J__I_NoInit(0), nil); var den__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000088__14, lang.RT_IntCast_J__I_NoInit(1), nil); var dr__17 any = jrt.NN(jrt.BigInteger_Cast(num__15)).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(den__16)).Ref(); var m__18 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__17, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)); var rm__19 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__17, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)); var c__20 int32 = jrt.NN(jrt.NN(jrt.BigInteger_Cast(rm__19)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(1))).CompareTo_BigInteger__I(jrt.BigInteger_Cast(den__16)); var m__21 any; var tmp12 bool; var or__1927000174__auto____21 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(c__20))















		if or__1927000174__auto____21 { tmp12 = or__1927000174__auto____21 } else { var and__1927000168__auto____22 bool = lang.Numbers_IsZero_J__Z_NoInit(int64(c__20)); if and__1927000168__auto____22 { tmp12 = jrt.NN(jrt.BigInteger_Cast(m__18)).TestBit_I__Z(lang.RT_IntCast_J__I_NoInit(0)) } else { tmp12 = and__1927000168__auto____22 } }; if tmp12 { var tmp13 *jrt.BigInteger = jrt.BigInteger_Cast(m__18); var tmp14 *jrt.BigInteger; jrt.BigInteger_Init(); tmp14 = jrt.BigInteger_ONE; m__21 = jrt.NN(tmp13).Add_BigInteger__BigInteger(tmp14).Ref() } else { m__21 = m__18 }
//line :231:1
		var top__22 any; var na_660 any; var na_662 any = qe__13; var na_663 int64 = int64(jrt.NN(jrt.BigInteger_Cast(m__21)).BitLength__I())

















		if jrt.Long_InstanceOf(na_662) { var n0_664 int64 = jrt.NN(jrt.Long_Cast(na_662)).LongValue__J(); var n1_665 int64 = na_663; var nr_666 int64 = n0_664 + n1_665; if (n0_664^nr_666)&(n1_665^nr_666) >= 0 { na_660 = jrt.Long_ValueOf_J__Long_NoInit(nr_666).Ref() } else { na_660 = lang.Numbers_Add_O_J__Number_NoInit(na_662, na_663) } } else { na_660 = lang.Numbers_Add_O_J__Number_NoInit(na_662, na_663) }; var na_661 int64 = -1; if jrt.Long_InstanceOf(na_660) { var n0_667 int64 = jrt.NN(jrt.Long_Cast(na_660)).LongValue__J(); var n1_668 int64 = na_661; var nr_669 int64 = n0_667 + n1_668; if (n0_667^nr_669)&(n1_668^nr_669) >= 0 { top__22 = jrt.Long_ValueOf_J__Long_NoInit(nr_669).Ref() } else { top__22 = lang.Numbers_Add_O_J__Number_NoInit(na_660, na_661) } } else { top__22 = lang.Numbers_Add_O_J__Number_NoInit(na_660, na_661) }
		var tmp15 bool; var na_670 any = top__22; if jrt.Long_InstanceOf(na_670) { var n0_671 int64 = jrt.NN(jrt.Long_Cast(na_670)).LongValue__J(); var n1_672 int64 = emax__3_l; tmp15 = n0_671 > n1_672 } else { var tmp16 any; if emax__3_b == nil { emax__3_b = jrt.Long_ValueOf_J__Long_NoInit(emax__3_l).Ref(); tmp16 = emax__3_b } else { tmp16 = emax__3_b }; tmp15 = lang.Numbers_Gt_O_O__Z_NoInit(na_670, tmp16) }; if tmp15 { return nil } else { var v__23 any; var tmp17 bool
			var na_674 any = qe__13
			if jrt.Long_InstanceOf(na_674) { var n0_675 int64 = jrt.NN(jrt.Long_Cast(na_674)).LongValue__J(); tmp17 = n0_675 < 0 } else { if jrt.Double_InstanceOf(na_674) { var n0_675_2 float64 = jrt.NN(jrt.Double_Cast(na_674)).DoubleValue__D(); tmp17 = n0_675_2 < 0.0 } else { tmp17 = lang.Numbers_IsNeg_O__Z_NoInit(na_674) } }; if tmp17 {
				var tmp18 any; var root_676 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = m__21; if linked_677 == nil { tmp18 = ifn_678.Invoke_O__O(arg_679) } else { tmp18 = linked_677.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_676, arg_679) }; var tmp19 any = tmp18; var tmp20 any; var root_680 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any; var root_684 any = A_arbace_go_check_const_A_const_29.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, A_arbace_go_check_const_pow2_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any; var na_688 any = qe__13; if jrt.Long_InstanceOf(na_688) { var n0_689 int64 = jrt.NN(jrt.Long_Cast(na_688)).LongValue__J(); if n0_689 == -9223372036854775808 { arg_687 = lang.Numbers_Minus_O__Number_NoInit(na_688) } else { arg_687 = jrt.Long_ValueOf_J__Long_NoInit(-n0_689).Ref() } } else { if jrt.Double_InstanceOf(na_688) { var n0_689_2 float64 = jrt.NN(jrt.Double_Cast(na_688)).DoubleValue__D(); arg_687 = jrt.Double_ValueOf_D__Double_NoInit(-n0_689_2).Ref() } else { arg_687 = lang.Numbers_Minus_O__Number_NoInit(na_688) } }; if linked_685 == nil { arg_683 = ifn_686.Invoke_O__O(arg_687) } else { arg_683 = linked_685.(*A_arbace_go_check_const_pow2_A).Invoke_O_O__O(root_684, arg_687) }; if linked_681 == nil { tmp20 = ifn_682.Invoke_O__O(arg_683) } else { tmp20 = linked_681.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_680, arg_683) }; v__23 = lang.Numbers_Divide_O_O__Number_NoInit(tmp19, tmp20) } else {
					var root_690 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = jrt.NN(jrt.BigInteger_Cast(m__21)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(qe__13)).Ref(); if linked_691 == nil { v__23 = ifn_692.Invoke_O__O(arg_693) } else { v__23 = linked_691.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_690, arg_693) } }
//line :250:1
			var v__24 any; var tmp21 any; var root_694 any = A_arbace_go_check_const_A_const_24.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_696 lang.IFn




			if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = v__23; if linked_695 == nil { tmp21 = ifn_696.Invoke_O__O(arg_697) } else { tmp21 = linked_695.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_694, arg_697) }; if jrt.J2g_Truth(tmp21) { v__24 = v__23 } else { var root_698 any = A_arbace_go_check_const_A_const_47.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, A_arbace_go_check_const_norm_int_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any; var root_702 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, A_arbace_go_check_const_bi_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = v__23; if linked_703 == nil { arg_701 = ifn_704.Invoke_O__O(arg_705) } else { arg_701 = linked_703.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_702, arg_705) }; if linked_699 == nil { v__24 = ifn_700.Invoke_O__O(arg_701) } else { v__24 = linked_699.(*A_arbace_go_check_const_norm_int_A).Invoke_O_O__O(root_698, arg_701) } }
			if neg__9 { var na_706 any = v__24; if jrt.Long_InstanceOf(na_706) { var n0_707 int64 = jrt.NN(jrt.Long_Cast(na_706)).LongValue__J(); if n0_707 == -9223372036854775808 { return lang.Numbers_Minus_O__Number_NoInit(na_706) } else { return jrt.Long_ValueOf_J__Long_NoInit(-n0_707).Ref() } } else { if jrt.Double_InstanceOf(na_706) { var n0_707_2 float64 = jrt.NN(jrt.Double_Cast(na_706)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(-n0_707_2).Ref() } else { return lang.Numbers_Minus_O__Number_NoInit(na_706) } } } else { return v__24 } } } }

func A_arbace_go_check_const_round64_A_New() *A_arbace_go_check_const_round64_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_round64_A{}; t.Ctor(); return t }
//line :258:1
func (t *A_arbace_go_check_const_round64_A) Ctor() {}
//line :258:1
func (t *A_arbace_go_check_const_round64_A) Invoke_O_O__O(self, x__0 any) any { var root_710 any = A_arbace_go_check_const_A_const_49.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_710, A_arbace_go_check_const_round_binary_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = x__0; var arg_715 any = A_arbace_go_check_const_A_const_51; if linked_711 == nil { return ifn_712.Invoke_O_O_O_O__O(arg_713, A_arbace_go_check_const_A_const_50, arg_715, A_arbace_go_check_const_A_const_52) } else { return linked_711.(*A_arbace_go_check_const_round_binary_A).InvokeSpec_O_O_J_O_O_J_O__O(root_710, arg_713, 53, A_arbace_go_check_const_A_const_50, arg_715, 1023, A_arbace_go_check_const_A_const_52) } }
func A_arbace_go_check_const_round32_A_New() *A_arbace_go_check_const_round32_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_round32_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_go_check_const_round32_A) Ctor() {}
//line :259:1
func (t *A_arbace_go_check_const_round32_A) Invoke_O_O__O(self, x__0 any) any { var root_717 any = A_arbace_go_check_const_A_const_49.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_717, A_arbace_go_check_const_round_binary_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = x__0; var arg_722 any = A_arbace_go_check_const_A_const_54; if linked_718 == nil { return ifn_719.Invoke_O_O_O_O__O(arg_720, A_arbace_go_check_const_A_const_53, arg_722, A_arbace_go_check_const_A_const_55) } else { return linked_718.(*A_arbace_go_check_const_round_binary_A).InvokeSpec_O_O_J_O_O_J_O__O(root_717, arg_720, 24, A_arbace_go_check_const_A_const_53, arg_722, 127, A_arbace_go_check_const_A_const_55) } }

func A_arbace_go_check_const_exact_of_double_A_New() *A_arbace_go_check_const_exact_of_double_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_exact_of_double_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_go_check_const_exact_of_double_A) Ctor() {}
//line :261:1
func (t *A_arbace_go_check_const_exact_of_double_A) InvokePrim_O_D__O(self any, d__0 float64) any {


	if lang.Numbers_IsZero_D__Z_NoInit(d__0) { return A_arbace_go_check_const_A_const_17 } else { var bits__2 int64 = jrt.Double_DoubleToRawLongBits_D__J_NoInit(d__0); var neg__3 bool = lang.Numbers_IsNeg_J__Z_NoInit(bits__2); var ex__4 int64 = lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(bits__2, 52), 2047); var frac__5 int64 = lang.Numbers_And_J_J__J_NoInit(bits__2, 4503599627370495); var vec__161000094__6 any





		if lang.Numbers_IsZero_J__Z_NoInit(ex__4) { vec__161000094__6 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(frac__5).Ref(), A_arbace_go_check_const_A_const_56) } else { vec__161000094__6 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(frac__5, lang.Numbers_ShiftLeft_J_J__J_NoInit(1, 52))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(ex__4, 1075)).Ref()) }
//line :264:1
		var m__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000094__6, lang.RT_IntCast_J__I_NoInit(0), nil); var e__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000094__6, lang.RT_IntCast_J__I_NoInit(1), nil); var v__9 any; var tmp1 bool
		var na_724 any = e__8





		if jrt.Long_InstanceOf(na_724) { var n0_725 int64 = jrt.NN(jrt.Long_Cast(na_724)).LongValue__J(); tmp1 = n0_725 < 0 } else { if jrt.Double_InstanceOf(na_724) { var n0_725_2 float64 = jrt.NN(jrt.Double_Cast(na_724)).DoubleValue__D(); tmp1 = n0_725_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_724) } }; if tmp1 { var tmp2 any; var root_726 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_728 lang.IFn; if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = m__7; if linked_727 == nil { tmp2 = ifn_728.Invoke_O__O(arg_729) } else { tmp2 = linked_727.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_726, arg_729) }; var tmp3 any = tmp2; var tmp4 any; var root_730 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any; var root_734 any = A_arbace_go_check_const_A_const_29.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, A_arbace_go_check_const_pow2_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any; var na_738 any = e__8; if jrt.Long_InstanceOf(na_738) { var n0_739 int64 = jrt.NN(jrt.Long_Cast(na_738)).LongValue__J(); if n0_739 == -9223372036854775808 { arg_737 = lang.Numbers_Minus_O__Number_NoInit(na_738) } else { arg_737 = jrt.Long_ValueOf_J__Long_NoInit(-n0_739).Ref() } } else { if jrt.Double_InstanceOf(na_738) { var n0_739_2 float64 = jrt.NN(jrt.Double_Cast(na_738)).DoubleValue__D(); arg_737 = jrt.Double_ValueOf_D__Double_NoInit(-n0_739_2).Ref() } else { arg_737 = lang.Numbers_Minus_O__Number_NoInit(na_738) } }; if linked_735 == nil { arg_733 = ifn_736.Invoke_O__O(arg_737) } else { arg_733 = linked_735.(*A_arbace_go_check_const_pow2_A).Invoke_O_O__O(root_734, arg_737) }; if linked_731 == nil { tmp4 = ifn_732.Invoke_O__O(arg_733) } else { tmp4 = linked_731.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_730, arg_733) }; v__9 = lang.Numbers_Divide_O_O__Number_NoInit(tmp3, tmp4) } else { var root_740 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_742 lang.IFn; if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any; var tmp5 any; var root_744 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_744, A_arbace_go_check_const_bi_A_fn_class); var ifn_746 lang.IFn; if linked_745 == nil { ifn_746 = lang.IFn_Cast(root_744) } else { ifn_746 = nil }; var arg_747 any = m__7; if linked_745 == nil { tmp5 = ifn_746.Invoke_O__O(arg_747) } else { tmp5 = linked_745.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_744, arg_747) }; arg_743 = jrt.NN(jrt.BigInteger_Cast(tmp5)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(e__8)).Ref(); if linked_741 == nil { v__9 = ifn_742.Invoke_O__O(arg_743) } else { v__9 = linked_741.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_740, arg_743) } }
//line :264:1
		var v__10 any; var tmp6 any; var root_748 any = A_arbace_go_check_const_A_const_24.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_750 lang.IFn







		if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = v__9; if linked_749 == nil { tmp6 = ifn_750.Invoke_O__O(arg_751) } else { tmp6 = linked_749.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_748, arg_751) }; if jrt.J2g_Truth(tmp6) { v__10 = v__9 } else { var root_752 any = A_arbace_go_check_const_A_const_47.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, A_arbace_go_check_const_norm_int_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any; var root_756 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, A_arbace_go_check_const_bi_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = v__9; if linked_757 == nil { arg_755 = ifn_758.Invoke_O__O(arg_759) } else { arg_755 = linked_757.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_756, arg_759) }; if linked_753 == nil { v__10 = ifn_754.Invoke_O__O(arg_755) } else { v__10 = linked_753.(*A_arbace_go_check_const_norm_int_A).Invoke_O_O__O(root_752, arg_755) } }
		if neg__3 { var na_760 any = v__10; if jrt.Long_InstanceOf(na_760) { var n0_761 int64 = jrt.NN(jrt.Long_Cast(na_760)).LongValue__J(); if n0_761 == -9223372036854775808 { return lang.Numbers_Minus_O__Number_NoInit(na_760) } else { return jrt.Long_ValueOf_J__Long_NoInit(-n0_761).Ref() } } else { if jrt.Double_InstanceOf(na_760) { var n0_761_2 float64 = jrt.NN(jrt.Double_Cast(na_760)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(-n0_761_2).Ref() } else { return lang.Numbers_Minus_O__Number_NoInit(na_760) } } } else { return v__10 } } }
//line :261:1
func (t *A_arbace_go_check_const_exact_of_double_A) Invoke_O_O__O(self, p_d__0 any) any { return t.InvokePrim_O_D__O(self, lang.RT_DoubleCast_O__D_NoInit(p_d__0)) }













func A_arbace_go_check_const_to_double_A_New() *A_arbace_go_check_const_to_double_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_to_double_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_go_check_const_to_double_A) Ctor() {}
//line :275:1
func (t *A_arbace_go_check_const_to_double_A) InvokePrim_O_O__D(self, x__0 any) float64 { var tmp1 any; var r__2 any; var root_762 any = A_arbace_go_check_const_A_const_57.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, A_arbace_go_check_const_round64_A_fn_class); var ifn_764 lang.IFn; if


	linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = x__0; if linked_763 == nil { r__2 = ifn_764.Invoke_O__O(arg_765) } else { r__2 = linked_763.(*A_arbace_go_check_const_round64_A).Invoke_O_O__O(root_762, arg_765) }; if
	lang.Util_Identical_O_O__Z_NoInit(r__2, nil) {
		var tmp2 int64; var root_766 any = A_arbace_go_check_const_A_const_44.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_766, A_arbace_go_check_const_fsign_A_fn_class); var ifn_768 lang.IFn; if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = x__0; if linked_767 == nil { tmp2 = lang.RT_LongCast_O__J_NoInit(ifn_768.Invoke_O__O(arg_769)) } else { tmp2 = linked_767.(*A_arbace_go_check_const_fsign_A).InvokePrim_O_O__J(root_766, arg_769) }; if lang.Numbers_IsPos_J__Z_NoInit(tmp2) { tmp1 = jrt.Double_ValueOf_D__Double_NoInit(jrt.PosInf64).Ref() } else { tmp1 = jrt.Double_ValueOf_D__Double_NoInit(jrt.NegInf64).Ref() } } else {
//line :279:1
			var tmp3 any; var root_770 any = A_arbace_go_check_const_A_const_24.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_772 lang.IFn

			if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = r__2; if linked_771 == nil { tmp3 = ifn_772.Invoke_O__O(arg_773) } else { tmp3 = linked_771.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_770, arg_773) }
//line :279:1
			if jrt.J2g_Truth(tmp3) {

				var tmp4 any; var root_794 any = A_arbace_go_check_const_A_const_60.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_796 lang.IFn; if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_check_const_A_const_61.GetRawRoot__O()); var tmp6 any = A_arbace_go_check_const_A_const_62; var arg_797 any = tmp5.Invoke_O_O__O(tmp6, jrt.MathContext_New_I(lang.RT_IntCast_J__I_NoInit(40))); if linked_795 == nil { ifn_796.Invoke_O__O(arg_797) } else { linked_795.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_794, arg_797) }; var tmp7 any = A_arbace_go_check_const_to_double_fn__161000098_A_New_O(r__2); var tmp8 *jrt.Class; var fncls__793 *jrt.Class = A_arbace_go_check_const_to_double_fn__161000098_A_fn_class; if fncls__793 == nil { var fncls__793d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_go_check_const_to_double_fn__161000098_A_fn_class = fncls__793d; tmp8 = fncls__793d } else { tmp8 = fncls__793 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O(); tmp1 = lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(tmp4, Lit_6, false) } else {
//line :279:1
					if A_arbace_go_check_const_A_const_8 != nil {


						tmp1 = jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(r__2)).Ref() } else {
//line :279:1
							tmp1 = nil } } }; return /*line :275:1*/ jrt.Number_Cast(tmp1).DoubleValue__D() }
//line :275:1
func (t *A_arbace_go_check_const_to_double_A) Invoke_O_O__O(self, x__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_O__D(self, x__0)).Ref() }





func A_arbace_go_check_const_to_double_fn__161000098_A_New_O(p0 any) *A_arbace_go_check_const_to_double_fn__161000098_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_to_double_fn__161000098_A{}; t.Ctor_O(p0); return t }
//line :281:1
func (t *A_arbace_go_check_const_to_double_fn__161000098_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :281:1
func (t *A_arbace_go_check_const_to_double_fn__161000098_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var root_774 any = A_arbace_go_check_const_A_const_58.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_bigdec_A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any; var root_778 any = A_arbace_go_check_const_A_const_25.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_numerator_A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = t.F_r; if linked_779 == nil { arg_777 = ifn_780.Invoke_O__O(arg_781) } else { arg_777 = linked_779.(*aot_arbace_core.A_arbace_core_numerator_A).Invoke_O_O__O(root_778, arg_781) }; if linked_775 == nil { tmp2 = ifn_776.Invoke_O__O(arg_777) } else { tmp2 = linked_775.(*aot_arbace_core.A_arbace_core_bigdec_A).Invoke_O_O__O(root_774, arg_777) }; var tmp3 any = tmp2; var tmp4 any; var root_782 any = A_arbace_go_check_const_A_const_58.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, aot_arbace_core.A_arbace_core_bigdec_A_fn_class); var ifn_784 lang.IFn; if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any; var root_786 any = A_arbace_go_check_const_A_const_26.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_denominator_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any; var t_ any = t.F_r; t.F_r = nil; arg_789 = t_; if linked_787 == nil { arg_785 = ifn_788.Invoke_O__O(arg_789) } else { arg_785 = linked_787.(*aot_arbace_core.A_arbace_core_denominator_A).Invoke_O_O__O(root_786, arg_789) }; if linked_783 == nil { tmp4 = ifn_784.Invoke_O__O(arg_785) } else { tmp4 = linked_783.(*aot_arbace_core.A_arbace_core_bigdec_A).Invoke_O_O__O(root_782, arg_785) }; tmp1 = lang.Numbers_Divide_O_O__Number_NoInit(tmp3, tmp4) }; return nil }(); var root_790 any = A_arbace_go_check_const_A_const_59.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; if linked_791 == nil { ifn_792.Invoke__O() } else { linked_791.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_790) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }




func A_arbace_go_check_const_latin1_A_New() *A_arbace_go_check_const_latin1_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_latin1_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_go_check_const_latin1_A) Ctor() {}
//line :286:1
func (t *A_arbace_go_check_const_latin1_A) Invoke_O_O__O(self, bs__0 any) any { return jrt.String_New_B1_Charset(jrt.J2g_CastArray[*jrt.ByteArray](bs__0, jrt.Prim_byte.ArrayClass()), jrt.StandardCharsets_ISO_8859_1) }




func A_arbace_go_check_const_utf8_value_A_New() *A_arbace_go_check_const_utf8_value_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_utf8_value_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_go_check_const_utf8_value_A) Ctor() {}
//line :291:1
func (t *A_arbace_go_check_const_utf8_value_A) Invoke_O_O__O(self, s__0 any) any {


	var root_803 any = A_arbace_go_check_const_A_const_63.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, A_arbace_go_check_const_latin1_A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = jrt.NN(jrt.String_Cast(s__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref(); if linked_804 == nil { return ifn_805.Invoke_O__O(arg_806) } else { return linked_804.(*A_arbace_go_check_const_latin1_A).Invoke_O_O__O(root_803, arg_806)
	} }
func A_arbace_go_check_const_value_bytes_A_New() *A_arbace_go_check_const_value_bytes_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_value_bytes_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_go_check_const_value_bytes_A) Ctor() {}
//line :296:1
func (t *A_arbace_go_check_const_value_bytes_A) Invoke_O_O__O(self, v__0 any) any { return jrt.NN(jrt.String_Cast(v__0)).GetBytes_Charset__B1(jrt.StandardCharsets_ISO_8859_1).Ref() }

func A_arbace_go_check_const_value_text_A_New() *A_arbace_go_check_const_value_text_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_value_text_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_go_check_const_value_text_A) Ctor() {}
//line :298:1
func (t *A_arbace_go_check_const_value_text_A) Invoke_O_O__O(self, v__0 any) any { var tmp1 any; var root_807 any = A_arbace_go_check_const_A_const_64.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, A_arbace_go_check_const_value_bytes_A_fn_class); var ifn_809 lang.IFn; if


	linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = v__0; if linked_808 == nil { tmp1 = ifn_809.Invoke_O__O(arg_810) } else { tmp1 = linked_808.(*A_arbace_go_check_const_value_bytes_A).Invoke_O_O__O(root_807, arg_810) }; return /*line :298:1*/ jrt.String_New_B1_Charset(jrt.J2g_CastArray[*jrt.ByteArray](tmp1, jrt.Prim_byte.ArrayClass()), jrt.StandardCharsets_UTF_8) }




func A_arbace_go_check_const_rune_string_A_New() *A_arbace_go_check_const_rune_string_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_rune_string_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_go_check_const_rune_string_A) Ctor() {}
//line :303:1
func (t *A_arbace_go_check_const_rune_string_A) Invoke_O_O__O(self, r__0 any) any { var r__2 int64; var tmp1 any; var and__1927000168__auto____2 bool = jrt.Long_InstanceOf(r__0); if and__1927000168__auto____2 {


	var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_check_const_A_const_65.GetRawRoot__O()); var tmp3 any = A_arbace_go_check_const_A_const_17; var and__1927000168__auto____3 any = tmp2.Invoke_O_O_O__O(tmp3, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(r__0)).Ref(), A_arbace_go_check_const_A_const_66); if jrt.J2g_Truth(and__1927000168__auto____3) { var root_817 any = A_arbace_go_check_const_A_const_28.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_const_A_const_65.GetRawRoot__O()); var tmp5 any = A_arbace_go_check_const_A_const_67; var arg_820 any = tmp4.Invoke_O_O_O__O(tmp5, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(r__0)).Ref(), A_arbace_go_check_const_A_const_68); if linked_818 == nil { tmp1 = ifn_819.Invoke_O__O(arg_820) } else { tmp1 = linked_818.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_817, arg_820) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) {
		r__2 = lang.RT_LongCast_O__J_NoInit(r__0) } else {
//line :306:1
			r__2 = 65533 }; var root_827 any =

	A_arbace_go_check_const_A_const_69.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, A_arbace_go_check_const_utf8_value_A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = jrt.String_New_C1(jrt.Character_ToChars_I__C1_NoInit(lang.RT_IntCast_J__I_NoInit(r__2))); if linked_828 == nil { return ifn_829.Invoke_O__O(arg_830) } else { return linked_828.(*A_arbace_go_check_const_utf8_value_A).Invoke_O_O__O(root_827, arg_830) } }

func A_arbace_go_check_const_rnd_A_New() *A_arbace_go_check_const_rnd_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_rnd_A{}; t.Ctor(); return t }
//line :310:1
func (t *A_arbace_go_check_const_rnd_A) Ctor() {}
//line :310:1
func (t *A_arbace_go_check_const_rnd_A) Invoke_O_O_O_O_O__O(self, m__0, e__1, p__2, sticky__3 any) any { var vec__161000106__5 any; var root_831 any = A_arbace_go_check_const_A_const_18.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, A_arbace_go_check_const_round_int_A_fn_class); var ifn_833 lang.IFn; if


	linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = m__0; var arg_835 any = sticky__3; var arg_836 any = p__2; if linked_832 == nil { vec__161000106__5 = ifn_833.Invoke_O_O_O__O(arg_834, arg_835, arg_836) } else { vec__161000106__5 = linked_832.(*A_arbace_go_check_const_round_int_A).Invoke_O_O_O_O__O(root_831, arg_834, arg_835, arg_836) }; var m2__6 any = /*line :310:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__161000106__5, lang.RT_IntCast_J__I_NoInit(0), nil); var sh__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000106__5, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(m2__6, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e__1), lang.RT_LongCast_O__J_NoInit(sh__7))).Ref()) }




func A_arbace_go_check_const_pmul_A_New() *A_arbace_go_check_const_pmul_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_pmul_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_go_check_const_pmul_A) Ctor() {}
//line :315:1
func (t *A_arbace_go_check_const_pmul_A) Invoke_O_O_O_O__O(self, p__161000110__0, p__161000111__1, p__2 any) any { var vec__161000112__4 any = p__161000110__0; var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000112__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000112__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__161000115__7 any = p__161000111__1; var m2__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000115__7, lang.RT_IntCast_J__I_NoInit(0), nil); var e2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000115__7, lang.RT_IntCast_J__I_NoInit(1), nil); var root_837 any = A_arbace_go_check_const_A_const_70.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, A_arbace_go_check_const_rnd_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any = jrt.NN(jrt.BigInteger_Cast(m1__5)).Multiply_BigInteger__BigInteger(jrt.BigInteger_Cast(m2__8)).Ref(); var arg_841 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e1__6), lang.RT_LongCast_O__J_NoInit(e2__9))).Ref(); var arg_842 any = p__2; var arg_843 any = jrt.Boolean_FALSE.Ref(); if linked_838 == nil { return ifn_839.Invoke_O_O_O_O__O(arg_840, arg_841, arg_842, arg_843) } else { return linked_838.(*A_arbace_go_check_const_rnd_A).Invoke_O_O_O_O_O__O(root_837, arg_840, arg_841, arg_842, arg_843) } }

func A_arbace_go_check_const_pquo_A_New() *A_arbace_go_check_const_pquo_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_pquo_A{}; t.Ctor(); return t }
//line :317:1
func (t *A_arbace_go_check_const_pquo_A) Ctor() {}
//line :317:1
func (t *A_arbace_go_check_const_pquo_A) Invoke_O_O_O_O__O(self, p__161000119__0, p__161000120__1, p__2 any) any { if jrt.Long_InstanceOf(p__2) { return t.InvokeSpec_O_O_O_J_O__O(self, p__161000119__0, p__161000120__1, jrt.NN(jrt.Long_Cast(p__2)).LongValue__J(), p__2) } else { var vec__161000121__4 any = p__161000119__0; var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000121__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000121__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__161000124__7 any = p__161000120__1; var m2__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000124__7, lang.RT_IntCast_J__I_NoInit(0), nil); var e2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000124__7, lang.RT_IntCast_J__I_NoInit(1), nil); var k__10 any; var tmp1 jrt.Number_I; var na_844 any; var na_846 any = p__2; var na_847 int64 = 2
															if jrt.Long_InstanceOf(na_846) { var n0_848 int64 = jrt.NN(jrt.Long_Cast(na_846)).LongValue__J(); var n1_849 int64 = na_847; var nr_850 int64 = n0_848 + n1_849; if (n0_848^nr_850)&(n1_849^nr_850) >= 0 { na_844 = jrt.Long_ValueOf_J__Long_NoInit(nr_850).Ref() } else { na_844 = lang.Numbers_Add_O_J__Number_NoInit(na_846, na_847) } } else { na_844 = lang.Numbers_Add_O_J__Number_NoInit(na_846, na_847) }; var na_845 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m2__8)).Abs__BigInteger()).BitLength__I()), int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m1__5)).Abs__BigInteger()).BitLength__I())); if jrt.Long_InstanceOf(na_844) { var n0_851 int64 = jrt.NN(jrt.Long_Cast(na_844)).LongValue__J(); var n1_852 int64 = na_845; var nr_853 int64 = n0_851 + n1_852; if (n0_851^nr_853)&(n1_852^nr_853) >= 0 { tmp1 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_853)) } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_844, na_845) } } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_844, na_845) }; k__10 = lang.Numbers_Max_J_O__O_NoInit(0, tmp1)
//line :317:1
	var dr__11 any = jrt.NN(jrt.NN(jrt.BigInteger_Cast(m1__5)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(k__10))).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(m2__8)).Ref(); var root_854 any = A_arbace_go_check_const_A_const_70.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, A_arbace_go_check_const_rnd_A_fn_class); var ifn_856 lang.IFn


	if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__11, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)); var arg_858 any; var na_861 int64 = lang.Numbers_Minus_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e1__6), lang.RT_LongCast_O__J_NoInit(e2__9)); var na_862 any = k__10; if jrt.Long_InstanceOf(na_862) { var n0_863 int64 = na_861; var n1_864 int64 = jrt.NN(jrt.Long_Cast(na_862)).LongValue__J(); var nr_865 int64 = n0_863 - n1_864; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_864 == -9223372036854775808); if tmp3 { tmp3 = (n0_863^n1_864)&(n0_863^nr_865) >= 0 }; tmp2 = tmp3; if tmp2 { arg_858 = jrt.Long_ValueOf_J__Long_NoInit(nr_865).Ref() } else { arg_858 = lang.Numbers_Minus_J_O__Number_NoInit(na_861, na_862) } } else { arg_858 = lang.Numbers_Minus_J_O__Number_NoInit(na_861, na_862) }; var arg_859 any = p__2; var arg_860 any; var root_866 any = A_arbace_go_check_const_A_const_28.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__11, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)))).Signum__I()))).Ref(); if linked_867 == nil { arg_860 = ifn_868.Invoke_O__O(arg_869) } else { arg_860 = linked_867.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_866, arg_869) }; if linked_855 == nil { return ifn_856.Invoke_O_O_O_O__O(arg_857, arg_858, arg_859, arg_860) } else { return linked_855.(*A_arbace_go_check_const_rnd_A).Invoke_O_O_O_O_O__O(root_854, arg_857, arg_858, arg_859, arg_860) } } }
//line :317:1
func (t *A_arbace_go_check_const_pquo_A) InvokeSpec_O_O_O_J_O__O(self, p__161000119__0, p__161000120__1 any, p__2_l int64, p__2_b any) any { var vec__161000121__4 any = p__161000119__0; var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000121__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000121__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__161000124__7 any = p__161000120__1; var m2__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000124__7, lang.RT_IntCast_J__I_NoInit(0), nil); var e2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000124__7, lang.RT_IntCast_J__I_NoInit(1), nil); var k__10 any; var tmp1 jrt.Number_I; var na_870 any; var na_872 int64 = 2; var n0_873 int64 = p__2_l; var n1_874 int64 = na_872; var nr_875 int64 = n0_873 + n1_874; if
																		(n0_873^nr_875)&(n1_874^nr_875) >= 0 { na_870 = jrt.Long_ValueOf_J__Long_NoInit(nr_875).Ref() } else { var tmp2 any; if p__2_b == nil { p__2_b = jrt.Long_ValueOf_J__Long_NoInit(p__2_l).Ref(); tmp2 = p__2_b } else { tmp2 = p__2_b }; na_870 = lang.Numbers_Add_O_J__Number_NoInit(tmp2, na_872) }; var na_871 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m2__8)).Abs__BigInteger()).BitLength__I()), int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m1__5)).Abs__BigInteger()).BitLength__I())); if jrt.Long_InstanceOf(na_870) { var n0_876 int64 = jrt.NN(jrt.Long_Cast(na_870)).LongValue__J(); var n1_877 int64 = na_871; var nr_878 int64 = n0_876 + n1_877; if (n0_876^nr_878)&(n1_877^nr_878) >= 0 { tmp1 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_878)) } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_870, na_871) } } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_870, na_871) }; k__10 = lang.Numbers_Max_J_O__O_NoInit(0, tmp1); var dr__11 any = /*line :317:1*/jrt.NN(jrt.NN(jrt.BigInteger_Cast(m1__5)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(k__10))).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(m2__8)).Ref(); var root_879 any = A_arbace_go_check_const_A_const_70.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_879, A_arbace_go_check_const_rnd_A_fn_class); var ifn_881 lang.IFn; if


	linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__11, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)); var arg_883 any; var na_886 int64 = lang.Numbers_Minus_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e1__6), lang.RT_LongCast_O__J_NoInit(e2__9)); var na_887 any = k__10; if jrt.Long_InstanceOf(na_887) { var n0_888 int64 = na_886; var n1_889 int64 = jrt.NN(jrt.Long_Cast(na_887)).LongValue__J(); var nr_890 int64 = n0_888 - n1_889; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_889 == -9223372036854775808); if tmp4 { tmp4 = (n0_888^n1_889)&(n0_888^nr_890) >= 0 }; tmp3 = tmp4; if tmp3 { arg_883 = jrt.Long_ValueOf_J__Long_NoInit(nr_890).Ref() } else { arg_883 = lang.Numbers_Minus_J_O__Number_NoInit(na_886, na_887) } } else { arg_883 = lang.Numbers_Minus_J_O__Number_NoInit(na_886, na_887) }; var arg_884 any; if p__2_b == nil { p__2_b = jrt.Long_ValueOf_J__Long_NoInit(p__2_l).Ref(); arg_884 = p__2_b } else { arg_884 = p__2_b }; var arg_885 any; var root_891 any = A_arbace_go_check_const_A_const_28.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_893 lang.IFn; if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__11, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)))).Signum__I()))).Ref(); if linked_892 == nil { arg_885 = ifn_893.Invoke_O__O(arg_894) } else { arg_885 = linked_892.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_891, arg_894) }; if linked_880 == nil { return ifn_881.Invoke_O_O_O_O__O(arg_882, arg_883, arg_884, arg_885) } else { return linked_880.(*A_arbace_go_check_const_rnd_A).Invoke_O_O_O_O_O__O(root_879, arg_882, arg_883, arg_884, arg_885) } }



func A_arbace_go_check_const_pow5_A_New() *A_arbace_go_check_const_pow5_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_pow5_A{}; t.Ctor(); return t }
//line :324:1
func (t *A_arbace_go_check_const_pow5_A) Ctor() {}
//line :324:1
func (t *A_arbace_go_check_const_pow5_A) Invoke_O_O_O__O(self, n__0, prec__1 any) any { { var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(n__0); if tmp2 { tmp2 = jrt.Long_InstanceOf(prec__1) }; tmp1 = tmp2; if tmp1 { return t.InvokeSpec_O_J_O_J_O__O(self, jrt.NN(jrt.Long_Cast(n__0)).LongValue__J(), n__0, jrt.NN(jrt.Long_Cast(prec__1)).LongValue__J(), prec__1) } else {


	var tmp3 bool; var na_895 any = n__0; var na_896 int64 = 27; if jrt.Long_InstanceOf(na_895) { var n0_897 int64 = jrt.NN(jrt.Long_Cast(na_895)).LongValue__J(); var n1_898 int64 = na_896; tmp3 = n0_897 <= n1_898 } else { tmp3 = lang.Numbers_Lte_O_J__Z_NoInit(na_895, na_896) }; if tmp3 { return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.BigInteger_ValueOf_J__BigInteger(5)).Pow_I__BigInteger(lang.RT_IntCast_O__I_NoInit(n__0)).Ref(), A_arbace_go_check_const_A_const_17) } else { var z__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_const_A_const_71.GetRawRoot__O(), A_arbace_go_check_const_A_const_17); var f__4 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.BigInteger_ValueOf_J__BigInteger(5).Ref(), A_arbace_go_check_const_A_const_17); var n__5 any
		var na_900 any = n__0; var na_901 int64 = 27
		if jrt.Long_InstanceOf(na_900) { var n0_902 int64 = jrt.NN(jrt.Long_Cast(na_900)).LongValue__J(); var n1_903 int64 = na_901; var nr_904 int64 = n0_902 - n1_903; var tmp4 bool; var tmp5 bool; tmp5 = !(n1_903 == -9223372036854775808); if tmp5 { tmp5 = (n0_902^n1_903)&(n0_902^nr_904) >= 0 }; tmp4 = tmp5; if tmp4 { n__5 = jrt.Long_ValueOf_J__Long_NoInit(nr_904).Ref() } else { n__5 = lang.Numbers_Minus_O_J__Number_NoInit(na_900, na_901) } } else { n__5 = lang.Numbers_Minus_O_J__Number_NoInit(na_900, na_901) }
//line :327:1
	L1: for {


		var tmp6 bool; var na_905 any = n__5; if jrt.Long_InstanceOf(na_905) { var n0_906 int64 = jrt.NN(jrt.Long_Cast(na_905)).LongValue__J(); tmp6 = n0_906 == 0 } else { if jrt.Double_InstanceOf(na_905) { var n0_906_2 float64 = jrt.NN(jrt.Double_Cast(na_905)).DoubleValue__D(); tmp6 = n0_906_2 == 0.0 } else { tmp6 = lang.Numbers_IsZero_O__Z_NoInit(na_905) } }; if tmp6 { return z__3 } else {

			var tmp7 any; var tmp8 any; var root_907 any = A_arbace_go_check_const_A_const_72.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, aot_arbace_core.A_arbace_core_odd_QMARK__A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = n__5; if linked_908 == nil { tmp8 = ifn_909.Invoke_O__O(arg_910) } else { tmp8 = linked_908.(*aot_arbace_core.A_arbace_core_odd_QMARK__A).Invoke_O_O__O(root_907, arg_910) }; if jrt.J2g_Truth(tmp8) { var root_911 any = A_arbace_go_check_const_A_const_73.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, A_arbace_go_check_const_pmul_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = z__3; var arg_915 any = f__4; var arg_916 any = prec__1; if linked_912 == nil { tmp7 = ifn_913.Invoke_O_O_O__O(arg_914, arg_915, arg_916) } else { tmp7 = linked_912.(*A_arbace_go_check_const_pmul_A).Invoke_O_O_O_O__O(root_911, arg_914, arg_915, arg_916) } } else { tmp7 = z__3 }; var tmp9 any = tmp7; var tmp10 any; var root_917 any = A_arbace_go_check_const_A_const_73.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, A_arbace_go_check_const_pmul_A_fn_class); var ifn_919 lang.IFn; if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any = f__4; var arg_921 any = f__4; var arg_922 any; var na_923 any = prec__1; var na_924 int64 = 64; if jrt.Long_InstanceOf(na_923) { var n0_925 int64 = jrt.NN(jrt.Long_Cast(na_923)).LongValue__J(); var n1_926 int64 = na_924; var nr_927 int64 = n0_925 + n1_926; if (n0_925^nr_927)&(n1_926^nr_927) >= 0 { arg_922 = jrt.Long_ValueOf_J__Long_NoInit(nr_927).Ref() } else { arg_922 = lang.Numbers_Add_O_J__Number_NoInit(na_923, na_924) } } else { arg_922 = lang.Numbers_Add_O_J__Number_NoInit(na_923, na_924) }; if linked_918 == nil { tmp10 = ifn_919.Invoke_O_O_O__O(arg_920, arg_921, arg_922) } else { tmp10 = linked_918.(*A_arbace_go_check_const_pmul_A).Invoke_O_O_O_O__O(root_917, arg_920, arg_921, arg_922) }; var tmp11 any = tmp10; var tmp12 jrt.Number_I; var na_928 any = n__5; var na_929 int64 = 2; if jrt.Long_InstanceOf(na_928) { var n0_930 int64 = jrt.NN(jrt.Long_Cast(na_928)).LongValue__J(); var n1_931 int64 = na_929; if n1_931 == 0 { tmp12 = lang.Numbers_Quotient_O_J__Number_NoInit(na_928, na_929) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_930 / n1_931)) } } else { tmp12 = lang.Numbers_Quotient_O_J__Number_NoInit(na_928, na_929) }; z__3, f__4, n__5 = tmp9, tmp11, tmp12; continue L1 } } } } }; /*line :324:1*/panic("j2g: unreachable") }
//line :324:1
func (t *A_arbace_go_check_const_pow5_A) InvokeSpec_O_J_O_J_O__O(self any, n__0_l int64, n__0_b any, prec__1_l int64, prec__1_b any) any {


	{ var tmp1 bool; var na_933 int64 = 27; var n0_934 int64 = n__0_l; var n1_935 int64 = na_933; tmp1 = n0_934 <= n1_935; if tmp1 { var tmp2 *jrt.BigInteger = jrt.BigInteger_ValueOf_J__BigInteger(5); var tmp3 any
		if n__0_b == nil { n__0_b = jrt.Long_ValueOf_J__Long_NoInit(n__0_l).Ref(); tmp3 = n__0_b } else { tmp3 = n__0_b }
//line :327:1
		return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(tmp2).Pow_I__BigInteger(lang.RT_IntCast_O__I_NoInit(tmp3)).Ref(), A_arbace_go_check_const_A_const_17) } else { var z__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_const_A_const_71.GetRawRoot__O(), A_arbace_go_check_const_A_const_17); var f__4 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.BigInteger_ValueOf_J__BigInteger(5).Ref(), A_arbace_go_check_const_A_const_17); var n__5 any; var na_937 int64 = 27; var n0_938 int64 = n__0_l; var n1_939 int64 = na_937; var nr_940 int64 = n0_938 - n1_939; var tmp4 bool; var tmp5 bool

			tmp5 = !(n1_939 == -9223372036854775808); if tmp5 { tmp5 = (n0_938^n1_939)&(n0_938^nr_940) >= 0 }; tmp4 = tmp5; if tmp4 { n__5 = jrt.Long_ValueOf_J__Long_NoInit(nr_940).Ref() } else { var tmp6 any; if n__0_b == nil { n__0_b = jrt.Long_ValueOf_J__Long_NoInit(n__0_l).Ref(); tmp6 = n__0_b } else { tmp6 = n__0_b }; n__5 = lang.Numbers_Minus_O_J__Number_NoInit(tmp6, na_937) }
//line :327:1
		L1: for {


			var tmp7 bool; var na_941 any = n__5; if jrt.Long_InstanceOf(na_941) { var n0_942 int64 = jrt.NN(jrt.Long_Cast(na_941)).LongValue__J(); tmp7 = n0_942 == 0 } else { if jrt.Double_InstanceOf(na_941) { var n0_942_2 float64 = jrt.NN(jrt.Double_Cast(na_941)).DoubleValue__D(); tmp7 = n0_942_2 == 0.0 } else { tmp7 = lang.Numbers_IsZero_O__Z_NoInit(na_941) } }; if tmp7 { return z__3 } else {

				var tmp8 any; var tmp9 any; var root_943 any = A_arbace_go_check_const_A_const_72.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_odd_QMARK__A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = n__5; if linked_944 == nil { tmp9 = ifn_945.Invoke_O__O(arg_946) } else { tmp9 = linked_944.(*aot_arbace_core.A_arbace_core_odd_QMARK__A).Invoke_O_O__O(root_943, arg_946) }; if jrt.J2g_Truth(tmp9) { var root_947 any = A_arbace_go_check_const_A_const_73.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_947, A_arbace_go_check_const_pmul_A_fn_class); var ifn_949 lang.IFn; if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any = z__3; var arg_951 any = f__4; var arg_952 any; if prec__1_b == nil { prec__1_b = jrt.Long_ValueOf_J__Long_NoInit(prec__1_l).Ref(); arg_952 = prec__1_b } else { arg_952 = prec__1_b }; if linked_948 == nil { tmp8 = ifn_949.Invoke_O_O_O__O(arg_950, arg_951, arg_952) } else { tmp8 = linked_948.(*A_arbace_go_check_const_pmul_A).Invoke_O_O_O_O__O(root_947, arg_950, arg_951, arg_952) } } else { tmp8 = z__3 }; var tmp10 any = tmp8; var tmp11 any; var root_953 any = A_arbace_go_check_const_A_const_73.GetRawRoot__O(); var linked_954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_953, A_arbace_go_check_const_pmul_A_fn_class); var ifn_955 lang.IFn; if linked_954 == nil { ifn_955 = lang.IFn_Cast(root_953) } else { ifn_955 = nil }; var arg_956 any = f__4; var arg_957 any = f__4; var arg_958 any; var na_959 int64 = 64; var n0_960 int64 = prec__1_l; var n1_961 int64 = na_959; var nr_962 int64 = n0_960 + n1_961; if (n0_960^nr_962)&(n1_961^nr_962) >= 0 { arg_958 = jrt.Long_ValueOf_J__Long_NoInit(nr_962).Ref() } else { var tmp12 any; if prec__1_b == nil { prec__1_b = jrt.Long_ValueOf_J__Long_NoInit(prec__1_l).Ref(); tmp12 = prec__1_b } else { tmp12 = prec__1_b }; arg_958 = lang.Numbers_Add_O_J__Number_NoInit(tmp12, na_959) }; if linked_954 == nil { tmp11 = ifn_955.Invoke_O_O_O__O(arg_956, arg_957, arg_958) } else { tmp11 = linked_954.(*A_arbace_go_check_const_pmul_A).Invoke_O_O_O_O__O(root_953, arg_956, arg_957, arg_958) }; var tmp13 any = tmp11; var tmp14 jrt.Number_I; var na_963 any = n__5; var na_964 int64 = 2; if jrt.Long_InstanceOf(na_963) { var n0_965 int64 = jrt.NN(jrt.Long_Cast(na_963)).LongValue__J(); var n1_966 int64 = na_964; if n1_966 == 0 { tmp14 = lang.Numbers_Quotient_O_J__Number_NoInit(na_963, na_964) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_965 / n1_966)) } } else { tmp14 = lang.Numbers_Quotient_O_J__Number_NoInit(na_963, na_964) }; z__3, f__4, n__5 = tmp10, tmp13, tmp14; continue L1 } } } }
//line :324:1
	panic("j2g: unreachable")
}








func A_arbace_go_check_const_big_float_decimal_A_New() *A_arbace_go_check_const_big_float_decimal_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_big_float_decimal_A{}; t.Ctor(); return t }
//line :334:1
func (t *A_arbace_go_check_const_big_float_decimal_A) Ctor() {}
//line :334:1
func (t *A_arbace_go_check_const_big_float_decimal_A) Invoke_O_O_O__O(self, d__0, k__1 any) any { var p__3 any; var root_968 any = A_arbace_go_check_const_A_const_74.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_968, A_arbace_go_check_const_pow5_A_fn_class); var ifn_970 lang.IFn; if



	linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 int64 = jrt.Math_Abs_J__J(lang.RT_LongCast_O__J_NoInit(k__1)); var arg_972 any; var na_973 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O(); var na_974 int64 = 64; if jrt.Long_InstanceOf(na_973) { var n0_975 int64 = jrt.NN(jrt.Long_Cast(na_973)).LongValue__J(); var n1_976 int64 = na_974; var nr_977 int64 = n0_975 + n1_976; if (n0_975^nr_977)&(n1_976^nr_977) >= 0 { arg_972 = jrt.Long_ValueOf_J__Long_NoInit(nr_977).Ref() } else { arg_972 = lang.Numbers_Add_O_J__Number_NoInit(na_973, na_974) } } else { arg_972 = lang.Numbers_Add_O_J__Number_NoInit(na_973, na_974) }; if linked_969 == nil { p__3 = ifn_970.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_971).Ref(), arg_972) } else { if jrt.Long_InstanceOf(arg_972) { p__3 = linked_969.(*A_arbace_go_check_const_pow5_A).InvokeSpec_O_J_O_J_O__O(root_968, arg_971, nil, jrt.NN(jrt.Long_Cast(arg_972)).LongValue__J(), arg_972) } else { p__3 = linked_969.(*A_arbace_go_check_const_pow5_A).Invoke_O_O_O__O(root_968, jrt.Long_ValueOf_J__Long_NoInit(arg_971).Ref(), arg_972) } }; var vec__161000129__4 any; var tmp1 bool; var na_978 any = k__1; if
	jrt.Long_InstanceOf(na_978) { var n0_979 int64 = jrt.NN(jrt.Long_Cast(na_978)).LongValue__J(); tmp1 = n0_979 < 0 } else { if jrt.Double_InstanceOf(na_978) { var n0_979_2 float64 = jrt.NN(jrt.Double_Cast(na_978)).DoubleValue__D(); tmp1 = n0_979_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_978) } }; if tmp1 { var root_980 any = A_arbace_go_check_const_A_const_75.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_980, A_arbace_go_check_const_pquo_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = lang.Tuple_Create_O_O__IPersistentVector(d__0, k__1); var arg_984 any = p__3; var arg_985 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O(); if linked_981 == nil { vec__161000129__4 = ifn_982.Invoke_O_O_O__O(arg_983, arg_984, arg_985) } else { if jrt.Long_InstanceOf(arg_985) { vec__161000129__4 = linked_981.(*A_arbace_go_check_const_pquo_A).InvokeSpec_O_O_O_J_O__O(root_980, arg_983, arg_984, jrt.NN(jrt.Long_Cast(arg_985)).LongValue__J(), arg_985) } else { vec__161000129__4 = linked_981.(*A_arbace_go_check_const_pquo_A).Invoke_O_O_O_O__O(root_980, arg_983, arg_984, arg_985) } } } else { var root_986 any = A_arbace_go_check_const_A_const_73.GetRawRoot__O(); var linked_987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_986, A_arbace_go_check_const_pmul_A_fn_class); var ifn_988 lang.IFn; if linked_987 == nil { ifn_988 = lang.IFn_Cast(root_986) } else { ifn_988 = nil }; var arg_989 any = lang.Tuple_Create_O_O__IPersistentVector(d__0, k__1); var arg_990 any = p__3; var arg_991 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O(); if linked_987 == nil { vec__161000129__4 = ifn_988.Invoke_O_O_O__O(arg_989, arg_990, arg_991) } else { vec__161000129__4 = linked_987.(*A_arbace_go_check_const_pmul_A).Invoke_O_O_O_O__O(root_986, arg_989, arg_990, arg_991) } }; var m__5 any = /*line :334:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__161000129__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000129__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_992 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_994 lang.IFn; if





	linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = m__5; var arg_996 any = e__6; if linked_993 == nil { return ifn_994.Invoke_O_O__O(arg_995, arg_996) } else { return linked_993.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O__O(root_992, arg_995, arg_996) } }

func A_arbace_go_check_const_decimal_exact_A_New() *A_arbace_go_check_const_decimal_exact_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_decimal_exact_A{}; t.Ctor(); return t }
//line :342:1
func (t *A_arbace_go_check_const_decimal_exact_A) Ctor() {}
//line :342:1
func (t *A_arbace_go_check_const_decimal_exact_A) Invoke_O_O__O(self, d__0 any) any { var unscaled__2 any = jrt.NN(jrt.BigDecimal_Cast(d__0)).UnscaledValue__BigInteger().Ref(); var scale__3 int32 = jrt.NN(jrt.BigDecimal_Cast(d__0)).Scale__I(); var mag__4 float64 = lang.Numbers_Minus_D__D_NoInit(lang.Numbers_Multiply_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.BigDecimal_Cast(d__0)).Precision__I()), int64(scale__3)), 3.3219280948873626)); var tmp1 float64 = jrt.Math_Abs_D__D(lang.RT_DoubleCast_D__D_NoInit(mag__4)); var tmp2 jrt.Number_I; var na_997 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var na_998 int64 = 64; if







	jrt.Long_InstanceOf(na_997) { var n0_999 int64 = jrt.NN(jrt.Long_Cast(na_997)).LongValue__J(); var n1_1000 int64 = na_998; var nr_1001 int64 = n0_999 + n1_1000; if (n0_999^nr_1001)&(n1_1000^nr_1001) >= 0 { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_1001)) } else { tmp2 = lang.Numbers_Add_O_J__Number_NoInit(na_997, na_998) } } else { tmp2 = lang.Numbers_Add_O_J__Number_NoInit(na_997, na_998) }; if lang.Numbers_Gt_D_O__Z_NoInit(tmp1, tmp2) {
		if lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(unscaled__2)).Signum__I())) { return A_arbace_go_check_const_A_const_17 } else {

			var root_1002 any = A_arbace_go_check_const_A_const_76.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, A_arbace_go_check_const_big_float_decimal_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = unscaled__2; var arg_1006 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(int64(scale__3))).Ref(); if linked_1003 == nil { return ifn_1004.Invoke_O_O__O(arg_1005, arg_1006) } else { return linked_1003.(*A_arbace_go_check_const_big_float_decimal_A).Invoke_O_O_O__O(root_1002, arg_1005, arg_1006) } } } else {
				var root_1007 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any; var root_1011 any = A_arbace_go_check_const_A_const_77.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_rationalize_A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = d__0; if linked_1012 == nil { arg_1010 = ifn_1013.Invoke_O__O(arg_1014) } else { arg_1010 = linked_1012.(*aot_arbace_core.A_arbace_core_rationalize_A).Invoke_O_O__O(root_1011, arg_1014) }; if linked_1008 == nil { return ifn_1009.Invoke_O__O(arg_1010) } else { return linked_1008.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_1007, arg_1010) } } }

func A_arbace_go_check_const_double_literal_A_New() *A_arbace_go_check_const_double_literal_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_double_literal_A{}; t.Ctor(); return t }
//line :356:1
func (t *A_arbace_go_check_const_double_literal_A) Ctor() {}
//line :356:1
func (t *A_arbace_go_check_const_double_literal_A) InvokePrim_O_D__O(self any, d__0 float64) any {


	var root_1015 any = A_arbace_go_check_const_A_const_78.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, A_arbace_go_check_const_decimal_exact_A_fn_class); var ifn_1017 lang.IFn; if linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any = jrt.BigDecimal_New_String(jrt.Double_ToString_D__String_NoInit(d__0)); if linked_1016 == nil { return ifn_1017.Invoke_O__O(arg_1018) } else { return linked_1016.(*A_arbace_go_check_const_decimal_exact_A).Invoke_O_O__O(root_1015, arg_1018) } }
//line :356:1
func (t *A_arbace_go_check_const_double_literal_A) Invoke_O_O__O(self, p_d__0 any) any { return t.InvokePrim_O_D__O(self, lang.RT_DoubleCast_O__D_NoInit(p_d__0)) }




func A_arbace_go_check_const_binary_float_A_New() *A_arbace_go_check_const_binary_float_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_binary_float_A{}; t.Ctor(); return t }
//line :361:1
func (t *A_arbace_go_check_const_binary_float_A) Ctor() {}
//line :361:1
func (t *A_arbace_go_check_const_binary_float_A) Invoke_O_O_O__O(self, m__0, e__1 any) any {


	var root_1019 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_1021 lang.IFn; if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any; var root_1024 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, A_arbace_go_check_const_bi_A_fn_class); var ifn_1026 lang.IFn; if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = m__0; if linked_1025 == nil { arg_1022 = ifn_1026.Invoke_O__O(arg_1027) } else { arg_1022 = linked_1025.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_1024, arg_1027) }; var arg_1023 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(e__1)).Ref(); if linked_1020 == nil { return ifn_1021.Invoke_O_O__O(arg_1022, arg_1023) } else { return linked_1020.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O__O(root_1019, arg_1022, arg_1023)
	}
}

func A_arbace_go_check_const_complex_QMARK__A_New() *A_arbace_go_check_const_complex_QMARK__A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_complex_QMARK__A{}; t.Ctor(); return t }
//line :368:1
func (t *A_arbace_go_check_const_complex_QMARK__A) Ctor() {}
//line :368:1
func (t *A_arbace_go_check_const_complex_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any; var root_1028 any = A_arbace_go_check_const_A_const_15.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1030 lang.IFn; if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = x__0; if linked_1029 == nil { and__1927000168__auto____2 = ifn_1030.Invoke_O__O(arg_1031) } else { and__1927000168__auto____2 = linked_1029.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1028, arg_1031) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_const_A_const_79; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_const_cplx_A_New() *A_arbace_go_check_const_cplx_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_cplx_A{}; t.Ctor(); return t }
//line :369:1
func (t *A_arbace_go_check_const_cplx_A) Ctor() {}
//line :369:1
func (t *A_arbace_go_check_const_cplx_A) Invoke_O_O_O__O(self, re__0, im__1 any) any { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_const_A_const_79, re__0, im__1) }
func A_arbace_go_check_const_re_part_A_New() *A_arbace_go_check_const_re_part_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_re_part_A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_go_check_const_re_part_A) Ctor() {}
//line :370:1
func (t *A_arbace_go_check_const_re_part_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_1032 any = A_arbace_go_check_const_A_const_80.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, A_arbace_go_check_const_complex_QMARK__A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = x__0; if linked_1033 == nil { tmp1 = ifn_1034.Invoke_O__O(arg_1035) } else { tmp1 = linked_1033.(*A_arbace_go_check_const_complex_QMARK__A).Invoke_O_O__O(root_1032, arg_1035) }; if jrt.J2g_Truth(tmp1) { return lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(1)) } else { return x__0 } }
func A_arbace_go_check_const_im_part_A_New() *A_arbace_go_check_const_im_part_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_im_part_A{}; t.Ctor(); return t }
//line :371:1
func (t *A_arbace_go_check_const_im_part_A) Ctor() {}
//line :371:1
func (t *A_arbace_go_check_const_im_part_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_1036 any = A_arbace_go_check_const_A_const_80.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1036, A_arbace_go_check_const_complex_QMARK__A_fn_class); var ifn_1038 lang.IFn; if linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = x__0; if linked_1037 == nil { tmp1 = ifn_1038.Invoke_O__O(arg_1039) } else { tmp1 = linked_1037.(*A_arbace_go_check_const_complex_QMARK__A).Invoke_O_O__O(root_1036, arg_1039) }; if jrt.J2g_Truth(tmp1) { return lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(2)) } else { return A_arbace_go_check_const_A_const_17 } }
func A_arbace_go_check_const_complex_val_A_New() *A_arbace_go_check_const_complex_val_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_complex_val_A{}; t.Ctor(); return t }
//line :372:1
func (t *A_arbace_go_check_const_complex_val_A) Ctor() {}
//line :372:1
func (t *A_arbace_go_check_const_complex_val_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_1040 any = A_arbace_go_check_const_A_const_80.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, A_arbace_go_check_const_complex_QMARK__A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = x__0; if linked_1041 == nil { tmp1 = ifn_1042.Invoke_O__O(arg_1043) } else { tmp1 = linked_1041.(*A_arbace_go_check_const_complex_QMARK__A).Invoke_O_O__O(root_1040, arg_1043) }; if jrt.J2g_Truth(tmp1) { return x__0 } else { var tmp2 any = A_arbace_go_check_const_A_const_79; var tmp3 any; var root_1044 any = A_arbace_go_check_const_A_const_81.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, A_arbace_go_check_const_float_val_A_fn_class); var ifn_1046 lang.IFn; if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = x__0; if linked_1045 == nil { tmp3 = ifn_1046.Invoke_O__O(arg_1047) } else { tmp3 = linked_1045.(*A_arbace_go_check_const_float_val_A).Invoke_O_O__O(root_1044, arg_1047) }; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp3, A_arbace_go_check_const_A_const_17) } }









































type A_arbace_go_check_const_A struct{ jrt.Object }

var A_arbace_go_check_const_A_const_pool *jrt.RefArray

var A_arbace_go_check_const_A_const_0 *lang.Var

var A_arbace_go_check_const_A_const_1 any

var A_arbace_go_check_const_A_const_2 *lang.Var

var A_arbace_go_check_const_A_const_3 *lang.Var

var A_arbace_go_check_const_A_const_4 *lang.Var

var A_arbace_go_check_const_A_const_5 *lang.Var

var A_arbace_go_check_const_A_const_6 any

var A_arbace_go_check_const_A_const_7 *lang.Var

var A_arbace_go_check_const_A_const_8 *lang.Keyword

var A_arbace_go_check_const_A_const_9 *lang.Var

var A_arbace_go_check_const_A_const_10 *lang.Var

var A_arbace_go_check_const_A_const_11 *lang.Var

var A_arbace_go_check_const_A_const_12 *lang.Keyword

var A_arbace_go_check_const_A_const_13 *lang.Var

var A_arbace_go_check_const_A_const_14 *lang.Var

var A_arbace_go_check_const_A_const_15 *lang.Var

var A_arbace_go_check_const_A_const_16 *lang.Keyword

var A_arbace_go_check_const_A_const_17 any

var A_arbace_go_check_const_A_const_18 *lang.Var

var A_arbace_go_check_const_A_const_19 *lang.Var

var A_arbace_go_check_const_A_const_20 *lang.Var

var A_arbace_go_check_const_A_const_21 *lang.Var

var A_arbace_go_check_const_A_const_22 *lang.Keyword

var A_arbace_go_check_const_A_const_23 *lang.Var

var A_arbace_go_check_const_A_const_24 *lang.Var

var A_arbace_go_check_const_A_const_25 *lang.Var

var A_arbace_go_check_const_A_const_26 *lang.Var

var A_arbace_go_check_const_A_const_27 *lang.Var

var A_arbace_go_check_const_A_const_28 *lang.Var

var A_arbace_go_check_const_A_const_29 *lang.Var

var A_arbace_go_check_const_A_const_30 *lang.Var

var A_arbace_go_check_const_A_const_31 *lang.Var

var A_arbace_go_check_const_A_const_32 *lang.Var

var A_arbace_go_check_const_A_const_33 *lang.Var

var A_arbace_go_check_const_A_const_34 *lang.Var

var A_arbace_go_check_const_A_const_35 *lang.Var

var A_arbace_go_check_const_A_const_36 *lang.Var

var A_arbace_go_check_const_A_const_37 *lang.Var

var A_arbace_go_check_const_A_const_38 *lang.Var

var A_arbace_go_check_const_A_const_39 *lang.Var

var A_arbace_go_check_const_A_const_40 *lang.Var

var A_arbace_go_check_const_A_const_41 *lang.Var

var A_arbace_go_check_const_A_const_42 *lang.Var

var A_arbace_go_check_const_A_const_43 *lang.Var

var A_arbace_go_check_const_A_const_44 *lang.Var

var A_arbace_go_check_const_A_const_45 *lang.Var

var A_arbace_go_check_const_A_const_46 *lang.Var

var A_arbace_go_check_const_A_const_47 *lang.Var

var A_arbace_go_check_const_A_const_48 *lang.Var

var A_arbace_go_check_const_A_const_49 *lang.Var

var A_arbace_go_check_const_A_const_50 any

var A_arbace_go_check_const_A_const_51 any

var A_arbace_go_check_const_A_const_52 any

var A_arbace_go_check_const_A_const_53 any

var A_arbace_go_check_const_A_const_54 any

var A_arbace_go_check_const_A_const_55 any

var A_arbace_go_check_const_A_const_56 any

var A_arbace_go_check_const_A_const_57 *lang.Var

var A_arbace_go_check_const_A_const_58 *lang.Var

var A_arbace_go_check_const_A_const_59 *lang.Var

var A_arbace_go_check_const_A_const_60 *lang.Var

var A_arbace_go_check_const_A_const_61 *lang.Var

var A_arbace_go_check_const_A_const_62 *lang.Var

var A_arbace_go_check_const_A_const_63 *lang.Var

var A_arbace_go_check_const_A_const_64 *lang.Var

var A_arbace_go_check_const_A_const_65 *lang.Var

var A_arbace_go_check_const_A_const_66 any

var A_arbace_go_check_const_A_const_67 any

var A_arbace_go_check_const_A_const_68 any

var A_arbace_go_check_const_A_const_69 *lang.Var

var A_arbace_go_check_const_A_const_70 *lang.Var

var A_arbace_go_check_const_A_const_71 *lang.Var

var A_arbace_go_check_const_A_const_72 *lang.Var

var A_arbace_go_check_const_A_const_73 *lang.Var

var A_arbace_go_check_const_A_const_74 *lang.Var

var A_arbace_go_check_const_A_const_75 *lang.Var

var A_arbace_go_check_const_A_const_76 *lang.Var

var A_arbace_go_check_const_A_const_77 *lang.Var

var A_arbace_go_check_const_A_const_78 *lang.Var

var A_arbace_go_check_const_A_const_79 *lang.Keyword

var A_arbace_go_check_const_A_const_80 *lang.Var

var A_arbace_go_check_const_A_const_81 *lang.Var

var A_arbace_go_check_const_A_init jrt.ClassInit

func A_arbace_go_check_const_A_Init() { if !A_arbace_go_check_const_A_init.Done() { A_arbace_go_check_const_A_init.Run(A_arbace_go_check_const_A_clinit) } }

func A_arbace_go_check_const_A_clinit() { A_arbace_go_check_const_A_clinit_p0(); A_arbace_go_check_const_A_clinit_p1(); A_arbace_go_check_const_A_clinit_p2(); A_arbace_go_check_const_A_clinit_p3(); A_arbace_go_check_const_A_clinit_p4(); A_arbace_go_check_const_A_clinit_p5(); A_arbace_go_check_const_A_clinit_p6() }

func A_arbace_go_check_const_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_const_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 89); A_arbace_go_check_const_A_const_0 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[7]); A_arbace_go_check_const_A_const_1 = A_arbace_go_check_const_A_const_pool.A[8]; A_arbace_go_check_const_A_const_2 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[9]); A_arbace_go_check_const_A_const_3 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[10]); A_arbace_go_check_const_A_const_4 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[11]); A_arbace_go_check_const_A_const_5 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[12]); A_arbace_go_check_const_A_const_6 = A_arbace_go_check_const_A_const_pool.A[13]; A_arbace_go_check_const_A_const_7 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[14]); A_arbace_go_check_const_A_const_8 = lang.Keyword_Cast(A_arbace_go_check_const_A_const_pool.A[15]); A_arbace_go_check_const_A_const_9 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[16]); A_arbace_go_check_const_A_const_10 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[17]) }

func A_arbace_go_check_const_A_clinit_p1() { A_arbace_go_check_const_A_const_11 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[18]); A_arbace_go_check_const_A_const_12 = lang.Keyword_Cast(A_arbace_go_check_const_A_const_pool.A[19]); A_arbace_go_check_const_A_const_13 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[20]); A_arbace_go_check_const_A_const_14 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[21]); A_arbace_go_check_const_A_const_15 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[22]); A_arbace_go_check_const_A_const_16 = lang.Keyword_Cast(A_arbace_go_check_const_A_const_pool.A[23]); A_arbace_go_check_const_A_const_17 = A_arbace_go_check_const_A_const_pool.A[24]; A_arbace_go_check_const_A_const_18 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[25]); A_arbace_go_check_const_A_const_19 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[26]); A_arbace_go_check_const_A_const_20 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[27]); A_arbace_go_check_const_A_const_21 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[28]); A_arbace_go_check_const_A_const_22 = lang.Keyword_Cast(A_arbace_go_check_const_A_const_pool.A[29]) }

func A_arbace_go_check_const_A_clinit_p2() { A_arbace_go_check_const_A_const_23 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[30]); A_arbace_go_check_const_A_const_24 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[31]); A_arbace_go_check_const_A_const_25 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[32]); A_arbace_go_check_const_A_const_26 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[33]); A_arbace_go_check_const_A_const_27 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[34]); A_arbace_go_check_const_A_const_28 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[35]); A_arbace_go_check_const_A_const_29 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[36]); A_arbace_go_check_const_A_const_30 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[37]); A_arbace_go_check_const_A_const_31 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[38]); A_arbace_go_check_const_A_const_32 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[39]); A_arbace_go_check_const_A_const_33 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[40]); A_arbace_go_check_const_A_const_34 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[41]) }

func A_arbace_go_check_const_A_clinit_p3() { A_arbace_go_check_const_A_const_35 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[42]); A_arbace_go_check_const_A_const_36 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[43]); A_arbace_go_check_const_A_const_37 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[44]); A_arbace_go_check_const_A_const_38 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[45]); A_arbace_go_check_const_A_const_39 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[46]); A_arbace_go_check_const_A_const_40 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[47]); A_arbace_go_check_const_A_const_41 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[48]); A_arbace_go_check_const_A_const_42 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[49]); A_arbace_go_check_const_A_const_43 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[50]); A_arbace_go_check_const_A_const_44 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[51]); A_arbace_go_check_const_A_const_45 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[52]); A_arbace_go_check_const_A_const_46 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[53]) }

func A_arbace_go_check_const_A_clinit_p4() { A_arbace_go_check_const_A_const_47 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[54]); A_arbace_go_check_const_A_const_48 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[55]); A_arbace_go_check_const_A_const_49 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[56]); A_arbace_go_check_const_A_const_50 = A_arbace_go_check_const_A_const_pool.A[57]; A_arbace_go_check_const_A_const_51 = A_arbace_go_check_const_A_const_pool.A[58]; A_arbace_go_check_const_A_const_52 = A_arbace_go_check_const_A_const_pool.A[59]; A_arbace_go_check_const_A_const_53 = A_arbace_go_check_const_A_const_pool.A[60]; A_arbace_go_check_const_A_const_54 = A_arbace_go_check_const_A_const_pool.A[61]; A_arbace_go_check_const_A_const_55 = A_arbace_go_check_const_A_const_pool.A[62]; A_arbace_go_check_const_A_const_56 = A_arbace_go_check_const_A_const_pool.A[63]; A_arbace_go_check_const_A_const_57 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[64]); A_arbace_go_check_const_A_const_58 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[65]); A_arbace_go_check_const_A_const_59 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[66]) }

func A_arbace_go_check_const_A_clinit_p5() { A_arbace_go_check_const_A_const_60 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[67]); A_arbace_go_check_const_A_const_61 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[68]); A_arbace_go_check_const_A_const_62 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[69]); A_arbace_go_check_const_A_const_63 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[70]); A_arbace_go_check_const_A_const_64 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[71]); A_arbace_go_check_const_A_const_65 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[72]); A_arbace_go_check_const_A_const_66 = A_arbace_go_check_const_A_const_pool.A[73]; A_arbace_go_check_const_A_const_67 = A_arbace_go_check_const_A_const_pool.A[74]; A_arbace_go_check_const_A_const_68 = A_arbace_go_check_const_A_const_pool.A[75]; A_arbace_go_check_const_A_const_69 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[76]); A_arbace_go_check_const_A_const_70 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[77]); A_arbace_go_check_const_A_const_71 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[78]) }

func A_arbace_go_check_const_A_clinit_p6() { A_arbace_go_check_const_A_const_72 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[79]); A_arbace_go_check_const_A_const_73 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[80]); A_arbace_go_check_const_A_const_74 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[81]); A_arbace_go_check_const_A_const_75 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[82]); A_arbace_go_check_const_A_const_76 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[83]); A_arbace_go_check_const_A_const_77 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[84]); A_arbace_go_check_const_A_const_78 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[85]); A_arbace_go_check_const_A_const_79 = lang.Keyword_Cast(A_arbace_go_check_const_A_const_pool.A[86]); A_arbace_go_check_const_A_const_80 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[87]); A_arbace_go_check_const_A_const_81 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[88]) }

func A_arbace_go_check_const_A_New() *A_arbace_go_check_const_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_const_A) Ctor() {}

func (t *A_arbace_go_check_const_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_const_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_const_A_class }

func (t *A_arbace_go_check_const_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_const_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_const_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_const_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_const_A); return ok }

func A_arbace_go_check_const_A_Cast(x any) *A_arbace_go_check_const_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_const_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_const_A_class)) }; return v }



type A_arbace_go_check_const_bf_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_const_bf__GT_rat_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf__GT_rat_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_add_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_add_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_cmp_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_cmp_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_exp_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_exp_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_mul_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_mul_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_neg_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_neg_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_norm_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_norm_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_quo_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_quo_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_sign_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_sign_A_fn_class *jrt.Class



type A_arbace_go_check_const_bi_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bi_A_fn_class *jrt.Class



type A_arbace_go_check_const_big_float_decimal_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_big_float_decimal_A_fn_class *jrt.Class



type A_arbace_go_check_const_binary_float_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_binary_float_A_fn_class *jrt.Class



type A_arbace_go_check_const_bit_len_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bit_len_A_fn_class *jrt.Class



type A_arbace_go_check_const_complex_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_const_complex_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_const_complex_val_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_complex_val_A_fn_class *jrt.Class



type A_arbace_go_check_const_cplx_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_cplx_A_fn_class *jrt.Class



type A_arbace_go_check_const_decimal_exact_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_decimal_exact_A_fn_class *jrt.Class



type A_arbace_go_check_const_double_literal_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_double_literal_A_fn_class *jrt.Class



type A_arbace_go_check_const_eval161000004_A struct{ jrt.Object }

func A_arbace_go_check_const_eval161000004_A_New() *A_arbace_go_check_const_eval161000004_A { t := &A_arbace_go_check_const_eval161000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_const_eval161000004_A) Ctor() {}

func (t *A_arbace_go_check_const_eval161000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_const_eval161000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_const_eval161000004_A_class }

func (t *A_arbace_go_check_const_eval161000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_const_eval161000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_const_eval161000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_const_eval161000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_const_eval161000004_A); return ok }

func A_arbace_go_check_const_eval161000004_A_Cast(x any) *A_arbace_go_check_const_eval161000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_const_eval161000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_const_eval161000004_A_class)) }; return v }



type A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A_fn_class *jrt.Class



type A_arbace_go_check_const_eval161000008_A struct{ jrt.Object }

func A_arbace_go_check_const_eval161000008_A_New() *A_arbace_go_check_const_eval161000008_A { t := &A_arbace_go_check_const_eval161000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_const_eval161000008_A) Ctor() {}

func (t *A_arbace_go_check_const_eval161000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_const_eval161000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_const_eval161000008_A_class }

func (t *A_arbace_go_check_const_eval161000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_const_eval161000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_const_eval161000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_const_eval161000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_const_eval161000008_A); return ok }

func A_arbace_go_check_const_eval161000008_A_Cast(x any) *A_arbace_go_check_const_eval161000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_const_eval161000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_const_eval161000008_A_class)) }; return v }



type A_arbace_go_check_const_eval161000008_fn__161000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_eval161000008_fn__161000009_A_fn_class *jrt.Class



type A_arbace_go_check_const_exact_of_double_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_exact_of_double_A_fn_class *jrt.Class



type A_arbace_go_check_const_fadd_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fadd_A_fn_class *jrt.Class



type A_arbace_go_check_const_fcmp_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fcmp_A_fn_class *jrt.Class



type A_arbace_go_check_const_float_val_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_float_val_A_fn_class *jrt.Class



type A_arbace_go_check_const_fmul_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fmul_A_fn_class *jrt.Class



type A_arbace_go_check_const_fneg_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fneg_A_fn_class *jrt.Class



type A_arbace_go_check_const_fquo_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fquo_A_fn_class *jrt.Class



type A_arbace_go_check_const_fsign_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fsign_A_fn_class *jrt.Class



type A_arbace_go_check_const_fsub_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fsub_A_fn_class *jrt.Class



type A_arbace_go_check_const_fzero_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fzero_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_const_im_part_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_im_part_A_fn_class *jrt.Class



type A_arbace_go_check_const_int_val_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_int_val_A_fn_class *jrt.Class



type A_arbace_go_check_const_int_val_try_round__161000082_A struct{ j2g_header uint64; F_n int32; F_m, F_p any; F_ee int64 }

var A_arbace_go_check_const_int_val_try_round__161000082_A_fn_class *jrt.Class



type A_arbace_go_check_const_latin1_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_latin1_A_fn_class *jrt.Class



type A_arbace_go_check_const_make_rat_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_make_rat_A_fn_class *jrt.Class



type A_arbace_go_check_const_norm_int_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_norm_int_A_fn_class *jrt.Class



type A_arbace_go_check_const_pmul_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_pmul_A_fn_class *jrt.Class



type A_arbace_go_check_const_pow2_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_pow2_A_fn_class *jrt.Class



type A_arbace_go_check_const_pow5_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_pow5_A_fn_class *jrt.Class



type A_arbace_go_check_const_pquo_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_pquo_A_fn_class *jrt.Class



type A_arbace_go_check_const_rat__GT_bf_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_rat__GT_bf_A_fn_class *jrt.Class



type A_arbace_go_check_const_rat_num_den_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_rat_num_den_A_fn_class *jrt.Class



type A_arbace_go_check_const_re_part_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_re_part_A_fn_class *jrt.Class



type A_arbace_go_check_const_rnd_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_rnd_A_fn_class *jrt.Class



type A_arbace_go_check_const_round32_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_round32_A_fn_class *jrt.Class



type A_arbace_go_check_const_round64_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_round64_A_fn_class *jrt.Class



type A_arbace_go_check_const_round_binary_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_round_binary_A_fn_class *jrt.Class



type A_arbace_go_check_const_round_int_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_round_int_A_fn_class *jrt.Class



type A_arbace_go_check_const_rune_string_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_rune_string_A_fn_class *jrt.Class



type A_arbace_go_check_const_small_int_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_const_small_int_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_const_to_bf_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_to_bf_A_fn_class *jrt.Class



type A_arbace_go_check_const_to_double_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_to_double_A_fn_class *jrt.Class



type A_arbace_go_check_const_to_double_fn__161000098_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_const_to_double_fn__161000098_A_fn_class *jrt.Class



type A_arbace_go_check_const_utf8_value_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_utf8_value_A_fn_class *jrt.Class



type A_arbace_go_check_const_value_bytes_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_value_bytes_A_fn_class *jrt.Class



type A_arbace_go_check_const_value_text_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_value_text_A_fn_class *jrt.Class
