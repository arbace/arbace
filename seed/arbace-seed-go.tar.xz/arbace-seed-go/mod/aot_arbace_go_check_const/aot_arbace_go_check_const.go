//line aot_arbace_go_check_const.ae:1
package aot_arbace_go_check_const

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A_New() *A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_go_check_const_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_const_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_const_eval161000008_fn__161000009_A_New() *A_arbace_go_check_const_eval161000008_fn__161000009_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_eval161000008_fn__161000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_const_eval161000008_fn__161000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_const_eval161000008_fn__161000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_const_A_const_2.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_go_check_const_A_const_3.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_go_check_const_A_const_4; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_const_A_const_5.GetRawRoot__O(), A_arbace_go_check_const_A_const_6) }


















func A_arbace_go_check_const_bi_A_New() *A_arbace_go_check_const_bi_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bi_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_go_check_const_bi_A) Ctor() {}
//line :20:1
func (t *A_arbace_go_check_const_bi_A) Invoke_O_O__O(self, x__0 any) any {


	if jrt.BigInteger_InstanceOf(x__0) { return x__0 } else { var tmp1 bool; var or__1927000174__auto____2 bool = jrt.Long_InstanceOf(x__0)

		if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = jrt.Integer_InstanceOf(x__0); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 bool = jrt.Short_InstanceOf(x__0); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = jrt.Byte_InstanceOf(x__0) } } }
//line :23:1
		if tmp1 {

			return jrt.BigInteger_ValueOf_J__BigInteger(lang.RT_LongCast_O__J_NoInit(x__0)).Ref() } else {
//line :23:1
				if lang.BigInt_InstanceOf(x__0) {


					var root_15 any = A_arbace_go_check_const_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = x__0; if linked_16 == nil { return ifn_17.Invoke_O__O(arg_18) } else { return linked_16.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_15, arg_18) } } else {
//line :23:1
						if A_arbace_go_check_const_A_const_8 != nil { var tmp2 any; var root_19 any = A_arbace_go_check_const_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_21 lang.IFn



							if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil, Lit_2, nil); var tmp4 any = lang.IFn_Cast(A_arbace_go_check_const_A_const_10.GetRawRoot__O()).Invoke_O__O(x__0); var tmp5 any; var root_28 any = A_arbace_go_check_const_A_const_11.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = x__0; if linked_29 == nil { tmp5 = ifn_30.Invoke_O__O(arg_31) } else { tmp5 = linked_29.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_28, arg_31) }; arg_22 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp5)).Ref(); var arg_23 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_const_A_const_12, x__0)); if linked_20 == nil { tmp2 = ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { tmp2 = linked_20.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) }
//line :23:1
							panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) } else { return nil
							}
					}
			}
	}
}
func A_arbace_go_check_const_norm_int_A_New() *A_arbace_go_check_const_norm_int_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_norm_int_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_go_check_const_norm_int_A) Ctor() {}
//line :29:1
func (t *A_arbace_go_check_const_norm_int_A) Invoke_O_O__O(self, b__0 any) any {


	if lang.Numbers_Lt_J_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(b__0)).BitLength__I()), 64) { return jrt.Long_ValueOf_J__Long_NoInit(jrt.NN(jrt.BigInteger_Cast(b__0)).LongValue__J()).Ref() } else { var root_32 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = b__0; if linked_33 == nil { return ifn_34.Invoke_O__O(arg_35) } else { return linked_33.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_32, arg_35)
	} } }
func A_arbace_go_check_const_bit_len_A_New() *A_arbace_go_check_const_bit_len_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bit_len_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_go_check_const_bit_len_A) Ctor() {}
//line :34:1
func (t *A_arbace_go_check_const_bit_len_A) InvokePrim_O_O__J(self, x__0 any) int64 {


	var tmp1 any; var root_36 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, A_arbace_go_check_const_bi_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = x__0; if linked_37 == nil { tmp1 = ifn_38.Invoke_O__O(arg_39) } else { tmp1 = linked_37.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_36, arg_39) }; return lang.RT_LongCast_I__J_NoInit(jrt.NN(jrt.NN(jrt.BigInteger_Cast(tmp1)).Abs__BigInteger()).BitLength__I()) }
//line :34:1
func (t *A_arbace_go_check_const_bit_len_A) Invoke_O_O__O(self, x__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, x__0)).Ref() }






func A_arbace_go_check_const_pow2_A_New() *A_arbace_go_check_const_pow2_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_pow2_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_go_check_const_pow2_A) Ctor() {}
//line :41:1
func (t *A_arbace_go_check_const_pow2_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *jrt.BigInteger; jrt.BigInteger_Init(); tmp1 = jrt.BigInteger_ONE; var tmp2 *jrt.BigInteger = tmp1; return jrt.NN(tmp2).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(n__0)).Ref() }






func A_arbace_go_check_const_bf_QMARK__A_New() *A_arbace_go_check_const_bf_QMARK__A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_QMARK__A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_go_check_const_bf_QMARK__A) Ctor() {}
//line :48:1
func (t *A_arbace_go_check_const_bf_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any; var root_40 any = A_arbace_go_check_const_A_const_15.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = x__0; if linked_41 == nil { and__1927000168__auto____2 = ifn_42.Invoke_O__O(arg_43) } else { and__1927000168__auto____2 = linked_41.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_40, arg_43) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_const_A_const_16; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_go_check_const_round_int_A_New() *A_arbace_go_check_const_round_int_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_round_int_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_go_check_const_round_int_A) Ctor() {}
//line :50:1
func (t *A_arbace_go_check_const_round_int_A) Invoke_O_O_O_O__O(self, m__0, sticky__1, p__2 any) any { var n__4 int32 = jrt.NN(jrt.NN(jrt.BigInteger_Cast(m__0)).Abs__BigInteger()).BitLength__I(); var tmp1 bool; var na_44 int64 = int64(n__4); var na_45 any = p__2; if




	jrt.Long_InstanceOf(na_45) { var n0_46 int64 = na_44; var n1_47 int64 = jrt.NN(jrt.Long_Cast(na_45)).LongValue__J(); tmp1 = n0_46 <= n1_47 } else { tmp1 = lang.Numbers_Lte_J_O__Z_NoInit(na_44, na_45) }; if tmp1 { return lang.Tuple_Create_O_O__IPersistentVector(m__0, A_arbace_go_check_const_A_const_17) } else { var sh__5 any; var na_49 int64 = int64(n__4)
		var na_50 any = p__2
		if jrt.Long_InstanceOf(na_50) { var n0_51 int64 = na_49; var n1_52 int64 = jrt.NN(jrt.Long_Cast(na_50)).LongValue__J(); var nr_53 int64 = n0_51 - n1_52; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_52 == -9223372036854775808); if tmp3 { tmp3 = (n0_51^n1_52)&(n0_51^nr_53) >= 0 }; tmp2 = tmp3; if tmp2 { sh__5 = jrt.Long_ValueOf_J__Long_NoInit(nr_53).Ref() } else { sh__5 = lang.Numbers_Minus_J_O__Number_NoInit(na_49, na_50) } } else { sh__5 = lang.Numbers_Minus_J_O__Number_NoInit(na_49, na_50) }
//line :55:1
		var neg__6 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(m__0)).Signum__I())); var a__7 any = jrt.NN(jrt.BigInteger_Cast(m__0)).Abs__BigInteger().Ref(); var q__8 any = jrt.NN(jrt.BigInteger_Cast(a__7)).ShiftRight_I__BigInteger(lang.RT_IntCast_O__I_NoInit(sh__5)).Ref(); var half_bit__9 bool; var tmp4 *jrt.BigInteger = jrt.BigInteger_Cast(a__7); var tmp5 jrt.Number_I
		var na_54 any = sh__5




		if jrt.Long_InstanceOf(na_54) { var n0_55 int64 = jrt.NN(jrt.Long_Cast(na_54)).LongValue__J(); if n0_55 == -9223372036854775808 { tmp5 = lang.Numbers_Dec_O__Number_NoInit(na_54) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_55 - 1)) } } else { if jrt.Double_InstanceOf(na_54) { var n0_55_2 float64 = jrt.NN(jrt.Double_Cast(na_54)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_55_2 - 1.0)) } else { tmp5 = lang.Numbers_Dec_O__Number_NoInit(na_54) } }; half_bit__9 = jrt.NN(tmp4).TestBit_I__Z(lang.RT_IntCast_O__I_NoInit(tmp5))
//line :55:1
		var below__10 any
		var or__1927000174__auto____10 any = sticky__1





		if jrt.J2g_Truth(or__1927000174__auto____10) { below__10 = or__1927000174__auto____10 } else { var and__1927000168__auto____11 bool; var na_56 any = sh__5; var na_57 int64 = 1; if jrt.Long_InstanceOf(na_56) { var n0_58 int64 = jrt.NN(jrt.Long_Cast(na_56)).LongValue__J(); var n1_59 int64 = na_57; and__1927000168__auto____11 = n0_58 > n1_59 } else { and__1927000168__auto____11 = lang.Numbers_Gt_O_J__Z_NoInit(na_56, na_57) }; if and__1927000168__auto____11 { var tmp6 bool; var na_61 int64 = int64(jrt.NN(jrt.BigInteger_Cast(a__7)).GetLowestSetBit__I()); var na_62 any; var na_63 any = sh__5; if jrt.Long_InstanceOf(na_63) { var n0_64 int64 = jrt.NN(jrt.Long_Cast(na_63)).LongValue__J(); if n0_64 == -9223372036854775808 { na_62 = lang.Numbers_Dec_O__Number_NoInit(na_63) } else { na_62 = jrt.Long_ValueOf_J__Long_NoInit(n0_64 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_63) { var n0_64_2 float64 = jrt.NN(jrt.Double_Cast(na_63)).DoubleValue__D(); na_62 = jrt.Double_ValueOf_D__Double_NoInit(n0_64_2 - 1.0).Ref() } else { na_62 = lang.Numbers_Dec_O__Number_NoInit(na_63) } }; if jrt.Long_InstanceOf(na_62) { var n0_65 int64 = na_61; var n1_66 int64 = jrt.NN(jrt.Long_Cast(na_62)).LongValue__J(); tmp6 = n0_65 < n1_66 } else { tmp6 = lang.Numbers_Lt_J_O__Z_NoInit(na_61, na_62) }; below__10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp6).Ref() } else { below__10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } }
//line :55:1
		var up__11 any
		var and__1927000168__auto____11_2 bool = half_bit__9






		if and__1927000168__auto____11_2 { var or__1927000174__auto____12 any = below__10; if jrt.J2g_Truth(or__1927000174__auto____12) { up__11 = or__1927000174__auto____12 } else { up__11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.BigInteger_Cast(q__8)).TestBit_I__Z(lang.RT_IntCast_J__I_NoInit(0))).Ref() } } else { up__11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11_2).Ref() }
//line :55:1
		var q__12 any








		if jrt.J2g_Truth(up__11) { var tmp7 *jrt.BigInteger = jrt.BigInteger_Cast(q__8); var tmp8 *jrt.BigInteger; jrt.BigInteger_Init(); tmp8 = jrt.BigInteger_ONE; q__12 = jrt.NN(tmp7).Add_BigInteger__BigInteger(tmp8).Ref() } else { q__12 = q__8 }
//line :55:1
		var vec__161000017__13 any; var tmp9 bool; var na_68 int64 = int64(jrt.NN(jrt.BigInteger_Cast(q__12)).BitLength__I())
		var na_69 any = p__2








		if jrt.Long_InstanceOf(na_69) { var n0_70 int64 = na_68; var n1_71 int64 = jrt.NN(jrt.Long_Cast(na_69)).LongValue__J(); tmp9 = n0_70 > n1_71 } else { tmp9 = lang.Numbers_Gt_J_O__Z_NoInit(na_68, na_69) }; if tmp9 { var tmp10 any = jrt.NN(jrt.BigInteger_Cast(q__12)).ShiftRight_I__BigInteger(lang.RT_IntCast_J__I_NoInit(1)).Ref(); var tmp11 jrt.Number_I; var na_73 any = sh__5; if jrt.Long_InstanceOf(na_73) { var n0_74 int64 = jrt.NN(jrt.Long_Cast(na_73)).LongValue__J(); if n0_74 == 9223372036854775807 { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_73) } else { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_74 + 1)) } } else { if jrt.Double_InstanceOf(na_73) { var n0_74_2 float64 = jrt.NN(jrt.Double_Cast(na_73)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_74_2 + 1.0)) } else { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_73) } }; vec__161000017__13 = lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11) } else { vec__161000017__13 = lang.Tuple_Create_O_O__IPersistentVector(q__12, sh__5) }
//line :55:1
		var q__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000017__13, lang.RT_IntCast_J__I_NoInit(0), nil); var sh__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000017__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp12 any










		if neg__6 { tmp12 = lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(q__14, Lit_4, false) } else { tmp12 = q__14 }
//line :55:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp12, sh__15) } }












func A_arbace_go_check_const_bf_norm_A_New() *A_arbace_go_check_const_bf_norm_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_norm_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_go_check_const_bf_norm_A) Ctor() {}
//line :68:1
func (t *A_arbace_go_check_const_bf_norm_A) Invoke_O_O_O_O__O(self, m__0, e__1, sticky__2 any) any {



	if lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(m__0)).Signum__I())) { return A_arbace_go_check_const_A_const_17 } else { var vec__161000021__4 any; var root_75 any = A_arbace_go_check_const_A_const_18.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, A_arbace_go_check_const_round_int_A_fn_class); var ifn_77 lang.IFn

		if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = m__0; var arg_79 any = sticky__2; var arg_80 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O(); if linked_76 == nil { vec__161000021__4 = ifn_77.Invoke_O_O_O__O(arg_78, arg_79, arg_80) } else { vec__161000021__4 = linked_76.(*A_arbace_go_check_const_round_int_A).Invoke_O_O_O_O__O(root_75, arg_78, arg_79, arg_80) }
//line :72:1
		var m__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000021__4, lang.RT_IntCast_J__I_NoInit(0), nil); var sh__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000021__4, lang.RT_IntCast_J__I_NoInit(1), nil); var e__7 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e__1), lang.RT_LongCast_O__J_NoInit(sh__6)); var z__8 int32 = jrt.NN(jrt.BigInteger_Cast(m__5)).GetLowestSetBit__I(); var tmp1 any = A_arbace_go_check_const_A_const_16; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp1, jrt.NN(jrt.BigInteger_Cast(m__5)).ShiftRight_I__BigInteger(lang.RT_IntCast_I__I_NoInit(z__8)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(e__7, int64(z__8))).Ref()) } }
//line :68:1
func (t *A_arbace_go_check_const_bf_norm_A) Invoke_O_O_O__O(self, m__0, e__1 any) any {

	var root_81 any = A_arbace_go_check_const_A_const_20.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = m__0; var arg_85 any = e__1; var arg_86 any = jrt.Boolean_FALSE.Ref(); if linked_82 == nil { return ifn_83.Invoke_O_O_O__O(arg_84, arg_85, arg_86) } else { return linked_82.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O_O__O(root_81, arg_84, arg_85, arg_86)
	}
}






func A_arbace_go_check_const_rat_num_den_A_New() *A_arbace_go_check_const_rat_num_den_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_rat_num_den_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_go_check_const_rat_num_den_A) Ctor() {}
//line :79:1
func (t *A_arbace_go_check_const_rat_num_den_A) Invoke_O_O__O(self, r__0 any) any {
	var tmp1 any; var root_87 any = A_arbace_go_check_const_A_const_21.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = r__0; if linked_88 == nil { tmp1 = ifn_89.Invoke_O__O(arg_90) } else { tmp1 = linked_88.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_87, arg_90) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_91 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, A_arbace_go_check_const_bi_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any; var root_95 any = A_arbace_go_check_const_A_const_22.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_numerator_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = r__0; if linked_96 == nil { arg_94 = ifn_97.Invoke_O__O(arg_98) } else { arg_94 = linked_96.(*aot_arbace_core.A_arbace_core_numerator_A).Invoke_O_O__O(root_95, arg_98) }; if linked_92 == nil { tmp2 = ifn_93.Invoke_O__O(arg_94) } else { tmp2 = linked_92.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_91, arg_94) }; var tmp3 any = tmp2; var tmp4 any; var root_99 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, A_arbace_go_check_const_bi_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any; var root_103 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_denominator_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = r__0; if linked_104 == nil { arg_102 = ifn_105.Invoke_O__O(arg_106) } else { arg_102 = linked_104.(*aot_arbace_core.A_arbace_core_denominator_A).Invoke_O_O__O(root_103, arg_106) }; if linked_100 == nil { tmp4 = ifn_101.Invoke_O__O(arg_102) } else { tmp4 = linked_100.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_99, arg_102) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { var tmp5 any; var root_107 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, A_arbace_go_check_const_bi_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = r__0; if linked_108 == nil { tmp5 = ifn_109.Invoke_O__O(arg_110) } else { tmp5 = linked_108.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_107, arg_110) }; var tmp6 any = tmp5; var tmp7 *jrt.BigInteger; jrt.BigInteger_Init(); tmp7 = jrt.BigInteger_ONE; return lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7.Ref())
	} }
func A_arbace_go_check_const_rat__GT_bf_A_New() *A_arbace_go_check_const_rat__GT_bf_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_rat__GT_bf_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_go_check_const_rat__GT_bf_A) Ctor() {}
//line :82:1
func (t *A_arbace_go_check_const_rat__GT_bf_A) Invoke_O_O__O(self, r__0 any) any { var vec__161000026__2 any; var root_111 any = A_arbace_go_check_const_A_const_24.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, A_arbace_go_check_const_rat_num_den_A_fn_class); var ifn_113 lang.IFn; if


	linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = r__0; if linked_112 == nil { vec__161000026__2 = ifn_113.Invoke_O__O(arg_114) } else { vec__161000026__2 = linked_112.(*A_arbace_go_check_const_rat_num_den_A).Invoke_O_O__O(root_111, arg_114) }; var p__3 any = /*line :82:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__161000026__2, lang.RT_IntCast_J__I_NoInit(0), nil); var q__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000026__2, lang.RT_IntCast_J__I_NoInit(1), nil); if



	lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__3)).Signum__I())) { return A_arbace_go_check_const_A_const_17 } else { var k__5 any; var na_115 any; var na_117 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O()
		var na_118 int64 = 2
		if jrt.Long_InstanceOf(na_117) { var n0_119 int64 = jrt.NN(jrt.Long_Cast(na_117)).LongValue__J(); var n1_120 int64 = na_118; var nr_121 int64 = n0_119 + n1_120; if (n0_119^nr_121)&(n1_120^nr_121) >= 0 { na_115 = jrt.Long_ValueOf_J__Long_NoInit(nr_121).Ref() } else { na_115 = lang.Numbers_Add_O_J__Number_NoInit(na_117, na_118) } } else { na_115 = lang.Numbers_Add_O_J__Number_NoInit(na_117, na_118) }; var na_116 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(q__4)).BitLength__I()), int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(p__3)).Abs__BigInteger()).BitLength__I())); if jrt.Long_InstanceOf(na_115) { var n0_122 int64 = jrt.NN(jrt.Long_Cast(na_115)).LongValue__J(); var n1_123 int64 = na_116; var nr_124 int64 = n0_122 + n1_123; if (n0_122^nr_124)&(n1_123^nr_124) >= 0 { k__5 = jrt.Long_ValueOf_J__Long_NoInit(nr_124).Ref() } else { k__5 = lang.Numbers_Add_O_J__Number_NoInit(na_115, na_116) } } else { k__5 = lang.Numbers_Add_O_J__Number_NoInit(na_115, na_116) }
//line :86:1
		var k__6 any = lang.Numbers_Max_O_J__O_NoInit(k__5, 0); var dr__7 any = jrt.NN(jrt.NN(jrt.BigInteger_Cast(p__3)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(k__6))).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(q__4)).Ref(); var root_125 any = A_arbace_go_check_const_A_const_20.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_127 lang.IFn




		if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__7, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)); var arg_129 any; var na_131 any = k__6; if jrt.Long_InstanceOf(na_131) { var n0_132 int64 = jrt.NN(jrt.Long_Cast(na_131)).LongValue__J(); if n0_132 == -9223372036854775808 { arg_129 = lang.Numbers_Minus_O__Number_NoInit(na_131) } else { arg_129 = jrt.Long_ValueOf_J__Long_NoInit(-n0_132).Ref() } } else { if jrt.Double_InstanceOf(na_131) { var n0_132_2 float64 = jrt.NN(jrt.Double_Cast(na_131)).DoubleValue__D(); arg_129 = jrt.Double_ValueOf_D__Double_NoInit(-n0_132_2).Ref() } else { arg_129 = lang.Numbers_Minus_O__Number_NoInit(na_131) } }; var arg_130 any; var root_133 any = A_arbace_go_check_const_A_const_25.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__7, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)))).Signum__I()))).Ref(); if linked_134 == nil { arg_130 = ifn_135.Invoke_O__O(arg_136) } else { arg_130 = linked_134.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_133, arg_136) }; if linked_126 == nil { return ifn_127.Invoke_O_O_O__O(arg_128, arg_129, arg_130) } else { return linked_126.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O_O__O(root_125, arg_128, arg_129, arg_130) } } }

func A_arbace_go_check_const_bf__GT_rat_A_New() *A_arbace_go_check_const_bf__GT_rat_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf__GT_rat_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_go_check_const_bf__GT_rat_A) Ctor() {}
//line :93:1
func (t *A_arbace_go_check_const_bf__GT_rat_A) Invoke_O_O__O(self, p__161000030__0 any) any { var vec__161000031__2 any = p__161000030__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000031__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000031__2, lang.RT_IntCast_J__I_NoInit(1), nil); var e__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000031__2, lang.RT_IntCast_J__I_NoInit(2), nil); var e__6 int64 = lang.RT_LongCast_O__J_NoInit(e__5); _ = ___3; if



	lang.Numbers_IsNeg_J__Z_NoInit(e__6) {
		var tmp1 any; var root_137 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = m__4; if linked_138 == nil { tmp1 = ifn_139.Invoke_O__O(arg_140) } else { tmp1 = linked_138.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_137, arg_140) }; var tmp2 any = tmp1; var tmp3 any; var root_141 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any; var root_145 any = A_arbace_go_check_const_A_const_26.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, A_arbace_go_check_const_pow2_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(e__6)).Ref(); if linked_146 == nil { arg_144 = ifn_147.Invoke_O__O(arg_148) } else { arg_144 = linked_146.(*A_arbace_go_check_const_pow2_A).Invoke_O_O__O(root_145, arg_148) }; if linked_142 == nil { tmp3 = ifn_143.Invoke_O__O(arg_144) } else { tmp3 = linked_142.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_141, arg_144) }; return lang.Numbers_Divide_O_O__Number_NoInit(tmp2, tmp3) } else {
			var root_149 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = jrt.NN(jrt.BigInteger_Cast(m__4)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(e__6)).Ref(); if linked_150 == nil { return ifn_151.Invoke_O__O(arg_152) } else { return linked_150.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_149, arg_152) } } }

func A_arbace_go_check_const_small_int_QMARK__A_New() *A_arbace_go_check_const_small_int_QMARK__A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_small_int_QMARK__A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_go_check_const_small_int_QMARK__A) Ctor() {}
//line :101:1
func (t *A_arbace_go_check_const_small_int_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var tmp1 bool; var na_153 int64; var root_155 any = A_arbace_go_check_const_A_const_27.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_155, A_arbace_go_check_const_bit_len_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = x__0; if linked_156 == nil { na_153 = lang.RT_LongCast_O__J_NoInit(ifn_157.Invoke_O__O(arg_158)) } else { na_153 = linked_156.(*A_arbace_go_check_const_bit_len_A).InvokePrim_O_O__J(root_155, arg_158) }; var na_154 any = A_arbace_go_check_const_A_const_28.GetRawRoot__O(); if jrt.Long_InstanceOf(na_154) { var n0_159 int64 = na_153; var n1_160 int64 = jrt.NN(jrt.Long_Cast(na_154)).LongValue__J(); tmp1 = n0_159 < n1_160 } else { tmp1 = lang.Numbers_Lt_J_O__Z_NoInit(na_153, na_154) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref() }

func A_arbace_go_check_const_make_rat_A_New() *A_arbace_go_check_const_make_rat_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_make_rat_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_go_check_const_make_rat_A) Ctor() {}
//line :103:1
func (t *A_arbace_go_check_const_make_rat_A) Invoke_O_O__O(self, r__0 any) any {


	var tmp1 any; var root_162 any = A_arbace_go_check_const_A_const_21.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = r__0; if linked_163 == nil { tmp1 = ifn_164.Invoke_O__O(arg_165) } else { tmp1 = linked_163.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_162, arg_165) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var and__1927000168__auto____2 any; var root_166 any = A_arbace_go_check_const_A_const_29.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, A_arbace_go_check_const_small_int_QMARK__A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any; var root_170 any = A_arbace_go_check_const_A_const_22.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_numerator_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = r__0; if linked_171 == nil { arg_169 = ifn_172.Invoke_O__O(arg_173) } else { arg_169 = linked_171.(*aot_arbace_core.A_arbace_core_numerator_A).Invoke_O_O__O(root_170, arg_173) }; if linked_167 == nil { and__1927000168__auto____2 = ifn_168.Invoke_O__O(arg_169) } else { and__1927000168__auto____2 = linked_167.(*A_arbace_go_check_const_small_int_QMARK__A).Invoke_O_O__O(root_166, arg_169) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_174 any = A_arbace_go_check_const_A_const_29.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, A_arbace_go_check_const_small_int_QMARK__A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any; var root_178 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_denominator_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = r__0; if linked_179 == nil { arg_177 = ifn_180.Invoke_O__O(arg_181) } else { arg_177 = linked_179.(*aot_arbace_core.A_arbace_core_denominator_A).Invoke_O_O__O(root_178, arg_181) }; if linked_175 == nil { tmp2 = ifn_176.Invoke_O__O(arg_177) } else { tmp2 = linked_175.(*A_arbace_go_check_const_small_int_QMARK__A).Invoke_O_O__O(root_174, arg_177) } } else { tmp2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp2) { return r__0 } else { var root_182 any = A_arbace_go_check_const_A_const_30.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, A_arbace_go_check_const_rat__GT_bf_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = r__0; if linked_183 == nil { return ifn_184.Invoke_O__O(arg_185) } else { return linked_183.(*A_arbace_go_check_const_rat__GT_bf_A).Invoke_O_O__O(root_182, arg_185) } } } else {
			var tmp3 any; var root_186 any = A_arbace_go_check_const_A_const_29.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, A_arbace_go_check_const_small_int_QMARK__A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = r__0; if linked_187 == nil { tmp3 = ifn_188.Invoke_O__O(arg_189) } else { tmp3 = linked_187.(*A_arbace_go_check_const_small_int_QMARK__A).Invoke_O_O__O(root_186, arg_189) }; if jrt.J2g_Truth(tmp3) { return r__0 } else { var root_190 any = A_arbace_go_check_const_A_const_30.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, A_arbace_go_check_const_rat__GT_bf_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = r__0; if linked_191 == nil { return ifn_192.Invoke_O__O(arg_193) } else { return linked_191.(*A_arbace_go_check_const_rat__GT_bf_A).Invoke_O_O__O(root_190, arg_193)
			} } } }
func A_arbace_go_check_const_bf_exp_A_New() *A_arbace_go_check_const_bf_exp_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_exp_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_go_check_const_bf_exp_A) Ctor() {}
//line :110:1
func (t *A_arbace_go_check_const_bf_exp_A) InvokePrim_O_O__J(self, p__161000037__0 any) int64 { var vec__161000038__2 any = p__161000037__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000038__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000038__2, lang.RT_IntCast_J__I_NoInit(1), nil); var e__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000038__2, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___3; return /*line :113:1*/ lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e__5), int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m__4)).Abs__BigInteger()).BitLength__I())) }
//line :110:1
func (t *A_arbace_go_check_const_bf_exp_A) Invoke_O_O__O(self, p__161000037__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, p__161000037__0)).Ref() }




func A_arbace_go_check_const_to_bf_A_New() *A_arbace_go_check_const_to_bf_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_to_bf_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_go_check_const_to_bf_A) Ctor() {}
//line :115:1
func (t *A_arbace_go_check_const_to_bf_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_194 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = x__0; if linked_195 == nil { tmp1 = ifn_196.Invoke_O__O(arg_197) } else { tmp1 = linked_195.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_194, arg_197) }; if jrt.J2g_Truth(tmp1) { return x__0 } else { var root_198 any = A_arbace_go_check_const_A_const_30.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, A_arbace_go_check_const_rat__GT_bf_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = x__0; if linked_199 == nil { return ifn_200.Invoke_O__O(arg_201) } else { return linked_199.(*A_arbace_go_check_const_rat__GT_bf_A).Invoke_O_O__O(root_198, arg_201) } } }

func A_arbace_go_check_const_bf_sign_A_New() *A_arbace_go_check_const_bf_sign_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_sign_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_go_check_const_bf_sign_A) Ctor() {}
//line :117:1
func (t *A_arbace_go_check_const_bf_sign_A) InvokePrim_O_O__J(self, x__0 any) int64 { var tmp1 any; var root_202 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = x__0; if linked_203 == nil { tmp1 = ifn_204.Invoke_O__O(arg_205) } else { tmp1 = linked_203.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_202, arg_205) }; if jrt.J2g_Truth(tmp1) { return lang.RT_LongCast_I__J_NoInit(jrt.NN(jrt.BigInteger_Cast(lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(1)))).Signum__I()) } else { return lang.RT_LongCast_I__J_NoInit(lang.Util_Compare_O_O__I_NoInit(x__0, A_arbace_go_check_const_A_const_17)) } }
//line :117:1
func (t *A_arbace_go_check_const_bf_sign_A) Invoke_O_O__O(self, x__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, x__0)).Ref() }

func A_arbace_go_check_const_bf_add_A_New() *A_arbace_go_check_const_bf_add_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_add_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_go_check_const_bf_add_A) Ctor() {}
//line :119:1
func (t *A_arbace_go_check_const_bf_add_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var vec__161000044__3 any; var root_206 any = A_arbace_go_check_const_A_const_32.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_208 lang.IFn; if
											linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = x__0; if linked_207 == nil { vec__161000044__3 = ifn_208.Invoke_O__O(arg_209) } else { vec__161000044__3 = linked_207.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_206, arg_209) }; var ___4 any = /*line :119:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__161000044__3, lang.RT_IntCast_J__I_NoInit(0), nil); var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000044__3, lang.RT_IntCast_J__I_NoInit(1), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000044__3, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__161000047__7 any; var root_210 any = A_arbace_go_check_const_A_const_32.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_212 lang.IFn; _ = ___4; if
											linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = y__1; if linked_211 == nil { vec__161000047__7 = ifn_212.Invoke_O__O(arg_213) } else { vec__161000047__7 = linked_211.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_210, arg_213) }; var ___8 any = /*line :119:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__161000047__7, lang.RT_IntCast_J__I_NoInit(0), nil); var m2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000047__7, lang.RT_IntCast_J__I_NoInit(1), nil); var e2__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000047__7, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___8; if

	lang.Util_Equiv_J_O__Z_NoInit(0, x__0) {
		var root_214 any = A_arbace_go_check_const_A_const_32.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = y__1; if linked_215 == nil { return ifn_216.Invoke_O__O(arg_217) } else { return linked_215.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_214, arg_217) } } else {
//line :121:1
			if lang.Util_Equiv_J_O__Z_NoInit(0, y__1) {

				var root_218 any = A_arbace_go_check_const_A_const_32.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = x__0; if linked_219 == nil { return ifn_220.Invoke_O__O(arg_221) } else { return linked_219.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_218, arg_221) } } else {
//line :121:1
					if A_arbace_go_check_const_A_const_8 != nil { var e1__11 int64 = lang.RT_LongCast_O__J_NoInit(e1__6); var e2__12 int64 = lang.RT_LongCast_O__J_NoInit(e2__10); var vec__161000050__13 any




						if lang.Numbers_Gte_J_J__Z_NoInit(lang.Numbers_Add_J_J__J_NoInit(e1__11, int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m1__5)).Abs__BigInteger()).BitLength__I())), lang.Numbers_Add_J_J__J_NoInit(e2__12, int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m2__9)).Abs__BigInteger()).BitLength__I()))) { vec__161000050__13 = lang.Tuple_Create_O_O_O_O__IPersistentVector(m1__5, jrt.Long_ValueOf_J__Long_NoInit(e1__11).Ref(), m2__9, jrt.Long_ValueOf_J__Long_NoInit(e2__12).Ref()) } else { vec__161000050__13 = lang.Tuple_Create_O_O_O_O__IPersistentVector(m2__9, jrt.Long_ValueOf_J__Long_NoInit(e2__12).Ref(), m1__5, jrt.Long_ValueOf_J__Long_NoInit(e1__11).Ref()) }
//line :121:1
						var hi_m__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000050__13, lang.RT_IntCast_J__I_NoInit(0), nil); var hi_e__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000050__13, lang.RT_IntCast_J__I_NoInit(1), nil); var lo_m__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000050__13, lang.RT_IntCast_J__I_NoInit(2), nil); var lo_e__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000050__13, lang.RT_IntCast_J__I_NoInit(3), nil); var hi_m__18 any = hi_m__14; var lo_m__19 any = lo_m__16; var hi_top__20 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(hi_e__15), int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(hi_m__18)).Abs__BigInteger()).BitLength__I())); var lo_top__21 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(lo_e__17), int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(lo_m__19)).Abs__BigInteger()).BitLength__I())); var tmp1 bool; var na_222 int64 = lang.Numbers_Minus_J_J__J_NoInit(hi_top__20, lo_top__21); var na_223 any; var na_224 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O()
						var na_225 int64 = 8








						if jrt.Long_InstanceOf(na_224) { var n0_226 int64 = jrt.NN(jrt.Long_Cast(na_224)).LongValue__J(); var n1_227 int64 = na_225; var nr_228 int64 = n0_226 + n1_227; if (n0_226^nr_228)&(n1_227^nr_228) >= 0 { na_223 = jrt.Long_ValueOf_J__Long_NoInit(nr_228).Ref() } else { na_223 = lang.Numbers_Add_O_J__Number_NoInit(na_224, na_225) } } else { na_223 = lang.Numbers_Add_O_J__Number_NoInit(na_224, na_225) }; if jrt.Long_InstanceOf(na_223) { var n0_229 int64 = na_222; var n1_230 int64 = jrt.NN(jrt.Long_Cast(na_223)).LongValue__J(); tmp1 = n0_229 > n1_230 } else { tmp1 = lang.Numbers_Gt_J_O__Z_NoInit(na_222, na_223) }; if tmp1 {

							var root_232 any = A_arbace_go_check_const_A_const_20.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = hi_m__18; var arg_236 any = hi_e__15; if linked_233 == nil { return ifn_234.Invoke_O_O__O(arg_235, arg_236) } else { return linked_233.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O__O(root_232, arg_235, arg_236) } } else {
//line :131:1
								var e__22 int64 = lang.Numbers_Min_J_J__J_NoInit(e1__11, e2__12); var s__23 any = jrt.NN(jrt.NN(jrt.BigInteger_Cast(m1__5)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(e1__11, e__22)))).Add_BigInteger__BigInteger(jrt.NN(jrt.BigInteger_Cast(m2__9)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(e2__12, e__22)))).Ref(); var root_237 any = A_arbace_go_check_const_A_const_20.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_239 lang.IFn




								if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = s__23; var arg_241 any = jrt.Long_ValueOf_J__Long_NoInit(e__22).Ref(); if linked_238 == nil { return ifn_239.Invoke_O_O__O(arg_240, arg_241) } else { return linked_238.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O__O(root_237, arg_240, arg_241) } } } else {
//line :121:1
									return nil } } } }
















func A_arbace_go_check_const_bf_neg_A_New() *A_arbace_go_check_const_bf_neg_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_neg_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_go_check_const_bf_neg_A) Ctor() {}
//line :138:1
func (t *A_arbace_go_check_const_bf_neg_A) Invoke_O_O__O(self, x__0 any) any { if jrt.Long_InstanceOf(x__0) { return t.InvokeSpec_O_J_O__O(self, jrt.NN(jrt.Long_Cast(x__0)).LongValue__J(), x__0) } else { var tmp1 any; var root_242 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = x__0; if linked_243 == nil { tmp1 = ifn_244.Invoke_O__O(arg_245) } else { tmp1 = linked_243.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_242, arg_245) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_go_check_const_A_const_16; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, jrt.NN(jrt.BigInteger_Cast(lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(1)))).Negate__BigInteger().Ref(), lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(2))) } else { var na_246 any = x__0; if jrt.Long_InstanceOf(na_246) { var n0_247 int64 = jrt.NN(jrt.Long_Cast(na_246)).LongValue__J(); if n0_247 == -9223372036854775808 { return lang.Numbers_Minus_O__Number_NoInit(na_246) } else { return jrt.Long_ValueOf_J__Long_NoInit(-n0_247).Ref() } } else { if jrt.Double_InstanceOf(na_246) { var n0_247_2 float64 = jrt.NN(jrt.Double_Cast(na_246)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(-n0_247_2).Ref() } else { return lang.Numbers_Minus_O__Number_NoInit(na_246) } } } } }
//line :138:1
func (t *A_arbace_go_check_const_bf_neg_A) InvokeSpec_O_J_O__O(self any, x__0_l int64, x__0_b any) any { var tmp1 any; var root_248 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_251 = x__0_b } else { arg_251 = x__0_b }; if linked_249 == nil { tmp1 = ifn_250.Invoke_O__O(arg_251) } else { tmp1 = linked_249.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_248, arg_251) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_go_check_const_A_const_16; var tmp3 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp3 = x__0_b } else { tmp3 = x__0_b }; var tmp4 any = jrt.NN(jrt.BigInteger_Cast(lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(1)))).Negate__BigInteger().Ref(); var tmp5 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp5 = x__0_b } else { tmp5 = x__0_b }; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp4, lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(2))) } else { var n0_252 int64 = x__0_l; if n0_252 == -9223372036854775808 { var tmp6 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp6 = x__0_b } else { tmp6 = x__0_b }; return lang.Numbers_Minus_O__Number_NoInit(tmp6) } else { return jrt.Long_ValueOf_J__Long_NoInit(-n0_252).Ref() } } }

func A_arbace_go_check_const_bf_mul_A_New() *A_arbace_go_check_const_bf_mul_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_mul_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_go_check_const_bf_mul_A) Ctor() {}
//line :140:1
func (t *A_arbace_go_check_const_bf_mul_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Equiv_J_O__Z_NoInit(0, x__0); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_J_O__Z_NoInit(0, y__1) }; if tmp1 { return A_arbace_go_check_const_A_const_17 } else { var vec__161000055__3 any; var root_253 any = A_arbace_go_check_const_A_const_32.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_255 lang.IFn

		if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = x__0; if linked_254 == nil { vec__161000055__3 = ifn_255.Invoke_O__O(arg_256) } else { vec__161000055__3 = linked_254.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_253, arg_256) }
//line :141:1
		var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000055__3, lang.RT_IntCast_J__I_NoInit(0), nil); var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000055__3, lang.RT_IntCast_J__I_NoInit(1), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000055__3, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__161000058__7 any; var root_257 any = A_arbace_go_check_const_A_const_32.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_259 lang.IFn; _ = ___4

		if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = y__1; if linked_258 == nil { vec__161000058__7 = ifn_259.Invoke_O__O(arg_260) } else { vec__161000058__7 = linked_258.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_257, arg_260) }
//line :141:1
		var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000058__7, lang.RT_IntCast_J__I_NoInit(0), nil); var m2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000058__7, lang.RT_IntCast_J__I_NoInit(1), nil); var e2__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000058__7, lang.RT_IntCast_J__I_NoInit(2), nil); var root_261 any = A_arbace_go_check_const_A_const_20.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_263 lang.IFn; _ = ___8


		if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = jrt.NN(jrt.BigInteger_Cast(m1__5)).Multiply_BigInteger__BigInteger(jrt.BigInteger_Cast(m2__9)).Ref(); var arg_265 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e1__6), lang.RT_LongCast_O__J_NoInit(e2__10))).Ref(); if linked_262 == nil { return ifn_263.Invoke_O_O__O(arg_264, arg_265) } else { return linked_262.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O__O(root_261, arg_264, arg_265)
		} } }
func A_arbace_go_check_const_bf_quo_A_New() *A_arbace_go_check_const_bf_quo_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_quo_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_go_check_const_bf_quo_A) Ctor() {}
//line :146:1
func (t *A_arbace_go_check_const_bf_quo_A) Invoke_O_O_O__O(self, x__0, y__1 any) any {
	if lang.Util_Equiv_J_O__Z_NoInit(0, x__0) { return A_arbace_go_check_const_A_const_17 } else { var vec__161000062__3 any; var root_266 any = A_arbace_go_check_const_A_const_32.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_268 lang.IFn

		if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = x__0; if linked_267 == nil { vec__161000062__3 = ifn_268.Invoke_O__O(arg_269) } else { vec__161000062__3 = linked_267.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_266, arg_269) }
//line :147:1
		var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000062__3, lang.RT_IntCast_J__I_NoInit(0), nil); var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000062__3, lang.RT_IntCast_J__I_NoInit(1), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000062__3, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__161000065__7 any; var root_270 any = A_arbace_go_check_const_A_const_32.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, A_arbace_go_check_const_to_bf_A_fn_class); var ifn_272 lang.IFn; _ = ___4

		if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = y__1; if linked_271 == nil { vec__161000065__7 = ifn_272.Invoke_O__O(arg_273) } else { vec__161000065__7 = linked_271.(*A_arbace_go_check_const_to_bf_A).Invoke_O_O__O(root_270, arg_273) }
//line :147:1
		var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000065__7, lang.RT_IntCast_J__I_NoInit(0), nil); var m2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000065__7, lang.RT_IntCast_J__I_NoInit(1), nil); var e2__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000065__7, lang.RT_IntCast_J__I_NoInit(2), nil); var k__11 any; var tmp1 jrt.Number_I; var na_274 any; var na_276 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O(); var na_277 int64 = 2; _ = ___8


		if jrt.Long_InstanceOf(na_276) { var n0_278 int64 = jrt.NN(jrt.Long_Cast(na_276)).LongValue__J(); var n1_279 int64 = na_277; var nr_280 int64 = n0_278 + n1_279; if (n0_278^nr_280)&(n1_279^nr_280) >= 0 { na_274 = jrt.Long_ValueOf_J__Long_NoInit(nr_280).Ref() } else { na_274 = lang.Numbers_Add_O_J__Number_NoInit(na_276, na_277) } } else { na_274 = lang.Numbers_Add_O_J__Number_NoInit(na_276, na_277) }; var na_275 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m2__9)).Abs__BigInteger()).BitLength__I()), int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m1__5)).Abs__BigInteger()).BitLength__I())); if jrt.Long_InstanceOf(na_274) { var n0_281 int64 = jrt.NN(jrt.Long_Cast(na_274)).LongValue__J(); var n1_282 int64 = na_275; var nr_283 int64 = n0_281 + n1_282; if (n0_281^nr_283)&(n1_282^nr_283) >= 0 { tmp1 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_283)) } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_274, na_275) } } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_274, na_275) }; k__11 = lang.Numbers_Max_J_O__O_NoInit(0, tmp1)
//line :147:1
		var dr__12 any = jrt.NN(jrt.NN(jrt.BigInteger_Cast(m1__5)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(k__11))).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(m2__9)).Ref(); var root_284 any = A_arbace_go_check_const_A_const_20.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_286 lang.IFn




		if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__12, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)); var arg_288 any; var na_290 int64 = lang.Numbers_Minus_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e1__6), lang.RT_LongCast_O__J_NoInit(e2__10)); var na_291 any = k__11; if jrt.Long_InstanceOf(na_291) { var n0_292 int64 = na_290; var n1_293 int64 = jrt.NN(jrt.Long_Cast(na_291)).LongValue__J(); var nr_294 int64 = n0_292 - n1_293; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_293 == -9223372036854775808); if tmp3 { tmp3 = (n0_292^n1_293)&(n0_292^nr_294) >= 0 }; tmp2 = tmp3; if tmp2 { arg_288 = jrt.Long_ValueOf_J__Long_NoInit(nr_294).Ref() } else { arg_288 = lang.Numbers_Minus_J_O__Number_NoInit(na_290, na_291) } } else { arg_288 = lang.Numbers_Minus_J_O__Number_NoInit(na_290, na_291) }; var arg_289 any; var root_295 any = A_arbace_go_check_const_A_const_25.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__12, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)))).Signum__I()))).Ref(); if linked_296 == nil { arg_289 = ifn_297.Invoke_O__O(arg_298) } else { arg_289 = linked_296.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_295, arg_298) }; if linked_285 == nil { return ifn_286.Invoke_O_O_O__O(arg_287, arg_288, arg_289) } else { return linked_285.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O_O__O(root_284, arg_287, arg_288, arg_289)
		} } }
func A_arbace_go_check_const_bf_cmp_A_New() *A_arbace_go_check_const_bf_cmp_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_bf_cmp_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_go_check_const_bf_cmp_A) Ctor() {}
//line :154:1
func (t *A_arbace_go_check_const_bf_cmp_A) InvokePrim_O_O_O__J(self, x__0, y__1 any) int64 { var tmp1 any; var root_299 any = A_arbace_go_check_const_A_const_33.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_299, A_arbace_go_check_const_bf_sign_A_fn_class); var ifn_301 lang.IFn; if


	linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any; var root_303 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, A_arbace_go_check_const_bf_add_A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = x__0; var arg_307 any; var root_308 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_308, A_arbace_go_check_const_bf_neg_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = y__1; if linked_309 == nil { arg_307 = ifn_310.Invoke_O__O(arg_311) } else { if jrt.Long_InstanceOf(arg_311) { arg_307 = linked_309.(*A_arbace_go_check_const_bf_neg_A).InvokeSpec_O_J_O__O(root_308, jrt.NN(jrt.Long_Cast(arg_311)).LongValue__J(), arg_311) } else { arg_307 = linked_309.(*A_arbace_go_check_const_bf_neg_A).Invoke_O_O__O(root_308, arg_311) } }; if linked_304 == nil { arg_302 = ifn_305.Invoke_O_O__O(arg_306, arg_307) } else { arg_302 = linked_304.(*A_arbace_go_check_const_bf_add_A).Invoke_O_O_O__O(root_303, arg_306, arg_307) }; if linked_300 == nil { tmp1 = ifn_301.Invoke_O__O(arg_302) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_300.(*A_arbace_go_check_const_bf_sign_A).InvokePrim_O_O__J(root_299, arg_302)).Ref() }; return /*line :154:1*/ jrt.Number_Cast(tmp1).LongValue__J() }
//line :154:1
func (t *A_arbace_go_check_const_bf_cmp_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O_O__J(self, x__0, y__1)).Ref() }






func A_arbace_go_check_const_float_val_A_New() *A_arbace_go_check_const_float_val_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_float_val_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_go_check_const_float_val_A) Ctor() {}
//line :161:1
func (t *A_arbace_go_check_const_float_val_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var root_312 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_314 lang.IFn
	if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = x__0; if linked_313 == nil { tmp1 = ifn_314.Invoke_O__O(arg_315) } else { tmp1 = linked_313.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_312, arg_315) }
//line :164:1
	if jrt.J2g_Truth(tmp1) { return x__0 } else { var tmp2 any; var root_316 any = A_arbace_go_check_const_A_const_36.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_318 lang.IFn

		if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = x__0; if linked_317 == nil { tmp2 = ifn_318.Invoke_O__O(arg_319) } else { tmp2 = linked_317.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_316, arg_319) }
//line :164:1
		if jrt.J2g_Truth(tmp2) {

			var root_320 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = x__0; if linked_321 == nil { return ifn_322.Invoke_O__O(arg_323) } else { return linked_321.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_320, arg_323) } } else {
//line :164:1
				if A_arbace_go_check_const_A_const_8 != nil { return x__0 } else { return nil
				}
			}
	}
}
func A_arbace_go_check_const_fadd_A_New() *A_arbace_go_check_const_fadd_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fadd_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_go_check_const_fadd_A) Ctor() {}
//line :169:1
func (t *A_arbace_go_check_const_fadd_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(x__0); if tmp2 { tmp2 = jrt.Long_InstanceOf(y__1) }; tmp1 = tmp2; if tmp1 { return t.InvokeSpec_O_J_O_J_O__O(self, jrt.NN(jrt.Long_Cast(x__0)).LongValue__J(), x__0, jrt.NN(jrt.Long_Cast(y__1)).LongValue__J(), y__1) } else { var tmp3 any; var or__1927000174__auto____3 any; var root_324 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = x__0; if linked_325 == nil { or__1927000174__auto____3 = ifn_326.Invoke_O__O(arg_327) } else { or__1927000174__auto____3 = linked_325.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_324, arg_327) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var root_328 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = y__1; if linked_329 == nil { tmp3 = ifn_330.Invoke_O__O(arg_331) } else { tmp3 = linked_329.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_328, arg_331) } }; if jrt.J2g_Truth(tmp3) { var root_332 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, A_arbace_go_check_const_bf_add_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = x__0; var arg_336 any = y__1; if linked_333 == nil { return ifn_334.Invoke_O_O__O(arg_335, arg_336) } else { return linked_333.(*A_arbace_go_check_const_bf_add_A).Invoke_O_O_O__O(root_332, arg_335, arg_336) } } else { var root_337 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any; var na_341 any = x__0; var na_342 any = y__1; var tmp4 bool; var tmp5 bool; tmp5 = jrt.Long_InstanceOf(na_341); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_342) }; tmp4 = tmp5; if tmp4 { var n0_343 int64 = jrt.NN(jrt.Long_Cast(na_341)).LongValue__J(); var n1_344 int64 = jrt.NN(jrt.Long_Cast(na_342)).LongValue__J(); var nr_345 int64 = n0_343 + n1_344; if (n0_343^nr_345)&(n1_344^nr_345) >= 0 { arg_340 = jrt.Long_ValueOf_J__Long_NoInit(nr_345).Ref() } else { arg_340 = lang.Numbers_Add_O_O__Number_NoInit(na_341, na_342) } } else { var tmp6 bool; var tmp7 bool; tmp7 = jrt.Double_InstanceOf(na_341); if tmp7 { tmp7 = jrt.Double_InstanceOf(na_342) }; tmp6 = tmp7; if tmp6 { var n0_343_2 float64 = jrt.NN(jrt.Double_Cast(na_341)).DoubleValue__D(); var n1_344_2 float64 = jrt.NN(jrt.Double_Cast(na_342)).DoubleValue__D(); arg_340 = jrt.Double_ValueOf_D__Double_NoInit(n0_343_2 + n1_344_2).Ref() } else { arg_340 = lang.Numbers_Add_O_O__Number_NoInit(na_341, na_342) } }; if linked_338 == nil { return ifn_339.Invoke_O__O(arg_340) } else { return linked_338.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_337, arg_340) } } } }
//line :169:1
func (t *A_arbace_go_check_const_fadd_A) InvokeSpec_O_J_O_J_O__O(self any, x__0_l int64, x__0_b any, y__1_l int64, y__1_b any) any { var tmp1 any; var or__1927000174__auto____3 any; var root_346 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_349 = x__0_b } else { arg_349 = x__0_b }; if linked_347 == nil { or__1927000174__auto____3 = ifn_348.Invoke_O__O(arg_349) } else { or__1927000174__auto____3 = linked_347.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_346, arg_349) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_350 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); arg_353 = y__1_b } else { arg_353 = y__1_b }; if linked_351 == nil { tmp1 = ifn_352.Invoke_O__O(arg_353) } else { tmp1 = linked_351.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_350, arg_353) } }; if jrt.J2g_Truth(tmp1) { var root_354 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, A_arbace_go_check_const_bf_add_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_357 = x__0_b } else { arg_357 = x__0_b }; var arg_358 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); arg_358 = y__1_b } else { arg_358 = y__1_b }; if linked_355 == nil { return ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { return linked_355.(*A_arbace_go_check_const_bf_add_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) } } else { var root_359 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any; var n0_363 int64 = x__0_l; var n1_364 int64 = y__1_l; var nr_365 int64 = n0_363 + n1_364; if (n0_363^nr_365)&(n1_364^nr_365) >= 0 { arg_362 = jrt.Long_ValueOf_J__Long_NoInit(nr_365).Ref() } else { var tmp2 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp2 = x__0_b } else { tmp2 = x__0_b }; var tmp3 any = tmp2; var tmp4 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp4 = y__1_b } else { tmp4 = y__1_b }; arg_362 = lang.Numbers_Add_O_O__Number_NoInit(tmp3, tmp4) }; if linked_360 == nil { return ifn_361.Invoke_O__O(arg_362) } else { return linked_360.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_359, arg_362) } } }
func A_arbace_go_check_const_fsub_A_New() *A_arbace_go_check_const_fsub_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fsub_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_go_check_const_fsub_A) Ctor() {}
//line :170:1
func (t *A_arbace_go_check_const_fsub_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(x__0); if tmp2 { tmp2 = jrt.Long_InstanceOf(y__1) }; tmp1 = tmp2; if tmp1 { return t.InvokeSpec_O_J_O_J_O__O(self, jrt.NN(jrt.Long_Cast(x__0)).LongValue__J(), x__0, jrt.NN(jrt.Long_Cast(y__1)).LongValue__J(), y__1) } else { var tmp3 any; var or__1927000174__auto____3 any; var root_366 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = x__0; if linked_367 == nil { or__1927000174__auto____3 = ifn_368.Invoke_O__O(arg_369) } else { or__1927000174__auto____3 = linked_367.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_366, arg_369) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var root_370 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = y__1; if linked_371 == nil { tmp3 = ifn_372.Invoke_O__O(arg_373) } else { tmp3 = linked_371.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_370, arg_373) } }; if jrt.J2g_Truth(tmp3) { var root_374 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, A_arbace_go_check_const_bf_add_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = x__0; var arg_378 any; var root_379 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_379, A_arbace_go_check_const_bf_neg_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = y__1; if linked_380 == nil { arg_378 = ifn_381.Invoke_O__O(arg_382) } else { if jrt.Long_InstanceOf(arg_382) { arg_378 = linked_380.(*A_arbace_go_check_const_bf_neg_A).InvokeSpec_O_J_O__O(root_379, jrt.NN(jrt.Long_Cast(arg_382)).LongValue__J(), arg_382) } else { arg_378 = linked_380.(*A_arbace_go_check_const_bf_neg_A).Invoke_O_O__O(root_379, arg_382) } }; if linked_375 == nil { return ifn_376.Invoke_O_O__O(arg_377, arg_378) } else { return linked_375.(*A_arbace_go_check_const_bf_add_A).Invoke_O_O_O__O(root_374, arg_377, arg_378) } } else { var root_383 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any; var na_387 any = x__0; var na_388 any = y__1; var tmp4 bool; var tmp5 bool; tmp5 = jrt.Long_InstanceOf(na_387); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_388) }; tmp4 = tmp5; if tmp4 { var n0_389 int64 = jrt.NN(jrt.Long_Cast(na_387)).LongValue__J(); var n1_390 int64 = jrt.NN(jrt.Long_Cast(na_388)).LongValue__J(); var nr_391 int64 = n0_389 - n1_390; var tmp6 bool; var tmp7 bool; tmp7 = !(n1_390 == -9223372036854775808); if tmp7 { tmp7 = (n0_389^n1_390)&(n0_389^nr_391) >= 0 }; tmp6 = tmp7; if tmp6 { arg_386 = jrt.Long_ValueOf_J__Long_NoInit(nr_391).Ref() } else { arg_386 = lang.Numbers_Minus_O_O__Number_NoInit(na_387, na_388) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_387); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_388) }; tmp8 = tmp9; if tmp8 { var n0_389_2 float64 = jrt.NN(jrt.Double_Cast(na_387)).DoubleValue__D(); var n1_390_2 float64 = jrt.NN(jrt.Double_Cast(na_388)).DoubleValue__D(); arg_386 = jrt.Double_ValueOf_D__Double_NoInit(n0_389_2 + -n1_390_2).Ref() } else { arg_386 = lang.Numbers_Minus_O_O__Number_NoInit(na_387, na_388) } }; if linked_384 == nil { return ifn_385.Invoke_O__O(arg_386) } else { return linked_384.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_383, arg_386) } } } }
//line :170:1
func (t *A_arbace_go_check_const_fsub_A) InvokeSpec_O_J_O_J_O__O(self any, x__0_l int64, x__0_b any, y__1_l int64, y__1_b any) any { var tmp1 any; var or__1927000174__auto____3 any; var root_392 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_395 = x__0_b } else { arg_395 = x__0_b }; if linked_393 == nil { or__1927000174__auto____3 = ifn_394.Invoke_O__O(arg_395) } else { or__1927000174__auto____3 = linked_393.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_392, arg_395) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_396 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); arg_399 = y__1_b } else { arg_399 = y__1_b }; if linked_397 == nil { tmp1 = ifn_398.Invoke_O__O(arg_399) } else { tmp1 = linked_397.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_396, arg_399) } }; if jrt.J2g_Truth(tmp1) { var root_400 any = A_arbace_go_check_const_A_const_34.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, A_arbace_go_check_const_bf_add_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_403 = x__0_b } else { arg_403 = x__0_b }; var arg_404 any; var root_405 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_405, A_arbace_go_check_const_bf_neg_A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; if linked_406 == nil { var tmp2 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp2 = y__1_b } else { tmp2 = y__1_b }; arg_404 = ifn_407.Invoke_O__O(tmp2) } else { arg_404 = linked_406.(*A_arbace_go_check_const_bf_neg_A).InvokeSpec_O_J_O__O(root_405, y__1_l, y__1_b) }; if linked_401 == nil { return ifn_402.Invoke_O_O__O(arg_403, arg_404) } else { return linked_401.(*A_arbace_go_check_const_bf_add_A).Invoke_O_O_O__O(root_400, arg_403, arg_404) } } else { var root_409 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_411 lang.IFn; if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any; var n0_413 int64 = x__0_l; var n1_414 int64 = y__1_l; var nr_415 int64 = n0_413 - n1_414; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_414 == -9223372036854775808); if tmp4 { tmp4 = (n0_413^n1_414)&(n0_413^nr_415) >= 0 }; tmp3 = tmp4; if tmp3 { arg_412 = jrt.Long_ValueOf_J__Long_NoInit(nr_415).Ref() } else { var tmp5 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp5 = x__0_b } else { tmp5 = x__0_b }; var tmp6 any = tmp5; var tmp7 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp7 = y__1_b } else { tmp7 = y__1_b }; arg_412 = lang.Numbers_Minus_O_O__Number_NoInit(tmp6, tmp7) }; if linked_410 == nil { return ifn_411.Invoke_O__O(arg_412) } else { return linked_410.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_409, arg_412) } } }
func A_arbace_go_check_const_fmul_A_New() *A_arbace_go_check_const_fmul_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fmul_A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_go_check_const_fmul_A) Ctor() {}
//line :171:1
func (t *A_arbace_go_check_const_fmul_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(x__0); if tmp2 { tmp2 = jrt.Long_InstanceOf(y__1) }; tmp1 = tmp2; if tmp1 { return t.InvokeSpec_O_J_O_J_O__O(self, jrt.NN(jrt.Long_Cast(x__0)).LongValue__J(), x__0, jrt.NN(jrt.Long_Cast(y__1)).LongValue__J(), y__1) } else { var tmp3 any; var or__1927000174__auto____3 any; var root_416 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = x__0; if linked_417 == nil { or__1927000174__auto____3 = ifn_418.Invoke_O__O(arg_419) } else { or__1927000174__auto____3 = linked_417.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_416, arg_419) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var root_420 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = y__1; if linked_421 == nil { tmp3 = ifn_422.Invoke_O__O(arg_423) } else { tmp3 = linked_421.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_420, arg_423) } }; if jrt.J2g_Truth(tmp3) { var root_424 any = A_arbace_go_check_const_A_const_38.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, A_arbace_go_check_const_bf_mul_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = x__0; var arg_428 any = y__1; if linked_425 == nil { return ifn_426.Invoke_O_O__O(arg_427, arg_428) } else { return linked_425.(*A_arbace_go_check_const_bf_mul_A).Invoke_O_O_O__O(root_424, arg_427, arg_428) } } else { var root_429 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any; var na_433 any = x__0; var na_434 any = y__1; var tmp4 bool; var tmp5 bool; tmp5 = jrt.Long_InstanceOf(na_433); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_434) }; tmp4 = tmp5; if tmp4 { var n0_435 int64 = jrt.NN(jrt.Long_Cast(na_433)).LongValue__J(); var n1_436 int64 = jrt.NN(jrt.Long_Cast(na_434)).LongValue__J(); var nr_437 int64 = n0_435 * n1_436; var tmp6 bool; var tmp7 bool; var tmp8 bool; var tmp9 bool; tmp9 = n0_435 == -9223372036854775808; if tmp9 { tmp9 = n1_436 < 0 }; tmp8 = tmp9; tmp7 = !tmp8; if tmp7 { var tmp10 bool; tmp10 = n1_436 == 0; if !tmp10 { tmp10 = nr_437/n1_436 == n0_435 }; tmp7 = tmp10 }; tmp6 = tmp7; if tmp6 { arg_432 = jrt.Long_ValueOf_J__Long_NoInit(nr_437).Ref() } else { arg_432 = lang.Numbers_Multiply_O_O__Number_NoInit(na_433, na_434) } } else { var tmp11 bool; var tmp12 bool; tmp12 = jrt.Double_InstanceOf(na_433); if tmp12 { tmp12 = jrt.Double_InstanceOf(na_434) }; tmp11 = tmp12; if tmp11 { var n0_435_2 float64 = jrt.NN(jrt.Double_Cast(na_433)).DoubleValue__D(); var n1_436_2 float64 = jrt.NN(jrt.Double_Cast(na_434)).DoubleValue__D(); arg_432 = jrt.Double_ValueOf_D__Double_NoInit(float64(n0_435_2 * n1_436_2)).Ref() } else { arg_432 = lang.Numbers_Multiply_O_O__Number_NoInit(na_433, na_434) } }; if linked_430 == nil { return ifn_431.Invoke_O__O(arg_432) } else { return linked_430.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_429, arg_432) } } } }
//line :171:1
func (t *A_arbace_go_check_const_fmul_A) InvokeSpec_O_J_O_J_O__O(self any, x__0_l int64, x__0_b any, y__1_l int64, y__1_b any) any { var tmp1 any; var or__1927000174__auto____3 any; var root_438 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_441 = x__0_b } else { arg_441 = x__0_b }; if linked_439 == nil { or__1927000174__auto____3 = ifn_440.Invoke_O__O(arg_441) } else { or__1927000174__auto____3 = linked_439.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_438, arg_441) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_442 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); arg_445 = y__1_b } else { arg_445 = y__1_b }; if linked_443 == nil { tmp1 = ifn_444.Invoke_O__O(arg_445) } else { tmp1 = linked_443.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_442, arg_445) } }; if jrt.J2g_Truth(tmp1) { var root_446 any = A_arbace_go_check_const_A_const_38.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, A_arbace_go_check_const_bf_mul_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_449 = x__0_b } else { arg_449 = x__0_b }; var arg_450 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); arg_450 = y__1_b } else { arg_450 = y__1_b }; if linked_447 == nil { return ifn_448.Invoke_O_O__O(arg_449, arg_450) } else { return linked_447.(*A_arbace_go_check_const_bf_mul_A).Invoke_O_O_O__O(root_446, arg_449, arg_450) } } else { var root_451 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any; var n0_455 int64 = x__0_l; var n1_456 int64 = y__1_l; var nr_457 int64 = n0_455 * n1_456; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = n0_455 == -9223372036854775808; if tmp5 { tmp5 = n1_456 < 0 }; tmp4 = tmp5; tmp3 = !tmp4; if tmp3 { var tmp6 bool; tmp6 = n1_456 == 0; if !tmp6 { tmp6 = nr_457/n1_456 == n0_455 }; tmp3 = tmp6 }; tmp2 = tmp3; if tmp2 { arg_454 = jrt.Long_ValueOf_J__Long_NoInit(nr_457).Ref() } else { var tmp7 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp7 = x__0_b } else { tmp7 = x__0_b }; var tmp8 any = tmp7; var tmp9 any; if y__1_b == nil { y__1_b = jrt.Long_ValueOf_J__Long_NoInit(y__1_l).Ref(); tmp9 = y__1_b } else { tmp9 = y__1_b }; arg_454 = lang.Numbers_Multiply_O_O__Number_NoInit(tmp8, tmp9) }; if linked_452 == nil { return ifn_453.Invoke_O__O(arg_454) } else { return linked_452.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_451, arg_454) } } }
func A_arbace_go_check_const_fquo_A_New() *A_arbace_go_check_const_fquo_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fquo_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_go_check_const_fquo_A) Ctor() {}
//line :172:1
func (t *A_arbace_go_check_const_fquo_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 any; var or__1927000174__auto____3 any; var root_458 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = x__0; if linked_459 == nil { or__1927000174__auto____3 = ifn_460.Invoke_O__O(arg_461) } else { or__1927000174__auto____3 = linked_459.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_458, arg_461) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_462 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = y__1; if linked_463 == nil { tmp1 = ifn_464.Invoke_O__O(arg_465) } else { tmp1 = linked_463.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_462, arg_465) } }; if jrt.J2g_Truth(tmp1) { var root_466 any = A_arbace_go_check_const_A_const_39.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, A_arbace_go_check_const_bf_quo_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = x__0; var arg_470 any = y__1; if linked_467 == nil { return ifn_468.Invoke_O_O__O(arg_469, arg_470) } else { return linked_467.(*A_arbace_go_check_const_bf_quo_A).Invoke_O_O_O__O(root_466, arg_469, arg_470) } } else { var root_471 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = lang.Numbers_Divide_O_O__Number_NoInit(x__0, y__1); if linked_472 == nil { return ifn_473.Invoke_O__O(arg_474) } else { return linked_472.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_471, arg_474) } } }
func A_arbace_go_check_const_fneg_A_New() *A_arbace_go_check_const_fneg_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fneg_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_go_check_const_fneg_A) Ctor() {}
//line :173:1
func (t *A_arbace_go_check_const_fneg_A) Invoke_O_O__O(self, x__0 any) any { var root_475 any = A_arbace_go_check_const_A_const_35.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_475, A_arbace_go_check_const_bf_neg_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = x__0; if linked_476 == nil { return ifn_477.Invoke_O__O(arg_478) } else { if jrt.Long_InstanceOf(arg_478) { return linked_476.(*A_arbace_go_check_const_bf_neg_A).InvokeSpec_O_J_O__O(root_475, jrt.NN(jrt.Long_Cast(arg_478)).LongValue__J(), arg_478) } else { return linked_476.(*A_arbace_go_check_const_bf_neg_A).Invoke_O_O__O(root_475, arg_478) } } }
func A_arbace_go_check_const_fsign_A_New() *A_arbace_go_check_const_fsign_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fsign_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_go_check_const_fsign_A) Ctor() {}
//line :174:1
func (t *A_arbace_go_check_const_fsign_A) InvokePrim_O_O__J(self, x__0 any) int64 { var tmp1 any; var root_479 any = A_arbace_go_check_const_A_const_33.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_479, A_arbace_go_check_const_bf_sign_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = x__0; if linked_480 == nil { tmp1 = ifn_481.Invoke_O__O(arg_482) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_480.(*A_arbace_go_check_const_bf_sign_A).InvokePrim_O_O__J(root_479, arg_482)).Ref() }; return jrt.Number_Cast(tmp1).LongValue__J() }
//line :174:1
func (t *A_arbace_go_check_const_fsign_A) Invoke_O_O__O(self, x__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, x__0)).Ref() }
func A_arbace_go_check_const_fcmp_A_New() *A_arbace_go_check_const_fcmp_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fcmp_A{}; t.Ctor(); return t }
//line :175:1
func (t *A_arbace_go_check_const_fcmp_A) Ctor() {}
//line :175:1
func (t *A_arbace_go_check_const_fcmp_A) InvokePrim_O_O_O__J(self, x__0, y__1 any) int64 { var tmp1 any; var tmp2 any; var or__1927000174__auto____3 any; var root_483 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = x__0; if linked_484 == nil { or__1927000174__auto____3 = ifn_485.Invoke_O__O(arg_486) } else { or__1927000174__auto____3 = linked_484.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_483, arg_486) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_487 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = y__1; if linked_488 == nil { tmp2 = ifn_489.Invoke_O__O(arg_490) } else { tmp2 = linked_488.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_487, arg_490) } }; if jrt.J2g_Truth(tmp2) { var root_491 any = A_arbace_go_check_const_A_const_40.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_491, A_arbace_go_check_const_bf_cmp_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = x__0; var arg_495 any = y__1; if linked_492 == nil { tmp1 = ifn_493.Invoke_O_O__O(arg_494, arg_495) } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(linked_492.(*A_arbace_go_check_const_bf_cmp_A).InvokePrim_O_O_O__J(root_491, arg_494, arg_495)).Ref() } } else { tmp1 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.Util_Compare_O_O__I_NoInit(x__0, y__1))).Ref() }; return jrt.Number_Cast(tmp1).LongValue__J() }
//line :175:1
func (t *A_arbace_go_check_const_fcmp_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O_O__J(self, x__0, y__1)).Ref() }
func A_arbace_go_check_const_fzero_QMARK__A_New() *A_arbace_go_check_const_fzero_QMARK__A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_fzero_QMARK__A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_go_check_const_fzero_QMARK__A) Ctor() {}
//line :176:1
func (t *A_arbace_go_check_const_fzero_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var tmp1 int64; var root_496 any = A_arbace_go_check_const_A_const_41.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_496, A_arbace_go_check_const_fsign_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = x__0; if linked_497 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_498.Invoke_O__O(arg_499)) } else { tmp1 = linked_497.(*A_arbace_go_check_const_fsign_A).InvokePrim_O_O__J(root_496, arg_499) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref() }

func A_arbace_go_check_const_int_val_A_New() *A_arbace_go_check_const_int_val_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_int_val_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_go_check_const_int_val_A) Ctor() {}
//line :178:1
func (t *A_arbace_go_check_const_int_val_A) Invoke_O_O__O(self, x__0 any) any {




	var tmp1 any; var root_500 any = A_arbace_go_check_const_A_const_36.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_502 lang.IFn
	if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = x__0; if linked_501 == nil { tmp1 = ifn_502.Invoke_O__O(arg_503) } else { tmp1 = linked_501.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_500, arg_503) }
//line :183:1
	if jrt.J2g_Truth(tmp1) { return x__0 } else { var tmp2 any; var root_504 any = A_arbace_go_check_const_A_const_21.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_506 lang.IFn

		if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = x__0; if linked_505 == nil { tmp2 = ifn_506.Invoke_O__O(arg_507) } else { tmp2 = linked_505.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_504, arg_507) }
//line :183:1
		if jrt.J2g_Truth(tmp2) { return nil } else { var tmp3 any; var root_508 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_510 lang.IFn


			if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = x__0; if linked_509 == nil { tmp3 = ifn_510.Invoke_O__O(arg_511) } else { tmp3 = linked_509.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_508, arg_511) }
//line :183:1
			if jrt.J2g_Truth(tmp3) { var e__2 any; var root_512 any = A_arbace_go_check_const_A_const_42.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_512, A_arbace_go_check_const_bf_exp_A_fn_class); var ifn_514 lang.IFn



				if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = x__0; if linked_513 == nil { e__2 = ifn_514.Invoke_O__O(arg_515) } else { e__2 = jrt.Long_ValueOf_J__Long_NoInit(linked_513.(*A_arbace_go_check_const_bf_exp_A).InvokePrim_O_O__J(root_512, arg_515)).Ref() }
				var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_const_A_const_43.GetRawRoot__O()); var tmp5 jrt.Number_I; var na_522 any = A_arbace_go_check_const_A_const_28.GetRawRoot__O(); if jrt.Long_InstanceOf(na_522) { var n0_523 int64 = jrt.NN(jrt.Long_Cast(na_522)).LongValue__J(); if n0_523 == -9223372036854775808 { tmp5 = lang.Numbers_Minus_O__Number_NoInit(na_522) } else { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(-n0_523)) } } else { if jrt.Double_InstanceOf(na_522) { var n0_523_2 float64 = jrt.NN(jrt.Double_Cast(na_522)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(-n0_523_2)) } else { tmp5 = lang.Numbers_Minus_O__Number_NoInit(na_522) } }; if jrt.J2g_Truth(tmp4.Invoke_O_O_O__O(tmp5, e__2, A_arbace_go_check_const_A_const_28.GetRawRoot__O())) { var vec__161000079__3 any = x__0; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000079__3, lang.RT_IntCast_J__I_NoInit(0), nil); var m__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000079__3, lang.RT_IntCast_J__I_NoInit(1), nil); var ee__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000079__3, lang.RT_IntCast_J__I_NoInit(2), nil); var ee__7 int64 = lang.RT_LongCast_O__J_NoInit(ee__6); _ = ___4


					if lang.Numbers_Gte_J_J__Z_NoInit(ee__7, 0) {
						var root_524 any = A_arbace_go_check_const_A_const_44.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, A_arbace_go_check_const_norm_int_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = jrt.NN(jrt.BigInteger_Cast(m__5)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(ee__7)).Ref(); if linked_525 == nil { return ifn_526.Invoke_O__O(arg_527) } else { return linked_525.(*A_arbace_go_check_const_norm_int_A).Invoke_O_O__O(root_524, arg_527) } } else {
//line :191:1
							var p__8 any; var na_528 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O()
							var na_529 int64 = 4

							if jrt.Long_InstanceOf(na_528) { var n0_530 int64 = jrt.NN(jrt.Long_Cast(na_528)).LongValue__J(); var n1_531 int64 = na_529; var nr_532 int64 = n0_530 - n1_531; var tmp6 bool; var tmp7 bool; tmp7 = !(n1_531 == -9223372036854775808); if tmp7 { tmp7 = (n0_530^n1_531)&(n0_530^nr_532) >= 0 }; tmp6 = tmp7; if tmp6 { p__8 = jrt.Long_ValueOf_J__Long_NoInit(nr_532).Ref() } else { p__8 = lang.Numbers_Minus_O_J__Number_NoInit(na_528, na_529) } } else { p__8 = lang.Numbers_Minus_O_J__Number_NoInit(na_528, na_529) }
//line :191:1
							var n__9 int32 = jrt.NN(jrt.NN(jrt.BigInteger_Cast(m__5)).Abs__BigInteger()).BitLength__I(); var try_round__10 any; var tmp8 any = A_arbace_go_check_const_int_val_try_round__161000082_A_New_I_O_O_J(n__9, m__5, p__8, ee__7); var tmp9 *jrt.Class
							var fncls__557 /*line :191:1*/*jrt.Class = A_arbace_go_check_const_int_val_try_round__161000082_A_fn_class




							if fncls__557 == nil { var fncls__557d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_go_check_const_int_val_try_round__161000082_A_fn_class = fncls__557d; tmp9 = fncls__557d } else { tmp9 = fncls__557 }; try_round__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)
//line :191:1
							var or__1927000174__auto____11 any = lang.IFn_Cast(try_round__10).Invoke_O__O(jrt.Boolean_FALSE.Ref())















							if jrt.J2g_Truth(or__1927000174__auto____11) { return or__1927000174__auto____11 } else { return lang.IFn_Cast(try_round__10).Invoke_O__O(jrt.Boolean_TRUE.Ref()) } } } else {
//line :188:1
								return nil } } else {
//line :183:1
									if A_arbace_go_check_const_A_const_8 != nil { return nil } else { return nil
									}
								}
		}
	}
}







func A_arbace_go_check_const_int_val_try_round__161000082_A_New_I_O_O_J(p0 int32, p1, p2 any, p3 int64) *A_arbace_go_check_const_int_val_try_round__161000082_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_int_val_try_round__161000082_A{}; t.Ctor_I_O_O_J(p0, p1, p2, p3); return t }
//line :196:1
func (t *A_arbace_go_check_const_int_val_try_round__161000082_A) Ctor_I_O_O_J(c__n int32, c__m, c__p any, c__ee int64) { t.F_n = c__n; t.F_m = c__m; t.F_p = c__p; t.F_ee = c__ee }
//line :196:1
func (t *A_arbace_go_check_const_int_val_try_round__161000082_A) Invoke_O_O__O(self, up_QMARK___1 any) any {
	var tmp1 bool; var na_533 int64 = int64(t.F_n); var na_534 any = t.F_p; if jrt.Long_InstanceOf(na_534) { var n0_535 int64 = na_533; var n1_536 int64 = jrt.NN(jrt.Long_Cast(na_534)).LongValue__J(); tmp1 = n0_535 <= n1_536 } else { tmp1 = lang.Numbers_Lte_J_O__Z_NoInit(na_533, na_534) }; if tmp1 { return nil } else { var sh__2 any; var na_538 int64 = int64(t.F_n); var na_539 any = t.F_p

		if jrt.Long_InstanceOf(na_539) { var n0_540 int64 = na_538; var n1_541 int64 = jrt.NN(jrt.Long_Cast(na_539)).LongValue__J(); var nr_542 int64 = n0_540 - n1_541; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_541 == -9223372036854775808); if tmp3 { tmp3 = (n0_540^n1_541)&(n0_540^nr_542) >= 0 }; tmp2 = tmp3; if tmp2 { sh__2 = jrt.Long_ValueOf_J__Long_NoInit(nr_542).Ref() } else { sh__2 = lang.Numbers_Minus_J_O__Number_NoInit(na_538, na_539) } } else { sh__2 = lang.Numbers_Minus_J_O__Number_NoInit(na_538, na_539) }
//line :197:1
		var a__3 any = jrt.NN(jrt.BigInteger_Cast(t.F_m)).Abs__BigInteger().Ref(); var q__4 any = jrt.NN(jrt.BigInteger_Cast(a__3)).ShiftRight_I__BigInteger(lang.RT_IntCast_O__I_NoInit(sh__2)).Ref(); var q__5 any




		if jrt.J2g_Truth(up_QMARK___1) { var tmp4 *jrt.BigInteger = jrt.BigInteger_Cast(q__4); var tmp5 *jrt.BigInteger; jrt.BigInteger_Init(); tmp5 = jrt.BigInteger_ONE; q__5 = jrt.NN(tmp4).Add_BigInteger__BigInteger(tmp5).Ref() } else { q__5 = q__4 }
//line :197:1
		var ve__6 any; var na_543 int64 = t.F_ee
		var na_544 any = sh__2




		if jrt.Long_InstanceOf(na_544) { var n0_545 int64 = na_543; var n1_546 int64 = jrt.NN(jrt.Long_Cast(na_544)).LongValue__J(); var nr_547 int64 = n0_545 + n1_546; if (n0_545^nr_547)&(n1_546^nr_547) >= 0 { ve__6 = jrt.Long_ValueOf_J__Long_NoInit(nr_547).Ref() } else { ve__6 = lang.Numbers_Add_J_O__Number_NoInit(na_543, na_544) } } else { ve__6 = lang.Numbers_Add_J_O__Number_NoInit(na_543, na_544) }
		var tmp6 bool; var na_548 any = ve__6; var na_549 int64 = 0; if jrt.Long_InstanceOf(na_548) { var n0_550 int64 = jrt.NN(jrt.Long_Cast(na_548)).LongValue__J(); var n1_551 int64 = na_549; tmp6 = n0_550 >= n1_551 } else { tmp6 = lang.Numbers_Gte_O_J__Z_NoInit(na_548, na_549) }; if tmp6 { var v__7 any = jrt.NN(jrt.BigInteger_Cast(q__5)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(ve__6)).Ref(); var root_553 any = A_arbace_go_check_const_A_const_44.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, A_arbace_go_check_const_norm_int_A_fn_class); var ifn_555 lang.IFn

			if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any; if lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(t.F_m)).Signum__I())) { arg_556 = jrt.NN(jrt.BigInteger_Cast(v__7)).Negate__BigInteger().Ref() } else { arg_556 = v__7 }; if linked_554 == nil { return ifn_555.Invoke_O__O(arg_556) } else { return linked_554.(*A_arbace_go_check_const_norm_int_A).Invoke_O_O__O(root_553, arg_556) } } else {
//line :204:1
				return nil
			}
	}
}




func A_arbace_go_check_const_round_binary_A_New() *A_arbace_go_check_const_round_binary_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_round_binary_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_go_check_const_round_binary_A) Ctor() {}
//line :212:1
func (t *A_arbace_go_check_const_round_binary_A) Invoke_O_O_O_O_O__O(self, x__0, mbits__1, emin__2, emax__3 any) any { var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(mbits__1); if tmp2 { tmp2 = jrt.Long_InstanceOf(emax__3) }; tmp1 = tmp2; if tmp1 { return t.InvokeSpec_O_O_J_O_O_J_O__O(self, x__0, jrt.NN(jrt.Long_Cast(mbits__1)).LongValue__J(), mbits__1, emin__2, jrt.NN(jrt.Long_Cast(emax__3)).LongValue__J(), emax__3) } else { var r__5 any; var tmp3 any; var root_558 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_560 lang.IFn




	if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = x__0; if linked_559 == nil { tmp3 = ifn_560.Invoke_O__O(arg_561) } else { tmp3 = linked_559.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_558, arg_561) }; if jrt.J2g_Truth(tmp3) { var root_562 any = A_arbace_go_check_const_A_const_45.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, A_arbace_go_check_const_bf__GT_rat_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = x__0; if linked_563 == nil { r__5 = ifn_564.Invoke_O__O(arg_565) } else { r__5 = linked_563.(*A_arbace_go_check_const_bf__GT_rat_A).Invoke_O_O__O(root_562, arg_565) } } else { r__5 = x__0 }
//line :212:1
	var vec__161000085__6 any; var root_566 any = A_arbace_go_check_const_A_const_24.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, A_arbace_go_check_const_rat_num_den_A_fn_class); var ifn_568 lang.IFn





	if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = r__5; if linked_567 == nil { vec__161000085__6 = ifn_568.Invoke_O__O(arg_569) } else { vec__161000085__6 = linked_567.(*A_arbace_go_check_const_rat_num_den_A).Invoke_O_O__O(root_566, arg_569) }
//line :212:1
	var p__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000085__6, lang.RT_IntCast_J__I_NoInit(0), nil); var q__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000085__6, lang.RT_IntCast_J__I_NoInit(1), nil)






	if lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__7)).Signum__I())) { return A_arbace_go_check_const_A_const_17 } else { var neg__9 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__7)).Signum__I())); var p__10 any = jrt.NN(jrt.BigInteger_Cast(p__7)).Abs__BigInteger().Ref(); var e0__11 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__10)).BitLength__I()), int64(jrt.NN(jrt.BigInteger_Cast(q__8)).BitLength__I())); var e__12 int64





		if lang.Numbers_Gte_J_J__Z_NoInit(e0__11, 0) {
			if lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__10)).CompareTo_BigInteger__I(jrt.NN(jrt.BigInteger_Cast(q__8)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(e0__11))))) { e__12 = lang.Numbers_Dec_J__J_NoInit(e0__11) } else { e__12 = e0__11 } } else {
				if lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(p__10)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J__J_NoInit(e0__11)))).CompareTo_BigInteger__I(jrt.BigInteger_Cast(q__8)))) { e__12 = lang.Numbers_Dec_J__J_NoInit(e0__11) } else { e__12 = e0__11 } }
//line :219:1
		var qe__13 any; var na_570 any = lang.Numbers_Max_J_O__O_NoInit(e__12, emin__2); var na_571 any
		var na_572 any = mbits__1








		if jrt.Long_InstanceOf(na_572) { var n0_573 int64 = jrt.NN(jrt.Long_Cast(na_572)).LongValue__J(); if n0_573 == -9223372036854775808 { na_571 = lang.Numbers_Dec_O__Number_NoInit(na_572) } else { na_571 = jrt.Long_ValueOf_J__Long_NoInit(n0_573 - 1).Ref() } } else { if jrt.Double_InstanceOf(na_572) { var n0_573_2 float64 = jrt.NN(jrt.Double_Cast(na_572)).DoubleValue__D(); na_571 = jrt.Double_ValueOf_D__Double_NoInit(n0_573_2 - 1.0).Ref() } else { na_571 = lang.Numbers_Dec_O__Number_NoInit(na_572) } }; var tmp4 bool; var tmp5 bool; tmp5 = jrt.Long_InstanceOf(na_570); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_571) }; tmp4 = tmp5; if tmp4 { var n0_574 int64 = jrt.NN(jrt.Long_Cast(na_570)).LongValue__J(); var n1_575 int64 = jrt.NN(jrt.Long_Cast(na_571)).LongValue__J(); var nr_576 int64 = n0_574 - n1_575; var tmp6 bool; var tmp7 bool; tmp7 = !(n1_575 == -9223372036854775808); if tmp7 { tmp7 = (n0_574^n1_575)&(n0_574^nr_576) >= 0 }; tmp6 = tmp7; if tmp6 { qe__13 = jrt.Long_ValueOf_J__Long_NoInit(nr_576).Ref() } else { qe__13 = lang.Numbers_Minus_O_O__Number_NoInit(na_570, na_571) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_570); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_571) }; tmp8 = tmp9; if tmp8 { var n0_574_2 float64 = jrt.NN(jrt.Double_Cast(na_570)).DoubleValue__D(); var n1_575_2 float64 = jrt.NN(jrt.Double_Cast(na_571)).DoubleValue__D(); qe__13 = jrt.Double_ValueOf_D__Double_NoInit(n0_574_2 + -n1_575_2).Ref() } else { qe__13 = lang.Numbers_Minus_O_O__Number_NoInit(na_570, na_571) } }
//line :219:1
		var vec__161000088__14 any; var tmp10 bool
		var na_577 any = qe__13










		if jrt.Long_InstanceOf(na_577) { var n0_578 int64 = jrt.NN(jrt.Long_Cast(na_577)).LongValue__J(); tmp10 = n0_578 < 0 } else { if jrt.Double_InstanceOf(na_577) { var n0_578_2 float64 = jrt.NN(jrt.Double_Cast(na_577)).DoubleValue__D(); tmp10 = n0_578_2 < 0.0 } else { tmp10 = lang.Numbers_IsNeg_O__Z_NoInit(na_577) } }; if tmp10 { var tmp11 *jrt.BigInteger = jrt.BigInteger_Cast(p__10); var tmp12 jrt.Number_I; var na_628 any = qe__13; if jrt.Long_InstanceOf(na_628) { var n0_629 int64 = jrt.NN(jrt.Long_Cast(na_628)).LongValue__J(); if n0_629 == -9223372036854775808 { tmp12 = lang.Numbers_Minus_O__Number_NoInit(na_628) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(-n0_629)) } } else { if jrt.Double_InstanceOf(na_628) { var n0_629_2 float64 = jrt.NN(jrt.Double_Cast(na_628)).DoubleValue__D(); tmp12 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(-n0_629_2)) } else { tmp12 = lang.Numbers_Minus_O__Number_NoInit(na_628) } }; vec__161000088__14 = lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(tmp11).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(tmp12)).Ref(), q__8) } else { vec__161000088__14 = lang.Tuple_Create_O_O__IPersistentVector(p__10, jrt.NN(jrt.BigInteger_Cast(q__8)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(qe__13)).Ref()) }
//line :219:1
		var num__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000088__14, lang.RT_IntCast_J__I_NoInit(0), nil); var den__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000088__14, lang.RT_IntCast_J__I_NoInit(1), nil); var dr__17 any = jrt.NN(jrt.BigInteger_Cast(num__15)).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(den__16)).Ref(); var m__18 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__17, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)); var rm__19 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__17, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)); var c__20 int32 = jrt.NN(jrt.NN(jrt.BigInteger_Cast(rm__19)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(1))).CompareTo_BigInteger__I(jrt.BigInteger_Cast(den__16)); var m__21 any; var tmp13 bool; var or__1927000174__auto____21 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(c__20))















		if or__1927000174__auto____21 { tmp13 = or__1927000174__auto____21 } else { var and__1927000168__auto____22 bool = lang.Numbers_IsZero_J__Z_NoInit(int64(c__20)); if and__1927000168__auto____22 { tmp13 = jrt.NN(jrt.BigInteger_Cast(m__18)).TestBit_I__Z(lang.RT_IntCast_J__I_NoInit(0)) } else { tmp13 = and__1927000168__auto____22 } }; if tmp13 { var tmp14 *jrt.BigInteger = jrt.BigInteger_Cast(m__18); var tmp15 *jrt.BigInteger; jrt.BigInteger_Init(); tmp15 = jrt.BigInteger_ONE; m__21 = jrt.NN(tmp14).Add_BigInteger__BigInteger(tmp15).Ref() } else { m__21 = m__18 }
//line :219:1
		var top__22 any; var na_579 any; var na_581 any = qe__13; var na_582 int64 = int64(jrt.NN(jrt.BigInteger_Cast(m__21)).BitLength__I())

















		if jrt.Long_InstanceOf(na_581) { var n0_583 int64 = jrt.NN(jrt.Long_Cast(na_581)).LongValue__J(); var n1_584 int64 = na_582; var nr_585 int64 = n0_583 + n1_584; if (n0_583^nr_585)&(n1_584^nr_585) >= 0 { na_579 = jrt.Long_ValueOf_J__Long_NoInit(nr_585).Ref() } else { na_579 = lang.Numbers_Add_O_J__Number_NoInit(na_581, na_582) } } else { na_579 = lang.Numbers_Add_O_J__Number_NoInit(na_581, na_582) }; var na_580 int64 = -1; if jrt.Long_InstanceOf(na_579) { var n0_586 int64 = jrt.NN(jrt.Long_Cast(na_579)).LongValue__J(); var n1_587 int64 = na_580; var nr_588 int64 = n0_586 + n1_587; if (n0_586^nr_588)&(n1_587^nr_588) >= 0 { top__22 = jrt.Long_ValueOf_J__Long_NoInit(nr_588).Ref() } else { top__22 = lang.Numbers_Add_O_J__Number_NoInit(na_579, na_580) } } else { top__22 = lang.Numbers_Add_O_J__Number_NoInit(na_579, na_580) }
		var tmp16 bool; var na_589 any = top__22; var na_590 any = emax__3; var tmp17 bool; var tmp18 bool; tmp18 = jrt.Long_InstanceOf(na_589); if tmp18 { tmp18 = jrt.Long_InstanceOf(na_590) }; tmp17 = tmp18; if tmp17 { var n0_591 int64 = jrt.NN(jrt.Long_Cast(na_589)).LongValue__J(); var n1_592 int64 = jrt.NN(jrt.Long_Cast(na_590)).LongValue__J(); tmp16 = n0_591 > n1_592 } else { var tmp19 bool; var tmp20 bool; tmp20 = jrt.Double_InstanceOf(na_589); if tmp20 { tmp20 = jrt.Double_InstanceOf(na_590) }; tmp19 = tmp20; if tmp19 { var n0_591_2 float64 = jrt.NN(jrt.Double_Cast(na_589)).DoubleValue__D(); var n1_592_2 float64 = jrt.NN(jrt.Double_Cast(na_590)).DoubleValue__D(); tmp16 = n1_592_2 < n0_591_2 } else { tmp16 = lang.Numbers_Gt_O_O__Z_NoInit(na_589, na_590) } }; if tmp16 { return nil } else { var v__23 any; var tmp21 bool
			var na_594 any = qe__13
			if jrt.Long_InstanceOf(na_594) { var n0_595 int64 = jrt.NN(jrt.Long_Cast(na_594)).LongValue__J(); tmp21 = n0_595 < 0 } else { if jrt.Double_InstanceOf(na_594) { var n0_595_2 float64 = jrt.NN(jrt.Double_Cast(na_594)).DoubleValue__D(); tmp21 = n0_595_2 < 0.0 } else { tmp21 = lang.Numbers_IsNeg_O__Z_NoInit(na_594) } }; if tmp21 {
				var tmp22 any; var root_596 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = m__21; if linked_597 == nil { tmp22 = ifn_598.Invoke_O__O(arg_599) } else { tmp22 = linked_597.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_596, arg_599) }; var tmp23 any = tmp22; var tmp24 any; var root_600 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any; var root_604 any = A_arbace_go_check_const_A_const_26.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_604, A_arbace_go_check_const_pow2_A_fn_class); var ifn_606 lang.IFn; if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any; var na_608 any = qe__13; if jrt.Long_InstanceOf(na_608) { var n0_609 int64 = jrt.NN(jrt.Long_Cast(na_608)).LongValue__J(); if n0_609 == -9223372036854775808 { arg_607 = lang.Numbers_Minus_O__Number_NoInit(na_608) } else { arg_607 = jrt.Long_ValueOf_J__Long_NoInit(-n0_609).Ref() } } else { if jrt.Double_InstanceOf(na_608) { var n0_609_2 float64 = jrt.NN(jrt.Double_Cast(na_608)).DoubleValue__D(); arg_607 = jrt.Double_ValueOf_D__Double_NoInit(-n0_609_2).Ref() } else { arg_607 = lang.Numbers_Minus_O__Number_NoInit(na_608) } }; if linked_605 == nil { arg_603 = ifn_606.Invoke_O__O(arg_607) } else { arg_603 = linked_605.(*A_arbace_go_check_const_pow2_A).Invoke_O_O__O(root_604, arg_607) }; if linked_601 == nil { tmp24 = ifn_602.Invoke_O__O(arg_603) } else { tmp24 = linked_601.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_600, arg_603) }; v__23 = lang.Numbers_Divide_O_O__Number_NoInit(tmp23, tmp24) } else {
					var root_610 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = jrt.NN(jrt.BigInteger_Cast(m__21)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(qe__13)).Ref(); if linked_611 == nil { v__23 = ifn_612.Invoke_O__O(arg_613) } else { v__23 = linked_611.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_610, arg_613) } }
//line :238:1
			var v__24 any; var tmp25 any; var root_614 any = A_arbace_go_check_const_A_const_21.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_616 lang.IFn




			if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = v__23; if linked_615 == nil { tmp25 = ifn_616.Invoke_O__O(arg_617) } else { tmp25 = linked_615.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_614, arg_617) }; if jrt.J2g_Truth(tmp25) { v__24 = v__23 } else { var root_618 any = A_arbace_go_check_const_A_const_44.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, A_arbace_go_check_const_norm_int_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any; var root_622 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, A_arbace_go_check_const_bi_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = v__23; if linked_623 == nil { arg_621 = ifn_624.Invoke_O__O(arg_625) } else { arg_621 = linked_623.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_622, arg_625) }; if linked_619 == nil { v__24 = ifn_620.Invoke_O__O(arg_621) } else { v__24 = linked_619.(*A_arbace_go_check_const_norm_int_A).Invoke_O_O__O(root_618, arg_621) } }
			if neg__9 { var na_626 any = v__24; if jrt.Long_InstanceOf(na_626) { var n0_627 int64 = jrt.NN(jrt.Long_Cast(na_626)).LongValue__J(); if n0_627 == -9223372036854775808 { return lang.Numbers_Minus_O__Number_NoInit(na_626) } else { return jrt.Long_ValueOf_J__Long_NoInit(-n0_627).Ref() } } else { if jrt.Double_InstanceOf(na_626) { var n0_627_2 float64 = jrt.NN(jrt.Double_Cast(na_626)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(-n0_627_2).Ref() } else { return lang.Numbers_Minus_O__Number_NoInit(na_626) } } } else { return v__24 } } } } }
//line :212:1
func (t *A_arbace_go_check_const_round_binary_A) InvokeSpec_O_O_J_O_O_J_O__O(self, x__0 any, mbits__1_l int64, mbits__1_b, emin__2 any, emax__3_l int64, emax__3_b any) any { var r__5 any; var tmp1 any; var root_630 any = A_arbace_go_check_const_A_const_31.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, A_arbace_go_check_const_bf_QMARK__A_fn_class); var ifn_632 lang.IFn; if




	linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = x__0; if linked_631 == nil { tmp1 = ifn_632.Invoke_O__O(arg_633) } else { tmp1 = linked_631.(*A_arbace_go_check_const_bf_QMARK__A).Invoke_O_O__O(root_630, arg_633) }; if jrt.J2g_Truth(tmp1) { var root_634 any = A_arbace_go_check_const_A_const_45.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, A_arbace_go_check_const_bf__GT_rat_A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = x__0; if linked_635 == nil { r__5 = ifn_636.Invoke_O__O(arg_637) } else { r__5 = linked_635.(*A_arbace_go_check_const_bf__GT_rat_A).Invoke_O_O__O(root_634, arg_637) } } else { r__5 = x__0 }; var vec__161000085__6 any; var root_638 any = /*line :212:1*/A_arbace_go_check_const_A_const_24.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, A_arbace_go_check_const_rat_num_den_A_fn_class); var ifn_640 lang.IFn; if





	linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = r__5; if linked_639 == nil { vec__161000085__6 = ifn_640.Invoke_O__O(arg_641) } else { vec__161000085__6 = linked_639.(*A_arbace_go_check_const_rat_num_den_A).Invoke_O_O__O(root_638, arg_641) }; var p__7 any = /*line :212:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__161000085__6, lang.RT_IntCast_J__I_NoInit(0), nil); var q__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000085__6, lang.RT_IntCast_J__I_NoInit(1), nil); if






	lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__7)).Signum__I())) { return A_arbace_go_check_const_A_const_17 } else { var neg__9 bool = lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__7)).Signum__I())); var p__10 any = jrt.NN(jrt.BigInteger_Cast(p__7)).Abs__BigInteger().Ref(); var e0__11 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__10)).BitLength__I()), int64(jrt.NN(jrt.BigInteger_Cast(q__8)).BitLength__I())); var e__12 int64





		if lang.Numbers_Gte_J_J__Z_NoInit(e0__11, 0) {
			if lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(p__10)).CompareTo_BigInteger__I(jrt.NN(jrt.BigInteger_Cast(q__8)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(e0__11))))) { e__12 = lang.Numbers_Dec_J__J_NoInit(e0__11) } else { e__12 = e0__11 } } else {
				if lang.Numbers_IsNeg_J__Z_NoInit(int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(p__10)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J__J_NoInit(e0__11)))).CompareTo_BigInteger__I(jrt.BigInteger_Cast(q__8)))) { e__12 = lang.Numbers_Dec_J__J_NoInit(e0__11) } else { e__12 = e0__11 } }
//line :219:1
		var qe__13 any; var na_642 any = lang.Numbers_Max_J_O__O_NoInit(e__12, emin__2); var na_643 any
		var n0_644 int64 = mbits__1_l








		if n0_644 == -9223372036854775808 { var tmp2 any; if mbits__1_b == nil { mbits__1_b = jrt.Long_ValueOf_J__Long_NoInit(mbits__1_l).Ref(); tmp2 = mbits__1_b } else { tmp2 = mbits__1_b }; na_643 = lang.Numbers_Dec_O__Number_NoInit(tmp2) } else { na_643 = jrt.Long_ValueOf_J__Long_NoInit(n0_644 - 1).Ref() }; var tmp3 bool; var tmp4 bool; tmp4 = jrt.Long_InstanceOf(na_642); if tmp4 { tmp4 = jrt.Long_InstanceOf(na_643) }; tmp3 = tmp4; if tmp3 { var n0_645 int64 = jrt.NN(jrt.Long_Cast(na_642)).LongValue__J(); var n1_646 int64 = jrt.NN(jrt.Long_Cast(na_643)).LongValue__J(); var nr_647 int64 = n0_645 - n1_646; var tmp5 bool; var tmp6 bool; tmp6 = !(n1_646 == -9223372036854775808); if tmp6 { tmp6 = (n0_645^n1_646)&(n0_645^nr_647) >= 0 }; tmp5 = tmp6; if tmp5 { qe__13 = jrt.Long_ValueOf_J__Long_NoInit(nr_647).Ref() } else { qe__13 = lang.Numbers_Minus_O_O__Number_NoInit(na_642, na_643) } } else { var tmp7 bool; var tmp8 bool; tmp8 = jrt.Double_InstanceOf(na_642); if tmp8 { tmp8 = jrt.Double_InstanceOf(na_643) }; tmp7 = tmp8; if tmp7 { var n0_645_2 float64 = jrt.NN(jrt.Double_Cast(na_642)).DoubleValue__D(); var n1_646_2 float64 = jrt.NN(jrt.Double_Cast(na_643)).DoubleValue__D(); qe__13 = jrt.Double_ValueOf_D__Double_NoInit(n0_645_2 + -n1_646_2).Ref() } else { qe__13 = lang.Numbers_Minus_O_O__Number_NoInit(na_642, na_643) } }
//line :219:1
		var vec__161000088__14 any; var tmp9 bool
		var na_648 any = qe__13










		if jrt.Long_InstanceOf(na_648) { var n0_649 int64 = jrt.NN(jrt.Long_Cast(na_648)).LongValue__J(); tmp9 = n0_649 < 0 } else { if jrt.Double_InstanceOf(na_648) { var n0_649_2 float64 = jrt.NN(jrt.Double_Cast(na_648)).DoubleValue__D(); tmp9 = n0_649_2 < 0.0 } else { tmp9 = lang.Numbers_IsNeg_O__Z_NoInit(na_648) } }; if tmp9 { var tmp10 *jrt.BigInteger = jrt.BigInteger_Cast(p__10); var tmp11 jrt.Number_I; var na_698 any = qe__13; if jrt.Long_InstanceOf(na_698) { var n0_699 int64 = jrt.NN(jrt.Long_Cast(na_698)).LongValue__J(); if n0_699 == -9223372036854775808 { tmp11 = lang.Numbers_Minus_O__Number_NoInit(na_698) } else { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(-n0_699)) } } else { if jrt.Double_InstanceOf(na_698) { var n0_699_2 float64 = jrt.NN(jrt.Double_Cast(na_698)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(-n0_699_2)) } else { tmp11 = lang.Numbers_Minus_O__Number_NoInit(na_698) } }; vec__161000088__14 = lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(tmp10).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(tmp11)).Ref(), q__8) } else { vec__161000088__14 = lang.Tuple_Create_O_O__IPersistentVector(p__10, jrt.NN(jrt.BigInteger_Cast(q__8)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(qe__13)).Ref()) }
//line :219:1
		var num__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000088__14, lang.RT_IntCast_J__I_NoInit(0), nil); var den__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000088__14, lang.RT_IntCast_J__I_NoInit(1), nil); var dr__17 any = jrt.NN(jrt.BigInteger_Cast(num__15)).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(den__16)).Ref(); var m__18 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__17, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)); var rm__19 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__17, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)); var c__20 int32 = jrt.NN(jrt.NN(jrt.BigInteger_Cast(rm__19)).ShiftLeft_I__BigInteger(lang.RT_IntCast_J__I_NoInit(1))).CompareTo_BigInteger__I(jrt.BigInteger_Cast(den__16)); var m__21 any; var tmp12 bool; var or__1927000174__auto____21 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(c__20))















		if or__1927000174__auto____21 { tmp12 = or__1927000174__auto____21 } else { var and__1927000168__auto____22 bool = lang.Numbers_IsZero_J__Z_NoInit(int64(c__20)); if and__1927000168__auto____22 { tmp12 = jrt.NN(jrt.BigInteger_Cast(m__18)).TestBit_I__Z(lang.RT_IntCast_J__I_NoInit(0)) } else { tmp12 = and__1927000168__auto____22 } }; if tmp12 { var tmp13 *jrt.BigInteger = jrt.BigInteger_Cast(m__18); var tmp14 *jrt.BigInteger; jrt.BigInteger_Init(); tmp14 = jrt.BigInteger_ONE; m__21 = jrt.NN(tmp13).Add_BigInteger__BigInteger(tmp14).Ref() } else { m__21 = m__18 }
//line :219:1
		var top__22 any; var na_650 any; var na_652 any = qe__13; var na_653 int64 = int64(jrt.NN(jrt.BigInteger_Cast(m__21)).BitLength__I())

















		if jrt.Long_InstanceOf(na_652) { var n0_654 int64 = jrt.NN(jrt.Long_Cast(na_652)).LongValue__J(); var n1_655 int64 = na_653; var nr_656 int64 = n0_654 + n1_655; if (n0_654^nr_656)&(n1_655^nr_656) >= 0 { na_650 = jrt.Long_ValueOf_J__Long_NoInit(nr_656).Ref() } else { na_650 = lang.Numbers_Add_O_J__Number_NoInit(na_652, na_653) } } else { na_650 = lang.Numbers_Add_O_J__Number_NoInit(na_652, na_653) }; var na_651 int64 = -1; if jrt.Long_InstanceOf(na_650) { var n0_657 int64 = jrt.NN(jrt.Long_Cast(na_650)).LongValue__J(); var n1_658 int64 = na_651; var nr_659 int64 = n0_657 + n1_658; if (n0_657^nr_659)&(n1_658^nr_659) >= 0 { top__22 = jrt.Long_ValueOf_J__Long_NoInit(nr_659).Ref() } else { top__22 = lang.Numbers_Add_O_J__Number_NoInit(na_650, na_651) } } else { top__22 = lang.Numbers_Add_O_J__Number_NoInit(na_650, na_651) }
		var tmp15 bool; var na_660 any = top__22; if jrt.Long_InstanceOf(na_660) { var n0_661 int64 = jrt.NN(jrt.Long_Cast(na_660)).LongValue__J(); var n1_662 int64 = emax__3_l; tmp15 = n0_661 > n1_662 } else { var tmp16 any; if emax__3_b == nil { emax__3_b = jrt.Long_ValueOf_J__Long_NoInit(emax__3_l).Ref(); tmp16 = emax__3_b } else { tmp16 = emax__3_b }; tmp15 = lang.Numbers_Gt_O_O__Z_NoInit(na_660, tmp16) }; if tmp15 { return nil } else { var v__23 any; var tmp17 bool
			var na_664 any = qe__13
			if jrt.Long_InstanceOf(na_664) { var n0_665 int64 = jrt.NN(jrt.Long_Cast(na_664)).LongValue__J(); tmp17 = n0_665 < 0 } else { if jrt.Double_InstanceOf(na_664) { var n0_665_2 float64 = jrt.NN(jrt.Double_Cast(na_664)).DoubleValue__D(); tmp17 = n0_665_2 < 0.0 } else { tmp17 = lang.Numbers_IsNeg_O__Z_NoInit(na_664) } }; if tmp17 {
				var tmp18 any; var root_666 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any = m__21; if linked_667 == nil { tmp18 = ifn_668.Invoke_O__O(arg_669) } else { tmp18 = linked_667.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_666, arg_669) }; var tmp19 any = tmp18; var tmp20 any; var root_670 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any; var root_674 any = A_arbace_go_check_const_A_const_26.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, A_arbace_go_check_const_pow2_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any; var na_678 any = qe__13; if jrt.Long_InstanceOf(na_678) { var n0_679 int64 = jrt.NN(jrt.Long_Cast(na_678)).LongValue__J(); if n0_679 == -9223372036854775808 { arg_677 = lang.Numbers_Minus_O__Number_NoInit(na_678) } else { arg_677 = jrt.Long_ValueOf_J__Long_NoInit(-n0_679).Ref() } } else { if jrt.Double_InstanceOf(na_678) { var n0_679_2 float64 = jrt.NN(jrt.Double_Cast(na_678)).DoubleValue__D(); arg_677 = jrt.Double_ValueOf_D__Double_NoInit(-n0_679_2).Ref() } else { arg_677 = lang.Numbers_Minus_O__Number_NoInit(na_678) } }; if linked_675 == nil { arg_673 = ifn_676.Invoke_O__O(arg_677) } else { arg_673 = linked_675.(*A_arbace_go_check_const_pow2_A).Invoke_O_O__O(root_674, arg_677) }; if linked_671 == nil { tmp20 = ifn_672.Invoke_O__O(arg_673) } else { tmp20 = linked_671.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_670, arg_673) }; v__23 = lang.Numbers_Divide_O_O__Number_NoInit(tmp19, tmp20) } else {
					var root_680 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any = jrt.NN(jrt.BigInteger_Cast(m__21)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(qe__13)).Ref(); if linked_681 == nil { v__23 = ifn_682.Invoke_O__O(arg_683) } else { v__23 = linked_681.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_680, arg_683) } }
//line :238:1
			var v__24 any; var tmp21 any; var root_684 any = A_arbace_go_check_const_A_const_21.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_686 lang.IFn




			if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = v__23; if linked_685 == nil { tmp21 = ifn_686.Invoke_O__O(arg_687) } else { tmp21 = linked_685.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_684, arg_687) }; if jrt.J2g_Truth(tmp21) { v__24 = v__23 } else { var root_688 any = A_arbace_go_check_const_A_const_44.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, A_arbace_go_check_const_norm_int_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any; var root_692 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, A_arbace_go_check_const_bi_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = v__23; if linked_693 == nil { arg_691 = ifn_694.Invoke_O__O(arg_695) } else { arg_691 = linked_693.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_692, arg_695) }; if linked_689 == nil { v__24 = ifn_690.Invoke_O__O(arg_691) } else { v__24 = linked_689.(*A_arbace_go_check_const_norm_int_A).Invoke_O_O__O(root_688, arg_691) } }
			if neg__9 { var na_696 any = v__24; if jrt.Long_InstanceOf(na_696) { var n0_697 int64 = jrt.NN(jrt.Long_Cast(na_696)).LongValue__J(); if n0_697 == -9223372036854775808 { return lang.Numbers_Minus_O__Number_NoInit(na_696) } else { return jrt.Long_ValueOf_J__Long_NoInit(-n0_697).Ref() } } else { if jrt.Double_InstanceOf(na_696) { var n0_697_2 float64 = jrt.NN(jrt.Double_Cast(na_696)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(-n0_697_2).Ref() } else { return lang.Numbers_Minus_O__Number_NoInit(na_696) } } } else { return v__24 } } } }

func A_arbace_go_check_const_round64_A_New() *A_arbace_go_check_const_round64_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_round64_A{}; t.Ctor(); return t }
//line :246:1
func (t *A_arbace_go_check_const_round64_A) Ctor() {}
//line :246:1
func (t *A_arbace_go_check_const_round64_A) Invoke_O_O__O(self, x__0 any) any { var root_700 any = A_arbace_go_check_const_A_const_46.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_700, A_arbace_go_check_const_round_binary_A_fn_class); var ifn_702 lang.IFn; if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = x__0; var arg_705 any = A_arbace_go_check_const_A_const_48; if linked_701 == nil { return ifn_702.Invoke_O_O_O_O__O(arg_703, A_arbace_go_check_const_A_const_47, arg_705, A_arbace_go_check_const_A_const_49) } else { return linked_701.(*A_arbace_go_check_const_round_binary_A).InvokeSpec_O_O_J_O_O_J_O__O(root_700, arg_703, 53, A_arbace_go_check_const_A_const_47, arg_705, 1023, A_arbace_go_check_const_A_const_49) } }
func A_arbace_go_check_const_round32_A_New() *A_arbace_go_check_const_round32_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_round32_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_go_check_const_round32_A) Ctor() {}
//line :247:1
func (t *A_arbace_go_check_const_round32_A) Invoke_O_O__O(self, x__0 any) any { var root_707 any = A_arbace_go_check_const_A_const_46.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_707, A_arbace_go_check_const_round_binary_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = x__0; var arg_712 any = A_arbace_go_check_const_A_const_51; if linked_708 == nil { return ifn_709.Invoke_O_O_O_O__O(arg_710, A_arbace_go_check_const_A_const_50, arg_712, A_arbace_go_check_const_A_const_52) } else { return linked_708.(*A_arbace_go_check_const_round_binary_A).InvokeSpec_O_O_J_O_O_J_O__O(root_707, arg_710, 24, A_arbace_go_check_const_A_const_50, arg_712, 127, A_arbace_go_check_const_A_const_52) } }

func A_arbace_go_check_const_exact_of_double_A_New() *A_arbace_go_check_const_exact_of_double_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_exact_of_double_A{}; t.Ctor(); return t }
//line :249:1
func (t *A_arbace_go_check_const_exact_of_double_A) Ctor() {}
//line :249:1
func (t *A_arbace_go_check_const_exact_of_double_A) InvokePrim_O_D__O(self any, d__0 float64) any {


	if lang.Numbers_IsZero_D__Z_NoInit(d__0) { return A_arbace_go_check_const_A_const_17 } else { var bits__2 int64 = jrt.Double_DoubleToRawLongBits_D__J_NoInit(d__0); var neg__3 bool = lang.Numbers_IsNeg_J__Z_NoInit(bits__2); var ex__4 int64 = lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(bits__2, 52), 2047); var frac__5 int64 = lang.Numbers_And_J_J__J_NoInit(bits__2, 4503599627370495); var vec__161000094__6 any





		if lang.Numbers_IsZero_J__Z_NoInit(ex__4) { vec__161000094__6 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(frac__5).Ref(), A_arbace_go_check_const_A_const_53) } else { vec__161000094__6 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(frac__5, lang.Numbers_ShiftLeft_J_J__J_NoInit(1, 52))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(ex__4, 1075)).Ref()) }
//line :252:1
		var m__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000094__6, lang.RT_IntCast_J__I_NoInit(0), nil); var e__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000094__6, lang.RT_IntCast_J__I_NoInit(1), nil); var v__9 any; var tmp1 bool
		var na_714 any = e__8





		if jrt.Long_InstanceOf(na_714) { var n0_715 int64 = jrt.NN(jrt.Long_Cast(na_714)).LongValue__J(); tmp1 = n0_715 < 0 } else { if jrt.Double_InstanceOf(na_714) { var n0_715_2 float64 = jrt.NN(jrt.Double_Cast(na_714)).DoubleValue__D(); tmp1 = n0_715_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_714) } }; if tmp1 { var tmp2 any; var root_716 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = m__7; if linked_717 == nil { tmp2 = ifn_718.Invoke_O__O(arg_719) } else { tmp2 = linked_717.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_716, arg_719) }; var tmp3 any = tmp2; var tmp4 any; var root_720 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any; var root_724 any = A_arbace_go_check_const_A_const_26.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, A_arbace_go_check_const_pow2_A_fn_class); var ifn_726 lang.IFn; if linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any; var na_728 any = e__8; if jrt.Long_InstanceOf(na_728) { var n0_729 int64 = jrt.NN(jrt.Long_Cast(na_728)).LongValue__J(); if n0_729 == -9223372036854775808 { arg_727 = lang.Numbers_Minus_O__Number_NoInit(na_728) } else { arg_727 = jrt.Long_ValueOf_J__Long_NoInit(-n0_729).Ref() } } else { if jrt.Double_InstanceOf(na_728) { var n0_729_2 float64 = jrt.NN(jrt.Double_Cast(na_728)).DoubleValue__D(); arg_727 = jrt.Double_ValueOf_D__Double_NoInit(-n0_729_2).Ref() } else { arg_727 = lang.Numbers_Minus_O__Number_NoInit(na_728) } }; if linked_725 == nil { arg_723 = ifn_726.Invoke_O__O(arg_727) } else { arg_723 = linked_725.(*A_arbace_go_check_const_pow2_A).Invoke_O_O__O(root_724, arg_727) }; if linked_721 == nil { tmp4 = ifn_722.Invoke_O__O(arg_723) } else { tmp4 = linked_721.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_720, arg_723) }; v__9 = lang.Numbers_Divide_O_O__Number_NoInit(tmp3, tmp4) } else { var root_730 any = A_arbace_go_check_const_A_const_13.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_bigint_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any; var tmp5 any; var root_734 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, A_arbace_go_check_const_bi_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any = m__7; if linked_735 == nil { tmp5 = ifn_736.Invoke_O__O(arg_737) } else { tmp5 = linked_735.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_734, arg_737) }; arg_733 = jrt.NN(jrt.BigInteger_Cast(tmp5)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(e__8)).Ref(); if linked_731 == nil { v__9 = ifn_732.Invoke_O__O(arg_733) } else { v__9 = linked_731.(*aot_arbace_core.A_arbace_core_bigint_A).Invoke_O_O__O(root_730, arg_733) } }
//line :252:1
		var v__10 any; var tmp6 any; var root_738 any = A_arbace_go_check_const_A_const_21.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_740 lang.IFn







		if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = v__9; if linked_739 == nil { tmp6 = ifn_740.Invoke_O__O(arg_741) } else { tmp6 = linked_739.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_738, arg_741) }; if jrt.J2g_Truth(tmp6) { v__10 = v__9 } else { var root_742 any = A_arbace_go_check_const_A_const_44.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, A_arbace_go_check_const_norm_int_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any; var root_746 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, A_arbace_go_check_const_bi_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = v__9; if linked_747 == nil { arg_745 = ifn_748.Invoke_O__O(arg_749) } else { arg_745 = linked_747.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_746, arg_749) }; if linked_743 == nil { v__10 = ifn_744.Invoke_O__O(arg_745) } else { v__10 = linked_743.(*A_arbace_go_check_const_norm_int_A).Invoke_O_O__O(root_742, arg_745) } }
		if neg__3 { var na_750 any = v__10; if jrt.Long_InstanceOf(na_750) { var n0_751 int64 = jrt.NN(jrt.Long_Cast(na_750)).LongValue__J(); if n0_751 == -9223372036854775808 { return lang.Numbers_Minus_O__Number_NoInit(na_750) } else { return jrt.Long_ValueOf_J__Long_NoInit(-n0_751).Ref() } } else { if jrt.Double_InstanceOf(na_750) { var n0_751_2 float64 = jrt.NN(jrt.Double_Cast(na_750)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(-n0_751_2).Ref() } else { return lang.Numbers_Minus_O__Number_NoInit(na_750) } } } else { return v__10 } } }
//line :249:1
func (t *A_arbace_go_check_const_exact_of_double_A) Invoke_O_O__O(self, p_d__0 any) any { return t.InvokePrim_O_D__O(self, lang.RT_DoubleCast_O__D_NoInit(p_d__0)) }













func A_arbace_go_check_const_to_double_A_New() *A_arbace_go_check_const_to_double_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_to_double_A{}; t.Ctor(); return t }
//line :263:1
func (t *A_arbace_go_check_const_to_double_A) Ctor() {}
//line :263:1
func (t *A_arbace_go_check_const_to_double_A) InvokePrim_O_O__D(self, x__0 any) float64 { var tmp1 any; var r__2 any; var root_752 any = A_arbace_go_check_const_A_const_54.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, A_arbace_go_check_const_round64_A_fn_class); var ifn_754 lang.IFn; if


	linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = x__0; if linked_753 == nil { r__2 = ifn_754.Invoke_O__O(arg_755) } else { r__2 = linked_753.(*A_arbace_go_check_const_round64_A).Invoke_O_O__O(root_752, arg_755) }; if
	lang.Util_Identical_O_O__Z_NoInit(r__2, nil) {
		var tmp2 int64; var root_756 any = A_arbace_go_check_const_A_const_41.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_756, A_arbace_go_check_const_fsign_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = x__0; if linked_757 == nil { tmp2 = lang.RT_LongCast_O__J_NoInit(ifn_758.Invoke_O__O(arg_759)) } else { tmp2 = linked_757.(*A_arbace_go_check_const_fsign_A).InvokePrim_O_O__J(root_756, arg_759) }; if lang.Numbers_IsPos_J__Z_NoInit(tmp2) { tmp1 = jrt.Double_ValueOf_D__Double_NoInit(jrt.PosInf64).Ref() } else { tmp1 = jrt.Double_ValueOf_D__Double_NoInit(jrt.NegInf64).Ref() } } else {
//line :267:1
			var tmp3 any; var root_760 any = A_arbace_go_check_const_A_const_21.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_762 lang.IFn

			if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = r__2; if linked_761 == nil { tmp3 = ifn_762.Invoke_O__O(arg_763) } else { tmp3 = linked_761.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_760, arg_763) }
//line :267:1
			if jrt.J2g_Truth(tmp3) {

				var tmp4 any; var root_784 any = A_arbace_go_check_const_A_const_57.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_784, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_786 lang.IFn; if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_check_const_A_const_58.GetRawRoot__O()); var tmp6 any = A_arbace_go_check_const_A_const_59; var arg_787 any = tmp5.Invoke_O_O__O(tmp6, jrt.MathContext_New_I(lang.RT_IntCast_J__I_NoInit(40))); if linked_785 == nil { ifn_786.Invoke_O__O(arg_787) } else { linked_785.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_784, arg_787) }; var tmp7 any = A_arbace_go_check_const_to_double_fn__161000098_A_New_O(r__2); var tmp8 *jrt.Class; var fncls__783 *jrt.Class = A_arbace_go_check_const_to_double_fn__161000098_A_fn_class; if fncls__783 == nil { var fncls__783d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_go_check_const_to_double_fn__161000098_A_fn_class = fncls__783d; tmp8 = fncls__783d } else { tmp8 = fncls__783 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O(); tmp1 = lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(tmp4, Lit_6, false) } else {
//line :267:1
					if A_arbace_go_check_const_A_const_8 != nil {


						tmp1 = jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(r__2)).Ref() } else {
//line :267:1
							tmp1 = nil } } }; return /*line :263:1*/ jrt.Number_Cast(tmp1).DoubleValue__D() }
//line :263:1
func (t *A_arbace_go_check_const_to_double_A) Invoke_O_O__O(self, x__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_O__D(self, x__0)).Ref() }





func A_arbace_go_check_const_to_double_fn__161000098_A_New_O(p0 any) *A_arbace_go_check_const_to_double_fn__161000098_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_to_double_fn__161000098_A{}; t.Ctor_O(p0); return t }
//line :269:1
func (t *A_arbace_go_check_const_to_double_fn__161000098_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :269:1
func (t *A_arbace_go_check_const_to_double_fn__161000098_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var root_764 any = A_arbace_go_check_const_A_const_55.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_bigdec_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any; var root_768 any = A_arbace_go_check_const_A_const_22.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_numerator_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = t.F_r; if linked_769 == nil { arg_767 = ifn_770.Invoke_O__O(arg_771) } else { arg_767 = linked_769.(*aot_arbace_core.A_arbace_core_numerator_A).Invoke_O_O__O(root_768, arg_771) }; if linked_765 == nil { tmp2 = ifn_766.Invoke_O__O(arg_767) } else { tmp2 = linked_765.(*aot_arbace_core.A_arbace_core_bigdec_A).Invoke_O_O__O(root_764, arg_767) }; var tmp3 any = tmp2; var tmp4 any; var root_772 any = A_arbace_go_check_const_A_const_55.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_bigdec_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any; var root_776 any = A_arbace_go_check_const_A_const_23.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_core.A_arbace_core_denominator_A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any; var t_ any = t.F_r; t.F_r = nil; arg_779 = t_; if linked_777 == nil { arg_775 = ifn_778.Invoke_O__O(arg_779) } else { arg_775 = linked_777.(*aot_arbace_core.A_arbace_core_denominator_A).Invoke_O_O__O(root_776, arg_779) }; if linked_773 == nil { tmp4 = ifn_774.Invoke_O__O(arg_775) } else { tmp4 = linked_773.(*aot_arbace_core.A_arbace_core_bigdec_A).Invoke_O_O__O(root_772, arg_775) }; tmp1 = lang.Numbers_Divide_O_O__Number_NoInit(tmp3, tmp4) }; return nil }(); var root_780 any = A_arbace_go_check_const_A_const_56.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; if linked_781 == nil { ifn_782.Invoke__O() } else { linked_781.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_780) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }




func A_arbace_go_check_const_latin1_A_New() *A_arbace_go_check_const_latin1_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_latin1_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_go_check_const_latin1_A) Ctor() {}
//line :274:1
func (t *A_arbace_go_check_const_latin1_A) Invoke_O_O__O(self, bs__0 any) any { return jrt.String_New_B1_Charset(jrt.J2g_CastArray[*jrt.ByteArray](bs__0, jrt.Prim_byte.ArrayClass()), jrt.StandardCharsets_ISO_8859_1) }




func A_arbace_go_check_const_utf8_value_A_New() *A_arbace_go_check_const_utf8_value_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_utf8_value_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_go_check_const_utf8_value_A) Ctor() {}
//line :279:1
func (t *A_arbace_go_check_const_utf8_value_A) Invoke_O_O__O(self, s__0 any) any {


	var root_793 any = A_arbace_go_check_const_A_const_60.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, A_arbace_go_check_const_latin1_A_fn_class); var ifn_795 lang.IFn; if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = jrt.NN(jrt.String_Cast(s__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8).Ref(); if linked_794 == nil { return ifn_795.Invoke_O__O(arg_796) } else { return linked_794.(*A_arbace_go_check_const_latin1_A).Invoke_O_O__O(root_793, arg_796)
	} }
func A_arbace_go_check_const_value_bytes_A_New() *A_arbace_go_check_const_value_bytes_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_value_bytes_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_go_check_const_value_bytes_A) Ctor() {}
//line :284:1
func (t *A_arbace_go_check_const_value_bytes_A) Invoke_O_O__O(self, v__0 any) any { return jrt.NN(jrt.String_Cast(v__0)).GetBytes_Charset__B1(jrt.StandardCharsets_ISO_8859_1).Ref() }

func A_arbace_go_check_const_value_text_A_New() *A_arbace_go_check_const_value_text_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_value_text_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_go_check_const_value_text_A) Ctor() {}
//line :286:1
func (t *A_arbace_go_check_const_value_text_A) Invoke_O_O__O(self, v__0 any) any { var tmp1 any; var root_797 any = A_arbace_go_check_const_A_const_61.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, A_arbace_go_check_const_value_bytes_A_fn_class); var ifn_799 lang.IFn; if


	linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = v__0; if linked_798 == nil { tmp1 = ifn_799.Invoke_O__O(arg_800) } else { tmp1 = linked_798.(*A_arbace_go_check_const_value_bytes_A).Invoke_O_O__O(root_797, arg_800) }; return /*line :286:1*/ jrt.String_New_B1_Charset(jrt.J2g_CastArray[*jrt.ByteArray](tmp1, jrt.Prim_byte.ArrayClass()), jrt.StandardCharsets_UTF_8) }




func A_arbace_go_check_const_rune_string_A_New() *A_arbace_go_check_const_rune_string_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_rune_string_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_go_check_const_rune_string_A) Ctor() {}
//line :291:1
func (t *A_arbace_go_check_const_rune_string_A) Invoke_O_O__O(self, r__0 any) any { var r__2 int64; var tmp1 any; var and__1927000168__auto____2 bool = jrt.Long_InstanceOf(r__0); if and__1927000168__auto____2 {


	var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_check_const_A_const_62.GetRawRoot__O()); var tmp3 any = A_arbace_go_check_const_A_const_17; var and__1927000168__auto____3 any = tmp2.Invoke_O_O_O__O(tmp3, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(r__0)).Ref(), A_arbace_go_check_const_A_const_63); if jrt.J2g_Truth(and__1927000168__auto____3) { var root_807 any = A_arbace_go_check_const_A_const_25.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_const_A_const_62.GetRawRoot__O()); var tmp5 any = A_arbace_go_check_const_A_const_64; var arg_810 any = tmp4.Invoke_O_O_O__O(tmp5, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(r__0)).Ref(), A_arbace_go_check_const_A_const_65); if linked_808 == nil { tmp1 = ifn_809.Invoke_O__O(arg_810) } else { tmp1 = linked_808.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_807, arg_810) } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp1) {
		r__2 = lang.RT_LongCast_O__J_NoInit(r__0) } else {
//line :294:1
			r__2 = 65533 }; var root_817 any =

	A_arbace_go_check_const_A_const_66.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, A_arbace_go_check_const_utf8_value_A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = jrt.String_New_C1(jrt.Character_ToChars_I__C1_NoInit(lang.RT_IntCast_J__I_NoInit(r__2))); if linked_818 == nil { return ifn_819.Invoke_O__O(arg_820) } else { return linked_818.(*A_arbace_go_check_const_utf8_value_A).Invoke_O_O__O(root_817, arg_820) } }

func A_arbace_go_check_const_rnd_A_New() *A_arbace_go_check_const_rnd_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_rnd_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_go_check_const_rnd_A) Ctor() {}
//line :298:1
func (t *A_arbace_go_check_const_rnd_A) Invoke_O_O_O_O_O__O(self, m__0, e__1, p__2, sticky__3 any) any { var vec__161000106__5 any; var root_821 any = A_arbace_go_check_const_A_const_18.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, A_arbace_go_check_const_round_int_A_fn_class); var ifn_823 lang.IFn; if


	linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = m__0; var arg_825 any = sticky__3; var arg_826 any = p__2; if linked_822 == nil { vec__161000106__5 = ifn_823.Invoke_O_O_O__O(arg_824, arg_825, arg_826) } else { vec__161000106__5 = linked_822.(*A_arbace_go_check_const_round_int_A).Invoke_O_O_O_O__O(root_821, arg_824, arg_825, arg_826) }; var m2__6 any = /*line :298:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__161000106__5, lang.RT_IntCast_J__I_NoInit(0), nil); var sh__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000106__5, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(m2__6, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e__1), lang.RT_LongCast_O__J_NoInit(sh__7))).Ref()) }




func A_arbace_go_check_const_pmul_A_New() *A_arbace_go_check_const_pmul_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_pmul_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_go_check_const_pmul_A) Ctor() {}
//line :303:1
func (t *A_arbace_go_check_const_pmul_A) Invoke_O_O_O_O__O(self, p__161000110__0, p__161000111__1, p__2 any) any { var vec__161000112__4 any = p__161000110__0; var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000112__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000112__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__161000115__7 any = p__161000111__1; var m2__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000115__7, lang.RT_IntCast_J__I_NoInit(0), nil); var e2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000115__7, lang.RT_IntCast_J__I_NoInit(1), nil); var root_827 any = A_arbace_go_check_const_A_const_67.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, A_arbace_go_check_const_rnd_A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = jrt.NN(jrt.BigInteger_Cast(m1__5)).Multiply_BigInteger__BigInteger(jrt.BigInteger_Cast(m2__8)).Ref(); var arg_831 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e1__6), lang.RT_LongCast_O__J_NoInit(e2__9))).Ref(); var arg_832 any = p__2; var arg_833 any = jrt.Boolean_FALSE.Ref(); if linked_828 == nil { return ifn_829.Invoke_O_O_O_O__O(arg_830, arg_831, arg_832, arg_833) } else { return linked_828.(*A_arbace_go_check_const_rnd_A).Invoke_O_O_O_O_O__O(root_827, arg_830, arg_831, arg_832, arg_833) } }

func A_arbace_go_check_const_pquo_A_New() *A_arbace_go_check_const_pquo_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_pquo_A{}; t.Ctor(); return t }
//line :305:1
func (t *A_arbace_go_check_const_pquo_A) Ctor() {}
//line :305:1
func (t *A_arbace_go_check_const_pquo_A) Invoke_O_O_O_O__O(self, p__161000119__0, p__161000120__1, p__2 any) any { if jrt.Long_InstanceOf(p__2) { return t.InvokeSpec_O_O_O_J_O__O(self, p__161000119__0, p__161000120__1, jrt.NN(jrt.Long_Cast(p__2)).LongValue__J(), p__2) } else { var vec__161000121__4 any = p__161000119__0; var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000121__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000121__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__161000124__7 any = p__161000120__1; var m2__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000124__7, lang.RT_IntCast_J__I_NoInit(0), nil); var e2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000124__7, lang.RT_IntCast_J__I_NoInit(1), nil); var k__10 any; var tmp1 jrt.Number_I; var na_834 any; var na_836 any = p__2; var na_837 int64 = 2
															if jrt.Long_InstanceOf(na_836) { var n0_838 int64 = jrt.NN(jrt.Long_Cast(na_836)).LongValue__J(); var n1_839 int64 = na_837; var nr_840 int64 = n0_838 + n1_839; if (n0_838^nr_840)&(n1_839^nr_840) >= 0 { na_834 = jrt.Long_ValueOf_J__Long_NoInit(nr_840).Ref() } else { na_834 = lang.Numbers_Add_O_J__Number_NoInit(na_836, na_837) } } else { na_834 = lang.Numbers_Add_O_J__Number_NoInit(na_836, na_837) }; var na_835 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m2__8)).Abs__BigInteger()).BitLength__I()), int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m1__5)).Abs__BigInteger()).BitLength__I())); if jrt.Long_InstanceOf(na_834) { var n0_841 int64 = jrt.NN(jrt.Long_Cast(na_834)).LongValue__J(); var n1_842 int64 = na_835; var nr_843 int64 = n0_841 + n1_842; if (n0_841^nr_843)&(n1_842^nr_843) >= 0 { tmp1 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_843)) } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_834, na_835) } } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_834, na_835) }; k__10 = lang.Numbers_Max_J_O__O_NoInit(0, tmp1)
//line :305:1
	var dr__11 any = jrt.NN(jrt.NN(jrt.BigInteger_Cast(m1__5)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(k__10))).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(m2__8)).Ref(); var root_844 any = A_arbace_go_check_const_A_const_67.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, A_arbace_go_check_const_rnd_A_fn_class); var ifn_846 lang.IFn


	if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__11, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)); var arg_848 any; var na_851 int64 = lang.Numbers_Minus_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e1__6), lang.RT_LongCast_O__J_NoInit(e2__9)); var na_852 any = k__10; if jrt.Long_InstanceOf(na_852) { var n0_853 int64 = na_851; var n1_854 int64 = jrt.NN(jrt.Long_Cast(na_852)).LongValue__J(); var nr_855 int64 = n0_853 - n1_854; var tmp2 bool; var tmp3 bool; tmp3 = !(n1_854 == -9223372036854775808); if tmp3 { tmp3 = (n0_853^n1_854)&(n0_853^nr_855) >= 0 }; tmp2 = tmp3; if tmp2 { arg_848 = jrt.Long_ValueOf_J__Long_NoInit(nr_855).Ref() } else { arg_848 = lang.Numbers_Minus_J_O__Number_NoInit(na_851, na_852) } } else { arg_848 = lang.Numbers_Minus_J_O__Number_NoInit(na_851, na_852) }; var arg_849 any = p__2; var arg_850 any; var root_856 any = A_arbace_go_check_const_A_const_25.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__11, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)))).Signum__I()))).Ref(); if linked_857 == nil { arg_850 = ifn_858.Invoke_O__O(arg_859) } else { arg_850 = linked_857.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_856, arg_859) }; if linked_845 == nil { return ifn_846.Invoke_O_O_O_O__O(arg_847, arg_848, arg_849, arg_850) } else { return linked_845.(*A_arbace_go_check_const_rnd_A).Invoke_O_O_O_O_O__O(root_844, arg_847, arg_848, arg_849, arg_850) } } }
//line :305:1
func (t *A_arbace_go_check_const_pquo_A) InvokeSpec_O_O_O_J_O__O(self, p__161000119__0, p__161000120__1 any, p__2_l int64, p__2_b any) any { var vec__161000121__4 any = p__161000119__0; var m1__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000121__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e1__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000121__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__161000124__7 any = p__161000120__1; var m2__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000124__7, lang.RT_IntCast_J__I_NoInit(0), nil); var e2__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000124__7, lang.RT_IntCast_J__I_NoInit(1), nil); var k__10 any; var tmp1 jrt.Number_I; var na_860 any; var na_862 int64 = 2; var n0_863 int64 = p__2_l; var n1_864 int64 = na_862; var nr_865 int64 = n0_863 + n1_864; if
																		(n0_863^nr_865)&(n1_864^nr_865) >= 0 { na_860 = jrt.Long_ValueOf_J__Long_NoInit(nr_865).Ref() } else { var tmp2 any; if p__2_b == nil { p__2_b = jrt.Long_ValueOf_J__Long_NoInit(p__2_l).Ref(); tmp2 = p__2_b } else { tmp2 = p__2_b }; na_860 = lang.Numbers_Add_O_J__Number_NoInit(tmp2, na_862) }; var na_861 int64 = lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m2__8)).Abs__BigInteger()).BitLength__I()), int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(m1__5)).Abs__BigInteger()).BitLength__I())); if jrt.Long_InstanceOf(na_860) { var n0_866 int64 = jrt.NN(jrt.Long_Cast(na_860)).LongValue__J(); var n1_867 int64 = na_861; var nr_868 int64 = n0_866 + n1_867; if (n0_866^nr_868)&(n1_867^nr_868) >= 0 { tmp1 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_868)) } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_860, na_861) } } else { tmp1 = lang.Numbers_Add_O_J__Number_NoInit(na_860, na_861) }; k__10 = lang.Numbers_Max_J_O__O_NoInit(0, tmp1); var dr__11 any = /*line :305:1*/jrt.NN(jrt.NN(jrt.BigInteger_Cast(m1__5)).ShiftLeft_I__BigInteger(lang.RT_IntCast_O__I_NoInit(k__10))).DivideAndRemainder_BigInteger__BigInteger1(jrt.BigInteger_Cast(m2__8)).Ref(); var root_869 any = A_arbace_go_check_const_A_const_67.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, A_arbace_go_check_const_rnd_A_fn_class); var ifn_871 lang.IFn; if


	linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__11, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)); var arg_873 any; var na_876 int64 = lang.Numbers_Minus_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(e1__6), lang.RT_LongCast_O__J_NoInit(e2__9)); var na_877 any = k__10; if jrt.Long_InstanceOf(na_877) { var n0_878 int64 = na_876; var n1_879 int64 = jrt.NN(jrt.Long_Cast(na_877)).LongValue__J(); var nr_880 int64 = n0_878 - n1_879; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_879 == -9223372036854775808); if tmp4 { tmp4 = (n0_878^n1_879)&(n0_878^nr_880) >= 0 }; tmp3 = tmp4; if tmp3 { arg_873 = jrt.Long_ValueOf_J__Long_NoInit(nr_880).Ref() } else { arg_873 = lang.Numbers_Minus_J_O__Number_NoInit(na_876, na_877) } } else { arg_873 = lang.Numbers_Minus_J_O__Number_NoInit(na_876, na_877) }; var arg_874 any; if p__2_b == nil { p__2_b = jrt.Long_ValueOf_J__Long_NoInit(p__2_l).Ref(); arg_874 = p__2_b } else { arg_874 = p__2_b }; var arg_875 any; var root_881 any = A_arbace_go_check_const_A_const_25.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](dr__11, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)))).Signum__I()))).Ref(); if linked_882 == nil { arg_875 = ifn_883.Invoke_O__O(arg_884) } else { arg_875 = linked_882.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_881, arg_884) }; if linked_870 == nil { return ifn_871.Invoke_O_O_O_O__O(arg_872, arg_873, arg_874, arg_875) } else { return linked_870.(*A_arbace_go_check_const_rnd_A).Invoke_O_O_O_O_O__O(root_869, arg_872, arg_873, arg_874, arg_875) } }



func A_arbace_go_check_const_pow5_A_New() *A_arbace_go_check_const_pow5_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_pow5_A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_go_check_const_pow5_A) Ctor() {}
//line :312:1
func (t *A_arbace_go_check_const_pow5_A) Invoke_O_O_O__O(self, n__0, prec__1 any) any { { var tmp1 bool; var tmp2 bool; tmp2 = jrt.Long_InstanceOf(n__0); if tmp2 { tmp2 = jrt.Long_InstanceOf(prec__1) }; tmp1 = tmp2; if tmp1 { return t.InvokeSpec_O_J_O_J_O__O(self, jrt.NN(jrt.Long_Cast(n__0)).LongValue__J(), n__0, jrt.NN(jrt.Long_Cast(prec__1)).LongValue__J(), prec__1) } else {


	var tmp3 bool; var na_885 any = n__0; var na_886 int64 = 27; if jrt.Long_InstanceOf(na_885) { var n0_887 int64 = jrt.NN(jrt.Long_Cast(na_885)).LongValue__J(); var n1_888 int64 = na_886; tmp3 = n0_887 <= n1_888 } else { tmp3 = lang.Numbers_Lte_O_J__Z_NoInit(na_885, na_886) }; if tmp3 { return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.BigInteger_ValueOf_J__BigInteger(5)).Pow_I__BigInteger(lang.RT_IntCast_O__I_NoInit(n__0)).Ref(), A_arbace_go_check_const_A_const_17) } else { var z__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_const_A_const_68.GetRawRoot__O(), A_arbace_go_check_const_A_const_17); var f__4 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.BigInteger_ValueOf_J__BigInteger(5).Ref(), A_arbace_go_check_const_A_const_17); var n__5 any
		var na_890 any = n__0; var na_891 int64 = 27
		if jrt.Long_InstanceOf(na_890) { var n0_892 int64 = jrt.NN(jrt.Long_Cast(na_890)).LongValue__J(); var n1_893 int64 = na_891; var nr_894 int64 = n0_892 - n1_893; var tmp4 bool; var tmp5 bool; tmp5 = !(n1_893 == -9223372036854775808); if tmp5 { tmp5 = (n0_892^n1_893)&(n0_892^nr_894) >= 0 }; tmp4 = tmp5; if tmp4 { n__5 = jrt.Long_ValueOf_J__Long_NoInit(nr_894).Ref() } else { n__5 = lang.Numbers_Minus_O_J__Number_NoInit(na_890, na_891) } } else { n__5 = lang.Numbers_Minus_O_J__Number_NoInit(na_890, na_891) }
//line :315:1
	L1: for {


		var tmp6 bool; var na_895 any = n__5; if jrt.Long_InstanceOf(na_895) { var n0_896 int64 = jrt.NN(jrt.Long_Cast(na_895)).LongValue__J(); tmp6 = n0_896 == 0 } else { if jrt.Double_InstanceOf(na_895) { var n0_896_2 float64 = jrt.NN(jrt.Double_Cast(na_895)).DoubleValue__D(); tmp6 = n0_896_2 == 0.0 } else { tmp6 = lang.Numbers_IsZero_O__Z_NoInit(na_895) } }; if tmp6 { return z__3 } else {

			var tmp7 any; var tmp8 any; var root_897 any = A_arbace_go_check_const_A_const_69.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_897, aot_arbace_core.A_arbace_core_odd_QMARK__A_fn_class); var ifn_899 lang.IFn; if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any = n__5; if linked_898 == nil { tmp8 = ifn_899.Invoke_O__O(arg_900) } else { tmp8 = linked_898.(*aot_arbace_core.A_arbace_core_odd_QMARK__A).Invoke_O_O__O(root_897, arg_900) }; if jrt.J2g_Truth(tmp8) { var root_901 any = A_arbace_go_check_const_A_const_70.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, A_arbace_go_check_const_pmul_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any = z__3; var arg_905 any = f__4; var arg_906 any = prec__1; if linked_902 == nil { tmp7 = ifn_903.Invoke_O_O_O__O(arg_904, arg_905, arg_906) } else { tmp7 = linked_902.(*A_arbace_go_check_const_pmul_A).Invoke_O_O_O_O__O(root_901, arg_904, arg_905, arg_906) } } else { tmp7 = z__3 }; var tmp9 any = tmp7; var tmp10 any; var root_907 any = A_arbace_go_check_const_A_const_70.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, A_arbace_go_check_const_pmul_A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = f__4; var arg_911 any = f__4; var arg_912 any; var na_913 any = prec__1; var na_914 int64 = 64; if jrt.Long_InstanceOf(na_913) { var n0_915 int64 = jrt.NN(jrt.Long_Cast(na_913)).LongValue__J(); var n1_916 int64 = na_914; var nr_917 int64 = n0_915 + n1_916; if (n0_915^nr_917)&(n1_916^nr_917) >= 0 { arg_912 = jrt.Long_ValueOf_J__Long_NoInit(nr_917).Ref() } else { arg_912 = lang.Numbers_Add_O_J__Number_NoInit(na_913, na_914) } } else { arg_912 = lang.Numbers_Add_O_J__Number_NoInit(na_913, na_914) }; if linked_908 == nil { tmp10 = ifn_909.Invoke_O_O_O__O(arg_910, arg_911, arg_912) } else { tmp10 = linked_908.(*A_arbace_go_check_const_pmul_A).Invoke_O_O_O_O__O(root_907, arg_910, arg_911, arg_912) }; var tmp11 any = tmp10; var tmp12 jrt.Number_I; var na_918 any = n__5; var na_919 int64 = 2; if jrt.Long_InstanceOf(na_918) { var n0_920 int64 = jrt.NN(jrt.Long_Cast(na_918)).LongValue__J(); var n1_921 int64 = na_919; if n1_921 == 0 { tmp12 = lang.Numbers_Quotient_O_J__Number_NoInit(na_918, na_919) } else { tmp12 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_920 / n1_921)) } } else { tmp12 = lang.Numbers_Quotient_O_J__Number_NoInit(na_918, na_919) }; z__3, f__4, n__5 = tmp9, tmp11, tmp12; continue L1 } } } } }; /*line :312:1*/panic("j2g: unreachable") }
//line :312:1
func (t *A_arbace_go_check_const_pow5_A) InvokeSpec_O_J_O_J_O__O(self any, n__0_l int64, n__0_b any, prec__1_l int64, prec__1_b any) any {


	{ var tmp1 bool; var na_923 int64 = 27; var n0_924 int64 = n__0_l; var n1_925 int64 = na_923; tmp1 = n0_924 <= n1_925; if tmp1 { var tmp2 *jrt.BigInteger = jrt.BigInteger_ValueOf_J__BigInteger(5); var tmp3 any
		if n__0_b == nil { n__0_b = jrt.Long_ValueOf_J__Long_NoInit(n__0_l).Ref(); tmp3 = n__0_b } else { tmp3 = n__0_b }
//line :315:1
		return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(tmp2).Pow_I__BigInteger(lang.RT_IntCast_O__I_NoInit(tmp3)).Ref(), A_arbace_go_check_const_A_const_17) } else { var z__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_check_const_A_const_68.GetRawRoot__O(), A_arbace_go_check_const_A_const_17); var f__4 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.BigInteger_ValueOf_J__BigInteger(5).Ref(), A_arbace_go_check_const_A_const_17); var n__5 any; var na_927 int64 = 27; var n0_928 int64 = n__0_l; var n1_929 int64 = na_927; var nr_930 int64 = n0_928 - n1_929; var tmp4 bool; var tmp5 bool

			tmp5 = !(n1_929 == -9223372036854775808); if tmp5 { tmp5 = (n0_928^n1_929)&(n0_928^nr_930) >= 0 }; tmp4 = tmp5; if tmp4 { n__5 = jrt.Long_ValueOf_J__Long_NoInit(nr_930).Ref() } else { var tmp6 any; if n__0_b == nil { n__0_b = jrt.Long_ValueOf_J__Long_NoInit(n__0_l).Ref(); tmp6 = n__0_b } else { tmp6 = n__0_b }; n__5 = lang.Numbers_Minus_O_J__Number_NoInit(tmp6, na_927) }
//line :315:1
		L1: for {


			var tmp7 bool; var na_931 any = n__5; if jrt.Long_InstanceOf(na_931) { var n0_932 int64 = jrt.NN(jrt.Long_Cast(na_931)).LongValue__J(); tmp7 = n0_932 == 0 } else { if jrt.Double_InstanceOf(na_931) { var n0_932_2 float64 = jrt.NN(jrt.Double_Cast(na_931)).DoubleValue__D(); tmp7 = n0_932_2 == 0.0 } else { tmp7 = lang.Numbers_IsZero_O__Z_NoInit(na_931) } }; if tmp7 { return z__3 } else {

				var tmp8 any; var tmp9 any; var root_933 any = A_arbace_go_check_const_A_const_69.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_odd_QMARK__A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = n__5; if linked_934 == nil { tmp9 = ifn_935.Invoke_O__O(arg_936) } else { tmp9 = linked_934.(*aot_arbace_core.A_arbace_core_odd_QMARK__A).Invoke_O_O__O(root_933, arg_936) }; if jrt.J2g_Truth(tmp9) { var root_937 any = A_arbace_go_check_const_A_const_70.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, A_arbace_go_check_const_pmul_A_fn_class); var ifn_939 lang.IFn; if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = z__3; var arg_941 any = f__4; var arg_942 any; if prec__1_b == nil { prec__1_b = jrt.Long_ValueOf_J__Long_NoInit(prec__1_l).Ref(); arg_942 = prec__1_b } else { arg_942 = prec__1_b }; if linked_938 == nil { tmp8 = ifn_939.Invoke_O_O_O__O(arg_940, arg_941, arg_942) } else { tmp8 = linked_938.(*A_arbace_go_check_const_pmul_A).Invoke_O_O_O_O__O(root_937, arg_940, arg_941, arg_942) } } else { tmp8 = z__3 }; var tmp10 any = tmp8; var tmp11 any; var root_943 any = A_arbace_go_check_const_A_const_70.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, A_arbace_go_check_const_pmul_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = f__4; var arg_947 any = f__4; var arg_948 any; var na_949 int64 = 64; var n0_950 int64 = prec__1_l; var n1_951 int64 = na_949; var nr_952 int64 = n0_950 + n1_951; if (n0_950^nr_952)&(n1_951^nr_952) >= 0 { arg_948 = jrt.Long_ValueOf_J__Long_NoInit(nr_952).Ref() } else { var tmp12 any; if prec__1_b == nil { prec__1_b = jrt.Long_ValueOf_J__Long_NoInit(prec__1_l).Ref(); tmp12 = prec__1_b } else { tmp12 = prec__1_b }; arg_948 = lang.Numbers_Add_O_J__Number_NoInit(tmp12, na_949) }; if linked_944 == nil { tmp11 = ifn_945.Invoke_O_O_O__O(arg_946, arg_947, arg_948) } else { tmp11 = linked_944.(*A_arbace_go_check_const_pmul_A).Invoke_O_O_O_O__O(root_943, arg_946, arg_947, arg_948) }; var tmp13 any = tmp11; var tmp14 jrt.Number_I; var na_953 any = n__5; var na_954 int64 = 2; if jrt.Long_InstanceOf(na_953) { var n0_955 int64 = jrt.NN(jrt.Long_Cast(na_953)).LongValue__J(); var n1_956 int64 = na_954; if n1_956 == 0 { tmp14 = lang.Numbers_Quotient_O_J__Number_NoInit(na_953, na_954) } else { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_955 / n1_956)) } } else { tmp14 = lang.Numbers_Quotient_O_J__Number_NoInit(na_953, na_954) }; z__3, f__4, n__5 = tmp10, tmp13, tmp14; continue L1 } } } }
//line :312:1
	panic("j2g: unreachable")
}








func A_arbace_go_check_const_big_float_decimal_A_New() *A_arbace_go_check_const_big_float_decimal_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_big_float_decimal_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_go_check_const_big_float_decimal_A) Ctor() {}
//line :322:1
func (t *A_arbace_go_check_const_big_float_decimal_A) Invoke_O_O_O__O(self, d__0, k__1 any) any { var p__3 any; var root_958 any = A_arbace_go_check_const_A_const_71.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_958, A_arbace_go_check_const_pow5_A_fn_class); var ifn_960 lang.IFn; if



	linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 int64 = jrt.Math_Abs_J__J(lang.RT_LongCast_O__J_NoInit(k__1)); var arg_962 any; var na_963 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O(); var na_964 int64 = 64; if jrt.Long_InstanceOf(na_963) { var n0_965 int64 = jrt.NN(jrt.Long_Cast(na_963)).LongValue__J(); var n1_966 int64 = na_964; var nr_967 int64 = n0_965 + n1_966; if (n0_965^nr_967)&(n1_966^nr_967) >= 0 { arg_962 = jrt.Long_ValueOf_J__Long_NoInit(nr_967).Ref() } else { arg_962 = lang.Numbers_Add_O_J__Number_NoInit(na_963, na_964) } } else { arg_962 = lang.Numbers_Add_O_J__Number_NoInit(na_963, na_964) }; if linked_959 == nil { p__3 = ifn_960.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_961).Ref(), arg_962) } else { if jrt.Long_InstanceOf(arg_962) { p__3 = linked_959.(*A_arbace_go_check_const_pow5_A).InvokeSpec_O_J_O_J_O__O(root_958, arg_961, nil, jrt.NN(jrt.Long_Cast(arg_962)).LongValue__J(), arg_962) } else { p__3 = linked_959.(*A_arbace_go_check_const_pow5_A).Invoke_O_O_O__O(root_958, jrt.Long_ValueOf_J__Long_NoInit(arg_961).Ref(), arg_962) } }; var vec__161000129__4 any; var tmp1 bool; var na_968 any = k__1; if
	jrt.Long_InstanceOf(na_968) { var n0_969 int64 = jrt.NN(jrt.Long_Cast(na_968)).LongValue__J(); tmp1 = n0_969 < 0 } else { if jrt.Double_InstanceOf(na_968) { var n0_969_2 float64 = jrt.NN(jrt.Double_Cast(na_968)).DoubleValue__D(); tmp1 = n0_969_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_968) } }; if tmp1 { var root_970 any = A_arbace_go_check_const_A_const_72.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_970, A_arbace_go_check_const_pquo_A_fn_class); var ifn_972 lang.IFn; if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any = lang.Tuple_Create_O_O__IPersistentVector(d__0, k__1); var arg_974 any = p__3; var arg_975 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O(); if linked_971 == nil { vec__161000129__4 = ifn_972.Invoke_O_O_O__O(arg_973, arg_974, arg_975) } else { if jrt.Long_InstanceOf(arg_975) { vec__161000129__4 = linked_971.(*A_arbace_go_check_const_pquo_A).InvokeSpec_O_O_O_J_O__O(root_970, arg_973, arg_974, jrt.NN(jrt.Long_Cast(arg_975)).LongValue__J(), arg_975) } else { vec__161000129__4 = linked_971.(*A_arbace_go_check_const_pquo_A).Invoke_O_O_O_O__O(root_970, arg_973, arg_974, arg_975) } } } else { var root_976 any = A_arbace_go_check_const_A_const_70.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, A_arbace_go_check_const_pmul_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = lang.Tuple_Create_O_O__IPersistentVector(d__0, k__1); var arg_980 any = p__3; var arg_981 any = A_arbace_go_check_const_A_const_19.GetRawRoot__O(); if linked_977 == nil { vec__161000129__4 = ifn_978.Invoke_O_O_O__O(arg_979, arg_980, arg_981) } else { vec__161000129__4 = linked_977.(*A_arbace_go_check_const_pmul_A).Invoke_O_O_O_O__O(root_976, arg_979, arg_980, arg_981) } }; var m__5 any = /*line :322:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__161000129__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__161000129__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_982 any = A_arbace_go_check_const_A_const_20.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_982, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_984 lang.IFn; if





	linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = m__5; var arg_986 any = e__6; if linked_983 == nil { return ifn_984.Invoke_O_O__O(arg_985, arg_986) } else { return linked_983.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O__O(root_982, arg_985, arg_986) } }

func A_arbace_go_check_const_decimal_exact_A_New() *A_arbace_go_check_const_decimal_exact_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_decimal_exact_A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_go_check_const_decimal_exact_A) Ctor() {}
//line :330:1
func (t *A_arbace_go_check_const_decimal_exact_A) Invoke_O_O__O(self, d__0 any) any { var unscaled__2 any = jrt.NN(jrt.BigDecimal_Cast(d__0)).UnscaledValue__BigInteger().Ref(); var scale__3 int32 = jrt.NN(jrt.BigDecimal_Cast(d__0)).Scale__I(); var mag__4 float64 = lang.Numbers_Minus_D__D_NoInit(lang.Numbers_Multiply_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(jrt.NN(jrt.BigDecimal_Cast(d__0)).Precision__I()), int64(scale__3)), 3.3219280948873626)); var tmp1 float64 = jrt.Math_Abs_D__D(lang.RT_DoubleCast_D__D_NoInit(mag__4)); var tmp2 jrt.Number_I; var na_987 any = A_arbace_go_check_const_A_const_28.GetRawRoot__O(); var na_988 int64 = 64; if







	jrt.Long_InstanceOf(na_987) { var n0_989 int64 = jrt.NN(jrt.Long_Cast(na_987)).LongValue__J(); var n1_990 int64 = na_988; var nr_991 int64 = n0_989 + n1_990; if (n0_989^nr_991)&(n1_990^nr_991) >= 0 { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_991)) } else { tmp2 = lang.Numbers_Add_O_J__Number_NoInit(na_987, na_988) } } else { tmp2 = lang.Numbers_Add_O_J__Number_NoInit(na_987, na_988) }; if lang.Numbers_Gt_D_O__Z_NoInit(tmp1, tmp2) {
		if lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(unscaled__2)).Signum__I())) { return A_arbace_go_check_const_A_const_17 } else {

			var root_992 any = A_arbace_go_check_const_A_const_73.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, A_arbace_go_check_const_big_float_decimal_A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = unscaled__2; var arg_996 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(int64(scale__3))).Ref(); if linked_993 == nil { return ifn_994.Invoke_O_O__O(arg_995, arg_996) } else { return linked_993.(*A_arbace_go_check_const_big_float_decimal_A).Invoke_O_O_O__O(root_992, arg_995, arg_996) } } } else {
				var root_997 any = A_arbace_go_check_const_A_const_37.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, A_arbace_go_check_const_make_rat_A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any; var root_1001 any = A_arbace_go_check_const_A_const_74.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1001, aot_arbace_core.A_arbace_core_rationalize_A_fn_class); var ifn_1003 lang.IFn; if linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any = d__0; if linked_1002 == nil { arg_1000 = ifn_1003.Invoke_O__O(arg_1004) } else { arg_1000 = linked_1002.(*aot_arbace_core.A_arbace_core_rationalize_A).Invoke_O_O__O(root_1001, arg_1004) }; if linked_998 == nil { return ifn_999.Invoke_O__O(arg_1000) } else { return linked_998.(*A_arbace_go_check_const_make_rat_A).Invoke_O_O__O(root_997, arg_1000) } } }

func A_arbace_go_check_const_double_literal_A_New() *A_arbace_go_check_const_double_literal_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_double_literal_A{}; t.Ctor(); return t }
//line :344:1
func (t *A_arbace_go_check_const_double_literal_A) Ctor() {}
//line :344:1
func (t *A_arbace_go_check_const_double_literal_A) InvokePrim_O_D__O(self any, d__0 float64) any {


	var root_1005 any = A_arbace_go_check_const_A_const_75.GetRawRoot__O(); var linked_1006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1005, A_arbace_go_check_const_decimal_exact_A_fn_class); var ifn_1007 lang.IFn; if linked_1006 == nil { ifn_1007 = lang.IFn_Cast(root_1005) } else { ifn_1007 = nil }; var arg_1008 any = jrt.BigDecimal_New_String(jrt.Double_ToString_D__String_NoInit(d__0)); if linked_1006 == nil { return ifn_1007.Invoke_O__O(arg_1008) } else { return linked_1006.(*A_arbace_go_check_const_decimal_exact_A).Invoke_O_O__O(root_1005, arg_1008) } }
//line :344:1
func (t *A_arbace_go_check_const_double_literal_A) Invoke_O_O__O(self, p_d__0 any) any { return t.InvokePrim_O_D__O(self, lang.RT_DoubleCast_O__D_NoInit(p_d__0)) }




func A_arbace_go_check_const_binary_float_A_New() *A_arbace_go_check_const_binary_float_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_binary_float_A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_go_check_const_binary_float_A) Ctor() {}
//line :349:1
func (t *A_arbace_go_check_const_binary_float_A) Invoke_O_O_O__O(self, m__0, e__1 any) any {


	var root_1009 any = A_arbace_go_check_const_A_const_20.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, A_arbace_go_check_const_bf_norm_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any; var root_1014 any = A_arbace_go_check_const_A_const_14.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, A_arbace_go_check_const_bi_A_fn_class); var ifn_1016 lang.IFn; if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = m__0; if linked_1015 == nil { arg_1012 = ifn_1016.Invoke_O__O(arg_1017) } else { arg_1012 = linked_1015.(*A_arbace_go_check_const_bi_A).Invoke_O_O__O(root_1014, arg_1017) }; var arg_1013 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(e__1)).Ref(); if linked_1010 == nil { return ifn_1011.Invoke_O_O__O(arg_1012, arg_1013) } else { return linked_1010.(*A_arbace_go_check_const_bf_norm_A).Invoke_O_O_O__O(root_1009, arg_1012, arg_1013)
	}
}

func A_arbace_go_check_const_complex_QMARK__A_New() *A_arbace_go_check_const_complex_QMARK__A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_complex_QMARK__A{}; t.Ctor(); return t }
//line :356:1
func (t *A_arbace_go_check_const_complex_QMARK__A) Ctor() {}
//line :356:1
func (t *A_arbace_go_check_const_complex_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any; var root_1018 any = A_arbace_go_check_const_A_const_15.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = x__0; if linked_1019 == nil { and__1927000168__auto____2 = ifn_1020.Invoke_O__O(arg_1021) } else { and__1927000168__auto____2 = linked_1019.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1018, arg_1021) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_const_A_const_76; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(0)))).Ref() } else { return and__1927000168__auto____2 } }
func A_arbace_go_check_const_cplx_A_New() *A_arbace_go_check_const_cplx_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_cplx_A{}; t.Ctor(); return t }
//line :357:1
func (t *A_arbace_go_check_const_cplx_A) Ctor() {}
//line :357:1
func (t *A_arbace_go_check_const_cplx_A) Invoke_O_O_O__O(self, re__0, im__1 any) any { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_check_const_A_const_76, re__0, im__1) }
func A_arbace_go_check_const_re_part_A_New() *A_arbace_go_check_const_re_part_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_re_part_A{}; t.Ctor(); return t }
//line :358:1
func (t *A_arbace_go_check_const_re_part_A) Ctor() {}
//line :358:1
func (t *A_arbace_go_check_const_re_part_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_1022 any = A_arbace_go_check_const_A_const_77.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, A_arbace_go_check_const_complex_QMARK__A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = x__0; if linked_1023 == nil { tmp1 = ifn_1024.Invoke_O__O(arg_1025) } else { tmp1 = linked_1023.(*A_arbace_go_check_const_complex_QMARK__A).Invoke_O_O__O(root_1022, arg_1025) }; if jrt.J2g_Truth(tmp1) { return lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(1)) } else { return x__0 } }
func A_arbace_go_check_const_im_part_A_New() *A_arbace_go_check_const_im_part_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_im_part_A{}; t.Ctor(); return t }
//line :359:1
func (t *A_arbace_go_check_const_im_part_A) Ctor() {}
//line :359:1
func (t *A_arbace_go_check_const_im_part_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_1026 any = A_arbace_go_check_const_A_const_77.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, A_arbace_go_check_const_complex_QMARK__A_fn_class); var ifn_1028 lang.IFn; if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = x__0; if linked_1027 == nil { tmp1 = ifn_1028.Invoke_O__O(arg_1029) } else { tmp1 = linked_1027.(*A_arbace_go_check_const_complex_QMARK__A).Invoke_O_O__O(root_1026, arg_1029) }; if jrt.J2g_Truth(tmp1) { return lang.RT_Nth_O_I__O_NoInit(x__0, lang.RT_IntCast_J__I_NoInit(2)) } else { return A_arbace_go_check_const_A_const_17 } }
func A_arbace_go_check_const_complex_val_A_New() *A_arbace_go_check_const_complex_val_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_complex_val_A{}; t.Ctor(); return t }
//line :360:1
func (t *A_arbace_go_check_const_complex_val_A) Ctor() {}
//line :360:1
func (t *A_arbace_go_check_const_complex_val_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_1030 any = A_arbace_go_check_const_A_const_77.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1030, A_arbace_go_check_const_complex_QMARK__A_fn_class); var ifn_1032 lang.IFn; if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any = x__0; if linked_1031 == nil { tmp1 = ifn_1032.Invoke_O__O(arg_1033) } else { tmp1 = linked_1031.(*A_arbace_go_check_const_complex_QMARK__A).Invoke_O_O__O(root_1030, arg_1033) }; if jrt.J2g_Truth(tmp1) { return x__0 } else { var tmp2 any = A_arbace_go_check_const_A_const_76; var tmp3 any; var root_1034 any = A_arbace_go_check_const_A_const_78.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, A_arbace_go_check_const_float_val_A_fn_class); var ifn_1036 lang.IFn; if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = x__0; if linked_1035 == nil { tmp3 = ifn_1036.Invoke_O__O(arg_1037) } else { tmp3 = linked_1035.(*A_arbace_go_check_const_float_val_A).Invoke_O_O__O(root_1034, arg_1037) }; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp3, A_arbace_go_check_const_A_const_17) } }










































type A_arbace_go_check_const_A struct{ jrt.Object }

var A_arbace_go_check_const_A_const_pool *jrt.RefArray

var A_arbace_go_check_const_A_const_0 *lang.Var

var A_arbace_go_check_const_A_const_1 any

var A_arbace_go_check_const_A_const_2 *lang.Var

var A_arbace_go_check_const_A_const_3 *lang.Var

var A_arbace_go_check_const_A_const_4 *lang.Var

var A_arbace_go_check_const_A_const_5 *lang.Var

var A_arbace_go_check_const_A_const_6 any

var A_arbace_go_check_const_A_const_7 *lang.Var

var A_arbace_go_check_const_A_const_8 *lang.Keyword

var A_arbace_go_check_const_A_const_9 *lang.Var

var A_arbace_go_check_const_A_const_10 *lang.Var

var A_arbace_go_check_const_A_const_11 *lang.Var

var A_arbace_go_check_const_A_const_12 *lang.Keyword

var A_arbace_go_check_const_A_const_13 *lang.Var

var A_arbace_go_check_const_A_const_14 *lang.Var

var A_arbace_go_check_const_A_const_15 *lang.Var

var A_arbace_go_check_const_A_const_16 *lang.Keyword

var A_arbace_go_check_const_A_const_17 any

var A_arbace_go_check_const_A_const_18 *lang.Var

var A_arbace_go_check_const_A_const_19 *lang.Var

var A_arbace_go_check_const_A_const_20 *lang.Var

var A_arbace_go_check_const_A_const_21 *lang.Var

var A_arbace_go_check_const_A_const_22 *lang.Var

var A_arbace_go_check_const_A_const_23 *lang.Var

var A_arbace_go_check_const_A_const_24 *lang.Var

var A_arbace_go_check_const_A_const_25 *lang.Var

var A_arbace_go_check_const_A_const_26 *lang.Var

var A_arbace_go_check_const_A_const_27 *lang.Var

var A_arbace_go_check_const_A_const_28 *lang.Var

var A_arbace_go_check_const_A_const_29 *lang.Var

var A_arbace_go_check_const_A_const_30 *lang.Var

var A_arbace_go_check_const_A_const_31 *lang.Var

var A_arbace_go_check_const_A_const_32 *lang.Var

var A_arbace_go_check_const_A_const_33 *lang.Var

var A_arbace_go_check_const_A_const_34 *lang.Var

var A_arbace_go_check_const_A_const_35 *lang.Var

var A_arbace_go_check_const_A_const_36 *lang.Var

var A_arbace_go_check_const_A_const_37 *lang.Var

var A_arbace_go_check_const_A_const_38 *lang.Var

var A_arbace_go_check_const_A_const_39 *lang.Var

var A_arbace_go_check_const_A_const_40 *lang.Var

var A_arbace_go_check_const_A_const_41 *lang.Var

var A_arbace_go_check_const_A_const_42 *lang.Var

var A_arbace_go_check_const_A_const_43 *lang.Var

var A_arbace_go_check_const_A_const_44 *lang.Var

var A_arbace_go_check_const_A_const_45 *lang.Var

var A_arbace_go_check_const_A_const_46 *lang.Var

var A_arbace_go_check_const_A_const_47 any

var A_arbace_go_check_const_A_const_48 any

var A_arbace_go_check_const_A_const_49 any

var A_arbace_go_check_const_A_const_50 any

var A_arbace_go_check_const_A_const_51 any

var A_arbace_go_check_const_A_const_52 any

var A_arbace_go_check_const_A_const_53 any

var A_arbace_go_check_const_A_const_54 *lang.Var

var A_arbace_go_check_const_A_const_55 *lang.Var

var A_arbace_go_check_const_A_const_56 *lang.Var

var A_arbace_go_check_const_A_const_57 *lang.Var

var A_arbace_go_check_const_A_const_58 *lang.Var

var A_arbace_go_check_const_A_const_59 *lang.Var

var A_arbace_go_check_const_A_const_60 *lang.Var

var A_arbace_go_check_const_A_const_61 *lang.Var

var A_arbace_go_check_const_A_const_62 *lang.Var

var A_arbace_go_check_const_A_const_63 any

var A_arbace_go_check_const_A_const_64 any

var A_arbace_go_check_const_A_const_65 any

var A_arbace_go_check_const_A_const_66 *lang.Var

var A_arbace_go_check_const_A_const_67 *lang.Var

var A_arbace_go_check_const_A_const_68 *lang.Var

var A_arbace_go_check_const_A_const_69 *lang.Var

var A_arbace_go_check_const_A_const_70 *lang.Var

var A_arbace_go_check_const_A_const_71 *lang.Var

var A_arbace_go_check_const_A_const_72 *lang.Var

var A_arbace_go_check_const_A_const_73 *lang.Var

var A_arbace_go_check_const_A_const_74 *lang.Var

var A_arbace_go_check_const_A_const_75 *lang.Var

var A_arbace_go_check_const_A_const_76 *lang.Keyword

var A_arbace_go_check_const_A_const_77 *lang.Var

var A_arbace_go_check_const_A_const_78 *lang.Var

var A_arbace_go_check_const_A_init jrt.ClassInit

func A_arbace_go_check_const_A_Init() { if !A_arbace_go_check_const_A_init.Done() { A_arbace_go_check_const_A_init.Run(A_arbace_go_check_const_A_clinit) } }

func A_arbace_go_check_const_A_clinit() { A_arbace_go_check_const_A_clinit_p0(); A_arbace_go_check_const_A_clinit_p1(); A_arbace_go_check_const_A_clinit_p2(); A_arbace_go_check_const_A_clinit_p3(); A_arbace_go_check_const_A_clinit_p4(); A_arbace_go_check_const_A_clinit_p5(); A_arbace_go_check_const_A_clinit_p6() }

func A_arbace_go_check_const_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_const_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 85); A_arbace_go_check_const_A_const_0 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[6]); A_arbace_go_check_const_A_const_1 = A_arbace_go_check_const_A_const_pool.A[7]; A_arbace_go_check_const_A_const_2 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[8]); A_arbace_go_check_const_A_const_3 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[9]); A_arbace_go_check_const_A_const_4 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[10]); A_arbace_go_check_const_A_const_5 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[11]); A_arbace_go_check_const_A_const_6 = A_arbace_go_check_const_A_const_pool.A[12]; A_arbace_go_check_const_A_const_7 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[13]); A_arbace_go_check_const_A_const_8 = lang.Keyword_Cast(A_arbace_go_check_const_A_const_pool.A[14]); A_arbace_go_check_const_A_const_9 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[15]); A_arbace_go_check_const_A_const_10 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[16]) }

func A_arbace_go_check_const_A_clinit_p1() { A_arbace_go_check_const_A_const_11 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[17]); A_arbace_go_check_const_A_const_12 = lang.Keyword_Cast(A_arbace_go_check_const_A_const_pool.A[18]); A_arbace_go_check_const_A_const_13 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[19]); A_arbace_go_check_const_A_const_14 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[20]); A_arbace_go_check_const_A_const_15 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[21]); A_arbace_go_check_const_A_const_16 = lang.Keyword_Cast(A_arbace_go_check_const_A_const_pool.A[22]); A_arbace_go_check_const_A_const_17 = A_arbace_go_check_const_A_const_pool.A[23]; A_arbace_go_check_const_A_const_18 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[24]); A_arbace_go_check_const_A_const_19 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[25]); A_arbace_go_check_const_A_const_20 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[26]); A_arbace_go_check_const_A_const_21 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[27]); A_arbace_go_check_const_A_const_22 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[28]) }

func A_arbace_go_check_const_A_clinit_p2() { A_arbace_go_check_const_A_const_23 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[29]); A_arbace_go_check_const_A_const_24 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[30]); A_arbace_go_check_const_A_const_25 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[31]); A_arbace_go_check_const_A_const_26 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[32]); A_arbace_go_check_const_A_const_27 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[33]); A_arbace_go_check_const_A_const_28 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[34]); A_arbace_go_check_const_A_const_29 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[35]); A_arbace_go_check_const_A_const_30 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[36]); A_arbace_go_check_const_A_const_31 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[37]); A_arbace_go_check_const_A_const_32 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[38]); A_arbace_go_check_const_A_const_33 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[39]); A_arbace_go_check_const_A_const_34 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[40]) }

func A_arbace_go_check_const_A_clinit_p3() { A_arbace_go_check_const_A_const_35 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[41]); A_arbace_go_check_const_A_const_36 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[42]); A_arbace_go_check_const_A_const_37 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[43]); A_arbace_go_check_const_A_const_38 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[44]); A_arbace_go_check_const_A_const_39 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[45]); A_arbace_go_check_const_A_const_40 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[46]); A_arbace_go_check_const_A_const_41 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[47]); A_arbace_go_check_const_A_const_42 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[48]); A_arbace_go_check_const_A_const_43 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[49]); A_arbace_go_check_const_A_const_44 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[50]); A_arbace_go_check_const_A_const_45 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[51]); A_arbace_go_check_const_A_const_46 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[52]) }

func A_arbace_go_check_const_A_clinit_p4() { A_arbace_go_check_const_A_const_47 = A_arbace_go_check_const_A_const_pool.A[53]; A_arbace_go_check_const_A_const_48 = A_arbace_go_check_const_A_const_pool.A[54]; A_arbace_go_check_const_A_const_49 = A_arbace_go_check_const_A_const_pool.A[55]; A_arbace_go_check_const_A_const_50 = A_arbace_go_check_const_A_const_pool.A[56]; A_arbace_go_check_const_A_const_51 = A_arbace_go_check_const_A_const_pool.A[57]; A_arbace_go_check_const_A_const_52 = A_arbace_go_check_const_A_const_pool.A[58]; A_arbace_go_check_const_A_const_53 = A_arbace_go_check_const_A_const_pool.A[59]; A_arbace_go_check_const_A_const_54 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[60]); A_arbace_go_check_const_A_const_55 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[61]); A_arbace_go_check_const_A_const_56 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[62]); A_arbace_go_check_const_A_const_57 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[63]); A_arbace_go_check_const_A_const_58 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[64]); A_arbace_go_check_const_A_const_59 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[65]) }

func A_arbace_go_check_const_A_clinit_p5() { A_arbace_go_check_const_A_const_60 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[66]); A_arbace_go_check_const_A_const_61 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[67]); A_arbace_go_check_const_A_const_62 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[68]); A_arbace_go_check_const_A_const_63 = A_arbace_go_check_const_A_const_pool.A[69]; A_arbace_go_check_const_A_const_64 = A_arbace_go_check_const_A_const_pool.A[70]; A_arbace_go_check_const_A_const_65 = A_arbace_go_check_const_A_const_pool.A[71]; A_arbace_go_check_const_A_const_66 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[72]); A_arbace_go_check_const_A_const_67 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[73]); A_arbace_go_check_const_A_const_68 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[74]); A_arbace_go_check_const_A_const_69 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[75]); A_arbace_go_check_const_A_const_70 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[76]); A_arbace_go_check_const_A_const_71 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[77]) }

func A_arbace_go_check_const_A_clinit_p6() { A_arbace_go_check_const_A_const_72 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[78]); A_arbace_go_check_const_A_const_73 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[79]); A_arbace_go_check_const_A_const_74 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[80]); A_arbace_go_check_const_A_const_75 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[81]); A_arbace_go_check_const_A_const_76 = lang.Keyword_Cast(A_arbace_go_check_const_A_const_pool.A[82]); A_arbace_go_check_const_A_const_77 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[83]); A_arbace_go_check_const_A_const_78 = lang.Var_Cast(A_arbace_go_check_const_A_const_pool.A[84]) }

func A_arbace_go_check_const_A_New() *A_arbace_go_check_const_A { A_arbace_go_check_const_A_Init(); t := &A_arbace_go_check_const_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_const_A) Ctor() {}

func (t *A_arbace_go_check_const_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_const_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_const_A_class }

func (t *A_arbace_go_check_const_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_const_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_const_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_const_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_const_A); return ok }

func A_arbace_go_check_const_A_Cast(x any) *A_arbace_go_check_const_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_const_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_const_A_class)) }; return v }



type A_arbace_go_check_const_bf_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_const_bf__GT_rat_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf__GT_rat_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_add_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_add_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_cmp_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_cmp_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_exp_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_exp_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_mul_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_mul_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_neg_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_neg_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_norm_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_norm_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_quo_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_quo_A_fn_class *jrt.Class



type A_arbace_go_check_const_bf_sign_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bf_sign_A_fn_class *jrt.Class



type A_arbace_go_check_const_bi_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bi_A_fn_class *jrt.Class



type A_arbace_go_check_const_big_float_decimal_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_big_float_decimal_A_fn_class *jrt.Class



type A_arbace_go_check_const_binary_float_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_binary_float_A_fn_class *jrt.Class



type A_arbace_go_check_const_bit_len_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_bit_len_A_fn_class *jrt.Class



type A_arbace_go_check_const_complex_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_const_complex_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_const_complex_val_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_complex_val_A_fn_class *jrt.Class



type A_arbace_go_check_const_cplx_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_cplx_A_fn_class *jrt.Class



type A_arbace_go_check_const_decimal_exact_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_decimal_exact_A_fn_class *jrt.Class



type A_arbace_go_check_const_double_literal_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_double_literal_A_fn_class *jrt.Class



type A_arbace_go_check_const_eval161000004_A struct{ jrt.Object }

func A_arbace_go_check_const_eval161000004_A_New() *A_arbace_go_check_const_eval161000004_A { t := &A_arbace_go_check_const_eval161000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_const_eval161000004_A) Ctor() {}

func (t *A_arbace_go_check_const_eval161000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_const_eval161000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_const_eval161000004_A_class }

func (t *A_arbace_go_check_const_eval161000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_const_eval161000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_const_eval161000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_const_eval161000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_const_eval161000004_A); return ok }

func A_arbace_go_check_const_eval161000004_A_Cast(x any) *A_arbace_go_check_const_eval161000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_const_eval161000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_const_eval161000004_A_class)) }; return v }



type A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A_fn_class *jrt.Class



type A_arbace_go_check_const_eval161000008_A struct{ jrt.Object }

func A_arbace_go_check_const_eval161000008_A_New() *A_arbace_go_check_const_eval161000008_A { t := &A_arbace_go_check_const_eval161000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_const_eval161000008_A) Ctor() {}

func (t *A_arbace_go_check_const_eval161000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_const_eval161000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_const_eval161000008_A_class }

func (t *A_arbace_go_check_const_eval161000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_const_eval161000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_const_eval161000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_const_eval161000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_const_eval161000008_A); return ok }

func A_arbace_go_check_const_eval161000008_A_Cast(x any) *A_arbace_go_check_const_eval161000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_const_eval161000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_const_eval161000008_A_class)) }; return v }



type A_arbace_go_check_const_eval161000008_fn__161000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_eval161000008_fn__161000009_A_fn_class *jrt.Class



type A_arbace_go_check_const_exact_of_double_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_exact_of_double_A_fn_class *jrt.Class



type A_arbace_go_check_const_fadd_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fadd_A_fn_class *jrt.Class



type A_arbace_go_check_const_fcmp_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fcmp_A_fn_class *jrt.Class



type A_arbace_go_check_const_float_val_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_float_val_A_fn_class *jrt.Class



type A_arbace_go_check_const_fmul_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fmul_A_fn_class *jrt.Class



type A_arbace_go_check_const_fneg_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fneg_A_fn_class *jrt.Class



type A_arbace_go_check_const_fquo_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fquo_A_fn_class *jrt.Class



type A_arbace_go_check_const_fsign_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fsign_A_fn_class *jrt.Class



type A_arbace_go_check_const_fsub_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fsub_A_fn_class *jrt.Class



type A_arbace_go_check_const_fzero_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_const_fzero_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_const_im_part_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_im_part_A_fn_class *jrt.Class



type A_arbace_go_check_const_int_val_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_int_val_A_fn_class *jrt.Class



type A_arbace_go_check_const_int_val_try_round__161000082_A struct{ j2g_header uint64; F_n int32; F_m, F_p any; F_ee int64 }

var A_arbace_go_check_const_int_val_try_round__161000082_A_fn_class *jrt.Class



type A_arbace_go_check_const_latin1_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_latin1_A_fn_class *jrt.Class



type A_arbace_go_check_const_make_rat_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_make_rat_A_fn_class *jrt.Class



type A_arbace_go_check_const_norm_int_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_norm_int_A_fn_class *jrt.Class



type A_arbace_go_check_const_pmul_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_pmul_A_fn_class *jrt.Class



type A_arbace_go_check_const_pow2_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_pow2_A_fn_class *jrt.Class



type A_arbace_go_check_const_pow5_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_pow5_A_fn_class *jrt.Class



type A_arbace_go_check_const_pquo_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_pquo_A_fn_class *jrt.Class



type A_arbace_go_check_const_rat__GT_bf_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_rat__GT_bf_A_fn_class *jrt.Class



type A_arbace_go_check_const_rat_num_den_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_rat_num_den_A_fn_class *jrt.Class



type A_arbace_go_check_const_re_part_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_re_part_A_fn_class *jrt.Class



type A_arbace_go_check_const_rnd_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_rnd_A_fn_class *jrt.Class



type A_arbace_go_check_const_round32_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_round32_A_fn_class *jrt.Class



type A_arbace_go_check_const_round64_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_round64_A_fn_class *jrt.Class



type A_arbace_go_check_const_round_binary_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_round_binary_A_fn_class *jrt.Class



type A_arbace_go_check_const_round_int_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_round_int_A_fn_class *jrt.Class



type A_arbace_go_check_const_rune_string_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_rune_string_A_fn_class *jrt.Class



type A_arbace_go_check_const_small_int_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_const_small_int_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_const_to_bf_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_to_bf_A_fn_class *jrt.Class



type A_arbace_go_check_const_to_double_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_to_double_A_fn_class *jrt.Class



type A_arbace_go_check_const_to_double_fn__161000098_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_check_const_to_double_fn__161000098_A_fn_class *jrt.Class



type A_arbace_go_check_const_utf8_value_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_utf8_value_A_fn_class *jrt.Class



type A_arbace_go_check_const_value_bytes_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_value_bytes_A_fn_class *jrt.Class



type A_arbace_go_check_const_value_text_A struct{ j2g_header uint64 }

var A_arbace_go_check_const_value_text_A_fn_class *jrt.Class
