//line j2g_strings.ae:1
package aot_arbace_go_check_const

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn3,dockn4,elsekn1,xkn2,bfkn1,cv11,arbace.core5,referR0,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn21,arbace.go.check.constm2,R1,s952,goi's checker: constant values (doc/go/GOI-SPEC.md §3.5), with go/constant's semantics.\n\n  A value's representation follows the kind of its type, as the checker carries the type\n  beside it (the operand's :type):\n\n  - booleans: true, false;\n  - strings: a String whose chars are the Go string's bytes (each 0-255, ISO-8859-1), so that\n    equality, order, concatenation and length are Go's byte-wise ones;\n  - integers (typed integer types, untyped int and rune): Long or BigInt;\n  - floats (typed floats, untyped float): an exact rational (Long, BigInt, Ratio) while\n    numerator and denominator stay below go/constant's maxExp (4096 bits), else a binary float\n    [:bf M E] (M·2^E, |M| odd below 2^512), as go/constant switches from big.Rat to big.Float\n    (prec 512); typed floats hold the rounded value, exactly;\n  - complex: [:c RE IM], each part a float as above;\n  - :unknown, the value of an operation that overflowed (go/constant's Unknown).v11,arbace.core10,bigintegerR2,v11,arbace.core7,ex-infov11,arbace.core6,pr-strv11,arbace.core5,classR3,v11,arbace.core6,bigintv21,arbace.go.check.const2,biv11,arbace.core7,vector?R4,l0,v21,arbace.go.check.const9,round-intv21,arbace.go.check.const4,precv21,arbace.go.check.const7,bf-normv11,arbace.core6,ratio?v11,arbace.core9,numeratorv11,arbace.core11,denominatorv21,arbace.go.check.const11,rat-num-denv11,arbace.core3,notv21,arbace.go.check.const4,pow2v21,arbace.go.check.const7,bit-lenv21,arbace.go.check.const7,max-expv21,arbace.go.check.const10,small-int?v21,arbace.go.check.const7,rat->bfv21,arbace.go.check.const3,bf?v21,arbace.go.check.const5,to-bfv21,arbace.go.check.const7,bf-signv21,arbace.go.check.const6,bf-addv21,arbace.go.check.const6,bf-negv11,arbace.core8,integer?v21,arbace.go.check.const8,make-ratv21,arbace.go.check.const6,bf-mulv21,arbace.go.check.const6,bf-quov21,arbace.go.check.const6,bf-cmpv21,arbace.go.check.const5,fsignv21,arbace.go.check.const6,bf-expv11,arbace.core1,<v21,arbace.go.check.const8,norm-intv21,arbace.go.check.const7,bf->ratv21,arbace.go.check.const12,round-binaryl53,l-1022,l1023,l24,l-126,l127,l-1074,v21,arbace.go.check.const7,round64v11,arbace.core6,bigdecv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core14,*math-context*v21,arbace.go.check.const6,latin1v21,arbace.go.check.const11,value-bytesv11,arbace.core2,<=l1114111,l55296,l57343,v21,arbace.go.check.const10,utf8-valuev21,arbace.go.check.const3,rndv21,arbace.go.check.const6,five27v11,arbace.core4,odd?v21,arbace.go.check.const4,pmulv21,arbace.go.check.const4,pow5v21,arbace.go.check.const4,pquov21,arbace.go.check.const17,big-float-decimalv11,arbace.core11,rationalizev21,arbace.go.check.const13,decimal-exactR5,v21,arbace.go.check.const8,complex?v21,arbace.go.check.const9,float-val")

var Lit_1 *jrt.String = jrt.Intern("not an integer value: ")

var Lit_2 *jrt.String = jrt.Intern(" ")

var Lit_3 *jrt.String = jrt.Intern("arbace.go.check.const$int_val$try_round__161000082")

var Lit_4 *jrt.String = jrt.Intern("negate")

var Lit_5 *jrt.String = jrt.Intern("arbace.go.check.const$to_double$fn__161000098")

var Lit_6 *jrt.String = jrt.Intern("doubleValue")

var Lit_7 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn1,xkn3,tagyn20,java.math.BigIntegerkn4,linekn6,columnkn4,fileyn10,BigIntegeryn4,longkn7,privateyn1,nyn6,stickyyn1,pyn1,myn1,eyn1,ryn1,_yn1,yyn5,mbitsyn4,eminyn4,emaxyn6,doubleyn5,bytesyn16,java.lang.Stringyn6,Stringyn2,e1yn2,e2yn4,precyn1,kyn10,BigDecimalyn2,reyn2,imv11,arbace.core5,in-nsMyn21,arbace.go.check.constm2,R0,s952,goi's checker: constant values (doc/go/GOI-SPEC.md §3.5), with go/constant's semantics.\n\n  A value's representation follows the kind of its type, as the checker carries the type\n  beside it (the operand's :type):\n\n  - booleans: true, false;\n  - strings: a String whose chars are the Go string's bytes (each 0-255, ISO-8859-1), so that\n    equality, order, concatenation and length are Go's byte-wise ones;\n  - integers (typed integer types, untyped int and rune): Long or BigInt;\n  - floats (typed floats, untyped float): an exact rational (Long, BigInt, Ratio) while\n    numerator and denominator stay below go/constant's maxExp (4096 bits), else a binary float\n    [:bf M E] (M·2^E, |M| odd below 2^512), as go/constant switches from big.Rat to big.Float\n    (prec 512); typed floats hold the rounded value, exactly;\n  - complex: [:c RE IM], each part a float as above;\n  - :unknown, the value of an operation that overflowed (go/constant's Unknown).m2,R0,s952,goi's checker: constant values (doc/go/GOI-SPEC.md §3.5), with go/constant's semantics.\n\n  A value's representation follows the kind of its type, as the checker carries the type\n  beside it (the operand's :type):\n\n  - booleans: true, false;\n  - strings: a String whose chars are the Go string's bytes (each 0-255, ISO-8859-1), so that\n    equality, order, concatenation and length are Go's byte-wise ones;\n  - integers (typed integer types, untyped int and rune): Long or BigInt;\n  - floats (typed floats, untyped float): an exact rational (Long, BigInt, Ratio) while\n    numerator and denominator stay below go/constant's maxExp (4096 bits), else a binary float\n    [:bf M E] (M·2^E, |M| odd below 2^512), as go/constant switches from big.Rat to big.Float\n    (prec 512); typed floats hold the rounded value, exactly;\n  - complex: [:c RE IM], each part a float as above;\n  - :unknown, the value of an operation that overflowed (go/constant's Unknown).R1,v21,arbace.go.check.const2,bim10,R2,L1,MV1,R3,m2,R4,R5,R0,s18,x as a BigInteger.R6,i20,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const8,norm-intm10,R2,L1,V1,Myn1,bm2,R4,R9,R0,s51,A BigInteger as a Long when it fits, else a BigInt.R6,i29,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const7,bit-lenm10,R2,L1,MV1,R3,m2,R4,R10,R0,s73,go/constant's BitLen of an integer: the bit length of its absolute value.R6,i34,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const3,twom8,R11,TR6,i39,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const4,pow2m8,R2,L1,MV1,R12,m2,R4,R5,R6,i41,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const4,precl512,m6,R6,i45,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const7,max-expl4096,m6,R6,i46,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const3,bf?m8,R2,L1,V1,R3,R6,i48,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const9,round-intm12,R11,TR2,L1,V3,Myn1,mm2,R4,R9,R13,R14,R0,s176,Rounds the integer m (with sticky: any nonzero bits below it already dropped) to p bits,\n  to nearest even: [m' e'] with value m'·2^e' approximating m (the exponent offset e').R6,i50,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const7,bf-normm12,R11,TR2,L2,V2,R15,R16,V3,Myn1,mm2,R4,R9,R16,R13,R0,s58,M·2^E rounded to prec bits, as [:bf M E] with M odd, or 0.R6,i68,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const11,rat-num-denm10,R11,TR2,L1,V1,R17,R6,i79,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const7,rat->bfm10,R2,L1,V1,R17,R0,s57,An exact rational rounded to a binary float of prec bits.R6,i82,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const7,bf->ratm10,R2,L1,V1,V3,R18,Myn1,mm2,R4,R9,R16,R0,s63,The exact rational of a binary float (its integer may be huge).R6,i93,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const10,small-int?m10,R11,TR2,L1,V1,R3,R6,i101,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const8,make-ratm10,R2,L1,V1,R17,R0,s86,go/constant's makeRat: the rational r, or a binary float when its parts are too large.R6,i103,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const6,bf-expm10,R2,L1,MV1,V3,R18,Myn1,mm2,R4,R9,R16,m2,R4,R10,R0,s80,go/constant's MantExp of a binary float: the exponent e with 0.5 <= |x|/2^e < 1.R6,i110,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const5,to-bfm10,R11,TR2,L1,V1,R3,R6,i115,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const7,bf-signm10,R11,TR2,L1,MV1,R3,m2,R4,R10,R6,i117,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const6,bf-addm10,R11,TR2,L1,V2,R3,R19,R6,i119,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const6,bf-negm10,R11,TR2,L1,V1,R3,R6,i138,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const6,bf-mulm10,R11,TR2,L1,V2,R3,R19,R6,i140,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const6,bf-quom10,R11,TR2,L1,V2,R3,R19,R6,i146,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const6,bf-cmpm12,R11,TR2,L1,MV2,R3,R19,m2,R4,R10,R0,s60,Compares two floats of which at least one is a binary float.R6,i154,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const9,float-valm10,R2,L1,V1,R3,R0,s51,go/constant's ToFloat of an integer or float value.R6,i161,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const4,faddm8,R2,L1,V2,R3,R19,R6,i169,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const4,fsubm8,R2,L1,V2,R3,R19,R6,i170,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const4,fmulm8,R2,L1,V2,R3,R19,R6,i171,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const4,fquom8,R2,L1,V2,R3,R19,R6,i172,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const4,fnegm8,R2,L1,V1,R3,R6,i173,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const5,fsignm8,R2,L1,MV1,R3,m2,R4,R10,R6,i174,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const4,fcmpm8,R2,L1,MV2,R3,R19,m2,R4,R10,R6,i175,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const6,fzero?m8,R2,L1,V1,R3,R6,i176,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const7,int-valm10,R2,L1,V1,R3,R0,s272,go/constant's ToInt of a float value: the integer when the value is integral, else nil.\n  A binary float within the rational range is integral when exact or when rounding it down or\n  up a little (to prec - 4 bits) gives an integer, as go/constant assumes rounding errors.R6,i178,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const12,round-binarym12,R11,TR2,L1,V4,R3,R20,R21,R22,R0,s226,The exact rational nearest (ties to even) to x among the binary floats of mbits bits of\n  mantissa and minimum normal exponent emin (float64: 53, -1022; float32: 24, -126), or nil\n  when it overflows to infinity (beyond emax).R6,i212,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const7,round64m8,R2,L1,V1,R3,R6,i246,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const7,round32m8,R2,L1,V1,R3,R6,i247,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const15,exact-of-doublem10,R2,L1,V1,Myn1,dm2,R4,R23,R0,s44,The exact rational value of a finite double.R6,i249,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const9,to-doublem10,R2,L1,MV1,R3,m2,R4,R23,R0,s64,The double nearest to a float value (infinite beyond the range).R6,i263,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const6,latin1m10,R2,L1,MV1,Myn2,bsm2,R4,R24,m2,R4,R25,R0,s52,Go string bytes as a value (a String of byte chars).R6,i274,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const10,utf8-valuem10,R2,L1,MV1,Myn1,sm2,R4,R26,m2,R4,R25,R0,s68,The value of a Go string that is the UTF-8 encoding of the String s.R6,i279,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const11,value-bytesm8,R2,L1,MV1,Myn1,vm2,R4,R26,m2,R4,R24,R6,i284,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const10,value-textm10,R2,L1,MV1,Myn1,vm2,R4,R26,m2,R4,R25,R0,s72,A string value decoded as UTF-8 (invalid bytes as U+FFFD), for messages.R6,i286,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const11,rune-stringm10,R2,L1,MV1,R17,m2,R4,R25,R0,s82,string(r) of an integer r: its UTF-8 encoding, U+FFFD when not a valid code point.R6,i291,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const3,rndm12,R11,TR2,L1,V4,Myn1,mm2,R4,R9,R16,R14,R13,R0,s86,m·2^e rounded to p bits (nearest even; sticky: nonzero bits dropped below m): [m' e'].R6,i298,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const4,pmulm10,R11,TR2,L1,V3,V2,Myn2,m1m2,R4,R9,R27,V2,Myn2,m2m2,R4,R9,R28,R14,R6,i303,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const4,pquom10,R11,TR2,L1,V3,V2,Myn2,m1m2,R4,R9,R27,V2,Myn2,m2m2,R4,R9,R28,R14,R6,i305,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const6,five27m8,R11,TR6,i310,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const4,pow5m12,R11,TR2,L1,V2,R12,R29,R0,s84,math/big's pow5: 5^n at precision prec (its multiplications rounded as big.Float's).R6,i312,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const17,big-float-decimalm12,R11,TR2,L1,V2,Myn1,dm2,R4,R9,R30,R0,s170,big.Float's SetString of a decimal D·10^k at precision 512 (math/big floatconv.go: the\n  mantissa exact, times 2^k, times or divided by 5^|k| computed at prec + 64 bits).R6,i322,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const13,decimal-exactm10,R2,L1,V1,Myn1,dm2,R4,R31,R0,s176,The value of a decimal literal (a BigDecimal): exact as a rational, or, beyond go/constant's\n  rational range, the binary float go/constant makes of it (big.Float's SetString).R6,i330,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const14,double-literalm10,R2,L1,V1,Myn1,dm2,R4,R23,R0,s88,The exact value a Clojure double denotes in Go forms: its shortest text's decimal value.R6,i344,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const12,binary-floatm10,R2,L1,V2,R15,R16,R0,s30,(binary-float M E) as a value.R6,i349,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const8,complex?m8,R2,L1,V1,R3,R6,i356,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const4,cplxm8,R2,L1,V2,R32,R33,R6,i357,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const7,re-partm8,R2,L1,V1,R3,R6,i358,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const7,im-partm8,R2,L1,V1,R3,R6,i359,R7,i1,R8,s24,arbace/go/check/const.aev21,arbace.go.check.const11,complex-valm8,R2,L1,V1,R3,R6,i360,R7,i1,R8,s24,arbace/go/check/const.ae")

var Lit_8 *jrt.String = jrt.Intern("arbace.go.check.const$eval161000004$loading__1927001464__auto____161000005")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.check.const$eval161000008$fn__161000009")

var Lit_10 *jrt.String = jrt.Intern("arbace.go.check.const$bi")

var Lit_11 *jrt.String = jrt.Intern("arbace.go.check.const$norm_int")

var Lit_12 *jrt.String = jrt.Intern("arbace.go.check.const$bit_len")

var Lit_13 *jrt.String = jrt.Intern("arbace.go.check.const$pow2")

var Lit_14 *jrt.String = jrt.Intern("arbace.go.check.const$bf_QMARK_")

var Lit_15 *jrt.String = jrt.Intern("arbace.go.check.const$round_int")

var Lit_16 *jrt.String = jrt.Intern("arbace.go.check.const$bf_norm")

var Lit_17 *jrt.String = jrt.Intern("arbace.go.check.const$rat_num_den")

var Lit_18 *jrt.String = jrt.Intern("arbace.go.check.const$rat__GT_bf")

var Lit_19 *jrt.String = jrt.Intern("arbace.go.check.const$bf__GT_rat")

var Lit_20 *jrt.String = jrt.Intern("arbace.go.check.const$small_int_QMARK_")

var Lit_21 *jrt.String = jrt.Intern("arbace.go.check.const$make_rat")

var Lit_22 *jrt.String = jrt.Intern("arbace.go.check.const$bf_exp")

var Lit_23 *jrt.String = jrt.Intern("arbace.go.check.const$to_bf")

var Lit_24 *jrt.String = jrt.Intern("arbace.go.check.const$bf_sign")

var Lit_25 *jrt.String = jrt.Intern("arbace.go.check.const$bf_add")

var Lit_26 *jrt.String = jrt.Intern("arbace.go.check.const$bf_neg")

var Lit_27 *jrt.String = jrt.Intern("arbace.go.check.const$bf_mul")

var Lit_28 *jrt.String = jrt.Intern("arbace.go.check.const$bf_quo")

var Lit_29 *jrt.String = jrt.Intern("arbace.go.check.const$bf_cmp")

var Lit_30 *jrt.String = jrt.Intern("arbace.go.check.const$float_val")

var Lit_31 *jrt.String = jrt.Intern("arbace.go.check.const$fadd")

var Lit_32 *jrt.String = jrt.Intern("arbace.go.check.const$fsub")

var Lit_33 *jrt.String = jrt.Intern("arbace.go.check.const$fmul")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.check.const$fquo")

var Lit_35 *jrt.String = jrt.Intern("arbace.go.check.const$fneg")

var Lit_36 *jrt.String = jrt.Intern("arbace.go.check.const$fsign")

var Lit_37 *jrt.String = jrt.Intern("arbace.go.check.const$fcmp")

var Lit_38 *jrt.String = jrt.Intern("arbace.go.check.const$fzero_QMARK_")

var Lit_39 *jrt.String = jrt.Intern("arbace.go.check.const$int_val")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.check.const$round_binary")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.check.const$round64")

var Lit_42 *jrt.String = jrt.Intern("arbace.go.check.const$round32")

var Lit_43 *jrt.String = jrt.Intern("arbace.go.check.const$exact_of_double")

var Lit_44 *jrt.String = jrt.Intern("arbace.go.check.const$to_double")

var Lit_45 *jrt.String = jrt.Intern("arbace.go.check.const$latin1")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.check.const$utf8_value")

var Lit_47 *jrt.String = jrt.Intern("arbace.go.check.const$value_bytes")

var Lit_48 *jrt.String = jrt.Intern("arbace.go.check.const$value_text")

var Lit_49 *jrt.String = jrt.Intern("arbace.go.check.const$rune_string")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.check.const$rnd")

var Lit_51 *jrt.String = jrt.Intern("arbace.go.check.const$pmul")

var Lit_52 *jrt.String = jrt.Intern("arbace.go.check.const$pquo")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.check.const$pow5")

var Lit_54 *jrt.String = jrt.Intern("arbace.go.check.const$big_float_decimal")

var Lit_55 *jrt.String = jrt.Intern("arbace.go.check.const$decimal_exact")

var Lit_56 *jrt.String = jrt.Intern("arbace.go.check.const$double_literal")

var Lit_57 *jrt.String = jrt.Intern("arbace.go.check.const$binary_float")

var Lit_58 *jrt.String = jrt.Intern("arbace.go.check.const$complex_QMARK_")

var Lit_59 *jrt.String = jrt.Intern("arbace.go.check.const$cplx")

var Lit_60 *jrt.String = jrt.Intern("arbace.go.check.const$re_part")

var Lit_61 *jrt.String = jrt.Intern("arbace.go.check.const$im_part")

var Lit_62 *jrt.String = jrt.Intern("arbace.go.check.const$complex_val")
