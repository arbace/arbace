//line j2g_classes.ae:1
package aot_arbace_go_check_const

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_go_check_const_bf_QMARK__A_class, Name: "arbace.go.check.const$bf_QMARK_", Modifiers: 25, Simple: "bf_QMARK_", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_bf_QMARK__A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_bf__GT_rat_A_class, Name: "arbace.go.check.const$bf__GT_rat", Modifiers: 25, Simple: "bf__GT_rat", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_bf__GT_rat_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_bf_add_A_class, Name: "arbace.go.check.const$bf_add", Modifiers: 25, Simple: "bf_add", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_bf_add_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_bf_cmp_A_class, Name: "arbace.go.check.const$bf_cmp", Modifiers: 25, Simple: "bf_cmp", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_bf_cmp_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_bf_exp_A_class, Name: "arbace.go.check.const$bf_exp", Modifiers: 25, Simple: "bf_exp", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_bf_exp_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_bf_mul_A_class, Name: "arbace.go.check.const$bf_mul", Modifiers: 25, Simple: "bf_mul", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_bf_mul_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_bf_neg_A_class, Name: "arbace.go.check.const$bf_neg", Modifiers: 25, Simple: "bf_neg", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_bf_neg_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_bf_norm_A_class, Name: "arbace.go.check.const$bf_norm", Modifiers: 25, Simple: "bf_norm", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_bf_norm_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_bf_quo_A_class, Name: "arbace.go.check.const$bf_quo", Modifiers: 25, Simple: "bf_quo", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_bf_quo_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_bf_sign_A_class, Name: "arbace.go.check.const$bf_sign", Modifiers: 25, Simple: "bf_sign", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_bf_sign_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_bi_A_class, Name: "arbace.go.check.const$bi", Modifiers: 25, Simple: "bi", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_bi_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_big_float_decimal_A_class, Name: "arbace.go.check.const$big_float_decimal", Modifiers: 25, Simple: "big_float_decimal", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_big_float_decimal_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_binary_float_A_class, Name: "arbace.go.check.const$binary_float", Modifiers: 25, Simple: "binary_float", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_binary_float_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_bit_len_A_class, Name: "arbace.go.check.const$bit_len", Modifiers: 25, Simple: "bit_len", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_bit_len_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_complex_QMARK__A_class, Name: "arbace.go.check.const$complex_QMARK_", Modifiers: 25, Simple: "complex_QMARK_", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_complex_QMARK__A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_complex_val_A_class, Name: "arbace.go.check.const$complex_val", Modifiers: 25, Simple: "complex_val", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_complex_val_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_cplx_A_class, Name: "arbace.go.check.const$cplx", Modifiers: 25, Simple: "cplx", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_cplx_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_decimal_exact_A_class, Name: "arbace.go.check.const$decimal_exact", Modifiers: 25, Simple: "decimal_exact", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_decimal_exact_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_double_literal_A_class, Name: "arbace.go.check.const$double_literal", Modifiers: 25, Simple: "double_literal", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_double_literal_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A_class, Name: "arbace.go.check.const$eval161000004$loading__1927001464__auto____161000005", Modifiers: 25, Simple: "loading__1927001464__auto____161000005", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_eval161000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_eval161000008_fn__161000009_A_class, Name: "arbace.go.check.const$eval161000008$fn__161000009", Modifiers: 25, Simple: "fn__161000009", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_eval161000008_fn__161000009_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_eval161000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_exact_of_double_A_class, Name: "arbace.go.check.const$exact_of_double", Modifiers: 25, Simple: "exact_of_double", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_exact_of_double_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_fadd_A_class, Name: "arbace.go.check.const$fadd", Modifiers: 25, Simple: "fadd", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_fadd_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_fcmp_A_class, Name: "arbace.go.check.const$fcmp", Modifiers: 25, Simple: "fcmp", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_fcmp_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_float_val_A_class, Name: "arbace.go.check.const$float_val", Modifiers: 25, Simple: "float_val", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_float_val_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_fmul_A_class, Name: "arbace.go.check.const$fmul", Modifiers: 25, Simple: "fmul", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_fmul_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_fneg_A_class, Name: "arbace.go.check.const$fneg", Modifiers: 25, Simple: "fneg", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_fneg_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_fquo_A_class, Name: "arbace.go.check.const$fquo", Modifiers: 25, Simple: "fquo", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_fquo_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_fsign_A_class, Name: "arbace.go.check.const$fsign", Modifiers: 25, Simple: "fsign", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_fsign_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_fsub_A_class, Name: "arbace.go.check.const$fsub", Modifiers: 25, Simple: "fsub", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_fsub_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_fzero_QMARK__A_class, Name: "arbace.go.check.const$fzero_QMARK_", Modifiers: 25, Simple: "fzero_QMARK_", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_fzero_QMARK__A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_im_part_A_class, Name: "arbace.go.check.const$im_part", Modifiers: 25, Simple: "im_part", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_im_part_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_int_val_A_class, Name: "arbace.go.check.const$int_val", Modifiers: 25, Simple: "int_val", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_int_val_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_int_val_try_round__161000082_A_class, Name: "arbace.go.check.const$int_val$try_round__161000082", Modifiers: 25, Simple: "try_round__161000082", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_int_val_try_round__161000082_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_int_val_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_latin1_A_class, Name: "arbace.go.check.const$latin1", Modifiers: 25, Simple: "latin1", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_latin1_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_make_rat_A_class, Name: "arbace.go.check.const$make_rat", Modifiers: 25, Simple: "make_rat", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_make_rat_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_norm_int_A_class, Name: "arbace.go.check.const$norm_int", Modifiers: 25, Simple: "norm_int", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_norm_int_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_pmul_A_class, Name: "arbace.go.check.const$pmul", Modifiers: 25, Simple: "pmul", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_pmul_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_pow2_A_class, Name: "arbace.go.check.const$pow2", Modifiers: 25, Simple: "pow2", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_pow2_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_pow5_A_class, Name: "arbace.go.check.const$pow5", Modifiers: 25, Simple: "pow5", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_pow5_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_pquo_A_class, Name: "arbace.go.check.const$pquo", Modifiers: 25, Simple: "pquo", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_pquo_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_rat__GT_bf_A_class, Name: "arbace.go.check.const$rat__GT_bf", Modifiers: 25, Simple: "rat__GT_bf", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_rat__GT_bf_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_rat_num_den_A_class, Name: "arbace.go.check.const$rat_num_den", Modifiers: 25, Simple: "rat_num_den", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_rat_num_den_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_re_part_A_class, Name: "arbace.go.check.const$re_part", Modifiers: 25, Simple: "re_part", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_re_part_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_rnd_A_class, Name: "arbace.go.check.const$rnd", Modifiers: 25, Simple: "rnd", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_rnd_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_round32_A_class, Name: "arbace.go.check.const$round32", Modifiers: 25, Simple: "round32", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_round32_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_round64_A_class, Name: "arbace.go.check.const$round64", Modifiers: 25, Simple: "round64", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_round64_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_round_binary_A_class, Name: "arbace.go.check.const$round_binary", Modifiers: 25, Simple: "round_binary", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_round_binary_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_round_int_A_class, Name: "arbace.go.check.const$round_int", Modifiers: 25, Simple: "round_int", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_round_int_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_rune_string_A_class, Name: "arbace.go.check.const$rune_string", Modifiers: 25, Simple: "rune_string", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_rune_string_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_small_int_QMARK__A_class, Name: "arbace.go.check.const$small_int_QMARK_", Modifiers: 25, Simple: "small_int_QMARK_", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_small_int_QMARK__A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_to_bf_A_class, Name: "arbace.go.check.const$to_bf", Modifiers: 25, Simple: "to_bf", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_to_bf_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_to_double_A_class, Name: "arbace.go.check.const$to_double", Modifiers: 25, Simple: "to_double", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_to_double_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_to_double_fn__161000098_A_class, Name: "arbace.go.check.const$to_double$fn__161000098", Modifiers: 25, Simple: "fn__161000098", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_to_double_fn__161000098_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_to_double_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_utf8_value_A_class, Name: "arbace.go.check.const$utf8_value", Modifiers: 25, Simple: "utf8_value", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_utf8_value_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_value_bytes_A_class, Name: "arbace.go.check.const$value_bytes", Modifiers: 25, Simple: "value_bytes", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_value_bytes_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_const_value_text_A_class, Name: "arbace.go.check.const$value_text", Modifiers: 25, Simple: "value_text", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_value_text_A", Source: "const.ae", Declaring: &A_arbace_go_check_const_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_go_check_const_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_check_const_A_New()}; return nil }

var A_arbace_go_check_const_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_check_const_A_new}

var A_arbace_go_check_const_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.check.const", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_A"})

func init() { i := A_arbace_go_check_const_A_class.Info(); i.IsInstance = A_arbace_go_check_const_A_InstanceOf; i.Init = A_arbace_go_check_const_A_Init; i.Table = A_arbace_go_check_const_A_members }

var A_arbace_go_check_const_bf_QMARK__A_class *jrt.Class

var A_arbace_go_check_const_bf__GT_rat_A_class *jrt.Class

var A_arbace_go_check_const_bf_add_A_class *jrt.Class

var A_arbace_go_check_const_bf_cmp_A_class *jrt.Class

var A_arbace_go_check_const_bf_exp_A_class *jrt.Class

var A_arbace_go_check_const_bf_mul_A_class *jrt.Class

var A_arbace_go_check_const_bf_neg_A_class *jrt.Class

var A_arbace_go_check_const_bf_norm_A_class *jrt.Class

var A_arbace_go_check_const_bf_quo_A_class *jrt.Class

var A_arbace_go_check_const_bf_sign_A_class *jrt.Class

var A_arbace_go_check_const_bi_A_class *jrt.Class

var A_arbace_go_check_const_big_float_decimal_A_class *jrt.Class

var A_arbace_go_check_const_binary_float_A_class *jrt.Class

var A_arbace_go_check_const_bit_len_A_class *jrt.Class

var A_arbace_go_check_const_complex_QMARK__A_class *jrt.Class

var A_arbace_go_check_const_complex_val_A_class *jrt.Class

var A_arbace_go_check_const_cplx_A_class *jrt.Class

var A_arbace_go_check_const_decimal_exact_A_class *jrt.Class

var A_arbace_go_check_const_double_literal_A_class *jrt.Class

func A_arbace_go_check_const_eval161000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_check_const_eval161000004_A_New()}; return nil }

var A_arbace_go_check_const_eval161000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_check_const_eval161000004_A_new}

var A_arbace_go_check_const_eval161000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.check.const$eval161000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_check_const_A_class, Simple: "eval161000004", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_eval161000004_A"})

func init() { i := A_arbace_go_check_const_eval161000004_A_class.Info(); i.IsInstance = A_arbace_go_check_const_eval161000004_A_InstanceOf; i.Table = A_arbace_go_check_const_eval161000004_A_members }

var A_arbace_go_check_const_eval161000004_loading__1927001464__auto____161000005_A_class *jrt.Class

func A_arbace_go_check_const_eval161000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_check_const_eval161000008_A_New()}; return nil }

var A_arbace_go_check_const_eval161000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_check_const_eval161000008_A_new}

var A_arbace_go_check_const_eval161000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.check.const$eval161000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_check_const_A_class, Simple: "eval161000008", Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const_eval161000008_A"})

func init() { i := A_arbace_go_check_const_eval161000008_A_class.Info(); i.IsInstance = A_arbace_go_check_const_eval161000008_A_InstanceOf; i.Table = A_arbace_go_check_const_eval161000008_A_members }

var A_arbace_go_check_const_eval161000008_fn__161000009_A_class *jrt.Class

var A_arbace_go_check_const_exact_of_double_A_class *jrt.Class

var A_arbace_go_check_const_fadd_A_class *jrt.Class

var A_arbace_go_check_const_fcmp_A_class *jrt.Class

var A_arbace_go_check_const_float_val_A_class *jrt.Class

var A_arbace_go_check_const_fmul_A_class *jrt.Class

var A_arbace_go_check_const_fneg_A_class *jrt.Class

var A_arbace_go_check_const_fquo_A_class *jrt.Class

var A_arbace_go_check_const_fsign_A_class *jrt.Class

var A_arbace_go_check_const_fsub_A_class *jrt.Class

var A_arbace_go_check_const_fzero_QMARK__A_class *jrt.Class

var A_arbace_go_check_const_im_part_A_class *jrt.Class

var A_arbace_go_check_const_int_val_A_class *jrt.Class

var A_arbace_go_check_const_int_val_try_round__161000082_A_class *jrt.Class

var A_arbace_go_check_const_latin1_A_class *jrt.Class

var A_arbace_go_check_const_make_rat_A_class *jrt.Class

var A_arbace_go_check_const_norm_int_A_class *jrt.Class

var A_arbace_go_check_const_pmul_A_class *jrt.Class

var A_arbace_go_check_const_pow2_A_class *jrt.Class

var A_arbace_go_check_const_pow5_A_class *jrt.Class

var A_arbace_go_check_const_pquo_A_class *jrt.Class

var A_arbace_go_check_const_rat__GT_bf_A_class *jrt.Class

var A_arbace_go_check_const_rat_num_den_A_class *jrt.Class

var A_arbace_go_check_const_re_part_A_class *jrt.Class

var A_arbace_go_check_const_rnd_A_class *jrt.Class

var A_arbace_go_check_const_round32_A_class *jrt.Class

var A_arbace_go_check_const_round64_A_class *jrt.Class

var A_arbace_go_check_const_round_binary_A_class *jrt.Class

var A_arbace_go_check_const_round_int_A_class *jrt.Class

var A_arbace_go_check_const_rune_string_A_class *jrt.Class

var A_arbace_go_check_const_small_int_QMARK__A_class *jrt.Class

var A_arbace_go_check_const_to_bf_A_class *jrt.Class

var A_arbace_go_check_const_to_double_A_class *jrt.Class

var A_arbace_go_check_const_to_double_fn__161000098_A_class *jrt.Class

var A_arbace_go_check_const_utf8_value_A_class *jrt.Class

var A_arbace_go_check_const_value_bytes_A_class *jrt.Class

var A_arbace_go_check_const_value_text_A_class *jrt.Class

func A_arbace_go_check_const__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_go_check_const__init_A_Load__O()}; return nil }

func A_arbace_go_check_const__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_check_const__init_A_New()}; return nil }

var A_arbace_go_check_const__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_go_check_const__init_A_invoke, New: A_arbace_go_check_const__init_A_new}

var A_arbace_go_check_const__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.check.const__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_check_const.A_arbace_go_check_const__init_A", Source: "const.ae"})

func init() { i := A_arbace_go_check_const__init_A_class.Info(); i.IsInstance = A_arbace_go_check_const__init_A_InstanceOf; i.Init = A_arbace_go_check_const__init_A_Init; i.Table = A_arbace_go_check_const__init_A_members }
