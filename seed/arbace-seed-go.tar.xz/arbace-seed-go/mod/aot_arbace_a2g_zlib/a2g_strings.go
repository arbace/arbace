//line a2g_strings.ae:1
package aot_arbace_a2g_zlib

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("commute")

var Lit_3 *jrt.String = jrt.Intern("deref")

var Lit_4 *jrt.String = jrt.Intern("conj")

var Lit_5 *jrt.String = jrt.Intern("arbace.a2g.zlib")

var Lit_6 *jrt.String = jrt.Intern("doc")

var Lit_7 *jrt.String = jrt.Intern("A zlib stream (RFC 1950) of DEFLATE data (RFC 1951) written in Arbace, for the resources\n  bin/a2g --program embeds compressed (amendment SZ2): the same bytes on every host, the JVM's\n  and the Go executable's (doc/STANDALONE-NOTES.md, S3, SA21), where the JVM's\n  java.util.zip.Deflater (zlib's C code) exists on the JVM only and Go's compress/flate writes\n  other bytes. jrt's InflaterInputStream (Go's compress/zlib) and the JDK's read it.\n\n  The compressor: LZ77 over the whole input (a 32 KB window, matches of 3 to 258 bytes, hash\n  chains of 3-byte prefixes searched to a fixed depth, one step of lazy matching, as zlib's\n  deflate_slow), then blocks of at most 16,384 symbols, each with its own Huffman codes\n  (dynamic blocks; lengths limited to 15 bits, 7 for the code length code, by halving the\n  frequencies until the code fits). Every choice is integer arithmetic and ties broken by\n  symbol, so the output depends on the input alone.")

var Lit_8 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_9 *jrt.String = jrt.Intern("filterv")

var Lit_10 *jrt.String = jrt.Intern("empty?")

var Lit_11 *jrt.String = jrt.Intern("else")

var Lit_12 *jrt.String = jrt.Intern("into")

var Lit_13 *jrt.String = jrt.Intern("first")

var Lit_14 *jrt.String = jrt.Intern("disj")

var Lit_15 *jrt.String = jrt.Intern("reduce")

var Lit_16 *jrt.String = jrt.Intern("range")

var Lit_17 *jrt.String = jrt.Intern("sorted-set")

var Lit_18 *jrt.String = jrt.Intern("map")

var Lit_19 *jrt.String = jrt.Intern("reverse-bits")

var Lit_20 *jrt.String = jrt.Intern("match-length")

var Lit_21 *jrt.String = jrt.Intern("longest")

var Lit_22 *jrt.String = jrt.Intern("insert!")

var Lit_23 *jrt.String = jrt.Intern("vec")

var Lit_24 *jrt.String = jrt.Intern("huffman-lengths")

var Lit_25 *jrt.String = jrt.Intern("canonical-codes")

var Lit_26 *jrt.String = jrt.Intern("last")

var Lit_27 *jrt.String = jrt.Intern("rle-lengths")

var Lit_28 *jrt.String = jrt.Intern("seq")

var Lit_29 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_30 *jrt.String = jrt.Intern("chunk-first")

var Lit_31 *jrt.String = jrt.Intern("chunk-rest")

var Lit_32 *jrt.String = jrt.Intern("next")

var Lit_33 *jrt.String = jrt.Intern("take-while")

var Lit_34 *jrt.String = jrt.Intern("filter")

var Lit_35 *jrt.String = jrt.Intern("bit-test")

var Lit_36 *jrt.String = jrt.Intern("code-of")

var Lit_37 *jrt.String = jrt.Intern("len-base")

var Lit_38 *jrt.String = jrt.Intern("dist-base")

var Lit_39 *jrt.String = jrt.Intern("concat")

var Lit_40 *jrt.String = jrt.Intern("take")

var Lit_41 *jrt.String = jrt.Intern("reverse")

var Lit_42 *jrt.String = jrt.Intern("cl-order")

var Lit_43 *jrt.String = jrt.Intern("dist-extra")

var Lit_44 *jrt.String = jrt.Intern("len-extra")

var Lit_45 *jrt.String = jrt.Intern("lz77")

var Lit_46 *jrt.String = jrt.Intern("write-block!")

var Lit_47 *jrt.String = jrt.Intern("adler32")

var Lit_48 *jrt.String = jrt.Intern("arbace.a2g.zlib$adler32")

var Lit_49 *jrt.String = jrt.Intern("arbace.a2g.zlib$canonical_codes")

var Lit_50 *jrt.String = jrt.Intern("arbace.a2g.zlib$code_of")

var Lit_51 *jrt.String = jrt.Intern("arbace.a2g.zlib$deflate")

var Lit_52 *jrt.String = jrt.Intern("arbace.a2g.zlib$eval274000004$loading__1927001464__auto____274000005")

var Lit_53 *jrt.String = jrt.Intern("java.io.ByteArrayOutputStream")

var Lit_54 *jrt.String = jrt.Intern("arbace.a2g.zlib$eval274000008$fn__274000009")

var Lit_55 *jrt.String = jrt.Intern("arbace.a2g.zlib$eval274000012$__GT_Bits__274000014")

var Lit_56 *jrt.String = jrt.Intern("arbace.a2g.zlib$huffman_lengths")

var Lit_57 *jrt.String = jrt.Intern("arbace.a2g.zlib$huffman_lengths$fn__274000019")

var Lit_58 *jrt.String = jrt.Intern("arbace.a2g.zlib$huffman_lengths$fn__274000021")

var Lit_59 *jrt.String = jrt.Intern("arbace.a2g.zlib$huffman_lengths$fn__274000023")

var Lit_60 *jrt.String = jrt.Intern("arbace.a2g.zlib$huffman_lengths$fn__274000025")

var Lit_61 *jrt.String = jrt.Intern("arbace.a2g.zlib$huffman_lengths$fn__274000025$fn__274000026")

var Lit_62 *jrt.String = jrt.Intern("arbace.a2g.zlib$insert_BANG_")

var Lit_63 *jrt.String = jrt.Intern("arbace.a2g.zlib$longest")

var Lit_64 *jrt.String = jrt.Intern("arbace.a2g.zlib$lz77")

var Lit_65 *jrt.String = jrt.Intern("arbace.a2g.zlib$match_length")

var Lit_66 *jrt.String = jrt.Intern("arbace.a2g.zlib$reverse_bits")

var Lit_67 *jrt.String = jrt.Intern("arbace.a2g.zlib$rle_lengths")

var Lit_68 *jrt.String = jrt.Intern("arbace.a2g.zlib$rle_lengths$fn__274000038")

var Lit_69 *jrt.String = jrt.Intern("arbace.a2g.zlib$write_block_BANG_")

var Lit_70 *jrt.String = jrt.Intern("arbace.a2g.zlib$write_block_BANG_$fn__274000045")

var Lit_71 *jrt.String = jrt.Intern("arbace.a2g.zlib$write_block_BANG_$fn__274000047")

var Lit_72 *jrt.String = jrt.Intern("arbace.a2g.zlib$write_block_BANG_$fn__274000049")

var Lit_73 *jrt.String = jrt.Intern("arbace.a2g.zlib$write_block_BANG_$fn__274000055")

var Lit_74 *jrt.String = jrt.Intern("arbace.a2g.zlib$write_block_BANG_$fn__274000063")

var Lit_75 *jrt.String = jrt.Intern("out")

var Lit_76 *jrt.String = jrt.Intern("tag")

var Lit_77 *jrt.String = jrt.Intern("ByteArrayOutputStream")

var Lit_78 *jrt.String = jrt.Intern("acc")

var Lit_79 *jrt.String = jrt.Intern("long")

var Lit_80 *jrt.String = jrt.Intern("unsynchronized-mutable")

var Lit_81 *jrt.String = jrt.Intern("n")

var Lit_82 *jrt.String = jrt.Intern("in-ns")

var Lit_83 *jrt.String = jrt.Intern("arbace.a2g.zlib.Bits")

var Lit_84 *jrt.String = jrt.Intern("->Bits")

var Lit_85 *jrt.String = jrt.Intern("arglists")

var Lit_86 *jrt.String = jrt.Intern("Positional factory function for class arbace.a2g.zlib.Bits.")

var Lit_87 *jrt.String = jrt.Intern("line")

var Lit_88 *jrt.String = jrt.Intern("column")

var Lit_89 *jrt.String = jrt.Intern("file")

var Lit_90 *jrt.String = jrt.Intern("arbace/a2g/zlib.ae")

var Lit_91 *jrt.String = jrt.Intern("private")

var Lit_92 *jrt.String = jrt.Intern("code")

var Lit_93 *jrt.String = jrt.Intern("len")

var Lit_94 *jrt.String = jrt.Intern("freqs")

var Lit_95 *jrt.String = jrt.Intern("longs")

var Lit_96 *jrt.String = jrt.Intern("limit")

var Lit_97 *jrt.String = jrt.Intern("The code lengths (a long array) of a Huffman code for the frequencies freqs (a long array),\n  at most limit bits each; 0 for an absent symbol. Ties are broken by symbol order. A single\n  used symbol gets length 1.")

var Lit_98 *jrt.String = jrt.Intern("lens")

var Lit_99 *jrt.String = jrt.Intern("The codes (a long array, bit-reversed for writing) of the code lengths lens (RFC 1951\n  §3.2.2).")

var Lit_100 *jrt.String = jrt.Intern("[J")

var Lit_101 *jrt.String = jrt.Intern("bases")

var Lit_102 *jrt.String = jrt.Intern("v")

var Lit_103 *jrt.String = jrt.Intern("The index of the last base in bases (a long array) at most v.")

var Lit_104 *jrt.String = jrt.Intern("window")

var Lit_105 *jrt.String = jrt.Intern("const")

var Lit_106 *jrt.String = jrt.Intern("max-chain")

var Lit_107 *jrt.String = jrt.Intern("nice-length")

var Lit_108 *jrt.String = jrt.Intern("b")

var Lit_109 *jrt.String = jrt.Intern("bytes")

var Lit_110 *jrt.String = jrt.Intern("i")

var Lit_111 *jrt.String = jrt.Intern("j")

var Lit_112 *jrt.String = jrt.Intern("max")

var Lit_113 *jrt.String = jrt.Intern("The length of the common prefix of b at i and at j (< i), at most max.")

var Lit_114 *jrt.String = jrt.Intern("head")

var Lit_115 *jrt.String = jrt.Intern("ints")

var Lit_116 *jrt.String = jrt.Intern("prev")

var Lit_117 *jrt.String = jrt.Intern("Enters position i of b (n bytes) into the hash chains: prev[i] is the last position before i\n  whose 3 bytes hash as i's, head[h] the last position of hash h.")

var Lit_118 *jrt.String = jrt.Intern("The longest match for position i of b along its hash chain: (length << 16 | distance), or\n  0 when none is 3 bytes long.")

var Lit_119 *jrt.String = jrt.Intern("The symbols of b: a long array of entries, a literal byte v as v, a match as\n  (length << 16 | distance) with bit 40 set; and their count.")

var Lit_120 *jrt.String = jrt.Intern("block-symbols")

var Lit_121 *jrt.String = jrt.Intern("ls")

var Lit_122 *jrt.String = jrt.Intern("The code length code's symbols for the lengths ls (RFC 1951 §3.2.7): [symbol extra-value].")

var Lit_123 *jrt.String = jrt.Intern("w")

var Lit_124 *jrt.String = jrt.Intern("Bits")

var Lit_125 *jrt.String = jrt.Intern("syms")

var Lit_126 *jrt.String = jrt.Intern("from")

var Lit_127 *jrt.String = jrt.Intern("to")

var Lit_128 *jrt.String = jrt.Intern("last?")

var Lit_129 *jrt.String = jrt.Intern("Writes the symbols syms[from, to) as one dynamic block (last? sets BFINAL).")

var Lit_130 *jrt.String = jrt.Intern("deflate")

var Lit_131 *jrt.String = jrt.Intern("bytes b as a zlib stream (RFC 1950): the header (deflate, a 32 KB window, the maximum\n  compression level's flag, as the JDK's Deflater at level 9), DEFLATE blocks, the Adler-32 of\n  b.")
