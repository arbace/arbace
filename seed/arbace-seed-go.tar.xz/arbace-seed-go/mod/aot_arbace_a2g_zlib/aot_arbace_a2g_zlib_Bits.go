//line aot_arbace_a2g_zlib_Bits.ae:1
package aot_arbace_a2g_zlib

import (
	"arbace/jrt"
	"arbace/lang"
)












func A_arbace_a2g_zlib_Bits_A_New_O_J_J(p0 any, p1, p2 int64) *A_arbace_a2g_zlib_Bits_A { t := &A_arbace_a2g_zlib_Bits_A{}; t.Ctor_O_J_J(p0, p1, p2); return t }
//line :19:1
func (t *A_arbace_a2g_zlib_Bits_A) Ctor_O_J_J(out any, acc, n int64) { t.F_out = out; t.F_acc = acc; t.F_n = n }
//line :19:1
func A_arbace_a2g_zlib_Bits_A_GetBasis__IPersistentVector() lang.IPersistentVector { var tmp1 any = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_75)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_77).Ref()))); var tmp2 lang.IObj = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_78)); var tmp3 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(); var tmp4 any = lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref(); var tmp5 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(); var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; var tmp7 any = tmp2.WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6.Ref()))); var tmp8 lang.IObj = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_81)); var tmp9 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(); var tmp10 any = lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref(); var tmp11 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(); var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_TRUE; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp1, tmp7, tmp8.WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12.Ref())))) }
//line :19:1
func (t *A_arbace_a2g_zlib_Bits_A) Invoke__O() any {















	if lang.Numbers_IsPos_J__Z(t.F_n) { var tmp1 *jrt.ByteArrayOutputStream = jrt.ByteArrayOutputStream_Cast(t.F_out); jrt.NN(tmp1).Write_I__V(lang.RT_IntCast_J__I(lang.Numbers_And_J_J__J(t.F_acc, 255))) }
//line :19:1
	t.F_acc = 0; t.F_n = 0; return t }
//line :19:1
func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O__O(v__1, k__2 any) any { var tmp1 int64 = t.F_acc; t.F_acc = lang.Numbers_Or_J_J__J(tmp1, lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(v__1), t.F_n)); var tmp2 int64 = t.F_n; t.F_n = lang.Numbers_Add_J_J__J(tmp2, lang.RT_LongCast_O__J(k__2)); L1: for {







	if lang.Numbers_Gte_J_J__Z(t.F_n, 8) {
		var tmp3 *jrt.ByteArrayOutputStream = jrt.ByteArrayOutputStream_Cast(t.F_out); jrt.NN(tmp3).Write_I__V(lang.RT_IntCast_J__I(lang.Numbers_And_J_J__J(t.F_acc, 255)))
//line :27:1
		t.F_acc = lang.Numbers_UnsignedShiftRight_J_J__J(t.F_acc, 8); t.F_n = lang.Numbers_Minus_J_J__J(t.F_n, 8)



		continue L1 }
//line :19:1
	break L1 }; return t }











type A_arbace_a2g_zlib_Bits_A struct{ jrt.Object; F_out any; F_acc, F_n int64 }

func (t *A_arbace_a2g_zlib_Bits_A) Is_IFn() {}

func (t *A_arbace_a2g_zlib_Bits_A) Is_IType() {}

func (t *A_arbace_a2g_zlib_Bits_A) Is_Callable() {}

func (t *A_arbace_a2g_zlib_Bits_A) Is_Runnable() {}

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O_O_O_O_O_O_O_O_O__O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O_O_O__O(p0, p1, p2, p3, p4, p5 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Run__V() { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.run()V")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O_O_O_O_O__O(p0, p1, p2, p3, p4, p5, p6, p7 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O__O(p0 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O__O(p0, p1, p2 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O1__O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19 any, p20 *jrt.RefArray) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O_O_O_O_O_O_O__O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O_O_O_O__O(p0, p1, p2, p3, p4, p5, p6 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O__O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O__O(p0, p1, p2, p3 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O_O__O(p0, p1, p2, p3, p4 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O_O_O_O_O_O__O(p0, p1, p2, p3, p4, p5, p6, p7, p8 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Call__O() any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.call()Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) ApplyTo_ISeq__O(p0 lang.ISeq) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.applyTo(Larbace/lang/ISeq;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.a2g.zlib.Bits.invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_a2g_zlib_Bits_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_Bits_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_Bits_A_class }

func (t *A_arbace_a2g_zlib_Bits_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_Bits_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_Bits_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_Bits_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_Bits_A); return ok }

func A_arbace_a2g_zlib_Bits_A_Cast(x any) *A_arbace_a2g_zlib_Bits_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_Bits_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_Bits_A_class)) }; return v }
