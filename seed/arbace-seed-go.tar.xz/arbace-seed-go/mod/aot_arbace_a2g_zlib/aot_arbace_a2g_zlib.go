//line aot_arbace_a2g_zlib.ae:1
package aot_arbace_a2g_zlib

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_New() *A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A { A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_Init(); t := &A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp4 = A_arbace_a2g_zlib_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_a2g_zlib_A_Init(); tmp6 = A_arbace_a2g_zlib_A_const_1; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; lang.RT_Init(); tmp7 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp7).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_53)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp8 != nil { panic(tmp8) }; return tmp3 }
//line :1:1
func A_arbace_a2g_zlib_eval274000008_fn__274000009_A_New() *A_arbace_a2g_zlib_eval274000008_fn__274000009_A { A_arbace_a2g_zlib_eval274000008_fn__274000009_A_Init(); t := &A_arbace_a2g_zlib_eval274000008_fn__274000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_zlib_eval274000008_fn__274000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_zlib_eval274000008_fn__274000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp1 = A_arbace_a2g_zlib_A_const_2; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp3 = A_arbace_a2g_zlib_A_const_3; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp5 = A_arbace_a2g_zlib_A_const_6; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp7 = A_arbace_a2g_zlib_A_const_4; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_a2g_zlib_A_Init(); tmp9 = A_arbace_a2g_zlib_A_const_5; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }

















func A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_New() *A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A { A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_Init(); t := &A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A) Ctor() {}
//line :19:1
func (t *A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A) Invoke_O_O_O_O__O(self, out__1, acc__2, n__3 any) any { return A_arbace_a2g_zlib_Bits_A_New_O_J_J(out__1, lang.RT_LongCast_O__J(acc__2), lang.RT_LongCast_O__J(n__3)) }



















func A_arbace_a2g_zlib_reverse_bits_A_New() *A_arbace_a2g_zlib_reverse_bits_A { A_arbace_a2g_zlib_reverse_bits_A_Init(); t := &A_arbace_a2g_zlib_reverse_bits_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_a2g_zlib_reverse_bits_A) Ctor() {}
//line :39:1
func (t *A_arbace_a2g_zlib_reverse_bits_A) Invoke_O_O_O__O(self, p_code__0, p_len__1 any) any { var code__0 int64 = lang.RT_LongCast_O__J(p_code__0); var len__1 int64 = lang.RT_LongCast_O__J(p_len__1); var tmp1 int64; var c__3 int64 = code__0; var r__4 int64 = 0; var i__5 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z(i__5, len__1) { c__3, r__4, i__5 = lang.Numbers_ShiftRight_J_J__J(c__3, 1), lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_J_J__J(r__4, 1), lang.Numbers_And_J_J__J(c__3, 1)), lang.Numbers_Inc_J__J(i__5); continue L1 } else { tmp1 = r__4 }
//line :39:1
	break L1 }; return jrt.Long_ValueOf_J__Long(tmp1).Ref() }






func A_arbace_a2g_zlib_huffman_lengths_A_New() *A_arbace_a2g_zlib_huffman_lengths_A { A_arbace_a2g_zlib_huffman_lengths_A_Init(); t := &A_arbace_a2g_zlib_huffman_lengths_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_a2g_zlib_huffman_lengths_A) Ctor() {}
//line :46:1
func (t *A_arbace_a2g_zlib_huffman_lengths_A) Invoke_O_O_O__O(self, freqs__0, p_limit__1 any) any { { var limit__1 int64 = lang.RT_LongCast_O__J(p_limit__1); var n__3 int32 = lang.RT_Alength_J1__I(jrt.A2g_CastArray[*jrt.LongArray](freqs__0, jrt.Prim_long.ArrayClass())); var fs__4 any = lang.RT_Aclone_J1__J1(jrt.A2g_CastArray[*jrt.LongArray](freqs__0, jrt.Prim_long.ArrayClass())).Ref(); L1: for { var syms__5 any; var tmp1 *lang.Var






	A_arbace_a2g_zlib_A_Init(); tmp1 = A_arbace_a2g_zlib_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_New_O(fs__4); var tmp4 *jrt.Class; A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_Init(); tmp4 = A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp6 = A_arbace_a2g_zlib_A_const_14; syms__5 = tmp2.Invoke_O_O__O(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(n__3).Ref()))
//line :46:1
	var lens__6 any = lang.Numbers_Long_array_O__J1(jrt.Integer_ValueOf_I__Integer(n__3).Ref()).Ref(); var tmp7 *lang.Var








	A_arbace_a2g_zlib_A_Init(); tmp7 = A_arbace_a2g_zlib_A_const_8; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(syms__5)) { return lens__6 } else { if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(syms__5))) {

		var tmp8 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](lens__6, jrt.Prim_long.ArrayClass()); var tmp9 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp9 = A_arbace_a2g_zlib_A_const_11; jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(tmp8, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(syms__5))), 1))
//line :55:1
		return lens__6 } else { var tmp10 *lang.Keyword; A_arbace_a2g_zlib_A_Init(); tmp10 = A_arbace_a2g_zlib_A_const_9; if tmp10 != nil { var parent__7 any = lang.Numbers_Long_array_O__J1(jrt.Long_ValueOf_J__Long(lang.Numbers_Multiply_J_J__J(2, int64(n__3))).Ref()).Ref(); var start__8 any; var tmp11 *lang.Var






			A_arbace_a2g_zlib_A_Init(); tmp11 = A_arbace_a2g_zlib_A_const_10; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp13 = A_arbace_a2g_zlib_A_const_15; var tmp14 any = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke__O(); var tmp15 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp15 = A_arbace_a2g_zlib_A_const_16; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any = A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_New_O(fs__4); var tmp18 *jrt.Class; A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_Init(); tmp18 = A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_fn_class; start__8 = tmp12.Invoke_O_O__O(tmp14, tmp16.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil), syms__5))
//line :55:1
			var ___9 any; var tmp19 any = A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_New_O_I_O(parent__7, n__3, start__8); var tmp20 *jrt.Class; _ = ___9







			A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_Init(); tmp20 = A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_fn_class; ___9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil).Invoke__O()
//line :55:1
			var root__10 int64 = lang.Numbers_Add_J_J__J(lang.Numbers_Add_J_J__J(int64(n__3), lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(syms__5)))), -1); var maxlen__11 any; var tmp21 *lang.Var















			A_arbace_a2g_zlib_A_Init(); tmp21 = A_arbace_a2g_zlib_A_const_13; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any = A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_New_O_O_J(parent__7, lens__6, root__10); var tmp24 *jrt.Class; A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_Init(); tmp24 = A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_fn_class; var tmp25 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); var tmp26 any; A_arbace_a2g_zlib_A_Init(); tmp26 = A_arbace_a2g_zlib_A_const_17; maxlen__11 = tmp22.Invoke_O_O_O__O(tmp25, tmp26, syms__5)




			if lang.Numbers_Lte_O_J__Z(maxlen__11, limit__1) { return lens__6 } else { var f2__12 any = lang.Numbers_Long_array_O__J1(jrt.Integer_ValueOf_I__Integer(n__3).Ref()).Ref(); var n__1927000701__auto____13 int64 = lang.RT_LongCast_I__J(n__3); var i__14 int64 = 0; L2: for {


				if lang.Numbers_Lt_J_J__Z(i__14, n__1927000701__auto____13) { var f__15 int64 = lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](fs__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(i__14))
					if lang.Numbers_IsPos_J__Z(f__15) { jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.A2g_CastArray[*jrt.LongArray](f2__12, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(i__14), lang.Numbers_Max_J_J__J(1, lang.Numbers_ShiftRight_J_J__J(f__15, 1)))) }
//line :79:1
					i__14 = lang.Numbers_Unchecked_inc_J__J(i__14); continue L2 }
//line :76:1
				break L2
			}



				fs__4 = f2__12; continue L1 } } else {
//line :55:1
					return nil } } } } }; /*line :46:1*/panic("a2g: unreachable") }






func A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_New_O(p0 any) *A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A { A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_Init(); t := &A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A{}; t.Ctor_O(p0); return t }
//line :53:1
func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A) Ctor_O(c__fs any) { t.F_fs = c__fs }
//line :53:1
func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A) Invoke_O_O__O(self, p1__274000018_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](t.F_fs, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_J__Z(lang.RT_Aget_J1_I__J(tmp1, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(p1__274000018_SHARP___1))))).Ref() }








func A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_New_O(p0 any) *A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A { A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_Init(); t := &A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A{}; t.Ctor_O(p0); return t }
//line :62:1
func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A) Ctor_O(c__fs any) { t.F_fs = c__fs }
//line :62:1
func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A) Invoke_O_O__O(self, s__1 any) any { var tmp1 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](t.F_fs, jrt.Prim_long.ArrayClass()); return lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(tmp1, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__1)))).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(s__1)).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(s__1)).Ref()) }
func A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A { A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_Init(); t := &A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :63:1
func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A) Ctor_O_I_O(c__parent any, c__n int32, c__start any) { t.F_parent = c__parent; t.F_n = c__n; t.F_start = c__start }
//line :63:1
func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A) Invoke_O__O(self any) any { { var q__1 any; var t_ any = t.F_start; t.F_start = nil; q__1 = t_; var next_id__2 int64 = lang.RT_LongCast_I__J(t.F_n); var order__3 int64 = lang.RT_LongCast_I__J(t.F_n); L1: for {
											if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(q__1)), 1) { var a__4 any; var tmp1 *lang.Var
												A_arbace_a2g_zlib_A_Init(); tmp1 = A_arbace_a2g_zlib_A_const_11; a__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(q__1)
//line :64:1
		var q__5 any; var tmp2 *lang.Var
		A_arbace_a2g_zlib_A_Init(); tmp2 = A_arbace_a2g_zlib_A_const_12; q__5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(q__1, a__4)
//line :64:1
		var b__6 any; var tmp3 *lang.Var
		A_arbace_a2g_zlib_A_Init(); tmp3 = A_arbace_a2g_zlib_A_const_11; b__6 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(q__5)
//line :64:1
		var q__7 any; var tmp4 *lang.Var
		A_arbace_a2g_zlib_A_Init(); tmp4 = A_arbace_a2g_zlib_A_const_12; q__7 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(q__5, b__6)
		var tmp5 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](t.F_parent, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(tmp5, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(lang.RT_Nth_O_I__O(a__4, lang.RT_IntCast_J__I(2)))), next_id__2))
		var tmp6 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](t.F_parent, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(tmp6, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(lang.RT_Nth_O_I__O(b__6, lang.RT_IntCast_J__I(2)))), next_id__2))
		var tmp7 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp7 = A_arbace_a2g_zlib_A_const_4; q__1, next_id__2, order__3 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(q__7, lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(a__4, lang.RT_IntCast_J__I(0))), lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(b__6, lang.RT_IntCast_J__I(0))))).Ref(), jrt.Long_ValueOf_J__Long(order__3).Ref(), jrt.Long_ValueOf_J__Long(next_id__2).Ref())), lang.Numbers_Inc_J__J(next_id__2), lang.Numbers_Inc_J__J(order__3); continue L1 } else {
//line :64:1
			return nil } } }; /*line :63:1*/panic("a2g: unreachable") }







func A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A { A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_Init(); t := &A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :71:1
func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A) Ctor_O_O_J(c__parent, c__lens any, c__root int64) { t.F_parent = c__parent; t.F_lens = c__lens; t.F_root = c__root }
//line :71:1
func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A) Invoke_O_O_O__O(self, p_m__1, s__2 any) any { var m__1 int64 = lang.RT_LongCast_O__J(p_m__1); var d__3 int64; var tmp1 any = A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_New_O_O_J(t.F_parent, s__2, t.F_root); var tmp2 *jrt.Class;
													A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_Init(); tmp2 = A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_fn_class; d__3 = lang.RT_LongCast_O__J(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()); var tmp3 /*line :73:1*/*jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](t.F_lens, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(tmp3, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__2)), d__3)); return /*line :74:1*/ jrt.Long_ValueOf_J__Long(lang.Numbers_Max_J_J__J(m__1, d__3)).Ref() }
//line :72:1
func A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A { A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_Init(); t := &A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :72:1
func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A) Ctor_O_O_J(c__parent, c__s any, c__root int64) { t.F_parent = c__parent; t.F_s = c__s; t.F_root = c__root }
//line :72:1
func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A) Invoke_O__O(self any) any { { var x__1 int64; var tmp1 any; var t_ any = t.F_s; t.F_s = nil; tmp1 = t_; x__1 = lang.RT_LongCast_O__J(tmp1); var d__2 int64 = 0; L1: for { if lang.Numbers_Equiv_J_J__Z(x__1, t.F_root) { return jrt.Long_ValueOf_J__Long(d__2).Ref() } else { var tmp2 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](t.F_parent, jrt.Prim_long.ArrayClass()); x__1, d__2 = lang.RT_Aget_J1_I__J(tmp2, lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(x__1))), lang.Numbers_Inc_J__J(d__2); continue L1 } } }; panic("a2g: unreachable") }










func A_arbace_a2g_zlib_canonical_codes_A_New() *A_arbace_a2g_zlib_canonical_codes_A { A_arbace_a2g_zlib_canonical_codes_A_Init(); t := &A_arbace_a2g_zlib_canonical_codes_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_a2g_zlib_canonical_codes_A) Ctor() {}
//line :83:1
func (t *A_arbace_a2g_zlib_canonical_codes_A) Invoke_O_O__O(self, lens__0 any) any { var n__2 int32 = lang.RT_Alength_J1__I(jrt.A2g_CastArray[*jrt.LongArray](lens__0, jrt.Prim_long.ArrayClass())); var bl_count__3 any; var tmp1 any;




	A_arbace_a2g_zlib_A_Init(); tmp1 = A_arbace_a2g_zlib_A_const_18; bl_count__3 = lang.Numbers_Long_array_O__J1(tmp1).Ref(); var next_code__4 any; var tmp2 any;
	A_arbace_a2g_zlib_A_Init(); tmp2 = A_arbace_a2g_zlib_A_const_18; next_code__4 = lang.Numbers_Long_array_O__J1(tmp2).Ref(); var codes__5 any = /*line :83:1*/lang.Numbers_Long_array_O__J1(jrt.Integer_ValueOf_I__Integer(n__2).Ref()).Ref(); var n__1927000701__auto____6 int64 = lang.RT_LongCast_I__J(n__2); var i__7 int64 = 0; L1: for {







		if lang.Numbers_Lt_J_J__Z(i__7, n__1927000701__auto____6) { var l__8 int64 = lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](lens__0, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(i__7)); if lang.Numbers_IsPos_J__Z(l__8) { jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.A2g_CastArray[*jrt.LongArray](bl_count__3, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(l__8)), lang.Numbers_Inc_J__J(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](bl_count__3, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(l__8)))))) }; i__7 = lang.Numbers_Unchecked_inc_J__J(i__7); continue L1 }
//line :83:1
		break L1 }; var bits__6 int64 = 1; var code__7 int64 = 0; L2: for {









			if lang.Numbers_Lt_J_J__Z(bits__6, 16) { var code__8 int64 = lang.Numbers_ShiftLeft_J_J__J(lang.Numbers_Add_J_J__J(code__7, lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](bl_count__3, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(lang.Numbers_Dec_J__J(bits__6)))), 1)

				jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.A2g_CastArray[*jrt.LongArray](next_code__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(bits__6), code__8))
				bits__6, code__7 = lang.Numbers_Inc_J__J(bits__6), code__8; continue L2 }
//line :83:1
			break L2 }; var n__1927000701__auto____6_2 int64 = lang.RT_LongCast_I__J(n__2); var i__7_2 int64 = 0; L3: for {













				if lang.Numbers_Lt_J_J__Z(i__7_2, n__1927000701__auto____6_2) { var l__8_2 int64 = lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](lens__0, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(i__7_2))

					if lang.Numbers_IsPos_J__Z(l__8_2) {
						var tmp3 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](codes__5, jrt.Prim_long.ArrayClass()); var tmp4 int32 = lang.RT_IntCast_J__I(i__7_2); var tmp5 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp5 = A_arbace_a2g_zlib_A_const_19; jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(tmp3, tmp4, lang.RT_LongCast_O__J(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](next_code__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(l__8_2)))).Ref(), jrt.Long_ValueOf_J__Long(l__8_2).Ref()))))
						jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.A2g_CastArray[*jrt.LongArray](next_code__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(l__8_2)), lang.Numbers_Inc_J__J(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](next_code__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(l__8_2)))))) }
//line :97:1
					i__7_2 = lang.Numbers_Unchecked_inc_J__J(i__7_2); continue L3 }
//line :83:1
				break L3 }; return codes__5 }





























func A_arbace_a2g_zlib_code_of_A_New() *A_arbace_a2g_zlib_code_of_A { A_arbace_a2g_zlib_code_of_A_Init(); t := &A_arbace_a2g_zlib_code_of_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_a2g_zlib_code_of_A) Ctor() {}
//line :113:1
func (t *A_arbace_a2g_zlib_code_of_A) Invoke_O_O_O__O(self, bases__0, p_v__1 any) any { var v__1 int64 = lang.RT_LongCast_O__J(p_v__1); var tmp1 int64; var i__3 int64 = lang.Numbers_Dec_J__J(int64(lang.RT_Alength_J1__I(jrt.A2g_CastArray[*jrt.LongArray](bases__0, jrt.Prim_long.ArrayClass())))); L1: for {


	if lang.Numbers_Gt_J_J__Z(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](bases__0, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(i__3)), v__1) { i__3 = lang.Numbers_Dec_J__J(i__3); continue L1 } else { tmp1 = i__3 }
//line :113:1
	break L1 }; return jrt.Long_ValueOf_J__Long(tmp1).Ref() }













func A_arbace_a2g_zlib_match_length_A_New() *A_arbace_a2g_zlib_match_length_A { A_arbace_a2g_zlib_match_length_A_Init(); t := &A_arbace_a2g_zlib_match_length_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_a2g_zlib_match_length_A) Ctor() {}
//line :127:1
func (t *A_arbace_a2g_zlib_match_length_A) Invoke_O_O_O_O_O__O(self, b__0, p_i__1, p_j__2, p_max__3 any) any { var i__1 int64 = lang.RT_LongCast_O__J(p_i__1); var j__2 int64 = lang.RT_LongCast_O__J(p_j__2); var max__3 int64 = lang.RT_LongCast_O__J(p_max__3); var tmp1 int64; var k__5 int64 = 0; L1: for {


	var tmp2 bool; var and__1927000168__auto____6 bool = lang.Numbers_Lt_J_J__Z(k__5, max__3); if and__1927000168__auto____6 { tmp2 = lang.Numbers_Equiv_J_J__Z(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(lang.Numbers_Add_J_J__J(i__1, k__5)))).Ref()), lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(lang.Numbers_Add_J_J__J(j__2, k__5)))).Ref())) } else { tmp2 = and__1927000168__auto____6 }; if tmp2 { k__5 = lang.Numbers_Inc_J__J(k__5); continue L1 } else { tmp1 = k__5 }
//line :127:1
	break L1 }; return jrt.Long_ValueOf_J__Long(tmp1).Ref() }




func A_arbace_a2g_zlib_insert_BANG__A_New() *A_arbace_a2g_zlib_insert_BANG__A { A_arbace_a2g_zlib_insert_BANG__A_Init(); t := &A_arbace_a2g_zlib_insert_BANG__A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_a2g_zlib_insert_BANG__A) Ctor() {}
//line :132:1
func (t *A_arbace_a2g_zlib_insert_BANG__A) Invoke_O_O_O_O_O__O(self, b__0, head__1, prev__2, p_i__3 any) any { var i__3 int64 = lang.RT_LongCast_O__J(p_i__3); if



	lang.Numbers_Lte_J_J__Z(lang.Numbers_Add_J_J__J(i__3, 3), int64(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())))) { var h__5 int64 = lang.Numbers_And_J_J__J(lang.Numbers_Xor_J_J__J(lang.Numbers_Xor_J_J__J(lang.Numbers_Xor_J_J__J(lang.Numbers_ShiftLeft_J_J__J(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(i__3))).Ref()), 255), 8), lang.Numbers_ShiftLeft_J_J__J(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(lang.Numbers_Add_J_J__J(i__3, 1)))).Ref()), 255), 4)), lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(lang.Numbers_Add_J_J__J(i__3, 2)))).Ref()), 255)), lang.Numbers_ShiftLeft_J_J__J(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(lang.Numbers_Add_J_J__J(i__3, 2)))).Ref()), 255), 11)), 65535)





		jrt.Integer_ValueOf_I__Integer(lang.RT_Aset_I1_I_I__I(jrt.A2g_CastArray[*jrt.IntArray](prev__2, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I(i__3), lang.RT_Aget_I1_I__I(jrt.A2g_CastArray[*jrt.IntArray](head__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I(h__5))))
		jrt.Integer_ValueOf_I__Integer(lang.RT_Aset_I1_I_I__I(jrt.A2g_CastArray[*jrt.IntArray](head__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I(h__5), lang.RT_IntCast_J__I(i__3))) }; return nil }


func A_arbace_a2g_zlib_longest_A_New() *A_arbace_a2g_zlib_longest_A { A_arbace_a2g_zlib_longest_A_Init(); t := &A_arbace_a2g_zlib_longest_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_a2g_zlib_longest_A) Ctor() {}
//line :146:1
func (t *A_arbace_a2g_zlib_longest_A) Invoke_O_O_O_O__O(self, b__0, prev__1, p_i__2 any) any { var i__2 int64 = lang.RT_LongCast_O__J(p_i__2); var tmp1 int64; var n__4 int32 = lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())); if




	lang.Numbers_Gt_J_J__Z(lang.Numbers_Add_J_J__J(i__2, 3), int64(n__4)) { tmp1 = 0 } else { var maxl__5 int64 = lang.Numbers_Min_J_J__J(258, lang.Numbers_Minus_J_J__J(int64(n__4), i__2)); var j__6 int64 = lang.RT_LongCast_I__J(lang.RT_Aget_I1_I__I(jrt.A2g_CastArray[*jrt.IntArray](prev__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I(i__2))); var chain__7 int64 = 0; var best__8 any = lang.RT_Box_J__Number(0); var bestd__9 int64 = 0; L1: for {



		var tmp2 bool; var or__1927000174__auto____10 bool = lang.Numbers_IsNeg_J__Z(j__6); if or__1927000174__auto____10 { tmp2 = or__1927000174__auto____10 } else { var or__1927000174__auto____11 bool = lang.Numbers_Gt_J_J__Z(lang.Numbers_Minus_J_J__J(i__2, j__6), 32768); if or__1927000174__auto____11 { tmp2 = or__1927000174__auto____11 } else { var or__1927000174__auto____12 bool = lang.Numbers_Gte_J_J__Z(chain__7, 64); if or__1927000174__auto____12 { tmp2 = or__1927000174__auto____12 } else { var or__1927000174__auto____13 bool = lang.Numbers_Gte_O_J__Z(best__8, 64); if or__1927000174__auto____13 { tmp2 = or__1927000174__auto____13 } else { tmp2 = lang.Numbers_Gte_O_J__Z(best__8, maxl__5) } } } }; if tmp2 {
			if lang.Numbers_Gte_O_J__Z(best__8, 3) { tmp1 = lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_O_J__J(best__8, 16), bestd__9) } else { tmp1 = 0 } } else {
//line :155:1
				var l__10 any

				if lang.Numbers_Equiv_J_J__Z(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_O__I(lang.Numbers_Add_J_O__Number(j__6, best__8)))).Ref()), lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_O__I(lang.Numbers_Add_J_O__Number(i__2, best__8)))).Ref())) {
					var tmp3 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp3 = A_arbace_a2g_zlib_A_const_20; l__10 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O_O__O(b__0, jrt.Long_ValueOf_J__Long(i__2).Ref(), jrt.Long_ValueOf_J__Long(j__6).Ref(), jrt.Long_ValueOf_J__Long(maxl__5).Ref()) } else {
//line :157:1
						A_arbace_a2g_zlib_A_Init(); l__10 = A_arbace_a2g_zlib_A_const_17
					}

				if lang.Numbers_Gt_J_O__Z(lang.RT_LongCast_O__J(l__10), best__8) {
					j__6, chain__7, best__8, bestd__9 = lang.RT_LongCast_I__J(lang.RT_Aget_I1_I__I(jrt.A2g_CastArray[*jrt.IntArray](prev__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I(j__6))), lang.Numbers_Inc_J__J(chain__7), l__10, lang.Numbers_Minus_J_J__J(i__2, j__6); continue L1 } else {
						j__6, chain__7, best__8, bestd__9 = lang.RT_LongCast_I__J(lang.RT_Aget_I1_I__I(jrt.A2g_CastArray[*jrt.IntArray](prev__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I(j__6))), lang.Numbers_Inc_J__J(chain__7), best__8, bestd__9; continue L1 } }
//line :151:1
		break L1 } }; return /*line :146:1*/ jrt.Long_ValueOf_J__Long(tmp1).Ref() }

















func A_arbace_a2g_zlib_lz77_A_New() *A_arbace_a2g_zlib_lz77_A { A_arbace_a2g_zlib_lz77_A_Init(); t := &A_arbace_a2g_zlib_lz77_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_a2g_zlib_lz77_A) Ctor() {}
//line :164:1
func (t *A_arbace_a2g_zlib_lz77_A) Invoke_O_O__O(self, b__0 any) any { { var n__2 int32 = lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())); var head__3 any; var tmp1 int32 = lang.RT_IntCast_J__I(65536); var tmp2 any




	A_arbace_a2g_zlib_A_Init(); tmp2 = A_arbace_a2g_zlib_A_const_21; head__3 = lang.Numbers_Int_array_I_O__I1(tmp1, tmp2).Ref()
//line :164:1
	var prev__4 any; var tmp3 int32 = lang.RT_IntCast_J__I(lang.Numbers_Max_J_J__J(int64(n__2), 1)); var tmp4 any





	A_arbace_a2g_zlib_A_Init(); tmp4 = A_arbace_a2g_zlib_A_const_21; prev__4 = lang.Numbers_Int_array_I_O__I1(tmp3, tmp4).Ref()
//line :164:1
	var out__5 any = lang.Numbers_Long_array_O__J1(jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(n__2))).Ref()).Ref(); var flag__6 int64 = lang.Numbers_ShiftLeft_J_J__J(1, 40); var i__7 int64 = 0; var k__8 int64 = 0; var pending__9 any = lang.RT_Box_J__Number(0); L1: for {











		if lang.Numbers_Gte_J_J__Z(i__7, int64(n__2)) {
			if lang.Numbers_IsPos_O__Z(pending__9) {
				jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.A2g_CastArray[*jrt.LongArray](out__5, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(k__8), lang.Numbers_Or_O_J__J(pending__9, flag__6)))
//line :177:1
				return lang.Tuple_Create_O_O__IPersistentVector(out__5, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(k__8)).Ref()) } else { return lang.Tuple_Create_O_O__IPersistentVector(out__5, jrt.Long_ValueOf_J__Long(k__8).Ref()) } } else {



					var tmp5 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp5 = A_arbace_a2g_zlib_A_const_23; lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O_O_O__O(b__0, head__3, prev__4, jrt.Long_ValueOf_J__Long(i__7).Ref())
//line :176:1
					var m__10 any; var tmp6 *lang.Var





					A_arbace_a2g_zlib_A_Init(); tmp6 = A_arbace_a2g_zlib_A_const_22; m__10 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O_O__O(b__0, prev__4, jrt.Long_ValueOf_J__Long(i__7).Ref())
					if lang.Numbers_IsPos_O__Z(pending__9) {

						if lang.Numbers_Gt_J_J__Z(lang.Numbers_ShiftRight_O_J__J(m__10, 16), lang.Numbers_ShiftRight_O_J__J(pending__9, 16)) {

							jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.A2g_CastArray[*jrt.LongArray](out__5, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(k__8), lang.RT_LongCast_J__J(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(lang.Numbers_Dec_J__J(i__7)))).Ref()), 255))))
							i__7, k__8, pending__9 = lang.Numbers_Inc_J__J(i__7), lang.Numbers_Inc_J__J(k__8), m__10; continue L1 } else {
//line :185:1
								var end__11 int64 = lang.Numbers_Add_J_J__J(lang.Numbers_Dec_J__J(i__7), lang.Numbers_ShiftRight_O_J__J(pending__9, 16))





								jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.A2g_CastArray[*jrt.LongArray](out__5, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(k__8), lang.Numbers_Or_O_J__J(pending__9, flag__6)))
//line :185:1
								var x__12 int64 = lang.Numbers_Inc_J__J(i__7); L2: for {






									if lang.Numbers_Lt_J_J__Z(x__12, end__11) { var tmp7 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp7 = A_arbace_a2g_zlib_A_const_23; lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O_O_O__O(b__0, head__3, prev__4, jrt.Long_ValueOf_J__Long(x__12).Ref()); x__12 = lang.Numbers_Inc_J__J(x__12); continue L2 }
//line :185:1
									break L2
								}






								var tmp8 int64 = lang.Numbers_Inc_J__J(k__8); var tmp9 any; A_arbace_a2g_zlib_A_Init(); tmp9 = A_arbace_a2g_zlib_A_const_17; i__7, k__8, pending__9 = end__11, tmp8, tmp9; continue L1 } } else {
//line :183:1
									if lang.Numbers_IsPos_O__Z(m__10) {










										i__7, k__8, pending__9 = lang.Numbers_Inc_J__J(i__7), k__8, m__10; continue L1 } else {
//line :183:1
											var tmp10 *lang.Keyword; A_arbace_a2g_zlib_A_Init(); tmp10 = A_arbace_a2g_zlib_A_const_9; if tmp10 != nil {











												jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.A2g_CastArray[*jrt.LongArray](out__5, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(k__8), lang.RT_LongCast_J__J(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(i__7))).Ref()), 255))))
												var tmp11 int64 = lang.Numbers_Inc_J__J(i__7); var tmp12 int64 = lang.Numbers_Inc_J__J(k__8); var tmp13 any; A_arbace_a2g_zlib_A_Init(); tmp13 = A_arbace_a2g_zlib_A_const_17; i__7, k__8, pending__9 = tmp11, tmp12, tmp13; continue L1 } else {
//line :183:1
													return nil } } } } } }; /*line :164:1*/panic("a2g: unreachable") }







































func A_arbace_a2g_zlib_rle_lengths_A_New() *A_arbace_a2g_zlib_rle_lengths_A { A_arbace_a2g_zlib_rle_lengths_A_Init(); t := &A_arbace_a2g_zlib_rle_lengths_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_a2g_zlib_rle_lengths_A) Ctor() {}
//line :204:1
func (t *A_arbace_a2g_zlib_rle_lengths_A) Invoke_O_O__O(self, ls__0 any) any { { var v__2 any; var tmp1 *lang.Var


	A_arbace_a2g_zlib_A_Init(); tmp1 = A_arbace_a2g_zlib_A_const_24; v__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(ls__0)
//line :204:1
	var n__3 int32 = lang.RT_Count_O__I(v__2); var i__4 any = lang.RT_Box_J__Number(0); var acc__5 any; lang.PersistentVector_Init(); acc__5 = lang.PersistentVector_EMPTY.Ref(); L1: for {




		if lang.Numbers_Gte_O_J__Z(i__4, int64(n__3)) { return acc__5 } else { var x__6 int64 = lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(v__2, lang.RT_IntCast_O__I(i__4))); var run__7 any; var tmp2 any = A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_New_O_I_J_O(i__4, n__3, x__6, v__2); var tmp3 *jrt.Class


			A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_Init(); tmp3 = A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_fn_class; run__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
			var tmp4 bool; var and__1927000168__auto____8 bool = lang.Numbers_IsZero_J__Z(x__6)
			if and__1927000168__auto____8 { tmp4 = lang.Numbers_Gte_O_J__Z(run__7, 11) } else { tmp4 = and__1927000168__auto____8 }
//line :213:1
			if tmp4 { var r__8 any = lang.Numbers_Min_O_J__O(run__7, 138); var tmp5 any = lang.Numbers_Add_O_O__Number(i__4, r__8); var tmp6 *lang.Var
				A_arbace_a2g_zlib_A_Init(); tmp6 = A_arbace_a2g_zlib_A_const_4; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_a2g_zlib_A_Init(); tmp8 = A_arbace_a2g_zlib_A_const_25; var tmp9 any = tmp8; i__4, acc__5 = tmp5, tmp7.Invoke_O_O__O(acc__5, lang.Tuple_Create_O_O__IPersistentVector(tmp9, lang.Numbers_Minus_O_J__Number(r__8, 11))); continue L1 } else {
//line :213:1
					var tmp10 bool; var and__1927000168__auto____8_2 bool = lang.Numbers_IsZero_J__Z(x__6)

					if and__1927000168__auto____8_2 { tmp10 = lang.Numbers_Gte_O_J__Z(run__7, 3) } else { tmp10 = and__1927000168__auto____8_2 }
//line :213:1
					if tmp10 { var r__8_2 any = lang.Numbers_Min_O_J__O(run__7, 10); var tmp11 any = lang.Numbers_Add_O_O__Number(i__4, r__8_2); var tmp12 *lang.Var

						A_arbace_a2g_zlib_A_Init(); tmp12 = A_arbace_a2g_zlib_A_const_4; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any; A_arbace_a2g_zlib_A_Init(); tmp14 = A_arbace_a2g_zlib_A_const_26; var tmp15 any = tmp14; i__4, acc__5 = tmp11, tmp13.Invoke_O_O__O(acc__5, lang.Tuple_Create_O_O__IPersistentVector(tmp15, lang.Numbers_Minus_O_J__Number(r__8_2, 3))); continue L1 } else {
//line :213:1
							var tmp16 bool; var and__1927000168__auto____8_3 bool = lang.Numbers_IsPos_J__Z(x__6)


							if and__1927000168__auto____8_3 { tmp16 = lang.Numbers_Gte_O_J__Z(run__7, 4) } else { tmp16 = and__1927000168__auto____8_3 }
//line :213:1
							if tmp16 { var r__8_3 any = lang.Numbers_Min_O_J__O(lang.Numbers_Dec_O__Number(run__7), 6); var tmp17 any = lang.Numbers_Add_O_O__Number(lang.Numbers_Add_O_J__Number(i__4, 1), r__8_3); var tmp18 *lang.Var


								A_arbace_a2g_zlib_A_Init(); tmp18 = A_arbace_a2g_zlib_A_const_4; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any = jrt.Long_ValueOf_J__Long(x__6).Ref(); var tmp21 any; A_arbace_a2g_zlib_A_Init(); tmp21 = A_arbace_a2g_zlib_A_const_17; var tmp22 any = lang.Tuple_Create_O_O__IPersistentVector(tmp20, tmp21); var tmp23 any; A_arbace_a2g_zlib_A_Init(); tmp23 = A_arbace_a2g_zlib_A_const_18; var tmp24 any = tmp23; i__4, acc__5 = tmp17, tmp19.Invoke_O_O_O__O(acc__5, tmp22, lang.Tuple_Create_O_O__IPersistentVector(tmp24, lang.Numbers_Minus_O_J__Number(r__8_3, 3))); continue L1 } else {
//line :213:1
									var tmp25 *lang.Keyword; A_arbace_a2g_zlib_A_Init(); tmp25 = A_arbace_a2g_zlib_A_const_9; if tmp25 != nil {



										var tmp26 any = lang.Numbers_Inc_O__Number(i__4); var tmp27 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp27 = A_arbace_a2g_zlib_A_const_4; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any = jrt.Long_ValueOf_J__Long(x__6).Ref(); var tmp30 any; A_arbace_a2g_zlib_A_Init(); tmp30 = A_arbace_a2g_zlib_A_const_17; i__4, acc__5 = tmp26, tmp28.Invoke_O_O__O(acc__5, lang.Tuple_Create_O_O__IPersistentVector(tmp29, tmp30)); continue L1 } else {
//line :213:1
											return nil } } } } } } }; /*line :204:1*/panic("a2g: unreachable") }







func A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_New_O_I_J_O(p0 any, p1 int32, p2 int64, p3 any) *A_arbace_a2g_zlib_rle_lengths_fn__274000038_A { A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_Init(); t := &A_arbace_a2g_zlib_rle_lengths_fn__274000038_A{}; t.Ctor_O_I_J_O(p0, p1, p2, p3); return t }
//line :212:1
func (t *A_arbace_a2g_zlib_rle_lengths_fn__274000038_A) Ctor_O_I_J_O(c__i any, c__n int32, c__x int64, c__v any) { t.F_i = c__i; t.F_n = c__n; t.F_x = c__x; t.F_v = c__v }
//line :212:1
func (t *A_arbace_a2g_zlib_rle_lengths_fn__274000038_A) Invoke_O__O(self any) any { { var j__1 any = t.F_i; L1: for { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Numbers_Lt_O_J__Z(j__1, int64(t.F_n)); if and__1927000168__auto____2 { var tmp2 int64 = t.F_x; var tmp3 any = t.F_v; tmp1 = lang.Numbers_Equiv_J_J__Z(tmp2, lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(tmp3, lang.RT_IntCast_O__I(j__1)))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { j__1 = lang.Numbers_Inc_O__Number(j__1); continue L1 } else { return lang.Numbers_Minus_O_O__Number(j__1, t.F_i) } } }; panic("a2g: unreachable") }






func A_arbace_a2g_zlib_write_block_BANG__A_New() *A_arbace_a2g_zlib_write_block_BANG__A { A_arbace_a2g_zlib_write_block_BANG__A_Init(); t := &A_arbace_a2g_zlib_write_block_BANG__A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_a2g_zlib_write_block_BANG__A) Ctor() {}
//line :219:1
func (t *A_arbace_a2g_zlib_write_block_BANG__A) Invoke_O_O_O_O_O_O__O(self, w__0, syms__1, from__2, to__3, last_QMARK___4 any) any { var from__6 int64 = lang.RT_LongCast_O__J(from__2); var to__7 int64 = lang.RT_LongCast_O__J(to__3); var lf__8 any; var tmp1 any;


	A_arbace_a2g_zlib_A_Init(); tmp1 = A_arbace_a2g_zlib_A_const_27; lf__8 = lang.Numbers_Long_array_O__J1(tmp1).Ref(); var df__9 any; var tmp2 any; A_arbace_a2g_zlib_A_Init(); tmp2 = A_arbace_a2g_zlib_A_const_28; df__9 = lang.Numbers_Long_array_O__J1(tmp2).Ref(); var i__10 int64 = from__6; L1:
//line :219:1
	for {




		if lang.Numbers_Lt_J_J__Z(i__10, to__7) { var s__11 int64 = lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](syms__1, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(i__10))); var tmp3 *lang.Var

			A_arbace_a2g_zlib_A_Init(); tmp3 = A_arbace_a2g_zlib_A_const_41; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = jrt.Long_ValueOf_J__Long(s__11).Ref(); var tmp6 any; A_arbace_a2g_zlib_A_Init(); tmp6 = A_arbace_a2g_zlib_A_const_43; if jrt.A2g_Truth(tmp4.Invoke_O_O__O(tmp5, tmp6)) { var len__12 int64 = lang.Numbers_And_J_J__J(lang.Numbers_ShiftRight_J_J__J(s__11, 16), 65535); var d__13 int64 = lang.Numbers_And_J_J__J(s__11, 65535); var tmp7 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()); var tmp8 *lang.Var

				A_arbace_a2g_zlib_A_Init(); tmp8 = A_arbace_a2g_zlib_A_const_42; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp10 = A_arbace_a2g_zlib_A_const_44; var tmp11 int32 = lang.RT_IntCast_J__I(lang.Numbers_Add_J_J__J(257, lang.RT_LongCast_O__J(tmp9.Invoke_O_O__O(jrt.NN(tmp10).GetRawRoot__O(), jrt.Long_ValueOf_J__Long(len__12).Ref())))); var tmp12 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()); var tmp13 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp13 = A_arbace_a2g_zlib_A_const_42; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp15 = A_arbace_a2g_zlib_A_const_44; jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(tmp7, tmp11, lang.Numbers_Inc_J__J(lang.RT_Aget_J1_I__J(tmp12, lang.RT_IntCast_J__I(lang.Numbers_Add_J_J__J(257, lang.RT_LongCast_O__J(tmp14.Invoke_O_O__O(jrt.NN(tmp15).GetRawRoot__O(), jrt.Long_ValueOf_J__Long(len__12).Ref()))))))))
				var tmp16 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()); var tmp17 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp17 = A_arbace_a2g_zlib_A_const_42; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp19 = A_arbace_a2g_zlib_A_const_45; var tmp20 int32 = lang.RT_IntCast_J__I(lang.RT_LongCast_O__J(tmp18.Invoke_O_O__O(jrt.NN(tmp19).GetRawRoot__O(), jrt.Long_ValueOf_J__Long(d__13).Ref()))); var tmp21 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()); var tmp22 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp22 = A_arbace_a2g_zlib_A_const_42; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp24 = A_arbace_a2g_zlib_A_const_45; jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(tmp16, tmp20, lang.Numbers_Inc_J__J(lang.RT_Aget_J1_I__J(tmp21, lang.RT_IntCast_J__I(lang.RT_LongCast_O__J(tmp23.Invoke_O_O__O(jrt.NN(tmp24).GetRawRoot__O(), jrt.Long_ValueOf_J__Long(d__13).Ref()))))))) } else {
					jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.A2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(s__11)), lang.Numbers_Inc_J__J(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(s__11)))))) }
			i__10 = lang.Numbers_Inc_J__J(i__10); continue L1 }
//line :219:1
		break L1 };












	jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.A2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(256), 1)); var used__10 int32; var tmp25 /*line :219:1*/*lang.Var;














	A_arbace_a2g_zlib_A_Init(); tmp25 = A_arbace_a2g_zlib_A_const_40; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 any = A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_New_O(df__9); var tmp28 *jrt.Class; A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_Init(); tmp28 = A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_fn_class; var tmp29 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); var tmp30 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp30 = A_arbace_a2g_zlib_A_const_14; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 any; A_arbace_a2g_zlib_A_Init(); tmp32 = A_arbace_a2g_zlib_A_const_28; used__10 = lang.RT_Count_O__I(tmp26.Invoke_O_O__O(tmp29, tmp31.Invoke_O__O(tmp32))); if
	lang.Numbers_IsZero_J__Z(int64(used__10)) { jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.A2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(0), 1)); jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.A2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(1), 1)) } else { if lang.Numbers_Equiv_J_J__Z(1, int64(used__10)) {
		var tmp33 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()); var tmp34 int64; if lang.Numbers_IsPos_J__Z(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(0))) { tmp34 = 1 } else { tmp34 = 0 }; jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(tmp33, lang.RT_IntCast_J__I(tmp34), 1)) } }; var ll__10 any; var tmp35 /*line :219:1*/*lang.Var;

















	A_arbace_a2g_zlib_A_Init(); tmp35 = A_arbace_a2g_zlib_A_const_29; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 any; A_arbace_a2g_zlib_A_Init(); tmp37 = A_arbace_a2g_zlib_A_const_46; ll__10 = tmp36.Invoke_O_O__O(lf__8, tmp37); var dl__11 any; var tmp38 /*line :219:1*/*lang.Var;


















	A_arbace_a2g_zlib_A_Init(); tmp38 = A_arbace_a2g_zlib_A_const_29; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 any; A_arbace_a2g_zlib_A_Init(); tmp40 = A_arbace_a2g_zlib_A_const_46; dl__11 = tmp39.Invoke_O_O__O(df__9, tmp40); var lc__12 any; var tmp41 /*line :219:1*/*lang.Var;



















	A_arbace_a2g_zlib_A_Init(); tmp41 = A_arbace_a2g_zlib_A_const_30; lc__12 = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(ll__10); var dc__13 any; var tmp42 /*line :219:1*/*lang.Var;




















	A_arbace_a2g_zlib_A_Init(); tmp42 = A_arbace_a2g_zlib_A_const_30; dc__13 = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(dl__11); var hlit__14 any; var tmp43 any; var or__1927000174__auto____14 any; var tmp44 /*line :219:1*/*lang.Var;





















	A_arbace_a2g_zlib_A_Init(); tmp44 = A_arbace_a2g_zlib_A_const_31; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp46 = A_arbace_a2g_zlib_A_const_40; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 any = A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_New_O(ll__10); var tmp49 *jrt.Class; A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_Init(); tmp49 = A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_fn_class; var tmp50 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp48, tmp49, nil); var tmp51 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp51 = A_arbace_a2g_zlib_A_const_14; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 any; A_arbace_a2g_zlib_A_Init(); tmp53 = A_arbace_a2g_zlib_A_const_47; or__1927000174__auto____14 = tmp45.Invoke_O__O(tmp47.Invoke_O_O__O(tmp50, tmp52.Invoke_O__O(tmp53))); if jrt.A2g_Truth(or__1927000174__auto____14) { tmp43 = or__1927000174__auto____14 } else { A_arbace_a2g_zlib_A_Init(); tmp43 = A_arbace_a2g_zlib_A_const_17 }; hlit__14 = lang.Numbers_Max_J_O__O(257, lang.Numbers_Inc_O__Number(tmp43)); var hdist__15 any; var tmp54 any; var or__1927000174__auto____15 any; var tmp55 /*line :219:1*/*lang.Var;






















	A_arbace_a2g_zlib_A_Init(); tmp55 = A_arbace_a2g_zlib_A_const_31; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp57 = A_arbace_a2g_zlib_A_const_40; var tmp58 lang.IFn = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()); var tmp59 any = A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_New_O(dl__11); var tmp60 *jrt.Class; A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_Init(); tmp60 = A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_fn_class; var tmp61 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp59, tmp60, nil); var tmp62 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp62 = A_arbace_a2g_zlib_A_const_14; var tmp63 lang.IFn = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()); var tmp64 any; A_arbace_a2g_zlib_A_Init(); tmp64 = A_arbace_a2g_zlib_A_const_28; or__1927000174__auto____15 = tmp56.Invoke_O__O(tmp58.Invoke_O_O__O(tmp61, tmp63.Invoke_O__O(tmp64))); if jrt.A2g_Truth(or__1927000174__auto____15) { tmp54 = or__1927000174__auto____15 } else { A_arbace_a2g_zlib_A_Init(); tmp54 = A_arbace_a2g_zlib_A_const_17 }; hdist__15 = lang.Numbers_Max_J_O__O(1, lang.Numbers_Inc_O__Number(tmp54)); var rle__16 any; var tmp65 /*line :219:1*/*lang.Var;























	A_arbace_a2g_zlib_A_Init(); tmp65 = A_arbace_a2g_zlib_A_const_32; var tmp66 lang.IFn = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()); var tmp67 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp67 = A_arbace_a2g_zlib_A_const_48; var tmp68 lang.IFn = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()); var tmp69 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp69 = A_arbace_a2g_zlib_A_const_49; var tmp70 lang.IFn = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()); var tmp71 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp71 = A_arbace_a2g_zlib_A_const_34; var tmp72 any = tmp70.Invoke_O_O__O(hlit__14, lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()).Invoke_O__O(ll__10)); var tmp73 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp73 = A_arbace_a2g_zlib_A_const_49; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp75 = A_arbace_a2g_zlib_A_const_34; rle__16 = tmp66.Invoke_O__O(tmp68.Invoke_O_O__O(tmp72, tmp74.Invoke_O_O__O(hdist__15, lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()).Invoke_O__O(dl__11)))); var cf__17 any; var tmp76 any;
	A_arbace_a2g_zlib_A_Init(); tmp76 = A_arbace_a2g_zlib_A_const_33; cf__17 = lang.Numbers_Long_array_O__J1(tmp76).Ref(); var ___18 any; var tmp77 any = /*line :219:1*/A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_New_O_O(cf__17, rle__16); var tmp78 *jrt.Class; _ = ___18;

























	A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_Init(); tmp78 = A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_fn_class; ___18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp77, tmp78, nil).Invoke__O(); var cl__19 any; var tmp79 /*line :219:1*/*lang.Var;


























	A_arbace_a2g_zlib_A_Init(); tmp79 = A_arbace_a2g_zlib_A_const_29; var tmp80 lang.IFn = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()); var tmp81 any; A_arbace_a2g_zlib_A_Init(); tmp81 = A_arbace_a2g_zlib_A_const_50; cl__19 = tmp80.Invoke_O_O__O(cf__17, tmp81); var cc__20 any; var tmp82 /*line :219:1*/*lang.Var;



























	A_arbace_a2g_zlib_A_Init(); tmp82 = A_arbace_a2g_zlib_A_const_30; cc__20 = lang.IFn_Cast(jrt.NN(tmp82).GetRawRoot__O()).Invoke_O__O(cl__19); var hclen__21 int64; var tmp83 /*line :219:1*/*lang.Var;




























	A_arbace_a2g_zlib_A_Init(); tmp83 = A_arbace_a2g_zlib_A_const_39; var tmp84 lang.IFn = lang.IFn_Cast(jrt.NN(tmp83).GetRawRoot__O()); var tmp85 any = A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_New_O(cl__19); var tmp86 *jrt.Class; A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_Init(); tmp86 = A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_fn_class; var tmp87 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp85, tmp86, nil); var tmp88 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp88 = A_arbace_a2g_zlib_A_const_51; var tmp89 lang.IFn = lang.IFn_Cast(jrt.NN(tmp88).GetRawRoot__O()); var tmp90 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp90 = A_arbace_a2g_zlib_A_const_52; hclen__21 = lang.Numbers_Max_J_J__J(4, lang.Numbers_Minus_J_J__J(19, int64(lang.RT_Count_O__I(tmp84.Invoke_O_O__O(tmp87, tmp89.Invoke_O__O(jrt.NN(tmp90).GetRawRoot__O())))))); var tmp91 lang.IFn =
	lang.IFn_Cast(w__0); var tmp92 any; if jrt.A2g_Truth(last_QMARK___4) { A_arbace_a2g_zlib_A_Init(); tmp92 = A_arbace_a2g_zlib_A_const_53 } else { A_arbace_a2g_zlib_A_Init(); tmp92 = A_arbace_a2g_zlib_A_const_17 }; var tmp93 any = tmp92; var tmp94 any; A_arbace_a2g_zlib_A_Init(); tmp94 = A_arbace_a2g_zlib_A_const_53; tmp91.Invoke_O_O__O(tmp93, tmp94); var tmp95 lang.IFn =
	lang.IFn_Cast(w__0); var tmp96 any; A_arbace_a2g_zlib_A_Init(); tmp96 = A_arbace_a2g_zlib_A_const_54; var tmp97 any = tmp96; var tmp98 any; A_arbace_a2g_zlib_A_Init(); tmp98 = A_arbace_a2g_zlib_A_const_54; tmp95.Invoke_O_O__O(tmp97, tmp98); var tmp99 lang.IFn =
	lang.IFn_Cast(w__0); var tmp100 any = lang.Numbers_Minus_O_J__Number(hlit__14, 257); var tmp101 any; A_arbace_a2g_zlib_A_Init(); tmp101 = A_arbace_a2g_zlib_A_const_55; tmp99.Invoke_O_O__O(tmp100, tmp101); var tmp102 lang.IFn =
	lang.IFn_Cast(w__0); var tmp103 any = lang.Numbers_Minus_O_J__Number(hdist__15, 1); var tmp104 any; A_arbace_a2g_zlib_A_Init(); tmp104 = A_arbace_a2g_zlib_A_const_55; tmp102.Invoke_O_O__O(tmp103, tmp104); var tmp105 lang.IFn =
	lang.IFn_Cast(w__0); var tmp106 any = jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(hclen__21, 4)).Ref(); var tmp107 any; A_arbace_a2g_zlib_A_Init(); tmp107 = A_arbace_a2g_zlib_A_const_56; tmp105.Invoke_O_O__O(tmp106, tmp107); var seq_274000065__22 any; var tmp108 /*line :219:1*/*lang.Var;


































	A_arbace_a2g_zlib_A_Init(); tmp108 = A_arbace_a2g_zlib_A_const_34; var tmp109 lang.IFn = lang.IFn_Cast(jrt.NN(tmp108).GetRawRoot__O()); var tmp110 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp110 = A_arbace_a2g_zlib_A_const_49; var tmp111 lang.IFn = lang.IFn_Cast(jrt.NN(tmp110).GetRawRoot__O()); var tmp112 any = jrt.Long_ValueOf_J__Long(hclen__21).Ref(); var tmp113 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp113 = A_arbace_a2g_zlib_A_const_52; seq_274000065__22 = tmp109.Invoke_O__O(tmp111.Invoke_O_O__O(tmp112, jrt.NN(tmp113).GetRawRoot__O())); var chunk_274000066__23 any; var count_274000067__24 int64 = 0; var i_274000068__25 int64 = 0; L2:
//line :219:1
	for {


































		if lang.Numbers_Lt_J_J__Z(i_274000068__25, count_274000067__24) { var s__26 any = lang.Indexed_Cast(chunk_274000066__23).Nth_I__O(lang.RT_IntCast_J__I(i_274000068__25)); var tmp114 lang.IFn = lang.IFn_Cast(w__0); var tmp115 any = jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](cl__19, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__26)))).Ref(); var tmp116 any; A_arbace_a2g_zlib_A_Init(); tmp116 = A_arbace_a2g_zlib_A_const_57; tmp114.Invoke_O_O__O(tmp115, tmp116); seq_274000065__22, chunk_274000066__23, count_274000067__24, i_274000068__25 = seq_274000065__22, chunk_274000066__23, count_274000067__24, lang.Numbers_Unchecked_inc_J__J(i_274000068__25); continue L2 } else { var temp__1927000414__auto____26 any; var tmp117 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp117 = A_arbace_a2g_zlib_A_const_34; temp__1927000414__auto____26 = lang.IFn_Cast(jrt.NN(tmp117).GetRawRoot__O()).Invoke_O__O(seq_274000065__22); if jrt.A2g_Truth(temp__1927000414__auto____26) { var seq_274000065__27 any = temp__1927000414__auto____26; var tmp118 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp118 = A_arbace_a2g_zlib_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp118).GetRawRoot__O()).Invoke_O__O(seq_274000065__27)) { var c__1927000678__auto____28 any; var tmp119 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp119 = A_arbace_a2g_zlib_A_const_36; c__1927000678__auto____28 = lang.IFn_Cast(jrt.NN(tmp119).GetRawRoot__O()).Invoke_O__O(seq_274000065__27); var tmp120 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp120 = A_arbace_a2g_zlib_A_const_37; seq_274000065__22, chunk_274000066__23, count_274000067__24, i_274000068__25 = lang.IFn_Cast(jrt.NN(tmp120).GetRawRoot__O()).Invoke_O__O(seq_274000065__27), c__1927000678__auto____28, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____28))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var s__28 any; var tmp121 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp121 = A_arbace_a2g_zlib_A_const_11; s__28 = lang.IFn_Cast(jrt.NN(tmp121).GetRawRoot__O()).Invoke_O__O(seq_274000065__27); var tmp122 lang.IFn = lang.IFn_Cast(w__0); var tmp123 any = jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](cl__19, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__28)))).Ref(); var tmp124 any; A_arbace_a2g_zlib_A_Init(); tmp124 = A_arbace_a2g_zlib_A_const_57; tmp122.Invoke_O_O__O(tmp123, tmp124); var tmp125 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp125 = A_arbace_a2g_zlib_A_const_38; seq_274000065__22, chunk_274000066__23, count_274000067__24, i_274000068__25 = lang.IFn_Cast(jrt.NN(tmp125).GetRawRoot__O()).Invoke_O__O(seq_274000065__27), nil, 0, 0; continue L2 } } }
//line :219:1
		break L2 }; var seq_274000069__22 any; var tmp126 *lang.Var;



































	A_arbace_a2g_zlib_A_Init(); tmp126 = A_arbace_a2g_zlib_A_const_34; seq_274000069__22 = lang.IFn_Cast(jrt.NN(tmp126).GetRawRoot__O()).Invoke_O__O(rle__16); var chunk_274000070__23 any; var count_274000071__24 int64 = 0; var i_274000072__25 int64 = 0; L3:
//line :219:1
	for {



































		if lang.Numbers_Lt_J_J__Z(i_274000072__25, count_274000071__24) { var vec__274000073__26 any = lang.Indexed_Cast(chunk_274000070__23).Nth_I__O(lang.RT_IntCast_J__I(i_274000072__25)); var s__27 any = lang.RT_Nth_O_I_O__O(vec__274000073__26, lang.RT_IntCast_J__I(0), nil); var x__28 any = lang.RT_Nth_O_I_O__O(vec__274000073__26, lang.RT_IntCast_J__I(1), nil)
			lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](cc__20, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__27)))).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](cl__19, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__27)))).Ref())
//line :255:1
			var G__274000076__29_ int32 = lang.RT_IntCast_O__I(s__27)

		L4: switch { default: switch G__274000076__29_ { case 16: var tmp127 lang.IFn = lang.IFn_Cast(w__0); var tmp128 any; A_arbace_a2g_zlib_A_Init(); tmp128 = A_arbace_a2g_zlib_A_const_54; tmp127.Invoke_O_O__O(x__28, tmp128); break L4; case 17: var tmp129 lang.IFn = lang.IFn_Cast(w__0); var tmp130 any; A_arbace_a2g_zlib_A_Init(); tmp130 = A_arbace_a2g_zlib_A_const_57; tmp129.Invoke_O_O__O(x__28, tmp130); break L4; case 18: var tmp131 lang.IFn = lang.IFn_Cast(w__0); var tmp132 any; A_arbace_a2g_zlib_A_Init(); tmp132 = A_arbace_a2g_zlib_A_const_50; tmp131.Invoke_O_O__O(x__28, tmp132); break L4; default:}}
//line :255:1
			seq_274000069__22, chunk_274000070__23, count_274000071__24, i_274000072__25 = seq_274000069__22, chunk_274000070__23, count_274000071__24, lang.Numbers_Unchecked_inc_J__J(i_274000072__25); continue L3 } else { var temp__1927000414__auto____26_2 any; var tmp133 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp133 = A_arbace_a2g_zlib_A_const_34; temp__1927000414__auto____26_2 = lang.IFn_Cast(jrt.NN(tmp133).GetRawRoot__O()).Invoke_O__O(seq_274000069__22); if jrt.A2g_Truth(temp__1927000414__auto____26_2) { var seq_274000069__27 any = temp__1927000414__auto____26_2; var tmp134 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp134 = A_arbace_a2g_zlib_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp134).GetRawRoot__O()).Invoke_O__O(seq_274000069__27)) { var c__1927000678__auto____28_2 any; var tmp135 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp135 = A_arbace_a2g_zlib_A_const_36; c__1927000678__auto____28_2 = lang.IFn_Cast(jrt.NN(tmp135).GetRawRoot__O()).Invoke_O__O(seq_274000069__27); var tmp136 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp136 = A_arbace_a2g_zlib_A_const_37; seq_274000069__22, chunk_274000070__23, count_274000071__24, i_274000072__25 = lang.IFn_Cast(jrt.NN(tmp136).GetRawRoot__O()).Invoke_O__O(seq_274000069__27), c__1927000678__auto____28_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____28_2))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var vec__274000077__28 any; var tmp137 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp137 = A_arbace_a2g_zlib_A_const_11; vec__274000077__28 = lang.IFn_Cast(jrt.NN(tmp137).GetRawRoot__O()).Invoke_O__O(seq_274000069__27); var s__29 any = lang.RT_Nth_O_I_O__O(vec__274000077__28, lang.RT_IntCast_J__I(0), nil); var x__30 any = lang.RT_Nth_O_I_O__O(vec__274000077__28, lang.RT_IntCast_J__I(1), nil)
				lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](cc__20, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__29)))).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](cl__19, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__29)))).Ref())
//line :255:1
				var G__274000080__31_ int32 = lang.RT_IntCast_O__I(s__29)

			L5: switch { default: switch G__274000080__31_ { case 16: var tmp138 lang.IFn = lang.IFn_Cast(w__0); var tmp139 any; A_arbace_a2g_zlib_A_Init(); tmp139 = A_arbace_a2g_zlib_A_const_54; tmp138.Invoke_O_O__O(x__30, tmp139); break L5; case 17: var tmp140 lang.IFn = lang.IFn_Cast(w__0); var tmp141 any; A_arbace_a2g_zlib_A_Init(); tmp141 = A_arbace_a2g_zlib_A_const_57; tmp140.Invoke_O_O__O(x__30, tmp141); break L5; case 18: var tmp142 lang.IFn = lang.IFn_Cast(w__0); var tmp143 any; A_arbace_a2g_zlib_A_Init(); tmp143 = A_arbace_a2g_zlib_A_const_50; tmp142.Invoke_O_O__O(x__30, tmp143); break L5; default:}}
//line :255:1
				var tmp144 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp144 = A_arbace_a2g_zlib_A_const_38; seq_274000069__22, chunk_274000070__23, count_274000071__24, i_274000072__25 = lang.IFn_Cast(jrt.NN(tmp144).GetRawRoot__O()).Invoke_O__O(seq_274000069__27), nil, 0, 0; continue L3 } } }
//line :219:1
		break L3 }; var i__22 int64 = from__6; L6: for {







































			if lang.Numbers_Lt_J_J__Z(i__22, to__7) { var s__23 int64 = lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](syms__1, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(i__22))); var tmp145 *lang.Var

				A_arbace_a2g_zlib_A_Init(); tmp145 = A_arbace_a2g_zlib_A_const_41; var tmp146 lang.IFn = lang.IFn_Cast(jrt.NN(tmp145).GetRawRoot__O()); var tmp147 any = jrt.Long_ValueOf_J__Long(s__23).Ref(); var tmp148 any; A_arbace_a2g_zlib_A_Init(); tmp148 = A_arbace_a2g_zlib_A_const_43; if jrt.A2g_Truth(tmp146.Invoke_O_O__O(tmp147, tmp148)) { var len__24 int64 = lang.Numbers_And_J_J__J(lang.Numbers_ShiftRight_J_J__J(s__23, 16), 65535); var d__25 int64 = lang.Numbers_And_J_J__J(s__23, 65535); var lcode__26 any; var tmp149 *lang.Var

					A_arbace_a2g_zlib_A_Init(); tmp149 = A_arbace_a2g_zlib_A_const_42; var tmp150 lang.IFn = lang.IFn_Cast(jrt.NN(tmp149).GetRawRoot__O()); var tmp151 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp151 = A_arbace_a2g_zlib_A_const_44; lcode__26 = tmp150.Invoke_O_O__O(jrt.NN(tmp151).GetRawRoot__O(), jrt.Long_ValueOf_J__Long(len__24).Ref())
//line :261:1
					var dcode__27 any; var tmp152 *lang.Var

					A_arbace_a2g_zlib_A_Init(); tmp152 = A_arbace_a2g_zlib_A_const_42; var tmp153 lang.IFn = lang.IFn_Cast(jrt.NN(tmp152).GetRawRoot__O()); var tmp154 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp154 = A_arbace_a2g_zlib_A_const_45; dcode__27 = tmp153.Invoke_O_O__O(jrt.NN(tmp154).GetRawRoot__O(), jrt.Long_ValueOf_J__Long(d__25).Ref())
					lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](lc__12, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(lang.Numbers_Add_J_O__Number(257, lcode__26)))).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](ll__10, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(lang.Numbers_Add_J_O__Number(257, lcode__26)))).Ref())
					var tmp155 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp155 = A_arbace_a2g_zlib_A_const_59; if lang.Numbers_IsPos_J__Z(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](jrt.NN(tmp155).GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(lcode__26))) { var tmp156 lang.IFn = lang.IFn_Cast(w__0); var tmp157 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp157 = A_arbace_a2g_zlib_A_const_44; var tmp158 any = jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(len__24, lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](jrt.NN(tmp157).GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(lcode__26)))).Ref(); var tmp159 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp159 = A_arbace_a2g_zlib_A_const_59; tmp156.Invoke_O_O__O(tmp158, jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](jrt.NN(tmp159).GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(lcode__26))).Ref()) }
					lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](dc__13, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(dcode__27))).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](dl__11, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(dcode__27))).Ref())
					var tmp160 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp160 = A_arbace_a2g_zlib_A_const_58; if lang.Numbers_IsPos_J__Z(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](jrt.NN(tmp160).GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(dcode__27))) { var tmp161 lang.IFn = lang.IFn_Cast(w__0); var tmp162 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp162 = A_arbace_a2g_zlib_A_const_45; var tmp163 any = jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(d__25, lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](jrt.NN(tmp162).GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(dcode__27)))).Ref(); var tmp164 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp164 = A_arbace_a2g_zlib_A_const_58; tmp161.Invoke_O_O__O(tmp163, jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](jrt.NN(tmp164).GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(dcode__27))).Ref()) } } else {
						lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](lc__12, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(s__23)))).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](ll__10, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(s__23)))).Ref()) }
				i__22 = lang.Numbers_Inc_J__J(i__22); continue L6 }
//line :219:1
			break L6 }; return /*line :270:1*/ lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](lc__12, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(256))).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.A2g_CastArray[*jrt.LongArray](ll__10, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(256))).Ref()) }
//line :234:1
func A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_New_O(p0 any) *A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A { A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_Init(); t := &A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A{}; t.Ctor_O(p0); return t }
//line :234:1
func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A) Ctor_O(c__df any) { t.F_df = c__df }
//line :234:1
func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A) Invoke_O_O__O(self, p1__274000041_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](t.F_df, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_J__Z(lang.RT_Aget_J1_I__J(tmp1, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(p1__274000041_SHARP___1))))).Ref() }






func A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_New_O(p0 any) *A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A { A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_Init(); t := &A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A{}; t.Ctor_O(p0); return t }
//line :241:1
func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A) Ctor_O(c__ll any) { t.F_ll = c__ll }
//line :241:1
func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A) Invoke_O_O__O(self, p1__274000042_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](t.F_ll, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_J__Z(lang.RT_Aget_J1_I__J(tmp1, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(p1__274000042_SHARP___1))))).Ref() }
func A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_New_O(p0 any) *A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A { A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_Init(); t := &A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A{}; t.Ctor_O(p0); return t }
//line :242:1
func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A) Ctor_O(c__dl any) { t.F_dl = c__dl }
//line :242:1
func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A) Invoke_O_O__O(self, p1__274000043_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](t.F_dl, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_J__Z(lang.RT_Aget_J1_I__J(tmp1, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(p1__274000043_SHARP___1))))).Ref() }


func A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_New_O_O(p0, p1 any) *A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A { A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_Init(); t := &A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A{}; t.Ctor_O_O(p0, p1); return t }
//line :245:1
func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A) Ctor_O_O(c__cf, c__rle any) { t.F_cf = c__cf; t.F_rle = c__rle }
//line :245:1
func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A) Invoke_O__O(self any) any { { var seq_274000051__1 any; var tmp1 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp1 = A_arbace_a2g_zlib_A_const_34; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var t_ any = t.F_rle; t.F_rle = nil; tmp3 = t_; seq_274000051__1 = tmp2.Invoke_O__O(tmp3); var chunk_274000052__2 any; var count_274000053__3 int64 = 0; var i_274000054__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z(i_274000054__4, count_274000053__3) { var vec__274000056__5 any = lang.Indexed_Cast(chunk_274000052__2).Nth_I__O(lang.RT_IntCast_J__I(i_274000054__4)); var s__6 any = lang.RT_Nth_O_I_O__O(vec__274000056__5, lang.RT_IntCast_J__I(0), nil); var tmp4 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](t.F_cf, jrt.Prim_long.ArrayClass()); var tmp5 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](t.F_cf, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(tmp4, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__6)), lang.Numbers_Inc_J__J(lang.RT_Aget_J1_I__J(tmp5, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__6)))))); seq_274000051__1, chunk_274000052__2, count_274000053__3, i_274000054__4 = seq_274000051__1, chunk_274000052__2, count_274000053__3, lang.Numbers_Unchecked_inc_J__J(i_274000054__4); continue L1 } else { var temp__1927000414__auto____5 any; var tmp6 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp6 = A_arbace_a2g_zlib_A_const_34; temp__1927000414__auto____5 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(seq_274000051__1); if jrt.A2g_Truth(temp__1927000414__auto____5) { var seq_274000051__6 any = temp__1927000414__auto____5; var tmp7 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp7 = A_arbace_a2g_zlib_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq_274000051__6)) { var c__1927000678__auto____7 any; var tmp8 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp8 = A_arbace_a2g_zlib_A_const_36; c__1927000678__auto____7 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq_274000051__6); var tmp9 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp9 = A_arbace_a2g_zlib_A_const_37; seq_274000051__1, chunk_274000052__2, count_274000053__3, i_274000054__4 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq_274000051__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__274000059__7 any; var tmp10 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp10 = A_arbace_a2g_zlib_A_const_11; vec__274000059__7 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(seq_274000051__6); var s__8 any = lang.RT_Nth_O_I_O__O(vec__274000059__7, lang.RT_IntCast_J__I(0), nil); var tmp11 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](t.F_cf, jrt.Prim_long.ArrayClass()); var tmp12 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](t.F_cf, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(tmp11, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__8)), lang.Numbers_Inc_J__J(lang.RT_Aget_J1_I__J(tmp12, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__8)))))); var tmp13 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp13 = A_arbace_a2g_zlib_A_const_38; seq_274000051__1, chunk_274000052__2, count_274000053__3, i_274000054__4 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(seq_274000051__6), nil, 0, 0; continue L1 } } else { return nil } } } }; panic("a2g: unreachable") }


func A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_New_O(p0 any) *A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A { A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_Init(); t := &A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A{}; t.Ctor_O(p0); return t }
//line :248:1
func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A) Ctor_O(c__cl any) { t.F_cl = c__cl }
//line :248:1
func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A) Invoke_O_O__O(self, p1__274000044_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.A2g_CastArray[*jrt.LongArray](t.F_cl, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(lang.RT_Aget_J1_I__J(tmp1, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(p1__274000044_SHARP___1))))).Ref() }























func A_arbace_a2g_zlib_adler32_A_New() *A_arbace_a2g_zlib_adler32_A { A_arbace_a2g_zlib_adler32_A_Init(); t := &A_arbace_a2g_zlib_adler32_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_a2g_zlib_adler32_A) Ctor() {}
//line :272:1
func (t *A_arbace_a2g_zlib_adler32_A) Invoke_O_O__O(self, b__0 any) any { var tmp1 int64; var i__2 int64 = 0; var a__3 int64 = 1; var s__4 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z(i__2, int64(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())))) { var a__5 int64 = lang.Numbers_Remainder_J_J__J(lang.Numbers_Add_J_J__J(a__3, lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.A2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(i__2))).Ref()), 255)), 65521)

		i__2, a__3, s__4 = lang.Numbers_Inc_J__J(i__2), a__5, lang.Numbers_Remainder_J_J__J(lang.Numbers_Add_J_J__J(s__4, a__5), 65521); continue L1 } else {
			tmp1 = lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_J_J__J(s__4, 16), a__3) }
//line :272:1
	break L1 }; return jrt.Long_ValueOf_J__Long(tmp1).Ref() }






func A_arbace_a2g_zlib_deflate_A_New() *A_arbace_a2g_zlib_deflate_A { A_arbace_a2g_zlib_deflate_A_Init(); t := &A_arbace_a2g_zlib_deflate_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_a2g_zlib_deflate_A) Ctor() {}
//line :279:1
func (t *A_arbace_a2g_zlib_deflate_A) Invoke_O_O__O(self, b__0 any) any { var out__2 any = jrt.ByteArrayOutputStream_New(); var w__3 any = A_arbace_a2g_zlib_Bits_A_New_O_J_J(out__2, 0, 0); var vec__274000083__4 any; var tmp1 *lang.Var;






	A_arbace_a2g_zlib_A_Init(); tmp1 = A_arbace_a2g_zlib_A_const_60; vec__274000083__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(b__0); var syms__5 any = /*line :279:1*/lang.RT_Nth_O_I_O__O(vec__274000083__4, lang.RT_IntCast_J__I(0), nil); var k__6 any = lang.RT_Nth_O_I_O__O(vec__274000083__4, lang.RT_IntCast_J__I(1), nil); var k__7 int64 = lang.RT_LongCast_O__J(k__6);








	jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(120)); jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(218)); if
	lang.Numbers_IsZero_J__Z(k__7) {
		var tmp2 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp2 = A_arbace_a2g_zlib_A_const_61; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_a2g_zlib_A_Init(); tmp4 = A_arbace_a2g_zlib_A_const_17; var tmp5 any = tmp4; var tmp6 any; A_arbace_a2g_zlib_A_Init(); tmp6 = A_arbace_a2g_zlib_A_const_17; var tmp7 any = tmp6; var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; tmp3.Invoke_O_O_O_O_O__O(w__3, syms__5, tmp5, tmp7, tmp8.Ref()) } else {
//line :289:1
			var from__8 int64 = 0; L1: for { var to__9 int64 = lang.Numbers_Min_J_J__J(k__7, lang.Numbers_Add_J_J__J(from__8, 16384)); var tmp9 *lang.Var



				A_arbace_a2g_zlib_A_Init(); tmp9 = A_arbace_a2g_zlib_A_const_61; lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O_O_O_O_O__O(w__3, syms__5, jrt.Long_ValueOf_J__Long(from__8).Ref(), jrt.Long_ValueOf_J__Long(to__9).Ref(), jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Equiv_J_J__Z(to__9, k__7)).Ref())
				if lang.Numbers_Lt_J_J__Z(to__9, k__7) { from__8 = to__9; continue L1 }
//line :289:1
				break L1 } };





	lang.IFn_Cast(w__3).Invoke__O(); var a__8 any; var tmp10 /*line :279:1*/*lang.Var;
















	A_arbace_a2g_zlib_A_Init(); tmp10 = A_arbace_a2g_zlib_A_const_62; a__8 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(b__0); var seq_274000086__9 any; var tmp11 /*line :279:1*/*lang.Var;

















	A_arbace_a2g_zlib_A_Init(); tmp11 = A_arbace_a2g_zlib_A_const_34; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any; A_arbace_a2g_zlib_A_Init(); tmp13 = A_arbace_a2g_zlib_A_const_63; seq_274000086__9 = tmp12.Invoke_O__O(tmp13); var chunk_274000087__10 any; var count_274000088__11 int64 = 0; var i_274000089__12 int64 = 0; L2:
//line :279:1
	for {

















		if lang.Numbers_Lt_J_J__Z(i_274000089__12, count_274000088__11) { var sh__13 any = lang.Indexed_Cast(chunk_274000087__10).Nth_I__O(lang.RT_IntCast_J__I(i_274000089__12)); jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(lang.Numbers_And_J_J__J(lang.Numbers_ShiftRight_O_O__J(a__8, sh__13), 255))); seq_274000086__9, chunk_274000087__10, count_274000088__11, i_274000089__12 = seq_274000086__9, chunk_274000087__10, count_274000088__11, lang.Numbers_Unchecked_inc_J__J(i_274000089__12); continue L2 } else { var temp__1927000414__auto____13 any; var tmp14 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp14 = A_arbace_a2g_zlib_A_const_34; temp__1927000414__auto____13 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(seq_274000086__9); if jrt.A2g_Truth(temp__1927000414__auto____13) { var seq_274000086__14 any = temp__1927000414__auto____13; var tmp15 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp15 = A_arbace_a2g_zlib_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(seq_274000086__14)) { var c__1927000678__auto____15 any; var tmp16 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp16 = A_arbace_a2g_zlib_A_const_36; c__1927000678__auto____15 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(seq_274000086__14); var tmp17 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp17 = A_arbace_a2g_zlib_A_const_37; seq_274000086__9, chunk_274000087__10, count_274000088__11, i_274000089__12 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(seq_274000086__14), c__1927000678__auto____15, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var sh__15 any; var tmp18 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp18 = A_arbace_a2g_zlib_A_const_11; sh__15 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(seq_274000086__14); jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(lang.Numbers_And_J_J__J(lang.Numbers_ShiftRight_O_O__J(a__8, sh__15), 255))); var tmp19 *lang.Var; A_arbace_a2g_zlib_A_Init(); tmp19 = A_arbace_a2g_zlib_A_const_38; seq_274000086__9, chunk_274000087__10, count_274000088__11, i_274000089__12 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(seq_274000086__14), nil, 0, 0; continue L2 } } }
//line :279:1
		break L2 }; return /*line :298:1*/ jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).ToByteArray__B1().Ref() }
//line :287:1
type A_arbace_a2g_zlib_A struct{ jrt.Object }

var A_arbace_a2g_zlib_A_const_0 *lang.Var

var A_arbace_a2g_zlib_A_const_1 any

var A_arbace_a2g_zlib_A_const_2 *lang.Var

var A_arbace_a2g_zlib_A_const_3 *lang.Var

var A_arbace_a2g_zlib_A_const_4 *lang.Var

var A_arbace_a2g_zlib_A_const_5 any

var A_arbace_a2g_zlib_A_const_6 *lang.Var

var A_arbace_a2g_zlib_A_const_7 *lang.Var

var A_arbace_a2g_zlib_A_const_8 *lang.Var

var A_arbace_a2g_zlib_A_const_9 *lang.Keyword

var A_arbace_a2g_zlib_A_const_10 *lang.Var

var A_arbace_a2g_zlib_A_const_11 *lang.Var

var A_arbace_a2g_zlib_A_const_12 *lang.Var

var A_arbace_a2g_zlib_A_const_13 *lang.Var

var A_arbace_a2g_zlib_A_const_14 *lang.Var

var A_arbace_a2g_zlib_A_const_15 *lang.Var

var A_arbace_a2g_zlib_A_const_16 *lang.Var

var A_arbace_a2g_zlib_A_const_17 any

var A_arbace_a2g_zlib_A_const_18 any

var A_arbace_a2g_zlib_A_const_19 *lang.Var

var A_arbace_a2g_zlib_A_const_20 *lang.Var

var A_arbace_a2g_zlib_A_const_21 any

var A_arbace_a2g_zlib_A_const_22 *lang.Var

var A_arbace_a2g_zlib_A_const_23 *lang.Var

var A_arbace_a2g_zlib_A_const_24 *lang.Var

var A_arbace_a2g_zlib_A_const_25 any

var A_arbace_a2g_zlib_A_const_26 any

var A_arbace_a2g_zlib_A_const_27 any

var A_arbace_a2g_zlib_A_const_28 any

var A_arbace_a2g_zlib_A_const_29 *lang.Var

var A_arbace_a2g_zlib_A_const_30 *lang.Var

var A_arbace_a2g_zlib_A_const_31 *lang.Var

var A_arbace_a2g_zlib_A_const_32 *lang.Var

var A_arbace_a2g_zlib_A_const_33 any

var A_arbace_a2g_zlib_A_const_34 *lang.Var

var A_arbace_a2g_zlib_A_const_35 *lang.Var

var A_arbace_a2g_zlib_A_const_36 *lang.Var

var A_arbace_a2g_zlib_A_const_37 *lang.Var

var A_arbace_a2g_zlib_A_const_38 *lang.Var

var A_arbace_a2g_zlib_A_const_39 *lang.Var

var A_arbace_a2g_zlib_A_const_40 *lang.Var

var A_arbace_a2g_zlib_A_const_41 *lang.Var

var A_arbace_a2g_zlib_A_const_42 *lang.Var

var A_arbace_a2g_zlib_A_const_43 any

var A_arbace_a2g_zlib_A_const_44 *lang.Var

var A_arbace_a2g_zlib_A_const_45 *lang.Var

var A_arbace_a2g_zlib_A_const_46 any

var A_arbace_a2g_zlib_A_const_47 any

var A_arbace_a2g_zlib_A_const_48 *lang.Var

var A_arbace_a2g_zlib_A_const_49 *lang.Var

var A_arbace_a2g_zlib_A_const_50 any

var A_arbace_a2g_zlib_A_const_51 *lang.Var

var A_arbace_a2g_zlib_A_const_52 *lang.Var

var A_arbace_a2g_zlib_A_const_53 any

var A_arbace_a2g_zlib_A_const_54 any

var A_arbace_a2g_zlib_A_const_55 any

var A_arbace_a2g_zlib_A_const_56 any

var A_arbace_a2g_zlib_A_const_57 any

var A_arbace_a2g_zlib_A_const_58 *lang.Var

var A_arbace_a2g_zlib_A_const_59 *lang.Var

var A_arbace_a2g_zlib_A_const_60 *lang.Var

var A_arbace_a2g_zlib_A_const_61 *lang.Var

var A_arbace_a2g_zlib_A_const_62 *lang.Var

var A_arbace_a2g_zlib_A_const_63 any

var A_arbace_a2g_zlib_A_init jrt.ClassInit

func A_arbace_a2g_zlib_A_Init() { if !A_arbace_a2g_zlib_A_init.Done() { A_arbace_a2g_zlib_A_init.Run(A_arbace_a2g_zlib_A_clinit) } }

func A_arbace_a2g_zlib_A_clinit() { A_arbace_a2g_zlib_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_a2g_zlib_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_zlib_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_a2g_zlib_A_const_3 = lang.RT_Var_String_String__Var(Lit_0, Lit_3); A_arbace_a2g_zlib_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_4); A_arbace_a2g_zlib_A_const_5 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7))); A_arbace_a2g_zlib_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_a2g_zlib_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_a2g_zlib_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_a2g_zlib_A_const_9 = lang.RT_Keyword_String_String__Keyword(nil, Lit_11); A_arbace_a2g_zlib_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_a2g_zlib_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_a2g_zlib_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_a2g_zlib_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_a2g_zlib_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_a2g_zlib_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_a2g_zlib_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_a2g_zlib_A_const_17 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_a2g_zlib_A_const_18 = jrt.Long_ValueOf_J__Long(16).Ref(); A_arbace_a2g_zlib_A_const_19 = lang.RT_Var_String_String__Var(Lit_5, Lit_19); A_arbace_a2g_zlib_A_const_20 = lang.RT_Var_String_String__Var(Lit_5, Lit_20); A_arbace_a2g_zlib_A_const_21 = jrt.Long_ValueOf_J__Long(-1).Ref(); A_arbace_a2g_zlib_A_const_22 = lang.RT_Var_String_String__Var(Lit_5, Lit_21); A_arbace_a2g_zlib_A_const_23 = lang.RT_Var_String_String__Var(Lit_5, Lit_22); A_arbace_a2g_zlib_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_a2g_zlib_A_const_25 = jrt.Long_ValueOf_J__Long(18).Ref(); A_arbace_a2g_zlib_A_const_26 = jrt.Long_ValueOf_J__Long(17).Ref(); A_arbace_a2g_zlib_A_const_27 = jrt.Long_ValueOf_J__Long(286).Ref(); A_arbace_a2g_zlib_A_const_28 = jrt.Long_ValueOf_J__Long(30).Ref(); A_arbace_a2g_zlib_A_const_29 = lang.RT_Var_String_String__Var(Lit_5, Lit_24); A_arbace_a2g_zlib_A_const_30 = lang.RT_Var_String_String__Var(Lit_5, Lit_25); A_arbace_a2g_zlib_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_a2g_zlib_A_const_32 = lang.RT_Var_String_String__Var(Lit_5, Lit_27); A_arbace_a2g_zlib_A_const_33 = jrt.Long_ValueOf_J__Long(19).Ref(); A_arbace_a2g_zlib_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_a2g_zlib_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_a2g_zlib_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_a2g_zlib_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_a2g_zlib_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_a2g_zlib_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_a2g_zlib_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_a2g_zlib_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_a2g_zlib_A_const_42 = lang.RT_Var_String_String__Var(Lit_5, Lit_36); A_arbace_a2g_zlib_A_const_43 = jrt.Long_ValueOf_J__Long(40).Ref(); A_arbace_a2g_zlib_A_const_44 = lang.RT_Var_String_String__Var(Lit_5, Lit_37); A_arbace_a2g_zlib_A_const_45 = lang.RT_Var_String_String__Var(Lit_5, Lit_38); A_arbace_a2g_zlib_A_const_46 = jrt.Long_ValueOf_J__Long(15).Ref(); A_arbace_a2g_zlib_A_const_47 = jrt.Long_ValueOf_J__Long(286).Ref(); A_arbace_a2g_zlib_A_const_48 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_a2g_zlib_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_a2g_zlib_A_const_50 = jrt.Long_ValueOf_J__Long(7).Ref(); A_arbace_a2g_zlib_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_a2g_zlib_A_const_52 = lang.RT_Var_String_String__Var(Lit_5, Lit_42); A_arbace_a2g_zlib_A_const_53 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_a2g_zlib_A_const_54 = jrt.Long_ValueOf_J__Long(2).Ref(); A_arbace_a2g_zlib_A_const_55 = jrt.Long_ValueOf_J__Long(5).Ref(); A_arbace_a2g_zlib_A_const_56 = jrt.Long_ValueOf_J__Long(4).Ref(); A_arbace_a2g_zlib_A_const_57 = jrt.Long_ValueOf_J__Long(3).Ref(); A_arbace_a2g_zlib_A_const_58 = lang.RT_Var_String_String__Var(Lit_5, Lit_43); A_arbace_a2g_zlib_A_const_59 = lang.RT_Var_String_String__Var(Lit_5, Lit_44); A_arbace_a2g_zlib_A_const_60 = lang.RT_Var_String_String__Var(Lit_5, Lit_45); A_arbace_a2g_zlib_A_const_61 = lang.RT_Var_String_String__Var(Lit_5, Lit_46); A_arbace_a2g_zlib_A_const_62 = lang.RT_Var_String_String__Var(Lit_5, Lit_47); A_arbace_a2g_zlib_A_const_63 = lang.Tuple_Create_O_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(24).Ref(), jrt.Long_ValueOf_J__Long(16).Ref(), jrt.Long_ValueOf_J__Long(8).Ref(), jrt.Long_ValueOf_J__Long(0).Ref()) }

func A_arbace_a2g_zlib_A_New() *A_arbace_a2g_zlib_A { A_arbace_a2g_zlib_A_Init(); t := &A_arbace_a2g_zlib_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_zlib_A) Ctor() {}

func (t *A_arbace_a2g_zlib_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_A_class }

func (t *A_arbace_a2g_zlib_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_A); return ok }

func A_arbace_a2g_zlib_A_Cast(x any) *A_arbace_a2g_zlib_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_A_class)) }; return v }



type A_arbace_a2g_zlib_adler32_A struct{ jrt.Object }

func (t *A_arbace_a2g_zlib_adler32_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_zlib_adler32_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_adler32_A_init jrt.ClassInit

func A_arbace_a2g_zlib_adler32_A_Init() { if !A_arbace_a2g_zlib_adler32_A_init.Done() { A_arbace_a2g_zlib_adler32_A_init.Run(A_arbace_a2g_zlib_adler32_A_clinit) } }

func A_arbace_a2g_zlib_adler32_A_clinit() { A_arbace_a2g_zlib_adler32_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_48, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_adler32_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_adler32_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_adler32_A_class }

func (t *A_arbace_a2g_zlib_adler32_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_adler32_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_adler32_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_adler32_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_adler32_A); return ok }

func A_arbace_a2g_zlib_adler32_A_Cast(x any) *A_arbace_a2g_zlib_adler32_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_adler32_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_adler32_A_class)) }; return v }



type A_arbace_a2g_zlib_canonical_codes_A struct{ jrt.Object }

func (t *A_arbace_a2g_zlib_canonical_codes_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_zlib_canonical_codes_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_canonical_codes_A_init jrt.ClassInit

func A_arbace_a2g_zlib_canonical_codes_A_Init() { if !A_arbace_a2g_zlib_canonical_codes_A_init.Done() { A_arbace_a2g_zlib_canonical_codes_A_init.Run(A_arbace_a2g_zlib_canonical_codes_A_clinit) } }

func A_arbace_a2g_zlib_canonical_codes_A_clinit() { A_arbace_a2g_zlib_canonical_codes_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_49, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_canonical_codes_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_canonical_codes_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_canonical_codes_A_class }

func (t *A_arbace_a2g_zlib_canonical_codes_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_canonical_codes_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_canonical_codes_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_canonical_codes_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_canonical_codes_A); return ok }

func A_arbace_a2g_zlib_canonical_codes_A_Cast(x any) *A_arbace_a2g_zlib_canonical_codes_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_canonical_codes_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_canonical_codes_A_class)) }; return v }



type A_arbace_a2g_zlib_code_of_A struct{ jrt.Object }

func (t *A_arbace_a2g_zlib_code_of_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_zlib_code_of_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_code_of_A_init jrt.ClassInit

func A_arbace_a2g_zlib_code_of_A_Init() { if !A_arbace_a2g_zlib_code_of_A_init.Done() { A_arbace_a2g_zlib_code_of_A_init.Run(A_arbace_a2g_zlib_code_of_A_clinit) } }

func A_arbace_a2g_zlib_code_of_A_clinit() { A_arbace_a2g_zlib_code_of_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_50, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_code_of_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_code_of_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_code_of_A_class }

func (t *A_arbace_a2g_zlib_code_of_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_code_of_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_code_of_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_code_of_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_code_of_A); return ok }

func A_arbace_a2g_zlib_code_of_A_Cast(x any) *A_arbace_a2g_zlib_code_of_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_code_of_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_code_of_A_class)) }; return v }



type A_arbace_a2g_zlib_deflate_A struct{ jrt.Object }

func (t *A_arbace_a2g_zlib_deflate_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_zlib_deflate_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_deflate_A_init jrt.ClassInit

func A_arbace_a2g_zlib_deflate_A_Init() { if !A_arbace_a2g_zlib_deflate_A_init.Done() { A_arbace_a2g_zlib_deflate_A_init.Run(A_arbace_a2g_zlib_deflate_A_clinit) } }

func A_arbace_a2g_zlib_deflate_A_clinit() { A_arbace_a2g_zlib_deflate_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_51, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_deflate_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_deflate_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_deflate_A_class }

func (t *A_arbace_a2g_zlib_deflate_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_deflate_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_deflate_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_deflate_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_deflate_A); return ok }

func A_arbace_a2g_zlib_deflate_A_Cast(x any) *A_arbace_a2g_zlib_deflate_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_deflate_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_deflate_A_class)) }; return v }



type A_arbace_a2g_zlib_eval274000004_A struct{ jrt.Object }

func A_arbace_a2g_zlib_eval274000004_A_New() *A_arbace_a2g_zlib_eval274000004_A { t := &A_arbace_a2g_zlib_eval274000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_zlib_eval274000004_A) Ctor() {}

func (t *A_arbace_a2g_zlib_eval274000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_eval274000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_eval274000004_A_class }

func (t *A_arbace_a2g_zlib_eval274000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_eval274000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_eval274000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_eval274000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_eval274000004_A); return ok }

func A_arbace_a2g_zlib_eval274000004_A_Cast(x any) *A_arbace_a2g_zlib_eval274000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_eval274000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_eval274000004_A_class)) }; return v }



type A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A struct{ jrt.Object }

func (t *A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_init jrt.ClassInit

func A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_Init() { if !A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_init.Done() { A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_init.Run(A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_clinit) } }

func A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_clinit() { A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_52, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_class }

func (t *A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A); return ok }

func A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_Cast(x any) *A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_class)) }; return v }



type A_arbace_a2g_zlib_eval274000008_A struct{ jrt.Object }

func A_arbace_a2g_zlib_eval274000008_A_New() *A_arbace_a2g_zlib_eval274000008_A { t := &A_arbace_a2g_zlib_eval274000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_zlib_eval274000008_A) Ctor() {}

func (t *A_arbace_a2g_zlib_eval274000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_eval274000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_eval274000008_A_class }

func (t *A_arbace_a2g_zlib_eval274000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_eval274000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_eval274000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_eval274000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_eval274000008_A); return ok }

func A_arbace_a2g_zlib_eval274000008_A_Cast(x any) *A_arbace_a2g_zlib_eval274000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_eval274000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_eval274000008_A_class)) }; return v }



type A_arbace_a2g_zlib_eval274000008_fn__274000009_A struct{ jrt.Object }

func (t *A_arbace_a2g_zlib_eval274000008_fn__274000009_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_zlib_eval274000008_fn__274000009_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_eval274000008_fn__274000009_A_init jrt.ClassInit

func A_arbace_a2g_zlib_eval274000008_fn__274000009_A_Init() { if !A_arbace_a2g_zlib_eval274000008_fn__274000009_A_init.Done() { A_arbace_a2g_zlib_eval274000008_fn__274000009_A_init.Run(A_arbace_a2g_zlib_eval274000008_fn__274000009_A_clinit) } }

func A_arbace_a2g_zlib_eval274000008_fn__274000009_A_clinit() { A_arbace_a2g_zlib_eval274000008_fn__274000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_54, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_eval274000008_fn__274000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_eval274000008_fn__274000009_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_eval274000008_fn__274000009_A_class }

func (t *A_arbace_a2g_zlib_eval274000008_fn__274000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_eval274000008_fn__274000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_eval274000008_fn__274000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_eval274000008_fn__274000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_eval274000008_fn__274000009_A); return ok }

func A_arbace_a2g_zlib_eval274000008_fn__274000009_A_Cast(x any) *A_arbace_a2g_zlib_eval274000008_fn__274000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_eval274000008_fn__274000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_eval274000008_fn__274000009_A_class)) }; return v }



type A_arbace_a2g_zlib_eval274000012_A struct{ jrt.Object }

func A_arbace_a2g_zlib_eval274000012_A_New() *A_arbace_a2g_zlib_eval274000012_A { t := &A_arbace_a2g_zlib_eval274000012_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_zlib_eval274000012_A) Ctor() {}

func (t *A_arbace_a2g_zlib_eval274000012_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_eval274000012_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_eval274000012_A_class }

func (t *A_arbace_a2g_zlib_eval274000012_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_eval274000012_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_eval274000012_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_eval274000012_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_eval274000012_A); return ok }

func A_arbace_a2g_zlib_eval274000012_A_Cast(x any) *A_arbace_a2g_zlib_eval274000012_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_eval274000012_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_eval274000012_A_class)) }; return v }



type A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A struct{ jrt.Object }

func (t *A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A) Is_Compiler_AOTF3() {}

var A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_init jrt.ClassInit

func A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_Init() { if !A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_init.Done() { A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_init.Run(A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_clinit) } }

func A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_clinit() { A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_55, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_class }

func (t *A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A); return ok }

func A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_Cast(x any) *A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_class)) }; return v }



type A_arbace_a2g_zlib_huffman_lengths_A struct{ jrt.Object }

func (t *A_arbace_a2g_zlib_huffman_lengths_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_zlib_huffman_lengths_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_huffman_lengths_A_init jrt.ClassInit

func A_arbace_a2g_zlib_huffman_lengths_A_Init() { if !A_arbace_a2g_zlib_huffman_lengths_A_init.Done() { A_arbace_a2g_zlib_huffman_lengths_A_init.Run(A_arbace_a2g_zlib_huffman_lengths_A_clinit) } }

func A_arbace_a2g_zlib_huffman_lengths_A_clinit() { A_arbace_a2g_zlib_huffman_lengths_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_56, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_huffman_lengths_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_huffman_lengths_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_huffman_lengths_A_class }

func (t *A_arbace_a2g_zlib_huffman_lengths_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_huffman_lengths_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_huffman_lengths_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_huffman_lengths_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_huffman_lengths_A); return ok }

func A_arbace_a2g_zlib_huffman_lengths_A_Cast(x any) *A_arbace_a2g_zlib_huffman_lengths_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_huffman_lengths_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_huffman_lengths_A_class)) }; return v }



type A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A struct{ jrt.Object; F_fs any }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_init jrt.ClassInit

func A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_Init() { if !A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_init.Done() { A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_init.Run(A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_clinit) } }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_clinit() { A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_57, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_class }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A); return ok }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_Cast(x any) *A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_class)) }; return v }



type A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A struct{ jrt.Object; F_fs any }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_init jrt.ClassInit

func A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_Init() { if !A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_init.Done() { A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_init.Run(A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_clinit) } }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_clinit() { A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_58, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_class }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A); return ok }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_Cast(x any) *A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_class)) }; return v }



type A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A struct{ jrt.Object; F_parent any; F_n int32; F_start any }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_init jrt.ClassInit

func A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_Init() { if !A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_init.Done() { A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_init.Run(A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_clinit) } }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_clinit() { A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_59, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_class }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A); return ok }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_Cast(x any) *A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_class)) }; return v }



type A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A struct{ jrt.Object; F_parent, F_lens any; F_root int64 }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_init jrt.ClassInit

func A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_Init() { if !A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_init.Done() { A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_init.Run(A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_clinit) } }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_clinit() { A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_60, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_class }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A); return ok }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_Cast(x any) *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_class)) }; return v }



type A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A struct{ jrt.Object; F_parent, F_s any; F_root int64 }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_init jrt.ClassInit

func A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_Init() { if !A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_init.Done() { A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_init.Run(A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_clinit) } }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_clinit() { A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_61, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_class }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A); return ok }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_Cast(x any) *A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_class)) }; return v }



type A_arbace_a2g_zlib_insert_BANG__A struct{ jrt.Object }

func (t *A_arbace_a2g_zlib_insert_BANG__A) Is_Compiler_AOTF4() {}

var A_arbace_a2g_zlib_insert_BANG__A_fn_class *jrt.Class

var A_arbace_a2g_zlib_insert_BANG__A_init jrt.ClassInit

func A_arbace_a2g_zlib_insert_BANG__A_Init() { if !A_arbace_a2g_zlib_insert_BANG__A_init.Done() { A_arbace_a2g_zlib_insert_BANG__A_init.Run(A_arbace_a2g_zlib_insert_BANG__A_clinit) } }

func A_arbace_a2g_zlib_insert_BANG__A_clinit() { A_arbace_a2g_zlib_insert_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_62, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_insert_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_insert_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_insert_BANG__A_class }

func (t *A_arbace_a2g_zlib_insert_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_insert_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_insert_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_insert_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_insert_BANG__A); return ok }

func A_arbace_a2g_zlib_insert_BANG__A_Cast(x any) *A_arbace_a2g_zlib_insert_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_insert_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_insert_BANG__A_class)) }; return v }



type A_arbace_a2g_zlib_longest_A struct{ jrt.Object }

func (t *A_arbace_a2g_zlib_longest_A) Is_Compiler_AOTF3() {}

var A_arbace_a2g_zlib_longest_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_longest_A_init jrt.ClassInit

func A_arbace_a2g_zlib_longest_A_Init() { if !A_arbace_a2g_zlib_longest_A_init.Done() { A_arbace_a2g_zlib_longest_A_init.Run(A_arbace_a2g_zlib_longest_A_clinit) } }

func A_arbace_a2g_zlib_longest_A_clinit() { A_arbace_a2g_zlib_longest_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_63, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_longest_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_longest_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_longest_A_class }

func (t *A_arbace_a2g_zlib_longest_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_longest_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_longest_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_longest_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_longest_A); return ok }

func A_arbace_a2g_zlib_longest_A_Cast(x any) *A_arbace_a2g_zlib_longest_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_longest_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_longest_A_class)) }; return v }



type A_arbace_a2g_zlib_lz77_A struct{ jrt.Object }

func (t *A_arbace_a2g_zlib_lz77_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_zlib_lz77_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_lz77_A_init jrt.ClassInit

func A_arbace_a2g_zlib_lz77_A_Init() { if !A_arbace_a2g_zlib_lz77_A_init.Done() { A_arbace_a2g_zlib_lz77_A_init.Run(A_arbace_a2g_zlib_lz77_A_clinit) } }

func A_arbace_a2g_zlib_lz77_A_clinit() { A_arbace_a2g_zlib_lz77_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_64, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_lz77_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_lz77_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_lz77_A_class }

func (t *A_arbace_a2g_zlib_lz77_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_lz77_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_lz77_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_lz77_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_lz77_A); return ok }

func A_arbace_a2g_zlib_lz77_A_Cast(x any) *A_arbace_a2g_zlib_lz77_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_lz77_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_lz77_A_class)) }; return v }



type A_arbace_a2g_zlib_match_length_A struct{ jrt.Object }

func (t *A_arbace_a2g_zlib_match_length_A) Is_Compiler_AOTF4() {}

var A_arbace_a2g_zlib_match_length_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_match_length_A_init jrt.ClassInit

func A_arbace_a2g_zlib_match_length_A_Init() { if !A_arbace_a2g_zlib_match_length_A_init.Done() { A_arbace_a2g_zlib_match_length_A_init.Run(A_arbace_a2g_zlib_match_length_A_clinit) } }

func A_arbace_a2g_zlib_match_length_A_clinit() { A_arbace_a2g_zlib_match_length_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_65, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_match_length_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_match_length_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_match_length_A_class }

func (t *A_arbace_a2g_zlib_match_length_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_match_length_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_match_length_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_match_length_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_match_length_A); return ok }

func A_arbace_a2g_zlib_match_length_A_Cast(x any) *A_arbace_a2g_zlib_match_length_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_match_length_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_match_length_A_class)) }; return v }



type A_arbace_a2g_zlib_reverse_bits_A struct{ jrt.Object }

func (t *A_arbace_a2g_zlib_reverse_bits_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_zlib_reverse_bits_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_reverse_bits_A_init jrt.ClassInit

func A_arbace_a2g_zlib_reverse_bits_A_Init() { if !A_arbace_a2g_zlib_reverse_bits_A_init.Done() { A_arbace_a2g_zlib_reverse_bits_A_init.Run(A_arbace_a2g_zlib_reverse_bits_A_clinit) } }

func A_arbace_a2g_zlib_reverse_bits_A_clinit() { A_arbace_a2g_zlib_reverse_bits_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_66, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_reverse_bits_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_reverse_bits_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_reverse_bits_A_class }

func (t *A_arbace_a2g_zlib_reverse_bits_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_reverse_bits_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_reverse_bits_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_reverse_bits_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_reverse_bits_A); return ok }

func A_arbace_a2g_zlib_reverse_bits_A_Cast(x any) *A_arbace_a2g_zlib_reverse_bits_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_reverse_bits_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_reverse_bits_A_class)) }; return v }



type A_arbace_a2g_zlib_rle_lengths_A struct{ jrt.Object }

func (t *A_arbace_a2g_zlib_rle_lengths_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_zlib_rle_lengths_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_rle_lengths_A_init jrt.ClassInit

func A_arbace_a2g_zlib_rle_lengths_A_Init() { if !A_arbace_a2g_zlib_rle_lengths_A_init.Done() { A_arbace_a2g_zlib_rle_lengths_A_init.Run(A_arbace_a2g_zlib_rle_lengths_A_clinit) } }

func A_arbace_a2g_zlib_rle_lengths_A_clinit() { A_arbace_a2g_zlib_rle_lengths_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_67, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_rle_lengths_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_rle_lengths_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_rle_lengths_A_class }

func (t *A_arbace_a2g_zlib_rle_lengths_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_rle_lengths_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_rle_lengths_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_rle_lengths_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_rle_lengths_A); return ok }

func A_arbace_a2g_zlib_rle_lengths_A_Cast(x any) *A_arbace_a2g_zlib_rle_lengths_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_rle_lengths_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_rle_lengths_A_class)) }; return v }



type A_arbace_a2g_zlib_rle_lengths_fn__274000038_A struct{ jrt.Object; F_i any; F_n int32; F_x int64; F_v any }

func (t *A_arbace_a2g_zlib_rle_lengths_fn__274000038_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_init jrt.ClassInit

func A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_Init() { if !A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_init.Done() { A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_init.Run(A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_clinit) } }

func A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_clinit() { A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_68, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_rle_lengths_fn__274000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_rle_lengths_fn__274000038_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_class }

func (t *A_arbace_a2g_zlib_rle_lengths_fn__274000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_rle_lengths_fn__274000038_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_rle_lengths_fn__274000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_rle_lengths_fn__274000038_A); return ok }

func A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_Cast(x any) *A_arbace_a2g_zlib_rle_lengths_fn__274000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_rle_lengths_fn__274000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_class)) }; return v }



type A_arbace_a2g_zlib_write_block_BANG__A struct{ jrt.Object }

func (t *A_arbace_a2g_zlib_write_block_BANG__A) Is_Compiler_AOTF5() {}

var A_arbace_a2g_zlib_write_block_BANG__A_fn_class *jrt.Class

var A_arbace_a2g_zlib_write_block_BANG__A_init jrt.ClassInit

func A_arbace_a2g_zlib_write_block_BANG__A_Init() { if !A_arbace_a2g_zlib_write_block_BANG__A_init.Done() { A_arbace_a2g_zlib_write_block_BANG__A_init.Run(A_arbace_a2g_zlib_write_block_BANG__A_clinit) } }

func A_arbace_a2g_zlib_write_block_BANG__A_clinit() { A_arbace_a2g_zlib_write_block_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_69, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_write_block_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_write_block_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_write_block_BANG__A_class }

func (t *A_arbace_a2g_zlib_write_block_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_write_block_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_write_block_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_write_block_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_write_block_BANG__A); return ok }

func A_arbace_a2g_zlib_write_block_BANG__A_Cast(x any) *A_arbace_a2g_zlib_write_block_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_write_block_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_write_block_BANG__A_class)) }; return v }



type A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A struct{ jrt.Object; F_df any }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_init jrt.ClassInit

func A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_Init() { if !A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_init.Done() { A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_init.Run(A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_clinit) } }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_clinit() { A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_70, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_class }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A); return ok }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_Cast(x any) *A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_class)) }; return v }



type A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A struct{ jrt.Object; F_ll any }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_init jrt.ClassInit

func A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_Init() { if !A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_init.Done() { A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_init.Run(A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_clinit) } }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_clinit() { A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_71, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_class }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A); return ok }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_Cast(x any) *A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_class)) }; return v }



type A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A struct{ jrt.Object; F_dl any }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_init jrt.ClassInit

func A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_Init() { if !A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_init.Done() { A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_init.Run(A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_clinit) } }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_clinit() { A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_72, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_class }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A); return ok }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_Cast(x any) *A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_class)) }; return v }



type A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A struct{ jrt.Object; F_cf, F_rle any }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_init jrt.ClassInit

func A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_Init() { if !A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_init.Done() { A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_init.Run(A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_clinit) } }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_clinit() { A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_73, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_class }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A); return ok }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_Cast(x any) *A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_class)) }; return v }



type A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A struct{ jrt.Object; F_cl any }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_fn_class *jrt.Class

var A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_init jrt.ClassInit

func A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_Init() { if !A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_init.Done() { A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_init.Run(A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_clinit) } }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_clinit() { A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_74, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_class }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A); return ok }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_Cast(x any) *A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_class)) }; return v }
