//line aot_arbace_a2g_zlib__init.ae:1
package aot_arbace_a2g_zlib

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_zlib__init_A_Unit0__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_a2g_zlib__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_zlib__init_A_const_1) }
//line :1:1
func A_arbace_a2g_zlib__init_A_Unit1__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_a2g_zlib__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_2)) }
//line :1:1
func A_arbace_a2g_zlib__init_A_Unit2__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_Init(); tmp2 = A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_a2g_zlib__init_A_Unit3__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_a2g_zlib__init_A_const_1)).Equals_O__Z(A_arbace_a2g_zlib__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_a2g_zlib_eval274000008_fn__274000009_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_zlib_eval274000008_fn__274000009_A_Init(); tmp2 = A_arbace_a2g_zlib_eval274000008_fn__274000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_a2g_zlib__init_A_Load__O() any { A_arbace_a2g_zlib__init_A_Init(); A_arbace_a2g_zlib__init_A_Unit0__O(); A_arbace_a2g_zlib__init_A_Unit1__O(); A_arbace_a2g_zlib__init_A_Unit2__O(); A_arbace_a2g_zlib__init_A_Unit3__O(); A_arbace_a2g_zlib__init_A_Unit4__O(); A_arbace_a2g_zlib__init_A_Unit5__O(); A_arbace_a2g_zlib__init_A_Unit6__O(); A_arbace_a2g_zlib__init_A_Unit7__O(); A_arbace_a2g_zlib__init_A_Unit8__O(); A_arbace_a2g_zlib__init_A_Unit9__O(); A_arbace_a2g_zlib__init_A_Unit10__O(); A_arbace_a2g_zlib__init_A_Unit11__O(); A_arbace_a2g_zlib__init_A_Unit12__O(); A_arbace_a2g_zlib__init_A_Unit13__O(); A_arbace_a2g_zlib__init_A_Unit14__O(); A_arbace_a2g_zlib__init_A_Unit15__O(); A_arbace_a2g_zlib__init_A_Unit16__O(); A_arbace_a2g_zlib__init_A_Unit17__O(); A_arbace_a2g_zlib__init_A_Unit18__O(); A_arbace_a2g_zlib__init_A_Unit19__O(); A_arbace_a2g_zlib__init_A_Unit20__O(); A_arbace_a2g_zlib__init_A_Unit21__O(); A_arbace_a2g_zlib__init_A_Unit22__O(); A_arbace_a2g_zlib__init_A_Unit23__O(); A_arbace_a2g_zlib__init_A_Unit24__O(); A_arbace_a2g_zlib__init_A_Unit25__O(); return nil }













func A_arbace_a2g_zlib__init_A_Unit4__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_83)); var tmp2 *lang.Var = A_arbace_a2g_zlib__init_A_const_5; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_6)); var tmp3 *lang.Var = A_arbace_a2g_zlib__init_A_const_5; var tmp4 any = A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_New(); var tmp5 *jrt.Class; A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_Init(); tmp5 = A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_fn_class; jrt.NN(tmp3).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); return A_arbace_a2g_zlib__init_A_const_4.Ref() }



















func A_arbace_a2g_zlib__init_A_Unit5__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_7; var tmp2 any = A_arbace_a2g_zlib_reverse_bits_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_zlib_reverse_bits_A_Init(); tmp3 = A_arbace_a2g_zlib_reverse_bits_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_7; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_8)); return A_arbace_a2g_zlib__init_A_const_7.Ref() }






func A_arbace_a2g_zlib__init_A_Unit6__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(46, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_9; var tmp2 any = A_arbace_a2g_zlib_huffman_lengths_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_zlib_huffman_lengths_A_Init(); tmp3 = A_arbace_a2g_zlib_huffman_lengths_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_9; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_10)); return A_arbace_a2g_zlib__init_A_const_9.Ref() }




































func A_arbace_a2g_zlib__init_A_Unit7__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(83, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_11; var tmp2 any = A_arbace_a2g_zlib_canonical_codes_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_zlib_canonical_codes_A_Init(); tmp3 = A_arbace_a2g_zlib_canonical_codes_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_11; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_12)); return A_arbace_a2g_zlib__init_A_const_11.Ref() }























func A_arbace_a2g_zlib__init_A_Unit8__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(107, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_13; jrt.NN(tmp1).BindRoot_O__V(lang.Numbers_Long_array_O__J1(A_arbace_a2g_zlib__init_A_const_14).Ref()); var tmp2 *lang.Var = A_arbace_a2g_zlib__init_A_const_13; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_15)); return A_arbace_a2g_zlib__init_A_const_13.Ref() }
func A_arbace_a2g_zlib__init_A_Unit9__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(108, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_16; jrt.NN(tmp1).BindRoot_O__V(lang.Numbers_Long_array_O__J1(A_arbace_a2g_zlib__init_A_const_17).Ref()); var tmp2 *lang.Var = A_arbace_a2g_zlib__init_A_const_16; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_18)); return A_arbace_a2g_zlib__init_A_const_16.Ref() }
func A_arbace_a2g_zlib__init_A_Unit10__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(109, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_19; jrt.NN(tmp1).BindRoot_O__V(lang.Numbers_Long_array_O__J1(A_arbace_a2g_zlib__init_A_const_20).Ref()); var tmp2 *lang.Var = A_arbace_a2g_zlib__init_A_const_19; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_21)); return A_arbace_a2g_zlib__init_A_const_19.Ref() }

func A_arbace_a2g_zlib__init_A_Unit11__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(111, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_22; jrt.NN(tmp1).BindRoot_O__V(lang.Numbers_Long_array_O__J1(A_arbace_a2g_zlib__init_A_const_23).Ref()); var tmp2 *lang.Var = A_arbace_a2g_zlib__init_A_const_22; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_24)); return A_arbace_a2g_zlib__init_A_const_22.Ref() }

func A_arbace_a2g_zlib__init_A_Unit12__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(113, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_25; var tmp2 any = A_arbace_a2g_zlib_code_of_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_zlib_code_of_A_Init(); tmp3 = A_arbace_a2g_zlib_code_of_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_25; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_26)); return A_arbace_a2g_zlib__init_A_const_25.Ref() }









func A_arbace_a2g_zlib__init_A_Unit13__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(123, 1); jrt.NN(A_arbace_a2g_zlib__init_A_const_27).BindRoot_O__V(A_arbace_a2g_zlib__init_A_const_28); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_27; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_29)); return A_arbace_a2g_zlib__init_A_const_27.Ref() }
func A_arbace_a2g_zlib__init_A_Unit14__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(124, 1); jrt.NN(A_arbace_a2g_zlib__init_A_const_30).BindRoot_O__V(A_arbace_a2g_zlib__init_A_const_31); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_30; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_32)); return A_arbace_a2g_zlib__init_A_const_30.Ref() }
func A_arbace_a2g_zlib__init_A_Unit15__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(125, 1); jrt.NN(A_arbace_a2g_zlib__init_A_const_33).BindRoot_O__V(A_arbace_a2g_zlib__init_A_const_31); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_33; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_34)); return A_arbace_a2g_zlib__init_A_const_33.Ref() }

func A_arbace_a2g_zlib__init_A_Unit16__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(127, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_35; var tmp2 any = A_arbace_a2g_zlib_match_length_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_zlib_match_length_A_Init(); tmp3 = A_arbace_a2g_zlib_match_length_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_35; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_36)); return A_arbace_a2g_zlib__init_A_const_35.Ref() }




func A_arbace_a2g_zlib__init_A_Unit17__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(132, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_37; var tmp2 any = A_arbace_a2g_zlib_insert_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_zlib_insert_BANG__A_Init(); tmp3 = A_arbace_a2g_zlib_insert_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_37; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_38)); return A_arbace_a2g_zlib__init_A_const_37.Ref() }













func A_arbace_a2g_zlib__init_A_Unit18__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(146, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_39; var tmp2 any = A_arbace_a2g_zlib_longest_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_zlib_longest_A_Init(); tmp3 = A_arbace_a2g_zlib_longest_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_39; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_40)); return A_arbace_a2g_zlib__init_A_const_39.Ref() }

















func A_arbace_a2g_zlib__init_A_Unit19__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(164, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_41; var tmp2 any = A_arbace_a2g_zlib_lz77_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_zlib_lz77_A_Init(); tmp3 = A_arbace_a2g_zlib_lz77_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_41; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_42)); return A_arbace_a2g_zlib__init_A_const_41.Ref() }




































func A_arbace_a2g_zlib__init_A_Unit20__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(201, 1); jrt.NN(A_arbace_a2g_zlib__init_A_const_43).BindRoot_O__V(A_arbace_a2g_zlib__init_A_const_44); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_43; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_45)); return A_arbace_a2g_zlib__init_A_const_43.Ref() }
func A_arbace_a2g_zlib__init_A_Unit21__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); jrt.NN(A_arbace_a2g_zlib__init_A_const_46).BindRoot_O__V(A_arbace_a2g_zlib__init_A_const_47); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_46; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_48)); return A_arbace_a2g_zlib__init_A_const_46.Ref() }

func A_arbace_a2g_zlib__init_A_Unit22__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(204, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_49; var tmp2 any = A_arbace_a2g_zlib_rle_lengths_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_zlib_rle_lengths_A_Init(); tmp3 = A_arbace_a2g_zlib_rle_lengths_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_49; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_50)); return A_arbace_a2g_zlib__init_A_const_49.Ref() }














func A_arbace_a2g_zlib__init_A_Unit23__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(219, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_51; var tmp2 any = A_arbace_a2g_zlib_write_block_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_zlib_write_block_BANG__A_Init(); tmp3 = A_arbace_a2g_zlib_write_block_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_51; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_52)); return A_arbace_a2g_zlib__init_A_const_51.Ref() }




















































func A_arbace_a2g_zlib__init_A_Unit24__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(272, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_53; var tmp2 any = A_arbace_a2g_zlib_adler32_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_zlib_adler32_A_Init(); tmp3 = A_arbace_a2g_zlib_adler32_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_53; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_54)); return A_arbace_a2g_zlib__init_A_const_53.Ref() }






func A_arbace_a2g_zlib__init_A_Unit25__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(279, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_55; var tmp2 any = A_arbace_a2g_zlib_deflate_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_zlib_deflate_A_Init(); tmp3 = A_arbace_a2g_zlib_deflate_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_55; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_56)); return A_arbace_a2g_zlib__init_A_const_55.Ref() }



type A_arbace_a2g_zlib__init_A struct{ jrt.Object }

var A_arbace_a2g_zlib__init_A_const_0 *lang.Var

var A_arbace_a2g_zlib__init_A_const_1 any

var A_arbace_a2g_zlib__init_A_const_2 any

var A_arbace_a2g_zlib__init_A_const_3 any

var A_arbace_a2g_zlib__init_A_const_4 *jrt.Class

var A_arbace_a2g_zlib__init_A_const_5 *lang.Var

var A_arbace_a2g_zlib__init_A_const_6 any

var A_arbace_a2g_zlib__init_A_const_7 *lang.Var

var A_arbace_a2g_zlib__init_A_const_8 any

var A_arbace_a2g_zlib__init_A_const_9 *lang.Var

var A_arbace_a2g_zlib__init_A_const_10 any

var A_arbace_a2g_zlib__init_A_const_11 *lang.Var

var A_arbace_a2g_zlib__init_A_const_12 any

var A_arbace_a2g_zlib__init_A_const_13 *lang.Var

var A_arbace_a2g_zlib__init_A_const_14 any

var A_arbace_a2g_zlib__init_A_const_15 any

var A_arbace_a2g_zlib__init_A_const_16 *lang.Var

var A_arbace_a2g_zlib__init_A_const_17 any

var A_arbace_a2g_zlib__init_A_const_18 any

var A_arbace_a2g_zlib__init_A_const_19 *lang.Var

var A_arbace_a2g_zlib__init_A_const_20 any

var A_arbace_a2g_zlib__init_A_const_21 any

var A_arbace_a2g_zlib__init_A_const_22 *lang.Var

var A_arbace_a2g_zlib__init_A_const_23 any

var A_arbace_a2g_zlib__init_A_const_24 any

var A_arbace_a2g_zlib__init_A_const_25 *lang.Var

var A_arbace_a2g_zlib__init_A_const_26 any

var A_arbace_a2g_zlib__init_A_const_27 *lang.Var

var A_arbace_a2g_zlib__init_A_const_28 any

var A_arbace_a2g_zlib__init_A_const_29 any

var A_arbace_a2g_zlib__init_A_const_30 *lang.Var

var A_arbace_a2g_zlib__init_A_const_31 any

var A_arbace_a2g_zlib__init_A_const_32 any

var A_arbace_a2g_zlib__init_A_const_33 *lang.Var

var A_arbace_a2g_zlib__init_A_const_34 any

var A_arbace_a2g_zlib__init_A_const_35 *lang.Var

var A_arbace_a2g_zlib__init_A_const_36 any

var A_arbace_a2g_zlib__init_A_const_37 *lang.Var

var A_arbace_a2g_zlib__init_A_const_38 any

var A_arbace_a2g_zlib__init_A_const_39 *lang.Var

var A_arbace_a2g_zlib__init_A_const_40 any

var A_arbace_a2g_zlib__init_A_const_41 *lang.Var

var A_arbace_a2g_zlib__init_A_const_42 any

var A_arbace_a2g_zlib__init_A_const_43 *lang.Var

var A_arbace_a2g_zlib__init_A_const_44 any

var A_arbace_a2g_zlib__init_A_const_45 any

var A_arbace_a2g_zlib__init_A_const_46 *lang.Var

var A_arbace_a2g_zlib__init_A_const_47 any

var A_arbace_a2g_zlib__init_A_const_48 any

var A_arbace_a2g_zlib__init_A_const_49 *lang.Var

var A_arbace_a2g_zlib__init_A_const_50 any

var A_arbace_a2g_zlib__init_A_const_51 *lang.Var

var A_arbace_a2g_zlib__init_A_const_52 any

var A_arbace_a2g_zlib__init_A_const_53 *lang.Var

var A_arbace_a2g_zlib__init_A_const_54 any

var A_arbace_a2g_zlib__init_A_const_55 *lang.Var

var A_arbace_a2g_zlib__init_A_const_56 any

var A_arbace_a2g_zlib__init_A_init jrt.ClassInit

func A_arbace_a2g_zlib__init_A_Init() { if !A_arbace_a2g_zlib__init_A_init.Done() { A_arbace_a2g_zlib__init_A_init.Run(A_arbace_a2g_zlib__init_A_clinit) } }

func A_arbace_a2g_zlib__init_A_clinit() { A_arbace_a2g_zlib__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_82); A_arbace_a2g_zlib__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7))); A_arbace_a2g_zlib__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7)); A_arbace_a2g_zlib__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_zlib__init_A_const_4 = lang.RT_ClassForNameNonLoading_String__Class(Lit_83); A_arbace_a2g_zlib__init_A_const_5 = lang.RT_Var_String_String__Var(Lit_5, Lit_84); A_arbace_a2g_zlib__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_85).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_75).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_81).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_86, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_5, Lit_19); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_a2g_zlib__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_85).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_93)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(39).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_5, Lit_24); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_a2g_zlib__init_A_const_10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_85).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_94)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_96)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(46).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_5, Lit_25); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_a2g_zlib__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_85).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_98)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_99, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(83).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_5, Lit_37); A_arbace_a2g_zlib__init_A_const_14 = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(3).Ref(), jrt.Long_ValueOf_J__Long(4).Ref(), jrt.Long_ValueOf_J__Long(5).Ref(), jrt.Long_ValueOf_J__Long(6).Ref(), jrt.Long_ValueOf_J__Long(7).Ref(), jrt.Long_ValueOf_J__Long(8).Ref(), jrt.Long_ValueOf_J__Long(9).Ref(), jrt.Long_ValueOf_J__Long(10).Ref(), jrt.Long_ValueOf_J__Long(11).Ref(), jrt.Long_ValueOf_J__Long(13).Ref(), jrt.Long_ValueOf_J__Long(15).Ref(), jrt.Long_ValueOf_J__Long(17).Ref(), jrt.Long_ValueOf_J__Long(19).Ref(), jrt.Long_ValueOf_J__Long(23).Ref(), jrt.Long_ValueOf_J__Long(27).Ref(), jrt.Long_ValueOf_J__Long(31).Ref(), jrt.Long_ValueOf_J__Long(35).Ref(), jrt.Long_ValueOf_J__Long(43).Ref(), jrt.Long_ValueOf_J__Long(51).Ref(), jrt.Long_ValueOf_J__Long(59).Ref(), jrt.Long_ValueOf_J__Long(67).Ref(), jrt.Long_ValueOf_J__Long(83).Ref(), jrt.Long_ValueOf_J__Long(99).Ref(), jrt.Long_ValueOf_J__Long(115).Ref(), jrt.Long_ValueOf_J__Long(131).Ref(), jrt.Long_ValueOf_J__Long(163).Ref(), jrt.Long_ValueOf_J__Long(195).Ref(), jrt.Long_ValueOf_J__Long(227).Ref(), jrt.Long_ValueOf_J__Long(258).Ref())); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(); var tmp11 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_TRUE; var tmp13 any = tmp12.Ref(); A_arbace_a2g_zlib__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, Lit_100, tmp11, tmp13, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(107).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_5, Lit_44); A_arbace_a2g_zlib__init_A_const_17 = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(0).Ref(), jrt.Long_ValueOf_J__Long(0).Ref(), jrt.Long_ValueOf_J__Long(0).Ref(), jrt.Long_ValueOf_J__Long(0).Ref(), jrt.Long_ValueOf_J__Long(0).Ref(), jrt.Long_ValueOf_J__Long(0).Ref(), jrt.Long_ValueOf_J__Long(0).Ref(), jrt.Long_ValueOf_J__Long(0).Ref(), jrt.Long_ValueOf_J__Long(1).Ref(), jrt.Long_ValueOf_J__Long(1).Ref(), jrt.Long_ValueOf_J__Long(1).Ref(), jrt.Long_ValueOf_J__Long(1).Ref(), jrt.Long_ValueOf_J__Long(2).Ref(), jrt.Long_ValueOf_J__Long(2).Ref(), jrt.Long_ValueOf_J__Long(2).Ref(), jrt.Long_ValueOf_J__Long(2).Ref(), jrt.Long_ValueOf_J__Long(3).Ref(), jrt.Long_ValueOf_J__Long(3).Ref(), jrt.Long_ValueOf_J__Long(3).Ref(), jrt.Long_ValueOf_J__Long(3).Ref(), jrt.Long_ValueOf_J__Long(4).Ref(), jrt.Long_ValueOf_J__Long(4).Ref(), jrt.Long_ValueOf_J__Long(4).Ref(), jrt.Long_ValueOf_J__Long(4).Ref(), jrt.Long_ValueOf_J__Long(5).Ref(), jrt.Long_ValueOf_J__Long(5).Ref(), jrt.Long_ValueOf_J__Long(5).Ref(), jrt.Long_ValueOf_J__Long(5).Ref(), jrt.Long_ValueOf_J__Long(0).Ref())); var tmp14 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(); var tmp15 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp16 *jrt.Boolean; jrt.Boolean_Init(); tmp16 = jrt.Boolean_TRUE; var tmp17 any = tmp16.Ref(); A_arbace_a2g_zlib__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp14, Lit_100, tmp15, tmp17, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(108).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_5, Lit_38); A_arbace_a2g_zlib__init_A_const_20 = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref(), jrt.Long_ValueOf_J__Long(2).Ref(), jrt.Long_ValueOf_J__Long(3).Ref(), jrt.Long_ValueOf_J__Long(4).Ref(), jrt.Long_ValueOf_J__Long(5).Ref(), jrt.Long_ValueOf_J__Long(7).Ref(), jrt.Long_ValueOf_J__Long(9).Ref(), jrt.Long_ValueOf_J__Long(13).Ref(), jrt.Long_ValueOf_J__Long(17).Ref(), jrt.Long_ValueOf_J__Long(25).Ref(), jrt.Long_ValueOf_J__Long(33).Ref(), jrt.Long_ValueOf_J__Long(49).Ref(), jrt.Long_ValueOf_J__Long(65).Ref(), jrt.Long_ValueOf_J__Long(97).Ref(), jrt.Long_ValueOf_J__Long(129).Ref(), jrt.Long_ValueOf_J__Long(193).Ref(), jrt.Long_ValueOf_J__Long(257).Ref(), jrt.Long_ValueOf_J__Long(385).Ref(), jrt.Long_ValueOf_J__Long(513).Ref(), jrt.Long_ValueOf_J__Long(769).Ref(), jrt.Long_ValueOf_J__Long(1025).Ref(), jrt.Long_ValueOf_J__Long(1537).Ref(), jrt.Long_ValueOf_J__Long(2049).Ref(), jrt.Long_ValueOf_J__Long(3073).Ref(), jrt.Long_ValueOf_J__Long(4097).Ref(), jrt.Long_ValueOf_J__Long(6145).Ref(), jrt.Long_ValueOf_J__Long(8193).Ref(), jrt.Long_ValueOf_J__Long(12289).Ref(), jrt.Long_ValueOf_J__Long(16385).Ref(), jrt.Long_ValueOf_J__Long(24577).Ref())); var tmp18 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_a2g_zlib__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp18, Lit_100, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(109).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_5, Lit_43); A_arbace_a2g_zlib__init_A_const_23 = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(0).Ref(), jrt.Long_ValueOf_J__Long(0).Ref(), jrt.Long_ValueOf_J__Long(0).Ref(), jrt.Long_ValueOf_J__Long(0).Ref(), jrt.Long_ValueOf_J__Long(1).Ref(), jrt.Long_ValueOf_J__Long(1).Ref(), jrt.Long_ValueOf_J__Long(2).Ref(), jrt.Long_ValueOf_J__Long(2).Ref(), jrt.Long_ValueOf_J__Long(3).Ref(), jrt.Long_ValueOf_J__Long(3).Ref(), jrt.Long_ValueOf_J__Long(4).Ref(), jrt.Long_ValueOf_J__Long(4).Ref(), jrt.Long_ValueOf_J__Long(5).Ref(), jrt.Long_ValueOf_J__Long(5).Ref(), jrt.Long_ValueOf_J__Long(6).Ref(), jrt.Long_ValueOf_J__Long(6).Ref(), jrt.Long_ValueOf_J__Long(7).Ref(), jrt.Long_ValueOf_J__Long(7).Ref(), jrt.Long_ValueOf_J__Long(8).Ref(), jrt.Long_ValueOf_J__Long(8).Ref(), jrt.Long_ValueOf_J__Long(9).Ref(), jrt.Long_ValueOf_J__Long(9).Ref(), jrt.Long_ValueOf_J__Long(10).Ref(), jrt.Long_ValueOf_J__Long(10).Ref(), jrt.Long_ValueOf_J__Long(11).Ref(), jrt.Long_ValueOf_J__Long(11).Ref(), jrt.Long_ValueOf_J__Long(12).Ref(), jrt.Long_ValueOf_J__Long(12).Ref(), jrt.Long_ValueOf_J__Long(13).Ref(), jrt.Long_ValueOf_J__Long(13).Ref())); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(); var tmp23 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp24 *jrt.Boolean; jrt.Boolean_Init(); tmp24 = jrt.Boolean_TRUE; var tmp25 any = tmp24.Ref(); A_arbace_a2g_zlib__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, Lit_100, tmp23, tmp25, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(111).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_5, Lit_36); var tmp26 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp27 *jrt.Boolean; jrt.Boolean_Init(); tmp27 = jrt.Boolean_TRUE; var tmp28 any = tmp27.Ref(); A_arbace_a2g_zlib__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp26, tmp28, lang.RT_Keyword_String_String__Keyword(nil, Lit_85).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_101)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_102)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_103, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(113).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_5, Lit_104); A_arbace_a2g_zlib__init_A_const_28 = jrt.Long_ValueOf_J__Long(32768).Ref(); var tmp29 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_105).Ref(); var tmp30 *jrt.Boolean; jrt.Boolean_Init(); tmp30 = jrt.Boolean_TRUE; var tmp31 any = tmp30.Ref(); var tmp32 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp33 *jrt.Boolean; jrt.Boolean_Init(); tmp33 = jrt.Boolean_TRUE; var tmp34 any = tmp33.Ref(); A_arbace_a2g_zlib__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp29, tmp31, tmp32, tmp34, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(123).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_5, Lit_106); A_arbace_a2g_zlib__init_A_const_31 = jrt.Long_ValueOf_J__Long(64).Ref(); var tmp35 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_105).Ref(); var tmp36 *jrt.Boolean; jrt.Boolean_Init(); tmp36 = jrt.Boolean_TRUE; var tmp37 any = tmp36.Ref(); var tmp38 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp39 *jrt.Boolean; jrt.Boolean_Init(); tmp39 = jrt.Boolean_TRUE; var tmp40 any = tmp39.Ref(); A_arbace_a2g_zlib__init_A_const_32 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp35, tmp37, tmp38, tmp40, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(124).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_33 = lang.RT_Var_String_String__Var(Lit_5, Lit_107); var tmp41 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_105).Ref(); var tmp42 *jrt.Boolean; jrt.Boolean_Init(); tmp42 = jrt.Boolean_TRUE; var tmp43 any = tmp42.Ref(); var tmp44 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp45 *jrt.Boolean; jrt.Boolean_Init(); tmp45 = jrt.Boolean_TRUE; var tmp46 any = tmp45.Ref(); A_arbace_a2g_zlib__init_A_const_34 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp41, tmp43, tmp44, tmp46, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(125).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_35 = lang.RT_Var_String_String__Var(Lit_5, Lit_20); var tmp47 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp48 *jrt.Boolean; jrt.Boolean_Init(); tmp48 = jrt.Boolean_TRUE; var tmp49 any = tmp48.Ref(); A_arbace_a2g_zlib__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp47, tmp49, lang.RT_Keyword_String_String__Keyword(nil, Lit_85).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_108)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_110)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_111)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_112)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_113, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(127).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_37 = lang.RT_Var_String_String__Var(Lit_5, Lit_22); var tmp50 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp51 *jrt.Boolean; jrt.Boolean_Init(); tmp51 = jrt.Boolean_TRUE; var tmp52 any = tmp51.Ref(); A_arbace_a2g_zlib__init_A_const_38 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp50, tmp52, lang.RT_Keyword_String_String__Keyword(nil, Lit_85).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_108)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_114)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_116)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_110)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_117, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(132).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_39 = lang.RT_Var_String_String__Var(Lit_5, Lit_21); var tmp53 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp54 *jrt.Boolean; jrt.Boolean_Init(); tmp54 = jrt.Boolean_TRUE; var tmp55 any = tmp54.Ref(); A_arbace_a2g_zlib__init_A_const_40 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp53, tmp55, lang.RT_Keyword_String_String__Keyword(nil, Lit_85).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_108)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_116)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_110)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_118, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(146).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_5, Lit_45); var tmp56 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp57 *jrt.Boolean; jrt.Boolean_Init(); tmp57 = jrt.Boolean_TRUE; var tmp58 any = tmp57.Ref(); A_arbace_a2g_zlib__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp56, tmp58, lang.RT_Keyword_String_String__Keyword(nil, Lit_85).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_108)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_119, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(164).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_5, Lit_120); A_arbace_a2g_zlib__init_A_const_44 = jrt.Long_ValueOf_J__Long(16384).Ref(); var tmp59 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_105).Ref(); var tmp60 *jrt.Boolean; jrt.Boolean_Init(); tmp60 = jrt.Boolean_TRUE; var tmp61 any = tmp60.Ref(); var tmp62 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp63 *jrt.Boolean; jrt.Boolean_Init(); tmp63 = jrt.Boolean_TRUE; var tmp64 any = tmp63.Ref(); A_arbace_a2g_zlib__init_A_const_45 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp59, tmp61, tmp62, tmp64, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(201).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_46 = lang.RT_Var_String_String__Var(Lit_5, Lit_42); A_arbace_a2g_zlib__init_A_const_47 = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(16).Ref(), jrt.Long_ValueOf_J__Long(17).Ref(), jrt.Long_ValueOf_J__Long(18).Ref(), jrt.Long_ValueOf_J__Long(0).Ref(), jrt.Long_ValueOf_J__Long(8).Ref(), jrt.Long_ValueOf_J__Long(7).Ref(), jrt.Long_ValueOf_J__Long(9).Ref(), jrt.Long_ValueOf_J__Long(6).Ref(), jrt.Long_ValueOf_J__Long(10).Ref(), jrt.Long_ValueOf_J__Long(5).Ref(), jrt.Long_ValueOf_J__Long(11).Ref(), jrt.Long_ValueOf_J__Long(4).Ref(), jrt.Long_ValueOf_J__Long(12).Ref(), jrt.Long_ValueOf_J__Long(3).Ref(), jrt.Long_ValueOf_J__Long(13).Ref(), jrt.Long_ValueOf_J__Long(2).Ref(), jrt.Long_ValueOf_J__Long(14).Ref(), jrt.Long_ValueOf_J__Long(1).Ref(), jrt.Long_ValueOf_J__Long(15).Ref())); var tmp65 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp66 *jrt.Boolean; jrt.Boolean_Init(); tmp66 = jrt.Boolean_TRUE; var tmp67 any = tmp66.Ref(); A_arbace_a2g_zlib__init_A_const_48 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp65, tmp67, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(202).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_49 = lang.RT_Var_String_String__Var(Lit_5, Lit_27); var tmp68 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp69 *jrt.Boolean; jrt.Boolean_Init(); tmp69 = jrt.Boolean_TRUE; var tmp70 any = tmp69.Ref(); A_arbace_a2g_zlib__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp68, tmp70, lang.RT_Keyword_String_String__Keyword(nil, Lit_85).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_121).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_122, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(204).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_51 = lang.RT_Var_String_String__Var(Lit_5, Lit_46); var tmp71 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp72 *jrt.Boolean; jrt.Boolean_Init(); tmp72 = jrt.Boolean_TRUE; var tmp73 any = tmp72.Ref(); A_arbace_a2g_zlib__init_A_const_52 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp71, tmp73, lang.RT_Keyword_String_String__Keyword(nil, Lit_85).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_123)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_124).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_125)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_127).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_128).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_129, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(219).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_53 = lang.RT_Var_String_String__Var(Lit_5, Lit_47); var tmp74 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp75 *jrt.Boolean; jrt.Boolean_Init(); tmp75 = jrt.Boolean_TRUE; var tmp76 any = tmp75.Ref(); A_arbace_a2g_zlib__init_A_const_54 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp74, tmp76, lang.RT_Keyword_String_String__Keyword(nil, Lit_85).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_108)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(272).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)); A_arbace_a2g_zlib__init_A_const_55 = lang.RT_Var_String_String__Var(Lit_5, Lit_130); A_arbace_a2g_zlib__init_A_const_56 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_85).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_108)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_131, lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(279).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), Lit_90)) }

func A_arbace_a2g_zlib__init_A_New() *A_arbace_a2g_zlib__init_A { A_arbace_a2g_zlib__init_A_Init(); t := &A_arbace_a2g_zlib__init_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_zlib__init_A) Ctor() {}

func (t *A_arbace_a2g_zlib__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib__init_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib__init_A_class }

func (t *A_arbace_a2g_zlib__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib__init_A); return ok }

func A_arbace_a2g_zlib__init_A_Cast(x any) *A_arbace_a2g_zlib__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib__init_A_class)) }; return v }
