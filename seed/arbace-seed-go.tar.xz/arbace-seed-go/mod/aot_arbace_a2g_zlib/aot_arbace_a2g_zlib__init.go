//line aot_arbace_a2g_zlib__init.ae:1
package aot_arbace_a2g_zlib

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_zlib__init_A_Unit0__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(A_arbace_a2g_zlib__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_zlib__init_A_const_1) }
//line :1:1
func A_arbace_a2g_zlib__init_A_Unit1__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_a2g_zlib__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_2)) }
//line :1:1
func A_arbace_a2g_zlib__init_A_Unit2__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_a2g_zlib__init_A_Unit3__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_a2g_zlib__init_A_const_1)).Equals_O__Z(A_arbace_a2g_zlib__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_a2g_zlib_eval274000008_fn__274000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_a2g_zlib_eval274000008_fn__274000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_a2g_zlib_eval274000008_fn__274000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_a2g_zlib__init_A_Load__O() any { A_arbace_a2g_zlib__init_A_Init(); A_arbace_a2g_zlib__init_A_Unit0__O(); A_arbace_a2g_zlib__init_A_Unit1__O(); A_arbace_a2g_zlib__init_A_Unit2__O(); A_arbace_a2g_zlib__init_A_Unit3__O(); A_arbace_a2g_zlib__init_A_Unit4__O(); A_arbace_a2g_zlib__init_A_Unit5__O(); A_arbace_a2g_zlib__init_A_Unit6__O(); A_arbace_a2g_zlib__init_A_Unit7__O(); A_arbace_a2g_zlib__init_A_Unit8__O(); A_arbace_a2g_zlib__init_A_Unit9__O(); A_arbace_a2g_zlib__init_A_Unit10__O(); A_arbace_a2g_zlib__init_A_Unit11__O(); A_arbace_a2g_zlib__init_A_Unit12__O(); A_arbace_a2g_zlib__init_A_Unit13__O(); A_arbace_a2g_zlib__init_A_Unit14__O(); A_arbace_a2g_zlib__init_A_Unit15__O(); A_arbace_a2g_zlib__init_A_Unit16__O(); A_arbace_a2g_zlib__init_A_Unit17__O(); A_arbace_a2g_zlib__init_A_Unit18__O(); A_arbace_a2g_zlib__init_A_Unit19__O(); A_arbace_a2g_zlib__init_A_Unit20__O(); A_arbace_a2g_zlib__init_A_Unit21__O(); A_arbace_a2g_zlib__init_A_Unit22__O(); A_arbace_a2g_zlib__init_A_Unit23__O(); A_arbace_a2g_zlib__init_A_Unit24__O(); A_arbace_a2g_zlib__init_A_Unit25__O(); return nil }













func A_arbace_a2g_zlib__init_A_Unit4__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_23)); var tmp2 *lang.Var = A_arbace_a2g_zlib__init_A_const_5; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_6)); var tmp3 *lang.Var = A_arbace_a2g_zlib__init_A_const_5; var tmp4 any = A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_New(); var tmp5 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_fn_class = fncls__3d; tmp5 = fncls__3d } else { tmp5 = fncls__3 }; tmp3.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); return A_arbace_a2g_zlib__init_A_const_4 }



















func A_arbace_a2g_zlib__init_A_Unit5__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_7; var tmp2 any = A_arbace_a2g_zlib_reverse_bits_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_a2g_zlib_reverse_bits_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_25, false); A_arbace_a2g_zlib_reverse_bits_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_8)); return A_arbace_a2g_zlib__init_A_const_7 }






func A_arbace_a2g_zlib__init_A_Unit6__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(46, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_9; var tmp2 any = A_arbace_a2g_zlib_huffman_lengths_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_a2g_zlib_huffman_lengths_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); A_arbace_a2g_zlib_huffman_lengths_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_10)); return A_arbace_a2g_zlib__init_A_const_9 }




































func A_arbace_a2g_zlib__init_A_Unit7__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(83, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_11; var tmp2 any = A_arbace_a2g_zlib_canonical_codes_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_a2g_zlib_canonical_codes_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); A_arbace_a2g_zlib_canonical_codes_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_12)); return A_arbace_a2g_zlib__init_A_const_11 }























func A_arbace_a2g_zlib__init_A_Unit8__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(107, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_13; tmp1.BindRoot_O__V(lang.Numbers_Long_array_O__J1(A_arbace_a2g_zlib__init_A_const_14).Ref()); var tmp2 *lang.Var = A_arbace_a2g_zlib__init_A_const_13; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_15)); return A_arbace_a2g_zlib__init_A_const_13 }
func A_arbace_a2g_zlib__init_A_Unit9__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(108, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_16; tmp1.BindRoot_O__V(lang.Numbers_Long_array_O__J1(A_arbace_a2g_zlib__init_A_const_17).Ref()); var tmp2 *lang.Var = A_arbace_a2g_zlib__init_A_const_16; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_18)); return A_arbace_a2g_zlib__init_A_const_16 }
func A_arbace_a2g_zlib__init_A_Unit10__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(109, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_19; tmp1.BindRoot_O__V(lang.Numbers_Long_array_O__J1(A_arbace_a2g_zlib__init_A_const_20).Ref()); var tmp2 *lang.Var = A_arbace_a2g_zlib__init_A_const_19; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_21)); return A_arbace_a2g_zlib__init_A_const_19 }

func A_arbace_a2g_zlib__init_A_Unit11__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(111, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_22; tmp1.BindRoot_O__V(lang.Numbers_Long_array_O__J1(A_arbace_a2g_zlib__init_A_const_23).Ref()); var tmp2 *lang.Var = A_arbace_a2g_zlib__init_A_const_22; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_24)); return A_arbace_a2g_zlib__init_A_const_22 }

func A_arbace_a2g_zlib__init_A_Unit12__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(113, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_25; var tmp2 any = A_arbace_a2g_zlib_code_of_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_a2g_zlib_code_of_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); A_arbace_a2g_zlib_code_of_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_26)); return A_arbace_a2g_zlib__init_A_const_25 }









func A_arbace_a2g_zlib__init_A_Unit13__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(123, 1); A_arbace_a2g_zlib__init_A_const_27.BindRoot_O__V(A_arbace_a2g_zlib__init_A_const_28); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_27; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_29)); return A_arbace_a2g_zlib__init_A_const_27 }
func A_arbace_a2g_zlib__init_A_Unit14__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(124, 1); A_arbace_a2g_zlib__init_A_const_30.BindRoot_O__V(A_arbace_a2g_zlib__init_A_const_31); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_32)); return A_arbace_a2g_zlib__init_A_const_30 }
func A_arbace_a2g_zlib__init_A_Unit15__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(125, 1); A_arbace_a2g_zlib__init_A_const_33.BindRoot_O__V(A_arbace_a2g_zlib__init_A_const_31); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_33; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_34)); return A_arbace_a2g_zlib__init_A_const_33 }

func A_arbace_a2g_zlib__init_A_Unit16__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(127, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_35; var tmp2 any = A_arbace_a2g_zlib_match_length_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_a2g_zlib_match_length_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_a2g_zlib_match_length_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_36)); return A_arbace_a2g_zlib__init_A_const_35 }




func A_arbace_a2g_zlib__init_A_Unit17__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(132, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_37; var tmp2 any = A_arbace_a2g_zlib_insert_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_a2g_zlib_insert_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_a2g_zlib_insert_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_38)); return A_arbace_a2g_zlib__init_A_const_37 }













func A_arbace_a2g_zlib__init_A_Unit18__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(146, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_39; var tmp2 any = A_arbace_a2g_zlib_longest_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_a2g_zlib_longest_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); A_arbace_a2g_zlib_longest_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_40)); return A_arbace_a2g_zlib__init_A_const_39 }

















func A_arbace_a2g_zlib__init_A_Unit19__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(164, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_41; var tmp2 any = A_arbace_a2g_zlib_lz77_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_a2g_zlib_lz77_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); A_arbace_a2g_zlib_lz77_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_42)); return A_arbace_a2g_zlib__init_A_const_41 }




































func A_arbace_a2g_zlib__init_A_Unit20__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(201, 1); A_arbace_a2g_zlib__init_A_const_43.BindRoot_O__V(A_arbace_a2g_zlib__init_A_const_44); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_45)); return A_arbace_a2g_zlib__init_A_const_43 }
func A_arbace_a2g_zlib__init_A_Unit21__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); A_arbace_a2g_zlib__init_A_const_46.BindRoot_O__V(A_arbace_a2g_zlib__init_A_const_47); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_46; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_48)); return A_arbace_a2g_zlib__init_A_const_46 }

func A_arbace_a2g_zlib__init_A_Unit22__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(204, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_49; var tmp2 any = A_arbace_a2g_zlib_rle_lengths_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_a2g_zlib_rle_lengths_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_a2g_zlib_rle_lengths_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_50)); return A_arbace_a2g_zlib__init_A_const_49 }














func A_arbace_a2g_zlib__init_A_Unit23__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(219, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_51; var tmp2 any = A_arbace_a2g_zlib_write_block_BANG__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_a2g_zlib_write_block_BANG__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); A_arbace_a2g_zlib_write_block_BANG__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_52)); return A_arbace_a2g_zlib__init_A_const_51 }




















































func A_arbace_a2g_zlib__init_A_Unit24__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(272, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_53; var tmp2 any = A_arbace_a2g_zlib_adler32_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_a2g_zlib_adler32_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_a2g_zlib_adler32_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_54)); return A_arbace_a2g_zlib__init_A_const_53 }






func A_arbace_a2g_zlib__init_A_Unit25__O() any { A_arbace_a2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V(279, 1); var tmp1 *lang.Var = A_arbace_a2g_zlib__init_A_const_55; var tmp2 any = A_arbace_a2g_zlib_deflate_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_a2g_zlib_deflate_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_a2g_zlib_deflate_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_zlib__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_zlib__init_A_const_56)); return A_arbace_a2g_zlib__init_A_const_55 }



type A_arbace_a2g_zlib__init_A struct{ jrt.Object }

var A_arbace_a2g_zlib__init_A_const_pool *jrt.RefArray

var A_arbace_a2g_zlib__init_A_const_0 *lang.Var

var A_arbace_a2g_zlib__init_A_const_1 any

var A_arbace_a2g_zlib__init_A_const_2 any

var A_arbace_a2g_zlib__init_A_const_3 any

var A_arbace_a2g_zlib__init_A_const_4 *jrt.Class

var A_arbace_a2g_zlib__init_A_const_5 *lang.Var

var A_arbace_a2g_zlib__init_A_const_6 any

var A_arbace_a2g_zlib__init_A_const_7 *lang.Var

var A_arbace_a2g_zlib__init_A_const_8 any

var A_arbace_a2g_zlib__init_A_const_9 *lang.Var

var A_arbace_a2g_zlib__init_A_const_10 any

var A_arbace_a2g_zlib__init_A_const_11 *lang.Var

var A_arbace_a2g_zlib__init_A_const_12 any

var A_arbace_a2g_zlib__init_A_const_13 *lang.Var

var A_arbace_a2g_zlib__init_A_const_14 any

var A_arbace_a2g_zlib__init_A_const_15 any

var A_arbace_a2g_zlib__init_A_const_16 *lang.Var

var A_arbace_a2g_zlib__init_A_const_17 any

var A_arbace_a2g_zlib__init_A_const_18 any

var A_arbace_a2g_zlib__init_A_const_19 *lang.Var

var A_arbace_a2g_zlib__init_A_const_20 any

var A_arbace_a2g_zlib__init_A_const_21 any

var A_arbace_a2g_zlib__init_A_const_22 *lang.Var

var A_arbace_a2g_zlib__init_A_const_23 any

var A_arbace_a2g_zlib__init_A_const_24 any

var A_arbace_a2g_zlib__init_A_const_25 *lang.Var

var A_arbace_a2g_zlib__init_A_const_26 any

var A_arbace_a2g_zlib__init_A_const_27 *lang.Var

var A_arbace_a2g_zlib__init_A_const_28 any

var A_arbace_a2g_zlib__init_A_const_29 any

var A_arbace_a2g_zlib__init_A_const_30 *lang.Var

var A_arbace_a2g_zlib__init_A_const_31 any

var A_arbace_a2g_zlib__init_A_const_32 any

var A_arbace_a2g_zlib__init_A_const_33 *lang.Var

var A_arbace_a2g_zlib__init_A_const_34 any

var A_arbace_a2g_zlib__init_A_const_35 *lang.Var

var A_arbace_a2g_zlib__init_A_const_36 any

var A_arbace_a2g_zlib__init_A_const_37 *lang.Var

var A_arbace_a2g_zlib__init_A_const_38 any

var A_arbace_a2g_zlib__init_A_const_39 *lang.Var

var A_arbace_a2g_zlib__init_A_const_40 any

var A_arbace_a2g_zlib__init_A_const_41 *lang.Var

var A_arbace_a2g_zlib__init_A_const_42 any

var A_arbace_a2g_zlib__init_A_const_43 *lang.Var

var A_arbace_a2g_zlib__init_A_const_44 any

var A_arbace_a2g_zlib__init_A_const_45 any

var A_arbace_a2g_zlib__init_A_const_46 *lang.Var

var A_arbace_a2g_zlib__init_A_const_47 any

var A_arbace_a2g_zlib__init_A_const_48 any

var A_arbace_a2g_zlib__init_A_const_49 *lang.Var

var A_arbace_a2g_zlib__init_A_const_50 any

var A_arbace_a2g_zlib__init_A_const_51 *lang.Var

var A_arbace_a2g_zlib__init_A_const_52 any

var A_arbace_a2g_zlib__init_A_const_53 *lang.Var

var A_arbace_a2g_zlib__init_A_const_54 any

var A_arbace_a2g_zlib__init_A_const_55 *lang.Var

var A_arbace_a2g_zlib__init_A_const_56 any

var A_arbace_a2g_zlib__init_A_init jrt.ClassInit

func A_arbace_a2g_zlib__init_A_Init() { if !A_arbace_a2g_zlib__init_A_init.Done() { A_arbace_a2g_zlib__init_A_init.Run(A_arbace_a2g_zlib__init_A_clinit) } }

func A_arbace_a2g_zlib__init_A_clinit() { A_arbace_a2g_zlib__init_A_clinit_p0(); A_arbace_a2g_zlib__init_A_clinit_p1(); A_arbace_a2g_zlib__init_A_clinit_p2(); A_arbace_a2g_zlib__init_A_clinit_p3(); A_arbace_a2g_zlib__init_A_clinit_p4() }

func A_arbace_a2g_zlib__init_A_clinit_p0() { A_arbace_a2g_zlib__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_20, 78); A_arbace_a2g_zlib__init_A_const_0 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[21]); A_arbace_a2g_zlib__init_A_const_1 = A_arbace_a2g_zlib__init_A_const_pool.A[22]; A_arbace_a2g_zlib__init_A_const_2 = A_arbace_a2g_zlib__init_A_const_pool.A[23]; A_arbace_a2g_zlib__init_A_const_3 = A_arbace_a2g_zlib__init_A_const_pool.A[24]; A_arbace_a2g_zlib__init_A_const_4 = jrt.Class_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[25]); A_arbace_a2g_zlib__init_A_const_5 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[26]); A_arbace_a2g_zlib__init_A_const_6 = A_arbace_a2g_zlib__init_A_const_pool.A[27]; A_arbace_a2g_zlib__init_A_const_7 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[28]); A_arbace_a2g_zlib__init_A_const_8 = A_arbace_a2g_zlib__init_A_const_pool.A[29]; A_arbace_a2g_zlib__init_A_const_9 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[30]); A_arbace_a2g_zlib__init_A_const_10 = A_arbace_a2g_zlib__init_A_const_pool.A[31]; A_arbace_a2g_zlib__init_A_const_11 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[32]); A_arbace_a2g_zlib__init_A_const_12 = A_arbace_a2g_zlib__init_A_const_pool.A[33] }

func A_arbace_a2g_zlib__init_A_clinit_p1() { A_arbace_a2g_zlib__init_A_const_13 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[34]); A_arbace_a2g_zlib__init_A_const_14 = A_arbace_a2g_zlib__init_A_const_pool.A[35]; A_arbace_a2g_zlib__init_A_const_15 = A_arbace_a2g_zlib__init_A_const_pool.A[36]; A_arbace_a2g_zlib__init_A_const_16 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[37]); A_arbace_a2g_zlib__init_A_const_17 = A_arbace_a2g_zlib__init_A_const_pool.A[38]; A_arbace_a2g_zlib__init_A_const_18 = A_arbace_a2g_zlib__init_A_const_pool.A[39]; A_arbace_a2g_zlib__init_A_const_19 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[40]); A_arbace_a2g_zlib__init_A_const_20 = A_arbace_a2g_zlib__init_A_const_pool.A[41]; A_arbace_a2g_zlib__init_A_const_21 = A_arbace_a2g_zlib__init_A_const_pool.A[42]; A_arbace_a2g_zlib__init_A_const_22 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[43]); A_arbace_a2g_zlib__init_A_const_23 = A_arbace_a2g_zlib__init_A_const_pool.A[44]; A_arbace_a2g_zlib__init_A_const_24 = A_arbace_a2g_zlib__init_A_const_pool.A[45]; A_arbace_a2g_zlib__init_A_const_25 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[46]); A_arbace_a2g_zlib__init_A_const_26 = A_arbace_a2g_zlib__init_A_const_pool.A[47] }

func A_arbace_a2g_zlib__init_A_clinit_p2() { A_arbace_a2g_zlib__init_A_const_27 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[48]); A_arbace_a2g_zlib__init_A_const_28 = A_arbace_a2g_zlib__init_A_const_pool.A[49]; A_arbace_a2g_zlib__init_A_const_29 = A_arbace_a2g_zlib__init_A_const_pool.A[50]; A_arbace_a2g_zlib__init_A_const_30 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[51]); A_arbace_a2g_zlib__init_A_const_31 = A_arbace_a2g_zlib__init_A_const_pool.A[52]; A_arbace_a2g_zlib__init_A_const_32 = A_arbace_a2g_zlib__init_A_const_pool.A[53]; A_arbace_a2g_zlib__init_A_const_33 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[54]); A_arbace_a2g_zlib__init_A_const_34 = A_arbace_a2g_zlib__init_A_const_pool.A[55]; A_arbace_a2g_zlib__init_A_const_35 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[56]); A_arbace_a2g_zlib__init_A_const_36 = A_arbace_a2g_zlib__init_A_const_pool.A[57]; A_arbace_a2g_zlib__init_A_const_37 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[58]); A_arbace_a2g_zlib__init_A_const_38 = A_arbace_a2g_zlib__init_A_const_pool.A[59]; A_arbace_a2g_zlib__init_A_const_39 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[60]); A_arbace_a2g_zlib__init_A_const_40 = A_arbace_a2g_zlib__init_A_const_pool.A[61] }

func A_arbace_a2g_zlib__init_A_clinit_p3() { A_arbace_a2g_zlib__init_A_const_41 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[62]); A_arbace_a2g_zlib__init_A_const_42 = A_arbace_a2g_zlib__init_A_const_pool.A[63]; A_arbace_a2g_zlib__init_A_const_43 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[64]); A_arbace_a2g_zlib__init_A_const_44 = A_arbace_a2g_zlib__init_A_const_pool.A[65]; A_arbace_a2g_zlib__init_A_const_45 = A_arbace_a2g_zlib__init_A_const_pool.A[66]; A_arbace_a2g_zlib__init_A_const_46 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[67]); A_arbace_a2g_zlib__init_A_const_47 = A_arbace_a2g_zlib__init_A_const_pool.A[68]; A_arbace_a2g_zlib__init_A_const_48 = A_arbace_a2g_zlib__init_A_const_pool.A[69]; A_arbace_a2g_zlib__init_A_const_49 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[70]); A_arbace_a2g_zlib__init_A_const_50 = A_arbace_a2g_zlib__init_A_const_pool.A[71]; A_arbace_a2g_zlib__init_A_const_51 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[72]); A_arbace_a2g_zlib__init_A_const_52 = A_arbace_a2g_zlib__init_A_const_pool.A[73]; A_arbace_a2g_zlib__init_A_const_53 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[74]); A_arbace_a2g_zlib__init_A_const_54 = A_arbace_a2g_zlib__init_A_const_pool.A[75] }

func A_arbace_a2g_zlib__init_A_clinit_p4() { A_arbace_a2g_zlib__init_A_const_55 = lang.Var_Cast(A_arbace_a2g_zlib__init_A_const_pool.A[76]); A_arbace_a2g_zlib__init_A_const_56 = A_arbace_a2g_zlib__init_A_const_pool.A[77] }

func A_arbace_a2g_zlib__init_A_New() *A_arbace_a2g_zlib__init_A { A_arbace_a2g_zlib__init_A_Init(); t := &A_arbace_a2g_zlib__init_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_zlib__init_A) Ctor() {}

func (t *A_arbace_a2g_zlib__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_zlib__init_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_zlib__init_A_class }

func (t *A_arbace_a2g_zlib__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_zlib__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_zlib__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_zlib__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_zlib__init_A); return ok }

func A_arbace_a2g_zlib__init_A_Cast(x any) *A_arbace_a2g_zlib__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_zlib__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_zlib__init_A_class)) }; return v }
