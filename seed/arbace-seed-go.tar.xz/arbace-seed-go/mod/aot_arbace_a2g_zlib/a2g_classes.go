//line a2g_classes.ae:1
package aot_arbace_a2g_zlib

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_a2g_zlib_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_A_New()}; return nil }

var A_arbace_a2g_zlib_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_zlib_A_new}

var A_arbace_a2g_zlib_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_A"})

func init() { i := A_arbace_a2g_zlib_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_A_InstanceOf; i.Init = A_arbace_a2g_zlib_A_Init; i.Table = A_arbace_a2g_zlib_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_A_class, reflect.TypeFor[A_arbace_a2g_zlib_A]()) }

func A_arbace_a2g_zlib_adler32_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_adler32_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_zlib_adler32_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_adler32_A_New()}; return nil }

func A_arbace_a2g_zlib_adler32_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_adler32_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_adler32_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_adler32_A_invoke, New: A_arbace_a2g_zlib_adler32_A_new, Get: A_arbace_a2g_zlib_adler32_A_get}

var A_arbace_a2g_zlib_adler32_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$adler32", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_zlib_A_class, Simple: "adler32", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_adler32_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_adler32_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_adler32_A_InstanceOf; i.Init = A_arbace_a2g_zlib_adler32_A_Init; i.Table = A_arbace_a2g_zlib_adler32_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_adler32_A_class, reflect.TypeFor[A_arbace_a2g_zlib_adler32_A]()) }

func A_arbace_a2g_zlib_canonical_codes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_canonical_codes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_zlib_canonical_codes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_canonical_codes_A_New()}; return nil }

func A_arbace_a2g_zlib_canonical_codes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_canonical_codes_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_canonical_codes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_canonical_codes_A_invoke, New: A_arbace_a2g_zlib_canonical_codes_A_new, Get: A_arbace_a2g_zlib_canonical_codes_A_get}

var A_arbace_a2g_zlib_canonical_codes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$canonical_codes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_zlib_A_class, Simple: "canonical_codes", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_canonical_codes_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_canonical_codes_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_canonical_codes_A_InstanceOf; i.Init = A_arbace_a2g_zlib_canonical_codes_A_Init; i.Table = A_arbace_a2g_zlib_canonical_codes_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_canonical_codes_A_class, reflect.TypeFor[A_arbace_a2g_zlib_canonical_codes_A]()) }

func A_arbace_a2g_zlib_code_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_code_of_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_zlib_code_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_code_of_A_New()}; return nil }

func A_arbace_a2g_zlib_code_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_code_of_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_code_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_code_of_A_invoke, New: A_arbace_a2g_zlib_code_of_A_new, Get: A_arbace_a2g_zlib_code_of_A_get}

var A_arbace_a2g_zlib_code_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$code_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_zlib_A_class, Simple: "code_of", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_code_of_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_code_of_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_code_of_A_InstanceOf; i.Init = A_arbace_a2g_zlib_code_of_A_Init; i.Table = A_arbace_a2g_zlib_code_of_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_code_of_A_class, reflect.TypeFor[A_arbace_a2g_zlib_code_of_A]()) }

func A_arbace_a2g_zlib_deflate_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_deflate_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_zlib_deflate_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_deflate_A_New()}; return nil }

func A_arbace_a2g_zlib_deflate_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_deflate_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_deflate_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_deflate_A_invoke, New: A_arbace_a2g_zlib_deflate_A_new, Get: A_arbace_a2g_zlib_deflate_A_get}

var A_arbace_a2g_zlib_deflate_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$deflate", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_zlib_A_class, Simple: "deflate", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_deflate_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_deflate_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_deflate_A_InstanceOf; i.Init = A_arbace_a2g_zlib_deflate_A_Init; i.Table = A_arbace_a2g_zlib_deflate_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_deflate_A_class, reflect.TypeFor[A_arbace_a2g_zlib_deflate_A]()) }

func A_arbace_a2g_zlib_eval274000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_eval274000004_A_New()}; return nil }

var A_arbace_a2g_zlib_eval274000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_zlib_eval274000004_A_new}

var A_arbace_a2g_zlib_eval274000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$eval274000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_zlib_A_class, Simple: "eval274000004", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_eval274000004_A"})

func init() { i := A_arbace_a2g_zlib_eval274000004_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_eval274000004_A_InstanceOf; i.Table = A_arbace_a2g_zlib_eval274000004_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_eval274000004_A_class, reflect.TypeFor[A_arbace_a2g_zlib_eval274000004_A]()) }

func A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_New()}; return nil }

func A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_invoke, New: A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_new, Get: A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_get}

var A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$eval274000004$loading__1927001464__auto____274000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_zlib_eval274000004_A_class, Simple: "loading__1927001464__auto____274000005", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_InstanceOf; i.Init = A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_Init; i.Table = A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A_class, reflect.TypeFor[A_arbace_a2g_zlib_eval274000004_loading__1927001464__auto____274000005_A]()) }

func A_arbace_a2g_zlib_eval274000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_eval274000008_A_New()}; return nil }

var A_arbace_a2g_zlib_eval274000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_zlib_eval274000008_A_new}

var A_arbace_a2g_zlib_eval274000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$eval274000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_zlib_A_class, Simple: "eval274000008", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_eval274000008_A"})

func init() { i := A_arbace_a2g_zlib_eval274000008_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_eval274000008_A_InstanceOf; i.Table = A_arbace_a2g_zlib_eval274000008_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_eval274000008_A_class, reflect.TypeFor[A_arbace_a2g_zlib_eval274000008_A]()) }

func A_arbace_a2g_zlib_eval274000008_fn__274000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_eval274000008_fn__274000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_zlib_eval274000008_fn__274000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_eval274000008_fn__274000009_A_New()}; return nil }

func A_arbace_a2g_zlib_eval274000008_fn__274000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_eval274000008_fn__274000009_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_eval274000008_fn__274000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_eval274000008_fn__274000009_A_invoke, New: A_arbace_a2g_zlib_eval274000008_fn__274000009_A_new, Get: A_arbace_a2g_zlib_eval274000008_fn__274000009_A_get}

var A_arbace_a2g_zlib_eval274000008_fn__274000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$eval274000008$fn__274000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_zlib_eval274000008_A_class, Simple: "fn__274000009", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_eval274000008_fn__274000009_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_eval274000008_fn__274000009_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_eval274000008_fn__274000009_A_InstanceOf; i.Init = A_arbace_a2g_zlib_eval274000008_fn__274000009_A_Init; i.Table = A_arbace_a2g_zlib_eval274000008_fn__274000009_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_eval274000008_fn__274000009_A_class, reflect.TypeFor[A_arbace_a2g_zlib_eval274000008_fn__274000009_A]()) }

func A_arbace_a2g_zlib_eval274000012_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_eval274000012_A_New()}; return nil }

var A_arbace_a2g_zlib_eval274000012_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_zlib_eval274000012_A_new}

var A_arbace_a2g_zlib_eval274000012_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$eval274000012", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_zlib_A_class, Simple: "eval274000012", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_eval274000012_A"})

func init() { i := A_arbace_a2g_zlib_eval274000012_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_eval274000012_A_InstanceOf; i.Table = A_arbace_a2g_zlib_eval274000012_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_eval274000012_A_class, reflect.TypeFor[A_arbace_a2g_zlib_eval274000012_A]()) }

func A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_New()}; return nil }

func A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_invoke, New: A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_new, Get: A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_get}

var A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$eval274000012$__GT_Bits__274000014", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_zlib_eval274000012_A_class, Simple: "__GT_Bits__274000014", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_InstanceOf; i.Init = A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_Init; i.Table = A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A_class, reflect.TypeFor[A_arbace_a2g_zlib_eval274000012___GT_Bits__274000014_A]()) }

func A_arbace_a2g_zlib_huffman_lengths_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_huffman_lengths_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_zlib_huffman_lengths_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_huffman_lengths_A_New()}; return nil }

func A_arbace_a2g_zlib_huffman_lengths_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_huffman_lengths_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_huffman_lengths_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_huffman_lengths_A_invoke, New: A_arbace_a2g_zlib_huffman_lengths_A_new, Get: A_arbace_a2g_zlib_huffman_lengths_A_get}

var A_arbace_a2g_zlib_huffman_lengths_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$huffman_lengths", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_zlib_A_class, Simple: "huffman_lengths", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_huffman_lengths_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_huffman_lengths_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_huffman_lengths_A_InstanceOf; i.Init = A_arbace_a2g_zlib_huffman_lengths_A_Init; i.Table = A_arbace_a2g_zlib_huffman_lengths_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_huffman_lengths_A_class, reflect.TypeFor[A_arbace_a2g_zlib_huffman_lengths_A]()) }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_New_O(args[0])}; return nil }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_invoke, New: A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_new, Get: A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_get}

var A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$huffman_lengths$fn__274000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_zlib_huffman_lengths_A_class, Simple: "fn__274000019", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_InstanceOf; i.Init = A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_Init; i.Table = A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A_class, reflect.TypeFor[A_arbace_a2g_zlib_huffman_lengths_fn__274000019_A]()) }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_New_O(args[0])}; return nil }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_invoke, New: A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_new, Get: A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_get}

var A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$huffman_lengths$fn__274000021", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_zlib_huffman_lengths_A_class, Simple: "fn__274000021", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_InstanceOf; i.Init = A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_Init; i.Table = A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A_class, reflect.TypeFor[A_arbace_a2g_zlib_huffman_lengths_fn__274000021_A]()) }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_invoke, New: A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_new, Get: A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_get}

var A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$huffman_lengths$fn__274000023", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_zlib_huffman_lengths_A_class, Simple: "fn__274000023", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_InstanceOf; i.Init = A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_Init; i.Table = A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A_class, reflect.TypeFor[A_arbace_a2g_zlib_huffman_lengths_fn__274000023_A]()) }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_New_O_O_J(args[0], args[1], args[2].(int64))}; return nil }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;J)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_invoke, New: A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_new, Get: A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_get}

var A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$huffman_lengths$fn__274000025", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_zlib_huffman_lengths_A_class, Simple: "fn__274000025", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_InstanceOf; i.Init = A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_Init; i.Table = A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_class, reflect.TypeFor[A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A]()) }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_New_O_O_J(args[0], args[1], args[2].(int64))}; return nil }

func A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;J)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_invoke, New: A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_new, Get: A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_get}

var A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$huffman_lengths$fn__274000025$fn__274000026", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_zlib_huffman_lengths_fn__274000025_A_class, Simple: "fn__274000026", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_InstanceOf; i.Init = A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_Init; i.Table = A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A_class, reflect.TypeFor[A_arbace_a2g_zlib_huffman_lengths_fn__274000025_fn__274000026_A]()) }

func A_arbace_a2g_zlib_insert_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_insert_BANG__A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_zlib_insert_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_insert_BANG__A_New()}; return nil }

func A_arbace_a2g_zlib_insert_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_insert_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_zlib_insert_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_insert_BANG__A_invoke, New: A_arbace_a2g_zlib_insert_BANG__A_new, Get: A_arbace_a2g_zlib_insert_BANG__A_get}

var A_arbace_a2g_zlib_insert_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$insert_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_a2g_zlib_A_class, Simple: "insert_BANG_", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_insert_BANG__A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_insert_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_insert_BANG__A_InstanceOf; i.Init = A_arbace_a2g_zlib_insert_BANG__A_Init; i.Table = A_arbace_a2g_zlib_insert_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_insert_BANG__A_class, reflect.TypeFor[A_arbace_a2g_zlib_insert_BANG__A]()) }

func A_arbace_a2g_zlib_longest_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_longest_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_zlib_longest_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_longest_A_New()}; return nil }

func A_arbace_a2g_zlib_longest_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_longest_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_longest_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_longest_A_invoke, New: A_arbace_a2g_zlib_longest_A_new, Get: A_arbace_a2g_zlib_longest_A_get}

var A_arbace_a2g_zlib_longest_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$longest", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_zlib_A_class, Simple: "longest", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_longest_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_longest_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_longest_A_InstanceOf; i.Init = A_arbace_a2g_zlib_longest_A_Init; i.Table = A_arbace_a2g_zlib_longest_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_longest_A_class, reflect.TypeFor[A_arbace_a2g_zlib_longest_A]()) }

func A_arbace_a2g_zlib_lz77_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_lz77_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_zlib_lz77_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_lz77_A_New()}; return nil }

func A_arbace_a2g_zlib_lz77_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_lz77_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_lz77_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_lz77_A_invoke, New: A_arbace_a2g_zlib_lz77_A_new, Get: A_arbace_a2g_zlib_lz77_A_get}

var A_arbace_a2g_zlib_lz77_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$lz77", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_zlib_A_class, Simple: "lz77", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_lz77_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_lz77_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_lz77_A_InstanceOf; i.Init = A_arbace_a2g_zlib_lz77_A_Init; i.Table = A_arbace_a2g_zlib_lz77_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_lz77_A_class, reflect.TypeFor[A_arbace_a2g_zlib_lz77_A]()) }

func A_arbace_a2g_zlib_match_length_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_match_length_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_zlib_match_length_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_match_length_A_New()}; return nil }

func A_arbace_a2g_zlib_match_length_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_match_length_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_match_length_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_match_length_A_invoke, New: A_arbace_a2g_zlib_match_length_A_new, Get: A_arbace_a2g_zlib_match_length_A_get}

var A_arbace_a2g_zlib_match_length_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$match_length", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_a2g_zlib_A_class, Simple: "match_length", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_match_length_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_match_length_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_match_length_A_InstanceOf; i.Init = A_arbace_a2g_zlib_match_length_A_Init; i.Table = A_arbace_a2g_zlib_match_length_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_match_length_A_class, reflect.TypeFor[A_arbace_a2g_zlib_match_length_A]()) }

func A_arbace_a2g_zlib_reverse_bits_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_reverse_bits_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_zlib_reverse_bits_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_reverse_bits_A_New()}; return nil }

func A_arbace_a2g_zlib_reverse_bits_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_reverse_bits_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_reverse_bits_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_reverse_bits_A_invoke, New: A_arbace_a2g_zlib_reverse_bits_A_new, Get: A_arbace_a2g_zlib_reverse_bits_A_get}

var A_arbace_a2g_zlib_reverse_bits_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$reverse_bits", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_zlib_A_class, Simple: "reverse_bits", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_reverse_bits_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_reverse_bits_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_reverse_bits_A_InstanceOf; i.Init = A_arbace_a2g_zlib_reverse_bits_A_Init; i.Table = A_arbace_a2g_zlib_reverse_bits_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_reverse_bits_A_class, reflect.TypeFor[A_arbace_a2g_zlib_reverse_bits_A]()) }

func A_arbace_a2g_zlib_rle_lengths_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_rle_lengths_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_zlib_rle_lengths_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_rle_lengths_A_New()}; return nil }

func A_arbace_a2g_zlib_rle_lengths_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_rle_lengths_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_rle_lengths_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_rle_lengths_A_invoke, New: A_arbace_a2g_zlib_rle_lengths_A_new, Get: A_arbace_a2g_zlib_rle_lengths_A_get}

var A_arbace_a2g_zlib_rle_lengths_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$rle_lengths", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_zlib_A_class, Simple: "rle_lengths", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_rle_lengths_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_rle_lengths_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_rle_lengths_A_InstanceOf; i.Init = A_arbace_a2g_zlib_rle_lengths_A_Init; i.Table = A_arbace_a2g_zlib_rle_lengths_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_rle_lengths_A_class, reflect.TypeFor[A_arbace_a2g_zlib_rle_lengths_A]()) }

func A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_rle_lengths_fn__274000038_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_New_O_I_J_O(args[0], args[1].(int32), args[2].(int64), args[3])}; return nil }

func A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;IJLjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_invoke, New: A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_new, Get: A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_get}

var A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$rle_lengths$fn__274000038", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_zlib_rle_lengths_A_class, Simple: "fn__274000038", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_rle_lengths_fn__274000038_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_InstanceOf; i.Init = A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_Init; i.Table = A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_rle_lengths_fn__274000038_A_class, reflect.TypeFor[A_arbace_a2g_zlib_rle_lengths_fn__274000038_A]()) }

func A_arbace_a2g_zlib_write_block_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_write_block_BANG__A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_a2g_zlib_write_block_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_write_block_BANG__A_New()}; return nil }

func A_arbace_a2g_zlib_write_block_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_write_block_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_zlib_write_block_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_write_block_BANG__A_invoke, New: A_arbace_a2g_zlib_write_block_BANG__A_new, Get: A_arbace_a2g_zlib_write_block_BANG__A_get}

var A_arbace_a2g_zlib_write_block_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$write_block_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_a2g_zlib_A_class, Simple: "write_block_BANG_", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_write_block_BANG__A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_write_block_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_write_block_BANG__A_InstanceOf; i.Init = A_arbace_a2g_zlib_write_block_BANG__A_Init; i.Table = A_arbace_a2g_zlib_write_block_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_write_block_BANG__A_class, reflect.TypeFor[A_arbace_a2g_zlib_write_block_BANG__A]()) }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_New_O(args[0])}; return nil }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_invoke, New: A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_new, Get: A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_get}

var A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$write_block_BANG_$fn__274000045", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_zlib_write_block_BANG__A_class, Simple: "fn__274000045", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_InstanceOf; i.Init = A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_Init; i.Table = A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A_class, reflect.TypeFor[A_arbace_a2g_zlib_write_block_BANG__fn__274000045_A]()) }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_New_O(args[0])}; return nil }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_invoke, New: A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_new, Get: A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_get}

var A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$write_block_BANG_$fn__274000047", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_zlib_write_block_BANG__A_class, Simple: "fn__274000047", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_InstanceOf; i.Init = A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_Init; i.Table = A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A_class, reflect.TypeFor[A_arbace_a2g_zlib_write_block_BANG__fn__274000047_A]()) }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_New_O(args[0])}; return nil }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_invoke, New: A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_new, Get: A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_get}

var A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$write_block_BANG_$fn__274000049", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_zlib_write_block_BANG__A_class, Simple: "fn__274000049", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_InstanceOf; i.Init = A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_Init; i.Table = A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A_class, reflect.TypeFor[A_arbace_a2g_zlib_write_block_BANG__fn__274000049_A]()) }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_invoke, New: A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_new, Get: A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_get}

var A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$write_block_BANG_$fn__274000055", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_zlib_write_block_BANG__A_class, Simple: "fn__274000055", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_InstanceOf; i.Init = A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_Init; i.Table = A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A_class, reflect.TypeFor[A_arbace_a2g_zlib_write_block_BANG__fn__274000055_A]()) }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_New_O(args[0])}; return nil }

func A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_fn_class)}; return nil }

var A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_invoke, New: A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_new, Get: A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_get}

var A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib$write_block_BANG_$fn__274000063", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_zlib_write_block_BANG__A_class, Simple: "fn__274000063", Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_InstanceOf; i.Init = A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_Init; i.Table = A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A_class, reflect.TypeFor[A_arbace_a2g_zlib_write_block_BANG__fn__274000063_A]()) }

func A_arbace_a2g_zlib_Bits_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_Bits_A_GetBasis__IPersistentVector(); case 1: return this.(*A_arbace_a2g_zlib_Bits_A).Invoke__O(); case 2: return this.(*A_arbace_a2g_zlib_Bits_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_zlib_Bits_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib_Bits_A_New_O_J_J(args[0], args[1].(int64), args[2].(int64))}; return nil }

func A_arbace_a2g_zlib_Bits_A_get(i int32, o any) any { switch i { case 0: return o.(*A_arbace_a2g_zlib_Bits_A).F_out}; return nil }

var A_arbace_a2g_zlib_Bits_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 getBasis ()Larbace.lang.IPersistentVector;\nM1 invoke ()Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;JJ)V\nG17 out Ljava.lang.Object;", Invoke: A_arbace_a2g_zlib_Bits_A_invoke, New: A_arbace_a2g_zlib_Bits_A_new, Get: A_arbace_a2g_zlib_Bits_A_get}

var A_arbace_a2g_zlib_Bits_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib.Bits", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.IFn_class, lang.IType_class}, Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib_Bits_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib_Bits_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib_Bits_A_InstanceOf; i.Table = A_arbace_a2g_zlib_Bits_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib_Bits_A_class, reflect.TypeFor[A_arbace_a2g_zlib_Bits_A]()) }

func A_arbace_a2g_zlib__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_zlib__init_A_Load__O(); case 1: return A_arbace_a2g_zlib__init_A_Unit0__O(); case 2: return A_arbace_a2g_zlib__init_A_Unit1__O(); case 3: return A_arbace_a2g_zlib__init_A_Unit10__O(); case 4: return A_arbace_a2g_zlib__init_A_Unit11__O(); case 5: return A_arbace_a2g_zlib__init_A_Unit12__O(); case 6: return A_arbace_a2g_zlib__init_A_Unit13__O(); case 7: return A_arbace_a2g_zlib__init_A_Unit14__O(); case 8: return A_arbace_a2g_zlib__init_A_Unit15__O(); case 9: return A_arbace_a2g_zlib__init_A_Unit16__O(); case 10: return A_arbace_a2g_zlib__init_A_Unit17__O(); case 11: return A_arbace_a2g_zlib__init_A_Unit18__O(); case 12: return A_arbace_a2g_zlib__init_A_Unit19__O(); case 13: return A_arbace_a2g_zlib__init_A_Unit2__O(); case 14: return A_arbace_a2g_zlib__init_A_Unit20__O(); case 15: return A_arbace_a2g_zlib__init_A_Unit21__O(); case 16: return A_arbace_a2g_zlib__init_A_Unit22__O(); case 17: return A_arbace_a2g_zlib__init_A_Unit23__O(); case 18: return A_arbace_a2g_zlib__init_A_Unit24__O(); case 19: return A_arbace_a2g_zlib__init_A_Unit25__O(); case 20: return A_arbace_a2g_zlib__init_A_Unit3__O(); case 21: return A_arbace_a2g_zlib__init_A_Unit4__O(); case 22: return A_arbace_a2g_zlib__init_A_Unit5__O(); case 23: return A_arbace_a2g_zlib__init_A_Unit6__O(); case 24: return A_arbace_a2g_zlib__init_A_Unit7__O(); case 25: return A_arbace_a2g_zlib__init_A_Unit8__O(); case 26: return A_arbace_a2g_zlib__init_A_Unit9__O()}; return nil }

func A_arbace_a2g_zlib__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_zlib__init_A_New()}; return nil }

var A_arbace_a2g_zlib__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_zlib__init_A_invoke, New: A_arbace_a2g_zlib__init_A_new}

var A_arbace_a2g_zlib__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.zlib__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_zlib.A_arbace_a2g_zlib__init_A", Source: "zlib.ae"})

func init() { i := A_arbace_a2g_zlib__init_A_class.Info(); i.IsInstance = A_arbace_a2g_zlib__init_A_InstanceOf; i.Init = A_arbace_a2g_zlib__init_A_Init; i.Table = A_arbace_a2g_zlib__init_A_members; jrt.RegisterGoType(A_arbace_a2g_zlib__init_A_class, reflect.TypeFor[A_arbace_a2g_zlib__init_A]()) }
