//line a2g_strings.ae:1
package aot_arbace_box_build

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn10,arbace.boxkn2,asyn3,boxyn10,arbace.ednyn3,ednyn13,arbace.stringyn3,strkn3,docks16,arbace.box.build5,errorkn3,dirkn8,packageskn3,srckn7,includekn3,logkn3,ramkn4,cpuskn5,cachekn3,runkn4,exitkn5,faultkn4,whatkn6,resultkn7,consolekn4,hashkn4,argskn3,outkn6,goarchkn3,stdkn4,gooskn7,goamd64kn4,pathkn1,skn4,elsekn5,toolskn7,importskn3,cwdkn9,resourceskn11,embed-fileskn8,patternskn5,embedkn9,importmapkn5,imagekn3,asmkn5,treeskn7,compilekn4,namekn4,langkn2,gokn4,plankn4,linkkn8,archiveskn4,onlykn4,jobskn4,mainkn7,ldflagskn3,refv11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn16,arbace.box.buildm2,R8,s2311,Builds a Go program from a plan, in the box or natively, by tool guests.\n\n    (import-plan plan)     natively (or wherever the sources are files): the plan of\n                           tools/goplan (a map, or its file's path) with each package's\n                           directory stored as a tree (:src) and the assembly's includes\n                           (:include, GOROOT/pkg/include); its hash\n    (build plan opts)      the program built: the plan (a map, or a hash or ref of\n                           import-plan's), each package's archive by compile, asm (its\n                           symbols, then each .s) and the archive's members appended here,\n                           then link; the image's hash (a blob), and ref (:ref opts) pointed\n                           at it\n\n    (archives plan opts)   the packages' archives {path entry}; with :only (a set of paths)\n                           only those built, the others :archives' (opts)\n    (link plan archives opts)  the image linked from them: its hash\n    (action what req opts)     one action: its result (doc/go/BOX-NOTES.md, S8: the rebuild's\n                           a2g, printing and preparing are actions too)\n\n  opts: :tools {:compile H :asm H :link H} (by default the refs tool.<tool>.<arch>), :ldflags\n  (by default the box's guests' link: -T 0x201000 -R 0x1000 -w), :ref, :jobs (the actions run at\n  once, by default 4), :cache (false: no action cache), :log (a function of a line, by default\n  println), :resources ({path {:ram BYTES :cpus N}} for a package's compile, a path ending in *\n  for those it begins, :link for the link;\n  S8), :run (a function of a request giving its result: by default arbace.box/run, a spawn;\n  arbace.box.rebuild/host-run runs it on the host). A package with :embed (arbace.box.plan's\n  {:patterns {PATTERN [FILE ...]}}) is compiled with -embedcfg (S8).\n\n  Each action is a request (arbace.box/request-text): the tool's image, its command line, the\n  trees it reads (/s the package's sources, /d the archives it imports, /c the import\n  configuration and the like, /i the includes) and its output directory (/o); its key the hash\n  of the request less :ram and :cpus, its result kept under the ref ac.KEY (61 hexadecimal\n  digits): a rerun after an interruption redoes only what has no result.v11,arbace.core13,*loaded-libs*v11,arbace.core7,ex-infov11,arbace.core5,assocR9,v11,arbace.core3,strv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv11,arbace.core10,chunk-restv11,arbace.core4,nextv11,arbace.core4,intov10,arbace.box8,put-treev11,arbace.core12,chunk-bufferv13,arbace.string10,ends-with?v10,arbace.box8,put-fileR10,v11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core4,restv11,arbace.core4,map?v10,arbace.edn11,read-stringv11,arbace.core4,atomv16,arbace.box.build11,source-treev11,arbace.core5,swap!v11,arbace.core6,updatev10,arbace.box3,putv11,arbace.core5,slurpR11,v11,arbace.core4,mapvv11,arbace.core6,dissocR12,R13,v10,arbace.box7,put-dirv11,arbace.core6,pr-strv16,arbace.box.build11,import-planR14,v16,arbace.box.build6,*opts*v11,arbace.core7,printlnv11,arbace.core5,applyv11,arbace.core4,subsv16,arbace.box.build10,sha256-hexl0,l61,v10,arbace.box12,request-textR15,R16,v16,arbace.box.build9,cache-refR17,v10,arbace.box3,refv10,arbace.box4,sizev10,arbace.box6,resultR18,v10,arbace.box3,runR19,v16,arbace.box.build4,failv11,arbace.core3,notv10,arbace.box4,ref!v16,arbace.box.build3,logR20,v10,arbace.box3,getR21,R22,R23,R24,v11,arbace.core6,formatR25,v16,arbace.box.build7,action*v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv10,arbace.box8,tree-getR26,R27,v11,arbace.core6,concatV1,R28,R29,R30,v11,arbace.core3,vecR31,v11,arbace.core6,mapcatR28,V1,s4,-stdv16,arbace.box.build12,arch-definesv11,arbace.core6,repeatc32,l16,l12,l6,l8,l10,v11,arbace.core4,odd?v16,arbace.box.build9,ar-memberv11,arbace.core6,empty?R32,v16,arbace.box.build17,forward-declaringv11,arbace.core3,mapc34,c92,R33,v11,arbace.core4,sortv11,arbace.core8,distinctv11,arbace.core3,valv11,arbace.core9,interposev16,arbace.box.build8,json-strv11,arbace.core7,sort-byv11,arbace.core3,keyv11,arbace.core8,to-arrayR34,R35,v16,arbace.box.build9,deps-treev11,arbace.core5,mergem4,R26,s2,/oR36,s2,/sR37,v11,arbace.core4,someR38,R39,R40,v16,arbace.box.build12,embed-configv16,arbace.box.build8,out-filev11,arbace.core5,doallv10,arbace.box9,get-bytesv11,arbace.core6,secondR41,v11,arbace.core7,string?v13,arbace.string12,starts-with?v11,arbace.core4,compv11,arbace.core1,-v11,arbace.core5,countR42,R43,R44,v16,arbace.box.build8,asm-argsv16,arbace.box.build9,file-treem2,s8,go_asm.hs0,R45,v11,arbace.core11,select-keysR46,R47,V1,s4,-stdv16,arbace.box.build9,complete?V1,s9,-completeV2,s10,-goversions8,go1.27.1V2,s8,-symabiss10,/c/symabisV5,s4,-c=4s15,-nolocalimportss10,-importcfgs12,/c/importcfgs5,-packV2,s9,-embedcfgs11,/c/embedcfgV2,s7,-asmhdrs11,/o/go_asm.hR48,V2,R15,R16,v11,arbace.core11,future-callv16,arbace.box.build14,append-membersv11,arbace.core10,re-matchesp12,[0-9a-f]{64}v10,arbace.box4,loadR49,v11,arbace.core4,nameV3,R45,R43,R50,v16,arbace.box.build9,read-planv16,arbace.box.build10,with-toolsR51,R52,R53,v11,arbace.core11,map-indexedl4,v16,arbace.box.build13,build-packageR54,R50,R36,V7,s4,links2,-os8,/o/a.outs10,-importcfgs17,/c/importcfg.links14,-buildmode=exes9,-buildid=R55,V5,s2,-Ts8,0x201000s2,-Rs6,0x1000s2,-wV2,R15,R16,v16,arbace.box.build8,archivesv16,arbace.box.build4,linkR56,v16,arbace.box.build5,build")

var Lit_1 *jrt.String = jrt.Intern("arbace.box.build: ")

var Lit_2 *jrt.String = jrt.Intern(": ")

var Lit_3 *jrt.String = jrt.Intern("\n")

var Lit_4 *jrt.String = jrt.Intern("the guest faulted: ")

var Lit_5 *jrt.String = jrt.Intern("exit ")

var Lit_6 *jrt.String = jrt.Intern("%-8s %s%s")

var Lit_7 *jrt.String = jrt.Intern(" (cached)")

var Lit_8 *jrt.String = jrt.Intern(" %.2f s")

var Lit_9 *jrt.String = jrt.Intern("arbace.box.build$ar_member$pad__598000077")

var Lit_10 *jrt.String = jrt.Intern("`\n")

var Lit_11 *jrt.String = jrt.Intern("0")

var Lit_12 *jrt.String = jrt.Intern("644")

var Lit_13 *jrt.String = jrt.Intern("-D")

var Lit_14 *jrt.String = jrt.Intern("GOOS_")

var Lit_15 *jrt.String = jrt.Intern("GOARCH_")

var Lit_16 *jrt.String = jrt.Intern("amd64")

var Lit_17 *jrt.String = jrt.Intern("GOAMD64_")

var Lit_18 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000242")

var Lit_19 *jrt.String = jrt.Intern("arbace.box.build$archives$conveyed__598000244")

var Lit_20 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000252")

var Lit_21 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000254")

var Lit_22 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000260")

var Lit_23 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000262")

var Lit_24 *jrt.String = jrt.Intern("arbace.box.build$archives$iter__598000268__598000272")

var Lit_25 *jrt.String = jrt.Intern("arbace.box.build$archives$conveyed__598000244$fn__598000245")

var Lit_26 *jrt.String = jrt.Intern("arbace.box.build: no archive given for ")

var Lit_27 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000254$fn__598000255")

var Lit_28 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000254$fn__598000255$fn__598000256")

var Lit_29 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000262$fn__598000263")

var Lit_30 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000262$fn__598000263$fn__598000264")

var Lit_31 *jrt.String = jrt.Intern("arbace.box.build$archives$iter__598000268__598000272$fn__598000273")

var Lit_32 *jrt.String = jrt.Intern("arbace.box.build$archives$iter__598000268__598000272$fn__598000273$fn__598000274")

var Lit_33 *jrt.String = jrt.Intern("asm")

var Lit_34 *jrt.String = jrt.Intern("-p")

var Lit_35 *jrt.String = jrt.Intern("-trimpath")

var Lit_36 *jrt.String = jrt.Intern("/s=>")

var Lit_37 *jrt.String = jrt.Intern(";/c=>")

var Lit_38 *jrt.String = jrt.Intern("-I")

var Lit_39 *jrt.String = jrt.Intern("/c/")

var Lit_40 *jrt.String = jrt.Intern("/i")

var Lit_41 *jrt.String = jrt.Intern("arbace.box.build$asm_args$fn__598000074")

var Lit_42 *jrt.String = jrt.Intern("-o")

var Lit_43 *jrt.String = jrt.Intern("arbace.box.build$build$fn__598000301")

var Lit_44 *jrt.String = jrt.Intern("%s: %d packages, the image %s (%d bytes) in %.1f s")

var Lit_45 *jrt.String = jrt.Intern("# import config\n")

var Lit_46 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000150__598000154")

var Lit_47 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000166__598000170")

var Lit_48 *jrt.String = jrt.Intern("arbace.box.build$build_package$res_of__598000176")

var Lit_49 *jrt.String = jrt.Intern("arbace.box.build$build_package$fn__598000179")

var Lit_50 *jrt.String = jrt.Intern(" embeds files: plan it with arbace.box.plan")

var Lit_51 *jrt.String = jrt.Intern("symabis")

var Lit_52 *jrt.String = jrt.Intern("/o/symabis")

var Lit_53 *jrt.String = jrt.Intern("-gensymabis")

var Lit_54 *jrt.String = jrt.Intern("arbace.box.build$build_package$fn__598000184")

var Lit_55 *jrt.String = jrt.Intern("/s")

var Lit_56 *jrt.String = jrt.Intern("/c")

var Lit_57 *jrt.String = jrt.Intern("compile")

var Lit_58 *jrt.String = jrt.Intern("/o/_pkg_.a")

var Lit_59 *jrt.String = jrt.Intern(";/o=>;/c=>")

var Lit_60 *jrt.String = jrt.Intern("main")

var Lit_61 *jrt.String = jrt.Intern("-lang=")

var Lit_62 *jrt.String = jrt.Intern("arbace.box.build$build_package$fn__598000186")

var Lit_63 *jrt.String = jrt.Intern("/d")

var Lit_64 *jrt.String = jrt.Intern("importcfg")

var Lit_65 *jrt.String = jrt.Intern("embedcfg")

var Lit_66 *jrt.String = jrt.Intern("_pkg_.a")

var Lit_67 *jrt.String = jrt.Intern("go_asm.h")

var Lit_68 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000189__598000193")

var Lit_69 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000203__598000207")

var Lit_70 *jrt.String = jrt.Intern("*")

var Lit_71 *jrt.String = jrt.Intern("./")

var Lit_72 *jrt.String = jrt.Intern("/s/")

var Lit_73 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000150__598000154$fn__598000155")

var Lit_74 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000150__598000154$fn__598000155$fn__598000156")

var Lit_75 *jrt.String = jrt.Intern("importmap ")

var Lit_76 *jrt.String = jrt.Intern("=")

var Lit_77 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000166__598000170$fn__598000171")

var Lit_78 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000166__598000170$fn__598000171$fn__598000172")

var Lit_79 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000189__598000193$fn__598000194")

var Lit_80 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000189__598000193$fn__598000194$fn__598000195")

var Lit_81 *jrt.String = jrt.Intern(".o")

var Lit_82 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000189__598000193$fn__598000194$fn__598000199")

var Lit_83 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000189__598000193$fn__598000194$fn__598000195$fn__598000196")

var Lit_84 *jrt.String = jrt.Intern("asm ")

var Lit_85 *jrt.String = jrt.Intern("/o/")

var Lit_86 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000203__598000207$fn__598000208")

var Lit_87 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000203__598000207$fn__598000208$fn__598000209")

var Lit_88 *jrt.String = jrt.Intern(" ")

var Lit_89 *jrt.String = jrt.Intern("ac.")

var Lit_90 *jrt.String = jrt.Intern("arbace.box.build$deps_tree$iter__598000092__598000096")

var Lit_91 *jrt.String = jrt.Intern("arbace.box.build$deps_tree$iter__598000102__598000106")

var Lit_92 *jrt.String = jrt.Intern("arbace.box.build$deps_tree$iter__598000092__598000096$fn__598000097")

var Lit_93 *jrt.String = jrt.Intern("arbace.box.build$deps_tree$iter__598000092__598000096$fn__598000097$fn__598000098")

var Lit_94 *jrt.String = jrt.Intern(".a")

var Lit_95 *jrt.String = jrt.Intern("arbace.box.build$deps_tree$iter__598000102__598000106$fn__598000107")

var Lit_96 *jrt.String = jrt.Intern("arbace.box.build$deps_tree$iter__598000102__598000106$fn__598000107$fn__598000108")

var Lit_97 *jrt.String = jrt.Intern("packagefile ")

var Lit_98 *jrt.String = jrt.Intern("=/d/")

var Lit_99 *jrt.String = jrt.Intern("{\"Patterns\":{")

var Lit_100 *jrt.String = jrt.Intern("},\"Files\":{")

var Lit_101 *jrt.String = jrt.Intern("}}\n")

var Lit_102 *jrt.String = jrt.Intern(",")

var Lit_103 *jrt.String = jrt.Intern("arbace.box.build$embed_config$iter__598000116__598000120")

var Lit_104 *jrt.String = jrt.Intern("arbace.box.build$embed_config$iter__598000132__598000136")

var Lit_105 *jrt.String = jrt.Intern("arbace.box.build$embed_config$iter__598000116__598000120$fn__598000121")

var Lit_106 *jrt.String = jrt.Intern("arbace.box.build$embed_config$iter__598000116__598000120$fn__598000121$fn__598000122")

var Lit_107 *jrt.String = jrt.Intern(":[")

var Lit_108 *jrt.String = jrt.Intern("]")

var Lit_109 *jrt.String = jrt.Intern("arbace.box.build$embed_config$iter__598000132__598000136$fn__598000137")

var Lit_110 *jrt.String = jrt.Intern("arbace.box.build$embed_config$iter__598000132__598000136$fn__598000137$fn__598000138")

var Lit_111 *jrt.String = jrt.Intern(":")

var Lit_112 *jrt.String = jrt.Intern("java.io.ByteArrayOutputStream")

var Lit_113 *jrt.String = jrt.Intern("java.nio.charset.StandardCharsets")

var Lit_114 *jrt.String = jrt.Intern("java.security.MessageDigest")

var Lit_115 *jrt.String = jrt.Intern("arbace.box.build$file_tree$iter__598000054__598000058")

var Lit_116 *jrt.String = jrt.Intern("arbace.box.build$file_tree$iter__598000054__598000058$fn__598000059")

var Lit_117 *jrt.String = jrt.Intern("arbace.box.build$file_tree$iter__598000054__598000058$fn__598000059$fn__598000060")

var Lit_118 *jrt.String = jrt.Intern("arbace.box.build$import_plan$src__598000042")

var Lit_119 *jrt.String = jrt.Intern("/pkg/include")

var Lit_120 *jrt.String = jrt.Intern("arbace.box.build$import_plan$fn__598000044")

var Lit_121 *jrt.String = jrt.Intern("/root/tamago-go")

var Lit_122 *jrt.String = jrt.Intern("arbace.box.build$import_plan$fn__598000044$fn__598000045")

var Lit_123 *jrt.String = jrt.Intern("\"")

var Lit_124 *jrt.String = jrt.Intern("arbace.box.build$json_str$fn__598000113")

var Lit_125 *jrt.String = jrt.Intern("\\\"")

var Lit_126 *jrt.String = jrt.Intern("\\\\")

var Lit_127 *jrt.String = jrt.Intern("\\u%04x")

var Lit_128 *jrt.String = jrt.Intern("arbace.box.build$link$fn__598000285")

var Lit_129 *jrt.String = jrt.Intern("arbace.box.build$link$iter__598000290__598000294")

var Lit_130 *jrt.String = jrt.Intern(" link")

var Lit_131 *jrt.String = jrt.Intern("/d/")

var Lit_132 *jrt.String = jrt.Intern("importcfg.link")

var Lit_133 *jrt.String = jrt.Intern("/o")

var Lit_134 *jrt.String = jrt.Intern("a.out")

var Lit_135 *jrt.String = jrt.Intern("arbace.box.build$link$iter__598000290__598000294$fn__598000295")

var Lit_136 *jrt.String = jrt.Intern("arbace.box.build$link$iter__598000290__598000294$fn__598000295$fn__598000296")

var Lit_137 *jrt.String = jrt.Intern(": no ")

var Lit_138 *jrt.String = jrt.Intern(" in its output")

var Lit_139 *jrt.String = jrt.Intern("arbace.box.build: no plan ")

var Lit_140 *jrt.String = jrt.Intern("SHA-256")

var Lit_141 *jrt.String = jrt.Intern("arbace.box.build$source_tree$headers__598000018")

var Lit_142 *jrt.String = jrt.Intern("arbace.box.build$source_tree$iter__598000030__598000034")

var Lit_143 *jrt.String = jrt.Intern("arbace.box.build$source_tree$headers__598000018$iter__598000019__598000023")

var Lit_144 *jrt.String = jrt.Intern("arbace.box.build$source_tree$headers__598000018$iter__598000019__598000023$fn__598000024")

var Lit_145 *jrt.String = jrt.Intern("arbace.box.build$source_tree$headers__598000018$iter__598000019__598000023$fn__598000024$fn__598000025")

var Lit_146 *jrt.String = jrt.Intern(".h")

var Lit_147 *jrt.String = jrt.Intern("arbace.box.build$source_tree$iter__598000030__598000034$fn__598000035")

var Lit_148 *jrt.String = jrt.Intern("arbace.box.build$source_tree$iter__598000030__598000034$fn__598000035$fn__598000036")

var Lit_149 *jrt.String = jrt.Intern("arbace.box.build$with_tools$iter__598000221__598000225")

var Lit_150 *jrt.String = jrt.Intern("arbace.box.build$with_tools$iter__598000221__598000225$fn__598000226")

var Lit_151 *jrt.String = jrt.Intern("arbace.box.build$with_tools$iter__598000221__598000225$fn__598000226$fn__598000227")

var Lit_152 *jrt.String = jrt.Intern("tool.")

var Lit_153 *jrt.String = jrt.Intern(".")

var Lit_154 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn3,msgyn4,datakn4,linekn6,columnkn4,filekn3,tagyn6,Stringyn12,java.io.Fileyn4,planyn6,gorootkn7,dynamicyn1,&yn2,xsyn3,reqyn4,whatyn4,optsyn3,resyn4,nameyn1,myn3,pkgyn3,outyn4,moreyn5,bytesyn7,membersyn8,archivesyn5,indexyn5,pathsyn8,patternsyn1,pv11,arbace.core5,in-nsMyn16,arbace.box.buildm2,R0,s2311,Builds a Go program from a plan, in the box or natively, by tool guests.\n\n    (import-plan plan)     natively (or wherever the sources are files): the plan of\n                           tools/goplan (a map, or its file's path) with each package's\n                           directory stored as a tree (:src) and the assembly's includes\n                           (:include, GOROOT/pkg/include); its hash\n    (build plan opts)      the program built: the plan (a map, or a hash or ref of\n                           import-plan's), each package's archive by compile, asm (its\n                           symbols, then each .s) and the archive's members appended here,\n                           then link; the image's hash (a blob), and ref (:ref opts) pointed\n                           at it\n\n    (archives plan opts)   the packages' archives {path entry}; with :only (a set of paths)\n                           only those built, the others :archives' (opts)\n    (link plan archives opts)  the image linked from them: its hash\n    (action what req opts)     one action: its result (doc/go/BOX-NOTES.md, S8: the rebuild's\n                           a2g, printing and preparing are actions too)\n\n  opts: :tools {:compile H :asm H :link H} (by default the refs tool.<tool>.<arch>), :ldflags\n  (by default the box's guests' link: -T 0x201000 -R 0x1000 -w), :ref, :jobs (the actions run at\n  once, by default 4), :cache (false: no action cache), :log (a function of a line, by default\n  println), :resources ({path {:ram BYTES :cpus N}} for a package's compile, a path ending in *\n  for those it begins, :link for the link;\n  S8), :run (a function of a request giving its result: by default arbace.box/run, a spawn;\n  arbace.box.rebuild/host-run runs it on the host). A package with :embed (arbace.box.plan's\n  {:patterns {PATTERN [FILE ...]}}) is compiled with -embedcfg (S8).\n\n  Each action is a request (arbace.box/request-text): the tool's image, its command line, the\n  trees it reads (/s the package's sources, /d the archives it imports, /c the import\n  configuration and the like, /i the includes) and its output directory (/o); its key the hash\n  of the request less :ram and :cpus, its result kept under the ref ac.KEY (61 hexadecimal\n  digits): a rerun after an interruption redoes only what has no result.m2,R0,s2311,Builds a Go program from a plan, in the box or natively, by tool guests.\n\n    (import-plan plan)     natively (or wherever the sources are files): the plan of\n                           tools/goplan (a map, or its file's path) with each package's\n                           directory stored as a tree (:src) and the assembly's includes\n                           (:include, GOROOT/pkg/include); its hash\n    (build plan opts)      the program built: the plan (a map, or a hash or ref of\n                           import-plan's), each package's archive by compile, asm (its\n                           symbols, then each .s) and the archive's members appended here,\n                           then link; the image's hash (a blob), and ref (:ref opts) pointed\n                           at it\n\n    (archives plan opts)   the packages' archives {path entry}; with :only (a set of paths)\n                           only those built, the others :archives' (opts)\n    (link plan archives opts)  the image linked from them: its hash\n    (action what req opts)     one action: its result (doc/go/BOX-NOTES.md, S8: the rebuild's\n                           a2g, printing and preparing are actions too)\n\n  opts: :tools {:compile H :asm H :link H} (by default the refs tool.<tool>.<arch>), :ldflags\n  (by default the box's guests' link: -T 0x201000 -R 0x1000 -w), :ref, :jobs (the actions run at\n  once, by default 4), :cache (false: no action cache), :log (a function of a line, by default\n  println), :resources ({path {:ram BYTES :cpus N}} for a package's compile, a path ending in *\n  for those it begins, :link for the link;\n  S8), :run (a function of a request giving its result: by default arbace.box/run, a spawn;\n  arbace.box.rebuild/host-run runs it on the host). A package with :embed (arbace.box.plan's\n  {:patterns {PATTERN [FILE ...]}}) is compiled with -embedcfg (S8).\n\n  Each action is a request (arbace.box/request-text): the tool's image, its command line, the\n  trees it reads (/s the package's sources, /d the archives it imports, /c the import\n  configuration and the like, /i the includes) and its output directory (/o); its key the hash\n  of the request less :ram and :cpus, its result kept under the ref ac.KEY (61 hexadecimal\n  digits): a rerun after an interruption redoes only what has no result.R1,v16,arbace.box.build4,failm10,R2,TR3,L1,V2,R4,R5,R6,i44,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build10,sha256-hexm10,R2,TR3,L1,V1,Myn1,sm2,R9,R10,R6,i47,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build11,source-treem12,R2,TR3,L1,V1,Myn1,dm2,R9,R11,R0,s178,A package's directory as a tree: its files (not its subdirectories, other packages), and the\n  .h files of its subdirectories (an assembly file includes them by a relative path).R6,i59,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build11,import-planm10,R3,L2,V1,R12,V2,R12,R13,R0,s181,Stores the plan's sources as trees and the plan itself (see the namespace's doc): its hash.\n  goroot is the GOROOT whose pkg/include the assembly reads (by default /root/tamago-go).R6,i82,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build6,*opts*m10,R14,TR2,TR6,i98,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build3,logm10,R2,TR3,L1,V2,R15,R16,R6,i100,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build9,cache-refm10,R2,TR3,L1,V1,R17,R6,i103,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build7,action*m10,R2,TR3,L1,V2,R18,R17,R6,i106,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build6,actionm10,R3,L2,V2,R18,R17,V3,R18,R17,R19,R0,s214,Runs request req (or takes its result from the cache): its result. A result that is not\n  :exit 0 is an ex-info with the console. opts: the namespace's (:run, :cache, :log), by\n  default those of the build running.R6,i124,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build8,out-filem12,R2,TR3,L1,V3,R20,R18,R21,R0,s43,The entry name of result res's output tree.R6,i131,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build9,file-treem12,R2,TR3,L1,V1,R22,R0,s48,A tree of files given as {name string-or-bytes}.R6,i137,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build12,arch-definesm10,R2,TR3,L1,V1,R12,R6,i142,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build8,asm-argsm10,R2,TR3,L1,V5,R12,R23,R24,R15,R25,R6,i150,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build9,ar-memberm10,R2,TR3,L1,MV2,Myn4,namem2,R9,R10,Myn4,datam2,R9,R26,m2,R9,R26,R6,i158,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build14,append-membersm10,R2,TR3,L1,MV2,Myn7,archivem2,R9,R26,R27,m2,R9,R26,R6,i167,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build17,forward-declaringS10,s2,oss3,nets4,syncs7,syscalls13,runtime/pprofs5,bytess4,times13,internal/polls15,runtime/metricss13,runtime/tracem10,R2,TR6,i173,R7,i1,R8,s19,arbace/box/build.aeR0,s135,The standard packages with declarations the runtime supplies, which go build compiles without\n  -complete (cmd/go/internal/work/gc.go).v16,arbace.box.build9,complete?m12,R2,TR3,L1,V1,R23,R0,s53,Is the package's Go all of it (go build's -complete)?R6,i178,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build9,deps-treem12,R2,TR3,L1,V3,R28,R29,R30,R0,s111,The tree /d: the archives of the packages imports names, each <index>.a; and the\n  importcfg lines naming them.R6,i183,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build8,json-strm12,R2,TR3,L1,V1,Myn1,sm2,R9,R10,R0,s19,s as a JSON string.R6,i190,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build12,embed-configm12,R2,TR3,L1,V1,R31,R0,s142,compile's -embedcfg for the patterns {PATTERN [FILE ...]} (files relative to the package's\n  directory, mounted at /s): JSON, the keys sorted.R6,i199,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build13,build-packagem12,R2,TR3,L1,V4,R12,R23,R28,R29,R0,s56,The package's archive: its tree entry [:file HASH SIZE].R6,i211,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build9,read-planm10,R2,TR3,L1,V1,R12,R6,i276,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build10,with-toolsm12,R2,TR3,L1,V2,R32,R19,R0,s82,opts with :tools complete: the refs tool.<tool>.<arch> for those it does not name.R6,i281,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build8,archivesm10,R3,L1,V2,R12,R19,R0,s234,The archives of the plan's packages, built (see the namespace's doc): {path entry}, each\n  entry the archive's [:file HASH SIZE]. With :only (opts), a set of paths, only those are\n  built again, the others taken from :archives (opts).R6,i291,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build4,linkm10,R3,L1,V3,R12,R28,R19,R0,s223,Links the plan's program from its archives ({path entry}, archives' answer): the image's\n  hash. The link's flags are :ldflags (opts; by default the box's guests': -T 0x201000 -R 0x1000\n  -w) after -buildmode=exe -buildid=.R6,i322,R7,i1,R8,s19,arbace/box/build.aev16,arbace.box.build5,buildm10,R3,L2,V1,R12,V2,R12,R19,R0,s70,Builds the plan's program (see the namespace's doc): the image's hash.R6,i346,R7,i1,R8,s19,arbace/box/build.ae")

var Lit_155 *jrt.String = jrt.Intern("arbace.box.build$eval598000004$loading__1927001464__auto____598000005")

var Lit_156 *jrt.String = jrt.Intern("arbace.box.build$eval598000008$fn__598000009")

var Lit_157 *jrt.String = jrt.Intern("arbace.box.build$fail")

var Lit_158 *jrt.String = jrt.Intern("arbace.box.build$sha256_hex")

var Lit_159 *jrt.String = jrt.Intern("arbace.box.build$source_tree")

var Lit_160 *jrt.String = jrt.Intern("arbace.box.build$import_plan")

var Lit_161 *jrt.String = jrt.Intern("arbace.box.build$log")

var Lit_162 *jrt.String = jrt.Intern("arbace.box.build$cache_ref")

var Lit_163 *jrt.String = jrt.Intern("arbace.box.build$action_STAR_")

var Lit_164 *jrt.String = jrt.Intern("arbace.box.build$action")

var Lit_165 *jrt.String = jrt.Intern("arbace.box.build$out_file")

var Lit_166 *jrt.String = jrt.Intern("arbace.box.build$file_tree")

var Lit_167 *jrt.String = jrt.Intern("arbace.box.build$arch_defines")

var Lit_168 *jrt.String = jrt.Intern("arbace.box.build$asm_args")

var Lit_169 *jrt.String = jrt.Intern("arbace.box.build$ar_member")

var Lit_170 *jrt.String = jrt.Intern("arbace.box.build$append_members")

var Lit_171 *jrt.String = jrt.Intern("arbace.box.build$complete_QMARK_")

var Lit_172 *jrt.String = jrt.Intern("arbace.box.build$deps_tree")

var Lit_173 *jrt.String = jrt.Intern("arbace.box.build$json_str")

var Lit_174 *jrt.String = jrt.Intern("arbace.box.build$embed_config")

var Lit_175 *jrt.String = jrt.Intern("arbace.box.build$build_package")

var Lit_176 *jrt.String = jrt.Intern("arbace.box.build$read_plan")

var Lit_177 *jrt.String = jrt.Intern("arbace.box.build$with_tools")

var Lit_178 *jrt.String = jrt.Intern("arbace.box.build$archives")

var Lit_179 *jrt.String = jrt.Intern("arbace.box.build$link")

var Lit_180 *jrt.String = jrt.Intern("arbace.box.build$build")
