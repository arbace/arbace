//line a2g_strings.ae:1
package aot_arbace_box_build

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.box")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("box")

var Lit_6 *jrt.String = jrt.Intern("arbace.edn")

var Lit_7 *jrt.String = jrt.Intern("edn")

var Lit_8 *jrt.String = jrt.Intern("arbace.string")

var Lit_9 *jrt.String = jrt.Intern("str")

var Lit_10 *jrt.String = jrt.Intern("commute")

var Lit_11 *jrt.String = jrt.Intern("deref")

var Lit_12 *jrt.String = jrt.Intern("conj")

var Lit_13 *jrt.String = jrt.Intern("arbace.box.build")

var Lit_14 *jrt.String = jrt.Intern("doc")

var Lit_15 *jrt.String = jrt.Intern("Builds a Go program from a plan, in the box or natively, by tool guests.\n\n    (import-plan plan)     natively (or wherever the sources are files): the plan of\n                           tools/goplan (a map, or its file's path) with each package's\n                           directory stored as a tree (:src) and the assembly's includes\n                           (:include, GOROOT/pkg/include); its hash\n    (build plan opts)      the program built: the plan (a map, or a hash or ref of\n                           import-plan's), each package's archive by compile, asm (its\n                           symbols, then each .s) and the archive's members appended here,\n                           then link; the image's hash (a blob), and ref (:ref opts) pointed\n                           at it\n\n    (archives plan opts)   the packages' archives {path entry}; with :only (a set of paths)\n                           only those built, the others :archives' (opts)\n    (link plan archives opts)  the image linked from them: its hash\n    (action what req opts)     one action: its result (doc/go/BOX-NOTES.md, S8: the rebuild's\n                           a2g, printing and preparing are actions too)\n\n  opts: :tools {:compile H :asm H :link H} (by default the refs tool.<tool>.<arch>), :ldflags\n  (by default the box's guests' link: -T 0x201000 -R 0x1000 -w), :ref, :jobs (the actions run at\n  once, by default 4), :cache (false: no action cache), :log (a function of a line, by default\n  println), :resources ({path {:ram BYTES :cpus N}} for a package's compile, a path ending in *\n  for those it begins, :link for the link;\n  S8), :run (a function of a request giving its result: by default arbace.box/run, a spawn;\n  arbace.box.rebuild/host-run runs it on the host). A package with :embed (arbace.box.plan's\n  {:patterns {PATTERN [FILE ...]}}) is compiled with -embedcfg (S8).\n\n  Each action is a request (arbace.box/request-text): the tool's image, its command line, the\n  trees it reads (/s the package's sources, /d the archives it imports, /c the import\n  configuration and the like, /i the includes) and its output directory (/o); its key the hash\n  of the request less :ram and :cpus, its result kept under the ref ac.KEY (61 hexadecimal\n  digits): a rerun after an interruption redoes only what has no result.")

var Lit_16 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_17 *jrt.String = jrt.Intern("ex-info")

var Lit_18 *jrt.String = jrt.Intern("assoc")

var Lit_19 *jrt.String = jrt.Intern("error")

var Lit_20 *jrt.String = jrt.Intern("seq")

var Lit_21 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_22 *jrt.String = jrt.Intern("chunk-first")

var Lit_23 *jrt.String = jrt.Intern("first")

var Lit_24 *jrt.String = jrt.Intern("chunk-rest")

var Lit_25 *jrt.String = jrt.Intern("next")

var Lit_26 *jrt.String = jrt.Intern("into")

var Lit_27 *jrt.String = jrt.Intern("put-tree")

var Lit_28 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_29 *jrt.String = jrt.Intern("ends-with?")

var Lit_30 *jrt.String = jrt.Intern("put-file")

var Lit_31 *jrt.String = jrt.Intern("dir")

var Lit_32 *jrt.String = jrt.Intern("chunk-append")

var Lit_33 *jrt.String = jrt.Intern("chunk-cons")

var Lit_34 *jrt.String = jrt.Intern("cons")

var Lit_35 *jrt.String = jrt.Intern("chunk")

var Lit_36 *jrt.String = jrt.Intern("rest")

var Lit_37 *jrt.String = jrt.Intern("map?")

var Lit_38 *jrt.String = jrt.Intern("read-string")

var Lit_39 *jrt.String = jrt.Intern("atom")

var Lit_40 *jrt.String = jrt.Intern("source-tree")

var Lit_41 *jrt.String = jrt.Intern("swap!")

var Lit_42 *jrt.String = jrt.Intern("update")

var Lit_43 *jrt.String = jrt.Intern("put")

var Lit_44 *jrt.String = jrt.Intern("slurp")

var Lit_45 *jrt.String = jrt.Intern("packages")

var Lit_46 *jrt.String = jrt.Intern("mapv")

var Lit_47 *jrt.String = jrt.Intern("dissoc")

var Lit_48 *jrt.String = jrt.Intern("src")

var Lit_49 *jrt.String = jrt.Intern("include")

var Lit_50 *jrt.String = jrt.Intern("put-dir")

var Lit_51 *jrt.String = jrt.Intern("pr-str")

var Lit_52 *jrt.String = jrt.Intern("import-plan")

var Lit_53 *jrt.String = jrt.Intern("log")

var Lit_54 *jrt.String = jrt.Intern("*opts*")

var Lit_55 *jrt.String = jrt.Intern("println")

var Lit_56 *jrt.String = jrt.Intern("apply")

var Lit_57 *jrt.String = jrt.Intern("subs")

var Lit_58 *jrt.String = jrt.Intern("sha256-hex")

var Lit_59 *jrt.String = jrt.Intern("request-text")

var Lit_60 *jrt.String = jrt.Intern("ram")

var Lit_61 *jrt.String = jrt.Intern("cpus")

var Lit_62 *jrt.String = jrt.Intern("cache-ref")

var Lit_63 *jrt.String = jrt.Intern("cache")

var Lit_64 *jrt.String = jrt.Intern("ref")

var Lit_65 *jrt.String = jrt.Intern("size")

var Lit_66 *jrt.String = jrt.Intern("result")

var Lit_67 *jrt.String = jrt.Intern("run")

var Lit_68 *jrt.String = jrt.Intern("exit")

var Lit_69 *jrt.String = jrt.Intern("fail")

var Lit_70 *jrt.String = jrt.Intern("not")

var Lit_71 *jrt.String = jrt.Intern("ref!")

var Lit_72 *jrt.String = jrt.Intern("fault")

var Lit_73 *jrt.String = jrt.Intern("get")

var Lit_74 *jrt.String = jrt.Intern("what")

var Lit_75 *jrt.String = jrt.Intern("console")

var Lit_76 *jrt.String = jrt.Intern("hash")

var Lit_77 *jrt.String = jrt.Intern("format")

var Lit_78 *jrt.String = jrt.Intern("args")

var Lit_79 *jrt.String = jrt.Intern("action*")

var Lit_80 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_81 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_82 *jrt.String = jrt.Intern("hash-map")

var Lit_83 *jrt.String = jrt.Intern("tree-get")

var Lit_84 *jrt.String = jrt.Intern("out")

var Lit_85 *jrt.String = jrt.Intern("goarch")

var Lit_86 *jrt.String = jrt.Intern("concat")

var Lit_87 *jrt.String = jrt.Intern("std")

var Lit_88 *jrt.String = jrt.Intern("goos")

var Lit_89 *jrt.String = jrt.Intern("goamd64")

var Lit_90 *jrt.String = jrt.Intern("vec")

var Lit_91 *jrt.String = jrt.Intern("path")

var Lit_92 *jrt.String = jrt.Intern("mapcat")

var Lit_93 *jrt.String = jrt.Intern("-std")

var Lit_94 *jrt.String = jrt.Intern("arch-defines")

var Lit_95 *jrt.String = jrt.Intern("repeat")

var Lit_96 *jrt.String = jrt.Intern("odd?")

var Lit_97 *jrt.String = jrt.Intern("ar-member")

var Lit_98 *jrt.String = jrt.Intern("empty?")

var Lit_99 *jrt.String = jrt.Intern("s")

var Lit_100 *jrt.String = jrt.Intern("forward-declaring")

var Lit_101 *jrt.String = jrt.Intern("map")

var Lit_102 *jrt.String = jrt.Intern("else")

var Lit_103 *jrt.String = jrt.Intern("sort")

var Lit_104 *jrt.String = jrt.Intern("distinct")

var Lit_105 *jrt.String = jrt.Intern("val")

var Lit_106 *jrt.String = jrt.Intern("interpose")

var Lit_107 *jrt.String = jrt.Intern("json-str")

var Lit_108 *jrt.String = jrt.Intern("sort-by")

var Lit_109 *jrt.String = jrt.Intern("key")

var Lit_110 *jrt.String = jrt.Intern("to-array")

var Lit_111 *jrt.String = jrt.Intern("tools")

var Lit_112 *jrt.String = jrt.Intern("imports")

var Lit_113 *jrt.String = jrt.Intern("deps-tree")

var Lit_114 *jrt.String = jrt.Intern("merge")

var Lit_115 *jrt.String = jrt.Intern("/o")

var Lit_116 *jrt.String = jrt.Intern("cwd")

var Lit_117 *jrt.String = jrt.Intern("/s")

var Lit_118 *jrt.String = jrt.Intern("resources")

var Lit_119 *jrt.String = jrt.Intern("some")

var Lit_120 *jrt.String = jrt.Intern("embed-files")

var Lit_121 *jrt.String = jrt.Intern("patterns")

var Lit_122 *jrt.String = jrt.Intern("embed")

var Lit_123 *jrt.String = jrt.Intern("embed-config")

var Lit_124 *jrt.String = jrt.Intern("out-file")

var Lit_125 *jrt.String = jrt.Intern("doall")

var Lit_126 *jrt.String = jrt.Intern("get-bytes")

var Lit_127 *jrt.String = jrt.Intern("second")

var Lit_128 *jrt.String = jrt.Intern("importmap")

var Lit_129 *jrt.String = jrt.Intern("string?")

var Lit_130 *jrt.String = jrt.Intern("starts-with?")

var Lit_131 *jrt.String = jrt.Intern("comp")

var Lit_132 *jrt.String = jrt.Intern("-")

var Lit_133 *jrt.String = jrt.Intern("count")

var Lit_134 *jrt.String = jrt.Intern("image")

var Lit_135 *jrt.String = jrt.Intern("asm")

var Lit_136 *jrt.String = jrt.Intern("trees")

var Lit_137 *jrt.String = jrt.Intern("asm-args")

var Lit_138 *jrt.String = jrt.Intern("file-tree")

var Lit_139 *jrt.String = jrt.Intern("go_asm.h")

var Lit_140 *jrt.String = jrt.Intern("")

var Lit_141 *jrt.String = jrt.Intern("compile")

var Lit_142 *jrt.String = jrt.Intern("select-keys")

var Lit_143 *jrt.String = jrt.Intern("name")

var Lit_144 *jrt.String = jrt.Intern("lang")

var Lit_145 *jrt.String = jrt.Intern("complete?")

var Lit_146 *jrt.String = jrt.Intern("-complete")

var Lit_147 *jrt.String = jrt.Intern("-goversion")

var Lit_148 *jrt.String = jrt.Intern("go1.27.1")

var Lit_149 *jrt.String = jrt.Intern("-symabis")

var Lit_150 *jrt.String = jrt.Intern("/c/symabis")

var Lit_151 *jrt.String = jrt.Intern("-c=4")

var Lit_152 *jrt.String = jrt.Intern("-nolocalimports")

var Lit_153 *jrt.String = jrt.Intern("-importcfg")

var Lit_154 *jrt.String = jrt.Intern("/c/importcfg")

var Lit_155 *jrt.String = jrt.Intern("-pack")

var Lit_156 *jrt.String = jrt.Intern("-embedcfg")

var Lit_157 *jrt.String = jrt.Intern("/c/embedcfg")

var Lit_158 *jrt.String = jrt.Intern("-asmhdr")

var Lit_159 *jrt.String = jrt.Intern("/o/go_asm.h")

var Lit_160 *jrt.String = jrt.Intern("go")

var Lit_161 *jrt.String = jrt.Intern("future-call")

var Lit_162 *jrt.String = jrt.Intern("append-members")

var Lit_163 *jrt.String = jrt.Intern("re-matches")

var Lit_164 *jrt.String = jrt.Intern("[0-9a-f]{64}")

var Lit_165 *jrt.String = jrt.Intern("load")

var Lit_166 *jrt.String = jrt.Intern("plan")

var Lit_167 *jrt.String = jrt.Intern("link")

var Lit_168 *jrt.String = jrt.Intern("read-plan")

var Lit_169 *jrt.String = jrt.Intern("with-tools")

var Lit_170 *jrt.String = jrt.Intern("archives")

var Lit_171 *jrt.String = jrt.Intern("only")

var Lit_172 *jrt.String = jrt.Intern("jobs")

var Lit_173 *jrt.String = jrt.Intern("map-indexed")

var Lit_174 *jrt.String = jrt.Intern("build-package")

var Lit_175 *jrt.String = jrt.Intern("main")

var Lit_176 *jrt.String = jrt.Intern("ldflags")

var Lit_177 *jrt.String = jrt.Intern("-T")

var Lit_178 *jrt.String = jrt.Intern("0x201000")

var Lit_179 *jrt.String = jrt.Intern("-R")

var Lit_180 *jrt.String = jrt.Intern("0x1000")

var Lit_181 *jrt.String = jrt.Intern("-w")

var Lit_182 *jrt.String = jrt.Intern("build")

var Lit_183 *jrt.String = jrt.Intern("arbace.box.build$action")

var Lit_184 *jrt.String = jrt.Intern("arbace.box.build$action_STAR_")

var Lit_185 *jrt.String = jrt.Intern("arbace.box.build: ")

var Lit_186 *jrt.String = jrt.Intern(": ")

var Lit_187 *jrt.String = jrt.Intern("\n")

var Lit_188 *jrt.String = jrt.Intern("the guest faulted: ")

var Lit_189 *jrt.String = jrt.Intern("exit ")

var Lit_190 *jrt.String = jrt.Intern("%-8s %s%s")

var Lit_191 *jrt.String = jrt.Intern(" (cached)")

var Lit_192 *jrt.String = jrt.Intern(" %.2f s")

var Lit_193 *jrt.String = jrt.Intern("arbace.box.build$append_members")

var Lit_194 *jrt.String = jrt.Intern("arbace.box.build$ar_member")

var Lit_195 *jrt.String = jrt.Intern("`\n")

var Lit_196 *jrt.String = jrt.Intern("0")

var Lit_197 *jrt.String = jrt.Intern("644")

var Lit_198 *jrt.String = jrt.Intern("arbace.box.build$ar_member$pad__598000077")

var Lit_199 *jrt.String = jrt.Intern("arbace.box.build$arch_defines")

var Lit_200 *jrt.String = jrt.Intern("-D")

var Lit_201 *jrt.String = jrt.Intern("GOOS_")

var Lit_202 *jrt.String = jrt.Intern("GOARCH_")

var Lit_203 *jrt.String = jrt.Intern("amd64")

var Lit_204 *jrt.String = jrt.Intern("GOAMD64_")

var Lit_205 *jrt.String = jrt.Intern("arbace.box.build$archives")

var Lit_206 *jrt.String = jrt.Intern("arbace.box.build$archives$conveyed__598000244")

var Lit_207 *jrt.String = jrt.Intern("arbace.box.build$archives$conveyed__598000244$fn__598000245")

var Lit_208 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000242")

var Lit_209 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000252")

var Lit_210 *jrt.String = jrt.Intern("arbace.box.build: no archive given for ")

var Lit_211 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000254")

var Lit_212 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000254$fn__598000255")

var Lit_213 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000254$fn__598000255$fn__598000256")

var Lit_214 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000260")

var Lit_215 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000262")

var Lit_216 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000262$fn__598000263")

var Lit_217 *jrt.String = jrt.Intern("arbace.box.build$archives$fn__598000262$fn__598000263$fn__598000264")

var Lit_218 *jrt.String = jrt.Intern("arbace.box.build$archives$iter__598000268__598000272")

var Lit_219 *jrt.String = jrt.Intern("arbace.box.build$archives$iter__598000268__598000272$fn__598000273")

var Lit_220 *jrt.String = jrt.Intern("arbace.box.build$archives$iter__598000268__598000272$fn__598000273$fn__598000274")

var Lit_221 *jrt.String = jrt.Intern("arbace.box.build$asm_args")

var Lit_222 *jrt.String = jrt.Intern("-p")

var Lit_223 *jrt.String = jrt.Intern("-trimpath")

var Lit_224 *jrt.String = jrt.Intern("/s=>")

var Lit_225 *jrt.String = jrt.Intern(";/c=>")

var Lit_226 *jrt.String = jrt.Intern("-I")

var Lit_227 *jrt.String = jrt.Intern("/c/")

var Lit_228 *jrt.String = jrt.Intern("/i")

var Lit_229 *jrt.String = jrt.Intern("-o")

var Lit_230 *jrt.String = jrt.Intern("arbace.box.build$asm_args$fn__598000074")

var Lit_231 *jrt.String = jrt.Intern("arbace.box.build$build")

var Lit_232 *jrt.String = jrt.Intern("arbace.box.build$build$fn__598000301")

var Lit_233 *jrt.String = jrt.Intern("%s: %d packages, the image %s (%d bytes) in %.1f s")

var Lit_234 *jrt.String = jrt.Intern("arbace.box.build$build_package")

var Lit_235 *jrt.String = jrt.Intern("# import config\n")

var Lit_236 *jrt.String = jrt.Intern(" embeds files: plan it with arbace.box.plan")

var Lit_237 *jrt.String = jrt.Intern("symabis")

var Lit_238 *jrt.String = jrt.Intern("/o/symabis")

var Lit_239 *jrt.String = jrt.Intern("-gensymabis")

var Lit_240 *jrt.String = jrt.Intern("/c")

var Lit_241 *jrt.String = jrt.Intern("/o/_pkg_.a")

var Lit_242 *jrt.String = jrt.Intern(";/o=>;/c=>")

var Lit_243 *jrt.String = jrt.Intern("-lang=")

var Lit_244 *jrt.String = jrt.Intern("/d")

var Lit_245 *jrt.String = jrt.Intern("importcfg")

var Lit_246 *jrt.String = jrt.Intern("embedcfg")

var Lit_247 *jrt.String = jrt.Intern("_pkg_.a")

var Lit_248 *jrt.String = jrt.Intern("arbace.box.build$build_package$fn__598000179")

var Lit_249 *jrt.String = jrt.Intern("*")

var Lit_250 *jrt.String = jrt.Intern("arbace.box.build$build_package$fn__598000184")

var Lit_251 *jrt.String = jrt.Intern("./")

var Lit_252 *jrt.String = jrt.Intern("arbace.box.build$build_package$fn__598000186")

var Lit_253 *jrt.String = jrt.Intern("/s/")

var Lit_254 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000150__598000154")

var Lit_255 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000150__598000154$fn__598000155")

var Lit_256 *jrt.String = jrt.Intern("importmap ")

var Lit_257 *jrt.String = jrt.Intern("=")

var Lit_258 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000150__598000154$fn__598000155$fn__598000156")

var Lit_259 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000166__598000170")

var Lit_260 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000166__598000170$fn__598000171")

var Lit_261 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000166__598000170$fn__598000171$fn__598000172")

var Lit_262 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000189__598000193")

var Lit_263 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000189__598000193$fn__598000194")

var Lit_264 *jrt.String = jrt.Intern(".o")

var Lit_265 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000189__598000193$fn__598000194$fn__598000195")

var Lit_266 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000189__598000193$fn__598000194$fn__598000195$fn__598000196")

var Lit_267 *jrt.String = jrt.Intern("asm ")

var Lit_268 *jrt.String = jrt.Intern("/o/")

var Lit_269 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000189__598000193$fn__598000194$fn__598000199")

var Lit_270 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000203__598000207")

var Lit_271 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000203__598000207$fn__598000208")

var Lit_272 *jrt.String = jrt.Intern("arbace.box.build$build_package$iter__598000203__598000207$fn__598000208$fn__598000209")

var Lit_273 *jrt.String = jrt.Intern("arbace.box.build$build_package$res_of__598000176")

var Lit_274 *jrt.String = jrt.Intern(" ")

var Lit_275 *jrt.String = jrt.Intern("arbace.box.build$cache_ref")

var Lit_276 *jrt.String = jrt.Intern("ac.")

var Lit_277 *jrt.String = jrt.Intern("arbace.box.build$complete_QMARK_")

var Lit_278 *jrt.String = jrt.Intern("arbace.box.build$deps_tree")

var Lit_279 *jrt.String = jrt.Intern("arbace.box.build$deps_tree$iter__598000092__598000096")

var Lit_280 *jrt.String = jrt.Intern("arbace.box.build$deps_tree$iter__598000092__598000096$fn__598000097")

var Lit_281 *jrt.String = jrt.Intern(".a")

var Lit_282 *jrt.String = jrt.Intern("arbace.box.build$deps_tree$iter__598000092__598000096$fn__598000097$fn__598000098")

var Lit_283 *jrt.String = jrt.Intern("arbace.box.build$deps_tree$iter__598000102__598000106")

var Lit_284 *jrt.String = jrt.Intern("arbace.box.build$deps_tree$iter__598000102__598000106$fn__598000107")

var Lit_285 *jrt.String = jrt.Intern("packagefile ")

var Lit_286 *jrt.String = jrt.Intern("=/d/")

var Lit_287 *jrt.String = jrt.Intern("arbace.box.build$deps_tree$iter__598000102__598000106$fn__598000107$fn__598000108")

var Lit_288 *jrt.String = jrt.Intern("arbace.box.build$embed_config")

var Lit_289 *jrt.String = jrt.Intern("{\"Patterns\":{")

var Lit_290 *jrt.String = jrt.Intern("},\"Files\":{")

var Lit_291 *jrt.String = jrt.Intern("}}\n")

var Lit_292 *jrt.String = jrt.Intern(",")

var Lit_293 *jrt.String = jrt.Intern("arbace.box.build$embed_config$iter__598000116__598000120")

var Lit_294 *jrt.String = jrt.Intern("arbace.box.build$embed_config$iter__598000116__598000120$fn__598000121")

var Lit_295 *jrt.String = jrt.Intern(":[")

var Lit_296 *jrt.String = jrt.Intern("]")

var Lit_297 *jrt.String = jrt.Intern("arbace.box.build$embed_config$iter__598000116__598000120$fn__598000121$fn__598000122")

var Lit_298 *jrt.String = jrt.Intern("arbace.box.build$embed_config$iter__598000132__598000136")

var Lit_299 *jrt.String = jrt.Intern("arbace.box.build$embed_config$iter__598000132__598000136$fn__598000137")

var Lit_300 *jrt.String = jrt.Intern(":")

var Lit_301 *jrt.String = jrt.Intern("arbace.box.build$embed_config$iter__598000132__598000136$fn__598000137$fn__598000138")

var Lit_302 *jrt.String = jrt.Intern("arbace.box.build$eval598000004$loading__1927001464__auto____598000005")

var Lit_303 *jrt.String = jrt.Intern("java.io.ByteArrayOutputStream")

var Lit_304 *jrt.String = jrt.Intern("java.nio.charset.StandardCharsets")

var Lit_305 *jrt.String = jrt.Intern("java.security.MessageDigest")

var Lit_306 *jrt.String = jrt.Intern("arbace.box.build$eval598000008$fn__598000009")

var Lit_307 *jrt.String = jrt.Intern("arbace.box.build$fail")

var Lit_308 *jrt.String = jrt.Intern("arbace.box.build$file_tree")

var Lit_309 *jrt.String = jrt.Intern("arbace.box.build$file_tree$iter__598000054__598000058")

var Lit_310 *jrt.String = jrt.Intern("arbace.box.build$file_tree$iter__598000054__598000058$fn__598000059")

var Lit_311 *jrt.String = jrt.Intern("arbace.box.build$file_tree$iter__598000054__598000058$fn__598000059$fn__598000060")

var Lit_312 *jrt.String = jrt.Intern("arbace.box.build$import_plan")

var Lit_313 *jrt.String = jrt.Intern("/pkg/include")

var Lit_314 *jrt.String = jrt.Intern("/root/tamago-go")

var Lit_315 *jrt.String = jrt.Intern("arbace.box.build$import_plan$fn__598000044")

var Lit_316 *jrt.String = jrt.Intern("arbace.box.build$import_plan$fn__598000044$fn__598000045")

var Lit_317 *jrt.String = jrt.Intern("arbace.box.build$import_plan$src__598000042")

var Lit_318 *jrt.String = jrt.Intern("arbace.box.build$json_str")

var Lit_319 *jrt.String = jrt.Intern("\"")

var Lit_320 *jrt.String = jrt.Intern("arbace.box.build$json_str$fn__598000113")

var Lit_321 *jrt.String = jrt.Intern("\\\"")

var Lit_322 *jrt.String = jrt.Intern("\\\\")

var Lit_323 *jrt.String = jrt.Intern("\\u%04x")

var Lit_324 *jrt.String = jrt.Intern("arbace.box.build$link")

var Lit_325 *jrt.String = jrt.Intern(" link")

var Lit_326 *jrt.String = jrt.Intern("/d/")

var Lit_327 *jrt.String = jrt.Intern("importcfg.link")

var Lit_328 *jrt.String = jrt.Intern("a.out")

var Lit_329 *jrt.String = jrt.Intern("arbace.box.build$link$fn__598000285")

var Lit_330 *jrt.String = jrt.Intern("arbace.box.build$link$iter__598000290__598000294")

var Lit_331 *jrt.String = jrt.Intern("arbace.box.build$link$iter__598000290__598000294$fn__598000295")

var Lit_332 *jrt.String = jrt.Intern("arbace.box.build$link$iter__598000290__598000294$fn__598000295$fn__598000296")

var Lit_333 *jrt.String = jrt.Intern("arbace.box.build$log")

var Lit_334 *jrt.String = jrt.Intern("arbace.box.build$out_file")

var Lit_335 *jrt.String = jrt.Intern(": no ")

var Lit_336 *jrt.String = jrt.Intern(" in its output")

var Lit_337 *jrt.String = jrt.Intern("arbace.box.build$read_plan")

var Lit_338 *jrt.String = jrt.Intern("arbace.box.build: no plan ")

var Lit_339 *jrt.String = jrt.Intern("arbace.box.build$sha256_hex")

var Lit_340 *jrt.String = jrt.Intern("SHA-256")

var Lit_341 *jrt.String = jrt.Intern("arbace.box.build$source_tree")

var Lit_342 *jrt.String = jrt.Intern("arbace.box.build$source_tree$headers__598000018")

var Lit_343 *jrt.String = jrt.Intern("arbace.box.build$source_tree$headers__598000018$iter__598000019__598000023")

var Lit_344 *jrt.String = jrt.Intern("arbace.box.build$source_tree$headers__598000018$iter__598000019__598000023$fn__598000024")

var Lit_345 *jrt.String = jrt.Intern(".h")

var Lit_346 *jrt.String = jrt.Intern("arbace.box.build$source_tree$headers__598000018$iter__598000019__598000023$fn__598000024$fn__598000025")

var Lit_347 *jrt.String = jrt.Intern("arbace.box.build$source_tree$iter__598000030__598000034")

var Lit_348 *jrt.String = jrt.Intern("arbace.box.build$source_tree$iter__598000030__598000034$fn__598000035")

var Lit_349 *jrt.String = jrt.Intern("arbace.box.build$source_tree$iter__598000030__598000034$fn__598000035$fn__598000036")

var Lit_350 *jrt.String = jrt.Intern("arbace.box.build$with_tools")

var Lit_351 *jrt.String = jrt.Intern("arbace.box.build$with_tools$iter__598000221__598000225")

var Lit_352 *jrt.String = jrt.Intern("arbace.box.build$with_tools$iter__598000221__598000225$fn__598000226")

var Lit_353 *jrt.String = jrt.Intern("tool.")

var Lit_354 *jrt.String = jrt.Intern(".")

var Lit_355 *jrt.String = jrt.Intern("arbace.box.build$with_tools$iter__598000221__598000225$fn__598000226$fn__598000227")

var Lit_356 *jrt.String = jrt.Intern("in-ns")

var Lit_357 *jrt.String = jrt.Intern("private")

var Lit_358 *jrt.String = jrt.Intern("arglists")

var Lit_359 *jrt.String = jrt.Intern("msg")

var Lit_360 *jrt.String = jrt.Intern("data")

var Lit_361 *jrt.String = jrt.Intern("line")

var Lit_362 *jrt.String = jrt.Intern("column")

var Lit_363 *jrt.String = jrt.Intern("file")

var Lit_364 *jrt.String = jrt.Intern("arbace/box/build.ae")

var Lit_365 *jrt.String = jrt.Intern("tag")

var Lit_366 *jrt.String = jrt.Intern("String")

var Lit_367 *jrt.String = jrt.Intern("d")

var Lit_368 *jrt.String = jrt.Intern("java.io.File")

var Lit_369 *jrt.String = jrt.Intern("A package's directory as a tree: its files (not its subdirectories, other packages), and the\n  .h files of its subdirectories (an assembly file includes them by a relative path).")

var Lit_370 *jrt.String = jrt.Intern("goroot")

var Lit_371 *jrt.String = jrt.Intern("Stores the plan's sources as trees and the plan itself (see the namespace's doc): its hash.\n  goroot is the GOROOT whose pkg/include the assembly reads (by default /root/tamago-go).")

var Lit_372 *jrt.String = jrt.Intern("dynamic")

var Lit_373 *jrt.String = jrt.Intern("&")

var Lit_374 *jrt.String = jrt.Intern("xs")

var Lit_375 *jrt.String = jrt.Intern("req")

var Lit_376 *jrt.String = jrt.Intern("action")

var Lit_377 *jrt.String = jrt.Intern("opts")

var Lit_378 *jrt.String = jrt.Intern("Runs request req (or takes its result from the cache): its result. A result that is not\n  :exit 0 is an ex-info with the console. opts: the namespace's (:run, :cache, :log), by\n  default those of the build running.")

var Lit_379 *jrt.String = jrt.Intern("res")

var Lit_380 *jrt.String = jrt.Intern("The entry name of result res's output tree.")

var Lit_381 *jrt.String = jrt.Intern("m")

var Lit_382 *jrt.String = jrt.Intern("A tree of files given as {name string-or-bytes}.")

var Lit_383 *jrt.String = jrt.Intern("pkg")

var Lit_384 *jrt.String = jrt.Intern("more")

var Lit_385 *jrt.String = jrt.Intern("bytes")

var Lit_386 *jrt.String = jrt.Intern("archive")

var Lit_387 *jrt.String = jrt.Intern("members")

var Lit_388 *jrt.String = jrt.Intern("The standard packages with declarations the runtime supplies, which go build compiles without\n  -complete (cmd/go/internal/work/gc.go).")

var Lit_389 *jrt.String = jrt.Intern("Is the package's Go all of it (go build's -complete)?")

var Lit_390 *jrt.String = jrt.Intern("index")

var Lit_391 *jrt.String = jrt.Intern("paths")

var Lit_392 *jrt.String = jrt.Intern("The tree /d: the archives of the packages imports names, each <index>.a; and the\n  importcfg lines naming them.")

var Lit_393 *jrt.String = jrt.Intern("s as a JSON string.")

var Lit_394 *jrt.String = jrt.Intern("compile's -embedcfg for the patterns {PATTERN [FILE ...]} (files relative to the package's\n  directory, mounted at /s): JSON, the keys sorted.")

var Lit_395 *jrt.String = jrt.Intern("The package's archive: its tree entry [:file HASH SIZE].")

var Lit_396 *jrt.String = jrt.Intern("p")

var Lit_397 *jrt.String = jrt.Intern("opts with :tools complete: the refs tool.<tool>.<arch> for those it does not name.")

var Lit_398 *jrt.String = jrt.Intern("The archives of the plan's packages, built (see the namespace's doc): {path entry}, each\n  entry the archive's [:file HASH SIZE]. With :only (opts), a set of paths, only those are\n  built again, the others taken from :archives (opts).")

var Lit_399 *jrt.String = jrt.Intern("Links the plan's program from its archives ({path entry}, archives' answer): the image's\n  hash. The link's flags are :ldflags (opts; by default the box's guests': -T 0x201000 -R 0x1000\n  -w) after -buildmode=exe -buildid=.")

var Lit_400 *jrt.String = jrt.Intern("Builds the plan's program (see the namespace's doc): the image's hash.")
