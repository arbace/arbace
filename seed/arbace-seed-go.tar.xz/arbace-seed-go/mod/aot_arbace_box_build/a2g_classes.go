//line a2g_classes.ae:1
package aot_arbace_box_build

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_box_build_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_A_New()}; return nil }

var A_arbace_box_build_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_build_A_new}

var A_arbace_box_build_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_build.A_arbace_box_build_A"})

func init() { i := A_arbace_box_build_A_class.Info(); i.IsInstance = A_arbace_box_build_A_InstanceOf; i.Init = A_arbace_box_build_A_Init; i.Table = A_arbace_box_build_A_members; jrt.RegisterGoType(A_arbace_box_build_A_class, reflect.TypeFor[A_arbace_box_build_A]()) }

func A_arbace_box_build_action_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_action_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_box_build_action_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_build_action_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_action_A_New()}; return nil }

func A_arbace_box_build_action_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_action_A_fn_class)}; return nil }

var A_arbace_box_build_action_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_action_A_invoke, New: A_arbace_box_build_action_A_new, Get: A_arbace_box_build_action_A_get}

var A_arbace_box_build_action_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$action", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_build_A_class, Simple: "action", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_action_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_action_A_class.Info(); i.IsInstance = A_arbace_box_build_action_A_InstanceOf; i.Init = A_arbace_box_build_action_A_Init; i.Table = A_arbace_box_build_action_A_members; jrt.RegisterGoType(A_arbace_box_build_action_A_class, reflect.TypeFor[A_arbace_box_build_action_A]()) }

func A_arbace_box_build_action_STAR__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_action_STAR__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_action_STAR__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_action_STAR__A_New()}; return nil }

func A_arbace_box_build_action_STAR__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_action_STAR__A_fn_class)}; return nil }

var A_arbace_box_build_action_STAR__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_action_STAR__A_invoke, New: A_arbace_box_build_action_STAR__A_new, Get: A_arbace_box_build_action_STAR__A_get}

var A_arbace_box_build_action_STAR__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$action_STAR_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_build_A_class, Simple: "action_STAR_", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_action_STAR__A", Source: "build.ae"})

func init() { i := A_arbace_box_build_action_STAR__A_class.Info(); i.IsInstance = A_arbace_box_build_action_STAR__A_InstanceOf; i.Init = A_arbace_box_build_action_STAR__A_Init; i.Table = A_arbace_box_build_action_STAR__A_members; jrt.RegisterGoType(A_arbace_box_build_action_STAR__A_class, reflect.TypeFor[A_arbace_box_build_action_STAR__A]()) }

func A_arbace_box_build_append_members_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_append_members_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_append_members_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_append_members_A_New()}; return nil }

func A_arbace_box_build_append_members_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_append_members_A_fn_class)}; return nil }

var A_arbace_box_build_append_members_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_append_members_A_invoke, New: A_arbace_box_build_append_members_A_new, Get: A_arbace_box_build_append_members_A_get}

var A_arbace_box_build_append_members_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$append_members", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_build_A_class, Simple: "append_members", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_append_members_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_append_members_A_class.Info(); i.IsInstance = A_arbace_box_build_append_members_A_InstanceOf; i.Init = A_arbace_box_build_append_members_A_Init; i.Table = A_arbace_box_build_append_members_A_members; jrt.RegisterGoType(A_arbace_box_build_append_members_A_class, reflect.TypeFor[A_arbace_box_build_append_members_A]()) }

func A_arbace_box_build_ar_member_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_ar_member_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_ar_member_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_ar_member_A_New()}; return nil }

func A_arbace_box_build_ar_member_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_ar_member_A_fn_class)}; return nil }

var A_arbace_box_build_ar_member_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_ar_member_A_invoke, New: A_arbace_box_build_ar_member_A_new, Get: A_arbace_box_build_ar_member_A_get}

var A_arbace_box_build_ar_member_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$ar_member", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_build_A_class, Simple: "ar_member", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_ar_member_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_ar_member_A_class.Info(); i.IsInstance = A_arbace_box_build_ar_member_A_InstanceOf; i.Init = A_arbace_box_build_ar_member_A_Init; i.Table = A_arbace_box_build_ar_member_A_members; jrt.RegisterGoType(A_arbace_box_build_ar_member_A_class, reflect.TypeFor[A_arbace_box_build_ar_member_A]()) }

func A_arbace_box_build_ar_member_pad__598000077_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_ar_member_pad__598000077_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_ar_member_pad__598000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_ar_member_pad__598000077_A_New()}; return nil }

func A_arbace_box_build_ar_member_pad__598000077_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_ar_member_pad__598000077_A_fn_class)}; return nil }

var A_arbace_box_build_ar_member_pad__598000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_ar_member_pad__598000077_A_invoke, New: A_arbace_box_build_ar_member_pad__598000077_A_new, Get: A_arbace_box_build_ar_member_pad__598000077_A_get}

var A_arbace_box_build_ar_member_pad__598000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$ar_member$pad__598000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_build_ar_member_A_class, Simple: "pad__598000077", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_ar_member_pad__598000077_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_ar_member_pad__598000077_A_class.Info(); i.IsInstance = A_arbace_box_build_ar_member_pad__598000077_A_InstanceOf; i.Init = A_arbace_box_build_ar_member_pad__598000077_A_Init; i.Table = A_arbace_box_build_ar_member_pad__598000077_A_members; jrt.RegisterGoType(A_arbace_box_build_ar_member_pad__598000077_A_class, reflect.TypeFor[A_arbace_box_build_ar_member_pad__598000077_A]()) }

func A_arbace_box_build_arch_defines_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_arch_defines_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_arch_defines_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_arch_defines_A_New()}; return nil }

func A_arbace_box_build_arch_defines_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_arch_defines_A_fn_class)}; return nil }

var A_arbace_box_build_arch_defines_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_arch_defines_A_invoke, New: A_arbace_box_build_arch_defines_A_new, Get: A_arbace_box_build_arch_defines_A_get}

var A_arbace_box_build_arch_defines_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$arch_defines", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_A_class, Simple: "arch_defines", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_arch_defines_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_arch_defines_A_class.Info(); i.IsInstance = A_arbace_box_build_arch_defines_A_InstanceOf; i.Init = A_arbace_box_build_arch_defines_A_Init; i.Table = A_arbace_box_build_arch_defines_A_members; jrt.RegisterGoType(A_arbace_box_build_arch_defines_A_class, reflect.TypeFor[A_arbace_box_build_arch_defines_A]()) }

func A_arbace_box_build_archives_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_archives_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_archives_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_archives_A_New()}; return nil }

func A_arbace_box_build_archives_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_archives_A_fn_class)}; return nil }

var A_arbace_box_build_archives_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_archives_A_invoke, New: A_arbace_box_build_archives_A_new, Get: A_arbace_box_build_archives_A_get}

var A_arbace_box_build_archives_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$archives", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_build_A_class, Simple: "archives", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_archives_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_archives_A_class.Info(); i.IsInstance = A_arbace_box_build_archives_A_InstanceOf; i.Init = A_arbace_box_build_archives_A_Init; i.Table = A_arbace_box_build_archives_A_members; jrt.RegisterGoType(A_arbace_box_build_archives_A_class, reflect.TypeFor[A_arbace_box_build_archives_A]()) }

func A_arbace_box_build_archives_conveyed__598000244_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_archives_conveyed__598000244_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_archives_conveyed__598000244_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_archives_conveyed__598000244_A_New_O(args[0])}; return nil }

func A_arbace_box_build_archives_conveyed__598000244_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_archives_conveyed__598000244_A_fn_class)}; return nil }

var A_arbace_box_build_archives_conveyed__598000244_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_archives_conveyed__598000244_A_invoke, New: A_arbace_box_build_archives_conveyed__598000244_A_new, Get: A_arbace_box_build_archives_conveyed__598000244_A_get}

var A_arbace_box_build_archives_conveyed__598000244_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$archives$conveyed__598000244", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_archives_A_class, Simple: "conveyed__598000244", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_archives_conveyed__598000244_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_archives_conveyed__598000244_A_class.Info(); i.IsInstance = A_arbace_box_build_archives_conveyed__598000244_A_InstanceOf; i.Init = A_arbace_box_build_archives_conveyed__598000244_A_Init; i.Table = A_arbace_box_build_archives_conveyed__598000244_A_members; jrt.RegisterGoType(A_arbace_box_build_archives_conveyed__598000244_A_class, reflect.TypeFor[A_arbace_box_build_archives_conveyed__598000244_A]()) }

func A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_fn_class)}; return nil }

var A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_invoke, New: A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_new, Get: A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_get}

var A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$archives$conveyed__598000244$fn__598000245", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_archives_conveyed__598000244_A_class, Simple: "fn__598000245", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_class.Info(); i.IsInstance = A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_InstanceOf; i.Init = A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_Init; i.Table = A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_members; jrt.RegisterGoType(A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_class, reflect.TypeFor[A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A]()) }

func A_arbace_box_build_archives_fn__598000242_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_archives_fn__598000242_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_archives_fn__598000242_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_archives_fn__598000242_A_New()}; return nil }

func A_arbace_box_build_archives_fn__598000242_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_archives_fn__598000242_A_fn_class)}; return nil }

var A_arbace_box_build_archives_fn__598000242_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_archives_fn__598000242_A_invoke, New: A_arbace_box_build_archives_fn__598000242_A_new, Get: A_arbace_box_build_archives_fn__598000242_A_get}

var A_arbace_box_build_archives_fn__598000242_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$archives$fn__598000242", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_build_archives_A_class, Simple: "fn__598000242", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_archives_fn__598000242_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_archives_fn__598000242_A_class.Info(); i.IsInstance = A_arbace_box_build_archives_fn__598000242_A_InstanceOf; i.Init = A_arbace_box_build_archives_fn__598000242_A_Init; i.Table = A_arbace_box_build_archives_fn__598000242_A_members; jrt.RegisterGoType(A_arbace_box_build_archives_fn__598000242_A_class, reflect.TypeFor[A_arbace_box_build_archives_fn__598000242_A]()) }

func A_arbace_box_build_archives_fn__598000252_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_archives_fn__598000252_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_archives_fn__598000252_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_archives_fn__598000252_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_build_archives_fn__598000252_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_archives_fn__598000252_A_fn_class)}; return nil }

var A_arbace_box_build_archives_fn__598000252_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_archives_fn__598000252_A_invoke, New: A_arbace_box_build_archives_fn__598000252_A_new, Get: A_arbace_box_build_archives_fn__598000252_A_get}

var A_arbace_box_build_archives_fn__598000252_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$archives$fn__598000252", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_archives_A_class, Simple: "fn__598000252", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_archives_fn__598000252_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_archives_fn__598000252_A_class.Info(); i.IsInstance = A_arbace_box_build_archives_fn__598000252_A_InstanceOf; i.Init = A_arbace_box_build_archives_fn__598000252_A_Init; i.Table = A_arbace_box_build_archives_fn__598000252_A_members; jrt.RegisterGoType(A_arbace_box_build_archives_fn__598000252_A_class, reflect.TypeFor[A_arbace_box_build_archives_fn__598000252_A]()) }

func A_arbace_box_build_archives_fn__598000254_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_archives_fn__598000254_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_archives_fn__598000254_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_archives_fn__598000254_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_box_build_archives_fn__598000254_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_archives_fn__598000254_A_fn_class)}; return nil }

var A_arbace_box_build_archives_fn__598000254_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_archives_fn__598000254_A_invoke, New: A_arbace_box_build_archives_fn__598000254_A_new, Get: A_arbace_box_build_archives_fn__598000254_A_get}

var A_arbace_box_build_archives_fn__598000254_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$archives$fn__598000254", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_archives_A_class, Simple: "fn__598000254", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_archives_fn__598000254_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_archives_fn__598000254_A_class.Info(); i.IsInstance = A_arbace_box_build_archives_fn__598000254_A_InstanceOf; i.Init = A_arbace_box_build_archives_fn__598000254_A_Init; i.Table = A_arbace_box_build_archives_fn__598000254_A_members; jrt.RegisterGoType(A_arbace_box_build_archives_fn__598000254_A_class, reflect.TypeFor[A_arbace_box_build_archives_fn__598000254_A]()) }

func A_arbace_box_build_archives_fn__598000254_fn__598000255_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_archives_fn__598000254_fn__598000255_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_archives_fn__598000254_fn__598000255_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_archives_fn__598000254_fn__598000255_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_box_build_archives_fn__598000254_fn__598000255_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_archives_fn__598000254_fn__598000255_A_fn_class)}; return nil }

var A_arbace_box_build_archives_fn__598000254_fn__598000255_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_archives_fn__598000254_fn__598000255_A_invoke, New: A_arbace_box_build_archives_fn__598000254_fn__598000255_A_new, Get: A_arbace_box_build_archives_fn__598000254_fn__598000255_A_get}

var A_arbace_box_build_archives_fn__598000254_fn__598000255_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$archives$fn__598000254$fn__598000255", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_archives_fn__598000254_A_class, Simple: "fn__598000255", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_archives_fn__598000254_fn__598000255_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_archives_fn__598000254_fn__598000255_A_class.Info(); i.IsInstance = A_arbace_box_build_archives_fn__598000254_fn__598000255_A_InstanceOf; i.Init = A_arbace_box_build_archives_fn__598000254_fn__598000255_A_Init; i.Table = A_arbace_box_build_archives_fn__598000254_fn__598000255_A_members; jrt.RegisterGoType(A_arbace_box_build_archives_fn__598000254_fn__598000255_A_class, reflect.TypeFor[A_arbace_box_build_archives_fn__598000254_fn__598000255_A]()) }

func A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_New()}; return nil }

func A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_fn_class)}; return nil }

var A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_invoke, New: A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_new, Get: A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_get}

var A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$archives$fn__598000254$fn__598000255$fn__598000256", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_build_archives_fn__598000254_fn__598000255_A_class, Simple: "fn__598000256", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_class.Info(); i.IsInstance = A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_InstanceOf; i.Init = A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_Init; i.Table = A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_members; jrt.RegisterGoType(A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_class, reflect.TypeFor[A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A]()) }

func A_arbace_box_build_archives_fn__598000260_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_archives_fn__598000260_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_archives_fn__598000260_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_archives_fn__598000260_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_build_archives_fn__598000260_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_archives_fn__598000260_A_fn_class)}; return nil }

var A_arbace_box_build_archives_fn__598000260_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_archives_fn__598000260_A_invoke, New: A_arbace_box_build_archives_fn__598000260_A_new, Get: A_arbace_box_build_archives_fn__598000260_A_get}

var A_arbace_box_build_archives_fn__598000260_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$archives$fn__598000260", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_archives_A_class, Simple: "fn__598000260", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_archives_fn__598000260_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_archives_fn__598000260_A_class.Info(); i.IsInstance = A_arbace_box_build_archives_fn__598000260_A_InstanceOf; i.Init = A_arbace_box_build_archives_fn__598000260_A_Init; i.Table = A_arbace_box_build_archives_fn__598000260_A_members; jrt.RegisterGoType(A_arbace_box_build_archives_fn__598000260_A_class, reflect.TypeFor[A_arbace_box_build_archives_fn__598000260_A]()) }

func A_arbace_box_build_archives_fn__598000262_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_archives_fn__598000262_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_archives_fn__598000262_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_archives_fn__598000262_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_box_build_archives_fn__598000262_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_archives_fn__598000262_A_fn_class)}; return nil }

var A_arbace_box_build_archives_fn__598000262_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_archives_fn__598000262_A_invoke, New: A_arbace_box_build_archives_fn__598000262_A_new, Get: A_arbace_box_build_archives_fn__598000262_A_get}

var A_arbace_box_build_archives_fn__598000262_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$archives$fn__598000262", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_archives_A_class, Simple: "fn__598000262", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_archives_fn__598000262_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_archives_fn__598000262_A_class.Info(); i.IsInstance = A_arbace_box_build_archives_fn__598000262_A_InstanceOf; i.Init = A_arbace_box_build_archives_fn__598000262_A_Init; i.Table = A_arbace_box_build_archives_fn__598000262_A_members; jrt.RegisterGoType(A_arbace_box_build_archives_fn__598000262_A_class, reflect.TypeFor[A_arbace_box_build_archives_fn__598000262_A]()) }

func A_arbace_box_build_archives_fn__598000262_fn__598000263_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_archives_fn__598000262_fn__598000263_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_archives_fn__598000262_fn__598000263_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_archives_fn__598000262_fn__598000263_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_box_build_archives_fn__598000262_fn__598000263_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_archives_fn__598000262_fn__598000263_A_fn_class)}; return nil }

var A_arbace_box_build_archives_fn__598000262_fn__598000263_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_archives_fn__598000262_fn__598000263_A_invoke, New: A_arbace_box_build_archives_fn__598000262_fn__598000263_A_new, Get: A_arbace_box_build_archives_fn__598000262_fn__598000263_A_get}

var A_arbace_box_build_archives_fn__598000262_fn__598000263_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$archives$fn__598000262$fn__598000263", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_archives_fn__598000262_A_class, Simple: "fn__598000263", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_archives_fn__598000262_fn__598000263_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_archives_fn__598000262_fn__598000263_A_class.Info(); i.IsInstance = A_arbace_box_build_archives_fn__598000262_fn__598000263_A_InstanceOf; i.Init = A_arbace_box_build_archives_fn__598000262_fn__598000263_A_Init; i.Table = A_arbace_box_build_archives_fn__598000262_fn__598000263_A_members; jrt.RegisterGoType(A_arbace_box_build_archives_fn__598000262_fn__598000263_A_class, reflect.TypeFor[A_arbace_box_build_archives_fn__598000262_fn__598000263_A]()) }

func A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_New()}; return nil }

func A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_fn_class)}; return nil }

var A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_invoke, New: A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_new, Get: A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_get}

var A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$archives$fn__598000262$fn__598000263$fn__598000264", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_build_archives_fn__598000262_fn__598000263_A_class, Simple: "fn__598000264", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_class.Info(); i.IsInstance = A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_InstanceOf; i.Init = A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_Init; i.Table = A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_members; jrt.RegisterGoType(A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_class, reflect.TypeFor[A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A]()) }

func A_arbace_box_build_archives_iter__598000268__598000272_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_archives_iter__598000268__598000272_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_archives_iter__598000268__598000272_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_archives_iter__598000268__598000272_A_New()}; return nil }

func A_arbace_box_build_archives_iter__598000268__598000272_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_archives_iter__598000268__598000272_A_fn_class)}; return nil }

var A_arbace_box_build_archives_iter__598000268__598000272_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_archives_iter__598000268__598000272_A_invoke, New: A_arbace_box_build_archives_iter__598000268__598000272_A_new, Get: A_arbace_box_build_archives_iter__598000268__598000272_A_get}

var A_arbace_box_build_archives_iter__598000268__598000272_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$archives$iter__598000268__598000272", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_archives_A_class, Simple: "iter__598000268__598000272", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_archives_iter__598000268__598000272_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_archives_iter__598000268__598000272_A_class.Info(); i.IsInstance = A_arbace_box_build_archives_iter__598000268__598000272_A_InstanceOf; i.Init = A_arbace_box_build_archives_iter__598000268__598000272_A_Init; i.Table = A_arbace_box_build_archives_iter__598000268__598000272_A_members; jrt.RegisterGoType(A_arbace_box_build_archives_iter__598000268__598000272_A_class, reflect.TypeFor[A_arbace_box_build_archives_iter__598000268__598000272_A]()) }

func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_fn_class)}; return nil }

var A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_invoke, New: A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_new, Get: A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_get}

var A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$archives$iter__598000268__598000272$fn__598000273", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_archives_iter__598000268__598000272_A_class, Simple: "fn__598000273", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_class.Info(); i.IsInstance = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_InstanceOf; i.Init = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_Init; i.Table = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_members; jrt.RegisterGoType(A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_class, reflect.TypeFor[A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A]()) }

func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_fn_class)}; return nil }

var A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_invoke, New: A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_new, Get: A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_get}

var A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$archives$iter__598000268__598000272$fn__598000273$fn__598000274", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_class, Simple: "fn__598000274", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_class.Info(); i.IsInstance = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_InstanceOf; i.Init = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_Init; i.Table = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_members; jrt.RegisterGoType(A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_class, reflect.TypeFor[A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A]()) }

func A_arbace_box_build_asm_args_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_asm_args_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_box_build_asm_args_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_asm_args_A_New()}; return nil }

func A_arbace_box_build_asm_args_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_asm_args_A_fn_class)}; return nil }

var A_arbace_box_build_asm_args_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_asm_args_A_invoke, New: A_arbace_box_build_asm_args_A_new, Get: A_arbace_box_build_asm_args_A_get}

var A_arbace_box_build_asm_args_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$asm_args", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_box_build_A_class, Simple: "asm_args", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_asm_args_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_asm_args_A_class.Info(); i.IsInstance = A_arbace_box_build_asm_args_A_InstanceOf; i.Init = A_arbace_box_build_asm_args_A_Init; i.Table = A_arbace_box_build_asm_args_A_members; jrt.RegisterGoType(A_arbace_box_build_asm_args_A_class, reflect.TypeFor[A_arbace_box_build_asm_args_A]()) }

func A_arbace_box_build_asm_args_fn__598000074_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_asm_args_fn__598000074_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_asm_args_fn__598000074_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_asm_args_fn__598000074_A_New_O(args[0])}; return nil }

func A_arbace_box_build_asm_args_fn__598000074_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_asm_args_fn__598000074_A_fn_class)}; return nil }

var A_arbace_box_build_asm_args_fn__598000074_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_asm_args_fn__598000074_A_invoke, New: A_arbace_box_build_asm_args_fn__598000074_A_new, Get: A_arbace_box_build_asm_args_fn__598000074_A_get}

var A_arbace_box_build_asm_args_fn__598000074_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$asm_args$fn__598000074", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_asm_args_A_class, Simple: "fn__598000074", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_asm_args_fn__598000074_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_asm_args_fn__598000074_A_class.Info(); i.IsInstance = A_arbace_box_build_asm_args_fn__598000074_A_InstanceOf; i.Init = A_arbace_box_build_asm_args_fn__598000074_A_Init; i.Table = A_arbace_box_build_asm_args_fn__598000074_A_members; jrt.RegisterGoType(A_arbace_box_build_asm_args_fn__598000074_A_class, reflect.TypeFor[A_arbace_box_build_asm_args_fn__598000074_A]()) }

func A_arbace_box_build_build_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_box_build_build_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_build_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_A_New()}; return nil }

func A_arbace_box_build_build_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_A_fn_class)}; return nil }

var A_arbace_box_build_build_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_A_invoke, New: A_arbace_box_build_build_A_new, Get: A_arbace_box_build_build_A_get}

var A_arbace_box_build_build_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_A_class, Simple: "build", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_A_class.Info(); i.IsInstance = A_arbace_box_build_build_A_InstanceOf; i.Init = A_arbace_box_build_build_A_Init; i.Table = A_arbace_box_build_build_A_members; jrt.RegisterGoType(A_arbace_box_build_build_A_class, reflect.TypeFor[A_arbace_box_build_build_A]()) }

func A_arbace_box_build_build_fn__598000301_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_fn__598000301_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_build_fn__598000301_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_fn__598000301_A_New_O_O_J(args[0], args[1], args[2].(int64))}; return nil }

func A_arbace_box_build_build_fn__598000301_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_fn__598000301_A_fn_class)}; return nil }

var A_arbace_box_build_build_fn__598000301_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;J)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_fn__598000301_A_invoke, New: A_arbace_box_build_build_fn__598000301_A_new, Get: A_arbace_box_build_build_fn__598000301_A_get}

var A_arbace_box_build_build_fn__598000301_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build$fn__598000301", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_build_A_class, Simple: "fn__598000301", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_fn__598000301_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_fn__598000301_A_class.Info(); i.IsInstance = A_arbace_box_build_build_fn__598000301_A_InstanceOf; i.Init = A_arbace_box_build_build_fn__598000301_A_Init; i.Table = A_arbace_box_build_build_fn__598000301_A_members; jrt.RegisterGoType(A_arbace_box_build_build_fn__598000301_A_class, reflect.TypeFor[A_arbace_box_build_build_fn__598000301_A]()) }

func A_arbace_box_build_build_package_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_box_build_build_package_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_A_New()}; return nil }

func A_arbace_box_build_build_package_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_A_invoke, New: A_arbace_box_build_build_package_A_new, Get: A_arbace_box_build_build_package_A_get}

var A_arbace_box_build_build_package_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_box_build_A_class, Simple: "build_package", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_A_InstanceOf; i.Init = A_arbace_box_build_build_package_A_Init; i.Table = A_arbace_box_build_build_package_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_A_class, reflect.TypeFor[A_arbace_box_build_build_package_A]()) }

func A_arbace_box_build_build_package_fn__598000179_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_fn__598000179_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_build_package_fn__598000179_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_fn__598000179_A_New_O(args[0])}; return nil }

func A_arbace_box_build_build_package_fn__598000179_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_fn__598000179_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_fn__598000179_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_fn__598000179_A_invoke, New: A_arbace_box_build_build_package_fn__598000179_A_new, Get: A_arbace_box_build_build_package_fn__598000179_A_get}

var A_arbace_box_build_build_package_fn__598000179_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$fn__598000179", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_build_package_A_class, Simple: "fn__598000179", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_fn__598000179_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_fn__598000179_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_fn__598000179_A_InstanceOf; i.Init = A_arbace_box_build_build_package_fn__598000179_A_Init; i.Table = A_arbace_box_build_build_package_fn__598000179_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_fn__598000179_A_class, reflect.TypeFor[A_arbace_box_build_build_package_fn__598000179_A]()) }

func A_arbace_box_build_build_package_fn__598000184_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_fn__598000184_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_build_package_fn__598000184_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_fn__598000184_A_New()}; return nil }

func A_arbace_box_build_build_package_fn__598000184_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_fn__598000184_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_fn__598000184_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_fn__598000184_A_invoke, New: A_arbace_box_build_build_package_fn__598000184_A_new, Get: A_arbace_box_build_build_package_fn__598000184_A_get}

var A_arbace_box_build_build_package_fn__598000184_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$fn__598000184", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_build_package_A_class, Simple: "fn__598000184", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_fn__598000184_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_fn__598000184_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_fn__598000184_A_InstanceOf; i.Init = A_arbace_box_build_build_package_fn__598000184_A_Init; i.Table = A_arbace_box_build_build_package_fn__598000184_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_fn__598000184_A_class, reflect.TypeFor[A_arbace_box_build_build_package_fn__598000184_A]()) }

func A_arbace_box_build_build_package_fn__598000186_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_fn__598000186_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_build_package_fn__598000186_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_fn__598000186_A_New()}; return nil }

func A_arbace_box_build_build_package_fn__598000186_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_fn__598000186_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_fn__598000186_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_fn__598000186_A_invoke, New: A_arbace_box_build_build_package_fn__598000186_A_new, Get: A_arbace_box_build_build_package_fn__598000186_A_get}

var A_arbace_box_build_build_package_fn__598000186_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$fn__598000186", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_build_package_A_class, Simple: "fn__598000186", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_fn__598000186_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_fn__598000186_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_fn__598000186_A_InstanceOf; i.Init = A_arbace_box_build_build_package_fn__598000186_A_Init; i.Table = A_arbace_box_build_build_package_fn__598000186_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_fn__598000186_A_class, reflect.TypeFor[A_arbace_box_build_build_package_fn__598000186_A]()) }

func A_arbace_box_build_build_package_iter__598000150__598000154_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_iter__598000150__598000154_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_build_package_iter__598000150__598000154_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_iter__598000150__598000154_A_New()}; return nil }

func A_arbace_box_build_build_package_iter__598000150__598000154_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_iter__598000150__598000154_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_iter__598000150__598000154_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_iter__598000150__598000154_A_invoke, New: A_arbace_box_build_build_package_iter__598000150__598000154_A_new, Get: A_arbace_box_build_build_package_iter__598000150__598000154_A_get}

var A_arbace_box_build_build_package_iter__598000150__598000154_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$iter__598000150__598000154", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_build_package_A_class, Simple: "iter__598000150__598000154", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_iter__598000150__598000154_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_iter__598000150__598000154_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_iter__598000150__598000154_A_InstanceOf; i.Init = A_arbace_box_build_build_package_iter__598000150__598000154_A_Init; i.Table = A_arbace_box_build_build_package_iter__598000150__598000154_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_iter__598000150__598000154_A_class, reflect.TypeFor[A_arbace_box_build_build_package_iter__598000150__598000154_A]()) }

func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_invoke, New: A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_new, Get: A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_get}

var A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$iter__598000150__598000154$fn__598000155", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_build_package_iter__598000150__598000154_A_class, Simple: "fn__598000155", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_InstanceOf; i.Init = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_Init; i.Table = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_class, reflect.TypeFor[A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A]()) }

func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_invoke, New: A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_new, Get: A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_get}

var A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$iter__598000150__598000154$fn__598000155$fn__598000156", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_class, Simple: "fn__598000156", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_InstanceOf; i.Init = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_Init; i.Table = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_class, reflect.TypeFor[A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A]()) }

func A_arbace_box_build_build_package_iter__598000166__598000170_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_iter__598000166__598000170_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_build_package_iter__598000166__598000170_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_iter__598000166__598000170_A_New()}; return nil }

func A_arbace_box_build_build_package_iter__598000166__598000170_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_iter__598000166__598000170_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_iter__598000166__598000170_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_iter__598000166__598000170_A_invoke, New: A_arbace_box_build_build_package_iter__598000166__598000170_A_new, Get: A_arbace_box_build_build_package_iter__598000166__598000170_A_get}

var A_arbace_box_build_build_package_iter__598000166__598000170_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$iter__598000166__598000170", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_build_package_A_class, Simple: "iter__598000166__598000170", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_iter__598000166__598000170_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_iter__598000166__598000170_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_iter__598000166__598000170_A_InstanceOf; i.Init = A_arbace_box_build_build_package_iter__598000166__598000170_A_Init; i.Table = A_arbace_box_build_build_package_iter__598000166__598000170_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_iter__598000166__598000170_A_class, reflect.TypeFor[A_arbace_box_build_build_package_iter__598000166__598000170_A]()) }

func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_invoke, New: A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_new, Get: A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_get}

var A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$iter__598000166__598000170$fn__598000171", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_build_package_iter__598000166__598000170_A_class, Simple: "fn__598000171", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_InstanceOf; i.Init = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_Init; i.Table = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_class, reflect.TypeFor[A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A]()) }

func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_invoke, New: A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_new, Get: A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_get}

var A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$iter__598000166__598000170$fn__598000171$fn__598000172", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_class, Simple: "fn__598000172", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_InstanceOf; i.Init = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_Init; i.Table = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_class, reflect.TypeFor[A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A]()) }

func A_arbace_box_build_build_package_iter__598000189__598000193_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_iter__598000189__598000193_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_build_package_iter__598000189__598000193_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_iter__598000189__598000193_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_box_build_build_package_iter__598000189__598000193_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_iter__598000189__598000193_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_iter__598000189__598000193_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_iter__598000189__598000193_A_invoke, New: A_arbace_box_build_build_package_iter__598000189__598000193_A_new, Get: A_arbace_box_build_build_package_iter__598000189__598000193_A_get}

var A_arbace_box_build_build_package_iter__598000189__598000193_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$iter__598000189__598000193", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_build_package_A_class, Simple: "iter__598000189__598000193", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_iter__598000189__598000193_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_iter__598000189__598000193_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_iter__598000189__598000193_A_InstanceOf; i.Init = A_arbace_box_build_build_package_iter__598000189__598000193_A_Init; i.Table = A_arbace_box_build_build_package_iter__598000189__598000193_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_iter__598000189__598000193_A_class, reflect.TypeFor[A_arbace_box_build_build_package_iter__598000189__598000193_A]()) }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_New_O_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7])}; return nil }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_invoke, New: A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_new, Get: A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_get}

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$iter__598000189__598000193$fn__598000194", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_build_package_iter__598000189__598000193_A_class, Simple: "fn__598000194", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_InstanceOf; i.Init = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_Init; i.Table = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_class, reflect.TypeFor[A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A]()) }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_New_O_O_O_O_O_O_O_I_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7].(int32), args[8])}; return nil }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_invoke, New: A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_new, Get: A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_get}

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$iter__598000189__598000193$fn__598000194$fn__598000195", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_class, Simple: "fn__598000195", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_InstanceOf; i.Init = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_Init; i.Table = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_class, reflect.TypeFor[A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A]()) }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_New_O_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7])}; return nil }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_invoke, New: A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_new, Get: A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_get}

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$iter__598000189__598000193$fn__598000194$fn__598000195$fn__598000196", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_class, Simple: "fn__598000196", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_InstanceOf; i.Init = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_Init; i.Table = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_class, reflect.TypeFor[A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A]()) }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_New_O_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7])}; return nil }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_invoke, New: A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_new, Get: A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_get}

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$iter__598000189__598000193$fn__598000194$fn__598000199", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_class, Simple: "fn__598000199", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_InstanceOf; i.Init = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_Init; i.Table = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_class, reflect.TypeFor[A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A]()) }

func A_arbace_box_build_build_package_iter__598000203__598000207_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_iter__598000203__598000207_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_build_package_iter__598000203__598000207_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_iter__598000203__598000207_A_New()}; return nil }

func A_arbace_box_build_build_package_iter__598000203__598000207_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_iter__598000203__598000207_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_iter__598000203__598000207_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_iter__598000203__598000207_A_invoke, New: A_arbace_box_build_build_package_iter__598000203__598000207_A_new, Get: A_arbace_box_build_build_package_iter__598000203__598000207_A_get}

var A_arbace_box_build_build_package_iter__598000203__598000207_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$iter__598000203__598000207", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_build_package_A_class, Simple: "iter__598000203__598000207", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_iter__598000203__598000207_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_iter__598000203__598000207_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_iter__598000203__598000207_A_InstanceOf; i.Init = A_arbace_box_build_build_package_iter__598000203__598000207_A_Init; i.Table = A_arbace_box_build_build_package_iter__598000203__598000207_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_iter__598000203__598000207_A_class, reflect.TypeFor[A_arbace_box_build_build_package_iter__598000203__598000207_A]()) }

func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_invoke, New: A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_new, Get: A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_get}

var A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$iter__598000203__598000207$fn__598000208", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_build_package_iter__598000203__598000207_A_class, Simple: "fn__598000208", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_InstanceOf; i.Init = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_Init; i.Table = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_class, reflect.TypeFor[A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A]()) }

func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_invoke, New: A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_new, Get: A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_get}

var A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$iter__598000203__598000207$fn__598000208$fn__598000209", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_class, Simple: "fn__598000209", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_InstanceOf; i.Init = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_Init; i.Table = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_class, reflect.TypeFor[A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A]()) }

func A_arbace_box_build_build_package_res_of__598000176_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_build_package_res_of__598000176_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_build_package_res_of__598000176_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_build_package_res_of__598000176_A_New_O(args[0])}; return nil }

func A_arbace_box_build_build_package_res_of__598000176_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_build_package_res_of__598000176_A_fn_class)}; return nil }

var A_arbace_box_build_build_package_res_of__598000176_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_build_package_res_of__598000176_A_invoke, New: A_arbace_box_build_build_package_res_of__598000176_A_new, Get: A_arbace_box_build_build_package_res_of__598000176_A_get}

var A_arbace_box_build_build_package_res_of__598000176_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$build_package$res_of__598000176", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_build_build_package_A_class, Simple: "res_of__598000176", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_build_package_res_of__598000176_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_build_package_res_of__598000176_A_class.Info(); i.IsInstance = A_arbace_box_build_build_package_res_of__598000176_A_InstanceOf; i.Init = A_arbace_box_build_build_package_res_of__598000176_A_Init; i.Table = A_arbace_box_build_build_package_res_of__598000176_A_members; jrt.RegisterGoType(A_arbace_box_build_build_package_res_of__598000176_A_class, reflect.TypeFor[A_arbace_box_build_build_package_res_of__598000176_A]()) }

func A_arbace_box_build_cache_ref_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_cache_ref_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_cache_ref_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_cache_ref_A_New()}; return nil }

func A_arbace_box_build_cache_ref_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_cache_ref_A_fn_class)}; return nil }

var A_arbace_box_build_cache_ref_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_cache_ref_A_invoke, New: A_arbace_box_build_cache_ref_A_new, Get: A_arbace_box_build_cache_ref_A_get}

var A_arbace_box_build_cache_ref_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$cache_ref", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_A_class, Simple: "cache_ref", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_cache_ref_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_cache_ref_A_class.Info(); i.IsInstance = A_arbace_box_build_cache_ref_A_InstanceOf; i.Init = A_arbace_box_build_cache_ref_A_Init; i.Table = A_arbace_box_build_cache_ref_A_members; jrt.RegisterGoType(A_arbace_box_build_cache_ref_A_class, reflect.TypeFor[A_arbace_box_build_cache_ref_A]()) }

func A_arbace_box_build_complete_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_complete_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_complete_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_complete_QMARK__A_New()}; return nil }

func A_arbace_box_build_complete_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_complete_QMARK__A_fn_class)}; return nil }

var A_arbace_box_build_complete_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_complete_QMARK__A_invoke, New: A_arbace_box_build_complete_QMARK__A_new, Get: A_arbace_box_build_complete_QMARK__A_get}

var A_arbace_box_build_complete_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$complete_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_A_class, Simple: "complete_QMARK_", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_complete_QMARK__A", Source: "build.ae"})

func init() { i := A_arbace_box_build_complete_QMARK__A_class.Info(); i.IsInstance = A_arbace_box_build_complete_QMARK__A_InstanceOf; i.Init = A_arbace_box_build_complete_QMARK__A_Init; i.Table = A_arbace_box_build_complete_QMARK__A_members; jrt.RegisterGoType(A_arbace_box_build_complete_QMARK__A_class, reflect.TypeFor[A_arbace_box_build_complete_QMARK__A]()) }

func A_arbace_box_build_deps_tree_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_deps_tree_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_build_deps_tree_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_deps_tree_A_New()}; return nil }

func A_arbace_box_build_deps_tree_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_deps_tree_A_fn_class)}; return nil }

var A_arbace_box_build_deps_tree_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_deps_tree_A_invoke, New: A_arbace_box_build_deps_tree_A_new, Get: A_arbace_box_build_deps_tree_A_get}

var A_arbace_box_build_deps_tree_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$deps_tree", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_box_build_A_class, Simple: "deps_tree", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_deps_tree_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_deps_tree_A_class.Info(); i.IsInstance = A_arbace_box_build_deps_tree_A_InstanceOf; i.Init = A_arbace_box_build_deps_tree_A_Init; i.Table = A_arbace_box_build_deps_tree_A_members; jrt.RegisterGoType(A_arbace_box_build_deps_tree_A_class, reflect.TypeFor[A_arbace_box_build_deps_tree_A]()) }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_deps_tree_iter__598000092__598000096_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_deps_tree_iter__598000092__598000096_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_deps_tree_iter__598000092__598000096_A_fn_class)}; return nil }

var A_arbace_box_build_deps_tree_iter__598000092__598000096_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_deps_tree_iter__598000092__598000096_A_invoke, New: A_arbace_box_build_deps_tree_iter__598000092__598000096_A_new, Get: A_arbace_box_build_deps_tree_iter__598000092__598000096_A_get}

var A_arbace_box_build_deps_tree_iter__598000092__598000096_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$deps_tree$iter__598000092__598000096", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_deps_tree_A_class, Simple: "iter__598000092__598000096", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_deps_tree_iter__598000092__598000096_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_deps_tree_iter__598000092__598000096_A_class.Info(); i.IsInstance = A_arbace_box_build_deps_tree_iter__598000092__598000096_A_InstanceOf; i.Init = A_arbace_box_build_deps_tree_iter__598000092__598000096_A_Init; i.Table = A_arbace_box_build_deps_tree_iter__598000092__598000096_A_members; jrt.RegisterGoType(A_arbace_box_build_deps_tree_iter__598000092__598000096_A_class, reflect.TypeFor[A_arbace_box_build_deps_tree_iter__598000092__598000096_A]()) }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_fn_class)}; return nil }

var A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_invoke, New: A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_new, Get: A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_get}

var A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$deps_tree$iter__598000092__598000096$fn__598000097", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_deps_tree_iter__598000092__598000096_A_class, Simple: "fn__598000097", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_class.Info(); i.IsInstance = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_InstanceOf; i.Init = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_Init; i.Table = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_members; jrt.RegisterGoType(A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_class, reflect.TypeFor[A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A]()) }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_fn_class)}; return nil }

var A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_invoke, New: A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_new, Get: A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_get}

var A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$deps_tree$iter__598000092__598000096$fn__598000097$fn__598000098", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_class, Simple: "fn__598000098", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_class.Info(); i.IsInstance = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_InstanceOf; i.Init = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_Init; i.Table = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_members; jrt.RegisterGoType(A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_class, reflect.TypeFor[A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A]()) }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_deps_tree_iter__598000102__598000106_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_deps_tree_iter__598000102__598000106_A_New_O(args[0])}; return nil }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_deps_tree_iter__598000102__598000106_A_fn_class)}; return nil }

var A_arbace_box_build_deps_tree_iter__598000102__598000106_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_deps_tree_iter__598000102__598000106_A_invoke, New: A_arbace_box_build_deps_tree_iter__598000102__598000106_A_new, Get: A_arbace_box_build_deps_tree_iter__598000102__598000106_A_get}

var A_arbace_box_build_deps_tree_iter__598000102__598000106_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$deps_tree$iter__598000102__598000106", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_deps_tree_A_class, Simple: "iter__598000102__598000106", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_deps_tree_iter__598000102__598000106_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_deps_tree_iter__598000102__598000106_A_class.Info(); i.IsInstance = A_arbace_box_build_deps_tree_iter__598000102__598000106_A_InstanceOf; i.Init = A_arbace_box_build_deps_tree_iter__598000102__598000106_A_Init; i.Table = A_arbace_box_build_deps_tree_iter__598000102__598000106_A_members; jrt.RegisterGoType(A_arbace_box_build_deps_tree_iter__598000102__598000106_A_class, reflect.TypeFor[A_arbace_box_build_deps_tree_iter__598000102__598000106_A]()) }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_fn_class)}; return nil }

var A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_invoke, New: A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_new, Get: A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_get}

var A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$deps_tree$iter__598000102__598000106$fn__598000107", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_deps_tree_iter__598000102__598000106_A_class, Simple: "fn__598000107", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_class.Info(); i.IsInstance = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_InstanceOf; i.Init = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_Init; i.Table = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_members; jrt.RegisterGoType(A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_class, reflect.TypeFor[A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A]()) }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_fn_class)}; return nil }

var A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_invoke, New: A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_new, Get: A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_get}

var A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$deps_tree$iter__598000102__598000106$fn__598000107$fn__598000108", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_class, Simple: "fn__598000108", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_class.Info(); i.IsInstance = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_InstanceOf; i.Init = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_Init; i.Table = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_members; jrt.RegisterGoType(A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_class, reflect.TypeFor[A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A]()) }

func A_arbace_box_build_embed_config_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_embed_config_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_embed_config_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_embed_config_A_New()}; return nil }

func A_arbace_box_build_embed_config_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_embed_config_A_fn_class)}; return nil }

var A_arbace_box_build_embed_config_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_embed_config_A_invoke, New: A_arbace_box_build_embed_config_A_new, Get: A_arbace_box_build_embed_config_A_get}

var A_arbace_box_build_embed_config_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$embed_config", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_A_class, Simple: "embed_config", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_embed_config_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_embed_config_A_class.Info(); i.IsInstance = A_arbace_box_build_embed_config_A_InstanceOf; i.Init = A_arbace_box_build_embed_config_A_Init; i.Table = A_arbace_box_build_embed_config_A_members; jrt.RegisterGoType(A_arbace_box_build_embed_config_A_class, reflect.TypeFor[A_arbace_box_build_embed_config_A]()) }

func A_arbace_box_build_embed_config_iter__598000116__598000120_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_embed_config_iter__598000116__598000120_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_embed_config_iter__598000116__598000120_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_embed_config_iter__598000116__598000120_A_New()}; return nil }

func A_arbace_box_build_embed_config_iter__598000116__598000120_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_embed_config_iter__598000116__598000120_A_fn_class)}; return nil }

var A_arbace_box_build_embed_config_iter__598000116__598000120_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_embed_config_iter__598000116__598000120_A_invoke, New: A_arbace_box_build_embed_config_iter__598000116__598000120_A_new, Get: A_arbace_box_build_embed_config_iter__598000116__598000120_A_get}

var A_arbace_box_build_embed_config_iter__598000116__598000120_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$embed_config$iter__598000116__598000120", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_embed_config_A_class, Simple: "iter__598000116__598000120", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_embed_config_iter__598000116__598000120_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_embed_config_iter__598000116__598000120_A_class.Info(); i.IsInstance = A_arbace_box_build_embed_config_iter__598000116__598000120_A_InstanceOf; i.Init = A_arbace_box_build_embed_config_iter__598000116__598000120_A_Init; i.Table = A_arbace_box_build_embed_config_iter__598000116__598000120_A_members; jrt.RegisterGoType(A_arbace_box_build_embed_config_iter__598000116__598000120_A_class, reflect.TypeFor[A_arbace_box_build_embed_config_iter__598000116__598000120_A]()) }

func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_fn_class)}; return nil }

var A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_invoke, New: A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_new, Get: A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_get}

var A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$embed_config$iter__598000116__598000120$fn__598000121", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_embed_config_iter__598000116__598000120_A_class, Simple: "fn__598000121", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_class.Info(); i.IsInstance = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_InstanceOf; i.Init = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_Init; i.Table = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_members; jrt.RegisterGoType(A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_class, reflect.TypeFor[A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A]()) }

func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_fn_class)}; return nil }

var A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_invoke, New: A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_new, Get: A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_get}

var A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$embed_config$iter__598000116__598000120$fn__598000121$fn__598000122", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_class, Simple: "fn__598000122", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_class.Info(); i.IsInstance = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_InstanceOf; i.Init = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_Init; i.Table = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_members; jrt.RegisterGoType(A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_class, reflect.TypeFor[A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A]()) }

func A_arbace_box_build_embed_config_iter__598000132__598000136_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_embed_config_iter__598000132__598000136_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_embed_config_iter__598000132__598000136_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_embed_config_iter__598000132__598000136_A_New()}; return nil }

func A_arbace_box_build_embed_config_iter__598000132__598000136_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_embed_config_iter__598000132__598000136_A_fn_class)}; return nil }

var A_arbace_box_build_embed_config_iter__598000132__598000136_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_embed_config_iter__598000132__598000136_A_invoke, New: A_arbace_box_build_embed_config_iter__598000132__598000136_A_new, Get: A_arbace_box_build_embed_config_iter__598000132__598000136_A_get}

var A_arbace_box_build_embed_config_iter__598000132__598000136_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$embed_config$iter__598000132__598000136", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_embed_config_A_class, Simple: "iter__598000132__598000136", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_embed_config_iter__598000132__598000136_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_embed_config_iter__598000132__598000136_A_class.Info(); i.IsInstance = A_arbace_box_build_embed_config_iter__598000132__598000136_A_InstanceOf; i.Init = A_arbace_box_build_embed_config_iter__598000132__598000136_A_Init; i.Table = A_arbace_box_build_embed_config_iter__598000132__598000136_A_members; jrt.RegisterGoType(A_arbace_box_build_embed_config_iter__598000132__598000136_A_class, reflect.TypeFor[A_arbace_box_build_embed_config_iter__598000132__598000136_A]()) }

func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_fn_class)}; return nil }

var A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_invoke, New: A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_new, Get: A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_get}

var A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$embed_config$iter__598000132__598000136$fn__598000137", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_embed_config_iter__598000132__598000136_A_class, Simple: "fn__598000137", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_class.Info(); i.IsInstance = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_InstanceOf; i.Init = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_Init; i.Table = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_members; jrt.RegisterGoType(A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_class, reflect.TypeFor[A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A]()) }

func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_fn_class)}; return nil }

var A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_invoke, New: A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_new, Get: A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_get}

var A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$embed_config$iter__598000132__598000136$fn__598000137$fn__598000138", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_class, Simple: "fn__598000138", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_class.Info(); i.IsInstance = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_InstanceOf; i.Init = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_Init; i.Table = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_members; jrt.RegisterGoType(A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_class, reflect.TypeFor[A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A]()) }

func A_arbace_box_build_eval598000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_eval598000004_A_New()}; return nil }

var A_arbace_box_build_eval598000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_build_eval598000004_A_new}

var A_arbace_box_build_eval598000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$eval598000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_build_A_class, Simple: "eval598000004", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_eval598000004_A"})

func init() { i := A_arbace_box_build_eval598000004_A_class.Info(); i.IsInstance = A_arbace_box_build_eval598000004_A_InstanceOf; i.Table = A_arbace_box_build_eval598000004_A_members; jrt.RegisterGoType(A_arbace_box_build_eval598000004_A_class, reflect.TypeFor[A_arbace_box_build_eval598000004_A]()) }

func A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_New()}; return nil }

func A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_fn_class)}; return nil }

var A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_invoke, New: A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_new, Get: A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_get}

var A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$eval598000004$loading__1927001464__auto____598000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_eval598000004_A_class, Simple: "loading__1927001464__auto____598000005", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_class.Info(); i.IsInstance = A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_InstanceOf; i.Init = A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_Init; i.Table = A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_members; jrt.RegisterGoType(A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_class, reflect.TypeFor[A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A]()) }

func A_arbace_box_build_eval598000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_eval598000008_A_New()}; return nil }

var A_arbace_box_build_eval598000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_build_eval598000008_A_new}

var A_arbace_box_build_eval598000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$eval598000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_build_A_class, Simple: "eval598000008", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_eval598000008_A"})

func init() { i := A_arbace_box_build_eval598000008_A_class.Info(); i.IsInstance = A_arbace_box_build_eval598000008_A_InstanceOf; i.Table = A_arbace_box_build_eval598000008_A_members; jrt.RegisterGoType(A_arbace_box_build_eval598000008_A_class, reflect.TypeFor[A_arbace_box_build_eval598000008_A]()) }

func A_arbace_box_build_eval598000008_fn__598000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_eval598000008_fn__598000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_eval598000008_fn__598000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_eval598000008_fn__598000009_A_New()}; return nil }

func A_arbace_box_build_eval598000008_fn__598000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_eval598000008_fn__598000009_A_fn_class)}; return nil }

var A_arbace_box_build_eval598000008_fn__598000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_eval598000008_fn__598000009_A_invoke, New: A_arbace_box_build_eval598000008_fn__598000009_A_new, Get: A_arbace_box_build_eval598000008_fn__598000009_A_get}

var A_arbace_box_build_eval598000008_fn__598000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$eval598000008$fn__598000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_eval598000008_A_class, Simple: "fn__598000009", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_eval598000008_fn__598000009_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_eval598000008_fn__598000009_A_class.Info(); i.IsInstance = A_arbace_box_build_eval598000008_fn__598000009_A_InstanceOf; i.Init = A_arbace_box_build_eval598000008_fn__598000009_A_Init; i.Table = A_arbace_box_build_eval598000008_fn__598000009_A_members; jrt.RegisterGoType(A_arbace_box_build_eval598000008_fn__598000009_A_class, reflect.TypeFor[A_arbace_box_build_eval598000008_fn__598000009_A]()) }

func A_arbace_box_build_fail_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_fail_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_fail_A_New()}; return nil }

func A_arbace_box_build_fail_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_fail_A_fn_class)}; return nil }

var A_arbace_box_build_fail_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_fail_A_invoke, New: A_arbace_box_build_fail_A_new, Get: A_arbace_box_build_fail_A_get}

var A_arbace_box_build_fail_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$fail", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_build_A_class, Simple: "fail", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_fail_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_fail_A_class.Info(); i.IsInstance = A_arbace_box_build_fail_A_InstanceOf; i.Init = A_arbace_box_build_fail_A_Init; i.Table = A_arbace_box_build_fail_A_members; jrt.RegisterGoType(A_arbace_box_build_fail_A_class, reflect.TypeFor[A_arbace_box_build_fail_A]()) }

func A_arbace_box_build_file_tree_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_file_tree_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_file_tree_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_file_tree_A_New()}; return nil }

func A_arbace_box_build_file_tree_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_file_tree_A_fn_class)}; return nil }

var A_arbace_box_build_file_tree_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_file_tree_A_invoke, New: A_arbace_box_build_file_tree_A_new, Get: A_arbace_box_build_file_tree_A_get}

var A_arbace_box_build_file_tree_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$file_tree", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_A_class, Simple: "file_tree", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_file_tree_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_file_tree_A_class.Info(); i.IsInstance = A_arbace_box_build_file_tree_A_InstanceOf; i.Init = A_arbace_box_build_file_tree_A_Init; i.Table = A_arbace_box_build_file_tree_A_members; jrt.RegisterGoType(A_arbace_box_build_file_tree_A_class, reflect.TypeFor[A_arbace_box_build_file_tree_A]()) }

func A_arbace_box_build_file_tree_iter__598000054__598000058_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_file_tree_iter__598000054__598000058_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_file_tree_iter__598000054__598000058_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_file_tree_iter__598000054__598000058_A_New()}; return nil }

func A_arbace_box_build_file_tree_iter__598000054__598000058_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_file_tree_iter__598000054__598000058_A_fn_class)}; return nil }

var A_arbace_box_build_file_tree_iter__598000054__598000058_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_file_tree_iter__598000054__598000058_A_invoke, New: A_arbace_box_build_file_tree_iter__598000054__598000058_A_new, Get: A_arbace_box_build_file_tree_iter__598000054__598000058_A_get}

var A_arbace_box_build_file_tree_iter__598000054__598000058_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$file_tree$iter__598000054__598000058", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_file_tree_A_class, Simple: "iter__598000054__598000058", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_file_tree_iter__598000054__598000058_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_file_tree_iter__598000054__598000058_A_class.Info(); i.IsInstance = A_arbace_box_build_file_tree_iter__598000054__598000058_A_InstanceOf; i.Init = A_arbace_box_build_file_tree_iter__598000054__598000058_A_Init; i.Table = A_arbace_box_build_file_tree_iter__598000054__598000058_A_members; jrt.RegisterGoType(A_arbace_box_build_file_tree_iter__598000054__598000058_A_class, reflect.TypeFor[A_arbace_box_build_file_tree_iter__598000054__598000058_A]()) }

func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_fn_class)}; return nil }

var A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_invoke, New: A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_new, Get: A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_get}

var A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$file_tree$iter__598000054__598000058$fn__598000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_file_tree_iter__598000054__598000058_A_class, Simple: "fn__598000059", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_class.Info(); i.IsInstance = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_InstanceOf; i.Init = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_Init; i.Table = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_members; jrt.RegisterGoType(A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_class, reflect.TypeFor[A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A]()) }

func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_fn_class)}; return nil }

var A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_invoke, New: A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_new, Get: A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_get}

var A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$file_tree$iter__598000054__598000058$fn__598000059$fn__598000060", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_class, Simple: "fn__598000060", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_class.Info(); i.IsInstance = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_InstanceOf; i.Init = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_Init; i.Table = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_members; jrt.RegisterGoType(A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_class, reflect.TypeFor[A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A]()) }

func A_arbace_box_build_import_plan_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_import_plan_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_box_build_import_plan_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_import_plan_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_import_plan_A_New()}; return nil }

func A_arbace_box_build_import_plan_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_import_plan_A_fn_class)}; return nil }

var A_arbace_box_build_import_plan_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_import_plan_A_invoke, New: A_arbace_box_build_import_plan_A_new, Get: A_arbace_box_build_import_plan_A_get}

var A_arbace_box_build_import_plan_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$import_plan", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_A_class, Simple: "import_plan", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_import_plan_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_import_plan_A_class.Info(); i.IsInstance = A_arbace_box_build_import_plan_A_InstanceOf; i.Init = A_arbace_box_build_import_plan_A_Init; i.Table = A_arbace_box_build_import_plan_A_members; jrt.RegisterGoType(A_arbace_box_build_import_plan_A_class, reflect.TypeFor[A_arbace_box_build_import_plan_A]()) }

func A_arbace_box_build_import_plan_fn__598000044_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_import_plan_fn__598000044_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_import_plan_fn__598000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_import_plan_fn__598000044_A_New_O(args[0])}; return nil }

func A_arbace_box_build_import_plan_fn__598000044_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_import_plan_fn__598000044_A_fn_class)}; return nil }

var A_arbace_box_build_import_plan_fn__598000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_import_plan_fn__598000044_A_invoke, New: A_arbace_box_build_import_plan_fn__598000044_A_new, Get: A_arbace_box_build_import_plan_fn__598000044_A_get}

var A_arbace_box_build_import_plan_fn__598000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$import_plan$fn__598000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_import_plan_A_class, Simple: "fn__598000044", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_import_plan_fn__598000044_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_import_plan_fn__598000044_A_class.Info(); i.IsInstance = A_arbace_box_build_import_plan_fn__598000044_A_InstanceOf; i.Init = A_arbace_box_build_import_plan_fn__598000044_A_Init; i.Table = A_arbace_box_build_import_plan_fn__598000044_A_members; jrt.RegisterGoType(A_arbace_box_build_import_plan_fn__598000044_A_class, reflect.TypeFor[A_arbace_box_build_import_plan_fn__598000044_A]()) }

func A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_New_O(args[0])}; return nil }

func A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_fn_class)}; return nil }

var A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_invoke, New: A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_new, Get: A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_get}

var A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$import_plan$fn__598000044$fn__598000045", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_import_plan_fn__598000044_A_class, Simple: "fn__598000045", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_class.Info(); i.IsInstance = A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_InstanceOf; i.Init = A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_Init; i.Table = A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_members; jrt.RegisterGoType(A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_class, reflect.TypeFor[A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A]()) }

func A_arbace_box_build_import_plan_src__598000042_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_import_plan_src__598000042_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_import_plan_src__598000042_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_import_plan_src__598000042_A_New_O(args[0])}; return nil }

func A_arbace_box_build_import_plan_src__598000042_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_import_plan_src__598000042_A_fn_class)}; return nil }

var A_arbace_box_build_import_plan_src__598000042_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_import_plan_src__598000042_A_invoke, New: A_arbace_box_build_import_plan_src__598000042_A_new, Get: A_arbace_box_build_import_plan_src__598000042_A_get}

var A_arbace_box_build_import_plan_src__598000042_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$import_plan$src__598000042", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_import_plan_A_class, Simple: "src__598000042", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_import_plan_src__598000042_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_import_plan_src__598000042_A_class.Info(); i.IsInstance = A_arbace_box_build_import_plan_src__598000042_A_InstanceOf; i.Init = A_arbace_box_build_import_plan_src__598000042_A_Init; i.Table = A_arbace_box_build_import_plan_src__598000042_A_members; jrt.RegisterGoType(A_arbace_box_build_import_plan_src__598000042_A_class, reflect.TypeFor[A_arbace_box_build_import_plan_src__598000042_A]()) }

func A_arbace_box_build_json_str_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_json_str_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_json_str_A_New()}; return nil }

func A_arbace_box_build_json_str_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_json_str_A_fn_class)}; return nil }

var A_arbace_box_build_json_str_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_json_str_A_invoke, New: A_arbace_box_build_json_str_A_new, Get: A_arbace_box_build_json_str_A_get}

var A_arbace_box_build_json_str_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$json_str", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_A_class, Simple: "json_str", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_json_str_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_json_str_A_class.Info(); i.IsInstance = A_arbace_box_build_json_str_A_InstanceOf; i.Init = A_arbace_box_build_json_str_A_Init; i.Table = A_arbace_box_build_json_str_A_members; jrt.RegisterGoType(A_arbace_box_build_json_str_A_class, reflect.TypeFor[A_arbace_box_build_json_str_A]()) }

func A_arbace_box_build_json_str_fn__598000113_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_json_str_fn__598000113_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_json_str_fn__598000113_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_json_str_fn__598000113_A_New()}; return nil }

func A_arbace_box_build_json_str_fn__598000113_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_json_str_fn__598000113_A_fn_class)}; return nil }

var A_arbace_box_build_json_str_fn__598000113_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_json_str_fn__598000113_A_invoke, New: A_arbace_box_build_json_str_fn__598000113_A_new, Get: A_arbace_box_build_json_str_fn__598000113_A_get}

var A_arbace_box_build_json_str_fn__598000113_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$json_str$fn__598000113", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_json_str_A_class, Simple: "fn__598000113", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_json_str_fn__598000113_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_json_str_fn__598000113_A_class.Info(); i.IsInstance = A_arbace_box_build_json_str_fn__598000113_A_InstanceOf; i.Init = A_arbace_box_build_json_str_fn__598000113_A_Init; i.Table = A_arbace_box_build_json_str_fn__598000113_A_members; jrt.RegisterGoType(A_arbace_box_build_json_str_fn__598000113_A_class, reflect.TypeFor[A_arbace_box_build_json_str_fn__598000113_A]()) }

func A_arbace_box_build_link_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_link_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_build_link_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_link_A_New()}; return nil }

func A_arbace_box_build_link_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_link_A_fn_class)}; return nil }

var A_arbace_box_build_link_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_link_A_invoke, New: A_arbace_box_build_link_A_new, Get: A_arbace_box_build_link_A_get}

var A_arbace_box_build_link_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$link", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_box_build_A_class, Simple: "link", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_link_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_link_A_class.Info(); i.IsInstance = A_arbace_box_build_link_A_InstanceOf; i.Init = A_arbace_box_build_link_A_Init; i.Table = A_arbace_box_build_link_A_members; jrt.RegisterGoType(A_arbace_box_build_link_A_class, reflect.TypeFor[A_arbace_box_build_link_A]()) }

func A_arbace_box_build_link_fn__598000285_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_link_fn__598000285_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_link_fn__598000285_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_link_fn__598000285_A_New()}; return nil }

func A_arbace_box_build_link_fn__598000285_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_link_fn__598000285_A_fn_class)}; return nil }

var A_arbace_box_build_link_fn__598000285_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_link_fn__598000285_A_invoke, New: A_arbace_box_build_link_fn__598000285_A_new, Get: A_arbace_box_build_link_fn__598000285_A_get}

var A_arbace_box_build_link_fn__598000285_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$link$fn__598000285", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_build_link_A_class, Simple: "fn__598000285", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_link_fn__598000285_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_link_fn__598000285_A_class.Info(); i.IsInstance = A_arbace_box_build_link_fn__598000285_A_InstanceOf; i.Init = A_arbace_box_build_link_fn__598000285_A_Init; i.Table = A_arbace_box_build_link_fn__598000285_A_members; jrt.RegisterGoType(A_arbace_box_build_link_fn__598000285_A_class, reflect.TypeFor[A_arbace_box_build_link_fn__598000285_A]()) }

func A_arbace_box_build_link_iter__598000290__598000294_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_link_iter__598000290__598000294_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_link_iter__598000290__598000294_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_link_iter__598000290__598000294_A_New()}; return nil }

func A_arbace_box_build_link_iter__598000290__598000294_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_link_iter__598000290__598000294_A_fn_class)}; return nil }

var A_arbace_box_build_link_iter__598000290__598000294_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_link_iter__598000290__598000294_A_invoke, New: A_arbace_box_build_link_iter__598000290__598000294_A_new, Get: A_arbace_box_build_link_iter__598000290__598000294_A_get}

var A_arbace_box_build_link_iter__598000290__598000294_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$link$iter__598000290__598000294", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_link_A_class, Simple: "iter__598000290__598000294", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_link_iter__598000290__598000294_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_link_iter__598000290__598000294_A_class.Info(); i.IsInstance = A_arbace_box_build_link_iter__598000290__598000294_A_InstanceOf; i.Init = A_arbace_box_build_link_iter__598000290__598000294_A_Init; i.Table = A_arbace_box_build_link_iter__598000290__598000294_A_members; jrt.RegisterGoType(A_arbace_box_build_link_iter__598000290__598000294_A_class, reflect.TypeFor[A_arbace_box_build_link_iter__598000290__598000294_A]()) }

func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_fn_class)}; return nil }

var A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_invoke, New: A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_new, Get: A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_get}

var A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$link$iter__598000290__598000294$fn__598000295", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_link_iter__598000290__598000294_A_class, Simple: "fn__598000295", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_class.Info(); i.IsInstance = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_InstanceOf; i.Init = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_Init; i.Table = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_members; jrt.RegisterGoType(A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_class, reflect.TypeFor[A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A]()) }

func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_fn_class)}; return nil }

var A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_invoke, New: A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_new, Get: A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_get}

var A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$link$iter__598000290__598000294$fn__598000295$fn__598000296", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_class, Simple: "fn__598000296", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_class.Info(); i.IsInstance = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_InstanceOf; i.Init = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_Init; i.Table = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_members; jrt.RegisterGoType(A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_class, reflect.TypeFor[A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A]()) }

func A_arbace_box_build_log_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_log_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_log_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_log_A_New()}; return nil }

func A_arbace_box_build_log_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_log_A_fn_class)}; return nil }

var A_arbace_box_build_log_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_log_A_invoke, New: A_arbace_box_build_log_A_new, Get: A_arbace_box_build_log_A_get}

var A_arbace_box_build_log_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$log", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_box_build_A_class, Simple: "log", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_log_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_log_A_class.Info(); i.IsInstance = A_arbace_box_build_log_A_InstanceOf; i.Init = A_arbace_box_build_log_A_Init; i.Table = A_arbace_box_build_log_A_members; jrt.RegisterGoType(A_arbace_box_build_log_A_class, reflect.TypeFor[A_arbace_box_build_log_A]()) }

func A_arbace_box_build_out_file_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_build_out_file_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_out_file_A_New()}; return nil }

func A_arbace_box_build_out_file_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_out_file_A_fn_class)}; return nil }

var A_arbace_box_build_out_file_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_out_file_A_invoke, New: A_arbace_box_build_out_file_A_new, Get: A_arbace_box_build_out_file_A_get}

var A_arbace_box_build_out_file_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$out_file", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_box_build_A_class, Simple: "out_file", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_out_file_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_out_file_A_class.Info(); i.IsInstance = A_arbace_box_build_out_file_A_InstanceOf; i.Init = A_arbace_box_build_out_file_A_Init; i.Table = A_arbace_box_build_out_file_A_members; jrt.RegisterGoType(A_arbace_box_build_out_file_A_class, reflect.TypeFor[A_arbace_box_build_out_file_A]()) }

func A_arbace_box_build_read_plan_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_read_plan_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_read_plan_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_read_plan_A_New()}; return nil }

func A_arbace_box_build_read_plan_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_read_plan_A_fn_class)}; return nil }

var A_arbace_box_build_read_plan_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_read_plan_A_invoke, New: A_arbace_box_build_read_plan_A_new, Get: A_arbace_box_build_read_plan_A_get}

var A_arbace_box_build_read_plan_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$read_plan", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_A_class, Simple: "read_plan", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_read_plan_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_read_plan_A_class.Info(); i.IsInstance = A_arbace_box_build_read_plan_A_InstanceOf; i.Init = A_arbace_box_build_read_plan_A_Init; i.Table = A_arbace_box_build_read_plan_A_members; jrt.RegisterGoType(A_arbace_box_build_read_plan_A_class, reflect.TypeFor[A_arbace_box_build_read_plan_A]()) }

func A_arbace_box_build_sha256_hex_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_sha256_hex_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_sha256_hex_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_sha256_hex_A_New()}; return nil }

func A_arbace_box_build_sha256_hex_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_sha256_hex_A_fn_class)}; return nil }

var A_arbace_box_build_sha256_hex_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_sha256_hex_A_invoke, New: A_arbace_box_build_sha256_hex_A_new, Get: A_arbace_box_build_sha256_hex_A_get}

var A_arbace_box_build_sha256_hex_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$sha256_hex", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_A_class, Simple: "sha256_hex", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_sha256_hex_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_sha256_hex_A_class.Info(); i.IsInstance = A_arbace_box_build_sha256_hex_A_InstanceOf; i.Init = A_arbace_box_build_sha256_hex_A_Init; i.Table = A_arbace_box_build_sha256_hex_A_members; jrt.RegisterGoType(A_arbace_box_build_sha256_hex_A_class, reflect.TypeFor[A_arbace_box_build_sha256_hex_A]()) }

func A_arbace_box_build_source_tree_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_source_tree_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_source_tree_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_source_tree_A_New()}; return nil }

func A_arbace_box_build_source_tree_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_source_tree_A_fn_class)}; return nil }

var A_arbace_box_build_source_tree_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_source_tree_A_invoke, New: A_arbace_box_build_source_tree_A_new, Get: A_arbace_box_build_source_tree_A_get}

var A_arbace_box_build_source_tree_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$source_tree", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_A_class, Simple: "source_tree", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_source_tree_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_source_tree_A_class.Info(); i.IsInstance = A_arbace_box_build_source_tree_A_InstanceOf; i.Init = A_arbace_box_build_source_tree_A_Init; i.Table = A_arbace_box_build_source_tree_A_members; jrt.RegisterGoType(A_arbace_box_build_source_tree_A_class, reflect.TypeFor[A_arbace_box_build_source_tree_A]()) }

func A_arbace_box_build_source_tree_headers__598000018_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_source_tree_headers__598000018_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_source_tree_headers__598000018_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_source_tree_headers__598000018_A_New()}; return nil }

func A_arbace_box_build_source_tree_headers__598000018_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_source_tree_headers__598000018_A_fn_class)}; return nil }

var A_arbace_box_build_source_tree_headers__598000018_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_source_tree_headers__598000018_A_invoke, New: A_arbace_box_build_source_tree_headers__598000018_A_new, Get: A_arbace_box_build_source_tree_headers__598000018_A_get}

var A_arbace_box_build_source_tree_headers__598000018_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$source_tree$headers__598000018", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_source_tree_A_class, Simple: "headers__598000018", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_source_tree_headers__598000018_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_source_tree_headers__598000018_A_class.Info(); i.IsInstance = A_arbace_box_build_source_tree_headers__598000018_A_InstanceOf; i.Init = A_arbace_box_build_source_tree_headers__598000018_A_Init; i.Table = A_arbace_box_build_source_tree_headers__598000018_A_members; jrt.RegisterGoType(A_arbace_box_build_source_tree_headers__598000018_A_class, reflect.TypeFor[A_arbace_box_build_source_tree_headers__598000018_A]()) }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_New_O(args[0])}; return nil }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_fn_class)}; return nil }

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_invoke, New: A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_new, Get: A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_get}

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$source_tree$headers__598000018$iter__598000019__598000023", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_source_tree_headers__598000018_A_class, Simple: "iter__598000019__598000023", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_class.Info(); i.IsInstance = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_InstanceOf; i.Init = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_Init; i.Table = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_members; jrt.RegisterGoType(A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_class, reflect.TypeFor[A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A]()) }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_fn_class)}; return nil }

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_invoke, New: A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_new, Get: A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_get}

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$source_tree$headers__598000018$iter__598000019__598000023$fn__598000024", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_class, Simple: "fn__598000024", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_class.Info(); i.IsInstance = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_InstanceOf; i.Init = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_Init; i.Table = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_members; jrt.RegisterGoType(A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_class, reflect.TypeFor[A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A]()) }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_fn_class)}; return nil }

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_invoke, New: A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_new, Get: A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_get}

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$source_tree$headers__598000018$iter__598000019__598000023$fn__598000024$fn__598000025", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_class, Simple: "fn__598000025", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_class.Info(); i.IsInstance = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_InstanceOf; i.Init = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_Init; i.Table = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_members; jrt.RegisterGoType(A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_class, reflect.TypeFor[A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A]()) }

func A_arbace_box_build_source_tree_iter__598000030__598000034_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_source_tree_iter__598000030__598000034_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_source_tree_iter__598000030__598000034_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_source_tree_iter__598000030__598000034_A_New_O(args[0])}; return nil }

func A_arbace_box_build_source_tree_iter__598000030__598000034_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_source_tree_iter__598000030__598000034_A_fn_class)}; return nil }

var A_arbace_box_build_source_tree_iter__598000030__598000034_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_source_tree_iter__598000030__598000034_A_invoke, New: A_arbace_box_build_source_tree_iter__598000030__598000034_A_new, Get: A_arbace_box_build_source_tree_iter__598000030__598000034_A_get}

var A_arbace_box_build_source_tree_iter__598000030__598000034_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$source_tree$iter__598000030__598000034", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_source_tree_A_class, Simple: "iter__598000030__598000034", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_source_tree_iter__598000030__598000034_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_source_tree_iter__598000030__598000034_A_class.Info(); i.IsInstance = A_arbace_box_build_source_tree_iter__598000030__598000034_A_InstanceOf; i.Init = A_arbace_box_build_source_tree_iter__598000030__598000034_A_Init; i.Table = A_arbace_box_build_source_tree_iter__598000030__598000034_A_members; jrt.RegisterGoType(A_arbace_box_build_source_tree_iter__598000030__598000034_A_class, reflect.TypeFor[A_arbace_box_build_source_tree_iter__598000030__598000034_A]()) }

func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_fn_class)}; return nil }

var A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_invoke, New: A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_new, Get: A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_get}

var A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$source_tree$iter__598000030__598000034$fn__598000035", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_source_tree_iter__598000030__598000034_A_class, Simple: "fn__598000035", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_class.Info(); i.IsInstance = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_InstanceOf; i.Init = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_Init; i.Table = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_members; jrt.RegisterGoType(A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_class, reflect.TypeFor[A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A]()) }

func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_fn_class)}; return nil }

var A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_invoke, New: A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_new, Get: A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_get}

var A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$source_tree$iter__598000030__598000034$fn__598000035$fn__598000036", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_class, Simple: "fn__598000036", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_class.Info(); i.IsInstance = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_InstanceOf; i.Init = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_Init; i.Table = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_members; jrt.RegisterGoType(A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_class, reflect.TypeFor[A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A]()) }

func A_arbace_box_build_with_tools_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_with_tools_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_with_tools_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_with_tools_A_New()}; return nil }

func A_arbace_box_build_with_tools_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_with_tools_A_fn_class)}; return nil }

var A_arbace_box_build_with_tools_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_with_tools_A_invoke, New: A_arbace_box_build_with_tools_A_new, Get: A_arbace_box_build_with_tools_A_get}

var A_arbace_box_build_with_tools_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$with_tools", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_build_A_class, Simple: "with_tools", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_with_tools_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_with_tools_A_class.Info(); i.IsInstance = A_arbace_box_build_with_tools_A_InstanceOf; i.Init = A_arbace_box_build_with_tools_A_Init; i.Table = A_arbace_box_build_with_tools_A_members; jrt.RegisterGoType(A_arbace_box_build_with_tools_A_class, reflect.TypeFor[A_arbace_box_build_with_tools_A]()) }

func A_arbace_box_build_with_tools_iter__598000221__598000225_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_with_tools_iter__598000221__598000225_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_build_with_tools_iter__598000221__598000225_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_with_tools_iter__598000221__598000225_A_New_O(args[0])}; return nil }

func A_arbace_box_build_with_tools_iter__598000221__598000225_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_with_tools_iter__598000221__598000225_A_fn_class)}; return nil }

var A_arbace_box_build_with_tools_iter__598000221__598000225_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_with_tools_iter__598000221__598000225_A_invoke, New: A_arbace_box_build_with_tools_iter__598000221__598000225_A_new, Get: A_arbace_box_build_with_tools_iter__598000221__598000225_A_get}

var A_arbace_box_build_with_tools_iter__598000221__598000225_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$with_tools$iter__598000221__598000225", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_build_with_tools_A_class, Simple: "iter__598000221__598000225", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_with_tools_iter__598000221__598000225_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_with_tools_iter__598000221__598000225_A_class.Info(); i.IsInstance = A_arbace_box_build_with_tools_iter__598000221__598000225_A_InstanceOf; i.Init = A_arbace_box_build_with_tools_iter__598000221__598000225_A_Init; i.Table = A_arbace_box_build_with_tools_iter__598000221__598000225_A_members; jrt.RegisterGoType(A_arbace_box_build_with_tools_iter__598000221__598000225_A_class, reflect.TypeFor[A_arbace_box_build_with_tools_iter__598000221__598000225_A]()) }

func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_fn_class)}; return nil }

var A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_invoke, New: A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_new, Get: A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_get}

var A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$with_tools$iter__598000221__598000225$fn__598000226", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_with_tools_iter__598000221__598000225_A_class, Simple: "fn__598000226", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_class.Info(); i.IsInstance = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_InstanceOf; i.Init = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_Init; i.Table = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_members; jrt.RegisterGoType(A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_class, reflect.TypeFor[A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A]()) }

func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_fn_class)}; return nil }

var A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_invoke, New: A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_new, Get: A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_get}

var A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build$with_tools$iter__598000221__598000225$fn__598000226$fn__598000227", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_class, Simple: "fn__598000227", Go: "arbace/aot_arbace_box_build.A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A", Source: "build.ae"})

func init() { i := A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_class.Info(); i.IsInstance = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_InstanceOf; i.Init = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_Init; i.Table = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_members; jrt.RegisterGoType(A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_class, reflect.TypeFor[A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A]()) }

func A_arbace_box_build__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_box_build__init_A_Load__O(); case 1: return A_arbace_box_build__init_A_Unit0__O(); case 2: return A_arbace_box_build__init_A_Unit1__O(); case 3: return A_arbace_box_build__init_A_Unit10__O(); case 4: return A_arbace_box_build__init_A_Unit11__O(); case 5: return A_arbace_box_build__init_A_Unit12__O(); case 6: return A_arbace_box_build__init_A_Unit13__O(); case 7: return A_arbace_box_build__init_A_Unit14__O(); case 8: return A_arbace_box_build__init_A_Unit15__O(); case 9: return A_arbace_box_build__init_A_Unit16__O(); case 10: return A_arbace_box_build__init_A_Unit17__O(); case 11: return A_arbace_box_build__init_A_Unit18__O(); case 12: return A_arbace_box_build__init_A_Unit19__O(); case 13: return A_arbace_box_build__init_A_Unit2__O(); case 14: return A_arbace_box_build__init_A_Unit20__O(); case 15: return A_arbace_box_build__init_A_Unit21__O(); case 16: return A_arbace_box_build__init_A_Unit22__O(); case 17: return A_arbace_box_build__init_A_Unit23__O(); case 18: return A_arbace_box_build__init_A_Unit24__O(); case 19: return A_arbace_box_build__init_A_Unit25__O(); case 20: return A_arbace_box_build__init_A_Unit26__O(); case 21: return A_arbace_box_build__init_A_Unit27__O(); case 22: return A_arbace_box_build__init_A_Unit28__O(); case 23: return A_arbace_box_build__init_A_Unit29__O(); case 24: return A_arbace_box_build__init_A_Unit3__O(); case 25: return A_arbace_box_build__init_A_Unit4__O(); case 26: return A_arbace_box_build__init_A_Unit5__O(); case 27: return A_arbace_box_build__init_A_Unit6__O(); case 28: return A_arbace_box_build__init_A_Unit7__O(); case 29: return A_arbace_box_build__init_A_Unit8__O(); case 30: return A_arbace_box_build__init_A_Unit9__O()}; return nil }

func A_arbace_box_build__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_build__init_A_New()}; return nil }

var A_arbace_box_build__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_box_build__init_A_invoke, New: A_arbace_box_build__init_A_new}

var A_arbace_box_build__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.build__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_build.A_arbace_box_build__init_A", Source: "build.ae"})

func init() { i := A_arbace_box_build__init_A_class.Info(); i.IsInstance = A_arbace_box_build__init_A_InstanceOf; i.Init = A_arbace_box_build__init_A_Init; i.Table = A_arbace_box_build__init_A_members; jrt.RegisterGoType(A_arbace_box_build__init_A_class, reflect.TypeFor[A_arbace_box_build__init_A]()) }
