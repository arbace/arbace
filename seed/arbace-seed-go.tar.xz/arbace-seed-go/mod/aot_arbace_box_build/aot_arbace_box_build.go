//line aot_arbace_box_build.ae:1
package aot_arbace_box_build

import (
	"arbace/aot_arbace_box"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_edn"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :4:1
func A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_New() *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_build_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_box_build_A_const_1); lang.IFn_Cast(A_arbace_box_build_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_box_build_A_const_3, A_arbace_box_build_A_const_4, A_arbace_box_build_A_const_5); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_112)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_113)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_114)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :4:1
func A_arbace_box_build_eval598000008_fn__598000009_A_New() *A_arbace_box_build_eval598000008_fn__598000009_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_eval598000008_fn__598000009_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_build_eval598000008_fn__598000009_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_build_eval598000008_fn__598000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_box_build_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_box_build_A_const_9.GetRawRoot__O(), A_arbace_box_build_A_const_10) }







































func A_arbace_box_build_fail_A_New() *A_arbace_box_build_fail_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_fail_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_box_build_fail_A) Ctor() {}
//line :44:1
func (t *A_arbace_box_build_fail_A) Invoke_O_O_O__O(self, msg__0, data__1 any) any { var tmp1 any; var root_21 any = A_arbace_box_build_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_23 lang.IFn; if
											linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = msg__0; var arg_25 any; var root_26 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = data__1; var arg_30 any = A_arbace_box_build_A_const_13; var arg_31 any = jrt.Boolean_TRUE.Ref(); if linked_27 == nil { arg_25 = ifn_28.Invoke_O_O_O__O(arg_29, arg_30, arg_31) } else { arg_25 = linked_27.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_26, arg_29, arg_30, arg_31) }; if linked_22 == nil { tmp1 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { tmp1 = linked_22.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; /*line :44:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }


func A_arbace_box_build_sha256_hex_A_New() *A_arbace_box_build_sha256_hex_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_sha256_hex_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_box_build_sha256_hex_A) Ctor() {}
//line :47:1
func (t *A_arbace_box_build_sha256_hex_A) Invoke_O_O__O(self, s__0 any) any { var d__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_140).Digest_B1__B1(jrt.NN(jrt.String_Cast(s__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8)).Ref(); var sb__3 any = jrt.StringBuilder_New(); var seq_598000013__4 any; var root_36 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_38 lang.IFn; if


	linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = d__2; if linked_37 == nil { seq_598000013__4 = ifn_38.Invoke_O__O(arg_39) } else { seq_598000013__4 = linked_37.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_36, arg_39) }; var chunk_598000014__5 any; var count_598000015__6 int64 = 0; var i_598000016__7 int64 = 0; L1:
//line :47:1
	for {


		if lang.Numbers_Lt_J_J__Z_NoInit(i_598000016__7, count_598000015__6) { var b__8 any = lang.Indexed_Cast(chunk_598000014__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_598000016__7)); var x__9 int64; var na_56 any = b__8; var na_57 int64 = 255
			if jrt.Long_InstanceOf(na_56) { var n0_58 int64 = jrt.NN(jrt.Long_Cast(na_56)).LongValue__J(); var n1_59 int64 = na_57; x__9 = n0_58 & n1_59 } else { x__9 = lang.Numbers_And_O_J__J_NoInit(na_56, na_57) }
			jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(x__9, 4)), lang.RT_IntCast_J__I_NoInit(16)))
			jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_And_J_J__J_NoInit(x__9, 15)), lang.RT_IntCast_J__I_NoInit(16)))
//line :50:1
			seq_598000013__4, chunk_598000014__5, count_598000015__6, i_598000016__7 = seq_598000013__4, chunk_598000014__5, count_598000015__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_598000016__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_40 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = seq_598000013__4; if linked_41 == nil { temp__1927000414__auto____8 = ifn_42.Invoke_O__O(arg_43) } else { temp__1927000414__auto____8 = linked_41.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_40, arg_43) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_598000013__9 any = temp__1927000414__auto____8; var tmp1 any; var root_44 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = seq_598000013__9; if linked_45 == nil { tmp1 = ifn_46.Invoke_O__O(arg_47) } else { tmp1 = linked_45.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_44, arg_47) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____10 any; var root_48 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = seq_598000013__9; if linked_49 == nil { c__1927000678__auto____10 = ifn_50.Invoke_O__O(arg_51) } else { c__1927000678__auto____10 = linked_49.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_48, arg_51) }; var tmp2 any; var root_61 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = seq_598000013__9; if linked_62 == nil { tmp2 = ifn_63.Invoke_O__O(arg_64) } else { tmp2 = linked_62.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_61, arg_64) }; seq_598000013__4, chunk_598000014__5, count_598000015__6, i_598000016__7 = tmp2, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var b__10 any; var root_52 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = seq_598000013__9; if linked_53 == nil { b__10 = ifn_54.Invoke_O__O(arg_55) } else { b__10 = linked_53.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_52, arg_55) }; var x__11 int64; var na_65 any = b__10; var na_66 int64 = 255
				if jrt.Long_InstanceOf(na_65) { var n0_67 int64 = jrt.NN(jrt.Long_Cast(na_65)).LongValue__J(); var n1_68 int64 = na_66; x__11 = n0_67 & n1_68 } else { x__11 = lang.Numbers_And_O_J__J_NoInit(na_65, na_66) }
				jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(x__11, 4)), lang.RT_IntCast_J__I_NoInit(16)))
				jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_And_J_J__J_NoInit(x__11, 15)), lang.RT_IntCast_J__I_NoInit(16)))
//line :50:1
				var tmp3 any; var root_70 any = A_arbace_box_build_A_const_20.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = seq_598000013__9; if linked_71 == nil { tmp3 = ifn_72.Invoke_O__O(arg_73) } else { tmp3 = linked_71.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_70, arg_73) }; seq_598000013__4, chunk_598000014__5, count_598000015__6, i_598000016__7 = tmp3, nil, 0, 0; continue L1 } } }
//line :47:1
		break L1 }; var root_32 any =






	A_arbace_box_build_A_const_14.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = sb__3; if linked_33 == nil { return ifn_34.Invoke_O__O(arg_35) } else { return linked_33.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_32, arg_35) } }




func A_arbace_box_build_source_tree_A_New() *A_arbace_box_build_source_tree_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_A{}; t.Ctor(); return t }
//line :59:1
func (t *A_arbace_box_build_source_tree_A) Ctor() {}
//line :59:1
func (t *A_arbace_box_build_source_tree_A) Invoke_O_O__O(self, d__0 any) any { var fs__2 any = jrt.File_Cast(d__0).ListFiles__File1().Ref(); var headers__3 any; var fnbody__172 any = A_arbace_box_build_source_tree_headers__598000018_A_New(); var tmp1 *jrt.Class; var fncls__171 *jrt.Class = A_arbace_box_build_source_tree_headers__598000018_A_fn_class; if




	fncls__171 == nil { var fncls__171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_141, false, nil); A_arbace_box_build_source_tree_headers__598000018_A_fn_class = fncls__171d; tmp1 = fncls__171d } else { tmp1 = fncls__171 }; headers__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__172, tmp1, nil); var root_173 any =








	A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any; var root_177 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_179 lang.IFn; if
	linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_181 any; var iter__1927001039__auto____4 any; var fnbody__255 any = A_arbace_box_build_source_tree_iter__598000030__598000034_A_New_O(headers__3); var tmp2 *jrt.Class; var fncls__254 *jrt.Class = A_arbace_box_build_source_tree_iter__598000030__598000034_A_fn_class; if
	fncls__254 == nil { var fncls__254d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_142, false, fnbody__255); A_arbace_box_build_source_tree_iter__598000030__598000034_A_fn_class = fncls__254d; tmp2 = fncls__254d } else { tmp2 = fncls__254 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__255, tmp2, nil); arg_181 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(fs__2); if /*line :74:1*/ linked_178 == nil { arg_176 = ifn_179.Invoke_O_O__O(arg_180, arg_181) } else { arg_176 = linked_178.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_177, arg_180, arg_181) }; if /*line :73:1*/ linked_174 == nil { return ifn_175.Invoke_O__O(arg_176) } else { return linked_174.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_173, arg_176) } }
//line :64:1
func A_arbace_box_build_source_tree_headers__598000018_A_New() *A_arbace_box_build_source_tree_headers__598000018_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_box_build_source_tree_headers__598000018_A) Ctor() {}
//line :64:1
func (t *A_arbace_box_build_source_tree_headers__598000018_A) Invoke_O_O__O(self, s__1 any) any { var m__2 any; var root_74 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_76 lang.IFn; if
												linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_78 any; var iter__1927001039__auto____2 any; var fnbody__162 any = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_New_O(self); var tmp1 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_fn_class; if
												fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_143, false, fnbody__162); A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_fn_class = fncls__161d; tmp1 = fncls__161d } else { tmp1 = fncls__161 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__162, tmp1, nil); arg_78 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(jrt.File_Cast(s__1).ListFiles__File1().Ref()); if /*line :65:1*/ linked_75 == nil { m__2 = ifn_76.Invoke_O_O__O(arg_77, arg_78) } else { m__2 = linked_75.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_74, arg_77, arg_78) }; var tmp2 any; var root_163 any =






	A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = m__2; if linked_164 == nil { tmp2 = ifn_165.Invoke_O__O(arg_166) } else { tmp2 = linked_164.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_163, arg_166) }; if jrt.J2g_Truth(tmp2) { var root_167 any = A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = m__2; if linked_168 == nil { return ifn_169.Invoke_O__O(arg_170) } else { return linked_168.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_167, arg_170) } } else { return nil } }
//line :66:1
func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_New_O(p0 any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A{}; t.Ctor_O(p0); return t }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A) Ctor_O(c__headers any) { t.F_headers = c__headers }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A) Invoke_O_O__O(self, s__598000020__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__160 any = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_New_O_O_O(self, t.F_headers, s__598000020__1); var tmp2 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_144, false, fnbody__160); A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_fn_class = fncls__159d; tmp2 = fncls__159d } else { tmp2 = fncls__159 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__160, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :66:1
func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A) Ctor_O_O_O(c__iter__598000019, c__headers, c__s__598000020 any) { t.F_iter__598000019 = c__iter__598000019; t.F_headers = c__headers; t.F_s__598000020 = c__s__598000020 }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A) Invoke_O__O(self any) any { { var s__598000020__1 any; var t_ any = t.F_s__598000020; t.F_s__598000020 = nil; s__598000020__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_79 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = s__598000020__1; if linked_80 == nil { temp__1927000414__auto____2 = ifn_81.Invoke_O__O(arg_82) } else { temp__1927000414__auto____2 = linked_80.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_79, arg_82) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000020__3 any = temp__1927000414__auto____2; var tmp1 any; var root_83 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = s__598000020__3; if linked_84 == nil { tmp1 = ifn_85.Invoke_O__O(arg_86) } else { tmp1 = linked_84.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_83, arg_86) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_87 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = s__598000020__3; if linked_88 == nil { c__1927001037__auto____4 = ifn_89.Invoke_O__O(arg_90) } else { c__1927001037__auto____4 = linked_88.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_87, arg_90) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000022__6 any; var root_91 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_92 == nil { b__598000022__6 = ifn_93.Invoke_O__O(arg_94) } else { b__598000022__6 = linked_92.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_91, arg_94) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_New_O_O_I_O(t.F_headers, b__598000022__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_145, false, fnbody__110); A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_111 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any; var root_116 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = b__598000022__6; if linked_117 == nil { arg_114 = ifn_118.Invoke_O__O(arg_119) } else { arg_114 = linked_117.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_116, arg_119) }; var arg_115 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000019); var tmp5 any; var root_120 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = s__598000020__3; if linked_121 == nil { tmp5 = ifn_122.Invoke_O__O(arg_123) } else { tmp5 = linked_121.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_120, arg_123) }; arg_115 = tmp4.Invoke_O__O(tmp5); if linked_112 == nil { return ifn_113.Invoke_O_O__O(arg_114, arg_115) } else { return linked_112.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_111, arg_114, arg_115) } } else { var root_124 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any; var root_129 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = b__598000022__6; if linked_130 == nil { arg_127 = ifn_131.Invoke_O__O(arg_132) } else { arg_127 = linked_130.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_129, arg_132) }; var arg_128 any; if linked_125 == nil { return ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { return linked_125.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_124, arg_127, arg_128) } } } else { var f__4 any; var root_133 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = s__598000020__3; if linked_134 == nil { f__4 = ifn_135.Invoke_O__O(arg_136) } else { f__4 = linked_134.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_133, arg_136) }; var e__5 any
																	if jrt.File_Cast(f__4).IsDirectory__Z() { var temp__1927000414__auto____5 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__4); if jrt.J2g_Truth(temp__1927000414__auto____5) { var h__6 any = temp__1927000414__auto____5; e__5 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_25, h__6) } else { e__5 = nil } } else { var tmp6 any; var root_137 any = A_arbace_box_build_A_const_23.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_139 lang.IFn
																		if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = jrt.File_Cast(f__4).GetName__String().Ref(); var arg_141 any = Lit_146; if linked_138 == nil { tmp6 = ifn_139.Invoke_O_O__O(arg_140, arg_141) } else { tmp6 = linked_138.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_137, arg_140, arg_141) }
//line :67:1
		if jrt.J2g_Truth(tmp6) {

			var root_142 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = jrt.Files_ReadAllBytes_Path__B1(jrt.File_Cast(f__4).ToPath__Path()).Ref(); if linked_143 == nil { e__5 = ifn_144.Invoke_O__O(arg_145) } else { e__5 = linked_143.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_142, arg_145) } } else {
//line :67:1
				e__5 = nil } }
//line :66:1
	if jrt.J2g_Truth(e__5) { var root_146 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.File_Cast(f__4).GetName__String().Ref(), e__5); var arg_150 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__598000019); var tmp8 any; var root_151 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = s__598000020__3; if linked_152 == nil { tmp8 = ifn_153.Invoke_O__O(arg_154) } else { tmp8 = linked_152.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_151, arg_154) }; arg_150 = tmp7.Invoke_O__O(tmp8); if linked_147 == nil { return ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { return linked_147.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) } } else { var tmp9 any; var root_155 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = s__598000020__3; if linked_156 == nil { tmp9 = ifn_157.Invoke_O__O(arg_158) } else { tmp9 = linked_156.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_155, arg_158) }; s__598000020__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :66:1
func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A) Ctor_O_O_I_O(c__headers, c__b__598000022 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_headers = c__headers; t.F_b__598000022 = c__b__598000022; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A) Invoke_O__O(self any) any { { var i__598000021__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000021__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000021__1)); var e__3 any
																		if jrt.File_Cast(f__2).IsDirectory__Z() { var temp__1927000414__auto____3 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__2); if jrt.J2g_Truth(temp__1927000414__auto____3) { var h__4 any = temp__1927000414__auto____3; e__3 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_25, h__4) } else { e__3 = nil } } else { var tmp2 any; var root_95 any = A_arbace_box_build_A_const_23.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_97 lang.IFn
																			if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = jrt.File_Cast(f__2).GetName__String().Ref(); var arg_99 any = Lit_146; if linked_96 == nil { tmp2 = ifn_97.Invoke_O_O__O(arg_98, arg_99) } else { tmp2 = linked_96.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_95, arg_98, arg_99) }
//line :67:1
		if jrt.J2g_Truth(tmp2) {

			var root_100 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = jrt.Files_ReadAllBytes_Path__B1(jrt.File_Cast(f__2).ToPath__Path()).Ref(); if linked_101 == nil { e__3 = ifn_102.Invoke_O__O(arg_103) } else { e__3 = linked_101.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_100, arg_103) } } else {
//line :67:1
				e__3 = nil } }
//line :66:1
	if jrt.J2g_Truth(e__3) { var root_104 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = t.F_b__598000022; var arg_108 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.File_Cast(f__2).GetName__String().Ref(), e__3); if linked_105 == nil { ifn_106.Invoke_O_O__O(arg_107, arg_108) } else { linked_105.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_104, arg_107, arg_108) }; i__598000021__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000021__1); continue L1 } else { i__598000021__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000021__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_box_build_source_tree_iter__598000030__598000034_A_New_O(p0 any) *A_arbace_box_build_source_tree_iter__598000030__598000034_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_iter__598000030__598000034_A{}; t.Ctor_O(p0); return t }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_A) Ctor_O(c__headers any) { t.F_headers = c__headers }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_A) Invoke_O_O__O(self, s__598000031__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__253 any = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_New_O_O_O(t.F_headers, self, s__598000031__1); var tmp2 *jrt.Class; var fncls__252 *jrt.Class = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_fn_class; if fncls__252 == nil { var fncls__252d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_147, false, fnbody__253); A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_fn_class = fncls__252d; tmp2 = fncls__252d } else { tmp2 = fncls__252 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__253, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :75:1
func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A) Ctor_O_O_O(c__headers, c__iter__598000030, c__s__598000031 any) { t.F_headers = c__headers; t.F_iter__598000030 = c__iter__598000030; t.F_s__598000031 = c__s__598000031 }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A) Invoke_O__O(self any) any { { var s__598000031__1 any; var t_ any = t.F_s__598000031; t.F_s__598000031 = nil; s__598000031__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_182 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = s__598000031__1; if linked_183 == nil { temp__1927000414__auto____2 = ifn_184.Invoke_O__O(arg_185) } else { temp__1927000414__auto____2 = linked_183.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_182, arg_185) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000031__3 any = temp__1927000414__auto____2; var tmp1 any; var root_186 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = s__598000031__3; if linked_187 == nil { tmp1 = ifn_188.Invoke_O__O(arg_189) } else { tmp1 = linked_187.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_186, arg_189) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_190 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = s__598000031__3; if linked_191 == nil { c__1927001037__auto____4 = ifn_192.Invoke_O__O(arg_193) } else { c__1927001037__auto____4 = linked_191.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_190, arg_193) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000033__6 any; var root_194 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_195 == nil { b__598000033__6 = ifn_196.Invoke_O__O(arg_197) } else { b__598000033__6 = linked_195.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_194, arg_197) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__208 any = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_New_O_O_I_O(t.F_headers, b__598000033__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__207 *jrt.Class = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_fn_class; if fncls__207 == nil { var fncls__207d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_148, false, fnbody__208); A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_fn_class = fncls__207d; tmp3 = fncls__207d } else { tmp3 = fncls__207 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__208, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_209 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any; var root_214 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = b__598000033__6; if linked_215 == nil { arg_212 = ifn_216.Invoke_O__O(arg_217) } else { arg_212 = linked_215.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_214, arg_217) }; var arg_213 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000030); var tmp5 any; var root_218 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = s__598000031__3; if linked_219 == nil { tmp5 = ifn_220.Invoke_O__O(arg_221) } else { tmp5 = linked_219.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_218, arg_221) }; arg_213 = tmp4.Invoke_O__O(tmp5); if linked_210 == nil { return ifn_211.Invoke_O_O__O(arg_212, arg_213) } else { return linked_210.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_209, arg_212, arg_213) } } else { var root_222 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any; var root_227 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = b__598000033__6; if linked_228 == nil { arg_225 = ifn_229.Invoke_O__O(arg_230) } else { arg_225 = linked_228.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_227, arg_230) }; var arg_226 any; if linked_223 == nil { return ifn_224.Invoke_O_O__O(arg_225, arg_226) } else { return linked_223.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_222, arg_225, arg_226) } } } else { var f__4 any; var root_231 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = s__598000031__3; if linked_232 == nil { f__4 = ifn_233.Invoke_O__O(arg_234) } else { f__4 = linked_232.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_231, arg_234) }; var e__5 any
														if jrt.File_Cast(f__4).IsDirectory__Z() { var temp__1927000414__auto____5 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__4)
															if jrt.J2g_Truth(temp__1927000414__auto____5) { var h__6 any = temp__1927000414__auto____5; e__5 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_25, h__6) } else { e__5 = nil } } else {
																var root_235 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = jrt.Files_ReadAllBytes_Path__B1(jrt.File_Cast(f__4).ToPath__Path()).Ref(); if linked_236 == nil { e__5 = ifn_237.Invoke_O__O(arg_238) } else { e__5 = linked_236.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_235, arg_238) } }
//line :75:1
	if jrt.J2g_Truth(e__5) { var root_239 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.File_Cast(f__4).GetName__String().Ref(), e__5); var arg_243 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000030); var tmp7 any; var root_244 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = s__598000031__3; if linked_245 == nil { tmp7 = ifn_246.Invoke_O__O(arg_247) } else { tmp7 = linked_245.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_244, arg_247) }; arg_243 = tmp6.Invoke_O__O(tmp7); if linked_240 == nil { return ifn_241.Invoke_O_O__O(arg_242, arg_243) } else { return linked_240.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_239, arg_242, arg_243) } } else { var tmp8 any; var root_248 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = s__598000031__3; if linked_249 == nil { tmp8 = ifn_250.Invoke_O__O(arg_251) } else { tmp8 = linked_249.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_248, arg_251) }; s__598000031__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :75:1
func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A) Ctor_O_O_I_O(c__headers, c__b__598000033 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_headers = c__headers; t.F_b__598000033 = c__b__598000033; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A) Invoke_O__O(self any) any { { var i__598000032__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000032__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000032__1)); var e__3 any
																if jrt.File_Cast(f__2).IsDirectory__Z() { var temp__1927000414__auto____3 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__2)
																	if jrt.J2g_Truth(temp__1927000414__auto____3) { var h__4 any = temp__1927000414__auto____3; e__3 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_25, h__4) } else { e__3 = nil } } else {
																		var root_198 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = jrt.Files_ReadAllBytes_Path__B1(jrt.File_Cast(f__2).ToPath__Path()).Ref(); if linked_199 == nil { e__3 = ifn_200.Invoke_O__O(arg_201) } else { e__3 = linked_199.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_198, arg_201) } }
//line :75:1
	if jrt.J2g_Truth(e__3) { var root_202 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = t.F_b__598000033; var arg_206 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.File_Cast(f__2).GetName__String().Ref(), e__3); if linked_203 == nil { ifn_204.Invoke_O_O__O(arg_205, arg_206) } else { linked_203.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_202, arg_205, arg_206) }; i__598000032__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000032__1); continue L1 } else { i__598000032__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000032__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_box_build_import_plan_A_New() *A_arbace_box_build_import_plan_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_import_plan_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_box_build_import_plan_A) Ctor() {}
//line :82:1
func (t *A_arbace_box_build_import_plan_A) Invoke_O_O_O__O(self, plan__0, goroot__1 any) any { var p__3 any; var tmp1 any; var root_256 any = A_arbace_box_build_A_const_32.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_258 lang.IFn; if




	linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = plan__0; if linked_257 == nil { tmp1 = ifn_258.Invoke_O__O(arg_259) } else { tmp1 = linked_257.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_256, arg_259) }; if jrt.J2g_Truth(tmp1) { p__3 = plan__0 } else { var root_260 any = A_arbace_box_build_A_const_33.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_edn.A_arbace_edn_read_string_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = lang.IFn_Cast(A_arbace_box_build_A_const_34.GetRawRoot__O()).Invoke_O__O(plan__0); if linked_261 == nil { p__3 = ifn_262.Invoke_O__O(arg_263) } else { p__3 = linked_261.(*aot_arbace_edn.A_arbace_edn_read_string_A).Invoke_O_O__O(root_260, arg_263) } }; var dirs__4 any; var root_268 any = /*line :82:1*/A_arbace_box_build_A_const_35.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_270 lang.IFn; if





	linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_269 == nil { dirs__4 = ifn_270.Invoke_O__O(arg_271) } else { dirs__4 = linked_269.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_268, arg_271) }; var src__5 any; var fnbody__288 any = /*line :82:1*/A_arbace_box_build_import_plan_src__598000042_A_New_O(dirs__4); var tmp2 *jrt.Class; var fncls__287 *jrt.Class = A_arbace_box_build_import_plan_src__598000042_A_fn_class; if






	fncls__287 == nil { var fncls__287d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_118, false, fnbody__288); A_arbace_box_build_import_plan_src__598000042_A_fn_class = fncls__287d; tmp2 = fncls__287d } else { tmp2 = fncls__287 }; src__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__288, tmp2, nil); var p__6 any; var root_289 any = /*line :82:1*/A_arbace_box_build_A_const_38.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_291 lang.IFn; if









	linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any; var root_295 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_297 lang.IFn; if /*line :91:1*/ linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = p__3; var arg_299 any = A_arbace_box_build_A_const_39; var arg_300 any; var root_301 any = A_arbace_box_build_A_const_40.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_box.A_arbace_box_put_dir_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_119), jrt.RefArrayOf(jrt.Object_class, goroot__1, nil)).Ref(); if linked_302 == nil { arg_300 = ifn_303.Invoke_O__O(arg_304) } else { arg_300 = linked_302.(*aot_arbace_box.A_arbace_box_put_dir_A).Invoke_O_O__O(root_301, arg_304) }; if linked_296 == nil { arg_292 = ifn_297.Invoke_O_O_O__O(arg_298, arg_299, arg_300) } else { arg_292 = linked_296.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_295, arg_298, arg_299, arg_300) }; var arg_293 any = A_arbace_box_build_A_const_41; var arg_294 any; var fnbody__324 any =
	A_arbace_box_build_import_plan_fn__598000044_A_New_O(src__5); var tmp3 *jrt.Class; var fncls__323 *jrt.Class = A_arbace_box_build_import_plan_fn__598000044_A_fn_class; if fncls__323 == nil { var fncls__323d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_120, false, fnbody__324); A_arbace_box_build_import_plan_fn__598000044_A_fn_class = fncls__323d; tmp3 = fncls__323d } else { tmp3 = fncls__323 }; arg_294 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__324, tmp3, nil); if linked_290 == nil { p__6 = ifn_291.Invoke_O_O_O__O(arg_292, arg_293, arg_294) } else { p__6 = linked_290.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_289, arg_292, arg_293, arg_294) }; var root_325 any =
	A_arbace_box_build_A_const_45.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_box.A_arbace_box_put_A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = lang.IFn_Cast(A_arbace_box_build_A_const_46.GetRawRoot__O()).Invoke_O__O(p__6); if linked_326 == nil { return ifn_327.Invoke_O__O(arg_328) } else { return linked_326.(*aot_arbace_box.A_arbace_box_put_A).Invoke_O_O__O(root_325, arg_328) } }
//line :82:1
func (t *A_arbace_box_build_import_plan_A) Invoke_O_O__O(self, plan__0 any) any {


	var root_333 any = A_arbace_box_build_A_const_47.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, A_arbace_box_build_import_plan_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = plan__0; var arg_337 any = Lit_121; if linked_334 == nil { return ifn_335.Invoke_O_O__O(arg_336, arg_337) } else { return linked_334.(*A_arbace_box_build_import_plan_A).Invoke_O_O_O__O(root_333, arg_336, arg_337)
	}
}

func A_arbace_box_build_import_plan_src__598000042_A_New_O(p0 any) *A_arbace_box_build_import_plan_src__598000042_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_import_plan_src__598000042_A{}; t.Ctor_O(p0); return t }
//line :89:1
func (t *A_arbace_box_build_import_plan_src__598000042_A) Ctor_O(c__dirs any) { t.F_dirs = c__dirs }
//line :89:1
func (t *A_arbace_box_build_import_plan_src__598000042_A) Invoke_O_O__O(self, dir__1 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_272 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = t.F_dirs; if linked_273 == nil { tmp1 = ifn_274.Invoke_O__O(arg_275) } else { tmp1 = linked_273.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_272, arg_275) }; or__1927000174__auto____2 = lang.IFn_Cast(tmp1).Invoke_O__O(dir__1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var h__3 any; var root_276 any = A_arbace_box_build_A_const_36.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, A_arbace_box_build_source_tree_A_fn_class); var ifn_278 lang.IFn; if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = jrt.File_New_String(jrt.String_Cast(dir__1)); if linked_277 == nil { h__3 = ifn_278.Invoke_O__O(arg_279) } else { h__3 = linked_277.(*A_arbace_box_build_source_tree_A).Invoke_O_O__O(root_276, arg_279) }; var root_280 any = A_arbace_box_build_A_const_37.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = t.F_dirs; var arg_284 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var arg_285 any = dir__1; var arg_286 any = h__3; if linked_281 == nil { ifn_282.Invoke_O_O_O_O__O(arg_283, arg_284, arg_285, arg_286) } else { linked_281.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_280, arg_283, arg_284, arg_285, arg_286) }; return h__3 } }


func A_arbace_box_build_import_plan_fn__598000044_A_New_O(p0 any) *A_arbace_box_build_import_plan_fn__598000044_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_import_plan_fn__598000044_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_A) Ctor_O(c__src any) { t.F_src = c__src }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_A) Invoke_O_O__O(self, ps__1 any) any { var root_305 any = A_arbace_box_build_A_const_42.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any; var fnbody__322 any = A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_New_O(t.F_src); var tmp1 *jrt.Class; var fncls__321 *jrt.Class = A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_fn_class; if fncls__321 == nil { var fncls__321d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_122, false, fnbody__322); A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_fn_class = fncls__321d; tmp1 = fncls__321d } else { tmp1 = fncls__321 }; arg_308 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__322, tmp1, nil); var arg_309 any = ps__1; if linked_306 == nil { return ifn_307.Invoke_O_O__O(arg_308, arg_309) } else { return linked_306.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_305, arg_308, arg_309) } }
//line :92:1
func A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_New_O(p0 any) *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A) Ctor_O(c__src any) { t.F_src = c__src }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A) Invoke_O_O__O(self, p1__598000041_SHARP___1 any) any { var root_310 any = A_arbace_box_build_A_const_43.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any; var root_315 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = p1__598000041_SHARP___1; var arg_319 any = A_arbace_box_build_A_const_44; var tmp1 lang.IFn = lang.IFn_Cast(t.F_src); var arg_320 any = tmp1.Invoke_O__O(A_arbace_box_build_A_const_25.Invoke_O__O(p1__598000041_SHARP___1)); if linked_316 == nil { arg_313 = ifn_317.Invoke_O_O_O__O(arg_318, arg_319, arg_320) } else { arg_313 = linked_316.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_315, arg_318, arg_319, arg_320) }; var arg_314 any = A_arbace_box_build_A_const_25; if linked_311 == nil { return ifn_312.Invoke_O_O__O(arg_313, arg_314) } else { return linked_311.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_310, arg_313, arg_314) } }







func A_arbace_box_build_log_A_New() *A_arbace_box_build_log_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_log_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_box_build_log_A) Ctor() {}
//line :100:1
func (t *A_arbace_box_build_log_A) DoInvoke_O_O__O(self, xs__0 any) any {
	var tmp1 lang.IFn = A_arbace_box_build_A_const_48; var tmp2 lang.IFn = lang.IFn_Cast(tmp1.Invoke_O_O__O(A_arbace_box_build_A_const_49.Get__O(), A_arbace_box_build_A_const_50.GetRawRoot__O())); var tmp3 any; var root_338 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_342 any = xs__0; if linked_339 == nil { tmp3 = ifn_340.Invoke_O_O__O(arg_341, arg_342) } else { tmp3 = linked_339.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_338, arg_341, arg_342) }; return tmp2.Invoke_O__O(tmp3)
}
func A_arbace_box_build_cache_ref_A_New() *A_arbace_box_build_cache_ref_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_cache_ref_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_box_build_cache_ref_A) Ctor() {}
//line :103:1
func (t *A_arbace_box_build_cache_ref_A) Invoke_O_O__O(self, req__0 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_89, nil); var tmp2 any; var root_343 any = A_arbace_box_build_A_const_52.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any; var root_349 any = A_arbace_box_build_A_const_53.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, A_arbace_box_build_sha256_hex_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any; var root_353 any = A_arbace_box_build_A_const_54.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_box.A_arbace_box_request_text_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = lang.IFn_Cast(A_arbace_box_build_A_const_43.GetRawRoot__O()).Invoke_O_O_O__O(req__0, A_arbace_box_build_A_const_55, A_arbace_box_build_A_const_56); if linked_354 == nil { arg_352 = ifn_355.Invoke_O__O(arg_356) } else { arg_352 = linked_354.(*aot_arbace_box.A_arbace_box_request_text_A).Invoke_O_O__O(root_353, arg_356) }; if linked_350 == nil { arg_346 = ifn_351.Invoke_O__O(arg_352) } else { arg_346 = linked_350.(*A_arbace_box_build_sha256_hex_A).Invoke_O_O__O(root_349, arg_352) }; var arg_347 any = A_arbace_box_build_A_const_57; var arg_348 any = A_arbace_box_build_A_const_58; if linked_344 == nil { tmp2 = ifn_345.Invoke_O_O_O__O(arg_346, arg_347, arg_348) } else { tmp2 = linked_344.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_343, arg_346, arg_347, arg_348) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref()
}
func A_arbace_box_build_action_STAR__A_New() *A_arbace_box_build_action_STAR__A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_action_STAR__A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_box_build_action_STAR__A) Ctor() {}
//line :106:1
func (t *A_arbace_box_build_action_STAR__A) Invoke_O_O_O__O(self, what__0, req__1 any) any { var cref__3 any; var root_363 any = A_arbace_box_build_A_const_59.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, A_arbace_box_build_cache_ref_A_fn_class); var ifn_365 lang.IFn; if

	linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = req__1; if linked_364 == nil { cref__3 = ifn_365.Invoke_O__O(arg_366) } else { cref__3 = linked_364.(*A_arbace_box_build_cache_ref_A).Invoke_O_O__O(root_363, arg_366) }; var cached__4 any; var tmp1 lang.IFn = A_arbace_box_build_A_const_60; if
	jrt.J2g_Truth(tmp1.Invoke_O_O__O(A_arbace_box_build_A_const_49.Get__O(), jrt.Boolean_TRUE.Ref())) { var temp__1927000414__auto____4 any; var root_367 any = A_arbace_box_build_A_const_61.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_box.A_arbace_box_ref_A_fn_class); var ifn_369 lang.IFn
		if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = cref__3; if linked_368 == nil { temp__1927000414__auto____4 = ifn_369.Invoke_O__O(arg_370) } else { temp__1927000414__auto____4 = linked_368.(*aot_arbace_box.A_arbace_box_ref_A).Invoke_O_O__O(root_367, arg_370) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var h__5 any = temp__1927000414__auto____4; var tmp2 any; var root_371 any = A_arbace_box_build_A_const_62.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_box.A_arbace_box_size_A_fn_class); var ifn_373 lang.IFn
			if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = h__5; if linked_372 == nil { tmp2 = ifn_373.Invoke_O__O(arg_374) } else { tmp2 = linked_372.(*aot_arbace_box.A_arbace_box_size_A).Invoke_O_O__O(root_371, arg_374) }; if jrt.J2g_Truth(tmp2) { var root_375 any = A_arbace_box_build_A_const_63.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_box.A_arbace_box_result_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = h__5; if linked_376 == nil { cached__4 = ifn_377.Invoke_O__O(arg_378) } else { cached__4 = linked_376.(*aot_arbace_box.A_arbace_box_result_A).Invoke_O_O__O(root_375, arg_378) } } else { cached__4 = nil } } else {
//line :110:1
				cached__4 = nil } } else {
//line :109:1
					cached__4 = nil }; var t0__5 int64 = /*line :106:1*/jrt.System_NanoTime__J(); var res__6 any; var or__1927000174__auto____6 any = cached__4; if






	jrt.J2g_Truth(or__1927000174__auto____6) { res__6 = or__1927000174__auto____6 } else { var tmp3 lang.IFn = A_arbace_box_build_A_const_64; res__6 = lang.IFn_Cast(tmp3.Invoke_O_O__O(A_arbace_box_build_A_const_49.Get__O(), A_arbace_box_build_A_const_65.GetRawRoot__O())).Invoke_O__O(req__1) }; if
	lang.Util_Equiv_J_O__Z_NoInit(0, A_arbace_box_build_A_const_66.Invoke_O__O(res__6)) { } else {
		var root_379 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, A_arbace_box_build_fail_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil, Lit_2, nil, Lit_3, nil); var tmp5 *jrt.String; if jrt.J2g_Truth(A_arbace_box_build_A_const_68.Invoke_O__O(res__6)) { tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_4, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_68.Invoke_O__O(res__6))) } else { tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_66.Invoke_O__O(res__6))) }; var tmp6 any = tmp5.Ref(); var tmp7 any; var root_384 any = A_arbace_box_build_A_const_69.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_box.A_arbace_box_get_A_fn_class); var ifn_386 lang.IFn
		if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = A_arbace_box_build_A_const_70.Invoke_O__O(res__6); if linked_385 == nil { tmp7 = ifn_386.Invoke_O__O(arg_387) } else { tmp7 = linked_385.(*aot_arbace_box.A_arbace_box_get_A).Invoke_O_O__O(root_384, arg_387) }
//line :115:1
		arg_382 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, what__0, nil, tmp6, nil, tmp7)).Ref(); var arg_383 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_71, what__0, A_arbace_box_build_A_const_72, res__6)); if linked_380 == nil { ifn_381.Invoke_O_O__O(arg_382, arg_383) } else { linked_380.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_379, arg_382, arg_383) } }; var tmp8 any; var and__1927000168__auto____7 any; var root_388 any =


	A_arbace_box_build_A_const_73.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = cached__4; if linked_389 == nil { and__1927000168__auto____7 = ifn_390.Invoke_O__O(arg_391) } else { and__1927000168__auto____7 = linked_389.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_388, arg_391) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp9 lang.IFn = A_arbace_box_build_A_const_60; tmp8 = tmp9.Invoke_O_O__O(A_arbace_box_build_A_const_49.Get__O(), jrt.Boolean_TRUE.Ref()) } else { tmp8 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp8) {
		var root_392 any = A_arbace_box_build_A_const_74.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_box.A_arbace_box_ref_BANG__A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = cref__3; var arg_396 any = A_arbace_box_build_A_const_75.Invoke_O__O(res__6); if linked_393 == nil { ifn_394.Invoke_O_O__O(arg_395, arg_396) } else { linked_393.(*aot_arbace_box.A_arbace_box_ref_BANG__A).Invoke_O_O_O__O(root_392, arg_395, arg_396) } }; var tmp10 lang.IFn =
	lang.IFn_Cast(A_arbace_box_build_A_const_76.GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_77.GetRawRoot__O()); var tmp12 any; var root_408 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = A_arbace_box_build_A_const_78.Invoke_O__O(req__1); if linked_409 == nil { tmp12 = ifn_410.Invoke_O__O(arg_411) } else { tmp12 = linked_409.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_408, arg_411) }; var tmp13 any = tmp12; var tmp14 any; if
	jrt.J2g_Truth(cached__4) { tmp14 = Lit_7 } else { tmp14 = lang.IFn_Cast(A_arbace_box_build_A_const_77.GetRawRoot__O()).Invoke_O_O__O(Lit_8, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__5), 1.0e9)).Ref()) }; /*line :120:1*/tmp10.Invoke_O__O(tmp11.Invoke_O_O_O_O__O(Lit_6, tmp13, what__0, tmp14)); return res__6 }



func A_arbace_box_build_action_A_New() *A_arbace_box_build_action_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_action_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_box_build_action_A) Ctor() {}
//line :124:1
func (t *A_arbace_box_build_action_A) Invoke_O_O_O_O__O(self, what__0, req__1, opts__2 any) any {




	var root_425 any = A_arbace_box_build_A_const_81.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, opts__2); if linked_426 == nil { ifn_427.Invoke_O__O(arg_428) } else { linked_426.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_425, arg_428) }
//line :124:1
	var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




		{ var root_417 any = A_arbace_box_build_A_const_79.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, A_arbace_box_build_action_STAR__A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = what__0; var arg_421 any = req__1; if linked_418 == nil { tmp1 = ifn_419.Invoke_O_O__O(arg_420, arg_421) } else { tmp1 = linked_418.(*A_arbace_box_build_action_STAR__A).Invoke_O_O_O__O(root_417, arg_420, arg_421) } }
//line :124:1
		return nil }(); var root_422 any = A_arbace_box_build_A_const_80.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_424 lang.IFn




	if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; if linked_423 == nil { ifn_424.Invoke__O() } else { linked_423.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_422) }
//line :124:1
	if tmp2 != nil { panic(tmp2) }; return tmp1 }
//line :124:1
func (t *A_arbace_box_build_action_A) Invoke_O_O_O__O(self, what__0, req__1 any) any {



	var root_434 any = A_arbace_box_build_A_const_79.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, A_arbace_box_build_action_STAR__A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = what__0; var arg_438 any = req__1; if linked_435 == nil { return ifn_436.Invoke_O_O__O(arg_437, arg_438) } else { return linked_435.(*A_arbace_box_build_action_STAR__A).Invoke_O_O_O__O(root_434, arg_437, arg_438)
	}
}
func A_arbace_box_build_out_file_A_New() *A_arbace_box_build_out_file_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_out_file_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_box_build_out_file_A) Ctor() {}
//line :131:1
func (t *A_arbace_box_build_out_file_A) Invoke_O_O_O_O__O(self, res__0, what__1, name__2 any) any { var or__1927000174__auto____4 any; var root_439 any = A_arbace_box_build_A_const_83.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_box.A_arbace_box_tree_get_A_fn_class); var ifn_441 lang.IFn; if


	linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = A_arbace_box_build_A_const_84.Invoke_O__O(res__0); var arg_443 any = name__2; if linked_440 == nil { or__1927000174__auto____4 = ifn_441.Invoke_O_O__O(arg_442, arg_443) } else { or__1927000174__auto____4 = linked_440.(*aot_arbace_box.A_arbace_box_tree_get_A).Invoke_O_O_O__O(root_439, arg_442, arg_443) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {
		var root_444 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, A_arbace_box_build_fail_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_1, nil, Lit_137, nil, Lit_138), jrt.RefArrayOf(jrt.Object_class, nil, what__1, nil, name__2, nil)).Ref(); var arg_448 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_72, res__0)); if linked_445 == nil { return ifn_446.Invoke_O_O__O(arg_447, arg_448) } else { return linked_445.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_444, arg_447, arg_448) } } }

func A_arbace_box_build_file_tree_A_New() *A_arbace_box_build_file_tree_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_file_tree_A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_box_build_file_tree_A) Ctor() {}
//line :137:1
func (t *A_arbace_box_build_file_tree_A) Invoke_O_O__O(self, m__0 any) any {


	var root_449 any = A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any; var root_453 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_457 any; var iter__1927001039__auto____2 any; var fnbody__527 any = A_arbace_box_build_file_tree_iter__598000054__598000058_A_New(); var tmp1 *jrt.Class; var fncls__526 *jrt.Class = A_arbace_box_build_file_tree_iter__598000054__598000058_A_fn_class; if fncls__526 == nil { var fncls__526d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_115, false, nil); A_arbace_box_build_file_tree_iter__598000054__598000058_A_fn_class = fncls__526d; tmp1 = fncls__526d } else { tmp1 = fncls__526 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__527, tmp1, nil); arg_457 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(m__0); if linked_454 == nil { arg_452 = ifn_455.Invoke_O_O__O(arg_456, arg_457) } else { arg_452 = linked_454.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_453, arg_456, arg_457) }; if linked_450 == nil { return ifn_451.Invoke_O__O(arg_452) } else { return linked_450.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_449, arg_452) } }
//line :140:1
func A_arbace_box_build_file_tree_iter__598000054__598000058_A_New() *A_arbace_box_build_file_tree_iter__598000054__598000058_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_file_tree_iter__598000054__598000058_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_A) Ctor() {}
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_A) Invoke_O_O__O(self, s__598000055__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__525 any = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_New_O_O(s__598000055__1, self); var tmp2 *jrt.Class; var fncls__524 *jrt.Class = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_fn_class; if fncls__524 == nil { var fncls__524d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_116, false, fnbody__525); A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_fn_class = fncls__524d; tmp2 = fncls__524d } else { tmp2 = fncls__524 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__525, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :140:1
func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_New_O_O(p0, p1 any) *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A) Ctor_O_O(c__s__598000055, c__iter__598000054 any) { t.F_s__598000055 = c__s__598000055; t.F_iter__598000054 = c__iter__598000054 }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A) Invoke_O__O(self any) any { { var s__598000055__1 any; var t_ any = t.F_s__598000055; t.F_s__598000055 = nil; s__598000055__1 = t_; for { var temp__1927000414__auto____2 any; var root_458 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = s__598000055__1; if linked_459 == nil { temp__1927000414__auto____2 = ifn_460.Invoke_O__O(arg_461) } else { temp__1927000414__auto____2 = linked_459.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_458, arg_461) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000055__3 any = temp__1927000414__auto____2; var tmp1 any; var root_462 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = s__598000055__3; if linked_463 == nil { tmp1 = ifn_464.Invoke_O__O(arg_465) } else { tmp1 = linked_463.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_462, arg_465) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_466 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = s__598000055__3; if linked_467 == nil { c__1927001037__auto____4 = ifn_468.Invoke_O__O(arg_469) } else { c__1927001037__auto____4 = linked_467.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_466, arg_469) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000057__6 any; var root_470 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_471 == nil { b__598000057__6 = ifn_472.Invoke_O__O(arg_473) } else { b__598000057__6 = linked_471.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_470, arg_473) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__484 any = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_New_O_I_O(b__598000057__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__483 *jrt.Class = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_fn_class; if fncls__483 == nil { var fncls__483d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_117, false, fnbody__484); A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_fn_class = fncls__483d; tmp3 = fncls__483d } else { tmp3 = fncls__483 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__484, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_485 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any; var root_490 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = b__598000057__6; if linked_491 == nil { arg_488 = ifn_492.Invoke_O__O(arg_493) } else { arg_488 = linked_491.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_490, arg_493) }; var arg_489 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000054); var tmp5 any; var root_494 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = s__598000055__3; if linked_495 == nil { tmp5 = ifn_496.Invoke_O__O(arg_497) } else { tmp5 = linked_495.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_494, arg_497) }; arg_489 = tmp4.Invoke_O__O(tmp5); if linked_486 == nil { return ifn_487.Invoke_O_O__O(arg_488, arg_489) } else { return linked_486.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_485, arg_488, arg_489) } } else { var root_498 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any; var root_503 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = b__598000057__6; if linked_504 == nil { arg_501 = ifn_505.Invoke_O__O(arg_506) } else { arg_501 = linked_504.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_503, arg_506) }; var arg_502 any; if linked_499 == nil { return ifn_500.Invoke_O_O__O(arg_501, arg_502) } else { return linked_499.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_498, arg_501, arg_502) } } } else { var vec__598000065__4 any; var root_507 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = s__598000055__3; if linked_508 == nil { vec__598000065__4 = ifn_509.Invoke_O__O(arg_510) } else { vec__598000065__4 = linked_508.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_507, arg_510) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000065__4, lang.RT_IntCast_J__I_NoInit(0), nil); var x__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000065__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_511 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any; var tmp6 any; var root_516 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = x__6; if linked_517 == nil { tmp6 = ifn_518.Invoke_O__O(arg_519) } else { tmp6 = linked_517.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_516, arg_519) }; arg_514 = lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp6); var arg_515 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__598000054); var tmp8 any; var root_520 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = s__598000055__3; if linked_521 == nil { tmp8 = ifn_522.Invoke_O__O(arg_523) } else { tmp8 = linked_521.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_520, arg_523) }; arg_515 = tmp7.Invoke_O__O(tmp8); if linked_512 == nil { return ifn_513.Invoke_O_O__O(arg_514, arg_515) } else { return linked_512.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_511, arg_514, arg_515) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :140:1
func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A) Ctor_O_I_O(c__b__598000057 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000057 = c__b__598000057; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A) Invoke_O__O(self any) any { { var i__598000056__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000056__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000061__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000056__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000061__2, lang.RT_IntCast_J__I_NoInit(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000061__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_474 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = t.F_b__598000057; var arg_478 any; var tmp2 any; var root_479 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = x__4; if linked_480 == nil { tmp2 = ifn_481.Invoke_O__O(arg_482) } else { tmp2 = linked_480.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_479, arg_482) }; arg_478 = lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp2); if linked_475 == nil { ifn_476.Invoke_O_O__O(arg_477, arg_478) } else { linked_475.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_474, arg_477, arg_478) }; i__598000056__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000056__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_box_build_arch_defines_A_New() *A_arbace_box_build_arch_defines_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_arch_defines_A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_box_build_arch_defines_A) Ctor() {}
//line :142:1
func (t *A_arbace_box_build_arch_defines_A) Invoke_O_O__O(self, plan__0 any) any { var a__2 any = A_arbace_box_build_A_const_85.Invoke_O__O(plan__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_86.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(Lit_13, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_14, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_87.Invoke_O__O(plan__0))).Ref(), Lit_13, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, a__2)).Ref()); var tmp3 any = A_arbace_box_build_A_const_88; var tmp4 lang.IPersistentVector; var G__598000071__3_ any = a__2; L1:



switch { default: switch lang.Util_Hash_O__I_NoInit(G__598000071__3_) { case 92926582: if lang.Util_Equiv_O_O__Z_NoInit(G__598000071__3_, Lit_16) { tmp4 = lang.Tuple_Create_O_O__IPersistentVector(Lit_13, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_89.Invoke_O__O(plan__0))).Ref()); break L1 }; default:}; tmp4 = Up_PersistentVector_IPersistentVector(lang.PersistentVector_EMPTY)}; return /*line :144:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }





func A_arbace_box_build_asm_args_A_New() *A_arbace_box_build_asm_args_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_asm_args_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_box_build_asm_args_A) Ctor() {}
//line :150:1
func (t *A_arbace_box_build_asm_args_A) DoInvoke_O_O_O_O_O__O(self, plan__0, pkg__1, out__2, more__3 any) any {
	var root_535 any = A_arbace_box_build_A_const_90.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_86.GetRawRoot__O()); var tmp2 any = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_33, Lit_34, A_arbace_box_build_A_const_91.Invoke_O__O(pkg__1), Lit_35, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_36, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_91.Invoke_O__O(pkg__1), nil)).Ref(), Lit_38, Lit_39, Lit_38, Lit_40)); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_92.GetRawRoot__O()); var tmp4 *lang.Compiler_AOTFn; var fnbody__552 any = A_arbace_box_build_asm_args_fn__598000074_A_New_O(pkg__1); var tmp5 *jrt.Class
	var fncls__551 /*line :151:1*/*jrt.Class = A_arbace_box_build_asm_args_fn__598000074_A_fn_class

	if fncls__551 == nil { var fncls__551d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__552); A_arbace_box_build_asm_args_fn__598000074_A_fn_class = fncls__551d; tmp5 = fncls__551d } else { tmp5 = fncls__551 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__552, tmp5, nil)
//line :151:1
	var tmp6 any = tmp4.Ref(); var tmp7 any; var root_553 any = A_arbace_box_build_A_const_95.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, A_arbace_box_build_arch_defines_A_fn_class); var ifn_555 lang.IFn

	if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = plan__0; if linked_554 == nil { tmp7 = ifn_555.Invoke_O__O(arg_556) } else { tmp7 = linked_554.(*A_arbace_box_build_arch_defines_A).Invoke_O_O__O(root_553, arg_556) }
//line :151:1
	arg_538 = tmp1.Invoke_O_O_O_O__O(tmp2, tmp3.Invoke_O_O__O(tmp6, tmp7), more__3, lang.Tuple_Create_O_O__IPersistentVector(Lit_42, out__2)); if linked_536 == nil { return ifn_537.Invoke_O__O(arg_538) } else { return linked_536.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_535, arg_538)
	} }
func A_arbace_box_build_asm_args_fn__598000074_A_New_O(p0 any) *A_arbace_box_build_asm_args_fn__598000074_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_asm_args_fn__598000074_A{}; t.Ctor_O(p0); return t }
//line :153:1
func (t *A_arbace_box_build_asm_args_fn__598000074_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :153:1
func (t *A_arbace_box_build_asm_args_fn__598000074_A) Invoke_O_O__O(self, p1__598000073_SHARP___1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(p1__598000073_SHARP___1, A_arbace_box_build_A_const_93) { if jrt.J2g_Truth(A_arbace_box_build_A_const_93.Invoke_O__O(t.F_pkg)) { return A_arbace_box_build_A_const_94 } else { return nil } } else { return lang.Tuple_Create_O__IPersistentVector(p1__598000073_SHARP___1) } }




func A_arbace_box_build_ar_member_A_New() *A_arbace_box_build_ar_member_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_ar_member_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_box_build_ar_member_A) Ctor() {}
//line :158:1
func (t *A_arbace_box_build_ar_member_A) Invoke_O_O_O__O(self, name__0, data__1 any) any { var pad__3 any; var fnbody__587 any = A_arbace_box_build_ar_member_pad__598000077_A_New(); var tmp1 *jrt.Class; var fncls__586 *jrt.Class = A_arbace_box_build_ar_member_pad__598000077_A_fn_class; if
												fncls__586 == nil { var fncls__586d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, nil); A_arbace_box_build_ar_member_pad__598000077_A_fn_class = fncls__586d; tmp1 = fncls__586d } else { tmp1 = fncls__586 }; pad__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__587, tmp1, nil); var hdr__4 any; var tmp2 /*line :158:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil, nil, nil, nil, Lit_10); var tmp3 lang.IFn = lang.IFn_Cast(pad__3); var tmp4 any; var root_588 any = A_arbace_box_build_A_const_52.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_590 lang.IFn; if

	linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = name__0; var arg_592 any = A_arbace_box_build_A_const_57; var arg_593 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Min_J_J__J_NoInit(16, int64(lang.RT_Count_O__I_NoInit(name__0)))).Ref(); if linked_589 == nil { tmp4 = ifn_590.Invoke_O_O_O__O(arg_591, arg_592, arg_593) } else { tmp4 = linked_589.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_588, arg_591, arg_592, arg_593) }; var tmp5 any = tmp3.Invoke_O_O__O(tmp4, A_arbace_box_build_A_const_98); var tmp6 any = lang.IFn_Cast(pad__3).Invoke_O_O__O(Lit_11, A_arbace_box_build_A_const_99); var tmp7 any = lang.IFn_Cast(pad__3).Invoke_O_O__O(Lit_11, A_arbace_box_build_A_const_100); var tmp8 any = lang.IFn_Cast(pad__3).Invoke_O_O__O(Lit_11, A_arbace_box_build_A_const_100); var tmp9 any = lang.IFn_Cast(pad__3).Invoke_O_O__O(Lit_12, A_arbace_box_build_A_const_101); var tmp10 lang.IFn = lang.IFn_Cast(pad__3); var tmp11 any; var root_594 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(data__1))).Ref(); if linked_595 == nil { tmp11 = ifn_596.Invoke_O__O(arg_597) } else { tmp11 = linked_595.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_594, arg_597) }; hdr__4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10.Invoke_O_O__O(tmp11, A_arbace_box_build_A_const_102), nil)).Ref(); var o__5 any = /*line :158:1*/jrt.ByteArrayOutputStream_New();



	jrt.OutputStream_Cast(o__5).Write_B1__V(jrt.NN(jrt.String_Cast(hdr__4)).GetBytes_Charset__B1(jrt.StandardCharsets_US_ASCII));
	jrt.OutputStream_Cast(o__5).Write_B1__V(jrt.ByteArray_Cast(data__1)); var tmp12 any; var root_598 any =
	A_arbace_box_build_A_const_103.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_odd_QMARK__A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(data__1))).Ref(); if linked_599 == nil { tmp12 = ifn_600.Invoke_O__O(arg_601) } else { tmp12 = linked_599.(*aot_arbace_core.A_arbace_core_odd_QMARK__A).Invoke_O_O__O(root_598, arg_601) }; if jrt.J2g_Truth(tmp12) { jrt.ByteArrayOutputStream_Cast(o__5).Write_I__V(lang.RT_IntCast_J__I_NoInit(10)) }; return /*line :165:1*/ jrt.ByteArrayOutputStream_Cast(o__5).ToByteArray__B1().Ref() }
//line :159:1
func A_arbace_box_build_ar_member_pad__598000077_A_New() *A_arbace_box_build_ar_member_pad__598000077_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_ar_member_pad__598000077_A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_box_build_ar_member_pad__598000077_A) Ctor() {}
//line :159:1
func (t *A_arbace_box_build_ar_member_pad__598000077_A) Invoke_O_O_O__O(self, s__1, n__2 any) any { if jrt.Long_InstanceOf(n__2) { return t.InvokeSpec_O_O_J_O__O(self, s__1, jrt.NN(jrt.Long_Cast(n__2)).LongValue__J(), n__2) } else { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_557 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_561 any; var root_562 any = A_arbace_box_build_A_const_96.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any; var na_567 any = n__2; var na_568 int64 = int64(lang.RT_Count_O__I_NoInit(s__1)); if jrt.Long_InstanceOf(na_567) { var n0_569 int64 = jrt.NN(jrt.Long_Cast(na_567)).LongValue__J(); var n1_570 int64 = na_568; var nr_571 int64 = n0_569 - n1_570; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_570 == -9223372036854775808); if tmp4 { tmp4 = (n0_569^n1_570)&(n0_569^nr_571) >= 0 }; tmp3 = tmp4; if tmp3 { arg_565 = jrt.Long_ValueOf_J__Long_NoInit(nr_571).Ref() } else { arg_565 = lang.Numbers_Minus_O_J__Number_NoInit(na_567, na_568) } } else { arg_565 = lang.Numbers_Minus_O_J__Number_NoInit(na_567, na_568) }; var arg_566 any = A_arbace_box_build_A_const_97; if linked_563 == nil { arg_561 = ifn_564.Invoke_O_O__O(arg_565, arg_566) } else { arg_561 = linked_563.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_562, arg_565, arg_566) }; if linked_558 == nil { tmp2 = ifn_559.Invoke_O_O__O(arg_560, arg_561) } else { tmp2 = linked_558.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_557, arg_560, arg_561) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, s__1, tmp2)).Ref() } }
//line :159:1
func (t *A_arbace_box_build_ar_member_pad__598000077_A) InvokeSpec_O_O_J_O__O(self, s__1 any, n__2_l int64, n__2_b any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_572 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_576 any; var root_577 any = A_arbace_box_build_A_const_96.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_579 lang.IFn; if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any; var na_582 int64 = int64(lang.RT_Count_O__I_NoInit(s__1)); var n0_583 int64 = n__2_l; var n1_584 int64 = na_582; var nr_585 int64 = n0_583 - n1_584; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_584 == -9223372036854775808); if tmp4 { tmp4 = (n0_583^n1_584)&(n0_583^nr_585) >= 0 }; tmp3 = tmp4; if tmp3 { arg_580 = jrt.Long_ValueOf_J__Long_NoInit(nr_585).Ref() } else { var tmp5 any; if n__2_b == nil { n__2_b = jrt.Long_ValueOf_J__Long_NoInit(n__2_l).Ref(); tmp5 = n__2_b } else { tmp5 = n__2_b }; arg_580 = lang.Numbers_Minus_O_J__Number_NoInit(tmp5, na_582) }; var arg_581 any = A_arbace_box_build_A_const_97; if linked_578 == nil { arg_576 = ifn_579.Invoke_O_O__O(arg_580, arg_581) } else { arg_576 = linked_578.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_577, arg_580, arg_581) }; if linked_573 == nil { tmp2 = ifn_574.Invoke_O_O__O(arg_575, arg_576) } else { tmp2 = linked_573.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_572, arg_575, arg_576) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, s__1, tmp2)).Ref() }







func A_arbace_box_build_append_members_A_New() *A_arbace_box_build_append_members_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_append_members_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_box_build_append_members_A) Ctor() {}
//line :167:1
func (t *A_arbace_box_build_append_members_A) Invoke_O_O_O__O(self, archive__0, members__1 any) any { var o__3 any = jrt.ByteArrayOutputStream_New();

	jrt.OutputStream_Cast(o__3).Write_B1__V(jrt.ByteArray_Cast(archive__0)); var seq_598000080__4 any; var root_602 any = /*line :167:1*/A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_604 lang.IFn; if


	linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = members__1; if linked_603 == nil { seq_598000080__4 = ifn_604.Invoke_O__O(arg_605) } else { seq_598000080__4 = linked_603.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_602, arg_605) }; var chunk_598000081__5 any; var count_598000082__6 int64 = 0; var i_598000083__7 int64 = 0; L1:
//line :167:1
	for {


		if lang.Numbers_Lt_J_J__Z_NoInit(i_598000083__7, count_598000082__6) { var vec__598000084__8 any = lang.Indexed_Cast(chunk_598000081__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_598000083__7)); var n__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000084__8, lang.RT_IntCast_J__I_NoInit(0), nil); var data__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000084__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 jrt.OutputStream_I = jrt.OutputStream_Cast(o__3); var tmp2 any; var root_622 any = A_arbace_box_build_A_const_104.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, A_arbace_box_build_ar_member_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = n__9; var arg_626 any = data__10; if linked_623 == nil { tmp2 = ifn_624.Invoke_O_O__O(arg_625, arg_626) } else { tmp2 = linked_623.(*A_arbace_box_build_ar_member_A).Invoke_O_O_O__O(root_622, arg_625, arg_626) }; tmp1.Write_B1__V(jrt.ByteArray_Cast(tmp2)); seq_598000080__4, chunk_598000081__5, count_598000082__6, i_598000083__7 = seq_598000080__4, chunk_598000081__5, count_598000082__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_598000083__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_606 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = seq_598000080__4; if linked_607 == nil { temp__1927000414__auto____8 = ifn_608.Invoke_O__O(arg_609) } else { temp__1927000414__auto____8 = linked_607.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_606, arg_609) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_598000080__9 any = temp__1927000414__auto____8; var tmp3 any; var root_610 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = seq_598000080__9; if linked_611 == nil { tmp3 = ifn_612.Invoke_O__O(arg_613) } else { tmp3 = linked_611.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_610, arg_613) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____10 any; var root_614 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = seq_598000080__9; if linked_615 == nil { c__1927000678__auto____10 = ifn_616.Invoke_O__O(arg_617) } else { c__1927000678__auto____10 = linked_615.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_614, arg_617) }; var tmp4 any; var root_627 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_629 lang.IFn; if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = seq_598000080__9; if linked_628 == nil { tmp4 = ifn_629.Invoke_O__O(arg_630) } else { tmp4 = linked_628.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_627, arg_630) }; seq_598000080__4, chunk_598000081__5, count_598000082__6, i_598000083__7 = tmp4, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__598000087__10 any; var root_618 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = seq_598000080__9; if linked_619 == nil { vec__598000087__10 = ifn_620.Invoke_O__O(arg_621) } else { vec__598000087__10 = linked_619.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_618, arg_621) }; var n__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000087__10, lang.RT_IntCast_J__I_NoInit(0), nil); var data__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000087__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 jrt.OutputStream_I = jrt.OutputStream_Cast(o__3); var tmp6 any; var root_631 any = A_arbace_box_build_A_const_104.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, A_arbace_box_build_ar_member_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = n__11; var arg_635 any = data__12; if linked_632 == nil { tmp6 = ifn_633.Invoke_O_O__O(arg_634, arg_635) } else { tmp6 = linked_632.(*A_arbace_box_build_ar_member_A).Invoke_O_O_O__O(root_631, arg_634, arg_635) }; tmp5.Write_B1__V(jrt.ByteArray_Cast(tmp6)); var tmp7 any; var root_636 any = A_arbace_box_build_A_const_20.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_638 lang.IFn; if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any = seq_598000080__9; if linked_637 == nil { tmp7 = ifn_638.Invoke_O__O(arg_639) } else { tmp7 = linked_637.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_636, arg_639) }; seq_598000080__4, chunk_598000081__5, count_598000082__6, i_598000083__7 = tmp7, nil, 0, 0; continue L1 } } }
//line :167:1
		break L1 }; return /*line :171:1*/ jrt.ByteArrayOutputStream_Cast(o__3).ToByteArray__B1().Ref() }






func A_arbace_box_build_complete_QMARK__A_New() *A_arbace_box_build_complete_QMARK__A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_complete_QMARK__A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_box_build_complete_QMARK__A) Ctor() {}
//line :178:1
func (t *A_arbace_box_build_complete_QMARK__A) Invoke_O_O__O(self, pkg__0 any) any { var and__1927000168__auto____2 any; var root_640 any = A_arbace_box_build_A_const_105.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_642 lang.IFn; if


	linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = A_arbace_box_build_A_const_106.Invoke_O__O(pkg__0); if linked_641 == nil { and__1927000168__auto____2 = ifn_642.Invoke_O__O(arg_643) } else { and__1927000168__auto____2 = linked_641.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_640, arg_643) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_644 any = A_arbace_box_build_A_const_73.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any; var and__1927000168__auto____3 any = A_arbace_box_build_A_const_93.Invoke_O__O(pkg__0); if jrt.J2g_Truth(and__1927000168__auto____3) { arg_647 = lang.IFn_Cast(A_arbace_box_build_A_const_107.GetRawRoot__O()).Invoke_O__O(A_arbace_box_build_A_const_91.Invoke_O__O(pkg__0)) } else { arg_647 = and__1927000168__auto____3 }; if linked_645 == nil { return ifn_646.Invoke_O__O(arg_647) } else { return linked_645.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_644, arg_647) } } else { return and__1927000168__auto____2 } }

func A_arbace_box_build_deps_tree_A_New() *A_arbace_box_build_deps_tree_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_box_build_deps_tree_A) Ctor() {}
//line :183:1
func (t *A_arbace_box_build_deps_tree_A) Invoke_O_O_O_O__O(self, archives__0, index__1, paths__2 any) any { var tmp1 any; var root_648 any = A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_650 lang.IFn; if



	linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any; var root_652 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_656 any; var iter__1927001039__auto____4 any; var fnbody__718 any = A_arbace_box_build_deps_tree_iter__598000092__598000096_A_New_O_O(archives__0, index__1); var tmp2 *jrt.Class; var fncls__717 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000092__598000096_A_fn_class; if fncls__717 == nil { var fncls__717d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, fnbody__718); A_arbace_box_build_deps_tree_iter__598000092__598000096_A_fn_class = fncls__717d; tmp2 = fncls__717d } else { tmp2 = fncls__717 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__718, tmp2, nil); arg_656 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(paths__2); if linked_653 == nil { arg_651 = ifn_654.Invoke_O_O__O(arg_655, arg_656) } else { arg_651 = linked_653.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_652, arg_655, arg_656) }; if linked_649 == nil { tmp1 = ifn_650.Invoke_O__O(arg_651) } else { tmp1 = linked_649.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_648, arg_651) }; var tmp3 any = tmp1; var tmp4 any; var iter__1927001039__auto____4_2 any; var fnbody__780 any = /*line :183:1*/A_arbace_box_build_deps_tree_iter__598000102__598000106_A_New_O(index__1); var tmp5 *jrt.Class; var fncls__779 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000102__598000106_A_fn_class; if




	fncls__779 == nil { var fncls__779d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, fnbody__780); A_arbace_box_build_deps_tree_iter__598000102__598000106_A_fn_class = fncls__779d; tmp5 = fncls__779d } else { tmp5 = fncls__779 }; iter__1927001039__auto____4_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__780, tmp5, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____4_2).Invoke_O__O(paths__2); return /*line :183:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) }



func A_arbace_box_build_deps_tree_iter__598000092__598000096_A_New_O_O(p0, p1 any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000092__598000096_A{}; t.Ctor_O_O(p0, p1); return t }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_A) Ctor_O_O(c__archives, c__index any) { t.F_archives = c__archives; t.F_index = c__index }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_A) Invoke_O_O__O(self, s__598000093__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__716 any = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_New_O_O_O_O(t.F_archives, t.F_index, self, s__598000093__1); var tmp2 *jrt.Class; var fncls__715 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_fn_class; if fncls__715 == nil { var fncls__715d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, fnbody__716); A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_fn_class = fncls__715d; tmp2 = fncls__715d } else { tmp2 = fncls__715 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__716, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :187:1
func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A) Ctor_O_O_O_O(c__archives, c__index, c__iter__598000092, c__s__598000093 any) { t.F_archives = c__archives; t.F_index = c__index; t.F_iter__598000092 = c__iter__598000092; t.F_s__598000093 = c__s__598000093 }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A) Invoke_O__O(self any) any { { var s__598000093__1 any; var t_ any = t.F_s__598000093; t.F_s__598000093 = nil; s__598000093__1 = t_; for { var temp__1927000414__auto____2 any; var root_657 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = s__598000093__1; if linked_658 == nil { temp__1927000414__auto____2 = ifn_659.Invoke_O__O(arg_660) } else { temp__1927000414__auto____2 = linked_658.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_657, arg_660) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000093__3 any = temp__1927000414__auto____2; var tmp1 any; var root_661 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = s__598000093__3; if linked_662 == nil { tmp1 = ifn_663.Invoke_O__O(arg_664) } else { tmp1 = linked_662.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_661, arg_664) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_665 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = s__598000093__3; if linked_666 == nil { c__1927001037__auto____4 = ifn_667.Invoke_O__O(arg_668) } else { c__1927001037__auto____4 = linked_666.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_665, arg_668) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000095__6 any; var root_669 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_670 == nil { b__598000095__6 = ifn_671.Invoke_O__O(arg_672) } else { b__598000095__6 = linked_670.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_669, arg_672) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__679 any = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_New_O_O_O_I_O(b__598000095__6, t.F_archives, t.F_index, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__678 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_fn_class; if fncls__678 == nil { var fncls__678d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, fnbody__679); A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_fn_class = fncls__678d; tmp3 = fncls__678d } else { tmp3 = fncls__678 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__679, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_680 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any; var root_685 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any = b__598000095__6; if linked_686 == nil { arg_683 = ifn_687.Invoke_O__O(arg_688) } else { arg_683 = linked_686.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_685, arg_688) }; var arg_684 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000092); var tmp5 any; var root_689 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any = s__598000093__3; if linked_690 == nil { tmp5 = ifn_691.Invoke_O__O(arg_692) } else { tmp5 = linked_690.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_689, arg_692) }; arg_684 = tmp4.Invoke_O__O(tmp5); if linked_681 == nil { return ifn_682.Invoke_O_O__O(arg_683, arg_684) } else { return linked_681.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_680, arg_683, arg_684) } } else { var root_693 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any; var root_698 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = b__598000095__6; if linked_699 == nil { arg_696 = ifn_700.Invoke_O__O(arg_701) } else { arg_696 = linked_699.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_698, arg_701) }; var arg_697 any; if linked_694 == nil { return ifn_695.Invoke_O_O__O(arg_696, arg_697) } else { return linked_694.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_693, arg_696, arg_697) } } } else { var p__4 any; var root_702 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = s__598000093__3; if linked_703 == nil { p__4 = ifn_704.Invoke_O__O(arg_705) } else { p__4 = linked_703.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_702, arg_705) }; var a__5 any = lang.IFn_Cast(t.F_archives).Invoke_O__O(p__4); var root_706 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(t.F_index).Invoke_O__O(p__4), nil)).Ref(), a__5); var arg_710 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000092); var tmp7 any; var root_711 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = s__598000093__3; if linked_712 == nil { tmp7 = ifn_713.Invoke_O__O(arg_714) } else { tmp7 = linked_712.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_711, arg_714) }; arg_710 = tmp6.Invoke_O__O(tmp7); if linked_707 == nil { return ifn_708.Invoke_O_O__O(arg_709, arg_710) } else { return linked_707.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_706, arg_709, arg_710) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :187:1
func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A) Ctor_O_O_O_I_O(c__b__598000095, c__archives, c__index any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000095 = c__b__598000095; t.F_archives = c__archives; t.F_index = c__index; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A) Invoke_O__O(self any) any { { var i__598000094__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000094__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000094__1)); var a__3 any = lang.IFn_Cast(t.F_archives).Invoke_O__O(p__2); var root_673 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_673, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_675 lang.IFn; if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any = t.F_b__598000095; var arg_677 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(t.F_index).Invoke_O__O(p__2), nil)).Ref(), a__3); if linked_674 == nil { ifn_675.Invoke_O_O__O(arg_676, arg_677) } else { linked_674.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_673, arg_676, arg_677) }; i__598000094__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000094__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_box_build_deps_tree_iter__598000102__598000106_A_New_O(p0 any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000102__598000106_A{}; t.Ctor_O(p0); return t }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_A) Ctor_O(c__index any) { t.F_index = c__index }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_A) Invoke_O_O__O(self, s__598000103__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__778 any = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_New_O_O_O(s__598000103__1, t.F_index, self); var tmp2 *jrt.Class; var fncls__777 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_fn_class; if fncls__777 == nil { var fncls__777d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_95, false, fnbody__778); A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_fn_class = fncls__777d; tmp2 = fncls__777d } else { tmp2 = fncls__777 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__778, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :188:1
func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A) Ctor_O_O_O(c__s__598000103, c__index, c__iter__598000102 any) { t.F_s__598000103 = c__s__598000103; t.F_index = c__index; t.F_iter__598000102 = c__iter__598000102 }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A) Invoke_O__O(self any) any { { var s__598000103__1 any; var t_ any = t.F_s__598000103; t.F_s__598000103 = nil; s__598000103__1 = t_; for { var temp__1927000414__auto____2 any; var root_719 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = s__598000103__1; if linked_720 == nil { temp__1927000414__auto____2 = ifn_721.Invoke_O__O(arg_722) } else { temp__1927000414__auto____2 = linked_720.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_719, arg_722) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000103__3 any = temp__1927000414__auto____2; var tmp1 any; var root_723 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = s__598000103__3; if linked_724 == nil { tmp1 = ifn_725.Invoke_O__O(arg_726) } else { tmp1 = linked_724.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_723, arg_726) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_727 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = s__598000103__3; if linked_728 == nil { c__1927001037__auto____4 = ifn_729.Invoke_O__O(arg_730) } else { c__1927001037__auto____4 = linked_728.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_727, arg_730) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000105__6 any; var root_731 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_731, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_733 lang.IFn; if linked_732 == nil { ifn_733 = lang.IFn_Cast(root_731) } else { ifn_733 = nil }; var arg_734 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_732 == nil { b__598000105__6 = ifn_733.Invoke_O__O(arg_734) } else { b__598000105__6 = linked_732.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_731, arg_734) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__741 any = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_New_O_O_I_O(t.F_index, b__598000105__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__740 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_fn_class; if fncls__740 == nil { var fncls__740d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_96, false, fnbody__741); A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_fn_class = fncls__740d; tmp3 = fncls__740d } else { tmp3 = fncls__740 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__741, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_742 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any; var root_747 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = b__598000105__6; if linked_748 == nil { arg_745 = ifn_749.Invoke_O__O(arg_750) } else { arg_745 = linked_748.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_747, arg_750) }; var arg_746 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000102); var tmp5 any; var root_751 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = s__598000103__3; if linked_752 == nil { tmp5 = ifn_753.Invoke_O__O(arg_754) } else { tmp5 = linked_752.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_751, arg_754) }; arg_746 = tmp4.Invoke_O__O(tmp5); if linked_743 == nil { return ifn_744.Invoke_O_O__O(arg_745, arg_746) } else { return linked_743.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_742, arg_745, arg_746) } } else { var root_755 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any; var root_760 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = b__598000105__6; if linked_761 == nil { arg_758 = ifn_762.Invoke_O__O(arg_763) } else { arg_758 = linked_761.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_760, arg_763) }; var arg_759 any; if linked_756 == nil { return ifn_757.Invoke_O_O__O(arg_758, arg_759) } else { return linked_756.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_755, arg_758, arg_759) } } } else { var p__4 any; var root_764 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = s__598000103__3; if linked_765 == nil { p__4 = ifn_766.Invoke_O__O(arg_767) } else { p__4 = linked_765.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_764, arg_767) }; var root_768 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_97, nil, Lit_98, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, nil, p__4, nil, lang.IFn_Cast(t.F_index).Invoke_O__O(p__4), nil)).Ref(); var arg_772 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000102); var tmp7 any; var root_773 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = s__598000103__3; if linked_774 == nil { tmp7 = ifn_775.Invoke_O__O(arg_776) } else { tmp7 = linked_774.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_773, arg_776) }; arg_772 = tmp6.Invoke_O__O(tmp7); if linked_769 == nil { return ifn_770.Invoke_O_O__O(arg_771, arg_772) } else { return linked_769.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_768, arg_771, arg_772) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :188:1
func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A) Ctor_O_O_I_O(c__index, c__b__598000105 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_index = c__index; t.F_b__598000105 = c__b__598000105; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A) Invoke_O__O(self any) any { { var i__598000104__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000104__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000104__1)); var root_735 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_737 lang.IFn; if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = t.F_b__598000105; var arg_739 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_97, nil, Lit_98, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, nil, p__2, nil, lang.IFn_Cast(t.F_index).Invoke_O__O(p__2), nil)).Ref(); if linked_736 == nil { ifn_737.Invoke_O_O__O(arg_738, arg_739) } else { linked_736.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_735, arg_738, arg_739) }; i__598000104__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000104__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_box_build_json_str_A_New() *A_arbace_box_build_json_str_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_json_str_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_box_build_json_str_A) Ctor() {}
//line :190:1
func (t *A_arbace_box_build_json_str_A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_123, nil, Lit_123); var tmp2 any; var root_781 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_785 any; var root_786 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any; var fnbody__801 any = A_arbace_box_build_json_str_fn__598000113_A_New(); var tmp3 *jrt.Class; var fncls__800 *jrt.Class = A_arbace_box_build_json_str_fn__598000113_A_fn_class; if fncls__800 == nil { var fncls__800d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_124, false, nil); A_arbace_box_build_json_str_fn__598000113_A_fn_class = fncls__800d; tmp3 = fncls__800d } else { tmp3 = fncls__800 }; arg_789 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__801, tmp3, nil); var arg_790 any = s__0; if linked_787 == nil { arg_785 = ifn_788.Invoke_O_O__O(arg_789, arg_790) } else { arg_785 = linked_787.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_786, arg_789, arg_790) }; if linked_782 == nil { tmp2 = ifn_783.Invoke_O_O__O(arg_784, arg_785) } else { tmp2 = linked_782.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_781, arg_784, arg_785) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil)).Ref() }
//line :193:1
func A_arbace_box_build_json_str_fn__598000113_A_New() *A_arbace_box_build_json_str_fn__598000113_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_json_str_fn__598000113_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_box_build_json_str_fn__598000113_A) Ctor() {}
//line :193:1
func (t *A_arbace_box_build_json_str_fn__598000113_A) Invoke_O_O__O(self, c__1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(c__1, A_arbace_box_build_A_const_109) { return Lit_125 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__1, A_arbace_box_build_A_const_110) { return Lit_126 } else { if lang.Numbers_Lt_J_J__Z_NoInit(int64(lang.RT_IntCast_O__I_NoInit(c__1)), 32) {
											return lang.IFn_Cast(A_arbace_box_build_A_const_77.GetRawRoot__O()).Invoke_O_O__O(Lit_127, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(c__1)).Ref()) } else {
//line :193:1
		if A_arbace_box_build_A_const_111 != nil {

			var root_796 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = c__1; if linked_797 == nil { return ifn_798.Invoke_O__O(arg_799) } else { return linked_797.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_796, arg_799) } } else {
//line :193:1
				return nil } } } } }





func A_arbace_box_build_embed_config_A_New() *A_arbace_box_build_embed_config_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_box_build_embed_config_A) Ctor() {}
//line :199:1
func (t *A_arbace_box_build_embed_config_A) Invoke_O_O__O(self, patterns__0 any) any { var files__2 any; var root_802 any = A_arbace_box_build_A_const_112.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_804 lang.IFn; if



	linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any; var root_806 any = A_arbace_box_build_A_const_113.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = lang.IFn_Cast(A_arbace_box_build_A_const_92.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_114.GetRawRoot__O(), patterns__0); if linked_807 == nil { arg_805 = ifn_808.Invoke_O__O(arg_809) } else { arg_805 = linked_807.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_806, arg_809) }; if linked_803 == nil { files__2 = ifn_804.Invoke_O__O(arg_805) } else { files__2 = linked_803.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_802, arg_805) }; var tmp1 /*line :204:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_99, nil, Lit_100, nil, Lit_101); var tmp2 any; var root_815 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_815, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_817 lang.IFn; if
	linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_819 any; var root_820 any = A_arbace_box_build_A_const_115.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_822 lang.IFn; if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any = Lit_102; var arg_824 any; var iter__1927001039__auto____8 any; var fnbody__924 any = A_arbace_box_build_embed_config_iter__598000116__598000120_A_New(); var tmp3 *jrt.Class; var fncls__923 *jrt.Class = A_arbace_box_build_embed_config_iter__598000116__598000120_A_fn_class; if fncls__923 == nil { var fncls__923d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_103, false, nil); A_arbace_box_build_embed_config_iter__598000116__598000120_A_fn_class = fncls__923d; tmp3 = fncls__923d } else { tmp3 = fncls__923 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__924, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp5 any; var root_925 any = A_arbace_box_build_A_const_117.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_927 lang.IFn; if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = A_arbace_box_build_A_const_118.GetRawRoot__O(); var arg_929 any = patterns__0; if linked_926 == nil { tmp5 = ifn_927.Invoke_O_O__O(arg_928, arg_929) } else { tmp5 = linked_926.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_925, arg_928, arg_929) }; arg_824 = tmp4.Invoke_O__O(tmp5); if linked_821 == nil { arg_819 = ifn_822.Invoke_O_O__O(arg_823, arg_824) } else { arg_819 = linked_821.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_820, arg_823, arg_824) }; if linked_816 == nil { tmp2 = ifn_817.Invoke_O_O__O(arg_818, arg_819) } else { tmp2 = linked_816.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_815, arg_818, arg_819) }; var tmp6 any = tmp2; var tmp7 any; var root_930 any = /*line :204:1*/A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_932 lang.IFn; if



	linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_934 any; var root_935 any = A_arbace_box_build_A_const_115.GetRawRoot__O(); var linked_936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_935, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_937 lang.IFn; if linked_936 == nil { ifn_937 = lang.IFn_Cast(root_935) } else { ifn_937 = nil }; var arg_938 any = Lit_102; var arg_939 any; var iter__1927001039__auto____8_2 any; var fnbody__1017 any = A_arbace_box_build_embed_config_iter__598000132__598000136_A_New(); var tmp8 *jrt.Class; var fncls__1016 *jrt.Class = A_arbace_box_build_embed_config_iter__598000132__598000136_A_fn_class; if fncls__1016 == nil { var fncls__1016d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_104, false, nil); A_arbace_box_build_embed_config_iter__598000132__598000136_A_fn_class = fncls__1016d; tmp8 = fncls__1016d } else { tmp8 = fncls__1016 }; iter__1927001039__auto____8_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1017, tmp8, nil); arg_939 = lang.IFn_Cast(iter__1927001039__auto____8_2).Invoke_O__O(files__2); if linked_936 == nil { arg_934 = ifn_937.Invoke_O_O__O(arg_938, arg_939) } else { arg_934 = linked_936.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_935, arg_938, arg_939) }; if linked_931 == nil { tmp7 = ifn_932.Invoke_O_O__O(arg_933, arg_934) } else { tmp7 = linked_931.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_930, arg_933, arg_934) }; return /*line :204:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, tmp7, nil)).Ref() }
func A_arbace_box_build_embed_config_iter__598000116__598000120_A_New() *A_arbace_box_build_embed_config_iter__598000116__598000120_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000116__598000120_A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_A) Ctor() {}
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_A) Invoke_O_O__O(self, s__598000117__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__922 any = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_New_O_O(self, s__598000117__1); var tmp2 *jrt.Class; var fncls__921 *jrt.Class = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_fn_class; if fncls__921 == nil { var fncls__921d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_105, false, fnbody__922); A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_fn_class = fncls__921d; tmp2 = fncls__921d } else { tmp2 = fncls__921 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__922, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :205:1
func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_New_O_O(p0, p1 any) *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A{}; t.Ctor_O_O(p0, p1); return t }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A) Ctor_O_O(c__iter__598000116, c__s__598000117 any) { t.F_iter__598000116 = c__iter__598000116; t.F_s__598000117 = c__s__598000117 }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A) Invoke_O__O(self any) any { { var s__598000117__1 any; var t_ any = t.F_s__598000117; t.F_s__598000117 = nil; s__598000117__1 = t_; for { var temp__1927000414__auto____2 any; var root_825 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_827 lang.IFn; if linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = s__598000117__1; if linked_826 == nil { temp__1927000414__auto____2 = ifn_827.Invoke_O__O(arg_828) } else { temp__1927000414__auto____2 = linked_826.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_825, arg_828) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000117__3 any = temp__1927000414__auto____2; var tmp1 any; var root_829 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = s__598000117__3; if linked_830 == nil { tmp1 = ifn_831.Invoke_O__O(arg_832) } else { tmp1 = linked_830.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_829, arg_832) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_833 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_835 lang.IFn; if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = s__598000117__3; if linked_834 == nil { c__1927001037__auto____4 = ifn_835.Invoke_O__O(arg_836) } else { c__1927001037__auto____4 = linked_834.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_833, arg_836) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000119__6 any; var root_837 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_838 == nil { b__598000119__6 = ifn_839.Invoke_O__O(arg_840) } else { b__598000119__6 = linked_838.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_837, arg_840) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__866 any = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_New_O_I_O(b__598000119__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__865 *jrt.Class = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_fn_class; if fncls__865 == nil { var fncls__865d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_106, false, fnbody__866); A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_fn_class = fncls__865d; tmp3 = fncls__865d } else { tmp3 = fncls__865 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__866, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_867 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_869 lang.IFn; if linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any; var root_872 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_872, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_874 lang.IFn; if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any = b__598000119__6; if linked_873 == nil { arg_870 = ifn_874.Invoke_O__O(arg_875) } else { arg_870 = linked_873.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_872, arg_875) }; var arg_871 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000116); var tmp5 any; var root_876 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = s__598000117__3; if linked_877 == nil { tmp5 = ifn_878.Invoke_O__O(arg_879) } else { tmp5 = linked_877.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_876, arg_879) }; arg_871 = tmp4.Invoke_O__O(tmp5); if linked_868 == nil { return ifn_869.Invoke_O_O__O(arg_870, arg_871) } else { return linked_868.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_867, arg_870, arg_871) } } else { var root_880 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any; var root_885 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = b__598000119__6; if linked_886 == nil { arg_883 = ifn_887.Invoke_O__O(arg_888) } else { arg_883 = linked_886.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_885, arg_888) }; var arg_884 any; if linked_881 == nil { return ifn_882.Invoke_O_O__O(arg_883, arg_884) } else { return linked_881.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_880, arg_883, arg_884) } } } else { var vec__598000127__4 any; var root_889 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = s__598000117__3; if linked_890 == nil { vec__598000127__4 = ifn_891.Invoke_O__O(arg_892) } else { vec__598000127__4 = linked_890.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_889, arg_892) }; var p__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000127__4, lang.RT_IntCast_J__I_NoInit(0), nil); var fs__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000127__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_893 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_107, nil, Lit_108); var tmp7 any; var root_898 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, A_arbace_box_build_json_str_A_fn_class); var ifn_900 lang.IFn
														if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = p__5; if linked_899 == nil { tmp7 = ifn_900.Invoke_O__O(arg_901) } else { tmp7 = linked_899.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_898, arg_901) }; var tmp8 any = tmp7; var tmp9 any; var root_902 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_902, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_904 lang.IFn; if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_906 any; var root_907 any = A_arbace_box_build_A_const_115.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = Lit_102; var arg_911 any; var root_912 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_912, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_914 lang.IFn; if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var arg_916 any = fs__6; if linked_913 == nil { arg_911 = ifn_914.Invoke_O_O__O(arg_915, arg_916) } else { arg_911 = linked_913.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_912, arg_915, arg_916) }; if linked_908 == nil { arg_906 = ifn_909.Invoke_O_O__O(arg_910, arg_911) } else { arg_906 = linked_908.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_907, arg_910, arg_911) }; if linked_903 == nil { tmp9 = ifn_904.Invoke_O_O__O(arg_905, arg_906) } else { tmp9 = linked_903.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_902, arg_905, arg_906) }; arg_896 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9, nil)).Ref()
//line :205:1
	var arg_897 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__598000116); var tmp11 any; var root_917 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_919 lang.IFn; if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any = s__598000117__3; if linked_918 == nil { tmp11 = ifn_919.Invoke_O__O(arg_920) } else { tmp11 = linked_918.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_917, arg_920) }; arg_897 = tmp10.Invoke_O__O(tmp11); if linked_894 == nil { return ifn_895.Invoke_O_O__O(arg_896, arg_897) } else { return linked_894.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_893, arg_896, arg_897) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :205:1
func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A) Ctor_O_I_O(c__b__598000119 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000119 = c__b__598000119; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A) Invoke_O__O(self any) any { { var i__598000118__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000118__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000123__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000118__1)); var p__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000123__2, lang.RT_IntCast_J__I_NoInit(0), nil); var fs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000123__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_841 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any = t.F_b__598000119; var arg_845 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_107, nil, Lit_108); var tmp3 any; var root_846 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, A_arbace_box_build_json_str_A_fn_class); var ifn_848 lang.IFn
																if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any = p__3; if linked_847 == nil { tmp3 = ifn_848.Invoke_O__O(arg_849) } else { tmp3 = linked_847.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_846, arg_849) }; var tmp4 any = tmp3; var tmp5 any; var root_850 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_854 any; var root_855 any = A_arbace_box_build_A_const_115.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any = Lit_102; var arg_859 any; var root_860 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var arg_864 any = fs__4; if linked_861 == nil { arg_859 = ifn_862.Invoke_O_O__O(arg_863, arg_864) } else { arg_859 = linked_861.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_860, arg_863, arg_864) }; if linked_856 == nil { arg_854 = ifn_857.Invoke_O_O__O(arg_858, arg_859) } else { arg_854 = linked_856.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_855, arg_858, arg_859) }; if linked_851 == nil { tmp5 = ifn_852.Invoke_O_O__O(arg_853, arg_854) } else { tmp5 = linked_851.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_850, arg_853, arg_854) }; arg_845 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5, nil)).Ref()
//line :205:1
	if linked_842 == nil { ifn_843.Invoke_O_O__O(arg_844, arg_845) } else { linked_842.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_841, arg_844, arg_845) }; i__598000118__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000118__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_box_build_embed_config_iter__598000132__598000136_A_New() *A_arbace_box_build_embed_config_iter__598000132__598000136_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000132__598000136_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_A) Ctor() {}
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_A) Invoke_O_O__O(self, s__598000133__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1015 any = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_New_O_O(s__598000133__1, self); var tmp2 *jrt.Class; var fncls__1014 *jrt.Class = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_fn_class; if fncls__1014 == nil { var fncls__1014d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_109, false, fnbody__1015); A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_fn_class = fncls__1014d; tmp2 = fncls__1014d } else { tmp2 = fncls__1014 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1015, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :208:1
func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_New_O_O(p0, p1 any) *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A{}; t.Ctor_O_O(p0, p1); return t }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A) Ctor_O_O(c__s__598000133, c__iter__598000132 any) { t.F_s__598000133 = c__s__598000133; t.F_iter__598000132 = c__iter__598000132 }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A) Invoke_O__O(self any) any { { var s__598000133__1 any; var t_ any = t.F_s__598000133; t.F_s__598000133 = nil; s__598000133__1 = t_; for { var temp__1927000414__auto____2 any; var root_940 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_942 lang.IFn; if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = s__598000133__1; if linked_941 == nil { temp__1927000414__auto____2 = ifn_942.Invoke_O__O(arg_943) } else { temp__1927000414__auto____2 = linked_941.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_940, arg_943) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000133__3 any = temp__1927000414__auto____2; var tmp1 any; var root_944 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_946 lang.IFn; if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = s__598000133__3; if linked_945 == nil { tmp1 = ifn_946.Invoke_O__O(arg_947) } else { tmp1 = linked_945.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_944, arg_947) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_948 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = s__598000133__3; if linked_949 == nil { c__1927001037__auto____4 = ifn_950.Invoke_O__O(arg_951) } else { c__1927001037__auto____4 = linked_949.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_948, arg_951) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000135__6 any; var root_952 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_953 == nil { b__598000135__6 = ifn_954.Invoke_O__O(arg_955) } else { b__598000135__6 = linked_953.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_952, arg_955) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__970 any = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_New_O_I_O(b__598000135__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__969 *jrt.Class = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_fn_class; if fncls__969 == nil { var fncls__969d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_110, false, fnbody__970); A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_fn_class = fncls__969d; tmp3 = fncls__969d } else { tmp3 = fncls__969 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__970, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_971 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any; var root_976 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = b__598000135__6; if linked_977 == nil { arg_974 = ifn_978.Invoke_O__O(arg_979) } else { arg_974 = linked_977.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_976, arg_979) }; var arg_975 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000132); var tmp5 any; var root_980 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = s__598000133__3; if linked_981 == nil { tmp5 = ifn_982.Invoke_O__O(arg_983) } else { tmp5 = linked_981.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_980, arg_983) }; arg_975 = tmp4.Invoke_O__O(tmp5); if linked_972 == nil { return ifn_973.Invoke_O_O__O(arg_974, arg_975) } else { return linked_972.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_971, arg_974, arg_975) } } else { var root_984 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any; var root_989 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = b__598000135__6; if linked_990 == nil { arg_987 = ifn_991.Invoke_O__O(arg_992) } else { arg_987 = linked_990.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_989, arg_992) }; var arg_988 any; if linked_985 == nil { return ifn_986.Invoke_O_O__O(arg_987, arg_988) } else { return linked_985.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_984, arg_987, arg_988) } } } else { var f__4 any; var root_993 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_993, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_995 lang.IFn; if linked_994 == nil { ifn_995 = lang.IFn_Cast(root_993) } else { ifn_995 = nil }; var arg_996 any = s__598000133__3; if linked_994 == nil { f__4 = ifn_995.Invoke_O__O(arg_996) } else { f__4 = linked_994.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_993, arg_996) }; var root_997 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_111, nil); var tmp7 any; var root_1002 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, A_arbace_box_build_json_str_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = f__4; if linked_1003 == nil { tmp7 = ifn_1004.Invoke_O__O(arg_1005) } else { tmp7 = linked_1003.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_1002, arg_1005) }; var tmp8 any = tmp7; var tmp9 any; var root_1006 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, A_arbace_box_build_json_str_A_fn_class); var ifn_1008 lang.IFn; if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__4)).Ref(); if linked_1007 == nil { tmp9 = ifn_1008.Invoke_O__O(arg_1009) } else { tmp9 = linked_1007.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_1006, arg_1009) }; arg_1000 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_1001 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__598000132); var tmp11 any; var root_1010 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1012 lang.IFn; if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; var arg_1013 any = s__598000133__3; if linked_1011 == nil { tmp11 = ifn_1012.Invoke_O__O(arg_1013) } else { tmp11 = linked_1011.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1010, arg_1013) }; arg_1001 = tmp10.Invoke_O__O(tmp11); if linked_998 == nil { return ifn_999.Invoke_O_O__O(arg_1000, arg_1001) } else { return linked_998.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_997, arg_1000, arg_1001) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :208:1
func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A) Ctor_O_I_O(c__b__598000135 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000135 = c__b__598000135; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A) Invoke_O__O(self any) any { { var i__598000134__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000134__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000134__1)); var root_956 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = t.F_b__598000135; var arg_960 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_111, nil); var tmp3 any; var root_961 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, A_arbace_box_build_json_str_A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any = f__2; if linked_962 == nil { tmp3 = ifn_963.Invoke_O__O(arg_964) } else { tmp3 = linked_962.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_961, arg_964) }; var tmp4 any = tmp3; var tmp5 any; var root_965 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, A_arbace_box_build_json_str_A_fn_class); var ifn_967 lang.IFn; if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__2)).Ref(); if linked_966 == nil { tmp5 = ifn_967.Invoke_O__O(arg_968) } else { tmp5 = linked_966.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_965, arg_968) }; arg_960 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref(); if linked_957 == nil { ifn_958.Invoke_O_O__O(arg_959, arg_960) } else { linked_957.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_956, arg_959, arg_960) }; i__598000134__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000134__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_box_build_build_package_A_New() *A_arbace_box_build_build_package_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_box_build_build_package_A) Ctor() {}
//line :211:1
func (t *A_arbace_box_build_build_package_A) Invoke_O_O_O_O_O__O(self, plan__0, pkg__1, archives__2, index__3 any) any { var map__598000145__5 any = A_arbace_box_build_A_const_49.Get__O(); var map__598000145__6 any; if


	lang.ISeq_InstanceOf(map__598000145__5) { var tmp1 any; var root_1018 any = A_arbace_box_build_A_const_20.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = map__598000145__5; if linked_1019 == nil { tmp1 = ifn_1020.Invoke_O__O(arg_1021) } else { tmp1 = linked_1019.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1018, arg_1021) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1022 any = A_arbace_box_build_A_const_119.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = map__598000145__5; if linked_1023 == nil { tmp2 = ifn_1024.Invoke_O__O(arg_1025) } else { tmp2 = linked_1023.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1022, arg_1025) }; map__598000145__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1026 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1028 lang.IFn; if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = map__598000145__5; if linked_1027 == nil { tmp3 = ifn_1028.Invoke_O__O(arg_1029) } else { tmp3 = linked_1027.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1026, arg_1029) }; if jrt.J2g_Truth(tmp3) { var root_1030 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1030, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1032 lang.IFn; if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any = map__598000145__5; if linked_1031 == nil { map__598000145__6 = ifn_1032.Invoke_O__O(arg_1033) } else { map__598000145__6 = linked_1031.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1030, arg_1033) } } else { map__598000145__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__598000145__6 = map__598000145__5 }; var tools__7 any = /*line :211:1*/lang.RT_Get_O_O__O_NoInit(map__598000145__6, A_arbace_box_build_A_const_120); var P__8_ any = A_arbace_box_build_A_const_91.Invoke_O__O(pkg__1); var imports__9 any = A_arbace_box_build_A_const_121.Invoke_O__O(pkg__1); var vec__598000147__10 any; var root_1034 any = A_arbace_box_build_A_const_122.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, A_arbace_box_build_deps_tree_A_fn_class); var ifn_1036 lang.IFn; if





	linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = archives__2; var arg_1038 any = index__3; var arg_1039 any = imports__9; if linked_1035 == nil { vec__598000147__10 = ifn_1036.Invoke_O_O_O__O(arg_1037, arg_1038, arg_1039) } else { vec__598000147__10 = linked_1035.(*A_arbace_box_build_deps_tree_A).Invoke_O_O_O_O__O(root_1034, arg_1037, arg_1038, arg_1039) }; var dtree__11 any = /*line :211:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__598000147__10, lang.RT_IntCast_J__I_NoInit(0), nil); var lines__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000147__10, lang.RT_IntCast_J__I_NoInit(1), nil); var importcfg__13 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil, nil); var tmp5 any; var root_1040 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1042 lang.IFn; if







	linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_1044 any; var iter__1927001039__auto____16 any; var fnbody__1106 any = A_arbace_box_build_build_package_iter__598000150__598000154_A_New(); var tmp6 *jrt.Class; var fncls__1105 *jrt.Class = A_arbace_box_build_build_package_iter__598000150__598000154_A_fn_class; if fncls__1105 == nil { var fncls__1105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, nil); A_arbace_box_build_build_package_iter__598000150__598000154_A_fn_class = fncls__1105d; tmp6 = fncls__1105d } else { tmp6 = fncls__1105 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1106, tmp6, nil); var tmp7 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____16); var tmp8 any; var root_1107 any = A_arbace_box_build_A_const_112.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = A_arbace_box_build_A_const_123.Invoke_O__O(pkg__1); if linked_1108 == nil { tmp8 = ifn_1109.Invoke_O__O(arg_1110) } else { tmp8 = linked_1108.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1107, arg_1110) }; arg_1044 = tmp7.Invoke_O__O(tmp8); if linked_1041 == nil { tmp5 = ifn_1042.Invoke_O_O__O(arg_1043, arg_1044) } else { tmp5 = linked_1041.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1040, arg_1043, arg_1044) }; var tmp9 any = tmp5; var tmp10 any; var root_1111 any = /*line :218:1*/A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1113 lang.IFn; if

	linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_1115 any; var iter__1927001039__auto____16_2 any; var fnbody__1177 any = A_arbace_box_build_build_package_iter__598000166__598000170_A_New(); var tmp11 *jrt.Class; var fncls__1176 *jrt.Class = A_arbace_box_build_build_package_iter__598000166__598000170_A_fn_class; if fncls__1176 == nil { var fncls__1176d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, nil); A_arbace_box_build_build_package_iter__598000166__598000170_A_fn_class = fncls__1176d; tmp11 = fncls__1176d } else { tmp11 = fncls__1176 }; iter__1927001039__auto____16_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1177, tmp11, nil); arg_1115 = lang.IFn_Cast(iter__1927001039__auto____16_2).Invoke_O__O(lines__12); if linked_1112 == nil { tmp10 = ifn_1113.Invoke_O_O__O(arg_1114, arg_1115) } else { tmp10 = linked_1112.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1111, arg_1114, arg_1115) }; importcfg__13 = /*line :218:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, tmp10)).Ref(); var sfiles__14 any = /*line :211:1*/A_arbace_box_build_A_const_106.Invoke_O__O(pkg__1); var res_of__15 any; var fnbody__1189 any = A_arbace_box_build_build_package_res_of__598000176_A_New_O(P__8_); var tmp12 *jrt.Class; var fncls__1188 *jrt.Class = A_arbace_box_build_build_package_res_of__598000176_A_fn_class; if










	fncls__1188 == nil { var fncls__1188d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__1189); A_arbace_box_build_build_package_res_of__598000176_A_fn_class = fncls__1188d; tmp12 = fncls__1188d } else { tmp12 = fncls__1188 }; res_of__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1189, tmp12, nil); var rsc__16 any; var tmp13 /*line :211:1*/*lang.Keyword = A_arbace_box_build_A_const_126; var or__1927000174__auto____16 any = lang.RT_Get_O_O__O_NoInit(tmp13.Invoke_O__O(A_arbace_box_build_A_const_49.Get__O()), P__8_); if














	jrt.J2g_Truth(or__1927000174__auto____16) { rsc__16 = or__1927000174__auto____16 } else {
		var root_1190 any = A_arbace_box_build_A_const_127.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any; var fnbody__1216 any = A_arbace_box_build_build_package_fn__598000179_A_New_O(P__8_); var tmp14 *jrt.Class; var fncls__1215 *jrt.Class = A_arbace_box_build_build_package_fn__598000179_A_fn_class; if fncls__1215 == nil { var fncls__1215d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__1216); A_arbace_box_build_build_package_fn__598000179_A_fn_class = fncls__1215d; tmp14 = fncls__1215d } else { tmp14 = fncls__1215 }; arg_1193 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1216, tmp14, nil); var arg_1194 any; var root_1217 any = A_arbace_box_build_A_const_117.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1219 lang.IFn


		if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = lang.IFn_Cast(A_arbace_box_build_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_box_build_A_const_131.GetRawRoot__O(), A_arbace_box_build_A_const_132.GetRawRoot__O(), A_arbace_box_build_A_const_14.GetRawRoot__O(), A_arbace_box_build_A_const_118.GetRawRoot__O()); var tmp15 *lang.Keyword = A_arbace_box_build_A_const_126; var arg_1221 any = tmp15.Invoke_O__O(A_arbace_box_build_A_const_49.Get__O()); if linked_1218 == nil { arg_1194 = ifn_1219.Invoke_O_O__O(arg_1220, arg_1221) } else { arg_1194 = linked_1218.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1217, arg_1220, arg_1221) }
//line :227:1
		if linked_1191 == nil { rsc__16 = ifn_1192.Invoke_O_O__O(arg_1193, arg_1194) } else { rsc__16 = linked_1191.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1190, arg_1193, arg_1194) } }; var ___17 any; var tmp16 any; var and__1927000168__auto____17 any = /*line :211:1*/A_arbace_box_build_A_const_133.Invoke_O__O(pkg__1); _ = ___17; if



















	jrt.J2g_Truth(and__1927000168__auto____17) { var root_1229 any = A_arbace_box_build_A_const_73.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1231 lang.IFn; if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; var arg_1232 any = A_arbace_box_build_A_const_134.Invoke_O__O(pkg__1); if linked_1230 == nil { tmp16 = ifn_1231.Invoke_O__O(arg_1232) } else { tmp16 = linked_1230.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1229, arg_1232) } } else { tmp16 = and__1927000168__auto____17 }; if jrt.J2g_Truth(tmp16) {
		var root_1233 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_1234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1233, A_arbace_box_build_fail_A_fn_class); var ifn_1235 lang.IFn; if linked_1234 == nil { ifn_1235 = lang.IFn_Cast(root_1233) } else { ifn_1235 = nil }; var arg_1236 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_1, nil, Lit_50), jrt.RefArrayOf(jrt.Object_class, nil, P__8_, nil)).Ref(); var arg_1237 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_91, P__8_)); if linked_1234 == nil { ___17 = ifn_1235.Invoke_O_O__O(arg_1236, arg_1237) } else { ___17 = linked_1234.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_1233, arg_1236, arg_1237) } } else {
//line :231:1
			___17 = nil }; var embedcfg__18 any; var tmp17 /*line :211:1*/*lang.Keyword = A_arbace_box_build_A_const_135; var temp__1927000414__auto____18 any = tmp17.Invoke_O__O(A_arbace_box_build_A_const_134.Invoke_O__O(pkg__1)); if





















	jrt.J2g_Truth(temp__1927000414__auto____18) { var pats__19 any = temp__1927000414__auto____18; var root_1238 any = A_arbace_box_build_A_const_136.GetRawRoot__O(); var linked_1239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1238, A_arbace_box_build_embed_config_A_fn_class); var ifn_1240 lang.IFn
		if linked_1239 == nil { ifn_1240 = lang.IFn_Cast(root_1238) } else { ifn_1240 = nil }; var arg_1241 any = pats__19; if linked_1239 == nil { embedcfg__18 = ifn_1240.Invoke_O__O(arg_1241) } else { embedcfg__18 = linked_1239.(*A_arbace_box_build_embed_config_A).Invoke_O_O__O(root_1238, arg_1241) } } else {
//line :233:1
			embedcfg__18 = nil }; var symabis__19 any; var tmp18 any; var root_1242 any = /*line :211:1*/A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1242, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1244 lang.IFn; if























	linked_1243 == nil { ifn_1244 = lang.IFn_Cast(root_1242) } else { ifn_1244 = nil }; var arg_1245 any = sfiles__14; if linked_1243 == nil { tmp18 = ifn_1244.Invoke_O__O(arg_1245) } else { tmp18 = linked_1243.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1242, arg_1245) }; if jrt.J2g_Truth(tmp18) {
		var root_1246 any = A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1246, A_arbace_box_build_out_file_A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var arg_1249 any; var tmp19 lang.IFn = lang.IFn_Cast(res_of__15); var tmp20 any = A_arbace_box_build_A_const_138; var tmp21 any = A_arbace_box_build_A_const_139.Invoke_O__O(tools__7); var tmp22 any = A_arbace_box_build_A_const_78; var tmp23 any; var root_1252 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1254 lang.IFn

		if linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; var arg_1255 any = lang.IFn_Cast(A_arbace_box_build_A_const_140.GetRawRoot__O()).Invoke_O_O_O_O__O(plan__0, pkg__1, Lit_52, Lit_53); var arg_1256 any; var root_1264 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1264, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1266 lang.IFn; if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any; var fnbody__1270 any = A_arbace_box_build_build_package_fn__598000184_A_New(); var tmp24 *jrt.Class; var fncls__1269 *jrt.Class = A_arbace_box_build_build_package_fn__598000184_A_fn_class; if fncls__1269 == nil { var fncls__1269d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); A_arbace_box_build_build_package_fn__598000184_A_fn_class = fncls__1269d; tmp24 = fncls__1269d } else { tmp24 = fncls__1269 }; arg_1267 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1270, tmp24, nil); var arg_1268 any = sfiles__14; if linked_1265 == nil { arg_1256 = ifn_1266.Invoke_O_O__O(arg_1267, arg_1268) } else { arg_1256 = linked_1265.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1264, arg_1267, arg_1268) }; if linked_1253 == nil { tmp23 = ifn_1254.Invoke_O_O__O(arg_1255, arg_1256) } else { tmp23 = linked_1253.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1252, arg_1255, arg_1256) }
//line :236:1
		var tmp25 any = tmp23; var tmp26 any = A_arbace_box_build_A_const_141; var tmp27 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_55, A_arbace_box_build_A_const_44.Invoke_O__O(pkg__1)); var tmp28 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_40, A_arbace_box_build_A_const_39.Invoke_O__O(plan__0)); var tmp29 any; var root_1271 any = A_arbace_box_build_A_const_142.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, A_arbace_box_build_file_tree_A_fn_class); var ifn_1273 lang.IFn


		if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = A_arbace_box_build_A_const_143; if linked_1272 == nil { tmp29 = ifn_1273.Invoke_O__O(arg_1274) } else { tmp29 = linked_1272.(*A_arbace_box_build_file_tree_A).Invoke_O_O__O(root_1271, arg_1274) }
//line :236:1
		arg_1249 = tmp19.Invoke_O_O__O(Lit_51, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp20, tmp21, tmp22, tmp25, tmp26, lang.Tuple_Create_O_O_O__IPersistentVector(tmp27, tmp28, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp29))))); var arg_1250 any = P__8_; var arg_1251 any = Lit_51; if linked_1247 == nil { symabis__19 = ifn_1248.Invoke_O_O_O__O(arg_1249, arg_1250, arg_1251) } else { symabis__19 = linked_1247.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_1246, arg_1249, arg_1250, arg_1251) } } else {
//line :235:1
			symabis__19 = nil }; var compile__20 any; var tmp30 lang.IFn = /*line :211:1*/lang.IFn_Cast(res_of__15); var tmp31 any; var root_1522 any = A_arbace_box_build_A_const_124.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1522, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_1524 lang.IFn; if






























	linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any; var tmp32 any = A_arbace_box_build_A_const_138; var tmp33 any = A_arbace_box_build_A_const_149.Invoke_O__O(tools__7); var tmp34 any = A_arbace_box_build_A_const_78; var tmp35 any; var root_1527 any = A_arbace_box_build_A_const_90.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1529 lang.IFn; if

	linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_86.GetRawRoot__O()); var tmp37 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_36, nil, Lit_59), jrt.RefArrayOf(jrt.Object_class, nil, P__8_, nil)).Ref(); var tmp38 any; if
	lang.Util_Equiv_O_O__Z_NoInit(Lit_60, A_arbace_box_build_A_const_150.Invoke_O__O(pkg__1)) { tmp38 = Lit_60 } else { tmp38 = P__8_ }; var tmp39 any = /*line :244:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_57, Lit_42, Lit_58, Lit_35, tmp37, Lit_34, tmp38, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_151.Invoke_O__O(pkg__1))).Ref())); var tmp40 any; if

	jrt.J2g_Truth(A_arbace_box_build_A_const_93.Invoke_O__O(pkg__1)) { tmp40 = A_arbace_box_build_A_const_152 } else { tmp40 = nil }; var tmp41 any = tmp40; var tmp42 any; var tmp43 any; var root_1543 any = /*line :244:1*/A_arbace_box_build_A_const_153.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1543, A_arbace_box_build_complete_QMARK__A_fn_class); var ifn_1545 lang.IFn; if


	linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = pkg__1; if linked_1544 == nil { tmp43 = ifn_1545.Invoke_O__O(arg_1546) } else { tmp43 = linked_1544.(*A_arbace_box_build_complete_QMARK__A).Invoke_O_O__O(root_1543, arg_1546) }; if jrt.J2g_Truth(tmp43) { tmp42 = A_arbace_box_build_A_const_154 } else { tmp42 = nil }; var tmp44 any = tmp42; var tmp45 any = A_arbace_box_build_A_const_155; var tmp46 any; if

	jrt.J2g_Truth(symabis__19) { tmp46 = A_arbace_box_build_A_const_156 } else { tmp46 = nil }; var tmp47 any = tmp46; var tmp48 any = A_arbace_box_build_A_const_157; var tmp49 any; if

	jrt.J2g_Truth(embedcfg__18) { tmp49 = A_arbace_box_build_A_const_158 } else { tmp49 = nil }; var tmp50 any = tmp49; var tmp51 any; if
	jrt.J2g_Truth(symabis__19) { tmp51 = A_arbace_box_build_A_const_159 } else { tmp51 = nil }; var tmp52 any = tmp51; var tmp53 any; var root_1547 any = /*line :244:1*/A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1548 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1547, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1549 lang.IFn; if








	linked_1548 == nil { ifn_1549 = lang.IFn_Cast(root_1547) } else { ifn_1549 = nil }; var arg_1550 any; var fnbody__1553 any = A_arbace_box_build_build_package_fn__598000186_A_New(); var tmp54 *jrt.Class; var fncls__1552 *jrt.Class = A_arbace_box_build_build_package_fn__598000186_A_fn_class; if fncls__1552 == nil { var fncls__1552d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, nil); A_arbace_box_build_build_package_fn__598000186_A_fn_class = fncls__1552d; tmp54 = fncls__1552d } else { tmp54 = fncls__1552 }; arg_1550 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1553, tmp54, nil); var arg_1551 any = A_arbace_box_build_A_const_160.Invoke_O__O(pkg__1); if linked_1548 == nil { tmp53 = ifn_1549.Invoke_O_O__O(arg_1550, arg_1551) } else { tmp53 = linked_1548.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1547, arg_1550, arg_1551) }; arg_1530 = /*line :244:1*/tmp36.Invoke_O_O_O_O_O_O_O_O_O__O(tmp39, tmp41, tmp44, tmp45, tmp47, tmp48, tmp50, tmp52, tmp53); if linked_1528 == nil { tmp35 = ifn_1529.Invoke_O__O(arg_1530) } else { tmp35 = linked_1528.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1527, arg_1530) }; var tmp55 any = tmp35; var tmp56 any = A_arbace_box_build_A_const_141; var tmp57 any; var root_1554 any = /*line :242:1*/A_arbace_box_build_A_const_90.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1554, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1556 lang.IFn; if











	linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any; var root_1558 any = A_arbace_box_build_A_const_86.GetRawRoot__O(); var linked_1559 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1558, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1560 lang.IFn; if linked_1559 == nil { ifn_1560 = lang.IFn_Cast(root_1558) } else { ifn_1560 = nil }; var arg_1561 any; var tmp58 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_55, A_arbace_box_build_A_const_44.Invoke_O__O(pkg__1)); var tmp59 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_63, dtree__11); var tmp60 any; var root_1562 any = A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_1563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1562, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_1564 lang.IFn; if
	linked_1563 == nil { ifn_1564 = lang.IFn_Cast(root_1562) } else { ifn_1564 = nil }; var arg_1565 any; var G__598000188__20_ any; var tmp61 any; var root_1566 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1566, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_1568 lang.IFn; if linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any = importcfg__13; if linked_1567 == nil { tmp61 = ifn_1568.Invoke_O__O(arg_1569) } else { tmp61 = linked_1567.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_1566, arg_1569) }; G__598000188__20_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_64, tmp61)); var G__598000188__21_ any; if jrt.J2g_Truth(symabis__19) {
		var root_1570 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1570, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1572 lang.IFn; if linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = G__598000188__20_; var arg_1574 any = Lit_51; var arg_1575 any = symabis__19; if linked_1571 == nil { G__598000188__21_ = ifn_1572.Invoke_O_O_O__O(arg_1573, arg_1574, arg_1575) } else { G__598000188__21_ = linked_1571.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1570, arg_1573, arg_1574, arg_1575) } } else {
//line :255:1
			G__598000188__21_ = G__598000188__20_ }; if jrt.J2g_Truth(embedcfg__18) {

				var root_1576 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_1577 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1576, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1578 lang.IFn; if linked_1577 == nil { ifn_1578 = lang.IFn_Cast(root_1576) } else { ifn_1578 = nil }; var arg_1579 any = G__598000188__21_; var arg_1580 any = Lit_65; var arg_1581 any; var root_1582 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_1584 lang.IFn; if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = embedcfg__18; if linked_1583 == nil { arg_1581 = ifn_1584.Invoke_O__O(arg_1585) } else { arg_1581 = linked_1583.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_1582, arg_1585) }; if linked_1577 == nil { arg_1565 = ifn_1578.Invoke_O_O_O__O(arg_1579, arg_1580, arg_1581) } else { arg_1565 = linked_1577.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1576, arg_1579, arg_1580, arg_1581) } } else {
//line :255:1
					arg_1565 = G__598000188__21_ }; if linked_1563 == nil { tmp60 = ifn_1564.Invoke_O__O(arg_1565) } else { tmp60 = linked_1563.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_1562, arg_1565) }; arg_1561 = /*line :254:1*/lang.Tuple_Create_O_O_O__IPersistentVector(tmp58, tmp59, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp60)); if linked_1559 == nil { arg_1557 = ifn_1560.Invoke_O__O(arg_1561) } else { arg_1557 = linked_1559.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_1558, arg_1561) }; if linked_1555 == nil { tmp57 = ifn_1556.Invoke_O__O(arg_1557) } else { tmp57 = linked_1555.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1554, arg_1557) }; arg_1525 = /*line :242:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp32, tmp33, tmp34, tmp55, tmp56, tmp57)); var arg_1526 any; var root_1586 any = A_arbace_box_build_A_const_161.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1586, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1588 lang.IFn; if















	linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; var arg_1589 any = rsc__16; var arg_1590 any = A_arbace_box_build_A_const_162; if linked_1587 == nil { arg_1526 = ifn_1588.Invoke_O_O__O(arg_1589, arg_1590) } else { arg_1526 = linked_1587.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1586, arg_1589, arg_1590) }; if /*line :242:1*/ linked_1523 == nil { tmp31 = ifn_1524.Invoke_O_O__O(arg_1525, arg_1526) } else { tmp31 = linked_1523.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_1522, arg_1525, arg_1526) }; compile__20 = /*line :241:1*/tmp30.Invoke_O_O__O(Lit_57, tmp31); var archive__21 any; var root_1275 any = /*line :211:1*/A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1275, A_arbace_box_build_out_file_A_fn_class); var ifn_1277 lang.IFn; if















































	linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = compile__20; var arg_1279 any = P__8_; var arg_1280 any = Lit_66; if linked_1276 == nil { archive__21 = ifn_1277.Invoke_O_O_O__O(arg_1278, arg_1279, arg_1280) } else { archive__21 = linked_1276.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_1275, arg_1278, arg_1279, arg_1280) }; var tmp62 any; var root_1281 any =
	A_arbace_box_build_A_const_105.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1281, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1283 lang.IFn; if linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = sfiles__14; if linked_1282 == nil { tmp62 = ifn_1283.Invoke_O__O(arg_1284) } else { tmp62 = linked_1282.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1281, arg_1284) }; if jrt.J2g_Truth(tmp62) { return archive__21 } else { var asmh__22 any; var root_1285 any = A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, A_arbace_box_build_out_file_A_fn_class); var ifn_1287 lang.IFn

		if linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any = compile__20; var arg_1289 any = P__8_; var arg_1290 any = Lit_67; if linked_1286 == nil { asmh__22 = ifn_1287.Invoke_O_O_O__O(arg_1288, arg_1289, arg_1290) } else { asmh__22 = linked_1286.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_1285, arg_1288, arg_1289, arg_1290) }
//line :260:1
		var ctree__23 any; var root_1291 any = A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_1292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1291, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_1293 lang.IFn


		if linked_1292 == nil { ifn_1293 = lang.IFn_Cast(root_1291) } else { ifn_1293 = nil }; var arg_1294 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_67, asmh__22)); if linked_1292 == nil { ctree__23 = ifn_1293.Invoke_O__O(arg_1294) } else { ctree__23 = linked_1292.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_1291, arg_1294) }
//line :260:1
		var objs__24 any; var root_1295 any = A_arbace_box_build_A_const_144.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_1297 lang.IFn



		if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any; var iter__1927001039__auto____24 any; var fnbody__1418 any = A_arbace_box_build_build_package_iter__598000189__598000193_A_New_O_O_O_O_O_O(res_of__15, P__8_, plan__0, ctree__23, pkg__1, tools__7); var tmp63 *jrt.Class; var fncls__1417 *jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_A_fn_class
		if fncls__1417 == nil { var fncls__1417d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, fnbody__1418); A_arbace_box_build_build_package_iter__598000189__598000193_A_fn_class = fncls__1417d; tmp63 = fncls__1417d } else { tmp63 = fncls__1417 }; iter__1927001039__auto____24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1418, tmp63, nil); arg_1298 = lang.IFn_Cast(iter__1927001039__auto____24).Invoke_O__O(sfiles__14)
//line :264:1
		if linked_1296 == nil { objs__24 = ifn_1297.Invoke_O__O(arg_1298) } else { objs__24 = linked_1296.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_1295, arg_1298) }
//line :260:1
		var members__25 any; var iter__1927001039__auto____25 any; var fnbody__1504 any = A_arbace_box_build_build_package_iter__598000203__598000207_A_New(); var tmp64 *jrt.Class
		var fncls__1503 /*line :260:1*/*jrt.Class = A_arbace_box_build_build_package_iter__598000203__598000207_A_fn_class












		if fncls__1503 == nil { var fncls__1503d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, nil); A_arbace_box_build_build_package_iter__598000203__598000207_A_fn_class = fncls__1503d; tmp64 = fncls__1503d } else { tmp64 = fncls__1503 }; iter__1927001039__auto____25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1504, tmp64, nil); members__25 = lang.IFn_Cast(iter__1927001039__auto____25).Invoke_O__O(objs__24)
		var root_1505 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any; var root_1509 any = A_arbace_box_build_A_const_148.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, A_arbace_box_build_append_members_A_fn_class); var ifn_1511 lang.IFn; if linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any; var root_1514 any = A_arbace_box_build_A_const_146.GetRawRoot__O(); var linked_1515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1514, aot_arbace_box.A_arbace_box_get_bytes_A_fn_class); var ifn_1516 lang.IFn; if linked_1515 == nil { ifn_1516 = lang.IFn_Cast(root_1514) } else { ifn_1516 = nil }; var arg_1517 any; var root_1518 any = A_arbace_box_build_A_const_147.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = archive__21; if linked_1519 == nil { arg_1517 = ifn_1520.Invoke_O__O(arg_1521) } else { arg_1517 = linked_1519.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1518, arg_1521) }; if linked_1515 == nil { arg_1512 = ifn_1516.Invoke_O__O(arg_1517) } else { arg_1512 = linked_1515.(*aot_arbace_box.A_arbace_box_get_bytes_A).Invoke_O_O__O(root_1514, arg_1517) }; var arg_1513 any = members__25; if linked_1510 == nil { arg_1508 = ifn_1511.Invoke_O_O__O(arg_1512, arg_1513) } else { arg_1508 = linked_1510.(*A_arbace_box_build_append_members_A).Invoke_O_O_O__O(root_1509, arg_1512, arg_1513) }; if linked_1506 == nil { return ifn_1507.Invoke_O__O(arg_1508) } else { return linked_1506.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_1505, arg_1508) } } }
//line :219:1
func A_arbace_box_build_build_package_iter__598000150__598000154_A_New() *A_arbace_box_build_build_package_iter__598000150__598000154_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000150__598000154_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_A) Ctor() {}
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_A) Invoke_O_O__O(self, s__598000151__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1104 any = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_New_O_O(self, s__598000151__1); var tmp2 *jrt.Class; var fncls__1103 *jrt.Class = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_fn_class; if fncls__1103 == nil { var fncls__1103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, fnbody__1104); A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_fn_class = fncls__1103d; tmp2 = fncls__1103d } else { tmp2 = fncls__1103 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1104, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :219:1
func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_New_O_O(p0, p1 any) *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A{}; t.Ctor_O_O(p0, p1); return t }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A) Ctor_O_O(c__iter__598000150, c__s__598000151 any) { t.F_iter__598000150 = c__iter__598000150; t.F_s__598000151 = c__s__598000151 }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A) Invoke_O__O(self any) any { { var s__598000151__1 any; var t_ any = t.F_s__598000151; t.F_s__598000151 = nil; s__598000151__1 = t_; for { var temp__1927000414__auto____2 any; var root_1045 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1047 lang.IFn; if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any = s__598000151__1; if linked_1046 == nil { temp__1927000414__auto____2 = ifn_1047.Invoke_O__O(arg_1048) } else { temp__1927000414__auto____2 = linked_1046.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1045, arg_1048) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000151__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1049 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1049, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1051 lang.IFn; if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any = s__598000151__3; if linked_1050 == nil { tmp1 = ifn_1051.Invoke_O__O(arg_1052) } else { tmp1 = linked_1050.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1049, arg_1052) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1053 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any = s__598000151__3; if linked_1054 == nil { c__1927001037__auto____4 = ifn_1055.Invoke_O__O(arg_1056) } else { c__1927001037__auto____4 = linked_1054.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1053, arg_1056) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000153__6 any; var root_1057 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1058 == nil { b__598000153__6 = ifn_1059.Invoke_O__O(arg_1060) } else { b__598000153__6 = linked_1058.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1057, arg_1060) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1067 any = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_New_O_I_O(b__598000153__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1066 *jrt.Class = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_fn_class; if fncls__1066 == nil { var fncls__1066d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, fnbody__1067); A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_fn_class = fncls__1066d; tmp3 = fncls__1066d } else { tmp3 = fncls__1066 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1067, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1068 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1068, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1070 lang.IFn; if linked_1069 == nil { ifn_1070 = lang.IFn_Cast(root_1068) } else { ifn_1070 = nil }; var arg_1071 any; var root_1073 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = b__598000153__6; if linked_1074 == nil { arg_1071 = ifn_1075.Invoke_O__O(arg_1076) } else { arg_1071 = linked_1074.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1073, arg_1076) }; var arg_1072 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000150); var tmp5 any; var root_1077 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1079 lang.IFn; if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = s__598000151__3; if linked_1078 == nil { tmp5 = ifn_1079.Invoke_O__O(arg_1080) } else { tmp5 = linked_1078.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1077, arg_1080) }; arg_1072 = tmp4.Invoke_O__O(tmp5); if linked_1069 == nil { return ifn_1070.Invoke_O_O__O(arg_1071, arg_1072) } else { return linked_1069.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1068, arg_1071, arg_1072) } } else { var root_1081 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any; var root_1086 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1086, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1088 lang.IFn; if linked_1087 == nil { ifn_1088 = lang.IFn_Cast(root_1086) } else { ifn_1088 = nil }; var arg_1089 any = b__598000153__6; if linked_1087 == nil { arg_1084 = ifn_1088.Invoke_O__O(arg_1089) } else { arg_1084 = linked_1087.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1086, arg_1089) }; var arg_1085 any; if linked_1082 == nil { return ifn_1083.Invoke_O_O__O(arg_1084, arg_1085) } else { return linked_1082.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1081, arg_1084, arg_1085) } } } else { var vec__598000161__4 any; var root_1090 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1090, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1092 lang.IFn; if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any = s__598000151__3; if linked_1091 == nil { vec__598000161__4 = ifn_1092.Invoke_O__O(arg_1093) } else { vec__598000161__4 = linked_1091.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1090, arg_1093) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000161__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000161__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1094 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1094, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1096 lang.IFn; if linked_1095 == nil { ifn_1096 = lang.IFn_Cast(root_1094) } else { ifn_1096 = nil }; var arg_1097 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_75, nil, Lit_76, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, nil, k__5, nil, v__6, nil)).Ref(); var arg_1098 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000150); var tmp7 any; var root_1099 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1101 lang.IFn; if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = s__598000151__3; if linked_1100 == nil { tmp7 = ifn_1101.Invoke_O__O(arg_1102) } else { tmp7 = linked_1100.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1099, arg_1102) }; arg_1098 = tmp6.Invoke_O__O(tmp7); if linked_1095 == nil { return ifn_1096.Invoke_O_O__O(arg_1097, arg_1098) } else { return linked_1095.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1094, arg_1097, arg_1098) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :219:1
func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A) Ctor_O_I_O(c__b__598000153 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000153 = c__b__598000153; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A) Invoke_O__O(self any) any { { var i__598000152__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000152__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000157__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000152__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000157__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000157__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1061 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = t.F_b__598000153; var arg_1065 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_75, nil, Lit_76, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, nil, k__3, nil, v__4, nil)).Ref(); if linked_1062 == nil { ifn_1063.Invoke_O_O__O(arg_1064, arg_1065) } else { linked_1062.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1061, arg_1064, arg_1065) }; i__598000152__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000152__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_box_build_build_package_iter__598000166__598000170_A_New() *A_arbace_box_build_build_package_iter__598000166__598000170_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000166__598000170_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_A) Ctor() {}
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_A) Invoke_O_O__O(self, s__598000167__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1175 any = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_New_O_O(s__598000167__1, self); var tmp2 *jrt.Class; var fncls__1174 *jrt.Class = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_fn_class; if fncls__1174 == nil { var fncls__1174d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, fnbody__1175); A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_fn_class = fncls__1174d; tmp2 = fncls__1174d } else { tmp2 = fncls__1174 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1175, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :220:1
func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_New_O_O(p0, p1 any) *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A{}; t.Ctor_O_O(p0, p1); return t }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A) Ctor_O_O(c__s__598000167, c__iter__598000166 any) { t.F_s__598000167 = c__s__598000167; t.F_iter__598000166 = c__iter__598000166 }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A) Invoke_O__O(self any) any { { var s__598000167__1 any; var t_ any = t.F_s__598000167; t.F_s__598000167 = nil; s__598000167__1 = t_; for { var temp__1927000414__auto____2 any; var root_1116 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any = s__598000167__1; if linked_1117 == nil { temp__1927000414__auto____2 = ifn_1118.Invoke_O__O(arg_1119) } else { temp__1927000414__auto____2 = linked_1117.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1116, arg_1119) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000167__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1120 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1120, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1122 lang.IFn; if linked_1121 == nil { ifn_1122 = lang.IFn_Cast(root_1120) } else { ifn_1122 = nil }; var arg_1123 any = s__598000167__3; if linked_1121 == nil { tmp1 = ifn_1122.Invoke_O__O(arg_1123) } else { tmp1 = linked_1121.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1120, arg_1123) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1124 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1124, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1126 lang.IFn; if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any = s__598000167__3; if linked_1125 == nil { c__1927001037__auto____4 = ifn_1126.Invoke_O__O(arg_1127) } else { c__1927001037__auto____4 = linked_1125.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1124, arg_1127) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000169__6 any; var root_1128 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1128, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1130 lang.IFn; if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1129 == nil { b__598000169__6 = ifn_1130.Invoke_O__O(arg_1131) } else { b__598000169__6 = linked_1129.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1128, arg_1131) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1138 any = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_New_O_I_O(b__598000169__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1137 *jrt.Class = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_fn_class; if fncls__1137 == nil { var fncls__1137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, fnbody__1138); A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_fn_class = fncls__1137d; tmp3 = fncls__1137d } else { tmp3 = fncls__1137 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1138, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1139 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1141 lang.IFn; if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any; var root_1144 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = b__598000169__6; if linked_1145 == nil { arg_1142 = ifn_1146.Invoke_O__O(arg_1147) } else { arg_1142 = linked_1145.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1144, arg_1147) }; var arg_1143 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000166); var tmp5 any; var root_1148 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1148, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1150 lang.IFn; if linked_1149 == nil { ifn_1150 = lang.IFn_Cast(root_1148) } else { ifn_1150 = nil }; var arg_1151 any = s__598000167__3; if linked_1149 == nil { tmp5 = ifn_1150.Invoke_O__O(arg_1151) } else { tmp5 = linked_1149.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1148, arg_1151) }; arg_1143 = tmp4.Invoke_O__O(tmp5); if linked_1140 == nil { return ifn_1141.Invoke_O_O__O(arg_1142, arg_1143) } else { return linked_1140.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1139, arg_1142, arg_1143) } } else { var root_1152 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1152, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1154 lang.IFn; if linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var arg_1155 any; var root_1157 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any = b__598000169__6; if linked_1158 == nil { arg_1155 = ifn_1159.Invoke_O__O(arg_1160) } else { arg_1155 = linked_1158.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1157, arg_1160) }; var arg_1156 any; if linked_1153 == nil { return ifn_1154.Invoke_O_O__O(arg_1155, arg_1156) } else { return linked_1153.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1152, arg_1155, arg_1156) } } } else { var l__4 any; var root_1161 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = s__598000167__3; if linked_1162 == nil { l__4 = ifn_1163.Invoke_O__O(arg_1164) } else { l__4 = linked_1162.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1161, arg_1164) }; var root_1165 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1167 lang.IFn; if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, l__4, nil)).Ref(); var arg_1169 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000166); var tmp7 any; var root_1170 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1172 lang.IFn; if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any = s__598000167__3; if linked_1171 == nil { tmp7 = ifn_1172.Invoke_O__O(arg_1173) } else { tmp7 = linked_1171.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1170, arg_1173) }; arg_1169 = tmp6.Invoke_O__O(tmp7); if linked_1166 == nil { return ifn_1167.Invoke_O_O__O(arg_1168, arg_1169) } else { return linked_1166.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1165, arg_1168, arg_1169) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :220:1
func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A) Ctor_O_I_O(c__b__598000169 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000169 = c__b__598000169; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A) Invoke_O__O(self any) any { { var i__598000168__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000168__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000168__1)); var root_1132 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1132, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1134 lang.IFn; if linked_1133 == nil { ifn_1134 = lang.IFn_Cast(root_1132) } else { ifn_1134 = nil }; var arg_1135 any = t.F_b__598000169; var arg_1136 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, l__2, nil)).Ref(); if linked_1133 == nil { ifn_1134.Invoke_O_O__O(arg_1135, arg_1136) } else { linked_1133.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1132, arg_1135, arg_1136) }; i__598000168__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000168__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_box_build_build_package_res_of__598000176_A_New_O(p0 any) *A_arbace_box_build_build_package_res_of__598000176_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_res_of__598000176_A{}; t.Ctor_O(p0); return t }
//line :222:1
func (t *A_arbace_box_build_build_package_res_of__598000176_A) Ctor_O(c__P any) { t.F_P = c__P }
//line :222:1
func (t *A_arbace_box_build_build_package_res_of__598000176_A) Invoke_O_O_O__O(self, what__1, req__2 any) any { var root_1178 any = A_arbace_box_build_A_const_79.GetRawRoot__O(); var linked_1179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1178, A_arbace_box_build_action_STAR__A_fn_class); var ifn_1180 lang.IFn; if linked_1179 == nil { ifn_1180 = lang.IFn_Cast(root_1178) } else { ifn_1180 = nil }; var arg_1181 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_88, nil), jrt.RefArrayOf(jrt.Object_class, t.F_P, nil, what__1)).Ref(); var arg_1182 any; var root_1183 any = A_arbace_box_build_A_const_124.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1183, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_1185 lang.IFn; if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any = A_arbace_box_build_A_const_125; var arg_1187 any = req__2; if linked_1184 == nil { arg_1182 = ifn_1185.Invoke_O_O__O(arg_1186, arg_1187) } else { arg_1182 = linked_1184.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_1183, arg_1186, arg_1187) }; if linked_1179 == nil { return ifn_1180.Invoke_O_O__O(arg_1181, arg_1182) } else { return linked_1179.(*A_arbace_box_build_action_STAR__A).Invoke_O_O_O__O(root_1178, arg_1181, arg_1182) } }




func A_arbace_box_build_build_package_fn__598000179_A_New_O(p0 any) *A_arbace_box_build_build_package_fn__598000179_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_fn__598000179_A{}; t.Ctor_O(p0); return t }
//line :227:1
func (t *A_arbace_box_build_build_package_fn__598000179_A) Ctor_O(c__P any) { t.F_P = c__P }
//line :227:1
func (t *A_arbace_box_build_build_package_fn__598000179_A) Invoke_O_O__O(self, p__598000178__1 any) any { var vec__598000180__2 any = p__598000178__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000180__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000180__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var and__1927000168__auto____5 any; var root_1195 any = A_arbace_box_build_A_const_128.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1197 lang.IFn; if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any = k__3; if linked_1196 == nil { and__1927000168__auto____5 = ifn_1197.Invoke_O__O(arg_1198) } else { and__1927000168__auto____5 = linked_1196.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1195, arg_1198) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1199 any = A_arbace_box_build_A_const_23.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1201 lang.IFn; if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any = k__3; var arg_1203 any = Lit_70; if linked_1200 == nil { and__1927000168__auto____6 = ifn_1201.Invoke_O_O__O(arg_1202, arg_1203) } else { and__1927000168__auto____6 = linked_1200.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1199, arg_1202, arg_1203) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
													var root_1204 any = A_arbace_box_build_A_const_129.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1204, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any = t.F_P; var arg_1208 any; var root_1209 any = A_arbace_box_build_A_const_52.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any = k__3; var arg_1213 any = A_arbace_box_build_A_const_57; var arg_1214 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(k__3)))).Ref(); if linked_1210 == nil { arg_1208 = ifn_1211.Invoke_O_O_O__O(arg_1212, arg_1213, arg_1214) } else { arg_1208 = linked_1210.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1209, arg_1212, arg_1213, arg_1214) }; if linked_1205 == nil { tmp1 = ifn_1206.Invoke_O_O__O(arg_1207, arg_1208) } else { tmp1 = linked_1205.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1204, arg_1207, arg_1208) } } else {
//line :227:1
		tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { return v__4 } else { return nil } }










func A_arbace_box_build_build_package_fn__598000184_A_New() *A_arbace_box_build_build_package_fn__598000184_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_fn__598000184_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_box_build_build_package_fn__598000184_A) Ctor() {}
//line :238:1
func (t *A_arbace_box_build_build_package_fn__598000184_A) Invoke_O_O__O(self, p1__598000143_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_71, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__598000143_SHARP___1)).Ref() }














func A_arbace_box_build_build_package_fn__598000186_A_New() *A_arbace_box_build_build_package_fn__598000186_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_fn__598000186_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_box_build_build_package_fn__598000186_A) Ctor() {}
//line :253:1
func (t *A_arbace_box_build_build_package_fn__598000186_A) Invoke_O_O__O(self, p1__598000144_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__598000144_SHARP___1)).Ref() }











func A_arbace_box_build_build_package_iter__598000189__598000193_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_box_build_build_package_iter__598000189__598000193_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_A) Ctor_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__ctree, c__pkg, c__tools any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_tools = c__tools }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_A) Invoke_O_O__O(self, s__598000190__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1416 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_New_O_O_O_O_O_O_O_O(t.F_res_of, t.F_P, t.F_plan, t.F_ctree, t.F_pkg, t.F_tools, s__598000190__1, self); var tmp2 *jrt.Class; var fncls__1415 *jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_fn_class; if fncls__1415 == nil { var fncls__1415d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, fnbody__1416); A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_fn_class = fncls__1415d; tmp2 = fncls__1415d } else { tmp2 = fncls__1415 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1416, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :265:1
func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A) Ctor_O_O_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__ctree, c__pkg, c__tools, c__s__598000190, c__iter__598000189 any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_tools = c__tools; t.F_s__598000190 = c__s__598000190; t.F_iter__598000189 = c__iter__598000189 }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A) Invoke_O__O(self any) any { { var s__598000190__1 any; var t_ any = t.F_s__598000190; t.F_s__598000190 = nil; s__598000190__1 = t_; for { var temp__1927000414__auto____2 any; var root_1299 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = s__598000190__1; if linked_1300 == nil { temp__1927000414__auto____2 = ifn_1301.Invoke_O__O(arg_1302) } else { temp__1927000414__auto____2 = linked_1300.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1299, arg_1302) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000190__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1303 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1305 lang.IFn; if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any = s__598000190__3; if linked_1304 == nil { tmp1 = ifn_1305.Invoke_O__O(arg_1306) } else { tmp1 = linked_1304.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1303, arg_1306) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1307 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = s__598000190__3; if linked_1308 == nil { c__1927001037__auto____4 = ifn_1309.Invoke_O__O(arg_1310) } else { c__1927001037__auto____4 = linked_1308.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1307, arg_1310) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000192__6 any; var root_1311 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1311, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1313 lang.IFn; if linked_1312 == nil { ifn_1313 = lang.IFn_Cast(root_1311) } else { ifn_1313 = nil }; var arg_1314 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1312 == nil { b__598000192__6 = ifn_1313.Invoke_O__O(arg_1314) } else { b__598000192__6 = linked_1312.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1311, arg_1314) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1350 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_New_O_O_O_O_O_O_O_I_O(b__598000192__6, t.F_res_of, t.F_P, t.F_plan, t.F_ctree, t.F_pkg, t.F_tools, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1349 *jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_fn_class; if fncls__1349 == nil { var fncls__1349d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, fnbody__1350); A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_fn_class = fncls__1349d; tmp3 = fncls__1349d } else { tmp3 = fncls__1349 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1350, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1351 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1351, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1353 lang.IFn; if linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any; var root_1356 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1356, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1358 lang.IFn; if linked_1357 == nil { ifn_1358 = lang.IFn_Cast(root_1356) } else { ifn_1358 = nil }; var arg_1359 any = b__598000192__6; if linked_1357 == nil { arg_1354 = ifn_1358.Invoke_O__O(arg_1359) } else { arg_1354 = linked_1357.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1356, arg_1359) }; var arg_1355 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000189); var tmp5 any; var root_1360 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1360, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1362 lang.IFn; if linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; var arg_1363 any = s__598000190__3; if linked_1361 == nil { tmp5 = ifn_1362.Invoke_O__O(arg_1363) } else { tmp5 = linked_1361.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1360, arg_1363) }; arg_1355 = tmp4.Invoke_O__O(tmp5); if linked_1352 == nil { return ifn_1353.Invoke_O_O__O(arg_1354, arg_1355) } else { return linked_1352.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1351, arg_1354, arg_1355) } } else { var root_1364 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any; var root_1369 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1371 lang.IFn; if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var arg_1372 any = b__598000192__6; if linked_1370 == nil { arg_1367 = ifn_1371.Invoke_O__O(arg_1372) } else { arg_1367 = linked_1370.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1369, arg_1372) }; var arg_1368 any; if linked_1365 == nil { return ifn_1366.Invoke_O_O__O(arg_1367, arg_1368) } else { return linked_1365.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1364, arg_1367, arg_1368) } } } else { var s__4 any; var root_1373 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any = s__598000190__3; if linked_1374 == nil { s__4 = ifn_1375.Invoke_O__O(arg_1376) } else { s__4 = linked_1374.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1373, arg_1376) }; var root_1377 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any; var o__5 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_81); var tmp7 any; var root_1382 any = A_arbace_box_build_A_const_52.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1384 lang.IFn
														if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = s__4; var arg_1386 any = A_arbace_box_build_A_const_57; var arg_1387 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(s__4)), 2)).Ref(); if linked_1383 == nil { tmp7 = ifn_1384.Invoke_O_O_O__O(arg_1385, arg_1386, arg_1387) } else { tmp7 = linked_1383.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1382, arg_1385, arg_1386, arg_1387) }; o__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil)).Ref()
//line :265:1
	var tmp8 any; var root_1388 any = A_arbace_box_build_A_const_145.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_1390 lang.IFn

	if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any; var fnbody__1410 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_New_O_O_O_O_O_O_O_O(t.F_res_of, t.F_P, t.F_plan, o__5, t.F_ctree, t.F_pkg, s__4, t.F_tools); var tmp9 *jrt.Class; var fncls__1409 *jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_fn_class; if fncls__1409 == nil { var fncls__1409d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, fnbody__1410); A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_fn_class = fncls__1409d; tmp9 = fncls__1409d } else { tmp9 = fncls__1409 }; arg_1391 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1410, tmp9, nil); if linked_1389 == nil { tmp8 = ifn_1390.Invoke_O__O(arg_1391) } else { tmp8 = linked_1389.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_1388, arg_1391) }
//line :265:1
	arg_1380 = lang.Tuple_Create_O_O__IPersistentVector(o__5, tmp8); var arg_1381 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__598000189); var tmp11 any; var root_1411 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1411, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1413 lang.IFn; if linked_1412 == nil { ifn_1413 = lang.IFn_Cast(root_1411) } else { ifn_1413 = nil }; var arg_1414 any = s__598000190__3; if linked_1412 == nil { tmp11 = ifn_1413.Invoke_O__O(arg_1414) } else { tmp11 = linked_1412.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1411, arg_1414) }; arg_1381 = tmp10.Invoke_O__O(tmp11); if linked_1378 == nil { return ifn_1379.Invoke_O_O__O(arg_1380, arg_1381) } else { return linked_1378.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1377, arg_1380, arg_1381) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :265:1
func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_New_O_O_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6 any, p7 int32, p8 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A{}; t.Ctor_O_O_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A) Ctor_O_O_O_O_O_O_O_I_O(c__b__598000192, c__res_of, c__P, c__plan, c__ctree, c__pkg, c__tools any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000192 = c__b__598000192; t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_tools = c__tools; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A) Invoke_O__O(self any) any { { var i__598000191__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000191__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000191__1)); var root_1315 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1315, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1317 lang.IFn; if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any = t.F_b__598000192; var arg_1319 any; var o__3 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_81); var tmp3 any; var root_1320 any = A_arbace_box_build_A_const_52.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1322 lang.IFn
																if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = s__2; var arg_1324 any = A_arbace_box_build_A_const_57; var arg_1325 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(s__2)), 2)).Ref(); if linked_1321 == nil { tmp3 = ifn_1322.Invoke_O_O_O__O(arg_1323, arg_1324, arg_1325) } else { tmp3 = linked_1321.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1320, arg_1323, arg_1324, arg_1325) }; o__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref()
//line :265:1
	var tmp4 any; var root_1326 any = A_arbace_box_build_A_const_145.GetRawRoot__O(); var linked_1327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1326, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_1328 lang.IFn

	if linked_1327 == nil { ifn_1328 = lang.IFn_Cast(root_1326) } else { ifn_1328 = nil }; var arg_1329 any; var fnbody__1348 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_New_O_O_O_O_O_O_O_O(t.F_res_of, t.F_P, t.F_plan, t.F_ctree, t.F_pkg, o__3, s__2, t.F_tools); var tmp5 *jrt.Class; var fncls__1347 *jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_fn_class; if fncls__1347 == nil { var fncls__1347d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, fnbody__1348); A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_fn_class = fncls__1347d; tmp5 = fncls__1347d } else { tmp5 = fncls__1347 }; arg_1329 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1348, tmp5, nil); if linked_1327 == nil { tmp4 = ifn_1328.Invoke_O__O(arg_1329) } else { tmp4 = linked_1327.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_1326, arg_1329) }
//line :265:1
	arg_1319 = lang.Tuple_Create_O_O__IPersistentVector(o__3, tmp4); if linked_1316 == nil { ifn_1317.Invoke_O_O__O(arg_1318, arg_1319) } else { linked_1316.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1315, arg_1318, arg_1319) }; i__598000191__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000191__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A) Ctor_O_O_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__ctree, c__pkg, c__o, c__s, c__tools any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_o = c__o; t.F_s = c__s; t.F_tools = c__tools }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A) Invoke_O__O(self any) any {
	var root_1330 any = A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, A_arbace_box_build_out_file_A_fn_class); var ifn_1332 lang.IFn; if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any; var tmp1 any; var t_ any = t.F_res_of; t.F_res_of = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_84, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_s)).Ref(); var tmp4 any = A_arbace_box_build_A_const_138; var tmp5 *lang.Keyword = A_arbace_box_build_A_const_139; var tmp6 any; var t__2 any = t.F_tools
	t.F_tools = nil; tmp6 = t__2
//line :268:1
	var tmp7 any = tmp5.Invoke_O__O(tmp6); var tmp8 any = A_arbace_box_build_A_const_78; var tmp9 any; var root_1336 any = A_arbace_box_build_A_const_9.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1336, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1338 lang.IFn

	if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_140.GetRawRoot__O()); var tmp11 any = t.F_plan; var tmp12 any = t.F_pkg; var arg_1339 any = tmp10.Invoke_O_O_O__O(tmp11, tmp12, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_85, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_o)).Ref()); var arg_1340 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_71, nil); var tmp14 any; var t__3 any = t.F_s; t.F_s = nil; tmp14 = t__3; arg_1340 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_1337 == nil { tmp9 = ifn_1338.Invoke_O_O__O(arg_1339, arg_1340) } else { tmp9 = linked_1337.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1336, arg_1339, arg_1340) }
//line :268:1
	var tmp15 any = tmp9; var tmp16 any = A_arbace_box_build_A_const_141; var tmp17 *lang.Keyword = A_arbace_box_build_A_const_44; var tmp18 any; var t__4 any = t.F_pkg


	t.F_pkg = nil; tmp18 = t__4
//line :268:1
	var tmp19 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_55, tmp17.Invoke_O__O(tmp18)); var tmp20 *lang.Keyword = A_arbace_box_build_A_const_39; var tmp21 any; var t__5 any = t.F_plan


	t.F_plan = nil; tmp21 = t__5
//line :268:1
	var tmp22 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_40, tmp20.Invoke_O__O(tmp21)); var tmp23 any; var t__6 any = t.F_ctree; t.F_ctree = nil; tmp23 = t__6; arg_1333 = tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, tmp15, tmp16, lang.Tuple_Create_O_O_O__IPersistentVector(tmp19, tmp22, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp23))))); var arg_1334 any; var t__7 any = t.F_P; t.F_P = nil; arg_1334 = t__7; var arg_1335 any; var t__8 any = t.F_o; t.F_o = nil; arg_1335 = t__8; if linked_1331 == nil { return ifn_1332.Invoke_O_O_O__O(arg_1333, arg_1334, arg_1335) } else { return linked_1331.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_1330, arg_1333, arg_1334, arg_1335) } }
//line :267:1
func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A) Ctor_O_O_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__o, c__ctree, c__pkg, c__s, c__tools any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_o = c__o; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_s = c__s; t.F_tools = c__tools }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A) Invoke_O__O(self any) any {
	var root_1392 any = A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_1393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1392, A_arbace_box_build_out_file_A_fn_class); var ifn_1394 lang.IFn; if linked_1393 == nil { ifn_1394 = lang.IFn_Cast(root_1392) } else { ifn_1394 = nil }; var arg_1395 any; var tmp1 any; var t_ any = t.F_res_of; t.F_res_of = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_84, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_s)).Ref(); var tmp4 any = A_arbace_box_build_A_const_138; var tmp5 *lang.Keyword = A_arbace_box_build_A_const_139; var tmp6 any; var t__2 any = t.F_tools
	t.F_tools = nil; tmp6 = t__2
//line :268:1
	var tmp7 any = tmp5.Invoke_O__O(tmp6); var tmp8 any = A_arbace_box_build_A_const_78; var tmp9 any; var root_1398 any = A_arbace_box_build_A_const_9.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1400 lang.IFn

	if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_140.GetRawRoot__O()); var tmp11 any = t.F_plan; var tmp12 any = t.F_pkg; var arg_1401 any = tmp10.Invoke_O_O_O__O(tmp11, tmp12, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_85, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_o)).Ref()); var arg_1402 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_71, nil); var tmp14 any; var t__3 any = t.F_s; t.F_s = nil; tmp14 = t__3; arg_1402 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_1399 == nil { tmp9 = ifn_1400.Invoke_O_O__O(arg_1401, arg_1402) } else { tmp9 = linked_1399.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1398, arg_1401, arg_1402) }
//line :268:1
	var tmp15 any = tmp9; var tmp16 any = A_arbace_box_build_A_const_141; var tmp17 *lang.Keyword = A_arbace_box_build_A_const_44; var tmp18 any; var t__4 any = t.F_pkg


	t.F_pkg = nil; tmp18 = t__4
//line :268:1
	var tmp19 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_55, tmp17.Invoke_O__O(tmp18)); var tmp20 *lang.Keyword = A_arbace_box_build_A_const_39; var tmp21 any; var t__5 any = t.F_plan


	t.F_plan = nil; tmp21 = t__5
//line :268:1
	var tmp22 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_40, tmp20.Invoke_O__O(tmp21)); var tmp23 any; var t__6 any = t.F_ctree; t.F_ctree = nil; tmp23 = t__6; arg_1395 = tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, tmp15, tmp16, lang.Tuple_Create_O_O_O__IPersistentVector(tmp19, tmp22, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp23))))); var arg_1396 any; var t__7 any = t.F_P; t.F_P = nil; arg_1396 = t__7; var arg_1397 any; var t__8 any = t.F_o; t.F_o = nil; arg_1397 = t__8; if linked_1393 == nil { return ifn_1394.Invoke_O_O_O__O(arg_1395, arg_1396, arg_1397) } else { return linked_1393.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_1392, arg_1395, arg_1396, arg_1397)
	}
}


func A_arbace_box_build_build_package_iter__598000203__598000207_A_New() *A_arbace_box_build_build_package_iter__598000203__598000207_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000203__598000207_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_A) Ctor() {}
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_A) Invoke_O_O__O(self, s__598000204__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1502 any = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_New_O_O(self, s__598000204__1); var tmp2 *jrt.Class; var fncls__1501 *jrt.Class = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_fn_class; if fncls__1501 == nil { var fncls__1501d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, fnbody__1502); A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_fn_class = fncls__1501d; tmp2 = fncls__1501d } else { tmp2 = fncls__1501 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1502, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :273:1
func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_New_O_O(p0, p1 any) *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A{}; t.Ctor_O_O(p0, p1); return t }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A) Ctor_O_O(c__iter__598000203, c__s__598000204 any) { t.F_iter__598000203 = c__iter__598000203; t.F_s__598000204 = c__s__598000204 }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A) Invoke_O__O(self any) any { { var s__598000204__1 any; var t_ any = t.F_s__598000204; t.F_s__598000204 = nil; s__598000204__1 = t_; for { var temp__1927000414__auto____2 any; var root_1419 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1419, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1421 lang.IFn; if linked_1420 == nil { ifn_1421 = lang.IFn_Cast(root_1419) } else { ifn_1421 = nil }; var arg_1422 any = s__598000204__1; if linked_1420 == nil { temp__1927000414__auto____2 = ifn_1421.Invoke_O__O(arg_1422) } else { temp__1927000414__auto____2 = linked_1420.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1419, arg_1422) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000204__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1423 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1423, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1425 lang.IFn; if linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; var arg_1426 any = s__598000204__3; if linked_1424 == nil { tmp1 = ifn_1425.Invoke_O__O(arg_1426) } else { tmp1 = linked_1424.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1423, arg_1426) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1427 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1429 lang.IFn; if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = s__598000204__3; if linked_1428 == nil { c__1927001037__auto____4 = ifn_1429.Invoke_O__O(arg_1430) } else { c__1927001037__auto____4 = linked_1428.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1427, arg_1430) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000206__6 any; var root_1431 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1432 == nil { b__598000206__6 = ifn_1433.Invoke_O__O(arg_1434) } else { b__598000206__6 = linked_1432.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1431, arg_1434) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1453 any = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_New_O_I_O(b__598000206__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1452 *jrt.Class = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_fn_class; if fncls__1452 == nil { var fncls__1452d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, fnbody__1453); A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_fn_class = fncls__1452d; tmp3 = fncls__1452d } else { tmp3 = fncls__1452 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1453, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1454 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1454, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1456 lang.IFn; if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any; var root_1459 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1459, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1461 lang.IFn; if linked_1460 == nil { ifn_1461 = lang.IFn_Cast(root_1459) } else { ifn_1461 = nil }; var arg_1462 any = b__598000206__6; if linked_1460 == nil { arg_1457 = ifn_1461.Invoke_O__O(arg_1462) } else { arg_1457 = linked_1460.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1459, arg_1462) }; var arg_1458 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000203); var tmp5 any; var root_1463 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1465 lang.IFn; if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = s__598000204__3; if linked_1464 == nil { tmp5 = ifn_1465.Invoke_O__O(arg_1466) } else { tmp5 = linked_1464.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1463, arg_1466) }; arg_1458 = tmp4.Invoke_O__O(tmp5); if linked_1455 == nil { return ifn_1456.Invoke_O_O__O(arg_1457, arg_1458) } else { return linked_1455.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1454, arg_1457, arg_1458) } } else { var root_1467 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1469 lang.IFn; if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any; var root_1472 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1472, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1474 lang.IFn; if linked_1473 == nil { ifn_1474 = lang.IFn_Cast(root_1472) } else { ifn_1474 = nil }; var arg_1475 any = b__598000206__6; if linked_1473 == nil { arg_1470 = ifn_1474.Invoke_O__O(arg_1475) } else { arg_1470 = linked_1473.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1472, arg_1475) }; var arg_1471 any; if linked_1468 == nil { return ifn_1469.Invoke_O_O__O(arg_1470, arg_1471) } else { return linked_1468.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1467, arg_1470, arg_1471) } } } else { var vec__598000214__4 any; var root_1476 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1476, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1478 lang.IFn; if linked_1477 == nil { ifn_1478 = lang.IFn_Cast(root_1476) } else { ifn_1478 = nil }; var arg_1479 any = s__598000204__3; if linked_1477 == nil { vec__598000214__4 = ifn_1478.Invoke_O__O(arg_1479) } else { vec__598000214__4 = linked_1477.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1476, arg_1479) }; var o__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000214__4, lang.RT_IntCast_J__I_NoInit(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000214__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1480 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any; var tmp6 any; var root_1485 any = A_arbace_box_build_A_const_146.GetRawRoot__O(); var linked_1486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1485, aot_arbace_box.A_arbace_box_get_bytes_A_fn_class); var ifn_1487 lang.IFn; if linked_1486 == nil { ifn_1487 = lang.IFn_Cast(root_1485) } else { ifn_1487 = nil }; var arg_1488 any; var root_1489 any = A_arbace_box_build_A_const_147.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1489, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1491 lang.IFn; if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any; var root_1493 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1493, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1495 lang.IFn; if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any = f__6; if linked_1494 == nil { arg_1492 = ifn_1495.Invoke_O__O(arg_1496) } else { arg_1492 = linked_1494.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1493, arg_1496) }; if linked_1490 == nil { arg_1488 = ifn_1491.Invoke_O__O(arg_1492) } else { arg_1488 = linked_1490.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1489, arg_1492) }; if linked_1486 == nil { tmp6 = ifn_1487.Invoke_O__O(arg_1488) } else { tmp6 = linked_1486.(*aot_arbace_box.A_arbace_box_get_bytes_A).Invoke_O_O__O(root_1485, arg_1488) }; arg_1483 = lang.Tuple_Create_O_O__IPersistentVector(o__5, tmp6); var arg_1484 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__598000203); var tmp8 any; var root_1497 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1497, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1499 lang.IFn; if linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; var arg_1500 any = s__598000204__3; if linked_1498 == nil { tmp8 = ifn_1499.Invoke_O__O(arg_1500) } else { tmp8 = linked_1498.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1497, arg_1500) }; arg_1484 = tmp7.Invoke_O__O(tmp8); if linked_1481 == nil { return ifn_1482.Invoke_O_O__O(arg_1483, arg_1484) } else { return linked_1481.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1480, arg_1483, arg_1484) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :273:1
func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A) Ctor_O_I_O(c__b__598000206 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000206 = c__b__598000206; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A) Invoke_O__O(self any) any { { var i__598000205__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000205__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000210__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000205__1)); var o__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000210__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000210__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1435 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1435, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1437 lang.IFn; if linked_1436 == nil { ifn_1437 = lang.IFn_Cast(root_1435) } else { ifn_1437 = nil }; var arg_1438 any = t.F_b__598000206; var arg_1439 any; var tmp2 any; var root_1440 any = A_arbace_box_build_A_const_146.GetRawRoot__O(); var linked_1441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1440, aot_arbace_box.A_arbace_box_get_bytes_A_fn_class); var ifn_1442 lang.IFn; if linked_1441 == nil { ifn_1442 = lang.IFn_Cast(root_1440) } else { ifn_1442 = nil }; var arg_1443 any; var root_1444 any = A_arbace_box_build_A_const_147.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1444, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any; var root_1448 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1450 lang.IFn; if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = f__4; if linked_1449 == nil { arg_1447 = ifn_1450.Invoke_O__O(arg_1451) } else { arg_1447 = linked_1449.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1448, arg_1451) }; if linked_1445 == nil { arg_1443 = ifn_1446.Invoke_O__O(arg_1447) } else { arg_1443 = linked_1445.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1444, arg_1447) }; if linked_1441 == nil { tmp2 = ifn_1442.Invoke_O__O(arg_1443) } else { tmp2 = linked_1441.(*aot_arbace_box.A_arbace_box_get_bytes_A).Invoke_O_O__O(root_1440, arg_1443) }; arg_1439 = lang.Tuple_Create_O_O__IPersistentVector(o__3, tmp2); if linked_1436 == nil { ifn_1437.Invoke_O_O__O(arg_1438, arg_1439) } else { linked_1436.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1435, arg_1438, arg_1439) }; i__598000205__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000205__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_box_build_read_plan_A_New() *A_arbace_box_build_read_plan_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_read_plan_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_box_build_read_plan_A) Ctor() {}
//line :276:1
func (t *A_arbace_box_build_read_plan_A) Invoke_O_O__O(self, plan__0 any) any {
	var tmp1 any; var root_1591 any = A_arbace_box_build_A_const_32.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = plan__0; if linked_1592 == nil { tmp1 = ifn_1593.Invoke_O__O(arg_1594) } else { tmp1 = linked_1592.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1591, arg_1594) }; if jrt.J2g_Truth(tmp1) { return plan__0 } else { var tmp2 any; var root_1595 any = A_arbace_box_build_A_const_163.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_1597 lang.IFn
		if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any = A_arbace_box_build_A_const_164; var arg_1599 any = plan__0; if linked_1596 == nil { tmp2 = ifn_1597.Invoke_O_O__O(arg_1598, arg_1599) } else { tmp2 = linked_1596.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_1595, arg_1598, arg_1599) }
//line :277:1
		if jrt.J2g_Truth(tmp2) {
			var root_1600 any = A_arbace_box_build_A_const_33.GetRawRoot__O(); var linked_1601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1600, aot_arbace_edn.A_arbace_edn_read_string_A_fn_class); var ifn_1602 lang.IFn; if linked_1601 == nil { ifn_1602 = lang.IFn_Cast(root_1600) } else { ifn_1602 = nil }; var arg_1603 any; var root_1604 any = A_arbace_box_build_A_const_69.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, aot_arbace_box.A_arbace_box_get_A_fn_class); var ifn_1606 lang.IFn; if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = plan__0; if linked_1605 == nil { arg_1603 = ifn_1606.Invoke_O__O(arg_1607) } else { arg_1603 = linked_1605.(*aot_arbace_box.A_arbace_box_get_A).Invoke_O_O__O(root_1604, arg_1607) }; if linked_1601 == nil { return ifn_1602.Invoke_O__O(arg_1603) } else { return linked_1601.(*aot_arbace_edn.A_arbace_edn_read_string_A).Invoke_O_O__O(root_1600, arg_1603) } } else {
//line :277:1
				if A_arbace_box_build_A_const_111 != nil {

					var root_1608 any = A_arbace_box_build_A_const_33.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_edn.A_arbace_edn_read_string_A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any; var or__1927000174__auto____2 any; var root_1612 any = A_arbace_box_build_A_const_165.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1612, aot_arbace_box.A_arbace_box_load_A_fn_class); var ifn_1614 lang.IFn; if linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any = plan__0; if linked_1613 == nil { or__1927000174__auto____2 = ifn_1614.Invoke_O__O(arg_1615) } else { or__1927000174__auto____2 = linked_1613.(*aot_arbace_box.A_arbace_box_load_A).Invoke_O_O__O(root_1612, arg_1615) }; if jrt.J2g_Truth(or__1927000174__auto____2) { arg_1611 = or__1927000174__auto____2 } else { var root_1616 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_1617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1616, A_arbace_box_build_fail_A_fn_class); var ifn_1618 lang.IFn; if linked_1617 == nil { ifn_1618 = lang.IFn_Cast(root_1616) } else { ifn_1618 = nil }; var arg_1619 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_139, nil), jrt.RefArrayOf(jrt.Object_class, nil, plan__0)).Ref(); var arg_1620 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_166, plan__0)); if linked_1617 == nil { arg_1611 = ifn_1618.Invoke_O_O__O(arg_1619, arg_1620) } else { arg_1611 = linked_1617.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_1616, arg_1619, arg_1620) } }; if linked_1609 == nil { return ifn_1610.Invoke_O__O(arg_1611) } else { return linked_1609.(*aot_arbace_edn.A_arbace_edn_read_string_A).Invoke_O_O__O(root_1608, arg_1611) } } else {
//line :277:1
						return nil
					}
			}
	} }
func A_arbace_box_build_with_tools_A_New() *A_arbace_box_build_with_tools_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_with_tools_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_box_build_with_tools_A) Ctor() {}
//line :281:1
func (t *A_arbace_box_build_with_tools_A) Invoke_O_O_O__O(self, p__0, opts__1 any) any { var arch__3 any = A_arbace_box_build_A_const_85.Invoke_O__O(p__0); var tools__4 any; var root_1621 any = A_arbace_box_build_A_const_124.GetRawRoot__O(); var linked_1622 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1621, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_1623 lang.IFn; if



	linked_1622 == nil { ifn_1623 = lang.IFn_Cast(root_1621) } else { ifn_1623 = nil }; var arg_1624 any; var root_1626 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1626, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1628 lang.IFn; if linked_1627 == nil { ifn_1628 = lang.IFn_Cast(root_1626) } else { ifn_1628 = nil }; var arg_1629 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1630 any; var iter__1927001039__auto____4 any; var fnbody__1708 any = A_arbace_box_build_with_tools_iter__598000221__598000225_A_New_O(arch__3); var tmp1 *jrt.Class; var fncls__1707 *jrt.Class = A_arbace_box_build_with_tools_iter__598000221__598000225_A_fn_class; if fncls__1707 == nil { var fncls__1707d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_149, false, fnbody__1708); A_arbace_box_build_with_tools_iter__598000221__598000225_A_fn_class = fncls__1707d; tmp1 = fncls__1707d } else { tmp1 = fncls__1707 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1708, tmp1, nil); arg_1630 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(A_arbace_box_build_A_const_168); if linked_1627 == nil { arg_1624 = ifn_1628.Invoke_O_O__O(arg_1629, arg_1630) } else { arg_1624 = linked_1627.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1626, arg_1629, arg_1630) }; var arg_1625 any = A_arbace_box_build_A_const_120.Invoke_O__O(opts__1); if linked_1622 == nil { tools__4 = ifn_1623.Invoke_O_O__O(arg_1624, arg_1625) } else { tools__4 = linked_1622.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_1621, arg_1624, arg_1625) }; var seq_598000231__5 any; var root_1715 any = /*line :281:1*/A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1715, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1717 lang.IFn; if






	linked_1716 == nil { ifn_1717 = lang.IFn_Cast(root_1715) } else { ifn_1717 = nil }; var arg_1718 any = tools__4; if linked_1716 == nil { seq_598000231__5 = ifn_1717.Invoke_O__O(arg_1718) } else { seq_598000231__5 = linked_1716.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1715, arg_1718) }; var chunk_598000232__6 any; var count_598000233__7 int64 = 0; var i_598000234__8 int64 = 0; L1:
//line :281:1
	for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_598000234__8, count_598000233__7) { var vec__598000235__9 any = lang.Indexed_Cast(chunk_598000232__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_598000234__8)); var t__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000235__9, lang.RT_IntCast_J__I_NoInit(0), nil); var h__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000235__9, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(h__11) { } else { var root_1735 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_1736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1735, A_arbace_box_build_fail_A_fn_class); var ifn_1737 lang.IFn; if linked_1736 == nil { ifn_1737 = lang.IFn_Cast(root_1735) } else { ifn_1737 = nil }; var arg_1738 any; var tmp2 *jrt.RefArray = jrt.ConstRefArray("[0,7,s31:arbace.box.build: no image for ns15: (the ref tool.ns1:.ns1:)", []*jrt.Class{jrt.String_class}); var tmp3 any; var root_1740 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1740, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1742 lang.IFn; if linked_1741 == nil { ifn_1742 = lang.IFn_Cast(root_1740) } else { ifn_1742 = nil }; var arg_1743 any = t__10; if linked_1741 == nil { tmp3 = ifn_1742.Invoke_O__O(arg_1743) } else { tmp3 = linked_1741.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1740, arg_1743) }; var tmp4 any = tmp3; var tmp5 any; var root_1744 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = t__10; if linked_1745 == nil { tmp5 = ifn_1746.Invoke_O__O(arg_1747) } else { tmp5 = linked_1745.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1744, arg_1747) }; arg_1738 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp5, nil, arch__3, nil)).Ref(); var arg_1739 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1736 == nil { ifn_1737.Invoke_O_O__O(arg_1738, arg_1739) } else { linked_1736.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_1735, arg_1738, arg_1739) } }; seq_598000231__5, chunk_598000232__6, count_598000233__7, i_598000234__8 = seq_598000231__5, chunk_598000232__6, count_598000233__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_598000234__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1719 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1719, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1721 lang.IFn; if linked_1720 == nil { ifn_1721 = lang.IFn_Cast(root_1719) } else { ifn_1721 = nil }; var arg_1722 any = seq_598000231__5; if linked_1720 == nil { temp__1927000414__auto____9 = ifn_1721.Invoke_O__O(arg_1722) } else { temp__1927000414__auto____9 = linked_1720.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1719, arg_1722) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_598000231__10 any = temp__1927000414__auto____9; var tmp6 any; var root_1723 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1723, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1725 lang.IFn; if linked_1724 == nil { ifn_1725 = lang.IFn_Cast(root_1723) } else { ifn_1725 = nil }; var arg_1726 any = seq_598000231__10; if linked_1724 == nil { tmp6 = ifn_1725.Invoke_O__O(arg_1726) } else { tmp6 = linked_1724.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1723, arg_1726) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____11 any; var root_1727 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1727, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1729 lang.IFn; if linked_1728 == nil { ifn_1729 = lang.IFn_Cast(root_1727) } else { ifn_1729 = nil }; var arg_1730 any = seq_598000231__10; if linked_1728 == nil { c__1927000678__auto____11 = ifn_1729.Invoke_O__O(arg_1730) } else { c__1927000678__auto____11 = linked_1728.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1727, arg_1730) }; var tmp7 any; var root_1748 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1748, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1750 lang.IFn; if linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var arg_1751 any = seq_598000231__10; if linked_1749 == nil { tmp7 = ifn_1750.Invoke_O__O(arg_1751) } else { tmp7 = linked_1749.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1748, arg_1751) }; seq_598000231__5, chunk_598000232__6, count_598000233__7, i_598000234__8 = tmp7, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__598000238__11 any; var root_1731 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1731, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1733 lang.IFn; if linked_1732 == nil { ifn_1733 = lang.IFn_Cast(root_1731) } else { ifn_1733 = nil }; var arg_1734 any = seq_598000231__10; if linked_1732 == nil { vec__598000238__11 = ifn_1733.Invoke_O__O(arg_1734) } else { vec__598000238__11 = linked_1732.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1731, arg_1734) }; var t__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000238__11, lang.RT_IntCast_J__I_NoInit(0), nil); var h__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000238__11, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(h__13) { } else { var root_1752 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_1753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1752, A_arbace_box_build_fail_A_fn_class); var ifn_1754 lang.IFn; if linked_1753 == nil { ifn_1754 = lang.IFn_Cast(root_1752) } else { ifn_1754 = nil }; var arg_1755 any; var tmp8 *jrt.RefArray = jrt.ConstRefArray("[0,7,s31:arbace.box.build: no image for ns15: (the ref tool.ns1:.ns1:)", []*jrt.Class{jrt.String_class}); var tmp9 any; var root_1757 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1757, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1759 lang.IFn; if linked_1758 == nil { ifn_1759 = lang.IFn_Cast(root_1757) } else { ifn_1759 = nil }; var arg_1760 any = t__12; if linked_1758 == nil { tmp9 = ifn_1759.Invoke_O__O(arg_1760) } else { tmp9 = linked_1758.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1757, arg_1760) }; var tmp10 any = tmp9; var tmp11 any; var root_1761 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1761, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1763 lang.IFn; if linked_1762 == nil { ifn_1763 = lang.IFn_Cast(root_1761) } else { ifn_1763 = nil }; var arg_1764 any = t__12; if linked_1762 == nil { tmp11 = ifn_1763.Invoke_O__O(arg_1764) } else { tmp11 = linked_1762.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1761, arg_1764) }; arg_1755 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, nil, tmp11, nil, arch__3, nil)).Ref(); var arg_1756 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1753 == nil { ifn_1754.Invoke_O_O__O(arg_1755, arg_1756) } else { linked_1753.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_1752, arg_1755, arg_1756) } }; var tmp12 any; var root_1765 any = A_arbace_box_build_A_const_20.GetRawRoot__O(); var linked_1766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1765, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1767 lang.IFn; if linked_1766 == nil { ifn_1767 = lang.IFn_Cast(root_1765) } else { ifn_1767 = nil }; var arg_1768 any = seq_598000231__10; if linked_1766 == nil { tmp12 = ifn_1767.Invoke_O__O(arg_1768) } else { tmp12 = linked_1766.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1765, arg_1768) }; seq_598000231__5, chunk_598000232__6, count_598000233__7, i_598000234__8 = tmp12, nil, 0, 0; continue L1 } } }
//line :281:1
		break L1 }; var root_1709 any =







	A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_1710 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1709, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1711 lang.IFn; if linked_1710 == nil { ifn_1711 = lang.IFn_Cast(root_1709) } else { ifn_1711 = nil }; var arg_1712 any = opts__1; var arg_1713 any = A_arbace_box_build_A_const_120; var arg_1714 any = tools__4; if linked_1710 == nil { return ifn_1711.Invoke_O_O_O__O(arg_1712, arg_1713, arg_1714) } else { return linked_1710.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1709, arg_1712, arg_1713, arg_1714) } }
//line :285:1
func A_arbace_box_build_with_tools_iter__598000221__598000225_A_New_O(p0 any) *A_arbace_box_build_with_tools_iter__598000221__598000225_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_with_tools_iter__598000221__598000225_A{}; t.Ctor_O(p0); return t }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_A) Ctor_O(c__arch any) { t.F_arch = c__arch }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_A) Invoke_O_O__O(self, s__598000222__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1706 any = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_New_O_O_O(s__598000222__1, t.F_arch, self); var tmp2 *jrt.Class; var fncls__1705 *jrt.Class = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_fn_class; if fncls__1705 == nil { var fncls__1705d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_150, false, fnbody__1706); A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_fn_class = fncls__1705d; tmp2 = fncls__1705d } else { tmp2 = fncls__1705 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1706, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :285:1
func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A) Ctor_O_O_O(c__s__598000222, c__arch, c__iter__598000221 any) { t.F_s__598000222 = c__s__598000222; t.F_arch = c__arch; t.F_iter__598000221 = c__iter__598000221 }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A) Invoke_O__O(self any) any { { var s__598000222__1 any; var t_ any = t.F_s__598000222; t.F_s__598000222 = nil; s__598000222__1 = t_; for { var temp__1927000414__auto____2 any; var root_1631 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1631, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1633 lang.IFn; if linked_1632 == nil { ifn_1633 = lang.IFn_Cast(root_1631) } else { ifn_1633 = nil }; var arg_1634 any = s__598000222__1; if linked_1632 == nil { temp__1927000414__auto____2 = ifn_1633.Invoke_O__O(arg_1634) } else { temp__1927000414__auto____2 = linked_1632.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1631, arg_1634) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000222__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1635 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1635, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1637 lang.IFn; if linked_1636 == nil { ifn_1637 = lang.IFn_Cast(root_1635) } else { ifn_1637 = nil }; var arg_1638 any = s__598000222__3; if linked_1636 == nil { tmp1 = ifn_1637.Invoke_O__O(arg_1638) } else { tmp1 = linked_1636.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1635, arg_1638) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1639 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1639, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1641 lang.IFn; if linked_1640 == nil { ifn_1641 = lang.IFn_Cast(root_1639) } else { ifn_1641 = nil }; var arg_1642 any = s__598000222__3; if linked_1640 == nil { c__1927001037__auto____4 = ifn_1641.Invoke_O__O(arg_1642) } else { c__1927001037__auto____4 = linked_1640.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1639, arg_1642) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000224__6 any; var root_1643 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1643, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1645 lang.IFn; if linked_1644 == nil { ifn_1645 = lang.IFn_Cast(root_1643) } else { ifn_1645 = nil }; var arg_1646 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1644 == nil { b__598000224__6 = ifn_1645.Invoke_O__O(arg_1646) } else { b__598000224__6 = linked_1644.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1643, arg_1646) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1661 any = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_New_O_O_I_O(b__598000224__6, t.F_arch, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1660 *jrt.Class = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_fn_class; if fncls__1660 == nil { var fncls__1660d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_151, false, fnbody__1661); A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_fn_class = fncls__1660d; tmp3 = fncls__1660d } else { tmp3 = fncls__1660 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1661, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1662 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1662, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1664 lang.IFn; if linked_1663 == nil { ifn_1664 = lang.IFn_Cast(root_1662) } else { ifn_1664 = nil }; var arg_1665 any; var root_1667 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1667, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1669 lang.IFn; if linked_1668 == nil { ifn_1669 = lang.IFn_Cast(root_1667) } else { ifn_1669 = nil }; var arg_1670 any = b__598000224__6; if linked_1668 == nil { arg_1665 = ifn_1669.Invoke_O__O(arg_1670) } else { arg_1665 = linked_1668.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1667, arg_1670) }; var arg_1666 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000221); var tmp5 any; var root_1671 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1671, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any = s__598000222__3; if linked_1672 == nil { tmp5 = ifn_1673.Invoke_O__O(arg_1674) } else { tmp5 = linked_1672.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1671, arg_1674) }; arg_1666 = tmp4.Invoke_O__O(tmp5); if linked_1663 == nil { return ifn_1664.Invoke_O_O__O(arg_1665, arg_1666) } else { return linked_1663.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1662, arg_1665, arg_1666) } } else { var root_1675 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1675, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1677 lang.IFn; if linked_1676 == nil { ifn_1677 = lang.IFn_Cast(root_1675) } else { ifn_1677 = nil }; var arg_1678 any; var root_1680 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = b__598000224__6; if linked_1681 == nil { arg_1678 = ifn_1682.Invoke_O__O(arg_1683) } else { arg_1678 = linked_1681.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1680, arg_1683) }; var arg_1679 any; if linked_1676 == nil { return ifn_1677.Invoke_O_O__O(arg_1678, arg_1679) } else { return linked_1676.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1675, arg_1678, arg_1679) } } } else { var t__4 any; var root_1684 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1686 lang.IFn; if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = s__598000222__3; if linked_1685 == nil { t__4 = ifn_1686.Invoke_O__O(arg_1687) } else { t__4 = linked_1685.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1684, arg_1687) }; var root_1688 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1688, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1690 lang.IFn; if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any; var tmp6 any; var root_1693 any = A_arbace_box_build_A_const_61.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1693, aot_arbace_box.A_arbace_box_ref_A_fn_class); var ifn_1695 lang.IFn
														if linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var arg_1696 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_152, nil, Lit_153, nil); var tmp8 any; var root_1697 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1697, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1699 lang.IFn; if linked_1698 == nil { ifn_1699 = lang.IFn_Cast(root_1697) } else { ifn_1699 = nil }; var arg_1700 any = t__4; if linked_1698 == nil { tmp8 = ifn_1699.Invoke_O__O(arg_1700) } else { tmp8 = linked_1698.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1697, arg_1700) }; arg_1696 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil, t.F_arch)).Ref(); if linked_1694 == nil { tmp6 = ifn_1695.Invoke_O__O(arg_1696) } else { tmp6 = linked_1694.(*aot_arbace_box.A_arbace_box_ref_A).Invoke_O_O__O(root_1693, arg_1696) }
//line :285:1
	arg_1691 = lang.Tuple_Create_O_O__IPersistentVector(t__4, tmp6); var arg_1692 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__598000221); var tmp10 any; var root_1701 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1701, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1703 lang.IFn; if linked_1702 == nil { ifn_1703 = lang.IFn_Cast(root_1701) } else { ifn_1703 = nil }; var arg_1704 any = s__598000222__3; if linked_1702 == nil { tmp10 = ifn_1703.Invoke_O__O(arg_1704) } else { tmp10 = linked_1702.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1701, arg_1704) }; arg_1692 = tmp9.Invoke_O__O(tmp10); if linked_1689 == nil { return ifn_1690.Invoke_O_O__O(arg_1691, arg_1692) } else { return linked_1689.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1688, arg_1691, arg_1692) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :285:1
func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A) Ctor_O_O_I_O(c__b__598000224, c__arch any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000224 = c__b__598000224; t.F_arch = c__arch; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A) Invoke_O__O(self any) any { { var i__598000223__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000223__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000223__1)); var root_1647 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1647, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1649 lang.IFn; if linked_1648 == nil { ifn_1649 = lang.IFn_Cast(root_1647) } else { ifn_1649 = nil }; var arg_1650 any = t.F_b__598000224; var arg_1651 any; var tmp2 any; var root_1652 any = A_arbace_box_build_A_const_61.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_box.A_arbace_box_ref_A_fn_class); var ifn_1654 lang.IFn
																if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_152, nil, Lit_153, nil); var tmp4 any; var root_1656 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1658 lang.IFn; if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any = t__2; if linked_1657 == nil { tmp4 = ifn_1658.Invoke_O__O(arg_1659) } else { tmp4 = linked_1657.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1656, arg_1659) }; arg_1655 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, t.F_arch)).Ref(); if linked_1653 == nil { tmp2 = ifn_1654.Invoke_O__O(arg_1655) } else { tmp2 = linked_1653.(*aot_arbace_box.A_arbace_box_ref_A).Invoke_O_O__O(root_1652, arg_1655) }
//line :285:1
	arg_1651 = lang.Tuple_Create_O_O__IPersistentVector(t__2, tmp2); if linked_1648 == nil { ifn_1649.Invoke_O_O__O(arg_1650, arg_1651) } else { linked_1648.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1647, arg_1650, arg_1651) }; i__598000223__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000223__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_box_build_archives_A_New() *A_arbace_box_build_archives_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_box_build_archives_A) Ctor() {}
//line :291:1
func (t *A_arbace_box_build_archives_A) Invoke_O_O_O__O(self, plan__0, opts__1 any) any { var p__3 any; var root_1769 any = A_arbace_box_build_A_const_169.GetRawRoot__O(); var linked_1770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1769, A_arbace_box_build_read_plan_A_fn_class); var ifn_1771 lang.IFn; if




	linked_1770 == nil { ifn_1771 = lang.IFn_Cast(root_1769) } else { ifn_1771 = nil }; var arg_1772 any = plan__0; if linked_1770 == nil { p__3 = ifn_1771.Invoke_O__O(arg_1772) } else { p__3 = linked_1770.(*A_arbace_box_build_read_plan_A).Invoke_O_O__O(root_1769, arg_1772) }; var opts__4 any; var root_1773 any = /*line :291:1*/A_arbace_box_build_A_const_170.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, A_arbace_box_build_with_tools_A_fn_class); var ifn_1775 lang.IFn; if





	linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any = p__3; var arg_1777 any = opts__1; if linked_1774 == nil { opts__4 = ifn_1775.Invoke_O_O__O(arg_1776, arg_1777) } else { opts__4 = linked_1774.(*A_arbace_box_build_with_tools_A).Invoke_O_O_O__O(root_1773, arg_1776, arg_1777) }; var pkgs__5 any = /*line :291:1*/A_arbace_box_build_A_const_41.Invoke_O__O(p__3); var index__6 any; var root_1778 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1778, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1780 lang.IFn; if







	linked_1779 == nil { ifn_1780 = lang.IFn_Cast(root_1778) } else { ifn_1780 = nil }; var arg_1781 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1782 any; var root_1783 any = A_arbace_box_build_A_const_171.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any; var fnbody__1789 any = A_arbace_box_build_archives_fn__598000242_A_New(); var tmp1 *jrt.Class; var fncls__1788 *jrt.Class = A_arbace_box_build_archives_fn__598000242_A_fn_class; if fncls__1788 == nil { var fncls__1788d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, nil); A_arbace_box_build_archives_fn__598000242_A_fn_class = fncls__1788d; tmp1 = fncls__1788d } else { tmp1 = fncls__1788 }; arg_1786 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1789, tmp1, nil); var arg_1787 any = pkgs__5; if linked_1784 == nil { arg_1782 = ifn_1785.Invoke_O_O__O(arg_1786, arg_1787) } else { arg_1782 = linked_1784.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1783, arg_1786, arg_1787) }; if linked_1779 == nil { index__6 = ifn_1780.Invoke_O_O__O(arg_1781, arg_1782) } else { index__6 = linked_1779.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1778, arg_1781, arg_1782) }; var given__7 any = /*line :291:1*/A_arbace_box_build_A_const_172.Invoke_O__O(opts__4); var only__8 any = A_arbace_box_build_A_const_173.Invoke_O__O(opts__4); var futures__9 any; var root_1790 any = A_arbace_box_build_A_const_35.GetRawRoot__O(); var linked_1791 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1790, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1792 lang.IFn; if











	linked_1791 == nil { ifn_1792 = lang.IFn_Cast(root_1790) } else { ifn_1792 = nil }; var arg_1793 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1791 == nil { futures__9 = ifn_1792.Invoke_O__O(arg_1793) } else { futures__9 = linked_1791.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1790, arg_1793) }; var sem__10 any = /*line :291:1*/jrt.Semaphore_New_I(lang.RT_IntCast_O__I_NoInit(A_arbace_box_build_A_const_174.Invoke_O_O__O(opts__4, A_arbace_box_build_A_const_175))); var conveyed__11 any; var fnbody__1809 any = A_arbace_box_build_archives_conveyed__598000244_A_New_O(opts__4); var tmp2 *jrt.Class; var fncls__1808 *jrt.Class = A_arbace_box_build_archives_conveyed__598000244_A_fn_class; if













	fncls__1808 == nil { var fncls__1808d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, fnbody__1809); A_arbace_box_build_archives_conveyed__598000244_A_fn_class = fncls__1808d; tmp2 = fncls__1808d } else { tmp2 = fncls__1808 }; conveyed__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1809, tmp2, nil); var root_1892 any =
	A_arbace_box_build_A_const_81.GetRawRoot__O(); var linked_1893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1892, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1894 lang.IFn; if linked_1893 == nil { ifn_1894 = lang.IFn_Cast(root_1892) } else { ifn_1894 = nil }; var arg_1895 any = lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, opts__4); if linked_1893 == nil { ifn_1894.Invoke_O__O(arg_1895) } else { linked_1893.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1892, arg_1895) }; var tmp3 any; tmp18 := /*line :291:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_598000248__14 any; var root_1901 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1901, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1903 lang.IFn















		if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any = pkgs__5; if linked_1902 == nil { seq_598000248__14 = ifn_1903.Invoke_O__O(arg_1904) } else { seq_598000248__14 = linked_1902.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1901, arg_1904) }
//line :291:1
		var chunk_598000249__15 any; var count_598000250__16 int64 = 0; var i_598000251__17 int64 = 0; L1: for {















			if lang.Numbers_Lt_J_J__Z_NoInit(i_598000251__17, count_598000250__16) { var q__18 any = lang.Indexed_Cast(chunk_598000249__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_598000251__17)); var deps__19 any; var root_1921 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1922 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1921, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1923 lang.IFn
				if linked_1922 == nil { ifn_1923 = lang.IFn_Cast(root_1921) } else { ifn_1923 = nil }; var arg_1924 any; var root_1926 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1926, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1928 lang.IFn; if linked_1927 == nil { ifn_1928 = lang.IFn_Cast(root_1926) } else { ifn_1928 = nil }; var arg_1929 any = futures__9; if linked_1927 == nil { arg_1924 = ifn_1928.Invoke_O__O(arg_1929) } else { arg_1924 = linked_1927.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1926, arg_1929) }; var arg_1925 any = A_arbace_box_build_A_const_121.Invoke_O__O(q__18); if linked_1922 == nil { deps__19 = ifn_1923.Invoke_O_O__O(arg_1924, arg_1925) } else { deps__19 = linked_1922.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1921, arg_1924, arg_1925) }
				var root_1930 any = A_arbace_box_build_A_const_37.GetRawRoot__O(); var linked_1931 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1930, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1932 lang.IFn; if linked_1931 == nil { ifn_1932 = lang.IFn_Cast(root_1930) } else { ifn_1932 = nil }; var arg_1933 any = futures__9; var arg_1934 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var arg_1935 any = A_arbace_box_build_A_const_91.Invoke_O__O(q__18); var arg_1936 any; var tmp4 any; var and__1927000168__auto____20 any = only__8
				if jrt.J2g_Truth(and__1927000168__auto____20) { var root_1937 any = A_arbace_box_build_A_const_73.GetRawRoot__O(); var linked_1938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1937, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1939 lang.IFn; if linked_1938 == nil { ifn_1939 = lang.IFn_Cast(root_1937) } else { ifn_1939 = nil }; var arg_1940 any = lang.IFn_Cast(only__8).Invoke_O__O(A_arbace_box_build_A_const_91.Invoke_O__O(q__18)); if linked_1938 == nil { tmp4 = ifn_1939.Invoke_O__O(arg_1940) } else { tmp4 = linked_1938.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1937, arg_1940) } } else { tmp4 = and__1927000168__auto____20 }; if jrt.J2g_Truth(tmp4) { var tmp5 *lang.Compiler_AOTFn; var fnbody__1947 any = A_arbace_box_build_archives_fn__598000252_A_New_O_O(given__7, q__18); var tmp6 *jrt.Class; var fncls__1946 *jrt.Class = A_arbace_box_build_archives_fn__598000252_A_fn_class
					if fncls__1946 == nil { var fncls__1946d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__1947); A_arbace_box_build_archives_fn__598000252_A_fn_class = fncls__1946d; tmp6 = fncls__1946d } else { tmp6 = fncls__1946 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1947, tmp6, nil)
//line :310:1
					arg_1936 = lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp5)) } else {

						var root_1948 any = A_arbace_box_build_A_const_145.GetRawRoot__O(); var linked_1949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1948, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_1950 lang.IFn; if linked_1949 == nil { ifn_1950 = lang.IFn_Cast(root_1948) } else { ifn_1950 = nil }; var arg_1951 any; var fnbody__1979 any = A_arbace_box_build_archives_fn__598000254_A_New_O_O_O_O_O_O(index__6, p__3, deps__19, sem__10, conveyed__11, q__18); var tmp7 *jrt.Class; var fncls__1978 *jrt.Class = A_arbace_box_build_archives_fn__598000254_A_fn_class; if fncls__1978 == nil { var fncls__1978d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__1979); A_arbace_box_build_archives_fn__598000254_A_fn_class = fncls__1978d; tmp7 = fncls__1978d } else { tmp7 = fncls__1978 }; arg_1951 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1979, tmp7, nil); if linked_1949 == nil { arg_1936 = ifn_1950.Invoke_O__O(arg_1951) } else { arg_1936 = linked_1949.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_1948, arg_1951) } }
//line :309:1
				if linked_1931 == nil { ifn_1932.Invoke_O_O_O_O__O(arg_1933, arg_1934, arg_1935, arg_1936) } else { linked_1931.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1930, arg_1933, arg_1934, arg_1935, arg_1936) }
//line :307:1
				seq_598000248__14, chunk_598000249__15, count_598000250__16, i_598000251__17 = seq_598000248__14, chunk_598000249__15, count_598000250__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_598000251__17); continue L1 } else { var temp__1927000414__auto____18 any; var root_1905 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1905, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1907 lang.IFn; if linked_1906 == nil { ifn_1907 = lang.IFn_Cast(root_1905) } else { ifn_1907 = nil }; var arg_1908 any = seq_598000248__14; if linked_1906 == nil { temp__1927000414__auto____18 = ifn_1907.Invoke_O__O(arg_1908) } else { temp__1927000414__auto____18 = linked_1906.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1905, arg_1908) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_598000248__19 any = temp__1927000414__auto____18; var tmp8 any; var root_1909 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1909, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1911 lang.IFn; if linked_1910 == nil { ifn_1911 = lang.IFn_Cast(root_1909) } else { ifn_1911 = nil }; var arg_1912 any = seq_598000248__19; if linked_1910 == nil { tmp8 = ifn_1911.Invoke_O__O(arg_1912) } else { tmp8 = linked_1910.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1909, arg_1912) }; if jrt.J2g_Truth(tmp8) { var c__1927000678__auto____20 any; var root_1913 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1913, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1915 lang.IFn; if linked_1914 == nil { ifn_1915 = lang.IFn_Cast(root_1913) } else { ifn_1915 = nil }; var arg_1916 any = seq_598000248__19; if linked_1914 == nil { c__1927000678__auto____20 = ifn_1915.Invoke_O__O(arg_1916) } else { c__1927000678__auto____20 = linked_1914.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1913, arg_1916) }; var tmp9 any; var root_1980 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1980, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1982 lang.IFn; if linked_1981 == nil { ifn_1982 = lang.IFn_Cast(root_1980) } else { ifn_1982 = nil }; var arg_1983 any = seq_598000248__19; if linked_1981 == nil { tmp9 = ifn_1982.Invoke_O__O(arg_1983) } else { tmp9 = linked_1981.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1980, arg_1983) }; seq_598000248__14, chunk_598000249__15, count_598000250__16, i_598000251__17 = tmp9, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var q__20 any; var root_1917 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1917, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1919 lang.IFn; if linked_1918 == nil { ifn_1919 = lang.IFn_Cast(root_1917) } else { ifn_1919 = nil }; var arg_1920 any = seq_598000248__19; if linked_1918 == nil { q__20 = ifn_1919.Invoke_O__O(arg_1920) } else { q__20 = linked_1918.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1917, arg_1920) }; var deps__21 any; var root_1984 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1985 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1984, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1986 lang.IFn
					if linked_1985 == nil { ifn_1986 = lang.IFn_Cast(root_1984) } else { ifn_1986 = nil }; var arg_1987 any; var root_1989 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1989, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1991 lang.IFn; if linked_1990 == nil { ifn_1991 = lang.IFn_Cast(root_1989) } else { ifn_1991 = nil }; var arg_1992 any = futures__9; if linked_1990 == nil { arg_1987 = ifn_1991.Invoke_O__O(arg_1992) } else { arg_1987 = linked_1990.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1989, arg_1992) }; var arg_1988 any = A_arbace_box_build_A_const_121.Invoke_O__O(q__20); if linked_1985 == nil { deps__21 = ifn_1986.Invoke_O_O__O(arg_1987, arg_1988) } else { deps__21 = linked_1985.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1984, arg_1987, arg_1988) }
					var root_1993 any = A_arbace_box_build_A_const_37.GetRawRoot__O(); var linked_1994 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1993, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1995 lang.IFn; if linked_1994 == nil { ifn_1995 = lang.IFn_Cast(root_1993) } else { ifn_1995 = nil }; var arg_1996 any = futures__9; var arg_1997 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var arg_1998 any = A_arbace_box_build_A_const_91.Invoke_O__O(q__20); var arg_1999 any; var tmp10 any; var and__1927000168__auto____22 any = only__8
					if jrt.J2g_Truth(and__1927000168__auto____22) { var root_2000 any = A_arbace_box_build_A_const_73.GetRawRoot__O(); var linked_2001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2000, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2002 lang.IFn; if linked_2001 == nil { ifn_2002 = lang.IFn_Cast(root_2000) } else { ifn_2002 = nil }; var arg_2003 any = lang.IFn_Cast(only__8).Invoke_O__O(A_arbace_box_build_A_const_91.Invoke_O__O(q__20)); if linked_2001 == nil { tmp10 = ifn_2002.Invoke_O__O(arg_2003) } else { tmp10 = linked_2001.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2000, arg_2003) } } else { tmp10 = and__1927000168__auto____22 }; if jrt.J2g_Truth(tmp10) { var tmp11 *lang.Compiler_AOTFn; var fnbody__2010 any = A_arbace_box_build_archives_fn__598000260_A_New_O_O(given__7, q__20); var tmp12 *jrt.Class; var fncls__2009 *jrt.Class = A_arbace_box_build_archives_fn__598000260_A_fn_class
						if fncls__2009 == nil { var fncls__2009d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__2010); A_arbace_box_build_archives_fn__598000260_A_fn_class = fncls__2009d; tmp12 = fncls__2009d } else { tmp12 = fncls__2009 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2010, tmp12, nil)
//line :310:1
						arg_1999 = lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp11)) } else {

							var root_2011 any = A_arbace_box_build_A_const_145.GetRawRoot__O(); var linked_2012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2011, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_2013 lang.IFn; if linked_2012 == nil { ifn_2013 = lang.IFn_Cast(root_2011) } else { ifn_2013 = nil }; var arg_2014 any; var fnbody__2042 any = A_arbace_box_build_archives_fn__598000262_A_New_O_O_O_O_O_O(index__6, p__3, deps__21, sem__10, conveyed__11, q__20); var tmp13 *jrt.Class; var fncls__2041 *jrt.Class = A_arbace_box_build_archives_fn__598000262_A_fn_class; if fncls__2041 == nil { var fncls__2041d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__2042); A_arbace_box_build_archives_fn__598000262_A_fn_class = fncls__2041d; tmp13 = fncls__2041d } else { tmp13 = fncls__2041 }; arg_2014 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2042, tmp13, nil); if linked_2012 == nil { arg_1999 = ifn_2013.Invoke_O__O(arg_2014) } else { arg_1999 = linked_2012.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_2011, arg_2014) } }
//line :309:1
					if linked_1994 == nil { ifn_1995.Invoke_O_O_O_O__O(arg_1996, arg_1997, arg_1998, arg_1999) } else { linked_1994.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1993, arg_1996, arg_1997, arg_1998, arg_1999) }
//line :307:1
					var tmp14 any; var root_2043 any = A_arbace_box_build_A_const_20.GetRawRoot__O(); var linked_2044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2043, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2045 lang.IFn; if linked_2044 == nil { ifn_2045 = lang.IFn_Cast(root_2043) } else { ifn_2045 = nil }; var arg_2046 any = seq_598000248__19; if linked_2044 == nil { tmp14 = ifn_2045.Invoke_O__O(arg_2046) } else { tmp14 = linked_2044.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2043, arg_2046) }; seq_598000248__14, chunk_598000249__15, count_598000250__16, i_598000251__17 = tmp14, nil, 0, 0; continue L1 } } }
//line :291:1
			break L1
		}



























		var root_1810 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1810, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1812 lang.IFn; if linked_1811 == nil { ifn_1812 = lang.IFn_Cast(root_1810) } else { ifn_1812 = nil }; var arg_1813 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1814 any; var iter__1927001039__auto____14 any; var fnbody__1884 any = A_arbace_box_build_archives_iter__598000268__598000272_A_New(); var tmp15 *jrt.Class; var fncls__1883 *jrt.Class = A_arbace_box_build_archives_iter__598000268__598000272_A_fn_class; if fncls__1883 == nil { var fncls__1883d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, nil); A_arbace_box_build_archives_iter__598000268__598000272_A_fn_class = fncls__1883d; tmp15 = fncls__1883d } else { tmp15 = fncls__1883 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1884, tmp15, nil); var tmp16 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____14); var tmp17 any; var root_1885 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1885, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1887 lang.IFn; if linked_1886 == nil { ifn_1887 = lang.IFn_Cast(root_1885) } else { ifn_1887 = nil }; var arg_1888 any = futures__9; if linked_1886 == nil { tmp17 = ifn_1887.Invoke_O__O(arg_1888) } else { tmp17 = linked_1886.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1885, arg_1888) }; arg_1814 = tmp16.Invoke_O__O(tmp17); if linked_1811 == nil { tmp3 = ifn_1812.Invoke_O_O__O(arg_1813, arg_1814) } else { tmp3 = linked_1811.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1810, arg_1813, arg_1814) } }; return nil }(); var root_1889 any = /*line :291:1*/A_arbace_box_build_A_const_80.GetRawRoot__O(); var linked_1890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1889, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1891 lang.IFn; if














	linked_1890 == nil { ifn_1891 = lang.IFn_Cast(root_1889) } else { ifn_1891 = nil }; if linked_1890 == nil { ifn_1891.Invoke__O() } else { linked_1890.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1889) }; if /*line :291:1*/ tmp18 != nil { panic(tmp18) }; return tmp3 }







func A_arbace_box_build_archives_fn__598000242_A_New() *A_arbace_box_build_archives_fn__598000242_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000242_A{}; t.Ctor(); return t }
//line :299:1
func (t *A_arbace_box_build_archives_fn__598000242_A) Ctor() {}
//line :299:1
func (t *A_arbace_box_build_archives_fn__598000242_A) Invoke_O_O_O__O(self, i__1, q__2 any) any { return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_91.Invoke_O__O(q__2), i__1) }





func A_arbace_box_build_archives_conveyed__598000244_A_New_O(p0 any) *A_arbace_box_build_archives_conveyed__598000244_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_conveyed__598000244_A{}; t.Ctor_O(p0); return t }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_A) Invoke_O_O__O(self, f__1 any) any { var o__2 any = t.F_opts; var fnbody__1807 any = A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_New_O_O(f__1, o__2); var tmp1 *jrt.Class; var fncls__1806 *jrt.Class = A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_fn_class; if fncls__1806 == nil { var fncls__1806d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, fnbody__1807); A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_fn_class = fncls__1806d; tmp1 = fncls__1806d } else { tmp1 = fncls__1806 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1807, tmp1, nil) }
//line :305:1
func A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A{}; t.Ctor_O_O(p0, p1); return t }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A) Ctor_O_O(c__f, c__o any) { t.F_f = c__f; t.F_o = c__o }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A) Invoke_O__O(self any) any { var root_1797 any = A_arbace_box_build_A_const_81.GetRawRoot__O(); var linked_1798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1797, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1799 lang.IFn; if linked_1798 == nil { ifn_1799 = lang.IFn_Cast(root_1797) } else { ifn_1799 = nil }; var arg_1800 any = lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, t.F_o); if linked_1798 == nil { ifn_1799.Invoke_O__O(arg_1800) } else { linked_1798.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1797, arg_1800) }; var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(t.F_f).Invoke__O(); return nil }(); var root_1794 any = A_arbace_box_build_A_const_80.GetRawRoot__O(); var linked_1795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1794, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1796 lang.IFn; if linked_1795 == nil { ifn_1796 = lang.IFn_Cast(root_1794) } else { ifn_1796 = nil }; if linked_1795 == nil { ifn_1796.Invoke__O() } else { linked_1795.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1794) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }





func A_arbace_box_build_archives_fn__598000252_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_fn__598000252_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000252_A{}; t.Ctor_O_O(p0, p1); return t }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000252_A) Ctor_O_O(c__given, c__q any) { t.F_given = c__given; t.F_q = c__q }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000252_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var tmp1 any; var t_ any = t.F_given; t.F_given = nil; tmp1 = t_; or__1927000174__auto____1 = lang.RT_Get_O_O__O_NoInit(tmp1, A_arbace_box_build_A_const_91.Invoke_O__O(t.F_q)); if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { var root_1941 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_1942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1941, A_arbace_box_build_fail_A_fn_class); var ifn_1943 lang.IFn; if linked_1942 == nil { ifn_1943 = lang.IFn_Cast(root_1941) } else { ifn_1943 = nil }; var arg_1944 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil); var tmp3 *lang.Keyword = A_arbace_box_build_A_const_91; var tmp4 any; var t__2 any = t.F_q; t.F_q = nil; tmp4 = t__2; arg_1944 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3.Invoke_O__O(tmp4))).Ref(); var arg_1945 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1942 == nil { return ifn_1943.Invoke_O_O__O(arg_1944, arg_1945) } else { return linked_1942.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_1941, arg_1944, arg_1945) } } }
//line :311:1
func A_arbace_box_build_archives_fn__598000260_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_fn__598000260_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000260_A{}; t.Ctor_O_O(p0, p1); return t }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000260_A) Ctor_O_O(c__given, c__q any) { t.F_given = c__given; t.F_q = c__q }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000260_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var tmp1 any; var t_ any = t.F_given; t.F_given = nil; tmp1 = t_; or__1927000174__auto____1 = lang.RT_Get_O_O__O_NoInit(tmp1, A_arbace_box_build_A_const_91.Invoke_O__O(t.F_q)); if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { var root_2004 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_2005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2004, A_arbace_box_build_fail_A_fn_class); var ifn_2006 lang.IFn; if linked_2005 == nil { ifn_2006 = lang.IFn_Cast(root_2004) } else { ifn_2006 = nil }; var arg_2007 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil); var tmp3 *lang.Keyword = A_arbace_box_build_A_const_91; var tmp4 any; var t__2 any = t.F_q; t.F_q = nil; tmp4 = t__2; arg_2007 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3.Invoke_O__O(tmp4))).Ref(); var arg_2008 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2005 == nil { return ifn_2006.Invoke_O_O__O(arg_2007, arg_2008) } else { return linked_2005.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_2004, arg_2007, arg_2008) } } }
func A_arbace_box_build_archives_fn__598000254_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_box_build_archives_fn__598000254_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000254_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000254_A) Ctor_O_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__conveyed, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_conveyed = c__conveyed; t.F_q = c__q }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000254_A) Invoke_O__O(self any) any {
	var tmp1 any; var t_ any = t.F_conveyed; t.F_conveyed = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 *lang.Compiler_AOTFn; var fnbody__1977 any = A_arbace_box_build_archives_fn__598000254_fn__598000255_A_New_O_O_O_O_O(t.F_index, t.F_p, t.F_deps, t.F_sem, t.F_q); var tmp4 *jrt.Class; var fncls__1976 *jrt.Class = A_arbace_box_build_archives_fn__598000254_fn__598000255_A_fn_class
	if fncls__1976 == nil { var fncls__1976d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__1977); A_arbace_box_build_archives_fn__598000254_fn__598000255_A_fn_class = fncls__1976d; tmp4 = fncls__1976d } else { tmp4 = fncls__1976 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1977, tmp4, nil)
//line :313:1
	return lang.IFn_Cast(tmp2.Invoke_O__O(tmp3.Ref())).Invoke__O() }
//line :312:1
func A_arbace_box_build_archives_fn__598000262_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_box_build_archives_fn__598000262_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000262_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000262_A) Ctor_O_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__conveyed, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_conveyed = c__conveyed; t.F_q = c__q }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000262_A) Invoke_O__O(self any) any {
	var tmp1 any; var t_ any = t.F_conveyed; t.F_conveyed = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 *lang.Compiler_AOTFn; var fnbody__2040 any = A_arbace_box_build_archives_fn__598000262_fn__598000263_A_New_O_O_O_O_O(t.F_index, t.F_p, t.F_deps, t.F_sem, t.F_q); var tmp4 *jrt.Class; var fncls__2039 *jrt.Class = A_arbace_box_build_archives_fn__598000262_fn__598000263_A_fn_class
	if fncls__2039 == nil { var fncls__2039d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, fnbody__2040); A_arbace_box_build_archives_fn__598000262_fn__598000263_A_fn_class = fncls__2039d; tmp4 = fncls__2039d } else { tmp4 = fncls__2039 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2040, tmp4, nil)
//line :313:1
	return lang.IFn_Cast(tmp2.Invoke_O__O(tmp3.Ref())).Invoke__O() }
func A_arbace_box_build_archives_fn__598000254_fn__598000255_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_box_build_archives_fn__598000254_fn__598000255_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000254_fn__598000255_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_A) Ctor_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_q = c__q }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_A) Invoke_O__O(self any) any { var archives__1 any; var root_1952 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1952, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1954 lang.IFn; if
												linked_1953 == nil { ifn_1954 = lang.IFn_Cast(root_1952) } else { ifn_1954 = nil }; var arg_1955 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1956 any; var root_1957 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1958 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1957, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1959 lang.IFn; if linked_1958 == nil { ifn_1959 = lang.IFn_Cast(root_1957) } else { ifn_1959 = nil }; var arg_1960 any; var fnbody__1968 any = A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_New(); var tmp1 *jrt.Class; var fncls__1967 *jrt.Class = A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_fn_class; if fncls__1967 == nil { var fncls__1967d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, nil); A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_fn_class = fncls__1967d; tmp1 = fncls__1967d } else { tmp1 = fncls__1967 }; arg_1960 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1968, tmp1, nil); var arg_1961 any = A_arbace_box_build_A_const_121.Invoke_O__O(t.F_q); var arg_1962 any = t.F_deps; if linked_1958 == nil { arg_1956 = ifn_1959.Invoke_O_O_O__O(arg_1960, arg_1961, arg_1962) } else { arg_1956 = linked_1958.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1957, arg_1960, arg_1961, arg_1962) }; if linked_1953 == nil { archives__1 = ifn_1954.Invoke_O_O__O(arg_1955, arg_1956) } else { archives__1 = linked_1953.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1952, arg_1955, arg_1956) };
												jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Acquire__V(); var tmp2 any; tmp3 := /*line :314:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		{ var root_1969 any = A_arbace_box_build_A_const_176.GetRawRoot__O(); var linked_1970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1969, A_arbace_box_build_build_package_A_fn_class); var ifn_1971 lang.IFn; if linked_1970 == nil { ifn_1971 = lang.IFn_Cast(root_1969) } else { ifn_1971 = nil }; var arg_1972 any = t.F_p; var arg_1973 any = t.F_q; var arg_1974 any = archives__1; var arg_1975 any = t.F_index; if linked_1970 == nil { tmp2 = ifn_1971.Invoke_O_O_O_O__O(arg_1972, arg_1973, arg_1974, arg_1975) } else { tmp2 = linked_1970.(*A_arbace_box_build_build_package_A).Invoke_O_O_O_O_O__O(root_1969, arg_1972, arg_1973, arg_1974, arg_1975) } }
//line :314:1
		return nil }();




	jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Release__V(); if /*line :314:1*/ tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :314:1
func A_arbace_box_build_archives_fn__598000262_fn__598000263_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_box_build_archives_fn__598000262_fn__598000263_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000262_fn__598000263_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_A) Ctor_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_q = c__q }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_A) Invoke_O__O(self any) any { var archives__1 any; var root_2015 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_2016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2015, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2017 lang.IFn; if
												linked_2016 == nil { ifn_2017 = lang.IFn_Cast(root_2015) } else { ifn_2017 = nil }; var arg_2018 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2019 any; var root_2020 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_2021 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2020, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2022 lang.IFn; if linked_2021 == nil { ifn_2022 = lang.IFn_Cast(root_2020) } else { ifn_2022 = nil }; var arg_2023 any; var fnbody__2031 any = A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_New(); var tmp1 *jrt.Class; var fncls__2030 *jrt.Class = A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_fn_class; if fncls__2030 == nil { var fncls__2030d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_fn_class = fncls__2030d; tmp1 = fncls__2030d } else { tmp1 = fncls__2030 }; arg_2023 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2031, tmp1, nil); var arg_2024 any = A_arbace_box_build_A_const_121.Invoke_O__O(t.F_q); var arg_2025 any = t.F_deps; if linked_2021 == nil { arg_2019 = ifn_2022.Invoke_O_O_O__O(arg_2023, arg_2024, arg_2025) } else { arg_2019 = linked_2021.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_2020, arg_2023, arg_2024, arg_2025) }; if linked_2016 == nil { archives__1 = ifn_2017.Invoke_O_O__O(arg_2018, arg_2019) } else { archives__1 = linked_2016.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2015, arg_2018, arg_2019) };
												jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Acquire__V(); var tmp2 any; tmp3 := /*line :314:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		{ var root_2032 any = A_arbace_box_build_A_const_176.GetRawRoot__O(); var linked_2033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2032, A_arbace_box_build_build_package_A_fn_class); var ifn_2034 lang.IFn; if linked_2033 == nil { ifn_2034 = lang.IFn_Cast(root_2032) } else { ifn_2034 = nil }; var arg_2035 any = t.F_p; var arg_2036 any = t.F_q; var arg_2037 any = archives__1; var arg_2038 any = t.F_index; if linked_2033 == nil { tmp2 = ifn_2034.Invoke_O_O_O_O__O(arg_2035, arg_2036, arg_2037, arg_2038) } else { tmp2 = linked_2033.(*A_arbace_box_build_build_package_A).Invoke_O_O_O_O_O__O(root_2032, arg_2035, arg_2036, arg_2037, arg_2038) } }
//line :314:1
		return nil }();




	jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Release__V(); if /*line :314:1*/ tmp3 != nil { panic(tmp3) }; return tmp2 }
func A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_New() *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A) Ctor() {}
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A) Invoke_O_O_O__O(self, i__1, d__2 any) any { var tmp1 any; var root_1963 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1963, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1965 lang.IFn; if linked_1964 == nil { ifn_1965 = lang.IFn_Cast(root_1963) } else { ifn_1965 = nil }; var arg_1966 any = d__2; if linked_1964 == nil { tmp1 = ifn_1965.Invoke_O__O(arg_1966) } else { tmp1 = linked_1964.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1963, arg_1966) }; return lang.Tuple_Create_O_O__IPersistentVector(i__1, tmp1) }
//line :315:1
func A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_New() *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A) Ctor() {}
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A) Invoke_O_O_O__O(self, i__1, d__2 any) any { var tmp1 any; var root_2026 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_2027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2026, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2028 lang.IFn; if linked_2027 == nil { ifn_2028 = lang.IFn_Cast(root_2026) } else { ifn_2028 = nil }; var arg_2029 any = d__2; if linked_2027 == nil { tmp1 = ifn_2028.Invoke_O__O(arg_2029) } else { tmp1 = linked_2027.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2026, arg_2029) }; return lang.Tuple_Create_O_O__IPersistentVector(i__1, tmp1) }




func A_arbace_box_build_archives_iter__598000268__598000272_A_New() *A_arbace_box_build_archives_iter__598000268__598000272_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_iter__598000268__598000272_A{}; t.Ctor(); return t }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_A) Ctor() {}
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_A) Invoke_O_O__O(self, s__598000269__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1882 any = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_New_O_O(self, s__598000269__1); var tmp2 *jrt.Class; var fncls__1881 *jrt.Class = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_fn_class; if fncls__1881 == nil { var fncls__1881d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__1882); A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_fn_class = fncls__1881d; tmp2 = fncls__1881d } else { tmp2 = fncls__1881 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1882, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :320:1
func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A{}; t.Ctor_O_O(p0, p1); return t }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A) Ctor_O_O(c__iter__598000268, c__s__598000269 any) { t.F_iter__598000268 = c__iter__598000268; t.F_s__598000269 = c__s__598000269 }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A) Invoke_O__O(self any) any { { var s__598000269__1 any; var t_ any = t.F_s__598000269; t.F_s__598000269 = nil; s__598000269__1 = t_; for { var temp__1927000414__auto____2 any; var root_1815 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1815, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1817 lang.IFn; if linked_1816 == nil { ifn_1817 = lang.IFn_Cast(root_1815) } else { ifn_1817 = nil }; var arg_1818 any = s__598000269__1; if linked_1816 == nil { temp__1927000414__auto____2 = ifn_1817.Invoke_O__O(arg_1818) } else { temp__1927000414__auto____2 = linked_1816.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1815, arg_1818) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000269__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1819 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1819, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1821 lang.IFn; if linked_1820 == nil { ifn_1821 = lang.IFn_Cast(root_1819) } else { ifn_1821 = nil }; var arg_1822 any = s__598000269__3; if linked_1820 == nil { tmp1 = ifn_1821.Invoke_O__O(arg_1822) } else { tmp1 = linked_1820.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1819, arg_1822) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1823 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1823, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1825 lang.IFn; if linked_1824 == nil { ifn_1825 = lang.IFn_Cast(root_1823) } else { ifn_1825 = nil }; var arg_1826 any = s__598000269__3; if linked_1824 == nil { c__1927001037__auto____4 = ifn_1825.Invoke_O__O(arg_1826) } else { c__1927001037__auto____4 = linked_1824.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1823, arg_1826) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000271__6 any; var root_1827 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1827, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1829 lang.IFn; if linked_1828 == nil { ifn_1829 = lang.IFn_Cast(root_1827) } else { ifn_1829 = nil }; var arg_1830 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1828 == nil { b__598000271__6 = ifn_1829.Invoke_O__O(arg_1830) } else { b__598000271__6 = linked_1828.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1827, arg_1830) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1841 any = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_New_O_I_O(b__598000271__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1840 *jrt.Class = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_fn_class; if fncls__1840 == nil { var fncls__1840d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__1841); A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_fn_class = fncls__1840d; tmp3 = fncls__1840d } else { tmp3 = fncls__1840 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1841, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1842 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1842, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1844 lang.IFn; if linked_1843 == nil { ifn_1844 = lang.IFn_Cast(root_1842) } else { ifn_1844 = nil }; var arg_1845 any; var root_1847 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1847, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1849 lang.IFn; if linked_1848 == nil { ifn_1849 = lang.IFn_Cast(root_1847) } else { ifn_1849 = nil }; var arg_1850 any = b__598000271__6; if linked_1848 == nil { arg_1845 = ifn_1849.Invoke_O__O(arg_1850) } else { arg_1845 = linked_1848.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1847, arg_1850) }; var arg_1846 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000268); var tmp5 any; var root_1851 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1851, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1853 lang.IFn; if linked_1852 == nil { ifn_1853 = lang.IFn_Cast(root_1851) } else { ifn_1853 = nil }; var arg_1854 any = s__598000269__3; if linked_1852 == nil { tmp5 = ifn_1853.Invoke_O__O(arg_1854) } else { tmp5 = linked_1852.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1851, arg_1854) }; arg_1846 = tmp4.Invoke_O__O(tmp5); if linked_1843 == nil { return ifn_1844.Invoke_O_O__O(arg_1845, arg_1846) } else { return linked_1843.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1842, arg_1845, arg_1846) } } else { var root_1855 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1855, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1857 lang.IFn; if linked_1856 == nil { ifn_1857 = lang.IFn_Cast(root_1855) } else { ifn_1857 = nil }; var arg_1858 any; var root_1860 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1862 lang.IFn; if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any = b__598000271__6; if linked_1861 == nil { arg_1858 = ifn_1862.Invoke_O__O(arg_1863) } else { arg_1858 = linked_1861.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1860, arg_1863) }; var arg_1859 any; if linked_1856 == nil { return ifn_1857.Invoke_O_O__O(arg_1858, arg_1859) } else { return linked_1856.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1855, arg_1858, arg_1859) } } } else { var vec__598000279__4 any; var root_1864 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1864, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1866 lang.IFn; if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any = s__598000269__3; if linked_1865 == nil { vec__598000279__4 = ifn_1866.Invoke_O__O(arg_1867) } else { vec__598000279__4 = linked_1865.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1864, arg_1867) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000279__4, lang.RT_IntCast_J__I_NoInit(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000279__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1868 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1868, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1870 lang.IFn; if linked_1869 == nil { ifn_1870 = lang.IFn_Cast(root_1868) } else { ifn_1870 = nil }; var arg_1871 any; var tmp6 any; var root_1873 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1873, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1875 lang.IFn; if linked_1874 == nil { ifn_1875 = lang.IFn_Cast(root_1873) } else { ifn_1875 = nil }; var arg_1876 any = f__6; if linked_1874 == nil { tmp6 = ifn_1875.Invoke_O__O(arg_1876) } else { tmp6 = linked_1874.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1873, arg_1876) }; arg_1871 = lang.Tuple_Create_O_O__IPersistentVector(k__5, tmp6); var arg_1872 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__598000268); var tmp8 any; var root_1877 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1877, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1879 lang.IFn; if linked_1878 == nil { ifn_1879 = lang.IFn_Cast(root_1877) } else { ifn_1879 = nil }; var arg_1880 any = s__598000269__3; if linked_1878 == nil { tmp8 = ifn_1879.Invoke_O__O(arg_1880) } else { tmp8 = linked_1878.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1877, arg_1880) }; arg_1872 = tmp7.Invoke_O__O(tmp8); if linked_1869 == nil { return ifn_1870.Invoke_O_O__O(arg_1871, arg_1872) } else { return linked_1869.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1868, arg_1871, arg_1872) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :320:1
func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A) Ctor_O_I_O(c__b__598000271 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000271 = c__b__598000271; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A) Invoke_O__O(self any) any { { var i__598000270__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000270__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000275__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000270__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000275__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000275__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1831 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1831, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1833 lang.IFn; if linked_1832 == nil { ifn_1833 = lang.IFn_Cast(root_1831) } else { ifn_1833 = nil }; var arg_1834 any = t.F_b__598000271; var arg_1835 any; var tmp2 any; var root_1836 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any = f__4; if linked_1837 == nil { tmp2 = ifn_1838.Invoke_O__O(arg_1839) } else { tmp2 = linked_1837.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1836, arg_1839) }; arg_1835 = lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp2); if linked_1832 == nil { ifn_1833.Invoke_O_O__O(arg_1834, arg_1835) } else { linked_1832.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1831, arg_1834, arg_1835) }; i__598000270__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000270__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_box_build_link_A_New() *A_arbace_box_build_link_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_box_build_link_A) Ctor() {}
//line :322:1
func (t *A_arbace_box_build_link_A) Invoke_O_O_O_O__O(self, plan__0, archives__1, opts__2 any) any { var p__4 any; var root_2047 any = A_arbace_box_build_A_const_169.GetRawRoot__O(); var linked_2048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2047, A_arbace_box_build_read_plan_A_fn_class); var ifn_2049 lang.IFn; if




	linked_2048 == nil { ifn_2049 = lang.IFn_Cast(root_2047) } else { ifn_2049 = nil }; var arg_2050 any = plan__0; if linked_2048 == nil { p__4 = ifn_2049.Invoke_O__O(arg_2050) } else { p__4 = linked_2048.(*A_arbace_box_build_read_plan_A).Invoke_O_O__O(root_2047, arg_2050) }; var opts__5 any; var root_2051 any = /*line :322:1*/A_arbace_box_build_A_const_170.GetRawRoot__O(); var linked_2052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2051, A_arbace_box_build_with_tools_A_fn_class); var ifn_2053 lang.IFn; if





	linked_2052 == nil { ifn_2053 = lang.IFn_Cast(root_2051) } else { ifn_2053 = nil }; var arg_2054 any = p__4; var arg_2055 any = opts__2; if linked_2052 == nil { opts__5 = ifn_2053.Invoke_O_O__O(arg_2054, arg_2055) } else { opts__5 = linked_2052.(*A_arbace_box_build_with_tools_A).Invoke_O_O_O__O(root_2051, arg_2054, arg_2055) }; var pkgs__6 any = /*line :322:1*/A_arbace_box_build_A_const_41.Invoke_O__O(p__4); var index__7 any; var root_2056 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_2057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2056, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2058 lang.IFn; if







	linked_2057 == nil { ifn_2058 = lang.IFn_Cast(root_2056) } else { ifn_2058 = nil }; var arg_2059 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2060 any; var root_2061 any = A_arbace_box_build_A_const_171.GetRawRoot__O(); var linked_2062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2061, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2063 lang.IFn; if linked_2062 == nil { ifn_2063 = lang.IFn_Cast(root_2061) } else { ifn_2063 = nil }; var arg_2064 any; var fnbody__2067 any = A_arbace_box_build_link_fn__598000285_A_New(); var tmp1 *jrt.Class; var fncls__2066 *jrt.Class = A_arbace_box_build_link_fn__598000285_A_fn_class; if fncls__2066 == nil { var fncls__2066d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_128, false, nil); A_arbace_box_build_link_fn__598000285_A_fn_class = fncls__2066d; tmp1 = fncls__2066d } else { tmp1 = fncls__2066 }; arg_2064 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2067, tmp1, nil); var arg_2065 any = pkgs__6; if linked_2062 == nil { arg_2060 = ifn_2063.Invoke_O_O__O(arg_2064, arg_2065) } else { arg_2060 = linked_2062.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2061, arg_2064, arg_2065) }; if linked_2057 == nil { index__7 = ifn_2058.Invoke_O_O__O(arg_2059, arg_2060) } else { index__7 = linked_2057.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2056, arg_2059, arg_2060) }; var root_2188 any =
	A_arbace_box_build_A_const_81.GetRawRoot__O(); var linked_2189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2188, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2190 lang.IFn; if linked_2189 == nil { ifn_2190 = lang.IFn_Cast(root_2188) } else { ifn_2190 = nil }; var arg_2191 any = lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, opts__5); if linked_2189 == nil { ifn_2190.Invoke_O__O(arg_2191) } else { linked_2189.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2188, arg_2191) }; var tmp2 any; tmp17 := /*line :322:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var paths__10 any; var root_2068 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_2069 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2068, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2070 lang.IFn









		if linked_2069 == nil { ifn_2070 = lang.IFn_Cast(root_2068) } else { ifn_2070 = nil }; var arg_2071 any = A_arbace_box_build_A_const_91; var arg_2072 any = pkgs__6; if linked_2069 == nil { paths__10 = ifn_2070.Invoke_O_O__O(arg_2071, arg_2072) } else { paths__10 = linked_2069.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2068, arg_2071, arg_2072) }
//line :322:1
		var vec__598000287__11 any; var root_2073 any = A_arbace_box_build_A_const_122.GetRawRoot__O(); var linked_2074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2073, A_arbace_box_build_deps_tree_A_fn_class); var ifn_2075 lang.IFn










		if linked_2074 == nil { ifn_2075 = lang.IFn_Cast(root_2073) } else { ifn_2075 = nil }; var arg_2076 any = archives__1; var arg_2077 any = index__7; var arg_2078 any = paths__10; if linked_2074 == nil { vec__598000287__11 = ifn_2075.Invoke_O_O_O__O(arg_2076, arg_2077, arg_2078) } else { vec__598000287__11 = linked_2074.(*A_arbace_box_build_deps_tree_A).Invoke_O_O_O_O__O(root_2073, arg_2076, arg_2077, arg_2078) }
//line :322:1
		var dtree__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000287__11, lang.RT_IntCast_J__I_NoInit(0), nil); var lines__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000287__11, lang.RT_IntCast_J__I_NoInit(1), nil); var cfg__14 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil); var tmp4 any; var root_2079 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_2080 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2079, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2081 lang.IFn











		if linked_2080 == nil { ifn_2081 = lang.IFn_Cast(root_2079) } else { ifn_2081 = nil }; var arg_2082 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_2083 any; var iter__1927001039__auto____16 any; var fnbody__2145 any = A_arbace_box_build_link_iter__598000290__598000294_A_New(); var tmp5 *jrt.Class; var fncls__2144 *jrt.Class = A_arbace_box_build_link_iter__598000290__598000294_A_fn_class; if fncls__2144 == nil { var fncls__2144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_129, false, nil); A_arbace_box_build_link_iter__598000290__598000294_A_fn_class = fncls__2144d; tmp5 = fncls__2144d } else { tmp5 = fncls__2144 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2145, tmp5, nil); arg_2083 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(lines__13); if linked_2080 == nil { tmp4 = ifn_2081.Invoke_O_O__O(arg_2082, arg_2083) } else { tmp4 = linked_2080.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2079, arg_2082, arg_2083) }; cfg__14 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref()
//line :322:1
		var res__15 any; var root_2146 any = A_arbace_box_build_A_const_79.GetRawRoot__O(); var linked_2147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2146, A_arbace_box_build_action_STAR__A_fn_class); var ifn_2148 lang.IFn












		if linked_2147 == nil { ifn_2148 = lang.IFn_Cast(root_2146) } else { ifn_2148 = nil }; var arg_2149 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_130), jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_177.Invoke_O__O(p__4), nil)).Ref(); var arg_2150 any; var root_2151 any = A_arbace_box_build_A_const_124.GetRawRoot__O(); var linked_2152 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2151, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_2153 lang.IFn
		if linked_2152 == nil { ifn_2153 = lang.IFn_Cast(root_2151) } else { ifn_2153 = nil }; var arg_2154 any; var tmp6 any = A_arbace_box_build_A_const_138; var tmp7 *lang.Keyword = A_arbace_box_build_A_const_178; var tmp8 any = tmp7.Invoke_O__O(A_arbace_box_build_A_const_120.Invoke_O__O(opts__5)); var tmp9 any = A_arbace_box_build_A_const_78; var tmp10 any; var root_2156 any = A_arbace_box_build_A_const_90.GetRawRoot__O(); var linked_2157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2156, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2158 lang.IFn

		if linked_2157 == nil { ifn_2158 = lang.IFn_Cast(root_2156) } else { ifn_2158 = nil }; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_86.GetRawRoot__O()); var tmp12 any = A_arbace_box_build_A_const_179; var arg_2159 any = tmp11.Invoke_O_O_O__O(tmp12, A_arbace_box_build_A_const_180.Invoke_O_O__O(opts__5, A_arbace_box_build_A_const_181), lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_131, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(index__7).Invoke_O__O(A_arbace_box_build_A_const_177.Invoke_O__O(p__4)), nil)).Ref())); if linked_2157 == nil { tmp10 = ifn_2158.Invoke_O__O(arg_2159) } else { tmp10 = linked_2157.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2156, arg_2159) }
//line :336:1
		var tmp13 any = tmp10; var tmp14 any = A_arbace_box_build_A_const_141; var tmp15 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_63, dtree__12); var tmp16 any; var root_2166 any = A_arbace_box_build_A_const_142.GetRawRoot__O(); var linked_2167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2166, A_arbace_box_build_file_tree_A_fn_class); var ifn_2168 lang.IFn




		if linked_2167 == nil { ifn_2168 = lang.IFn_Cast(root_2166) } else { ifn_2168 = nil }; var arg_2169 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_132, cfg__14)); if linked_2167 == nil { tmp16 = ifn_2168.Invoke_O__O(arg_2169) } else { tmp16 = linked_2167.(*A_arbace_box_build_file_tree_A).Invoke_O_O__O(root_2166, arg_2169) }
//line :336:1
		arg_2154 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, tmp13, tmp14, lang.Tuple_Create_O_O__IPersistentVector(tmp15, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp16)), A_arbace_box_build_A_const_84, Lit_133, A_arbace_box_build_A_const_182, Lit_133)); var arg_2155 any; var root_2170 any = A_arbace_box_build_A_const_161.GetRawRoot__O(); var linked_2171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2170, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2172 lang.IFn






		if linked_2171 == nil { ifn_2172 = lang.IFn_Cast(root_2170) } else { ifn_2172 = nil }; var arg_2173 any = lang.RT_Get_O_O__O_NoInit(A_arbace_box_build_A_const_126.Invoke_O__O(opts__5), A_arbace_box_build_A_const_178); var arg_2174 any = A_arbace_box_build_A_const_183; if linked_2171 == nil { arg_2155 = ifn_2172.Invoke_O_O__O(arg_2173, arg_2174) } else { arg_2155 = linked_2171.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2170, arg_2173, arg_2174) }
//line :336:1
		if linked_2152 == nil { arg_2150 = ifn_2153.Invoke_O_O__O(arg_2154, arg_2155) } else { arg_2150 = linked_2152.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_2151, arg_2154, arg_2155) }
//line :335:1
		if linked_2147 == nil { res__15 = ifn_2148.Invoke_O_O__O(arg_2149, arg_2150) } else { res__15 = linked_2147.(*A_arbace_box_build_action_STAR__A).Invoke_O_O_O__O(root_2146, arg_2149, arg_2150)
		}







		var root_2175 any = A_arbace_box_build_A_const_147.GetRawRoot__O(); var linked_2176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2175, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2177 lang.IFn; if linked_2176 == nil { ifn_2177 = lang.IFn_Cast(root_2175) } else { ifn_2177 = nil }; var arg_2178 any; var root_2179 any = A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_2180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2179, A_arbace_box_build_out_file_A_fn_class); var ifn_2181 lang.IFn; if linked_2180 == nil { ifn_2181 = lang.IFn_Cast(root_2179) } else { ifn_2181 = nil }; var arg_2182 any = res__15; var arg_2183 any = A_arbace_box_build_A_const_177.Invoke_O__O(p__4); var arg_2184 any = Lit_134; if linked_2180 == nil { arg_2178 = ifn_2181.Invoke_O_O_O__O(arg_2182, arg_2183, arg_2184) } else { arg_2178 = linked_2180.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_2179, arg_2182, arg_2183, arg_2184) }; if linked_2176 == nil { tmp2 = ifn_2177.Invoke_O__O(arg_2178) } else { tmp2 = linked_2176.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2175, arg_2178) } }; return nil }(); var root_2185 any = /*line :322:1*/A_arbace_box_build_A_const_80.GetRawRoot__O(); var linked_2186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2185, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2187 lang.IFn; if








	linked_2186 == nil { ifn_2187 = lang.IFn_Cast(root_2185) } else { ifn_2187 = nil }; if linked_2186 == nil { ifn_2187.Invoke__O() } else { linked_2186.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2185) }; if /*line :322:1*/ tmp17 != nil { panic(tmp17) }; return tmp2 }







func A_arbace_box_build_link_fn__598000285_A_New() *A_arbace_box_build_link_fn__598000285_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_fn__598000285_A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_box_build_link_fn__598000285_A) Ctor() {}
//line :330:1
func (t *A_arbace_box_build_link_fn__598000285_A) Invoke_O_O_O__O(self, i__1, q__2 any) any { return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_91.Invoke_O__O(q__2), i__1) }



func A_arbace_box_build_link_iter__598000290__598000294_A_New() *A_arbace_box_build_link_iter__598000290__598000294_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_iter__598000290__598000294_A{}; t.Ctor(); return t }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_A) Ctor() {}
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_A) Invoke_O_O__O(self, s__598000291__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2143 any = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_New_O_O(self, s__598000291__1); var tmp2 *jrt.Class; var fncls__2142 *jrt.Class = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_fn_class; if fncls__2142 == nil { var fncls__2142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_135, false, fnbody__2143); A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_fn_class = fncls__2142d; tmp2 = fncls__2142d } else { tmp2 = fncls__2142 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2143, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :334:1
func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_New_O_O(p0, p1 any) *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A{}; t.Ctor_O_O(p0, p1); return t }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A) Ctor_O_O(c__iter__598000290, c__s__598000291 any) { t.F_iter__598000290 = c__iter__598000290; t.F_s__598000291 = c__s__598000291 }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A) Invoke_O__O(self any) any { { var s__598000291__1 any; var t_ any = t.F_s__598000291; t.F_s__598000291 = nil; s__598000291__1 = t_; for { var temp__1927000414__auto____2 any; var root_2084 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_2085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2084, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2086 lang.IFn; if linked_2085 == nil { ifn_2086 = lang.IFn_Cast(root_2084) } else { ifn_2086 = nil }; var arg_2087 any = s__598000291__1; if linked_2085 == nil { temp__1927000414__auto____2 = ifn_2086.Invoke_O__O(arg_2087) } else { temp__1927000414__auto____2 = linked_2085.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2084, arg_2087) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000291__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2088 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_2089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2088, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2090 lang.IFn; if linked_2089 == nil { ifn_2090 = lang.IFn_Cast(root_2088) } else { ifn_2090 = nil }; var arg_2091 any = s__598000291__3; if linked_2089 == nil { tmp1 = ifn_2090.Invoke_O__O(arg_2091) } else { tmp1 = linked_2089.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2088, arg_2091) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2092 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_2093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2092, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2094 lang.IFn; if linked_2093 == nil { ifn_2094 = lang.IFn_Cast(root_2092) } else { ifn_2094 = nil }; var arg_2095 any = s__598000291__3; if linked_2093 == nil { c__1927001037__auto____4 = ifn_2094.Invoke_O__O(arg_2095) } else { c__1927001037__auto____4 = linked_2093.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2092, arg_2095) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000293__6 any; var root_2096 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_2097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2096, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2098 lang.IFn; if linked_2097 == nil { ifn_2098 = lang.IFn_Cast(root_2096) } else { ifn_2098 = nil }; var arg_2099 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2097 == nil { b__598000293__6 = ifn_2098.Invoke_O__O(arg_2099) } else { b__598000293__6 = linked_2097.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2096, arg_2099) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2106 any = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_New_O_I_O(b__598000293__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2105 *jrt.Class = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_fn_class; if fncls__2105 == nil { var fncls__2105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_136, false, fnbody__2106); A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_fn_class = fncls__2105d; tmp3 = fncls__2105d } else { tmp3 = fncls__2105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2106, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2107 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_2108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2107, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2109 lang.IFn; if linked_2108 == nil { ifn_2109 = lang.IFn_Cast(root_2107) } else { ifn_2109 = nil }; var arg_2110 any; var root_2112 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_2113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2112, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2114 lang.IFn; if linked_2113 == nil { ifn_2114 = lang.IFn_Cast(root_2112) } else { ifn_2114 = nil }; var arg_2115 any = b__598000293__6; if linked_2113 == nil { arg_2110 = ifn_2114.Invoke_O__O(arg_2115) } else { arg_2110 = linked_2113.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2112, arg_2115) }; var arg_2111 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000290); var tmp5 any; var root_2116 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_2117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2116, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2118 lang.IFn; if linked_2117 == nil { ifn_2118 = lang.IFn_Cast(root_2116) } else { ifn_2118 = nil }; var arg_2119 any = s__598000291__3; if linked_2117 == nil { tmp5 = ifn_2118.Invoke_O__O(arg_2119) } else { tmp5 = linked_2117.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2116, arg_2119) }; arg_2111 = tmp4.Invoke_O__O(tmp5); if linked_2108 == nil { return ifn_2109.Invoke_O_O__O(arg_2110, arg_2111) } else { return linked_2108.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2107, arg_2110, arg_2111) } } else { var root_2120 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_2121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2120, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2122 lang.IFn; if linked_2121 == nil { ifn_2122 = lang.IFn_Cast(root_2120) } else { ifn_2122 = nil }; var arg_2123 any; var root_2125 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_2126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2125, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2127 lang.IFn; if linked_2126 == nil { ifn_2127 = lang.IFn_Cast(root_2125) } else { ifn_2127 = nil }; var arg_2128 any = b__598000293__6; if linked_2126 == nil { arg_2123 = ifn_2127.Invoke_O__O(arg_2128) } else { arg_2123 = linked_2126.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2125, arg_2128) }; var arg_2124 any; if linked_2121 == nil { return ifn_2122.Invoke_O_O__O(arg_2123, arg_2124) } else { return linked_2121.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2120, arg_2123, arg_2124) } } } else { var l__4 any; var root_2129 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_2130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2129, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2131 lang.IFn; if linked_2130 == nil { ifn_2131 = lang.IFn_Cast(root_2129) } else { ifn_2131 = nil }; var arg_2132 any = s__598000291__3; if linked_2130 == nil { l__4 = ifn_2131.Invoke_O__O(arg_2132) } else { l__4 = linked_2130.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2129, arg_2132) }; var root_2133 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_2134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2133, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2135 lang.IFn; if linked_2134 == nil { ifn_2135 = lang.IFn_Cast(root_2133) } else { ifn_2135 = nil }; var arg_2136 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, l__4, nil)).Ref(); var arg_2137 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000290); var tmp7 any; var root_2138 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_2139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2138, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2140 lang.IFn; if linked_2139 == nil { ifn_2140 = lang.IFn_Cast(root_2138) } else { ifn_2140 = nil }; var arg_2141 any = s__598000291__3; if linked_2139 == nil { tmp7 = ifn_2140.Invoke_O__O(arg_2141) } else { tmp7 = linked_2139.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2138, arg_2141) }; arg_2137 = tmp6.Invoke_O__O(tmp7); if linked_2134 == nil { return ifn_2135.Invoke_O_O__O(arg_2136, arg_2137) } else { return linked_2134.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2133, arg_2136, arg_2137) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :334:1
func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A) Ctor_O_I_O(c__b__598000293 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000293 = c__b__598000293; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A) Invoke_O__O(self any) any { { var i__598000292__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000292__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000292__1)); var root_2100 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_2101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2100, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2102 lang.IFn; if linked_2101 == nil { ifn_2102 = lang.IFn_Cast(root_2100) } else { ifn_2102 = nil }; var arg_2103 any = t.F_b__598000293; var arg_2104 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, l__2, nil)).Ref(); if linked_2101 == nil { ifn_2102.Invoke_O_O__O(arg_2103, arg_2104) } else { linked_2101.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2100, arg_2103, arg_2104) }; i__598000292__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000292__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }











func A_arbace_box_build_build_A_New() *A_arbace_box_build_build_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_box_build_build_A) Ctor() {}
//line :346:1
func (t *A_arbace_box_build_build_A) Invoke_O_O_O__O(self, plan__0, opts__1 any) any { var p__3 any; var root_2197 any = A_arbace_box_build_A_const_169.GetRawRoot__O(); var linked_2198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2197, A_arbace_box_build_read_plan_A_fn_class); var ifn_2199 lang.IFn; if



	linked_2198 == nil { ifn_2199 = lang.IFn_Cast(root_2197) } else { ifn_2199 = nil }; var arg_2200 any = plan__0; if linked_2198 == nil { p__3 = ifn_2199.Invoke_O__O(arg_2200) } else { p__3 = linked_2198.(*A_arbace_box_build_read_plan_A).Invoke_O_O__O(root_2197, arg_2200) }; var t0__4 int64 = /*line :346:1*/jrt.System_NanoTime__J(); var as__5 any; var root_2201 any = A_arbace_box_build_A_const_184.GetRawRoot__O(); var linked_2202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2201, A_arbace_box_build_archives_A_fn_class); var ifn_2203 lang.IFn; if





	linked_2202 == nil { ifn_2203 = lang.IFn_Cast(root_2201) } else { ifn_2203 = nil }; var arg_2204 any = p__3; var arg_2205 any = opts__1; if linked_2202 == nil { as__5 = ifn_2203.Invoke_O_O__O(arg_2204, arg_2205) } else { as__5 = linked_2202.(*A_arbace_box_build_archives_A).Invoke_O_O_O__O(root_2201, arg_2204, arg_2205) }; var image__6 any; var root_2206 any = /*line :346:1*/A_arbace_box_build_A_const_185.GetRawRoot__O(); var linked_2207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2206, A_arbace_box_build_link_A_fn_class); var ifn_2208 lang.IFn; if






	linked_2207 == nil { ifn_2208 = lang.IFn_Cast(root_2206) } else { ifn_2208 = nil }; var arg_2209 any = p__3; var arg_2210 any = as__5; var arg_2211 any = opts__1; if linked_2207 == nil { image__6 = ifn_2208.Invoke_O_O_O__O(arg_2209, arg_2210, arg_2211) } else { image__6 = linked_2207.(*A_arbace_box_build_link_A).Invoke_O_O_O_O__O(root_2206, arg_2209, arg_2210, arg_2211) }; var temp__1927000414__auto____7 any = /*line :346:1*/A_arbace_box_build_A_const_186.Invoke_O__O(opts__1); if







	jrt.J2g_Truth(temp__1927000414__auto____7) { var r__8 any = temp__1927000414__auto____7; var root_2212 any = A_arbace_box_build_A_const_74.GetRawRoot__O(); var linked_2213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2212, aot_arbace_box.A_arbace_box_ref_BANG__A_fn_class); var ifn_2214 lang.IFn; if linked_2213 == nil { ifn_2214 = lang.IFn_Cast(root_2212) } else { ifn_2214 = nil }; var arg_2215 any = r__8; var arg_2216 any = image__6; if linked_2213 == nil { ifn_2214.Invoke_O_O__O(arg_2215, arg_2216) } else { linked_2213.(*aot_arbace_box.A_arbace_box_ref_BANG__A).Invoke_O_O_O__O(root_2212, arg_2215, arg_2216) } }; var root_2239 any =
	A_arbace_box_build_A_const_81.GetRawRoot__O(); var linked_2240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2239, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2241 lang.IFn; if linked_2240 == nil { ifn_2241 = lang.IFn_Cast(root_2239) } else { ifn_2241 = nil }; var arg_2242 any = lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, opts__1); if linked_2240 == nil { ifn_2241.Invoke_O__O(arg_2242) } else { linked_2240.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2239, arg_2242) }; var tmp1 *lang.Compiler_AOTFn; var fnbody__2238 any = A_arbace_box_build_build_fn__598000301_A_New_O_O_J(p__3, image__6, t0__4); var tmp2 *jrt.Class; var fncls__2237 *jrt.Class = A_arbace_box_build_build_fn__598000301_A_fn_class; if fncls__2237 == nil { var fncls__2237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__2238); A_arbace_box_build_build_fn__598000301_A_fn_class = fncls__2237d; tmp2 = fncls__2237d } else { tmp2 = fncls__2237 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2238, tmp2, nil); Up_Compiler_AOTFn_IFn(tmp1).Invoke__O(); return image__6 }
//line :346:1
func (t *A_arbace_box_build_build_A) Invoke_O_O__O(self, plan__0 any) any {

	var root_2248 any = A_arbace_box_build_A_const_187.GetRawRoot__O(); var linked_2249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2248, A_arbace_box_build_build_A_fn_class); var ifn_2250 lang.IFn; if linked_2249 == nil { ifn_2250 = lang.IFn_Cast(root_2248) } else { ifn_2250 = nil }; var arg_2251 any = plan__0; var arg_2252 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2249 == nil { return ifn_2250.Invoke_O_O__O(arg_2251, arg_2252) } else { return linked_2249.(*A_arbace_box_build_build_A).Invoke_O_O_O__O(root_2248, arg_2251, arg_2252)
	}
}




func A_arbace_box_build_build_fn__598000301_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_box_build_build_fn__598000301_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_fn__598000301_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :355:1
func (t *A_arbace_box_build_build_fn__598000301_A) Ctor_O_O_J(c__p, c__image any, c__t0 int64) { t.F_p = c__p; t.F_image = c__image; t.F_t0 = c__t0 }
//line :355:1
func (t *A_arbace_box_build_build_fn__598000301_A) Invoke_O__O(self any) any { var tmp1 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_76.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_77.GetRawRoot__O()); var tmp4 any = A_arbace_box_build_A_const_177.Invoke_O__O(t.F_p); var tmp5 *lang.Keyword = A_arbace_box_build_A_const_41; var tmp6 any; var t_ any = t.F_p; t.F_p = nil; tmp6 = t_; var tmp7 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp5.Invoke_O__O(tmp6))).Ref(); var tmp8 any = t.F_image; var tmp9 any; var root_2230 any = A_arbace_box_build_A_const_62.GetRawRoot__O(); var linked_2231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2230, aot_arbace_box.A_arbace_box_size_A_fn_class); var ifn_2232 lang.IFn; if linked_2231 == nil { ifn_2232 = lang.IFn_Cast(root_2230) } else { ifn_2232 = nil }; var arg_2233 any; var t__2 any = t.F_image; t.F_image = nil; arg_2233 = t__2; if linked_2231 == nil { tmp9 = ifn_2232.Invoke_O__O(arg_2233) } else { tmp9 = linked_2231.(*aot_arbace_box.A_arbace_box_size_A).Invoke_O_O__O(root_2230, arg_2233) }; tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O_O_O_O_O_O__O(Lit_44, tmp4, tmp7, tmp8, tmp9, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t.F_t0), 1.0e9)).Ref())) }
//line :355:1
	return nil }(); var root_2234 any = A_arbace_box_build_A_const_80.GetRawRoot__O(); var linked_2235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2234, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2236 lang.IFn; if linked_2235 == nil { ifn_2236 = lang.IFn_Cast(root_2234) } else { ifn_2236 = nil }; if linked_2235 == nil { ifn_2236.Invoke__O() } else { linked_2235.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2234) }; if tmp10 != nil { panic(tmp10) }; return tmp1 }




























































































































































































































































type A_arbace_box_build_A struct{ jrt.Object }

var A_arbace_box_build_A_const_pool *jrt.RefArray

var A_arbace_box_build_A_const_0 *lang.Var

var A_arbace_box_build_A_const_1 any

var A_arbace_box_build_A_const_2 *lang.Var

var A_arbace_box_build_A_const_3 any

var A_arbace_box_build_A_const_4 any

var A_arbace_box_build_A_const_5 any

var A_arbace_box_build_A_const_6 *lang.Var

var A_arbace_box_build_A_const_7 *lang.Var

var A_arbace_box_build_A_const_8 *lang.Var

var A_arbace_box_build_A_const_9 *lang.Var

var A_arbace_box_build_A_const_10 any

var A_arbace_box_build_A_const_11 *lang.Var

var A_arbace_box_build_A_const_12 *lang.Var

var A_arbace_box_build_A_const_13 *lang.Keyword

var A_arbace_box_build_A_const_14 *lang.Var

var A_arbace_box_build_A_const_15 *lang.Var

var A_arbace_box_build_A_const_16 *lang.Var

var A_arbace_box_build_A_const_17 *lang.Var

var A_arbace_box_build_A_const_18 *lang.Var

var A_arbace_box_build_A_const_19 *lang.Var

var A_arbace_box_build_A_const_20 *lang.Var

var A_arbace_box_build_A_const_21 *lang.Var

var A_arbace_box_build_A_const_22 *lang.Var

var A_arbace_box_build_A_const_23 *lang.Var

var A_arbace_box_build_A_const_24 *lang.Var

var A_arbace_box_build_A_const_25 *lang.Keyword

var A_arbace_box_build_A_const_26 *lang.Var

var A_arbace_box_build_A_const_27 *lang.Var

var A_arbace_box_build_A_const_28 *lang.Var

var A_arbace_box_build_A_const_29 *lang.Var

var A_arbace_box_build_A_const_30 *lang.Var

var A_arbace_box_build_A_const_31 *lang.Var

var A_arbace_box_build_A_const_32 *lang.Var

var A_arbace_box_build_A_const_33 *lang.Var

var A_arbace_box_build_A_const_34 *lang.Var

var A_arbace_box_build_A_const_35 *lang.Var

var A_arbace_box_build_A_const_36 *lang.Var

var A_arbace_box_build_A_const_37 *lang.Var

var A_arbace_box_build_A_const_38 *lang.Var

var A_arbace_box_build_A_const_39 *lang.Keyword

var A_arbace_box_build_A_const_40 *lang.Var

var A_arbace_box_build_A_const_41 *lang.Keyword

var A_arbace_box_build_A_const_42 *lang.Var

var A_arbace_box_build_A_const_43 *lang.Var

var A_arbace_box_build_A_const_44 *lang.Keyword

var A_arbace_box_build_A_const_45 *lang.Var

var A_arbace_box_build_A_const_46 *lang.Var

var A_arbace_box_build_A_const_47 *lang.Var

var A_arbace_box_build_A_const_48 *lang.Keyword

var A_arbace_box_build_A_const_49 *lang.Var

var A_arbace_box_build_A_const_50 *lang.Var

var A_arbace_box_build_A_const_51 *lang.Var

var A_arbace_box_build_A_const_52 *lang.Var

var A_arbace_box_build_A_const_53 *lang.Var

var A_arbace_box_build_A_const_54 *lang.Var

var A_arbace_box_build_A_const_55 *lang.Keyword

var A_arbace_box_build_A_const_56 *lang.Keyword

var A_arbace_box_build_A_const_57 any

var A_arbace_box_build_A_const_58 any

var A_arbace_box_build_A_const_59 *lang.Var

var A_arbace_box_build_A_const_60 *lang.Keyword

var A_arbace_box_build_A_const_61 *lang.Var

var A_arbace_box_build_A_const_62 *lang.Var

var A_arbace_box_build_A_const_63 *lang.Var

var A_arbace_box_build_A_const_64 *lang.Keyword

var A_arbace_box_build_A_const_65 *lang.Var

var A_arbace_box_build_A_const_66 *lang.Keyword

var A_arbace_box_build_A_const_67 *lang.Var

var A_arbace_box_build_A_const_68 *lang.Keyword

var A_arbace_box_build_A_const_69 *lang.Var

var A_arbace_box_build_A_const_70 *lang.Keyword

var A_arbace_box_build_A_const_71 *lang.Keyword

var A_arbace_box_build_A_const_72 *lang.Keyword

var A_arbace_box_build_A_const_73 *lang.Var

var A_arbace_box_build_A_const_74 *lang.Var

var A_arbace_box_build_A_const_75 *lang.Keyword

var A_arbace_box_build_A_const_76 *lang.Var

var A_arbace_box_build_A_const_77 *lang.Var

var A_arbace_box_build_A_const_78 *lang.Keyword

var A_arbace_box_build_A_const_79 *lang.Var

var A_arbace_box_build_A_const_80 *lang.Var

var A_arbace_box_build_A_const_81 *lang.Var

var A_arbace_box_build_A_const_82 *lang.Var

var A_arbace_box_build_A_const_83 *lang.Var

var A_arbace_box_build_A_const_84 *lang.Keyword

var A_arbace_box_build_A_const_85 *lang.Keyword

var A_arbace_box_build_A_const_86 *lang.Var

var A_arbace_box_build_A_const_87 *lang.Keyword

var A_arbace_box_build_A_const_88 any

var A_arbace_box_build_A_const_89 *lang.Keyword

var A_arbace_box_build_A_const_90 *lang.Var

var A_arbace_box_build_A_const_91 *lang.Keyword

var A_arbace_box_build_A_const_92 *lang.Var

var A_arbace_box_build_A_const_93 *lang.Keyword

var A_arbace_box_build_A_const_94 any

var A_arbace_box_build_A_const_95 *lang.Var

var A_arbace_box_build_A_const_96 *lang.Var

var A_arbace_box_build_A_const_97 any

var A_arbace_box_build_A_const_98 any

var A_arbace_box_build_A_const_99 any

var A_arbace_box_build_A_const_100 any

var A_arbace_box_build_A_const_101 any

var A_arbace_box_build_A_const_102 any

var A_arbace_box_build_A_const_103 *lang.Var

var A_arbace_box_build_A_const_104 *lang.Var

var A_arbace_box_build_A_const_105 *lang.Var

var A_arbace_box_build_A_const_106 *lang.Keyword

var A_arbace_box_build_A_const_107 *lang.Var

var A_arbace_box_build_A_const_108 *lang.Var

var A_arbace_box_build_A_const_109 any

var A_arbace_box_build_A_const_110 any

var A_arbace_box_build_A_const_111 *lang.Keyword

var A_arbace_box_build_A_const_112 *lang.Var

var A_arbace_box_build_A_const_113 *lang.Var

var A_arbace_box_build_A_const_114 *lang.Var

var A_arbace_box_build_A_const_115 *lang.Var

var A_arbace_box_build_A_const_116 *lang.Var

var A_arbace_box_build_A_const_117 *lang.Var

var A_arbace_box_build_A_const_118 *lang.Var

var A_arbace_box_build_A_const_119 *lang.Var

var A_arbace_box_build_A_const_120 *lang.Keyword

var A_arbace_box_build_A_const_121 *lang.Keyword

var A_arbace_box_build_A_const_122 *lang.Var

var A_arbace_box_build_A_const_123 *lang.Keyword

var A_arbace_box_build_A_const_124 *lang.Var

var A_arbace_box_build_A_const_125 any

var A_arbace_box_build_A_const_126 *lang.Keyword

var A_arbace_box_build_A_const_127 *lang.Var

var A_arbace_box_build_A_const_128 *lang.Var

var A_arbace_box_build_A_const_129 *lang.Var

var A_arbace_box_build_A_const_130 *lang.Var

var A_arbace_box_build_A_const_131 *lang.Var

var A_arbace_box_build_A_const_132 *lang.Var

var A_arbace_box_build_A_const_133 *lang.Keyword

var A_arbace_box_build_A_const_134 *lang.Keyword

var A_arbace_box_build_A_const_135 *lang.Keyword

var A_arbace_box_build_A_const_136 *lang.Var

var A_arbace_box_build_A_const_137 *lang.Var

var A_arbace_box_build_A_const_138 *lang.Keyword

var A_arbace_box_build_A_const_139 *lang.Keyword

var A_arbace_box_build_A_const_140 *lang.Var

var A_arbace_box_build_A_const_141 *lang.Keyword

var A_arbace_box_build_A_const_142 *lang.Var

var A_arbace_box_build_A_const_143 any

var A_arbace_box_build_A_const_144 *lang.Var

var A_arbace_box_build_A_const_145 *lang.Var

var A_arbace_box_build_A_const_146 *lang.Var

var A_arbace_box_build_A_const_147 *lang.Var

var A_arbace_box_build_A_const_148 *lang.Var

var A_arbace_box_build_A_const_149 *lang.Keyword

var A_arbace_box_build_A_const_150 *lang.Keyword

var A_arbace_box_build_A_const_151 *lang.Keyword

var A_arbace_box_build_A_const_152 any

var A_arbace_box_build_A_const_153 *lang.Var

var A_arbace_box_build_A_const_154 any

var A_arbace_box_build_A_const_155 any

var A_arbace_box_build_A_const_156 any

var A_arbace_box_build_A_const_157 any

var A_arbace_box_build_A_const_158 any

var A_arbace_box_build_A_const_159 any

var A_arbace_box_build_A_const_160 *lang.Keyword

var A_arbace_box_build_A_const_161 *lang.Var

var A_arbace_box_build_A_const_162 any

var A_arbace_box_build_A_const_163 *lang.Var

var A_arbace_box_build_A_const_164 any

var A_arbace_box_build_A_const_165 *lang.Var

var A_arbace_box_build_A_const_166 *lang.Keyword

var A_arbace_box_build_A_const_167 *lang.Var

var A_arbace_box_build_A_const_168 any

var A_arbace_box_build_A_const_169 *lang.Var

var A_arbace_box_build_A_const_170 *lang.Var

var A_arbace_box_build_A_const_171 *lang.Var

var A_arbace_box_build_A_const_172 *lang.Keyword

var A_arbace_box_build_A_const_173 *lang.Keyword

var A_arbace_box_build_A_const_174 *lang.Keyword

var A_arbace_box_build_A_const_175 any

var A_arbace_box_build_A_const_176 *lang.Var

var A_arbace_box_build_A_const_177 *lang.Keyword

var A_arbace_box_build_A_const_178 *lang.Keyword

var A_arbace_box_build_A_const_179 any

var A_arbace_box_build_A_const_180 *lang.Keyword

var A_arbace_box_build_A_const_181 any

var A_arbace_box_build_A_const_182 *lang.Keyword

var A_arbace_box_build_A_const_183 any

var A_arbace_box_build_A_const_184 *lang.Var

var A_arbace_box_build_A_const_185 *lang.Var

var A_arbace_box_build_A_const_186 *lang.Keyword

var A_arbace_box_build_A_const_187 *lang.Var

var A_arbace_box_build_A_init jrt.ClassInit

func A_arbace_box_build_A_Init() { if !A_arbace_box_build_A_init.Done() { A_arbace_box_build_A_init.Run(A_arbace_box_build_A_clinit) } }

func A_arbace_box_build_A_clinit() { A_arbace_box_build_A_clinit_p0(); A_arbace_box_build_A_clinit_p1(); A_arbace_box_build_A_clinit_p2(); A_arbace_box_build_A_clinit_p3(); A_arbace_box_build_A_clinit_p4(); A_arbace_box_build_A_clinit_p5(); A_arbace_box_build_A_clinit_p6(); A_arbace_box_build_A_clinit_p7(); A_arbace_box_build_A_clinit_p8(); A_arbace_box_build_A_clinit_p9(); A_arbace_box_build_A_clinit_p10(); A_arbace_box_build_A_clinit_p11(); A_arbace_box_build_A_clinit_p12(); A_arbace_box_build_A_clinit_p13(); A_arbace_box_build_A_clinit_p14(); A_arbace_box_build_A_clinit_p15() }

func A_arbace_box_build_A_clinit_p0() { jrt.StartCheck(); A_arbace_box_build_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 245); A_arbace_box_build_A_const_0 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[57]); A_arbace_box_build_A_const_1 = A_arbace_box_build_A_const_pool.A[58]; A_arbace_box_build_A_const_2 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[59]); A_arbace_box_build_A_const_3 = A_arbace_box_build_A_const_pool.A[60]; A_arbace_box_build_A_const_4 = A_arbace_box_build_A_const_pool.A[61]; A_arbace_box_build_A_const_5 = A_arbace_box_build_A_const_pool.A[62]; A_arbace_box_build_A_const_6 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[63]); A_arbace_box_build_A_const_7 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[64]); A_arbace_box_build_A_const_8 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[65]); A_arbace_box_build_A_const_9 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[66]); A_arbace_box_build_A_const_10 = A_arbace_box_build_A_const_pool.A[67]; A_arbace_box_build_A_const_11 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[68]) }

func A_arbace_box_build_A_clinit_p1() { A_arbace_box_build_A_const_12 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[69]); A_arbace_box_build_A_const_13 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[70]); A_arbace_box_build_A_const_14 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[71]); A_arbace_box_build_A_const_15 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[72]); A_arbace_box_build_A_const_16 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[73]); A_arbace_box_build_A_const_17 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[74]); A_arbace_box_build_A_const_18 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[75]); A_arbace_box_build_A_const_19 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[76]); A_arbace_box_build_A_const_20 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[77]); A_arbace_box_build_A_const_21 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[78]); A_arbace_box_build_A_const_22 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[79]); A_arbace_box_build_A_const_23 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[80]) }

func A_arbace_box_build_A_clinit_p2() { A_arbace_box_build_A_const_24 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[81]); A_arbace_box_build_A_const_25 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[82]); A_arbace_box_build_A_const_26 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[83]); A_arbace_box_build_A_const_27 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[84]); A_arbace_box_build_A_const_28 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[85]); A_arbace_box_build_A_const_29 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[86]); A_arbace_box_build_A_const_30 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[87]); A_arbace_box_build_A_const_31 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[88]); A_arbace_box_build_A_const_32 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[89]); A_arbace_box_build_A_const_33 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[90]); A_arbace_box_build_A_const_34 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[91]); A_arbace_box_build_A_const_35 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[92]) }

func A_arbace_box_build_A_clinit_p3() { A_arbace_box_build_A_const_36 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[93]); A_arbace_box_build_A_const_37 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[94]); A_arbace_box_build_A_const_38 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[95]); A_arbace_box_build_A_const_39 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[96]); A_arbace_box_build_A_const_40 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[97]); A_arbace_box_build_A_const_41 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[98]); A_arbace_box_build_A_const_42 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[99]); A_arbace_box_build_A_const_43 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[100]); A_arbace_box_build_A_const_44 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[101]); A_arbace_box_build_A_const_45 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[102]); A_arbace_box_build_A_const_46 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[103]); A_arbace_box_build_A_const_47 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[104]) }

func A_arbace_box_build_A_clinit_p4() { A_arbace_box_build_A_const_48 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[105]); A_arbace_box_build_A_const_49 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[106]); A_arbace_box_build_A_const_50 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[107]); A_arbace_box_build_A_const_51 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[108]); A_arbace_box_build_A_const_52 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[109]); A_arbace_box_build_A_const_53 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[110]); A_arbace_box_build_A_const_54 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[111]); A_arbace_box_build_A_const_55 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[112]); A_arbace_box_build_A_const_56 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[113]); A_arbace_box_build_A_const_57 = A_arbace_box_build_A_const_pool.A[114]; A_arbace_box_build_A_const_58 = A_arbace_box_build_A_const_pool.A[115]; A_arbace_box_build_A_const_59 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[116]) }

func A_arbace_box_build_A_clinit_p5() { A_arbace_box_build_A_const_60 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[117]); A_arbace_box_build_A_const_61 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[118]); A_arbace_box_build_A_const_62 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[119]); A_arbace_box_build_A_const_63 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[120]); A_arbace_box_build_A_const_64 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[121]); A_arbace_box_build_A_const_65 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[122]); A_arbace_box_build_A_const_66 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[123]); A_arbace_box_build_A_const_67 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[124]); A_arbace_box_build_A_const_68 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[125]); A_arbace_box_build_A_const_69 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[126]); A_arbace_box_build_A_const_70 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[127]); A_arbace_box_build_A_const_71 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[128]) }

func A_arbace_box_build_A_clinit_p6() { A_arbace_box_build_A_const_72 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[129]); A_arbace_box_build_A_const_73 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[130]); A_arbace_box_build_A_const_74 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[131]); A_arbace_box_build_A_const_75 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[132]); A_arbace_box_build_A_const_76 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[133]); A_arbace_box_build_A_const_77 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[134]); A_arbace_box_build_A_const_78 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[135]); A_arbace_box_build_A_const_79 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[136]); A_arbace_box_build_A_const_80 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[137]); A_arbace_box_build_A_const_81 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[138]); A_arbace_box_build_A_const_82 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[139]); A_arbace_box_build_A_const_83 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[140]) }

func A_arbace_box_build_A_clinit_p7() { A_arbace_box_build_A_const_84 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[141]); A_arbace_box_build_A_const_85 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[142]); A_arbace_box_build_A_const_86 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[143]); A_arbace_box_build_A_const_87 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[144]); A_arbace_box_build_A_const_88 = A_arbace_box_build_A_const_pool.A[145]; A_arbace_box_build_A_const_89 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[146]); A_arbace_box_build_A_const_90 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[147]); A_arbace_box_build_A_const_91 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[148]); A_arbace_box_build_A_const_92 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[149]); A_arbace_box_build_A_const_93 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[150]); A_arbace_box_build_A_const_94 = A_arbace_box_build_A_const_pool.A[151]; A_arbace_box_build_A_const_95 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[152]) }

func A_arbace_box_build_A_clinit_p8() { A_arbace_box_build_A_const_96 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[153]); A_arbace_box_build_A_const_97 = A_arbace_box_build_A_const_pool.A[154]; A_arbace_box_build_A_const_98 = A_arbace_box_build_A_const_pool.A[155]; A_arbace_box_build_A_const_99 = A_arbace_box_build_A_const_pool.A[156]; A_arbace_box_build_A_const_100 = A_arbace_box_build_A_const_pool.A[157]; A_arbace_box_build_A_const_101 = A_arbace_box_build_A_const_pool.A[158]; A_arbace_box_build_A_const_102 = A_arbace_box_build_A_const_pool.A[159]; A_arbace_box_build_A_const_103 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[160]); A_arbace_box_build_A_const_104 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[161]); A_arbace_box_build_A_const_105 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[162]); A_arbace_box_build_A_const_106 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[163]); A_arbace_box_build_A_const_107 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[164]); A_arbace_box_build_A_const_108 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[165]) }

func A_arbace_box_build_A_clinit_p9() { A_arbace_box_build_A_const_109 = A_arbace_box_build_A_const_pool.A[166]; A_arbace_box_build_A_const_110 = A_arbace_box_build_A_const_pool.A[167]; A_arbace_box_build_A_const_111 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[168]); A_arbace_box_build_A_const_112 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[169]); A_arbace_box_build_A_const_113 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[170]); A_arbace_box_build_A_const_114 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[171]); A_arbace_box_build_A_const_115 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[172]); A_arbace_box_build_A_const_116 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[173]); A_arbace_box_build_A_const_117 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[174]); A_arbace_box_build_A_const_118 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[175]); A_arbace_box_build_A_const_119 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[176]); A_arbace_box_build_A_const_120 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[177]) }

func A_arbace_box_build_A_clinit_p10() { A_arbace_box_build_A_const_121 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[178]); A_arbace_box_build_A_const_122 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[179]); A_arbace_box_build_A_const_123 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[180]); A_arbace_box_build_A_const_124 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[181]); A_arbace_box_build_A_const_125 = A_arbace_box_build_A_const_pool.A[182]; A_arbace_box_build_A_const_126 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[183]); A_arbace_box_build_A_const_127 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[184]); A_arbace_box_build_A_const_128 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[185]); A_arbace_box_build_A_const_129 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[186]); A_arbace_box_build_A_const_130 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[187]); A_arbace_box_build_A_const_131 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[188]); A_arbace_box_build_A_const_132 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[189]) }

func A_arbace_box_build_A_clinit_p11() { A_arbace_box_build_A_const_133 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[190]); A_arbace_box_build_A_const_134 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[191]); A_arbace_box_build_A_const_135 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[192]); A_arbace_box_build_A_const_136 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[193]); A_arbace_box_build_A_const_137 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[194]); A_arbace_box_build_A_const_138 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[195]); A_arbace_box_build_A_const_139 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[196]); A_arbace_box_build_A_const_140 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[197]); A_arbace_box_build_A_const_141 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[198]); A_arbace_box_build_A_const_142 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[199]); A_arbace_box_build_A_const_143 = A_arbace_box_build_A_const_pool.A[200]; A_arbace_box_build_A_const_144 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[201]) }

func A_arbace_box_build_A_clinit_p12() { A_arbace_box_build_A_const_145 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[202]); A_arbace_box_build_A_const_146 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[203]); A_arbace_box_build_A_const_147 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[204]); A_arbace_box_build_A_const_148 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[205]); A_arbace_box_build_A_const_149 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[206]); A_arbace_box_build_A_const_150 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[207]); A_arbace_box_build_A_const_151 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[208]); A_arbace_box_build_A_const_152 = A_arbace_box_build_A_const_pool.A[209]; A_arbace_box_build_A_const_153 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[210]); A_arbace_box_build_A_const_154 = A_arbace_box_build_A_const_pool.A[211]; A_arbace_box_build_A_const_155 = A_arbace_box_build_A_const_pool.A[212]; A_arbace_box_build_A_const_156 = A_arbace_box_build_A_const_pool.A[213]; A_arbace_box_build_A_const_157 = A_arbace_box_build_A_const_pool.A[214] }

func A_arbace_box_build_A_clinit_p13() { A_arbace_box_build_A_const_158 = A_arbace_box_build_A_const_pool.A[215]; A_arbace_box_build_A_const_159 = A_arbace_box_build_A_const_pool.A[216]; A_arbace_box_build_A_const_160 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[217]); A_arbace_box_build_A_const_161 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[218]); A_arbace_box_build_A_const_162 = A_arbace_box_build_A_const_pool.A[219]; A_arbace_box_build_A_const_163 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[220]); A_arbace_box_build_A_const_164 = A_arbace_box_build_A_const_pool.A[221]; A_arbace_box_build_A_const_165 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[222]); A_arbace_box_build_A_const_166 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[223]); A_arbace_box_build_A_const_167 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[224]); A_arbace_box_build_A_const_168 = A_arbace_box_build_A_const_pool.A[225]; A_arbace_box_build_A_const_169 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[226]); A_arbace_box_build_A_const_170 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[227]) }

func A_arbace_box_build_A_clinit_p14() { A_arbace_box_build_A_const_171 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[228]); A_arbace_box_build_A_const_172 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[229]); A_arbace_box_build_A_const_173 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[230]); A_arbace_box_build_A_const_174 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[231]); A_arbace_box_build_A_const_175 = A_arbace_box_build_A_const_pool.A[232]; A_arbace_box_build_A_const_176 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[233]); A_arbace_box_build_A_const_177 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[234]); A_arbace_box_build_A_const_178 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[235]); A_arbace_box_build_A_const_179 = A_arbace_box_build_A_const_pool.A[236]; A_arbace_box_build_A_const_180 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[237]); A_arbace_box_build_A_const_181 = A_arbace_box_build_A_const_pool.A[238]; A_arbace_box_build_A_const_182 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[239]); A_arbace_box_build_A_const_183 = A_arbace_box_build_A_const_pool.A[240] }

func A_arbace_box_build_A_clinit_p15() { A_arbace_box_build_A_const_184 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[241]); A_arbace_box_build_A_const_185 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[242]); A_arbace_box_build_A_const_186 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[243]); A_arbace_box_build_A_const_187 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[244]) }

func A_arbace_box_build_A_New() *A_arbace_box_build_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_A{}; t.Ctor(); return t }

func (t *A_arbace_box_build_A) Ctor() {}

func (t *A_arbace_box_build_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_A_class }

func (t *A_arbace_box_build_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_build_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_A); return ok }

func A_arbace_box_build_A_Cast(x any) *A_arbace_box_build_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_A_class)) }; return v }



type A_arbace_box_build_action_A struct{ j2g_header uint64 }

var A_arbace_box_build_action_A_fn_class *jrt.Class



type A_arbace_box_build_action_STAR__A struct{ j2g_header uint64 }

var A_arbace_box_build_action_STAR__A_fn_class *jrt.Class



type A_arbace_box_build_append_members_A struct{ j2g_header uint64 }

var A_arbace_box_build_append_members_A_fn_class *jrt.Class



type A_arbace_box_build_ar_member_A struct{ j2g_header uint64 }

var A_arbace_box_build_ar_member_A_fn_class *jrt.Class



type A_arbace_box_build_ar_member_pad__598000077_A struct{ j2g_header uint64 }

var A_arbace_box_build_ar_member_pad__598000077_A_fn_class *jrt.Class



type A_arbace_box_build_arch_defines_A struct{ j2g_header uint64 }

var A_arbace_box_build_arch_defines_A_fn_class *jrt.Class



type A_arbace_box_build_archives_A struct{ j2g_header uint64 }

var A_arbace_box_build_archives_A_fn_class *jrt.Class



type A_arbace_box_build_archives_conveyed__598000244_A struct{ j2g_header uint64; F_opts any }

var A_arbace_box_build_archives_conveyed__598000244_A_fn_class *jrt.Class



type A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A struct{ j2g_header uint64; F_f, F_o any }

var A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000242_A struct{ j2g_header uint64 }

var A_arbace_box_build_archives_fn__598000242_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000252_A struct{ j2g_header uint64; F_given, F_q any }

var A_arbace_box_build_archives_fn__598000252_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000254_A struct{ j2g_header uint64; F_index, F_p, F_deps, F_sem, F_conveyed, F_q any }

var A_arbace_box_build_archives_fn__598000254_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000254_fn__598000255_A struct{ j2g_header uint64; F_index, F_p, F_deps, F_sem, F_q any }

var A_arbace_box_build_archives_fn__598000254_fn__598000255_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A struct{ j2g_header uint64 }

var A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000260_A struct{ j2g_header uint64; F_given, F_q any }

var A_arbace_box_build_archives_fn__598000260_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000262_A struct{ j2g_header uint64; F_index, F_p, F_deps, F_sem, F_conveyed, F_q any }

var A_arbace_box_build_archives_fn__598000262_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000262_fn__598000263_A struct{ j2g_header uint64; F_index, F_p, F_deps, F_sem, F_q any }

var A_arbace_box_build_archives_fn__598000262_fn__598000263_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A struct{ j2g_header uint64 }

var A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_fn_class *jrt.Class



type A_arbace_box_build_archives_iter__598000268__598000272_A struct{ j2g_header uint64 }

var A_arbace_box_build_archives_iter__598000268__598000272_A_fn_class *jrt.Class



type A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A struct{ j2g_header uint64; F_iter__598000268, F_s__598000269 any }

var A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_fn_class *jrt.Class



type A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A struct{ j2g_header uint64; F_b__598000271 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_fn_class *jrt.Class



type A_arbace_box_build_asm_args_A struct{ j2g_header uint64 }

var A_arbace_box_build_asm_args_A_fn_class *jrt.Class



type A_arbace_box_build_asm_args_fn__598000074_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_box_build_asm_args_fn__598000074_A_fn_class *jrt.Class



type A_arbace_box_build_build_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_A_fn_class *jrt.Class



type A_arbace_box_build_build_fn__598000301_A struct{ j2g_header uint64; F_p, F_image any; F_t0 int64 }

var A_arbace_box_build_build_fn__598000301_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_fn__598000179_A struct{ j2g_header uint64; F_P any }

var A_arbace_box_build_build_package_fn__598000179_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_fn__598000184_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_fn__598000184_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_fn__598000186_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_fn__598000186_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000150__598000154_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_iter__598000150__598000154_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A struct{ j2g_header uint64; F_iter__598000150, F_s__598000151 any }

var A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A struct{ j2g_header uint64; F_b__598000153 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000166__598000170_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_iter__598000166__598000170_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A struct{ j2g_header uint64; F_s__598000167, F_iter__598000166 any }

var A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A struct{ j2g_header uint64; F_b__598000169 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_A struct{ j2g_header uint64; F_res_of, F_P, F_plan, F_ctree, F_pkg, F_tools any }

var A_arbace_box_build_build_package_iter__598000189__598000193_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A struct{ j2g_header uint64; F_res_of, F_P, F_plan, F_ctree, F_pkg, F_tools, F_s__598000190, F_iter__598000189 any }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A struct{ j2g_header uint64; F_b__598000192, F_res_of, F_P, F_plan, F_ctree, F_pkg, F_tools any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A struct{ j2g_header uint64; F_res_of, F_P, F_plan, F_ctree, F_pkg, F_o, F_s, F_tools any }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A struct{ j2g_header uint64; F_res_of, F_P, F_plan, F_o, F_ctree, F_pkg, F_s, F_tools any }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000203__598000207_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_iter__598000203__598000207_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A struct{ j2g_header uint64; F_iter__598000203, F_s__598000204 any }

var A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A struct{ j2g_header uint64; F_b__598000206 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_res_of__598000176_A struct{ j2g_header uint64; F_P any }

var A_arbace_box_build_build_package_res_of__598000176_A_fn_class *jrt.Class



type A_arbace_box_build_cache_ref_A struct{ j2g_header uint64 }

var A_arbace_box_build_cache_ref_A_fn_class *jrt.Class



type A_arbace_box_build_complete_QMARK__A struct{ j2g_header uint64 }

var A_arbace_box_build_complete_QMARK__A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_A struct{ j2g_header uint64 }

var A_arbace_box_build_deps_tree_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000092__598000096_A struct{ j2g_header uint64; F_archives, F_index any }

var A_arbace_box_build_deps_tree_iter__598000092__598000096_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A struct{ j2g_header uint64; F_archives, F_index, F_iter__598000092, F_s__598000093 any }

var A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A struct{ j2g_header uint64; F_b__598000095, F_archives, F_index any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000102__598000106_A struct{ j2g_header uint64; F_index any }

var A_arbace_box_build_deps_tree_iter__598000102__598000106_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A struct{ j2g_header uint64; F_s__598000103, F_index, F_iter__598000102 any }

var A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A struct{ j2g_header uint64; F_index, F_b__598000105 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_A struct{ j2g_header uint64 }

var A_arbace_box_build_embed_config_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000116__598000120_A struct{ j2g_header uint64 }

var A_arbace_box_build_embed_config_iter__598000116__598000120_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A struct{ j2g_header uint64; F_iter__598000116, F_s__598000117 any }

var A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A struct{ j2g_header uint64; F_b__598000119 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000132__598000136_A struct{ j2g_header uint64 }

var A_arbace_box_build_embed_config_iter__598000132__598000136_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A struct{ j2g_header uint64; F_s__598000133, F_iter__598000132 any }

var A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A struct{ j2g_header uint64; F_b__598000135 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_fn_class *jrt.Class



type A_arbace_box_build_eval598000004_A struct{ jrt.Object }

func A_arbace_box_build_eval598000004_A_New() *A_arbace_box_build_eval598000004_A { t := &A_arbace_box_build_eval598000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_build_eval598000004_A) Ctor() {}

func (t *A_arbace_box_build_eval598000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_eval598000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_eval598000004_A_class }

func (t *A_arbace_box_build_eval598000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_eval598000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_build_eval598000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_eval598000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_eval598000004_A); return ok }

func A_arbace_box_build_eval598000004_A_Cast(x any) *A_arbace_box_build_eval598000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_eval598000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_eval598000004_A_class)) }; return v }



type A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A struct{ j2g_header uint64 }

var A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_fn_class *jrt.Class



type A_arbace_box_build_eval598000008_A struct{ jrt.Object }

func A_arbace_box_build_eval598000008_A_New() *A_arbace_box_build_eval598000008_A { t := &A_arbace_box_build_eval598000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_build_eval598000008_A) Ctor() {}

func (t *A_arbace_box_build_eval598000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_eval598000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_eval598000008_A_class }

func (t *A_arbace_box_build_eval598000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_eval598000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_build_eval598000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_eval598000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_eval598000008_A); return ok }

func A_arbace_box_build_eval598000008_A_Cast(x any) *A_arbace_box_build_eval598000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_eval598000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_eval598000008_A_class)) }; return v }



type A_arbace_box_build_eval598000008_fn__598000009_A struct{ j2g_header uint64 }

var A_arbace_box_build_eval598000008_fn__598000009_A_fn_class *jrt.Class



type A_arbace_box_build_fail_A struct{ j2g_header uint64 }

var A_arbace_box_build_fail_A_fn_class *jrt.Class



type A_arbace_box_build_file_tree_A struct{ j2g_header uint64 }

var A_arbace_box_build_file_tree_A_fn_class *jrt.Class



type A_arbace_box_build_file_tree_iter__598000054__598000058_A struct{ j2g_header uint64 }

var A_arbace_box_build_file_tree_iter__598000054__598000058_A_fn_class *jrt.Class



type A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A struct{ j2g_header uint64; F_s__598000055, F_iter__598000054 any }

var A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_fn_class *jrt.Class



type A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A struct{ j2g_header uint64; F_b__598000057 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_fn_class *jrt.Class



type A_arbace_box_build_import_plan_A struct{ j2g_header uint64 }

var A_arbace_box_build_import_plan_A_fn_class *jrt.Class



type A_arbace_box_build_import_plan_fn__598000044_A struct{ j2g_header uint64; F_src any }

var A_arbace_box_build_import_plan_fn__598000044_A_fn_class *jrt.Class



type A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A struct{ j2g_header uint64; F_src any }

var A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_fn_class *jrt.Class



type A_arbace_box_build_import_plan_src__598000042_A struct{ j2g_header uint64; F_dirs any }

var A_arbace_box_build_import_plan_src__598000042_A_fn_class *jrt.Class



type A_arbace_box_build_json_str_A struct{ j2g_header uint64 }

var A_arbace_box_build_json_str_A_fn_class *jrt.Class



type A_arbace_box_build_json_str_fn__598000113_A struct{ j2g_header uint64 }

var A_arbace_box_build_json_str_fn__598000113_A_fn_class *jrt.Class



type A_arbace_box_build_link_A struct{ j2g_header uint64 }

var A_arbace_box_build_link_A_fn_class *jrt.Class



type A_arbace_box_build_link_fn__598000285_A struct{ j2g_header uint64 }

var A_arbace_box_build_link_fn__598000285_A_fn_class *jrt.Class



type A_arbace_box_build_link_iter__598000290__598000294_A struct{ j2g_header uint64 }

var A_arbace_box_build_link_iter__598000290__598000294_A_fn_class *jrt.Class



type A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A struct{ j2g_header uint64; F_iter__598000290, F_s__598000291 any }

var A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_fn_class *jrt.Class



type A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A struct{ j2g_header uint64; F_b__598000293 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_fn_class *jrt.Class



type A_arbace_box_build_log_A struct{ j2g_header uint64 }

var A_arbace_box_build_log_A_fn_class *jrt.Class



type A_arbace_box_build_out_file_A struct{ j2g_header uint64 }

var A_arbace_box_build_out_file_A_fn_class *jrt.Class



type A_arbace_box_build_read_plan_A struct{ j2g_header uint64 }

var A_arbace_box_build_read_plan_A_fn_class *jrt.Class



type A_arbace_box_build_sha256_hex_A struct{ j2g_header uint64 }

var A_arbace_box_build_sha256_hex_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_A struct{ j2g_header uint64 }

var A_arbace_box_build_source_tree_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_headers__598000018_A struct{ j2g_header uint64 }

var A_arbace_box_build_source_tree_headers__598000018_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A struct{ j2g_header uint64; F_headers any }

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A struct{ j2g_header uint64; F_iter__598000019, F_headers, F_s__598000020 any }

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A struct{ j2g_header uint64; F_headers, F_b__598000022 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_iter__598000030__598000034_A struct{ j2g_header uint64; F_headers any }

var A_arbace_box_build_source_tree_iter__598000030__598000034_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A struct{ j2g_header uint64; F_headers, F_iter__598000030, F_s__598000031 any }

var A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A struct{ j2g_header uint64; F_headers, F_b__598000033 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_fn_class *jrt.Class



type A_arbace_box_build_with_tools_A struct{ j2g_header uint64 }

var A_arbace_box_build_with_tools_A_fn_class *jrt.Class



type A_arbace_box_build_with_tools_iter__598000221__598000225_A struct{ j2g_header uint64; F_arch any }

var A_arbace_box_build_with_tools_iter__598000221__598000225_A_fn_class *jrt.Class



type A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A struct{ j2g_header uint64; F_s__598000222, F_arch, F_iter__598000221 any }

var A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_fn_class *jrt.Class



type A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A struct{ j2g_header uint64; F_b__598000224, F_arch any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_fn_class *jrt.Class
