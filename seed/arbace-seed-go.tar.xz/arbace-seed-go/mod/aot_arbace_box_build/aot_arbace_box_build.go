//line aot_arbace_box_build.ae:1
package aot_arbace_box_build

import (
	"arbace/aot_arbace_box"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_edn"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :4:1
func A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_New() *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_build_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_box_build_A_const_1); lang.IFn_Cast(A_arbace_box_build_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_box_build_A_const_3, A_arbace_box_build_A_const_4, A_arbace_box_build_A_const_5); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_112)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_113)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_114)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :4:1
func A_arbace_box_build_eval598000008_fn__598000009_A_New() *A_arbace_box_build_eval598000008_fn__598000009_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_eval598000008_fn__598000009_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_build_eval598000008_fn__598000009_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_build_eval598000008_fn__598000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_6.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_box_build_A_const_8; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_box_build_A_const_9.GetRawRoot__O(), A_arbace_box_build_A_const_10) }







































func A_arbace_box_build_fail_A_New() *A_arbace_box_build_fail_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_fail_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_box_build_fail_A) Ctor() {}
//line :44:1
func (t *A_arbace_box_build_fail_A) Invoke_O_O_O__O(self, msg__0, data__1 any) any { var tmp1 any; var root_27 any = A_arbace_box_build_A_const_11.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_29 lang.IFn; if
											linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = msg__0; var arg_31 any; var root_21 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = data__1; var arg_25 any = A_arbace_box_build_A_const_13; var arg_26 any = jrt.Boolean_TRUE.Ref(); if linked_22 == nil { arg_31 = ifn_23.Invoke_O_O_O__O(arg_24, arg_25, arg_26) } else { arg_31 = linked_22.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_21, arg_24, arg_25, arg_26) }; if linked_28 == nil { tmp1 = ifn_29.Invoke_O_O__O(arg_30, arg_31) } else { tmp1 = linked_28.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_27, arg_30, arg_31) }; /*line :44:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }


func A_arbace_box_build_sha256_hex_A_New() *A_arbace_box_build_sha256_hex_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_sha256_hex_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_box_build_sha256_hex_A) Ctor() {}
//line :47:1
func (t *A_arbace_box_build_sha256_hex_A) Invoke_O_O__O(self, s__0 any) any { var d__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_140).Digest_B1__B1(jrt.NN(jrt.String_Cast(s__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8)).Ref(); var sb__3 any = jrt.StringBuilder_New(); var seq_598000013__4 any; var root_36 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_38 lang.IFn; if


	linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = d__2; if linked_37 == nil { seq_598000013__4 = ifn_38.Invoke_O__O(arg_39) } else { seq_598000013__4 = linked_37.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_36, arg_39) }; var chunk_598000014__5 any; var count_598000015__6 int64 = 0; var i_598000016__7 int64 = 0; L1:
//line :47:1
	for {


		if lang.Numbers_Lt_J_J__Z_NoInit(i_598000016__7, count_598000015__6) { var b__8 any = lang.Indexed_Cast(chunk_598000014__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_598000016__7)); var x__9 int64; var na_56 any = b__8; var na_57 int64 = 255
			if jrt.Long_InstanceOf(na_56) { var n0_58 int64 = jrt.NN(jrt.Long_Cast(na_56)).LongValue__J(); var n1_59 int64 = na_57; x__9 = n0_58 & n1_59 } else { x__9 = lang.Numbers_And_O_J__J_NoInit(na_56, na_57) }
			jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(x__9, 4)), lang.RT_IntCast_J__I_NoInit(16)))
			jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_And_J_J__J_NoInit(x__9, 15)), lang.RT_IntCast_J__I_NoInit(16)))
//line :50:1
			seq_598000013__4, chunk_598000014__5, count_598000015__6, i_598000016__7 = seq_598000013__4, chunk_598000014__5, count_598000015__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_598000016__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_40 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = seq_598000013__4; if linked_41 == nil { temp__1927000414__auto____8 = ifn_42.Invoke_O__O(arg_43) } else { temp__1927000414__auto____8 = linked_41.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_40, arg_43) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_598000013__9 any = temp__1927000414__auto____8; var tmp1 any; var root_44 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = seq_598000013__9; if linked_45 == nil { tmp1 = ifn_46.Invoke_O__O(arg_47) } else { tmp1 = linked_45.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_44, arg_47) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____10 any; var root_48 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = seq_598000013__9; if linked_49 == nil { c__1927000678__auto____10 = ifn_50.Invoke_O__O(arg_51) } else { c__1927000678__auto____10 = linked_49.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_48, arg_51) }; var tmp2 any; var root_61 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = seq_598000013__9; if linked_62 == nil { tmp2 = ifn_63.Invoke_O__O(arg_64) } else { tmp2 = linked_62.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_61, arg_64) }; seq_598000013__4, chunk_598000014__5, count_598000015__6, i_598000016__7 = tmp2, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var b__10 any; var root_52 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = seq_598000013__9; if linked_53 == nil { b__10 = ifn_54.Invoke_O__O(arg_55) } else { b__10 = linked_53.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_52, arg_55) }; var x__11 int64; var na_65 any = b__10; var na_66 int64 = 255
				if jrt.Long_InstanceOf(na_65) { var n0_67 int64 = jrt.NN(jrt.Long_Cast(na_65)).LongValue__J(); var n1_68 int64 = na_66; x__11 = n0_67 & n1_68 } else { x__11 = lang.Numbers_And_O_J__J_NoInit(na_65, na_66) }
				jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(x__11, 4)), lang.RT_IntCast_J__I_NoInit(16)))
				jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_And_J_J__J_NoInit(x__11, 15)), lang.RT_IntCast_J__I_NoInit(16)))
//line :50:1
				var tmp3 any; var root_70 any = A_arbace_box_build_A_const_20.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = seq_598000013__9; if linked_71 == nil { tmp3 = ifn_72.Invoke_O__O(arg_73) } else { tmp3 = linked_71.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_70, arg_73) }; seq_598000013__4, chunk_598000014__5, count_598000015__6, i_598000016__7 = tmp3, nil, 0, 0; continue L1 } } }
//line :47:1
		break L1 }; var root_32 any =






	A_arbace_box_build_A_const_14.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = sb__3; if linked_33 == nil { return ifn_34.Invoke_O__O(arg_35) } else { return linked_33.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_32, arg_35) } }




func A_arbace_box_build_source_tree_A_New() *A_arbace_box_build_source_tree_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_A{}; t.Ctor(); return t }
//line :59:1
func (t *A_arbace_box_build_source_tree_A) Ctor() {}
//line :59:1
func (t *A_arbace_box_build_source_tree_A) Invoke_O_O__O(self, d__0 any) any { var fs__2 any = jrt.NN(jrt.File_Cast(d__0)).ListFiles__File1().Ref(); var headers__3 any; var tmp1 any = A_arbace_box_build_source_tree_headers__598000018_A_New(); var tmp2 *jrt.Class; var fncls__168 *jrt.Class = A_arbace_box_build_source_tree_headers__598000018_A_fn_class; if




	fncls__168 == nil { var fncls__168d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_box_build_source_tree_headers__598000018_A_fn_class = fncls__168d; tmp2 = fncls__168d } else { tmp2 = fncls__168 }; headers__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var root_245 any =








	A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any; var root_240 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_242 lang.IFn; if
	linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_244 any; var iter__1927001039__auto____4 any; var tmp3 any = A_arbace_box_build_source_tree_iter__598000030__598000034_A_New_O(headers__3); var tmp4 *jrt.Class; var fncls__239 *jrt.Class = A_arbace_box_build_source_tree_iter__598000030__598000034_A_fn_class; if
	fncls__239 == nil { var fncls__239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_box_build_source_tree_iter__598000030__598000034_A_fn_class = fncls__239d; tmp4 = fncls__239d } else { tmp4 = fncls__239 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); arg_244 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(fs__2); if /*line :74:1*/ linked_241 == nil { arg_248 = ifn_242.Invoke_O_O__O(arg_243, arg_244) } else { arg_248 = linked_241.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_240, arg_243, arg_244) }; if /*line :73:1*/ linked_246 == nil { return ifn_247.Invoke_O__O(arg_248) } else { return linked_246.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_245, arg_248) } }
//line :64:1
func A_arbace_box_build_source_tree_headers__598000018_A_New() *A_arbace_box_build_source_tree_headers__598000018_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_box_build_source_tree_headers__598000018_A) Ctor() {}
//line :64:1
func (t *A_arbace_box_build_source_tree_headers__598000018_A) Invoke_O_O__O(self, s__1 any) any { var m__2 any; var root_155 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_157 lang.IFn; if
												linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_159 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_New_O(self); var tmp2 *jrt.Class; var fncls__154 *jrt.Class = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_fn_class; if
												fncls__154 == nil { var fncls__154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_fn_class = fncls__154d; tmp2 = fncls__154d } else { tmp2 = fncls__154 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_159 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(jrt.NN(jrt.File_Cast(s__1)).ListFiles__File1().Ref()); if /*line :65:1*/ linked_156 == nil { m__2 = ifn_157.Invoke_O_O__O(arg_158, arg_159) } else { m__2 = linked_156.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_155, arg_158, arg_159) }; var tmp3 any; var root_160 any =






	A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = m__2; if linked_161 == nil { tmp3 = ifn_162.Invoke_O__O(arg_163) } else { tmp3 = linked_161.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_160, arg_163) }; if jrt.J2g_Truth(tmp3) { var root_164 any = A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = m__2; if linked_165 == nil { return ifn_166.Invoke_O__O(arg_167) } else { return linked_165.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_164, arg_167) } } else { return nil } }
//line :66:1
func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_New_O(p0 any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A{}; t.Ctor_O(p0); return t }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A) Ctor_O(c__headers any) { t.F_headers = c__headers }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A) Invoke_O_O__O(self, s__598000020__1 any) any { var tmp1 any = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_New_O_O_O(self, t.F_headers, s__598000020__1); var tmp2 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_fn_class = fncls__153d; tmp2 = fncls__153d } else { tmp2 = fncls__153 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :66:1
func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A) Ctor_O_O_O(c__iter__598000019, c__headers, c__s__598000020 any) { t.F_iter__598000019 = c__iter__598000019; t.F_headers = c__headers; t.F_s__598000020 = c__s__598000020 }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A) Invoke_O__O(self any) any { { var s__598000020__1 any; var t_ any = t.F_s__598000020; t.F_s__598000020 = nil; s__598000020__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_74 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = s__598000020__1; if linked_75 == nil { temp__1927000414__auto____2 = ifn_76.Invoke_O__O(arg_77) } else { temp__1927000414__auto____2 = linked_75.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_74, arg_77) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000020__3 any = temp__1927000414__auto____2; var tmp1 any; var root_78 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = s__598000020__3; if linked_79 == nil { tmp1 = ifn_80.Invoke_O__O(arg_81) } else { tmp1 = linked_79.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_78, arg_81) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_82 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = s__598000020__3; if linked_83 == nil { c__1927001037__auto____4 = ifn_84.Invoke_O__O(arg_85) } else { c__1927001037__auto____4 = linked_83.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_82, arg_85) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000022__6 any; var root_86 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_87 == nil { b__598000022__6 = ifn_88.Invoke_O__O(arg_89) } else { b__598000022__6 = linked_87.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_86, arg_89) }; var tmp2 any = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_New_O_O_I_O(t.F_headers, b__598000022__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_fn_class = fncls__104d; tmp3 = fncls__104d } else { tmp3 = fncls__104 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_113 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any; var root_105 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = b__598000022__6; if linked_106 == nil { arg_116 = ifn_107.Invoke_O__O(arg_108) } else { arg_116 = linked_106.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_105, arg_108) }; var arg_117 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000019); var tmp5 any; var root_109 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = s__598000020__3; if linked_110 == nil { tmp5 = ifn_111.Invoke_O__O(arg_112) } else { tmp5 = linked_110.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_109, arg_112) }; arg_117 = tmp4.Invoke_O__O(tmp5); if linked_114 == nil { return ifn_115.Invoke_O_O__O(arg_116, arg_117) } else { return linked_114.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_113, arg_116, arg_117) } } else { var root_122 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any; var root_118 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = b__598000022__6; if linked_119 == nil { arg_125 = ifn_120.Invoke_O__O(arg_121) } else { arg_125 = linked_119.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_118, arg_121) }; var arg_126 any; if linked_123 == nil { return ifn_124.Invoke_O_O__O(arg_125, arg_126) } else { return linked_123.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_122, arg_125, arg_126) } } } else { var f__4 any; var root_127 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = s__598000020__3; if linked_128 == nil { f__4 = ifn_129.Invoke_O__O(arg_130) } else { f__4 = linked_128.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_127, arg_130) }; var e__5 any
																	if jrt.NN(jrt.File_Cast(f__4)).IsDirectory__Z() { var temp__1927000414__auto____5 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__4); if jrt.J2g_Truth(temp__1927000414__auto____5) { var h__6 any = temp__1927000414__auto____5; e__5 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_25, h__6) } else { e__5 = nil } } else { var tmp6 any; var root_131 any = A_arbace_box_build_A_const_23.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_133 lang.IFn
																		if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var arg_135 any = Lit_146; if linked_132 == nil { tmp6 = ifn_133.Invoke_O_O__O(arg_134, arg_135) } else { tmp6 = linked_132.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_131, arg_134, arg_135) }
//line :67:1
		if jrt.J2g_Truth(tmp6) {

			var root_136 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()).Ref(); if linked_137 == nil { e__5 = ifn_138.Invoke_O__O(arg_139) } else { e__5 = linked_137.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_136, arg_139) } } else {
//line :67:1
				e__5 = nil } }
//line :66:1
	if jrt.J2g_Truth(e__5) { var root_144 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), e__5); var arg_148 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__598000019); var tmp8 any; var root_140 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = s__598000020__3; if linked_141 == nil { tmp8 = ifn_142.Invoke_O__O(arg_143) } else { tmp8 = linked_141.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_140, arg_143) }; arg_148 = tmp7.Invoke_O__O(tmp8); if linked_145 == nil { return ifn_146.Invoke_O_O__O(arg_147, arg_148) } else { return linked_145.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_144, arg_147, arg_148) } } else { var tmp9 any; var root_149 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = s__598000020__3; if linked_150 == nil { tmp9 = ifn_151.Invoke_O__O(arg_152) } else { tmp9 = linked_150.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_149, arg_152) }; s__598000020__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :66:1
func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A) Ctor_O_O_I_O(c__headers, c__b__598000022 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_headers = c__headers; t.F_b__598000022 = c__b__598000022; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A) Invoke_O__O(self any) any { { var i__598000021__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000021__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000021__1)); var e__3 any
																		if jrt.NN(jrt.File_Cast(f__2)).IsDirectory__Z() { var temp__1927000414__auto____3 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__2); if jrt.J2g_Truth(temp__1927000414__auto____3) { var h__4 any = temp__1927000414__auto____3; e__3 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_25, h__4) } else { e__3 = nil } } else { var tmp2 any; var root_90 any = A_arbace_box_build_A_const_23.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_92 lang.IFn
																			if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var arg_94 any = Lit_146; if linked_91 == nil { tmp2 = ifn_92.Invoke_O_O__O(arg_93, arg_94) } else { tmp2 = linked_91.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_90, arg_93, arg_94) }
//line :67:1
		if jrt.J2g_Truth(tmp2) {

			var root_95 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()).Ref(); if linked_96 == nil { e__3 = ifn_97.Invoke_O__O(arg_98) } else { e__3 = linked_96.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_95, arg_98) } } else {
//line :67:1
				e__3 = nil } }
//line :66:1
	if jrt.J2g_Truth(e__3) { var root_99 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = t.F_b__598000022; var arg_103 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), e__3); if linked_100 == nil { ifn_101.Invoke_O_O__O(arg_102, arg_103) } else { linked_100.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_99, arg_102, arg_103) }; i__598000021__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000021__1); continue L1 } else { i__598000021__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000021__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_box_build_source_tree_iter__598000030__598000034_A_New_O(p0 any) *A_arbace_box_build_source_tree_iter__598000030__598000034_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_iter__598000030__598000034_A{}; t.Ctor_O(p0); return t }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_A) Ctor_O(c__headers any) { t.F_headers = c__headers }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_A) Invoke_O_O__O(self, s__598000031__1 any) any { var tmp1 any = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_New_O_O_O(t.F_headers, self, s__598000031__1); var tmp2 *jrt.Class; var fncls__238 *jrt.Class = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_fn_class; if fncls__238 == nil { var fncls__238d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_fn_class = fncls__238d; tmp2 = fncls__238d } else { tmp2 = fncls__238 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :75:1
func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A) Ctor_O_O_O(c__headers, c__iter__598000030, c__s__598000031 any) { t.F_headers = c__headers; t.F_iter__598000030 = c__iter__598000030; t.F_s__598000031 = c__s__598000031 }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A) Invoke_O__O(self any) any { { var s__598000031__1 any; var t_ any = t.F_s__598000031; t.F_s__598000031 = nil; s__598000031__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_169 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = s__598000031__1; if linked_170 == nil { temp__1927000414__auto____2 = ifn_171.Invoke_O__O(arg_172) } else { temp__1927000414__auto____2 = linked_170.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_169, arg_172) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000031__3 any = temp__1927000414__auto____2; var tmp1 any; var root_173 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = s__598000031__3; if linked_174 == nil { tmp1 = ifn_175.Invoke_O__O(arg_176) } else { tmp1 = linked_174.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_173, arg_176) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_177 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = s__598000031__3; if linked_178 == nil { c__1927001037__auto____4 = ifn_179.Invoke_O__O(arg_180) } else { c__1927001037__auto____4 = linked_178.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_177, arg_180) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000033__6 any; var root_181 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_182 == nil { b__598000033__6 = ifn_183.Invoke_O__O(arg_184) } else { b__598000033__6 = linked_182.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_181, arg_184) }; var tmp2 any = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_New_O_O_I_O(t.F_headers, b__598000033__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__194 *jrt.Class = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_fn_class; if fncls__194 == nil { var fncls__194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_fn_class = fncls__194d; tmp3 = fncls__194d } else { tmp3 = fncls__194 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_203 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any; var root_195 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = b__598000033__6; if linked_196 == nil { arg_206 = ifn_197.Invoke_O__O(arg_198) } else { arg_206 = linked_196.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_195, arg_198) }; var arg_207 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000030); var tmp5 any; var root_199 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = s__598000031__3; if linked_200 == nil { tmp5 = ifn_201.Invoke_O__O(arg_202) } else { tmp5 = linked_200.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_199, arg_202) }; arg_207 = tmp4.Invoke_O__O(tmp5); if linked_204 == nil { return ifn_205.Invoke_O_O__O(arg_206, arg_207) } else { return linked_204.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_203, arg_206, arg_207) } } else { var root_212 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any; var root_208 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = b__598000033__6; if linked_209 == nil { arg_215 = ifn_210.Invoke_O__O(arg_211) } else { arg_215 = linked_209.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_208, arg_211) }; var arg_216 any; if linked_213 == nil { return ifn_214.Invoke_O_O__O(arg_215, arg_216) } else { return linked_213.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_212, arg_215, arg_216) } } } else { var f__4 any; var root_217 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = s__598000031__3; if linked_218 == nil { f__4 = ifn_219.Invoke_O__O(arg_220) } else { f__4 = linked_218.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_217, arg_220) }; var e__5 any
														if jrt.NN(jrt.File_Cast(f__4)).IsDirectory__Z() { var temp__1927000414__auto____5 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__4)
															if jrt.J2g_Truth(temp__1927000414__auto____5) { var h__6 any = temp__1927000414__auto____5; e__5 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_25, h__6) } else { e__5 = nil } } else {
																var root_221 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()).Ref(); if linked_222 == nil { e__5 = ifn_223.Invoke_O__O(arg_224) } else { e__5 = linked_222.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_221, arg_224) } }
//line :75:1
	if jrt.J2g_Truth(e__5) { var root_229 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), e__5); var arg_233 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000030); var tmp7 any; var root_225 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = s__598000031__3; if linked_226 == nil { tmp7 = ifn_227.Invoke_O__O(arg_228) } else { tmp7 = linked_226.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_225, arg_228) }; arg_233 = tmp6.Invoke_O__O(tmp7); if linked_230 == nil { return ifn_231.Invoke_O_O__O(arg_232, arg_233) } else { return linked_230.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_229, arg_232, arg_233) } } else { var tmp8 any; var root_234 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = s__598000031__3; if linked_235 == nil { tmp8 = ifn_236.Invoke_O__O(arg_237) } else { tmp8 = linked_235.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_234, arg_237) }; s__598000031__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :75:1
func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A) Ctor_O_O_I_O(c__headers, c__b__598000033 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_headers = c__headers; t.F_b__598000033 = c__b__598000033; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A) Invoke_O__O(self any) any { { var i__598000032__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000032__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000032__1)); var e__3 any
																if jrt.NN(jrt.File_Cast(f__2)).IsDirectory__Z() { var temp__1927000414__auto____3 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__2)
																	if jrt.J2g_Truth(temp__1927000414__auto____3) { var h__4 any = temp__1927000414__auto____3; e__3 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_25, h__4) } else { e__3 = nil } } else {
																		var root_185 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()).Ref(); if linked_186 == nil { e__3 = ifn_187.Invoke_O__O(arg_188) } else { e__3 = linked_186.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_185, arg_188) } }
//line :75:1
	if jrt.J2g_Truth(e__3) { var root_189 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = t.F_b__598000033; var arg_193 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), e__3); if linked_190 == nil { ifn_191.Invoke_O_O__O(arg_192, arg_193) } else { linked_190.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_189, arg_192, arg_193) }; i__598000032__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000032__1); continue L1 } else { i__598000032__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000032__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_box_build_import_plan_A_New() *A_arbace_box_build_import_plan_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_import_plan_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_box_build_import_plan_A) Ctor() {}
//line :82:1
func (t *A_arbace_box_build_import_plan_A) Invoke_O_O_O__O(self, plan__0, goroot__1 any) any { var p__3 any; var tmp1 any; var root_249 any = A_arbace_box_build_A_const_32.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_251 lang.IFn; if




	linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = plan__0; if linked_250 == nil { tmp1 = ifn_251.Invoke_O__O(arg_252) } else { tmp1 = linked_250.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_249, arg_252) }; if jrt.J2g_Truth(tmp1) { p__3 = plan__0 } else { var root_257 any = A_arbace_box_build_A_const_33.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_edn.A_arbace_edn_read_string_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = lang.IFn_Cast(A_arbace_box_build_A_const_34.GetRawRoot__O()).Invoke_O__O(plan__0); if linked_258 == nil { p__3 = ifn_259.Invoke_O__O(arg_260) } else { p__3 = linked_258.(*aot_arbace_edn.A_arbace_edn_read_string_A).Invoke_O_O__O(root_257, arg_260) } }; var dirs__4 any; var root_261 any = /*line :82:1*/A_arbace_box_build_A_const_35.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_263 lang.IFn; if





	linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_262 == nil { dirs__4 = ifn_263.Invoke_O__O(arg_264) } else { dirs__4 = linked_262.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_261, arg_264) }; var src__5 any; var tmp2 any = /*line :82:1*/A_arbace_box_build_import_plan_src__598000042_A_New_O(dirs__4); var tmp3 *jrt.Class; var fncls__280 *jrt.Class = A_arbace_box_build_import_plan_src__598000042_A_fn_class; if






	fncls__280 == nil { var fncls__280d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_box_build_import_plan_src__598000042_A_fn_class = fncls__280d; tmp3 = fncls__280d } else { tmp3 = fncls__280 }; src__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var p__6 any; var root_309 any = /*line :82:1*/A_arbace_box_build_A_const_38.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_311 lang.IFn; if









	linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any; var root_285 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_287 lang.IFn; if /*line :91:1*/ linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = p__3; var arg_289 any = A_arbace_box_build_A_const_39; var arg_290 any; var root_281 any = A_arbace_box_build_A_const_40.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_box.A_arbace_box_put_dir_A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_119), jrt.RefArrayOf(jrt.Object_class, goroot__1, nil)).Ref(); if linked_282 == nil { arg_290 = ifn_283.Invoke_O__O(arg_284) } else { arg_290 = linked_282.(*aot_arbace_box.A_arbace_box_put_dir_A).Invoke_O_O__O(root_281, arg_284) }; if linked_286 == nil { arg_312 = ifn_287.Invoke_O_O_O__O(arg_288, arg_289, arg_290) } else { arg_312 = linked_286.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_285, arg_288, arg_289, arg_290) }; var arg_313 any = A_arbace_box_build_A_const_41; var arg_314 any; var tmp4 any =
	A_arbace_box_build_import_plan_fn__598000044_A_New_O(src__5); var tmp5 *jrt.Class; var fncls__308 *jrt.Class = A_arbace_box_build_import_plan_fn__598000044_A_fn_class; if fncls__308 == nil { var fncls__308d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_box_build_import_plan_fn__598000044_A_fn_class = fncls__308d; tmp5 = fncls__308d } else { tmp5 = fncls__308 }; arg_314 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if linked_310 == nil { p__6 = ifn_311.Invoke_O_O_O__O(arg_312, arg_313, arg_314) } else { p__6 = linked_310.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_309, arg_312, arg_313, arg_314) }; var root_319 any =
	A_arbace_box_build_A_const_45.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, aot_arbace_box.A_arbace_box_put_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = lang.IFn_Cast(A_arbace_box_build_A_const_46.GetRawRoot__O()).Invoke_O__O(p__6); if linked_320 == nil { return ifn_321.Invoke_O__O(arg_322) } else { return linked_320.(*aot_arbace_box.A_arbace_box_put_A).Invoke_O_O__O(root_319, arg_322) } }
//line :82:1
func (t *A_arbace_box_build_import_plan_A) Invoke_O_O__O(self, plan__0 any) any {


	var root_323 any = A_arbace_box_build_A_const_47.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, A_arbace_box_build_import_plan_A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = plan__0; var arg_327 any = Lit_121; if linked_324 == nil { return ifn_325.Invoke_O_O__O(arg_326, arg_327) } else { return linked_324.(*A_arbace_box_build_import_plan_A).Invoke_O_O_O__O(root_323, arg_326, arg_327)
	}
}

func A_arbace_box_build_import_plan_src__598000042_A_New_O(p0 any) *A_arbace_box_build_import_plan_src__598000042_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_import_plan_src__598000042_A{}; t.Ctor_O(p0); return t }
//line :89:1
func (t *A_arbace_box_build_import_plan_src__598000042_A) Ctor_O(c__dirs any) { t.F_dirs = c__dirs }
//line :89:1
func (t *A_arbace_box_build_import_plan_src__598000042_A) Invoke_O_O__O(self, dir__1 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_265 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = t.F_dirs; if linked_266 == nil { tmp1 = ifn_267.Invoke_O__O(arg_268) } else { tmp1 = linked_266.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_265, arg_268) }; or__1927000174__auto____2 = lang.IFn_Cast(tmp1).Invoke_O__O(dir__1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var h__3 any; var root_269 any = A_arbace_box_build_A_const_36.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, A_arbace_box_build_source_tree_A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = jrt.File_New_String(jrt.String_Cast(dir__1)); if linked_270 == nil { h__3 = ifn_271.Invoke_O__O(arg_272) } else { h__3 = linked_270.(*A_arbace_box_build_source_tree_A).Invoke_O_O__O(root_269, arg_272) }; var root_273 any = A_arbace_box_build_A_const_37.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = t.F_dirs; var arg_277 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var arg_278 any = dir__1; var arg_279 any = h__3; if linked_274 == nil { ifn_275.Invoke_O_O_O_O__O(arg_276, arg_277, arg_278, arg_279) } else { linked_274.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_273, arg_276, arg_277, arg_278, arg_279) }; return h__3 } }


func A_arbace_box_build_import_plan_fn__598000044_A_New_O(p0 any) *A_arbace_box_build_import_plan_fn__598000044_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_import_plan_fn__598000044_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_A) Ctor_O(c__src any) { t.F_src = c__src }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_A) Invoke_O_O__O(self, ps__1 any) any { var root_303 any = A_arbace_box_build_A_const_42.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any; var tmp1 any = A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_New_O(t.F_src); var tmp2 *jrt.Class; var fncls__302 *jrt.Class = A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_fn_class; if fncls__302 == nil { var fncls__302d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_fn_class = fncls__302d; tmp2 = fncls__302d } else { tmp2 = fncls__302 }; arg_306 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_307 any = ps__1; if linked_304 == nil { return ifn_305.Invoke_O_O__O(arg_306, arg_307) } else { return linked_304.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_303, arg_306, arg_307) } }
//line :92:1
func A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_New_O(p0 any) *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A) Ctor_O(c__src any) { t.F_src = c__src }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A) Invoke_O_O__O(self, p1__598000041_SHARP___1 any) any { var root_297 any = A_arbace_box_build_A_const_43.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_297, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_299 lang.IFn; if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any; var root_291 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = p1__598000041_SHARP___1; var arg_295 any = A_arbace_box_build_A_const_44; var tmp1 lang.IFn = lang.IFn_Cast(t.F_src); var arg_296 any = tmp1.Invoke_O__O(A_arbace_box_build_A_const_25.Invoke_O__O(p1__598000041_SHARP___1)); if linked_292 == nil { arg_300 = ifn_293.Invoke_O_O_O__O(arg_294, arg_295, arg_296) } else { arg_300 = linked_292.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_291, arg_294, arg_295, arg_296) }; var arg_301 any = A_arbace_box_build_A_const_25; if linked_298 == nil { return ifn_299.Invoke_O_O__O(arg_300, arg_301) } else { return linked_298.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_297, arg_300, arg_301) } }







func A_arbace_box_build_log_A_New() *A_arbace_box_build_log_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_log_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_box_build_log_A) Ctor() {}
//line :100:1
func (t *A_arbace_box_build_log_A) DoInvoke_O_O__O(self, xs__0 any) any {
	var tmp1 lang.IFn = A_arbace_box_build_A_const_48; var tmp2 lang.IFn = lang.IFn_Cast(tmp1.Invoke_O_O__O(A_arbace_box_build_A_const_49.Get__O(), A_arbace_box_build_A_const_50.GetRawRoot__O())); var tmp3 any; var root_328 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_332 any = xs__0; if linked_329 == nil { tmp3 = ifn_330.Invoke_O_O__O(arg_331, arg_332) } else { tmp3 = linked_329.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_328, arg_331, arg_332) }; return tmp2.Invoke_O__O(tmp3)
}
func A_arbace_box_build_cache_ref_A_New() *A_arbace_box_build_cache_ref_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_cache_ref_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_box_build_cache_ref_A) Ctor() {}
//line :103:1
func (t *A_arbace_box_build_cache_ref_A) Invoke_O_O__O(self, req__0 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_89, nil); var tmp2 any; var root_347 any = A_arbace_box_build_A_const_52.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any; var root_343 any = A_arbace_box_build_A_const_53.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, A_arbace_box_build_sha256_hex_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any; var root_339 any = A_arbace_box_build_A_const_54.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, aot_arbace_box.A_arbace_box_request_text_A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = lang.IFn_Cast(A_arbace_box_build_A_const_43.GetRawRoot__O()).Invoke_O_O_O__O(req__0, A_arbace_box_build_A_const_55, A_arbace_box_build_A_const_56); if linked_340 == nil { arg_346 = ifn_341.Invoke_O__O(arg_342) } else { arg_346 = linked_340.(*aot_arbace_box.A_arbace_box_request_text_A).Invoke_O_O__O(root_339, arg_342) }; if linked_344 == nil { arg_350 = ifn_345.Invoke_O__O(arg_346) } else { arg_350 = linked_344.(*A_arbace_box_build_sha256_hex_A).Invoke_O_O__O(root_343, arg_346) }; var arg_351 any = A_arbace_box_build_A_const_57; var arg_352 any = A_arbace_box_build_A_const_58; if linked_348 == nil { tmp2 = ifn_349.Invoke_O_O_O__O(arg_350, arg_351, arg_352) } else { tmp2 = linked_348.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_347, arg_350, arg_351, arg_352) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref()
}
func A_arbace_box_build_action_STAR__A_New() *A_arbace_box_build_action_STAR__A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_action_STAR__A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_box_build_action_STAR__A) Ctor() {}
//line :106:1
func (t *A_arbace_box_build_action_STAR__A) Invoke_O_O_O__O(self, what__0, req__1 any) any { var cref__3 any; var root_353 any = A_arbace_box_build_A_const_59.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, A_arbace_box_build_cache_ref_A_fn_class); var ifn_355 lang.IFn; if

	linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = req__1; if linked_354 == nil { cref__3 = ifn_355.Invoke_O__O(arg_356) } else { cref__3 = linked_354.(*A_arbace_box_build_cache_ref_A).Invoke_O_O__O(root_353, arg_356) }; var cached__4 any; var tmp1 lang.IFn = A_arbace_box_build_A_const_60; if
	jrt.J2g_Truth(tmp1.Invoke_O_O__O(A_arbace_box_build_A_const_49.Get__O(), jrt.Boolean_TRUE.Ref())) { var temp__1927000414__auto____4 any; var root_357 any = A_arbace_box_build_A_const_61.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, aot_arbace_box.A_arbace_box_ref_A_fn_class); var ifn_359 lang.IFn
		if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = cref__3; if linked_358 == nil { temp__1927000414__auto____4 = ifn_359.Invoke_O__O(arg_360) } else { temp__1927000414__auto____4 = linked_358.(*aot_arbace_box.A_arbace_box_ref_A).Invoke_O_O__O(root_357, arg_360) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var h__5 any = temp__1927000414__auto____4; var tmp2 any; var root_361 any = A_arbace_box_build_A_const_62.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, aot_arbace_box.A_arbace_box_size_A_fn_class); var ifn_363 lang.IFn
			if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = h__5; if linked_362 == nil { tmp2 = ifn_363.Invoke_O__O(arg_364) } else { tmp2 = linked_362.(*aot_arbace_box.A_arbace_box_size_A).Invoke_O_O__O(root_361, arg_364) }; if jrt.J2g_Truth(tmp2) { var root_365 any = A_arbace_box_build_A_const_63.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_box.A_arbace_box_result_A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = h__5; if linked_366 == nil { cached__4 = ifn_367.Invoke_O__O(arg_368) } else { cached__4 = linked_366.(*aot_arbace_box.A_arbace_box_result_A).Invoke_O_O__O(root_365, arg_368) } } else { cached__4 = nil } } else {
//line :110:1
				cached__4 = nil } } else {
//line :109:1
					cached__4 = nil }; var t0__5 int64 = /*line :106:1*/jrt.System_NanoTime__J(); var res__6 any; var or__1927000174__auto____6 any = cached__4; if






	jrt.J2g_Truth(or__1927000174__auto____6) { res__6 = or__1927000174__auto____6 } else { var tmp3 lang.IFn = A_arbace_box_build_A_const_64; res__6 = lang.IFn_Cast(tmp3.Invoke_O_O__O(A_arbace_box_build_A_const_49.Get__O(), A_arbace_box_build_A_const_65.GetRawRoot__O())).Invoke_O__O(req__1) }; if
	lang.Util_Equiv_J_O__Z_NoInit(0, A_arbace_box_build_A_const_66.Invoke_O__O(res__6)) { } else {
		var root_373 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_373, A_arbace_box_build_fail_A_fn_class); var ifn_375 lang.IFn; if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil, Lit_2, nil, Lit_3, nil); var tmp5 *jrt.String; if jrt.J2g_Truth(A_arbace_box_build_A_const_68.Invoke_O__O(res__6)) { tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_4, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_68.Invoke_O__O(res__6))) } else { tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_66.Invoke_O__O(res__6))) }; var tmp6 any = tmp5.Ref(); var tmp7 any; var root_369 any = A_arbace_box_build_A_const_69.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, aot_arbace_box.A_arbace_box_get_A_fn_class); var ifn_371 lang.IFn
		if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = A_arbace_box_build_A_const_70.Invoke_O__O(res__6); if linked_370 == nil { tmp7 = ifn_371.Invoke_O__O(arg_372) } else { tmp7 = linked_370.(*aot_arbace_box.A_arbace_box_get_A).Invoke_O_O__O(root_369, arg_372) }
//line :115:1
		arg_376 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, what__0, nil, tmp6, nil, tmp7)).Ref(); var arg_377 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_71, what__0, A_arbace_box_build_A_const_72, res__6)); if linked_374 == nil { ifn_375.Invoke_O_O__O(arg_376, arg_377) } else { linked_374.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_373, arg_376, arg_377) } }; var tmp8 any; var and__1927000168__auto____7 any; var root_378 any =


	A_arbace_box_build_A_const_73.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = cached__4; if linked_379 == nil { and__1927000168__auto____7 = ifn_380.Invoke_O__O(arg_381) } else { and__1927000168__auto____7 = linked_379.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_378, arg_381) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp9 lang.IFn = A_arbace_box_build_A_const_60; tmp8 = tmp9.Invoke_O_O__O(A_arbace_box_build_A_const_49.Get__O(), jrt.Boolean_TRUE.Ref()) } else { tmp8 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp8) {
		var root_382 any = A_arbace_box_build_A_const_74.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_box.A_arbace_box_ref_BANG__A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = cref__3; var arg_386 any = A_arbace_box_build_A_const_75.Invoke_O__O(res__6); if linked_383 == nil { ifn_384.Invoke_O_O__O(arg_385, arg_386) } else { linked_383.(*aot_arbace_box.A_arbace_box_ref_BANG__A).Invoke_O_O_O__O(root_382, arg_385, arg_386) } }; var tmp10 lang.IFn =
	lang.IFn_Cast(A_arbace_box_build_A_const_76.GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_77.GetRawRoot__O()); var tmp12 any; var root_387 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = A_arbace_box_build_A_const_78.Invoke_O__O(req__1); if linked_388 == nil { tmp12 = ifn_389.Invoke_O__O(arg_390) } else { tmp12 = linked_388.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_387, arg_390) }; var tmp13 any = tmp12; var tmp14 any; if
	jrt.J2g_Truth(cached__4) { tmp14 = Lit_7 } else { tmp14 = lang.IFn_Cast(A_arbace_box_build_A_const_77.GetRawRoot__O()).Invoke_O_O__O(Lit_8, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__5), 1.0e9)).Ref()) }; /*line :120:1*/tmp10.Invoke_O__O(tmp11.Invoke_O_O_O_O__O(Lit_6, tmp13, what__0, tmp14)); return res__6 }



func A_arbace_box_build_action_A_New() *A_arbace_box_build_action_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_action_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_box_build_action_A) Ctor() {}
//line :124:1
func (t *A_arbace_box_build_action_A) Invoke_O_O_O_O__O(self, what__0, req__1, opts__2 any) any {




	var root_420 any = A_arbace_box_build_A_const_81.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, opts__2); if linked_421 == nil { ifn_422.Invoke_O__O(arg_423) } else { linked_421.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_420, arg_423) }
//line :124:1
	var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




		{ var root_407 any = A_arbace_box_build_A_const_79.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, A_arbace_box_build_action_STAR__A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = what__0; var arg_411 any = req__1; if linked_408 == nil { tmp1 = ifn_409.Invoke_O_O__O(arg_410, arg_411) } else { tmp1 = linked_408.(*A_arbace_box_build_action_STAR__A).Invoke_O_O_O__O(root_407, arg_410, arg_411) } }
//line :124:1
		return nil }(); var root_412 any = A_arbace_box_build_A_const_80.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_414 lang.IFn




	if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; if linked_413 == nil { ifn_414.Invoke__O() } else { linked_413.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_412) }
//line :124:1
	if tmp2 != nil { panic(tmp2) }; return tmp1 }
//line :124:1
func (t *A_arbace_box_build_action_A) Invoke_O_O_O__O(self, what__0, req__1 any) any {



	var root_424 any = A_arbace_box_build_A_const_79.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, A_arbace_box_build_action_STAR__A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = what__0; var arg_428 any = req__1; if linked_425 == nil { return ifn_426.Invoke_O_O__O(arg_427, arg_428) } else { return linked_425.(*A_arbace_box_build_action_STAR__A).Invoke_O_O_O__O(root_424, arg_427, arg_428)
	}
}
func A_arbace_box_build_out_file_A_New() *A_arbace_box_build_out_file_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_out_file_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_box_build_out_file_A) Ctor() {}
//line :131:1
func (t *A_arbace_box_build_out_file_A) Invoke_O_O_O_O__O(self, res__0, what__1, name__2 any) any { var or__1927000174__auto____4 any; var root_429 any = A_arbace_box_build_A_const_83.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_box.A_arbace_box_tree_get_A_fn_class); var ifn_431 lang.IFn; if


	linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = A_arbace_box_build_A_const_84.Invoke_O__O(res__0); var arg_433 any = name__2; if linked_430 == nil { or__1927000174__auto____4 = ifn_431.Invoke_O_O__O(arg_432, arg_433) } else { or__1927000174__auto____4 = linked_430.(*aot_arbace_box.A_arbace_box_tree_get_A).Invoke_O_O_O__O(root_429, arg_432, arg_433) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {
		var root_434 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, A_arbace_box_build_fail_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_1, nil, Lit_137, nil, Lit_138), jrt.RefArrayOf(jrt.Object_class, nil, what__1, nil, name__2, nil)).Ref(); var arg_438 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_72, res__0)); if linked_435 == nil { return ifn_436.Invoke_O_O__O(arg_437, arg_438) } else { return linked_435.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_434, arg_437, arg_438) } } }

func A_arbace_box_build_file_tree_A_New() *A_arbace_box_build_file_tree_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_file_tree_A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_box_build_file_tree_A) Ctor() {}
//line :137:1
func (t *A_arbace_box_build_file_tree_A) Invoke_O_O__O(self, m__0 any) any {


	var root_511 any = A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any; var root_506 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_510 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_box_build_file_tree_iter__598000054__598000058_A_New(); var tmp2 *jrt.Class; var fncls__505 *jrt.Class = A_arbace_box_build_file_tree_iter__598000054__598000058_A_fn_class; if fncls__505 == nil { var fncls__505d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_box_build_file_tree_iter__598000054__598000058_A_fn_class = fncls__505d; tmp2 = fncls__505d } else { tmp2 = fncls__505 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_510 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(m__0); if linked_507 == nil { arg_514 = ifn_508.Invoke_O_O__O(arg_509, arg_510) } else { arg_514 = linked_507.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_506, arg_509, arg_510) }; if linked_512 == nil { return ifn_513.Invoke_O__O(arg_514) } else { return linked_512.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_511, arg_514) } }
//line :140:1
func A_arbace_box_build_file_tree_iter__598000054__598000058_A_New() *A_arbace_box_build_file_tree_iter__598000054__598000058_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_file_tree_iter__598000054__598000058_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_A) Ctor() {}
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_A) Invoke_O_O__O(self, s__598000055__1 any) any { var tmp1 any = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_New_O_O(s__598000055__1, self); var tmp2 *jrt.Class; var fncls__504 *jrt.Class = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_fn_class; if fncls__504 == nil { var fncls__504d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_fn_class = fncls__504d; tmp2 = fncls__504d } else { tmp2 = fncls__504 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :140:1
func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_New_O_O(p0, p1 any) *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A) Ctor_O_O(c__s__598000055, c__iter__598000054 any) { t.F_s__598000055 = c__s__598000055; t.F_iter__598000054 = c__iter__598000054 }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A) Invoke_O__O(self any) any { { var s__598000055__1 any; var t_ any = t.F_s__598000055; t.F_s__598000055 = nil; s__598000055__1 = t_; for { var temp__1927000414__auto____2 any; var root_439 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = s__598000055__1; if linked_440 == nil { temp__1927000414__auto____2 = ifn_441.Invoke_O__O(arg_442) } else { temp__1927000414__auto____2 = linked_440.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_439, arg_442) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000055__3 any = temp__1927000414__auto____2; var tmp1 any; var root_443 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = s__598000055__3; if linked_444 == nil { tmp1 = ifn_445.Invoke_O__O(arg_446) } else { tmp1 = linked_444.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_443, arg_446) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_447 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = s__598000055__3; if linked_448 == nil { c__1927001037__auto____4 = ifn_449.Invoke_O__O(arg_450) } else { c__1927001037__auto____4 = linked_448.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_447, arg_450) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000057__6 any; var root_451 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_452 == nil { b__598000057__6 = ifn_453.Invoke_O__O(arg_454) } else { b__598000057__6 = linked_452.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_451, arg_454) }; var tmp2 any = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_New_O_I_O(b__598000057__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__464 *jrt.Class = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_fn_class; if fncls__464 == nil { var fncls__464d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_fn_class = fncls__464d; tmp3 = fncls__464d } else { tmp3 = fncls__464 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_473 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_473, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_475 lang.IFn; if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any; var root_465 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = b__598000057__6; if linked_466 == nil { arg_476 = ifn_467.Invoke_O__O(arg_468) } else { arg_476 = linked_466.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_465, arg_468) }; var arg_477 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000054); var tmp5 any; var root_469 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = s__598000055__3; if linked_470 == nil { tmp5 = ifn_471.Invoke_O__O(arg_472) } else { tmp5 = linked_470.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_469, arg_472) }; arg_477 = tmp4.Invoke_O__O(tmp5); if linked_474 == nil { return ifn_475.Invoke_O_O__O(arg_476, arg_477) } else { return linked_474.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_473, arg_476, arg_477) } } else { var root_482 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any; var root_478 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = b__598000057__6; if linked_479 == nil { arg_485 = ifn_480.Invoke_O__O(arg_481) } else { arg_485 = linked_479.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_478, arg_481) }; var arg_486 any; if linked_483 == nil { return ifn_484.Invoke_O_O__O(arg_485, arg_486) } else { return linked_483.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_482, arg_485, arg_486) } } } else { var vec__598000065__4 any; var root_487 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = s__598000055__3; if linked_488 == nil { vec__598000065__4 = ifn_489.Invoke_O__O(arg_490) } else { vec__598000065__4 = linked_488.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_487, arg_490) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000065__4, lang.RT_IntCast_J__I_NoInit(0), nil); var x__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000065__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_499 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any; var tmp6 any; var root_491 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = x__6; if linked_492 == nil { tmp6 = ifn_493.Invoke_O__O(arg_494) } else { tmp6 = linked_492.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_491, arg_494) }; arg_502 = lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp6); var arg_503 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__598000054); var tmp8 any; var root_495 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = s__598000055__3; if linked_496 == nil { tmp8 = ifn_497.Invoke_O__O(arg_498) } else { tmp8 = linked_496.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_495, arg_498) }; arg_503 = tmp7.Invoke_O__O(tmp8); if linked_500 == nil { return ifn_501.Invoke_O_O__O(arg_502, arg_503) } else { return linked_500.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_499, arg_502, arg_503) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :140:1
func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A) Ctor_O_I_O(c__b__598000057 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000057 = c__b__598000057; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A) Invoke_O__O(self any) any { { var i__598000056__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000056__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000061__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000056__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000061__2, lang.RT_IntCast_J__I_NoInit(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000061__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_459 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_461 lang.IFn; if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = t.F_b__598000057; var arg_463 any; var tmp2 any; var root_455 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = x__4; if linked_456 == nil { tmp2 = ifn_457.Invoke_O__O(arg_458) } else { tmp2 = linked_456.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_455, arg_458) }; arg_463 = lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp2); if linked_460 == nil { ifn_461.Invoke_O_O__O(arg_462, arg_463) } else { linked_460.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_459, arg_462, arg_463) }; i__598000056__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000056__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_box_build_arch_defines_A_New() *A_arbace_box_build_arch_defines_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_arch_defines_A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_box_build_arch_defines_A) Ctor() {}
//line :142:1
func (t *A_arbace_box_build_arch_defines_A) Invoke_O_O__O(self, plan__0 any) any { var a__2 any = A_arbace_box_build_A_const_85.Invoke_O__O(plan__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_86.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(Lit_13, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_14, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_87.Invoke_O__O(plan__0))).Ref(), Lit_13, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, a__2)).Ref()); var tmp3 any = A_arbace_box_build_A_const_88; var tmp4 lang.IPersistentVector; var G__598000071__3_ any = a__2; L1:



switch { default: switch lang.Util_Hash_O__I_NoInit(G__598000071__3_) { case 92926582: if lang.Util_Equiv_O_O__Z_NoInit(G__598000071__3_, Lit_16) { tmp4 = lang.Tuple_Create_O_O__IPersistentVector(Lit_13, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_89.Invoke_O__O(plan__0))).Ref()); break L1 }; default:}; tmp4 = Up_PersistentVector_IPersistentVector(lang.PersistentVector_EMPTY)}; return /*line :144:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }





func A_arbace_box_build_asm_args_A_New() *A_arbace_box_build_asm_args_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_asm_args_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_box_build_asm_args_A) Ctor() {}
//line :150:1
func (t *A_arbace_box_build_asm_args_A) DoInvoke_O_O_O_O_O__O(self, plan__0, pkg__1, out__2, more__3 any) any {
	var root_539 any = A_arbace_box_build_A_const_90.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_86.GetRawRoot__O()); var tmp2 any = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_33, Lit_34, A_arbace_box_build_A_const_91.Invoke_O__O(pkg__1), Lit_35, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_36, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_91.Invoke_O__O(pkg__1), nil)).Ref(), Lit_38, Lit_39, Lit_38, Lit_40)); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_92.GetRawRoot__O()); var tmp4 any = A_arbace_box_build_asm_args_fn__598000074_A_New_O(pkg__1); var tmp5 *jrt.Class
	var fncls__522 /*line :151:1*/*jrt.Class = A_arbace_box_build_asm_args_fn__598000074_A_fn_class

	if fncls__522 == nil { var fncls__522d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_box_build_asm_args_fn__598000074_A_fn_class = fncls__522d; tmp5 = fncls__522d } else { tmp5 = fncls__522 }
//line :151:1
	var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 any; var root_523 any = A_arbace_box_build_A_const_95.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, A_arbace_box_build_arch_defines_A_fn_class); var ifn_525 lang.IFn

	if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = plan__0; if linked_524 == nil { tmp7 = ifn_525.Invoke_O__O(arg_526) } else { tmp7 = linked_524.(*A_arbace_box_build_arch_defines_A).Invoke_O_O__O(root_523, arg_526) }
//line :151:1
	arg_542 = tmp1.Invoke_O_O_O_O__O(tmp2, tmp3.Invoke_O_O__O(tmp6, tmp7), more__3, lang.Tuple_Create_O_O__IPersistentVector(Lit_42, out__2)); if linked_540 == nil { return ifn_541.Invoke_O__O(arg_542) } else { return linked_540.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_539, arg_542)
	} }
func A_arbace_box_build_asm_args_fn__598000074_A_New_O(p0 any) *A_arbace_box_build_asm_args_fn__598000074_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_asm_args_fn__598000074_A{}; t.Ctor_O(p0); return t }
//line :153:1
func (t *A_arbace_box_build_asm_args_fn__598000074_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :153:1
func (t *A_arbace_box_build_asm_args_fn__598000074_A) Invoke_O_O__O(self, p1__598000073_SHARP___1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(p1__598000073_SHARP___1, A_arbace_box_build_A_const_93) { if jrt.J2g_Truth(A_arbace_box_build_A_const_93.Invoke_O__O(t.F_pkg)) { return A_arbace_box_build_A_const_94 } else { return nil } } else { return lang.Tuple_Create_O__IPersistentVector(p1__598000073_SHARP___1) } }




func A_arbace_box_build_ar_member_A_New() *A_arbace_box_build_ar_member_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_ar_member_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_box_build_ar_member_A) Ctor() {}
//line :158:1
func (t *A_arbace_box_build_ar_member_A) Invoke_O_O_O__O(self, name__0, data__1 any) any { var pad__3 any; var tmp1 any = A_arbace_box_build_ar_member_pad__598000077_A_New(); var tmp2 *jrt.Class; var fncls__558 *jrt.Class = A_arbace_box_build_ar_member_pad__598000077_A_fn_class; if
												fncls__558 == nil { var fncls__558d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_box_build_ar_member_pad__598000077_A_fn_class = fncls__558d; tmp2 = fncls__558d } else { tmp2 = fncls__558 }; pad__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var hdr__4 any; var tmp3 /*line :158:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil, nil, nil, nil, Lit_10); var tmp4 lang.IFn = lang.IFn_Cast(pad__3); var tmp5 any; var root_559 any = A_arbace_box_build_A_const_52.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_561 lang.IFn; if

	linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = name__0; var arg_563 any = A_arbace_box_build_A_const_57; var arg_564 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Min_J_J__J_NoInit(16, int64(lang.RT_Count_O__I_NoInit(name__0)))).Ref(); if linked_560 == nil { tmp5 = ifn_561.Invoke_O_O_O__O(arg_562, arg_563, arg_564) } else { tmp5 = linked_560.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_559, arg_562, arg_563, arg_564) }; var tmp6 any = tmp4.Invoke_O_O__O(tmp5, A_arbace_box_build_A_const_98); var tmp7 any = lang.IFn_Cast(pad__3).Invoke_O_O__O(Lit_11, A_arbace_box_build_A_const_99); var tmp8 any = lang.IFn_Cast(pad__3).Invoke_O_O__O(Lit_11, A_arbace_box_build_A_const_100); var tmp9 any = lang.IFn_Cast(pad__3).Invoke_O_O__O(Lit_11, A_arbace_box_build_A_const_100); var tmp10 any = lang.IFn_Cast(pad__3).Invoke_O_O__O(Lit_12, A_arbace_box_build_A_const_101); var tmp11 lang.IFn = lang.IFn_Cast(pad__3); var tmp12 any; var root_565 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](data__1, jrt.Prim_byte.ArrayClass()))).Ref(); if linked_566 == nil { tmp12 = ifn_567.Invoke_O__O(arg_568) } else { tmp12 = linked_566.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_565, arg_568) }; hdr__4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11.Invoke_O_O__O(tmp12, A_arbace_box_build_A_const_102), nil)).Ref(); var o__5 any = /*line :158:1*/jrt.ByteArrayOutputStream_New();



	jrt.OutputStream_Cast(o__5).Write_B1__V(jrt.NN(jrt.String_Cast(hdr__4)).GetBytes_Charset__B1(jrt.StandardCharsets_US_ASCII));
	jrt.OutputStream_Cast(o__5).Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](data__1, jrt.Prim_byte.ArrayClass())); var tmp13 any; var root_569 any =
	A_arbace_box_build_A_const_103.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_odd_QMARK__A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](data__1, jrt.Prim_byte.ArrayClass()))).Ref(); if linked_570 == nil { tmp13 = ifn_571.Invoke_O__O(arg_572) } else { tmp13 = linked_570.(*aot_arbace_core.A_arbace_core_odd_QMARK__A).Invoke_O_O__O(root_569, arg_572) }; if jrt.J2g_Truth(tmp13) { jrt.NN(jrt.ByteArrayOutputStream_Cast(o__5)).Write_I__V(lang.RT_IntCast_J__I_NoInit(10)) }; return /*line :165:1*/ jrt.NN(jrt.ByteArrayOutputStream_Cast(o__5)).ToByteArray__B1().Ref() }
//line :159:1
func A_arbace_box_build_ar_member_pad__598000077_A_New() *A_arbace_box_build_ar_member_pad__598000077_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_ar_member_pad__598000077_A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_box_build_ar_member_pad__598000077_A) Ctor() {}
//line :159:1
func (t *A_arbace_box_build_ar_member_pad__598000077_A) Invoke_O_O_O__O(self, s__1, n__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_553 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_557 any; var root_548 any = A_arbace_box_build_A_const_96.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any; var na_543 any = n__2; var na_544 int64 = int64(lang.RT_Count_O__I_NoInit(s__1)); if jrt.Long_InstanceOf(na_543) { var n0_545 int64 = jrt.NN(jrt.Long_Cast(na_543)).LongValue__J(); var n1_546 int64 = na_544; var nr_547 int64 = n0_545 - n1_546; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_546 == -9223372036854775808); if tmp4 { tmp4 = (n0_545^n1_546)&(n0_545^nr_547) >= 0 }; tmp3 = tmp4; if tmp3 { arg_551 = jrt.Long_ValueOf_J__Long_NoInit(nr_547).Ref() } else { arg_551 = lang.Numbers_Minus_O_J__Number_NoInit(na_543, na_544) } } else { arg_551 = lang.Numbers_Minus_O_J__Number_NoInit(na_543, na_544) }; var arg_552 any = A_arbace_box_build_A_const_97; if linked_549 == nil { arg_557 = ifn_550.Invoke_O_O__O(arg_551, arg_552) } else { arg_557 = linked_549.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_548, arg_551, arg_552) }; if linked_554 == nil { tmp2 = ifn_555.Invoke_O_O__O(arg_556, arg_557) } else { tmp2 = linked_554.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_553, arg_556, arg_557) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, s__1, tmp2)).Ref() }







func A_arbace_box_build_append_members_A_New() *A_arbace_box_build_append_members_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_append_members_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_box_build_append_members_A) Ctor() {}
//line :167:1
func (t *A_arbace_box_build_append_members_A) Invoke_O_O_O__O(self, archive__0, members__1 any) any { var o__3 any = jrt.ByteArrayOutputStream_New();

	jrt.OutputStream_Cast(o__3).Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](archive__0, jrt.Prim_byte.ArrayClass())); var seq_598000080__4 any; var root_573 any = /*line :167:1*/A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_575 lang.IFn; if


	linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = members__1; if linked_574 == nil { seq_598000080__4 = ifn_575.Invoke_O__O(arg_576) } else { seq_598000080__4 = linked_574.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_573, arg_576) }; var chunk_598000081__5 any; var count_598000082__6 int64 = 0; var i_598000083__7 int64 = 0; L1:
//line :167:1
	for {


		if lang.Numbers_Lt_J_J__Z_NoInit(i_598000083__7, count_598000082__6) { var vec__598000084__8 any = lang.Indexed_Cast(chunk_598000081__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_598000083__7)); var n__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000084__8, lang.RT_IntCast_J__I_NoInit(0), nil); var data__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000084__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 jrt.OutputStream_I = jrt.OutputStream_Cast(o__3); var tmp2 any; var root_593 any = A_arbace_box_build_A_const_104.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, A_arbace_box_build_ar_member_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = n__9; var arg_597 any = data__10; if linked_594 == nil { tmp2 = ifn_595.Invoke_O_O__O(arg_596, arg_597) } else { tmp2 = linked_594.(*A_arbace_box_build_ar_member_A).Invoke_O_O_O__O(root_593, arg_596, arg_597) }; tmp1.Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](tmp2, jrt.Prim_byte.ArrayClass())); seq_598000080__4, chunk_598000081__5, count_598000082__6, i_598000083__7 = seq_598000080__4, chunk_598000081__5, count_598000082__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_598000083__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_577 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_579 lang.IFn; if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = seq_598000080__4; if linked_578 == nil { temp__1927000414__auto____8 = ifn_579.Invoke_O__O(arg_580) } else { temp__1927000414__auto____8 = linked_578.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_577, arg_580) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_598000080__9 any = temp__1927000414__auto____8; var tmp3 any; var root_581 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = seq_598000080__9; if linked_582 == nil { tmp3 = ifn_583.Invoke_O__O(arg_584) } else { tmp3 = linked_582.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_581, arg_584) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____10 any; var root_585 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = seq_598000080__9; if linked_586 == nil { c__1927000678__auto____10 = ifn_587.Invoke_O__O(arg_588) } else { c__1927000678__auto____10 = linked_586.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_585, arg_588) }; var tmp4 any; var root_598 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = seq_598000080__9; if linked_599 == nil { tmp4 = ifn_600.Invoke_O__O(arg_601) } else { tmp4 = linked_599.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_598, arg_601) }; seq_598000080__4, chunk_598000081__5, count_598000082__6, i_598000083__7 = tmp4, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__598000087__10 any; var root_589 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = seq_598000080__9; if linked_590 == nil { vec__598000087__10 = ifn_591.Invoke_O__O(arg_592) } else { vec__598000087__10 = linked_590.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_589, arg_592) }; var n__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000087__10, lang.RT_IntCast_J__I_NoInit(0), nil); var data__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000087__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 jrt.OutputStream_I = jrt.OutputStream_Cast(o__3); var tmp6 any; var root_602 any = A_arbace_box_build_A_const_104.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, A_arbace_box_build_ar_member_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = n__11; var arg_606 any = data__12; if linked_603 == nil { tmp6 = ifn_604.Invoke_O_O__O(arg_605, arg_606) } else { tmp6 = linked_603.(*A_arbace_box_build_ar_member_A).Invoke_O_O_O__O(root_602, arg_605, arg_606) }; tmp5.Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](tmp6, jrt.Prim_byte.ArrayClass())); var tmp7 any; var root_607 any = A_arbace_box_build_A_const_20.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = seq_598000080__9; if linked_608 == nil { tmp7 = ifn_609.Invoke_O__O(arg_610) } else { tmp7 = linked_608.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_607, arg_610) }; seq_598000080__4, chunk_598000081__5, count_598000082__6, i_598000083__7 = tmp7, nil, 0, 0; continue L1 } } }
//line :167:1
		break L1 }; return /*line :171:1*/ jrt.NN(jrt.ByteArrayOutputStream_Cast(o__3)).ToByteArray__B1().Ref() }






func A_arbace_box_build_complete_QMARK__A_New() *A_arbace_box_build_complete_QMARK__A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_complete_QMARK__A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_box_build_complete_QMARK__A) Ctor() {}
//line :178:1
func (t *A_arbace_box_build_complete_QMARK__A) Invoke_O_O__O(self, pkg__0 any) any { var and__1927000168__auto____2 any; var root_611 any = A_arbace_box_build_A_const_105.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_613 lang.IFn; if


	linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = A_arbace_box_build_A_const_106.Invoke_O__O(pkg__0); if linked_612 == nil { and__1927000168__auto____2 = ifn_613.Invoke_O__O(arg_614) } else { and__1927000168__auto____2 = linked_612.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_611, arg_614) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_615 any = A_arbace_box_build_A_const_73.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any; var and__1927000168__auto____3 any = A_arbace_box_build_A_const_93.Invoke_O__O(pkg__0); if jrt.J2g_Truth(and__1927000168__auto____3) { arg_618 = lang.IFn_Cast(A_arbace_box_build_A_const_107.GetRawRoot__O()).Invoke_O__O(A_arbace_box_build_A_const_91.Invoke_O__O(pkg__0)) } else { arg_618 = and__1927000168__auto____3 }; if linked_616 == nil { return ifn_617.Invoke_O__O(arg_618) } else { return linked_616.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_615, arg_618) } } else { return and__1927000168__auto____2 } }

func A_arbace_box_build_deps_tree_A_New() *A_arbace_box_build_deps_tree_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_box_build_deps_tree_A) Ctor() {}
//line :183:1
func (t *A_arbace_box_build_deps_tree_A) Invoke_O_O_O_O__O(self, archives__0, index__1, paths__2 any) any { var tmp1 any; var root_683 any = A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_685 lang.IFn; if



	linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any; var root_678 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_682 any; var iter__1927001039__auto____4 any; var tmp2 any = A_arbace_box_build_deps_tree_iter__598000092__598000096_A_New_O_O(archives__0, index__1); var tmp3 *jrt.Class; var fncls__677 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000092__598000096_A_fn_class; if fncls__677 == nil { var fncls__677d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_box_build_deps_tree_iter__598000092__598000096_A_fn_class = fncls__677d; tmp3 = fncls__677d } else { tmp3 = fncls__677 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); arg_682 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(paths__2); if linked_679 == nil { arg_686 = ifn_680.Invoke_O_O__O(arg_681, arg_682) } else { arg_686 = linked_679.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_678, arg_681, arg_682) }; if linked_684 == nil { tmp1 = ifn_685.Invoke_O__O(arg_686) } else { tmp1 = linked_684.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_683, arg_686) }; var tmp4 any = tmp1; var tmp5 any; var iter__1927001039__auto____4_2 any; var tmp6 any = /*line :183:1*/A_arbace_box_build_deps_tree_iter__598000102__598000106_A_New_O(index__1); var tmp7 *jrt.Class; var fncls__745 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000102__598000106_A_fn_class; if




	fncls__745 == nil { var fncls__745d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_box_build_deps_tree_iter__598000102__598000106_A_fn_class = fncls__745d; tmp7 = fncls__745d } else { tmp7 = fncls__745 }; iter__1927001039__auto____4_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); tmp5 = lang.IFn_Cast(iter__1927001039__auto____4_2).Invoke_O__O(paths__2); return /*line :183:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp4, tmp5) }



func A_arbace_box_build_deps_tree_iter__598000092__598000096_A_New_O_O(p0, p1 any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000092__598000096_A{}; t.Ctor_O_O(p0, p1); return t }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_A) Ctor_O_O(c__archives, c__index any) { t.F_archives = c__archives; t.F_index = c__index }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_A) Invoke_O_O__O(self, s__598000093__1 any) any { var tmp1 any = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_New_O_O_O_O(t.F_archives, t.F_index, self, s__598000093__1); var tmp2 *jrt.Class; var fncls__676 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_fn_class; if fncls__676 == nil { var fncls__676d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_fn_class = fncls__676d; tmp2 = fncls__676d } else { tmp2 = fncls__676 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :187:1
func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A) Ctor_O_O_O_O(c__archives, c__index, c__iter__598000092, c__s__598000093 any) { t.F_archives = c__archives; t.F_index = c__index; t.F_iter__598000092 = c__iter__598000092; t.F_s__598000093 = c__s__598000093 }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A) Invoke_O__O(self any) any { { var s__598000093__1 any; var t_ any = t.F_s__598000093; t.F_s__598000093 = nil; s__598000093__1 = t_; for { var temp__1927000414__auto____2 any; var root_619 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = s__598000093__1; if linked_620 == nil { temp__1927000414__auto____2 = ifn_621.Invoke_O__O(arg_622) } else { temp__1927000414__auto____2 = linked_620.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_619, arg_622) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000093__3 any = temp__1927000414__auto____2; var tmp1 any; var root_623 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_625 lang.IFn; if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = s__598000093__3; if linked_624 == nil { tmp1 = ifn_625.Invoke_O__O(arg_626) } else { tmp1 = linked_624.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_623, arg_626) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_627 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_629 lang.IFn; if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = s__598000093__3; if linked_628 == nil { c__1927001037__auto____4 = ifn_629.Invoke_O__O(arg_630) } else { c__1927001037__auto____4 = linked_628.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_627, arg_630) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000095__6 any; var root_631 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_632 == nil { b__598000095__6 = ifn_633.Invoke_O__O(arg_634) } else { b__598000095__6 = linked_632.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_631, arg_634) }; var tmp2 any = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_New_O_O_O_I_O(b__598000095__6, t.F_archives, t.F_index, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__640 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_fn_class; if fncls__640 == nil { var fncls__640d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_fn_class = fncls__640d; tmp3 = fncls__640d } else { tmp3 = fncls__640 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_649 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_651 lang.IFn; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any; var root_641 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_641, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_643 lang.IFn; if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = b__598000095__6; if linked_642 == nil { arg_652 = ifn_643.Invoke_O__O(arg_644) } else { arg_652 = linked_642.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_641, arg_644) }; var arg_653 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000092); var tmp5 any; var root_645 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = s__598000093__3; if linked_646 == nil { tmp5 = ifn_647.Invoke_O__O(arg_648) } else { tmp5 = linked_646.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_645, arg_648) }; arg_653 = tmp4.Invoke_O__O(tmp5); if linked_650 == nil { return ifn_651.Invoke_O_O__O(arg_652, arg_653) } else { return linked_650.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_649, arg_652, arg_653) } } else { var root_658 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any; var root_654 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_656 lang.IFn; if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = b__598000095__6; if linked_655 == nil { arg_661 = ifn_656.Invoke_O__O(arg_657) } else { arg_661 = linked_655.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_654, arg_657) }; var arg_662 any; if linked_659 == nil { return ifn_660.Invoke_O_O__O(arg_661, arg_662) } else { return linked_659.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_658, arg_661, arg_662) } } } else { var p__4 any; var root_663 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = s__598000093__3; if linked_664 == nil { p__4 = ifn_665.Invoke_O__O(arg_666) } else { p__4 = linked_664.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_663, arg_666) }; var a__5 any = lang.IFn_Cast(t.F_archives).Invoke_O__O(p__4); var root_671 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(t.F_index).Invoke_O__O(p__4), nil)).Ref(), a__5); var arg_675 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000092); var tmp7 any; var root_667 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = s__598000093__3; if linked_668 == nil { tmp7 = ifn_669.Invoke_O__O(arg_670) } else { tmp7 = linked_668.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_667, arg_670) }; arg_675 = tmp6.Invoke_O__O(tmp7); if linked_672 == nil { return ifn_673.Invoke_O_O__O(arg_674, arg_675) } else { return linked_672.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_671, arg_674, arg_675) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :187:1
func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A) Ctor_O_O_O_I_O(c__b__598000095, c__archives, c__index any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000095 = c__b__598000095; t.F_archives = c__archives; t.F_index = c__index; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A) Invoke_O__O(self any) any { { var i__598000094__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000094__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000094__1)); var a__3 any = lang.IFn_Cast(t.F_archives).Invoke_O__O(p__2); var root_635 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = t.F_b__598000095; var arg_639 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(t.F_index).Invoke_O__O(p__2), nil)).Ref(), a__3); if linked_636 == nil { ifn_637.Invoke_O_O__O(arg_638, arg_639) } else { linked_636.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_635, arg_638, arg_639) }; i__598000094__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000094__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_box_build_deps_tree_iter__598000102__598000106_A_New_O(p0 any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000102__598000106_A{}; t.Ctor_O(p0); return t }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_A) Ctor_O(c__index any) { t.F_index = c__index }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_A) Invoke_O_O__O(self, s__598000103__1 any) any { var tmp1 any = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_New_O_O_O(s__598000103__1, t.F_index, self); var tmp2 *jrt.Class; var fncls__744 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_fn_class; if fncls__744 == nil { var fncls__744d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_fn_class = fncls__744d; tmp2 = fncls__744d } else { tmp2 = fncls__744 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :188:1
func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A) Ctor_O_O_O(c__s__598000103, c__index, c__iter__598000102 any) { t.F_s__598000103 = c__s__598000103; t.F_index = c__index; t.F_iter__598000102 = c__iter__598000102 }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A) Invoke_O__O(self any) any { { var s__598000103__1 any; var t_ any = t.F_s__598000103; t.F_s__598000103 = nil; s__598000103__1 = t_; for { var temp__1927000414__auto____2 any; var root_687 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_689 lang.IFn; if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = s__598000103__1; if linked_688 == nil { temp__1927000414__auto____2 = ifn_689.Invoke_O__O(arg_690) } else { temp__1927000414__auto____2 = linked_688.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_687, arg_690) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000103__3 any = temp__1927000414__auto____2; var tmp1 any; var root_691 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = s__598000103__3; if linked_692 == nil { tmp1 = ifn_693.Invoke_O__O(arg_694) } else { tmp1 = linked_692.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_691, arg_694) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_695 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = s__598000103__3; if linked_696 == nil { c__1927001037__auto____4 = ifn_697.Invoke_O__O(arg_698) } else { c__1927001037__auto____4 = linked_696.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_695, arg_698) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000105__6 any; var root_699 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_700 == nil { b__598000105__6 = ifn_701.Invoke_O__O(arg_702) } else { b__598000105__6 = linked_700.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_699, arg_702) }; var tmp2 any = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_New_O_O_I_O(t.F_index, b__598000105__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__708 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_fn_class; if fncls__708 == nil { var fncls__708d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_fn_class = fncls__708d; tmp3 = fncls__708d } else { tmp3 = fncls__708 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_717 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any; var root_709 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = b__598000105__6; if linked_710 == nil { arg_720 = ifn_711.Invoke_O__O(arg_712) } else { arg_720 = linked_710.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_709, arg_712) }; var arg_721 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000102); var tmp5 any; var root_713 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_715 lang.IFn; if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = s__598000103__3; if linked_714 == nil { tmp5 = ifn_715.Invoke_O__O(arg_716) } else { tmp5 = linked_714.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_713, arg_716) }; arg_721 = tmp4.Invoke_O__O(tmp5); if linked_718 == nil { return ifn_719.Invoke_O_O__O(arg_720, arg_721) } else { return linked_718.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_717, arg_720, arg_721) } } else { var root_726 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_728 lang.IFn; if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any; var root_722 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_722, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_724 lang.IFn; if linked_723 == nil { ifn_724 = lang.IFn_Cast(root_722) } else { ifn_724 = nil }; var arg_725 any = b__598000105__6; if linked_723 == nil { arg_729 = ifn_724.Invoke_O__O(arg_725) } else { arg_729 = linked_723.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_722, arg_725) }; var arg_730 any; if linked_727 == nil { return ifn_728.Invoke_O_O__O(arg_729, arg_730) } else { return linked_727.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_726, arg_729, arg_730) } } } else { var p__4 any; var root_731 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_731, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_733 lang.IFn; if linked_732 == nil { ifn_733 = lang.IFn_Cast(root_731) } else { ifn_733 = nil }; var arg_734 any = s__598000103__3; if linked_732 == nil { p__4 = ifn_733.Invoke_O__O(arg_734) } else { p__4 = linked_732.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_731, arg_734) }; var root_739 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_741 lang.IFn; if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_97, nil, Lit_98, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, nil, p__4, nil, lang.IFn_Cast(t.F_index).Invoke_O__O(p__4), nil)).Ref(); var arg_743 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000102); var tmp7 any; var root_735 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_737 lang.IFn; if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = s__598000103__3; if linked_736 == nil { tmp7 = ifn_737.Invoke_O__O(arg_738) } else { tmp7 = linked_736.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_735, arg_738) }; arg_743 = tmp6.Invoke_O__O(tmp7); if linked_740 == nil { return ifn_741.Invoke_O_O__O(arg_742, arg_743) } else { return linked_740.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_739, arg_742, arg_743) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :188:1
func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A) Ctor_O_O_I_O(c__index, c__b__598000105 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_index = c__index; t.F_b__598000105 = c__b__598000105; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A) Invoke_O__O(self any) any { { var i__598000104__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000104__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000104__1)); var root_703 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = t.F_b__598000105; var arg_707 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_97, nil, Lit_98, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, nil, p__2, nil, lang.IFn_Cast(t.F_index).Invoke_O__O(p__2), nil)).Ref(); if linked_704 == nil { ifn_705.Invoke_O_O__O(arg_706, arg_707) } else { linked_704.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_703, arg_706, arg_707) }; i__598000104__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000104__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_box_build_json_str_A_New() *A_arbace_box_build_json_str_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_json_str_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_box_build_json_str_A) Ctor() {}
//line :190:1
func (t *A_arbace_box_build_json_str_A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_123, nil, Lit_123); var tmp2 any; var root_761 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_765 any; var root_756 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any; var tmp3 any = A_arbace_box_build_json_str_fn__598000113_A_New(); var tmp4 *jrt.Class; var fncls__755 *jrt.Class = A_arbace_box_build_json_str_fn__598000113_A_fn_class; if fncls__755 == nil { var fncls__755d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_box_build_json_str_fn__598000113_A_fn_class = fncls__755d; tmp4 = fncls__755d } else { tmp4 = fncls__755 }; arg_759 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_760 any = s__0; if linked_757 == nil { arg_765 = ifn_758.Invoke_O_O__O(arg_759, arg_760) } else { arg_765 = linked_757.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_756, arg_759, arg_760) }; if linked_762 == nil { tmp2 = ifn_763.Invoke_O_O__O(arg_764, arg_765) } else { tmp2 = linked_762.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_761, arg_764, arg_765) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil)).Ref() }
//line :193:1
func A_arbace_box_build_json_str_fn__598000113_A_New() *A_arbace_box_build_json_str_fn__598000113_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_json_str_fn__598000113_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_box_build_json_str_fn__598000113_A) Ctor() {}
//line :193:1
func (t *A_arbace_box_build_json_str_fn__598000113_A) Invoke_O_O__O(self, c__1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(c__1, A_arbace_box_build_A_const_109) { return Lit_125 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__1, A_arbace_box_build_A_const_110) { return Lit_126 } else { if lang.Numbers_Lt_J_J__Z_NoInit(int64(lang.RT_IntCast_O__I_NoInit(c__1)), 32) {
											return lang.IFn_Cast(A_arbace_box_build_A_const_77.GetRawRoot__O()).Invoke_O_O__O(Lit_127, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(c__1)).Ref()) } else {
//line :193:1
		if A_arbace_box_build_A_const_111 != nil {

			var root_751 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = c__1; if linked_752 == nil { return ifn_753.Invoke_O__O(arg_754) } else { return linked_752.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_751, arg_754) } } else {
//line :193:1
				return nil } } } } }





func A_arbace_box_build_embed_config_A_New() *A_arbace_box_build_embed_config_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_box_build_embed_config_A) Ctor() {}
//line :199:1
func (t *A_arbace_box_build_embed_config_A) Invoke_O_O__O(self, patterns__0 any) any { var files__2 any; var root_775 any = A_arbace_box_build_A_const_112.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_777 lang.IFn; if



	linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any; var root_771 any = A_arbace_box_build_A_const_113.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = lang.IFn_Cast(A_arbace_box_build_A_const_92.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_114.GetRawRoot__O(), patterns__0); if linked_772 == nil { arg_778 = ifn_773.Invoke_O__O(arg_774) } else { arg_778 = linked_772.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_771, arg_774) }; if linked_776 == nil { files__2 = ifn_777.Invoke_O__O(arg_778) } else { files__2 = linked_776.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_775, arg_778) }; var tmp1 /*line :204:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_99, nil, Lit_100, nil, Lit_101); var tmp2 any; var root_886 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_888 lang.IFn; if
	linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_890 any; var root_881 any = A_arbace_box_build_A_const_115.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = Lit_102; var arg_885 any; var iter__1927001039__auto____8 any; var tmp3 any = A_arbace_box_build_embed_config_iter__598000116__598000120_A_New(); var tmp4 *jrt.Class; var fncls__875 *jrt.Class = A_arbace_box_build_embed_config_iter__598000116__598000120_A_fn_class; if fncls__875 == nil { var fncls__875d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_box_build_embed_config_iter__598000116__598000120_A_fn_class = fncls__875d; tmp4 = fncls__875d } else { tmp4 = fncls__875 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp6 any; var root_876 any = A_arbace_box_build_A_const_117.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = A_arbace_box_build_A_const_118.GetRawRoot__O(); var arg_880 any = patterns__0; if linked_877 == nil { tmp6 = ifn_878.Invoke_O_O__O(arg_879, arg_880) } else { tmp6 = linked_877.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_876, arg_879, arg_880) }; arg_885 = tmp5.Invoke_O__O(tmp6); if linked_882 == nil { arg_890 = ifn_883.Invoke_O_O__O(arg_884, arg_885) } else { arg_890 = linked_882.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_881, arg_884, arg_885) }; if linked_887 == nil { tmp2 = ifn_888.Invoke_O_O__O(arg_889, arg_890) } else { tmp2 = linked_887.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_886, arg_889, arg_890) }; var tmp7 any = tmp2; var tmp8 any; var root_971 any = /*line :204:1*/A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_973 lang.IFn; if



	linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_975 any; var root_966 any = A_arbace_box_build_A_const_115.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_968 lang.IFn; if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any = Lit_102; var arg_970 any; var iter__1927001039__auto____8_2 any; var tmp9 any = A_arbace_box_build_embed_config_iter__598000132__598000136_A_New(); var tmp10 *jrt.Class; var fncls__965 *jrt.Class = A_arbace_box_build_embed_config_iter__598000132__598000136_A_fn_class; if fncls__965 == nil { var fncls__965d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_box_build_embed_config_iter__598000132__598000136_A_fn_class = fncls__965d; tmp10 = fncls__965d } else { tmp10 = fncls__965 }; iter__1927001039__auto____8_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); arg_970 = lang.IFn_Cast(iter__1927001039__auto____8_2).Invoke_O__O(files__2); if linked_967 == nil { arg_975 = ifn_968.Invoke_O_O__O(arg_969, arg_970) } else { arg_975 = linked_967.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_966, arg_969, arg_970) }; if linked_972 == nil { tmp8 = ifn_973.Invoke_O_O__O(arg_974, arg_975) } else { tmp8 = linked_972.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_971, arg_974, arg_975) }; return /*line :204:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, tmp8, nil)).Ref() }
func A_arbace_box_build_embed_config_iter__598000116__598000120_A_New() *A_arbace_box_build_embed_config_iter__598000116__598000120_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000116__598000120_A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_A) Ctor() {}
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_A) Invoke_O_O__O(self, s__598000117__1 any) any { var tmp1 any = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_New_O_O(self, s__598000117__1); var tmp2 *jrt.Class; var fncls__874 *jrt.Class = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_fn_class; if fncls__874 == nil { var fncls__874d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_fn_class = fncls__874d; tmp2 = fncls__874d } else { tmp2 = fncls__874 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :205:1
func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_New_O_O(p0, p1 any) *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A{}; t.Ctor_O_O(p0, p1); return t }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A) Ctor_O_O(c__iter__598000116, c__s__598000117 any) { t.F_iter__598000116 = c__iter__598000116; t.F_s__598000117 = c__s__598000117 }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A) Invoke_O__O(self any) any { { var s__598000117__1 any; var t_ any = t.F_s__598000117; t.F_s__598000117 = nil; s__598000117__1 = t_; for { var temp__1927000414__auto____2 any; var root_779 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = s__598000117__1; if linked_780 == nil { temp__1927000414__auto____2 = ifn_781.Invoke_O__O(arg_782) } else { temp__1927000414__auto____2 = linked_780.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_779, arg_782) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000117__3 any = temp__1927000414__auto____2; var tmp1 any; var root_783 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_785 lang.IFn; if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any = s__598000117__3; if linked_784 == nil { tmp1 = ifn_785.Invoke_O__O(arg_786) } else { tmp1 = linked_784.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_783, arg_786) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_787 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_789 lang.IFn; if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any = s__598000117__3; if linked_788 == nil { c__1927001037__auto____4 = ifn_789.Invoke_O__O(arg_790) } else { c__1927001037__auto____4 = linked_788.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_787, arg_790) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000119__6 any; var root_791 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_792 == nil { b__598000119__6 = ifn_793.Invoke_O__O(arg_794) } else { b__598000119__6 = linked_792.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_791, arg_794) }; var tmp2 any = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_New_O_I_O(b__598000119__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__819 *jrt.Class = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_fn_class; if fncls__819 == nil { var fncls__819d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_fn_class = fncls__819d; tmp3 = fncls__819d } else { tmp3 = fncls__819 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_828 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any; var root_820 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_822 lang.IFn; if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any = b__598000119__6; if linked_821 == nil { arg_831 = ifn_822.Invoke_O__O(arg_823) } else { arg_831 = linked_821.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_820, arg_823) }; var arg_832 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000116); var tmp5 any; var root_824 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_824, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_826 lang.IFn; if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = s__598000117__3; if linked_825 == nil { tmp5 = ifn_826.Invoke_O__O(arg_827) } else { tmp5 = linked_825.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_824, arg_827) }; arg_832 = tmp4.Invoke_O__O(tmp5); if linked_829 == nil { return ifn_830.Invoke_O_O__O(arg_831, arg_832) } else { return linked_829.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_828, arg_831, arg_832) } } else { var root_837 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any; var root_833 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_835 lang.IFn; if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = b__598000119__6; if linked_834 == nil { arg_840 = ifn_835.Invoke_O__O(arg_836) } else { arg_840 = linked_834.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_833, arg_836) }; var arg_841 any; if linked_838 == nil { return ifn_839.Invoke_O_O__O(arg_840, arg_841) } else { return linked_838.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_837, arg_840, arg_841) } } } else { var vec__598000127__4 any; var root_842 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_844 lang.IFn; if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any = s__598000117__3; if linked_843 == nil { vec__598000127__4 = ifn_844.Invoke_O__O(arg_845) } else { vec__598000127__4 = linked_843.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_842, arg_845) }; var p__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000127__4, lang.RT_IntCast_J__I_NoInit(0), nil); var fs__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000127__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_869 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_107, nil, Lit_108); var tmp7 any; var root_846 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, A_arbace_box_build_json_str_A_fn_class); var ifn_848 lang.IFn
														if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any = p__5; if linked_847 == nil { tmp7 = ifn_848.Invoke_O__O(arg_849) } else { tmp7 = linked_847.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_846, arg_849) }; var tmp8 any = tmp7; var tmp9 any; var root_860 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_864 any; var root_855 any = A_arbace_box_build_A_const_115.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any = Lit_102; var arg_859 any; var root_850 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var arg_854 any = fs__6; if linked_851 == nil { arg_859 = ifn_852.Invoke_O_O__O(arg_853, arg_854) } else { arg_859 = linked_851.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_850, arg_853, arg_854) }; if linked_856 == nil { arg_864 = ifn_857.Invoke_O_O__O(arg_858, arg_859) } else { arg_864 = linked_856.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_855, arg_858, arg_859) }; if linked_861 == nil { tmp9 = ifn_862.Invoke_O_O__O(arg_863, arg_864) } else { tmp9 = linked_861.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_860, arg_863, arg_864) }; arg_872 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9, nil)).Ref()
//line :205:1
	var arg_873 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__598000116); var tmp11 any; var root_865 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = s__598000117__3; if linked_866 == nil { tmp11 = ifn_867.Invoke_O__O(arg_868) } else { tmp11 = linked_866.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_865, arg_868) }; arg_873 = tmp10.Invoke_O__O(tmp11); if linked_870 == nil { return ifn_871.Invoke_O_O__O(arg_872, arg_873) } else { return linked_870.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_869, arg_872, arg_873) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :205:1
func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A) Ctor_O_I_O(c__b__598000119 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000119 = c__b__598000119; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A) Invoke_O__O(self any) any { { var i__598000118__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000118__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000123__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000118__1)); var p__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000123__2, lang.RT_IntCast_J__I_NoInit(0), nil); var fs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000123__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_814 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = t.F_b__598000119; var arg_818 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_107, nil, Lit_108); var tmp3 any; var root_795 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, A_arbace_box_build_json_str_A_fn_class); var ifn_797 lang.IFn
																if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = p__3; if linked_796 == nil { tmp3 = ifn_797.Invoke_O__O(arg_798) } else { tmp3 = linked_796.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_795, arg_798) }; var tmp4 any = tmp3; var tmp5 any; var root_809 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_813 any; var root_804 any = A_arbace_box_build_A_const_115.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_806 lang.IFn; if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = Lit_102; var arg_808 any; var root_799 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var arg_803 any = fs__4; if linked_800 == nil { arg_808 = ifn_801.Invoke_O_O__O(arg_802, arg_803) } else { arg_808 = linked_800.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_799, arg_802, arg_803) }; if linked_805 == nil { arg_813 = ifn_806.Invoke_O_O__O(arg_807, arg_808) } else { arg_813 = linked_805.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_804, arg_807, arg_808) }; if linked_810 == nil { tmp5 = ifn_811.Invoke_O_O__O(arg_812, arg_813) } else { tmp5 = linked_810.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_809, arg_812, arg_813) }; arg_818 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5, nil)).Ref()
//line :205:1
	if linked_815 == nil { ifn_816.Invoke_O_O__O(arg_817, arg_818) } else { linked_815.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_814, arg_817, arg_818) }; i__598000118__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000118__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_box_build_embed_config_iter__598000132__598000136_A_New() *A_arbace_box_build_embed_config_iter__598000132__598000136_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000132__598000136_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_A) Ctor() {}
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_A) Invoke_O_O__O(self, s__598000133__1 any) any { var tmp1 any = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_New_O_O(s__598000133__1, self); var tmp2 *jrt.Class; var fncls__964 *jrt.Class = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_fn_class; if fncls__964 == nil { var fncls__964d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_fn_class = fncls__964d; tmp2 = fncls__964d } else { tmp2 = fncls__964 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :208:1
func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_New_O_O(p0, p1 any) *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A{}; t.Ctor_O_O(p0, p1); return t }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A) Ctor_O_O(c__s__598000133, c__iter__598000132 any) { t.F_s__598000133 = c__s__598000133; t.F_iter__598000132 = c__iter__598000132 }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A) Invoke_O__O(self any) any { { var s__598000133__1 any; var t_ any = t.F_s__598000133; t.F_s__598000133 = nil; s__598000133__1 = t_; for { var temp__1927000414__auto____2 any; var root_891 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_893 lang.IFn; if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = s__598000133__1; if linked_892 == nil { temp__1927000414__auto____2 = ifn_893.Invoke_O__O(arg_894) } else { temp__1927000414__auto____2 = linked_892.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_891, arg_894) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000133__3 any = temp__1927000414__auto____2; var tmp1 any; var root_895 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = s__598000133__3; if linked_896 == nil { tmp1 = ifn_897.Invoke_O__O(arg_898) } else { tmp1 = linked_896.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_895, arg_898) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_899 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = s__598000133__3; if linked_900 == nil { c__1927001037__auto____4 = ifn_901.Invoke_O__O(arg_902) } else { c__1927001037__auto____4 = linked_900.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_899, arg_902) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000135__6 any; var root_903 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_904 == nil { b__598000135__6 = ifn_905.Invoke_O__O(arg_906) } else { b__598000135__6 = linked_904.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_903, arg_906) }; var tmp2 any = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_New_O_I_O(b__598000135__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__920 *jrt.Class = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_fn_class; if fncls__920 == nil { var fncls__920d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_fn_class = fncls__920d; tmp3 = fncls__920d } else { tmp3 = fncls__920 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_929 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_931 lang.IFn; if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any; var root_921 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any = b__598000135__6; if linked_922 == nil { arg_932 = ifn_923.Invoke_O__O(arg_924) } else { arg_932 = linked_922.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_921, arg_924) }; var arg_933 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000132); var tmp5 any; var root_925 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_927 lang.IFn; if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = s__598000133__3; if linked_926 == nil { tmp5 = ifn_927.Invoke_O__O(arg_928) } else { tmp5 = linked_926.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_925, arg_928) }; arg_933 = tmp4.Invoke_O__O(tmp5); if linked_930 == nil { return ifn_931.Invoke_O_O__O(arg_932, arg_933) } else { return linked_930.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_929, arg_932, arg_933) } } else { var root_938 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any; var root_934 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = b__598000135__6; if linked_935 == nil { arg_941 = ifn_936.Invoke_O__O(arg_937) } else { arg_941 = linked_935.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_934, arg_937) }; var arg_942 any; if linked_939 == nil { return ifn_940.Invoke_O_O__O(arg_941, arg_942) } else { return linked_939.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_938, arg_941, arg_942) } } } else { var f__4 any; var root_943 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = s__598000133__3; if linked_944 == nil { f__4 = ifn_945.Invoke_O__O(arg_946) } else { f__4 = linked_944.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_943, arg_946) }; var root_959 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_111, nil); var tmp7 any; var root_947 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_947, A_arbace_box_build_json_str_A_fn_class); var ifn_949 lang.IFn; if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any = f__4; if linked_948 == nil { tmp7 = ifn_949.Invoke_O__O(arg_950) } else { tmp7 = linked_948.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_947, arg_950) }; var tmp8 any = tmp7; var tmp9 any; var root_951 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, A_arbace_box_build_json_str_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__4)).Ref(); if linked_952 == nil { tmp9 = ifn_953.Invoke_O__O(arg_954) } else { tmp9 = linked_952.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_951, arg_954) }; arg_962 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_963 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__598000132); var tmp11 any; var root_955 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_955, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = s__598000133__3; if linked_956 == nil { tmp11 = ifn_957.Invoke_O__O(arg_958) } else { tmp11 = linked_956.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_955, arg_958) }; arg_963 = tmp10.Invoke_O__O(tmp11); if linked_960 == nil { return ifn_961.Invoke_O_O__O(arg_962, arg_963) } else { return linked_960.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_959, arg_962, arg_963) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :208:1
func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A) Ctor_O_I_O(c__b__598000135 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000135 = c__b__598000135; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A) Invoke_O__O(self any) any { { var i__598000134__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000134__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000134__1)); var root_915 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_917 lang.IFn; if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any = t.F_b__598000135; var arg_919 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_111, nil); var tmp3 any; var root_907 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, A_arbace_box_build_json_str_A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = f__2; if linked_908 == nil { tmp3 = ifn_909.Invoke_O__O(arg_910) } else { tmp3 = linked_908.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_907, arg_910) }; var tmp4 any = tmp3; var tmp5 any; var root_911 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, A_arbace_box_build_json_str_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__2)).Ref(); if linked_912 == nil { tmp5 = ifn_913.Invoke_O__O(arg_914) } else { tmp5 = linked_912.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_911, arg_914) }; arg_919 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref(); if linked_916 == nil { ifn_917.Invoke_O_O__O(arg_918, arg_919) } else { linked_916.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_915, arg_918, arg_919) }; i__598000134__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000134__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_box_build_build_package_A_New() *A_arbace_box_build_build_package_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_box_build_build_package_A) Ctor() {}
//line :211:1
func (t *A_arbace_box_build_build_package_A) Invoke_O_O_O_O_O__O(self, plan__0, pkg__1, archives__2, index__3 any) any { var map__598000145__5 any = A_arbace_box_build_A_const_49.Get__O(); var map__598000145__6 any; if


	lang.ISeq_InstanceOf(map__598000145__5) { var tmp1 any; var root_976 any = A_arbace_box_build_A_const_20.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = map__598000145__5; if linked_977 == nil { tmp1 = ifn_978.Invoke_O__O(arg_979) } else { tmp1 = linked_977.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_976, arg_979) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_980 any = A_arbace_box_build_A_const_119.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = map__598000145__5; if linked_981 == nil { tmp2 = ifn_982.Invoke_O__O(arg_983) } else { tmp2 = linked_981.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_980, arg_983) }; map__598000145__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_984 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = map__598000145__5; if linked_985 == nil { tmp3 = ifn_986.Invoke_O__O(arg_987) } else { tmp3 = linked_985.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_984, arg_987) }; if jrt.J2g_Truth(tmp3) { var root_988 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = map__598000145__5; if linked_989 == nil { map__598000145__6 = ifn_990.Invoke_O__O(arg_991) } else { map__598000145__6 = linked_989.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_988, arg_991) } } else { map__598000145__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__598000145__6 = map__598000145__5 }; var tools__7 any = /*line :211:1*/lang.RT_Get_O_O__O_NoInit(map__598000145__6, A_arbace_box_build_A_const_120); var P__8_ any = A_arbace_box_build_A_const_91.Invoke_O__O(pkg__1); var imports__9 any = A_arbace_box_build_A_const_121.Invoke_O__O(pkg__1); var vec__598000147__10 any; var root_992 any = A_arbace_box_build_A_const_122.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, A_arbace_box_build_deps_tree_A_fn_class); var ifn_994 lang.IFn; if





	linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = archives__2; var arg_996 any = index__3; var arg_997 any = imports__9; if linked_993 == nil { vec__598000147__10 = ifn_994.Invoke_O_O_O__O(arg_995, arg_996, arg_997) } else { vec__598000147__10 = linked_993.(*A_arbace_box_build_deps_tree_A).Invoke_O_O_O_O__O(root_992, arg_995, arg_996, arg_997) }; var dtree__11 any = /*line :211:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__598000147__10, lang.RT_IntCast_J__I_NoInit(0), nil); var lines__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000147__10, lang.RT_IntCast_J__I_NoInit(1), nil); var importcfg__13 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil, nil); var tmp5 any; var root_1061 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1063 lang.IFn; if







	linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_1065 any; var iter__1927001039__auto____16 any; var tmp6 any = A_arbace_box_build_build_package_iter__598000150__598000154_A_New(); var tmp7 *jrt.Class; var fncls__1056 *jrt.Class = A_arbace_box_build_build_package_iter__598000150__598000154_A_fn_class; if fncls__1056 == nil { var fncls__1056d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_box_build_build_package_iter__598000150__598000154_A_fn_class = fncls__1056d; tmp7 = fncls__1056d } else { tmp7 = fncls__1056 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____16); var tmp9 any; var root_1057 any = A_arbace_box_build_A_const_112.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = A_arbace_box_build_A_const_123.Invoke_O__O(pkg__1); if linked_1058 == nil { tmp9 = ifn_1059.Invoke_O__O(arg_1060) } else { tmp9 = linked_1058.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1057, arg_1060) }; arg_1065 = tmp8.Invoke_O__O(tmp9); if linked_1062 == nil { tmp5 = ifn_1063.Invoke_O_O__O(arg_1064, arg_1065) } else { tmp5 = linked_1062.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1061, arg_1064, arg_1065) }; var tmp10 any = tmp5; var tmp11 any; var root_1125 any = /*line :218:1*/A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1127 lang.IFn; if

	linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_1129 any; var iter__1927001039__auto____16_2 any; var tmp12 any = A_arbace_box_build_build_package_iter__598000166__598000170_A_New(); var tmp13 *jrt.Class; var fncls__1124 *jrt.Class = A_arbace_box_build_build_package_iter__598000166__598000170_A_fn_class; if fncls__1124 == nil { var fncls__1124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_box_build_build_package_iter__598000166__598000170_A_fn_class = fncls__1124d; tmp13 = fncls__1124d } else { tmp13 = fncls__1124 }; iter__1927001039__auto____16_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); arg_1129 = lang.IFn_Cast(iter__1927001039__auto____16_2).Invoke_O__O(lines__12); if linked_1126 == nil { tmp11 = ifn_1127.Invoke_O_O__O(arg_1128, arg_1129) } else { tmp11 = linked_1126.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1125, arg_1128, arg_1129) }; importcfg__13 = /*line :218:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, tmp11)).Ref(); var sfiles__14 any = /*line :211:1*/A_arbace_box_build_A_const_106.Invoke_O__O(pkg__1); var res_of__15 any; var tmp14 any = A_arbace_box_build_build_package_res_of__598000176_A_New_O(P__8_); var tmp15 *jrt.Class; var fncls__1140 *jrt.Class = A_arbace_box_build_build_package_res_of__598000176_A_fn_class; if










	fncls__1140 == nil { var fncls__1140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_box_build_build_package_res_of__598000176_A_fn_class = fncls__1140d; tmp15 = fncls__1140d } else { tmp15 = fncls__1140 }; res_of__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var rsc__16 any; var tmp16 /*line :211:1*/*lang.Keyword = A_arbace_box_build_A_const_126; var or__1927000174__auto____16 any = lang.RT_Get_O_O__O_NoInit(tmp16.Invoke_O__O(A_arbace_box_build_A_const_49.Get__O()), P__8_); if














	jrt.J2g_Truth(or__1927000174__auto____16) { rsc__16 = or__1927000174__auto____16 } else {
		var root_1174 any = A_arbace_box_build_A_const_127.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1176 lang.IFn; if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any; var tmp17 any = A_arbace_box_build_build_package_fn__598000179_A_New_O(P__8_); var tmp18 *jrt.Class; var fncls__1161 *jrt.Class = A_arbace_box_build_build_package_fn__598000179_A_fn_class; if fncls__1161 == nil { var fncls__1161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_box_build_build_package_fn__598000179_A_fn_class = fncls__1161d; tmp18 = fncls__1161d } else { tmp18 = fncls__1161 }; arg_1177 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var arg_1178 any; var root_1169 any = A_arbace_box_build_A_const_117.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1171 lang.IFn


		if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = lang.IFn_Cast(A_arbace_box_build_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_box_build_A_const_131.GetRawRoot__O(), A_arbace_box_build_A_const_132.GetRawRoot__O(), A_arbace_box_build_A_const_14.GetRawRoot__O(), A_arbace_box_build_A_const_118.GetRawRoot__O()); var tmp19 *lang.Keyword = A_arbace_box_build_A_const_126; var arg_1173 any = tmp19.Invoke_O__O(A_arbace_box_build_A_const_49.Get__O()); if linked_1170 == nil { arg_1178 = ifn_1171.Invoke_O_O__O(arg_1172, arg_1173) } else { arg_1178 = linked_1170.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1169, arg_1172, arg_1173) }
//line :227:1
		if linked_1175 == nil { rsc__16 = ifn_1176.Invoke_O_O__O(arg_1177, arg_1178) } else { rsc__16 = linked_1175.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1174, arg_1177, arg_1178) } }; var ___17 any; var tmp20 any; var and__1927000168__auto____17 any = /*line :211:1*/A_arbace_box_build_A_const_133.Invoke_O__O(pkg__1); _ = ___17; if



















	jrt.J2g_Truth(and__1927000168__auto____17) { var root_1179 any = A_arbace_box_build_A_const_73.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any = A_arbace_box_build_A_const_134.Invoke_O__O(pkg__1); if linked_1180 == nil { tmp20 = ifn_1181.Invoke_O__O(arg_1182) } else { tmp20 = linked_1180.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1179, arg_1182) } } else { tmp20 = and__1927000168__auto____17 }; if jrt.J2g_Truth(tmp20) {
		var root_1183 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1183, A_arbace_box_build_fail_A_fn_class); var ifn_1185 lang.IFn; if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_1, nil, Lit_50), jrt.RefArrayOf(jrt.Object_class, nil, P__8_, nil)).Ref(); var arg_1187 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_91, P__8_)); if linked_1184 == nil { ___17 = ifn_1185.Invoke_O_O__O(arg_1186, arg_1187) } else { ___17 = linked_1184.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_1183, arg_1186, arg_1187) } } else {
//line :231:1
			___17 = nil }; var embedcfg__18 any; var tmp21 /*line :211:1*/*lang.Keyword = A_arbace_box_build_A_const_135; var temp__1927000414__auto____18 any = tmp21.Invoke_O__O(A_arbace_box_build_A_const_134.Invoke_O__O(pkg__1)); if





















	jrt.J2g_Truth(temp__1927000414__auto____18) { var pats__19 any = temp__1927000414__auto____18; var root_1188 any = A_arbace_box_build_A_const_136.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, A_arbace_box_build_embed_config_A_fn_class); var ifn_1190 lang.IFn
		if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any = pats__19; if linked_1189 == nil { embedcfg__18 = ifn_1190.Invoke_O__O(arg_1191) } else { embedcfg__18 = linked_1189.(*A_arbace_box_build_embed_config_A).Invoke_O_O__O(root_1188, arg_1191) } } else {
//line :233:1
			embedcfg__18 = nil }; var symabis__19 any; var tmp22 any; var root_1192 any = /*line :211:1*/A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1194 lang.IFn; if























	linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any = sfiles__14; if linked_1193 == nil { tmp22 = ifn_1194.Invoke_O__O(arg_1195) } else { tmp22 = linked_1193.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1192, arg_1195) }; if jrt.J2g_Truth(tmp22) {
		var root_1218 any = A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_1219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1218, A_arbace_box_build_out_file_A_fn_class); var ifn_1220 lang.IFn; if linked_1219 == nil { ifn_1220 = lang.IFn_Cast(root_1218) } else { ifn_1220 = nil }; var arg_1221 any; var tmp23 lang.IFn = lang.IFn_Cast(res_of__15); var tmp24 any = A_arbace_box_build_A_const_138; var tmp25 any = A_arbace_box_build_A_const_139.Invoke_O__O(tools__7); var tmp26 any = A_arbace_box_build_A_const_78; var tmp27 any; var root_1209 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1211 lang.IFn

		if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any = lang.IFn_Cast(A_arbace_box_build_A_const_140.GetRawRoot__O()).Invoke_O_O_O_O__O(plan__0, pkg__1, Lit_52, Lit_53); var arg_1213 any; var root_1204 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any; var tmp28 any = A_arbace_box_build_build_package_fn__598000184_A_New(); var tmp29 *jrt.Class; var fncls__1203 *jrt.Class = A_arbace_box_build_build_package_fn__598000184_A_fn_class; if fncls__1203 == nil { var fncls__1203d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_box_build_build_package_fn__598000184_A_fn_class = fncls__1203d; tmp29 = fncls__1203d } else { tmp29 = fncls__1203 }; arg_1207 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); var arg_1208 any = sfiles__14; if linked_1205 == nil { arg_1213 = ifn_1206.Invoke_O_O__O(arg_1207, arg_1208) } else { arg_1213 = linked_1205.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1204, arg_1207, arg_1208) }; if linked_1210 == nil { tmp27 = ifn_1211.Invoke_O_O__O(arg_1212, arg_1213) } else { tmp27 = linked_1210.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1209, arg_1212, arg_1213) }
//line :236:1
		var tmp30 any = tmp27; var tmp31 any = A_arbace_box_build_A_const_141; var tmp32 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_55, A_arbace_box_build_A_const_44.Invoke_O__O(pkg__1)); var tmp33 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_40, A_arbace_box_build_A_const_39.Invoke_O__O(plan__0)); var tmp34 any; var root_1214 any = A_arbace_box_build_A_const_142.GetRawRoot__O(); var linked_1215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1214, A_arbace_box_build_file_tree_A_fn_class); var ifn_1216 lang.IFn


		if linked_1215 == nil { ifn_1216 = lang.IFn_Cast(root_1214) } else { ifn_1216 = nil }; var arg_1217 any = A_arbace_box_build_A_const_143; if linked_1215 == nil { tmp34 = ifn_1216.Invoke_O__O(arg_1217) } else { tmp34 = linked_1215.(*A_arbace_box_build_file_tree_A).Invoke_O_O__O(root_1214, arg_1217) }
//line :236:1
		arg_1221 = tmp23.Invoke_O_O__O(Lit_51, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp24, tmp25, tmp26, tmp30, tmp31, lang.Tuple_Create_O_O_O__IPersistentVector(tmp32, tmp33, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp34))))); var arg_1222 any = P__8_; var arg_1223 any = Lit_51; if linked_1219 == nil { symabis__19 = ifn_1220.Invoke_O_O_O__O(arg_1221, arg_1222, arg_1223) } else { symabis__19 = linked_1219.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_1218, arg_1221, arg_1222, arg_1223) } } else {
//line :235:1
			symabis__19 = nil }; var compile__20 any; var tmp35 lang.IFn = /*line :211:1*/lang.IFn_Cast(res_of__15); var tmp36 any; var root_1526 any = A_arbace_box_build_A_const_124.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1526, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_1528 lang.IFn; if






























	linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any; var tmp37 any = A_arbace_box_build_A_const_138; var tmp38 any = A_arbace_box_build_A_const_149.Invoke_O__O(tools__7); var tmp39 any = A_arbace_box_build_A_const_78; var tmp40 any; var root_1485 any = A_arbace_box_build_A_const_90.GetRawRoot__O(); var linked_1486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1485, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1487 lang.IFn; if

	linked_1486 == nil { ifn_1487 = lang.IFn_Cast(root_1485) } else { ifn_1487 = nil }; var arg_1488 any; var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_86.GetRawRoot__O()); var tmp42 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_36, nil, Lit_59), jrt.RefArrayOf(jrt.Object_class, nil, P__8_, nil)).Ref(); var tmp43 any; if
	lang.Util_Equiv_O_O__Z_NoInit(Lit_60, A_arbace_box_build_A_const_150.Invoke_O__O(pkg__1)) { tmp43 = Lit_60 } else { tmp43 = P__8_ }; var tmp44 any = /*line :244:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_57, Lit_42, Lit_58, Lit_35, tmp42, Lit_34, tmp43, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_151.Invoke_O__O(pkg__1))).Ref())); var tmp45 any; if

	jrt.J2g_Truth(A_arbace_box_build_A_const_93.Invoke_O__O(pkg__1)) { tmp45 = A_arbace_box_build_A_const_152 } else { tmp45 = nil }; var tmp46 any = tmp45; var tmp47 any; var tmp48 any; var root_1463 any = /*line :244:1*/A_arbace_box_build_A_const_153.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, A_arbace_box_build_complete_QMARK__A_fn_class); var ifn_1465 lang.IFn; if


	linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = pkg__1; if linked_1464 == nil { tmp48 = ifn_1465.Invoke_O__O(arg_1466) } else { tmp48 = linked_1464.(*A_arbace_box_build_complete_QMARK__A).Invoke_O_O__O(root_1463, arg_1466) }; if jrt.J2g_Truth(tmp48) { tmp47 = A_arbace_box_build_A_const_154 } else { tmp47 = nil }; var tmp49 any = tmp47; var tmp50 any = A_arbace_box_build_A_const_155; var tmp51 any; if

	jrt.J2g_Truth(symabis__19) { tmp51 = A_arbace_box_build_A_const_156 } else { tmp51 = nil }; var tmp52 any = tmp51; var tmp53 any = A_arbace_box_build_A_const_157; var tmp54 any; if

	jrt.J2g_Truth(embedcfg__18) { tmp54 = A_arbace_box_build_A_const_158 } else { tmp54 = nil }; var tmp55 any = tmp54; var tmp56 any; if
	jrt.J2g_Truth(symabis__19) { tmp56 = A_arbace_box_build_A_const_159 } else { tmp56 = nil }; var tmp57 any = tmp56; var tmp58 any; var root_1468 any = /*line :244:1*/A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1469 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1468, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1470 lang.IFn; if








	linked_1469 == nil { ifn_1470 = lang.IFn_Cast(root_1468) } else { ifn_1470 = nil }; var arg_1471 any; var tmp59 any = A_arbace_box_build_build_package_fn__598000186_A_New(); var tmp60 *jrt.Class; var fncls__1467 *jrt.Class = A_arbace_box_build_build_package_fn__598000186_A_fn_class; if fncls__1467 == nil { var fncls__1467d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_box_build_build_package_fn__598000186_A_fn_class = fncls__1467d; tmp60 = fncls__1467d } else { tmp60 = fncls__1467 }; arg_1471 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp59, tmp60, nil); var arg_1472 any = A_arbace_box_build_A_const_160.Invoke_O__O(pkg__1); if linked_1469 == nil { tmp58 = ifn_1470.Invoke_O_O__O(arg_1471, arg_1472) } else { tmp58 = linked_1469.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1468, arg_1471, arg_1472) }; arg_1488 = /*line :244:1*/tmp41.Invoke_O_O_O_O_O_O_O_O_O__O(tmp44, tmp46, tmp49, tmp50, tmp52, tmp53, tmp55, tmp57, tmp58); if linked_1486 == nil { tmp40 = ifn_1487.Invoke_O__O(arg_1488) } else { tmp40 = linked_1486.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1485, arg_1488) }; var tmp61 any = tmp40; var tmp62 any = A_arbace_box_build_A_const_141; var tmp63 any; var root_1517 any = /*line :242:1*/A_arbace_box_build_A_const_90.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1519 lang.IFn; if











	linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any; var root_1513 any = A_arbace_box_build_A_const_86.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1515 lang.IFn; if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any; var tmp64 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_55, A_arbace_box_build_A_const_44.Invoke_O__O(pkg__1)); var tmp65 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_63, dtree__11); var tmp66 any; var root_1509 any = A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_1511 lang.IFn; if
	linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any; var G__598000188__20_ any; var tmp67 any; var root_1489 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1489, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_1491 lang.IFn; if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any = importcfg__13; if linked_1490 == nil { tmp67 = ifn_1491.Invoke_O__O(arg_1492) } else { tmp67 = linked_1490.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_1489, arg_1492) }; G__598000188__20_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_64, tmp67)); var G__598000188__21_ any; if jrt.J2g_Truth(symabis__19) {
		var root_1493 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1493, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1495 lang.IFn; if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any = G__598000188__20_; var arg_1497 any = Lit_51; var arg_1498 any = symabis__19; if linked_1494 == nil { G__598000188__21_ = ifn_1495.Invoke_O_O_O__O(arg_1496, arg_1497, arg_1498) } else { G__598000188__21_ = linked_1494.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1493, arg_1496, arg_1497, arg_1498) } } else {
//line :255:1
			G__598000188__21_ = G__598000188__20_ }; if jrt.J2g_Truth(embedcfg__18) {

				var root_1503 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_1504 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1503, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1505 lang.IFn; if linked_1504 == nil { ifn_1505 = lang.IFn_Cast(root_1503) } else { ifn_1505 = nil }; var arg_1506 any = G__598000188__21_; var arg_1507 any = Lit_65; var arg_1508 any; var root_1499 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_1500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1499, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_1501 lang.IFn; if linked_1500 == nil { ifn_1501 = lang.IFn_Cast(root_1499) } else { ifn_1501 = nil }; var arg_1502 any = embedcfg__18; if linked_1500 == nil { arg_1508 = ifn_1501.Invoke_O__O(arg_1502) } else { arg_1508 = linked_1500.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_1499, arg_1502) }; if linked_1504 == nil { arg_1512 = ifn_1505.Invoke_O_O_O__O(arg_1506, arg_1507, arg_1508) } else { arg_1512 = linked_1504.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1503, arg_1506, arg_1507, arg_1508) } } else {
//line :255:1
					arg_1512 = G__598000188__21_ }; if linked_1510 == nil { tmp66 = ifn_1511.Invoke_O__O(arg_1512) } else { tmp66 = linked_1510.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_1509, arg_1512) }; arg_1516 = /*line :254:1*/lang.Tuple_Create_O_O_O__IPersistentVector(tmp64, tmp65, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp66)); if linked_1514 == nil { arg_1520 = ifn_1515.Invoke_O__O(arg_1516) } else { arg_1520 = linked_1514.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_1513, arg_1516) }; if linked_1518 == nil { tmp63 = ifn_1519.Invoke_O__O(arg_1520) } else { tmp63 = linked_1518.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1517, arg_1520) }; arg_1529 = /*line :242:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp38, tmp39, tmp61, tmp62, tmp63)); var arg_1530 any; var root_1521 any = A_arbace_box_build_A_const_161.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1521, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1523 lang.IFn; if















	linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1524 any = rsc__16; var arg_1525 any = A_arbace_box_build_A_const_162; if linked_1522 == nil { arg_1530 = ifn_1523.Invoke_O_O__O(arg_1524, arg_1525) } else { arg_1530 = linked_1522.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1521, arg_1524, arg_1525) }; if /*line :242:1*/ linked_1527 == nil { tmp36 = ifn_1528.Invoke_O_O__O(arg_1529, arg_1530) } else { tmp36 = linked_1527.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_1526, arg_1529, arg_1530) }; compile__20 = /*line :241:1*/tmp35.Invoke_O_O__O(Lit_57, tmp36); var archive__21 any; var root_1224 any = /*line :211:1*/A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, A_arbace_box_build_out_file_A_fn_class); var ifn_1226 lang.IFn; if















































	linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = compile__20; var arg_1228 any = P__8_; var arg_1229 any = Lit_66; if linked_1225 == nil { archive__21 = ifn_1226.Invoke_O_O_O__O(arg_1227, arg_1228, arg_1229) } else { archive__21 = linked_1225.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_1224, arg_1227, arg_1228, arg_1229) }; var tmp68 any; var root_1230 any =
	A_arbace_box_build_A_const_105.GetRawRoot__O(); var linked_1231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1230, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1232 lang.IFn; if linked_1231 == nil { ifn_1232 = lang.IFn_Cast(root_1230) } else { ifn_1232 = nil }; var arg_1233 any = sfiles__14; if linked_1231 == nil { tmp68 = ifn_1232.Invoke_O__O(arg_1233) } else { tmp68 = linked_1231.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1230, arg_1233) }; if jrt.J2g_Truth(tmp68) { return archive__21 } else { var asmh__22 any; var root_1234 any = A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, A_arbace_box_build_out_file_A_fn_class); var ifn_1236 lang.IFn

		if linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any = compile__20; var arg_1238 any = P__8_; var arg_1239 any = Lit_67; if linked_1235 == nil { asmh__22 = ifn_1236.Invoke_O_O_O__O(arg_1237, arg_1238, arg_1239) } else { asmh__22 = linked_1235.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_1234, arg_1237, arg_1238, arg_1239) }
//line :260:1
		var ctree__23 any; var root_1240 any = A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_1242 lang.IFn


		if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_67, asmh__22)); if linked_1241 == nil { ctree__23 = ifn_1242.Invoke_O__O(arg_1243) } else { ctree__23 = linked_1241.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_1240, arg_1243) }
//line :260:1
		var objs__24 any; var root_1359 any = A_arbace_box_build_A_const_144.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_1361 lang.IFn



		if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any; var iter__1927001039__auto____24 any; var tmp69 any = A_arbace_box_build_build_package_iter__598000189__598000193_A_New_O_O_O_O_O_O(res_of__15, P__8_, plan__0, ctree__23, pkg__1, tools__7); var tmp70 *jrt.Class; var fncls__1358 *jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_A_fn_class
		if fncls__1358 == nil { var fncls__1358d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_box_build_build_package_iter__598000189__598000193_A_fn_class = fncls__1358d; tmp70 = fncls__1358d } else { tmp70 = fncls__1358 }; iter__1927001039__auto____24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp69, tmp70, nil); arg_1362 = lang.IFn_Cast(iter__1927001039__auto____24).Invoke_O__O(sfiles__14)
//line :264:1
		if linked_1360 == nil { objs__24 = ifn_1361.Invoke_O__O(arg_1362) } else { objs__24 = linked_1360.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_1359, arg_1362) }
//line :260:1
		var members__25 any; var iter__1927001039__auto____25 any; var tmp71 any = A_arbace_box_build_build_package_iter__598000203__598000207_A_New(); var tmp72 *jrt.Class
		var fncls__1445 /*line :260:1*/*jrt.Class = A_arbace_box_build_build_package_iter__598000203__598000207_A_fn_class












		if fncls__1445 == nil { var fncls__1445d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_box_build_build_package_iter__598000203__598000207_A_fn_class = fncls__1445d; tmp72 = fncls__1445d } else { tmp72 = fncls__1445 }; iter__1927001039__auto____25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp71, tmp72, nil); members__25 = lang.IFn_Cast(iter__1927001039__auto____25).Invoke_O__O(objs__24)
		var root_1459 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_1460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1459, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_1461 lang.IFn; if linked_1460 == nil { ifn_1461 = lang.IFn_Cast(root_1459) } else { ifn_1461 = nil }; var arg_1462 any; var root_1454 any = A_arbace_box_build_A_const_148.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1454, A_arbace_box_build_append_members_A_fn_class); var ifn_1456 lang.IFn; if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any; var root_1450 any = A_arbace_box_build_A_const_146.GetRawRoot__O(); var linked_1451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1450, aot_arbace_box.A_arbace_box_get_bytes_A_fn_class); var ifn_1452 lang.IFn; if linked_1451 == nil { ifn_1452 = lang.IFn_Cast(root_1450) } else { ifn_1452 = nil }; var arg_1453 any; var root_1446 any = A_arbace_box_build_A_const_147.GetRawRoot__O(); var linked_1447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1446, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1448 lang.IFn; if linked_1447 == nil { ifn_1448 = lang.IFn_Cast(root_1446) } else { ifn_1448 = nil }; var arg_1449 any = archive__21; if linked_1447 == nil { arg_1453 = ifn_1448.Invoke_O__O(arg_1449) } else { arg_1453 = linked_1447.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1446, arg_1449) }; if linked_1451 == nil { arg_1457 = ifn_1452.Invoke_O__O(arg_1453) } else { arg_1457 = linked_1451.(*aot_arbace_box.A_arbace_box_get_bytes_A).Invoke_O_O__O(root_1450, arg_1453) }; var arg_1458 any = members__25; if linked_1455 == nil { arg_1462 = ifn_1456.Invoke_O_O__O(arg_1457, arg_1458) } else { arg_1462 = linked_1455.(*A_arbace_box_build_append_members_A).Invoke_O_O_O__O(root_1454, arg_1457, arg_1458) }; if linked_1460 == nil { return ifn_1461.Invoke_O__O(arg_1462) } else { return linked_1460.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_1459, arg_1462) } } }
//line :219:1
func A_arbace_box_build_build_package_iter__598000150__598000154_A_New() *A_arbace_box_build_build_package_iter__598000150__598000154_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000150__598000154_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_A) Ctor() {}
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_A) Invoke_O_O__O(self, s__598000151__1 any) any { var tmp1 any = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_New_O_O(self, s__598000151__1); var tmp2 *jrt.Class; var fncls__1055 *jrt.Class = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_fn_class; if fncls__1055 == nil { var fncls__1055d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_fn_class = fncls__1055d; tmp2 = fncls__1055d } else { tmp2 = fncls__1055 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :219:1
func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_New_O_O(p0, p1 any) *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A{}; t.Ctor_O_O(p0, p1); return t }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A) Ctor_O_O(c__iter__598000150, c__s__598000151 any) { t.F_iter__598000150 = c__iter__598000150; t.F_s__598000151 = c__s__598000151 }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A) Invoke_O__O(self any) any { { var s__598000151__1 any; var t_ any = t.F_s__598000151; t.F_s__598000151 = nil; s__598000151__1 = t_; for { var temp__1927000414__auto____2 any; var root_998 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = s__598000151__1; if linked_999 == nil { temp__1927000414__auto____2 = ifn_1000.Invoke_O__O(arg_1001) } else { temp__1927000414__auto____2 = linked_999.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_998, arg_1001) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000151__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1002 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = s__598000151__3; if linked_1003 == nil { tmp1 = ifn_1004.Invoke_O__O(arg_1005) } else { tmp1 = linked_1003.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1002, arg_1005) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1006 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1008 lang.IFn; if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = s__598000151__3; if linked_1007 == nil { c__1927001037__auto____4 = ifn_1008.Invoke_O__O(arg_1009) } else { c__1927001037__auto____4 = linked_1007.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1006, arg_1009) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000153__6 any; var root_1010 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1012 lang.IFn; if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; var arg_1013 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1011 == nil { b__598000153__6 = ifn_1012.Invoke_O__O(arg_1013) } else { b__598000153__6 = linked_1011.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1010, arg_1013) }; var tmp2 any = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_New_O_I_O(b__598000153__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1019 *jrt.Class = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_fn_class; if fncls__1019 == nil { var fncls__1019d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_fn_class = fncls__1019d; tmp3 = fncls__1019d } else { tmp3 = fncls__1019 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1028 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1030 lang.IFn; if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any; var root_1020 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = b__598000153__6; if linked_1021 == nil { arg_1031 = ifn_1022.Invoke_O__O(arg_1023) } else { arg_1031 = linked_1021.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1020, arg_1023) }; var arg_1032 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000150); var tmp5 any; var root_1024 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1026 lang.IFn; if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = s__598000151__3; if linked_1025 == nil { tmp5 = ifn_1026.Invoke_O__O(arg_1027) } else { tmp5 = linked_1025.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1024, arg_1027) }; arg_1032 = tmp4.Invoke_O__O(tmp5); if linked_1029 == nil { return ifn_1030.Invoke_O_O__O(arg_1031, arg_1032) } else { return linked_1029.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1028, arg_1031, arg_1032) } } else { var root_1037 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any; var root_1033 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any = b__598000153__6; if linked_1034 == nil { arg_1040 = ifn_1035.Invoke_O__O(arg_1036) } else { arg_1040 = linked_1034.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1033, arg_1036) }; var arg_1041 any; if linked_1038 == nil { return ifn_1039.Invoke_O_O__O(arg_1040, arg_1041) } else { return linked_1038.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1037, arg_1040, arg_1041) } } } else { var vec__598000161__4 any; var root_1042 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = s__598000151__3; if linked_1043 == nil { vec__598000161__4 = ifn_1044.Invoke_O__O(arg_1045) } else { vec__598000161__4 = linked_1043.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1042, arg_1045) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000161__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000161__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1050 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1050, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_75, nil, Lit_76, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, nil, k__5, nil, v__6, nil)).Ref(); var arg_1054 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000150); var tmp7 any; var root_1046 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = s__598000151__3; if linked_1047 == nil { tmp7 = ifn_1048.Invoke_O__O(arg_1049) } else { tmp7 = linked_1047.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1046, arg_1049) }; arg_1054 = tmp6.Invoke_O__O(tmp7); if linked_1051 == nil { return ifn_1052.Invoke_O_O__O(arg_1053, arg_1054) } else { return linked_1051.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1050, arg_1053, arg_1054) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :219:1
func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A) Ctor_O_I_O(c__b__598000153 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000153 = c__b__598000153; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A) Invoke_O__O(self any) any { { var i__598000152__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000152__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000157__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000152__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000157__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000157__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1014 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1016 lang.IFn; if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = t.F_b__598000153; var arg_1018 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_75, nil, Lit_76, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, nil, k__3, nil, v__4, nil)).Ref(); if linked_1015 == nil { ifn_1016.Invoke_O_O__O(arg_1017, arg_1018) } else { linked_1015.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1014, arg_1017, arg_1018) }; i__598000152__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000152__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_box_build_build_package_iter__598000166__598000170_A_New() *A_arbace_box_build_build_package_iter__598000166__598000170_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000166__598000170_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_A) Ctor() {}
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_A) Invoke_O_O__O(self, s__598000167__1 any) any { var tmp1 any = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_New_O_O(s__598000167__1, self); var tmp2 *jrt.Class; var fncls__1123 *jrt.Class = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_fn_class; if fncls__1123 == nil { var fncls__1123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_fn_class = fncls__1123d; tmp2 = fncls__1123d } else { tmp2 = fncls__1123 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :220:1
func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_New_O_O(p0, p1 any) *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A{}; t.Ctor_O_O(p0, p1); return t }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A) Ctor_O_O(c__s__598000167, c__iter__598000166 any) { t.F_s__598000167 = c__s__598000167; t.F_iter__598000166 = c__iter__598000166 }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A) Invoke_O__O(self any) any { { var s__598000167__1 any; var t_ any = t.F_s__598000167; t.F_s__598000167 = nil; s__598000167__1 = t_; for { var temp__1927000414__auto____2 any; var root_1066 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = s__598000167__1; if linked_1067 == nil { temp__1927000414__auto____2 = ifn_1068.Invoke_O__O(arg_1069) } else { temp__1927000414__auto____2 = linked_1067.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1066, arg_1069) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000167__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1070 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = s__598000167__3; if linked_1071 == nil { tmp1 = ifn_1072.Invoke_O__O(arg_1073) } else { tmp1 = linked_1071.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1070, arg_1073) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1074 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1076 lang.IFn; if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = s__598000167__3; if linked_1075 == nil { c__1927001037__auto____4 = ifn_1076.Invoke_O__O(arg_1077) } else { c__1927001037__auto____4 = linked_1075.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1074, arg_1077) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000169__6 any; var root_1078 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1078, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1080 lang.IFn; if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1079 == nil { b__598000169__6 = ifn_1080.Invoke_O__O(arg_1081) } else { b__598000169__6 = linked_1079.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1078, arg_1081) }; var tmp2 any = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_New_O_I_O(b__598000169__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1087 *jrt.Class = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_fn_class; if fncls__1087 == nil { var fncls__1087d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_fn_class = fncls__1087d; tmp3 = fncls__1087d } else { tmp3 = fncls__1087 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1096 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any; var root_1088 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any = b__598000169__6; if linked_1089 == nil { arg_1099 = ifn_1090.Invoke_O__O(arg_1091) } else { arg_1099 = linked_1089.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1088, arg_1091) }; var arg_1100 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000166); var tmp5 any; var root_1092 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = s__598000167__3; if linked_1093 == nil { tmp5 = ifn_1094.Invoke_O__O(arg_1095) } else { tmp5 = linked_1093.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1092, arg_1095) }; arg_1100 = tmp4.Invoke_O__O(tmp5); if linked_1097 == nil { return ifn_1098.Invoke_O_O__O(arg_1099, arg_1100) } else { return linked_1097.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1096, arg_1099, arg_1100) } } else { var root_1105 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1105, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1107 lang.IFn; if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any; var root_1101 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1101, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1103 lang.IFn; if linked_1102 == nil { ifn_1103 = lang.IFn_Cast(root_1101) } else { ifn_1103 = nil }; var arg_1104 any = b__598000169__6; if linked_1102 == nil { arg_1108 = ifn_1103.Invoke_O__O(arg_1104) } else { arg_1108 = linked_1102.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1101, arg_1104) }; var arg_1109 any; if linked_1106 == nil { return ifn_1107.Invoke_O_O__O(arg_1108, arg_1109) } else { return linked_1106.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1105, arg_1108, arg_1109) } } } else { var l__4 any; var root_1110 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1110, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1112 lang.IFn; if linked_1111 == nil { ifn_1112 = lang.IFn_Cast(root_1110) } else { ifn_1112 = nil }; var arg_1113 any = s__598000167__3; if linked_1111 == nil { l__4 = ifn_1112.Invoke_O__O(arg_1113) } else { l__4 = linked_1111.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1110, arg_1113) }; var root_1118 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1118, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1120 lang.IFn; if linked_1119 == nil { ifn_1120 = lang.IFn_Cast(root_1118) } else { ifn_1120 = nil }; var arg_1121 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, l__4, nil)).Ref(); var arg_1122 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000166); var tmp7 any; var root_1114 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1114, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1116 lang.IFn; if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any = s__598000167__3; if linked_1115 == nil { tmp7 = ifn_1116.Invoke_O__O(arg_1117) } else { tmp7 = linked_1115.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1114, arg_1117) }; arg_1122 = tmp6.Invoke_O__O(tmp7); if linked_1119 == nil { return ifn_1120.Invoke_O_O__O(arg_1121, arg_1122) } else { return linked_1119.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1118, arg_1121, arg_1122) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :220:1
func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A) Ctor_O_I_O(c__b__598000169 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000169 = c__b__598000169; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A) Invoke_O__O(self any) any { { var i__598000168__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000168__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000168__1)); var root_1082 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1082, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1084 lang.IFn; if linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any = t.F_b__598000169; var arg_1086 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, l__2, nil)).Ref(); if linked_1083 == nil { ifn_1084.Invoke_O_O__O(arg_1085, arg_1086) } else { linked_1083.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1082, arg_1085, arg_1086) }; i__598000168__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000168__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_box_build_build_package_res_of__598000176_A_New_O(p0 any) *A_arbace_box_build_build_package_res_of__598000176_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_res_of__598000176_A{}; t.Ctor_O(p0); return t }
//line :222:1
func (t *A_arbace_box_build_build_package_res_of__598000176_A) Ctor_O(c__P any) { t.F_P = c__P }
//line :222:1
func (t *A_arbace_box_build_build_package_res_of__598000176_A) Invoke_O_O_O__O(self, what__1, req__2 any) any { var root_1135 any = A_arbace_box_build_A_const_79.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, A_arbace_box_build_action_STAR__A_fn_class); var ifn_1137 lang.IFn; if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_88, nil), jrt.RefArrayOf(jrt.Object_class, t.F_P, nil, what__1)).Ref(); var arg_1139 any; var root_1130 any = A_arbace_box_build_A_const_124.GetRawRoot__O(); var linked_1131 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1130, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_1132 lang.IFn; if linked_1131 == nil { ifn_1132 = lang.IFn_Cast(root_1130) } else { ifn_1132 = nil }; var arg_1133 any = A_arbace_box_build_A_const_125; var arg_1134 any = req__2; if linked_1131 == nil { arg_1139 = ifn_1132.Invoke_O_O__O(arg_1133, arg_1134) } else { arg_1139 = linked_1131.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_1130, arg_1133, arg_1134) }; if linked_1136 == nil { return ifn_1137.Invoke_O_O__O(arg_1138, arg_1139) } else { return linked_1136.(*A_arbace_box_build_action_STAR__A).Invoke_O_O_O__O(root_1135, arg_1138, arg_1139) } }




func A_arbace_box_build_build_package_fn__598000179_A_New_O(p0 any) *A_arbace_box_build_build_package_fn__598000179_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_fn__598000179_A{}; t.Ctor_O(p0); return t }
//line :227:1
func (t *A_arbace_box_build_build_package_fn__598000179_A) Ctor_O(c__P any) { t.F_P = c__P }
//line :227:1
func (t *A_arbace_box_build_build_package_fn__598000179_A) Invoke_O_O__O(self, p__598000178__1 any) any { var vec__598000180__2 any = p__598000178__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000180__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000180__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var and__1927000168__auto____5 any; var root_1141 any = A_arbace_box_build_A_const_128.GetRawRoot__O(); var linked_1142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1141, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1143 lang.IFn; if linked_1142 == nil { ifn_1143 = lang.IFn_Cast(root_1141) } else { ifn_1143 = nil }; var arg_1144 any = k__3; if linked_1142 == nil { and__1927000168__auto____5 = ifn_1143.Invoke_O__O(arg_1144) } else { and__1927000168__auto____5 = linked_1142.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1141, arg_1144) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1145 any = A_arbace_box_build_A_const_23.GetRawRoot__O(); var linked_1146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1145, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1147 lang.IFn; if linked_1146 == nil { ifn_1147 = lang.IFn_Cast(root_1145) } else { ifn_1147 = nil }; var arg_1148 any = k__3; var arg_1149 any = Lit_70; if linked_1146 == nil { and__1927000168__auto____6 = ifn_1147.Invoke_O_O__O(arg_1148, arg_1149) } else { and__1927000168__auto____6 = linked_1146.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1145, arg_1148, arg_1149) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
													var root_1156 any = A_arbace_box_build_A_const_129.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1156, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1158 lang.IFn; if linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any = t.F_P; var arg_1160 any; var root_1150 any = A_arbace_box_build_A_const_52.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any = k__3; var arg_1154 any = A_arbace_box_build_A_const_57; var arg_1155 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(k__3)))).Ref(); if linked_1151 == nil { arg_1160 = ifn_1152.Invoke_O_O_O__O(arg_1153, arg_1154, arg_1155) } else { arg_1160 = linked_1151.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1150, arg_1153, arg_1154, arg_1155) }; if linked_1157 == nil { tmp1 = ifn_1158.Invoke_O_O__O(arg_1159, arg_1160) } else { tmp1 = linked_1157.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1156, arg_1159, arg_1160) } } else {
//line :227:1
		tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { return v__4 } else { return nil } }










func A_arbace_box_build_build_package_fn__598000184_A_New() *A_arbace_box_build_build_package_fn__598000184_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_fn__598000184_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_box_build_build_package_fn__598000184_A) Ctor() {}
//line :238:1
func (t *A_arbace_box_build_build_package_fn__598000184_A) Invoke_O_O__O(self, p1__598000143_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_71, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__598000143_SHARP___1)).Ref() }














func A_arbace_box_build_build_package_fn__598000186_A_New() *A_arbace_box_build_build_package_fn__598000186_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_fn__598000186_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_box_build_build_package_fn__598000186_A) Ctor() {}
//line :253:1
func (t *A_arbace_box_build_build_package_fn__598000186_A) Invoke_O_O__O(self, p1__598000144_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__598000144_SHARP___1)).Ref() }











func A_arbace_box_build_build_package_iter__598000189__598000193_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_box_build_build_package_iter__598000189__598000193_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_A) Ctor_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__ctree, c__pkg, c__tools any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_tools = c__tools }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_A) Invoke_O_O__O(self, s__598000190__1 any) any { var tmp1 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_New_O_O_O_O_O_O_O_O(t.F_res_of, t.F_P, t.F_plan, t.F_ctree, t.F_pkg, t.F_tools, s__598000190__1, self); var tmp2 *jrt.Class; var fncls__1357 *jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_fn_class; if fncls__1357 == nil { var fncls__1357d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_fn_class = fncls__1357d; tmp2 = fncls__1357d } else { tmp2 = fncls__1357 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :265:1
func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A) Ctor_O_O_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__ctree, c__pkg, c__tools, c__s__598000190, c__iter__598000189 any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_tools = c__tools; t.F_s__598000190 = c__s__598000190; t.F_iter__598000189 = c__iter__598000189 }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A) Invoke_O__O(self any) any { { var s__598000190__1 any; var t_ any = t.F_s__598000190; t.F_s__598000190 = nil; s__598000190__1 = t_; for { var temp__1927000414__auto____2 any; var root_1244 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1246 lang.IFn; if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any = s__598000190__1; if linked_1245 == nil { temp__1927000414__auto____2 = ifn_1246.Invoke_O__O(arg_1247) } else { temp__1927000414__auto____2 = linked_1245.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1244, arg_1247) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000190__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1248 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1250 lang.IFn; if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any = s__598000190__3; if linked_1249 == nil { tmp1 = ifn_1250.Invoke_O__O(arg_1251) } else { tmp1 = linked_1249.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1248, arg_1251) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1252 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1254 lang.IFn; if linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; var arg_1255 any = s__598000190__3; if linked_1253 == nil { c__1927001037__auto____4 = ifn_1254.Invoke_O__O(arg_1255) } else { c__1927001037__auto____4 = linked_1253.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1252, arg_1255) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000192__6 any; var root_1256 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1258 lang.IFn; if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1257 == nil { b__598000192__6 = ifn_1258.Invoke_O__O(arg_1259) } else { b__598000192__6 = linked_1257.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1256, arg_1259) }; var tmp2 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_New_O_O_O_O_O_O_O_I_O(b__598000192__6, t.F_res_of, t.F_P, t.F_plan, t.F_ctree, t.F_pkg, t.F_tools, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1293 *jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_fn_class; if fncls__1293 == nil { var fncls__1293d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_fn_class = fncls__1293d; tmp3 = fncls__1293d } else { tmp3 = fncls__1293 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1302 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1302, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1304 lang.IFn; if linked_1303 == nil { ifn_1304 = lang.IFn_Cast(root_1302) } else { ifn_1304 = nil }; var arg_1305 any; var root_1294 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1294, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1296 lang.IFn; if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any = b__598000192__6; if linked_1295 == nil { arg_1305 = ifn_1296.Invoke_O__O(arg_1297) } else { arg_1305 = linked_1295.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1294, arg_1297) }; var arg_1306 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000189); var tmp5 any; var root_1298 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1298, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1300 lang.IFn; if linked_1299 == nil { ifn_1300 = lang.IFn_Cast(root_1298) } else { ifn_1300 = nil }; var arg_1301 any = s__598000190__3; if linked_1299 == nil { tmp5 = ifn_1300.Invoke_O__O(arg_1301) } else { tmp5 = linked_1299.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1298, arg_1301) }; arg_1306 = tmp4.Invoke_O__O(tmp5); if linked_1303 == nil { return ifn_1304.Invoke_O_O__O(arg_1305, arg_1306) } else { return linked_1303.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1302, arg_1305, arg_1306) } } else { var root_1311 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1311, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1313 lang.IFn; if linked_1312 == nil { ifn_1313 = lang.IFn_Cast(root_1311) } else { ifn_1313 = nil }; var arg_1314 any; var root_1307 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = b__598000192__6; if linked_1308 == nil { arg_1314 = ifn_1309.Invoke_O__O(arg_1310) } else { arg_1314 = linked_1308.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1307, arg_1310) }; var arg_1315 any; if linked_1312 == nil { return ifn_1313.Invoke_O_O__O(arg_1314, arg_1315) } else { return linked_1312.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1311, arg_1314, arg_1315) } } } else { var s__4 any; var root_1316 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1316, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1318 lang.IFn; if linked_1317 == nil { ifn_1318 = lang.IFn_Cast(root_1316) } else { ifn_1318 = nil }; var arg_1319 any = s__598000190__3; if linked_1317 == nil { s__4 = ifn_1318.Invoke_O__O(arg_1319) } else { s__4 = linked_1317.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1316, arg_1319) }; var root_1352 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1352, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1354 lang.IFn; if linked_1353 == nil { ifn_1354 = lang.IFn_Cast(root_1352) } else { ifn_1354 = nil }; var arg_1355 any; var o__5 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_81); var tmp7 any; var root_1320 any = A_arbace_box_build_A_const_52.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1322 lang.IFn
														if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = s__4; var arg_1324 any = A_arbace_box_build_A_const_57; var arg_1325 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(s__4)), 2)).Ref(); if linked_1321 == nil { tmp7 = ifn_1322.Invoke_O_O_O__O(arg_1323, arg_1324, arg_1325) } else { tmp7 = linked_1321.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1320, arg_1323, arg_1324, arg_1325) }; o__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil)).Ref()
//line :265:1
	var tmp8 any; var root_1344 any = A_arbace_box_build_A_const_145.GetRawRoot__O(); var linked_1345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1344, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_1346 lang.IFn

	if linked_1345 == nil { ifn_1346 = lang.IFn_Cast(root_1344) } else { ifn_1346 = nil }; var arg_1347 any; var tmp9 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_New_O_O_O_O_O_O_O_O(t.F_res_of, t.F_P, t.F_plan, o__5, t.F_ctree, t.F_pkg, s__4, t.F_tools); var tmp10 *jrt.Class; var fncls__1343 *jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_fn_class; if fncls__1343 == nil { var fncls__1343d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_fn_class = fncls__1343d; tmp10 = fncls__1343d } else { tmp10 = fncls__1343 }; arg_1347 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); if linked_1345 == nil { tmp8 = ifn_1346.Invoke_O__O(arg_1347) } else { tmp8 = linked_1345.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_1344, arg_1347) }
//line :265:1
	arg_1355 = lang.Tuple_Create_O_O__IPersistentVector(o__5, tmp8); var arg_1356 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__598000189); var tmp12 any; var root_1348 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any = s__598000190__3; if linked_1349 == nil { tmp12 = ifn_1350.Invoke_O__O(arg_1351) } else { tmp12 = linked_1349.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1348, arg_1351) }; arg_1356 = tmp11.Invoke_O__O(tmp12); if linked_1353 == nil { return ifn_1354.Invoke_O_O__O(arg_1355, arg_1356) } else { return linked_1353.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1352, arg_1355, arg_1356) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :265:1
func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_New_O_O_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6 any, p7 int32, p8 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A{}; t.Ctor_O_O_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A) Ctor_O_O_O_O_O_O_O_I_O(c__b__598000192, c__res_of, c__P, c__plan, c__ctree, c__pkg, c__tools any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000192 = c__b__598000192; t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_tools = c__tools; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A) Invoke_O__O(self any) any { { var i__598000191__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000191__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000191__1)); var root_1288 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1288, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1290 lang.IFn; if linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any = t.F_b__598000192; var arg_1292 any; var o__3 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_81); var tmp3 any; var root_1260 any = A_arbace_box_build_A_const_52.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1262 lang.IFn
																if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = s__2; var arg_1264 any = A_arbace_box_build_A_const_57; var arg_1265 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(s__2)), 2)).Ref(); if linked_1261 == nil { tmp3 = ifn_1262.Invoke_O_O_O__O(arg_1263, arg_1264, arg_1265) } else { tmp3 = linked_1261.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1260, arg_1263, arg_1264, arg_1265) }; o__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref()
//line :265:1
	var tmp4 any; var root_1284 any = A_arbace_box_build_A_const_145.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_1286 lang.IFn

	if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any; var tmp5 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_New_O_O_O_O_O_O_O_O(t.F_res_of, t.F_P, t.F_plan, t.F_ctree, t.F_pkg, o__3, s__2, t.F_tools); var tmp6 *jrt.Class; var fncls__1283 *jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_fn_class; if fncls__1283 == nil { var fncls__1283d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_fn_class = fncls__1283d; tmp6 = fncls__1283d } else { tmp6 = fncls__1283 }; arg_1287 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if linked_1285 == nil { tmp4 = ifn_1286.Invoke_O__O(arg_1287) } else { tmp4 = linked_1285.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_1284, arg_1287) }
//line :265:1
	arg_1292 = lang.Tuple_Create_O_O__IPersistentVector(o__3, tmp4); if linked_1289 == nil { ifn_1290.Invoke_O_O__O(arg_1291, arg_1292) } else { linked_1289.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1288, arg_1291, arg_1292) }; i__598000191__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000191__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A) Ctor_O_O_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__ctree, c__pkg, c__o, c__s, c__tools any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_o = c__o; t.F_s = c__s; t.F_tools = c__tools }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A) Invoke_O__O(self any) any {
	var root_1277 any = A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, A_arbace_box_build_out_file_A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any; var tmp1 any; var t_ any = t.F_res_of; t.F_res_of = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_84, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_s)).Ref(); var tmp4 any = A_arbace_box_build_A_const_138; var tmp5 *lang.Keyword = A_arbace_box_build_A_const_139; var tmp6 any; var t__2 any = t.F_tools
	t.F_tools = nil; tmp6 = t__2
//line :268:1
	var tmp7 any = tmp5.Invoke_O__O(tmp6); var tmp8 any = A_arbace_box_build_A_const_78; var tmp9 any; var root_1272 any = A_arbace_box_build_A_const_9.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1272, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1274 lang.IFn

	if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_140.GetRawRoot__O()); var tmp11 any = t.F_plan; var tmp12 any = t.F_pkg; var arg_1275 any = tmp10.Invoke_O_O_O__O(tmp11, tmp12, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_85, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_o)).Ref()); var arg_1276 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_71, nil); var tmp14 any; var t__3 any = t.F_s; t.F_s = nil; tmp14 = t__3; arg_1276 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_1273 == nil { tmp9 = ifn_1274.Invoke_O_O__O(arg_1275, arg_1276) } else { tmp9 = linked_1273.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1272, arg_1275, arg_1276) }
//line :268:1
	var tmp15 any = tmp9; var tmp16 any = A_arbace_box_build_A_const_141; var tmp17 *lang.Keyword = A_arbace_box_build_A_const_44; var tmp18 any; var t__4 any = t.F_pkg


	t.F_pkg = nil; tmp18 = t__4
//line :268:1
	var tmp19 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_55, tmp17.Invoke_O__O(tmp18)); var tmp20 *lang.Keyword = A_arbace_box_build_A_const_39; var tmp21 any; var t__5 any = t.F_plan


	t.F_plan = nil; tmp21 = t__5
//line :268:1
	var tmp22 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_40, tmp20.Invoke_O__O(tmp21)); var tmp23 any; var t__6 any = t.F_ctree; t.F_ctree = nil; tmp23 = t__6; arg_1280 = tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, tmp15, tmp16, lang.Tuple_Create_O_O_O__IPersistentVector(tmp19, tmp22, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp23))))); var arg_1281 any; var t__7 any = t.F_P; t.F_P = nil; arg_1281 = t__7; var arg_1282 any; var t__8 any = t.F_o; t.F_o = nil; arg_1282 = t__8; if linked_1278 == nil { return ifn_1279.Invoke_O_O_O__O(arg_1280, arg_1281, arg_1282) } else { return linked_1278.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_1277, arg_1280, arg_1281, arg_1282) } }
//line :267:1
func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A) Ctor_O_O_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__o, c__ctree, c__pkg, c__s, c__tools any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_o = c__o; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_s = c__s; t.F_tools = c__tools }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A) Invoke_O__O(self any) any {
	var root_1337 any = A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1337, A_arbace_box_build_out_file_A_fn_class); var ifn_1339 lang.IFn; if linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any; var tmp1 any; var t_ any = t.F_res_of; t.F_res_of = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_84, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_s)).Ref(); var tmp4 any = A_arbace_box_build_A_const_138; var tmp5 *lang.Keyword = A_arbace_box_build_A_const_139; var tmp6 any; var t__2 any = t.F_tools
	t.F_tools = nil; tmp6 = t__2
//line :268:1
	var tmp7 any = tmp5.Invoke_O__O(tmp6); var tmp8 any = A_arbace_box_build_A_const_78; var tmp9 any; var root_1332 any = A_arbace_box_build_A_const_9.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1332, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1334 lang.IFn

	if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_140.GetRawRoot__O()); var tmp11 any = t.F_plan; var tmp12 any = t.F_pkg; var arg_1335 any = tmp10.Invoke_O_O_O__O(tmp11, tmp12, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_85, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_o)).Ref()); var arg_1336 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_71, nil); var tmp14 any; var t__3 any = t.F_s; t.F_s = nil; tmp14 = t__3; arg_1336 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_1333 == nil { tmp9 = ifn_1334.Invoke_O_O__O(arg_1335, arg_1336) } else { tmp9 = linked_1333.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1332, arg_1335, arg_1336) }
//line :268:1
	var tmp15 any = tmp9; var tmp16 any = A_arbace_box_build_A_const_141; var tmp17 *lang.Keyword = A_arbace_box_build_A_const_44; var tmp18 any; var t__4 any = t.F_pkg


	t.F_pkg = nil; tmp18 = t__4
//line :268:1
	var tmp19 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_55, tmp17.Invoke_O__O(tmp18)); var tmp20 *lang.Keyword = A_arbace_box_build_A_const_39; var tmp21 any; var t__5 any = t.F_plan


	t.F_plan = nil; tmp21 = t__5
//line :268:1
	var tmp22 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_40, tmp20.Invoke_O__O(tmp21)); var tmp23 any; var t__6 any = t.F_ctree; t.F_ctree = nil; tmp23 = t__6; arg_1340 = tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, tmp15, tmp16, lang.Tuple_Create_O_O_O__IPersistentVector(tmp19, tmp22, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp23))))); var arg_1341 any; var t__7 any = t.F_P; t.F_P = nil; arg_1341 = t__7; var arg_1342 any; var t__8 any = t.F_o; t.F_o = nil; arg_1342 = t__8; if linked_1338 == nil { return ifn_1339.Invoke_O_O_O__O(arg_1340, arg_1341, arg_1342) } else { return linked_1338.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_1337, arg_1340, arg_1341, arg_1342)
	}
}


func A_arbace_box_build_build_package_iter__598000203__598000207_A_New() *A_arbace_box_build_build_package_iter__598000203__598000207_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000203__598000207_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_A) Ctor() {}
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_A) Invoke_O_O__O(self, s__598000204__1 any) any { var tmp1 any = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_New_O_O(self, s__598000204__1); var tmp2 *jrt.Class; var fncls__1444 *jrt.Class = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_fn_class; if fncls__1444 == nil { var fncls__1444d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_fn_class = fncls__1444d; tmp2 = fncls__1444d } else { tmp2 = fncls__1444 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :273:1
func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_New_O_O(p0, p1 any) *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A{}; t.Ctor_O_O(p0, p1); return t }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A) Ctor_O_O(c__iter__598000203, c__s__598000204 any) { t.F_iter__598000203 = c__iter__598000203; t.F_s__598000204 = c__s__598000204 }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A) Invoke_O__O(self any) any { { var s__598000204__1 any; var t_ any = t.F_s__598000204; t.F_s__598000204 = nil; s__598000204__1 = t_; for { var temp__1927000414__auto____2 any; var root_1363 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1363, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1365 lang.IFn; if linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any = s__598000204__1; if linked_1364 == nil { temp__1927000414__auto____2 = ifn_1365.Invoke_O__O(arg_1366) } else { temp__1927000414__auto____2 = linked_1364.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1363, arg_1366) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000204__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1367 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1367, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1369 lang.IFn; if linked_1368 == nil { ifn_1369 = lang.IFn_Cast(root_1367) } else { ifn_1369 = nil }; var arg_1370 any = s__598000204__3; if linked_1368 == nil { tmp1 = ifn_1369.Invoke_O__O(arg_1370) } else { tmp1 = linked_1368.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1367, arg_1370) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1371 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1371, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1373 lang.IFn; if linked_1372 == nil { ifn_1373 = lang.IFn_Cast(root_1371) } else { ifn_1373 = nil }; var arg_1374 any = s__598000204__3; if linked_1372 == nil { c__1927001037__auto____4 = ifn_1373.Invoke_O__O(arg_1374) } else { c__1927001037__auto____4 = linked_1372.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1371, arg_1374) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000206__6 any; var root_1375 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1375, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1377 lang.IFn; if linked_1376 == nil { ifn_1377 = lang.IFn_Cast(root_1375) } else { ifn_1377 = nil }; var arg_1378 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1376 == nil { b__598000206__6 = ifn_1377.Invoke_O__O(arg_1378) } else { b__598000206__6 = linked_1376.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1375, arg_1378) }; var tmp2 any = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_New_O_I_O(b__598000206__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1396 *jrt.Class = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_fn_class; if fncls__1396 == nil { var fncls__1396d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_fn_class = fncls__1396d; tmp3 = fncls__1396d } else { tmp3 = fncls__1396 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1405 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1405, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1407 lang.IFn; if linked_1406 == nil { ifn_1407 = lang.IFn_Cast(root_1405) } else { ifn_1407 = nil }; var arg_1408 any; var root_1397 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1397, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1399 lang.IFn; if linked_1398 == nil { ifn_1399 = lang.IFn_Cast(root_1397) } else { ifn_1399 = nil }; var arg_1400 any = b__598000206__6; if linked_1398 == nil { arg_1408 = ifn_1399.Invoke_O__O(arg_1400) } else { arg_1408 = linked_1398.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1397, arg_1400) }; var arg_1409 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000203); var tmp5 any; var root_1401 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1401, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1403 lang.IFn; if linked_1402 == nil { ifn_1403 = lang.IFn_Cast(root_1401) } else { ifn_1403 = nil }; var arg_1404 any = s__598000204__3; if linked_1402 == nil { tmp5 = ifn_1403.Invoke_O__O(arg_1404) } else { tmp5 = linked_1402.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1401, arg_1404) }; arg_1409 = tmp4.Invoke_O__O(tmp5); if linked_1406 == nil { return ifn_1407.Invoke_O_O__O(arg_1408, arg_1409) } else { return linked_1406.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1405, arg_1408, arg_1409) } } else { var root_1414 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1414, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1416 lang.IFn; if linked_1415 == nil { ifn_1416 = lang.IFn_Cast(root_1414) } else { ifn_1416 = nil }; var arg_1417 any; var root_1410 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1410, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1412 lang.IFn; if linked_1411 == nil { ifn_1412 = lang.IFn_Cast(root_1410) } else { ifn_1412 = nil }; var arg_1413 any = b__598000206__6; if linked_1411 == nil { arg_1417 = ifn_1412.Invoke_O__O(arg_1413) } else { arg_1417 = linked_1411.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1410, arg_1413) }; var arg_1418 any; if linked_1415 == nil { return ifn_1416.Invoke_O_O__O(arg_1417, arg_1418) } else { return linked_1415.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1414, arg_1417, arg_1418) } } } else { var vec__598000214__4 any; var root_1419 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1419, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1421 lang.IFn; if linked_1420 == nil { ifn_1421 = lang.IFn_Cast(root_1419) } else { ifn_1421 = nil }; var arg_1422 any = s__598000204__3; if linked_1420 == nil { vec__598000214__4 = ifn_1421.Invoke_O__O(arg_1422) } else { vec__598000214__4 = linked_1420.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1419, arg_1422) }; var o__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000214__4, lang.RT_IntCast_J__I_NoInit(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000214__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1439 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1441 lang.IFn; if linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any; var tmp6 any; var root_1431 any = A_arbace_box_build_A_const_146.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, aot_arbace_box.A_arbace_box_get_bytes_A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any; var root_1427 any = A_arbace_box_build_A_const_147.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1429 lang.IFn; if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any; var root_1423 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1423, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1425 lang.IFn; if linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; var arg_1426 any = f__6; if linked_1424 == nil { arg_1430 = ifn_1425.Invoke_O__O(arg_1426) } else { arg_1430 = linked_1424.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1423, arg_1426) }; if linked_1428 == nil { arg_1434 = ifn_1429.Invoke_O__O(arg_1430) } else { arg_1434 = linked_1428.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1427, arg_1430) }; if linked_1432 == nil { tmp6 = ifn_1433.Invoke_O__O(arg_1434) } else { tmp6 = linked_1432.(*aot_arbace_box.A_arbace_box_get_bytes_A).Invoke_O_O__O(root_1431, arg_1434) }; arg_1442 = lang.Tuple_Create_O_O__IPersistentVector(o__5, tmp6); var arg_1443 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__598000203); var tmp8 any; var root_1435 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1435, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1437 lang.IFn; if linked_1436 == nil { ifn_1437 = lang.IFn_Cast(root_1435) } else { ifn_1437 = nil }; var arg_1438 any = s__598000204__3; if linked_1436 == nil { tmp8 = ifn_1437.Invoke_O__O(arg_1438) } else { tmp8 = linked_1436.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1435, arg_1438) }; arg_1443 = tmp7.Invoke_O__O(tmp8); if linked_1440 == nil { return ifn_1441.Invoke_O_O__O(arg_1442, arg_1443) } else { return linked_1440.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1439, arg_1442, arg_1443) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :273:1
func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A) Ctor_O_I_O(c__b__598000206 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000206 = c__b__598000206; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A) Invoke_O__O(self any) any { { var i__598000205__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000205__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000210__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000205__1)); var o__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000210__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000210__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1391 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = t.F_b__598000206; var arg_1395 any; var tmp2 any; var root_1387 any = A_arbace_box_build_A_const_146.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_box.A_arbace_box_get_bytes_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any; var root_1383 any = A_arbace_box_build_A_const_147.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1385 lang.IFn; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any; var root_1379 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1379, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1381 lang.IFn; if linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any = f__4; if linked_1380 == nil { arg_1386 = ifn_1381.Invoke_O__O(arg_1382) } else { arg_1386 = linked_1380.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1379, arg_1382) }; if linked_1384 == nil { arg_1390 = ifn_1385.Invoke_O__O(arg_1386) } else { arg_1390 = linked_1384.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1383, arg_1386) }; if linked_1388 == nil { tmp2 = ifn_1389.Invoke_O__O(arg_1390) } else { tmp2 = linked_1388.(*aot_arbace_box.A_arbace_box_get_bytes_A).Invoke_O_O__O(root_1387, arg_1390) }; arg_1395 = lang.Tuple_Create_O_O__IPersistentVector(o__3, tmp2); if linked_1392 == nil { ifn_1393.Invoke_O_O__O(arg_1394, arg_1395) } else { linked_1392.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1391, arg_1394, arg_1395) }; i__598000205__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000205__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_box_build_read_plan_A_New() *A_arbace_box_build_read_plan_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_read_plan_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_box_build_read_plan_A) Ctor() {}
//line :276:1
func (t *A_arbace_box_build_read_plan_A) Invoke_O_O__O(self, plan__0 any) any {
	var tmp1 any; var root_1531 any = A_arbace_box_build_A_const_32.GetRawRoot__O(); var linked_1532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1531, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1533 lang.IFn; if linked_1532 == nil { ifn_1533 = lang.IFn_Cast(root_1531) } else { ifn_1533 = nil }; var arg_1534 any = plan__0; if linked_1532 == nil { tmp1 = ifn_1533.Invoke_O__O(arg_1534) } else { tmp1 = linked_1532.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1531, arg_1534) }; if jrt.J2g_Truth(tmp1) { return plan__0 } else { var tmp2 any; var root_1535 any = A_arbace_box_build_A_const_163.GetRawRoot__O(); var linked_1536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1535, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_1537 lang.IFn
		if linked_1536 == nil { ifn_1537 = lang.IFn_Cast(root_1535) } else { ifn_1537 = nil }; var arg_1538 any = A_arbace_box_build_A_const_164; var arg_1539 any = plan__0; if linked_1536 == nil { tmp2 = ifn_1537.Invoke_O_O__O(arg_1538, arg_1539) } else { tmp2 = linked_1536.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_1535, arg_1538, arg_1539) }
//line :277:1
		if jrt.J2g_Truth(tmp2) {
			var root_1544 any = A_arbace_box_build_A_const_33.GetRawRoot__O(); var linked_1545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1544, aot_arbace_edn.A_arbace_edn_read_string_A_fn_class); var ifn_1546 lang.IFn; if linked_1545 == nil { ifn_1546 = lang.IFn_Cast(root_1544) } else { ifn_1546 = nil }; var arg_1547 any; var root_1540 any = A_arbace_box_build_A_const_69.GetRawRoot__O(); var linked_1541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1540, aot_arbace_box.A_arbace_box_get_A_fn_class); var ifn_1542 lang.IFn; if linked_1541 == nil { ifn_1542 = lang.IFn_Cast(root_1540) } else { ifn_1542 = nil }; var arg_1543 any = plan__0; if linked_1541 == nil { arg_1547 = ifn_1542.Invoke_O__O(arg_1543) } else { arg_1547 = linked_1541.(*aot_arbace_box.A_arbace_box_get_A).Invoke_O_O__O(root_1540, arg_1543) }; if linked_1545 == nil { return ifn_1546.Invoke_O__O(arg_1547) } else { return linked_1545.(*aot_arbace_edn.A_arbace_edn_read_string_A).Invoke_O_O__O(root_1544, arg_1547) } } else {
//line :277:1
				if A_arbace_box_build_A_const_111 != nil {

					var root_1557 any = A_arbace_box_build_A_const_33.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, aot_arbace_edn.A_arbace_edn_read_string_A_fn_class); var ifn_1559 lang.IFn; if linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any; var or__1927000174__auto____2 any; var root_1548 any = A_arbace_box_build_A_const_165.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1548, aot_arbace_box.A_arbace_box_load_A_fn_class); var ifn_1550 lang.IFn; if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any = plan__0; if linked_1549 == nil { or__1927000174__auto____2 = ifn_1550.Invoke_O__O(arg_1551) } else { or__1927000174__auto____2 = linked_1549.(*aot_arbace_box.A_arbace_box_load_A).Invoke_O_O__O(root_1548, arg_1551) }; if jrt.J2g_Truth(or__1927000174__auto____2) { arg_1560 = or__1927000174__auto____2 } else { var root_1552 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_1553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1552, A_arbace_box_build_fail_A_fn_class); var ifn_1554 lang.IFn; if linked_1553 == nil { ifn_1554 = lang.IFn_Cast(root_1552) } else { ifn_1554 = nil }; var arg_1555 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_139, nil), jrt.RefArrayOf(jrt.Object_class, nil, plan__0)).Ref(); var arg_1556 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_166, plan__0)); if linked_1553 == nil { arg_1560 = ifn_1554.Invoke_O_O__O(arg_1555, arg_1556) } else { arg_1560 = linked_1553.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_1552, arg_1555, arg_1556) } }; if linked_1558 == nil { return ifn_1559.Invoke_O__O(arg_1560) } else { return linked_1558.(*aot_arbace_edn.A_arbace_edn_read_string_A).Invoke_O_O__O(root_1557, arg_1560) } } else {
//line :277:1
						return nil
					}
			}
	} }
func A_arbace_box_build_with_tools_A_New() *A_arbace_box_build_with_tools_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_with_tools_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_box_build_with_tools_A) Ctor() {}
//line :281:1
func (t *A_arbace_box_build_with_tools_A) Invoke_O_O_O__O(self, p__0, opts__1 any) any { var arch__3 any = A_arbace_box_build_A_const_85.Invoke_O__O(p__0); var tools__4 any; var root_1641 any = A_arbace_box_build_A_const_124.GetRawRoot__O(); var linked_1642 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1641, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_1643 lang.IFn; if



	linked_1642 == nil { ifn_1643 = lang.IFn_Cast(root_1641) } else { ifn_1643 = nil }; var arg_1644 any; var root_1636 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1640 any; var iter__1927001039__auto____4 any; var tmp1 any = A_arbace_box_build_with_tools_iter__598000221__598000225_A_New_O(arch__3); var tmp2 *jrt.Class; var fncls__1635 *jrt.Class = A_arbace_box_build_with_tools_iter__598000221__598000225_A_fn_class; if fncls__1635 == nil { var fncls__1635d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_box_build_with_tools_iter__598000221__598000225_A_fn_class = fncls__1635d; tmp2 = fncls__1635d } else { tmp2 = fncls__1635 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_1640 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(A_arbace_box_build_A_const_168); if linked_1637 == nil { arg_1644 = ifn_1638.Invoke_O_O__O(arg_1639, arg_1640) } else { arg_1644 = linked_1637.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1636, arg_1639, arg_1640) }; var arg_1645 any = A_arbace_box_build_A_const_120.Invoke_O__O(opts__1); if linked_1642 == nil { tools__4 = ifn_1643.Invoke_O_O__O(arg_1644, arg_1645) } else { tools__4 = linked_1642.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_1641, arg_1644, arg_1645) }; var seq_598000231__5 any; var root_1652 any = /*line :281:1*/A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1654 lang.IFn; if






	linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = tools__4; if linked_1653 == nil { seq_598000231__5 = ifn_1654.Invoke_O__O(arg_1655) } else { seq_598000231__5 = linked_1653.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1652, arg_1655) }; var chunk_598000232__6 any; var count_598000233__7 int64 = 0; var i_598000234__8 int64 = 0; L1:
//line :281:1
	for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_598000234__8, count_598000233__7) { var vec__598000235__9 any = lang.Indexed_Cast(chunk_598000232__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_598000234__8)); var t__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000235__9, lang.RT_IntCast_J__I_NoInit(0), nil); var h__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000235__9, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(h__11) { } else { var root_1680 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, A_arbace_box_build_fail_A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any; var tmp3 *jrt.RefArray = jrt.ConstRefArray("[0,7,s31:arbace.box.build: no image for ns15: (the ref tool.ns1:.ns1:)", []*jrt.Class{jrt.String_class}); var tmp4 any; var root_1672 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1672, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1674 lang.IFn; if linked_1673 == nil { ifn_1674 = lang.IFn_Cast(root_1672) } else { ifn_1674 = nil }; var arg_1675 any = t__10; if linked_1673 == nil { tmp4 = ifn_1674.Invoke_O__O(arg_1675) } else { tmp4 = linked_1673.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1672, arg_1675) }; var tmp5 any = tmp4; var tmp6 any; var root_1676 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1676, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1678 lang.IFn; if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1679 any = t__10; if linked_1677 == nil { tmp6 = ifn_1678.Invoke_O__O(arg_1679) } else { tmp6 = linked_1677.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1676, arg_1679) }; arg_1683 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp6, nil, arch__3, nil)).Ref(); var arg_1684 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1681 == nil { ifn_1682.Invoke_O_O__O(arg_1683, arg_1684) } else { linked_1681.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_1680, arg_1683, arg_1684) } }; seq_598000231__5, chunk_598000232__6, count_598000233__7, i_598000234__8 = seq_598000231__5, chunk_598000232__6, count_598000233__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_598000234__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1656 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1658 lang.IFn; if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any = seq_598000231__5; if linked_1657 == nil { temp__1927000414__auto____9 = ifn_1658.Invoke_O__O(arg_1659) } else { temp__1927000414__auto____9 = linked_1657.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1656, arg_1659) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_598000231__10 any = temp__1927000414__auto____9; var tmp7 any; var root_1660 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = seq_598000231__10; if linked_1661 == nil { tmp7 = ifn_1662.Invoke_O__O(arg_1663) } else { tmp7 = linked_1661.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1660, arg_1663) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____11 any; var root_1664 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = seq_598000231__10; if linked_1665 == nil { c__1927000678__auto____11 = ifn_1666.Invoke_O__O(arg_1667) } else { c__1927000678__auto____11 = linked_1665.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1664, arg_1667) }; var tmp8 any; var root_1685 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1685, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1687 lang.IFn; if linked_1686 == nil { ifn_1687 = lang.IFn_Cast(root_1685) } else { ifn_1687 = nil }; var arg_1688 any = seq_598000231__10; if linked_1686 == nil { tmp8 = ifn_1687.Invoke_O__O(arg_1688) } else { tmp8 = linked_1686.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1685, arg_1688) }; seq_598000231__5, chunk_598000232__6, count_598000233__7, i_598000234__8 = tmp8, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__598000238__11 any; var root_1668 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = seq_598000231__10; if linked_1669 == nil { vec__598000238__11 = ifn_1670.Invoke_O__O(arg_1671) } else { vec__598000238__11 = linked_1669.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1668, arg_1671) }; var t__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000238__11, lang.RT_IntCast_J__I_NoInit(0), nil); var h__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000238__11, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(h__13) { } else { var root_1697 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_1698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1697, A_arbace_box_build_fail_A_fn_class); var ifn_1699 lang.IFn; if linked_1698 == nil { ifn_1699 = lang.IFn_Cast(root_1697) } else { ifn_1699 = nil }; var arg_1700 any; var tmp9 *jrt.RefArray = jrt.ConstRefArray("[0,7,s31:arbace.box.build: no image for ns15: (the ref tool.ns1:.ns1:)", []*jrt.Class{jrt.String_class}); var tmp10 any; var root_1689 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1689, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1691 lang.IFn; if linked_1690 == nil { ifn_1691 = lang.IFn_Cast(root_1689) } else { ifn_1691 = nil }; var arg_1692 any = t__12; if linked_1690 == nil { tmp10 = ifn_1691.Invoke_O__O(arg_1692) } else { tmp10 = linked_1690.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1689, arg_1692) }; var tmp11 any = tmp10; var tmp12 any; var root_1693 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1693, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1695 lang.IFn; if linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var arg_1696 any = t__12; if linked_1694 == nil { tmp12 = ifn_1695.Invoke_O__O(arg_1696) } else { tmp12 = linked_1694.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1693, arg_1696) }; arg_1700 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp11, nil, tmp12, nil, arch__3, nil)).Ref(); var arg_1701 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1698 == nil { ifn_1699.Invoke_O_O__O(arg_1700, arg_1701) } else { linked_1698.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_1697, arg_1700, arg_1701) } }; var tmp13 any; var root_1702 any = A_arbace_box_build_A_const_20.GetRawRoot__O(); var linked_1703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1702, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1704 lang.IFn; if linked_1703 == nil { ifn_1704 = lang.IFn_Cast(root_1702) } else { ifn_1704 = nil }; var arg_1705 any = seq_598000231__10; if linked_1703 == nil { tmp13 = ifn_1704.Invoke_O__O(arg_1705) } else { tmp13 = linked_1703.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1702, arg_1705) }; seq_598000231__5, chunk_598000232__6, count_598000233__7, i_598000234__8 = tmp13, nil, 0, 0; continue L1 } } }
//line :281:1
		break L1 }; var root_1646 any =







	A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_1647 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1646, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1648 lang.IFn; if linked_1647 == nil { ifn_1648 = lang.IFn_Cast(root_1646) } else { ifn_1648 = nil }; var arg_1649 any = opts__1; var arg_1650 any = A_arbace_box_build_A_const_120; var arg_1651 any = tools__4; if linked_1647 == nil { return ifn_1648.Invoke_O_O_O__O(arg_1649, arg_1650, arg_1651) } else { return linked_1647.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1646, arg_1649, arg_1650, arg_1651) } }
//line :285:1
func A_arbace_box_build_with_tools_iter__598000221__598000225_A_New_O(p0 any) *A_arbace_box_build_with_tools_iter__598000221__598000225_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_with_tools_iter__598000221__598000225_A{}; t.Ctor_O(p0); return t }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_A) Ctor_O(c__arch any) { t.F_arch = c__arch }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_A) Invoke_O_O__O(self, s__598000222__1 any) any { var tmp1 any = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_New_O_O_O(s__598000222__1, t.F_arch, self); var tmp2 *jrt.Class; var fncls__1634 *jrt.Class = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_fn_class; if fncls__1634 == nil { var fncls__1634d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_fn_class = fncls__1634d; tmp2 = fncls__1634d } else { tmp2 = fncls__1634 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :285:1
func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A) Ctor_O_O_O(c__s__598000222, c__arch, c__iter__598000221 any) { t.F_s__598000222 = c__s__598000222; t.F_arch = c__arch; t.F_iter__598000221 = c__iter__598000221 }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A) Invoke_O__O(self any) any { { var s__598000222__1 any; var t_ any = t.F_s__598000222; t.F_s__598000222 = nil; s__598000222__1 = t_; for { var temp__1927000414__auto____2 any; var root_1561 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1563 lang.IFn; if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any = s__598000222__1; if linked_1562 == nil { temp__1927000414__auto____2 = ifn_1563.Invoke_O__O(arg_1564) } else { temp__1927000414__auto____2 = linked_1562.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1561, arg_1564) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000222__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1565 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1565, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1567 lang.IFn; if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any = s__598000222__3; if linked_1566 == nil { tmp1 = ifn_1567.Invoke_O__O(arg_1568) } else { tmp1 = linked_1566.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1565, arg_1568) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1569 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1569, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1571 lang.IFn; if linked_1570 == nil { ifn_1571 = lang.IFn_Cast(root_1569) } else { ifn_1571 = nil }; var arg_1572 any = s__598000222__3; if linked_1570 == nil { c__1927001037__auto____4 = ifn_1571.Invoke_O__O(arg_1572) } else { c__1927001037__auto____4 = linked_1570.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1569, arg_1572) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000224__6 any; var root_1573 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1573, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1575 lang.IFn; if linked_1574 == nil { ifn_1575 = lang.IFn_Cast(root_1573) } else { ifn_1575 = nil }; var arg_1576 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1574 == nil { b__598000224__6 = ifn_1575.Invoke_O__O(arg_1576) } else { b__598000224__6 = linked_1574.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1573, arg_1576) }; var tmp2 any = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_New_O_O_I_O(b__598000224__6, t.F_arch, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1590 *jrt.Class = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_fn_class; if fncls__1590 == nil { var fncls__1590d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_fn_class = fncls__1590d; tmp3 = fncls__1590d } else { tmp3 = fncls__1590 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1599 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1601 lang.IFn; if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any; var root_1591 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = b__598000224__6; if linked_1592 == nil { arg_1602 = ifn_1593.Invoke_O__O(arg_1594) } else { arg_1602 = linked_1592.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1591, arg_1594) }; var arg_1603 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000221); var tmp5 any; var root_1595 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1597 lang.IFn; if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any = s__598000222__3; if linked_1596 == nil { tmp5 = ifn_1597.Invoke_O__O(arg_1598) } else { tmp5 = linked_1596.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1595, arg_1598) }; arg_1603 = tmp4.Invoke_O__O(tmp5); if linked_1600 == nil { return ifn_1601.Invoke_O_O__O(arg_1602, arg_1603) } else { return linked_1600.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1599, arg_1602, arg_1603) } } else { var root_1608 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any; var root_1604 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1606 lang.IFn; if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = b__598000224__6; if linked_1605 == nil { arg_1611 = ifn_1606.Invoke_O__O(arg_1607) } else { arg_1611 = linked_1605.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1604, arg_1607) }; var arg_1612 any; if linked_1609 == nil { return ifn_1610.Invoke_O_O__O(arg_1611, arg_1612) } else { return linked_1609.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1608, arg_1611, arg_1612) } } } else { var t__4 any; var root_1613 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1613, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1615 lang.IFn; if linked_1614 == nil { ifn_1615 = lang.IFn_Cast(root_1613) } else { ifn_1615 = nil }; var arg_1616 any = s__598000222__3; if linked_1614 == nil { t__4 = ifn_1615.Invoke_O__O(arg_1616) } else { t__4 = linked_1614.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1613, arg_1616) }; var root_1629 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1629, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1631 lang.IFn; if linked_1630 == nil { ifn_1631 = lang.IFn_Cast(root_1629) } else { ifn_1631 = nil }; var arg_1632 any; var tmp6 any; var root_1621 any = A_arbace_box_build_A_const_61.GetRawRoot__O(); var linked_1622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1621, aot_arbace_box.A_arbace_box_ref_A_fn_class); var ifn_1623 lang.IFn
														if linked_1622 == nil { ifn_1623 = lang.IFn_Cast(root_1621) } else { ifn_1623 = nil }; var arg_1624 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_152, nil, Lit_153, nil); var tmp8 any; var root_1617 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1617, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1619 lang.IFn; if linked_1618 == nil { ifn_1619 = lang.IFn_Cast(root_1617) } else { ifn_1619 = nil }; var arg_1620 any = t__4; if linked_1618 == nil { tmp8 = ifn_1619.Invoke_O__O(arg_1620) } else { tmp8 = linked_1618.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1617, arg_1620) }; arg_1624 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil, t.F_arch)).Ref(); if linked_1622 == nil { tmp6 = ifn_1623.Invoke_O__O(arg_1624) } else { tmp6 = linked_1622.(*aot_arbace_box.A_arbace_box_ref_A).Invoke_O_O__O(root_1621, arg_1624) }
//line :285:1
	arg_1632 = lang.Tuple_Create_O_O__IPersistentVector(t__4, tmp6); var arg_1633 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__598000221); var tmp10 any; var root_1625 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1625, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1627 lang.IFn; if linked_1626 == nil { ifn_1627 = lang.IFn_Cast(root_1625) } else { ifn_1627 = nil }; var arg_1628 any = s__598000222__3; if linked_1626 == nil { tmp10 = ifn_1627.Invoke_O__O(arg_1628) } else { tmp10 = linked_1626.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1625, arg_1628) }; arg_1633 = tmp9.Invoke_O__O(tmp10); if linked_1630 == nil { return ifn_1631.Invoke_O_O__O(arg_1632, arg_1633) } else { return linked_1630.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1629, arg_1632, arg_1633) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :285:1
func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A) Ctor_O_O_I_O(c__b__598000224, c__arch any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000224 = c__b__598000224; t.F_arch = c__arch; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A) Invoke_O__O(self any) any { { var i__598000223__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000223__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000223__1)); var root_1585 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1585, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1587 lang.IFn; if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var arg_1588 any = t.F_b__598000224; var arg_1589 any; var tmp2 any; var root_1581 any = A_arbace_box_build_A_const_61.GetRawRoot__O(); var linked_1582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1581, aot_arbace_box.A_arbace_box_ref_A_fn_class); var ifn_1583 lang.IFn
																if linked_1582 == nil { ifn_1583 = lang.IFn_Cast(root_1581) } else { ifn_1583 = nil }; var arg_1584 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_152, nil, Lit_153, nil); var tmp4 any; var root_1577 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = t__2; if linked_1578 == nil { tmp4 = ifn_1579.Invoke_O__O(arg_1580) } else { tmp4 = linked_1578.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1577, arg_1580) }; arg_1584 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, t.F_arch)).Ref(); if linked_1582 == nil { tmp2 = ifn_1583.Invoke_O__O(arg_1584) } else { tmp2 = linked_1582.(*aot_arbace_box.A_arbace_box_ref_A).Invoke_O_O__O(root_1581, arg_1584) }
//line :285:1
	arg_1589 = lang.Tuple_Create_O_O__IPersistentVector(t__2, tmp2); if linked_1586 == nil { ifn_1587.Invoke_O_O__O(arg_1588, arg_1589) } else { linked_1586.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1585, arg_1588, arg_1589) }; i__598000223__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000223__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_box_build_archives_A_New() *A_arbace_box_build_archives_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_box_build_archives_A) Ctor() {}
//line :291:1
func (t *A_arbace_box_build_archives_A) Invoke_O_O_O__O(self, plan__0, opts__1 any) any { var p__3 any; var root_1706 any = A_arbace_box_build_A_const_169.GetRawRoot__O(); var linked_1707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1706, A_arbace_box_build_read_plan_A_fn_class); var ifn_1708 lang.IFn; if




	linked_1707 == nil { ifn_1708 = lang.IFn_Cast(root_1706) } else { ifn_1708 = nil }; var arg_1709 any = plan__0; if linked_1707 == nil { p__3 = ifn_1708.Invoke_O__O(arg_1709) } else { p__3 = linked_1707.(*A_arbace_box_build_read_plan_A).Invoke_O_O__O(root_1706, arg_1709) }; var opts__4 any; var root_1710 any = /*line :291:1*/A_arbace_box_build_A_const_170.GetRawRoot__O(); var linked_1711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1710, A_arbace_box_build_with_tools_A_fn_class); var ifn_1712 lang.IFn; if





	linked_1711 == nil { ifn_1712 = lang.IFn_Cast(root_1710) } else { ifn_1712 = nil }; var arg_1713 any = p__3; var arg_1714 any = opts__1; if linked_1711 == nil { opts__4 = ifn_1712.Invoke_O_O__O(arg_1713, arg_1714) } else { opts__4 = linked_1711.(*A_arbace_box_build_with_tools_A).Invoke_O_O_O__O(root_1710, arg_1713, arg_1714) }; var pkgs__5 any = /*line :291:1*/A_arbace_box_build_A_const_41.Invoke_O__O(p__3); var index__6 any; var root_1721 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1721, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1723 lang.IFn; if







	linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1725 any; var root_1716 any = A_arbace_box_build_A_const_171.GetRawRoot__O(); var linked_1717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1716, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1718 lang.IFn; if linked_1717 == nil { ifn_1718 = lang.IFn_Cast(root_1716) } else { ifn_1718 = nil }; var arg_1719 any; var tmp1 any = A_arbace_box_build_archives_fn__598000242_A_New(); var tmp2 *jrt.Class; var fncls__1715 *jrt.Class = A_arbace_box_build_archives_fn__598000242_A_fn_class; if fncls__1715 == nil { var fncls__1715d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_box_build_archives_fn__598000242_A_fn_class = fncls__1715d; tmp2 = fncls__1715d } else { tmp2 = fncls__1715 }; arg_1719 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1720 any = pkgs__5; if linked_1717 == nil { arg_1725 = ifn_1718.Invoke_O_O__O(arg_1719, arg_1720) } else { arg_1725 = linked_1717.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1716, arg_1719, arg_1720) }; if linked_1722 == nil { index__6 = ifn_1723.Invoke_O_O__O(arg_1724, arg_1725) } else { index__6 = linked_1722.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1721, arg_1724, arg_1725) }; var given__7 any = /*line :291:1*/A_arbace_box_build_A_const_172.Invoke_O__O(opts__4); var only__8 any = A_arbace_box_build_A_const_173.Invoke_O__O(opts__4); var futures__9 any; var root_1726 any = A_arbace_box_build_A_const_35.GetRawRoot__O(); var linked_1727 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1726, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1728 lang.IFn; if











	linked_1727 == nil { ifn_1728 = lang.IFn_Cast(root_1726) } else { ifn_1728 = nil }; var arg_1729 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1727 == nil { futures__9 = ifn_1728.Invoke_O__O(arg_1729) } else { futures__9 = linked_1727.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1726, arg_1729) }; var sem__10 any = /*line :291:1*/jrt.Semaphore_New_I(lang.RT_IntCast_O__I_NoInit(A_arbace_box_build_A_const_174.Invoke_O_O__O(opts__4, A_arbace_box_build_A_const_175))); var conveyed__11 any; var tmp3 any = A_arbace_box_build_archives_conveyed__598000244_A_New_O(opts__4); var tmp4 *jrt.Class; var fncls__1743 *jrt.Class = A_arbace_box_build_archives_conveyed__598000244_A_fn_class; if













	fncls__1743 == nil { var fncls__1743d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_box_build_archives_conveyed__598000244_A_fn_class = fncls__1743d; tmp4 = fncls__1743d } else { tmp4 = fncls__1743 }; conveyed__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var root_1828 any =
	A_arbace_box_build_A_const_81.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1830 lang.IFn; if linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; var arg_1831 any = lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, opts__4); if linked_1829 == nil { ifn_1830.Invoke_O__O(arg_1831) } else { linked_1829.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1828, arg_1831) }; var tmp5 any; tmp23 := /*line :291:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_598000248__14 any; var root_1832 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1832, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1834 lang.IFn















		if linked_1833 == nil { ifn_1834 = lang.IFn_Cast(root_1832) } else { ifn_1834 = nil }; var arg_1835 any = pkgs__5; if linked_1833 == nil { seq_598000248__14 = ifn_1834.Invoke_O__O(arg_1835) } else { seq_598000248__14 = linked_1833.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1832, arg_1835) }
//line :291:1
		var chunk_598000249__15 any; var count_598000250__16 int64 = 0; var i_598000251__17 int64 = 0; L1: for {















			if lang.Numbers_Lt_J_J__Z_NoInit(i_598000251__17, count_598000250__16) { var q__18 any = lang.Indexed_Cast(chunk_598000249__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_598000251__17)); var deps__19 any; var root_1856 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1856, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1858 lang.IFn
				if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any; var root_1852 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = futures__9; if linked_1853 == nil { arg_1859 = ifn_1854.Invoke_O__O(arg_1855) } else { arg_1859 = linked_1853.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1852, arg_1855) }; var arg_1860 any = A_arbace_box_build_A_const_121.Invoke_O__O(q__18); if linked_1857 == nil { deps__19 = ifn_1858.Invoke_O_O__O(arg_1859, arg_1860) } else { deps__19 = linked_1857.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1856, arg_1859, arg_1860) }
				var root_1900 any = A_arbace_box_build_A_const_37.GetRawRoot__O(); var linked_1901 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1900, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1902 lang.IFn; if linked_1901 == nil { ifn_1902 = lang.IFn_Cast(root_1900) } else { ifn_1902 = nil }; var arg_1903 any = futures__9; var arg_1904 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var arg_1905 any = A_arbace_box_build_A_const_91.Invoke_O__O(q__18); var arg_1906 any; var tmp6 any; var and__1927000168__auto____20 any = only__8
				if jrt.J2g_Truth(and__1927000168__auto____20) { var root_1861 any = A_arbace_box_build_A_const_73.GetRawRoot__O(); var linked_1862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1861, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1863 lang.IFn; if linked_1862 == nil { ifn_1863 = lang.IFn_Cast(root_1861) } else { ifn_1863 = nil }; var arg_1864 any = lang.IFn_Cast(only__8).Invoke_O__O(A_arbace_box_build_A_const_91.Invoke_O__O(q__18)); if linked_1862 == nil { tmp6 = ifn_1863.Invoke_O__O(arg_1864) } else { tmp6 = linked_1862.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1861, arg_1864) } } else { tmp6 = and__1927000168__auto____20 }; if jrt.J2g_Truth(tmp6) { var tmp7 any = A_arbace_box_build_archives_fn__598000252_A_New_O_O(given__7, q__18); var tmp8 *jrt.Class; var fncls__1870 *jrt.Class = A_arbace_box_build_archives_fn__598000252_A_fn_class
					if fncls__1870 == nil { var fncls__1870d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_box_build_archives_fn__598000252_A_fn_class = fncls__1870d; tmp8 = fncls__1870d } else { tmp8 = fncls__1870 }
//line :310:1
					arg_1906 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)) } else {

						var root_1896 any = A_arbace_box_build_A_const_145.GetRawRoot__O(); var linked_1897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1896, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_1898 lang.IFn; if linked_1897 == nil { ifn_1898 = lang.IFn_Cast(root_1896) } else { ifn_1898 = nil }; var arg_1899 any; var tmp9 any = A_arbace_box_build_archives_fn__598000254_A_New_O_O_O_O_O_O(index__6, p__3, deps__19, sem__10, conveyed__11, q__18); var tmp10 *jrt.Class; var fncls__1895 *jrt.Class = A_arbace_box_build_archives_fn__598000254_A_fn_class; if fncls__1895 == nil { var fncls__1895d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_box_build_archives_fn__598000254_A_fn_class = fncls__1895d; tmp10 = fncls__1895d } else { tmp10 = fncls__1895 }; arg_1899 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); if linked_1897 == nil { arg_1906 = ifn_1898.Invoke_O__O(arg_1899) } else { arg_1906 = linked_1897.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_1896, arg_1899) } }
//line :309:1
				if linked_1901 == nil { ifn_1902.Invoke_O_O_O_O__O(arg_1903, arg_1904, arg_1905, arg_1906) } else { linked_1901.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1900, arg_1903, arg_1904, arg_1905, arg_1906) }
//line :307:1
				seq_598000248__14, chunk_598000249__15, count_598000250__16, i_598000251__17 = seq_598000248__14, chunk_598000249__15, count_598000250__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_598000251__17); continue L1 } else { var temp__1927000414__auto____18 any; var root_1836 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any = seq_598000248__14; if linked_1837 == nil { temp__1927000414__auto____18 = ifn_1838.Invoke_O__O(arg_1839) } else { temp__1927000414__auto____18 = linked_1837.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1836, arg_1839) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_598000248__19 any = temp__1927000414__auto____18; var tmp11 any; var root_1840 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1840, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1842 lang.IFn; if linked_1841 == nil { ifn_1842 = lang.IFn_Cast(root_1840) } else { ifn_1842 = nil }; var arg_1843 any = seq_598000248__19; if linked_1841 == nil { tmp11 = ifn_1842.Invoke_O__O(arg_1843) } else { tmp11 = linked_1841.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1840, arg_1843) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____20 any; var root_1844 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1844, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1846 lang.IFn; if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any = seq_598000248__19; if linked_1845 == nil { c__1927000678__auto____20 = ifn_1846.Invoke_O__O(arg_1847) } else { c__1927000678__auto____20 = linked_1845.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1844, arg_1847) }; var tmp12 any; var root_1907 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1907, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1909 lang.IFn; if linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = seq_598000248__19; if linked_1908 == nil { tmp12 = ifn_1909.Invoke_O__O(arg_1910) } else { tmp12 = linked_1908.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1907, arg_1910) }; seq_598000248__14, chunk_598000249__15, count_598000250__16, i_598000251__17 = tmp12, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var q__20 any; var root_1848 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1848, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1850 lang.IFn; if linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = seq_598000248__19; if linked_1849 == nil { q__20 = ifn_1850.Invoke_O__O(arg_1851) } else { q__20 = linked_1849.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1848, arg_1851) }; var deps__21 any; var root_1915 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1916 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1915, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1917 lang.IFn
					if linked_1916 == nil { ifn_1917 = lang.IFn_Cast(root_1915) } else { ifn_1917 = nil }; var arg_1918 any; var root_1911 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1911, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1913 lang.IFn; if linked_1912 == nil { ifn_1913 = lang.IFn_Cast(root_1911) } else { ifn_1913 = nil }; var arg_1914 any = futures__9; if linked_1912 == nil { arg_1918 = ifn_1913.Invoke_O__O(arg_1914) } else { arg_1918 = linked_1912.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1911, arg_1914) }; var arg_1919 any = A_arbace_box_build_A_const_121.Invoke_O__O(q__20); if linked_1916 == nil { deps__21 = ifn_1917.Invoke_O_O__O(arg_1918, arg_1919) } else { deps__21 = linked_1916.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1915, arg_1918, arg_1919) }
					var root_1959 any = A_arbace_box_build_A_const_37.GetRawRoot__O(); var linked_1960 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1959, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1961 lang.IFn; if linked_1960 == nil { ifn_1961 = lang.IFn_Cast(root_1959) } else { ifn_1961 = nil }; var arg_1962 any = futures__9; var arg_1963 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var arg_1964 any = A_arbace_box_build_A_const_91.Invoke_O__O(q__20); var arg_1965 any; var tmp13 any; var and__1927000168__auto____22 any = only__8
					if jrt.J2g_Truth(and__1927000168__auto____22) { var root_1920 any = A_arbace_box_build_A_const_73.GetRawRoot__O(); var linked_1921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1920, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1922 lang.IFn; if linked_1921 == nil { ifn_1922 = lang.IFn_Cast(root_1920) } else { ifn_1922 = nil }; var arg_1923 any = lang.IFn_Cast(only__8).Invoke_O__O(A_arbace_box_build_A_const_91.Invoke_O__O(q__20)); if linked_1921 == nil { tmp13 = ifn_1922.Invoke_O__O(arg_1923) } else { tmp13 = linked_1921.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1920, arg_1923) } } else { tmp13 = and__1927000168__auto____22 }; if jrt.J2g_Truth(tmp13) { var tmp14 any = A_arbace_box_build_archives_fn__598000260_A_New_O_O(given__7, q__20); var tmp15 *jrt.Class; var fncls__1929 *jrt.Class = A_arbace_box_build_archives_fn__598000260_A_fn_class
						if fncls__1929 == nil { var fncls__1929d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_box_build_archives_fn__598000260_A_fn_class = fncls__1929d; tmp15 = fncls__1929d } else { tmp15 = fncls__1929 }
//line :310:1
						arg_1965 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil)) } else {

							var root_1955 any = A_arbace_box_build_A_const_145.GetRawRoot__O(); var linked_1956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1955, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_1957 lang.IFn; if linked_1956 == nil { ifn_1957 = lang.IFn_Cast(root_1955) } else { ifn_1957 = nil }; var arg_1958 any; var tmp16 any = A_arbace_box_build_archives_fn__598000262_A_New_O_O_O_O_O_O(index__6, p__3, deps__21, sem__10, conveyed__11, q__20); var tmp17 *jrt.Class; var fncls__1954 *jrt.Class = A_arbace_box_build_archives_fn__598000262_A_fn_class; if fncls__1954 == nil { var fncls__1954d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_box_build_archives_fn__598000262_A_fn_class = fncls__1954d; tmp17 = fncls__1954d } else { tmp17 = fncls__1954 }; arg_1958 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); if linked_1956 == nil { arg_1965 = ifn_1957.Invoke_O__O(arg_1958) } else { arg_1965 = linked_1956.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_1955, arg_1958) } }
//line :309:1
					if linked_1960 == nil { ifn_1961.Invoke_O_O_O_O__O(arg_1962, arg_1963, arg_1964, arg_1965) } else { linked_1960.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1959, arg_1962, arg_1963, arg_1964, arg_1965) }
//line :307:1
					var tmp18 any; var root_1966 any = A_arbace_box_build_A_const_20.GetRawRoot__O(); var linked_1967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1966, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1968 lang.IFn; if linked_1967 == nil { ifn_1968 = lang.IFn_Cast(root_1966) } else { ifn_1968 = nil }; var arg_1969 any = seq_598000248__19; if linked_1967 == nil { tmp18 = ifn_1968.Invoke_O__O(arg_1969) } else { tmp18 = linked_1967.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1966, arg_1969) }; seq_598000248__14, chunk_598000249__15, count_598000250__16, i_598000251__17 = tmp18, nil, 0, 0; continue L1 } } }
//line :291:1
			break L1
		}



























		var root_1815 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1815, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1817 lang.IFn; if linked_1816 == nil { ifn_1817 = lang.IFn_Cast(root_1815) } else { ifn_1817 = nil }; var arg_1818 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1819 any; var iter__1927001039__auto____14 any; var tmp19 any = A_arbace_box_build_archives_iter__598000268__598000272_A_New(); var tmp20 *jrt.Class; var fncls__1810 *jrt.Class = A_arbace_box_build_archives_iter__598000268__598000272_A_fn_class; if fncls__1810 == nil { var fncls__1810d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_box_build_archives_iter__598000268__598000272_A_fn_class = fncls__1810d; tmp20 = fncls__1810d } else { tmp20 = fncls__1810 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); var tmp21 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____14); var tmp22 any; var root_1811 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1811, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1813 lang.IFn; if linked_1812 == nil { ifn_1813 = lang.IFn_Cast(root_1811) } else { ifn_1813 = nil }; var arg_1814 any = futures__9; if linked_1812 == nil { tmp22 = ifn_1813.Invoke_O__O(arg_1814) } else { tmp22 = linked_1812.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1811, arg_1814) }; arg_1819 = tmp21.Invoke_O__O(tmp22); if linked_1816 == nil { tmp5 = ifn_1817.Invoke_O_O__O(arg_1818, arg_1819) } else { tmp5 = linked_1816.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1815, arg_1818, arg_1819) } }; return nil }(); var root_1820 any = /*line :291:1*/A_arbace_box_build_A_const_80.GetRawRoot__O(); var linked_1821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1820, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1822 lang.IFn; if














	linked_1821 == nil { ifn_1822 = lang.IFn_Cast(root_1820) } else { ifn_1822 = nil }; if linked_1821 == nil { ifn_1822.Invoke__O() } else { linked_1821.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1820) }; if /*line :291:1*/ tmp23 != nil { panic(tmp23) }; return tmp5 }







func A_arbace_box_build_archives_fn__598000242_A_New() *A_arbace_box_build_archives_fn__598000242_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000242_A{}; t.Ctor(); return t }
//line :299:1
func (t *A_arbace_box_build_archives_fn__598000242_A) Ctor() {}
//line :299:1
func (t *A_arbace_box_build_archives_fn__598000242_A) Invoke_O_O_O__O(self, i__1, q__2 any) any { return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_91.Invoke_O__O(q__2), i__1) }





func A_arbace_box_build_archives_conveyed__598000244_A_New_O(p0 any) *A_arbace_box_build_archives_conveyed__598000244_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_conveyed__598000244_A{}; t.Ctor_O(p0); return t }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_A) Invoke_O_O__O(self, f__1 any) any { var o__2 any = t.F_opts; var tmp1 any = A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_New_O_O(f__1, o__2); var tmp2 *jrt.Class; var fncls__1742 *jrt.Class = A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_fn_class; if fncls__1742 == nil { var fncls__1742d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_fn_class = fncls__1742d; tmp2 = fncls__1742d } else { tmp2 = fncls__1742 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :305:1
func A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A{}; t.Ctor_O_O(p0, p1); return t }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A) Ctor_O_O(c__f, c__o any) { t.F_f = c__f; t.F_o = c__o }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A) Invoke_O__O(self any) any { var root_1738 any = A_arbace_box_build_A_const_81.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1738, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1740 lang.IFn; if linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var arg_1741 any = lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, t.F_o); if linked_1739 == nil { ifn_1740.Invoke_O__O(arg_1741) } else { linked_1739.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1738, arg_1741) }; var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(t.F_f).Invoke__O(); return nil }(); var root_1730 any = A_arbace_box_build_A_const_80.GetRawRoot__O(); var linked_1731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1730, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1732 lang.IFn; if linked_1731 == nil { ifn_1732 = lang.IFn_Cast(root_1730) } else { ifn_1732 = nil }; if linked_1731 == nil { ifn_1732.Invoke__O() } else { linked_1731.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1730) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }





func A_arbace_box_build_archives_fn__598000252_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_fn__598000252_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000252_A{}; t.Ctor_O_O(p0, p1); return t }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000252_A) Ctor_O_O(c__given, c__q any) { t.F_given = c__given; t.F_q = c__q }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000252_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var tmp1 any; var t_ any = t.F_given; t.F_given = nil; tmp1 = t_; or__1927000174__auto____1 = lang.RT_Get_O_O__O_NoInit(tmp1, A_arbace_box_build_A_const_91.Invoke_O__O(t.F_q)); if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { var root_1865 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_1866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1865, A_arbace_box_build_fail_A_fn_class); var ifn_1867 lang.IFn; if linked_1866 == nil { ifn_1867 = lang.IFn_Cast(root_1865) } else { ifn_1867 = nil }; var arg_1868 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil); var tmp3 *lang.Keyword = A_arbace_box_build_A_const_91; var tmp4 any; var t__2 any = t.F_q; t.F_q = nil; tmp4 = t__2; arg_1868 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3.Invoke_O__O(tmp4))).Ref(); var arg_1869 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1866 == nil { return ifn_1867.Invoke_O_O__O(arg_1868, arg_1869) } else { return linked_1866.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_1865, arg_1868, arg_1869) } } }
//line :311:1
func A_arbace_box_build_archives_fn__598000260_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_fn__598000260_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000260_A{}; t.Ctor_O_O(p0, p1); return t }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000260_A) Ctor_O_O(c__given, c__q any) { t.F_given = c__given; t.F_q = c__q }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000260_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var tmp1 any; var t_ any = t.F_given; t.F_given = nil; tmp1 = t_; or__1927000174__auto____1 = lang.RT_Get_O_O__O_NoInit(tmp1, A_arbace_box_build_A_const_91.Invoke_O__O(t.F_q)); if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { var root_1924 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_1925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1924, A_arbace_box_build_fail_A_fn_class); var ifn_1926 lang.IFn; if linked_1925 == nil { ifn_1926 = lang.IFn_Cast(root_1924) } else { ifn_1926 = nil }; var arg_1927 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil); var tmp3 *lang.Keyword = A_arbace_box_build_A_const_91; var tmp4 any; var t__2 any = t.F_q; t.F_q = nil; tmp4 = t__2; arg_1927 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3.Invoke_O__O(tmp4))).Ref(); var arg_1928 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1925 == nil { return ifn_1926.Invoke_O_O__O(arg_1927, arg_1928) } else { return linked_1925.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_1924, arg_1927, arg_1928) } } }
func A_arbace_box_build_archives_fn__598000254_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_box_build_archives_fn__598000254_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000254_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000254_A) Ctor_O_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__conveyed, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_conveyed = c__conveyed; t.F_q = c__q }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000254_A) Invoke_O__O(self any) any {
	var tmp1 any; var t_ any = t.F_conveyed; t.F_conveyed = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any = A_arbace_box_build_archives_fn__598000254_fn__598000255_A_New_O_O_O_O_O(t.F_index, t.F_p, t.F_deps, t.F_sem, t.F_q); var tmp4 *jrt.Class; var fncls__1894 *jrt.Class = A_arbace_box_build_archives_fn__598000254_fn__598000255_A_fn_class
	if fncls__1894 == nil { var fncls__1894d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_box_build_archives_fn__598000254_fn__598000255_A_fn_class = fncls__1894d; tmp4 = fncls__1894d } else { tmp4 = fncls__1894 }
//line :313:1
	return lang.IFn_Cast(tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil))).Invoke__O() }
//line :312:1
func A_arbace_box_build_archives_fn__598000262_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_box_build_archives_fn__598000262_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000262_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000262_A) Ctor_O_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__conveyed, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_conveyed = c__conveyed; t.F_q = c__q }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000262_A) Invoke_O__O(self any) any {
	var tmp1 any; var t_ any = t.F_conveyed; t.F_conveyed = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any = A_arbace_box_build_archives_fn__598000262_fn__598000263_A_New_O_O_O_O_O(t.F_index, t.F_p, t.F_deps, t.F_sem, t.F_q); var tmp4 *jrt.Class; var fncls__1953 *jrt.Class = A_arbace_box_build_archives_fn__598000262_fn__598000263_A_fn_class
	if fncls__1953 == nil { var fncls__1953d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_box_build_archives_fn__598000262_fn__598000263_A_fn_class = fncls__1953d; tmp4 = fncls__1953d } else { tmp4 = fncls__1953 }
//line :313:1
	return lang.IFn_Cast(tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil))).Invoke__O() }
func A_arbace_box_build_archives_fn__598000254_fn__598000255_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_box_build_archives_fn__598000254_fn__598000255_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000254_fn__598000255_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_A) Ctor_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_q = c__q }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_A) Invoke_O__O(self any) any { var archives__1 any; var root_1882 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1882, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1884 lang.IFn; if
												linked_1883 == nil { ifn_1884 = lang.IFn_Cast(root_1882) } else { ifn_1884 = nil }; var arg_1885 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1886 any; var root_1876 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1876, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1878 lang.IFn; if linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any; var tmp1 any = A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_New(); var tmp2 *jrt.Class; var fncls__1875 *jrt.Class = A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_fn_class; if fncls__1875 == nil { var fncls__1875d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_fn_class = fncls__1875d; tmp2 = fncls__1875d } else { tmp2 = fncls__1875 }; arg_1879 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1880 any = A_arbace_box_build_A_const_121.Invoke_O__O(t.F_q); var arg_1881 any = t.F_deps; if linked_1877 == nil { arg_1886 = ifn_1878.Invoke_O_O_O__O(arg_1879, arg_1880, arg_1881) } else { arg_1886 = linked_1877.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1876, arg_1879, arg_1880, arg_1881) }; if linked_1883 == nil { archives__1 = ifn_1884.Invoke_O_O__O(arg_1885, arg_1886) } else { archives__1 = linked_1883.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1882, arg_1885, arg_1886) };
												jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Acquire__V(); var tmp3 any; tmp4 := /*line :314:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		{ var root_1887 any = A_arbace_box_build_A_const_176.GetRawRoot__O(); var linked_1888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1887, A_arbace_box_build_build_package_A_fn_class); var ifn_1889 lang.IFn; if linked_1888 == nil { ifn_1889 = lang.IFn_Cast(root_1887) } else { ifn_1889 = nil }; var arg_1890 any = t.F_p; var arg_1891 any = t.F_q; var arg_1892 any = archives__1; var arg_1893 any = t.F_index; if linked_1888 == nil { tmp3 = ifn_1889.Invoke_O_O_O_O__O(arg_1890, arg_1891, arg_1892, arg_1893) } else { tmp3 = linked_1888.(*A_arbace_box_build_build_package_A).Invoke_O_O_O_O_O__O(root_1887, arg_1890, arg_1891, arg_1892, arg_1893) } }
//line :314:1
		return nil }();




	jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Release__V(); if /*line :314:1*/ tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :314:1
func A_arbace_box_build_archives_fn__598000262_fn__598000263_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_box_build_archives_fn__598000262_fn__598000263_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000262_fn__598000263_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_A) Ctor_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_q = c__q }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_A) Invoke_O__O(self any) any { var archives__1 any; var root_1941 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1941, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1943 lang.IFn; if
												linked_1942 == nil { ifn_1943 = lang.IFn_Cast(root_1941) } else { ifn_1943 = nil }; var arg_1944 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1945 any; var root_1935 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1936 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1935, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1937 lang.IFn; if linked_1936 == nil { ifn_1937 = lang.IFn_Cast(root_1935) } else { ifn_1937 = nil }; var arg_1938 any; var tmp1 any = A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_New(); var tmp2 *jrt.Class; var fncls__1934 *jrt.Class = A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_fn_class; if fncls__1934 == nil { var fncls__1934d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_fn_class = fncls__1934d; tmp2 = fncls__1934d } else { tmp2 = fncls__1934 }; arg_1938 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1939 any = A_arbace_box_build_A_const_121.Invoke_O__O(t.F_q); var arg_1940 any = t.F_deps; if linked_1936 == nil { arg_1945 = ifn_1937.Invoke_O_O_O__O(arg_1938, arg_1939, arg_1940) } else { arg_1945 = linked_1936.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1935, arg_1938, arg_1939, arg_1940) }; if linked_1942 == nil { archives__1 = ifn_1943.Invoke_O_O__O(arg_1944, arg_1945) } else { archives__1 = linked_1942.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1941, arg_1944, arg_1945) };
												jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Acquire__V(); var tmp3 any; tmp4 := /*line :314:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		{ var root_1946 any = A_arbace_box_build_A_const_176.GetRawRoot__O(); var linked_1947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1946, A_arbace_box_build_build_package_A_fn_class); var ifn_1948 lang.IFn; if linked_1947 == nil { ifn_1948 = lang.IFn_Cast(root_1946) } else { ifn_1948 = nil }; var arg_1949 any = t.F_p; var arg_1950 any = t.F_q; var arg_1951 any = archives__1; var arg_1952 any = t.F_index; if linked_1947 == nil { tmp3 = ifn_1948.Invoke_O_O_O_O__O(arg_1949, arg_1950, arg_1951, arg_1952) } else { tmp3 = linked_1947.(*A_arbace_box_build_build_package_A).Invoke_O_O_O_O_O__O(root_1946, arg_1949, arg_1950, arg_1951, arg_1952) } }
//line :314:1
		return nil }();




	jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Release__V(); if /*line :314:1*/ tmp4 != nil { panic(tmp4) }; return tmp3 }
func A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_New() *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A) Ctor() {}
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A) Invoke_O_O_O__O(self, i__1, d__2 any) any { var tmp1 any; var root_1871 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1871, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1873 lang.IFn; if linked_1872 == nil { ifn_1873 = lang.IFn_Cast(root_1871) } else { ifn_1873 = nil }; var arg_1874 any = d__2; if linked_1872 == nil { tmp1 = ifn_1873.Invoke_O__O(arg_1874) } else { tmp1 = linked_1872.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1871, arg_1874) }; return lang.Tuple_Create_O_O__IPersistentVector(i__1, tmp1) }
//line :315:1
func A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_New() *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A) Ctor() {}
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A) Invoke_O_O_O__O(self, i__1, d__2 any) any { var tmp1 any; var root_1930 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1930, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1932 lang.IFn; if linked_1931 == nil { ifn_1932 = lang.IFn_Cast(root_1930) } else { ifn_1932 = nil }; var arg_1933 any = d__2; if linked_1931 == nil { tmp1 = ifn_1932.Invoke_O__O(arg_1933) } else { tmp1 = linked_1931.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1930, arg_1933) }; return lang.Tuple_Create_O_O__IPersistentVector(i__1, tmp1) }




func A_arbace_box_build_archives_iter__598000268__598000272_A_New() *A_arbace_box_build_archives_iter__598000268__598000272_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_iter__598000268__598000272_A{}; t.Ctor(); return t }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_A) Ctor() {}
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_A) Invoke_O_O__O(self, s__598000269__1 any) any { var tmp1 any = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_New_O_O(self, s__598000269__1); var tmp2 *jrt.Class; var fncls__1809 *jrt.Class = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_fn_class; if fncls__1809 == nil { var fncls__1809d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_fn_class = fncls__1809d; tmp2 = fncls__1809d } else { tmp2 = fncls__1809 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :320:1
func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A{}; t.Ctor_O_O(p0, p1); return t }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A) Ctor_O_O(c__iter__598000268, c__s__598000269 any) { t.F_iter__598000268 = c__iter__598000268; t.F_s__598000269 = c__s__598000269 }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A) Invoke_O__O(self any) any { { var s__598000269__1 any; var t_ any = t.F_s__598000269; t.F_s__598000269 = nil; s__598000269__1 = t_; for { var temp__1927000414__auto____2 any; var root_1744 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = s__598000269__1; if linked_1745 == nil { temp__1927000414__auto____2 = ifn_1746.Invoke_O__O(arg_1747) } else { temp__1927000414__auto____2 = linked_1745.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1744, arg_1747) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000269__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1748 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1748, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1750 lang.IFn; if linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var arg_1751 any = s__598000269__3; if linked_1749 == nil { tmp1 = ifn_1750.Invoke_O__O(arg_1751) } else { tmp1 = linked_1749.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1748, arg_1751) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1752 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1752, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1754 lang.IFn; if linked_1753 == nil { ifn_1754 = lang.IFn_Cast(root_1752) } else { ifn_1754 = nil }; var arg_1755 any = s__598000269__3; if linked_1753 == nil { c__1927001037__auto____4 = ifn_1754.Invoke_O__O(arg_1755) } else { c__1927001037__auto____4 = linked_1753.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1752, arg_1755) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000271__6 any; var root_1756 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1756, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1758 lang.IFn; if linked_1757 == nil { ifn_1758 = lang.IFn_Cast(root_1756) } else { ifn_1758 = nil }; var arg_1759 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1757 == nil { b__598000271__6 = ifn_1758.Invoke_O__O(arg_1759) } else { b__598000271__6 = linked_1757.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1756, arg_1759) }; var tmp2 any = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_New_O_I_O(b__598000271__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1769 *jrt.Class = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_fn_class; if fncls__1769 == nil { var fncls__1769d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_fn_class = fncls__1769d; tmp3 = fncls__1769d } else { tmp3 = fncls__1769 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1778 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1778, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1780 lang.IFn; if linked_1779 == nil { ifn_1780 = lang.IFn_Cast(root_1778) } else { ifn_1780 = nil }; var arg_1781 any; var root_1770 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1770, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1772 lang.IFn; if linked_1771 == nil { ifn_1772 = lang.IFn_Cast(root_1770) } else { ifn_1772 = nil }; var arg_1773 any = b__598000271__6; if linked_1771 == nil { arg_1781 = ifn_1772.Invoke_O__O(arg_1773) } else { arg_1781 = linked_1771.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1770, arg_1773) }; var arg_1782 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000268); var tmp5 any; var root_1774 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1774, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1776 lang.IFn; if linked_1775 == nil { ifn_1776 = lang.IFn_Cast(root_1774) } else { ifn_1776 = nil }; var arg_1777 any = s__598000269__3; if linked_1775 == nil { tmp5 = ifn_1776.Invoke_O__O(arg_1777) } else { tmp5 = linked_1775.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1774, arg_1777) }; arg_1782 = tmp4.Invoke_O__O(tmp5); if linked_1779 == nil { return ifn_1780.Invoke_O_O__O(arg_1781, arg_1782) } else { return linked_1779.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1778, arg_1781, arg_1782) } } else { var root_1787 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1789 lang.IFn; if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any; var root_1783 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any = b__598000271__6; if linked_1784 == nil { arg_1790 = ifn_1785.Invoke_O__O(arg_1786) } else { arg_1790 = linked_1784.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1783, arg_1786) }; var arg_1791 any; if linked_1788 == nil { return ifn_1789.Invoke_O_O__O(arg_1790, arg_1791) } else { return linked_1788.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1787, arg_1790, arg_1791) } } } else { var vec__598000279__4 any; var root_1792 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1792, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1794 lang.IFn; if linked_1793 == nil { ifn_1794 = lang.IFn_Cast(root_1792) } else { ifn_1794 = nil }; var arg_1795 any = s__598000269__3; if linked_1793 == nil { vec__598000279__4 = ifn_1794.Invoke_O__O(arg_1795) } else { vec__598000279__4 = linked_1793.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1792, arg_1795) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000279__4, lang.RT_IntCast_J__I_NoInit(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000279__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1804 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1804, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1806 lang.IFn; if linked_1805 == nil { ifn_1806 = lang.IFn_Cast(root_1804) } else { ifn_1806 = nil }; var arg_1807 any; var tmp6 any; var root_1796 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1798 lang.IFn; if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any = f__6; if linked_1797 == nil { tmp6 = ifn_1798.Invoke_O__O(arg_1799) } else { tmp6 = linked_1797.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1796, arg_1799) }; arg_1807 = lang.Tuple_Create_O_O__IPersistentVector(k__5, tmp6); var arg_1808 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__598000268); var tmp8 any; var root_1800 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1800, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1802 lang.IFn; if linked_1801 == nil { ifn_1802 = lang.IFn_Cast(root_1800) } else { ifn_1802 = nil }; var arg_1803 any = s__598000269__3; if linked_1801 == nil { tmp8 = ifn_1802.Invoke_O__O(arg_1803) } else { tmp8 = linked_1801.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1800, arg_1803) }; arg_1808 = tmp7.Invoke_O__O(tmp8); if linked_1805 == nil { return ifn_1806.Invoke_O_O__O(arg_1807, arg_1808) } else { return linked_1805.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1804, arg_1807, arg_1808) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :320:1
func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A) Ctor_O_I_O(c__b__598000271 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000271 = c__b__598000271; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A) Invoke_O__O(self any) any { { var i__598000270__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000270__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000275__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000270__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000275__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000275__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1764 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1764, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1766 lang.IFn; if linked_1765 == nil { ifn_1766 = lang.IFn_Cast(root_1764) } else { ifn_1766 = nil }; var arg_1767 any = t.F_b__598000271; var arg_1768 any; var tmp2 any; var root_1760 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1760, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1762 lang.IFn; if linked_1761 == nil { ifn_1762 = lang.IFn_Cast(root_1760) } else { ifn_1762 = nil }; var arg_1763 any = f__4; if linked_1761 == nil { tmp2 = ifn_1762.Invoke_O__O(arg_1763) } else { tmp2 = linked_1761.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1760, arg_1763) }; arg_1768 = lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp2); if linked_1765 == nil { ifn_1766.Invoke_O_O__O(arg_1767, arg_1768) } else { linked_1765.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1764, arg_1767, arg_1768) }; i__598000270__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000270__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_box_build_link_A_New() *A_arbace_box_build_link_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_box_build_link_A) Ctor() {}
//line :322:1
func (t *A_arbace_box_build_link_A) Invoke_O_O_O_O__O(self, plan__0, archives__1, opts__2 any) any { var p__4 any; var root_1970 any = A_arbace_box_build_A_const_169.GetRawRoot__O(); var linked_1971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1970, A_arbace_box_build_read_plan_A_fn_class); var ifn_1972 lang.IFn; if




	linked_1971 == nil { ifn_1972 = lang.IFn_Cast(root_1970) } else { ifn_1972 = nil }; var arg_1973 any = plan__0; if linked_1971 == nil { p__4 = ifn_1972.Invoke_O__O(arg_1973) } else { p__4 = linked_1971.(*A_arbace_box_build_read_plan_A).Invoke_O_O__O(root_1970, arg_1973) }; var opts__5 any; var root_1974 any = /*line :322:1*/A_arbace_box_build_A_const_170.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, A_arbace_box_build_with_tools_A_fn_class); var ifn_1976 lang.IFn; if





	linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = p__4; var arg_1978 any = opts__2; if linked_1975 == nil { opts__5 = ifn_1976.Invoke_O_O__O(arg_1977, arg_1978) } else { opts__5 = linked_1975.(*A_arbace_box_build_with_tools_A).Invoke_O_O_O__O(root_1974, arg_1977, arg_1978) }; var pkgs__6 any = /*line :322:1*/A_arbace_box_build_A_const_41.Invoke_O__O(p__4); var index__7 any; var root_1985 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1985, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1987 lang.IFn; if







	linked_1986 == nil { ifn_1987 = lang.IFn_Cast(root_1985) } else { ifn_1987 = nil }; var arg_1988 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1989 any; var root_1980 any = A_arbace_box_build_A_const_171.GetRawRoot__O(); var linked_1981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1980, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1982 lang.IFn; if linked_1981 == nil { ifn_1982 = lang.IFn_Cast(root_1980) } else { ifn_1982 = nil }; var arg_1983 any; var tmp1 any = A_arbace_box_build_link_fn__598000285_A_New(); var tmp2 *jrt.Class; var fncls__1979 *jrt.Class = A_arbace_box_build_link_fn__598000285_A_fn_class; if fncls__1979 == nil { var fncls__1979d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_box_build_link_fn__598000285_A_fn_class = fncls__1979d; tmp2 = fncls__1979d } else { tmp2 = fncls__1979 }; arg_1983 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1984 any = pkgs__6; if linked_1981 == nil { arg_1989 = ifn_1982.Invoke_O_O__O(arg_1983, arg_1984) } else { arg_1989 = linked_1981.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1980, arg_1983, arg_1984) }; if linked_1986 == nil { index__7 = ifn_1987.Invoke_O_O__O(arg_1988, arg_1989) } else { index__7 = linked_1986.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1985, arg_1988, arg_1989) }; var root_2112 any =
	A_arbace_box_build_A_const_81.GetRawRoot__O(); var linked_2113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2112, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2114 lang.IFn; if linked_2113 == nil { ifn_2114 = lang.IFn_Cast(root_2112) } else { ifn_2114 = nil }; var arg_2115 any = lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, opts__5); if linked_2113 == nil { ifn_2114.Invoke_O__O(arg_2115) } else { linked_2113.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2112, arg_2115) }; var tmp3 any; tmp19 := /*line :322:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var paths__10 any; var root_1990 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1990, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1992 lang.IFn









		if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; var arg_1993 any = A_arbace_box_build_A_const_91; var arg_1994 any = pkgs__6; if linked_1991 == nil { paths__10 = ifn_1992.Invoke_O_O__O(arg_1993, arg_1994) } else { paths__10 = linked_1991.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1990, arg_1993, arg_1994) }
//line :322:1
		var vec__598000287__11 any; var root_1995 any = A_arbace_box_build_A_const_122.GetRawRoot__O(); var linked_1996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1995, A_arbace_box_build_deps_tree_A_fn_class); var ifn_1997 lang.IFn










		if linked_1996 == nil { ifn_1997 = lang.IFn_Cast(root_1995) } else { ifn_1997 = nil }; var arg_1998 any = archives__1; var arg_1999 any = index__7; var arg_2000 any = paths__10; if linked_1996 == nil { vec__598000287__11 = ifn_1997.Invoke_O_O_O__O(arg_1998, arg_1999, arg_2000) } else { vec__598000287__11 = linked_1996.(*A_arbace_box_build_deps_tree_A).Invoke_O_O_O_O__O(root_1995, arg_1998, arg_1999, arg_2000) }
//line :322:1
		var dtree__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000287__11, lang.RT_IntCast_J__I_NoInit(0), nil); var lines__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000287__11, lang.RT_IntCast_J__I_NoInit(1), nil); var cfg__14 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil); var tmp5 any; var root_2060 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_2061 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2060, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2062 lang.IFn











		if linked_2061 == nil { ifn_2062 = lang.IFn_Cast(root_2060) } else { ifn_2062 = nil }; var arg_2063 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_2064 any; var iter__1927001039__auto____16 any; var tmp6 any = A_arbace_box_build_link_iter__598000290__598000294_A_New(); var tmp7 *jrt.Class; var fncls__2059 *jrt.Class = A_arbace_box_build_link_iter__598000290__598000294_A_fn_class; if fncls__2059 == nil { var fncls__2059d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_box_build_link_iter__598000290__598000294_A_fn_class = fncls__2059d; tmp7 = fncls__2059d } else { tmp7 = fncls__2059 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); arg_2064 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(lines__13); if linked_2061 == nil { tmp5 = ifn_2062.Invoke_O_O__O(arg_2063, arg_2064) } else { tmp5 = linked_2061.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2060, arg_2063, arg_2064) }; cfg__14 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref()
//line :322:1
		var res__15 any; var root_2089 any = A_arbace_box_build_A_const_79.GetRawRoot__O(); var linked_2090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2089, A_arbace_box_build_action_STAR__A_fn_class); var ifn_2091 lang.IFn












		if linked_2090 == nil { ifn_2091 = lang.IFn_Cast(root_2089) } else { ifn_2091 = nil }; var arg_2092 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_130), jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_177.Invoke_O__O(p__4), nil)).Ref(); var arg_2093 any; var root_2084 any = A_arbace_box_build_A_const_124.GetRawRoot__O(); var linked_2085 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2084, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_2086 lang.IFn
		if linked_2085 == nil { ifn_2086 = lang.IFn_Cast(root_2084) } else { ifn_2086 = nil }; var arg_2087 any; var tmp8 any = A_arbace_box_build_A_const_138; var tmp9 *lang.Keyword = A_arbace_box_build_A_const_178; var tmp10 any = tmp9.Invoke_O__O(A_arbace_box_build_A_const_120.Invoke_O__O(opts__5)); var tmp11 any = A_arbace_box_build_A_const_78; var tmp12 any; var root_2071 any = A_arbace_box_build_A_const_90.GetRawRoot__O(); var linked_2072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2071, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2073 lang.IFn

		if linked_2072 == nil { ifn_2073 = lang.IFn_Cast(root_2071) } else { ifn_2073 = nil }; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_86.GetRawRoot__O()); var tmp14 any = A_arbace_box_build_A_const_179; var arg_2074 any = tmp13.Invoke_O_O_O__O(tmp14, A_arbace_box_build_A_const_180.Invoke_O_O__O(opts__5, A_arbace_box_build_A_const_181), lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_131, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(index__7).Invoke_O__O(A_arbace_box_build_A_const_177.Invoke_O__O(p__4)), nil)).Ref())); if linked_2072 == nil { tmp12 = ifn_2073.Invoke_O__O(arg_2074) } else { tmp12 = linked_2072.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2071, arg_2074) }
//line :336:1
		var tmp15 any = tmp12; var tmp16 any = A_arbace_box_build_A_const_141; var tmp17 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_63, dtree__12); var tmp18 any; var root_2075 any = A_arbace_box_build_A_const_142.GetRawRoot__O(); var linked_2076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2075, A_arbace_box_build_file_tree_A_fn_class); var ifn_2077 lang.IFn




		if linked_2076 == nil { ifn_2077 = lang.IFn_Cast(root_2075) } else { ifn_2077 = nil }; var arg_2078 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_132, cfg__14)); if linked_2076 == nil { tmp18 = ifn_2077.Invoke_O__O(arg_2078) } else { tmp18 = linked_2076.(*A_arbace_box_build_file_tree_A).Invoke_O_O__O(root_2075, arg_2078) }
//line :336:1
		arg_2087 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp10, tmp11, tmp15, tmp16, lang.Tuple_Create_O_O__IPersistentVector(tmp17, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp18)), A_arbace_box_build_A_const_84, Lit_133, A_arbace_box_build_A_const_182, Lit_133)); var arg_2088 any; var root_2079 any = A_arbace_box_build_A_const_161.GetRawRoot__O(); var linked_2080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2079, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2081 lang.IFn






		if linked_2080 == nil { ifn_2081 = lang.IFn_Cast(root_2079) } else { ifn_2081 = nil }; var arg_2082 any = lang.RT_Get_O_O__O_NoInit(A_arbace_box_build_A_const_126.Invoke_O__O(opts__5), A_arbace_box_build_A_const_178); var arg_2083 any = A_arbace_box_build_A_const_183; if linked_2080 == nil { arg_2088 = ifn_2081.Invoke_O_O__O(arg_2082, arg_2083) } else { arg_2088 = linked_2080.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2079, arg_2082, arg_2083) }
//line :336:1
		if linked_2085 == nil { arg_2093 = ifn_2086.Invoke_O_O__O(arg_2087, arg_2088) } else { arg_2093 = linked_2085.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_2084, arg_2087, arg_2088) }
//line :335:1
		if linked_2090 == nil { res__15 = ifn_2091.Invoke_O_O__O(arg_2092, arg_2093) } else { res__15 = linked_2090.(*A_arbace_box_build_action_STAR__A).Invoke_O_O_O__O(root_2089, arg_2092, arg_2093)
		}







		var root_2100 any = A_arbace_box_build_A_const_147.GetRawRoot__O(); var linked_2101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2100, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2102 lang.IFn; if linked_2101 == nil { ifn_2102 = lang.IFn_Cast(root_2100) } else { ifn_2102 = nil }; var arg_2103 any; var root_2094 any = A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_2095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2094, A_arbace_box_build_out_file_A_fn_class); var ifn_2096 lang.IFn; if linked_2095 == nil { ifn_2096 = lang.IFn_Cast(root_2094) } else { ifn_2096 = nil }; var arg_2097 any = res__15; var arg_2098 any = A_arbace_box_build_A_const_177.Invoke_O__O(p__4); var arg_2099 any = Lit_134; if linked_2095 == nil { arg_2103 = ifn_2096.Invoke_O_O_O__O(arg_2097, arg_2098, arg_2099) } else { arg_2103 = linked_2095.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_2094, arg_2097, arg_2098, arg_2099) }; if linked_2101 == nil { tmp3 = ifn_2102.Invoke_O__O(arg_2103) } else { tmp3 = linked_2101.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2100, arg_2103) } }; return nil }(); var root_2104 any = /*line :322:1*/A_arbace_box_build_A_const_80.GetRawRoot__O(); var linked_2105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2104, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2106 lang.IFn; if








	linked_2105 == nil { ifn_2106 = lang.IFn_Cast(root_2104) } else { ifn_2106 = nil }; if linked_2105 == nil { ifn_2106.Invoke__O() } else { linked_2105.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2104) }; if /*line :322:1*/ tmp19 != nil { panic(tmp19) }; return tmp3 }







func A_arbace_box_build_link_fn__598000285_A_New() *A_arbace_box_build_link_fn__598000285_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_fn__598000285_A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_box_build_link_fn__598000285_A) Ctor() {}
//line :330:1
func (t *A_arbace_box_build_link_fn__598000285_A) Invoke_O_O_O__O(self, i__1, q__2 any) any { return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_91.Invoke_O__O(q__2), i__1) }



func A_arbace_box_build_link_iter__598000290__598000294_A_New() *A_arbace_box_build_link_iter__598000290__598000294_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_iter__598000290__598000294_A{}; t.Ctor(); return t }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_A) Ctor() {}
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_A) Invoke_O_O__O(self, s__598000291__1 any) any { var tmp1 any = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_New_O_O(self, s__598000291__1); var tmp2 *jrt.Class; var fncls__2058 *jrt.Class = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_fn_class; if fncls__2058 == nil { var fncls__2058d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_fn_class = fncls__2058d; tmp2 = fncls__2058d } else { tmp2 = fncls__2058 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :334:1
func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_New_O_O(p0, p1 any) *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A{}; t.Ctor_O_O(p0, p1); return t }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A) Ctor_O_O(c__iter__598000290, c__s__598000291 any) { t.F_iter__598000290 = c__iter__598000290; t.F_s__598000291 = c__s__598000291 }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A) Invoke_O__O(self any) any { { var s__598000291__1 any; var t_ any = t.F_s__598000291; t.F_s__598000291 = nil; s__598000291__1 = t_; for { var temp__1927000414__auto____2 any; var root_2001 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_2002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2001, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2003 lang.IFn; if linked_2002 == nil { ifn_2003 = lang.IFn_Cast(root_2001) } else { ifn_2003 = nil }; var arg_2004 any = s__598000291__1; if linked_2002 == nil { temp__1927000414__auto____2 = ifn_2003.Invoke_O__O(arg_2004) } else { temp__1927000414__auto____2 = linked_2002.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2001, arg_2004) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000291__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2005 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_2006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2005, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2007 lang.IFn; if linked_2006 == nil { ifn_2007 = lang.IFn_Cast(root_2005) } else { ifn_2007 = nil }; var arg_2008 any = s__598000291__3; if linked_2006 == nil { tmp1 = ifn_2007.Invoke_O__O(arg_2008) } else { tmp1 = linked_2006.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2005, arg_2008) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2009 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_2010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2009, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2011 lang.IFn; if linked_2010 == nil { ifn_2011 = lang.IFn_Cast(root_2009) } else { ifn_2011 = nil }; var arg_2012 any = s__598000291__3; if linked_2010 == nil { c__1927001037__auto____4 = ifn_2011.Invoke_O__O(arg_2012) } else { c__1927001037__auto____4 = linked_2010.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2009, arg_2012) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000293__6 any; var root_2013 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_2014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2013, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2015 lang.IFn; if linked_2014 == nil { ifn_2015 = lang.IFn_Cast(root_2013) } else { ifn_2015 = nil }; var arg_2016 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2014 == nil { b__598000293__6 = ifn_2015.Invoke_O__O(arg_2016) } else { b__598000293__6 = linked_2014.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2013, arg_2016) }; var tmp2 any = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_New_O_I_O(b__598000293__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2022 *jrt.Class = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_fn_class; if fncls__2022 == nil { var fncls__2022d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_fn_class = fncls__2022d; tmp3 = fncls__2022d } else { tmp3 = fncls__2022 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2031 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_2032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2031, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2033 lang.IFn; if linked_2032 == nil { ifn_2033 = lang.IFn_Cast(root_2031) } else { ifn_2033 = nil }; var arg_2034 any; var root_2023 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_2024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2023, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2025 lang.IFn; if linked_2024 == nil { ifn_2025 = lang.IFn_Cast(root_2023) } else { ifn_2025 = nil }; var arg_2026 any = b__598000293__6; if linked_2024 == nil { arg_2034 = ifn_2025.Invoke_O__O(arg_2026) } else { arg_2034 = linked_2024.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2023, arg_2026) }; var arg_2035 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000290); var tmp5 any; var root_2027 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_2028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2027, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2029 lang.IFn; if linked_2028 == nil { ifn_2029 = lang.IFn_Cast(root_2027) } else { ifn_2029 = nil }; var arg_2030 any = s__598000291__3; if linked_2028 == nil { tmp5 = ifn_2029.Invoke_O__O(arg_2030) } else { tmp5 = linked_2028.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2027, arg_2030) }; arg_2035 = tmp4.Invoke_O__O(tmp5); if linked_2032 == nil { return ifn_2033.Invoke_O_O__O(arg_2034, arg_2035) } else { return linked_2032.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2031, arg_2034, arg_2035) } } else { var root_2040 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_2041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2040, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2042 lang.IFn; if linked_2041 == nil { ifn_2042 = lang.IFn_Cast(root_2040) } else { ifn_2042 = nil }; var arg_2043 any; var root_2036 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_2037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2036, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2038 lang.IFn; if linked_2037 == nil { ifn_2038 = lang.IFn_Cast(root_2036) } else { ifn_2038 = nil }; var arg_2039 any = b__598000293__6; if linked_2037 == nil { arg_2043 = ifn_2038.Invoke_O__O(arg_2039) } else { arg_2043 = linked_2037.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2036, arg_2039) }; var arg_2044 any; if linked_2041 == nil { return ifn_2042.Invoke_O_O__O(arg_2043, arg_2044) } else { return linked_2041.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2040, arg_2043, arg_2044) } } } else { var l__4 any; var root_2045 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_2046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2045, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2047 lang.IFn; if linked_2046 == nil { ifn_2047 = lang.IFn_Cast(root_2045) } else { ifn_2047 = nil }; var arg_2048 any = s__598000291__3; if linked_2046 == nil { l__4 = ifn_2047.Invoke_O__O(arg_2048) } else { l__4 = linked_2046.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2045, arg_2048) }; var root_2053 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_2054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2053, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2055 lang.IFn; if linked_2054 == nil { ifn_2055 = lang.IFn_Cast(root_2053) } else { ifn_2055 = nil }; var arg_2056 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, l__4, nil)).Ref(); var arg_2057 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000290); var tmp7 any; var root_2049 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_2050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2049, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2051 lang.IFn; if linked_2050 == nil { ifn_2051 = lang.IFn_Cast(root_2049) } else { ifn_2051 = nil }; var arg_2052 any = s__598000291__3; if linked_2050 == nil { tmp7 = ifn_2051.Invoke_O__O(arg_2052) } else { tmp7 = linked_2050.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2049, arg_2052) }; arg_2057 = tmp6.Invoke_O__O(tmp7); if linked_2054 == nil { return ifn_2055.Invoke_O_O__O(arg_2056, arg_2057) } else { return linked_2054.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2053, arg_2056, arg_2057) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :334:1
func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A) Ctor_O_I_O(c__b__598000293 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000293 = c__b__598000293; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A) Invoke_O__O(self any) any { { var i__598000292__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000292__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000292__1)); var root_2017 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_2018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2017, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2019 lang.IFn; if linked_2018 == nil { ifn_2019 = lang.IFn_Cast(root_2017) } else { ifn_2019 = nil }; var arg_2020 any = t.F_b__598000293; var arg_2021 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, l__2, nil)).Ref(); if linked_2018 == nil { ifn_2019.Invoke_O_O__O(arg_2020, arg_2021) } else { linked_2018.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2017, arg_2020, arg_2021) }; i__598000292__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000292__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }











func A_arbace_box_build_build_A_New() *A_arbace_box_build_build_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_box_build_build_A) Ctor() {}
//line :346:1
func (t *A_arbace_box_build_build_A) Invoke_O_O_O__O(self, plan__0, opts__1 any) any { var p__3 any; var root_2116 any = A_arbace_box_build_A_const_169.GetRawRoot__O(); var linked_2117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2116, A_arbace_box_build_read_plan_A_fn_class); var ifn_2118 lang.IFn; if



	linked_2117 == nil { ifn_2118 = lang.IFn_Cast(root_2116) } else { ifn_2118 = nil }; var arg_2119 any = plan__0; if linked_2117 == nil { p__3 = ifn_2118.Invoke_O__O(arg_2119) } else { p__3 = linked_2117.(*A_arbace_box_build_read_plan_A).Invoke_O_O__O(root_2116, arg_2119) }; var t0__4 int64 = /*line :346:1*/jrt.System_NanoTime__J(); var as__5 any; var root_2120 any = A_arbace_box_build_A_const_184.GetRawRoot__O(); var linked_2121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2120, A_arbace_box_build_archives_A_fn_class); var ifn_2122 lang.IFn; if





	linked_2121 == nil { ifn_2122 = lang.IFn_Cast(root_2120) } else { ifn_2122 = nil }; var arg_2123 any = p__3; var arg_2124 any = opts__1; if linked_2121 == nil { as__5 = ifn_2122.Invoke_O_O__O(arg_2123, arg_2124) } else { as__5 = linked_2121.(*A_arbace_box_build_archives_A).Invoke_O_O_O__O(root_2120, arg_2123, arg_2124) }; var image__6 any; var root_2125 any = /*line :346:1*/A_arbace_box_build_A_const_185.GetRawRoot__O(); var linked_2126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2125, A_arbace_box_build_link_A_fn_class); var ifn_2127 lang.IFn; if






	linked_2126 == nil { ifn_2127 = lang.IFn_Cast(root_2125) } else { ifn_2127 = nil }; var arg_2128 any = p__3; var arg_2129 any = as__5; var arg_2130 any = opts__1; if linked_2126 == nil { image__6 = ifn_2127.Invoke_O_O_O__O(arg_2128, arg_2129, arg_2130) } else { image__6 = linked_2126.(*A_arbace_box_build_link_A).Invoke_O_O_O_O__O(root_2125, arg_2128, arg_2129, arg_2130) }; var temp__1927000414__auto____7 any = /*line :346:1*/A_arbace_box_build_A_const_186.Invoke_O__O(opts__1); if







	jrt.J2g_Truth(temp__1927000414__auto____7) { var r__8 any = temp__1927000414__auto____7; var root_2131 any = A_arbace_box_build_A_const_74.GetRawRoot__O(); var linked_2132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2131, aot_arbace_box.A_arbace_box_ref_BANG__A_fn_class); var ifn_2133 lang.IFn; if linked_2132 == nil { ifn_2133 = lang.IFn_Cast(root_2131) } else { ifn_2133 = nil }; var arg_2134 any = r__8; var arg_2135 any = image__6; if linked_2132 == nil { ifn_2133.Invoke_O_O__O(arg_2134, arg_2135) } else { linked_2132.(*aot_arbace_box.A_arbace_box_ref_BANG__A).Invoke_O_O_O__O(root_2131, arg_2134, arg_2135) } }; var root_2162 any =
	A_arbace_box_build_A_const_81.GetRawRoot__O(); var linked_2163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2162, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2164 lang.IFn; if linked_2163 == nil { ifn_2164 = lang.IFn_Cast(root_2162) } else { ifn_2164 = nil }; var arg_2165 any = lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, opts__1); if linked_2163 == nil { ifn_2164.Invoke_O__O(arg_2165) } else { linked_2163.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2162, arg_2165) }; var tmp1 any = A_arbace_box_build_build_fn__598000301_A_New_O_O_J(p__3, image__6, t0__4); var tmp2 *jrt.Class; var fncls__2156 *jrt.Class = A_arbace_box_build_build_fn__598000301_A_fn_class; if fncls__2156 == nil { var fncls__2156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_box_build_build_fn__598000301_A_fn_class = fncls__2156d; tmp2 = fncls__2156d } else { tmp2 = fncls__2156 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); return image__6 }
//line :346:1
func (t *A_arbace_box_build_build_A) Invoke_O_O__O(self, plan__0 any) any {

	var root_2166 any = A_arbace_box_build_A_const_187.GetRawRoot__O(); var linked_2167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2166, A_arbace_box_build_build_A_fn_class); var ifn_2168 lang.IFn; if linked_2167 == nil { ifn_2168 = lang.IFn_Cast(root_2166) } else { ifn_2168 = nil }; var arg_2169 any = plan__0; var arg_2170 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2167 == nil { return ifn_2168.Invoke_O_O__O(arg_2169, arg_2170) } else { return linked_2167.(*A_arbace_box_build_build_A).Invoke_O_O_O__O(root_2166, arg_2169, arg_2170)
	}
}




func A_arbace_box_build_build_fn__598000301_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_box_build_build_fn__598000301_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_fn__598000301_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :355:1
func (t *A_arbace_box_build_build_fn__598000301_A) Ctor_O_O_J(c__p, c__image any, c__t0 int64) { t.F_p = c__p; t.F_image = c__image; t.F_t0 = c__t0 }
//line :355:1
func (t *A_arbace_box_build_build_fn__598000301_A) Invoke_O__O(self any) any { var tmp1 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_76.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_77.GetRawRoot__O()); var tmp4 any = A_arbace_box_build_A_const_177.Invoke_O__O(t.F_p); var tmp5 *lang.Keyword = A_arbace_box_build_A_const_41; var tmp6 any; var t_ any = t.F_p; t.F_p = nil; tmp6 = t_; var tmp7 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp5.Invoke_O__O(tmp6))).Ref(); var tmp8 any = t.F_image; var tmp9 any; var root_2136 any = A_arbace_box_build_A_const_62.GetRawRoot__O(); var linked_2137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2136, aot_arbace_box.A_arbace_box_size_A_fn_class); var ifn_2138 lang.IFn; if linked_2137 == nil { ifn_2138 = lang.IFn_Cast(root_2136) } else { ifn_2138 = nil }; var arg_2139 any; var t__2 any = t.F_image; t.F_image = nil; arg_2139 = t__2; if linked_2137 == nil { tmp9 = ifn_2138.Invoke_O__O(arg_2139) } else { tmp9 = linked_2137.(*aot_arbace_box.A_arbace_box_size_A).Invoke_O_O__O(root_2136, arg_2139) }; tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O_O_O_O_O_O__O(Lit_44, tmp4, tmp7, tmp8, tmp9, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t.F_t0), 1.0e9)).Ref())) }
//line :355:1
	return nil }(); var root_2153 any = A_arbace_box_build_A_const_80.GetRawRoot__O(); var linked_2154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2153, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2155 lang.IFn; if linked_2154 == nil { ifn_2155 = lang.IFn_Cast(root_2153) } else { ifn_2155 = nil }; if linked_2154 == nil { ifn_2155.Invoke__O() } else { linked_2154.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2153) }; if tmp10 != nil { panic(tmp10) }; return tmp1 }


























































































































































































































































type A_arbace_box_build_A struct{ jrt.Object }

var A_arbace_box_build_A_const_pool *jrt.RefArray

var A_arbace_box_build_A_const_0 *lang.Var

var A_arbace_box_build_A_const_1 any

var A_arbace_box_build_A_const_2 *lang.Var

var A_arbace_box_build_A_const_3 any

var A_arbace_box_build_A_const_4 any

var A_arbace_box_build_A_const_5 any

var A_arbace_box_build_A_const_6 *lang.Var

var A_arbace_box_build_A_const_7 *lang.Var

var A_arbace_box_build_A_const_8 *lang.Var

var A_arbace_box_build_A_const_9 *lang.Var

var A_arbace_box_build_A_const_10 any

var A_arbace_box_build_A_const_11 *lang.Var

var A_arbace_box_build_A_const_12 *lang.Var

var A_arbace_box_build_A_const_13 *lang.Keyword

var A_arbace_box_build_A_const_14 *lang.Var

var A_arbace_box_build_A_const_15 *lang.Var

var A_arbace_box_build_A_const_16 *lang.Var

var A_arbace_box_build_A_const_17 *lang.Var

var A_arbace_box_build_A_const_18 *lang.Var

var A_arbace_box_build_A_const_19 *lang.Var

var A_arbace_box_build_A_const_20 *lang.Var

var A_arbace_box_build_A_const_21 *lang.Var

var A_arbace_box_build_A_const_22 *lang.Var

var A_arbace_box_build_A_const_23 *lang.Var

var A_arbace_box_build_A_const_24 *lang.Var

var A_arbace_box_build_A_const_25 *lang.Keyword

var A_arbace_box_build_A_const_26 *lang.Var

var A_arbace_box_build_A_const_27 *lang.Var

var A_arbace_box_build_A_const_28 *lang.Var

var A_arbace_box_build_A_const_29 *lang.Var

var A_arbace_box_build_A_const_30 *lang.Var

var A_arbace_box_build_A_const_31 *lang.Var

var A_arbace_box_build_A_const_32 *lang.Var

var A_arbace_box_build_A_const_33 *lang.Var

var A_arbace_box_build_A_const_34 *lang.Var

var A_arbace_box_build_A_const_35 *lang.Var

var A_arbace_box_build_A_const_36 *lang.Var

var A_arbace_box_build_A_const_37 *lang.Var

var A_arbace_box_build_A_const_38 *lang.Var

var A_arbace_box_build_A_const_39 *lang.Keyword

var A_arbace_box_build_A_const_40 *lang.Var

var A_arbace_box_build_A_const_41 *lang.Keyword

var A_arbace_box_build_A_const_42 *lang.Var

var A_arbace_box_build_A_const_43 *lang.Var

var A_arbace_box_build_A_const_44 *lang.Keyword

var A_arbace_box_build_A_const_45 *lang.Var

var A_arbace_box_build_A_const_46 *lang.Var

var A_arbace_box_build_A_const_47 *lang.Var

var A_arbace_box_build_A_const_48 *lang.Keyword

var A_arbace_box_build_A_const_49 *lang.Var

var A_arbace_box_build_A_const_50 *lang.Var

var A_arbace_box_build_A_const_51 *lang.Var

var A_arbace_box_build_A_const_52 *lang.Var

var A_arbace_box_build_A_const_53 *lang.Var

var A_arbace_box_build_A_const_54 *lang.Var

var A_arbace_box_build_A_const_55 *lang.Keyword

var A_arbace_box_build_A_const_56 *lang.Keyword

var A_arbace_box_build_A_const_57 any

var A_arbace_box_build_A_const_58 any

var A_arbace_box_build_A_const_59 *lang.Var

var A_arbace_box_build_A_const_60 *lang.Keyword

var A_arbace_box_build_A_const_61 *lang.Var

var A_arbace_box_build_A_const_62 *lang.Var

var A_arbace_box_build_A_const_63 *lang.Var

var A_arbace_box_build_A_const_64 *lang.Keyword

var A_arbace_box_build_A_const_65 *lang.Var

var A_arbace_box_build_A_const_66 *lang.Keyword

var A_arbace_box_build_A_const_67 *lang.Var

var A_arbace_box_build_A_const_68 *lang.Keyword

var A_arbace_box_build_A_const_69 *lang.Var

var A_arbace_box_build_A_const_70 *lang.Keyword

var A_arbace_box_build_A_const_71 *lang.Keyword

var A_arbace_box_build_A_const_72 *lang.Keyword

var A_arbace_box_build_A_const_73 *lang.Var

var A_arbace_box_build_A_const_74 *lang.Var

var A_arbace_box_build_A_const_75 *lang.Keyword

var A_arbace_box_build_A_const_76 *lang.Var

var A_arbace_box_build_A_const_77 *lang.Var

var A_arbace_box_build_A_const_78 *lang.Keyword

var A_arbace_box_build_A_const_79 *lang.Var

var A_arbace_box_build_A_const_80 *lang.Var

var A_arbace_box_build_A_const_81 *lang.Var

var A_arbace_box_build_A_const_82 *lang.Var

var A_arbace_box_build_A_const_83 *lang.Var

var A_arbace_box_build_A_const_84 *lang.Keyword

var A_arbace_box_build_A_const_85 *lang.Keyword

var A_arbace_box_build_A_const_86 *lang.Var

var A_arbace_box_build_A_const_87 *lang.Keyword

var A_arbace_box_build_A_const_88 any

var A_arbace_box_build_A_const_89 *lang.Keyword

var A_arbace_box_build_A_const_90 *lang.Var

var A_arbace_box_build_A_const_91 *lang.Keyword

var A_arbace_box_build_A_const_92 *lang.Var

var A_arbace_box_build_A_const_93 *lang.Keyword

var A_arbace_box_build_A_const_94 any

var A_arbace_box_build_A_const_95 *lang.Var

var A_arbace_box_build_A_const_96 *lang.Var

var A_arbace_box_build_A_const_97 any

var A_arbace_box_build_A_const_98 any

var A_arbace_box_build_A_const_99 any

var A_arbace_box_build_A_const_100 any

var A_arbace_box_build_A_const_101 any

var A_arbace_box_build_A_const_102 any

var A_arbace_box_build_A_const_103 *lang.Var

var A_arbace_box_build_A_const_104 *lang.Var

var A_arbace_box_build_A_const_105 *lang.Var

var A_arbace_box_build_A_const_106 *lang.Keyword

var A_arbace_box_build_A_const_107 *lang.Var

var A_arbace_box_build_A_const_108 *lang.Var

var A_arbace_box_build_A_const_109 any

var A_arbace_box_build_A_const_110 any

var A_arbace_box_build_A_const_111 *lang.Keyword

var A_arbace_box_build_A_const_112 *lang.Var

var A_arbace_box_build_A_const_113 *lang.Var

var A_arbace_box_build_A_const_114 *lang.Var

var A_arbace_box_build_A_const_115 *lang.Var

var A_arbace_box_build_A_const_116 *lang.Var

var A_arbace_box_build_A_const_117 *lang.Var

var A_arbace_box_build_A_const_118 *lang.Var

var A_arbace_box_build_A_const_119 *lang.Var

var A_arbace_box_build_A_const_120 *lang.Keyword

var A_arbace_box_build_A_const_121 *lang.Keyword

var A_arbace_box_build_A_const_122 *lang.Var

var A_arbace_box_build_A_const_123 *lang.Keyword

var A_arbace_box_build_A_const_124 *lang.Var

var A_arbace_box_build_A_const_125 any

var A_arbace_box_build_A_const_126 *lang.Keyword

var A_arbace_box_build_A_const_127 *lang.Var

var A_arbace_box_build_A_const_128 *lang.Var

var A_arbace_box_build_A_const_129 *lang.Var

var A_arbace_box_build_A_const_130 *lang.Var

var A_arbace_box_build_A_const_131 *lang.Var

var A_arbace_box_build_A_const_132 *lang.Var

var A_arbace_box_build_A_const_133 *lang.Keyword

var A_arbace_box_build_A_const_134 *lang.Keyword

var A_arbace_box_build_A_const_135 *lang.Keyword

var A_arbace_box_build_A_const_136 *lang.Var

var A_arbace_box_build_A_const_137 *lang.Var

var A_arbace_box_build_A_const_138 *lang.Keyword

var A_arbace_box_build_A_const_139 *lang.Keyword

var A_arbace_box_build_A_const_140 *lang.Var

var A_arbace_box_build_A_const_141 *lang.Keyword

var A_arbace_box_build_A_const_142 *lang.Var

var A_arbace_box_build_A_const_143 any

var A_arbace_box_build_A_const_144 *lang.Var

var A_arbace_box_build_A_const_145 *lang.Var

var A_arbace_box_build_A_const_146 *lang.Var

var A_arbace_box_build_A_const_147 *lang.Var

var A_arbace_box_build_A_const_148 *lang.Var

var A_arbace_box_build_A_const_149 *lang.Keyword

var A_arbace_box_build_A_const_150 *lang.Keyword

var A_arbace_box_build_A_const_151 *lang.Keyword

var A_arbace_box_build_A_const_152 any

var A_arbace_box_build_A_const_153 *lang.Var

var A_arbace_box_build_A_const_154 any

var A_arbace_box_build_A_const_155 any

var A_arbace_box_build_A_const_156 any

var A_arbace_box_build_A_const_157 any

var A_arbace_box_build_A_const_158 any

var A_arbace_box_build_A_const_159 any

var A_arbace_box_build_A_const_160 *lang.Keyword

var A_arbace_box_build_A_const_161 *lang.Var

var A_arbace_box_build_A_const_162 any

var A_arbace_box_build_A_const_163 *lang.Var

var A_arbace_box_build_A_const_164 any

var A_arbace_box_build_A_const_165 *lang.Var

var A_arbace_box_build_A_const_166 *lang.Keyword

var A_arbace_box_build_A_const_167 *lang.Var

var A_arbace_box_build_A_const_168 any

var A_arbace_box_build_A_const_169 *lang.Var

var A_arbace_box_build_A_const_170 *lang.Var

var A_arbace_box_build_A_const_171 *lang.Var

var A_arbace_box_build_A_const_172 *lang.Keyword

var A_arbace_box_build_A_const_173 *lang.Keyword

var A_arbace_box_build_A_const_174 *lang.Keyword

var A_arbace_box_build_A_const_175 any

var A_arbace_box_build_A_const_176 *lang.Var

var A_arbace_box_build_A_const_177 *lang.Keyword

var A_arbace_box_build_A_const_178 *lang.Keyword

var A_arbace_box_build_A_const_179 any

var A_arbace_box_build_A_const_180 *lang.Keyword

var A_arbace_box_build_A_const_181 any

var A_arbace_box_build_A_const_182 *lang.Keyword

var A_arbace_box_build_A_const_183 any

var A_arbace_box_build_A_const_184 *lang.Var

var A_arbace_box_build_A_const_185 *lang.Var

var A_arbace_box_build_A_const_186 *lang.Keyword

var A_arbace_box_build_A_const_187 *lang.Var

var A_arbace_box_build_A_init jrt.ClassInit

func A_arbace_box_build_A_Init() { if !A_arbace_box_build_A_init.Done() { A_arbace_box_build_A_init.Run(A_arbace_box_build_A_clinit) } }

func A_arbace_box_build_A_clinit() { A_arbace_box_build_A_clinit_p0(); A_arbace_box_build_A_clinit_p1(); A_arbace_box_build_A_clinit_p2(); A_arbace_box_build_A_clinit_p3(); A_arbace_box_build_A_clinit_p4(); A_arbace_box_build_A_clinit_p5(); A_arbace_box_build_A_clinit_p6(); A_arbace_box_build_A_clinit_p7(); A_arbace_box_build_A_clinit_p8(); A_arbace_box_build_A_clinit_p9(); A_arbace_box_build_A_clinit_p10(); A_arbace_box_build_A_clinit_p11(); A_arbace_box_build_A_clinit_p12(); A_arbace_box_build_A_clinit_p13(); A_arbace_box_build_A_clinit_p14(); A_arbace_box_build_A_clinit_p15() }

func A_arbace_box_build_A_clinit_p0() { jrt.StartCheck(); A_arbace_box_build_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 245); A_arbace_box_build_A_const_0 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[57]); A_arbace_box_build_A_const_1 = A_arbace_box_build_A_const_pool.A[58]; A_arbace_box_build_A_const_2 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[59]); A_arbace_box_build_A_const_3 = A_arbace_box_build_A_const_pool.A[60]; A_arbace_box_build_A_const_4 = A_arbace_box_build_A_const_pool.A[61]; A_arbace_box_build_A_const_5 = A_arbace_box_build_A_const_pool.A[62]; A_arbace_box_build_A_const_6 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[63]); A_arbace_box_build_A_const_7 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[64]); A_arbace_box_build_A_const_8 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[65]); A_arbace_box_build_A_const_9 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[66]); A_arbace_box_build_A_const_10 = A_arbace_box_build_A_const_pool.A[67]; A_arbace_box_build_A_const_11 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[68]) }

func A_arbace_box_build_A_clinit_p1() { A_arbace_box_build_A_const_12 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[69]); A_arbace_box_build_A_const_13 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[70]); A_arbace_box_build_A_const_14 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[71]); A_arbace_box_build_A_const_15 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[72]); A_arbace_box_build_A_const_16 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[73]); A_arbace_box_build_A_const_17 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[74]); A_arbace_box_build_A_const_18 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[75]); A_arbace_box_build_A_const_19 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[76]); A_arbace_box_build_A_const_20 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[77]); A_arbace_box_build_A_const_21 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[78]); A_arbace_box_build_A_const_22 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[79]); A_arbace_box_build_A_const_23 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[80]) }

func A_arbace_box_build_A_clinit_p2() { A_arbace_box_build_A_const_24 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[81]); A_arbace_box_build_A_const_25 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[82]); A_arbace_box_build_A_const_26 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[83]); A_arbace_box_build_A_const_27 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[84]); A_arbace_box_build_A_const_28 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[85]); A_arbace_box_build_A_const_29 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[86]); A_arbace_box_build_A_const_30 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[87]); A_arbace_box_build_A_const_31 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[88]); A_arbace_box_build_A_const_32 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[89]); A_arbace_box_build_A_const_33 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[90]); A_arbace_box_build_A_const_34 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[91]); A_arbace_box_build_A_const_35 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[92]) }

func A_arbace_box_build_A_clinit_p3() { A_arbace_box_build_A_const_36 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[93]); A_arbace_box_build_A_const_37 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[94]); A_arbace_box_build_A_const_38 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[95]); A_arbace_box_build_A_const_39 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[96]); A_arbace_box_build_A_const_40 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[97]); A_arbace_box_build_A_const_41 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[98]); A_arbace_box_build_A_const_42 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[99]); A_arbace_box_build_A_const_43 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[100]); A_arbace_box_build_A_const_44 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[101]); A_arbace_box_build_A_const_45 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[102]); A_arbace_box_build_A_const_46 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[103]); A_arbace_box_build_A_const_47 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[104]) }

func A_arbace_box_build_A_clinit_p4() { A_arbace_box_build_A_const_48 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[105]); A_arbace_box_build_A_const_49 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[106]); A_arbace_box_build_A_const_50 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[107]); A_arbace_box_build_A_const_51 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[108]); A_arbace_box_build_A_const_52 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[109]); A_arbace_box_build_A_const_53 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[110]); A_arbace_box_build_A_const_54 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[111]); A_arbace_box_build_A_const_55 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[112]); A_arbace_box_build_A_const_56 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[113]); A_arbace_box_build_A_const_57 = A_arbace_box_build_A_const_pool.A[114]; A_arbace_box_build_A_const_58 = A_arbace_box_build_A_const_pool.A[115]; A_arbace_box_build_A_const_59 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[116]) }

func A_arbace_box_build_A_clinit_p5() { A_arbace_box_build_A_const_60 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[117]); A_arbace_box_build_A_const_61 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[118]); A_arbace_box_build_A_const_62 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[119]); A_arbace_box_build_A_const_63 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[120]); A_arbace_box_build_A_const_64 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[121]); A_arbace_box_build_A_const_65 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[122]); A_arbace_box_build_A_const_66 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[123]); A_arbace_box_build_A_const_67 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[124]); A_arbace_box_build_A_const_68 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[125]); A_arbace_box_build_A_const_69 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[126]); A_arbace_box_build_A_const_70 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[127]); A_arbace_box_build_A_const_71 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[128]) }

func A_arbace_box_build_A_clinit_p6() { A_arbace_box_build_A_const_72 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[129]); A_arbace_box_build_A_const_73 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[130]); A_arbace_box_build_A_const_74 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[131]); A_arbace_box_build_A_const_75 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[132]); A_arbace_box_build_A_const_76 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[133]); A_arbace_box_build_A_const_77 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[134]); A_arbace_box_build_A_const_78 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[135]); A_arbace_box_build_A_const_79 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[136]); A_arbace_box_build_A_const_80 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[137]); A_arbace_box_build_A_const_81 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[138]); A_arbace_box_build_A_const_82 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[139]); A_arbace_box_build_A_const_83 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[140]) }

func A_arbace_box_build_A_clinit_p7() { A_arbace_box_build_A_const_84 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[141]); A_arbace_box_build_A_const_85 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[142]); A_arbace_box_build_A_const_86 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[143]); A_arbace_box_build_A_const_87 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[144]); A_arbace_box_build_A_const_88 = A_arbace_box_build_A_const_pool.A[145]; A_arbace_box_build_A_const_89 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[146]); A_arbace_box_build_A_const_90 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[147]); A_arbace_box_build_A_const_91 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[148]); A_arbace_box_build_A_const_92 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[149]); A_arbace_box_build_A_const_93 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[150]); A_arbace_box_build_A_const_94 = A_arbace_box_build_A_const_pool.A[151]; A_arbace_box_build_A_const_95 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[152]) }

func A_arbace_box_build_A_clinit_p8() { A_arbace_box_build_A_const_96 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[153]); A_arbace_box_build_A_const_97 = A_arbace_box_build_A_const_pool.A[154]; A_arbace_box_build_A_const_98 = A_arbace_box_build_A_const_pool.A[155]; A_arbace_box_build_A_const_99 = A_arbace_box_build_A_const_pool.A[156]; A_arbace_box_build_A_const_100 = A_arbace_box_build_A_const_pool.A[157]; A_arbace_box_build_A_const_101 = A_arbace_box_build_A_const_pool.A[158]; A_arbace_box_build_A_const_102 = A_arbace_box_build_A_const_pool.A[159]; A_arbace_box_build_A_const_103 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[160]); A_arbace_box_build_A_const_104 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[161]); A_arbace_box_build_A_const_105 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[162]); A_arbace_box_build_A_const_106 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[163]); A_arbace_box_build_A_const_107 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[164]); A_arbace_box_build_A_const_108 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[165]) }

func A_arbace_box_build_A_clinit_p9() { A_arbace_box_build_A_const_109 = A_arbace_box_build_A_const_pool.A[166]; A_arbace_box_build_A_const_110 = A_arbace_box_build_A_const_pool.A[167]; A_arbace_box_build_A_const_111 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[168]); A_arbace_box_build_A_const_112 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[169]); A_arbace_box_build_A_const_113 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[170]); A_arbace_box_build_A_const_114 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[171]); A_arbace_box_build_A_const_115 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[172]); A_arbace_box_build_A_const_116 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[173]); A_arbace_box_build_A_const_117 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[174]); A_arbace_box_build_A_const_118 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[175]); A_arbace_box_build_A_const_119 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[176]); A_arbace_box_build_A_const_120 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[177]) }

func A_arbace_box_build_A_clinit_p10() { A_arbace_box_build_A_const_121 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[178]); A_arbace_box_build_A_const_122 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[179]); A_arbace_box_build_A_const_123 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[180]); A_arbace_box_build_A_const_124 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[181]); A_arbace_box_build_A_const_125 = A_arbace_box_build_A_const_pool.A[182]; A_arbace_box_build_A_const_126 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[183]); A_arbace_box_build_A_const_127 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[184]); A_arbace_box_build_A_const_128 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[185]); A_arbace_box_build_A_const_129 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[186]); A_arbace_box_build_A_const_130 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[187]); A_arbace_box_build_A_const_131 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[188]); A_arbace_box_build_A_const_132 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[189]) }

func A_arbace_box_build_A_clinit_p11() { A_arbace_box_build_A_const_133 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[190]); A_arbace_box_build_A_const_134 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[191]); A_arbace_box_build_A_const_135 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[192]); A_arbace_box_build_A_const_136 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[193]); A_arbace_box_build_A_const_137 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[194]); A_arbace_box_build_A_const_138 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[195]); A_arbace_box_build_A_const_139 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[196]); A_arbace_box_build_A_const_140 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[197]); A_arbace_box_build_A_const_141 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[198]); A_arbace_box_build_A_const_142 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[199]); A_arbace_box_build_A_const_143 = A_arbace_box_build_A_const_pool.A[200]; A_arbace_box_build_A_const_144 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[201]) }

func A_arbace_box_build_A_clinit_p12() { A_arbace_box_build_A_const_145 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[202]); A_arbace_box_build_A_const_146 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[203]); A_arbace_box_build_A_const_147 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[204]); A_arbace_box_build_A_const_148 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[205]); A_arbace_box_build_A_const_149 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[206]); A_arbace_box_build_A_const_150 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[207]); A_arbace_box_build_A_const_151 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[208]); A_arbace_box_build_A_const_152 = A_arbace_box_build_A_const_pool.A[209]; A_arbace_box_build_A_const_153 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[210]); A_arbace_box_build_A_const_154 = A_arbace_box_build_A_const_pool.A[211]; A_arbace_box_build_A_const_155 = A_arbace_box_build_A_const_pool.A[212]; A_arbace_box_build_A_const_156 = A_arbace_box_build_A_const_pool.A[213]; A_arbace_box_build_A_const_157 = A_arbace_box_build_A_const_pool.A[214] }

func A_arbace_box_build_A_clinit_p13() { A_arbace_box_build_A_const_158 = A_arbace_box_build_A_const_pool.A[215]; A_arbace_box_build_A_const_159 = A_arbace_box_build_A_const_pool.A[216]; A_arbace_box_build_A_const_160 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[217]); A_arbace_box_build_A_const_161 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[218]); A_arbace_box_build_A_const_162 = A_arbace_box_build_A_const_pool.A[219]; A_arbace_box_build_A_const_163 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[220]); A_arbace_box_build_A_const_164 = A_arbace_box_build_A_const_pool.A[221]; A_arbace_box_build_A_const_165 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[222]); A_arbace_box_build_A_const_166 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[223]); A_arbace_box_build_A_const_167 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[224]); A_arbace_box_build_A_const_168 = A_arbace_box_build_A_const_pool.A[225]; A_arbace_box_build_A_const_169 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[226]); A_arbace_box_build_A_const_170 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[227]) }

func A_arbace_box_build_A_clinit_p14() { A_arbace_box_build_A_const_171 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[228]); A_arbace_box_build_A_const_172 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[229]); A_arbace_box_build_A_const_173 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[230]); A_arbace_box_build_A_const_174 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[231]); A_arbace_box_build_A_const_175 = A_arbace_box_build_A_const_pool.A[232]; A_arbace_box_build_A_const_176 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[233]); A_arbace_box_build_A_const_177 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[234]); A_arbace_box_build_A_const_178 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[235]); A_arbace_box_build_A_const_179 = A_arbace_box_build_A_const_pool.A[236]; A_arbace_box_build_A_const_180 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[237]); A_arbace_box_build_A_const_181 = A_arbace_box_build_A_const_pool.A[238]; A_arbace_box_build_A_const_182 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[239]); A_arbace_box_build_A_const_183 = A_arbace_box_build_A_const_pool.A[240] }

func A_arbace_box_build_A_clinit_p15() { A_arbace_box_build_A_const_184 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[241]); A_arbace_box_build_A_const_185 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[242]); A_arbace_box_build_A_const_186 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[243]); A_arbace_box_build_A_const_187 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[244]) }

func A_arbace_box_build_A_New() *A_arbace_box_build_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_A{}; t.Ctor(); return t }

func (t *A_arbace_box_build_A) Ctor() {}

func (t *A_arbace_box_build_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_A_class }

func (t *A_arbace_box_build_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_build_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_A); return ok }

func A_arbace_box_build_A_Cast(x any) *A_arbace_box_build_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_A_class)) }; return v }



type A_arbace_box_build_action_A struct{ j2g_header uint64 }

var A_arbace_box_build_action_A_fn_class *jrt.Class



type A_arbace_box_build_action_STAR__A struct{ j2g_header uint64 }

var A_arbace_box_build_action_STAR__A_fn_class *jrt.Class



type A_arbace_box_build_append_members_A struct{ j2g_header uint64 }

var A_arbace_box_build_append_members_A_fn_class *jrt.Class



type A_arbace_box_build_ar_member_A struct{ j2g_header uint64 }

var A_arbace_box_build_ar_member_A_fn_class *jrt.Class



type A_arbace_box_build_ar_member_pad__598000077_A struct{ j2g_header uint64 }

var A_arbace_box_build_ar_member_pad__598000077_A_fn_class *jrt.Class



type A_arbace_box_build_arch_defines_A struct{ j2g_header uint64 }

var A_arbace_box_build_arch_defines_A_fn_class *jrt.Class



type A_arbace_box_build_archives_A struct{ j2g_header uint64 }

var A_arbace_box_build_archives_A_fn_class *jrt.Class



type A_arbace_box_build_archives_conveyed__598000244_A struct{ j2g_header uint64; F_opts any }

var A_arbace_box_build_archives_conveyed__598000244_A_fn_class *jrt.Class



type A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A struct{ j2g_header uint64; F_f, F_o any }

var A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000242_A struct{ j2g_header uint64 }

var A_arbace_box_build_archives_fn__598000242_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000252_A struct{ j2g_header uint64; F_given, F_q any }

var A_arbace_box_build_archives_fn__598000252_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000254_A struct{ j2g_header uint64; F_index, F_p, F_deps, F_sem, F_conveyed, F_q any }

var A_arbace_box_build_archives_fn__598000254_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000254_fn__598000255_A struct{ j2g_header uint64; F_index, F_p, F_deps, F_sem, F_q any }

var A_arbace_box_build_archives_fn__598000254_fn__598000255_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A struct{ j2g_header uint64 }

var A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000260_A struct{ j2g_header uint64; F_given, F_q any }

var A_arbace_box_build_archives_fn__598000260_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000262_A struct{ j2g_header uint64; F_index, F_p, F_deps, F_sem, F_conveyed, F_q any }

var A_arbace_box_build_archives_fn__598000262_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000262_fn__598000263_A struct{ j2g_header uint64; F_index, F_p, F_deps, F_sem, F_q any }

var A_arbace_box_build_archives_fn__598000262_fn__598000263_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A struct{ j2g_header uint64 }

var A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_fn_class *jrt.Class



type A_arbace_box_build_archives_iter__598000268__598000272_A struct{ j2g_header uint64 }

var A_arbace_box_build_archives_iter__598000268__598000272_A_fn_class *jrt.Class



type A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A struct{ j2g_header uint64; F_iter__598000268, F_s__598000269 any }

var A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_fn_class *jrt.Class



type A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A struct{ j2g_header uint64; F_b__598000271 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_fn_class *jrt.Class



type A_arbace_box_build_asm_args_A struct{ j2g_header uint64 }

var A_arbace_box_build_asm_args_A_fn_class *jrt.Class



type A_arbace_box_build_asm_args_fn__598000074_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_box_build_asm_args_fn__598000074_A_fn_class *jrt.Class



type A_arbace_box_build_build_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_A_fn_class *jrt.Class



type A_arbace_box_build_build_fn__598000301_A struct{ j2g_header uint64; F_p, F_image any; F_t0 int64 }

var A_arbace_box_build_build_fn__598000301_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_fn__598000179_A struct{ j2g_header uint64; F_P any }

var A_arbace_box_build_build_package_fn__598000179_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_fn__598000184_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_fn__598000184_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_fn__598000186_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_fn__598000186_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000150__598000154_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_iter__598000150__598000154_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A struct{ j2g_header uint64; F_iter__598000150, F_s__598000151 any }

var A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A struct{ j2g_header uint64; F_b__598000153 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000166__598000170_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_iter__598000166__598000170_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A struct{ j2g_header uint64; F_s__598000167, F_iter__598000166 any }

var A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A struct{ j2g_header uint64; F_b__598000169 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_A struct{ j2g_header uint64; F_res_of, F_P, F_plan, F_ctree, F_pkg, F_tools any }

var A_arbace_box_build_build_package_iter__598000189__598000193_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A struct{ j2g_header uint64; F_res_of, F_P, F_plan, F_ctree, F_pkg, F_tools, F_s__598000190, F_iter__598000189 any }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A struct{ j2g_header uint64; F_b__598000192, F_res_of, F_P, F_plan, F_ctree, F_pkg, F_tools any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A struct{ j2g_header uint64; F_res_of, F_P, F_plan, F_ctree, F_pkg, F_o, F_s, F_tools any }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A struct{ j2g_header uint64; F_res_of, F_P, F_plan, F_o, F_ctree, F_pkg, F_s, F_tools any }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000203__598000207_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_iter__598000203__598000207_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A struct{ j2g_header uint64; F_iter__598000203, F_s__598000204 any }

var A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A struct{ j2g_header uint64; F_b__598000206 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_res_of__598000176_A struct{ j2g_header uint64; F_P any }

var A_arbace_box_build_build_package_res_of__598000176_A_fn_class *jrt.Class



type A_arbace_box_build_cache_ref_A struct{ j2g_header uint64 }

var A_arbace_box_build_cache_ref_A_fn_class *jrt.Class



type A_arbace_box_build_complete_QMARK__A struct{ j2g_header uint64 }

var A_arbace_box_build_complete_QMARK__A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_A struct{ j2g_header uint64 }

var A_arbace_box_build_deps_tree_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000092__598000096_A struct{ j2g_header uint64; F_archives, F_index any }

var A_arbace_box_build_deps_tree_iter__598000092__598000096_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A struct{ j2g_header uint64; F_archives, F_index, F_iter__598000092, F_s__598000093 any }

var A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A struct{ j2g_header uint64; F_b__598000095, F_archives, F_index any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000102__598000106_A struct{ j2g_header uint64; F_index any }

var A_arbace_box_build_deps_tree_iter__598000102__598000106_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A struct{ j2g_header uint64; F_s__598000103, F_index, F_iter__598000102 any }

var A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A struct{ j2g_header uint64; F_index, F_b__598000105 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_A struct{ j2g_header uint64 }

var A_arbace_box_build_embed_config_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000116__598000120_A struct{ j2g_header uint64 }

var A_arbace_box_build_embed_config_iter__598000116__598000120_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A struct{ j2g_header uint64; F_iter__598000116, F_s__598000117 any }

var A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A struct{ j2g_header uint64; F_b__598000119 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000132__598000136_A struct{ j2g_header uint64 }

var A_arbace_box_build_embed_config_iter__598000132__598000136_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A struct{ j2g_header uint64; F_s__598000133, F_iter__598000132 any }

var A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A struct{ j2g_header uint64; F_b__598000135 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_fn_class *jrt.Class



type A_arbace_box_build_eval598000004_A struct{ jrt.Object }

func A_arbace_box_build_eval598000004_A_New() *A_arbace_box_build_eval598000004_A { t := &A_arbace_box_build_eval598000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_build_eval598000004_A) Ctor() {}

func (t *A_arbace_box_build_eval598000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_eval598000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_eval598000004_A_class }

func (t *A_arbace_box_build_eval598000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_eval598000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_build_eval598000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_eval598000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_eval598000004_A); return ok }

func A_arbace_box_build_eval598000004_A_Cast(x any) *A_arbace_box_build_eval598000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_eval598000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_eval598000004_A_class)) }; return v }



type A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A struct{ j2g_header uint64 }

var A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_fn_class *jrt.Class



type A_arbace_box_build_eval598000008_A struct{ jrt.Object }

func A_arbace_box_build_eval598000008_A_New() *A_arbace_box_build_eval598000008_A { t := &A_arbace_box_build_eval598000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_build_eval598000008_A) Ctor() {}

func (t *A_arbace_box_build_eval598000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_eval598000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_eval598000008_A_class }

func (t *A_arbace_box_build_eval598000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_eval598000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_build_eval598000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_eval598000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_eval598000008_A); return ok }

func A_arbace_box_build_eval598000008_A_Cast(x any) *A_arbace_box_build_eval598000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_eval598000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_eval598000008_A_class)) }; return v }



type A_arbace_box_build_eval598000008_fn__598000009_A struct{ j2g_header uint64 }

var A_arbace_box_build_eval598000008_fn__598000009_A_fn_class *jrt.Class



type A_arbace_box_build_fail_A struct{ j2g_header uint64 }

var A_arbace_box_build_fail_A_fn_class *jrt.Class



type A_arbace_box_build_file_tree_A struct{ j2g_header uint64 }

var A_arbace_box_build_file_tree_A_fn_class *jrt.Class



type A_arbace_box_build_file_tree_iter__598000054__598000058_A struct{ j2g_header uint64 }

var A_arbace_box_build_file_tree_iter__598000054__598000058_A_fn_class *jrt.Class



type A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A struct{ j2g_header uint64; F_s__598000055, F_iter__598000054 any }

var A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_fn_class *jrt.Class



type A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A struct{ j2g_header uint64; F_b__598000057 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_fn_class *jrt.Class



type A_arbace_box_build_import_plan_A struct{ j2g_header uint64 }

var A_arbace_box_build_import_plan_A_fn_class *jrt.Class



type A_arbace_box_build_import_plan_fn__598000044_A struct{ j2g_header uint64; F_src any }

var A_arbace_box_build_import_plan_fn__598000044_A_fn_class *jrt.Class



type A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A struct{ j2g_header uint64; F_src any }

var A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_fn_class *jrt.Class



type A_arbace_box_build_import_plan_src__598000042_A struct{ j2g_header uint64; F_dirs any }

var A_arbace_box_build_import_plan_src__598000042_A_fn_class *jrt.Class



type A_arbace_box_build_json_str_A struct{ j2g_header uint64 }

var A_arbace_box_build_json_str_A_fn_class *jrt.Class



type A_arbace_box_build_json_str_fn__598000113_A struct{ j2g_header uint64 }

var A_arbace_box_build_json_str_fn__598000113_A_fn_class *jrt.Class



type A_arbace_box_build_link_A struct{ j2g_header uint64 }

var A_arbace_box_build_link_A_fn_class *jrt.Class



type A_arbace_box_build_link_fn__598000285_A struct{ j2g_header uint64 }

var A_arbace_box_build_link_fn__598000285_A_fn_class *jrt.Class



type A_arbace_box_build_link_iter__598000290__598000294_A struct{ j2g_header uint64 }

var A_arbace_box_build_link_iter__598000290__598000294_A_fn_class *jrt.Class



type A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A struct{ j2g_header uint64; F_iter__598000290, F_s__598000291 any }

var A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_fn_class *jrt.Class



type A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A struct{ j2g_header uint64; F_b__598000293 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_fn_class *jrt.Class



type A_arbace_box_build_log_A struct{ j2g_header uint64 }

var A_arbace_box_build_log_A_fn_class *jrt.Class



type A_arbace_box_build_out_file_A struct{ j2g_header uint64 }

var A_arbace_box_build_out_file_A_fn_class *jrt.Class



type A_arbace_box_build_read_plan_A struct{ j2g_header uint64 }

var A_arbace_box_build_read_plan_A_fn_class *jrt.Class



type A_arbace_box_build_sha256_hex_A struct{ j2g_header uint64 }

var A_arbace_box_build_sha256_hex_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_A struct{ j2g_header uint64 }

var A_arbace_box_build_source_tree_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_headers__598000018_A struct{ j2g_header uint64 }

var A_arbace_box_build_source_tree_headers__598000018_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A struct{ j2g_header uint64; F_headers any }

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A struct{ j2g_header uint64; F_iter__598000019, F_headers, F_s__598000020 any }

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A struct{ j2g_header uint64; F_headers, F_b__598000022 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_iter__598000030__598000034_A struct{ j2g_header uint64; F_headers any }

var A_arbace_box_build_source_tree_iter__598000030__598000034_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A struct{ j2g_header uint64; F_headers, F_iter__598000030, F_s__598000031 any }

var A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A struct{ j2g_header uint64; F_headers, F_b__598000033 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_fn_class *jrt.Class



type A_arbace_box_build_with_tools_A struct{ j2g_header uint64 }

var A_arbace_box_build_with_tools_A_fn_class *jrt.Class



type A_arbace_box_build_with_tools_iter__598000221__598000225_A struct{ j2g_header uint64; F_arch any }

var A_arbace_box_build_with_tools_iter__598000221__598000225_A_fn_class *jrt.Class



type A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A struct{ j2g_header uint64; F_s__598000222, F_arch, F_iter__598000221 any }

var A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_fn_class *jrt.Class



type A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A struct{ j2g_header uint64; F_b__598000224, F_arch any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_fn_class *jrt.Class
