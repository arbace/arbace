//line aot_arbace_box_build.ae:1
package aot_arbace_box_build

import (
	"arbace/aot_arbace_box"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_edn"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :4:1
func A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_New() *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_build_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_box_build_A_const_1); lang.IFn_Cast(A_arbace_box_build_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_box_build_A_const_3, A_arbace_box_build_A_const_4, A_arbace_box_build_A_const_5); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_112)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_113)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_114)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :4:1
func A_arbace_box_build_eval598000008_fn__598000009_A_New() *A_arbace_box_build_eval598000008_fn__598000009_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_eval598000008_fn__598000009_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_build_eval598000008_fn__598000009_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_build_eval598000008_fn__598000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_box_build_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_box_build_A_const_9.GetRawRoot__O(), A_arbace_box_build_A_const_10) }







































func A_arbace_box_build_fail_A_New() *A_arbace_box_build_fail_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_fail_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_box_build_fail_A) Ctor() {}
//line :44:1
func (t *A_arbace_box_build_fail_A) Invoke_O_O_O__O(self, msg__0, data__1 any) any { var tmp1 any; var root_21 any = A_arbace_box_build_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_23 lang.IFn; if
											linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = msg__0; var arg_25 any; var root_26 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = data__1; var arg_30 any = A_arbace_box_build_A_const_13; var arg_31 any = jrt.Boolean_TRUE.Ref(); if linked_27 == nil { arg_25 = ifn_28.Invoke_O_O_O__O(arg_29, arg_30, arg_31) } else { arg_25 = linked_27.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_26, arg_29, arg_30, arg_31) }; if linked_22 == nil { tmp1 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { tmp1 = linked_22.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; /*line :44:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }


func A_arbace_box_build_sha256_hex_A_New() *A_arbace_box_build_sha256_hex_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_sha256_hex_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_box_build_sha256_hex_A) Ctor() {}
//line :47:1
func (t *A_arbace_box_build_sha256_hex_A) Invoke_O_O__O(self, s__0 any) any { var d__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_140).Digest_B1__B1(jrt.NN(jrt.String_Cast(s__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8)).Ref(); var sb__3 any = jrt.StringBuilder_New(); var seq_598000013__4 any; var root_36 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_38 lang.IFn; if


	linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = d__2; if linked_37 == nil { seq_598000013__4 = ifn_38.Invoke_O__O(arg_39) } else { seq_598000013__4 = linked_37.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_36, arg_39) }; var chunk_598000014__5 any; var count_598000015__6 int64 = 0; var i_598000016__7 int64 = 0; L1:
//line :47:1
	for {


		if lang.Numbers_Lt_J_J__Z_NoInit(i_598000016__7, count_598000015__6) { var b__8 any = lang.Indexed_Cast(chunk_598000014__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_598000016__7)); var x__9 int64; var na_56 any = b__8; var na_57 int64 = 255
			if jrt.Long_InstanceOf(na_56) { var n0_58 int64 = jrt.NN(jrt.Long_Cast(na_56)).LongValue__J(); var n1_59 int64 = na_57; x__9 = n0_58 & n1_59 } else { x__9 = lang.Numbers_And_O_J__J_NoInit(na_56, na_57) }
			jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(x__9, 4)), lang.RT_IntCast_J__I_NoInit(16)))
			jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_And_J_J__J_NoInit(x__9, 15)), lang.RT_IntCast_J__I_NoInit(16)))
//line :50:1
			seq_598000013__4, chunk_598000014__5, count_598000015__6, i_598000016__7 = seq_598000013__4, chunk_598000014__5, count_598000015__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_598000016__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_40 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = seq_598000013__4; if linked_41 == nil { temp__1927000414__auto____8 = ifn_42.Invoke_O__O(arg_43) } else { temp__1927000414__auto____8 = linked_41.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_40, arg_43) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_598000013__9 any = temp__1927000414__auto____8; var tmp1 any; var root_44 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = seq_598000013__9; if linked_45 == nil { tmp1 = ifn_46.Invoke_O__O(arg_47) } else { tmp1 = linked_45.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_44, arg_47) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____10 any; var root_48 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = seq_598000013__9; if linked_49 == nil { c__1927000678__auto____10 = ifn_50.Invoke_O__O(arg_51) } else { c__1927000678__auto____10 = linked_49.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_48, arg_51) }; var tmp2 any; var root_61 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = seq_598000013__9; if linked_62 == nil { tmp2 = ifn_63.Invoke_O__O(arg_64) } else { tmp2 = linked_62.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_61, arg_64) }; seq_598000013__4, chunk_598000014__5, count_598000015__6, i_598000016__7 = tmp2, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var b__10 any; var root_52 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = seq_598000013__9; if linked_53 == nil { b__10 = ifn_54.Invoke_O__O(arg_55) } else { b__10 = linked_53.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_52, arg_55) }; var x__11 int64; var na_65 any = b__10; var na_66 int64 = 255
				if jrt.Long_InstanceOf(na_65) { var n0_67 int64 = jrt.NN(jrt.Long_Cast(na_65)).LongValue__J(); var n1_68 int64 = na_66; x__11 = n0_67 & n1_68 } else { x__11 = lang.Numbers_And_O_J__J_NoInit(na_65, na_66) }
				jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(x__11, 4)), lang.RT_IntCast_J__I_NoInit(16)))
				jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_And_J_J__J_NoInit(x__11, 15)), lang.RT_IntCast_J__I_NoInit(16)))
//line :50:1
				var tmp3 any; var root_70 any = A_arbace_box_build_A_const_20.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = seq_598000013__9; if linked_71 == nil { tmp3 = ifn_72.Invoke_O__O(arg_73) } else { tmp3 = linked_71.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_70, arg_73) }; seq_598000013__4, chunk_598000014__5, count_598000015__6, i_598000016__7 = tmp3, nil, 0, 0; continue L1 } } }
//line :47:1
		break L1 }; var root_32 any =






	A_arbace_box_build_A_const_14.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = sb__3; if linked_33 == nil { return ifn_34.Invoke_O__O(arg_35) } else { return linked_33.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_32, arg_35) } }




func A_arbace_box_build_source_tree_A_New() *A_arbace_box_build_source_tree_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_A{}; t.Ctor(); return t }
//line :59:1
func (t *A_arbace_box_build_source_tree_A) Ctor() {}
//line :59:1
func (t *A_arbace_box_build_source_tree_A) Invoke_O_O__O(self, d__0 any) any { var fs__2 any = jrt.NN(jrt.File_Cast(d__0)).ListFiles__File1().Ref(); var headers__3 any; var tmp1 any = A_arbace_box_build_source_tree_headers__598000018_A_New(); var tmp2 *jrt.Class; var fncls__168 *jrt.Class = A_arbace_box_build_source_tree_headers__598000018_A_fn_class; if




	fncls__168 == nil { var fncls__168d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_box_build_source_tree_headers__598000018_A_fn_class = fncls__168d; tmp2 = fncls__168d } else { tmp2 = fncls__168 }; headers__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var root_169 any =








	A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any; var root_173 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_175 lang.IFn; if
	linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_177 any; var iter__1927001039__auto____4 any; var tmp3 any = A_arbace_box_build_source_tree_iter__598000030__598000034_A_New_O(headers__3); var tmp4 *jrt.Class; var fncls__248 *jrt.Class = A_arbace_box_build_source_tree_iter__598000030__598000034_A_fn_class; if
	fncls__248 == nil { var fncls__248d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_box_build_source_tree_iter__598000030__598000034_A_fn_class = fncls__248d; tmp4 = fncls__248d } else { tmp4 = fncls__248 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); arg_177 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(fs__2); if /*line :74:1*/ linked_174 == nil { arg_172 = ifn_175.Invoke_O_O__O(arg_176, arg_177) } else { arg_172 = linked_174.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_173, arg_176, arg_177) }; if /*line :73:1*/ linked_170 == nil { return ifn_171.Invoke_O__O(arg_172) } else { return linked_170.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_169, arg_172) } }
//line :64:1
func A_arbace_box_build_source_tree_headers__598000018_A_New() *A_arbace_box_build_source_tree_headers__598000018_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_box_build_source_tree_headers__598000018_A) Ctor() {}
//line :64:1
func (t *A_arbace_box_build_source_tree_headers__598000018_A) Invoke_O_O__O(self, s__1 any) any { var m__2 any; var root_74 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_76 lang.IFn; if
												linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_78 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_New_O(self); var tmp2 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_fn_class; if
												fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_fn_class = fncls__159d; tmp2 = fncls__159d } else { tmp2 = fncls__159 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_78 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(jrt.NN(jrt.File_Cast(s__1)).ListFiles__File1().Ref()); if /*line :65:1*/ linked_75 == nil { m__2 = ifn_76.Invoke_O_O__O(arg_77, arg_78) } else { m__2 = linked_75.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_74, arg_77, arg_78) }; var tmp3 any; var root_160 any =






	A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = m__2; if linked_161 == nil { tmp3 = ifn_162.Invoke_O__O(arg_163) } else { tmp3 = linked_161.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_160, arg_163) }; if jrt.J2g_Truth(tmp3) { var root_164 any = A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = m__2; if linked_165 == nil { return ifn_166.Invoke_O__O(arg_167) } else { return linked_165.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_164, arg_167) } } else { return nil } }
//line :66:1
func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_New_O(p0 any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A{}; t.Ctor_O(p0); return t }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A) Ctor_O(c__headers any) { t.F_headers = c__headers }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A) Invoke_O_O__O(self, s__598000020__1 any) any { var tmp1 any = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_New_O_O_O(self, t.F_headers, s__598000020__1); var tmp2 *jrt.Class; var fncls__158 *jrt.Class = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_fn_class; if fncls__158 == nil { var fncls__158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_fn_class = fncls__158d; tmp2 = fncls__158d } else { tmp2 = fncls__158 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :66:1
func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A) Ctor_O_O_O(c__iter__598000019, c__headers, c__s__598000020 any) { t.F_iter__598000019 = c__iter__598000019; t.F_headers = c__headers; t.F_s__598000020 = c__s__598000020 }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A) Invoke_O__O(self any) any { { var s__598000020__1 any; var t_ any = t.F_s__598000020; t.F_s__598000020 = nil; s__598000020__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_79 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = s__598000020__1; if linked_80 == nil { temp__1927000414__auto____2 = ifn_81.Invoke_O__O(arg_82) } else { temp__1927000414__auto____2 = linked_80.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_79, arg_82) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000020__3 any = temp__1927000414__auto____2; var tmp1 any; var root_83 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = s__598000020__3; if linked_84 == nil { tmp1 = ifn_85.Invoke_O__O(arg_86) } else { tmp1 = linked_84.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_83, arg_86) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_87 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = s__598000020__3; if linked_88 == nil { c__1927001037__auto____4 = ifn_89.Invoke_O__O(arg_90) } else { c__1927001037__auto____4 = linked_88.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_87, arg_90) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000022__6 any; var root_91 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_92 == nil { b__598000022__6 = ifn_93.Invoke_O__O(arg_94) } else { b__598000022__6 = linked_92.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_91, arg_94) }; var tmp2 any = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_New_O_O_I_O(t.F_headers, b__598000022__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_110 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any; var root_115 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = b__598000022__6; if linked_116 == nil { arg_113 = ifn_117.Invoke_O__O(arg_118) } else { arg_113 = linked_116.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_115, arg_118) }; var arg_114 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000019); var tmp5 any; var root_119 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = s__598000020__3; if linked_120 == nil { tmp5 = ifn_121.Invoke_O__O(arg_122) } else { tmp5 = linked_120.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_119, arg_122) }; arg_114 = tmp4.Invoke_O__O(tmp5); if linked_111 == nil { return ifn_112.Invoke_O_O__O(arg_113, arg_114) } else { return linked_111.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_110, arg_113, arg_114) } } else { var root_123 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any; var root_128 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = b__598000022__6; if linked_129 == nil { arg_126 = ifn_130.Invoke_O__O(arg_131) } else { arg_126 = linked_129.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_128, arg_131) }; var arg_127 any; if linked_124 == nil { return ifn_125.Invoke_O_O__O(arg_126, arg_127) } else { return linked_124.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_123, arg_126, arg_127) } } } else { var f__4 any; var root_132 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = s__598000020__3; if linked_133 == nil { f__4 = ifn_134.Invoke_O__O(arg_135) } else { f__4 = linked_133.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_132, arg_135) }; var e__5 any
																	if jrt.NN(jrt.File_Cast(f__4)).IsDirectory__Z() { var temp__1927000414__auto____5 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__4); if jrt.J2g_Truth(temp__1927000414__auto____5) { var h__6 any = temp__1927000414__auto____5; e__5 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_25, h__6) } else { e__5 = nil } } else { var tmp6 any; var root_136 any = A_arbace_box_build_A_const_23.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_138 lang.IFn
																		if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var arg_140 any = Lit_146; if linked_137 == nil { tmp6 = ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { tmp6 = linked_137.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_136, arg_139, arg_140) }
//line :67:1
		if jrt.J2g_Truth(tmp6) {

			var root_141 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()).Ref(); if linked_142 == nil { e__5 = ifn_143.Invoke_O__O(arg_144) } else { e__5 = linked_142.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_141, arg_144) } } else {
//line :67:1
				e__5 = nil } }
//line :66:1
	if jrt.J2g_Truth(e__5) { var root_145 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), e__5); var arg_149 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__598000019); var tmp8 any; var root_150 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = s__598000020__3; if linked_151 == nil { tmp8 = ifn_152.Invoke_O__O(arg_153) } else { tmp8 = linked_151.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_150, arg_153) }; arg_149 = tmp7.Invoke_O__O(tmp8); if linked_146 == nil { return ifn_147.Invoke_O_O__O(arg_148, arg_149) } else { return linked_146.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_145, arg_148, arg_149) } } else { var tmp9 any; var root_154 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = s__598000020__3; if linked_155 == nil { tmp9 = ifn_156.Invoke_O__O(arg_157) } else { tmp9 = linked_155.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_154, arg_157) }; s__598000020__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :66:1
func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A) Ctor_O_O_I_O(c__headers, c__b__598000022 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_headers = c__headers; t.F_b__598000022 = c__b__598000022; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A) Invoke_O__O(self any) any { { var i__598000021__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000021__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000021__1)); var e__3 any
																		if jrt.NN(jrt.File_Cast(f__2)).IsDirectory__Z() { var temp__1927000414__auto____3 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__2); if jrt.J2g_Truth(temp__1927000414__auto____3) { var h__4 any = temp__1927000414__auto____3; e__3 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_25, h__4) } else { e__3 = nil } } else { var tmp2 any; var root_95 any = A_arbace_box_build_A_const_23.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_97 lang.IFn
																			if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var arg_99 any = Lit_146; if linked_96 == nil { tmp2 = ifn_97.Invoke_O_O__O(arg_98, arg_99) } else { tmp2 = linked_96.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_95, arg_98, arg_99) }
//line :67:1
		if jrt.J2g_Truth(tmp2) {

			var root_100 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()).Ref(); if linked_101 == nil { e__3 = ifn_102.Invoke_O__O(arg_103) } else { e__3 = linked_101.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_100, arg_103) } } else {
//line :67:1
				e__3 = nil } }
//line :66:1
	if jrt.J2g_Truth(e__3) { var root_104 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = t.F_b__598000022; var arg_108 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), e__3); if linked_105 == nil { ifn_106.Invoke_O_O__O(arg_107, arg_108) } else { linked_105.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_104, arg_107, arg_108) }; i__598000021__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000021__1); continue L1 } else { i__598000021__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000021__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_box_build_source_tree_iter__598000030__598000034_A_New_O(p0 any) *A_arbace_box_build_source_tree_iter__598000030__598000034_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_iter__598000030__598000034_A{}; t.Ctor_O(p0); return t }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_A) Ctor_O(c__headers any) { t.F_headers = c__headers }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_A) Invoke_O_O__O(self, s__598000031__1 any) any { var tmp1 any = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_New_O_O_O(t.F_headers, self, s__598000031__1); var tmp2 *jrt.Class; var fncls__247 *jrt.Class = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_fn_class; if fncls__247 == nil { var fncls__247d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_fn_class = fncls__247d; tmp2 = fncls__247d } else { tmp2 = fncls__247 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :75:1
func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A) Ctor_O_O_O(c__headers, c__iter__598000030, c__s__598000031 any) { t.F_headers = c__headers; t.F_iter__598000030 = c__iter__598000030; t.F_s__598000031 = c__s__598000031 }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A) Invoke_O__O(self any) any { { var s__598000031__1 any; var t_ any = t.F_s__598000031; t.F_s__598000031 = nil; s__598000031__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_178 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = s__598000031__1; if linked_179 == nil { temp__1927000414__auto____2 = ifn_180.Invoke_O__O(arg_181) } else { temp__1927000414__auto____2 = linked_179.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_178, arg_181) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000031__3 any = temp__1927000414__auto____2; var tmp1 any; var root_182 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = s__598000031__3; if linked_183 == nil { tmp1 = ifn_184.Invoke_O__O(arg_185) } else { tmp1 = linked_183.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_182, arg_185) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_186 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = s__598000031__3; if linked_187 == nil { c__1927001037__auto____4 = ifn_188.Invoke_O__O(arg_189) } else { c__1927001037__auto____4 = linked_187.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_186, arg_189) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000033__6 any; var root_190 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_191 == nil { b__598000033__6 = ifn_192.Invoke_O__O(arg_193) } else { b__598000033__6 = linked_191.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_190, arg_193) }; var tmp2 any = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_New_O_O_I_O(t.F_headers, b__598000033__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__203 *jrt.Class = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_fn_class; if fncls__203 == nil { var fncls__203d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_fn_class = fncls__203d; tmp3 = fncls__203d } else { tmp3 = fncls__203 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_204 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any; var root_209 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = b__598000033__6; if linked_210 == nil { arg_207 = ifn_211.Invoke_O__O(arg_212) } else { arg_207 = linked_210.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_209, arg_212) }; var arg_208 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000030); var tmp5 any; var root_213 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = s__598000031__3; if linked_214 == nil { tmp5 = ifn_215.Invoke_O__O(arg_216) } else { tmp5 = linked_214.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_213, arg_216) }; arg_208 = tmp4.Invoke_O__O(tmp5); if linked_205 == nil { return ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { return linked_205.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) } } else { var root_217 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any; var root_222 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = b__598000033__6; if linked_223 == nil { arg_220 = ifn_224.Invoke_O__O(arg_225) } else { arg_220 = linked_223.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_222, arg_225) }; var arg_221 any; if linked_218 == nil { return ifn_219.Invoke_O_O__O(arg_220, arg_221) } else { return linked_218.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_217, arg_220, arg_221) } } } else { var f__4 any; var root_226 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = s__598000031__3; if linked_227 == nil { f__4 = ifn_228.Invoke_O__O(arg_229) } else { f__4 = linked_227.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_226, arg_229) }; var e__5 any
														if jrt.NN(jrt.File_Cast(f__4)).IsDirectory__Z() { var temp__1927000414__auto____5 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__4)
															if jrt.J2g_Truth(temp__1927000414__auto____5) { var h__6 any = temp__1927000414__auto____5; e__5 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_25, h__6) } else { e__5 = nil } } else {
																var root_230 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()).Ref(); if linked_231 == nil { e__5 = ifn_232.Invoke_O__O(arg_233) } else { e__5 = linked_231.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_230, arg_233) } }
//line :75:1
	if jrt.J2g_Truth(e__5) { var root_234 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), e__5); var arg_238 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000030); var tmp7 any; var root_239 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = s__598000031__3; if linked_240 == nil { tmp7 = ifn_241.Invoke_O__O(arg_242) } else { tmp7 = linked_240.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_239, arg_242) }; arg_238 = tmp6.Invoke_O__O(tmp7); if linked_235 == nil { return ifn_236.Invoke_O_O__O(arg_237, arg_238) } else { return linked_235.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_234, arg_237, arg_238) } } else { var tmp8 any; var root_243 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = s__598000031__3; if linked_244 == nil { tmp8 = ifn_245.Invoke_O__O(arg_246) } else { tmp8 = linked_244.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_243, arg_246) }; s__598000031__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :75:1
func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A) Ctor_O_O_I_O(c__headers, c__b__598000033 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_headers = c__headers; t.F_b__598000033 = c__b__598000033; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A) Invoke_O__O(self any) any { { var i__598000032__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000032__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000032__1)); var e__3 any
																if jrt.NN(jrt.File_Cast(f__2)).IsDirectory__Z() { var temp__1927000414__auto____3 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__2)
																	if jrt.J2g_Truth(temp__1927000414__auto____3) { var h__4 any = temp__1927000414__auto____3; e__3 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_25, h__4) } else { e__3 = nil } } else {
																		var root_194 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()).Ref(); if linked_195 == nil { e__3 = ifn_196.Invoke_O__O(arg_197) } else { e__3 = linked_195.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_194, arg_197) } }
//line :75:1
	if jrt.J2g_Truth(e__3) { var root_198 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = t.F_b__598000033; var arg_202 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), e__3); if linked_199 == nil { ifn_200.Invoke_O_O__O(arg_201, arg_202) } else { linked_199.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_198, arg_201, arg_202) }; i__598000032__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000032__1); continue L1 } else { i__598000032__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000032__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_box_build_import_plan_A_New() *A_arbace_box_build_import_plan_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_import_plan_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_box_build_import_plan_A) Ctor() {}
//line :82:1
func (t *A_arbace_box_build_import_plan_A) Invoke_O_O_O__O(self, plan__0, goroot__1 any) any { var p__3 any; var tmp1 any; var root_249 any = A_arbace_box_build_A_const_32.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_251 lang.IFn; if




	linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = plan__0; if linked_250 == nil { tmp1 = ifn_251.Invoke_O__O(arg_252) } else { tmp1 = linked_250.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_249, arg_252) }; if jrt.J2g_Truth(tmp1) { p__3 = plan__0 } else { var root_253 any = A_arbace_box_build_A_const_33.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_edn.A_arbace_edn_read_string_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = lang.IFn_Cast(A_arbace_box_build_A_const_34.GetRawRoot__O()).Invoke_O__O(plan__0); if linked_254 == nil { p__3 = ifn_255.Invoke_O__O(arg_256) } else { p__3 = linked_254.(*aot_arbace_edn.A_arbace_edn_read_string_A).Invoke_O_O__O(root_253, arg_256) } }; var dirs__4 any; var root_261 any = /*line :82:1*/A_arbace_box_build_A_const_35.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_263 lang.IFn; if





	linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_262 == nil { dirs__4 = ifn_263.Invoke_O__O(arg_264) } else { dirs__4 = linked_262.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_261, arg_264) }; var src__5 any; var tmp2 any = /*line :82:1*/A_arbace_box_build_import_plan_src__598000042_A_New_O(dirs__4); var tmp3 *jrt.Class; var fncls__280 *jrt.Class = A_arbace_box_build_import_plan_src__598000042_A_fn_class; if






	fncls__280 == nil { var fncls__280d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_box_build_import_plan_src__598000042_A_fn_class = fncls__280d; tmp3 = fncls__280d } else { tmp3 = fncls__280 }; src__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var p__6 any; var root_281 any = /*line :82:1*/A_arbace_box_build_A_const_38.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_283 lang.IFn; if









	linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any; var root_287 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_289 lang.IFn; if /*line :91:1*/ linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = p__3; var arg_291 any = A_arbace_box_build_A_const_39; var arg_292 any; var root_293 any = A_arbace_box_build_A_const_40.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, aot_arbace_box.A_arbace_box_put_dir_A_fn_class); var ifn_295 lang.IFn; if linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_119), jrt.RefArrayOf(jrt.Object_class, goroot__1, nil)).Ref(); if linked_294 == nil { arg_292 = ifn_295.Invoke_O__O(arg_296) } else { arg_292 = linked_294.(*aot_arbace_box.A_arbace_box_put_dir_A).Invoke_O_O__O(root_293, arg_296) }; if linked_288 == nil { arg_284 = ifn_289.Invoke_O_O_O__O(arg_290, arg_291, arg_292) } else { arg_284 = linked_288.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_287, arg_290, arg_291, arg_292) }; var arg_285 any = A_arbace_box_build_A_const_41; var arg_286 any; var tmp4 any =
	A_arbace_box_build_import_plan_fn__598000044_A_New_O(src__5); var tmp5 *jrt.Class; var fncls__314 *jrt.Class = A_arbace_box_build_import_plan_fn__598000044_A_fn_class; if fncls__314 == nil { var fncls__314d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_box_build_import_plan_fn__598000044_A_fn_class = fncls__314d; tmp5 = fncls__314d } else { tmp5 = fncls__314 }; arg_286 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if linked_282 == nil { p__6 = ifn_283.Invoke_O_O_O__O(arg_284, arg_285, arg_286) } else { p__6 = linked_282.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_281, arg_284, arg_285, arg_286) }; var root_315 any =
	A_arbace_box_build_A_const_45.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_box.A_arbace_box_put_A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = lang.IFn_Cast(A_arbace_box_build_A_const_46.GetRawRoot__O()).Invoke_O__O(p__6); if linked_316 == nil { return ifn_317.Invoke_O__O(arg_318) } else { return linked_316.(*aot_arbace_box.A_arbace_box_put_A).Invoke_O_O__O(root_315, arg_318) } }
//line :82:1
func (t *A_arbace_box_build_import_plan_A) Invoke_O_O__O(self, plan__0 any) any {


	var root_323 any = A_arbace_box_build_A_const_47.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, A_arbace_box_build_import_plan_A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = plan__0; var arg_327 any = Lit_121; if linked_324 == nil { return ifn_325.Invoke_O_O__O(arg_326, arg_327) } else { return linked_324.(*A_arbace_box_build_import_plan_A).Invoke_O_O_O__O(root_323, arg_326, arg_327)
	}
}

func A_arbace_box_build_import_plan_src__598000042_A_New_O(p0 any) *A_arbace_box_build_import_plan_src__598000042_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_import_plan_src__598000042_A{}; t.Ctor_O(p0); return t }
//line :89:1
func (t *A_arbace_box_build_import_plan_src__598000042_A) Ctor_O(c__dirs any) { t.F_dirs = c__dirs }
//line :89:1
func (t *A_arbace_box_build_import_plan_src__598000042_A) Invoke_O_O__O(self, dir__1 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_265 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = t.F_dirs; if linked_266 == nil { tmp1 = ifn_267.Invoke_O__O(arg_268) } else { tmp1 = linked_266.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_265, arg_268) }; or__1927000174__auto____2 = lang.IFn_Cast(tmp1).Invoke_O__O(dir__1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var h__3 any; var root_269 any = A_arbace_box_build_A_const_36.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, A_arbace_box_build_source_tree_A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = jrt.File_New_String(jrt.String_Cast(dir__1)); if linked_270 == nil { h__3 = ifn_271.Invoke_O__O(arg_272) } else { h__3 = linked_270.(*A_arbace_box_build_source_tree_A).Invoke_O_O__O(root_269, arg_272) }; var root_273 any = A_arbace_box_build_A_const_37.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = t.F_dirs; var arg_277 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var arg_278 any = dir__1; var arg_279 any = h__3; if linked_274 == nil { ifn_275.Invoke_O_O_O_O__O(arg_276, arg_277, arg_278, arg_279) } else { linked_274.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_273, arg_276, arg_277, arg_278, arg_279) }; return h__3 } }


func A_arbace_box_build_import_plan_fn__598000044_A_New_O(p0 any) *A_arbace_box_build_import_plan_fn__598000044_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_import_plan_fn__598000044_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_A) Ctor_O(c__src any) { t.F_src = c__src }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_A) Invoke_O_O__O(self, ps__1 any) any { var root_297 any = A_arbace_box_build_A_const_42.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_297, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_299 lang.IFn; if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any; var tmp1 any = A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_New_O(t.F_src); var tmp2 *jrt.Class; var fncls__313 *jrt.Class = A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_fn_class; if fncls__313 == nil { var fncls__313d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_fn_class = fncls__313d; tmp2 = fncls__313d } else { tmp2 = fncls__313 }; arg_300 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_301 any = ps__1; if linked_298 == nil { return ifn_299.Invoke_O_O__O(arg_300, arg_301) } else { return linked_298.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_297, arg_300, arg_301) } }
//line :92:1
func A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_New_O(p0 any) *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A) Ctor_O(c__src any) { t.F_src = c__src }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A) Invoke_O_O__O(self, p1__598000041_SHARP___1 any) any { var root_302 any = A_arbace_box_build_A_const_43.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any; var root_307 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any = p1__598000041_SHARP___1; var arg_311 any = A_arbace_box_build_A_const_44; var tmp1 lang.IFn = lang.IFn_Cast(t.F_src); var arg_312 any = tmp1.Invoke_O__O(A_arbace_box_build_A_const_25.Invoke_O__O(p1__598000041_SHARP___1)); if linked_308 == nil { arg_305 = ifn_309.Invoke_O_O_O__O(arg_310, arg_311, arg_312) } else { arg_305 = linked_308.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_307, arg_310, arg_311, arg_312) }; var arg_306 any = A_arbace_box_build_A_const_25; if linked_303 == nil { return ifn_304.Invoke_O_O__O(arg_305, arg_306) } else { return linked_303.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_302, arg_305, arg_306) } }







func A_arbace_box_build_log_A_New() *A_arbace_box_build_log_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_log_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_box_build_log_A) Ctor() {}
//line :100:1
func (t *A_arbace_box_build_log_A) DoInvoke_O_O__O(self, xs__0 any) any {
	var tmp1 lang.IFn = A_arbace_box_build_A_const_48; var tmp2 lang.IFn = lang.IFn_Cast(tmp1.Invoke_O_O__O(A_arbace_box_build_A_const_49.Get__O(), A_arbace_box_build_A_const_50.GetRawRoot__O())); var tmp3 any; var root_328 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_332 any = xs__0; if linked_329 == nil { tmp3 = ifn_330.Invoke_O_O__O(arg_331, arg_332) } else { tmp3 = linked_329.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_328, arg_331, arg_332) }; return tmp2.Invoke_O__O(tmp3)
}
func A_arbace_box_build_cache_ref_A_New() *A_arbace_box_build_cache_ref_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_cache_ref_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_box_build_cache_ref_A) Ctor() {}
//line :103:1
func (t *A_arbace_box_build_cache_ref_A) Invoke_O_O__O(self, req__0 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_89, nil); var tmp2 any; var root_333 any = A_arbace_box_build_A_const_52.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any; var root_339 any = A_arbace_box_build_A_const_53.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, A_arbace_box_build_sha256_hex_A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any; var root_343 any = A_arbace_box_build_A_const_54.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_box.A_arbace_box_request_text_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = lang.IFn_Cast(A_arbace_box_build_A_const_43.GetRawRoot__O()).Invoke_O_O_O__O(req__0, A_arbace_box_build_A_const_55, A_arbace_box_build_A_const_56); if linked_344 == nil { arg_342 = ifn_345.Invoke_O__O(arg_346) } else { arg_342 = linked_344.(*aot_arbace_box.A_arbace_box_request_text_A).Invoke_O_O__O(root_343, arg_346) }; if linked_340 == nil { arg_336 = ifn_341.Invoke_O__O(arg_342) } else { arg_336 = linked_340.(*A_arbace_box_build_sha256_hex_A).Invoke_O_O__O(root_339, arg_342) }; var arg_337 any = A_arbace_box_build_A_const_57; var arg_338 any = A_arbace_box_build_A_const_58; if linked_334 == nil { tmp2 = ifn_335.Invoke_O_O_O__O(arg_336, arg_337, arg_338) } else { tmp2 = linked_334.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_333, arg_336, arg_337, arg_338) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref()
}
func A_arbace_box_build_action_STAR__A_New() *A_arbace_box_build_action_STAR__A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_action_STAR__A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_box_build_action_STAR__A) Ctor() {}
//line :106:1
func (t *A_arbace_box_build_action_STAR__A) Invoke_O_O_O__O(self, what__0, req__1 any) any { var cref__3 any; var root_353 any = A_arbace_box_build_A_const_59.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, A_arbace_box_build_cache_ref_A_fn_class); var ifn_355 lang.IFn; if

	linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = req__1; if linked_354 == nil { cref__3 = ifn_355.Invoke_O__O(arg_356) } else { cref__3 = linked_354.(*A_arbace_box_build_cache_ref_A).Invoke_O_O__O(root_353, arg_356) }; var cached__4 any; var tmp1 lang.IFn = A_arbace_box_build_A_const_60; if
	jrt.J2g_Truth(tmp1.Invoke_O_O__O(A_arbace_box_build_A_const_49.Get__O(), jrt.Boolean_TRUE.Ref())) { var temp__1927000414__auto____4 any; var root_357 any = A_arbace_box_build_A_const_61.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, aot_arbace_box.A_arbace_box_ref_A_fn_class); var ifn_359 lang.IFn
		if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = cref__3; if linked_358 == nil { temp__1927000414__auto____4 = ifn_359.Invoke_O__O(arg_360) } else { temp__1927000414__auto____4 = linked_358.(*aot_arbace_box.A_arbace_box_ref_A).Invoke_O_O__O(root_357, arg_360) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var h__5 any = temp__1927000414__auto____4; var tmp2 any; var root_361 any = A_arbace_box_build_A_const_62.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, aot_arbace_box.A_arbace_box_size_A_fn_class); var ifn_363 lang.IFn
			if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = h__5; if linked_362 == nil { tmp2 = ifn_363.Invoke_O__O(arg_364) } else { tmp2 = linked_362.(*aot_arbace_box.A_arbace_box_size_A).Invoke_O_O__O(root_361, arg_364) }; if jrt.J2g_Truth(tmp2) { var root_365 any = A_arbace_box_build_A_const_63.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_box.A_arbace_box_result_A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = h__5; if linked_366 == nil { cached__4 = ifn_367.Invoke_O__O(arg_368) } else { cached__4 = linked_366.(*aot_arbace_box.A_arbace_box_result_A).Invoke_O_O__O(root_365, arg_368) } } else { cached__4 = nil } } else {
//line :110:1
				cached__4 = nil } } else {
//line :109:1
					cached__4 = nil }; var t0__5 int64 = /*line :106:1*/jrt.System_NanoTime__J(); var res__6 any; var or__1927000174__auto____6 any = cached__4; if






	jrt.J2g_Truth(or__1927000174__auto____6) { res__6 = or__1927000174__auto____6 } else { var tmp3 lang.IFn = A_arbace_box_build_A_const_64; res__6 = lang.IFn_Cast(tmp3.Invoke_O_O__O(A_arbace_box_build_A_const_49.Get__O(), A_arbace_box_build_A_const_65.GetRawRoot__O())).Invoke_O__O(req__1) }; if
	lang.Util_Equiv_J_O__Z_NoInit(0, A_arbace_box_build_A_const_66.Invoke_O__O(res__6)) { } else {
		var root_369 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, A_arbace_box_build_fail_A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil, Lit_2, nil, Lit_3, nil); var tmp5 *jrt.String; if jrt.J2g_Truth(A_arbace_box_build_A_const_68.Invoke_O__O(res__6)) { tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_4, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_68.Invoke_O__O(res__6))) } else { tmp5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_66.Invoke_O__O(res__6))) }; var tmp6 any = tmp5.Ref(); var tmp7 any; var root_374 any = A_arbace_box_build_A_const_69.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_box.A_arbace_box_get_A_fn_class); var ifn_376 lang.IFn
		if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = A_arbace_box_build_A_const_70.Invoke_O__O(res__6); if linked_375 == nil { tmp7 = ifn_376.Invoke_O__O(arg_377) } else { tmp7 = linked_375.(*aot_arbace_box.A_arbace_box_get_A).Invoke_O_O__O(root_374, arg_377) }
//line :115:1
		arg_372 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, what__0, nil, tmp6, nil, tmp7)).Ref(); var arg_373 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_71, what__0, A_arbace_box_build_A_const_72, res__6)); if linked_370 == nil { ifn_371.Invoke_O_O__O(arg_372, arg_373) } else { linked_370.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_369, arg_372, arg_373) } }; var tmp8 any; var and__1927000168__auto____7 any; var root_378 any =


	A_arbace_box_build_A_const_73.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = cached__4; if linked_379 == nil { and__1927000168__auto____7 = ifn_380.Invoke_O__O(arg_381) } else { and__1927000168__auto____7 = linked_379.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_378, arg_381) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp9 lang.IFn = A_arbace_box_build_A_const_60; tmp8 = tmp9.Invoke_O_O__O(A_arbace_box_build_A_const_49.Get__O(), jrt.Boolean_TRUE.Ref()) } else { tmp8 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp8) {
		var root_382 any = A_arbace_box_build_A_const_74.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_box.A_arbace_box_ref_BANG__A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = cref__3; var arg_386 any = A_arbace_box_build_A_const_75.Invoke_O__O(res__6); if linked_383 == nil { ifn_384.Invoke_O_O__O(arg_385, arg_386) } else { linked_383.(*aot_arbace_box.A_arbace_box_ref_BANG__A).Invoke_O_O_O__O(root_382, arg_385, arg_386) } }; var tmp10 lang.IFn =
	lang.IFn_Cast(A_arbace_box_build_A_const_76.GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_77.GetRawRoot__O()); var tmp12 any; var root_398 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = A_arbace_box_build_A_const_78.Invoke_O__O(req__1); if linked_399 == nil { tmp12 = ifn_400.Invoke_O__O(arg_401) } else { tmp12 = linked_399.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_398, arg_401) }; var tmp13 any = tmp12; var tmp14 any; if
	jrt.J2g_Truth(cached__4) { tmp14 = Lit_7 } else { tmp14 = lang.IFn_Cast(A_arbace_box_build_A_const_77.GetRawRoot__O()).Invoke_O_O__O(Lit_8, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__5), 1.0e9)).Ref()) }; /*line :120:1*/tmp10.Invoke_O__O(tmp11.Invoke_O_O_O_O__O(Lit_6, tmp13, what__0, tmp14)); return res__6 }



func A_arbace_box_build_action_A_New() *A_arbace_box_build_action_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_action_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_box_build_action_A) Ctor() {}
//line :124:1
func (t *A_arbace_box_build_action_A) Invoke_O_O_O_O__O(self, what__0, req__1, opts__2 any) any {




	var root_415 any = A_arbace_box_build_A_const_81.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, opts__2); if linked_416 == nil { ifn_417.Invoke_O__O(arg_418) } else { linked_416.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_415, arg_418) }
//line :124:1
	var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




		{ var root_407 any = A_arbace_box_build_A_const_79.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, A_arbace_box_build_action_STAR__A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = what__0; var arg_411 any = req__1; if linked_408 == nil { tmp1 = ifn_409.Invoke_O_O__O(arg_410, arg_411) } else { tmp1 = linked_408.(*A_arbace_box_build_action_STAR__A).Invoke_O_O_O__O(root_407, arg_410, arg_411) } }
//line :124:1
		return nil }(); var root_412 any = A_arbace_box_build_A_const_80.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_414 lang.IFn




	if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; if linked_413 == nil { ifn_414.Invoke__O() } else { linked_413.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_412) }
//line :124:1
	if tmp2 != nil { panic(tmp2) }; return tmp1 }
//line :124:1
func (t *A_arbace_box_build_action_A) Invoke_O_O_O__O(self, what__0, req__1 any) any {



	var root_424 any = A_arbace_box_build_A_const_79.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, A_arbace_box_build_action_STAR__A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = what__0; var arg_428 any = req__1; if linked_425 == nil { return ifn_426.Invoke_O_O__O(arg_427, arg_428) } else { return linked_425.(*A_arbace_box_build_action_STAR__A).Invoke_O_O_O__O(root_424, arg_427, arg_428)
	}
}
func A_arbace_box_build_out_file_A_New() *A_arbace_box_build_out_file_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_out_file_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_box_build_out_file_A) Ctor() {}
//line :131:1
func (t *A_arbace_box_build_out_file_A) Invoke_O_O_O_O__O(self, res__0, what__1, name__2 any) any { var or__1927000174__auto____4 any; var root_429 any = A_arbace_box_build_A_const_83.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_box.A_arbace_box_tree_get_A_fn_class); var ifn_431 lang.IFn; if


	linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = A_arbace_box_build_A_const_84.Invoke_O__O(res__0); var arg_433 any = name__2; if linked_430 == nil { or__1927000174__auto____4 = ifn_431.Invoke_O_O__O(arg_432, arg_433) } else { or__1927000174__auto____4 = linked_430.(*aot_arbace_box.A_arbace_box_tree_get_A).Invoke_O_O_O__O(root_429, arg_432, arg_433) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {
		var root_434 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, A_arbace_box_build_fail_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_1, nil, Lit_137, nil, Lit_138), jrt.RefArrayOf(jrt.Object_class, nil, what__1, nil, name__2, nil)).Ref(); var arg_438 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_72, res__0)); if linked_435 == nil { return ifn_436.Invoke_O_O__O(arg_437, arg_438) } else { return linked_435.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_434, arg_437, arg_438) } } }

func A_arbace_box_build_file_tree_A_New() *A_arbace_box_build_file_tree_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_file_tree_A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_box_build_file_tree_A) Ctor() {}
//line :137:1
func (t *A_arbace_box_build_file_tree_A) Invoke_O_O__O(self, m__0 any) any {


	var root_439 any = A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any; var root_443 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_447 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_box_build_file_tree_iter__598000054__598000058_A_New(); var tmp2 *jrt.Class; var fncls__514 *jrt.Class = A_arbace_box_build_file_tree_iter__598000054__598000058_A_fn_class; if fncls__514 == nil { var fncls__514d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_box_build_file_tree_iter__598000054__598000058_A_fn_class = fncls__514d; tmp2 = fncls__514d } else { tmp2 = fncls__514 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_447 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(m__0); if linked_444 == nil { arg_442 = ifn_445.Invoke_O_O__O(arg_446, arg_447) } else { arg_442 = linked_444.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_443, arg_446, arg_447) }; if linked_440 == nil { return ifn_441.Invoke_O__O(arg_442) } else { return linked_440.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_439, arg_442) } }
//line :140:1
func A_arbace_box_build_file_tree_iter__598000054__598000058_A_New() *A_arbace_box_build_file_tree_iter__598000054__598000058_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_file_tree_iter__598000054__598000058_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_A) Ctor() {}
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_A) Invoke_O_O__O(self, s__598000055__1 any) any { var tmp1 any = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_New_O_O(s__598000055__1, self); var tmp2 *jrt.Class; var fncls__513 *jrt.Class = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_fn_class; if fncls__513 == nil { var fncls__513d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_fn_class = fncls__513d; tmp2 = fncls__513d } else { tmp2 = fncls__513 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :140:1
func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_New_O_O(p0, p1 any) *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A) Ctor_O_O(c__s__598000055, c__iter__598000054 any) { t.F_s__598000055 = c__s__598000055; t.F_iter__598000054 = c__iter__598000054 }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A) Invoke_O__O(self any) any { { var s__598000055__1 any; var t_ any = t.F_s__598000055; t.F_s__598000055 = nil; s__598000055__1 = t_; for { var temp__1927000414__auto____2 any; var root_448 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any = s__598000055__1; if linked_449 == nil { temp__1927000414__auto____2 = ifn_450.Invoke_O__O(arg_451) } else { temp__1927000414__auto____2 = linked_449.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_448, arg_451) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000055__3 any = temp__1927000414__auto____2; var tmp1 any; var root_452 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = s__598000055__3; if linked_453 == nil { tmp1 = ifn_454.Invoke_O__O(arg_455) } else { tmp1 = linked_453.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_452, arg_455) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_456 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any = s__598000055__3; if linked_457 == nil { c__1927001037__auto____4 = ifn_458.Invoke_O__O(arg_459) } else { c__1927001037__auto____4 = linked_457.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_456, arg_459) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000057__6 any; var root_460 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_461 == nil { b__598000057__6 = ifn_462.Invoke_O__O(arg_463) } else { b__598000057__6 = linked_461.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_460, arg_463) }; var tmp2 any = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_New_O_I_O(b__598000057__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__473 *jrt.Class = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_fn_class; if fncls__473 == nil { var fncls__473d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_fn_class = fncls__473d; tmp3 = fncls__473d } else { tmp3 = fncls__473 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_474 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any; var root_479 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = b__598000057__6; if linked_480 == nil { arg_477 = ifn_481.Invoke_O__O(arg_482) } else { arg_477 = linked_480.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_479, arg_482) }; var arg_478 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000054); var tmp5 any; var root_483 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = s__598000055__3; if linked_484 == nil { tmp5 = ifn_485.Invoke_O__O(arg_486) } else { tmp5 = linked_484.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_483, arg_486) }; arg_478 = tmp4.Invoke_O__O(tmp5); if linked_475 == nil { return ifn_476.Invoke_O_O__O(arg_477, arg_478) } else { return linked_475.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_474, arg_477, arg_478) } } else { var root_487 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any; var root_492 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = b__598000057__6; if linked_493 == nil { arg_490 = ifn_494.Invoke_O__O(arg_495) } else { arg_490 = linked_493.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_492, arg_495) }; var arg_491 any; if linked_488 == nil { return ifn_489.Invoke_O_O__O(arg_490, arg_491) } else { return linked_488.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_487, arg_490, arg_491) } } } else { var vec__598000065__4 any; var root_496 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = s__598000055__3; if linked_497 == nil { vec__598000065__4 = ifn_498.Invoke_O__O(arg_499) } else { vec__598000065__4 = linked_497.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_496, arg_499) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000065__4, lang.RT_IntCast_J__I_NoInit(0), nil); var x__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000065__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_500 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any; var tmp6 any; var root_505 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_505, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_507 lang.IFn; if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any = x__6; if linked_506 == nil { tmp6 = ifn_507.Invoke_O__O(arg_508) } else { tmp6 = linked_506.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_505, arg_508) }; arg_503 = lang.Tuple_Create_O_O__IPersistentVector(n__5, tmp6); var arg_504 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__598000054); var tmp8 any; var root_509 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_511 lang.IFn; if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any = s__598000055__3; if linked_510 == nil { tmp8 = ifn_511.Invoke_O__O(arg_512) } else { tmp8 = linked_510.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_509, arg_512) }; arg_504 = tmp7.Invoke_O__O(tmp8); if linked_501 == nil { return ifn_502.Invoke_O_O__O(arg_503, arg_504) } else { return linked_501.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_500, arg_503, arg_504) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :140:1
func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A) Ctor_O_I_O(c__b__598000057 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000057 = c__b__598000057; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A) Invoke_O__O(self any) any { { var i__598000056__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000056__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000061__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000056__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000061__2, lang.RT_IntCast_J__I_NoInit(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000061__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_464 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = t.F_b__598000057; var arg_468 any; var tmp2 any; var root_469 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = x__4; if linked_470 == nil { tmp2 = ifn_471.Invoke_O__O(arg_472) } else { tmp2 = linked_470.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_469, arg_472) }; arg_468 = lang.Tuple_Create_O_O__IPersistentVector(n__3, tmp2); if linked_465 == nil { ifn_466.Invoke_O_O__O(arg_467, arg_468) } else { linked_465.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_464, arg_467, arg_468) }; i__598000056__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000056__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_box_build_arch_defines_A_New() *A_arbace_box_build_arch_defines_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_arch_defines_A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_box_build_arch_defines_A) Ctor() {}
//line :142:1
func (t *A_arbace_box_build_arch_defines_A) Invoke_O_O__O(self, plan__0 any) any { var a__2 any = A_arbace_box_build_A_const_85.Invoke_O__O(plan__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_86.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(Lit_13, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_14, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_87.Invoke_O__O(plan__0))).Ref(), Lit_13, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, a__2)).Ref()); var tmp3 any = A_arbace_box_build_A_const_88; var tmp4 lang.IPersistentVector; var G__598000071__3_ any = a__2; L1:



switch { default: switch lang.Util_Hash_O__I_NoInit(G__598000071__3_) { case 92926582: if lang.Util_Equiv_O_O__Z_NoInit(G__598000071__3_, Lit_16) { tmp4 = lang.Tuple_Create_O_O__IPersistentVector(Lit_13, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_89.Invoke_O__O(plan__0))).Ref()); break L1 }; default:}; tmp4 = Up_PersistentVector_IPersistentVector(lang.PersistentVector_EMPTY)}; return /*line :144:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }





func A_arbace_box_build_asm_args_A_New() *A_arbace_box_build_asm_args_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_asm_args_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_box_build_asm_args_A) Ctor() {}
//line :150:1
func (t *A_arbace_box_build_asm_args_A) DoInvoke_O_O_O_O_O__O(self, plan__0, pkg__1, out__2, more__3 any) any {
	var root_522 any = A_arbace_box_build_A_const_90.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_86.GetRawRoot__O()); var tmp2 any = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_33, Lit_34, A_arbace_box_build_A_const_91.Invoke_O__O(pkg__1), Lit_35, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_36, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_91.Invoke_O__O(pkg__1), nil)).Ref(), Lit_38, Lit_39, Lit_38, Lit_40)); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_92.GetRawRoot__O()); var tmp4 any = A_arbace_box_build_asm_args_fn__598000074_A_New_O(pkg__1); var tmp5 *jrt.Class
	var fncls__538 /*line :151:1*/*jrt.Class = A_arbace_box_build_asm_args_fn__598000074_A_fn_class

	if fncls__538 == nil { var fncls__538d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_box_build_asm_args_fn__598000074_A_fn_class = fncls__538d; tmp5 = fncls__538d } else { tmp5 = fncls__538 }
//line :151:1
	var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 any; var root_539 any = A_arbace_box_build_A_const_95.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, A_arbace_box_build_arch_defines_A_fn_class); var ifn_541 lang.IFn

	if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = plan__0; if linked_540 == nil { tmp7 = ifn_541.Invoke_O__O(arg_542) } else { tmp7 = linked_540.(*A_arbace_box_build_arch_defines_A).Invoke_O_O__O(root_539, arg_542) }
//line :151:1
	arg_525 = tmp1.Invoke_O_O_O_O__O(tmp2, tmp3.Invoke_O_O__O(tmp6, tmp7), more__3, lang.Tuple_Create_O_O__IPersistentVector(Lit_42, out__2)); if linked_523 == nil { return ifn_524.Invoke_O__O(arg_525) } else { return linked_523.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_522, arg_525)
	} }
func A_arbace_box_build_asm_args_fn__598000074_A_New_O(p0 any) *A_arbace_box_build_asm_args_fn__598000074_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_asm_args_fn__598000074_A{}; t.Ctor_O(p0); return t }
//line :153:1
func (t *A_arbace_box_build_asm_args_fn__598000074_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :153:1
func (t *A_arbace_box_build_asm_args_fn__598000074_A) Invoke_O_O__O(self, p1__598000073_SHARP___1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(p1__598000073_SHARP___1, A_arbace_box_build_A_const_93) { if jrt.J2g_Truth(A_arbace_box_build_A_const_93.Invoke_O__O(t.F_pkg)) { return A_arbace_box_build_A_const_94 } else { return nil } } else { return lang.Tuple_Create_O__IPersistentVector(p1__598000073_SHARP___1) } }




func A_arbace_box_build_ar_member_A_New() *A_arbace_box_build_ar_member_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_ar_member_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_box_build_ar_member_A) Ctor() {}
//line :158:1
func (t *A_arbace_box_build_ar_member_A) Invoke_O_O_O__O(self, name__0, data__1 any) any { var pad__3 any; var tmp1 any = A_arbace_box_build_ar_member_pad__598000077_A_New(); var tmp2 *jrt.Class; var fncls__572 *jrt.Class = A_arbace_box_build_ar_member_pad__598000077_A_fn_class; if
												fncls__572 == nil { var fncls__572d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_box_build_ar_member_pad__598000077_A_fn_class = fncls__572d; tmp2 = fncls__572d } else { tmp2 = fncls__572 }; pad__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var hdr__4 any; var tmp3 /*line :158:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil, nil, nil, nil, Lit_10); var tmp4 lang.IFn = lang.IFn_Cast(pad__3); var tmp5 any; var root_573 any = A_arbace_box_build_A_const_52.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_575 lang.IFn; if

	linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = name__0; var arg_577 any = A_arbace_box_build_A_const_57; var arg_578 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Min_J_J__J_NoInit(16, int64(lang.RT_Count_O__I_NoInit(name__0)))).Ref(); if linked_574 == nil { tmp5 = ifn_575.Invoke_O_O_O__O(arg_576, arg_577, arg_578) } else { tmp5 = linked_574.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_573, arg_576, arg_577, arg_578) }; var tmp6 any = tmp4.Invoke_O_O__O(tmp5, A_arbace_box_build_A_const_98); var tmp7 any = lang.IFn_Cast(pad__3).Invoke_O_O__O(Lit_11, A_arbace_box_build_A_const_99); var tmp8 any = lang.IFn_Cast(pad__3).Invoke_O_O__O(Lit_11, A_arbace_box_build_A_const_100); var tmp9 any = lang.IFn_Cast(pad__3).Invoke_O_O__O(Lit_11, A_arbace_box_build_A_const_100); var tmp10 any = lang.IFn_Cast(pad__3).Invoke_O_O__O(Lit_12, A_arbace_box_build_A_const_101); var tmp11 lang.IFn = lang.IFn_Cast(pad__3); var tmp12 any; var root_579 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](data__1, jrt.Prim_byte.ArrayClass()))).Ref(); if linked_580 == nil { tmp12 = ifn_581.Invoke_O__O(arg_582) } else { tmp12 = linked_580.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_579, arg_582) }; hdr__4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11.Invoke_O_O__O(tmp12, A_arbace_box_build_A_const_102), nil)).Ref(); var o__5 any = /*line :158:1*/jrt.ByteArrayOutputStream_New();



	jrt.OutputStream_Cast(o__5).Write_B1__V(jrt.NN(jrt.String_Cast(hdr__4)).GetBytes_Charset__B1(jrt.StandardCharsets_US_ASCII));
	jrt.OutputStream_Cast(o__5).Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](data__1, jrt.Prim_byte.ArrayClass())); var tmp13 any; var root_583 any =
	A_arbace_box_build_A_const_103.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_odd_QMARK__A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](data__1, jrt.Prim_byte.ArrayClass()))).Ref(); if linked_584 == nil { tmp13 = ifn_585.Invoke_O__O(arg_586) } else { tmp13 = linked_584.(*aot_arbace_core.A_arbace_core_odd_QMARK__A).Invoke_O_O__O(root_583, arg_586) }; if jrt.J2g_Truth(tmp13) { jrt.NN(jrt.ByteArrayOutputStream_Cast(o__5)).Write_I__V(lang.RT_IntCast_J__I_NoInit(10)) }; return /*line :165:1*/ jrt.NN(jrt.ByteArrayOutputStream_Cast(o__5)).ToByteArray__B1().Ref() }
//line :159:1
func A_arbace_box_build_ar_member_pad__598000077_A_New() *A_arbace_box_build_ar_member_pad__598000077_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_ar_member_pad__598000077_A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_box_build_ar_member_pad__598000077_A) Ctor() {}
//line :159:1
func (t *A_arbace_box_build_ar_member_pad__598000077_A) Invoke_O_O_O__O(self, s__1, n__2 any) any { if jrt.Long_InstanceOf(n__2) { return t.InvokeSpec_O_O_J_O__O(self, s__1, jrt.NN(jrt.Long_Cast(n__2)).LongValue__J(), n__2) } else { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_543 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_547 any; var root_548 any = A_arbace_box_build_A_const_96.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any; var na_553 any = n__2; var na_554 int64 = int64(lang.RT_Count_O__I_NoInit(s__1)); if jrt.Long_InstanceOf(na_553) { var n0_555 int64 = jrt.NN(jrt.Long_Cast(na_553)).LongValue__J(); var n1_556 int64 = na_554; var nr_557 int64 = n0_555 - n1_556; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_556 == -9223372036854775808); if tmp4 { tmp4 = (n0_555^n1_556)&(n0_555^nr_557) >= 0 }; tmp3 = tmp4; if tmp3 { arg_551 = jrt.Long_ValueOf_J__Long_NoInit(nr_557).Ref() } else { arg_551 = lang.Numbers_Minus_O_J__Number_NoInit(na_553, na_554) } } else { arg_551 = lang.Numbers_Minus_O_J__Number_NoInit(na_553, na_554) }; var arg_552 any = A_arbace_box_build_A_const_97; if linked_549 == nil { arg_547 = ifn_550.Invoke_O_O__O(arg_551, arg_552) } else { arg_547 = linked_549.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_548, arg_551, arg_552) }; if linked_544 == nil { tmp2 = ifn_545.Invoke_O_O__O(arg_546, arg_547) } else { tmp2 = linked_544.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_543, arg_546, arg_547) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, s__1, tmp2)).Ref() } }
//line :159:1
func (t *A_arbace_box_build_ar_member_pad__598000077_A) InvokeSpec_O_O_J_O__O(self, s__1 any, n__2_l int64, n__2_b any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_558 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_560 lang.IFn; if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_562 any; var root_563 any = A_arbace_box_build_A_const_96.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any; var na_568 int64 = int64(lang.RT_Count_O__I_NoInit(s__1)); var n0_569 int64 = n__2_l; var n1_570 int64 = na_568; var nr_571 int64 = n0_569 - n1_570; var tmp3 bool; var tmp4 bool; tmp4 = !(n1_570 == -9223372036854775808); if tmp4 { tmp4 = (n0_569^n1_570)&(n0_569^nr_571) >= 0 }; tmp3 = tmp4; if tmp3 { arg_566 = jrt.Long_ValueOf_J__Long_NoInit(nr_571).Ref() } else { var tmp5 any; if n__2_b == nil { n__2_b = jrt.Long_ValueOf_J__Long_NoInit(n__2_l).Ref(); tmp5 = n__2_b } else { tmp5 = n__2_b }; arg_566 = lang.Numbers_Minus_O_J__Number_NoInit(tmp5, na_568) }; var arg_567 any = A_arbace_box_build_A_const_97; if linked_564 == nil { arg_562 = ifn_565.Invoke_O_O__O(arg_566, arg_567) } else { arg_562 = linked_564.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_563, arg_566, arg_567) }; if linked_559 == nil { tmp2 = ifn_560.Invoke_O_O__O(arg_561, arg_562) } else { tmp2 = linked_559.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_558, arg_561, arg_562) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, s__1, tmp2)).Ref() }







func A_arbace_box_build_append_members_A_New() *A_arbace_box_build_append_members_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_append_members_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_box_build_append_members_A) Ctor() {}
//line :167:1
func (t *A_arbace_box_build_append_members_A) Invoke_O_O_O__O(self, archive__0, members__1 any) any { var o__3 any = jrt.ByteArrayOutputStream_New();

	jrt.OutputStream_Cast(o__3).Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](archive__0, jrt.Prim_byte.ArrayClass())); var seq_598000080__4 any; var root_587 any = /*line :167:1*/A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_589 lang.IFn; if


	linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = members__1; if linked_588 == nil { seq_598000080__4 = ifn_589.Invoke_O__O(arg_590) } else { seq_598000080__4 = linked_588.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_587, arg_590) }; var chunk_598000081__5 any; var count_598000082__6 int64 = 0; var i_598000083__7 int64 = 0; L1:
//line :167:1
	for {


		if lang.Numbers_Lt_J_J__Z_NoInit(i_598000083__7, count_598000082__6) { var vec__598000084__8 any = lang.Indexed_Cast(chunk_598000081__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_598000083__7)); var n__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000084__8, lang.RT_IntCast_J__I_NoInit(0), nil); var data__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000084__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 jrt.OutputStream_I = jrt.OutputStream_Cast(o__3); var tmp2 any; var root_607 any = A_arbace_box_build_A_const_104.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, A_arbace_box_build_ar_member_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = n__9; var arg_611 any = data__10; if linked_608 == nil { tmp2 = ifn_609.Invoke_O_O__O(arg_610, arg_611) } else { tmp2 = linked_608.(*A_arbace_box_build_ar_member_A).Invoke_O_O_O__O(root_607, arg_610, arg_611) }; tmp1.Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](tmp2, jrt.Prim_byte.ArrayClass())); seq_598000080__4, chunk_598000081__5, count_598000082__6, i_598000083__7 = seq_598000080__4, chunk_598000081__5, count_598000082__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_598000083__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_591 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_593 lang.IFn; if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = seq_598000080__4; if linked_592 == nil { temp__1927000414__auto____8 = ifn_593.Invoke_O__O(arg_594) } else { temp__1927000414__auto____8 = linked_592.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_591, arg_594) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_598000080__9 any = temp__1927000414__auto____8; var tmp3 any; var root_595 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = seq_598000080__9; if linked_596 == nil { tmp3 = ifn_597.Invoke_O__O(arg_598) } else { tmp3 = linked_596.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_595, arg_598) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____10 any; var root_599 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_599, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_601 lang.IFn; if linked_600 == nil { ifn_601 = lang.IFn_Cast(root_599) } else { ifn_601 = nil }; var arg_602 any = seq_598000080__9; if linked_600 == nil { c__1927000678__auto____10 = ifn_601.Invoke_O__O(arg_602) } else { c__1927000678__auto____10 = linked_600.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_599, arg_602) }; var tmp4 any; var root_612 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = seq_598000080__9; if linked_613 == nil { tmp4 = ifn_614.Invoke_O__O(arg_615) } else { tmp4 = linked_613.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_612, arg_615) }; seq_598000080__4, chunk_598000081__5, count_598000082__6, i_598000083__7 = tmp4, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__598000087__10 any; var root_603 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = seq_598000080__9; if linked_604 == nil { vec__598000087__10 = ifn_605.Invoke_O__O(arg_606) } else { vec__598000087__10 = linked_604.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_603, arg_606) }; var n__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000087__10, lang.RT_IntCast_J__I_NoInit(0), nil); var data__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000087__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 jrt.OutputStream_I = jrt.OutputStream_Cast(o__3); var tmp6 any; var root_616 any = A_arbace_box_build_A_const_104.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, A_arbace_box_build_ar_member_A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any = n__11; var arg_620 any = data__12; if linked_617 == nil { tmp6 = ifn_618.Invoke_O_O__O(arg_619, arg_620) } else { tmp6 = linked_617.(*A_arbace_box_build_ar_member_A).Invoke_O_O_O__O(root_616, arg_619, arg_620) }; tmp5.Write_B1__V(jrt.J2g_CastArray[*jrt.ByteArray](tmp6, jrt.Prim_byte.ArrayClass())); var tmp7 any; var root_621 any = A_arbace_box_build_A_const_20.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = seq_598000080__9; if linked_622 == nil { tmp7 = ifn_623.Invoke_O__O(arg_624) } else { tmp7 = linked_622.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_621, arg_624) }; seq_598000080__4, chunk_598000081__5, count_598000082__6, i_598000083__7 = tmp7, nil, 0, 0; continue L1 } } }
//line :167:1
		break L1 }; return /*line :171:1*/ jrt.NN(jrt.ByteArrayOutputStream_Cast(o__3)).ToByteArray__B1().Ref() }






func A_arbace_box_build_complete_QMARK__A_New() *A_arbace_box_build_complete_QMARK__A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_complete_QMARK__A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_box_build_complete_QMARK__A) Ctor() {}
//line :178:1
func (t *A_arbace_box_build_complete_QMARK__A) Invoke_O_O__O(self, pkg__0 any) any { var and__1927000168__auto____2 any; var root_625 any = A_arbace_box_build_A_const_105.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_627 lang.IFn; if


	linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = A_arbace_box_build_A_const_106.Invoke_O__O(pkg__0); if linked_626 == nil { and__1927000168__auto____2 = ifn_627.Invoke_O__O(arg_628) } else { and__1927000168__auto____2 = linked_626.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_625, arg_628) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_629 any = A_arbace_box_build_A_const_73.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any; var and__1927000168__auto____3 any = A_arbace_box_build_A_const_93.Invoke_O__O(pkg__0); if jrt.J2g_Truth(and__1927000168__auto____3) { arg_632 = lang.IFn_Cast(A_arbace_box_build_A_const_107.GetRawRoot__O()).Invoke_O__O(A_arbace_box_build_A_const_91.Invoke_O__O(pkg__0)) } else { arg_632 = and__1927000168__auto____3 }; if linked_630 == nil { return ifn_631.Invoke_O__O(arg_632) } else { return linked_630.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_629, arg_632) } } else { return and__1927000168__auto____2 } }

func A_arbace_box_build_deps_tree_A_New() *A_arbace_box_build_deps_tree_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_box_build_deps_tree_A) Ctor() {}
//line :183:1
func (t *A_arbace_box_build_deps_tree_A) Invoke_O_O_O_O__O(self, archives__0, index__1, paths__2 any) any { var tmp1 any; var root_633 any = A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_635 lang.IFn; if



	linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any; var root_637 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_641 any; var iter__1927001039__auto____4 any; var tmp2 any = A_arbace_box_build_deps_tree_iter__598000092__598000096_A_New_O_O(archives__0, index__1); var tmp3 *jrt.Class; var fncls__700 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000092__598000096_A_fn_class; if fncls__700 == nil { var fncls__700d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_box_build_deps_tree_iter__598000092__598000096_A_fn_class = fncls__700d; tmp3 = fncls__700d } else { tmp3 = fncls__700 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); arg_641 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(paths__2); if linked_638 == nil { arg_636 = ifn_639.Invoke_O_O__O(arg_640, arg_641) } else { arg_636 = linked_638.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_637, arg_640, arg_641) }; if linked_634 == nil { tmp1 = ifn_635.Invoke_O__O(arg_636) } else { tmp1 = linked_634.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_633, arg_636) }; var tmp4 any = tmp1; var tmp5 any; var iter__1927001039__auto____4_2 any; var tmp6 any = /*line :183:1*/A_arbace_box_build_deps_tree_iter__598000102__598000106_A_New_O(index__1); var tmp7 *jrt.Class; var fncls__759 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000102__598000106_A_fn_class; if




	fncls__759 == nil { var fncls__759d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_box_build_deps_tree_iter__598000102__598000106_A_fn_class = fncls__759d; tmp7 = fncls__759d } else { tmp7 = fncls__759 }; iter__1927001039__auto____4_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); tmp5 = lang.IFn_Cast(iter__1927001039__auto____4_2).Invoke_O__O(paths__2); return /*line :183:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp4, tmp5) }



func A_arbace_box_build_deps_tree_iter__598000092__598000096_A_New_O_O(p0, p1 any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000092__598000096_A{}; t.Ctor_O_O(p0, p1); return t }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_A) Ctor_O_O(c__archives, c__index any) { t.F_archives = c__archives; t.F_index = c__index }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_A) Invoke_O_O__O(self, s__598000093__1 any) any { var tmp1 any = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_New_O_O_O_O(t.F_archives, t.F_index, self, s__598000093__1); var tmp2 *jrt.Class; var fncls__699 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_fn_class; if fncls__699 == nil { var fncls__699d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_fn_class = fncls__699d; tmp2 = fncls__699d } else { tmp2 = fncls__699 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :187:1
func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A) Ctor_O_O_O_O(c__archives, c__index, c__iter__598000092, c__s__598000093 any) { t.F_archives = c__archives; t.F_index = c__index; t.F_iter__598000092 = c__iter__598000092; t.F_s__598000093 = c__s__598000093 }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A) Invoke_O__O(self any) any { { var s__598000093__1 any; var t_ any = t.F_s__598000093; t.F_s__598000093 = nil; s__598000093__1 = t_; for { var temp__1927000414__auto____2 any; var root_642 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = s__598000093__1; if linked_643 == nil { temp__1927000414__auto____2 = ifn_644.Invoke_O__O(arg_645) } else { temp__1927000414__auto____2 = linked_643.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_642, arg_645) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000093__3 any = temp__1927000414__auto____2; var tmp1 any; var root_646 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = s__598000093__3; if linked_647 == nil { tmp1 = ifn_648.Invoke_O__O(arg_649) } else { tmp1 = linked_647.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_646, arg_649) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_650 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = s__598000093__3; if linked_651 == nil { c__1927001037__auto____4 = ifn_652.Invoke_O__O(arg_653) } else { c__1927001037__auto____4 = linked_651.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_650, arg_653) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000095__6 any; var root_654 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_656 lang.IFn; if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_655 == nil { b__598000095__6 = ifn_656.Invoke_O__O(arg_657) } else { b__598000095__6 = linked_655.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_654, arg_657) }; var tmp2 any = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_New_O_O_O_I_O(b__598000095__6, t.F_archives, t.F_index, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__663 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_fn_class; if fncls__663 == nil { var fncls__663d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_fn_class = fncls__663d; tmp3 = fncls__663d } else { tmp3 = fncls__663 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_664 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any; var root_669 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = b__598000095__6; if linked_670 == nil { arg_667 = ifn_671.Invoke_O__O(arg_672) } else { arg_667 = linked_670.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_669, arg_672) }; var arg_668 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000092); var tmp5 any; var root_673 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_673, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_675 lang.IFn; if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any = s__598000093__3; if linked_674 == nil { tmp5 = ifn_675.Invoke_O__O(arg_676) } else { tmp5 = linked_674.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_673, arg_676) }; arg_668 = tmp4.Invoke_O__O(tmp5); if linked_665 == nil { return ifn_666.Invoke_O_O__O(arg_667, arg_668) } else { return linked_665.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_664, arg_667, arg_668) } } else { var root_677 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any; var root_682 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = b__598000095__6; if linked_683 == nil { arg_680 = ifn_684.Invoke_O__O(arg_685) } else { arg_680 = linked_683.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_682, arg_685) }; var arg_681 any; if linked_678 == nil { return ifn_679.Invoke_O_O__O(arg_680, arg_681) } else { return linked_678.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_677, arg_680, arg_681) } } } else { var p__4 any; var root_686 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = s__598000093__3; if linked_687 == nil { p__4 = ifn_688.Invoke_O__O(arg_689) } else { p__4 = linked_687.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_686, arg_689) }; var a__5 any = lang.IFn_Cast(t.F_archives).Invoke_O__O(p__4); var root_690 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(t.F_index).Invoke_O__O(p__4), nil)).Ref(), a__5); var arg_694 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000092); var tmp7 any; var root_695 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = s__598000093__3; if linked_696 == nil { tmp7 = ifn_697.Invoke_O__O(arg_698) } else { tmp7 = linked_696.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_695, arg_698) }; arg_694 = tmp6.Invoke_O__O(tmp7); if linked_691 == nil { return ifn_692.Invoke_O_O__O(arg_693, arg_694) } else { return linked_691.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_690, arg_693, arg_694) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :187:1
func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A) Ctor_O_O_O_I_O(c__b__598000095, c__archives, c__index any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000095 = c__b__598000095; t.F_archives = c__archives; t.F_index = c__index; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A) Invoke_O__O(self any) any { { var i__598000094__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000094__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000094__1)); var a__3 any = lang.IFn_Cast(t.F_archives).Invoke_O__O(p__2); var root_658 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = t.F_b__598000095; var arg_662 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(t.F_index).Invoke_O__O(p__2), nil)).Ref(), a__3); if linked_659 == nil { ifn_660.Invoke_O_O__O(arg_661, arg_662) } else { linked_659.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_658, arg_661, arg_662) }; i__598000094__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000094__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_box_build_deps_tree_iter__598000102__598000106_A_New_O(p0 any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000102__598000106_A{}; t.Ctor_O(p0); return t }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_A) Ctor_O(c__index any) { t.F_index = c__index }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_A) Invoke_O_O__O(self, s__598000103__1 any) any { var tmp1 any = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_New_O_O_O(s__598000103__1, t.F_index, self); var tmp2 *jrt.Class; var fncls__758 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_fn_class; if fncls__758 == nil { var fncls__758d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_fn_class = fncls__758d; tmp2 = fncls__758d } else { tmp2 = fncls__758 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :188:1
func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A) Ctor_O_O_O(c__s__598000103, c__index, c__iter__598000102 any) { t.F_s__598000103 = c__s__598000103; t.F_index = c__index; t.F_iter__598000102 = c__iter__598000102 }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A) Invoke_O__O(self any) any { { var s__598000103__1 any; var t_ any = t.F_s__598000103; t.F_s__598000103 = nil; s__598000103__1 = t_; for { var temp__1927000414__auto____2 any; var root_701 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = s__598000103__1; if linked_702 == nil { temp__1927000414__auto____2 = ifn_703.Invoke_O__O(arg_704) } else { temp__1927000414__auto____2 = linked_702.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_701, arg_704) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000103__3 any = temp__1927000414__auto____2; var tmp1 any; var root_705 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = s__598000103__3; if linked_706 == nil { tmp1 = ifn_707.Invoke_O__O(arg_708) } else { tmp1 = linked_706.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_705, arg_708) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_709 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = s__598000103__3; if linked_710 == nil { c__1927001037__auto____4 = ifn_711.Invoke_O__O(arg_712) } else { c__1927001037__auto____4 = linked_710.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_709, arg_712) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000105__6 any; var root_713 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_715 lang.IFn; if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_714 == nil { b__598000105__6 = ifn_715.Invoke_O__O(arg_716) } else { b__598000105__6 = linked_714.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_713, arg_716) }; var tmp2 any = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_New_O_O_I_O(t.F_index, b__598000105__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__722 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_fn_class; if fncls__722 == nil { var fncls__722d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_fn_class = fncls__722d; tmp3 = fncls__722d } else { tmp3 = fncls__722 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_723 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any; var root_728 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = b__598000105__6; if linked_729 == nil { arg_726 = ifn_730.Invoke_O__O(arg_731) } else { arg_726 = linked_729.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_728, arg_731) }; var arg_727 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000102); var tmp5 any; var root_732 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = s__598000103__3; if linked_733 == nil { tmp5 = ifn_734.Invoke_O__O(arg_735) } else { tmp5 = linked_733.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_732, arg_735) }; arg_727 = tmp4.Invoke_O__O(tmp5); if linked_724 == nil { return ifn_725.Invoke_O_O__O(arg_726, arg_727) } else { return linked_724.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_723, arg_726, arg_727) } } else { var root_736 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_738 lang.IFn; if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any; var root_741 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = b__598000105__6; if linked_742 == nil { arg_739 = ifn_743.Invoke_O__O(arg_744) } else { arg_739 = linked_742.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_741, arg_744) }; var arg_740 any; if linked_737 == nil { return ifn_738.Invoke_O_O__O(arg_739, arg_740) } else { return linked_737.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_736, arg_739, arg_740) } } } else { var p__4 any; var root_745 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any = s__598000103__3; if linked_746 == nil { p__4 = ifn_747.Invoke_O__O(arg_748) } else { p__4 = linked_746.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_745, arg_748) }; var root_749 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_751 lang.IFn; if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_97, nil, Lit_98, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, nil, p__4, nil, lang.IFn_Cast(t.F_index).Invoke_O__O(p__4), nil)).Ref(); var arg_753 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000102); var tmp7 any; var root_754 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = s__598000103__3; if linked_755 == nil { tmp7 = ifn_756.Invoke_O__O(arg_757) } else { tmp7 = linked_755.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_754, arg_757) }; arg_753 = tmp6.Invoke_O__O(tmp7); if linked_750 == nil { return ifn_751.Invoke_O_O__O(arg_752, arg_753) } else { return linked_750.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_749, arg_752, arg_753) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :188:1
func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A) Ctor_O_O_I_O(c__index, c__b__598000105 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_index = c__index; t.F_b__598000105 = c__b__598000105; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A) Invoke_O__O(self any) any { { var i__598000104__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000104__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000104__1)); var root_717 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = t.F_b__598000105; var arg_721 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_97, nil, Lit_98, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, nil, p__2, nil, lang.IFn_Cast(t.F_index).Invoke_O__O(p__2), nil)).Ref(); if linked_718 == nil { ifn_719.Invoke_O_O__O(arg_720, arg_721) } else { linked_718.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_717, arg_720, arg_721) }; i__598000104__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000104__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_box_build_json_str_A_New() *A_arbace_box_build_json_str_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_json_str_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_box_build_json_str_A) Ctor() {}
//line :190:1
func (t *A_arbace_box_build_json_str_A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_123, nil, Lit_123); var tmp2 any; var root_760 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_764 any; var root_765 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any; var tmp3 any = A_arbace_box_build_json_str_fn__598000113_A_New(); var tmp4 *jrt.Class; var fncls__779 *jrt.Class = A_arbace_box_build_json_str_fn__598000113_A_fn_class; if fncls__779 == nil { var fncls__779d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_box_build_json_str_fn__598000113_A_fn_class = fncls__779d; tmp4 = fncls__779d } else { tmp4 = fncls__779 }; arg_768 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_769 any = s__0; if linked_766 == nil { arg_764 = ifn_767.Invoke_O_O__O(arg_768, arg_769) } else { arg_764 = linked_766.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_765, arg_768, arg_769) }; if linked_761 == nil { tmp2 = ifn_762.Invoke_O_O__O(arg_763, arg_764) } else { tmp2 = linked_761.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_760, arg_763, arg_764) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil)).Ref() }
//line :193:1
func A_arbace_box_build_json_str_fn__598000113_A_New() *A_arbace_box_build_json_str_fn__598000113_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_json_str_fn__598000113_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_box_build_json_str_fn__598000113_A) Ctor() {}
//line :193:1
func (t *A_arbace_box_build_json_str_fn__598000113_A) Invoke_O_O__O(self, c__1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(c__1, A_arbace_box_build_A_const_109) { return Lit_125 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__1, A_arbace_box_build_A_const_110) { return Lit_126 } else { if lang.Numbers_Lt_J_J__Z_NoInit(int64(lang.RT_IntCast_O__I_NoInit(c__1)), 32) {
											return lang.IFn_Cast(A_arbace_box_build_A_const_77.GetRawRoot__O()).Invoke_O_O__O(Lit_127, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(c__1)).Ref()) } else {
//line :193:1
		if A_arbace_box_build_A_const_111 != nil {

			var root_775 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any = c__1; if linked_776 == nil { return ifn_777.Invoke_O__O(arg_778) } else { return linked_776.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_775, arg_778) } } else {
//line :193:1
				return nil } } } } }





func A_arbace_box_build_embed_config_A_New() *A_arbace_box_build_embed_config_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_box_build_embed_config_A) Ctor() {}
//line :199:1
func (t *A_arbace_box_build_embed_config_A) Invoke_O_O__O(self, patterns__0 any) any { var files__2 any; var root_780 any = A_arbace_box_build_A_const_112.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_782 lang.IFn; if



	linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any; var root_784 any = A_arbace_box_build_A_const_113.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_784, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_786 lang.IFn; if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any = lang.IFn_Cast(A_arbace_box_build_A_const_92.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_114.GetRawRoot__O(), patterns__0); if linked_785 == nil { arg_783 = ifn_786.Invoke_O__O(arg_787) } else { arg_783 = linked_785.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_784, arg_787) }; if linked_781 == nil { files__2 = ifn_782.Invoke_O__O(arg_783) } else { files__2 = linked_781.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_780, arg_783) }; var tmp1 /*line :204:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_99, nil, Lit_100, nil, Lit_101); var tmp2 any; var root_793 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_793, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_795 lang.IFn; if
	linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_797 any; var root_798 any = A_arbace_box_build_A_const_115.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = Lit_102; var arg_802 any; var iter__1927001039__auto____8 any; var tmp3 any = A_arbace_box_build_embed_config_iter__598000116__598000120_A_New(); var tmp4 *jrt.Class; var fncls__899 *jrt.Class = A_arbace_box_build_embed_config_iter__598000116__598000120_A_fn_class; if fncls__899 == nil { var fncls__899d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_box_build_embed_config_iter__598000116__598000120_A_fn_class = fncls__899d; tmp4 = fncls__899d } else { tmp4 = fncls__899 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp6 any; var root_900 any = A_arbace_box_build_A_const_117.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any = A_arbace_box_build_A_const_118.GetRawRoot__O(); var arg_904 any = patterns__0; if linked_901 == nil { tmp6 = ifn_902.Invoke_O_O__O(arg_903, arg_904) } else { tmp6 = linked_901.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_900, arg_903, arg_904) }; arg_802 = tmp5.Invoke_O__O(tmp6); if linked_799 == nil { arg_797 = ifn_800.Invoke_O_O__O(arg_801, arg_802) } else { arg_797 = linked_799.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_798, arg_801, arg_802) }; if linked_794 == nil { tmp2 = ifn_795.Invoke_O_O__O(arg_796, arg_797) } else { tmp2 = linked_794.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_793, arg_796, arg_797) }; var tmp7 any = tmp2; var tmp8 any; var root_905 any = /*line :204:1*/A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_905, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_907 lang.IFn; if



	linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_909 any; var root_910 any = A_arbace_box_build_A_const_115.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_910, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_912 lang.IFn; if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any = Lit_102; var arg_914 any; var iter__1927001039__auto____8_2 any; var tmp9 any = A_arbace_box_build_embed_config_iter__598000132__598000136_A_New(); var tmp10 *jrt.Class; var fncls__989 *jrt.Class = A_arbace_box_build_embed_config_iter__598000132__598000136_A_fn_class; if fncls__989 == nil { var fncls__989d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_box_build_embed_config_iter__598000132__598000136_A_fn_class = fncls__989d; tmp10 = fncls__989d } else { tmp10 = fncls__989 }; iter__1927001039__auto____8_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); arg_914 = lang.IFn_Cast(iter__1927001039__auto____8_2).Invoke_O__O(files__2); if linked_911 == nil { arg_909 = ifn_912.Invoke_O_O__O(arg_913, arg_914) } else { arg_909 = linked_911.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_910, arg_913, arg_914) }; if linked_906 == nil { tmp8 = ifn_907.Invoke_O_O__O(arg_908, arg_909) } else { tmp8 = linked_906.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_905, arg_908, arg_909) }; return /*line :204:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, tmp8, nil)).Ref() }
func A_arbace_box_build_embed_config_iter__598000116__598000120_A_New() *A_arbace_box_build_embed_config_iter__598000116__598000120_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000116__598000120_A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_A) Ctor() {}
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_A) Invoke_O_O__O(self, s__598000117__1 any) any { var tmp1 any = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_New_O_O(self, s__598000117__1); var tmp2 *jrt.Class; var fncls__898 *jrt.Class = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_fn_class; if fncls__898 == nil { var fncls__898d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_fn_class = fncls__898d; tmp2 = fncls__898d } else { tmp2 = fncls__898 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :205:1
func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_New_O_O(p0, p1 any) *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A{}; t.Ctor_O_O(p0, p1); return t }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A) Ctor_O_O(c__iter__598000116, c__s__598000117 any) { t.F_iter__598000116 = c__iter__598000116; t.F_s__598000117 = c__s__598000117 }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A) Invoke_O__O(self any) any { { var s__598000117__1 any; var t_ any = t.F_s__598000117; t.F_s__598000117 = nil; s__598000117__1 = t_; for { var temp__1927000414__auto____2 any; var root_803 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = s__598000117__1; if linked_804 == nil { temp__1927000414__auto____2 = ifn_805.Invoke_O__O(arg_806) } else { temp__1927000414__auto____2 = linked_804.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_803, arg_806) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000117__3 any = temp__1927000414__auto____2; var tmp1 any; var root_807 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = s__598000117__3; if linked_808 == nil { tmp1 = ifn_809.Invoke_O__O(arg_810) } else { tmp1 = linked_808.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_807, arg_810) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_811 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_811, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_813 lang.IFn; if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any = s__598000117__3; if linked_812 == nil { c__1927001037__auto____4 = ifn_813.Invoke_O__O(arg_814) } else { c__1927001037__auto____4 = linked_812.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_811, arg_814) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000119__6 any; var root_815 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_817 lang.IFn; if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_816 == nil { b__598000119__6 = ifn_817.Invoke_O__O(arg_818) } else { b__598000119__6 = linked_816.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_815, arg_818) }; var tmp2 any = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_New_O_I_O(b__598000119__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__843 *jrt.Class = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_fn_class; if fncls__843 == nil { var fncls__843d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_fn_class = fncls__843d; tmp3 = fncls__843d } else { tmp3 = fncls__843 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_844 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any; var root_849 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_849, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_851 lang.IFn; if linked_850 == nil { ifn_851 = lang.IFn_Cast(root_849) } else { ifn_851 = nil }; var arg_852 any = b__598000119__6; if linked_850 == nil { arg_847 = ifn_851.Invoke_O__O(arg_852) } else { arg_847 = linked_850.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_849, arg_852) }; var arg_848 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000116); var tmp5 any; var root_853 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = s__598000117__3; if linked_854 == nil { tmp5 = ifn_855.Invoke_O__O(arg_856) } else { tmp5 = linked_854.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_853, arg_856) }; arg_848 = tmp4.Invoke_O__O(tmp5); if linked_845 == nil { return ifn_846.Invoke_O_O__O(arg_847, arg_848) } else { return linked_845.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_844, arg_847, arg_848) } } else { var root_857 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any; var root_862 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_862, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_864 lang.IFn; if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any = b__598000119__6; if linked_863 == nil { arg_860 = ifn_864.Invoke_O__O(arg_865) } else { arg_860 = linked_863.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_862, arg_865) }; var arg_861 any; if linked_858 == nil { return ifn_859.Invoke_O_O__O(arg_860, arg_861) } else { return linked_858.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_857, arg_860, arg_861) } } } else { var vec__598000127__4 any; var root_866 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = s__598000117__3; if linked_867 == nil { vec__598000127__4 = ifn_868.Invoke_O__O(arg_869) } else { vec__598000127__4 = linked_867.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_866, arg_869) }; var p__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000127__4, lang.RT_IntCast_J__I_NoInit(0), nil); var fs__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000127__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_870 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_107, nil, Lit_108); var tmp7 any; var root_875 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, A_arbace_box_build_json_str_A_fn_class); var ifn_877 lang.IFn
														if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = p__5; if linked_876 == nil { tmp7 = ifn_877.Invoke_O__O(arg_878) } else { tmp7 = linked_876.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_875, arg_878) }; var tmp8 any = tmp7; var tmp9 any; var root_879 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_879, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_881 lang.IFn; if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_883 any; var root_884 any = A_arbace_box_build_A_const_115.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = Lit_102; var arg_888 any; var root_889 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_889, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var arg_893 any = fs__6; if linked_890 == nil { arg_888 = ifn_891.Invoke_O_O__O(arg_892, arg_893) } else { arg_888 = linked_890.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_889, arg_892, arg_893) }; if linked_885 == nil { arg_883 = ifn_886.Invoke_O_O__O(arg_887, arg_888) } else { arg_883 = linked_885.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_884, arg_887, arg_888) }; if linked_880 == nil { tmp9 = ifn_881.Invoke_O_O__O(arg_882, arg_883) } else { tmp9 = linked_880.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_879, arg_882, arg_883) }; arg_873 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9, nil)).Ref()
//line :205:1
	var arg_874 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__598000116); var tmp11 any; var root_894 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = s__598000117__3; if linked_895 == nil { tmp11 = ifn_896.Invoke_O__O(arg_897) } else { tmp11 = linked_895.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_894, arg_897) }; arg_874 = tmp10.Invoke_O__O(tmp11); if linked_871 == nil { return ifn_872.Invoke_O_O__O(arg_873, arg_874) } else { return linked_871.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_870, arg_873, arg_874) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :205:1
func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A) Ctor_O_I_O(c__b__598000119 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000119 = c__b__598000119; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A) Invoke_O__O(self any) any { { var i__598000118__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000118__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000123__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000118__1)); var p__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000123__2, lang.RT_IntCast_J__I_NoInit(0), nil); var fs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000123__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_819 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_819, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_821 lang.IFn; if linked_820 == nil { ifn_821 = lang.IFn_Cast(root_819) } else { ifn_821 = nil }; var arg_822 any = t.F_b__598000119; var arg_823 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_107, nil, Lit_108); var tmp3 any; var root_824 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_824, A_arbace_box_build_json_str_A_fn_class); var ifn_826 lang.IFn
																if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = p__3; if linked_825 == nil { tmp3 = ifn_826.Invoke_O__O(arg_827) } else { tmp3 = linked_825.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_824, arg_827) }; var tmp4 any = tmp3; var tmp5 any; var root_828 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_828, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_832 any; var root_833 any = A_arbace_box_build_A_const_115.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_835 lang.IFn; if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = Lit_102; var arg_837 any; var root_838 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_838, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_840 lang.IFn; if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var arg_842 any = fs__4; if linked_839 == nil { arg_837 = ifn_840.Invoke_O_O__O(arg_841, arg_842) } else { arg_837 = linked_839.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_838, arg_841, arg_842) }; if linked_834 == nil { arg_832 = ifn_835.Invoke_O_O__O(arg_836, arg_837) } else { arg_832 = linked_834.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_833, arg_836, arg_837) }; if linked_829 == nil { tmp5 = ifn_830.Invoke_O_O__O(arg_831, arg_832) } else { tmp5 = linked_829.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_828, arg_831, arg_832) }; arg_823 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5, nil)).Ref()
//line :205:1
	if linked_820 == nil { ifn_821.Invoke_O_O__O(arg_822, arg_823) } else { linked_820.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_819, arg_822, arg_823) }; i__598000118__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000118__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_box_build_embed_config_iter__598000132__598000136_A_New() *A_arbace_box_build_embed_config_iter__598000132__598000136_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000132__598000136_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_A) Ctor() {}
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_A) Invoke_O_O__O(self, s__598000133__1 any) any { var tmp1 any = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_New_O_O(s__598000133__1, self); var tmp2 *jrt.Class; var fncls__988 *jrt.Class = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_fn_class; if fncls__988 == nil { var fncls__988d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_fn_class = fncls__988d; tmp2 = fncls__988d } else { tmp2 = fncls__988 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :208:1
func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_New_O_O(p0, p1 any) *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A{}; t.Ctor_O_O(p0, p1); return t }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A) Ctor_O_O(c__s__598000133, c__iter__598000132 any) { t.F_s__598000133 = c__s__598000133; t.F_iter__598000132 = c__iter__598000132 }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A) Invoke_O__O(self any) any { { var s__598000133__1 any; var t_ any = t.F_s__598000133; t.F_s__598000133 = nil; s__598000133__1 = t_; for { var temp__1927000414__auto____2 any; var root_915 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_917 lang.IFn; if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any = s__598000133__1; if linked_916 == nil { temp__1927000414__auto____2 = ifn_917.Invoke_O__O(arg_918) } else { temp__1927000414__auto____2 = linked_916.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_915, arg_918) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000133__3 any = temp__1927000414__auto____2; var tmp1 any; var root_919 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = s__598000133__3; if linked_920 == nil { tmp1 = ifn_921.Invoke_O__O(arg_922) } else { tmp1 = linked_920.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_919, arg_922) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_923 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = s__598000133__3; if linked_924 == nil { c__1927001037__auto____4 = ifn_925.Invoke_O__O(arg_926) } else { c__1927001037__auto____4 = linked_924.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_923, arg_926) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000135__6 any; var root_927 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_929 lang.IFn; if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_928 == nil { b__598000135__6 = ifn_929.Invoke_O__O(arg_930) } else { b__598000135__6 = linked_928.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_927, arg_930) }; var tmp2 any = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_New_O_I_O(b__598000135__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__944 *jrt.Class = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_fn_class; if fncls__944 == nil { var fncls__944d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_fn_class = fncls__944d; tmp3 = fncls__944d } else { tmp3 = fncls__944 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_945 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_945, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_947 lang.IFn; if linked_946 == nil { ifn_947 = lang.IFn_Cast(root_945) } else { ifn_947 = nil }; var arg_948 any; var root_950 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = b__598000135__6; if linked_951 == nil { arg_948 = ifn_952.Invoke_O__O(arg_953) } else { arg_948 = linked_951.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_950, arg_953) }; var arg_949 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000132); var tmp5 any; var root_954 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = s__598000133__3; if linked_955 == nil { tmp5 = ifn_956.Invoke_O__O(arg_957) } else { tmp5 = linked_955.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_954, arg_957) }; arg_949 = tmp4.Invoke_O__O(tmp5); if linked_946 == nil { return ifn_947.Invoke_O_O__O(arg_948, arg_949) } else { return linked_946.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_945, arg_948, arg_949) } } else { var root_958 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any; var root_963 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_965 lang.IFn; if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = b__598000135__6; if linked_964 == nil { arg_961 = ifn_965.Invoke_O__O(arg_966) } else { arg_961 = linked_964.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_963, arg_966) }; var arg_962 any; if linked_959 == nil { return ifn_960.Invoke_O_O__O(arg_961, arg_962) } else { return linked_959.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_958, arg_961, arg_962) } } } else { var f__4 any; var root_967 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = s__598000133__3; if linked_968 == nil { f__4 = ifn_969.Invoke_O__O(arg_970) } else { f__4 = linked_968.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_967, arg_970) }; var root_971 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_111, nil); var tmp7 any; var root_976 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, A_arbace_box_build_json_str_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = f__4; if linked_977 == nil { tmp7 = ifn_978.Invoke_O__O(arg_979) } else { tmp7 = linked_977.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_976, arg_979) }; var tmp8 any = tmp7; var tmp9 any; var root_980 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, A_arbace_box_build_json_str_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__4)).Ref(); if linked_981 == nil { tmp9 = ifn_982.Invoke_O__O(arg_983) } else { tmp9 = linked_981.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_980, arg_983) }; arg_974 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_975 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__598000132); var tmp11 any; var root_984 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = s__598000133__3; if linked_985 == nil { tmp11 = ifn_986.Invoke_O__O(arg_987) } else { tmp11 = linked_985.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_984, arg_987) }; arg_975 = tmp10.Invoke_O__O(tmp11); if linked_972 == nil { return ifn_973.Invoke_O_O__O(arg_974, arg_975) } else { return linked_972.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_971, arg_974, arg_975) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :208:1
func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A) Ctor_O_I_O(c__b__598000135 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000135 = c__b__598000135; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A) Invoke_O__O(self any) any { { var i__598000134__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000134__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000134__1)); var root_931 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_931, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_933 lang.IFn; if linked_932 == nil { ifn_933 = lang.IFn_Cast(root_931) } else { ifn_933 = nil }; var arg_934 any = t.F_b__598000135; var arg_935 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_111, nil); var tmp3 any; var root_936 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, A_arbace_box_build_json_str_A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = f__2; if linked_937 == nil { tmp3 = ifn_938.Invoke_O__O(arg_939) } else { tmp3 = linked_937.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_936, arg_939) }; var tmp4 any = tmp3; var tmp5 any; var root_940 any = A_arbace_box_build_A_const_116.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, A_arbace_box_build_json_str_A_fn_class); var ifn_942 lang.IFn; if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__2)).Ref(); if linked_941 == nil { tmp5 = ifn_942.Invoke_O__O(arg_943) } else { tmp5 = linked_941.(*A_arbace_box_build_json_str_A).Invoke_O_O__O(root_940, arg_943) }; arg_935 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref(); if linked_932 == nil { ifn_933.Invoke_O_O__O(arg_934, arg_935) } else { linked_932.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_931, arg_934, arg_935) }; i__598000134__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000134__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_box_build_build_package_A_New() *A_arbace_box_build_build_package_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_box_build_build_package_A) Ctor() {}
//line :211:1
func (t *A_arbace_box_build_build_package_A) Invoke_O_O_O_O_O__O(self, plan__0, pkg__1, archives__2, index__3 any) any { var map__598000145__5 any = A_arbace_box_build_A_const_49.Get__O(); var map__598000145__6 any; if


	lang.ISeq_InstanceOf(map__598000145__5) { var tmp1 any; var root_990 any = A_arbace_box_build_A_const_20.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any = map__598000145__5; if linked_991 == nil { tmp1 = ifn_992.Invoke_O__O(arg_993) } else { tmp1 = linked_991.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_990, arg_993) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_994 any = A_arbace_box_build_A_const_119.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = map__598000145__5; if linked_995 == nil { tmp2 = ifn_996.Invoke_O__O(arg_997) } else { tmp2 = linked_995.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_994, arg_997) }; map__598000145__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_998 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = map__598000145__5; if linked_999 == nil { tmp3 = ifn_1000.Invoke_O__O(arg_1001) } else { tmp3 = linked_999.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_998, arg_1001) }; if jrt.J2g_Truth(tmp3) { var root_1002 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = map__598000145__5; if linked_1003 == nil { map__598000145__6 = ifn_1004.Invoke_O__O(arg_1005) } else { map__598000145__6 = linked_1003.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1002, arg_1005) } } else { map__598000145__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__598000145__6 = map__598000145__5 }; var tools__7 any = /*line :211:1*/lang.RT_Get_O_O__O_NoInit(map__598000145__6, A_arbace_box_build_A_const_120); var P__8_ any = A_arbace_box_build_A_const_91.Invoke_O__O(pkg__1); var imports__9 any = A_arbace_box_build_A_const_121.Invoke_O__O(pkg__1); var vec__598000147__10 any; var root_1006 any = A_arbace_box_build_A_const_122.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, A_arbace_box_build_deps_tree_A_fn_class); var ifn_1008 lang.IFn; if





	linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = archives__2; var arg_1010 any = index__3; var arg_1011 any = imports__9; if linked_1007 == nil { vec__598000147__10 = ifn_1008.Invoke_O_O_O__O(arg_1009, arg_1010, arg_1011) } else { vec__598000147__10 = linked_1007.(*A_arbace_box_build_deps_tree_A).Invoke_O_O_O_O__O(root_1006, arg_1009, arg_1010, arg_1011) }; var dtree__11 any = /*line :211:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__598000147__10, lang.RT_IntCast_J__I_NoInit(0), nil); var lines__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000147__10, lang.RT_IntCast_J__I_NoInit(1), nil); var importcfg__13 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil, nil); var tmp5 any; var root_1012 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1014 lang.IFn; if







	linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_1016 any; var iter__1927001039__auto____16 any; var tmp6 any = A_arbace_box_build_build_package_iter__598000150__598000154_A_New(); var tmp7 *jrt.Class; var fncls__1075 *jrt.Class = A_arbace_box_build_build_package_iter__598000150__598000154_A_fn_class; if fncls__1075 == nil { var fncls__1075d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_box_build_build_package_iter__598000150__598000154_A_fn_class = fncls__1075d; tmp7 = fncls__1075d } else { tmp7 = fncls__1075 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____16); var tmp9 any; var root_1076 any = A_arbace_box_build_A_const_112.GetRawRoot__O(); var linked_1077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1076, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1078 lang.IFn; if linked_1077 == nil { ifn_1078 = lang.IFn_Cast(root_1076) } else { ifn_1078 = nil }; var arg_1079 any = A_arbace_box_build_A_const_123.Invoke_O__O(pkg__1); if linked_1077 == nil { tmp9 = ifn_1078.Invoke_O__O(arg_1079) } else { tmp9 = linked_1077.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1076, arg_1079) }; arg_1016 = tmp8.Invoke_O__O(tmp9); if linked_1013 == nil { tmp5 = ifn_1014.Invoke_O_O__O(arg_1015, arg_1016) } else { tmp5 = linked_1013.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1012, arg_1015, arg_1016) }; var tmp10 any = tmp5; var tmp11 any; var root_1080 any = /*line :218:1*/A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_1081 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1080, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1082 lang.IFn; if

	linked_1081 == nil { ifn_1082 = lang.IFn_Cast(root_1080) } else { ifn_1082 = nil }; var arg_1083 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_1084 any; var iter__1927001039__auto____16_2 any; var tmp12 any = A_arbace_box_build_build_package_iter__598000166__598000170_A_New(); var tmp13 *jrt.Class; var fncls__1143 *jrt.Class = A_arbace_box_build_build_package_iter__598000166__598000170_A_fn_class; if fncls__1143 == nil { var fncls__1143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_box_build_build_package_iter__598000166__598000170_A_fn_class = fncls__1143d; tmp13 = fncls__1143d } else { tmp13 = fncls__1143 }; iter__1927001039__auto____16_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); arg_1084 = lang.IFn_Cast(iter__1927001039__auto____16_2).Invoke_O__O(lines__12); if linked_1081 == nil { tmp11 = ifn_1082.Invoke_O_O__O(arg_1083, arg_1084) } else { tmp11 = linked_1081.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1080, arg_1083, arg_1084) }; importcfg__13 = /*line :218:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, tmp11)).Ref(); var sfiles__14 any = /*line :211:1*/A_arbace_box_build_A_const_106.Invoke_O__O(pkg__1); var res_of__15 any; var tmp14 any = A_arbace_box_build_build_package_res_of__598000176_A_New_O(P__8_); var tmp15 *jrt.Class; var fncls__1154 *jrt.Class = A_arbace_box_build_build_package_res_of__598000176_A_fn_class; if










	fncls__1154 == nil { var fncls__1154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_box_build_build_package_res_of__598000176_A_fn_class = fncls__1154d; tmp15 = fncls__1154d } else { tmp15 = fncls__1154 }; res_of__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var rsc__16 any; var tmp16 /*line :211:1*/*lang.Keyword = A_arbace_box_build_A_const_126; var or__1927000174__auto____16 any = lang.RT_Get_O_O__O_NoInit(tmp16.Invoke_O__O(A_arbace_box_build_A_const_49.Get__O()), P__8_); if














	jrt.J2g_Truth(or__1927000174__auto____16) { rsc__16 = or__1927000174__auto____16 } else {
		var root_1155 any = A_arbace_box_build_A_const_127.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1157 lang.IFn; if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any; var tmp17 any = A_arbace_box_build_build_package_fn__598000179_A_New_O(P__8_); var tmp18 *jrt.Class; var fncls__1180 *jrt.Class = A_arbace_box_build_build_package_fn__598000179_A_fn_class; if fncls__1180 == nil { var fncls__1180d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_box_build_build_package_fn__598000179_A_fn_class = fncls__1180d; tmp18 = fncls__1180d } else { tmp18 = fncls__1180 }; arg_1158 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var arg_1159 any; var root_1181 any = A_arbace_box_build_A_const_117.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1183 lang.IFn


		if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = lang.IFn_Cast(A_arbace_box_build_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_box_build_A_const_131.GetRawRoot__O(), A_arbace_box_build_A_const_132.GetRawRoot__O(), A_arbace_box_build_A_const_14.GetRawRoot__O(), A_arbace_box_build_A_const_118.GetRawRoot__O()); var tmp19 *lang.Keyword = A_arbace_box_build_A_const_126; var arg_1185 any = tmp19.Invoke_O__O(A_arbace_box_build_A_const_49.Get__O()); if linked_1182 == nil { arg_1159 = ifn_1183.Invoke_O_O__O(arg_1184, arg_1185) } else { arg_1159 = linked_1182.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1181, arg_1184, arg_1185) }
//line :227:1
		if linked_1156 == nil { rsc__16 = ifn_1157.Invoke_O_O__O(arg_1158, arg_1159) } else { rsc__16 = linked_1156.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1155, arg_1158, arg_1159) } }; var ___17 any; var tmp20 any; var and__1927000168__auto____17 any = /*line :211:1*/A_arbace_box_build_A_const_133.Invoke_O__O(pkg__1); _ = ___17; if



















	jrt.J2g_Truth(and__1927000168__auto____17) { var root_1193 any = A_arbace_box_build_A_const_73.GetRawRoot__O(); var linked_1194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1193, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1195 lang.IFn; if linked_1194 == nil { ifn_1195 = lang.IFn_Cast(root_1193) } else { ifn_1195 = nil }; var arg_1196 any = A_arbace_box_build_A_const_134.Invoke_O__O(pkg__1); if linked_1194 == nil { tmp20 = ifn_1195.Invoke_O__O(arg_1196) } else { tmp20 = linked_1194.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1193, arg_1196) } } else { tmp20 = and__1927000168__auto____17 }; if jrt.J2g_Truth(tmp20) {
		var root_1197 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, A_arbace_box_build_fail_A_fn_class); var ifn_1199 lang.IFn; if linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_1, nil, Lit_50), jrt.RefArrayOf(jrt.Object_class, nil, P__8_, nil)).Ref(); var arg_1201 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_91, P__8_)); if linked_1198 == nil { ___17 = ifn_1199.Invoke_O_O__O(arg_1200, arg_1201) } else { ___17 = linked_1198.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_1197, arg_1200, arg_1201) } } else {
//line :231:1
			___17 = nil }; var embedcfg__18 any; var tmp21 /*line :211:1*/*lang.Keyword = A_arbace_box_build_A_const_135; var temp__1927000414__auto____18 any = tmp21.Invoke_O__O(A_arbace_box_build_A_const_134.Invoke_O__O(pkg__1)); if





















	jrt.J2g_Truth(temp__1927000414__auto____18) { var pats__19 any = temp__1927000414__auto____18; var root_1202 any = A_arbace_box_build_A_const_136.GetRawRoot__O(); var linked_1203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1202, A_arbace_box_build_embed_config_A_fn_class); var ifn_1204 lang.IFn
		if linked_1203 == nil { ifn_1204 = lang.IFn_Cast(root_1202) } else { ifn_1204 = nil }; var arg_1205 any = pats__19; if linked_1203 == nil { embedcfg__18 = ifn_1204.Invoke_O__O(arg_1205) } else { embedcfg__18 = linked_1203.(*A_arbace_box_build_embed_config_A).Invoke_O_O__O(root_1202, arg_1205) } } else {
//line :233:1
			embedcfg__18 = nil }; var symabis__19 any; var tmp22 any; var root_1206 any = /*line :211:1*/A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1208 lang.IFn; if























	linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any = sfiles__14; if linked_1207 == nil { tmp22 = ifn_1208.Invoke_O__O(arg_1209) } else { tmp22 = linked_1207.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1206, arg_1209) }; if jrt.J2g_Truth(tmp22) {
		var root_1210 any = A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, A_arbace_box_build_out_file_A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any; var tmp23 lang.IFn = lang.IFn_Cast(res_of__15); var tmp24 any = A_arbace_box_build_A_const_138; var tmp25 any = A_arbace_box_build_A_const_139.Invoke_O__O(tools__7); var tmp26 any = A_arbace_box_build_A_const_78; var tmp27 any; var root_1216 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1216, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1218 lang.IFn

		if linked_1217 == nil { ifn_1218 = lang.IFn_Cast(root_1216) } else { ifn_1218 = nil }; var arg_1219 any = lang.IFn_Cast(A_arbace_box_build_A_const_140.GetRawRoot__O()).Invoke_O_O_O_O__O(plan__0, pkg__1, Lit_52, Lit_53); var arg_1220 any; var root_1228 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1229 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1228, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1230 lang.IFn; if linked_1229 == nil { ifn_1230 = lang.IFn_Cast(root_1228) } else { ifn_1230 = nil }; var arg_1231 any; var tmp28 any = A_arbace_box_build_build_package_fn__598000184_A_New(); var tmp29 *jrt.Class; var fncls__1233 *jrt.Class = A_arbace_box_build_build_package_fn__598000184_A_fn_class; if fncls__1233 == nil { var fncls__1233d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_box_build_build_package_fn__598000184_A_fn_class = fncls__1233d; tmp29 = fncls__1233d } else { tmp29 = fncls__1233 }; arg_1231 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); var arg_1232 any = sfiles__14; if linked_1229 == nil { arg_1220 = ifn_1230.Invoke_O_O__O(arg_1231, arg_1232) } else { arg_1220 = linked_1229.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1228, arg_1231, arg_1232) }; if linked_1217 == nil { tmp27 = ifn_1218.Invoke_O_O__O(arg_1219, arg_1220) } else { tmp27 = linked_1217.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1216, arg_1219, arg_1220) }
//line :236:1
		var tmp30 any = tmp27; var tmp31 any = A_arbace_box_build_A_const_141; var tmp32 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_55, A_arbace_box_build_A_const_44.Invoke_O__O(pkg__1)); var tmp33 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_40, A_arbace_box_build_A_const_39.Invoke_O__O(plan__0)); var tmp34 any; var root_1234 any = A_arbace_box_build_A_const_142.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, A_arbace_box_build_file_tree_A_fn_class); var ifn_1236 lang.IFn


		if linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any = A_arbace_box_build_A_const_143; if linked_1235 == nil { tmp34 = ifn_1236.Invoke_O__O(arg_1237) } else { tmp34 = linked_1235.(*A_arbace_box_build_file_tree_A).Invoke_O_O__O(root_1234, arg_1237) }
//line :236:1
		arg_1213 = tmp23.Invoke_O_O__O(Lit_51, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp24, tmp25, tmp26, tmp30, tmp31, lang.Tuple_Create_O_O_O__IPersistentVector(tmp32, tmp33, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp34))))); var arg_1214 any = P__8_; var arg_1215 any = Lit_51; if linked_1211 == nil { symabis__19 = ifn_1212.Invoke_O_O_O__O(arg_1213, arg_1214, arg_1215) } else { symabis__19 = linked_1211.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_1210, arg_1213, arg_1214, arg_1215) } } else {
//line :235:1
			symabis__19 = nil }; var compile__20 any; var tmp35 lang.IFn = /*line :211:1*/lang.IFn_Cast(res_of__15); var tmp36 any; var root_1477 any = A_arbace_box_build_A_const_124.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1477, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_1479 lang.IFn; if






























	linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any; var tmp37 any = A_arbace_box_build_A_const_138; var tmp38 any = A_arbace_box_build_A_const_149.Invoke_O__O(tools__7); var tmp39 any = A_arbace_box_build_A_const_78; var tmp40 any; var root_1482 any = A_arbace_box_build_A_const_90.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1484 lang.IFn; if

	linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any; var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_86.GetRawRoot__O()); var tmp42 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_36, nil, Lit_59), jrt.RefArrayOf(jrt.Object_class, nil, P__8_, nil)).Ref(); var tmp43 any; if
	lang.Util_Equiv_O_O__Z_NoInit(Lit_60, A_arbace_box_build_A_const_150.Invoke_O__O(pkg__1)) { tmp43 = Lit_60 } else { tmp43 = P__8_ }; var tmp44 any = /*line :244:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_57, Lit_42, Lit_58, Lit_35, tmp42, Lit_34, tmp43, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_151.Invoke_O__O(pkg__1))).Ref())); var tmp45 any; if

	jrt.J2g_Truth(A_arbace_box_build_A_const_93.Invoke_O__O(pkg__1)) { tmp45 = A_arbace_box_build_A_const_152 } else { tmp45 = nil }; var tmp46 any = tmp45; var tmp47 any; var tmp48 any; var root_1498 any = /*line :244:1*/A_arbace_box_build_A_const_153.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1498, A_arbace_box_build_complete_QMARK__A_fn_class); var ifn_1500 lang.IFn; if


	linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any = pkg__1; if linked_1499 == nil { tmp48 = ifn_1500.Invoke_O__O(arg_1501) } else { tmp48 = linked_1499.(*A_arbace_box_build_complete_QMARK__A).Invoke_O_O__O(root_1498, arg_1501) }; if jrt.J2g_Truth(tmp48) { tmp47 = A_arbace_box_build_A_const_154 } else { tmp47 = nil }; var tmp49 any = tmp47; var tmp50 any = A_arbace_box_build_A_const_155; var tmp51 any; if

	jrt.J2g_Truth(symabis__19) { tmp51 = A_arbace_box_build_A_const_156 } else { tmp51 = nil }; var tmp52 any = tmp51; var tmp53 any = A_arbace_box_build_A_const_157; var tmp54 any; if

	jrt.J2g_Truth(embedcfg__18) { tmp54 = A_arbace_box_build_A_const_158 } else { tmp54 = nil }; var tmp55 any = tmp54; var tmp56 any; if
	jrt.J2g_Truth(symabis__19) { tmp56 = A_arbace_box_build_A_const_159 } else { tmp56 = nil }; var tmp57 any = tmp56; var tmp58 any; var root_1502 any = /*line :244:1*/A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1503 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1502, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1504 lang.IFn; if








	linked_1503 == nil { ifn_1504 = lang.IFn_Cast(root_1502) } else { ifn_1504 = nil }; var arg_1505 any; var tmp59 any = A_arbace_box_build_build_package_fn__598000186_A_New(); var tmp60 *jrt.Class; var fncls__1507 *jrt.Class = A_arbace_box_build_build_package_fn__598000186_A_fn_class; if fncls__1507 == nil { var fncls__1507d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_box_build_build_package_fn__598000186_A_fn_class = fncls__1507d; tmp60 = fncls__1507d } else { tmp60 = fncls__1507 }; arg_1505 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp59, tmp60, nil); var arg_1506 any = A_arbace_box_build_A_const_160.Invoke_O__O(pkg__1); if linked_1503 == nil { tmp58 = ifn_1504.Invoke_O_O__O(arg_1505, arg_1506) } else { tmp58 = linked_1503.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1502, arg_1505, arg_1506) }; arg_1485 = /*line :244:1*/tmp41.Invoke_O_O_O_O_O_O_O_O_O__O(tmp44, tmp46, tmp49, tmp50, tmp52, tmp53, tmp55, tmp57, tmp58); if linked_1483 == nil { tmp40 = ifn_1484.Invoke_O__O(arg_1485) } else { tmp40 = linked_1483.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1482, arg_1485) }; var tmp61 any = tmp40; var tmp62 any = A_arbace_box_build_A_const_141; var tmp63 any; var root_1508 any = /*line :242:1*/A_arbace_box_build_A_const_90.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1508, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1510 lang.IFn; if











	linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any; var root_1512 any = A_arbace_box_build_A_const_86.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1512, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1514 lang.IFn; if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; var arg_1515 any; var tmp64 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_55, A_arbace_box_build_A_const_44.Invoke_O__O(pkg__1)); var tmp65 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_63, dtree__11); var tmp66 any; var root_1516 any = A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1516, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_1518 lang.IFn; if
	linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any; var G__598000188__20_ any; var tmp67 any; var root_1520 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1520, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_1522 lang.IFn; if linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any = importcfg__13; if linked_1521 == nil { tmp67 = ifn_1522.Invoke_O__O(arg_1523) } else { tmp67 = linked_1521.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_1520, arg_1523) }; G__598000188__20_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_64, tmp67)); var G__598000188__21_ any; if jrt.J2g_Truth(symabis__19) {
		var root_1524 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_1525 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1524, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1526 lang.IFn; if linked_1525 == nil { ifn_1526 = lang.IFn_Cast(root_1524) } else { ifn_1526 = nil }; var arg_1527 any = G__598000188__20_; var arg_1528 any = Lit_51; var arg_1529 any = symabis__19; if linked_1525 == nil { G__598000188__21_ = ifn_1526.Invoke_O_O_O__O(arg_1527, arg_1528, arg_1529) } else { G__598000188__21_ = linked_1525.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1524, arg_1527, arg_1528, arg_1529) } } else {
//line :255:1
			G__598000188__21_ = G__598000188__20_ }; if jrt.J2g_Truth(embedcfg__18) {

				var root_1530 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_1531 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1530, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1532 lang.IFn; if linked_1531 == nil { ifn_1532 = lang.IFn_Cast(root_1530) } else { ifn_1532 = nil }; var arg_1533 any = G__598000188__21_; var arg_1534 any = Lit_65; var arg_1535 any; var root_1536 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_1537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1536, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_1538 lang.IFn; if linked_1537 == nil { ifn_1538 = lang.IFn_Cast(root_1536) } else { ifn_1538 = nil }; var arg_1539 any = embedcfg__18; if linked_1537 == nil { arg_1535 = ifn_1538.Invoke_O__O(arg_1539) } else { arg_1535 = linked_1537.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_1536, arg_1539) }; if linked_1531 == nil { arg_1519 = ifn_1532.Invoke_O_O_O__O(arg_1533, arg_1534, arg_1535) } else { arg_1519 = linked_1531.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1530, arg_1533, arg_1534, arg_1535) } } else {
//line :255:1
					arg_1519 = G__598000188__21_ }; if linked_1517 == nil { tmp66 = ifn_1518.Invoke_O__O(arg_1519) } else { tmp66 = linked_1517.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_1516, arg_1519) }; arg_1515 = /*line :254:1*/lang.Tuple_Create_O_O_O__IPersistentVector(tmp64, tmp65, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp66)); if linked_1513 == nil { arg_1511 = ifn_1514.Invoke_O__O(arg_1515) } else { arg_1511 = linked_1513.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_1512, arg_1515) }; if linked_1509 == nil { tmp63 = ifn_1510.Invoke_O__O(arg_1511) } else { tmp63 = linked_1509.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1508, arg_1511) }; arg_1480 = /*line :242:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp38, tmp39, tmp61, tmp62, tmp63)); var arg_1481 any; var root_1540 any = A_arbace_box_build_A_const_161.GetRawRoot__O(); var linked_1541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1540, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1542 lang.IFn; if















	linked_1541 == nil { ifn_1542 = lang.IFn_Cast(root_1540) } else { ifn_1542 = nil }; var arg_1543 any = rsc__16; var arg_1544 any = A_arbace_box_build_A_const_162; if linked_1541 == nil { arg_1481 = ifn_1542.Invoke_O_O__O(arg_1543, arg_1544) } else { arg_1481 = linked_1541.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1540, arg_1543, arg_1544) }; if /*line :242:1*/ linked_1478 == nil { tmp36 = ifn_1479.Invoke_O_O__O(arg_1480, arg_1481) } else { tmp36 = linked_1478.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_1477, arg_1480, arg_1481) }; compile__20 = /*line :241:1*/tmp35.Invoke_O_O__O(Lit_57, tmp36); var archive__21 any; var root_1238 any = /*line :211:1*/A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_1239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1238, A_arbace_box_build_out_file_A_fn_class); var ifn_1240 lang.IFn; if















































	linked_1239 == nil { ifn_1240 = lang.IFn_Cast(root_1238) } else { ifn_1240 = nil }; var arg_1241 any = compile__20; var arg_1242 any = P__8_; var arg_1243 any = Lit_66; if linked_1239 == nil { archive__21 = ifn_1240.Invoke_O_O_O__O(arg_1241, arg_1242, arg_1243) } else { archive__21 = linked_1239.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_1238, arg_1241, arg_1242, arg_1243) }; var tmp68 any; var root_1244 any =
	A_arbace_box_build_A_const_105.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1246 lang.IFn; if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any = sfiles__14; if linked_1245 == nil { tmp68 = ifn_1246.Invoke_O__O(arg_1247) } else { tmp68 = linked_1245.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1244, arg_1247) }; if jrt.J2g_Truth(tmp68) { return archive__21 } else { var asmh__22 any; var root_1248 any = A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1248, A_arbace_box_build_out_file_A_fn_class); var ifn_1250 lang.IFn

		if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any = compile__20; var arg_1252 any = P__8_; var arg_1253 any = Lit_67; if linked_1249 == nil { asmh__22 = ifn_1250.Invoke_O_O_O__O(arg_1251, arg_1252, arg_1253) } else { asmh__22 = linked_1249.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_1248, arg_1251, arg_1252, arg_1253) }
//line :260:1
		var ctree__23 any; var root_1254 any = A_arbace_box_build_A_const_31.GetRawRoot__O(); var linked_1255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1254, aot_arbace_box.A_arbace_box_put_tree_A_fn_class); var ifn_1256 lang.IFn


		if linked_1255 == nil { ifn_1256 = lang.IFn_Cast(root_1254) } else { ifn_1256 = nil }; var arg_1257 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_67, asmh__22)); if linked_1255 == nil { ctree__23 = ifn_1256.Invoke_O__O(arg_1257) } else { ctree__23 = linked_1255.(*aot_arbace_box.A_arbace_box_put_tree_A).Invoke_O_O__O(root_1254, arg_1257) }
//line :260:1
		var objs__24 any; var root_1258 any = A_arbace_box_build_A_const_144.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1258, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_1260 lang.IFn



		if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var arg_1261 any; var iter__1927001039__auto____24 any; var tmp69 any = A_arbace_box_build_build_package_iter__598000189__598000193_A_New_O_O_O_O_O_O(res_of__15, P__8_, plan__0, ctree__23, pkg__1, tools__7); var tmp70 *jrt.Class; var fncls__1376 *jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_A_fn_class
		if fncls__1376 == nil { var fncls__1376d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_box_build_build_package_iter__598000189__598000193_A_fn_class = fncls__1376d; tmp70 = fncls__1376d } else { tmp70 = fncls__1376 }; iter__1927001039__auto____24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp69, tmp70, nil); arg_1261 = lang.IFn_Cast(iter__1927001039__auto____24).Invoke_O__O(sfiles__14)
//line :264:1
		if linked_1259 == nil { objs__24 = ifn_1260.Invoke_O__O(arg_1261) } else { objs__24 = linked_1259.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_1258, arg_1261) }
//line :260:1
		var members__25 any; var iter__1927001039__auto____25 any; var tmp71 any = A_arbace_box_build_build_package_iter__598000203__598000207_A_New(); var tmp72 *jrt.Class
		var fncls__1459 /*line :260:1*/*jrt.Class = A_arbace_box_build_build_package_iter__598000203__598000207_A_fn_class












		if fncls__1459 == nil { var fncls__1459d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_box_build_build_package_iter__598000203__598000207_A_fn_class = fncls__1459d; tmp72 = fncls__1459d } else { tmp72 = fncls__1459 }; iter__1927001039__auto____25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp71, tmp72, nil); members__25 = lang.IFn_Cast(iter__1927001039__auto____25).Invoke_O__O(objs__24)
		var root_1460 any = A_arbace_box_build_A_const_24.GetRawRoot__O(); var linked_1461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1460, aot_arbace_box.A_arbace_box_put_file_A_fn_class); var ifn_1462 lang.IFn; if linked_1461 == nil { ifn_1462 = lang.IFn_Cast(root_1460) } else { ifn_1462 = nil }; var arg_1463 any; var root_1464 any = A_arbace_box_build_A_const_148.GetRawRoot__O(); var linked_1465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1464, A_arbace_box_build_append_members_A_fn_class); var ifn_1466 lang.IFn; if linked_1465 == nil { ifn_1466 = lang.IFn_Cast(root_1464) } else { ifn_1466 = nil }; var arg_1467 any; var root_1469 any = A_arbace_box_build_A_const_146.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, aot_arbace_box.A_arbace_box_get_bytes_A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any; var root_1473 any = A_arbace_box_build_A_const_147.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = archive__21; if linked_1474 == nil { arg_1472 = ifn_1475.Invoke_O__O(arg_1476) } else { arg_1472 = linked_1474.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1473, arg_1476) }; if linked_1470 == nil { arg_1467 = ifn_1471.Invoke_O__O(arg_1472) } else { arg_1467 = linked_1470.(*aot_arbace_box.A_arbace_box_get_bytes_A).Invoke_O_O__O(root_1469, arg_1472) }; var arg_1468 any = members__25; if linked_1465 == nil { arg_1463 = ifn_1466.Invoke_O_O__O(arg_1467, arg_1468) } else { arg_1463 = linked_1465.(*A_arbace_box_build_append_members_A).Invoke_O_O_O__O(root_1464, arg_1467, arg_1468) }; if linked_1461 == nil { return ifn_1462.Invoke_O__O(arg_1463) } else { return linked_1461.(*aot_arbace_box.A_arbace_box_put_file_A).Invoke_O_O__O(root_1460, arg_1463) } } }
//line :219:1
func A_arbace_box_build_build_package_iter__598000150__598000154_A_New() *A_arbace_box_build_build_package_iter__598000150__598000154_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000150__598000154_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_A) Ctor() {}
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_A) Invoke_O_O__O(self, s__598000151__1 any) any { var tmp1 any = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_New_O_O(self, s__598000151__1); var tmp2 *jrt.Class; var fncls__1074 *jrt.Class = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_fn_class; if fncls__1074 == nil { var fncls__1074d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_fn_class = fncls__1074d; tmp2 = fncls__1074d } else { tmp2 = fncls__1074 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :219:1
func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_New_O_O(p0, p1 any) *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A{}; t.Ctor_O_O(p0, p1); return t }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A) Ctor_O_O(c__iter__598000150, c__s__598000151 any) { t.F_iter__598000150 = c__iter__598000150; t.F_s__598000151 = c__s__598000151 }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A) Invoke_O__O(self any) any { { var s__598000151__1 any; var t_ any = t.F_s__598000151; t.F_s__598000151 = nil; s__598000151__1 = t_; for { var temp__1927000414__auto____2 any; var root_1017 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1017, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any = s__598000151__1; if linked_1018 == nil { temp__1927000414__auto____2 = ifn_1019.Invoke_O__O(arg_1020) } else { temp__1927000414__auto____2 = linked_1018.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1017, arg_1020) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000151__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1021 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1021, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1023 lang.IFn; if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any = s__598000151__3; if linked_1022 == nil { tmp1 = ifn_1023.Invoke_O__O(arg_1024) } else { tmp1 = linked_1022.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1021, arg_1024) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1025 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1025, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1027 lang.IFn; if linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any = s__598000151__3; if linked_1026 == nil { c__1927001037__auto____4 = ifn_1027.Invoke_O__O(arg_1028) } else { c__1927001037__auto____4 = linked_1026.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1025, arg_1028) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000153__6 any; var root_1029 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1030 == nil { b__598000153__6 = ifn_1031.Invoke_O__O(arg_1032) } else { b__598000153__6 = linked_1030.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1029, arg_1032) }; var tmp2 any = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_New_O_I_O(b__598000153__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1038 *jrt.Class = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_fn_class; if fncls__1038 == nil { var fncls__1038d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_fn_class = fncls__1038d; tmp3 = fncls__1038d } else { tmp3 = fncls__1038 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1039 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1041 lang.IFn; if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any; var root_1044 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1046 lang.IFn; if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = b__598000153__6; if linked_1045 == nil { arg_1042 = ifn_1046.Invoke_O__O(arg_1047) } else { arg_1042 = linked_1045.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1044, arg_1047) }; var arg_1043 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000150); var tmp5 any; var root_1048 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any = s__598000151__3; if linked_1049 == nil { tmp5 = ifn_1050.Invoke_O__O(arg_1051) } else { tmp5 = linked_1049.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1048, arg_1051) }; arg_1043 = tmp4.Invoke_O__O(tmp5); if linked_1040 == nil { return ifn_1041.Invoke_O_O__O(arg_1042, arg_1043) } else { return linked_1040.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1039, arg_1042, arg_1043) } } else { var root_1052 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1052, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1054 lang.IFn; if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any; var root_1057 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = b__598000153__6; if linked_1058 == nil { arg_1055 = ifn_1059.Invoke_O__O(arg_1060) } else { arg_1055 = linked_1058.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1057, arg_1060) }; var arg_1056 any; if linked_1053 == nil { return ifn_1054.Invoke_O_O__O(arg_1055, arg_1056) } else { return linked_1053.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1052, arg_1055, arg_1056) } } } else { var vec__598000161__4 any; var root_1061 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = s__598000151__3; if linked_1062 == nil { vec__598000161__4 = ifn_1063.Invoke_O__O(arg_1064) } else { vec__598000161__4 = linked_1062.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1061, arg_1064) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000161__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000161__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1065 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_75, nil, Lit_76, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, nil, k__5, nil, v__6, nil)).Ref(); var arg_1069 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000150); var tmp7 any; var root_1070 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = s__598000151__3; if linked_1071 == nil { tmp7 = ifn_1072.Invoke_O__O(arg_1073) } else { tmp7 = linked_1071.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1070, arg_1073) }; arg_1069 = tmp6.Invoke_O__O(tmp7); if linked_1066 == nil { return ifn_1067.Invoke_O_O__O(arg_1068, arg_1069) } else { return linked_1066.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1065, arg_1068, arg_1069) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :219:1
func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A) Ctor_O_I_O(c__b__598000153 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000153 = c__b__598000153; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A) Invoke_O__O(self any) any { { var i__598000152__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000152__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000157__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000152__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000157__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000157__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1033 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any = t.F_b__598000153; var arg_1037 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_75, nil, Lit_76, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, nil, k__3, nil, v__4, nil)).Ref(); if linked_1034 == nil { ifn_1035.Invoke_O_O__O(arg_1036, arg_1037) } else { linked_1034.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1033, arg_1036, arg_1037) }; i__598000152__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000152__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_box_build_build_package_iter__598000166__598000170_A_New() *A_arbace_box_build_build_package_iter__598000166__598000170_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000166__598000170_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_A) Ctor() {}
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_A) Invoke_O_O__O(self, s__598000167__1 any) any { var tmp1 any = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_New_O_O(s__598000167__1, self); var tmp2 *jrt.Class; var fncls__1142 *jrt.Class = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_fn_class; if fncls__1142 == nil { var fncls__1142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_fn_class = fncls__1142d; tmp2 = fncls__1142d } else { tmp2 = fncls__1142 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :220:1
func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_New_O_O(p0, p1 any) *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A{}; t.Ctor_O_O(p0, p1); return t }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A) Ctor_O_O(c__s__598000167, c__iter__598000166 any) { t.F_s__598000167 = c__s__598000167; t.F_iter__598000166 = c__iter__598000166 }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A) Invoke_O__O(self any) any { { var s__598000167__1 any; var t_ any = t.F_s__598000167; t.F_s__598000167 = nil; s__598000167__1 = t_; for { var temp__1927000414__auto____2 any; var root_1085 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any = s__598000167__1; if linked_1086 == nil { temp__1927000414__auto____2 = ifn_1087.Invoke_O__O(arg_1088) } else { temp__1927000414__auto____2 = linked_1086.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1085, arg_1088) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000167__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1089 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1091 lang.IFn; if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = s__598000167__3; if linked_1090 == nil { tmp1 = ifn_1091.Invoke_O__O(arg_1092) } else { tmp1 = linked_1090.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1089, arg_1092) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1093 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = s__598000167__3; if linked_1094 == nil { c__1927001037__auto____4 = ifn_1095.Invoke_O__O(arg_1096) } else { c__1927001037__auto____4 = linked_1094.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1093, arg_1096) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000169__6 any; var root_1097 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1097, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1099 lang.IFn; if linked_1098 == nil { ifn_1099 = lang.IFn_Cast(root_1097) } else { ifn_1099 = nil }; var arg_1100 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1098 == nil { b__598000169__6 = ifn_1099.Invoke_O__O(arg_1100) } else { b__598000169__6 = linked_1098.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1097, arg_1100) }; var tmp2 any = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_New_O_I_O(b__598000169__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1106 *jrt.Class = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_fn_class; if fncls__1106 == nil { var fncls__1106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_fn_class = fncls__1106d; tmp3 = fncls__1106d } else { tmp3 = fncls__1106 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1107 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any; var root_1112 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1114 lang.IFn; if linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any = b__598000169__6; if linked_1113 == nil { arg_1110 = ifn_1114.Invoke_O__O(arg_1115) } else { arg_1110 = linked_1113.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1112, arg_1115) }; var arg_1111 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000166); var tmp5 any; var root_1116 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any = s__598000167__3; if linked_1117 == nil { tmp5 = ifn_1118.Invoke_O__O(arg_1119) } else { tmp5 = linked_1117.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1116, arg_1119) }; arg_1111 = tmp4.Invoke_O__O(tmp5); if linked_1108 == nil { return ifn_1109.Invoke_O_O__O(arg_1110, arg_1111) } else { return linked_1108.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1107, arg_1110, arg_1111) } } else { var root_1120 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1120, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1122 lang.IFn; if linked_1121 == nil { ifn_1122 = lang.IFn_Cast(root_1120) } else { ifn_1122 = nil }; var arg_1123 any; var root_1125 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = b__598000169__6; if linked_1126 == nil { arg_1123 = ifn_1127.Invoke_O__O(arg_1128) } else { arg_1123 = linked_1126.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1125, arg_1128) }; var arg_1124 any; if linked_1121 == nil { return ifn_1122.Invoke_O_O__O(arg_1123, arg_1124) } else { return linked_1121.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1120, arg_1123, arg_1124) } } } else { var l__4 any; var root_1129 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1131 lang.IFn; if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = s__598000167__3; if linked_1130 == nil { l__4 = ifn_1131.Invoke_O__O(arg_1132) } else { l__4 = linked_1130.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1129, arg_1132) }; var root_1133 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1133, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1135 lang.IFn; if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, l__4, nil)).Ref(); var arg_1137 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000166); var tmp7 any; var root_1138 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any = s__598000167__3; if linked_1139 == nil { tmp7 = ifn_1140.Invoke_O__O(arg_1141) } else { tmp7 = linked_1139.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1138, arg_1141) }; arg_1137 = tmp6.Invoke_O__O(tmp7); if linked_1134 == nil { return ifn_1135.Invoke_O_O__O(arg_1136, arg_1137) } else { return linked_1134.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1133, arg_1136, arg_1137) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :220:1
func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A) Ctor_O_I_O(c__b__598000169 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000169 = c__b__598000169; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A) Invoke_O__O(self any) any { { var i__598000168__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000168__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000168__1)); var root_1101 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1101, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1103 lang.IFn; if linked_1102 == nil { ifn_1103 = lang.IFn_Cast(root_1101) } else { ifn_1103 = nil }; var arg_1104 any = t.F_b__598000169; var arg_1105 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, l__2, nil)).Ref(); if linked_1102 == nil { ifn_1103.Invoke_O_O__O(arg_1104, arg_1105) } else { linked_1102.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1101, arg_1104, arg_1105) }; i__598000168__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000168__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_box_build_build_package_res_of__598000176_A_New_O(p0 any) *A_arbace_box_build_build_package_res_of__598000176_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_res_of__598000176_A{}; t.Ctor_O(p0); return t }
//line :222:1
func (t *A_arbace_box_build_build_package_res_of__598000176_A) Ctor_O(c__P any) { t.F_P = c__P }
//line :222:1
func (t *A_arbace_box_build_build_package_res_of__598000176_A) Invoke_O_O_O__O(self, what__1, req__2 any) any { var root_1144 any = A_arbace_box_build_A_const_79.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, A_arbace_box_build_action_STAR__A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_88, nil), jrt.RefArrayOf(jrt.Object_class, t.F_P, nil, what__1)).Ref(); var arg_1148 any; var root_1149 any = A_arbace_box_build_A_const_124.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1149, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_1151 lang.IFn; if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = A_arbace_box_build_A_const_125; var arg_1153 any = req__2; if linked_1150 == nil { arg_1148 = ifn_1151.Invoke_O_O__O(arg_1152, arg_1153) } else { arg_1148 = linked_1150.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_1149, arg_1152, arg_1153) }; if linked_1145 == nil { return ifn_1146.Invoke_O_O__O(arg_1147, arg_1148) } else { return linked_1145.(*A_arbace_box_build_action_STAR__A).Invoke_O_O_O__O(root_1144, arg_1147, arg_1148) } }




func A_arbace_box_build_build_package_fn__598000179_A_New_O(p0 any) *A_arbace_box_build_build_package_fn__598000179_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_fn__598000179_A{}; t.Ctor_O(p0); return t }
//line :227:1
func (t *A_arbace_box_build_build_package_fn__598000179_A) Ctor_O(c__P any) { t.F_P = c__P }
//line :227:1
func (t *A_arbace_box_build_build_package_fn__598000179_A) Invoke_O_O__O(self, p__598000178__1 any) any { var vec__598000180__2 any = p__598000178__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000180__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000180__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var and__1927000168__auto____5 any; var root_1160 any = A_arbace_box_build_A_const_128.GetRawRoot__O(); var linked_1161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1160, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1162 lang.IFn; if linked_1161 == nil { ifn_1162 = lang.IFn_Cast(root_1160) } else { ifn_1162 = nil }; var arg_1163 any = k__3; if linked_1161 == nil { and__1927000168__auto____5 = ifn_1162.Invoke_O__O(arg_1163) } else { and__1927000168__auto____5 = linked_1161.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1160, arg_1163) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1164 any = A_arbace_box_build_A_const_23.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1166 lang.IFn; if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = k__3; var arg_1168 any = Lit_70; if linked_1165 == nil { and__1927000168__auto____6 = ifn_1166.Invoke_O_O__O(arg_1167, arg_1168) } else { and__1927000168__auto____6 = linked_1165.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1164, arg_1167, arg_1168) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
													var root_1169 any = A_arbace_box_build_A_const_129.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = t.F_P; var arg_1173 any; var root_1174 any = A_arbace_box_build_A_const_52.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1176 lang.IFn; if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any = k__3; var arg_1178 any = A_arbace_box_build_A_const_57; var arg_1179 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(k__3)))).Ref(); if linked_1175 == nil { arg_1173 = ifn_1176.Invoke_O_O_O__O(arg_1177, arg_1178, arg_1179) } else { arg_1173 = linked_1175.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1174, arg_1177, arg_1178, arg_1179) }; if linked_1170 == nil { tmp1 = ifn_1171.Invoke_O_O__O(arg_1172, arg_1173) } else { tmp1 = linked_1170.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1169, arg_1172, arg_1173) } } else {
//line :227:1
		tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { return v__4 } else { return nil } }










func A_arbace_box_build_build_package_fn__598000184_A_New() *A_arbace_box_build_build_package_fn__598000184_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_fn__598000184_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_box_build_build_package_fn__598000184_A) Ctor() {}
//line :238:1
func (t *A_arbace_box_build_build_package_fn__598000184_A) Invoke_O_O__O(self, p1__598000143_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_71, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__598000143_SHARP___1)).Ref() }














func A_arbace_box_build_build_package_fn__598000186_A_New() *A_arbace_box_build_build_package_fn__598000186_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_fn__598000186_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_box_build_build_package_fn__598000186_A) Ctor() {}
//line :253:1
func (t *A_arbace_box_build_build_package_fn__598000186_A) Invoke_O_O__O(self, p1__598000144_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__598000144_SHARP___1)).Ref() }











func A_arbace_box_build_build_package_iter__598000189__598000193_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_box_build_build_package_iter__598000189__598000193_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_A) Ctor_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__ctree, c__pkg, c__tools any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_tools = c__tools }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_A) Invoke_O_O__O(self, s__598000190__1 any) any { var tmp1 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_New_O_O_O_O_O_O_O_O(t.F_res_of, t.F_P, t.F_plan, t.F_ctree, t.F_pkg, t.F_tools, s__598000190__1, self); var tmp2 *jrt.Class; var fncls__1375 *jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_fn_class; if fncls__1375 == nil { var fncls__1375d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_fn_class = fncls__1375d; tmp2 = fncls__1375d } else { tmp2 = fncls__1375 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :265:1
func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A) Ctor_O_O_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__ctree, c__pkg, c__tools, c__s__598000190, c__iter__598000189 any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_tools = c__tools; t.F_s__598000190 = c__s__598000190; t.F_iter__598000189 = c__iter__598000189 }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A) Invoke_O__O(self any) any { { var s__598000190__1 any; var t_ any = t.F_s__598000190; t.F_s__598000190 = nil; s__598000190__1 = t_; for { var temp__1927000414__auto____2 any; var root_1262 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1262, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1264 lang.IFn; if linked_1263 == nil { ifn_1264 = lang.IFn_Cast(root_1262) } else { ifn_1264 = nil }; var arg_1265 any = s__598000190__1; if linked_1263 == nil { temp__1927000414__auto____2 = ifn_1264.Invoke_O__O(arg_1265) } else { temp__1927000414__auto____2 = linked_1263.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1262, arg_1265) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000190__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1266 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1266, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1268 lang.IFn; if linked_1267 == nil { ifn_1268 = lang.IFn_Cast(root_1266) } else { ifn_1268 = nil }; var arg_1269 any = s__598000190__3; if linked_1267 == nil { tmp1 = ifn_1268.Invoke_O__O(arg_1269) } else { tmp1 = linked_1267.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1266, arg_1269) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1270 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1270, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1272 lang.IFn; if linked_1271 == nil { ifn_1272 = lang.IFn_Cast(root_1270) } else { ifn_1272 = nil }; var arg_1273 any = s__598000190__3; if linked_1271 == nil { c__1927001037__auto____4 = ifn_1272.Invoke_O__O(arg_1273) } else { c__1927001037__auto____4 = linked_1271.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1270, arg_1273) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000192__6 any; var root_1274 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1274, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1276 lang.IFn; if linked_1275 == nil { ifn_1276 = lang.IFn_Cast(root_1274) } else { ifn_1276 = nil }; var arg_1277 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1275 == nil { b__598000192__6 = ifn_1276.Invoke_O__O(arg_1277) } else { b__598000192__6 = linked_1275.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1274, arg_1277) }; var tmp2 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_New_O_O_O_O_O_O_O_I_O(b__598000192__6, t.F_res_of, t.F_P, t.F_plan, t.F_ctree, t.F_pkg, t.F_tools, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1311 *jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_fn_class; if fncls__1311 == nil { var fncls__1311d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_fn_class = fncls__1311d; tmp3 = fncls__1311d } else { tmp3 = fncls__1311 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1312 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1314 lang.IFn; if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any; var root_1317 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1317, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1319 lang.IFn; if linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any = b__598000192__6; if linked_1318 == nil { arg_1315 = ifn_1319.Invoke_O__O(arg_1320) } else { arg_1315 = linked_1318.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1317, arg_1320) }; var arg_1316 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000189); var tmp5 any; var root_1321 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1321, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1323 lang.IFn; if linked_1322 == nil { ifn_1323 = lang.IFn_Cast(root_1321) } else { ifn_1323 = nil }; var arg_1324 any = s__598000190__3; if linked_1322 == nil { tmp5 = ifn_1323.Invoke_O__O(arg_1324) } else { tmp5 = linked_1322.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1321, arg_1324) }; arg_1316 = tmp4.Invoke_O__O(tmp5); if linked_1313 == nil { return ifn_1314.Invoke_O_O__O(arg_1315, arg_1316) } else { return linked_1313.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1312, arg_1315, arg_1316) } } else { var root_1325 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1327 lang.IFn; if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any; var root_1330 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1332 lang.IFn; if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = b__598000192__6; if linked_1331 == nil { arg_1328 = ifn_1332.Invoke_O__O(arg_1333) } else { arg_1328 = linked_1331.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1330, arg_1333) }; var arg_1329 any; if linked_1326 == nil { return ifn_1327.Invoke_O_O__O(arg_1328, arg_1329) } else { return linked_1326.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1325, arg_1328, arg_1329) } } } else { var s__4 any; var root_1334 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = s__598000190__3; if linked_1335 == nil { s__4 = ifn_1336.Invoke_O__O(arg_1337) } else { s__4 = linked_1335.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1334, arg_1337) }; var root_1338 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1340 lang.IFn; if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any; var o__5 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_81); var tmp7 any; var root_1343 any = A_arbace_box_build_A_const_52.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1345 lang.IFn
														if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = s__4; var arg_1347 any = A_arbace_box_build_A_const_57; var arg_1348 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(s__4)), 2)).Ref(); if linked_1344 == nil { tmp7 = ifn_1345.Invoke_O_O_O__O(arg_1346, arg_1347, arg_1348) } else { tmp7 = linked_1344.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1343, arg_1346, arg_1347, arg_1348) }; o__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil)).Ref()
//line :265:1
	var tmp8 any; var root_1349 any = A_arbace_box_build_A_const_145.GetRawRoot__O(); var linked_1350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1349, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_1351 lang.IFn

	if linked_1350 == nil { ifn_1351 = lang.IFn_Cast(root_1349) } else { ifn_1351 = nil }; var arg_1352 any; var tmp9 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_New_O_O_O_O_O_O_O_O(t.F_res_of, t.F_P, t.F_plan, o__5, t.F_ctree, t.F_pkg, s__4, t.F_tools); var tmp10 *jrt.Class; var fncls__1370 *jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_fn_class; if fncls__1370 == nil { var fncls__1370d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_fn_class = fncls__1370d; tmp10 = fncls__1370d } else { tmp10 = fncls__1370 }; arg_1352 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); if linked_1350 == nil { tmp8 = ifn_1351.Invoke_O__O(arg_1352) } else { tmp8 = linked_1350.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_1349, arg_1352) }
//line :265:1
	arg_1341 = lang.Tuple_Create_O_O__IPersistentVector(o__5, tmp8); var arg_1342 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__598000189); var tmp12 any; var root_1371 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1371, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1373 lang.IFn; if linked_1372 == nil { ifn_1373 = lang.IFn_Cast(root_1371) } else { ifn_1373 = nil }; var arg_1374 any = s__598000190__3; if linked_1372 == nil { tmp12 = ifn_1373.Invoke_O__O(arg_1374) } else { tmp12 = linked_1372.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1371, arg_1374) }; arg_1342 = tmp11.Invoke_O__O(tmp12); if linked_1339 == nil { return ifn_1340.Invoke_O_O__O(arg_1341, arg_1342) } else { return linked_1339.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1338, arg_1341, arg_1342) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :265:1
func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_New_O_O_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6 any, p7 int32, p8 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A{}; t.Ctor_O_O_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A) Ctor_O_O_O_O_O_O_O_I_O(c__b__598000192, c__res_of, c__P, c__plan, c__ctree, c__pkg, c__tools any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000192 = c__b__598000192; t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_tools = c__tools; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A) Invoke_O__O(self any) any { { var i__598000191__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000191__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000191__1)); var root_1278 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1278, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1280 lang.IFn; if linked_1279 == nil { ifn_1280 = lang.IFn_Cast(root_1278) } else { ifn_1280 = nil }; var arg_1281 any = t.F_b__598000192; var arg_1282 any; var o__3 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_81); var tmp3 any; var root_1283 any = A_arbace_box_build_A_const_52.GetRawRoot__O(); var linked_1284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1283, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1285 lang.IFn
																if linked_1284 == nil { ifn_1285 = lang.IFn_Cast(root_1283) } else { ifn_1285 = nil }; var arg_1286 any = s__2; var arg_1287 any = A_arbace_box_build_A_const_57; var arg_1288 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(s__2)), 2)).Ref(); if linked_1284 == nil { tmp3 = ifn_1285.Invoke_O_O_O__O(arg_1286, arg_1287, arg_1288) } else { tmp3 = linked_1284.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1283, arg_1286, arg_1287, arg_1288) }; o__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref()
//line :265:1
	var tmp4 any; var root_1289 any = A_arbace_box_build_A_const_145.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_1291 lang.IFn

	if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any; var tmp5 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_New_O_O_O_O_O_O_O_O(t.F_res_of, t.F_P, t.F_plan, t.F_ctree, t.F_pkg, o__3, s__2, t.F_tools); var tmp6 *jrt.Class; var fncls__1310 *jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_fn_class; if fncls__1310 == nil { var fncls__1310d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_fn_class = fncls__1310d; tmp6 = fncls__1310d } else { tmp6 = fncls__1310 }; arg_1292 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if linked_1290 == nil { tmp4 = ifn_1291.Invoke_O__O(arg_1292) } else { tmp4 = linked_1290.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_1289, arg_1292) }
//line :265:1
	arg_1282 = lang.Tuple_Create_O_O__IPersistentVector(o__3, tmp4); if linked_1279 == nil { ifn_1280.Invoke_O_O__O(arg_1281, arg_1282) } else { linked_1279.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1278, arg_1281, arg_1282) }; i__598000191__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000191__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A) Ctor_O_O_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__ctree, c__pkg, c__o, c__s, c__tools any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_o = c__o; t.F_s = c__s; t.F_tools = c__tools }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A) Invoke_O__O(self any) any {
	var root_1293 any = A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, A_arbace_box_build_out_file_A_fn_class); var ifn_1295 lang.IFn; if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any; var tmp1 any; var t_ any = t.F_res_of; t.F_res_of = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_84, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_s)).Ref(); var tmp4 any = A_arbace_box_build_A_const_138; var tmp5 *lang.Keyword = A_arbace_box_build_A_const_139; var tmp6 any; var t__2 any = t.F_tools
	t.F_tools = nil; tmp6 = t__2
//line :268:1
	var tmp7 any = tmp5.Invoke_O__O(tmp6); var tmp8 any = A_arbace_box_build_A_const_78; var tmp9 any; var root_1299 any = A_arbace_box_build_A_const_9.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1299, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1301 lang.IFn

	if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_140.GetRawRoot__O()); var tmp11 any = t.F_plan; var tmp12 any = t.F_pkg; var arg_1302 any = tmp10.Invoke_O_O_O__O(tmp11, tmp12, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_85, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_o)).Ref()); var arg_1303 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_71, nil); var tmp14 any; var t__3 any = t.F_s; t.F_s = nil; tmp14 = t__3; arg_1303 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_1300 == nil { tmp9 = ifn_1301.Invoke_O_O__O(arg_1302, arg_1303) } else { tmp9 = linked_1300.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1299, arg_1302, arg_1303) }
//line :268:1
	var tmp15 any = tmp9; var tmp16 any = A_arbace_box_build_A_const_141; var tmp17 *lang.Keyword = A_arbace_box_build_A_const_44; var tmp18 any; var t__4 any = t.F_pkg


	t.F_pkg = nil; tmp18 = t__4
//line :268:1
	var tmp19 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_55, tmp17.Invoke_O__O(tmp18)); var tmp20 *lang.Keyword = A_arbace_box_build_A_const_39; var tmp21 any; var t__5 any = t.F_plan


	t.F_plan = nil; tmp21 = t__5
//line :268:1
	var tmp22 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_40, tmp20.Invoke_O__O(tmp21)); var tmp23 any; var t__6 any = t.F_ctree; t.F_ctree = nil; tmp23 = t__6; arg_1296 = tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, tmp15, tmp16, lang.Tuple_Create_O_O_O__IPersistentVector(tmp19, tmp22, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp23))))); var arg_1297 any; var t__7 any = t.F_P; t.F_P = nil; arg_1297 = t__7; var arg_1298 any; var t__8 any = t.F_o; t.F_o = nil; arg_1298 = t__8; if linked_1294 == nil { return ifn_1295.Invoke_O_O_O__O(arg_1296, arg_1297, arg_1298) } else { return linked_1294.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_1293, arg_1296, arg_1297, arg_1298) } }
//line :267:1
func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A) Ctor_O_O_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__o, c__ctree, c__pkg, c__s, c__tools any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_o = c__o; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_s = c__s; t.F_tools = c__tools }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A) Invoke_O__O(self any) any {
	var root_1353 any = A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, A_arbace_box_build_out_file_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any; var tmp1 any; var t_ any = t.F_res_of; t.F_res_of = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_84, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_s)).Ref(); var tmp4 any = A_arbace_box_build_A_const_138; var tmp5 *lang.Keyword = A_arbace_box_build_A_const_139; var tmp6 any; var t__2 any = t.F_tools
	t.F_tools = nil; tmp6 = t__2
//line :268:1
	var tmp7 any = tmp5.Invoke_O__O(tmp6); var tmp8 any = A_arbace_box_build_A_const_78; var tmp9 any; var root_1359 any = A_arbace_box_build_A_const_9.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1361 lang.IFn

	if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_140.GetRawRoot__O()); var tmp11 any = t.F_plan; var tmp12 any = t.F_pkg; var arg_1362 any = tmp10.Invoke_O_O_O__O(tmp11, tmp12, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_85, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_o)).Ref()); var arg_1363 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_71, nil); var tmp14 any; var t__3 any = t.F_s; t.F_s = nil; tmp14 = t__3; arg_1363 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_1360 == nil { tmp9 = ifn_1361.Invoke_O_O__O(arg_1362, arg_1363) } else { tmp9 = linked_1360.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1359, arg_1362, arg_1363) }
//line :268:1
	var tmp15 any = tmp9; var tmp16 any = A_arbace_box_build_A_const_141; var tmp17 *lang.Keyword = A_arbace_box_build_A_const_44; var tmp18 any; var t__4 any = t.F_pkg


	t.F_pkg = nil; tmp18 = t__4
//line :268:1
	var tmp19 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_55, tmp17.Invoke_O__O(tmp18)); var tmp20 *lang.Keyword = A_arbace_box_build_A_const_39; var tmp21 any; var t__5 any = t.F_plan


	t.F_plan = nil; tmp21 = t__5
//line :268:1
	var tmp22 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_40, tmp20.Invoke_O__O(tmp21)); var tmp23 any; var t__6 any = t.F_ctree; t.F_ctree = nil; tmp23 = t__6; arg_1356 = tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, tmp15, tmp16, lang.Tuple_Create_O_O_O__IPersistentVector(tmp19, tmp22, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp23))))); var arg_1357 any; var t__7 any = t.F_P; t.F_P = nil; arg_1357 = t__7; var arg_1358 any; var t__8 any = t.F_o; t.F_o = nil; arg_1358 = t__8; if linked_1354 == nil { return ifn_1355.Invoke_O_O_O__O(arg_1356, arg_1357, arg_1358) } else { return linked_1354.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_1353, arg_1356, arg_1357, arg_1358)
	}
}


func A_arbace_box_build_build_package_iter__598000203__598000207_A_New() *A_arbace_box_build_build_package_iter__598000203__598000207_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000203__598000207_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_A) Ctor() {}
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_A) Invoke_O_O__O(self, s__598000204__1 any) any { var tmp1 any = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_New_O_O(self, s__598000204__1); var tmp2 *jrt.Class; var fncls__1458 *jrt.Class = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_fn_class; if fncls__1458 == nil { var fncls__1458d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_fn_class = fncls__1458d; tmp2 = fncls__1458d } else { tmp2 = fncls__1458 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :273:1
func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_New_O_O(p0, p1 any) *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A{}; t.Ctor_O_O(p0, p1); return t }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A) Ctor_O_O(c__iter__598000203, c__s__598000204 any) { t.F_iter__598000203 = c__iter__598000203; t.F_s__598000204 = c__s__598000204 }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A) Invoke_O__O(self any) any { { var s__598000204__1 any; var t_ any = t.F_s__598000204; t.F_s__598000204 = nil; s__598000204__1 = t_; for { var temp__1927000414__auto____2 any; var root_1377 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any = s__598000204__1; if linked_1378 == nil { temp__1927000414__auto____2 = ifn_1379.Invoke_O__O(arg_1380) } else { temp__1927000414__auto____2 = linked_1378.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1377, arg_1380) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000204__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1381 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1381, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1383 lang.IFn; if linked_1382 == nil { ifn_1383 = lang.IFn_Cast(root_1381) } else { ifn_1383 = nil }; var arg_1384 any = s__598000204__3; if linked_1382 == nil { tmp1 = ifn_1383.Invoke_O__O(arg_1384) } else { tmp1 = linked_1382.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1381, arg_1384) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1385 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1385, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1387 lang.IFn; if linked_1386 == nil { ifn_1387 = lang.IFn_Cast(root_1385) } else { ifn_1387 = nil }; var arg_1388 any = s__598000204__3; if linked_1386 == nil { c__1927001037__auto____4 = ifn_1387.Invoke_O__O(arg_1388) } else { c__1927001037__auto____4 = linked_1386.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1385, arg_1388) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000206__6 any; var root_1389 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1389, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1391 lang.IFn; if linked_1390 == nil { ifn_1391 = lang.IFn_Cast(root_1389) } else { ifn_1391 = nil }; var arg_1392 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1390 == nil { b__598000206__6 = ifn_1391.Invoke_O__O(arg_1392) } else { b__598000206__6 = linked_1390.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1389, arg_1392) }; var tmp2 any = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_New_O_I_O(b__598000206__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1410 *jrt.Class = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_fn_class; if fncls__1410 == nil { var fncls__1410d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_fn_class = fncls__1410d; tmp3 = fncls__1410d } else { tmp3 = fncls__1410 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1411 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1411, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1413 lang.IFn; if linked_1412 == nil { ifn_1413 = lang.IFn_Cast(root_1411) } else { ifn_1413 = nil }; var arg_1414 any; var root_1416 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = b__598000206__6; if linked_1417 == nil { arg_1414 = ifn_1418.Invoke_O__O(arg_1419) } else { arg_1414 = linked_1417.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1416, arg_1419) }; var arg_1415 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000203); var tmp5 any; var root_1420 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1420, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any = s__598000204__3; if linked_1421 == nil { tmp5 = ifn_1422.Invoke_O__O(arg_1423) } else { tmp5 = linked_1421.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1420, arg_1423) }; arg_1415 = tmp4.Invoke_O__O(tmp5); if linked_1412 == nil { return ifn_1413.Invoke_O_O__O(arg_1414, arg_1415) } else { return linked_1412.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1411, arg_1414, arg_1415) } } else { var root_1424 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1424, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1426 lang.IFn; if linked_1425 == nil { ifn_1426 = lang.IFn_Cast(root_1424) } else { ifn_1426 = nil }; var arg_1427 any; var root_1429 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1429, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1431 lang.IFn; if linked_1430 == nil { ifn_1431 = lang.IFn_Cast(root_1429) } else { ifn_1431 = nil }; var arg_1432 any = b__598000206__6; if linked_1430 == nil { arg_1427 = ifn_1431.Invoke_O__O(arg_1432) } else { arg_1427 = linked_1430.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1429, arg_1432) }; var arg_1428 any; if linked_1425 == nil { return ifn_1426.Invoke_O_O__O(arg_1427, arg_1428) } else { return linked_1425.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1424, arg_1427, arg_1428) } } } else { var vec__598000214__4 any; var root_1433 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = s__598000204__3; if linked_1434 == nil { vec__598000214__4 = ifn_1435.Invoke_O__O(arg_1436) } else { vec__598000214__4 = linked_1434.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1433, arg_1436) }; var o__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000214__4, lang.RT_IntCast_J__I_NoInit(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000214__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1437 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1439 lang.IFn; if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any; var tmp6 any; var root_1442 any = A_arbace_box_build_A_const_146.GetRawRoot__O(); var linked_1443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1442, aot_arbace_box.A_arbace_box_get_bytes_A_fn_class); var ifn_1444 lang.IFn; if linked_1443 == nil { ifn_1444 = lang.IFn_Cast(root_1442) } else { ifn_1444 = nil }; var arg_1445 any; var root_1446 any = A_arbace_box_build_A_const_147.GetRawRoot__O(); var linked_1447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1446, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1448 lang.IFn; if linked_1447 == nil { ifn_1448 = lang.IFn_Cast(root_1446) } else { ifn_1448 = nil }; var arg_1449 any; var root_1450 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1450, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1452 lang.IFn; if linked_1451 == nil { ifn_1452 = lang.IFn_Cast(root_1450) } else { ifn_1452 = nil }; var arg_1453 any = f__6; if linked_1451 == nil { arg_1449 = ifn_1452.Invoke_O__O(arg_1453) } else { arg_1449 = linked_1451.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1450, arg_1453) }; if linked_1447 == nil { arg_1445 = ifn_1448.Invoke_O__O(arg_1449) } else { arg_1445 = linked_1447.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1446, arg_1449) }; if linked_1443 == nil { tmp6 = ifn_1444.Invoke_O__O(arg_1445) } else { tmp6 = linked_1443.(*aot_arbace_box.A_arbace_box_get_bytes_A).Invoke_O_O__O(root_1442, arg_1445) }; arg_1440 = lang.Tuple_Create_O_O__IPersistentVector(o__5, tmp6); var arg_1441 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__598000203); var tmp8 any; var root_1454 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1454, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1456 lang.IFn; if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any = s__598000204__3; if linked_1455 == nil { tmp8 = ifn_1456.Invoke_O__O(arg_1457) } else { tmp8 = linked_1455.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1454, arg_1457) }; arg_1441 = tmp7.Invoke_O__O(tmp8); if linked_1438 == nil { return ifn_1439.Invoke_O_O__O(arg_1440, arg_1441) } else { return linked_1438.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1437, arg_1440, arg_1441) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :273:1
func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A) Ctor_O_I_O(c__b__598000206 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000206 = c__b__598000206; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A) Invoke_O__O(self any) any { { var i__598000205__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000205__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000210__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000205__1)); var o__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000210__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000210__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1393 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1393, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1395 lang.IFn; if linked_1394 == nil { ifn_1395 = lang.IFn_Cast(root_1393) } else { ifn_1395 = nil }; var arg_1396 any = t.F_b__598000206; var arg_1397 any; var tmp2 any; var root_1398 any = A_arbace_box_build_A_const_146.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_box.A_arbace_box_get_bytes_A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any; var root_1402 any = A_arbace_box_build_A_const_147.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1404 lang.IFn; if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any; var root_1406 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1408 lang.IFn; if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any = f__4; if linked_1407 == nil { arg_1405 = ifn_1408.Invoke_O__O(arg_1409) } else { arg_1405 = linked_1407.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1406, arg_1409) }; if linked_1403 == nil { arg_1401 = ifn_1404.Invoke_O__O(arg_1405) } else { arg_1401 = linked_1403.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1402, arg_1405) }; if linked_1399 == nil { tmp2 = ifn_1400.Invoke_O__O(arg_1401) } else { tmp2 = linked_1399.(*aot_arbace_box.A_arbace_box_get_bytes_A).Invoke_O_O__O(root_1398, arg_1401) }; arg_1397 = lang.Tuple_Create_O_O__IPersistentVector(o__3, tmp2); if linked_1394 == nil { ifn_1395.Invoke_O_O__O(arg_1396, arg_1397) } else { linked_1394.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1393, arg_1396, arg_1397) }; i__598000205__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000205__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_box_build_read_plan_A_New() *A_arbace_box_build_read_plan_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_read_plan_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_box_build_read_plan_A) Ctor() {}
//line :276:1
func (t *A_arbace_box_build_read_plan_A) Invoke_O_O__O(self, plan__0 any) any {
	var tmp1 any; var root_1545 any = A_arbace_box_build_A_const_32.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1545, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1547 lang.IFn; if linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any = plan__0; if linked_1546 == nil { tmp1 = ifn_1547.Invoke_O__O(arg_1548) } else { tmp1 = linked_1546.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1545, arg_1548) }; if jrt.J2g_Truth(tmp1) { return plan__0 } else { var tmp2 any; var root_1549 any = A_arbace_box_build_A_const_163.GetRawRoot__O(); var linked_1550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1549, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_1551 lang.IFn
		if linked_1550 == nil { ifn_1551 = lang.IFn_Cast(root_1549) } else { ifn_1551 = nil }; var arg_1552 any = A_arbace_box_build_A_const_164; var arg_1553 any = plan__0; if linked_1550 == nil { tmp2 = ifn_1551.Invoke_O_O__O(arg_1552, arg_1553) } else { tmp2 = linked_1550.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_1549, arg_1552, arg_1553) }
//line :277:1
		if jrt.J2g_Truth(tmp2) {
			var root_1554 any = A_arbace_box_build_A_const_33.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1554, aot_arbace_edn.A_arbace_edn_read_string_A_fn_class); var ifn_1556 lang.IFn; if linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any; var root_1558 any = A_arbace_box_build_A_const_69.GetRawRoot__O(); var linked_1559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1558, aot_arbace_box.A_arbace_box_get_A_fn_class); var ifn_1560 lang.IFn; if linked_1559 == nil { ifn_1560 = lang.IFn_Cast(root_1558) } else { ifn_1560 = nil }; var arg_1561 any = plan__0; if linked_1559 == nil { arg_1557 = ifn_1560.Invoke_O__O(arg_1561) } else { arg_1557 = linked_1559.(*aot_arbace_box.A_arbace_box_get_A).Invoke_O_O__O(root_1558, arg_1561) }; if linked_1555 == nil { return ifn_1556.Invoke_O__O(arg_1557) } else { return linked_1555.(*aot_arbace_edn.A_arbace_edn_read_string_A).Invoke_O_O__O(root_1554, arg_1557) } } else {
//line :277:1
				if A_arbace_box_build_A_const_111 != nil {

					var root_1562 any = A_arbace_box_build_A_const_33.GetRawRoot__O(); var linked_1563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1562, aot_arbace_edn.A_arbace_edn_read_string_A_fn_class); var ifn_1564 lang.IFn; if linked_1563 == nil { ifn_1564 = lang.IFn_Cast(root_1562) } else { ifn_1564 = nil }; var arg_1565 any; var or__1927000174__auto____2 any; var root_1566 any = A_arbace_box_build_A_const_165.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1566, aot_arbace_box.A_arbace_box_load_A_fn_class); var ifn_1568 lang.IFn; if linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any = plan__0; if linked_1567 == nil { or__1927000174__auto____2 = ifn_1568.Invoke_O__O(arg_1569) } else { or__1927000174__auto____2 = linked_1567.(*aot_arbace_box.A_arbace_box_load_A).Invoke_O_O__O(root_1566, arg_1569) }; if jrt.J2g_Truth(or__1927000174__auto____2) { arg_1565 = or__1927000174__auto____2 } else { var root_1570 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1570, A_arbace_box_build_fail_A_fn_class); var ifn_1572 lang.IFn; if linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_139, nil), jrt.RefArrayOf(jrt.Object_class, nil, plan__0)).Ref(); var arg_1574 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_166, plan__0)); if linked_1571 == nil { arg_1565 = ifn_1572.Invoke_O_O__O(arg_1573, arg_1574) } else { arg_1565 = linked_1571.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_1570, arg_1573, arg_1574) } }; if linked_1563 == nil { return ifn_1564.Invoke_O__O(arg_1565) } else { return linked_1563.(*aot_arbace_edn.A_arbace_edn_read_string_A).Invoke_O_O__O(root_1562, arg_1565) } } else {
//line :277:1
						return nil
					}
			}
	} }
func A_arbace_box_build_with_tools_A_New() *A_arbace_box_build_with_tools_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_with_tools_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_box_build_with_tools_A) Ctor() {}
//line :281:1
func (t *A_arbace_box_build_with_tools_A) Invoke_O_O_O__O(self, p__0, opts__1 any) any { var arch__3 any = A_arbace_box_build_A_const_85.Invoke_O__O(p__0); var tools__4 any; var root_1575 any = A_arbace_box_build_A_const_124.GetRawRoot__O(); var linked_1576 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1575, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_1577 lang.IFn; if



	linked_1576 == nil { ifn_1577 = lang.IFn_Cast(root_1575) } else { ifn_1577 = nil }; var arg_1578 any; var root_1580 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1580, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1582 lang.IFn; if linked_1581 == nil { ifn_1582 = lang.IFn_Cast(root_1580) } else { ifn_1582 = nil }; var arg_1583 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1584 any; var iter__1927001039__auto____4 any; var tmp1 any = A_arbace_box_build_with_tools_iter__598000221__598000225_A_New_O(arch__3); var tmp2 *jrt.Class; var fncls__1659 *jrt.Class = A_arbace_box_build_with_tools_iter__598000221__598000225_A_fn_class; if fncls__1659 == nil { var fncls__1659d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_box_build_with_tools_iter__598000221__598000225_A_fn_class = fncls__1659d; tmp2 = fncls__1659d } else { tmp2 = fncls__1659 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_1584 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(A_arbace_box_build_A_const_168); if linked_1581 == nil { arg_1578 = ifn_1582.Invoke_O_O__O(arg_1583, arg_1584) } else { arg_1578 = linked_1581.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1580, arg_1583, arg_1584) }; var arg_1579 any = A_arbace_box_build_A_const_120.Invoke_O__O(opts__1); if linked_1576 == nil { tools__4 = ifn_1577.Invoke_O_O__O(arg_1578, arg_1579) } else { tools__4 = linked_1576.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_1575, arg_1578, arg_1579) }; var seq_598000231__5 any; var root_1666 any = /*line :281:1*/A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1666, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1668 lang.IFn; if






	linked_1667 == nil { ifn_1668 = lang.IFn_Cast(root_1666) } else { ifn_1668 = nil }; var arg_1669 any = tools__4; if linked_1667 == nil { seq_598000231__5 = ifn_1668.Invoke_O__O(arg_1669) } else { seq_598000231__5 = linked_1667.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1666, arg_1669) }; var chunk_598000232__6 any; var count_598000233__7 int64 = 0; var i_598000234__8 int64 = 0; L1:
//line :281:1
	for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_598000234__8, count_598000233__7) { var vec__598000235__9 any = lang.Indexed_Cast(chunk_598000232__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_598000234__8)); var t__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000235__9, lang.RT_IntCast_J__I_NoInit(0), nil); var h__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000235__9, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(h__11) { } else { var root_1686 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_1687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1686, A_arbace_box_build_fail_A_fn_class); var ifn_1688 lang.IFn; if linked_1687 == nil { ifn_1688 = lang.IFn_Cast(root_1686) } else { ifn_1688 = nil }; var arg_1689 any; var tmp3 *jrt.RefArray = jrt.ConstRefArray("[0,7,s31:arbace.box.build: no image for ns15: (the ref tool.ns1:.ns1:)", []*jrt.Class{jrt.String_class}); var tmp4 any; var root_1691 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1691, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1693 lang.IFn; if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any = t__10; if linked_1692 == nil { tmp4 = ifn_1693.Invoke_O__O(arg_1694) } else { tmp4 = linked_1692.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1691, arg_1694) }; var tmp5 any = tmp4; var tmp6 any; var root_1695 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1695, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1697 lang.IFn; if linked_1696 == nil { ifn_1697 = lang.IFn_Cast(root_1695) } else { ifn_1697 = nil }; var arg_1698 any = t__10; if linked_1696 == nil { tmp6 = ifn_1697.Invoke_O__O(arg_1698) } else { tmp6 = linked_1696.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1695, arg_1698) }; arg_1689 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp6, nil, arch__3, nil)).Ref(); var arg_1690 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1687 == nil { ifn_1688.Invoke_O_O__O(arg_1689, arg_1690) } else { linked_1687.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_1686, arg_1689, arg_1690) } }; seq_598000231__5, chunk_598000232__6, count_598000233__7, i_598000234__8 = seq_598000231__5, chunk_598000232__6, count_598000233__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_598000234__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1670 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1670, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1672 lang.IFn; if linked_1671 == nil { ifn_1672 = lang.IFn_Cast(root_1670) } else { ifn_1672 = nil }; var arg_1673 any = seq_598000231__5; if linked_1671 == nil { temp__1927000414__auto____9 = ifn_1672.Invoke_O__O(arg_1673) } else { temp__1927000414__auto____9 = linked_1671.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1670, arg_1673) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_598000231__10 any = temp__1927000414__auto____9; var tmp7 any; var root_1674 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1674, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1676 lang.IFn; if linked_1675 == nil { ifn_1676 = lang.IFn_Cast(root_1674) } else { ifn_1676 = nil }; var arg_1677 any = seq_598000231__10; if linked_1675 == nil { tmp7 = ifn_1676.Invoke_O__O(arg_1677) } else { tmp7 = linked_1675.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1674, arg_1677) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____11 any; var root_1678 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1678, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1680 lang.IFn; if linked_1679 == nil { ifn_1680 = lang.IFn_Cast(root_1678) } else { ifn_1680 = nil }; var arg_1681 any = seq_598000231__10; if linked_1679 == nil { c__1927000678__auto____11 = ifn_1680.Invoke_O__O(arg_1681) } else { c__1927000678__auto____11 = linked_1679.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1678, arg_1681) }; var tmp8 any; var root_1699 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1699, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1701 lang.IFn; if linked_1700 == nil { ifn_1701 = lang.IFn_Cast(root_1699) } else { ifn_1701 = nil }; var arg_1702 any = seq_598000231__10; if linked_1700 == nil { tmp8 = ifn_1701.Invoke_O__O(arg_1702) } else { tmp8 = linked_1700.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1699, arg_1702) }; seq_598000231__5, chunk_598000232__6, count_598000233__7, i_598000234__8 = tmp8, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__598000238__11 any; var root_1682 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1682, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1684 lang.IFn; if linked_1683 == nil { ifn_1684 = lang.IFn_Cast(root_1682) } else { ifn_1684 = nil }; var arg_1685 any = seq_598000231__10; if linked_1683 == nil { vec__598000238__11 = ifn_1684.Invoke_O__O(arg_1685) } else { vec__598000238__11 = linked_1683.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1682, arg_1685) }; var t__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000238__11, lang.RT_IntCast_J__I_NoInit(0), nil); var h__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000238__11, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(h__13) { } else { var root_1703 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, A_arbace_box_build_fail_A_fn_class); var ifn_1705 lang.IFn; if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any; var tmp9 *jrt.RefArray = jrt.ConstRefArray("[0,7,s31:arbace.box.build: no image for ns15: (the ref tool.ns1:.ns1:)", []*jrt.Class{jrt.String_class}); var tmp10 any; var root_1708 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1708, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1710 lang.IFn; if linked_1709 == nil { ifn_1710 = lang.IFn_Cast(root_1708) } else { ifn_1710 = nil }; var arg_1711 any = t__12; if linked_1709 == nil { tmp10 = ifn_1710.Invoke_O__O(arg_1711) } else { tmp10 = linked_1709.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1708, arg_1711) }; var tmp11 any = tmp10; var tmp12 any; var root_1712 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1714 lang.IFn; if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any = t__12; if linked_1713 == nil { tmp12 = ifn_1714.Invoke_O__O(arg_1715) } else { tmp12 = linked_1713.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1712, arg_1715) }; arg_1706 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp11, nil, tmp12, nil, arch__3, nil)).Ref(); var arg_1707 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1704 == nil { ifn_1705.Invoke_O_O__O(arg_1706, arg_1707) } else { linked_1704.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_1703, arg_1706, arg_1707) } }; var tmp13 any; var root_1716 any = A_arbace_box_build_A_const_20.GetRawRoot__O(); var linked_1717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1716, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1718 lang.IFn; if linked_1717 == nil { ifn_1718 = lang.IFn_Cast(root_1716) } else { ifn_1718 = nil }; var arg_1719 any = seq_598000231__10; if linked_1717 == nil { tmp13 = ifn_1718.Invoke_O__O(arg_1719) } else { tmp13 = linked_1717.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1716, arg_1719) }; seq_598000231__5, chunk_598000232__6, count_598000233__7, i_598000234__8 = tmp13, nil, 0, 0; continue L1 } } }
//line :281:1
		break L1 }; var root_1660 any =







	A_arbace_box_build_A_const_12.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = opts__1; var arg_1664 any = A_arbace_box_build_A_const_120; var arg_1665 any = tools__4; if linked_1661 == nil { return ifn_1662.Invoke_O_O_O__O(arg_1663, arg_1664, arg_1665) } else { return linked_1661.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1660, arg_1663, arg_1664, arg_1665) } }
//line :285:1
func A_arbace_box_build_with_tools_iter__598000221__598000225_A_New_O(p0 any) *A_arbace_box_build_with_tools_iter__598000221__598000225_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_with_tools_iter__598000221__598000225_A{}; t.Ctor_O(p0); return t }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_A) Ctor_O(c__arch any) { t.F_arch = c__arch }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_A) Invoke_O_O__O(self, s__598000222__1 any) any { var tmp1 any = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_New_O_O_O(s__598000222__1, t.F_arch, self); var tmp2 *jrt.Class; var fncls__1658 *jrt.Class = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_fn_class; if fncls__1658 == nil { var fncls__1658d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_fn_class = fncls__1658d; tmp2 = fncls__1658d } else { tmp2 = fncls__1658 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :285:1
func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A) Ctor_O_O_O(c__s__598000222, c__arch, c__iter__598000221 any) { t.F_s__598000222 = c__s__598000222; t.F_arch = c__arch; t.F_iter__598000221 = c__iter__598000221 }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A) Invoke_O__O(self any) any { { var s__598000222__1 any; var t_ any = t.F_s__598000222; t.F_s__598000222 = nil; s__598000222__1 = t_; for { var temp__1927000414__auto____2 any; var root_1585 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1585, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1587 lang.IFn; if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var arg_1588 any = s__598000222__1; if linked_1586 == nil { temp__1927000414__auto____2 = ifn_1587.Invoke_O__O(arg_1588) } else { temp__1927000414__auto____2 = linked_1586.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1585, arg_1588) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000222__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1589 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1589, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1591 lang.IFn; if linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any = s__598000222__3; if linked_1590 == nil { tmp1 = ifn_1591.Invoke_O__O(arg_1592) } else { tmp1 = linked_1590.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1589, arg_1592) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1593 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1593, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1595 lang.IFn; if linked_1594 == nil { ifn_1595 = lang.IFn_Cast(root_1593) } else { ifn_1595 = nil }; var arg_1596 any = s__598000222__3; if linked_1594 == nil { c__1927001037__auto____4 = ifn_1595.Invoke_O__O(arg_1596) } else { c__1927001037__auto____4 = linked_1594.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1593, arg_1596) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000224__6 any; var root_1597 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1597, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1598 == nil { b__598000224__6 = ifn_1599.Invoke_O__O(arg_1600) } else { b__598000224__6 = linked_1598.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1597, arg_1600) }; var tmp2 any = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_New_O_O_I_O(b__598000224__6, t.F_arch, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1614 *jrt.Class = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_fn_class; if fncls__1614 == nil { var fncls__1614d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_fn_class = fncls__1614d; tmp3 = fncls__1614d } else { tmp3 = fncls__1614 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1615 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1615, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1617 lang.IFn; if linked_1616 == nil { ifn_1617 = lang.IFn_Cast(root_1615) } else { ifn_1617 = nil }; var arg_1618 any; var root_1620 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any = b__598000224__6; if linked_1621 == nil { arg_1618 = ifn_1622.Invoke_O__O(arg_1623) } else { arg_1618 = linked_1621.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1620, arg_1623) }; var arg_1619 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000221); var tmp5 any; var root_1624 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1624, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1626 lang.IFn; if linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any = s__598000222__3; if linked_1625 == nil { tmp5 = ifn_1626.Invoke_O__O(arg_1627) } else { tmp5 = linked_1625.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1624, arg_1627) }; arg_1619 = tmp4.Invoke_O__O(tmp5); if linked_1616 == nil { return ifn_1617.Invoke_O_O__O(arg_1618, arg_1619) } else { return linked_1616.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1615, arg_1618, arg_1619) } } else { var root_1628 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1628, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1630 lang.IFn; if linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any; var root_1633 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1633, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1635 lang.IFn; if linked_1634 == nil { ifn_1635 = lang.IFn_Cast(root_1633) } else { ifn_1635 = nil }; var arg_1636 any = b__598000224__6; if linked_1634 == nil { arg_1631 = ifn_1635.Invoke_O__O(arg_1636) } else { arg_1631 = linked_1634.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1633, arg_1636) }; var arg_1632 any; if linked_1629 == nil { return ifn_1630.Invoke_O_O__O(arg_1631, arg_1632) } else { return linked_1629.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1628, arg_1631, arg_1632) } } } else { var t__4 any; var root_1637 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1637, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1639 lang.IFn; if linked_1638 == nil { ifn_1639 = lang.IFn_Cast(root_1637) } else { ifn_1639 = nil }; var arg_1640 any = s__598000222__3; if linked_1638 == nil { t__4 = ifn_1639.Invoke_O__O(arg_1640) } else { t__4 = linked_1638.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1637, arg_1640) }; var root_1641 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1641, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1643 lang.IFn; if linked_1642 == nil { ifn_1643 = lang.IFn_Cast(root_1641) } else { ifn_1643 = nil }; var arg_1644 any; var tmp6 any; var root_1646 any = A_arbace_box_build_A_const_61.GetRawRoot__O(); var linked_1647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1646, aot_arbace_box.A_arbace_box_ref_A_fn_class); var ifn_1648 lang.IFn
														if linked_1647 == nil { ifn_1648 = lang.IFn_Cast(root_1646) } else { ifn_1648 = nil }; var arg_1649 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_152, nil, Lit_153, nil); var tmp8 any; var root_1650 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1650, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1652 lang.IFn; if linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any = t__4; if linked_1651 == nil { tmp8 = ifn_1652.Invoke_O__O(arg_1653) } else { tmp8 = linked_1651.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1650, arg_1653) }; arg_1649 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil, t.F_arch)).Ref(); if linked_1647 == nil { tmp6 = ifn_1648.Invoke_O__O(arg_1649) } else { tmp6 = linked_1647.(*aot_arbace_box.A_arbace_box_ref_A).Invoke_O_O__O(root_1646, arg_1649) }
//line :285:1
	arg_1644 = lang.Tuple_Create_O_O__IPersistentVector(t__4, tmp6); var arg_1645 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__598000221); var tmp10 any; var root_1654 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1654, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1656 lang.IFn; if linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any = s__598000222__3; if linked_1655 == nil { tmp10 = ifn_1656.Invoke_O__O(arg_1657) } else { tmp10 = linked_1655.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1654, arg_1657) }; arg_1645 = tmp9.Invoke_O__O(tmp10); if linked_1642 == nil { return ifn_1643.Invoke_O_O__O(arg_1644, arg_1645) } else { return linked_1642.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1641, arg_1644, arg_1645) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :285:1
func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A) Ctor_O_O_I_O(c__b__598000224, c__arch any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000224 = c__b__598000224; t.F_arch = c__arch; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A) Invoke_O__O(self any) any { { var i__598000223__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000223__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000223__1)); var root_1601 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1601, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = t.F_b__598000224; var arg_1605 any; var tmp2 any; var root_1606 any = A_arbace_box_build_A_const_61.GetRawRoot__O(); var linked_1607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1606, aot_arbace_box.A_arbace_box_ref_A_fn_class); var ifn_1608 lang.IFn
																if linked_1607 == nil { ifn_1608 = lang.IFn_Cast(root_1606) } else { ifn_1608 = nil }; var arg_1609 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_152, nil, Lit_153, nil); var tmp4 any; var root_1610 any = A_arbace_box_build_A_const_167.GetRawRoot__O(); var linked_1611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1610, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1612 lang.IFn; if linked_1611 == nil { ifn_1612 = lang.IFn_Cast(root_1610) } else { ifn_1612 = nil }; var arg_1613 any = t__2; if linked_1611 == nil { tmp4 = ifn_1612.Invoke_O__O(arg_1613) } else { tmp4 = linked_1611.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1610, arg_1613) }; arg_1609 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, t.F_arch)).Ref(); if linked_1607 == nil { tmp2 = ifn_1608.Invoke_O__O(arg_1609) } else { tmp2 = linked_1607.(*aot_arbace_box.A_arbace_box_ref_A).Invoke_O_O__O(root_1606, arg_1609) }
//line :285:1
	arg_1605 = lang.Tuple_Create_O_O__IPersistentVector(t__2, tmp2); if linked_1602 == nil { ifn_1603.Invoke_O_O__O(arg_1604, arg_1605) } else { linked_1602.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1601, arg_1604, arg_1605) }; i__598000223__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000223__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_box_build_archives_A_New() *A_arbace_box_build_archives_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_box_build_archives_A) Ctor() {}
//line :291:1
func (t *A_arbace_box_build_archives_A) Invoke_O_O_O__O(self, plan__0, opts__1 any) any { var p__3 any; var root_1720 any = A_arbace_box_build_A_const_169.GetRawRoot__O(); var linked_1721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1720, A_arbace_box_build_read_plan_A_fn_class); var ifn_1722 lang.IFn; if




	linked_1721 == nil { ifn_1722 = lang.IFn_Cast(root_1720) } else { ifn_1722 = nil }; var arg_1723 any = plan__0; if linked_1721 == nil { p__3 = ifn_1722.Invoke_O__O(arg_1723) } else { p__3 = linked_1721.(*A_arbace_box_build_read_plan_A).Invoke_O_O__O(root_1720, arg_1723) }; var opts__4 any; var root_1724 any = /*line :291:1*/A_arbace_box_build_A_const_170.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, A_arbace_box_build_with_tools_A_fn_class); var ifn_1726 lang.IFn; if





	linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any = p__3; var arg_1728 any = opts__1; if linked_1725 == nil { opts__4 = ifn_1726.Invoke_O_O__O(arg_1727, arg_1728) } else { opts__4 = linked_1725.(*A_arbace_box_build_with_tools_A).Invoke_O_O_O__O(root_1724, arg_1727, arg_1728) }; var pkgs__5 any = /*line :291:1*/A_arbace_box_build_A_const_41.Invoke_O__O(p__3); var index__6 any; var root_1729 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1729, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1731 lang.IFn; if







	linked_1730 == nil { ifn_1731 = lang.IFn_Cast(root_1729) } else { ifn_1731 = nil }; var arg_1732 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1733 any; var root_1734 any = A_arbace_box_build_A_const_171.GetRawRoot__O(); var linked_1735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1734, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1736 lang.IFn; if linked_1735 == nil { ifn_1736 = lang.IFn_Cast(root_1734) } else { ifn_1736 = nil }; var arg_1737 any; var tmp1 any = A_arbace_box_build_archives_fn__598000242_A_New(); var tmp2 *jrt.Class; var fncls__1739 *jrt.Class = A_arbace_box_build_archives_fn__598000242_A_fn_class; if fncls__1739 == nil { var fncls__1739d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_box_build_archives_fn__598000242_A_fn_class = fncls__1739d; tmp2 = fncls__1739d } else { tmp2 = fncls__1739 }; arg_1737 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1738 any = pkgs__5; if linked_1735 == nil { arg_1733 = ifn_1736.Invoke_O_O__O(arg_1737, arg_1738) } else { arg_1733 = linked_1735.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1734, arg_1737, arg_1738) }; if linked_1730 == nil { index__6 = ifn_1731.Invoke_O_O__O(arg_1732, arg_1733) } else { index__6 = linked_1730.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1729, arg_1732, arg_1733) }; var given__7 any = /*line :291:1*/A_arbace_box_build_A_const_172.Invoke_O__O(opts__4); var only__8 any = A_arbace_box_build_A_const_173.Invoke_O__O(opts__4); var futures__9 any; var root_1740 any = A_arbace_box_build_A_const_35.GetRawRoot__O(); var linked_1741 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1740, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1742 lang.IFn; if











	linked_1741 == nil { ifn_1742 = lang.IFn_Cast(root_1740) } else { ifn_1742 = nil }; var arg_1743 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1741 == nil { futures__9 = ifn_1742.Invoke_O__O(arg_1743) } else { futures__9 = linked_1741.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1740, arg_1743) }; var sem__10 any = /*line :291:1*/jrt.Semaphore_New_I(lang.RT_IntCast_O__I_NoInit(A_arbace_box_build_A_const_174.Invoke_O_O__O(opts__4, A_arbace_box_build_A_const_175))); var conveyed__11 any; var tmp3 any = A_arbace_box_build_archives_conveyed__598000244_A_New_O(opts__4); var tmp4 *jrt.Class; var fncls__1757 *jrt.Class = A_arbace_box_build_archives_conveyed__598000244_A_fn_class; if













	fncls__1757 == nil { var fncls__1757d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_box_build_archives_conveyed__598000244_A_fn_class = fncls__1757d; tmp4 = fncls__1757d } else { tmp4 = fncls__1757 }; conveyed__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var root_1837 any =
	A_arbace_box_build_A_const_81.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1839 lang.IFn; if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; var arg_1840 any = lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, opts__4); if linked_1838 == nil { ifn_1839.Invoke_O__O(arg_1840) } else { linked_1838.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1837, arg_1840) }; var tmp5 any; tmp23 := /*line :291:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_598000248__14 any; var root_1846 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1846, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1848 lang.IFn















		if linked_1847 == nil { ifn_1848 = lang.IFn_Cast(root_1846) } else { ifn_1848 = nil }; var arg_1849 any = pkgs__5; if linked_1847 == nil { seq_598000248__14 = ifn_1848.Invoke_O__O(arg_1849) } else { seq_598000248__14 = linked_1847.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1846, arg_1849) }
//line :291:1
		var chunk_598000249__15 any; var count_598000250__16 int64 = 0; var i_598000251__17 int64 = 0; L1: for {















			if lang.Numbers_Lt_J_J__Z_NoInit(i_598000251__17, count_598000250__16) { var q__18 any = lang.Indexed_Cast(chunk_598000249__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_598000251__17)); var deps__19 any; var root_1866 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1867 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1866, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1868 lang.IFn
				if linked_1867 == nil { ifn_1868 = lang.IFn_Cast(root_1866) } else { ifn_1868 = nil }; var arg_1869 any; var root_1871 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1871, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1873 lang.IFn; if linked_1872 == nil { ifn_1873 = lang.IFn_Cast(root_1871) } else { ifn_1873 = nil }; var arg_1874 any = futures__9; if linked_1872 == nil { arg_1869 = ifn_1873.Invoke_O__O(arg_1874) } else { arg_1869 = linked_1872.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1871, arg_1874) }; var arg_1870 any = A_arbace_box_build_A_const_121.Invoke_O__O(q__18); if linked_1867 == nil { deps__19 = ifn_1868.Invoke_O_O__O(arg_1869, arg_1870) } else { deps__19 = linked_1867.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1866, arg_1869, arg_1870) }
				var root_1875 any = A_arbace_box_build_A_const_37.GetRawRoot__O(); var linked_1876 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1875, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1877 lang.IFn; if linked_1876 == nil { ifn_1877 = lang.IFn_Cast(root_1875) } else { ifn_1877 = nil }; var arg_1878 any = futures__9; var arg_1879 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var arg_1880 any = A_arbace_box_build_A_const_91.Invoke_O__O(q__18); var arg_1881 any; var tmp6 any; var and__1927000168__auto____20 any = only__8
				if jrt.J2g_Truth(and__1927000168__auto____20) { var root_1882 any = A_arbace_box_build_A_const_73.GetRawRoot__O(); var linked_1883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1882, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1884 lang.IFn; if linked_1883 == nil { ifn_1884 = lang.IFn_Cast(root_1882) } else { ifn_1884 = nil }; var arg_1885 any = lang.IFn_Cast(only__8).Invoke_O__O(A_arbace_box_build_A_const_91.Invoke_O__O(q__18)); if linked_1883 == nil { tmp6 = ifn_1884.Invoke_O__O(arg_1885) } else { tmp6 = linked_1883.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1882, arg_1885) } } else { tmp6 = and__1927000168__auto____20 }; if jrt.J2g_Truth(tmp6) { var tmp7 any = A_arbace_box_build_archives_fn__598000252_A_New_O_O(given__7, q__18); var tmp8 *jrt.Class; var fncls__1891 *jrt.Class = A_arbace_box_build_archives_fn__598000252_A_fn_class
					if fncls__1891 == nil { var fncls__1891d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_box_build_archives_fn__598000252_A_fn_class = fncls__1891d; tmp8 = fncls__1891d } else { tmp8 = fncls__1891 }
//line :310:1
					arg_1881 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)) } else {

						var root_1892 any = A_arbace_box_build_A_const_145.GetRawRoot__O(); var linked_1893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1892, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_1894 lang.IFn; if linked_1893 == nil { ifn_1894 = lang.IFn_Cast(root_1892) } else { ifn_1894 = nil }; var arg_1895 any; var tmp9 any = A_arbace_box_build_archives_fn__598000254_A_New_O_O_O_O_O_O(index__6, p__3, deps__19, sem__10, conveyed__11, q__18); var tmp10 *jrt.Class; var fncls__1920 *jrt.Class = A_arbace_box_build_archives_fn__598000254_A_fn_class; if fncls__1920 == nil { var fncls__1920d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_box_build_archives_fn__598000254_A_fn_class = fncls__1920d; tmp10 = fncls__1920d } else { tmp10 = fncls__1920 }; arg_1895 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); if linked_1893 == nil { arg_1881 = ifn_1894.Invoke_O__O(arg_1895) } else { arg_1881 = linked_1893.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_1892, arg_1895) } }
//line :309:1
				if linked_1876 == nil { ifn_1877.Invoke_O_O_O_O__O(arg_1878, arg_1879, arg_1880, arg_1881) } else { linked_1876.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1875, arg_1878, arg_1879, arg_1880, arg_1881) }
//line :307:1
				seq_598000248__14, chunk_598000249__15, count_598000250__16, i_598000251__17 = seq_598000248__14, chunk_598000249__15, count_598000250__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_598000251__17); continue L1 } else { var temp__1927000414__auto____18 any; var root_1850 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1850, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1852 lang.IFn; if linked_1851 == nil { ifn_1852 = lang.IFn_Cast(root_1850) } else { ifn_1852 = nil }; var arg_1853 any = seq_598000248__14; if linked_1851 == nil { temp__1927000414__auto____18 = ifn_1852.Invoke_O__O(arg_1853) } else { temp__1927000414__auto____18 = linked_1851.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1850, arg_1853) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_598000248__19 any = temp__1927000414__auto____18; var tmp11 any; var root_1854 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1854, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1856 lang.IFn; if linked_1855 == nil { ifn_1856 = lang.IFn_Cast(root_1854) } else { ifn_1856 = nil }; var arg_1857 any = seq_598000248__19; if linked_1855 == nil { tmp11 = ifn_1856.Invoke_O__O(arg_1857) } else { tmp11 = linked_1855.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1854, arg_1857) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____20 any; var root_1858 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1858, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1860 lang.IFn; if linked_1859 == nil { ifn_1860 = lang.IFn_Cast(root_1858) } else { ifn_1860 = nil }; var arg_1861 any = seq_598000248__19; if linked_1859 == nil { c__1927000678__auto____20 = ifn_1860.Invoke_O__O(arg_1861) } else { c__1927000678__auto____20 = linked_1859.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1858, arg_1861) }; var tmp12 any; var root_1921 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1921, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1923 lang.IFn; if linked_1922 == nil { ifn_1923 = lang.IFn_Cast(root_1921) } else { ifn_1923 = nil }; var arg_1924 any = seq_598000248__19; if linked_1922 == nil { tmp12 = ifn_1923.Invoke_O__O(arg_1924) } else { tmp12 = linked_1922.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1921, arg_1924) }; seq_598000248__14, chunk_598000249__15, count_598000250__16, i_598000251__17 = tmp12, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var q__20 any; var root_1862 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1862, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1864 lang.IFn; if linked_1863 == nil { ifn_1864 = lang.IFn_Cast(root_1862) } else { ifn_1864 = nil }; var arg_1865 any = seq_598000248__19; if linked_1863 == nil { q__20 = ifn_1864.Invoke_O__O(arg_1865) } else { q__20 = linked_1863.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1862, arg_1865) }; var deps__21 any; var root_1925 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1926 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1925, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1927 lang.IFn
					if linked_1926 == nil { ifn_1927 = lang.IFn_Cast(root_1925) } else { ifn_1927 = nil }; var arg_1928 any; var root_1930 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1930, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1932 lang.IFn; if linked_1931 == nil { ifn_1932 = lang.IFn_Cast(root_1930) } else { ifn_1932 = nil }; var arg_1933 any = futures__9; if linked_1931 == nil { arg_1928 = ifn_1932.Invoke_O__O(arg_1933) } else { arg_1928 = linked_1931.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1930, arg_1933) }; var arg_1929 any = A_arbace_box_build_A_const_121.Invoke_O__O(q__20); if linked_1926 == nil { deps__21 = ifn_1927.Invoke_O_O__O(arg_1928, arg_1929) } else { deps__21 = linked_1926.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1925, arg_1928, arg_1929) }
					var root_1934 any = A_arbace_box_build_A_const_37.GetRawRoot__O(); var linked_1935 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1934, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1936 lang.IFn; if linked_1935 == nil { ifn_1936 = lang.IFn_Cast(root_1934) } else { ifn_1936 = nil }; var arg_1937 any = futures__9; var arg_1938 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var arg_1939 any = A_arbace_box_build_A_const_91.Invoke_O__O(q__20); var arg_1940 any; var tmp13 any; var and__1927000168__auto____22 any = only__8
					if jrt.J2g_Truth(and__1927000168__auto____22) { var root_1941 any = A_arbace_box_build_A_const_73.GetRawRoot__O(); var linked_1942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1941, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1943 lang.IFn; if linked_1942 == nil { ifn_1943 = lang.IFn_Cast(root_1941) } else { ifn_1943 = nil }; var arg_1944 any = lang.IFn_Cast(only__8).Invoke_O__O(A_arbace_box_build_A_const_91.Invoke_O__O(q__20)); if linked_1942 == nil { tmp13 = ifn_1943.Invoke_O__O(arg_1944) } else { tmp13 = linked_1942.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1941, arg_1944) } } else { tmp13 = and__1927000168__auto____22 }; if jrt.J2g_Truth(tmp13) { var tmp14 any = A_arbace_box_build_archives_fn__598000260_A_New_O_O(given__7, q__20); var tmp15 *jrt.Class; var fncls__1950 *jrt.Class = A_arbace_box_build_archives_fn__598000260_A_fn_class
						if fncls__1950 == nil { var fncls__1950d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_box_build_archives_fn__598000260_A_fn_class = fncls__1950d; tmp15 = fncls__1950d } else { tmp15 = fncls__1950 }
//line :310:1
						arg_1940 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil)) } else {

							var root_1951 any = A_arbace_box_build_A_const_145.GetRawRoot__O(); var linked_1952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1951, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_1953 lang.IFn; if linked_1952 == nil { ifn_1953 = lang.IFn_Cast(root_1951) } else { ifn_1953 = nil }; var arg_1954 any; var tmp16 any = A_arbace_box_build_archives_fn__598000262_A_New_O_O_O_O_O_O(index__6, p__3, deps__21, sem__10, conveyed__11, q__20); var tmp17 *jrt.Class; var fncls__1979 *jrt.Class = A_arbace_box_build_archives_fn__598000262_A_fn_class; if fncls__1979 == nil { var fncls__1979d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_box_build_archives_fn__598000262_A_fn_class = fncls__1979d; tmp17 = fncls__1979d } else { tmp17 = fncls__1979 }; arg_1954 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); if linked_1952 == nil { arg_1940 = ifn_1953.Invoke_O__O(arg_1954) } else { arg_1940 = linked_1952.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_1951, arg_1954) } }
//line :309:1
					if linked_1935 == nil { ifn_1936.Invoke_O_O_O_O__O(arg_1937, arg_1938, arg_1939, arg_1940) } else { linked_1935.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1934, arg_1937, arg_1938, arg_1939, arg_1940) }
//line :307:1
					var tmp18 any; var root_1980 any = A_arbace_box_build_A_const_20.GetRawRoot__O(); var linked_1981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1980, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1982 lang.IFn; if linked_1981 == nil { ifn_1982 = lang.IFn_Cast(root_1980) } else { ifn_1982 = nil }; var arg_1983 any = seq_598000248__19; if linked_1981 == nil { tmp18 = ifn_1982.Invoke_O__O(arg_1983) } else { tmp18 = linked_1981.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1980, arg_1983) }; seq_598000248__14, chunk_598000249__15, count_598000250__16, i_598000251__17 = tmp18, nil, 0, 0; continue L1 } } }
//line :291:1
			break L1
		}



























		var root_1758 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1760 lang.IFn; if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1762 any; var iter__1927001039__auto____14 any; var tmp19 any = A_arbace_box_build_archives_iter__598000268__598000272_A_New(); var tmp20 *jrt.Class; var fncls__1829 *jrt.Class = A_arbace_box_build_archives_iter__598000268__598000272_A_fn_class; if fncls__1829 == nil { var fncls__1829d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_box_build_archives_iter__598000268__598000272_A_fn_class = fncls__1829d; tmp20 = fncls__1829d } else { tmp20 = fncls__1829 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); var tmp21 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____14); var tmp22 any; var root_1830 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1830, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1832 lang.IFn; if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any = futures__9; if linked_1831 == nil { tmp22 = ifn_1832.Invoke_O__O(arg_1833) } else { tmp22 = linked_1831.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1830, arg_1833) }; arg_1762 = tmp21.Invoke_O__O(tmp22); if linked_1759 == nil { tmp5 = ifn_1760.Invoke_O_O__O(arg_1761, arg_1762) } else { tmp5 = linked_1759.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1758, arg_1761, arg_1762) } }; return nil }(); var root_1834 any = /*line :291:1*/A_arbace_box_build_A_const_80.GetRawRoot__O(); var linked_1835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1834, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1836 lang.IFn; if














	linked_1835 == nil { ifn_1836 = lang.IFn_Cast(root_1834) } else { ifn_1836 = nil }; if linked_1835 == nil { ifn_1836.Invoke__O() } else { linked_1835.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1834) }; if /*line :291:1*/ tmp23 != nil { panic(tmp23) }; return tmp5 }







func A_arbace_box_build_archives_fn__598000242_A_New() *A_arbace_box_build_archives_fn__598000242_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000242_A{}; t.Ctor(); return t }
//line :299:1
func (t *A_arbace_box_build_archives_fn__598000242_A) Ctor() {}
//line :299:1
func (t *A_arbace_box_build_archives_fn__598000242_A) Invoke_O_O_O__O(self, i__1, q__2 any) any { return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_91.Invoke_O__O(q__2), i__1) }





func A_arbace_box_build_archives_conveyed__598000244_A_New_O(p0 any) *A_arbace_box_build_archives_conveyed__598000244_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_conveyed__598000244_A{}; t.Ctor_O(p0); return t }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_A) Invoke_O_O__O(self, f__1 any) any { var o__2 any = t.F_opts; var tmp1 any = A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_New_O_O(f__1, o__2); var tmp2 *jrt.Class; var fncls__1756 *jrt.Class = A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_fn_class; if fncls__1756 == nil { var fncls__1756d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_fn_class = fncls__1756d; tmp2 = fncls__1756d } else { tmp2 = fncls__1756 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :305:1
func A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A{}; t.Ctor_O_O(p0, p1); return t }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A) Ctor_O_O(c__f, c__o any) { t.F_f = c__f; t.F_o = c__o }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A) Invoke_O__O(self any) any { var root_1747 any = A_arbace_box_build_A_const_81.GetRawRoot__O(); var linked_1748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1747, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1749 lang.IFn; if linked_1748 == nil { ifn_1749 = lang.IFn_Cast(root_1747) } else { ifn_1749 = nil }; var arg_1750 any = lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, t.F_o); if linked_1748 == nil { ifn_1749.Invoke_O__O(arg_1750) } else { linked_1748.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1747, arg_1750) }; var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(t.F_f).Invoke__O(); return nil }(); var root_1744 any = A_arbace_box_build_A_const_80.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; if linked_1745 == nil { ifn_1746.Invoke__O() } else { linked_1745.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1744) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }





func A_arbace_box_build_archives_fn__598000252_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_fn__598000252_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000252_A{}; t.Ctor_O_O(p0, p1); return t }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000252_A) Ctor_O_O(c__given, c__q any) { t.F_given = c__given; t.F_q = c__q }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000252_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var tmp1 any; var t_ any = t.F_given; t.F_given = nil; tmp1 = t_; or__1927000174__auto____1 = lang.RT_Get_O_O__O_NoInit(tmp1, A_arbace_box_build_A_const_91.Invoke_O__O(t.F_q)); if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { var root_1886 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_1887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1886, A_arbace_box_build_fail_A_fn_class); var ifn_1888 lang.IFn; if linked_1887 == nil { ifn_1888 = lang.IFn_Cast(root_1886) } else { ifn_1888 = nil }; var arg_1889 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil); var tmp3 *lang.Keyword = A_arbace_box_build_A_const_91; var tmp4 any; var t__2 any = t.F_q; t.F_q = nil; tmp4 = t__2; arg_1889 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3.Invoke_O__O(tmp4))).Ref(); var arg_1890 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1887 == nil { return ifn_1888.Invoke_O_O__O(arg_1889, arg_1890) } else { return linked_1887.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_1886, arg_1889, arg_1890) } } }
//line :311:1
func A_arbace_box_build_archives_fn__598000260_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_fn__598000260_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000260_A{}; t.Ctor_O_O(p0, p1); return t }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000260_A) Ctor_O_O(c__given, c__q any) { t.F_given = c__given; t.F_q = c__q }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000260_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var tmp1 any; var t_ any = t.F_given; t.F_given = nil; tmp1 = t_; or__1927000174__auto____1 = lang.RT_Get_O_O__O_NoInit(tmp1, A_arbace_box_build_A_const_91.Invoke_O__O(t.F_q)); if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { var root_1945 any = A_arbace_box_build_A_const_67.GetRawRoot__O(); var linked_1946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1945, A_arbace_box_build_fail_A_fn_class); var ifn_1947 lang.IFn; if linked_1946 == nil { ifn_1947 = lang.IFn_Cast(root_1945) } else { ifn_1947 = nil }; var arg_1948 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil); var tmp3 *lang.Keyword = A_arbace_box_build_A_const_91; var tmp4 any; var t__2 any = t.F_q; t.F_q = nil; tmp4 = t__2; arg_1948 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3.Invoke_O__O(tmp4))).Ref(); var arg_1949 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1946 == nil { return ifn_1947.Invoke_O_O__O(arg_1948, arg_1949) } else { return linked_1946.(*A_arbace_box_build_fail_A).Invoke_O_O_O__O(root_1945, arg_1948, arg_1949) } } }
func A_arbace_box_build_archives_fn__598000254_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_box_build_archives_fn__598000254_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000254_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000254_A) Ctor_O_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__conveyed, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_conveyed = c__conveyed; t.F_q = c__q }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000254_A) Invoke_O__O(self any) any {
	var tmp1 any; var t_ any = t.F_conveyed; t.F_conveyed = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any = A_arbace_box_build_archives_fn__598000254_fn__598000255_A_New_O_O_O_O_O(t.F_index, t.F_p, t.F_deps, t.F_sem, t.F_q); var tmp4 *jrt.Class; var fncls__1919 *jrt.Class = A_arbace_box_build_archives_fn__598000254_fn__598000255_A_fn_class
	if fncls__1919 == nil { var fncls__1919d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_box_build_archives_fn__598000254_fn__598000255_A_fn_class = fncls__1919d; tmp4 = fncls__1919d } else { tmp4 = fncls__1919 }
//line :313:1
	return lang.IFn_Cast(tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil))).Invoke__O() }
//line :312:1
func A_arbace_box_build_archives_fn__598000262_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_box_build_archives_fn__598000262_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000262_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000262_A) Ctor_O_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__conveyed, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_conveyed = c__conveyed; t.F_q = c__q }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000262_A) Invoke_O__O(self any) any {
	var tmp1 any; var t_ any = t.F_conveyed; t.F_conveyed = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any = A_arbace_box_build_archives_fn__598000262_fn__598000263_A_New_O_O_O_O_O(t.F_index, t.F_p, t.F_deps, t.F_sem, t.F_q); var tmp4 *jrt.Class; var fncls__1978 *jrt.Class = A_arbace_box_build_archives_fn__598000262_fn__598000263_A_fn_class
	if fncls__1978 == nil { var fncls__1978d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_box_build_archives_fn__598000262_fn__598000263_A_fn_class = fncls__1978d; tmp4 = fncls__1978d } else { tmp4 = fncls__1978 }
//line :313:1
	return lang.IFn_Cast(tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil))).Invoke__O() }
func A_arbace_box_build_archives_fn__598000254_fn__598000255_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_box_build_archives_fn__598000254_fn__598000255_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000254_fn__598000255_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_A) Ctor_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_q = c__q }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_A) Invoke_O__O(self any) any { var archives__1 any; var root_1896 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1896, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1898 lang.IFn; if
												linked_1897 == nil { ifn_1898 = lang.IFn_Cast(root_1896) } else { ifn_1898 = nil }; var arg_1899 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1900 any; var root_1901 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1901, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1903 lang.IFn; if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any; var tmp1 any = A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_New(); var tmp2 *jrt.Class; var fncls__1911 *jrt.Class = A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_fn_class; if fncls__1911 == nil { var fncls__1911d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_fn_class = fncls__1911d; tmp2 = fncls__1911d } else { tmp2 = fncls__1911 }; arg_1904 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1905 any = A_arbace_box_build_A_const_121.Invoke_O__O(t.F_q); var arg_1906 any = t.F_deps; if linked_1902 == nil { arg_1900 = ifn_1903.Invoke_O_O_O__O(arg_1904, arg_1905, arg_1906) } else { arg_1900 = linked_1902.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1901, arg_1904, arg_1905, arg_1906) }; if linked_1897 == nil { archives__1 = ifn_1898.Invoke_O_O__O(arg_1899, arg_1900) } else { archives__1 = linked_1897.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1896, arg_1899, arg_1900) };
												jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Acquire__V(); var tmp3 any; tmp4 := /*line :314:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		{ var root_1912 any = A_arbace_box_build_A_const_176.GetRawRoot__O(); var linked_1913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1912, A_arbace_box_build_build_package_A_fn_class); var ifn_1914 lang.IFn; if linked_1913 == nil { ifn_1914 = lang.IFn_Cast(root_1912) } else { ifn_1914 = nil }; var arg_1915 any = t.F_p; var arg_1916 any = t.F_q; var arg_1917 any = archives__1; var arg_1918 any = t.F_index; if linked_1913 == nil { tmp3 = ifn_1914.Invoke_O_O_O_O__O(arg_1915, arg_1916, arg_1917, arg_1918) } else { tmp3 = linked_1913.(*A_arbace_box_build_build_package_A).Invoke_O_O_O_O_O__O(root_1912, arg_1915, arg_1916, arg_1917, arg_1918) } }
//line :314:1
		return nil }();




	jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Release__V(); if /*line :314:1*/ tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :314:1
func A_arbace_box_build_archives_fn__598000262_fn__598000263_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_box_build_archives_fn__598000262_fn__598000263_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000262_fn__598000263_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_A) Ctor_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_q = c__q }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_A) Invoke_O__O(self any) any { var archives__1 any; var root_1955 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1955, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1957 lang.IFn; if
												linked_1956 == nil { ifn_1957 = lang.IFn_Cast(root_1955) } else { ifn_1957 = nil }; var arg_1958 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1959 any; var root_1960 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_1961 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1960, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1962 lang.IFn; if linked_1961 == nil { ifn_1962 = lang.IFn_Cast(root_1960) } else { ifn_1962 = nil }; var arg_1963 any; var tmp1 any = A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_New(); var tmp2 *jrt.Class; var fncls__1970 *jrt.Class = A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_fn_class; if fncls__1970 == nil { var fncls__1970d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_fn_class = fncls__1970d; tmp2 = fncls__1970d } else { tmp2 = fncls__1970 }; arg_1963 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1964 any = A_arbace_box_build_A_const_121.Invoke_O__O(t.F_q); var arg_1965 any = t.F_deps; if linked_1961 == nil { arg_1959 = ifn_1962.Invoke_O_O_O__O(arg_1963, arg_1964, arg_1965) } else { arg_1959 = linked_1961.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1960, arg_1963, arg_1964, arg_1965) }; if linked_1956 == nil { archives__1 = ifn_1957.Invoke_O_O__O(arg_1958, arg_1959) } else { archives__1 = linked_1956.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1955, arg_1958, arg_1959) };
												jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Acquire__V(); var tmp3 any; tmp4 := /*line :314:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		{ var root_1971 any = A_arbace_box_build_A_const_176.GetRawRoot__O(); var linked_1972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1971, A_arbace_box_build_build_package_A_fn_class); var ifn_1973 lang.IFn; if linked_1972 == nil { ifn_1973 = lang.IFn_Cast(root_1971) } else { ifn_1973 = nil }; var arg_1974 any = t.F_p; var arg_1975 any = t.F_q; var arg_1976 any = archives__1; var arg_1977 any = t.F_index; if linked_1972 == nil { tmp3 = ifn_1973.Invoke_O_O_O_O__O(arg_1974, arg_1975, arg_1976, arg_1977) } else { tmp3 = linked_1972.(*A_arbace_box_build_build_package_A).Invoke_O_O_O_O_O__O(root_1971, arg_1974, arg_1975, arg_1976, arg_1977) } }
//line :314:1
		return nil }();




	jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Release__V(); if /*line :314:1*/ tmp4 != nil { panic(tmp4) }; return tmp3 }
func A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_New() *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A) Ctor() {}
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A) Invoke_O_O_O__O(self, i__1, d__2 any) any { var tmp1 any; var root_1907 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1907, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1909 lang.IFn; if linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = d__2; if linked_1908 == nil { tmp1 = ifn_1909.Invoke_O__O(arg_1910) } else { tmp1 = linked_1908.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1907, arg_1910) }; return lang.Tuple_Create_O_O__IPersistentVector(i__1, tmp1) }
//line :315:1
func A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_New() *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A) Ctor() {}
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A) Invoke_O_O_O__O(self, i__1, d__2 any) any { var tmp1 any; var root_1966 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1966, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1968 lang.IFn; if linked_1967 == nil { ifn_1968 = lang.IFn_Cast(root_1966) } else { ifn_1968 = nil }; var arg_1969 any = d__2; if linked_1967 == nil { tmp1 = ifn_1968.Invoke_O__O(arg_1969) } else { tmp1 = linked_1967.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1966, arg_1969) }; return lang.Tuple_Create_O_O__IPersistentVector(i__1, tmp1) }




func A_arbace_box_build_archives_iter__598000268__598000272_A_New() *A_arbace_box_build_archives_iter__598000268__598000272_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_iter__598000268__598000272_A{}; t.Ctor(); return t }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_A) Ctor() {}
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_A) Invoke_O_O__O(self, s__598000269__1 any) any { var tmp1 any = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_New_O_O(self, s__598000269__1); var tmp2 *jrt.Class; var fncls__1828 *jrt.Class = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_fn_class; if fncls__1828 == nil { var fncls__1828d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_fn_class = fncls__1828d; tmp2 = fncls__1828d } else { tmp2 = fncls__1828 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :320:1
func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A{}; t.Ctor_O_O(p0, p1); return t }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A) Ctor_O_O(c__iter__598000268, c__s__598000269 any) { t.F_iter__598000268 = c__iter__598000268; t.F_s__598000269 = c__s__598000269 }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A) Invoke_O__O(self any) any { { var s__598000269__1 any; var t_ any = t.F_s__598000269; t.F_s__598000269 = nil; s__598000269__1 = t_; for { var temp__1927000414__auto____2 any; var root_1763 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_1764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1763, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1765 lang.IFn; if linked_1764 == nil { ifn_1765 = lang.IFn_Cast(root_1763) } else { ifn_1765 = nil }; var arg_1766 any = s__598000269__1; if linked_1764 == nil { temp__1927000414__auto____2 = ifn_1765.Invoke_O__O(arg_1766) } else { temp__1927000414__auto____2 = linked_1764.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1763, arg_1766) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000269__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1767 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_1768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1767, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1769 lang.IFn; if linked_1768 == nil { ifn_1769 = lang.IFn_Cast(root_1767) } else { ifn_1769 = nil }; var arg_1770 any = s__598000269__3; if linked_1768 == nil { tmp1 = ifn_1769.Invoke_O__O(arg_1770) } else { tmp1 = linked_1768.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1767, arg_1770) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1771 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_1772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1771, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1773 lang.IFn; if linked_1772 == nil { ifn_1773 = lang.IFn_Cast(root_1771) } else { ifn_1773 = nil }; var arg_1774 any = s__598000269__3; if linked_1772 == nil { c__1927001037__auto____4 = ifn_1773.Invoke_O__O(arg_1774) } else { c__1927001037__auto____4 = linked_1772.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1771, arg_1774) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000271__6 any; var root_1775 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_1776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1775, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1777 lang.IFn; if linked_1776 == nil { ifn_1777 = lang.IFn_Cast(root_1775) } else { ifn_1777 = nil }; var arg_1778 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1776 == nil { b__598000271__6 = ifn_1777.Invoke_O__O(arg_1778) } else { b__598000271__6 = linked_1776.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1775, arg_1778) }; var tmp2 any = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_New_O_I_O(b__598000271__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1788 *jrt.Class = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_fn_class; if fncls__1788 == nil { var fncls__1788d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_fn_class = fncls__1788d; tmp3 = fncls__1788d } else { tmp3 = fncls__1788 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1789 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1789, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1791 lang.IFn; if linked_1790 == nil { ifn_1791 = lang.IFn_Cast(root_1789) } else { ifn_1791 = nil }; var arg_1792 any; var root_1794 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1794, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1796 lang.IFn; if linked_1795 == nil { ifn_1796 = lang.IFn_Cast(root_1794) } else { ifn_1796 = nil }; var arg_1797 any = b__598000271__6; if linked_1795 == nil { arg_1792 = ifn_1796.Invoke_O__O(arg_1797) } else { arg_1792 = linked_1795.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1794, arg_1797) }; var arg_1793 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000268); var tmp5 any; var root_1798 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_1799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1798, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1800 lang.IFn; if linked_1799 == nil { ifn_1800 = lang.IFn_Cast(root_1798) } else { ifn_1800 = nil }; var arg_1801 any = s__598000269__3; if linked_1799 == nil { tmp5 = ifn_1800.Invoke_O__O(arg_1801) } else { tmp5 = linked_1799.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1798, arg_1801) }; arg_1793 = tmp4.Invoke_O__O(tmp5); if linked_1790 == nil { return ifn_1791.Invoke_O_O__O(arg_1792, arg_1793) } else { return linked_1790.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1789, arg_1792, arg_1793) } } else { var root_1802 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_1803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1802, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1804 lang.IFn; if linked_1803 == nil { ifn_1804 = lang.IFn_Cast(root_1802) } else { ifn_1804 = nil }; var arg_1805 any; var root_1807 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_1808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1807, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1809 lang.IFn; if linked_1808 == nil { ifn_1809 = lang.IFn_Cast(root_1807) } else { ifn_1809 = nil }; var arg_1810 any = b__598000271__6; if linked_1808 == nil { arg_1805 = ifn_1809.Invoke_O__O(arg_1810) } else { arg_1805 = linked_1808.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1807, arg_1810) }; var arg_1806 any; if linked_1803 == nil { return ifn_1804.Invoke_O_O__O(arg_1805, arg_1806) } else { return linked_1803.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1802, arg_1805, arg_1806) } } } else { var vec__598000279__4 any; var root_1811 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_1812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1811, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1813 lang.IFn; if linked_1812 == nil { ifn_1813 = lang.IFn_Cast(root_1811) } else { ifn_1813 = nil }; var arg_1814 any = s__598000269__3; if linked_1812 == nil { vec__598000279__4 = ifn_1813.Invoke_O__O(arg_1814) } else { vec__598000279__4 = linked_1812.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1811, arg_1814) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000279__4, lang.RT_IntCast_J__I_NoInit(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000279__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1815 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_1816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1815, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1817 lang.IFn; if linked_1816 == nil { ifn_1817 = lang.IFn_Cast(root_1815) } else { ifn_1817 = nil }; var arg_1818 any; var tmp6 any; var root_1820 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1820, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1822 lang.IFn; if linked_1821 == nil { ifn_1822 = lang.IFn_Cast(root_1820) } else { ifn_1822 = nil }; var arg_1823 any = f__6; if linked_1821 == nil { tmp6 = ifn_1822.Invoke_O__O(arg_1823) } else { tmp6 = linked_1821.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1820, arg_1823) }; arg_1818 = lang.Tuple_Create_O_O__IPersistentVector(k__5, tmp6); var arg_1819 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__598000268); var tmp8 any; var root_1824 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_1825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1824, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1826 lang.IFn; if linked_1825 == nil { ifn_1826 = lang.IFn_Cast(root_1824) } else { ifn_1826 = nil }; var arg_1827 any = s__598000269__3; if linked_1825 == nil { tmp8 = ifn_1826.Invoke_O__O(arg_1827) } else { tmp8 = linked_1825.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1824, arg_1827) }; arg_1819 = tmp7.Invoke_O__O(tmp8); if linked_1816 == nil { return ifn_1817.Invoke_O_O__O(arg_1818, arg_1819) } else { return linked_1816.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1815, arg_1818, arg_1819) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :320:1
func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A) Ctor_O_I_O(c__b__598000271 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000271 = c__b__598000271; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A) Invoke_O__O(self any) any { { var i__598000270__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000270__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000275__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000270__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000275__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000275__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1779 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1779, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1781 lang.IFn; if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any = t.F_b__598000271; var arg_1783 any; var tmp2 any; var root_1784 any = A_arbace_box_build_A_const_7.GetRawRoot__O(); var linked_1785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1784, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1786 lang.IFn; if linked_1785 == nil { ifn_1786 = lang.IFn_Cast(root_1784) } else { ifn_1786 = nil }; var arg_1787 any = f__4; if linked_1785 == nil { tmp2 = ifn_1786.Invoke_O__O(arg_1787) } else { tmp2 = linked_1785.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1784, arg_1787) }; arg_1783 = lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp2); if linked_1780 == nil { ifn_1781.Invoke_O_O__O(arg_1782, arg_1783) } else { linked_1780.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1779, arg_1782, arg_1783) }; i__598000270__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000270__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_box_build_link_A_New() *A_arbace_box_build_link_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_box_build_link_A) Ctor() {}
//line :322:1
func (t *A_arbace_box_build_link_A) Invoke_O_O_O_O__O(self, plan__0, archives__1, opts__2 any) any { var p__4 any; var root_1984 any = A_arbace_box_build_A_const_169.GetRawRoot__O(); var linked_1985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1984, A_arbace_box_build_read_plan_A_fn_class); var ifn_1986 lang.IFn; if




	linked_1985 == nil { ifn_1986 = lang.IFn_Cast(root_1984) } else { ifn_1986 = nil }; var arg_1987 any = plan__0; if linked_1985 == nil { p__4 = ifn_1986.Invoke_O__O(arg_1987) } else { p__4 = linked_1985.(*A_arbace_box_build_read_plan_A).Invoke_O_O__O(root_1984, arg_1987) }; var opts__5 any; var root_1988 any = /*line :322:1*/A_arbace_box_build_A_const_170.GetRawRoot__O(); var linked_1989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1988, A_arbace_box_build_with_tools_A_fn_class); var ifn_1990 lang.IFn; if





	linked_1989 == nil { ifn_1990 = lang.IFn_Cast(root_1988) } else { ifn_1990 = nil }; var arg_1991 any = p__4; var arg_1992 any = opts__2; if linked_1989 == nil { opts__5 = ifn_1990.Invoke_O_O__O(arg_1991, arg_1992) } else { opts__5 = linked_1989.(*A_arbace_box_build_with_tools_A).Invoke_O_O_O__O(root_1988, arg_1991, arg_1992) }; var pkgs__6 any = /*line :322:1*/A_arbace_box_build_A_const_41.Invoke_O__O(p__4); var index__7 any; var root_1993 any = A_arbace_box_build_A_const_21.GetRawRoot__O(); var linked_1994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1993, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1995 lang.IFn; if







	linked_1994 == nil { ifn_1995 = lang.IFn_Cast(root_1993) } else { ifn_1995 = nil }; var arg_1996 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1997 any; var root_1998 any = A_arbace_box_build_A_const_171.GetRawRoot__O(); var linked_1999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1998, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2000 lang.IFn; if linked_1999 == nil { ifn_2000 = lang.IFn_Cast(root_1998) } else { ifn_2000 = nil }; var arg_2001 any; var tmp1 any = A_arbace_box_build_link_fn__598000285_A_New(); var tmp2 *jrt.Class; var fncls__2003 *jrt.Class = A_arbace_box_build_link_fn__598000285_A_fn_class; if fncls__2003 == nil { var fncls__2003d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_box_build_link_fn__598000285_A_fn_class = fncls__2003d; tmp2 = fncls__2003d } else { tmp2 = fncls__2003 }; arg_2001 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2002 any = pkgs__6; if linked_1999 == nil { arg_1997 = ifn_2000.Invoke_O_O__O(arg_2001, arg_2002) } else { arg_1997 = linked_1999.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1998, arg_2001, arg_2002) }; if linked_1994 == nil { index__7 = ifn_1995.Invoke_O_O__O(arg_1996, arg_1997) } else { index__7 = linked_1994.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1993, arg_1996, arg_1997) }; var root_2121 any =
	A_arbace_box_build_A_const_81.GetRawRoot__O(); var linked_2122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2121, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2123 lang.IFn; if linked_2122 == nil { ifn_2123 = lang.IFn_Cast(root_2121) } else { ifn_2123 = nil }; var arg_2124 any = lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, opts__5); if linked_2122 == nil { ifn_2123.Invoke_O__O(arg_2124) } else { linked_2122.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2121, arg_2124) }; var tmp3 any; tmp19 := /*line :322:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var paths__10 any; var root_2004 any = A_arbace_box_build_A_const_108.GetRawRoot__O(); var linked_2005 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2004, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2006 lang.IFn









		if linked_2005 == nil { ifn_2006 = lang.IFn_Cast(root_2004) } else { ifn_2006 = nil }; var arg_2007 any = A_arbace_box_build_A_const_91; var arg_2008 any = pkgs__6; if linked_2005 == nil { paths__10 = ifn_2006.Invoke_O_O__O(arg_2007, arg_2008) } else { paths__10 = linked_2005.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2004, arg_2007, arg_2008) }
//line :322:1
		var vec__598000287__11 any; var root_2009 any = A_arbace_box_build_A_const_122.GetRawRoot__O(); var linked_2010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2009, A_arbace_box_build_deps_tree_A_fn_class); var ifn_2011 lang.IFn










		if linked_2010 == nil { ifn_2011 = lang.IFn_Cast(root_2009) } else { ifn_2011 = nil }; var arg_2012 any = archives__1; var arg_2013 any = index__7; var arg_2014 any = paths__10; if linked_2010 == nil { vec__598000287__11 = ifn_2011.Invoke_O_O_O__O(arg_2012, arg_2013, arg_2014) } else { vec__598000287__11 = linked_2010.(*A_arbace_box_build_deps_tree_A).Invoke_O_O_O_O__O(root_2009, arg_2012, arg_2013, arg_2014) }
//line :322:1
		var dtree__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000287__11, lang.RT_IntCast_J__I_NoInit(0), nil); var lines__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__598000287__11, lang.RT_IntCast_J__I_NoInit(1), nil); var cfg__14 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil); var tmp5 any; var root_2015 any = A_arbace_box_build_A_const_51.GetRawRoot__O(); var linked_2016 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2015, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2017 lang.IFn











		if linked_2016 == nil { ifn_2017 = lang.IFn_Cast(root_2015) } else { ifn_2017 = nil }; var arg_2018 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var arg_2019 any; var iter__1927001039__auto____16 any; var tmp6 any = A_arbace_box_build_link_iter__598000290__598000294_A_New(); var tmp7 *jrt.Class; var fncls__2078 *jrt.Class = A_arbace_box_build_link_iter__598000290__598000294_A_fn_class; if fncls__2078 == nil { var fncls__2078d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_box_build_link_iter__598000290__598000294_A_fn_class = fncls__2078d; tmp7 = fncls__2078d } else { tmp7 = fncls__2078 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); arg_2019 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(lines__13); if linked_2016 == nil { tmp5 = ifn_2017.Invoke_O_O__O(arg_2018, arg_2019) } else { tmp5 = linked_2016.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2015, arg_2018, arg_2019) }; cfg__14 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref()
//line :322:1
		var res__15 any; var root_2079 any = A_arbace_box_build_A_const_79.GetRawRoot__O(); var linked_2080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2079, A_arbace_box_build_action_STAR__A_fn_class); var ifn_2081 lang.IFn












		if linked_2080 == nil { ifn_2081 = lang.IFn_Cast(root_2079) } else { ifn_2081 = nil }; var arg_2082 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_130), jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_177.Invoke_O__O(p__4), nil)).Ref(); var arg_2083 any; var root_2084 any = A_arbace_box_build_A_const_124.GetRawRoot__O(); var linked_2085 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2084, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_2086 lang.IFn
		if linked_2085 == nil { ifn_2086 = lang.IFn_Cast(root_2084) } else { ifn_2086 = nil }; var arg_2087 any; var tmp8 any = A_arbace_box_build_A_const_138; var tmp9 *lang.Keyword = A_arbace_box_build_A_const_178; var tmp10 any = tmp9.Invoke_O__O(A_arbace_box_build_A_const_120.Invoke_O__O(opts__5)); var tmp11 any = A_arbace_box_build_A_const_78; var tmp12 any; var root_2089 any = A_arbace_box_build_A_const_90.GetRawRoot__O(); var linked_2090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2089, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2091 lang.IFn

		if linked_2090 == nil { ifn_2091 = lang.IFn_Cast(root_2089) } else { ifn_2091 = nil }; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_86.GetRawRoot__O()); var tmp14 any = A_arbace_box_build_A_const_179; var arg_2092 any = tmp13.Invoke_O_O_O__O(tmp14, A_arbace_box_build_A_const_180.Invoke_O_O__O(opts__5, A_arbace_box_build_A_const_181), lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_131, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(index__7).Invoke_O__O(A_arbace_box_build_A_const_177.Invoke_O__O(p__4)), nil)).Ref())); if linked_2090 == nil { tmp12 = ifn_2091.Invoke_O__O(arg_2092) } else { tmp12 = linked_2090.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2089, arg_2092) }
//line :336:1
		var tmp15 any = tmp12; var tmp16 any = A_arbace_box_build_A_const_141; var tmp17 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_63, dtree__12); var tmp18 any; var root_2099 any = A_arbace_box_build_A_const_142.GetRawRoot__O(); var linked_2100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2099, A_arbace_box_build_file_tree_A_fn_class); var ifn_2101 lang.IFn




		if linked_2100 == nil { ifn_2101 = lang.IFn_Cast(root_2099) } else { ifn_2101 = nil }; var arg_2102 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_132, cfg__14)); if linked_2100 == nil { tmp18 = ifn_2101.Invoke_O__O(arg_2102) } else { tmp18 = linked_2100.(*A_arbace_box_build_file_tree_A).Invoke_O_O__O(root_2099, arg_2102) }
//line :336:1
		arg_2087 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp10, tmp11, tmp15, tmp16, lang.Tuple_Create_O_O__IPersistentVector(tmp17, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp18)), A_arbace_box_build_A_const_84, Lit_133, A_arbace_box_build_A_const_182, Lit_133)); var arg_2088 any; var root_2103 any = A_arbace_box_build_A_const_161.GetRawRoot__O(); var linked_2104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2103, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2105 lang.IFn






		if linked_2104 == nil { ifn_2105 = lang.IFn_Cast(root_2103) } else { ifn_2105 = nil }; var arg_2106 any = lang.RT_Get_O_O__O_NoInit(A_arbace_box_build_A_const_126.Invoke_O__O(opts__5), A_arbace_box_build_A_const_178); var arg_2107 any = A_arbace_box_build_A_const_183; if linked_2104 == nil { arg_2088 = ifn_2105.Invoke_O_O__O(arg_2106, arg_2107) } else { arg_2088 = linked_2104.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2103, arg_2106, arg_2107) }
//line :336:1
		if linked_2085 == nil { arg_2083 = ifn_2086.Invoke_O_O__O(arg_2087, arg_2088) } else { arg_2083 = linked_2085.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_2084, arg_2087, arg_2088) }
//line :335:1
		if linked_2080 == nil { res__15 = ifn_2081.Invoke_O_O__O(arg_2082, arg_2083) } else { res__15 = linked_2080.(*A_arbace_box_build_action_STAR__A).Invoke_O_O_O__O(root_2079, arg_2082, arg_2083)
		}







		var root_2108 any = A_arbace_box_build_A_const_147.GetRawRoot__O(); var linked_2109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2108, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2110 lang.IFn; if linked_2109 == nil { ifn_2110 = lang.IFn_Cast(root_2108) } else { ifn_2110 = nil }; var arg_2111 any; var root_2112 any = A_arbace_box_build_A_const_137.GetRawRoot__O(); var linked_2113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2112, A_arbace_box_build_out_file_A_fn_class); var ifn_2114 lang.IFn; if linked_2113 == nil { ifn_2114 = lang.IFn_Cast(root_2112) } else { ifn_2114 = nil }; var arg_2115 any = res__15; var arg_2116 any = A_arbace_box_build_A_const_177.Invoke_O__O(p__4); var arg_2117 any = Lit_134; if linked_2113 == nil { arg_2111 = ifn_2114.Invoke_O_O_O__O(arg_2115, arg_2116, arg_2117) } else { arg_2111 = linked_2113.(*A_arbace_box_build_out_file_A).Invoke_O_O_O_O__O(root_2112, arg_2115, arg_2116, arg_2117) }; if linked_2109 == nil { tmp3 = ifn_2110.Invoke_O__O(arg_2111) } else { tmp3 = linked_2109.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2108, arg_2111) } }; return nil }(); var root_2118 any = /*line :322:1*/A_arbace_box_build_A_const_80.GetRawRoot__O(); var linked_2119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2118, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2120 lang.IFn; if








	linked_2119 == nil { ifn_2120 = lang.IFn_Cast(root_2118) } else { ifn_2120 = nil }; if linked_2119 == nil { ifn_2120.Invoke__O() } else { linked_2119.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2118) }; if /*line :322:1*/ tmp19 != nil { panic(tmp19) }; return tmp3 }







func A_arbace_box_build_link_fn__598000285_A_New() *A_arbace_box_build_link_fn__598000285_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_fn__598000285_A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_box_build_link_fn__598000285_A) Ctor() {}
//line :330:1
func (t *A_arbace_box_build_link_fn__598000285_A) Invoke_O_O_O__O(self, i__1, q__2 any) any { return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_91.Invoke_O__O(q__2), i__1) }



func A_arbace_box_build_link_iter__598000290__598000294_A_New() *A_arbace_box_build_link_iter__598000290__598000294_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_iter__598000290__598000294_A{}; t.Ctor(); return t }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_A) Ctor() {}
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_A) Invoke_O_O__O(self, s__598000291__1 any) any { var tmp1 any = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_New_O_O(self, s__598000291__1); var tmp2 *jrt.Class; var fncls__2077 *jrt.Class = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_fn_class; if fncls__2077 == nil { var fncls__2077d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_fn_class = fncls__2077d; tmp2 = fncls__2077d } else { tmp2 = fncls__2077 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :334:1
func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_New_O_O(p0, p1 any) *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A{}; t.Ctor_O_O(p0, p1); return t }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A) Ctor_O_O(c__iter__598000290, c__s__598000291 any) { t.F_iter__598000290 = c__iter__598000290; t.F_s__598000291 = c__s__598000291 }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A) Invoke_O__O(self any) any { { var s__598000291__1 any; var t_ any = t.F_s__598000291; t.F_s__598000291 = nil; s__598000291__1 = t_; for { var temp__1927000414__auto____2 any; var root_2020 any = A_arbace_box_build_A_const_15.GetRawRoot__O(); var linked_2021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2020, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2022 lang.IFn; if linked_2021 == nil { ifn_2022 = lang.IFn_Cast(root_2020) } else { ifn_2022 = nil }; var arg_2023 any = s__598000291__1; if linked_2021 == nil { temp__1927000414__auto____2 = ifn_2022.Invoke_O__O(arg_2023) } else { temp__1927000414__auto____2 = linked_2021.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2020, arg_2023) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__598000291__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2024 any = A_arbace_box_build_A_const_16.GetRawRoot__O(); var linked_2025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2024, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2026 lang.IFn; if linked_2025 == nil { ifn_2026 = lang.IFn_Cast(root_2024) } else { ifn_2026 = nil }; var arg_2027 any = s__598000291__3; if linked_2025 == nil { tmp1 = ifn_2026.Invoke_O__O(arg_2027) } else { tmp1 = linked_2025.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2024, arg_2027) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2028 any = A_arbace_box_build_A_const_17.GetRawRoot__O(); var linked_2029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2028, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2030 lang.IFn; if linked_2029 == nil { ifn_2030 = lang.IFn_Cast(root_2028) } else { ifn_2030 = nil }; var arg_2031 any = s__598000291__3; if linked_2029 == nil { c__1927001037__auto____4 = ifn_2030.Invoke_O__O(arg_2031) } else { c__1927001037__auto____4 = linked_2029.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2028, arg_2031) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__598000293__6 any; var root_2032 any = A_arbace_box_build_A_const_22.GetRawRoot__O(); var linked_2033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2032, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2034 lang.IFn; if linked_2033 == nil { ifn_2034 = lang.IFn_Cast(root_2032) } else { ifn_2034 = nil }; var arg_2035 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2033 == nil { b__598000293__6 = ifn_2034.Invoke_O__O(arg_2035) } else { b__598000293__6 = linked_2033.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2032, arg_2035) }; var tmp2 any = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_New_O_I_O(b__598000293__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2041 *jrt.Class = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_fn_class; if fncls__2041 == nil { var fncls__2041d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_fn_class = fncls__2041d; tmp3 = fncls__2041d } else { tmp3 = fncls__2041 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2042 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_2043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2042, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2044 lang.IFn; if linked_2043 == nil { ifn_2044 = lang.IFn_Cast(root_2042) } else { ifn_2044 = nil }; var arg_2045 any; var root_2047 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_2048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2047, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2049 lang.IFn; if linked_2048 == nil { ifn_2049 = lang.IFn_Cast(root_2047) } else { ifn_2049 = nil }; var arg_2050 any = b__598000293__6; if linked_2048 == nil { arg_2045 = ifn_2049.Invoke_O__O(arg_2050) } else { arg_2045 = linked_2048.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2047, arg_2050) }; var arg_2046 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000290); var tmp5 any; var root_2051 any = A_arbace_box_build_A_const_19.GetRawRoot__O(); var linked_2052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2051, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2053 lang.IFn; if linked_2052 == nil { ifn_2053 = lang.IFn_Cast(root_2051) } else { ifn_2053 = nil }; var arg_2054 any = s__598000291__3; if linked_2052 == nil { tmp5 = ifn_2053.Invoke_O__O(arg_2054) } else { tmp5 = linked_2052.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2051, arg_2054) }; arg_2046 = tmp4.Invoke_O__O(tmp5); if linked_2043 == nil { return ifn_2044.Invoke_O_O__O(arg_2045, arg_2046) } else { return linked_2043.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2042, arg_2045, arg_2046) } } else { var root_2055 any = A_arbace_box_build_A_const_27.GetRawRoot__O(); var linked_2056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2055, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2057 lang.IFn; if linked_2056 == nil { ifn_2057 = lang.IFn_Cast(root_2055) } else { ifn_2057 = nil }; var arg_2058 any; var root_2060 any = A_arbace_box_build_A_const_28.GetRawRoot__O(); var linked_2061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2060, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2062 lang.IFn; if linked_2061 == nil { ifn_2062 = lang.IFn_Cast(root_2060) } else { ifn_2062 = nil }; var arg_2063 any = b__598000293__6; if linked_2061 == nil { arg_2058 = ifn_2062.Invoke_O__O(arg_2063) } else { arg_2058 = linked_2061.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2060, arg_2063) }; var arg_2059 any; if linked_2056 == nil { return ifn_2057.Invoke_O_O__O(arg_2058, arg_2059) } else { return linked_2056.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2055, arg_2058, arg_2059) } } } else { var l__4 any; var root_2064 any = A_arbace_box_build_A_const_18.GetRawRoot__O(); var linked_2065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2064, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2066 lang.IFn; if linked_2065 == nil { ifn_2066 = lang.IFn_Cast(root_2064) } else { ifn_2066 = nil }; var arg_2067 any = s__598000291__3; if linked_2065 == nil { l__4 = ifn_2066.Invoke_O__O(arg_2067) } else { l__4 = linked_2065.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2064, arg_2067) }; var root_2068 any = A_arbace_box_build_A_const_29.GetRawRoot__O(); var linked_2069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2068, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2070 lang.IFn; if linked_2069 == nil { ifn_2070 = lang.IFn_Cast(root_2068) } else { ifn_2070 = nil }; var arg_2071 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, l__4, nil)).Ref(); var arg_2072 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__598000290); var tmp7 any; var root_2073 any = A_arbace_box_build_A_const_30.GetRawRoot__O(); var linked_2074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2073, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2075 lang.IFn; if linked_2074 == nil { ifn_2075 = lang.IFn_Cast(root_2073) } else { ifn_2075 = nil }; var arg_2076 any = s__598000291__3; if linked_2074 == nil { tmp7 = ifn_2075.Invoke_O__O(arg_2076) } else { tmp7 = linked_2074.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2073, arg_2076) }; arg_2072 = tmp6.Invoke_O__O(tmp7); if linked_2069 == nil { return ifn_2070.Invoke_O_O__O(arg_2071, arg_2072) } else { return linked_2069.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2068, arg_2071, arg_2072) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :334:1
func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A) Ctor_O_I_O(c__b__598000293 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000293 = c__b__598000293; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A) Invoke_O__O(self any) any { { var i__598000292__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__598000292__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__598000292__1)); var root_2036 any = A_arbace_box_build_A_const_26.GetRawRoot__O(); var linked_2037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2036, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2038 lang.IFn; if linked_2037 == nil { ifn_2038 = lang.IFn_Cast(root_2036) } else { ifn_2038 = nil }; var arg_2039 any = t.F_b__598000293; var arg_2040 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, l__2, nil)).Ref(); if linked_2037 == nil { ifn_2038.Invoke_O_O__O(arg_2039, arg_2040) } else { linked_2037.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2036, arg_2039, arg_2040) }; i__598000292__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__598000292__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }











func A_arbace_box_build_build_A_New() *A_arbace_box_build_build_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_box_build_build_A) Ctor() {}
//line :346:1
func (t *A_arbace_box_build_build_A) Invoke_O_O_O__O(self, plan__0, opts__1 any) any { var p__3 any; var root_2130 any = A_arbace_box_build_A_const_169.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, A_arbace_box_build_read_plan_A_fn_class); var ifn_2132 lang.IFn; if



	linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any = plan__0; if linked_2131 == nil { p__3 = ifn_2132.Invoke_O__O(arg_2133) } else { p__3 = linked_2131.(*A_arbace_box_build_read_plan_A).Invoke_O_O__O(root_2130, arg_2133) }; var t0__4 int64 = /*line :346:1*/jrt.System_NanoTime__J(); var as__5 any; var root_2134 any = A_arbace_box_build_A_const_184.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2134, A_arbace_box_build_archives_A_fn_class); var ifn_2136 lang.IFn; if





	linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any = p__3; var arg_2138 any = opts__1; if linked_2135 == nil { as__5 = ifn_2136.Invoke_O_O__O(arg_2137, arg_2138) } else { as__5 = linked_2135.(*A_arbace_box_build_archives_A).Invoke_O_O_O__O(root_2134, arg_2137, arg_2138) }; var image__6 any; var root_2139 any = /*line :346:1*/A_arbace_box_build_A_const_185.GetRawRoot__O(); var linked_2140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2139, A_arbace_box_build_link_A_fn_class); var ifn_2141 lang.IFn; if






	linked_2140 == nil { ifn_2141 = lang.IFn_Cast(root_2139) } else { ifn_2141 = nil }; var arg_2142 any = p__3; var arg_2143 any = as__5; var arg_2144 any = opts__1; if linked_2140 == nil { image__6 = ifn_2141.Invoke_O_O_O__O(arg_2142, arg_2143, arg_2144) } else { image__6 = linked_2140.(*A_arbace_box_build_link_A).Invoke_O_O_O_O__O(root_2139, arg_2142, arg_2143, arg_2144) }; var temp__1927000414__auto____7 any = /*line :346:1*/A_arbace_box_build_A_const_186.Invoke_O__O(opts__1); if







	jrt.J2g_Truth(temp__1927000414__auto____7) { var r__8 any = temp__1927000414__auto____7; var root_2145 any = A_arbace_box_build_A_const_74.GetRawRoot__O(); var linked_2146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2145, aot_arbace_box.A_arbace_box_ref_BANG__A_fn_class); var ifn_2147 lang.IFn; if linked_2146 == nil { ifn_2147 = lang.IFn_Cast(root_2145) } else { ifn_2147 = nil }; var arg_2148 any = r__8; var arg_2149 any = image__6; if linked_2146 == nil { ifn_2147.Invoke_O_O__O(arg_2148, arg_2149) } else { linked_2146.(*aot_arbace_box.A_arbace_box_ref_BANG__A).Invoke_O_O_O__O(root_2145, arg_2148, arg_2149) } }; var root_2171 any =
	A_arbace_box_build_A_const_81.GetRawRoot__O(); var linked_2172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2171, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2173 lang.IFn; if linked_2172 == nil { ifn_2173 = lang.IFn_Cast(root_2171) } else { ifn_2173 = nil }; var arg_2174 any = lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, opts__1); if linked_2172 == nil { ifn_2173.Invoke_O__O(arg_2174) } else { linked_2172.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2171, arg_2174) }; var tmp1 any = A_arbace_box_build_build_fn__598000301_A_New_O_O_J(p__3, image__6, t0__4); var tmp2 *jrt.Class; var fncls__2170 *jrt.Class = A_arbace_box_build_build_fn__598000301_A_fn_class; if fncls__2170 == nil { var fncls__2170d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_box_build_build_fn__598000301_A_fn_class = fncls__2170d; tmp2 = fncls__2170d } else { tmp2 = fncls__2170 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); return image__6 }
//line :346:1
func (t *A_arbace_box_build_build_A) Invoke_O_O__O(self, plan__0 any) any {

	var root_2180 any = A_arbace_box_build_A_const_187.GetRawRoot__O(); var linked_2181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2180, A_arbace_box_build_build_A_fn_class); var ifn_2182 lang.IFn; if linked_2181 == nil { ifn_2182 = lang.IFn_Cast(root_2180) } else { ifn_2182 = nil }; var arg_2183 any = plan__0; var arg_2184 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2181 == nil { return ifn_2182.Invoke_O_O__O(arg_2183, arg_2184) } else { return linked_2181.(*A_arbace_box_build_build_A).Invoke_O_O_O__O(root_2180, arg_2183, arg_2184)
	}
}




func A_arbace_box_build_build_fn__598000301_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_box_build_build_fn__598000301_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_fn__598000301_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :355:1
func (t *A_arbace_box_build_build_fn__598000301_A) Ctor_O_O_J(c__p, c__image any, c__t0 int64) { t.F_p = c__p; t.F_image = c__image; t.F_t0 = c__t0 }
//line :355:1
func (t *A_arbace_box_build_build_fn__598000301_A) Invoke_O__O(self any) any { var tmp1 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_76.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_77.GetRawRoot__O()); var tmp4 any = A_arbace_box_build_A_const_177.Invoke_O__O(t.F_p); var tmp5 *lang.Keyword = A_arbace_box_build_A_const_41; var tmp6 any; var t_ any = t.F_p; t.F_p = nil; tmp6 = t_; var tmp7 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp5.Invoke_O__O(tmp6))).Ref(); var tmp8 any = t.F_image; var tmp9 any; var root_2163 any = A_arbace_box_build_A_const_62.GetRawRoot__O(); var linked_2164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2163, aot_arbace_box.A_arbace_box_size_A_fn_class); var ifn_2165 lang.IFn; if linked_2164 == nil { ifn_2165 = lang.IFn_Cast(root_2163) } else { ifn_2165 = nil }; var arg_2166 any; var t__2 any = t.F_image; t.F_image = nil; arg_2166 = t__2; if linked_2164 == nil { tmp9 = ifn_2165.Invoke_O__O(arg_2166) } else { tmp9 = linked_2164.(*aot_arbace_box.A_arbace_box_size_A).Invoke_O_O__O(root_2163, arg_2166) }; tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O_O_O_O_O_O__O(Lit_44, tmp4, tmp7, tmp8, tmp9, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t.F_t0), 1.0e9)).Ref())) }
//line :355:1
	return nil }(); var root_2167 any = A_arbace_box_build_A_const_80.GetRawRoot__O(); var linked_2168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2167, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2169 lang.IFn; if linked_2168 == nil { ifn_2169 = lang.IFn_Cast(root_2167) } else { ifn_2169 = nil }; if linked_2168 == nil { ifn_2169.Invoke__O() } else { linked_2168.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2167) }; if tmp10 != nil { panic(tmp10) }; return tmp1 }




























































































































































































































































type A_arbace_box_build_A struct{ jrt.Object }

var A_arbace_box_build_A_const_pool *jrt.RefArray

var A_arbace_box_build_A_const_0 *lang.Var

var A_arbace_box_build_A_const_1 any

var A_arbace_box_build_A_const_2 *lang.Var

var A_arbace_box_build_A_const_3 any

var A_arbace_box_build_A_const_4 any

var A_arbace_box_build_A_const_5 any

var A_arbace_box_build_A_const_6 *lang.Var

var A_arbace_box_build_A_const_7 *lang.Var

var A_arbace_box_build_A_const_8 *lang.Var

var A_arbace_box_build_A_const_9 *lang.Var

var A_arbace_box_build_A_const_10 any

var A_arbace_box_build_A_const_11 *lang.Var

var A_arbace_box_build_A_const_12 *lang.Var

var A_arbace_box_build_A_const_13 *lang.Keyword

var A_arbace_box_build_A_const_14 *lang.Var

var A_arbace_box_build_A_const_15 *lang.Var

var A_arbace_box_build_A_const_16 *lang.Var

var A_arbace_box_build_A_const_17 *lang.Var

var A_arbace_box_build_A_const_18 *lang.Var

var A_arbace_box_build_A_const_19 *lang.Var

var A_arbace_box_build_A_const_20 *lang.Var

var A_arbace_box_build_A_const_21 *lang.Var

var A_arbace_box_build_A_const_22 *lang.Var

var A_arbace_box_build_A_const_23 *lang.Var

var A_arbace_box_build_A_const_24 *lang.Var

var A_arbace_box_build_A_const_25 *lang.Keyword

var A_arbace_box_build_A_const_26 *lang.Var

var A_arbace_box_build_A_const_27 *lang.Var

var A_arbace_box_build_A_const_28 *lang.Var

var A_arbace_box_build_A_const_29 *lang.Var

var A_arbace_box_build_A_const_30 *lang.Var

var A_arbace_box_build_A_const_31 *lang.Var

var A_arbace_box_build_A_const_32 *lang.Var

var A_arbace_box_build_A_const_33 *lang.Var

var A_arbace_box_build_A_const_34 *lang.Var

var A_arbace_box_build_A_const_35 *lang.Var

var A_arbace_box_build_A_const_36 *lang.Var

var A_arbace_box_build_A_const_37 *lang.Var

var A_arbace_box_build_A_const_38 *lang.Var

var A_arbace_box_build_A_const_39 *lang.Keyword

var A_arbace_box_build_A_const_40 *lang.Var

var A_arbace_box_build_A_const_41 *lang.Keyword

var A_arbace_box_build_A_const_42 *lang.Var

var A_arbace_box_build_A_const_43 *lang.Var

var A_arbace_box_build_A_const_44 *lang.Keyword

var A_arbace_box_build_A_const_45 *lang.Var

var A_arbace_box_build_A_const_46 *lang.Var

var A_arbace_box_build_A_const_47 *lang.Var

var A_arbace_box_build_A_const_48 *lang.Keyword

var A_arbace_box_build_A_const_49 *lang.Var

var A_arbace_box_build_A_const_50 *lang.Var

var A_arbace_box_build_A_const_51 *lang.Var

var A_arbace_box_build_A_const_52 *lang.Var

var A_arbace_box_build_A_const_53 *lang.Var

var A_arbace_box_build_A_const_54 *lang.Var

var A_arbace_box_build_A_const_55 *lang.Keyword

var A_arbace_box_build_A_const_56 *lang.Keyword

var A_arbace_box_build_A_const_57 any

var A_arbace_box_build_A_const_58 any

var A_arbace_box_build_A_const_59 *lang.Var

var A_arbace_box_build_A_const_60 *lang.Keyword

var A_arbace_box_build_A_const_61 *lang.Var

var A_arbace_box_build_A_const_62 *lang.Var

var A_arbace_box_build_A_const_63 *lang.Var

var A_arbace_box_build_A_const_64 *lang.Keyword

var A_arbace_box_build_A_const_65 *lang.Var

var A_arbace_box_build_A_const_66 *lang.Keyword

var A_arbace_box_build_A_const_67 *lang.Var

var A_arbace_box_build_A_const_68 *lang.Keyword

var A_arbace_box_build_A_const_69 *lang.Var

var A_arbace_box_build_A_const_70 *lang.Keyword

var A_arbace_box_build_A_const_71 *lang.Keyword

var A_arbace_box_build_A_const_72 *lang.Keyword

var A_arbace_box_build_A_const_73 *lang.Var

var A_arbace_box_build_A_const_74 *lang.Var

var A_arbace_box_build_A_const_75 *lang.Keyword

var A_arbace_box_build_A_const_76 *lang.Var

var A_arbace_box_build_A_const_77 *lang.Var

var A_arbace_box_build_A_const_78 *lang.Keyword

var A_arbace_box_build_A_const_79 *lang.Var

var A_arbace_box_build_A_const_80 *lang.Var

var A_arbace_box_build_A_const_81 *lang.Var

var A_arbace_box_build_A_const_82 *lang.Var

var A_arbace_box_build_A_const_83 *lang.Var

var A_arbace_box_build_A_const_84 *lang.Keyword

var A_arbace_box_build_A_const_85 *lang.Keyword

var A_arbace_box_build_A_const_86 *lang.Var

var A_arbace_box_build_A_const_87 *lang.Keyword

var A_arbace_box_build_A_const_88 any

var A_arbace_box_build_A_const_89 *lang.Keyword

var A_arbace_box_build_A_const_90 *lang.Var

var A_arbace_box_build_A_const_91 *lang.Keyword

var A_arbace_box_build_A_const_92 *lang.Var

var A_arbace_box_build_A_const_93 *lang.Keyword

var A_arbace_box_build_A_const_94 any

var A_arbace_box_build_A_const_95 *lang.Var

var A_arbace_box_build_A_const_96 *lang.Var

var A_arbace_box_build_A_const_97 any

var A_arbace_box_build_A_const_98 any

var A_arbace_box_build_A_const_99 any

var A_arbace_box_build_A_const_100 any

var A_arbace_box_build_A_const_101 any

var A_arbace_box_build_A_const_102 any

var A_arbace_box_build_A_const_103 *lang.Var

var A_arbace_box_build_A_const_104 *lang.Var

var A_arbace_box_build_A_const_105 *lang.Var

var A_arbace_box_build_A_const_106 *lang.Keyword

var A_arbace_box_build_A_const_107 *lang.Var

var A_arbace_box_build_A_const_108 *lang.Var

var A_arbace_box_build_A_const_109 any

var A_arbace_box_build_A_const_110 any

var A_arbace_box_build_A_const_111 *lang.Keyword

var A_arbace_box_build_A_const_112 *lang.Var

var A_arbace_box_build_A_const_113 *lang.Var

var A_arbace_box_build_A_const_114 *lang.Var

var A_arbace_box_build_A_const_115 *lang.Var

var A_arbace_box_build_A_const_116 *lang.Var

var A_arbace_box_build_A_const_117 *lang.Var

var A_arbace_box_build_A_const_118 *lang.Var

var A_arbace_box_build_A_const_119 *lang.Var

var A_arbace_box_build_A_const_120 *lang.Keyword

var A_arbace_box_build_A_const_121 *lang.Keyword

var A_arbace_box_build_A_const_122 *lang.Var

var A_arbace_box_build_A_const_123 *lang.Keyword

var A_arbace_box_build_A_const_124 *lang.Var

var A_arbace_box_build_A_const_125 any

var A_arbace_box_build_A_const_126 *lang.Keyword

var A_arbace_box_build_A_const_127 *lang.Var

var A_arbace_box_build_A_const_128 *lang.Var

var A_arbace_box_build_A_const_129 *lang.Var

var A_arbace_box_build_A_const_130 *lang.Var

var A_arbace_box_build_A_const_131 *lang.Var

var A_arbace_box_build_A_const_132 *lang.Var

var A_arbace_box_build_A_const_133 *lang.Keyword

var A_arbace_box_build_A_const_134 *lang.Keyword

var A_arbace_box_build_A_const_135 *lang.Keyword

var A_arbace_box_build_A_const_136 *lang.Var

var A_arbace_box_build_A_const_137 *lang.Var

var A_arbace_box_build_A_const_138 *lang.Keyword

var A_arbace_box_build_A_const_139 *lang.Keyword

var A_arbace_box_build_A_const_140 *lang.Var

var A_arbace_box_build_A_const_141 *lang.Keyword

var A_arbace_box_build_A_const_142 *lang.Var

var A_arbace_box_build_A_const_143 any

var A_arbace_box_build_A_const_144 *lang.Var

var A_arbace_box_build_A_const_145 *lang.Var

var A_arbace_box_build_A_const_146 *lang.Var

var A_arbace_box_build_A_const_147 *lang.Var

var A_arbace_box_build_A_const_148 *lang.Var

var A_arbace_box_build_A_const_149 *lang.Keyword

var A_arbace_box_build_A_const_150 *lang.Keyword

var A_arbace_box_build_A_const_151 *lang.Keyword

var A_arbace_box_build_A_const_152 any

var A_arbace_box_build_A_const_153 *lang.Var

var A_arbace_box_build_A_const_154 any

var A_arbace_box_build_A_const_155 any

var A_arbace_box_build_A_const_156 any

var A_arbace_box_build_A_const_157 any

var A_arbace_box_build_A_const_158 any

var A_arbace_box_build_A_const_159 any

var A_arbace_box_build_A_const_160 *lang.Keyword

var A_arbace_box_build_A_const_161 *lang.Var

var A_arbace_box_build_A_const_162 any

var A_arbace_box_build_A_const_163 *lang.Var

var A_arbace_box_build_A_const_164 any

var A_arbace_box_build_A_const_165 *lang.Var

var A_arbace_box_build_A_const_166 *lang.Keyword

var A_arbace_box_build_A_const_167 *lang.Var

var A_arbace_box_build_A_const_168 any

var A_arbace_box_build_A_const_169 *lang.Var

var A_arbace_box_build_A_const_170 *lang.Var

var A_arbace_box_build_A_const_171 *lang.Var

var A_arbace_box_build_A_const_172 *lang.Keyword

var A_arbace_box_build_A_const_173 *lang.Keyword

var A_arbace_box_build_A_const_174 *lang.Keyword

var A_arbace_box_build_A_const_175 any

var A_arbace_box_build_A_const_176 *lang.Var

var A_arbace_box_build_A_const_177 *lang.Keyword

var A_arbace_box_build_A_const_178 *lang.Keyword

var A_arbace_box_build_A_const_179 any

var A_arbace_box_build_A_const_180 *lang.Keyword

var A_arbace_box_build_A_const_181 any

var A_arbace_box_build_A_const_182 *lang.Keyword

var A_arbace_box_build_A_const_183 any

var A_arbace_box_build_A_const_184 *lang.Var

var A_arbace_box_build_A_const_185 *lang.Var

var A_arbace_box_build_A_const_186 *lang.Keyword

var A_arbace_box_build_A_const_187 *lang.Var

var A_arbace_box_build_A_init jrt.ClassInit

func A_arbace_box_build_A_Init() { if !A_arbace_box_build_A_init.Done() { A_arbace_box_build_A_init.Run(A_arbace_box_build_A_clinit) } }

func A_arbace_box_build_A_clinit() { A_arbace_box_build_A_clinit_p0(); A_arbace_box_build_A_clinit_p1(); A_arbace_box_build_A_clinit_p2(); A_arbace_box_build_A_clinit_p3(); A_arbace_box_build_A_clinit_p4(); A_arbace_box_build_A_clinit_p5(); A_arbace_box_build_A_clinit_p6(); A_arbace_box_build_A_clinit_p7(); A_arbace_box_build_A_clinit_p8(); A_arbace_box_build_A_clinit_p9(); A_arbace_box_build_A_clinit_p10(); A_arbace_box_build_A_clinit_p11(); A_arbace_box_build_A_clinit_p12(); A_arbace_box_build_A_clinit_p13(); A_arbace_box_build_A_clinit_p14(); A_arbace_box_build_A_clinit_p15() }

func A_arbace_box_build_A_clinit_p0() { jrt.StartCheck(); A_arbace_box_build_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 245); A_arbace_box_build_A_const_0 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[57]); A_arbace_box_build_A_const_1 = A_arbace_box_build_A_const_pool.A[58]; A_arbace_box_build_A_const_2 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[59]); A_arbace_box_build_A_const_3 = A_arbace_box_build_A_const_pool.A[60]; A_arbace_box_build_A_const_4 = A_arbace_box_build_A_const_pool.A[61]; A_arbace_box_build_A_const_5 = A_arbace_box_build_A_const_pool.A[62]; A_arbace_box_build_A_const_6 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[63]); A_arbace_box_build_A_const_7 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[64]); A_arbace_box_build_A_const_8 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[65]); A_arbace_box_build_A_const_9 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[66]); A_arbace_box_build_A_const_10 = A_arbace_box_build_A_const_pool.A[67]; A_arbace_box_build_A_const_11 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[68]) }

func A_arbace_box_build_A_clinit_p1() { A_arbace_box_build_A_const_12 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[69]); A_arbace_box_build_A_const_13 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[70]); A_arbace_box_build_A_const_14 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[71]); A_arbace_box_build_A_const_15 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[72]); A_arbace_box_build_A_const_16 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[73]); A_arbace_box_build_A_const_17 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[74]); A_arbace_box_build_A_const_18 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[75]); A_arbace_box_build_A_const_19 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[76]); A_arbace_box_build_A_const_20 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[77]); A_arbace_box_build_A_const_21 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[78]); A_arbace_box_build_A_const_22 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[79]); A_arbace_box_build_A_const_23 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[80]) }

func A_arbace_box_build_A_clinit_p2() { A_arbace_box_build_A_const_24 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[81]); A_arbace_box_build_A_const_25 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[82]); A_arbace_box_build_A_const_26 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[83]); A_arbace_box_build_A_const_27 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[84]); A_arbace_box_build_A_const_28 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[85]); A_arbace_box_build_A_const_29 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[86]); A_arbace_box_build_A_const_30 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[87]); A_arbace_box_build_A_const_31 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[88]); A_arbace_box_build_A_const_32 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[89]); A_arbace_box_build_A_const_33 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[90]); A_arbace_box_build_A_const_34 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[91]); A_arbace_box_build_A_const_35 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[92]) }

func A_arbace_box_build_A_clinit_p3() { A_arbace_box_build_A_const_36 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[93]); A_arbace_box_build_A_const_37 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[94]); A_arbace_box_build_A_const_38 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[95]); A_arbace_box_build_A_const_39 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[96]); A_arbace_box_build_A_const_40 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[97]); A_arbace_box_build_A_const_41 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[98]); A_arbace_box_build_A_const_42 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[99]); A_arbace_box_build_A_const_43 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[100]); A_arbace_box_build_A_const_44 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[101]); A_arbace_box_build_A_const_45 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[102]); A_arbace_box_build_A_const_46 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[103]); A_arbace_box_build_A_const_47 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[104]) }

func A_arbace_box_build_A_clinit_p4() { A_arbace_box_build_A_const_48 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[105]); A_arbace_box_build_A_const_49 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[106]); A_arbace_box_build_A_const_50 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[107]); A_arbace_box_build_A_const_51 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[108]); A_arbace_box_build_A_const_52 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[109]); A_arbace_box_build_A_const_53 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[110]); A_arbace_box_build_A_const_54 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[111]); A_arbace_box_build_A_const_55 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[112]); A_arbace_box_build_A_const_56 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[113]); A_arbace_box_build_A_const_57 = A_arbace_box_build_A_const_pool.A[114]; A_arbace_box_build_A_const_58 = A_arbace_box_build_A_const_pool.A[115]; A_arbace_box_build_A_const_59 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[116]) }

func A_arbace_box_build_A_clinit_p5() { A_arbace_box_build_A_const_60 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[117]); A_arbace_box_build_A_const_61 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[118]); A_arbace_box_build_A_const_62 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[119]); A_arbace_box_build_A_const_63 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[120]); A_arbace_box_build_A_const_64 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[121]); A_arbace_box_build_A_const_65 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[122]); A_arbace_box_build_A_const_66 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[123]); A_arbace_box_build_A_const_67 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[124]); A_arbace_box_build_A_const_68 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[125]); A_arbace_box_build_A_const_69 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[126]); A_arbace_box_build_A_const_70 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[127]); A_arbace_box_build_A_const_71 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[128]) }

func A_arbace_box_build_A_clinit_p6() { A_arbace_box_build_A_const_72 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[129]); A_arbace_box_build_A_const_73 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[130]); A_arbace_box_build_A_const_74 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[131]); A_arbace_box_build_A_const_75 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[132]); A_arbace_box_build_A_const_76 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[133]); A_arbace_box_build_A_const_77 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[134]); A_arbace_box_build_A_const_78 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[135]); A_arbace_box_build_A_const_79 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[136]); A_arbace_box_build_A_const_80 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[137]); A_arbace_box_build_A_const_81 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[138]); A_arbace_box_build_A_const_82 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[139]); A_arbace_box_build_A_const_83 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[140]) }

func A_arbace_box_build_A_clinit_p7() { A_arbace_box_build_A_const_84 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[141]); A_arbace_box_build_A_const_85 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[142]); A_arbace_box_build_A_const_86 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[143]); A_arbace_box_build_A_const_87 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[144]); A_arbace_box_build_A_const_88 = A_arbace_box_build_A_const_pool.A[145]; A_arbace_box_build_A_const_89 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[146]); A_arbace_box_build_A_const_90 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[147]); A_arbace_box_build_A_const_91 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[148]); A_arbace_box_build_A_const_92 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[149]); A_arbace_box_build_A_const_93 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[150]); A_arbace_box_build_A_const_94 = A_arbace_box_build_A_const_pool.A[151]; A_arbace_box_build_A_const_95 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[152]) }

func A_arbace_box_build_A_clinit_p8() { A_arbace_box_build_A_const_96 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[153]); A_arbace_box_build_A_const_97 = A_arbace_box_build_A_const_pool.A[154]; A_arbace_box_build_A_const_98 = A_arbace_box_build_A_const_pool.A[155]; A_arbace_box_build_A_const_99 = A_arbace_box_build_A_const_pool.A[156]; A_arbace_box_build_A_const_100 = A_arbace_box_build_A_const_pool.A[157]; A_arbace_box_build_A_const_101 = A_arbace_box_build_A_const_pool.A[158]; A_arbace_box_build_A_const_102 = A_arbace_box_build_A_const_pool.A[159]; A_arbace_box_build_A_const_103 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[160]); A_arbace_box_build_A_const_104 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[161]); A_arbace_box_build_A_const_105 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[162]); A_arbace_box_build_A_const_106 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[163]); A_arbace_box_build_A_const_107 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[164]); A_arbace_box_build_A_const_108 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[165]) }

func A_arbace_box_build_A_clinit_p9() { A_arbace_box_build_A_const_109 = A_arbace_box_build_A_const_pool.A[166]; A_arbace_box_build_A_const_110 = A_arbace_box_build_A_const_pool.A[167]; A_arbace_box_build_A_const_111 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[168]); A_arbace_box_build_A_const_112 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[169]); A_arbace_box_build_A_const_113 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[170]); A_arbace_box_build_A_const_114 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[171]); A_arbace_box_build_A_const_115 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[172]); A_arbace_box_build_A_const_116 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[173]); A_arbace_box_build_A_const_117 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[174]); A_arbace_box_build_A_const_118 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[175]); A_arbace_box_build_A_const_119 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[176]); A_arbace_box_build_A_const_120 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[177]) }

func A_arbace_box_build_A_clinit_p10() { A_arbace_box_build_A_const_121 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[178]); A_arbace_box_build_A_const_122 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[179]); A_arbace_box_build_A_const_123 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[180]); A_arbace_box_build_A_const_124 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[181]); A_arbace_box_build_A_const_125 = A_arbace_box_build_A_const_pool.A[182]; A_arbace_box_build_A_const_126 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[183]); A_arbace_box_build_A_const_127 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[184]); A_arbace_box_build_A_const_128 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[185]); A_arbace_box_build_A_const_129 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[186]); A_arbace_box_build_A_const_130 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[187]); A_arbace_box_build_A_const_131 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[188]); A_arbace_box_build_A_const_132 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[189]) }

func A_arbace_box_build_A_clinit_p11() { A_arbace_box_build_A_const_133 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[190]); A_arbace_box_build_A_const_134 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[191]); A_arbace_box_build_A_const_135 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[192]); A_arbace_box_build_A_const_136 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[193]); A_arbace_box_build_A_const_137 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[194]); A_arbace_box_build_A_const_138 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[195]); A_arbace_box_build_A_const_139 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[196]); A_arbace_box_build_A_const_140 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[197]); A_arbace_box_build_A_const_141 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[198]); A_arbace_box_build_A_const_142 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[199]); A_arbace_box_build_A_const_143 = A_arbace_box_build_A_const_pool.A[200]; A_arbace_box_build_A_const_144 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[201]) }

func A_arbace_box_build_A_clinit_p12() { A_arbace_box_build_A_const_145 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[202]); A_arbace_box_build_A_const_146 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[203]); A_arbace_box_build_A_const_147 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[204]); A_arbace_box_build_A_const_148 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[205]); A_arbace_box_build_A_const_149 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[206]); A_arbace_box_build_A_const_150 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[207]); A_arbace_box_build_A_const_151 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[208]); A_arbace_box_build_A_const_152 = A_arbace_box_build_A_const_pool.A[209]; A_arbace_box_build_A_const_153 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[210]); A_arbace_box_build_A_const_154 = A_arbace_box_build_A_const_pool.A[211]; A_arbace_box_build_A_const_155 = A_arbace_box_build_A_const_pool.A[212]; A_arbace_box_build_A_const_156 = A_arbace_box_build_A_const_pool.A[213]; A_arbace_box_build_A_const_157 = A_arbace_box_build_A_const_pool.A[214] }

func A_arbace_box_build_A_clinit_p13() { A_arbace_box_build_A_const_158 = A_arbace_box_build_A_const_pool.A[215]; A_arbace_box_build_A_const_159 = A_arbace_box_build_A_const_pool.A[216]; A_arbace_box_build_A_const_160 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[217]); A_arbace_box_build_A_const_161 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[218]); A_arbace_box_build_A_const_162 = A_arbace_box_build_A_const_pool.A[219]; A_arbace_box_build_A_const_163 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[220]); A_arbace_box_build_A_const_164 = A_arbace_box_build_A_const_pool.A[221]; A_arbace_box_build_A_const_165 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[222]); A_arbace_box_build_A_const_166 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[223]); A_arbace_box_build_A_const_167 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[224]); A_arbace_box_build_A_const_168 = A_arbace_box_build_A_const_pool.A[225]; A_arbace_box_build_A_const_169 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[226]); A_arbace_box_build_A_const_170 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[227]) }

func A_arbace_box_build_A_clinit_p14() { A_arbace_box_build_A_const_171 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[228]); A_arbace_box_build_A_const_172 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[229]); A_arbace_box_build_A_const_173 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[230]); A_arbace_box_build_A_const_174 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[231]); A_arbace_box_build_A_const_175 = A_arbace_box_build_A_const_pool.A[232]; A_arbace_box_build_A_const_176 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[233]); A_arbace_box_build_A_const_177 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[234]); A_arbace_box_build_A_const_178 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[235]); A_arbace_box_build_A_const_179 = A_arbace_box_build_A_const_pool.A[236]; A_arbace_box_build_A_const_180 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[237]); A_arbace_box_build_A_const_181 = A_arbace_box_build_A_const_pool.A[238]; A_arbace_box_build_A_const_182 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[239]); A_arbace_box_build_A_const_183 = A_arbace_box_build_A_const_pool.A[240] }

func A_arbace_box_build_A_clinit_p15() { A_arbace_box_build_A_const_184 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[241]); A_arbace_box_build_A_const_185 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[242]); A_arbace_box_build_A_const_186 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[243]); A_arbace_box_build_A_const_187 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[244]) }

func A_arbace_box_build_A_New() *A_arbace_box_build_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_A{}; t.Ctor(); return t }

func (t *A_arbace_box_build_A) Ctor() {}

func (t *A_arbace_box_build_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_A_class }

func (t *A_arbace_box_build_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_build_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_A); return ok }

func A_arbace_box_build_A_Cast(x any) *A_arbace_box_build_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_A_class)) }; return v }



type A_arbace_box_build_action_A struct{ j2g_header uint64 }

var A_arbace_box_build_action_A_fn_class *jrt.Class



type A_arbace_box_build_action_STAR__A struct{ j2g_header uint64 }

var A_arbace_box_build_action_STAR__A_fn_class *jrt.Class



type A_arbace_box_build_append_members_A struct{ j2g_header uint64 }

var A_arbace_box_build_append_members_A_fn_class *jrt.Class



type A_arbace_box_build_ar_member_A struct{ j2g_header uint64 }

var A_arbace_box_build_ar_member_A_fn_class *jrt.Class



type A_arbace_box_build_ar_member_pad__598000077_A struct{ j2g_header uint64 }

var A_arbace_box_build_ar_member_pad__598000077_A_fn_class *jrt.Class



type A_arbace_box_build_arch_defines_A struct{ j2g_header uint64 }

var A_arbace_box_build_arch_defines_A_fn_class *jrt.Class



type A_arbace_box_build_archives_A struct{ j2g_header uint64 }

var A_arbace_box_build_archives_A_fn_class *jrt.Class



type A_arbace_box_build_archives_conveyed__598000244_A struct{ j2g_header uint64; F_opts any }

var A_arbace_box_build_archives_conveyed__598000244_A_fn_class *jrt.Class



type A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A struct{ j2g_header uint64; F_f, F_o any }

var A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000242_A struct{ j2g_header uint64 }

var A_arbace_box_build_archives_fn__598000242_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000252_A struct{ j2g_header uint64; F_given, F_q any }

var A_arbace_box_build_archives_fn__598000252_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000254_A struct{ j2g_header uint64; F_index, F_p, F_deps, F_sem, F_conveyed, F_q any }

var A_arbace_box_build_archives_fn__598000254_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000254_fn__598000255_A struct{ j2g_header uint64; F_index, F_p, F_deps, F_sem, F_q any }

var A_arbace_box_build_archives_fn__598000254_fn__598000255_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A struct{ j2g_header uint64 }

var A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000260_A struct{ j2g_header uint64; F_given, F_q any }

var A_arbace_box_build_archives_fn__598000260_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000262_A struct{ j2g_header uint64; F_index, F_p, F_deps, F_sem, F_conveyed, F_q any }

var A_arbace_box_build_archives_fn__598000262_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000262_fn__598000263_A struct{ j2g_header uint64; F_index, F_p, F_deps, F_sem, F_q any }

var A_arbace_box_build_archives_fn__598000262_fn__598000263_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A struct{ j2g_header uint64 }

var A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_fn_class *jrt.Class



type A_arbace_box_build_archives_iter__598000268__598000272_A struct{ j2g_header uint64 }

var A_arbace_box_build_archives_iter__598000268__598000272_A_fn_class *jrt.Class



type A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A struct{ j2g_header uint64; F_iter__598000268, F_s__598000269 any }

var A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_fn_class *jrt.Class



type A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A struct{ j2g_header uint64; F_b__598000271 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_fn_class *jrt.Class



type A_arbace_box_build_asm_args_A struct{ j2g_header uint64 }

var A_arbace_box_build_asm_args_A_fn_class *jrt.Class



type A_arbace_box_build_asm_args_fn__598000074_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_box_build_asm_args_fn__598000074_A_fn_class *jrt.Class



type A_arbace_box_build_build_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_A_fn_class *jrt.Class



type A_arbace_box_build_build_fn__598000301_A struct{ j2g_header uint64; F_p, F_image any; F_t0 int64 }

var A_arbace_box_build_build_fn__598000301_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_fn__598000179_A struct{ j2g_header uint64; F_P any }

var A_arbace_box_build_build_package_fn__598000179_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_fn__598000184_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_fn__598000184_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_fn__598000186_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_fn__598000186_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000150__598000154_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_iter__598000150__598000154_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A struct{ j2g_header uint64; F_iter__598000150, F_s__598000151 any }

var A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A struct{ j2g_header uint64; F_b__598000153 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000166__598000170_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_iter__598000166__598000170_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A struct{ j2g_header uint64; F_s__598000167, F_iter__598000166 any }

var A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A struct{ j2g_header uint64; F_b__598000169 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_A struct{ j2g_header uint64; F_res_of, F_P, F_plan, F_ctree, F_pkg, F_tools any }

var A_arbace_box_build_build_package_iter__598000189__598000193_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A struct{ j2g_header uint64; F_res_of, F_P, F_plan, F_ctree, F_pkg, F_tools, F_s__598000190, F_iter__598000189 any }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A struct{ j2g_header uint64; F_b__598000192, F_res_of, F_P, F_plan, F_ctree, F_pkg, F_tools any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A struct{ j2g_header uint64; F_res_of, F_P, F_plan, F_ctree, F_pkg, F_o, F_s, F_tools any }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A struct{ j2g_header uint64; F_res_of, F_P, F_plan, F_o, F_ctree, F_pkg, F_s, F_tools any }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000203__598000207_A struct{ j2g_header uint64 }

var A_arbace_box_build_build_package_iter__598000203__598000207_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A struct{ j2g_header uint64; F_iter__598000203, F_s__598000204 any }

var A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A struct{ j2g_header uint64; F_b__598000206 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_res_of__598000176_A struct{ j2g_header uint64; F_P any }

var A_arbace_box_build_build_package_res_of__598000176_A_fn_class *jrt.Class



type A_arbace_box_build_cache_ref_A struct{ j2g_header uint64 }

var A_arbace_box_build_cache_ref_A_fn_class *jrt.Class



type A_arbace_box_build_complete_QMARK__A struct{ j2g_header uint64 }

var A_arbace_box_build_complete_QMARK__A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_A struct{ j2g_header uint64 }

var A_arbace_box_build_deps_tree_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000092__598000096_A struct{ j2g_header uint64; F_archives, F_index any }

var A_arbace_box_build_deps_tree_iter__598000092__598000096_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A struct{ j2g_header uint64; F_archives, F_index, F_iter__598000092, F_s__598000093 any }

var A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A struct{ j2g_header uint64; F_b__598000095, F_archives, F_index any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000102__598000106_A struct{ j2g_header uint64; F_index any }

var A_arbace_box_build_deps_tree_iter__598000102__598000106_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A struct{ j2g_header uint64; F_s__598000103, F_index, F_iter__598000102 any }

var A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A struct{ j2g_header uint64; F_index, F_b__598000105 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_A struct{ j2g_header uint64 }

var A_arbace_box_build_embed_config_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000116__598000120_A struct{ j2g_header uint64 }

var A_arbace_box_build_embed_config_iter__598000116__598000120_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A struct{ j2g_header uint64; F_iter__598000116, F_s__598000117 any }

var A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A struct{ j2g_header uint64; F_b__598000119 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000132__598000136_A struct{ j2g_header uint64 }

var A_arbace_box_build_embed_config_iter__598000132__598000136_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A struct{ j2g_header uint64; F_s__598000133, F_iter__598000132 any }

var A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A struct{ j2g_header uint64; F_b__598000135 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_fn_class *jrt.Class



type A_arbace_box_build_eval598000004_A struct{ jrt.Object }

func A_arbace_box_build_eval598000004_A_New() *A_arbace_box_build_eval598000004_A { t := &A_arbace_box_build_eval598000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_build_eval598000004_A) Ctor() {}

func (t *A_arbace_box_build_eval598000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_eval598000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_eval598000004_A_class }

func (t *A_arbace_box_build_eval598000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_eval598000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_build_eval598000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_eval598000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_eval598000004_A); return ok }

func A_arbace_box_build_eval598000004_A_Cast(x any) *A_arbace_box_build_eval598000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_eval598000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_eval598000004_A_class)) }; return v }



type A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A struct{ j2g_header uint64 }

var A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_fn_class *jrt.Class



type A_arbace_box_build_eval598000008_A struct{ jrt.Object }

func A_arbace_box_build_eval598000008_A_New() *A_arbace_box_build_eval598000008_A { t := &A_arbace_box_build_eval598000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_build_eval598000008_A) Ctor() {}

func (t *A_arbace_box_build_eval598000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_eval598000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_eval598000008_A_class }

func (t *A_arbace_box_build_eval598000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_eval598000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_build_eval598000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_eval598000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_eval598000008_A); return ok }

func A_arbace_box_build_eval598000008_A_Cast(x any) *A_arbace_box_build_eval598000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_eval598000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_eval598000008_A_class)) }; return v }



type A_arbace_box_build_eval598000008_fn__598000009_A struct{ j2g_header uint64 }

var A_arbace_box_build_eval598000008_fn__598000009_A_fn_class *jrt.Class



type A_arbace_box_build_fail_A struct{ j2g_header uint64 }

var A_arbace_box_build_fail_A_fn_class *jrt.Class



type A_arbace_box_build_file_tree_A struct{ j2g_header uint64 }

var A_arbace_box_build_file_tree_A_fn_class *jrt.Class



type A_arbace_box_build_file_tree_iter__598000054__598000058_A struct{ j2g_header uint64 }

var A_arbace_box_build_file_tree_iter__598000054__598000058_A_fn_class *jrt.Class



type A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A struct{ j2g_header uint64; F_s__598000055, F_iter__598000054 any }

var A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_fn_class *jrt.Class



type A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A struct{ j2g_header uint64; F_b__598000057 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_fn_class *jrt.Class



type A_arbace_box_build_import_plan_A struct{ j2g_header uint64 }

var A_arbace_box_build_import_plan_A_fn_class *jrt.Class



type A_arbace_box_build_import_plan_fn__598000044_A struct{ j2g_header uint64; F_src any }

var A_arbace_box_build_import_plan_fn__598000044_A_fn_class *jrt.Class



type A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A struct{ j2g_header uint64; F_src any }

var A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_fn_class *jrt.Class



type A_arbace_box_build_import_plan_src__598000042_A struct{ j2g_header uint64; F_dirs any }

var A_arbace_box_build_import_plan_src__598000042_A_fn_class *jrt.Class



type A_arbace_box_build_json_str_A struct{ j2g_header uint64 }

var A_arbace_box_build_json_str_A_fn_class *jrt.Class



type A_arbace_box_build_json_str_fn__598000113_A struct{ j2g_header uint64 }

var A_arbace_box_build_json_str_fn__598000113_A_fn_class *jrt.Class



type A_arbace_box_build_link_A struct{ j2g_header uint64 }

var A_arbace_box_build_link_A_fn_class *jrt.Class



type A_arbace_box_build_link_fn__598000285_A struct{ j2g_header uint64 }

var A_arbace_box_build_link_fn__598000285_A_fn_class *jrt.Class



type A_arbace_box_build_link_iter__598000290__598000294_A struct{ j2g_header uint64 }

var A_arbace_box_build_link_iter__598000290__598000294_A_fn_class *jrt.Class



type A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A struct{ j2g_header uint64; F_iter__598000290, F_s__598000291 any }

var A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_fn_class *jrt.Class



type A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A struct{ j2g_header uint64; F_b__598000293 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_fn_class *jrt.Class



type A_arbace_box_build_log_A struct{ j2g_header uint64 }

var A_arbace_box_build_log_A_fn_class *jrt.Class



type A_arbace_box_build_out_file_A struct{ j2g_header uint64 }

var A_arbace_box_build_out_file_A_fn_class *jrt.Class



type A_arbace_box_build_read_plan_A struct{ j2g_header uint64 }

var A_arbace_box_build_read_plan_A_fn_class *jrt.Class



type A_arbace_box_build_sha256_hex_A struct{ j2g_header uint64 }

var A_arbace_box_build_sha256_hex_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_A struct{ j2g_header uint64 }

var A_arbace_box_build_source_tree_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_headers__598000018_A struct{ j2g_header uint64 }

var A_arbace_box_build_source_tree_headers__598000018_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A struct{ j2g_header uint64; F_headers any }

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A struct{ j2g_header uint64; F_iter__598000019, F_headers, F_s__598000020 any }

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A struct{ j2g_header uint64; F_headers, F_b__598000022 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_iter__598000030__598000034_A struct{ j2g_header uint64; F_headers any }

var A_arbace_box_build_source_tree_iter__598000030__598000034_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A struct{ j2g_header uint64; F_headers, F_iter__598000030, F_s__598000031 any }

var A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A struct{ j2g_header uint64; F_headers, F_b__598000033 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_fn_class *jrt.Class



type A_arbace_box_build_with_tools_A struct{ j2g_header uint64 }

var A_arbace_box_build_with_tools_A_fn_class *jrt.Class



type A_arbace_box_build_with_tools_iter__598000221__598000225_A struct{ j2g_header uint64; F_arch any }

var A_arbace_box_build_with_tools_iter__598000221__598000225_A_fn_class *jrt.Class



type A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A struct{ j2g_header uint64; F_s__598000222, F_arch, F_iter__598000221 any }

var A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_fn_class *jrt.Class



type A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A struct{ j2g_header uint64; F_b__598000224, F_arch any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_fn_class *jrt.Class
