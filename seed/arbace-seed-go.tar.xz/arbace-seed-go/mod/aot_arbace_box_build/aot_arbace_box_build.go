//line aot_arbace_box_build.ae:1
package aot_arbace_box_build

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :4:1
func A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_New() *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_build_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_box_build_A_const_2); lang.IFn_Cast(A_arbace_box_build_A_const_1.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_box_build_A_const_3, A_arbace_box_build_A_const_4, A_arbace_box_build_A_const_5); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_112)); var tmp5 *lang.Var; lang.RT_Init(); tmp5 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp5).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_113)); var tmp6 *lang.Var; lang.RT_Init(); tmp6 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp6).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_114)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp7 != nil { panic(tmp7) }; return tmp3 }
//line :4:1
func A_arbace_box_build_eval598000008_fn__598000009_A_New() *A_arbace_box_build_eval598000008_fn__598000009_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_eval598000008_fn__598000009_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_build_eval598000008_fn__598000009_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_build_eval598000008_fn__598000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_box_build_A_const_6.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_box_build_A_const_10), A_arbace_box_build_A_const_8.GetRawRoot__O(), A_arbace_box_build_A_const_9) }







































func A_arbace_box_build_fail_A_New() *A_arbace_box_build_fail_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_fail_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_box_build_fail_A) Ctor() {}
//line :44:1
func (t *A_arbace_box_build_fail_A) Invoke_O_O_O__O(self, msg__0, data__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_11.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_12.GetRawRoot__O()); var tmp3 any = A_arbace_box_build_A_const_13; var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1.Invoke_O_O__O(msg__0, tmp2.Invoke_O_O_O__O(data__1, tmp3, tmp4.Ref()))))) }


func A_arbace_box_build_sha256_hex_A_New() *A_arbace_box_build_sha256_hex_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_sha256_hex_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_box_build_sha256_hex_A) Ctor() {}
//line :47:1
func (t *A_arbace_box_build_sha256_hex_A) Invoke_O_O__O(self, s__0 any) any { var d__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_140).Digest_B1__B1(jrt.NN(jrt.String_Cast(s__0)).GetBytes_Charset__B1(jrt.StandardCharsets_UTF_8)).Ref(); var sb__3 any = jrt.StringBuilder_New(); var seq_598000013__4 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(d__2); var chunk_598000014__5 any; var count_598000015__6 int64 = 0; var i_598000016__7 int64 = 0; L1: for {


	if lang.Numbers_Lt_J_J__Z(i_598000016__7, count_598000015__6) { var b__8 any = lang.Indexed_Cast(chunk_598000014__5).Nth_I__O(lang.RT_IntCast_J__I(i_598000016__7)); var x__9 int64 = lang.Numbers_And_O_J__J(b__8, 255)

		jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C(lang.RT_IntCast_J__I(lang.Numbers_ShiftRight_J_J__J(x__9, 4)), lang.RT_IntCast_J__I(16)))
		jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C(lang.RT_IntCast_J__I(lang.Numbers_And_J_J__J(x__9, 15)), lang.RT_IntCast_J__I(16)))
//line :50:1
		seq_598000013__4, chunk_598000014__5, count_598000015__6, i_598000016__7 = seq_598000013__4, chunk_598000014__5, count_598000015__6, lang.Numbers_Unchecked_inc_J__J(i_598000016__7); continue L1 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_598000013__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_598000013__9 any = temp__1927000414__auto____8; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(seq_598000013__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(seq_598000013__9); seq_598000013__4, chunk_598000014__5, count_598000015__6, i_598000016__7 = lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_598000013__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var b__10 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(seq_598000013__9); var x__11 int64 = lang.Numbers_And_O_J__J(b__10, 255)

			jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C(lang.RT_IntCast_J__I(lang.Numbers_ShiftRight_J_J__J(x__11, 4)), lang.RT_IntCast_J__I(16)))
			jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_C__StringBuilder(jrt.Character_ForDigit_I_I__C(lang.RT_IntCast_J__I(lang.Numbers_And_J_J__J(x__11, 15)), lang.RT_IntCast_J__I(16)))
//line :50:1
			seq_598000013__4, chunk_598000014__5, count_598000015__6, i_598000016__7 = lang.IFn_Cast(A_arbace_box_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_598000013__9), nil, 0, 0; continue L1 } } }
//line :47:1
	break L1 }; return /*line :54:1*/ lang.IFn_Cast(A_arbace_box_build_A_const_14.GetRawRoot__O()).Invoke_O__O(sb__3) }




func A_arbace_box_build_source_tree_A_New() *A_arbace_box_build_source_tree_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_A{}; t.Ctor(); return t }
//line :59:1
func (t *A_arbace_box_build_source_tree_A) Ctor() {}
//line :59:1
func (t *A_arbace_box_build_source_tree_A) Invoke_O_O__O(self, d__0 any) any { var fs__2 any = jrt.NN(jrt.File_Cast(d__0)).ListFiles__File1().Ref(); var headers__3 any; var tmp1 any = A_arbace_box_build_source_tree_headers__598000018_A_New(); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_box_build_source_tree_headers__598000018_A_fn_class; if




	fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_141, false); A_arbace_box_build_source_tree_headers__598000018_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; headers__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn =








	lang.IFn_Cast(A_arbace_box_build_A_const_22.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_21.GetRawRoot__O()); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; var tmp6 any = tmp5.Ref(); var tmp7 any; var iter__1927001039__auto____4 any; var tmp8 any = A_arbace_box_build_source_tree_iter__598000030__598000034_A_New_O(headers__3); var tmp9 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_box_build_source_tree_iter__598000030__598000034_A_fn_class; if

	fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_142, false); A_arbace_box_build_source_tree_iter__598000030__598000034_A_fn_class = fncls__7d; tmp9 = fncls__7d } else { tmp9 = fncls__7 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); tmp7 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(fs__2); return /*line :73:1*/ tmp3.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, tmp7)) }
//line :64:1
func A_arbace_box_build_source_tree_headers__598000018_A_New() *A_arbace_box_build_source_tree_headers__598000018_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_box_build_source_tree_headers__598000018_A) Ctor() {}
//line :64:1
func (t *A_arbace_box_build_source_tree_headers__598000018_A) Invoke_O_O__O(self, s__1 any) any { var m__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_21.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;
												lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 any; var iter__1927001039__auto____2 any; var tmp5 any = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_New_O(self); var tmp6 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_fn_class; if
												fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_143, false); A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_fn_class = fncls__3d; tmp6 = fncls__3d } else { tmp6 = fncls__3 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(jrt.NN(jrt.File_Cast(s__1)).ListFiles__File1().Ref()); m__2 = /*line :65:1*/tmp1.Invoke_O_O__O(tmp3, tmp4); if






	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(m__2)) { return lang.IFn_Cast(A_arbace_box_build_A_const_22.GetRawRoot__O()).Invoke_O__O(m__2) } else { return nil } }
//line :66:1
func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_New_O(p0 any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A{}; t.Ctor_O(p0); return t }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A) Ctor_O(c__headers any) { t.F_headers = c__headers }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A) Invoke_O_O__O(self, s__598000020__1 any) any { var tmp1 any = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_New_O_O_O(self, t.F_headers, s__598000020__1); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_144, false); A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :66:1
func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A) Ctor_O_O_O(c__iter__598000019, c__headers, c__s__598000020 any) { t.F_iter__598000019 = c__iter__598000019; t.F_headers = c__headers; t.F_s__598000020 = c__s__598000020 }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A) Invoke_O__O(self any) any { { var s__598000020__1 any; var t_ any = t.F_s__598000020; t.F_s__598000020 = nil; s__598000020__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(s__598000020__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000020__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(s__598000020__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(s__598000020__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000022__6 any = lang.IFn_Cast(A_arbace_box_build_A_const_23.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_New_O_O_I_O(t.F_headers, b__598000022__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_145, false); A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__598000019); return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000022__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(s__598000020__3))) } else { return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000022__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(s__598000020__3); var e__5 any
																	if jrt.NN(jrt.File_Cast(f__4)).IsDirectory__Z() { var temp__1927000414__auto____5 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__4); if jrt.A2g_Truth(temp__1927000414__auto____5) { var h__6 any = temp__1927000414__auto____5; e__5 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_26, h__6) } else { e__5 = nil } } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_24.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_146)) {

		e__5 = lang.IFn_Cast(A_arbace_box_build_A_const_25.GetRawRoot__O()).Invoke_O__O(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()).Ref()) } else {
//line :67:1
			e__5 = nil } }
//line :66:1
	if jrt.A2g_Truth(e__5) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000019); return lang.IFn_Cast(A_arbace_box_build_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), e__5), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__598000020__3))) } else { s__598000020__1 = lang.IFn_Cast(A_arbace_box_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__598000020__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :66:1
func A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A) Ctor_O_O_I_O(c__headers, c__b__598000022 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_headers = c__headers; t.F_b__598000022 = c__b__598000022; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :66:1
func (t *A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A) Invoke_O__O(self any) any { { var i__598000021__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000021__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000021__1)); var e__3 any
																		if jrt.NN(jrt.File_Cast(f__2)).IsDirectory__Z() { var temp__1927000414__auto____3 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__2); if jrt.A2g_Truth(temp__1927000414__auto____3) { var h__4 any = temp__1927000414__auto____3; e__3 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_26, h__4) } else { e__3 = nil } } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_24.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_146)) {

		e__3 = lang.IFn_Cast(A_arbace_box_build_A_const_25.GetRawRoot__O()).Invoke_O__O(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()).Ref()) } else {
//line :67:1
			e__3 = nil } }
//line :66:1
	if jrt.A2g_Truth(e__3) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_27.GetRawRoot__O()); var tmp3 any = t.F_b__598000022; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), e__3)); i__598000021__1 = lang.Numbers_Unchecked_inc_J__J(i__598000021__1); continue L1 } else { i__598000021__1 = lang.Numbers_Unchecked_inc_J__J(i__598000021__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }








func A_arbace_box_build_source_tree_iter__598000030__598000034_A_New_O(p0 any) *A_arbace_box_build_source_tree_iter__598000030__598000034_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_iter__598000030__598000034_A{}; t.Ctor_O(p0); return t }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_A) Ctor_O(c__headers any) { t.F_headers = c__headers }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_A) Invoke_O_O__O(self, s__598000031__1 any) any { var tmp1 any = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_New_O_O_O(t.F_headers, self, s__598000031__1); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_147, false); A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :75:1
func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A) Ctor_O_O_O(c__headers, c__iter__598000030, c__s__598000031 any) { t.F_headers = c__headers; t.F_iter__598000030 = c__iter__598000030; t.F_s__598000031 = c__s__598000031 }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A) Invoke_O__O(self any) any { { var s__598000031__1 any; var t_ any = t.F_s__598000031; t.F_s__598000031 = nil; s__598000031__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(s__598000031__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000031__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(s__598000031__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(s__598000031__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000033__6 any = lang.IFn_Cast(A_arbace_box_build_A_const_23.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_New_O_O_I_O(t.F_headers, b__598000033__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_148, false); A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__598000030); return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000033__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(s__598000031__3))) } else { return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000033__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(s__598000031__3); var e__5 any
														if jrt.NN(jrt.File_Cast(f__4)).IsDirectory__Z() { var temp__1927000414__auto____5 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__4)
															if jrt.A2g_Truth(temp__1927000414__auto____5) { var h__6 any = temp__1927000414__auto____5; e__5 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_26, h__6) } else { e__5 = nil } } else {
																e__5 = lang.IFn_Cast(A_arbace_box_build_A_const_25.GetRawRoot__O()).Invoke_O__O(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()).Ref()) }
//line :75:1
	if jrt.A2g_Truth(e__5) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000030); return lang.IFn_Cast(A_arbace_box_build_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), e__5), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__598000031__3))) } else { s__598000031__1 = lang.IFn_Cast(A_arbace_box_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__598000031__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :75:1
func A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A) Ctor_O_O_I_O(c__headers, c__b__598000033 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_headers = c__headers; t.F_b__598000033 = c__b__598000033; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :75:1
func (t *A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A) Invoke_O__O(self any) any { { var i__598000032__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000032__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000032__1)); var e__3 any
																if jrt.NN(jrt.File_Cast(f__2)).IsDirectory__Z() { var temp__1927000414__auto____3 any = lang.IFn_Cast(t.F_headers).Invoke_O__O(f__2)
																	if jrt.A2g_Truth(temp__1927000414__auto____3) { var h__4 any = temp__1927000414__auto____3; e__3 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_26, h__4) } else { e__3 = nil } } else {
																		e__3 = lang.IFn_Cast(A_arbace_box_build_A_const_25.GetRawRoot__O()).Invoke_O__O(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()).Ref()) }
//line :75:1
	if jrt.A2g_Truth(e__3) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_27.GetRawRoot__O()); var tmp3 any = t.F_b__598000033; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), e__3)); i__598000032__1 = lang.Numbers_Unchecked_inc_J__J(i__598000032__1); continue L1 } else { i__598000032__1 = lang.Numbers_Unchecked_inc_J__J(i__598000032__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }






func A_arbace_box_build_import_plan_A_New() *A_arbace_box_build_import_plan_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_import_plan_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_box_build_import_plan_A) Ctor() {}
//line :82:1
func (t *A_arbace_box_build_import_plan_A) Invoke_O_O_O__O(self, plan__0, goroot__1 any) any { var p__3 any; if




	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_32.GetRawRoot__O()).Invoke_O__O(plan__0)) { p__3 = plan__0 } else { p__3 = lang.IFn_Cast(A_arbace_box_build_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_39.GetRawRoot__O()).Invoke_O__O(plan__0)) }; var dirs__4 any; var tmp1 lang.IFn = /*line :82:1*/lang.IFn_Cast(A_arbace_box_build_A_const_34.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;





	lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; dirs__4 = tmp1.Invoke_O__O(tmp2.Ref()); var src__5 any; var tmp3 any = /*line :82:1*/A_arbace_box_build_import_plan_src__598000042_A_New_O(dirs__4); var tmp4 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_box_build_import_plan_src__598000042_A_fn_class; if






	fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_118, false); A_arbace_box_build_import_plan_src__598000042_A_fn_class = fncls__8d; tmp4 = fncls__8d } else { tmp4 = fncls__8 }; src__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var p__6 any; var tmp5 lang.IFn = /*line :82:1*/lang.IFn_Cast(A_arbace_box_build_A_const_37.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_12.GetRawRoot__O()); var tmp7 any = A_arbace_box_build_A_const_44; var tmp8 any = tmp6.Invoke_O_O_O__O(p__3, tmp7, lang.IFn_Cast(A_arbace_box_build_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_119), jrt.RefArrayOf(jrt.Object_class, goroot__1, nil)).Ref())); var tmp9 any = A_arbace_box_build_A_const_40; var tmp10 any = A_arbace_box_build_import_plan_fn__598000044_A_New_O(src__5); var tmp11 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_box_build_import_plan_fn__598000044_A_fn_class; if









	fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_120, false); A_arbace_box_build_import_plan_fn__598000044_A_fn_class = fncls__10d; tmp11 = fncls__10d } else { tmp11 = fncls__10 }; p__6 = tmp5.Invoke_O_O_O__O(tmp8, tmp9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)); return /*line :93:1*/ lang.IFn_Cast(A_arbace_box_build_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_46.GetRawRoot__O()).Invoke_O__O(p__6)) }
//line :82:1
func (t *A_arbace_box_build_import_plan_A) Invoke_O_O__O(self, plan__0 any) any {


	return lang.IFn_Cast(A_arbace_box_build_A_const_47.GetRawRoot__O()).Invoke_O_O__O(plan__0, Lit_121)
}


func A_arbace_box_build_import_plan_src__598000042_A_New_O(p0 any) *A_arbace_box_build_import_plan_src__598000042_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_import_plan_src__598000042_A{}; t.Ctor_O(p0); return t }
//line :89:1
func (t *A_arbace_box_build_import_plan_src__598000042_A) Ctor_O(c__dirs any) { t.F_dirs = c__dirs }
//line :89:1
func (t *A_arbace_box_build_import_plan_src__598000042_A) Invoke_O_O__O(self, dir__1 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(lang.IFn_Cast(A_arbace_box_build_A_const_7.GetRawRoot__O()).Invoke_O__O(t.F_dirs)).Invoke_O__O(dir__1); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var h__3 any = lang.IFn_Cast(A_arbace_box_build_A_const_35.GetRawRoot__O()).Invoke_O__O(jrt.File_New_String(jrt.String_Cast(dir__1))); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_36.GetRawRoot__O()); var tmp2 any = t.F_dirs; tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_box_build_A_const_12.GetRawRoot__O(), dir__1, h__3); return h__3 } }


func A_arbace_box_build_import_plan_fn__598000044_A_New_O(p0 any) *A_arbace_box_build_import_plan_fn__598000044_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_import_plan_fn__598000044_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_A) Ctor_O(c__src any) { t.F_src = c__src }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_A) Invoke_O_O__O(self, ps__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_41.GetRawRoot__O()); var tmp2 any = A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_New_O(t.F_src); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_122, false); A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ps__1) }
//line :92:1
func A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_New_O(p0 any) *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A) Ctor_O(c__src any) { t.F_src = c__src }
//line :92:1
func (t *A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A) Invoke_O_O__O(self, p1__598000041_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_box_build_A_const_43; var tmp3 lang.IFn = lang.IFn_Cast(t.F_src); return lang.IFn_Cast(A_arbace_box_build_A_const_42.GetRawRoot__O()).Invoke_O_O__O(tmp1.Invoke_O_O_O__O(p1__598000041_SHARP___1, tmp2, tmp3.Invoke_O__O(A_arbace_box_build_A_const_26.Invoke_O__O(p1__598000041_SHARP___1))), A_arbace_box_build_A_const_26) }







func A_arbace_box_build_log_A_New() *A_arbace_box_build_log_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_log_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_box_build_log_A) Ctor() {}
//line :100:1
func (t *A_arbace_box_build_log_A) DoInvoke_O_O__O(self, xs__0 any) any {
	var tmp1 lang.IFn = A_arbace_box_build_A_const_48; return lang.IFn_Cast(tmp1.Invoke_O_O__O(A_arbace_box_build_A_const_49.Get__O(), A_arbace_box_build_A_const_50.GetRawRoot__O())).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_51.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_14.GetRawRoot__O(), xs__0))
}
func A_arbace_box_build_cache_ref_A_New() *A_arbace_box_build_cache_ref_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_cache_ref_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_box_build_cache_ref_A) Ctor() {}
//line :103:1
func (t *A_arbace_box_build_cache_ref_A) Invoke_O_O__O(self, req__0 any) any {
	return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_build_A_const_52.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_53.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_42.GetRawRoot__O()).Invoke_O_O_O__O(req__0, A_arbace_box_build_A_const_57, A_arbace_box_build_A_const_58))), A_arbace_box_build_A_const_54, A_arbace_box_build_A_const_55))).Ref()
}
func A_arbace_box_build_action_STAR__A_New() *A_arbace_box_build_action_STAR__A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_action_STAR__A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_box_build_action_STAR__A) Ctor() {}
//line :106:1
func (t *A_arbace_box_build_action_STAR__A) Invoke_O_O_O__O(self, what__0, req__1 any) any { var cref__3 any = lang.IFn_Cast(A_arbace_box_build_A_const_59.GetRawRoot__O()).Invoke_O__O(req__1); var cached__4 any; var tmp1 lang.IFn = A_arbace_box_build_A_const_60; var tmp2 any = A_arbace_box_build_A_const_49.Get__O(); var tmp3 *jrt.Boolean;


	jrt.Boolean_Init(); tmp3 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp1.Invoke_O_O__O(tmp2, tmp3.Ref())) { var temp__1927000414__auto____4 any = lang.IFn_Cast(A_arbace_box_build_A_const_61.GetRawRoot__O()).Invoke_O__O(cref__3)
		if jrt.A2g_Truth(temp__1927000414__auto____4) { var h__5 any = temp__1927000414__auto____4
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_62.GetRawRoot__O()).Invoke_O__O(h__5)) { cached__4 = lang.IFn_Cast(A_arbace_box_build_A_const_63.GetRawRoot__O()).Invoke_O__O(h__5) } else { cached__4 = nil } } else {
//line :110:1
				cached__4 = nil } } else {
//line :109:1
					cached__4 = nil }; var t0__5 int64 = /*line :106:1*/jrt.System_NanoTime__J(); var res__6 any; var or__1927000174__auto____6 any = cached__4; if






	jrt.A2g_Truth(or__1927000174__auto____6) { res__6 = or__1927000174__auto____6 } else { var tmp4 lang.IFn = A_arbace_box_build_A_const_64; res__6 = lang.IFn_Cast(tmp4.Invoke_O_O__O(A_arbace_box_build_A_const_49.Get__O(), A_arbace_box_build_A_const_65.GetRawRoot__O())).Invoke_O__O(req__1) }; if
	lang.Util_Equiv_J_O__Z(0, A_arbace_box_build_A_const_66.Invoke_O__O(res__6)) { } else {
		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_67.GetRawRoot__O()); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil, Lit_2, nil, Lit_3, nil); var tmp7 *jrt.String; if jrt.A2g_Truth(A_arbace_box_build_A_const_71.Invoke_O__O(res__6)) { tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_4, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_71.Invoke_O__O(res__6))) } else { tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_66.Invoke_O__O(res__6))) }; tmp5.Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, what__0, nil, tmp7.Ref(), nil, lang.IFn_Cast(A_arbace_box_build_A_const_72.GetRawRoot__O()).Invoke_O__O(A_arbace_box_build_A_const_75.Invoke_O__O(res__6)))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_73, what__0, A_arbace_box_build_A_const_74, res__6))) }; var tmp8 any; var and__1927000168__auto____7 any =


	lang.IFn_Cast(A_arbace_box_build_A_const_68.GetRawRoot__O()).Invoke_O__O(cached__4); if jrt.A2g_Truth(and__1927000168__auto____7) { var tmp9 lang.IFn = A_arbace_box_build_A_const_60; var tmp10 any = A_arbace_box_build_A_const_49.Get__O(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; tmp8 = tmp9.Invoke_O_O__O(tmp10, tmp11.Ref()) } else { tmp8 = and__1927000168__auto____7 }; if jrt.A2g_Truth(tmp8) {
		lang.IFn_Cast(A_arbace_box_build_A_const_69.GetRawRoot__O()).Invoke_O_O__O(cref__3, A_arbace_box_build_A_const_76.Invoke_O__O(res__6)) }; var tmp12 lang.IFn =
	lang.IFn_Cast(A_arbace_box_build_A_const_70.GetRawRoot__O()); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_77.GetRawRoot__O()); var tmp14 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_box_build_A_const_78.Invoke_O__O(req__1)); var tmp15 any; if
	jrt.A2g_Truth(cached__4) { tmp15 = Lit_7 } else { tmp15 = lang.IFn_Cast(A_arbace_box_build_A_const_77.GetRawRoot__O()).Invoke_O_O__O(Lit_8, jrt.Double_ValueOf_D__Double(lang.Numbers_Divide_J_D__D(lang.Numbers_Minus_J_J__J(jrt.System_NanoTime__J(), t0__5), 1.0e9)).Ref()) }; /*line :120:1*/tmp12.Invoke_O__O(tmp13.Invoke_O_O_O_O__O(Lit_6, tmp14, what__0, tmp15)); return res__6 }



func A_arbace_box_build_action_A_New() *A_arbace_box_build_action_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_action_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_box_build_action_A) Ctor() {}
//line :124:1
func (t *A_arbace_box_build_action_A) Invoke_O_O_O_O__O(self, what__0, req__1, opts__2 any) any {




	lang.IFn_Cast(A_arbace_box_build_A_const_81.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, opts__2))
//line :124:1
	var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




		tmp1 = lang.IFn_Cast(A_arbace_box_build_A_const_79.GetRawRoot__O()).Invoke_O_O__O(what__0, req__1)
//line :124:1
		return nil
	}()



	lang.IFn_Cast(A_arbace_box_build_A_const_80.GetRawRoot__O()).Invoke__O()
//line :124:1
	if tmp2 != nil { panic(tmp2) }; return tmp1 }
//line :124:1
func (t *A_arbace_box_build_action_A) Invoke_O_O_O__O(self, what__0, req__1 any) any {



	return lang.IFn_Cast(A_arbace_box_build_A_const_79.GetRawRoot__O()).Invoke_O_O__O(what__0, req__1)
}

func A_arbace_box_build_out_file_A_New() *A_arbace_box_build_out_file_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_out_file_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_box_build_out_file_A) Ctor() {}
//line :131:1
func (t *A_arbace_box_build_out_file_A) Invoke_O_O_O_O__O(self, res__0, what__1, name__2 any) any { var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_box_build_A_const_83.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_84.Invoke_O__O(res__0), name__2); if


	jrt.A2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {
		return lang.IFn_Cast(A_arbace_box_build_A_const_67.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_1, nil, Lit_137, nil, Lit_138), jrt.RefArrayOf(jrt.Object_class, nil, what__1, nil, name__2, nil)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_74, res__0))) } }

func A_arbace_box_build_file_tree_A_New() *A_arbace_box_build_file_tree_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_file_tree_A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_box_build_file_tree_A) Ctor() {}
//line :137:1
func (t *A_arbace_box_build_file_tree_A) Invoke_O_O__O(self, m__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_22.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_21.GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 any; var iter__1927001039__auto____2 any; var tmp6 any = A_arbace_box_build_file_tree_iter__598000054__598000058_A_New(); var tmp7 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_box_build_file_tree_iter__598000054__598000058_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_115, false); A_arbace_box_build_file_tree_iter__598000054__598000058_A_fn_class = fncls__13d; tmp7 = fncls__13d } else { tmp7 = fncls__13 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); tmp5 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(m__0); return tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp4, tmp5)) }
//line :140:1
func A_arbace_box_build_file_tree_iter__598000054__598000058_A_New() *A_arbace_box_build_file_tree_iter__598000054__598000058_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_file_tree_iter__598000054__598000058_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_A) Ctor() {}
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_A) Invoke_O_O__O(self, s__598000055__1 any) any { var tmp1 any = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_New_O_O(s__598000055__1, self); var tmp2 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_116, false); A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_fn_class = fncls__12d; tmp2 = fncls__12d } else { tmp2 = fncls__12 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :140:1
func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_New_O_O(p0, p1 any) *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A) Ctor_O_O(c__s__598000055, c__iter__598000054 any) { t.F_s__598000055 = c__s__598000055; t.F_iter__598000054 = c__iter__598000054 }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A) Invoke_O__O(self any) any { { var s__598000055__1 any; var t_ any = t.F_s__598000055; t.F_s__598000055 = nil; s__598000055__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(s__598000055__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000055__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(s__598000055__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(s__598000055__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000057__6 any = lang.IFn_Cast(A_arbace_box_build_A_const_23.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_New_O_I_O(b__598000057__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_117, false); A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_fn_class = fncls__11d; tmp2 = fncls__11d } else { tmp2 = fncls__11 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__598000054); return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000057__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(s__598000055__3))) } else { return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000057__6), nil) } } else { var vec__598000065__4 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(s__598000055__3); var n__5 any = lang.RT_Nth_O_I_O__O(vec__598000065__4, lang.RT_IntCast_J__I(0), nil); var x__6 any = lang.RT_Nth_O_I_O__O(vec__598000065__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000054); return lang.IFn_Cast(A_arbace_box_build_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__5, lang.IFn_Cast(A_arbace_box_build_A_const_25.GetRawRoot__O()).Invoke_O__O(x__6)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__598000055__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :140:1
func A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A) Ctor_O_I_O(c__b__598000057 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000057 = c__b__598000057; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :140:1
func (t *A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A) Invoke_O__O(self any) any { { var i__598000056__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000056__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000061__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000056__1)); var n__3 any = lang.RT_Nth_O_I_O__O(vec__598000061__2, lang.RT_IntCast_J__I(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O(vec__598000061__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_27.GetRawRoot__O()); var tmp3 any = t.F_b__598000057; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(n__3, lang.IFn_Cast(A_arbace_box_build_A_const_25.GetRawRoot__O()).Invoke_O__O(x__4))); i__598000056__1 = lang.Numbers_Unchecked_inc_J__J(i__598000056__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_box_build_arch_defines_A_New() *A_arbace_box_build_arch_defines_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_arch_defines_A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_box_build_arch_defines_A) Ctor() {}
//line :142:1
func (t *A_arbace_box_build_arch_defines_A) Invoke_O_O__O(self, plan__0 any) any { var a__2 any = A_arbace_box_build_A_const_85.Invoke_O__O(plan__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_86.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(Lit_13, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_14, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_88.Invoke_O__O(plan__0))).Ref(), Lit_13, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, a__2)).Ref()); var tmp3 any = A_arbace_box_build_A_const_87; var tmp4 lang.IPersistentVector; var G__598000071__3_ any = a__2; L1:



switch { default: switch lang.Util_Hash_O__I(G__598000071__3_) { case 92926582: if lang.Util_Equiv_O_O__Z(G__598000071__3_, Lit_16) { tmp4 = lang.Tuple_Create_O_O__IPersistentVector(Lit_13, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_89.Invoke_O__O(plan__0))).Ref()); break L1 }; default:}; lang.PersistentVector_Init(); tmp4 = Up_PersistentVector_IPersistentVector(lang.PersistentVector_EMPTY)}; return /*line :144:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }





func A_arbace_box_build_asm_args_A_New() *A_arbace_box_build_asm_args_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_asm_args_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_box_build_asm_args_A) Ctor() {}
//line :150:1
func (t *A_arbace_box_build_asm_args_A) DoInvoke_O_O_O_O_O__O(self, plan__0, pkg__1, out__2, more__3 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_90.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_86.GetRawRoot__O()); var tmp3 any = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, Lit_33, Lit_34, A_arbace_box_build_A_const_91.Invoke_O__O(pkg__1), Lit_35, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_36, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_91.Invoke_O__O(pkg__1), nil)).Ref(), Lit_38, Lit_39, Lit_38, Lit_40)); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_92.GetRawRoot__O()); var tmp5 any = A_arbace_box_build_asm_args_fn__598000074_A_New_O(pkg__1); var tmp6 *jrt.Class
	var fncls__15 /*line :151:1*/*jrt.Class = A_arbace_box_build_asm_args_fn__598000074_A_fn_class

	if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_box_build_asm_args_fn__598000074_A_fn_class = fncls__15d; tmp6 = fncls__15d } else { tmp6 = fncls__15 }
//line :151:1
	return tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O__O(tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), lang.IFn_Cast(A_arbace_box_build_A_const_95.GetRawRoot__O()).Invoke_O__O(plan__0)), more__3, lang.Tuple_Create_O_O__IPersistentVector(Lit_42, out__2)))
}
func A_arbace_box_build_asm_args_fn__598000074_A_New_O(p0 any) *A_arbace_box_build_asm_args_fn__598000074_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_asm_args_fn__598000074_A{}; t.Ctor_O(p0); return t }
//line :153:1
func (t *A_arbace_box_build_asm_args_fn__598000074_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :153:1
func (t *A_arbace_box_build_asm_args_fn__598000074_A) Invoke_O_O__O(self, p1__598000073_SHARP___1 any) any { if lang.Util_Equiv_O_O__Z(p1__598000073_SHARP___1, A_arbace_box_build_A_const_93) { if jrt.A2g_Truth(A_arbace_box_build_A_const_93.Invoke_O__O(t.F_pkg)) { return A_arbace_box_build_A_const_94 } else { return nil } } else { return lang.Tuple_Create_O__IPersistentVector(p1__598000073_SHARP___1) } }




func A_arbace_box_build_ar_member_A_New() *A_arbace_box_build_ar_member_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_ar_member_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_box_build_ar_member_A) Ctor() {}
//line :158:1
func (t *A_arbace_box_build_ar_member_A) Invoke_O_O_O__O(self, name__0, data__1 any) any { var pad__3 any; var tmp1 any = A_arbace_box_build_ar_member_pad__598000077_A_New(); var tmp2 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_box_build_ar_member_pad__598000077_A_fn_class; if
												fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_box_build_ar_member_pad__598000077_A_fn_class = fncls__16d; tmp2 = fncls__16d } else { tmp2 = fncls__16 }; pad__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = /*line :158:1*/lang.IFn_Cast(A_arbace_box_build_A_const_52.GetRawRoot__O()); var tmp4 any = A_arbace_box_build_A_const_54; var hdr__4 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil, nil, nil, nil, nil, Lit_10), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(pad__3).Invoke_O_O__O(tmp3.Invoke_O_O_O__O(name__0, tmp4, jrt.Long_ValueOf_J__Long(lang.Numbers_Min_J_J__J(16, int64(lang.RT_Count_O__I(name__0)))).Ref()), A_arbace_box_build_A_const_98), lang.IFn_Cast(pad__3).Invoke_O_O__O(Lit_11, A_arbace_box_build_A_const_99), lang.IFn_Cast(pad__3).Invoke_O_O__O(Lit_11, A_arbace_box_build_A_const_100), lang.IFn_Cast(pad__3).Invoke_O_O__O(Lit_11, A_arbace_box_build_A_const_100), lang.IFn_Cast(pad__3).Invoke_O_O__O(Lit_12, A_arbace_box_build_A_const_101), lang.IFn_Cast(pad__3).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_14.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](data__1, jrt.Prim_byte.ArrayClass()))).Ref()), A_arbace_box_build_A_const_102), nil)).Ref(); var o__5 any = jrt.ByteArrayOutputStream_New();



	jrt.OutputStream_Cast(o__5).Write_B1__V(jrt.NN(jrt.String_Cast(hdr__4)).GetBytes_Charset__B1(jrt.StandardCharsets_US_ASCII));
	jrt.OutputStream_Cast(o__5).Write_B1__V(jrt.A2g_CastArray[*jrt.ByteArray](data__1, jrt.Prim_byte.ArrayClass())); if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_103.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Alength_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](data__1, jrt.Prim_byte.ArrayClass()))).Ref())) { jrt.NN(jrt.ByteArrayOutputStream_Cast(o__5)).Write_I__V(lang.RT_IntCast_J__I(10)) }; return /*line :165:1*/ jrt.NN(jrt.ByteArrayOutputStream_Cast(o__5)).ToByteArray__B1().Ref() }
//line :159:1
func A_arbace_box_build_ar_member_pad__598000077_A_New() *A_arbace_box_build_ar_member_pad__598000077_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_ar_member_pad__598000077_A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_box_build_ar_member_pad__598000077_A) Ctor() {}
//line :159:1
func (t *A_arbace_box_build_ar_member_pad__598000077_A) Invoke_O_O_O__O(self, s__1, n__2 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, s__1, lang.IFn_Cast(A_arbace_box_build_A_const_51.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_14.GetRawRoot__O(), lang.IFn_Cast(A_arbace_box_build_A_const_96.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Minus_O_J__Number(n__2, int64(lang.RT_Count_O__I(s__1))), A_arbace_box_build_A_const_97)))).Ref() }







func A_arbace_box_build_append_members_A_New() *A_arbace_box_build_append_members_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_append_members_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_box_build_append_members_A) Ctor() {}
//line :167:1
func (t *A_arbace_box_build_append_members_A) Invoke_O_O_O__O(self, archive__0, members__1 any) any { var o__3 any = jrt.ByteArrayOutputStream_New();

	jrt.OutputStream_Cast(o__3).Write_B1__V(jrt.A2g_CastArray[*jrt.ByteArray](archive__0, jrt.Prim_byte.ArrayClass())); var seq_598000080__4 any = /*line :167:1*/lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(members__1); var chunk_598000081__5 any; var count_598000082__6 int64 = 0; var i_598000083__7 int64 = 0; L1: for {


		if lang.Numbers_Lt_J_J__Z(i_598000083__7, count_598000082__6) { var vec__598000084__8 any = lang.Indexed_Cast(chunk_598000081__5).Nth_I__O(lang.RT_IntCast_J__I(i_598000083__7)); var n__9 any = lang.RT_Nth_O_I_O__O(vec__598000084__8, lang.RT_IntCast_J__I(0), nil); var data__10 any = lang.RT_Nth_O_I_O__O(vec__598000084__8, lang.RT_IntCast_J__I(1), nil); jrt.OutputStream_Cast(o__3).Write_B1__V(jrt.A2g_CastArray[*jrt.ByteArray](lang.IFn_Cast(A_arbace_box_build_A_const_104.GetRawRoot__O()).Invoke_O_O__O(n__9, data__10), jrt.Prim_byte.ArrayClass())); seq_598000080__4, chunk_598000081__5, count_598000082__6, i_598000083__7 = seq_598000080__4, chunk_598000081__5, count_598000082__6, lang.Numbers_Unchecked_inc_J__J(i_598000083__7); continue L1 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_598000080__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_598000080__9 any = temp__1927000414__auto____8; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(seq_598000080__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(seq_598000080__9); seq_598000080__4, chunk_598000081__5, count_598000082__6, i_598000083__7 = lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_598000080__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__598000087__10 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(seq_598000080__9); var n__11 any = lang.RT_Nth_O_I_O__O(vec__598000087__10, lang.RT_IntCast_J__I(0), nil); var data__12 any = lang.RT_Nth_O_I_O__O(vec__598000087__10, lang.RT_IntCast_J__I(1), nil); jrt.OutputStream_Cast(o__3).Write_B1__V(jrt.A2g_CastArray[*jrt.ByteArray](lang.IFn_Cast(A_arbace_box_build_A_const_104.GetRawRoot__O()).Invoke_O_O__O(n__11, data__12), jrt.Prim_byte.ArrayClass())); seq_598000080__4, chunk_598000081__5, count_598000082__6, i_598000083__7 = lang.IFn_Cast(A_arbace_box_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_598000080__9), nil, 0, 0; continue L1 } } }
//line :167:1
		break L1 }; return /*line :171:1*/ jrt.NN(jrt.ByteArrayOutputStream_Cast(o__3)).ToByteArray__B1().Ref() }






func A_arbace_box_build_complete_QMARK__A_New() *A_arbace_box_build_complete_QMARK__A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_complete_QMARK__A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_box_build_complete_QMARK__A) Ctor() {}
//line :178:1
func (t *A_arbace_box_build_complete_QMARK__A) Invoke_O_O__O(self, pkg__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_box_build_A_const_105.GetRawRoot__O()).Invoke_O__O(A_arbace_box_build_A_const_106.Invoke_O__O(pkg__0)); if


	jrt.A2g_Truth(and__1927000168__auto____2) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_68.GetRawRoot__O()); var tmp2 any; var and__1927000168__auto____3 any = A_arbace_box_build_A_const_93.Invoke_O__O(pkg__0); if jrt.A2g_Truth(and__1927000168__auto____3) { tmp2 = lang.IFn_Cast(A_arbace_box_build_A_const_107.GetRawRoot__O()).Invoke_O__O(A_arbace_box_build_A_const_91.Invoke_O__O(pkg__0)) } else { tmp2 = and__1927000168__auto____3 }; return tmp1.Invoke_O__O(tmp2) } else { return and__1927000168__auto____2 } }

func A_arbace_box_build_deps_tree_A_New() *A_arbace_box_build_deps_tree_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_box_build_deps_tree_A) Ctor() {}
//line :183:1
func (t *A_arbace_box_build_deps_tree_A) Invoke_O_O_O_O__O(self, archives__0, index__1, paths__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_22.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_21.GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 any; var iter__1927001039__auto____4 any; var tmp6 any = A_arbace_box_build_deps_tree_iter__598000092__598000096_A_New_O_O(archives__0, index__1); var tmp7 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000092__598000096_A_fn_class; if



	fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_90, false); A_arbace_box_build_deps_tree_iter__598000092__598000096_A_fn_class = fncls__22d; tmp7 = fncls__22d } else { tmp7 = fncls__22 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); tmp5 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(paths__2); var tmp8 any = /*line :183:1*/tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp4, tmp5)); var tmp9 any; var iter__1927001039__auto____4_2 any; var tmp10 any = A_arbace_box_build_deps_tree_iter__598000102__598000106_A_New_O(index__1); var tmp11 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000102__598000106_A_fn_class; if




	fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_91, false); A_arbace_box_build_deps_tree_iter__598000102__598000106_A_fn_class = fncls__19d; tmp11 = fncls__19d } else { tmp11 = fncls__19 }; iter__1927001039__auto____4_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); tmp9 = lang.IFn_Cast(iter__1927001039__auto____4_2).Invoke_O__O(paths__2); return /*line :183:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9) }



func A_arbace_box_build_deps_tree_iter__598000092__598000096_A_New_O_O(p0, p1 any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000092__598000096_A{}; t.Ctor_O_O(p0, p1); return t }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_A) Ctor_O_O(c__archives, c__index any) { t.F_archives = c__archives; t.F_index = c__index }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_A) Invoke_O_O__O(self, s__598000093__1 any) any { var tmp1 any = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_New_O_O_O_O(t.F_archives, t.F_index, self, s__598000093__1); var tmp2 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_92, false); A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_fn_class = fncls__21d; tmp2 = fncls__21d } else { tmp2 = fncls__21 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :187:1
func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A) Ctor_O_O_O_O(c__archives, c__index, c__iter__598000092, c__s__598000093 any) { t.F_archives = c__archives; t.F_index = c__index; t.F_iter__598000092 = c__iter__598000092; t.F_s__598000093 = c__s__598000093 }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A) Invoke_O__O(self any) any { { var s__598000093__1 any; var t_ any = t.F_s__598000093; t.F_s__598000093 = nil; s__598000093__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(s__598000093__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000093__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(s__598000093__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(s__598000093__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000095__6 any = lang.IFn_Cast(A_arbace_box_build_A_const_23.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_New_O_O_O_I_O(b__598000095__6, t.F_archives, t.F_index, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_93, false); A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_fn_class = fncls__20d; tmp2 = fncls__20d } else { tmp2 = fncls__20 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__598000092); return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000095__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(s__598000093__3))) } else { return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000095__6), nil) } } else { var p__4 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(s__598000093__3); var a__5 any = lang.IFn_Cast(t.F_archives).Invoke_O__O(p__4); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000092); return lang.IFn_Cast(A_arbace_box_build_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(t.F_index).Invoke_O__O(p__4), nil)).Ref(), a__5), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__598000093__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :187:1
func A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A) Ctor_O_O_O_I_O(c__b__598000095, c__archives, c__index any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000095 = c__b__598000095; t.F_archives = c__archives; t.F_index = c__index; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :187:1
func (t *A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A) Invoke_O__O(self any) any { { var i__598000094__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000094__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000094__1)); var a__3 any = lang.IFn_Cast(t.F_archives).Invoke_O__O(p__2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_27.GetRawRoot__O()); var tmp3 any = t.F_b__598000095; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(t.F_index).Invoke_O__O(p__2), nil)).Ref(), a__3)); i__598000094__1 = lang.Numbers_Unchecked_inc_J__J(i__598000094__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
func A_arbace_box_build_deps_tree_iter__598000102__598000106_A_New_O(p0 any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000102__598000106_A{}; t.Ctor_O(p0); return t }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_A) Ctor_O(c__index any) { t.F_index = c__index }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_A) Invoke_O_O__O(self, s__598000103__1 any) any { var tmp1 any = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_New_O_O_O(s__598000103__1, t.F_index, self); var tmp2 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_95, false); A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_fn_class = fncls__18d; tmp2 = fncls__18d } else { tmp2 = fncls__18 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :188:1
func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A) Ctor_O_O_O(c__s__598000103, c__index, c__iter__598000102 any) { t.F_s__598000103 = c__s__598000103; t.F_index = c__index; t.F_iter__598000102 = c__iter__598000102 }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A) Invoke_O__O(self any) any { { var s__598000103__1 any; var t_ any = t.F_s__598000103; t.F_s__598000103 = nil; s__598000103__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(s__598000103__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000103__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(s__598000103__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(s__598000103__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000105__6 any = lang.IFn_Cast(A_arbace_box_build_A_const_23.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_New_O_O_I_O(t.F_index, b__598000105__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_96, false); A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_fn_class = fncls__17d; tmp2 = fncls__17d } else { tmp2 = fncls__17 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__598000102); return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000105__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(s__598000103__3))) } else { return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000105__6), nil) } } else { var p__4 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(s__598000103__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000102); return lang.IFn_Cast(A_arbace_box_build_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_97, nil, Lit_98, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, nil, p__4, nil, lang.IFn_Cast(t.F_index).Invoke_O__O(p__4), nil)).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__598000103__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :188:1
func A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A) Ctor_O_O_I_O(c__index, c__b__598000105 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_index = c__index; t.F_b__598000105 = c__b__598000105; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :188:1
func (t *A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A) Invoke_O__O(self any) any { { var i__598000104__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000104__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000104__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_27.GetRawRoot__O()); var tmp3 any = t.F_b__598000105; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_97, nil, Lit_98, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, nil, p__2, nil, lang.IFn_Cast(t.F_index).Invoke_O__O(p__2), nil)).Ref()); i__598000104__1 = lang.Numbers_Unchecked_inc_J__J(i__598000104__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_box_build_json_str_A_New() *A_arbace_box_build_json_str_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_json_str_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_box_build_json_str_A) Ctor() {}
//line :190:1
func (t *A_arbace_box_build_json_str_A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_123, nil, Lit_123); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_51.GetRawRoot__O()); var tmp3 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_108.GetRawRoot__O()); var tmp5 any = A_arbace_box_build_json_str_fn__598000113_A_New(); var tmp6 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_box_build_json_str_fn__598000113_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_124, false); A_arbace_box_build_json_str_fn__598000113_A_fn_class = fncls__23d; tmp6 = fncls__23d } else { tmp6 = fncls__23 }; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), s__0)), nil)).Ref() }
//line :193:1
func A_arbace_box_build_json_str_fn__598000113_A_New() *A_arbace_box_build_json_str_fn__598000113_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_json_str_fn__598000113_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_box_build_json_str_fn__598000113_A) Ctor() {}
//line :193:1
func (t *A_arbace_box_build_json_str_fn__598000113_A) Invoke_O_O__O(self, c__1 any) any { if lang.Util_Equiv_O_O__Z(c__1, A_arbace_box_build_A_const_109) { return Lit_125 } else { if lang.Util_Equiv_O_O__Z(c__1, A_arbace_box_build_A_const_110) { return Lit_126 } else { if lang.Numbers_Lt_J_J__Z(int64(lang.RT_IntCast_O__I(c__1)), 32) {
											return lang.IFn_Cast(A_arbace_box_build_A_const_77.GetRawRoot__O()).Invoke_O_O__O(Lit_127, jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_O__I(c__1)).Ref()) } else {
//line :193:1
		if A_arbace_box_build_A_const_111 != nil {

			return lang.IFn_Cast(A_arbace_box_build_A_const_14.GetRawRoot__O()).Invoke_O__O(c__1) } else {
//line :193:1
				return nil } } } } }





func A_arbace_box_build_embed_config_A_New() *A_arbace_box_build_embed_config_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_box_build_embed_config_A) Ctor() {}
//line :199:1
func (t *A_arbace_box_build_embed_config_A) Invoke_O_O__O(self, patterns__0 any) any { var files__2 any = lang.IFn_Cast(A_arbace_box_build_A_const_112.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_113.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_92.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_114.GetRawRoot__O(), patterns__0))); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_99, nil, Lit_100, nil, Lit_101); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_51.GetRawRoot__O()); var tmp3 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_115.GetRawRoot__O()); var tmp5 any; var iter__1927001039__auto____8 any; var tmp6 any = A_arbace_box_build_embed_config_iter__598000116__598000120_A_New(); var tmp7 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_box_build_embed_config_iter__598000116__598000120_A_fn_class; if





	fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_103, false); A_arbace_box_build_embed_config_iter__598000116__598000120_A_fn_class = fncls__26d; tmp7 = fncls__26d } else { tmp7 = fncls__26 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); tmp5 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_117.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_118.GetRawRoot__O(), patterns__0)); var tmp8 any = /*line :204:1*/tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(Lit_102, tmp5)); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_51.GetRawRoot__O()); var tmp10 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_115.GetRawRoot__O()); var tmp12 any; var iter__1927001039__auto____8_2 any; var tmp13 any = A_arbace_box_build_embed_config_iter__598000132__598000136_A_New(); var tmp14 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_box_build_embed_config_iter__598000132__598000136_A_fn_class; if



	fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_104, false); A_arbace_box_build_embed_config_iter__598000132__598000136_A_fn_class = fncls__29d; tmp14 = fncls__29d } else { tmp14 = fncls__29 }; iter__1927001039__auto____8_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); tmp12 = lang.IFn_Cast(iter__1927001039__auto____8_2).Invoke_O__O(files__2); return /*line :204:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil, tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O__O(Lit_102, tmp12)), nil)).Ref() }
func A_arbace_box_build_embed_config_iter__598000116__598000120_A_New() *A_arbace_box_build_embed_config_iter__598000116__598000120_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000116__598000120_A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_A) Ctor() {}
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_A) Invoke_O_O__O(self, s__598000117__1 any) any { var tmp1 any = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_New_O_O(self, s__598000117__1); var tmp2 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_105, false); A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_fn_class = fncls__25d; tmp2 = fncls__25d } else { tmp2 = fncls__25 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :205:1
func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_New_O_O(p0, p1 any) *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A{}; t.Ctor_O_O(p0, p1); return t }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A) Ctor_O_O(c__iter__598000116, c__s__598000117 any) { t.F_iter__598000116 = c__iter__598000116; t.F_s__598000117 = c__s__598000117 }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A) Invoke_O__O(self any) any { { var s__598000117__1 any; var t_ any = t.F_s__598000117; t.F_s__598000117 = nil; s__598000117__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(s__598000117__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000117__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(s__598000117__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(s__598000117__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000119__6 any = lang.IFn_Cast(A_arbace_box_build_A_const_23.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_New_O_I_O(b__598000119__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_106, false); A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_fn_class = fncls__24d; tmp2 = fncls__24d } else { tmp2 = fncls__24 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__598000116); return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000119__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(s__598000117__3))) } else { return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000119__6), nil) } } else { var vec__598000127__4 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(s__598000117__3); var p__5 any = lang.RT_Nth_O_I_O__O(vec__598000127__4, lang.RT_IntCast_J__I(0), nil); var fs__6 any = lang.RT_Nth_O_I_O__O(vec__598000127__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000116); return lang.IFn_Cast(A_arbace_box_build_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_107, nil, Lit_108), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_box_build_A_const_116.GetRawRoot__O()).Invoke_O__O(p__5), nil, lang.IFn_Cast(A_arbace_box_build_A_const_51.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_14.GetRawRoot__O(), lang.IFn_Cast(A_arbace_box_build_A_const_115.GetRawRoot__O()).Invoke_O_O__O(Lit_102, lang.IFn_Cast(A_arbace_box_build_A_const_108.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_116.GetRawRoot__O(), fs__6))), nil)).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__598000117__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :205:1
func A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A) Ctor_O_I_O(c__b__598000119 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000119 = c__b__598000119; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :205:1
func (t *A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A) Invoke_O__O(self any) any { { var i__598000118__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000118__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000123__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000118__1)); var p__3 any = lang.RT_Nth_O_I_O__O(vec__598000123__2, lang.RT_IntCast_J__I(0), nil); var fs__4 any = lang.RT_Nth_O_I_O__O(vec__598000123__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_27.GetRawRoot__O()); var tmp3 any = t.F_b__598000119; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_107, nil, Lit_108), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_box_build_A_const_116.GetRawRoot__O()).Invoke_O__O(p__3), nil, lang.IFn_Cast(A_arbace_box_build_A_const_51.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_14.GetRawRoot__O(), lang.IFn_Cast(A_arbace_box_build_A_const_115.GetRawRoot__O()).Invoke_O_O__O(Lit_102, lang.IFn_Cast(A_arbace_box_build_A_const_108.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_116.GetRawRoot__O(), fs__4))), nil)).Ref()); i__598000118__1 = lang.Numbers_Unchecked_inc_J__J(i__598000118__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_box_build_embed_config_iter__598000132__598000136_A_New() *A_arbace_box_build_embed_config_iter__598000132__598000136_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000132__598000136_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_A) Ctor() {}
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_A) Invoke_O_O__O(self, s__598000133__1 any) any { var tmp1 any = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_New_O_O(s__598000133__1, self); var tmp2 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_109, false); A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_fn_class = fncls__28d; tmp2 = fncls__28d } else { tmp2 = fncls__28 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :208:1
func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_New_O_O(p0, p1 any) *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A{}; t.Ctor_O_O(p0, p1); return t }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A) Ctor_O_O(c__s__598000133, c__iter__598000132 any) { t.F_s__598000133 = c__s__598000133; t.F_iter__598000132 = c__iter__598000132 }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A) Invoke_O__O(self any) any { { var s__598000133__1 any; var t_ any = t.F_s__598000133; t.F_s__598000133 = nil; s__598000133__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(s__598000133__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000133__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(s__598000133__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(s__598000133__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000135__6 any = lang.IFn_Cast(A_arbace_box_build_A_const_23.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_New_O_I_O(b__598000135__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_110, false); A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_fn_class = fncls__27d; tmp2 = fncls__27d } else { tmp2 = fncls__27 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__598000132); return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000135__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(s__598000133__3))) } else { return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000135__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(s__598000133__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000132); return lang.IFn_Cast(A_arbace_box_build_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_111, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_box_build_A_const_116.GetRawRoot__O()).Invoke_O__O(f__4), nil, lang.IFn_Cast(A_arbace_box_build_A_const_116.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__4)).Ref()))).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__598000133__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :208:1
func A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A) Ctor_O_I_O(c__b__598000135 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000135 = c__b__598000135; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :208:1
func (t *A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A) Invoke_O__O(self any) any { { var i__598000134__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000134__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000134__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_27.GetRawRoot__O()); var tmp3 any = t.F_b__598000135; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_111, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_box_build_A_const_116.GetRawRoot__O()).Invoke_O__O(f__2), nil, lang.IFn_Cast(A_arbace_box_build_A_const_116.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__2)).Ref()))).Ref()); i__598000134__1 = lang.Numbers_Unchecked_inc_J__J(i__598000134__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_box_build_build_package_A_New() *A_arbace_box_build_build_package_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_box_build_build_package_A) Ctor() {}
//line :211:1
func (t *A_arbace_box_build_build_package_A) Invoke_O_O_O_O_O__O(self, plan__0, pkg__1, archives__2, index__3 any) any { var map__598000145__5 any = A_arbace_box_build_A_const_49.Get__O(); var map__598000145__6 any; if


	lang.ISeq_InstanceOf(map__598000145__5) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_20.GetRawRoot__O()).Invoke_O__O(map__598000145__5)) { map__598000145__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_box_build_A_const_119.GetRawRoot__O()).Invoke_O__O(map__598000145__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(map__598000145__5)) { map__598000145__6 = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(map__598000145__5) } else { lang.PersistentArrayMap_Init(); map__598000145__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__598000145__6 = map__598000145__5 }; var tools__7 any = /*line :211:1*/lang.RT_Get_O_O__O(map__598000145__6, A_arbace_box_build_A_const_120); var P__8_ any = A_arbace_box_build_A_const_91.Invoke_O__O(pkg__1); var imports__9 any = A_arbace_box_build_A_const_121.Invoke_O__O(pkg__1); var vec__598000147__10 any = lang.IFn_Cast(A_arbace_box_build_A_const_122.GetRawRoot__O()).Invoke_O_O_O__O(archives__2, index__3, imports__9); var dtree__11 any = lang.RT_Nth_O_I_O__O(vec__598000147__10, lang.RT_IntCast_J__I(0), nil); var lines__12 any = lang.RT_Nth_O_I_O__O(vec__598000147__10, lang.RT_IntCast_J__I(1), nil); var importcfg__13 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil, nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_51.GetRawRoot__O()); var tmp3 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var tmp4 any; var iter__1927001039__auto____16 any; var tmp5 any = A_arbace_box_build_build_package_iter__598000150__598000154_A_New(); var tmp6 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_box_build_build_package_iter__598000150__598000154_A_fn_class; if







	fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_box_build_build_package_iter__598000150__598000154_A_fn_class = fncls__36d; tmp6 = fncls__36d } else { tmp6 = fncls__36 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_box_build_A_const_135.Invoke_O__O(pkg__1))); var tmp7 any = /*line :218:1*/tmp2.Invoke_O_O__O(tmp3, tmp4); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_51.GetRawRoot__O()); var tmp9 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var tmp10 any; var iter__1927001039__auto____16_2 any; var tmp11 any = A_arbace_box_build_build_package_iter__598000166__598000170_A_New(); var tmp12 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_box_build_build_package_iter__598000166__598000170_A_fn_class; if

	fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_box_build_build_package_iter__598000166__598000170_A_fn_class = fncls__39d; tmp12 = fncls__39d } else { tmp12 = fncls__39 }; iter__1927001039__auto____16_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); tmp10 = lang.IFn_Cast(iter__1927001039__auto____16_2).Invoke_O__O(lines__12); importcfg__13 = /*line :218:1*/lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, tmp8.Invoke_O_O__O(tmp9, tmp10))).Ref(); var sfiles__14 any = /*line :211:1*/A_arbace_box_build_A_const_106.Invoke_O__O(pkg__1); var res_of__15 any; var tmp13 any = A_arbace_box_build_build_package_res_of__598000176_A_New_O(P__8_); var tmp14 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_box_build_build_package_res_of__598000176_A_fn_class; if










	fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_box_build_build_package_res_of__598000176_A_fn_class = fncls__30d; tmp14 = fncls__30d } else { tmp14 = fncls__30 }; res_of__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var rsc__16 any; var tmp15 /*line :211:1*/*lang.Keyword = A_arbace_box_build_A_const_125; var or__1927000174__auto____16 any = lang.RT_Get_O_O__O(tmp15.Invoke_O__O(A_arbace_box_build_A_const_49.Get__O()), P__8_); if














	jrt.A2g_Truth(or__1927000174__auto____16) { rsc__16 = or__1927000174__auto____16 } else {
		var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_126.GetRawRoot__O()); var tmp17 any = A_arbace_box_build_build_package_fn__598000179_A_New_O(P__8_); var tmp18 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_box_build_build_package_fn__598000179_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_box_build_build_package_fn__598000179_A_fn_class = fncls__40d; tmp18 = fncls__40d } else { tmp18 = fncls__40 }; var tmp19 *lang.Keyword = A_arbace_box_build_A_const_125; rsc__16 = tmp16.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil), lang.IFn_Cast(A_arbace_box_build_A_const_117.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_138.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_box_build_A_const_139.GetRawRoot__O(), A_arbace_box_build_A_const_140.GetRawRoot__O(), A_arbace_box_build_A_const_14.GetRawRoot__O(), A_arbace_box_build_A_const_118.GetRawRoot__O()), tmp19.Invoke_O__O(A_arbace_box_build_A_const_49.Get__O()))) }; var ___17 any; var tmp20 any; var and__1927000168__auto____17 any = /*line :211:1*/A_arbace_box_build_A_const_127.Invoke_O__O(pkg__1); _ = ___17; if



















	jrt.A2g_Truth(and__1927000168__auto____17) { tmp20 = lang.IFn_Cast(A_arbace_box_build_A_const_68.GetRawRoot__O()).Invoke_O__O(A_arbace_box_build_A_const_129.Invoke_O__O(pkg__1)) } else { tmp20 = and__1927000168__auto____17 }; if jrt.A2g_Truth(tmp20) {
		___17 = lang.IFn_Cast(A_arbace_box_build_A_const_67.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_1, nil, Lit_50), jrt.RefArrayOf(jrt.Object_class, nil, P__8_, nil)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_91, P__8_))) } else {
//line :231:1
			___17 = nil }; var embedcfg__18 any; var tmp21 /*line :211:1*/*lang.Keyword = A_arbace_box_build_A_const_128; var temp__1927000414__auto____18 any = tmp21.Invoke_O__O(A_arbace_box_build_A_const_129.Invoke_O__O(pkg__1)); if





















	jrt.A2g_Truth(temp__1927000414__auto____18) { var pats__19 any = temp__1927000414__auto____18
		embedcfg__18 = lang.IFn_Cast(A_arbace_box_build_A_const_130.GetRawRoot__O()).Invoke_O__O(pats__19) } else {
//line :233:1
			embedcfg__18 = nil }; var symabis__19 any; if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(sfiles__14)) {
		var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_131.GetRawRoot__O()); var tmp23 lang.IFn = lang.IFn_Cast(res_of__15); var tmp24 any = A_arbace_box_build_A_const_141; var tmp25 any = A_arbace_box_build_A_const_142.Invoke_O__O(tools__7); var tmp26 any = A_arbace_box_build_A_const_78; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_21.GetRawRoot__O()); var tmp28 any = lang.IFn_Cast(A_arbace_box_build_A_const_144.GetRawRoot__O()).Invoke_O_O_O_O__O(plan__0, pkg__1, Lit_52, Lit_53); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_108.GetRawRoot__O()); var tmp30 any = A_arbace_box_build_build_package_fn__598000184_A_New(); var tmp31 *jrt.Class
		var fncls__41 /*line :236:1*/*jrt.Class = A_arbace_box_build_build_package_fn__598000184_A_fn_class

		if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_box_build_build_package_fn__598000184_A_fn_class = fncls__41d; tmp31 = fncls__41d } else { tmp31 = fncls__41 }
//line :236:1
		var tmp32 any = tmp27.Invoke_O_O__O(tmp28, tmp29.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil), sfiles__14)); var tmp33 any = A_arbace_box_build_A_const_143; symabis__19 = tmp22.Invoke_O_O_O__O(tmp23.Invoke_O_O__O(Lit_51, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp24, tmp25, tmp26, tmp32, tmp33, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(Lit_55, A_arbace_box_build_A_const_43.Invoke_O__O(pkg__1)), lang.Tuple_Create_O_O__IPersistentVector(Lit_40, A_arbace_box_build_A_const_44.Invoke_O__O(plan__0)), lang.Tuple_Create_O_O__IPersistentVector(Lit_56, lang.IFn_Cast(A_arbace_box_build_A_const_145.GetRawRoot__O()).Invoke_O__O(A_arbace_box_build_A_const_146)))))), P__8_, Lit_51) } else {
//line :235:1
			symabis__19 = nil }; var compile__20 any; var tmp34 lang.IFn = /*line :211:1*/lang.IFn_Cast(res_of__15); var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_123.GetRawRoot__O()); var tmp36 any = A_arbace_box_build_A_const_141; var tmp37 any = A_arbace_box_build_A_const_147.Invoke_O__O(tools__7); var tmp38 any = A_arbace_box_build_A_const_78; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_90.GetRawRoot__O()); var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_86.GetRawRoot__O()); var tmp41 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_36, nil, Lit_59), jrt.RefArrayOf(jrt.Object_class, nil, P__8_, nil)).Ref(); var tmp42 any; if

































	lang.Util_Equiv_O_O__Z(Lit_60, A_arbace_box_build_A_const_149.Invoke_O__O(pkg__1)) { tmp42 = Lit_60 } else { tmp42 = P__8_ }; var tmp43 any = /*line :241:1*/lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, Lit_57, Lit_42, Lit_58, Lit_35, tmp41, Lit_34, tmp42, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_box_build_A_const_150.Invoke_O__O(pkg__1))).Ref())); var tmp44 any; if




	jrt.A2g_Truth(A_arbace_box_build_A_const_93.Invoke_O__O(pkg__1)) { tmp44 = A_arbace_box_build_A_const_151 } else { tmp44 = nil }; var tmp45 any = tmp44; var tmp46 any; if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_152.GetRawRoot__O()).Invoke_O__O(pkg__1)) { tmp46 = A_arbace_box_build_A_const_153 } else { tmp46 = nil }; var tmp47 any = tmp46; var tmp48 any = A_arbace_box_build_A_const_154; var tmp49 any; if

	jrt.A2g_Truth(symabis__19) { tmp49 = A_arbace_box_build_A_const_155 } else { tmp49 = nil }; var tmp50 any = tmp49; var tmp51 any = A_arbace_box_build_A_const_156; var tmp52 any; if

	jrt.A2g_Truth(embedcfg__18) { tmp52 = A_arbace_box_build_A_const_157 } else { tmp52 = nil }; var tmp53 any = tmp52; var tmp54 any; if
	jrt.A2g_Truth(symabis__19) { tmp54 = A_arbace_box_build_A_const_158 } else { tmp54 = nil }; var tmp55 any = tmp54; var tmp56 lang.IFn = /*line :241:1*/lang.IFn_Cast(A_arbace_box_build_A_const_108.GetRawRoot__O()); var tmp57 any = A_arbace_box_build_build_package_fn__598000186_A_New(); var tmp58 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_box_build_build_package_fn__598000186_A_fn_class; if











	fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); A_arbace_box_build_build_package_fn__598000186_A_fn_class = fncls__42d; tmp58 = fncls__42d } else { tmp58 = fncls__42 }; var tmp59 any = /*line :241:1*/tmp39.Invoke_O__O(tmp40.Invoke_O_O_O_O_O_O_O_O_O__O(tmp43, tmp45, tmp47, tmp48, tmp50, tmp51, tmp53, tmp55, tmp56.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp57, tmp58, nil), A_arbace_box_build_A_const_159.Invoke_O__O(pkg__1)))); var tmp60 any = A_arbace_box_build_A_const_143; var tmp61 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_90.GetRawRoot__O()); var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_86.GetRawRoot__O()); var tmp63 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_55, A_arbace_box_build_A_const_43.Invoke_O__O(pkg__1)); var tmp64 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_63, dtree__11); var tmp65 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_22.GetRawRoot__O()); var tmp66 any; var G__598000188__20_ any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_64, lang.IFn_Cast(A_arbace_box_build_A_const_25.GetRawRoot__O()).Invoke_O__O(importcfg__13))); var G__598000188__21_ any; if













	jrt.A2g_Truth(symabis__19) {
		G__598000188__21_ = lang.IFn_Cast(A_arbace_box_build_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(G__598000188__20_, Lit_51, symabis__19) } else {
//line :255:1
			G__598000188__21_ = G__598000188__20_ }; if jrt.A2g_Truth(embedcfg__18) {

				tmp66 = lang.IFn_Cast(A_arbace_box_build_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(G__598000188__21_, Lit_65, lang.IFn_Cast(A_arbace_box_build_A_const_25.GetRawRoot__O()).Invoke_O__O(embedcfg__18)) } else {
//line :255:1
					tmp66 = G__598000188__21_ }; compile__20 = /*line :241:1*/tmp34.Invoke_O_O__O(Lit_57, tmp35.Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp36, tmp37, tmp38, tmp59, tmp60, tmp61.Invoke_O__O(tmp62.Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp63, tmp64, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp65.Invoke_O__O(tmp66))))))), lang.IFn_Cast(A_arbace_box_build_A_const_148.GetRawRoot__O()).Invoke_O_O__O(rsc__16, A_arbace_box_build_A_const_160))); var archive__21 any = /*line :211:1*/lang.IFn_Cast(A_arbace_box_build_A_const_131.GetRawRoot__O()).Invoke_O_O_O__O(compile__20, P__8_, Lit_66); if
















































	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_105.GetRawRoot__O()).Invoke_O__O(sfiles__14)) { return archive__21 } else { var asmh__22 any = lang.IFn_Cast(A_arbace_box_build_A_const_131.GetRawRoot__O()).Invoke_O_O_O__O(compile__20, P__8_, Lit_67); var ctree__23 any = lang.IFn_Cast(A_arbace_box_build_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_67, asmh__22))); var objs__24 any; var tmp67 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_132.GetRawRoot__O()); var tmp68 any; var iter__1927001039__auto____24 any; var tmp69 any = A_arbace_box_build_build_package_iter__598000189__598000193_A_New_O_O_O_O_O_O(res_of__15, P__8_, plan__0, ctree__23, pkg__1, tools__7); var tmp70 *jrt.Class
		var fncls__47 /*line :260:1*/*jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_A_fn_class




		if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); A_arbace_box_build_build_package_iter__598000189__598000193_A_fn_class = fncls__47d; tmp70 = fncls__47d } else { tmp70 = fncls__47 }; iter__1927001039__auto____24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp69, tmp70, nil); tmp68 = lang.IFn_Cast(iter__1927001039__auto____24).Invoke_O__O(sfiles__14)
//line :264:1
		objs__24 = tmp67.Invoke_O__O(tmp68)
//line :260:1
		var members__25 any; var iter__1927001039__auto____25 any; var tmp71 any = A_arbace_box_build_build_package_iter__598000203__598000207_A_New(); var tmp72 *jrt.Class
		var fncls__33 /*line :260:1*/*jrt.Class = A_arbace_box_build_build_package_iter__598000203__598000207_A_fn_class












		if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_69, false); A_arbace_box_build_build_package_iter__598000203__598000207_A_fn_class = fncls__33d; tmp72 = fncls__33d } else { tmp72 = fncls__33 }; iter__1927001039__auto____25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp71, tmp72, nil); members__25 = lang.IFn_Cast(iter__1927001039__auto____25).Invoke_O__O(objs__24)
		return lang.IFn_Cast(A_arbace_box_build_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_162.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_133.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_134.GetRawRoot__O()).Invoke_O__O(archive__21)), members__25)) } }
//line :219:1
func A_arbace_box_build_build_package_iter__598000150__598000154_A_New() *A_arbace_box_build_build_package_iter__598000150__598000154_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000150__598000154_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_A) Ctor() {}
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_A) Invoke_O_O__O(self, s__598000151__1 any) any { var tmp1 any = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_New_O_O(self, s__598000151__1); var tmp2 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_73, false); A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_fn_class = fncls__35d; tmp2 = fncls__35d } else { tmp2 = fncls__35 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :219:1
func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_New_O_O(p0, p1 any) *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A{}; t.Ctor_O_O(p0, p1); return t }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A) Ctor_O_O(c__iter__598000150, c__s__598000151 any) { t.F_iter__598000150 = c__iter__598000150; t.F_s__598000151 = c__s__598000151 }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A) Invoke_O__O(self any) any { { var s__598000151__1 any; var t_ any = t.F_s__598000151; t.F_s__598000151 = nil; s__598000151__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(s__598000151__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000151__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(s__598000151__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(s__598000151__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000153__6 any = lang.IFn_Cast(A_arbace_box_build_A_const_23.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_New_O_I_O(b__598000153__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_74, false); A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_fn_class = fncls__34d; tmp2 = fncls__34d } else { tmp2 = fncls__34 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__598000150); return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000153__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(s__598000151__3))) } else { return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000153__6), nil) } } else { var vec__598000161__4 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(s__598000151__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__598000161__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__598000161__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000150); return lang.IFn_Cast(A_arbace_box_build_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_75, nil, Lit_76, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, nil, k__5, nil, v__6, nil)).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__598000151__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :219:1
func A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A) Ctor_O_I_O(c__b__598000153 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000153 = c__b__598000153; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :219:1
func (t *A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A) Invoke_O__O(self any) any { { var i__598000152__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000152__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000157__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000152__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__598000157__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__598000157__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_27.GetRawRoot__O()); var tmp3 any = t.F_b__598000153; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_75, nil, Lit_76, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, nil, k__3, nil, v__4, nil)).Ref()); i__598000152__1 = lang.Numbers_Unchecked_inc_J__J(i__598000152__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
func A_arbace_box_build_build_package_iter__598000166__598000170_A_New() *A_arbace_box_build_build_package_iter__598000166__598000170_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000166__598000170_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_A) Ctor() {}
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_A) Invoke_O_O__O(self, s__598000167__1 any) any { var tmp1 any = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_New_O_O(s__598000167__1, self); var tmp2 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_77, false); A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_fn_class = fncls__38d; tmp2 = fncls__38d } else { tmp2 = fncls__38 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :220:1
func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_New_O_O(p0, p1 any) *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A{}; t.Ctor_O_O(p0, p1); return t }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A) Ctor_O_O(c__s__598000167, c__iter__598000166 any) { t.F_s__598000167 = c__s__598000167; t.F_iter__598000166 = c__iter__598000166 }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A) Invoke_O__O(self any) any { { var s__598000167__1 any; var t_ any = t.F_s__598000167; t.F_s__598000167 = nil; s__598000167__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(s__598000167__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000167__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(s__598000167__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(s__598000167__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000169__6 any = lang.IFn_Cast(A_arbace_box_build_A_const_23.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_New_O_I_O(b__598000169__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_78, false); A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_fn_class = fncls__37d; tmp2 = fncls__37d } else { tmp2 = fncls__37 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__598000166); return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000169__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(s__598000167__3))) } else { return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000169__6), nil) } } else { var l__4 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(s__598000167__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000166); return lang.IFn_Cast(A_arbace_box_build_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, l__4, nil)).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__598000167__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :220:1
func A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A) Ctor_O_I_O(c__b__598000169 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000169 = c__b__598000169; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :220:1
func (t *A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A) Invoke_O__O(self any) any { { var i__598000168__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000168__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000168__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_27.GetRawRoot__O()); var tmp3 any = t.F_b__598000169; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, l__2, nil)).Ref()); i__598000168__1 = lang.Numbers_Unchecked_inc_J__J(i__598000168__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_box_build_build_package_res_of__598000176_A_New_O(p0 any) *A_arbace_box_build_build_package_res_of__598000176_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_res_of__598000176_A{}; t.Ctor_O(p0); return t }
//line :222:1
func (t *A_arbace_box_build_build_package_res_of__598000176_A) Ctor_O(c__P any) { t.F_P = c__P }
//line :222:1
func (t *A_arbace_box_build_build_package_res_of__598000176_A) Invoke_O_O_O__O(self, what__1, req__2 any) any { return lang.IFn_Cast(A_arbace_box_build_A_const_79.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_88, nil), jrt.RefArrayOf(jrt.Object_class, t.F_P, nil, what__1)).Ref(), lang.IFn_Cast(A_arbace_box_build_A_const_123.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_124, req__2)) }




func A_arbace_box_build_build_package_fn__598000179_A_New_O(p0 any) *A_arbace_box_build_build_package_fn__598000179_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_fn__598000179_A{}; t.Ctor_O(p0); return t }
//line :227:1
func (t *A_arbace_box_build_build_package_fn__598000179_A) Ctor_O(c__P any) { t.F_P = c__P }
//line :227:1
func (t *A_arbace_box_build_build_package_fn__598000179_A) Invoke_O_O__O(self, p__598000178__1 any) any { var vec__598000180__2 any = p__598000178__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__598000180__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__598000180__2, lang.RT_IntCast_J__I(1), nil); var tmp1 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_box_build_A_const_136.GetRawRoot__O()).Invoke_O__O(k__3); if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_box_build_A_const_24.GetRawRoot__O()).Invoke_O_O__O(k__3, Lit_70); if jrt.A2g_Truth(and__1927000168__auto____6) {
													var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_137.GetRawRoot__O()); var tmp3 any = t.F_P; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_52.GetRawRoot__O()); var tmp5 any = A_arbace_box_build_A_const_54; tmp1 = tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(k__3, tmp5, jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(k__3)))).Ref())) } else {
//line :227:1
		tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp1) { return v__4 } else { return nil } }










func A_arbace_box_build_build_package_fn__598000184_A_New() *A_arbace_box_build_build_package_fn__598000184_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_fn__598000184_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_box_build_build_package_fn__598000184_A) Ctor() {}
//line :238:1
func (t *A_arbace_box_build_build_package_fn__598000184_A) Invoke_O_O__O(self, p1__598000143_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_71, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__598000143_SHARP___1)).Ref() }














func A_arbace_box_build_build_package_fn__598000186_A_New() *A_arbace_box_build_build_package_fn__598000186_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_fn__598000186_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_box_build_build_package_fn__598000186_A) Ctor() {}
//line :253:1
func (t *A_arbace_box_build_build_package_fn__598000186_A) Invoke_O_O__O(self, p1__598000144_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__598000144_SHARP___1)).Ref() }











func A_arbace_box_build_build_package_iter__598000189__598000193_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_box_build_build_package_iter__598000189__598000193_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_A) Ctor_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__ctree, c__pkg, c__tools any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_tools = c__tools }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_A) Invoke_O_O__O(self, s__598000190__1 any) any { var tmp1 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_New_O_O_O_O_O_O_O_O(t.F_res_of, t.F_P, t.F_plan, t.F_ctree, t.F_pkg, t.F_tools, s__598000190__1, self); var tmp2 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_79, false); A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_fn_class = fncls__46d; tmp2 = fncls__46d } else { tmp2 = fncls__46 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :265:1
func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A) Ctor_O_O_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__ctree, c__pkg, c__tools, c__s__598000190, c__iter__598000189 any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_tools = c__tools; t.F_s__598000190 = c__s__598000190; t.F_iter__598000189 = c__iter__598000189 }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A) Invoke_O__O(self any) any { { var s__598000190__1 any; var t_ any = t.F_s__598000190; t.F_s__598000190 = nil; s__598000190__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(s__598000190__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000190__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(s__598000190__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(s__598000190__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000192__6 any = lang.IFn_Cast(A_arbace_box_build_A_const_23.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_New_O_O_O_O_O_O_O_I_O(b__598000192__6, t.F_res_of, t.F_P, t.F_plan, t.F_ctree, t.F_pkg, t.F_tools, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_80, false); A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__598000189); return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000192__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(s__598000190__3))) } else { return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000192__6), nil) } } else { var s__4 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(s__598000190__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_29.GetRawRoot__O()); var tmp5 lang.IPersistentVector; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_52.GetRawRoot__O()); var tmp7 any = A_arbace_box_build_A_const_54; var o__5 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_81), jrt.RefArrayOf(jrt.Object_class, tmp6.Invoke_O_O_O__O(s__4, tmp7, jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(s__4)), 2)).Ref()), nil)).Ref(); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_161.GetRawRoot__O()); var tmp9 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_New_O_O_O_O_O_O_O_O(t.F_res_of, t.F_P, t.F_plan, o__5, t.F_ctree, t.F_pkg, s__4, t.F_tools); var tmp10 *jrt.Class
														var fncls__45 /*line :265:1*/*jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_fn_class

	if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_82, false); A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_fn_class = fncls__45d; tmp10 = fncls__45d } else { tmp10 = fncls__45 }
//line :265:1
	tmp5 = lang.Tuple_Create_O_O__IPersistentVector(o__5, tmp8.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil))); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__598000189); return tmp4.Invoke_O_O__O(tmp5, tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__598000190__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :265:1
func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_New_O_O_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6 any, p7 int32, p8 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A{}; t.Ctor_O_O_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A) Ctor_O_O_O_O_O_O_O_I_O(c__b__598000192, c__res_of, c__P, c__plan, c__ctree, c__pkg, c__tools any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000192 = c__b__598000192; t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_tools = c__tools; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :265:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A) Invoke_O__O(self any) any { { var i__598000191__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000191__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000191__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_27.GetRawRoot__O()); var tmp3 any = t.F_b__598000192; var tmp4 lang.IPersistentVector; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_52.GetRawRoot__O()); var tmp6 any = A_arbace_box_build_A_const_54; var o__3 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_81), jrt.RefArrayOf(jrt.Object_class, tmp5.Invoke_O_O_O__O(s__2, tmp6, jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(s__2)), 2)).Ref()), nil)).Ref(); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_161.GetRawRoot__O()); var tmp8 any = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_New_O_O_O_O_O_O_O_O(t.F_res_of, t.F_P, t.F_plan, t.F_ctree, t.F_pkg, o__3, s__2, t.F_tools); var tmp9 *jrt.Class
																var fncls__43 /*line :265:1*/*jrt.Class = A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_fn_class

	if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_83, false); A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_fn_class = fncls__43d; tmp9 = fncls__43d } else { tmp9 = fncls__43 }
//line :265:1
	tmp4 = lang.Tuple_Create_O_O__IPersistentVector(o__3, tmp7.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil))); tmp2.Invoke_O_O__O(tmp3, tmp4); i__598000191__1 = lang.Numbers_Unchecked_inc_J__J(i__598000191__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A) Ctor_O_O_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__ctree, c__pkg, c__o, c__s, c__tools any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_o = c__o; t.F_s = c__s; t.F_tools = c__tools }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A) Invoke_O__O(self any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_131.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_res_of; t.F_res_of = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_84, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_s)).Ref(); var tmp5 any = A_arbace_box_build_A_const_141; var tmp6 *lang.Keyword = A_arbace_box_build_A_const_142; var tmp7 any; var t__2 any = t.F_tools
	t.F_tools = nil; tmp7 = t__2
//line :268:1
	var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 any = A_arbace_box_build_A_const_78; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_8.GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_144.GetRawRoot__O()); var tmp12 any = t.F_plan; var tmp13 any = t.F_pkg; var tmp14 any = tmp11.Invoke_O_O_O__O(tmp12, tmp13, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_85, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_o)).Ref()); var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_71, nil); var tmp16 any; var t__3 any = t.F_s

	t.F_s = nil; tmp16 = t__3
//line :268:1
	var tmp17 any = tmp10.Invoke_O_O__O(tmp14, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp16)).Ref()); var tmp18 any = A_arbace_box_build_A_const_143; var tmp19 *lang.Keyword = A_arbace_box_build_A_const_43; var tmp20 any; var t__4 any = t.F_pkg


	t.F_pkg = nil; tmp20 = t__4
//line :268:1
	var tmp21 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_55, tmp19.Invoke_O__O(tmp20)); var tmp22 *lang.Keyword = A_arbace_box_build_A_const_44; var tmp23 any; var t__5 any = t.F_plan


	t.F_plan = nil; tmp23 = t__5
//line :268:1
	var tmp24 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_40, tmp22.Invoke_O__O(tmp23)); var tmp25 any; var t__6 any = t.F_ctree; t.F_ctree = nil; tmp25 = t__6; var tmp26 any = tmp3.Invoke_O_O__O(tmp4, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp8, tmp9, tmp17, tmp18, lang.Tuple_Create_O_O_O__IPersistentVector(tmp21, tmp24, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp25))))); var tmp27 any; var t__7 any = t.F_P; t.F_P = nil; tmp27 = t__7; var tmp28 any = tmp27; var tmp29 any; var t__8 any = t.F_o; t.F_o = nil; tmp29 = t__8; return tmp1.Invoke_O_O_O__O(tmp26, tmp28, tmp29) }
//line :267:1
func A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A) Ctor_O_O_O_O_O_O_O_O(c__res_of, c__P, c__plan, c__o, c__ctree, c__pkg, c__s, c__tools any) { t.F_res_of = c__res_of; t.F_P = c__P; t.F_plan = c__plan; t.F_o = c__o; t.F_ctree = c__ctree; t.F_pkg = c__pkg; t.F_s = c__s; t.F_tools = c__tools }
//line :267:1
func (t *A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A) Invoke_O__O(self any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_131.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_res_of; t.F_res_of = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_84, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_s)).Ref(); var tmp5 any = A_arbace_box_build_A_const_141; var tmp6 *lang.Keyword = A_arbace_box_build_A_const_142; var tmp7 any; var t__2 any = t.F_tools
	t.F_tools = nil; tmp7 = t__2
//line :268:1
	var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 any = A_arbace_box_build_A_const_78; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_8.GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_144.GetRawRoot__O()); var tmp12 any = t.F_plan; var tmp13 any = t.F_pkg; var tmp14 any = tmp11.Invoke_O_O_O__O(tmp12, tmp13, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_85, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_o)).Ref()); var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_71, nil); var tmp16 any; var t__3 any = t.F_s

	t.F_s = nil; tmp16 = t__3
//line :268:1
	var tmp17 any = tmp10.Invoke_O_O__O(tmp14, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp16)).Ref()); var tmp18 any = A_arbace_box_build_A_const_143; var tmp19 *lang.Keyword = A_arbace_box_build_A_const_43; var tmp20 any; var t__4 any = t.F_pkg


	t.F_pkg = nil; tmp20 = t__4
//line :268:1
	var tmp21 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_55, tmp19.Invoke_O__O(tmp20)); var tmp22 *lang.Keyword = A_arbace_box_build_A_const_44; var tmp23 any; var t__5 any = t.F_plan


	t.F_plan = nil; tmp23 = t__5
//line :268:1
	var tmp24 any = lang.Tuple_Create_O_O__IPersistentVector(Lit_40, tmp22.Invoke_O__O(tmp23)); var tmp25 any; var t__6 any = t.F_ctree; t.F_ctree = nil; tmp25 = t__6; var tmp26 any = tmp3.Invoke_O_O__O(tmp4, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp8, tmp9, tmp17, tmp18, lang.Tuple_Create_O_O_O__IPersistentVector(tmp21, tmp24, lang.Tuple_Create_O_O__IPersistentVector(Lit_56, tmp25))))); var tmp27 any; var t__7 any = t.F_P; t.F_P = nil; tmp27 = t__7; var tmp28 any = tmp27; var tmp29 any; var t__8 any = t.F_o; t.F_o = nil; tmp29 = t__8; return tmp1.Invoke_O_O_O__O(tmp26, tmp28, tmp29)
}



func A_arbace_box_build_build_package_iter__598000203__598000207_A_New() *A_arbace_box_build_build_package_iter__598000203__598000207_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000203__598000207_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_A) Ctor() {}
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_A) Invoke_O_O__O(self, s__598000204__1 any) any { var tmp1 any = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_New_O_O(self, s__598000204__1); var tmp2 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_86, false); A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_fn_class = fncls__32d; tmp2 = fncls__32d } else { tmp2 = fncls__32 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :273:1
func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_New_O_O(p0, p1 any) *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A{}; t.Ctor_O_O(p0, p1); return t }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A) Ctor_O_O(c__iter__598000203, c__s__598000204 any) { t.F_iter__598000203 = c__iter__598000203; t.F_s__598000204 = c__s__598000204 }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A) Invoke_O__O(self any) any { { var s__598000204__1 any; var t_ any = t.F_s__598000204; t.F_s__598000204 = nil; s__598000204__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(s__598000204__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000204__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(s__598000204__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(s__598000204__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000206__6 any = lang.IFn_Cast(A_arbace_box_build_A_const_23.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_New_O_I_O(b__598000206__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_87, false); A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_fn_class = fncls__31d; tmp2 = fncls__31d } else { tmp2 = fncls__31 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__598000203); return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000206__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(s__598000204__3))) } else { return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000206__6), nil) } } else { var vec__598000214__4 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(s__598000204__3); var o__5 any = lang.RT_Nth_O_I_O__O(vec__598000214__4, lang.RT_IntCast_J__I(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O(vec__598000214__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000203); return lang.IFn_Cast(A_arbace_box_build_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(o__5, lang.IFn_Cast(A_arbace_box_build_A_const_133.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_134.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_7.GetRawRoot__O()).Invoke_O__O(f__6)))), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__598000204__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :273:1
func A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A) Ctor_O_I_O(c__b__598000206 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000206 = c__b__598000206; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :273:1
func (t *A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A) Invoke_O__O(self any) any { { var i__598000205__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000205__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000210__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000205__1)); var o__3 any = lang.RT_Nth_O_I_O__O(vec__598000210__2, lang.RT_IntCast_J__I(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O(vec__598000210__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_27.GetRawRoot__O()); var tmp3 any = t.F_b__598000206; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(o__3, lang.IFn_Cast(A_arbace_box_build_A_const_133.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_134.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_7.GetRawRoot__O()).Invoke_O__O(f__4))))); i__598000205__1 = lang.Numbers_Unchecked_inc_J__J(i__598000205__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_box_build_read_plan_A_New() *A_arbace_box_build_read_plan_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_read_plan_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_box_build_read_plan_A) Ctor() {}
//line :276:1
func (t *A_arbace_box_build_read_plan_A) Invoke_O_O__O(self, plan__0 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_32.GetRawRoot__O()).Invoke_O__O(plan__0)) { return plan__0 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_163.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_164, plan__0)) {
		return lang.IFn_Cast(A_arbace_box_build_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_72.GetRawRoot__O()).Invoke_O__O(plan__0)) } else {
//line :277:1
			if A_arbace_box_build_A_const_111 != nil {

				var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_33.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_box_build_A_const_165.GetRawRoot__O()).Invoke_O__O(plan__0); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = lang.IFn_Cast(A_arbace_box_build_A_const_67.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_139, nil), jrt.RefArrayOf(jrt.Object_class, nil, plan__0)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_166, plan__0))) }; return tmp1.Invoke_O__O(tmp2) } else {
//line :277:1
					return nil
				}
		}
	} }
func A_arbace_box_build_with_tools_A_New() *A_arbace_box_build_with_tools_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_with_tools_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_box_build_with_tools_A) Ctor() {}
//line :281:1
func (t *A_arbace_box_build_with_tools_A) Invoke_O_O_O__O(self, p__0, opts__1 any) any { var arch__3 any = A_arbace_box_build_A_const_85.Invoke_O__O(p__0); var tools__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_123.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_21.GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap;



	lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 any; var iter__1927001039__auto____4 any; var tmp6 any = A_arbace_box_build_with_tools_iter__598000221__598000225_A_New_O(arch__3); var tmp7 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_box_build_with_tools_iter__598000221__598000225_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_149, false); A_arbace_box_build_with_tools_iter__598000221__598000225_A_fn_class = fncls__50d; tmp7 = fncls__50d } else { tmp7 = fncls__50 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); tmp5 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(A_arbace_box_build_A_const_168); tools__4 = tmp1.Invoke_O_O__O(tmp2.Invoke_O_O__O(tmp4, tmp5), A_arbace_box_build_A_const_120.Invoke_O__O(opts__1)); var seq_598000231__5 any = /*line :281:1*/lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(tools__4); var chunk_598000232__6 any; var count_598000233__7 int64 = 0; var i_598000234__8 int64 = 0; L1: for {






		if lang.Numbers_Lt_J_J__Z(i_598000234__8, count_598000233__7) { var vec__598000235__9 any = lang.Indexed_Cast(chunk_598000232__6).Nth_I__O(lang.RT_IntCast_J__I(i_598000234__8)); var t__10 any = lang.RT_Nth_O_I_O__O(vec__598000235__9, lang.RT_IntCast_J__I(0), nil); var h__11 any = lang.RT_Nth_O_I_O__O(vec__598000235__9, lang.RT_IntCast_J__I(1), nil); if jrt.A2g_Truth(h__11) { } else { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_67.GetRawRoot__O()); var tmp9 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.ConstRefArray("[0,7,s31:arbace.box.build: no image for ns15: (the ref tool.ns1:.ns1:)", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_build_A_const_167.GetRawRoot__O()).Invoke_O__O(t__10), nil, lang.IFn_Cast(A_arbace_box_build_A_const_167.GetRawRoot__O()).Invoke_O__O(t__10), nil, arch__3, nil)).Ref(); var tmp10 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp10 = lang.PersistentArrayMap_EMPTY; tmp8.Invoke_O_O__O(tmp9, tmp10.Ref()) }; seq_598000231__5, chunk_598000232__6, count_598000233__7, i_598000234__8 = seq_598000231__5, chunk_598000232__6, count_598000233__7, lang.Numbers_Unchecked_inc_J__J(i_598000234__8); continue L1 } else { var temp__1927000414__auto____9 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_598000231__5); if jrt.A2g_Truth(temp__1927000414__auto____9) { var seq_598000231__10 any = temp__1927000414__auto____9; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(seq_598000231__10)) { var c__1927000678__auto____11 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(seq_598000231__10); seq_598000231__5, chunk_598000232__6, count_598000233__7, i_598000234__8 = lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_598000231__10), c__1927000678__auto____11, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__598000238__11 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(seq_598000231__10); var t__12 any = lang.RT_Nth_O_I_O__O(vec__598000238__11, lang.RT_IntCast_J__I(0), nil); var h__13 any = lang.RT_Nth_O_I_O__O(vec__598000238__11, lang.RT_IntCast_J__I(1), nil); if jrt.A2g_Truth(h__13) { } else { var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_67.GetRawRoot__O()); var tmp12 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.ConstRefArray("[0,7,s31:arbace.box.build: no image for ns15: (the ref tool.ns1:.ns1:)", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_build_A_const_167.GetRawRoot__O()).Invoke_O__O(t__12), nil, lang.IFn_Cast(A_arbace_box_build_A_const_167.GetRawRoot__O()).Invoke_O__O(t__12), nil, arch__3, nil)).Ref(); var tmp13 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp13 = lang.PersistentArrayMap_EMPTY; tmp11.Invoke_O_O__O(tmp12, tmp13.Ref()) }; seq_598000231__5, chunk_598000232__6, count_598000233__7, i_598000234__8 = lang.IFn_Cast(A_arbace_box_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_598000231__10), nil, 0, 0; continue L1 } } }
//line :281:1
		break L1 }; return /*line :289:1*/ lang.IFn_Cast(A_arbace_box_build_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(opts__1, A_arbace_box_build_A_const_120, tools__4) }
//line :285:1
func A_arbace_box_build_with_tools_iter__598000221__598000225_A_New_O(p0 any) *A_arbace_box_build_with_tools_iter__598000221__598000225_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_with_tools_iter__598000221__598000225_A{}; t.Ctor_O(p0); return t }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_A) Ctor_O(c__arch any) { t.F_arch = c__arch }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_A) Invoke_O_O__O(self, s__598000222__1 any) any { var tmp1 any = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_New_O_O_O(s__598000222__1, t.F_arch, self); var tmp2 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_150, false); A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_fn_class = fncls__49d; tmp2 = fncls__49d } else { tmp2 = fncls__49 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :285:1
func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_New_O_O_O(p0, p1, p2 any) *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A) Ctor_O_O_O(c__s__598000222, c__arch, c__iter__598000221 any) { t.F_s__598000222 = c__s__598000222; t.F_arch = c__arch; t.F_iter__598000221 = c__iter__598000221 }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A) Invoke_O__O(self any) any { { var s__598000222__1 any; var t_ any = t.F_s__598000222; t.F_s__598000222 = nil; s__598000222__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(s__598000222__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000222__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(s__598000222__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(s__598000222__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000224__6 any = lang.IFn_Cast(A_arbace_box_build_A_const_23.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_New_O_O_I_O(b__598000224__6, t.F_arch, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_151, false); A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_fn_class = fncls__48d; tmp2 = fncls__48d } else { tmp2 = fncls__48 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__598000221); return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000224__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(s__598000222__3))) } else { return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000224__6), nil) } } else { var t__4 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(s__598000222__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000221); return lang.IFn_Cast(A_arbace_box_build_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(t__4, lang.IFn_Cast(A_arbace_box_build_A_const_61.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_152, nil, Lit_153, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_build_A_const_167.GetRawRoot__O()).Invoke_O__O(t__4), nil, t.F_arch)).Ref())), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__598000222__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :285:1
func A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A) Ctor_O_O_I_O(c__b__598000224, c__arch any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000224 = c__b__598000224; t.F_arch = c__arch; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :285:1
func (t *A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A) Invoke_O__O(self any) any { { var i__598000223__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000223__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000223__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_27.GetRawRoot__O()); var tmp3 any = t.F_b__598000224; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(t__2, lang.IFn_Cast(A_arbace_box_build_A_const_61.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_152, nil, Lit_153, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_box_build_A_const_167.GetRawRoot__O()).Invoke_O__O(t__2), nil, t.F_arch)).Ref()))); i__598000223__1 = lang.Numbers_Unchecked_inc_J__J(i__598000223__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_box_build_archives_A_New() *A_arbace_box_build_archives_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_box_build_archives_A) Ctor() {}
//line :291:1
func (t *A_arbace_box_build_archives_A) Invoke_O_O_O__O(self, plan__0, opts__1 any) any { var p__3 any = lang.IFn_Cast(A_arbace_box_build_A_const_169.GetRawRoot__O()).Invoke_O__O(plan__0); var opts__4 any = lang.IFn_Cast(A_arbace_box_build_A_const_170.GetRawRoot__O()).Invoke_O_O__O(p__3, opts__1); var pkgs__5 any = A_arbace_box_build_A_const_40.Invoke_O__O(p__3); var index__6 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_21.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;







	lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_174.GetRawRoot__O()); var tmp5 any = A_arbace_box_build_archives_fn__598000242_A_New(); var tmp6 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_box_build_archives_fn__598000242_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_box_build_archives_fn__598000242_A_fn_class = fncls__53d; tmp6 = fncls__53d } else { tmp6 = fncls__53 }; index__6 = tmp1.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), pkgs__5)); var given__7 any = /*line :291:1*/A_arbace_box_build_A_const_171.Invoke_O__O(opts__4); var only__8 any = A_arbace_box_build_A_const_172.Invoke_O__O(opts__4); var futures__9 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_34.GetRawRoot__O()); var tmp8 *lang.PersistentArrayMap;











	lang.PersistentArrayMap_Init(); tmp8 = lang.PersistentArrayMap_EMPTY; futures__9 = tmp7.Invoke_O__O(tmp8.Ref()); var sem__10 any = /*line :291:1*/jrt.Semaphore_New_I(lang.RT_IntCast_O__I(A_arbace_box_build_A_const_173.Invoke_O_O__O(opts__4, A_arbace_box_build_A_const_175))); var conveyed__11 any; var tmp9 any = A_arbace_box_build_archives_conveyed__598000244_A_New_O(opts__4); var tmp10 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_box_build_archives_conveyed__598000244_A_fn_class; if













	fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_box_build_archives_conveyed__598000244_A_fn_class = fncls__52d; tmp10 = fncls__52d } else { tmp10 = fncls__52 }; conveyed__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil);
	lang.IFn_Cast(A_arbace_box_build_A_const_81.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, opts__4)); var tmp11 any; tmp38 := /*line :291:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_598000248__14 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(pkgs__5); var chunk_598000249__15 any; var count_598000250__16 int64 = 0; var i_598000251__17 int64 = 0; L1: for {















		if lang.Numbers_Lt_J_J__Z(i_598000251__17, count_598000250__16) { var q__18 any = lang.Indexed_Cast(chunk_598000249__15).Nth_I__O(lang.RT_IntCast_J__I(i_598000251__17)); var deps__19 any = lang.IFn_Cast(A_arbace_box_build_A_const_108.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_7.GetRawRoot__O()).Invoke_O__O(futures__9), A_arbace_box_build_A_const_121.Invoke_O__O(q__18)); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_36.GetRawRoot__O()); var tmp13 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var tmp14 any = A_arbace_box_build_A_const_91.Invoke_O__O(q__18); var tmp15 any; var tmp16 any
			var and__1927000168__auto____20 any = only__8

			if jrt.A2g_Truth(and__1927000168__auto____20) { tmp16 = lang.IFn_Cast(A_arbace_box_build_A_const_68.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(only__8).Invoke_O__O(A_arbace_box_build_A_const_91.Invoke_O__O(q__18))) } else { tmp16 = and__1927000168__auto____20 }; if jrt.A2g_Truth(tmp16) { var tmp17 any = A_arbace_box_build_archives_fn__598000252_A_New_O_O(given__7, q__18); var tmp18 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_box_build_archives_fn__598000252_A_fn_class
				if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); A_arbace_box_build_archives_fn__598000252_A_fn_class = fncls__54d; tmp18 = fncls__54d } else { tmp18 = fncls__54 }
//line :310:1
				tmp15 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil)) } else {

					var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_161.GetRawRoot__O()); var tmp20 any = A_arbace_box_build_archives_fn__598000254_A_New_O_O_O_O_O_O(index__6, p__3, deps__19, sem__10, conveyed__11, q__18); var tmp21 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_box_build_archives_fn__598000254_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_box_build_archives_fn__598000254_A_fn_class = fncls__57d; tmp21 = fncls__57d } else { tmp21 = fncls__57 }; tmp15 = tmp19.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil)) }
//line :309:1
			tmp12.Invoke_O_O_O_O__O(futures__9, tmp13, tmp14, tmp15)
//line :307:1
			seq_598000248__14, chunk_598000249__15, count_598000250__16, i_598000251__17 = seq_598000248__14, chunk_598000249__15, count_598000250__16, lang.Numbers_Unchecked_inc_J__J(i_598000251__17); continue L1 } else { var temp__1927000414__auto____18 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_598000248__14); if jrt.A2g_Truth(temp__1927000414__auto____18) { var seq_598000248__19 any = temp__1927000414__auto____18; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(seq_598000248__19)) { var c__1927000678__auto____20 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(seq_598000248__19); seq_598000248__14, chunk_598000249__15, count_598000250__16, i_598000251__17 = lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_598000248__19), c__1927000678__auto____20, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var q__20 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(seq_598000248__19); var deps__21 any = lang.IFn_Cast(A_arbace_box_build_A_const_108.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_7.GetRawRoot__O()).Invoke_O__O(futures__9), A_arbace_box_build_A_const_121.Invoke_O__O(q__20)); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_36.GetRawRoot__O()); var tmp23 any = A_arbace_box_build_A_const_12.GetRawRoot__O(); var tmp24 any = A_arbace_box_build_A_const_91.Invoke_O__O(q__20); var tmp25 any; var tmp26 any
				var and__1927000168__auto____22 any = only__8

				if jrt.A2g_Truth(and__1927000168__auto____22) { tmp26 = lang.IFn_Cast(A_arbace_box_build_A_const_68.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(only__8).Invoke_O__O(A_arbace_box_build_A_const_91.Invoke_O__O(q__20))) } else { tmp26 = and__1927000168__auto____22 }; if jrt.A2g_Truth(tmp26) { var tmp27 any = A_arbace_box_build_archives_fn__598000260_A_New_O_O(given__7, q__20); var tmp28 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_box_build_archives_fn__598000260_A_fn_class
					if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_box_build_archives_fn__598000260_A_fn_class = fncls__58d; tmp28 = fncls__58d } else { tmp28 = fncls__58 }
//line :310:1
					tmp25 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil)) } else {

						var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_161.GetRawRoot__O()); var tmp30 any = A_arbace_box_build_archives_fn__598000262_A_New_O_O_O_O_O_O(index__6, p__3, deps__21, sem__10, conveyed__11, q__20); var tmp31 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_box_build_archives_fn__598000262_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_box_build_archives_fn__598000262_A_fn_class = fncls__61d; tmp31 = fncls__61d } else { tmp31 = fncls__61 }; tmp25 = tmp29.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil)) }
//line :309:1
				tmp22.Invoke_O_O_O_O__O(futures__9, tmp23, tmp24, tmp25)
//line :307:1
				seq_598000248__14, chunk_598000249__15, count_598000250__16, i_598000251__17 = lang.IFn_Cast(A_arbace_box_build_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_598000248__19), nil, 0, 0; continue L1 } } }
//line :291:1
		break L1
	}



























		var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_21.GetRawRoot__O()); var tmp33 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp33 = lang.PersistentArrayMap_EMPTY; var tmp34 any = tmp33.Ref(); var tmp35 any; var iter__1927001039__auto____14 any; var tmp36 any = A_arbace_box_build_archives_iter__598000268__598000272_A_New(); var tmp37 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_box_build_archives_iter__598000268__598000272_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); A_arbace_box_build_archives_iter__598000268__598000272_A_fn_class = fncls__64d; tmp37 = fncls__64d } else { tmp37 = fncls__64 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp36, tmp37, nil); tmp35 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_7.GetRawRoot__O()).Invoke_O__O(futures__9)); tmp11 = tmp32.Invoke_O_O__O(tmp34, tmp35) }; return nil }(); /*line :306:1*/lang.IFn_Cast(A_arbace_box_build_A_const_80.GetRawRoot__O()).Invoke__O(); if /*line :291:1*/ tmp38 != nil { panic(tmp38) }; return tmp11 }







func A_arbace_box_build_archives_fn__598000242_A_New() *A_arbace_box_build_archives_fn__598000242_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000242_A{}; t.Ctor(); return t }
//line :299:1
func (t *A_arbace_box_build_archives_fn__598000242_A) Ctor() {}
//line :299:1
func (t *A_arbace_box_build_archives_fn__598000242_A) Invoke_O_O_O__O(self, i__1, q__2 any) any { return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_91.Invoke_O__O(q__2), i__1) }





func A_arbace_box_build_archives_conveyed__598000244_A_New_O(p0 any) *A_arbace_box_build_archives_conveyed__598000244_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_conveyed__598000244_A{}; t.Ctor_O(p0); return t }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_A) Invoke_O_O__O(self, f__1 any) any { var o__2 any = t.F_opts; var tmp1 any = A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_New_O_O(f__1, o__2); var tmp2 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_25, false); A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_fn_class = fncls__51d; tmp2 = fncls__51d } else { tmp2 = fncls__51 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :305:1
func A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A{}; t.Ctor_O_O(p0, p1); return t }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A) Ctor_O_O(c__f, c__o any) { t.F_f = c__f; t.F_o = c__o }
//line :305:1
func (t *A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A) Invoke_O__O(self any) any { lang.IFn_Cast(A_arbace_box_build_A_const_81.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, t.F_o)); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(t.F_f).Invoke__O(); return nil }(); lang.IFn_Cast(A_arbace_box_build_A_const_80.GetRawRoot__O()).Invoke__O(); if tmp2 != nil { panic(tmp2) }; return tmp1 }





func A_arbace_box_build_archives_fn__598000252_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_fn__598000252_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000252_A{}; t.Ctor_O_O(p0, p1); return t }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000252_A) Ctor_O_O(c__given, c__q any) { t.F_given = c__given; t.F_q = c__q }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000252_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var tmp1 any; var t_ any = t.F_given; t.F_given = nil; tmp1 = t_; or__1927000174__auto____1 = lang.RT_Get_O_O__O(tmp1, A_arbace_box_build_A_const_91.Invoke_O__O(t.F_q)); if jrt.A2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_67.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil); var tmp4 *lang.Keyword = A_arbace_box_build_A_const_91; var tmp5 any; var t__2 any = t.F_q; t.F_q = nil; tmp5 = t__2; var tmp6 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4.Invoke_O__O(tmp5))).Ref(); var tmp7 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp7 = lang.PersistentArrayMap_EMPTY; return tmp2.Invoke_O_O__O(tmp6, tmp7.Ref()) } }
//line :311:1
func A_arbace_box_build_archives_fn__598000260_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_fn__598000260_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000260_A{}; t.Ctor_O_O(p0, p1); return t }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000260_A) Ctor_O_O(c__given, c__q any) { t.F_given = c__given; t.F_q = c__q }
//line :311:1
func (t *A_arbace_box_build_archives_fn__598000260_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var tmp1 any; var t_ any = t.F_given; t.F_given = nil; tmp1 = t_; or__1927000174__auto____1 = lang.RT_Get_O_O__O(tmp1, A_arbace_box_build_A_const_91.Invoke_O__O(t.F_q)); if jrt.A2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_67.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil); var tmp4 *lang.Keyword = A_arbace_box_build_A_const_91; var tmp5 any; var t__2 any = t.F_q; t.F_q = nil; tmp5 = t__2; var tmp6 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4.Invoke_O__O(tmp5))).Ref(); var tmp7 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp7 = lang.PersistentArrayMap_EMPTY; return tmp2.Invoke_O_O__O(tmp6, tmp7.Ref()) } }
func A_arbace_box_build_archives_fn__598000254_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_box_build_archives_fn__598000254_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000254_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000254_A) Ctor_O_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__conveyed, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_conveyed = c__conveyed; t.F_q = c__q }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000254_A) Invoke_O__O(self any) any {
	var tmp1 any; var t_ any = t.F_conveyed; t.F_conveyed = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any = A_arbace_box_build_archives_fn__598000254_fn__598000255_A_New_O_O_O_O_O(t.F_index, t.F_p, t.F_deps, t.F_sem, t.F_q); var tmp4 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_box_build_archives_fn__598000254_fn__598000255_A_fn_class
	if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); A_arbace_box_build_archives_fn__598000254_fn__598000255_A_fn_class = fncls__56d; tmp4 = fncls__56d } else { tmp4 = fncls__56 }
//line :313:1
	return lang.IFn_Cast(tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil))).Invoke__O() }
//line :312:1
func A_arbace_box_build_archives_fn__598000262_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_box_build_archives_fn__598000262_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000262_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000262_A) Ctor_O_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__conveyed, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_conveyed = c__conveyed; t.F_q = c__q }
//line :312:1
func (t *A_arbace_box_build_archives_fn__598000262_A) Invoke_O__O(self any) any {
	var tmp1 any; var t_ any = t.F_conveyed; t.F_conveyed = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any = A_arbace_box_build_archives_fn__598000262_fn__598000263_A_New_O_O_O_O_O(t.F_index, t.F_p, t.F_deps, t.F_sem, t.F_q); var tmp4 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_box_build_archives_fn__598000262_fn__598000263_A_fn_class
	if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_box_build_archives_fn__598000262_fn__598000263_A_fn_class = fncls__60d; tmp4 = fncls__60d } else { tmp4 = fncls__60 }
//line :313:1
	return lang.IFn_Cast(tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil))).Invoke__O() }
func A_arbace_box_build_archives_fn__598000254_fn__598000255_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_box_build_archives_fn__598000254_fn__598000255_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000254_fn__598000255_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_A) Ctor_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_q = c__q }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_A) Invoke_O__O(self any) any { var archives__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_21.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;
												lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_108.GetRawRoot__O()); var tmp5 any = A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_New(); var tmp6 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_fn_class = fncls__55d; tmp6 = fncls__55d } else { tmp6 = fncls__55 }; archives__1 = tmp1.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), A_arbace_box_build_A_const_121.Invoke_O__O(t.F_q), t.F_deps));
												jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Acquire__V(); var tmp7 any; tmp8 := /*line :314:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		tmp7 = lang.IFn_Cast(A_arbace_box_build_A_const_176.GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_p, t.F_q, archives__1, t.F_index)
//line :314:1
		return nil }();




	jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Release__V(); if /*line :314:1*/ tmp8 != nil { panic(tmp8) }; return tmp7 }
//line :314:1
func A_arbace_box_build_archives_fn__598000262_fn__598000263_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_box_build_archives_fn__598000262_fn__598000263_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000262_fn__598000263_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_A) Ctor_O_O_O_O_O(c__index, c__p, c__deps, c__sem, c__q any) { t.F_index = c__index; t.F_p = c__p; t.F_deps = c__deps; t.F_sem = c__sem; t.F_q = c__q }
//line :314:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_A) Invoke_O__O(self any) any { var archives__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_21.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;
												lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_108.GetRawRoot__O()); var tmp5 any = A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_New(); var tmp6 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_fn_class = fncls__59d; tmp6 = fncls__59d } else { tmp6 = fncls__59 }; archives__1 = tmp1.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), A_arbace_box_build_A_const_121.Invoke_O__O(t.F_q), t.F_deps));
												jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Acquire__V(); var tmp7 any; tmp8 := /*line :314:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



		tmp7 = lang.IFn_Cast(A_arbace_box_build_A_const_176.GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_p, t.F_q, archives__1, t.F_index)
//line :314:1
		return nil }();




	jrt.NN(jrt.As[*jrt.Semaphore](t.F_sem)).Release__V(); if /*line :314:1*/ tmp8 != nil { panic(tmp8) }; return tmp7 }
func A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_New() *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A) Ctor() {}
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A) Invoke_O_O_O__O(self, i__1, d__2 any) any { return lang.Tuple_Create_O_O__IPersistentVector(i__1, lang.IFn_Cast(A_arbace_box_build_A_const_7.GetRawRoot__O()).Invoke_O__O(d__2)) }
//line :315:1
func A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_New() *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A) Ctor() {}
//line :315:1
func (t *A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A) Invoke_O_O_O__O(self, i__1, d__2 any) any { return lang.Tuple_Create_O_O__IPersistentVector(i__1, lang.IFn_Cast(A_arbace_box_build_A_const_7.GetRawRoot__O()).Invoke_O__O(d__2)) }




func A_arbace_box_build_archives_iter__598000268__598000272_A_New() *A_arbace_box_build_archives_iter__598000268__598000272_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_iter__598000268__598000272_A{}; t.Ctor(); return t }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_A) Ctor() {}
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_A) Invoke_O_O__O(self, s__598000269__1 any) any { var tmp1 any = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_New_O_O(self, s__598000269__1); var tmp2 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_fn_class = fncls__63d; tmp2 = fncls__63d } else { tmp2 = fncls__63 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :320:1
func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_New_O_O(p0, p1 any) *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A{}; t.Ctor_O_O(p0, p1); return t }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A) Ctor_O_O(c__iter__598000268, c__s__598000269 any) { t.F_iter__598000268 = c__iter__598000268; t.F_s__598000269 = c__s__598000269 }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A) Invoke_O__O(self any) any { { var s__598000269__1 any; var t_ any = t.F_s__598000269; t.F_s__598000269 = nil; s__598000269__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(s__598000269__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000269__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(s__598000269__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(s__598000269__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000271__6 any = lang.IFn_Cast(A_arbace_box_build_A_const_23.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_New_O_I_O(b__598000271__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_fn_class = fncls__62d; tmp2 = fncls__62d } else { tmp2 = fncls__62 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__598000268); return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000271__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(s__598000269__3))) } else { return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000271__6), nil) } } else { var vec__598000279__4 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(s__598000269__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__598000279__4, lang.RT_IntCast_J__I(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O(vec__598000279__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000268); return lang.IFn_Cast(A_arbace_box_build_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(k__5, lang.IFn_Cast(A_arbace_box_build_A_const_7.GetRawRoot__O()).Invoke_O__O(f__6)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__598000269__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :320:1
func A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A) Ctor_O_I_O(c__b__598000271 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000271 = c__b__598000271; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :320:1
func (t *A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A) Invoke_O__O(self any) any { { var i__598000270__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000270__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__598000275__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000270__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__598000275__2, lang.RT_IntCast_J__I(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O(vec__598000275__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_27.GetRawRoot__O()); var tmp3 any = t.F_b__598000271; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(k__3, lang.IFn_Cast(A_arbace_box_build_A_const_7.GetRawRoot__O()).Invoke_O__O(f__4))); i__598000270__1 = lang.Numbers_Unchecked_inc_J__J(i__598000270__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_box_build_link_A_New() *A_arbace_box_build_link_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_box_build_link_A) Ctor() {}
//line :322:1
func (t *A_arbace_box_build_link_A) Invoke_O_O_O_O__O(self, plan__0, archives__1, opts__2 any) any { var p__4 any = lang.IFn_Cast(A_arbace_box_build_A_const_169.GetRawRoot__O()).Invoke_O__O(plan__0); var opts__5 any = lang.IFn_Cast(A_arbace_box_build_A_const_170.GetRawRoot__O()).Invoke_O_O__O(p__4, opts__2); var pkgs__6 any = A_arbace_box_build_A_const_40.Invoke_O__O(p__4); var index__7 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_21.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;







	lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_174.GetRawRoot__O()); var tmp5 any = A_arbace_box_build_link_fn__598000285_A_New(); var tmp6 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_box_build_link_fn__598000285_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_128, false); A_arbace_box_build_link_fn__598000285_A_fn_class = fncls__65d; tmp6 = fncls__65d } else { tmp6 = fncls__65 }; index__7 = tmp1.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), pkgs__6));
	lang.IFn_Cast(A_arbace_box_build_A_const_81.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, opts__5)); var tmp7 any; tmp22 := /*line :322:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var paths__10 any = lang.IFn_Cast(A_arbace_box_build_A_const_108.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_91, pkgs__6); var vec__598000287__11 any = lang.IFn_Cast(A_arbace_box_build_A_const_122.GetRawRoot__O()).Invoke_O_O_O__O(archives__1, index__7, paths__10); var dtree__12 any = lang.RT_Nth_O_I_O__O(vec__598000287__11, lang.RT_IntCast_J__I(0), nil); var lines__13 any = lang.RT_Nth_O_I_O__O(vec__598000287__11, lang.RT_IntCast_J__I(1), nil); var cfg__14 any; var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_45, nil); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_51.GetRawRoot__O()); var tmp10 any = A_arbace_box_build_A_const_14.GetRawRoot__O(); var tmp11 any; var iter__1927001039__auto____16 any; var tmp12 any = A_arbace_box_build_link_iter__598000290__598000294_A_New(); var tmp13 *jrt.Class
		var fncls__68 /*line :322:1*/*jrt.Class = A_arbace_box_build_link_iter__598000290__598000294_A_fn_class











		if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_129, false); A_arbace_box_build_link_iter__598000290__598000294_A_fn_class = fncls__68d; tmp13 = fncls__68d } else { tmp13 = fncls__68 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); tmp11 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(lines__13); cfg__14 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9.Invoke_O_O__O(tmp10, tmp11))).Ref()
//line :322:1
		var tmp14 any = A_arbace_box_build_A_const_141; var tmp15 *lang.Keyword = A_arbace_box_build_A_const_178; var tmp16 any = tmp15.Invoke_O__O(A_arbace_box_build_A_const_120.Invoke_O__O(opts__5)); var tmp17 any = A_arbace_box_build_A_const_78; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_86.GetRawRoot__O()); var tmp19 any = A_arbace_box_build_A_const_180; var tmp20 any = lang.IFn_Cast(A_arbace_box_build_A_const_90.GetRawRoot__O()).Invoke_O__O(tmp18.Invoke_O_O_O__O(tmp19, A_arbace_box_build_A_const_181.Invoke_O_O__O(opts__5, A_arbace_box_build_A_const_182), lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_131, nil, Lit_94), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(index__7).Invoke_O__O(A_arbace_box_build_A_const_177.Invoke_O__O(p__4)), nil)).Ref()))); var tmp21 any = A_arbace_box_build_A_const_143; var res__15 any = lang.IFn_Cast(A_arbace_box_build_A_const_79.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_130), jrt.RefArrayOf(jrt.Object_class, A_arbace_box_build_A_const_177.Invoke_O__O(p__4), nil)).Ref(), lang.IFn_Cast(A_arbace_box_build_A_const_123.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp16, tmp17, tmp20, tmp21, lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(Lit_63, dtree__12), lang.Tuple_Create_O_O__IPersistentVector(Lit_56, lang.IFn_Cast(A_arbace_box_build_A_const_145.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_132, cfg__14))))), A_arbace_box_build_A_const_84, Lit_133, A_arbace_box_build_A_const_179, Lit_133)), lang.IFn_Cast(A_arbace_box_build_A_const_148.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Get_O_O__O(A_arbace_box_build_A_const_125.Invoke_O__O(opts__5), A_arbace_box_build_A_const_178), A_arbace_box_build_A_const_183)))





















		tmp7 = lang.IFn_Cast(A_arbace_box_build_A_const_134.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_131.GetRawRoot__O()).Invoke_O_O_O__O(res__15, A_arbace_box_build_A_const_177.Invoke_O__O(p__4), Lit_134)) }; return nil }(); /*line :331:1*/lang.IFn_Cast(A_arbace_box_build_A_const_80.GetRawRoot__O()).Invoke__O(); if /*line :322:1*/ tmp22 != nil { panic(tmp22) }; return tmp7 }







func A_arbace_box_build_link_fn__598000285_A_New() *A_arbace_box_build_link_fn__598000285_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_fn__598000285_A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_box_build_link_fn__598000285_A) Ctor() {}
//line :330:1
func (t *A_arbace_box_build_link_fn__598000285_A) Invoke_O_O_O__O(self, i__1, q__2 any) any { return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_box_build_A_const_91.Invoke_O__O(q__2), i__1) }



func A_arbace_box_build_link_iter__598000290__598000294_A_New() *A_arbace_box_build_link_iter__598000290__598000294_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_iter__598000290__598000294_A{}; t.Ctor(); return t }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_A) Ctor() {}
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_A) Invoke_O_O__O(self, s__598000291__1 any) any { var tmp1 any = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_New_O_O(self, s__598000291__1); var tmp2 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_135, false); A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_fn_class = fncls__67d; tmp2 = fncls__67d } else { tmp2 = fncls__67 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :334:1
func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_New_O_O(p0, p1 any) *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A{}; t.Ctor_O_O(p0, p1); return t }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A) Ctor_O_O(c__iter__598000290, c__s__598000291 any) { t.F_iter__598000290 = c__iter__598000290; t.F_s__598000291 = c__s__598000291 }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A) Invoke_O__O(self any) any { { var s__598000291__1 any; var t_ any = t.F_s__598000291; t.F_s__598000291 = nil; s__598000291__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_box_build_A_const_15.GetRawRoot__O()).Invoke_O__O(s__598000291__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__598000291__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_box_build_A_const_16.GetRawRoot__O()).Invoke_O__O(s__598000291__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_box_build_A_const_17.GetRawRoot__O()).Invoke_O__O(s__598000291__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__598000293__6 any = lang.IFn_Cast(A_arbace_box_build_A_const_23.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_New_O_I_O(b__598000293__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_136, false); A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_fn_class = fncls__66d; tmp2 = fncls__66d } else { tmp2 = fncls__66 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__598000290); return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000293__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_19.GetRawRoot__O()).Invoke_O__O(s__598000291__3))) } else { return lang.IFn_Cast(A_arbace_box_build_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_30.GetRawRoot__O()).Invoke_O__O(b__598000293__6), nil) } } else { var l__4 any = lang.IFn_Cast(A_arbace_box_build_A_const_18.GetRawRoot__O()).Invoke_O__O(s__598000291__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__598000290); return lang.IFn_Cast(A_arbace_box_build_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, l__4, nil)).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_31.GetRawRoot__O()).Invoke_O__O(s__598000291__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :334:1
func A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A) Ctor_O_I_O(c__b__598000293 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__598000293 = c__b__598000293; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :334:1
func (t *A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A) Invoke_O__O(self any) any { { var i__598000292__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__598000292__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__598000292__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_27.GetRawRoot__O()); var tmp3 any = t.F_b__598000293; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, l__2, nil)).Ref()); i__598000292__1 = lang.Numbers_Unchecked_inc_J__J(i__598000292__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }











func A_arbace_box_build_build_A_New() *A_arbace_box_build_build_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_box_build_build_A) Ctor() {}
//line :346:1
func (t *A_arbace_box_build_build_A) Invoke_O_O_O__O(self, plan__0, opts__1 any) any { var p__3 any = lang.IFn_Cast(A_arbace_box_build_A_const_169.GetRawRoot__O()).Invoke_O__O(plan__0); var t0__4 int64 = jrt.System_NanoTime__J(); var as__5 any = lang.IFn_Cast(A_arbace_box_build_A_const_184.GetRawRoot__O()).Invoke_O_O__O(p__3, opts__1); var image__6 any = lang.IFn_Cast(A_arbace_box_build_A_const_185.GetRawRoot__O()).Invoke_O_O_O__O(p__3, as__5, opts__1); var temp__1927000414__auto____7 any = A_arbace_box_build_A_const_186.Invoke_O__O(opts__1); if







	jrt.A2g_Truth(temp__1927000414__auto____7) { var r__8 any = temp__1927000414__auto____7; lang.IFn_Cast(A_arbace_box_build_A_const_69.GetRawRoot__O()).Invoke_O_O__O(r__8, image__6) };
	lang.IFn_Cast(A_arbace_box_build_A_const_81.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_box_build_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_box_build_A_const_49, opts__1)); var tmp1 any = A_arbace_box_build_build_fn__598000301_A_New_O_O_J(p__3, image__6, t0__4); var tmp2 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_box_build_build_fn__598000301_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); A_arbace_box_build_build_fn__598000301_A_fn_class = fncls__69d; tmp2 = fncls__69d } else { tmp2 = fncls__69 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); return image__6 }
//line :346:1
func (t *A_arbace_box_build_build_A) Invoke_O_O__O(self, plan__0 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_187.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; return tmp1.Invoke_O_O__O(plan__0, tmp2.Ref())
}





func A_arbace_box_build_build_fn__598000301_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_box_build_build_fn__598000301_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_build_fn__598000301_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :355:1
func (t *A_arbace_box_build_build_fn__598000301_A) Ctor_O_O_J(c__p, c__image any, c__t0 int64) { t.F_p = c__p; t.F_image = c__image; t.F_t0 = c__t0 }
//line :355:1
func (t *A_arbace_box_build_build_fn__598000301_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_70.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_77.GetRawRoot__O()); var tmp4 any = A_arbace_box_build_A_const_177.Invoke_O__O(t.F_p); var tmp5 *lang.Keyword = A_arbace_box_build_A_const_40; var tmp6 any; var t_ any = t.F_p; t.F_p = nil; tmp6 = t_; var tmp7 any = jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(tmp5.Invoke_O__O(tmp6))).Ref(); var tmp8 any = t.F_image; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_box_build_A_const_62.GetRawRoot__O()); var tmp10 any; var t__2 any = t.F_image; t.F_image = nil; tmp10 = t__2; tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O_O_O_O_O_O__O(Lit_44, tmp4, tmp7, tmp8, tmp9.Invoke_O__O(tmp10), jrt.Double_ValueOf_D__Double(lang.Numbers_Divide_J_D__D(lang.Numbers_Minus_J_J__J(jrt.System_NanoTime__J(), t.F_t0), 1.0e9)).Ref())) }
//line :355:1
	return nil }(); lang.IFn_Cast(A_arbace_box_build_A_const_80.GetRawRoot__O()).Invoke__O(); if tmp11 != nil { panic(tmp11) }; return tmp1 }


























































































































































































































































type A_arbace_box_build_A struct{ jrt.Object }

var A_arbace_box_build_A_const_pool *jrt.RefArray

var A_arbace_box_build_A_const_0 *lang.Var

var A_arbace_box_build_A_const_1 *lang.Var

var A_arbace_box_build_A_const_2 any

var A_arbace_box_build_A_const_3 any

var A_arbace_box_build_A_const_4 any

var A_arbace_box_build_A_const_5 any

var A_arbace_box_build_A_const_6 *lang.Var

var A_arbace_box_build_A_const_7 *lang.Var

var A_arbace_box_build_A_const_8 *lang.Var

var A_arbace_box_build_A_const_9 any

var A_arbace_box_build_A_const_10 *lang.Var

var A_arbace_box_build_A_const_11 *lang.Var

var A_arbace_box_build_A_const_12 *lang.Var

var A_arbace_box_build_A_const_13 *lang.Keyword

var A_arbace_box_build_A_const_14 *lang.Var

var A_arbace_box_build_A_const_15 *lang.Var

var A_arbace_box_build_A_const_16 *lang.Var

var A_arbace_box_build_A_const_17 *lang.Var

var A_arbace_box_build_A_const_18 *lang.Var

var A_arbace_box_build_A_const_19 *lang.Var

var A_arbace_box_build_A_const_20 *lang.Var

var A_arbace_box_build_A_const_21 *lang.Var

var A_arbace_box_build_A_const_22 *lang.Var

var A_arbace_box_build_A_const_23 *lang.Var

var A_arbace_box_build_A_const_24 *lang.Var

var A_arbace_box_build_A_const_25 *lang.Var

var A_arbace_box_build_A_const_26 *lang.Keyword

var A_arbace_box_build_A_const_27 *lang.Var

var A_arbace_box_build_A_const_28 *lang.Var

var A_arbace_box_build_A_const_29 *lang.Var

var A_arbace_box_build_A_const_30 *lang.Var

var A_arbace_box_build_A_const_31 *lang.Var

var A_arbace_box_build_A_const_32 *lang.Var

var A_arbace_box_build_A_const_33 *lang.Var

var A_arbace_box_build_A_const_34 *lang.Var

var A_arbace_box_build_A_const_35 *lang.Var

var A_arbace_box_build_A_const_36 *lang.Var

var A_arbace_box_build_A_const_37 *lang.Var

var A_arbace_box_build_A_const_38 *lang.Var

var A_arbace_box_build_A_const_39 *lang.Var

var A_arbace_box_build_A_const_40 *lang.Keyword

var A_arbace_box_build_A_const_41 *lang.Var

var A_arbace_box_build_A_const_42 *lang.Var

var A_arbace_box_build_A_const_43 *lang.Keyword

var A_arbace_box_build_A_const_44 *lang.Keyword

var A_arbace_box_build_A_const_45 *lang.Var

var A_arbace_box_build_A_const_46 *lang.Var

var A_arbace_box_build_A_const_47 *lang.Var

var A_arbace_box_build_A_const_48 *lang.Keyword

var A_arbace_box_build_A_const_49 *lang.Var

var A_arbace_box_build_A_const_50 *lang.Var

var A_arbace_box_build_A_const_51 *lang.Var

var A_arbace_box_build_A_const_52 *lang.Var

var A_arbace_box_build_A_const_53 *lang.Var

var A_arbace_box_build_A_const_54 any

var A_arbace_box_build_A_const_55 any

var A_arbace_box_build_A_const_56 *lang.Var

var A_arbace_box_build_A_const_57 *lang.Keyword

var A_arbace_box_build_A_const_58 *lang.Keyword

var A_arbace_box_build_A_const_59 *lang.Var

var A_arbace_box_build_A_const_60 *lang.Keyword

var A_arbace_box_build_A_const_61 *lang.Var

var A_arbace_box_build_A_const_62 *lang.Var

var A_arbace_box_build_A_const_63 *lang.Var

var A_arbace_box_build_A_const_64 *lang.Keyword

var A_arbace_box_build_A_const_65 *lang.Var

var A_arbace_box_build_A_const_66 *lang.Keyword

var A_arbace_box_build_A_const_67 *lang.Var

var A_arbace_box_build_A_const_68 *lang.Var

var A_arbace_box_build_A_const_69 *lang.Var

var A_arbace_box_build_A_const_70 *lang.Var

var A_arbace_box_build_A_const_71 *lang.Keyword

var A_arbace_box_build_A_const_72 *lang.Var

var A_arbace_box_build_A_const_73 *lang.Keyword

var A_arbace_box_build_A_const_74 *lang.Keyword

var A_arbace_box_build_A_const_75 *lang.Keyword

var A_arbace_box_build_A_const_76 *lang.Keyword

var A_arbace_box_build_A_const_77 *lang.Var

var A_arbace_box_build_A_const_78 *lang.Keyword

var A_arbace_box_build_A_const_79 *lang.Var

var A_arbace_box_build_A_const_80 *lang.Var

var A_arbace_box_build_A_const_81 *lang.Var

var A_arbace_box_build_A_const_82 *lang.Var

var A_arbace_box_build_A_const_83 *lang.Var

var A_arbace_box_build_A_const_84 *lang.Keyword

var A_arbace_box_build_A_const_85 *lang.Keyword

var A_arbace_box_build_A_const_86 *lang.Var

var A_arbace_box_build_A_const_87 any

var A_arbace_box_build_A_const_88 *lang.Keyword

var A_arbace_box_build_A_const_89 *lang.Keyword

var A_arbace_box_build_A_const_90 *lang.Var

var A_arbace_box_build_A_const_91 *lang.Keyword

var A_arbace_box_build_A_const_92 *lang.Var

var A_arbace_box_build_A_const_93 *lang.Keyword

var A_arbace_box_build_A_const_94 any

var A_arbace_box_build_A_const_95 *lang.Var

var A_arbace_box_build_A_const_96 *lang.Var

var A_arbace_box_build_A_const_97 any

var A_arbace_box_build_A_const_98 any

var A_arbace_box_build_A_const_99 any

var A_arbace_box_build_A_const_100 any

var A_arbace_box_build_A_const_101 any

var A_arbace_box_build_A_const_102 any

var A_arbace_box_build_A_const_103 *lang.Var

var A_arbace_box_build_A_const_104 *lang.Var

var A_arbace_box_build_A_const_105 *lang.Var

var A_arbace_box_build_A_const_106 *lang.Keyword

var A_arbace_box_build_A_const_107 *lang.Var

var A_arbace_box_build_A_const_108 *lang.Var

var A_arbace_box_build_A_const_109 any

var A_arbace_box_build_A_const_110 any

var A_arbace_box_build_A_const_111 *lang.Keyword

var A_arbace_box_build_A_const_112 *lang.Var

var A_arbace_box_build_A_const_113 *lang.Var

var A_arbace_box_build_A_const_114 *lang.Var

var A_arbace_box_build_A_const_115 *lang.Var

var A_arbace_box_build_A_const_116 *lang.Var

var A_arbace_box_build_A_const_117 *lang.Var

var A_arbace_box_build_A_const_118 *lang.Var

var A_arbace_box_build_A_const_119 *lang.Var

var A_arbace_box_build_A_const_120 *lang.Keyword

var A_arbace_box_build_A_const_121 *lang.Keyword

var A_arbace_box_build_A_const_122 *lang.Var

var A_arbace_box_build_A_const_123 *lang.Var

var A_arbace_box_build_A_const_124 any

var A_arbace_box_build_A_const_125 *lang.Keyword

var A_arbace_box_build_A_const_126 *lang.Var

var A_arbace_box_build_A_const_127 *lang.Keyword

var A_arbace_box_build_A_const_128 *lang.Keyword

var A_arbace_box_build_A_const_129 *lang.Keyword

var A_arbace_box_build_A_const_130 *lang.Var

var A_arbace_box_build_A_const_131 *lang.Var

var A_arbace_box_build_A_const_132 *lang.Var

var A_arbace_box_build_A_const_133 *lang.Var

var A_arbace_box_build_A_const_134 *lang.Var

var A_arbace_box_build_A_const_135 *lang.Keyword

var A_arbace_box_build_A_const_136 *lang.Var

var A_arbace_box_build_A_const_137 *lang.Var

var A_arbace_box_build_A_const_138 *lang.Var

var A_arbace_box_build_A_const_139 *lang.Var

var A_arbace_box_build_A_const_140 *lang.Var

var A_arbace_box_build_A_const_141 *lang.Keyword

var A_arbace_box_build_A_const_142 *lang.Keyword

var A_arbace_box_build_A_const_143 *lang.Keyword

var A_arbace_box_build_A_const_144 *lang.Var

var A_arbace_box_build_A_const_145 *lang.Var

var A_arbace_box_build_A_const_146 any

var A_arbace_box_build_A_const_147 *lang.Keyword

var A_arbace_box_build_A_const_148 *lang.Var

var A_arbace_box_build_A_const_149 *lang.Keyword

var A_arbace_box_build_A_const_150 *lang.Keyword

var A_arbace_box_build_A_const_151 any

var A_arbace_box_build_A_const_152 *lang.Var

var A_arbace_box_build_A_const_153 any

var A_arbace_box_build_A_const_154 any

var A_arbace_box_build_A_const_155 any

var A_arbace_box_build_A_const_156 any

var A_arbace_box_build_A_const_157 any

var A_arbace_box_build_A_const_158 any

var A_arbace_box_build_A_const_159 *lang.Keyword

var A_arbace_box_build_A_const_160 any

var A_arbace_box_build_A_const_161 *lang.Var

var A_arbace_box_build_A_const_162 *lang.Var

var A_arbace_box_build_A_const_163 *lang.Var

var A_arbace_box_build_A_const_164 any

var A_arbace_box_build_A_const_165 *lang.Var

var A_arbace_box_build_A_const_166 *lang.Keyword

var A_arbace_box_build_A_const_167 *lang.Var

var A_arbace_box_build_A_const_168 any

var A_arbace_box_build_A_const_169 *lang.Var

var A_arbace_box_build_A_const_170 *lang.Var

var A_arbace_box_build_A_const_171 *lang.Keyword

var A_arbace_box_build_A_const_172 *lang.Keyword

var A_arbace_box_build_A_const_173 *lang.Keyword

var A_arbace_box_build_A_const_174 *lang.Var

var A_arbace_box_build_A_const_175 any

var A_arbace_box_build_A_const_176 *lang.Var

var A_arbace_box_build_A_const_177 *lang.Keyword

var A_arbace_box_build_A_const_178 *lang.Keyword

var A_arbace_box_build_A_const_179 *lang.Keyword

var A_arbace_box_build_A_const_180 any

var A_arbace_box_build_A_const_181 *lang.Keyword

var A_arbace_box_build_A_const_182 any

var A_arbace_box_build_A_const_183 any

var A_arbace_box_build_A_const_184 *lang.Var

var A_arbace_box_build_A_const_185 *lang.Var

var A_arbace_box_build_A_const_186 *lang.Keyword

var A_arbace_box_build_A_const_187 *lang.Var

var A_arbace_box_build_A_init jrt.ClassInit

func A_arbace_box_build_A_Init() { if !A_arbace_box_build_A_init.Done() { A_arbace_box_build_A_init.Run(A_arbace_box_build_A_clinit) } }

func A_arbace_box_build_A_clinit() { A_arbace_box_build_A_clinit_p0(); A_arbace_box_build_A_clinit_p1(); A_arbace_box_build_A_clinit_p2(); A_arbace_box_build_A_clinit_p3(); A_arbace_box_build_A_clinit_p4(); A_arbace_box_build_A_clinit_p5(); A_arbace_box_build_A_clinit_p6(); A_arbace_box_build_A_clinit_p7(); A_arbace_box_build_A_clinit_p8(); A_arbace_box_build_A_clinit_p9(); A_arbace_box_build_A_clinit_p10(); A_arbace_box_build_A_clinit_p11(); A_arbace_box_build_A_clinit_p12(); A_arbace_box_build_A_clinit_p13(); A_arbace_box_build_A_clinit_p14(); A_arbace_box_build_A_clinit_p15() }

func A_arbace_box_build_A_clinit_p0() { A_arbace_box_build_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 245); A_arbace_box_build_A_const_0 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[57]); A_arbace_box_build_A_const_1 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[58]); A_arbace_box_build_A_const_2 = A_arbace_box_build_A_const_pool.A[59]; A_arbace_box_build_A_const_3 = A_arbace_box_build_A_const_pool.A[60]; A_arbace_box_build_A_const_4 = A_arbace_box_build_A_const_pool.A[61]; A_arbace_box_build_A_const_5 = A_arbace_box_build_A_const_pool.A[62]; A_arbace_box_build_A_const_6 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[63]); A_arbace_box_build_A_const_7 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[64]); A_arbace_box_build_A_const_8 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[65]); A_arbace_box_build_A_const_9 = A_arbace_box_build_A_const_pool.A[66]; A_arbace_box_build_A_const_10 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[67]); A_arbace_box_build_A_const_11 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[68]) }

func A_arbace_box_build_A_clinit_p1() { A_arbace_box_build_A_const_12 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[69]); A_arbace_box_build_A_const_13 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[70]); A_arbace_box_build_A_const_14 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[71]); A_arbace_box_build_A_const_15 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[72]); A_arbace_box_build_A_const_16 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[73]); A_arbace_box_build_A_const_17 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[74]); A_arbace_box_build_A_const_18 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[75]); A_arbace_box_build_A_const_19 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[76]); A_arbace_box_build_A_const_20 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[77]); A_arbace_box_build_A_const_21 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[78]); A_arbace_box_build_A_const_22 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[79]); A_arbace_box_build_A_const_23 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[80]) }

func A_arbace_box_build_A_clinit_p2() { A_arbace_box_build_A_const_24 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[81]); A_arbace_box_build_A_const_25 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[82]); A_arbace_box_build_A_const_26 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[83]); A_arbace_box_build_A_const_27 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[84]); A_arbace_box_build_A_const_28 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[85]); A_arbace_box_build_A_const_29 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[86]); A_arbace_box_build_A_const_30 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[87]); A_arbace_box_build_A_const_31 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[88]); A_arbace_box_build_A_const_32 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[89]); A_arbace_box_build_A_const_33 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[90]); A_arbace_box_build_A_const_34 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[91]); A_arbace_box_build_A_const_35 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[92]) }

func A_arbace_box_build_A_clinit_p3() { A_arbace_box_build_A_const_36 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[93]); A_arbace_box_build_A_const_37 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[94]); A_arbace_box_build_A_const_38 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[95]); A_arbace_box_build_A_const_39 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[96]); A_arbace_box_build_A_const_40 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[97]); A_arbace_box_build_A_const_41 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[98]); A_arbace_box_build_A_const_42 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[99]); A_arbace_box_build_A_const_43 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[100]); A_arbace_box_build_A_const_44 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[101]); A_arbace_box_build_A_const_45 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[102]); A_arbace_box_build_A_const_46 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[103]); A_arbace_box_build_A_const_47 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[104]) }

func A_arbace_box_build_A_clinit_p4() { A_arbace_box_build_A_const_48 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[105]); A_arbace_box_build_A_const_49 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[106]); A_arbace_box_build_A_const_50 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[107]); A_arbace_box_build_A_const_51 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[108]); A_arbace_box_build_A_const_52 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[109]); A_arbace_box_build_A_const_53 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[110]); A_arbace_box_build_A_const_54 = A_arbace_box_build_A_const_pool.A[111]; A_arbace_box_build_A_const_55 = A_arbace_box_build_A_const_pool.A[112]; A_arbace_box_build_A_const_56 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[113]); A_arbace_box_build_A_const_57 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[114]); A_arbace_box_build_A_const_58 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[115]); A_arbace_box_build_A_const_59 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[116]) }

func A_arbace_box_build_A_clinit_p5() { A_arbace_box_build_A_const_60 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[117]); A_arbace_box_build_A_const_61 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[118]); A_arbace_box_build_A_const_62 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[119]); A_arbace_box_build_A_const_63 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[120]); A_arbace_box_build_A_const_64 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[121]); A_arbace_box_build_A_const_65 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[122]); A_arbace_box_build_A_const_66 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[123]); A_arbace_box_build_A_const_67 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[124]); A_arbace_box_build_A_const_68 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[125]); A_arbace_box_build_A_const_69 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[126]); A_arbace_box_build_A_const_70 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[127]); A_arbace_box_build_A_const_71 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[128]) }

func A_arbace_box_build_A_clinit_p6() { A_arbace_box_build_A_const_72 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[129]); A_arbace_box_build_A_const_73 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[130]); A_arbace_box_build_A_const_74 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[131]); A_arbace_box_build_A_const_75 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[132]); A_arbace_box_build_A_const_76 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[133]); A_arbace_box_build_A_const_77 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[134]); A_arbace_box_build_A_const_78 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[135]); A_arbace_box_build_A_const_79 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[136]); A_arbace_box_build_A_const_80 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[137]); A_arbace_box_build_A_const_81 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[138]); A_arbace_box_build_A_const_82 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[139]); A_arbace_box_build_A_const_83 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[140]) }

func A_arbace_box_build_A_clinit_p7() { A_arbace_box_build_A_const_84 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[141]); A_arbace_box_build_A_const_85 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[142]); A_arbace_box_build_A_const_86 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[143]); A_arbace_box_build_A_const_87 = A_arbace_box_build_A_const_pool.A[144]; A_arbace_box_build_A_const_88 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[145]); A_arbace_box_build_A_const_89 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[146]); A_arbace_box_build_A_const_90 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[147]); A_arbace_box_build_A_const_91 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[148]); A_arbace_box_build_A_const_92 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[149]); A_arbace_box_build_A_const_93 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[150]); A_arbace_box_build_A_const_94 = A_arbace_box_build_A_const_pool.A[151]; A_arbace_box_build_A_const_95 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[152]) }

func A_arbace_box_build_A_clinit_p8() { A_arbace_box_build_A_const_96 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[153]); A_arbace_box_build_A_const_97 = A_arbace_box_build_A_const_pool.A[154]; A_arbace_box_build_A_const_98 = A_arbace_box_build_A_const_pool.A[155]; A_arbace_box_build_A_const_99 = A_arbace_box_build_A_const_pool.A[156]; A_arbace_box_build_A_const_100 = A_arbace_box_build_A_const_pool.A[157]; A_arbace_box_build_A_const_101 = A_arbace_box_build_A_const_pool.A[158]; A_arbace_box_build_A_const_102 = A_arbace_box_build_A_const_pool.A[159]; A_arbace_box_build_A_const_103 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[160]); A_arbace_box_build_A_const_104 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[161]); A_arbace_box_build_A_const_105 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[162]); A_arbace_box_build_A_const_106 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[163]); A_arbace_box_build_A_const_107 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[164]); A_arbace_box_build_A_const_108 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[165]) }

func A_arbace_box_build_A_clinit_p9() { A_arbace_box_build_A_const_109 = A_arbace_box_build_A_const_pool.A[166]; A_arbace_box_build_A_const_110 = A_arbace_box_build_A_const_pool.A[167]; A_arbace_box_build_A_const_111 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[168]); A_arbace_box_build_A_const_112 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[169]); A_arbace_box_build_A_const_113 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[170]); A_arbace_box_build_A_const_114 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[171]); A_arbace_box_build_A_const_115 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[172]); A_arbace_box_build_A_const_116 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[173]); A_arbace_box_build_A_const_117 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[174]); A_arbace_box_build_A_const_118 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[175]); A_arbace_box_build_A_const_119 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[176]); A_arbace_box_build_A_const_120 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[177]) }

func A_arbace_box_build_A_clinit_p10() { A_arbace_box_build_A_const_121 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[178]); A_arbace_box_build_A_const_122 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[179]); A_arbace_box_build_A_const_123 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[180]); A_arbace_box_build_A_const_124 = A_arbace_box_build_A_const_pool.A[181]; A_arbace_box_build_A_const_125 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[182]); A_arbace_box_build_A_const_126 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[183]); A_arbace_box_build_A_const_127 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[184]); A_arbace_box_build_A_const_128 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[185]); A_arbace_box_build_A_const_129 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[186]); A_arbace_box_build_A_const_130 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[187]); A_arbace_box_build_A_const_131 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[188]); A_arbace_box_build_A_const_132 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[189]) }

func A_arbace_box_build_A_clinit_p11() { A_arbace_box_build_A_const_133 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[190]); A_arbace_box_build_A_const_134 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[191]); A_arbace_box_build_A_const_135 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[192]); A_arbace_box_build_A_const_136 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[193]); A_arbace_box_build_A_const_137 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[194]); A_arbace_box_build_A_const_138 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[195]); A_arbace_box_build_A_const_139 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[196]); A_arbace_box_build_A_const_140 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[197]); A_arbace_box_build_A_const_141 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[198]); A_arbace_box_build_A_const_142 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[199]); A_arbace_box_build_A_const_143 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[200]); A_arbace_box_build_A_const_144 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[201]) }

func A_arbace_box_build_A_clinit_p12() { A_arbace_box_build_A_const_145 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[202]); A_arbace_box_build_A_const_146 = A_arbace_box_build_A_const_pool.A[203]; A_arbace_box_build_A_const_147 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[204]); A_arbace_box_build_A_const_148 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[205]); A_arbace_box_build_A_const_149 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[206]); A_arbace_box_build_A_const_150 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[207]); A_arbace_box_build_A_const_151 = A_arbace_box_build_A_const_pool.A[208]; A_arbace_box_build_A_const_152 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[209]); A_arbace_box_build_A_const_153 = A_arbace_box_build_A_const_pool.A[210]; A_arbace_box_build_A_const_154 = A_arbace_box_build_A_const_pool.A[211]; A_arbace_box_build_A_const_155 = A_arbace_box_build_A_const_pool.A[212]; A_arbace_box_build_A_const_156 = A_arbace_box_build_A_const_pool.A[213]; A_arbace_box_build_A_const_157 = A_arbace_box_build_A_const_pool.A[214]; A_arbace_box_build_A_const_158 = A_arbace_box_build_A_const_pool.A[215] }

func A_arbace_box_build_A_clinit_p13() { A_arbace_box_build_A_const_159 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[216]); A_arbace_box_build_A_const_160 = A_arbace_box_build_A_const_pool.A[217]; A_arbace_box_build_A_const_161 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[218]); A_arbace_box_build_A_const_162 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[219]); A_arbace_box_build_A_const_163 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[220]); A_arbace_box_build_A_const_164 = A_arbace_box_build_A_const_pool.A[221]; A_arbace_box_build_A_const_165 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[222]); A_arbace_box_build_A_const_166 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[223]); A_arbace_box_build_A_const_167 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[224]); A_arbace_box_build_A_const_168 = A_arbace_box_build_A_const_pool.A[225]; A_arbace_box_build_A_const_169 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[226]); A_arbace_box_build_A_const_170 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[227]) }

func A_arbace_box_build_A_clinit_p14() { A_arbace_box_build_A_const_171 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[228]); A_arbace_box_build_A_const_172 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[229]); A_arbace_box_build_A_const_173 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[230]); A_arbace_box_build_A_const_174 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[231]); A_arbace_box_build_A_const_175 = A_arbace_box_build_A_const_pool.A[232]; A_arbace_box_build_A_const_176 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[233]); A_arbace_box_build_A_const_177 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[234]); A_arbace_box_build_A_const_178 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[235]); A_arbace_box_build_A_const_179 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[236]); A_arbace_box_build_A_const_180 = A_arbace_box_build_A_const_pool.A[237]; A_arbace_box_build_A_const_181 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[238]); A_arbace_box_build_A_const_182 = A_arbace_box_build_A_const_pool.A[239]; A_arbace_box_build_A_const_183 = A_arbace_box_build_A_const_pool.A[240] }

func A_arbace_box_build_A_clinit_p15() { A_arbace_box_build_A_const_184 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[241]); A_arbace_box_build_A_const_185 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[242]); A_arbace_box_build_A_const_186 = lang.Keyword_Cast(A_arbace_box_build_A_const_pool.A[243]); A_arbace_box_build_A_const_187 = lang.Var_Cast(A_arbace_box_build_A_const_pool.A[244]) }

func A_arbace_box_build_A_New() *A_arbace_box_build_A { A_arbace_box_build_A_Init(); t := &A_arbace_box_build_A{}; t.Ctor(); return t }

func (t *A_arbace_box_build_A) Ctor() {}

func (t *A_arbace_box_build_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_A_class }

func (t *A_arbace_box_build_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_A); return ok }

func A_arbace_box_build_A_Cast(x any) *A_arbace_box_build_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_A_class)) }; return v }



type A_arbace_box_build_action_A struct{ a2g_header uint64 }

var A_arbace_box_build_action_A_fn_class *jrt.Class



type A_arbace_box_build_action_STAR__A struct{ a2g_header uint64 }

var A_arbace_box_build_action_STAR__A_fn_class *jrt.Class



type A_arbace_box_build_append_members_A struct{ a2g_header uint64 }

var A_arbace_box_build_append_members_A_fn_class *jrt.Class



type A_arbace_box_build_ar_member_A struct{ a2g_header uint64 }

var A_arbace_box_build_ar_member_A_fn_class *jrt.Class



type A_arbace_box_build_ar_member_pad__598000077_A struct{ a2g_header uint64 }

var A_arbace_box_build_ar_member_pad__598000077_A_fn_class *jrt.Class



type A_arbace_box_build_arch_defines_A struct{ a2g_header uint64 }

var A_arbace_box_build_arch_defines_A_fn_class *jrt.Class



type A_arbace_box_build_archives_A struct{ a2g_header uint64 }

var A_arbace_box_build_archives_A_fn_class *jrt.Class



type A_arbace_box_build_archives_conveyed__598000244_A struct{ a2g_header uint64; F_opts any }

var A_arbace_box_build_archives_conveyed__598000244_A_fn_class *jrt.Class



type A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A struct{ a2g_header uint64; F_f, F_o any }

var A_arbace_box_build_archives_conveyed__598000244_fn__598000245_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000242_A struct{ a2g_header uint64 }

var A_arbace_box_build_archives_fn__598000242_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000252_A struct{ a2g_header uint64; F_given, F_q any }

var A_arbace_box_build_archives_fn__598000252_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000254_A struct{ a2g_header uint64; F_index, F_p, F_deps, F_sem, F_conveyed, F_q any }

var A_arbace_box_build_archives_fn__598000254_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000254_fn__598000255_A struct{ a2g_header uint64; F_index, F_p, F_deps, F_sem, F_q any }

var A_arbace_box_build_archives_fn__598000254_fn__598000255_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A struct{ a2g_header uint64 }

var A_arbace_box_build_archives_fn__598000254_fn__598000255_fn__598000256_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000260_A struct{ a2g_header uint64; F_given, F_q any }

var A_arbace_box_build_archives_fn__598000260_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000262_A struct{ a2g_header uint64; F_index, F_p, F_deps, F_sem, F_conveyed, F_q any }

var A_arbace_box_build_archives_fn__598000262_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000262_fn__598000263_A struct{ a2g_header uint64; F_index, F_p, F_deps, F_sem, F_q any }

var A_arbace_box_build_archives_fn__598000262_fn__598000263_A_fn_class *jrt.Class



type A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A struct{ a2g_header uint64 }

var A_arbace_box_build_archives_fn__598000262_fn__598000263_fn__598000264_A_fn_class *jrt.Class



type A_arbace_box_build_archives_iter__598000268__598000272_A struct{ a2g_header uint64 }

var A_arbace_box_build_archives_iter__598000268__598000272_A_fn_class *jrt.Class



type A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A struct{ a2g_header uint64; F_iter__598000268, F_s__598000269 any }

var A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_A_fn_class *jrt.Class



type A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A struct{ a2g_header uint64; F_b__598000271 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_archives_iter__598000268__598000272_fn__598000273_fn__598000274_A_fn_class *jrt.Class



type A_arbace_box_build_asm_args_A struct{ a2g_header uint64 }

var A_arbace_box_build_asm_args_A_fn_class *jrt.Class



type A_arbace_box_build_asm_args_fn__598000074_A struct{ a2g_header uint64; F_pkg any }

var A_arbace_box_build_asm_args_fn__598000074_A_fn_class *jrt.Class



type A_arbace_box_build_build_A struct{ a2g_header uint64 }

var A_arbace_box_build_build_A_fn_class *jrt.Class



type A_arbace_box_build_build_fn__598000301_A struct{ a2g_header uint64; F_p, F_image any; F_t0 int64 }

var A_arbace_box_build_build_fn__598000301_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_A struct{ a2g_header uint64 }

var A_arbace_box_build_build_package_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_fn__598000179_A struct{ a2g_header uint64; F_P any }

var A_arbace_box_build_build_package_fn__598000179_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_fn__598000184_A struct{ a2g_header uint64 }

var A_arbace_box_build_build_package_fn__598000184_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_fn__598000186_A struct{ a2g_header uint64 }

var A_arbace_box_build_build_package_fn__598000186_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000150__598000154_A struct{ a2g_header uint64 }

var A_arbace_box_build_build_package_iter__598000150__598000154_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A struct{ a2g_header uint64; F_iter__598000150, F_s__598000151 any }

var A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A struct{ a2g_header uint64; F_b__598000153 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_build_package_iter__598000150__598000154_fn__598000155_fn__598000156_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000166__598000170_A struct{ a2g_header uint64 }

var A_arbace_box_build_build_package_iter__598000166__598000170_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A struct{ a2g_header uint64; F_s__598000167, F_iter__598000166 any }

var A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A struct{ a2g_header uint64; F_b__598000169 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_build_package_iter__598000166__598000170_fn__598000171_fn__598000172_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_A struct{ a2g_header uint64; F_res_of, F_P, F_plan, F_ctree, F_pkg, F_tools any }

var A_arbace_box_build_build_package_iter__598000189__598000193_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A struct{ a2g_header uint64; F_res_of, F_P, F_plan, F_ctree, F_pkg, F_tools, F_s__598000190, F_iter__598000189 any }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A struct{ a2g_header uint64; F_b__598000192, F_res_of, F_P, F_plan, F_ctree, F_pkg, F_tools any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A struct{ a2g_header uint64; F_res_of, F_P, F_plan, F_ctree, F_pkg, F_o, F_s, F_tools any }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000195_fn__598000196_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A struct{ a2g_header uint64; F_res_of, F_P, F_plan, F_o, F_ctree, F_pkg, F_s, F_tools any }

var A_arbace_box_build_build_package_iter__598000189__598000193_fn__598000194_fn__598000199_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000203__598000207_A struct{ a2g_header uint64 }

var A_arbace_box_build_build_package_iter__598000203__598000207_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A struct{ a2g_header uint64; F_iter__598000203, F_s__598000204 any }

var A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A struct{ a2g_header uint64; F_b__598000206 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_build_package_iter__598000203__598000207_fn__598000208_fn__598000209_A_fn_class *jrt.Class



type A_arbace_box_build_build_package_res_of__598000176_A struct{ a2g_header uint64; F_P any }

var A_arbace_box_build_build_package_res_of__598000176_A_fn_class *jrt.Class



type A_arbace_box_build_cache_ref_A struct{ a2g_header uint64 }

var A_arbace_box_build_cache_ref_A_fn_class *jrt.Class



type A_arbace_box_build_complete_QMARK__A struct{ a2g_header uint64 }

var A_arbace_box_build_complete_QMARK__A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_A struct{ a2g_header uint64 }

var A_arbace_box_build_deps_tree_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000092__598000096_A struct{ a2g_header uint64; F_archives, F_index any }

var A_arbace_box_build_deps_tree_iter__598000092__598000096_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A struct{ a2g_header uint64; F_archives, F_index, F_iter__598000092, F_s__598000093 any }

var A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A struct{ a2g_header uint64; F_b__598000095, F_archives, F_index any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_deps_tree_iter__598000092__598000096_fn__598000097_fn__598000098_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000102__598000106_A struct{ a2g_header uint64; F_index any }

var A_arbace_box_build_deps_tree_iter__598000102__598000106_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A struct{ a2g_header uint64; F_s__598000103, F_index, F_iter__598000102 any }

var A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_A_fn_class *jrt.Class



type A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A struct{ a2g_header uint64; F_index, F_b__598000105 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_deps_tree_iter__598000102__598000106_fn__598000107_fn__598000108_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_A struct{ a2g_header uint64 }

var A_arbace_box_build_embed_config_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000116__598000120_A struct{ a2g_header uint64 }

var A_arbace_box_build_embed_config_iter__598000116__598000120_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A struct{ a2g_header uint64; F_iter__598000116, F_s__598000117 any }

var A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A struct{ a2g_header uint64; F_b__598000119 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_embed_config_iter__598000116__598000120_fn__598000121_fn__598000122_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000132__598000136_A struct{ a2g_header uint64 }

var A_arbace_box_build_embed_config_iter__598000132__598000136_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A struct{ a2g_header uint64; F_s__598000133, F_iter__598000132 any }

var A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_A_fn_class *jrt.Class



type A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A struct{ a2g_header uint64; F_b__598000135 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_embed_config_iter__598000132__598000136_fn__598000137_fn__598000138_A_fn_class *jrt.Class



type A_arbace_box_build_eval598000004_A struct{ jrt.Object }

func A_arbace_box_build_eval598000004_A_New() *A_arbace_box_build_eval598000004_A { t := &A_arbace_box_build_eval598000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_build_eval598000004_A) Ctor() {}

func (t *A_arbace_box_build_eval598000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_eval598000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_eval598000004_A_class }

func (t *A_arbace_box_build_eval598000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_eval598000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_eval598000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_eval598000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_eval598000004_A); return ok }

func A_arbace_box_build_eval598000004_A_Cast(x any) *A_arbace_box_build_eval598000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_eval598000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_eval598000004_A_class)) }; return v }



type A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A struct{ a2g_header uint64 }

var A_arbace_box_build_eval598000004_loading__1927001464__auto____598000005_A_fn_class *jrt.Class



type A_arbace_box_build_eval598000008_A struct{ jrt.Object }

func A_arbace_box_build_eval598000008_A_New() *A_arbace_box_build_eval598000008_A { t := &A_arbace_box_build_eval598000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_build_eval598000008_A) Ctor() {}

func (t *A_arbace_box_build_eval598000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_build_eval598000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_build_eval598000008_A_class }

func (t *A_arbace_box_build_eval598000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_build_eval598000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_build_eval598000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_build_eval598000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_build_eval598000008_A); return ok }

func A_arbace_box_build_eval598000008_A_Cast(x any) *A_arbace_box_build_eval598000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_build_eval598000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_build_eval598000008_A_class)) }; return v }



type A_arbace_box_build_eval598000008_fn__598000009_A struct{ a2g_header uint64 }

var A_arbace_box_build_eval598000008_fn__598000009_A_fn_class *jrt.Class



type A_arbace_box_build_fail_A struct{ a2g_header uint64 }

var A_arbace_box_build_fail_A_fn_class *jrt.Class



type A_arbace_box_build_file_tree_A struct{ a2g_header uint64 }

var A_arbace_box_build_file_tree_A_fn_class *jrt.Class



type A_arbace_box_build_file_tree_iter__598000054__598000058_A struct{ a2g_header uint64 }

var A_arbace_box_build_file_tree_iter__598000054__598000058_A_fn_class *jrt.Class



type A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A struct{ a2g_header uint64; F_s__598000055, F_iter__598000054 any }

var A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_A_fn_class *jrt.Class



type A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A struct{ a2g_header uint64; F_b__598000057 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_file_tree_iter__598000054__598000058_fn__598000059_fn__598000060_A_fn_class *jrt.Class



type A_arbace_box_build_import_plan_A struct{ a2g_header uint64 }

var A_arbace_box_build_import_plan_A_fn_class *jrt.Class



type A_arbace_box_build_import_plan_fn__598000044_A struct{ a2g_header uint64; F_src any }

var A_arbace_box_build_import_plan_fn__598000044_A_fn_class *jrt.Class



type A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A struct{ a2g_header uint64; F_src any }

var A_arbace_box_build_import_plan_fn__598000044_fn__598000045_A_fn_class *jrt.Class



type A_arbace_box_build_import_plan_src__598000042_A struct{ a2g_header uint64; F_dirs any }

var A_arbace_box_build_import_plan_src__598000042_A_fn_class *jrt.Class



type A_arbace_box_build_json_str_A struct{ a2g_header uint64 }

var A_arbace_box_build_json_str_A_fn_class *jrt.Class



type A_arbace_box_build_json_str_fn__598000113_A struct{ a2g_header uint64 }

var A_arbace_box_build_json_str_fn__598000113_A_fn_class *jrt.Class



type A_arbace_box_build_link_A struct{ a2g_header uint64 }

var A_arbace_box_build_link_A_fn_class *jrt.Class



type A_arbace_box_build_link_fn__598000285_A struct{ a2g_header uint64 }

var A_arbace_box_build_link_fn__598000285_A_fn_class *jrt.Class



type A_arbace_box_build_link_iter__598000290__598000294_A struct{ a2g_header uint64 }

var A_arbace_box_build_link_iter__598000290__598000294_A_fn_class *jrt.Class



type A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A struct{ a2g_header uint64; F_iter__598000290, F_s__598000291 any }

var A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_A_fn_class *jrt.Class



type A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A struct{ a2g_header uint64; F_b__598000293 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_link_iter__598000290__598000294_fn__598000295_fn__598000296_A_fn_class *jrt.Class



type A_arbace_box_build_log_A struct{ a2g_header uint64 }

var A_arbace_box_build_log_A_fn_class *jrt.Class



type A_arbace_box_build_out_file_A struct{ a2g_header uint64 }

var A_arbace_box_build_out_file_A_fn_class *jrt.Class



type A_arbace_box_build_read_plan_A struct{ a2g_header uint64 }

var A_arbace_box_build_read_plan_A_fn_class *jrt.Class



type A_arbace_box_build_sha256_hex_A struct{ a2g_header uint64 }

var A_arbace_box_build_sha256_hex_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_A struct{ a2g_header uint64 }

var A_arbace_box_build_source_tree_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_headers__598000018_A struct{ a2g_header uint64 }

var A_arbace_box_build_source_tree_headers__598000018_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A struct{ a2g_header uint64; F_headers any }

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A struct{ a2g_header uint64; F_iter__598000019, F_headers, F_s__598000020 any }

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A struct{ a2g_header uint64; F_headers, F_b__598000022 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_source_tree_headers__598000018_iter__598000019__598000023_fn__598000024_fn__598000025_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_iter__598000030__598000034_A struct{ a2g_header uint64; F_headers any }

var A_arbace_box_build_source_tree_iter__598000030__598000034_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A struct{ a2g_header uint64; F_headers, F_iter__598000030, F_s__598000031 any }

var A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_A_fn_class *jrt.Class



type A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A struct{ a2g_header uint64; F_headers, F_b__598000033 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_source_tree_iter__598000030__598000034_fn__598000035_fn__598000036_A_fn_class *jrt.Class



type A_arbace_box_build_with_tools_A struct{ a2g_header uint64 }

var A_arbace_box_build_with_tools_A_fn_class *jrt.Class



type A_arbace_box_build_with_tools_iter__598000221__598000225_A struct{ a2g_header uint64; F_arch any }

var A_arbace_box_build_with_tools_iter__598000221__598000225_A_fn_class *jrt.Class



type A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A struct{ a2g_header uint64; F_s__598000222, F_arch, F_iter__598000221 any }

var A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_A_fn_class *jrt.Class



type A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A struct{ a2g_header uint64; F_b__598000224, F_arch any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_box_build_with_tools_iter__598000221__598000225_fn__598000226_fn__598000227_A_fn_class *jrt.Class
